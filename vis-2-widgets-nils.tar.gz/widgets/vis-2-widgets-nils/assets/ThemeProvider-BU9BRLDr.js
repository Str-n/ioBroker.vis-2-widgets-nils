import { h as u, g as f, m as c, __tla as __tla_0 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__prop_mf_2_types__loadShare__.js-Btvp0r21.js";
import { j as i, __tla as __tla_2 } from "./jsx-runtime-BoEuoyzn.js";
let y, h, _;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  const m = u(null);
  _ = function() {
    return f(m);
  };
  let l;
  l = typeof Symbol == "function" && Symbol.for;
  h = l ? Symbol.for("mui.nested") : "__THEME_NESTED__";
  function a(e, t) {
    return typeof t == "function" ? t(e) : {
      ...e,
      ...t
    };
  }
  y = function(e) {
    const { children: t, theme: n } = e, o = _(), s = c(() => {
      const r = o === null ? {
        ...n
      } : a(o, n);
      return r != null && (r[h] = o !== null), r;
    }, [
      n,
      o
    ]);
    return i.jsx(m.Provider, {
      value: s,
      children: t
    });
  };
});
export {
  y as T,
  __tla,
  h as n,
  _ as u
};
