import { j as e, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { a, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { h as s } from "./moment-BLMuvzoS.js";
import { a as u, b as o, c as N, d as j, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { a as D, __tla as __tla_3 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CRxa-Ic2.js";
import { G as T } from "./Generic-CC2u2WPj.js";
import { __tla as __tla_4 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
let r;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  const i = {
    dialogTitle: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    },
    fullCamera: {
      width: "100%",
      height: "100%",
      objectFit: "contain"
    },
    dialogTime: {
      position: "absolute",
      bottom: 3,
      right: 3,
      opacity: 0.8,
      fontStyle: "italic",
      fontSize: 14
    },
    camera: {
      width: "100%",
      height: "100%",
      objectFit: "contain",
      cursor: "pointer"
    },
    time: {
      textAlign: "right",
      width: "100%",
      paddingTop: 20,
      fontSize: 12,
      opacity: 0.8,
      fontStyle: "italic",
      position: "absolute",
      bottom: 3,
      right: 3
    },
    dialogContent: {
      display: "flex",
      flexDirection: "column"
    },
    dialogImageContainer: {
      flex: 1,
      overflow: "hidden",
      display: "flex",
      position: "relative"
    },
    imageContainer: {
      flex: 1,
      overflow: "hidden",
      position: "relative",
      width: "100%",
      height: "100%"
    }
  }, l = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA1MTIuMDAxIDUxMi4wMDEiPg0KCTxwYXRoIGZpbGw9ImN1cnJlbnRDb2xvciIgZD0iTTQzNy4wMTksNzQuOTgyQzM4OC42NjcsMjYuNjMsMzI0LjM3OSwwLjAwMSwyNTUuOTk5LDAuMDAxUzEyMy4zMzIsMjYuNjMsNzQuOTgxLDc0Ljk4Mg0KCQlDMjYuNjI4LDEyMy4zMzMsMCwxODcuNjIxLDAsMjU2LjAwMXMyNi42MjgsMTMyLjY2Nyw3NC45ODEsMTgxLjAxOEMxMjMuMzMyLDQ4NS4zNzIsMTg3LjYxOSw1MTIsMjU2LjAwMSw1MTINCgkJYzY4LjM3OSwwLDEzMi42NjYtMjYuNjI4LDE4MS4wMi03NC45ODFjNDguMzUxLTQ4LjM1MSw3NC45ODEtMTEyLjYzOSw3NC45ODEtMTgxLjAxOFM0ODUuMzcsMTIzLjMzMyw0MzcuMDE5LDc0Ljk4MnoNCgkJIE0yNTYuMDAxLDQ5My42OTFjLTYzLjQ5LDAuMDAxLTEyMy4xODEtMjQuNzI0LTE2OC4wNzMtNjkuNjE4QzQzLjAzMywzNzkuMTgsMTguMzA5LDMxOS40OTEsMTguMzA5LDI1Ni4wMDENCgkJYzAtNjAuNDI4LDIyLjQxMS0xMTcuNDAzLDYzLjI3OS0xNjEuNDY1bDU3LjcxOSw1Ny43MTloLTI1LjE2MWMtMTguNjkzLDAtMzMuOTAyLDE1LjIwOS0zMy45MDIsMzMuOTAydjE2NC43MDgNCgkJYzAsMTguNjkzLDE1LjIwOSwzMy45MDIsMzMuOTAyLDMzLjkwMkgzNzEuODJsNDUuNjQ1LDQ1LjY0NUMzNzMuNDAyLDQ3MS4yNzksMzE2LjQyNyw0OTMuNjkxLDI1Ni4wMDEsNDkzLjY5MXogTTI5Mi42MTMsMTcwLjU2NA0KCQloMzEuMTI0djMyLjk1M2MwLDUuMDU2LDQuMDk4LDkuMTU0LDkuMTU0LDkuMTU0aDgwLjU1NHYxMzguMTkzYzAsOC41OTgtNi45OTUsMTUuNTkzLTE1LjU5MywxNS41OTNoLTE4LjQ1bC01NS4wMjgtNTUuMDI4DQoJCWM3LjgzOS0xMi40NDQsMTIuMzk1LTI3LjE1NiwxMi4zOTUtNDIuOTE4YzAtNDQuNTM3LTM2LjIzMy04MC43Ny04MC43Ny04MC43N2MtMTUuNzYzLDAtMzAuNDczLDQuNTU1LTQyLjkxOCwxMi4zOTUNCgkJbC0yOS41NzItMjkuNTcyaDM1Ljg3M0gyOTIuNjEzeiBNMjI4LjUzNywxNTIuMjU1di0yMC4xMzdoNTQuOTIzdjIwLjEzN0gyMjguNTM3eiBNMzQyLjA0OSwxOTQuMzYzdi0yMy43OTloNTUuODA3DQoJCWM4LjU5OCwwLDE1LjU5Myw2Ljk5NSwxNS41OTMsMTUuNTkzdjguMjA2SDM0Mi4wNDl6IE0yNTUuOTk5LDMxMi4yMzljMTEuOTQ1LDAsMjIuNzgyLTQuODE5LDMwLjY4Mi0xMi42MWwxMy4yNDEsMTMuMjQxDQoJCWMtMTEuMjkzLDExLjE4Mi0yNi44MTMsMTguMTAzLTQzLjkyMywxOC4xMDNjLTM0LjQ0MSwwLTYyLjQ2MS0yOC4wMi02Mi40NjEtNjIuNDYxYzAtMTcuMTEsNi45Mi0zMi42MywxOC4xMDMtNDMuOTIzDQoJCWwxMy4yNCwxMy4yNGMtNy43OTEsNy45LTEyLjYxLDE4LjczNy0xMi42MSwzMC42ODNDMjEyLjI3MSwyOTIuNjIzLDIzMS44ODcsMzEyLjIzOSwyNTUuOTk5LDMxMi4yMzl6IE0yNzMuNzM3LDI4Ni42ODUNCgkJYy00LjU4NSw0LjQ3NS0xMC44NCw3LjI0NS0xNy43MzYsNy4yNDVjLTE0LjAxNiwwLTI1LjQyLTExLjQwMy0yNS40Mi0yNS40MTljLTAuMDAxLTYuODk4LDIuNzctMTMuMTUzLDcuMjQ1LTE3LjczOA0KCQlMMjczLjczNywyODYuNjg1eiBNMjU2LjA0LDI0My4wOTRjMTMuOTg0LDAuMDIyLDI1LjM1NSwxMS4zOTMsMjUuMzc3LDI1LjM3N0wyNTYuMDQsMjQzLjA5NHogTTI5Ni45MDEsMjgzLjk1Nw0KCQljMS44MjEtNC44MDUsMi44MjYtMTAuMDA5LDIuODI2LTE1LjQ0NWMwLTI0LjExMi0xOS42MTYtNDMuNzI5LTQzLjcyOC00My43MjljLTUuNDM3LDAtMTAuNjQsMS4wMDUtMTUuNDQ1LDIuODI2bC0xNC4xMDgtMTQuMTA4DQoJCWM4LjgwNC00Ljc0OSwxOC44NjgtNy40NTEsMjkuNTU0LTcuNDUxYzM0LjQ0MSwwLDYyLjQ2MSwyOC4wMiw2Mi40NjEsNjIuNDYxYy0wLjAwMSwxMC42ODUtMi43MDIsMjAuNzUtNy40NTIsMjkuNTU0DQoJCUwyOTYuOTAxLDI4My45NTd6IE0xOTguNzAxLDIxMS42NDhjLTE0LjQ5OCwxNC42MDgtMjMuNDcxLDM0LjcwNi0yMy40NzEsNTYuODY0YzAsNDQuNTM3LDM2LjIzMyw4MC43Nyw4MC43Nyw4MC43Nw0KCQljMjIuMTU3LDAsNDIuMjU2LTguOTc0LDU2Ljg2Mi0yMy40NzFsNDAuNjQ4LDQwLjY0OEgxMTQuMTQ2Yy04LjU5OCwwLTE1LjU5My02Ljk5NS0xNS41OTMtMTUuNTkzVjE4Ni4xNTcNCgkJYzAtOC41OTgsNi45OTUtMTUuNTkzLDE1LjU5My0xNS41OTNoNDMuNDcxTDE5OC43MDEsMjExLjY0OHogTTQzMC40MTIsNDE3LjQ2NmwtMzIuNjk4LTMyLjY5OGgwLjE0Mg0KCQljMTguNjkzLDAsMzMuOTAyLTE1LjIwOSwzMy45MDItMzMuOTAyVjE4Ni4xNTdjMC0xOC42OTMtMTUuMjA5LTMzLjkwMi0zMy45MDItMzMuOTAySDMwMS43N3YtMjkuMjkyDQoJCWMwLTUuMDU2LTQuMDk4LTkuMTU0LTkuMTU0LTkuMTU0aC03My4yMzJjLTUuMDU3LDAtOS4xNTQsNC4wOTktOS4xNTQsOS4xNTR2MjkuMjkzaC00NS4wMjhMOTQuNTM1LDgxLjU4OQ0KCQlDMTM4LjU5Nyw0MC43MjMsMTk1LjU3MiwxOC4zMSwyNTUuOTk5LDE4LjMxYzYzLjQ4OSwwLDEyMy4xNzgsMjQuNzI0LDE2OC4wNzMsNjkuNjE5DQoJCWM0NC44OTUsNDQuODkzLDY5LjYxOSwxMDQuNTgzLDY5LjYxOSwxNjguMDczQzQ5My42OTEsMzE2LjQzLDQ3MS4yOCwzNzMuNDA0LDQzMC40MTIsNDE3LjQ2NnoiLz4NCgk8Y2lyY2xlIGZpbGw9ImN1cnJlbnRDb2xvciIgY3g9IjE2OC4xMjQiIGN5PSIzMjkuODQxIiByPSI5LjE1NCIvPg0KPC9zdmc+DQo=";
  r = class extends T {
    imageRef = a.createRef();
    fullImageRef = a.createRef();
    imageInterval = null;
    fullImageInterval = null;
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        dialog: false,
        refreshTime: 0,
        fullRefreshTime: 0
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2Camera",
        visSet: "vis-2-widgets-nils",
        visName: "Camera",
        visWidgetLabel: "camera",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                noBinding: false
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "url",
                label: "url",
                hidden: (t) => !!t["url-oid"],
                default: "https://loremflickr.com/320/240/germany",
                tooltip: "delete_to_use_oid"
              },
              {
                name: "url-oid",
                label: "url_oid",
                hidden: (t) => !!t.url,
                default: "",
                noInit: true,
                tooltip: "delete_to_use_constant_url"
              },
              {
                name: "refreshInterval",
                type: "number",
                default: 2e3,
                label: "refresh_interval",
                tooltip: "refresh_interval_tooltip"
              },
              {
                name: "fullUrl",
                label: "full_url",
                hidden: (t) => !!t["url-oid"]
              },
              {
                name: "fullRefreshInterval",
                type: "number",
                label: "full_refresh",
                tooltip: "full_refresh_interval_tooltip"
              },
              {
                name: "showRefreshTime",
                type: "checkbox",
                label: "show_refresh_time",
                default: true,
                noBinding: false
              },
              {
                name: "rotateVideo",
                type: "slider",
                label: "rotate_video",
                min: 0,
                max: 359,
                default: 0
              },
              {
                name: "doNotAddTimestamp",
                type: "checkbox",
                label: "do_not_add_timestamp",
                default: true,
                noBinding: false,
                tooltip: "do_not_add_timestamp_tooltip"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 240,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_camera.png"
      };
    }
    getWidgetInfo() {
      return r.getWidgetInfo();
    }
    takeUrl(t = false) {
      let M = t ? this.state.rxData.fullUrl || this.state.rxData.url : this.state.rxData.url;
      return this.state.rxData["url-oid"] && (M = this.getPropertyValue("url-oid")), M ? this.state.rxData.doNotAddTimestamp === true || this.state.rxData.doNotAddTimestamp === "true" ? M : M + (M.includes("?") ? "&_ts=" : "?_ts=") + Date.now() : l;
    }
    propertiesUpdate() {
      this.imageInterval && (clearInterval(this.imageInterval), this.imageInterval = null), this.imageInterval = setInterval(async () => {
        const t = this.takeUrl();
        await fetch(t, {
          cache: "reload",
          mode: "no-cors"
        }), this.imageRef.current && (this.imageRef.current.src = t), this.setState({
          refreshTime: Date.now()
        });
      }, this.state.rxData.refreshInterval >= 1e3 ? this.state.rxData.refreshInterval : 1e3), this.fullImageInterval && (clearInterval(this.fullImageInterval), this.fullImageInterval = null), this.state.dialog && (this.fullImageInterval = setInterval(async () => {
        const t = this.takeUrl(true);
        await fetch(t, {
          cache: "reload",
          mode: "no-cors"
        }), this.fullImageRef.current && (this.fullImageRef.current.src = t), this.setState({
          fullRefreshTime: Date.now()
        });
      }, (this.state.rxData.fullRefreshInterval || this.state.rxData.refreshInterval) >= 500 ? this.state.rxData.fullRefreshInterval || this.state.rxData.refreshInterval : 500));
    }
    componentDidMount() {
      super.componentDidMount(), this.propertiesUpdate();
    }
    onRxDataChanged() {
      this.propertiesUpdate();
    }
    componentWillUnmount() {
      super.componentWillUnmount(), this.imageInterval && clearInterval(this.imageInterval), this.fullImageInterval && clearInterval(this.fullImageInterval);
    }
    closeDialog = () => {
      this.setState({
        dialog: false
      }), this.fullImageInterval && (clearInterval(this.fullImageInterval), this.fullImageInterval = null);
    };
    renderDialog() {
      return this.state.dialog ? e.jsxs(u, {
        open: true,
        onClose: this.closeDialog,
        children: [
          e.jsxs(o, {
            style: i.dialogTitle,
            children: [
              this.state.rxData.widgetTitle,
              e.jsx("div", {
                style: {
                  flex: 1
                }
              }),
              e.jsx(N, {
                onClick: this.closeDialog,
                children: e.jsx(D, {})
              })
            ]
          }),
          e.jsx(j, {
            children: e.jsx("div", {
              style: i.dialogContent,
              children: e.jsxs("div", {
                style: i.dialogImageContainer,
                children: [
                  e.jsx("img", {
                    ref: this.fullImageRef,
                    src: this.state.rxData.fullUrl || this.state.rxData.url || l,
                    alt: "Camera",
                    style: {
                      ...i.fullCamera,
                      transform: `rotate(${this.state.rxData.rotateVideo}deg)`
                    }
                  }),
                  (this.state.rxData.showRefreshTime === true || this.state.rxData.showRefreshTime === "true") && this.state.fullRefreshTime ? e.jsx("div", {
                    style: i.dialogTime,
                    children: s(this.state.fullRefreshTime).format("HH:mm:ss")
                  }) : null
                ]
              })
            })
          })
        ]
      }) : null;
    }
    renderWidgetBody(t) {
      super.renderWidgetBody(t);
      const M = e.jsxs(e.Fragment, {
        children: [
          e.jsxs("div", {
            style: i.imageContainer,
            onClick: () => this.setState({
              dialog: true
            }, () => this.propertiesUpdate()),
            children: [
              e.jsx("img", {
                ref: this.imageRef,
                src: this.takeUrl(),
                alt: "Camera",
                style: {
                  ...i.camera,
                  transform: `rotate(${this.state.rxData.rotateVideo}deg)`
                }
              }),
              this.state.rxData.showRefreshTime && this.state.refreshTime ? e.jsx("div", {
                style: i.time,
                children: s(this.state.refreshTime).format("HH:mm:ss")
              }) : null
            ]
          }),
          this.renderDialog()
        ]
      });
      return this.state.rxData.noCard === true || this.state.rxData.noCard === "true" || t.widget.usedInWidget ? M : this.wrapContent(M, null, {
        boxSizing: "border-box",
        paddingBottom: 10,
        height: "100%"
      });
    }
  };
});
export {
  __tla,
  r as default
};
