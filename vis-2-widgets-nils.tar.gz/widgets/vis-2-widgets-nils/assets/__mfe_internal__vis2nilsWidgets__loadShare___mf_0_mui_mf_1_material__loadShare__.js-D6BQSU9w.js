let V_, r, g, C, bs, cs, ds, gs, ys, ps, I_, A_, q, Z_, d, Ts, ns, Le, Hs, A, g_, l_, T_, U_, S, b_, Ps, h, O, __, W_, Ss, W, o_, j, vs, B, Q_, u_, Ls, Y, d_, q_, v_, Z, w_, Is, p_, rs, z, w, L_, P, F, R, $, M;
let __tla = (async () => {
  const a = "__mf_init____mf__virtual/__mfe_internal__vis2nilsWidgets__mf_v__runtimeInit__mf_v__.js__";
  let e = globalThis[a];
  if (!e) {
    let _, t;
    const l = new Promise((m, i) => {
      _ = m, t = i;
    });
    e = globalThis[a] = {
      initPromise: l,
      initResolve: _,
      initReject: t
    }, typeof window > "u" && _({
      loadRemote: function() {
        return Promise.resolve(void 0);
      },
      loadShare: function() {
        return Promise.resolve(void 0);
      }
    });
  }
  const f = e.initPromise, o = f.then((_) => _.loadShare("@mui/material", {
    customShareInfo: {
      shareConfig: {
        singleton: true,
        strictVersion: false,
        requiredVersion: "*"
      }
    }
  })), s = await o.then((_) => typeof _ == "function" ? _() : _);
  s.__esModule ? s.default : s.default;
  let n, p, c, u, y, U, b, T, I, L, v, x, k, D, G, H, N, E, V, K, Q, J, X, s_, e_, t_, a_, m_, i_, f_, r_, n_, C_, c_, y_, S_, B_, h_, P_, x_, k_, F_, D_, G_, M_, R_, H_, N_, E_, O_, z_, j_, K_, J_, X_, Y_, $_, _s, ss, es, ts, as, ls, ms, is, fs, os, Cs, us, Us, Bs, As, hs, xs, ks, Fs, Ds, Gs, Ms, Rs, ws, Ns, Es, Vs, Os, zs, js, qs, Ws, Ks, Qs, Zs, Js, Xs, Ys, $s, _e, se, ee, te, ae, le, me, ie, fe, oe, re, ne, Ce, ge, pe, ce, de, ue, ye, Ue, be, Se, Te, Ie, Be, Ae, he, ve, Pe, xe, ke, Fe, De, Ge, Me, Re, we, He, Ne, Ee, Ve, Oe, ze, je, qe, We, Ke, Qe, Ze, Je, Xe, Ye, $e, _t, st, et, tt, at, lt, mt, it, ft, ot, rt, nt, Ct, gt, pt, ct, dt, ut, yt, Ut, bt, St, Tt, It, Bt, At, ht, Lt, vt, Pt, xt, kt, Ft, Dt, Gt, Mt, Rt, wt, Ht, Nt, Et, Vt, Ot, zt, jt, qt, Wt, Kt, Qt, Zt, Jt, Xt, Yt, $t, _a, sa, ea, ta, aa, la, ma, ia, fa, oa, ra, na, Ca, ga, pa, ca, da, ua, ya, Ua, ba, Sa, Ta, Ia, Ba, Aa, ha, La, va, Pa, xa, ka, Fa, Da, Ga, Ma, Ra, wa, Ha, Na, Ea, Va, Oa, za, ja, qa, Wa, Ka, Qa, Za, Ja, Xa, Ya, $a, _l, sl, el, tl, al, ll, ml, il, fl, ol, rl, nl, Cl, gl, pl, cl, dl, ul, yl, Ul, bl, Sl, Tl, Il, Bl, Al, hl, Ll, vl, Pl, xl, kl, Fl, Dl, Gl, Ml, Rl, wl, Hl, Nl, El, Vl, Ol, zl, jl, ql, Wl, Kl, Ql, Zl, Jl, Xl, Yl, $l, _m, sm, em, tm, am, lm, mm, im, fm, om, rm, nm, Cm, gm, pm, cm, dm, um, ym, Um, bm, Sm, Tm, Im, Bm, Am, hm, Lm, vm, Pm, xm, km, Fm, Dm, Gm, Mm, Rm, wm, Hm, Nm, Em, Vm, Om, zm, jm, qm, Wm, Km, Qm, Zm, Jm, Xm, Ym, $m, _i, si, ei, ti, ai, li, mi, ii, fi, oi, ri, ni, Ci, gi, pi, ci, di, ui, yi, Ui, bi, Si, Ti, Ii, Bi, Ai, hi, Li, vi, Pi, xi, ki, Fi, Di, Gi, Mi, Ri, wi, Hi, Ni;
  ({ Accordion: r, AccordionActions: n, AccordionDetails: C, AccordionSummary: g, Alert: p, AlertTitle: c, AppBar: d, Autocomplete: u, Avatar: y, AvatarGroup: U, Backdrop: b, Badge: S, BottomNavigation: T, BottomNavigationAction: I, Box: B, Breadcrumbs: A, Button: h, ButtonBase: L, ButtonGroup: v, Card: P, CardActionArea: x, CardActions: k, CardContent: F, CardHeader: D, CardMedia: G, Checkbox: M, Chip: R, CircularProgress: w, ClickAwayListener: H, Collapse: N, Container: E, CssBaseline: V, Dialog: O, DialogActions: z, DialogContent: j, DialogContentText: q, DialogTitle: W, Divider: K, Drawer: Q, Fab: Z, Fade: J, FilledInput: X, FormControl: Y, FormControlLabel: $, FormGroup: __, FormHelperText: s_, FormLabel: e_, GlobalStyles: t_, Grid: a_, Grid2: l_, Grow: m_, Hidden: i_, Icon: f_, IconButton: o_, ImageList: r_, ImageListItem: n_, ImageListItemBar: C_, Input: g_, InputAdornment: p_, InputBase: c_, InputLabel: d_, LinearProgress: u_, Link: y_, List: U_, ListItem: b_, ListItemAvatar: S_, ListItemButton: T_, ListItemIcon: I_, ListItemSecondaryAction: B_, ListItemText: A_, ListSubheader: h_, Menu: L_, MenuItem: v_, MenuList: P_, MobileStepper: x_, Modal: k_, NativeSelect: F_, NoSsr: D_, OutlinedInput: G_, Pagination: M_, PaginationItem: R_, Paper: w_, Popover: H_, Popper: N_, Portal: E_, Radio: V_, RadioGroup: O_, Rating: z_, ScopedCssBaseline: j_, Select: q_, Skeleton: W_, Slide: K_, Slider: Q_, Snackbar: Z_, SnackbarContent: J_, SpeedDial: X_, SpeedDialAction: Y_, SpeedDialIcon: $_, Stack: _s, Step: ss, StepButton: es, StepConnector: ts, StepContent: as, StepIcon: ls, StepLabel: ms, Stepper: is, SvgIcon: fs, SwipeableDrawer: os, Switch: rs, Tab: ns, TabScrollButton: Cs, Table: gs, TableBody: ps, TableCell: cs, TableContainer: ds, TableFooter: us, TableHead: ys, TablePagination: Us, TableRow: bs, TableSortLabel: Ss, Tabs: Ts, TextField: Is, TextareaAutosize: Bs, ToggleButton: As, ToggleButtonGroup: hs, Toolbar: Ls, Tooltip: vs, Typography: Ps, Unstable_TrapFocus: xs, Zoom: ks, colors: Fs, darkScrollbar: Ds, generateUtilityClass: Gs, generateUtilityClasses: Ms, unstable_composeClasses: Rs, useAutocomplete: ws, useMediaQuery: Hs, usePagination: Ns, useScrollTrigger: Es, StyledEngineProvider: Vs, THEME_ID: Os, ThemeProvider: zs, adaptV4Theme: js, alpha: qs, createColorScheme: Ws, createMuiTheme: Ks, createStyles: Qs, createTheme: Zs, createTransitions: Js, css: Xs, darken: Ys, decomposeColor: $s, duration: _e, easing: se, emphasize: ee, experimentalStyled: te, experimental_extendTheme: ae, experimental_sx: le, extendTheme: me, getContrastRatio: ie, getLuminance: fe, getOverlayAlpha: oe, hexToRgb: re, hslToRgb: ne, keyframes: Ce, lighten: ge, makeStyles: pe, private_createMixins: ce, private_createTypography: de, private_excludeVariablesFromRoot: ue, recomposeColor: ye, responsiveFontSizes: Ue, rgbToHex: be, shouldSkipGeneratingVar: Se, styled: Te, unstable_createBreakpoints: Ie, unstable_createMuiStrictModeTheme: Be, unstable_getUnit: Ae, unstable_toUnitless: he, useTheme: Le, useThemeProps: ve, withStyles: Pe, withTheme: xe, CssVarsProvider: ke, Experimental_CssVarsProvider: Fe, getInitColorSchemeScript: De, useColorScheme: Ge, capitalize: Me, createChainedFunction: Re, createSvgIcon: we, debounce: He, deprecatedPropType: Ne, isMuiElement: Ee, mergeSlotProps: Ve, ownerDocument: Oe, ownerWindow: ze, requirePropFactory: je, setRef: qe, unstable_ClassNameGenerator: We, unstable_memoTheme: Ke, unstable_useEnhancedEffect: Qe, unstable_useId: Ze, unsupportedProp: Je, useControlled: Xe, useEventCallback: Ye, useForkRef: $e, accordionClasses: _t, getAccordionUtilityClass: st, accordionActionsClasses: et, getAccordionActionsUtilityClass: tt, accordionDetailsClasses: at, getAccordionDetailsUtilityClass: lt, accordionSummaryClasses: mt, getAccordionSummaryUtilityClass: it, alertClasses: ft, getAlertUtilityClass: ot, alertTitleClasses: rt, getAlertTitleUtilityClass: nt, appBarClasses: Ct, getAppBarUtilityClass: gt, autocompleteClasses: pt, createFilterOptions: ct, getAutocompleteUtilityClass: dt, avatarClasses: ut, getAvatarUtilityClass: yt, avatarGroupClasses: Ut, getAvatarGroupUtilityClass: bt, backdropClasses: St, getBackdropUtilityClass: Tt, badgeClasses: It, getBadgeUtilityClass: Bt, bottomNavigationClasses: At, getBottomNavigationUtilityClass: ht, bottomNavigationActionClasses: Lt, getBottomNavigationActionUtilityClass: vt, boxClasses: Pt, breadcrumbsClasses: xt, getBreadcrumbsUtilityClass: kt, buttonClasses: Ft, getButtonUtilityClass: Dt, buttonBaseClasses: Gt, touchRippleClasses: Mt, getButtonBaseUtilityClass: Rt, getTouchRippleUtilityClass: wt, ButtonGroupButtonContext: Ht, ButtonGroupContext: Nt, buttonGroupClasses: Et, getButtonGroupUtilityClass: Vt, cardClasses: Ot, getCardUtilityClass: zt, cardActionAreaClasses: jt, getCardActionAreaUtilityClass: qt, cardActionsClasses: Wt, getCardActionsUtilityClass: Kt, cardContentClasses: Qt, getCardContentUtilityClass: Zt, cardHeaderClasses: Jt, getCardHeaderUtilityClass: Xt, cardMediaClasses: Yt, getCardMediaUtilityClass: $t, checkboxClasses: _a, getCheckboxUtilityClass: sa, chipClasses: ea, getChipUtilityClass: ta, circularProgressClasses: aa, getCircularProgressUtilityClass: la, collapseClasses: ma, getCollapseUtilityClass: ia, containerClasses: fa, getContainerUtilityClass: oa, dialogClasses: ra, getDialogUtilityClass: na, dialogActionsClasses: Ca, getDialogActionsUtilityClass: ga, dialogContentClasses: pa, getDialogContentUtilityClass: ca, dialogContentTextClasses: da, getDialogContentTextUtilityClass: ua, dialogTitleClasses: ya, getDialogTitleUtilityClass: Ua, dividerClasses: ba, getDividerUtilityClass: Sa, drawerClasses: Ta, getDrawerUtilityClass: Ia, fabClasses: Ba, getFabUtilityClass: Aa, filledInputClasses: ha, getFilledInputUtilityClass: La, formControlClasses: va, useFormControl: Pa, getFormControlUtilityClasses: xa, formControlLabelClasses: ka, getFormControlLabelUtilityClasses: Fa, formGroupClasses: Da, getFormGroupUtilityClass: Ga, formHelperTextClasses: Ma, getFormHelperTextUtilityClasses: Ra, formLabelClasses: wa, FormLabelRoot: Ha, getFormLabelUtilityClasses: Na, grid2Classes: Ea, getGrid2UtilityClass: Va, iconClasses: Oa, getIconUtilityClass: za, iconButtonClasses: ja, getIconButtonUtilityClass: qa, imageListClasses: Wa, getImageListUtilityClass: Ka, imageListItemClasses: Qa, getImageListItemUtilityClass: Za, imageListItemBarClasses: Ja, getImageListItemBarUtilityClass: Xa, inputClasses: Ya, getInputUtilityClass: $a, inputAdornmentClasses: _l, getInputAdornmentUtilityClass: sl, inputBaseClasses: el, getInputBaseUtilityClass: tl, inputLabelClasses: al, getInputLabelUtilityClasses: ll, linearProgressClasses: ml, getLinearProgressUtilityClass: il, linkClasses: fl, getLinkUtilityClass: ol, listClasses: rl, getListUtilityClass: nl, listItemClasses: Cl, getListItemUtilityClass: gl, listItemAvatarClasses: pl, getListItemAvatarUtilityClass: cl, listItemButtonClasses: dl, getListItemButtonUtilityClass: ul, listItemIconClasses: yl, getListItemIconUtilityClass: Ul, listItemSecondaryActionClasses: bl, getListItemSecondaryActionClassesUtilityClass: Sl, listItemTextClasses: Tl, getListItemTextUtilityClass: Il, listSubheaderClasses: Bl, getListSubheaderUtilityClass: Al, menuClasses: hl, getMenuUtilityClass: Ll, menuItemClasses: vl, getMenuItemUtilityClass: Pl, mobileStepperClasses: xl, getMobileStepperUtilityClass: kl, ModalManager: Fl, modalClasses: Dl, getModalUtilityClass: Gl, nativeSelectClasses: Ml, getNativeSelectUtilityClasses: Rl, outlinedInputClasses: wl, getOutlinedInputUtilityClass: Hl, paginationClasses: Nl, getPaginationUtilityClass: El, paginationItemClasses: Vl, getPaginationItemUtilityClass: Ol, paperClasses: zl, getPaperUtilityClass: jl, popoverClasses: ql, PopoverPaper: Wl, PopoverRoot: Kl, getOffsetLeft: Ql, getOffsetTop: Zl, getPopoverUtilityClass: Jl, getPopperUtilityClass: Xl, radioClasses: Yl, getRadioUtilityClass: $l, radioGroupClasses: _m, useRadioGroup: sm, getRadioGroupUtilityClass: em, ratingClasses: tm, getRatingUtilityClass: am, scopedCssBaselineClasses: lm, getScopedCssBaselineUtilityClass: mm, selectClasses: im, getSelectUtilityClasses: fm, skeletonClasses: om, getSkeletonUtilityClass: rm, sliderClasses: nm, SliderMark: Cm, SliderMarkLabel: gm, SliderRail: pm, SliderRoot: cm, SliderThumb: dm, SliderTrack: um, SliderValueLabel: ym, getSliderUtilityClass: Um, snackbarClasses: bm, getSnackbarUtilityClass: Sm, snackbarContentClasses: Tm, getSnackbarContentUtilityClass: Im, speedDialClasses: Bm, getSpeedDialUtilityClass: Am, speedDialActionClasses: hm, getSpeedDialActionUtilityClass: Lm, speedDialIconClasses: vm, getSpeedDialIconUtilityClass: Pm, stackClasses: xm, StepContext: km, stepClasses: Fm, getStepUtilityClass: Dm, useStepContext: Gm, stepButtonClasses: Mm, getStepButtonUtilityClass: Rm, stepConnectorClasses: wm, getStepConnectorUtilityClass: Hm, stepContentClasses: Nm, getStepContentUtilityClass: Em, stepIconClasses: Vm, getStepIconUtilityClass: Om, stepLabelClasses: zm, getStepLabelUtilityClass: jm, StepperContext: qm, stepperClasses: Wm, getStepperUtilityClass: Km, useStepperContext: Qm, svgIconClasses: Zm, getSvgIconUtilityClass: Jm, switchClasses: Xm, getSwitchUtilityClass: Ym, tabClasses: $m, getTabUtilityClass: _i, tableClasses: si, getTableUtilityClass: ei, tableBodyClasses: ti, getTableBodyUtilityClass: ai, tableCellClasses: li, getTableCellUtilityClass: mi, tableContainerClasses: ii, getTableContainerUtilityClass: fi, tableFooterClasses: oi, getTableFooterUtilityClass: ri, tableHeadClasses: ni, getTableHeadUtilityClass: Ci, tablePaginationClasses: gi, getTablePaginationUtilityClass: pi, tableRowClasses: ci, getTableRowUtilityClass: di, tableSortLabelClasses: ui, getTableSortLabelUtilityClass: yi, tabsClasses: Ui, getTabsUtilityClass: bi, tabScrollButtonClasses: Si, getTabScrollButtonUtilityClass: Ti, textFieldClasses: Ii, getTextFieldUtilityClass: Bi, toggleButtonClasses: Ai, getToggleButtonUtilityClass: hi, toggleButtonGroupClasses: Li, getToggleButtonGroupUtilityClass: vi, toolbarClasses: Pi, getToolbarUtilityClass: xi, tooltipClasses: ki, getTooltipUtilityClass: Fi, typographyClasses: Di, getTypographyUtilityClass: Gi, major: Mi, minor: Ri, patch: wi, prerelease: Hi, version: Ni } = s);
})();
export {
  V_ as $,
  r as A,
  g as B,
  C,
  bs as D,
  cs as E,
  ds as F,
  gs as G,
  ys as H,
  ps as I,
  I_ as J,
  A_ as K,
  q as L,
  Z_ as M,
  d as N,
  Ts as O,
  ns as P,
  Le as Q,
  Hs as R,
  A as S,
  g_ as T,
  l_ as U,
  T_ as V,
  U_ as W,
  S as X,
  b_ as Y,
  Ps as Z,
  h as _,
  __tla,
  O as a,
  __ as a0,
  W_ as a1,
  Ss as a2,
  W as b,
  o_ as c,
  j as d,
  vs as e,
  B as f,
  Q_ as g,
  u_ as h,
  Ls as i,
  Y as j,
  d_ as k,
  q_ as l,
  v_ as m,
  Z as n,
  w_ as o,
  Is as p,
  p_ as q,
  rs as r,
  z as s,
  w as t,
  L_ as u,
  P as v,
  F as w,
  R as x,
  $ as y,
  M as z
};
