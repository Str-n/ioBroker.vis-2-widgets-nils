function o(r) {
  "@babel/helpers - typeof";
  return o = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, o(r);
}
function n(r, t) {
  if (o(r) != "object" || !r) return r;
  var e = r[Symbol.toPrimitive];
  if (e !== void 0) {
    var i = e.call(r, t);
    if (o(i) != "object") return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(r);
}
function y(r) {
  var t = n(r, "string");
  return o(t) == "symbol" ? t : t + "";
}
export {
  y as t
};
