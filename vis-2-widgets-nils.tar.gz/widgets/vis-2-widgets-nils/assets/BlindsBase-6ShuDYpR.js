import { j as r, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { G as y } from "./Generic-CC2u2WPj.js";
import { _ as N, a as D, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { n as g, _ as f, a as _, b as S, c as j, d as M, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { _ as C, __tla as __tla_3 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_system__loadShare__.js-yqXflbgy.js";
import { q as b, G as T, H as k, I as B, a as O, __tla as __tla_4 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CRxa-Ic2.js";
import { c as v, __tla as __tla_5 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CA-kW2vj.js";
let R, H;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  const p = {
    dialogTitle: {
      textAlign: "center"
    },
    wrapperSliderBlock: {
      display: "flex",
      flexDirection: "column"
    },
    buttonStopStyle: {
      float: "left"
    },
    sliderText: {
      display: "inline-block"
    },
    sliderStyle: {
      marginTop: "1em",
      marginBottom: "1em",
      position: "relative",
      zIndex: 11,
      width: "10em",
      borderRadius: "2em",
      overflow: "hidden",
      background: "white",
      cursor: "pointer",
      boxShadow: "0px 3px 5px -1px rgba(0, 0, 0, 0.2), 0px 6px 10px 0px rgba(0, 0, 0, 0.14), 0px 1px 18px 0px rgba(0, 0, 0, 0.12)",
      height: "20em",
      boxSizing: "border-box"
    }
  }, x = "#c7c70e";
  class d extends N {
    static types = {
      value: 0,
      dimmer: 1,
      blinds: 2
    };
    static mouseDown = false;
    button = {
      time: 0,
      name: "",
      timer: null,
      timeUp: 0
    };
    refSlider = D.createRef();
    type;
    top = void 0;
    height = void 0;
    controlTimer = null;
    constructor(t) {
      super(t), this.state = {
        value: this.props.startValue || 0,
        toggleValue: this.props.startToggleValue || false,
        lastControl: 0
      }, this.type = this.props.type || d.types.dimmer;
    }
    static getDerivedStateFromProps(t, e) {
      let o = null;
      return t.startValue !== e.value && !d.mouseDown && Date.now() - e.lastControl > 1e3 && (o = {}, o.value = t.startValue), t.startToggleValue !== void 0 && t.startToggleValue !== e.toggleValue && (o || (o = {}), o.toggleValue = t.startToggleValue), o || null;
    }
    eventToValue(t) {
      const e = t.touches ? t.touches[t.touches.length - 1].clientY : t.clientY;
      let o = 100 - Math.round((e - this.top) / this.height * 100);
      o > 100 ? o = 100 : o < 0 && (o = 0), this.setState({
        value: o
      }), Date.now() - this.state.lastControl > 200 && this.type !== d.types.blinds && this.setState({
        lastControl: Date.now()
      }, () => this.onValueChanged(o));
    }
    onMouseMove = (t) => {
      d.mouseDown && (t.preventDefault(), t.stopPropagation(), this.eventToValue(t));
    };
    onMouseDown = (t) => {
      if (t.preventDefault(), t.stopPropagation(), !this.height) if (this.refSlider.current) this.height = this.refSlider.current.offsetHeight, this.top = this.refSlider.current.getBoundingClientRect().top;
      else return;
      d.mouseDown = true, this.eventToValue(t), window.document.addEventListener("mousemove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.addEventListener("mouseup", this.onMouseUp, {
        passive: false,
        capture: true
      }), window.document.addEventListener("touchmove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.addEventListener("touchend", this.onMouseUp, {
        passive: false,
        capture: true
      });
    };
    onValueChanged(t) {
      var _a, _b;
      this.props.controlTimeout ? (this.controlTimer && (clearTimeout(this.controlTimer), this.controlTimer = null), this.controlTimer = setTimeout(() => {
        var _a2, _b2;
        (_b2 = (_a2 = this.props).onValueChange) == null ? void 0 : _b2.call(_a2, t);
      }, this.props.controlTimeout)) : (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, t);
    }
    onMouseUp = (t) => {
      t.preventDefault(), t.stopPropagation(), d.mouseDown && (d.mouseDown = false, window.document.removeEventListener("mousemove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("mouseup", this.onMouseUp, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("touchmove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("touchend", this.onMouseUp, {
        passive: false,
        capture: true
      })), this.setState({
        lastControl: Date.now()
      }, () => {
        var _a, _b;
        (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, this.state.value, true);
      });
    };
    componentWillUnmount() {
      d.mouseDown && (d.mouseDown = false, window.document.removeEventListener("mousemove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("mouseup", this.onMouseUp, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("touchmove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("touchend", this.onMouseUp, {
        passive: false,
        capture: true
      }));
    }
    getTopButtonName() {
      switch (this.props.type) {
        case d.types.blinds:
          return r.jsx(T, {
            style: {
              width: 20,
              height: 20
            }
          });
        case d.types.dimmer:
          return r.jsx(b, {
            style: {
              color: x,
              width: 20,
              height: 20
            }
          });
        default:
          return v.t("ON");
      }
    }
    getBottomButtonName() {
      switch (this.props.type) {
        case d.types.blinds:
          return r.jsx(k, {
            style: {
              width: 20,
              height: 20
            }
          });
        case d.types.dimmer:
          return r.jsx(b, {
            style: {
              width: 20,
              height: 20
            }
          });
        default:
          return v.t("OFF");
      }
    }
    onButtonDown(t, e) {
      t == null ? void 0 : t.stopPropagation(), !(Date.now() - this.button.time < 50) && (this.button.timer && clearTimeout(this.button.timer), this.button.name = e, this.button.time = Date.now(), this.button.timer = setTimeout(() => {
        this.button.timer = null;
        let o;
        switch (this.button.name) {
          case "top":
            o = 100;
            break;
          case "bottom":
            o = 0;
            break;
        }
        o !== void 0 && this.setState({
          value: o
        }, () => {
          var _a, _b;
          return (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, o, true);
        });
      }, 400));
    }
    getSliderColor() {
      if (this.props.type !== d.types.blinds) {
        if (this.props.type === d.types.dimmer) {
          const t = this.state.value;
          return C(x, 1 - (t / 70 + 0.3));
        }
        return "#888";
      }
    }
    getValueText() {
      let t = "%";
      return this.props.type !== d.types.blinds && this.props.type !== d.types.dimmer && (t = this.props.unit || ""), this.state.value + t;
    }
    getToggleButton() {
      return this.props.onToggle ? r.jsx(g, {
        onClick: this.props.onToggle,
        className: "dimmer-button",
        style: p.buttonToggleStyle,
        children: r.jsx(b, {})
      }) : null;
    }
    getStopButton() {
      return this.props.onStop ? r.jsx(g, {
        style: p.buttonStopStyle,
        size: "small",
        onClick: this.props.onStop,
        color: "secondary",
        children: r.jsx(B, {})
      }) : null;
    }
    generateContent() {
      const t = {
        position: "absolute",
        width: "100%",
        left: 0,
        height: `${this.props.type === d.types.blinds ? 100 - this.state.value : this.state.value}%`,
        background: this.props.background || this.getSliderColor(),
        transitionProperty: "height",
        transitionDuration: "0.1s"
      }, e = {
        position: "absolute",
        width: "2em",
        height: "0.3em",
        left: "calc(50% - 1em)",
        background: "white",
        borderRadius: "0.4em"
      };
      return this.props.type === d.types.blinds ? (t.top = 0, e.bottom = "0.4em", t.backgroundImage = "linear-gradient(0deg, #949494 4.55%, #c9c9c9 4.55%, #c9c9c9 50%, #949494 50%, #949494 54.55%, #c9c9c9 54.55%, #c9c9c9 100%)", t.backgroundSize = "100% 2.5em", t.backgroundPosition = "center bottom") : (t.bottom = 0, e.top = "0.4em"), r.jsxs("div", {
        style: p.wrapperSlider,
        className: "vis-2-slider-wrapper",
        children: [
          r.jsxs("div", {
            style: p.wrapperSliderBlock,
            className: "vis-2-slider-wrapper-block",
            children: [
              r.jsx(f, {
                variant: "outlined",
                onClick: (o) => this.onButtonDown(o, "top"),
                children: this.getTopButtonName()
              }),
              r.jsx("div", {
                className: "vis-2-slider-blind",
                ref: this.refSlider,
                onMouseDown: this.onMouseDown,
                onTouchStart: this.onMouseDown,
                onClick: (o) => o.stopPropagation(),
                style: p.sliderStyle,
                children: r.jsx("div", {
                  style: t,
                  className: "vis-2-slider-inside",
                  children: r.jsx("div", {
                    style: e,
                    className: "vis-2-slider-handler"
                  })
                })
              }),
              r.jsx(f, {
                variant: "outlined",
                onClick: (o) => this.onButtonDown(o, "bottom"),
                children: this.getBottomButtonName()
              })
            ]
          }),
          this.getToggleButton()
        ]
      });
    }
    render() {
      return r.jsxs(_, {
        open: true,
        onClose: () => this.props.onClose(),
        children: [
          r.jsxs(S, {
            style: p.dialogTitle,
            children: [
              this.getStopButton(),
              r.jsx("div", {
                style: p.sliderText,
                children: this.getValueText()
              }),
              r.jsx(j, {
                onClick: () => this.props.onClose(),
                style: {
                  float: "right"
                },
                children: r.jsx(O, {})
              })
            ]
          }),
          r.jsx(M, {
            children: this.generateContent()
          })
        ]
      });
    }
  }
  let u;
  u = {
    blindHandle: {
      position: "absolute",
      borderColor: "#a5aaad",
      borderStyle: "solid",
      background: "linear-gradient(to bottom, rgba(226, 226, 226, 1) 0%, rgba(219, 219, 219, 1) 50%, rgba(209, 209, 209, 1) 51%, rgba(254, 254, 254, 1) 100%)"
    },
    blindBlind: {
      backgroundImage: "linear-gradient(0deg, #949494 4.55%, #c9c9c9 4.55%, #c9c9c9 50%, #949494 50%, #949494 54.55%, #c9c9c9 54.55%, #c9c9c9 100%)",
      backgroundSize: "100% 20px",
      backgroundPosition: "center bottom",
      width: "100%",
      position: "absolute",
      transitionProperty: "height",
      transitionDuration: "0.3s"
    },
    blindBlind1: {
      height: "100%",
      boxSizing: "border-box",
      borderStyle: "solid",
      background: "linear-gradient(45deg, rgba(173, 174, 178, 1) 0%, rgba(251, 251, 251, 1) 100%)"
    },
    blindBlind2: {
      position: "relative",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
      borderStyle: "solid",
      borderColor: "rgba(0, 0, 0, 0)"
    },
    blindBlind3: {
      position: "relative",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
      background: "linear-gradient(to bottom, rgba(0, 0, 0, 0.8) 0%, rgba(0, 51, 135, 0.83) 100%)"
    },
    blindBlind4: {
      position: "relative",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
      borderStyle: "solid",
      background: "linear-gradient(45deg, rgba(221, 231, 243, 0.7) 0%, rgba(120, 132, 146, 0.7) 52%, rgba(166, 178, 190, 0.7) 68%, rgba(201, 206, 210, 0.7) 100%)",
      transitionProperty: "transform",
      transitionDuration: "0.3s",
      transformOrigin: "0 100%"
    },
    blindBlind4_left: {
      transformOrigin: "0 0"
    },
    blindBlind4_right: {
      transformOrigin: "100% 0"
    },
    blindBlind4_top: {
      transformOrigin: "0 100%"
    },
    blindBlind4_bottom: {
      transformOrigin: "0 0"
    },
    blindBlind4Opened_left: {
      transform: "skew(0deg, 10deg) scale(0.9, 1)"
    },
    blindBlind4Opened_right: {
      transform: "skew(0deg, -10deg) scale(0.9, 1)"
    },
    blindBlind4Opened_top: {
      transform: "skew(-10deg, 0deg) scale(1, 0.9)"
    },
    blindBlind4Opened_bottom: {
      transform: "skew(10deg, 0deg) scale(1, 0.9)"
    },
    blindBlind4_tilted: {
      transform: "skew(-10deg, 0deg) scale(1, 0.9)",
      transformOrigin: "0 100%"
    },
    blindHandleBG: {},
    blindHandleTiltedBG: {
      background: "linear-gradient(to bottom, rgba(241, 231, 103, 1) 0%, rgba(254, 182, 69, 1) 100%)"
    }
  };
  H = u;
  R = class extends y {
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        showBlindsDialog: null
      };
    }
    getMinMaxPosition(t, e) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
      const o = t ? this.state.rxData[`slideStop_oid${t}`] : this.state.rxData.oid_stop;
      let i = t && !this.state.rxData.oid ? this.state.rxData[`slidePos_oid${t}`] : this.state.rxData.oid, n = t && !this.state.rxData.oid ? this.state.rxData[`slideInvert${t}`] === true || this.state.rxData[`slideInvert${t}`] === "true" : this.state.rxData.invert === true || this.state.rxData.invert === "true";
      e !== void 0 && (i = this.state.rxData[`slidePos_oid${t}`] !== "nothing_selected" ? this.state.rxData[`slidePos_oid${t}`] : "", n = this.state.rxData[`slideInvert${e}`] === true || this.state.rxData[`slideInvert${e}`] === "true"), t && (i === "nothing_selected" || !i) && (i = this.state.rxData.oid, n = this.state.rxData.invert === true || this.state.rxData.invert === "true");
      let l, s;
      if (!t) l = parseFloat(this.state.rxData.min), Number.isNaN(l) && (((_a = this.state.main) == null ? void 0 : _a.min) === void 0 || Number.isNaN((_b = this.state.main) == null ? void 0 : _b.min) ? l = 0 : l = this.state.main.min), s = parseFloat(this.state.rxData.max), Number.isNaN(s) && (((_c = this.state.main) == null ? void 0 : _c.max) === void 0 || Number.isNaN((_d = this.state.main) == null ? void 0 : _d.max) ? s = 100 : s = this.state.main.max);
      else if (e !== void 0) {
        const h = typeof this.state.objects[e] == "object" ? parseFloat((_f = (_e = this.state.objects[e]) == null ? void 0 : _e.common) == null ? void 0 : _f.min) : void 0;
        h === void 0 || Number.isNaN(h) ? ((_g = this.state.main) == null ? void 0 : _g.min) === void 0 || Number.isNaN(parseFloat(this.state.main.min)) ? l = 0 : l = this.state.main.min : l = h;
        const c = typeof this.state.objects[e] == "object" ? parseFloat((_i = (_h = this.state.objects[e]) == null ? void 0 : _h.common) == null ? void 0 : _i.max) : void 0;
        c === void 0 || Number.isNaN(c) ? ((_j = this.state.main) == null ? void 0 : _j.max) === void 0 || Number.isNaN(this.state.main.max) ? s = 100 : s = this.state.main.max : s = c;
      } else {
        if (l = parseFloat(this.state.rxData[`slideMin${t}`]), Number.isNaN(l)) {
          const h = typeof this.state.objects[t] == "object" ? parseFloat((_l = (_k = this.state.objects[t]) == null ? void 0 : _k.common) == null ? void 0 : _l.min) : void 0;
          h === void 0 || Number.isNaN(h) ? (l = parseFloat(this.state.rxData.min), Number.isNaN(l) && (l = parseFloat((_m = this.state.main) == null ? void 0 : _m.min), Number.isNaN(l) && (l = 0))) : l = h;
        }
        if (s = parseFloat(this.state.rxData[`slideMax${t}`]), Number.isNaN(s)) {
          const h = typeof this.state.objects[t] == "object" ? parseFloat((_o = (_n = this.state.objects[t]) == null ? void 0 : _n.common) == null ? void 0 : _o.max) : void 0;
          h === void 0 || Number.isNaN(h) ? (s = parseFloat(this.state.rxData.max), Number.isNaN(s) && (s = parseFloat((_p = this.state.main) == null ? void 0 : _p.max), Number.isNaN(s) && (s = 100))) : s = h;
        }
      }
      let a = this.state.values[`${i}.val`];
      return a == null ? a = 0 : (a < l && (a = l), a > s && (a = s), a = Math.round(100 * (a - l) / (s - l))), n && (a = 100 - a), {
        min: l,
        max: s,
        shutterPos: a,
        invert: n,
        stopOid: o,
        positionOid: i,
        customOid: i !== this.state.rxData.oid,
        hasControl: i !== "nothing_selected" && !!i
      };
    }
    renderBlindsDialog() {
      if (this.state.showBlindsDialog !== null) {
        const t = this.getMinMaxPosition(this.state.showBlindsDialog === true ? 0 : this.state.showBlindsDialog, this.state.showBlindsDialogIndexOfButton);
        return r.jsx(d, {
          onClose: () => {
            this.lastClick = Date.now(), this.setState({
              showBlindsDialog: null
            });
          },
          onStop: t.stopOid && t.stopOid !== "nothing_selected" ? () => this.props.context.setValue(t.stopOid, true) : void 0,
          controlTimeout: parseInt(this.state.rxData.timeout, 10) || 0,
          onValueChange: (e, o) => {
            t.invert && (e = 100 - e), e = (t.max - t.min) / 100 * e + t.min, o && this.props.context.setValue(t.positionOid, e);
          },
          startValue: t.shutterPos,
          type: d.types.blinds
        });
      }
      return null;
    }
    renderOneWindow(t, e) {
      const o = this.getMinMaxPosition(t, e.indexOfButton);
      let i = null, n = null;
      e.handleOid && (i = this.state.values[`${e.handleOid}.val`], i === 2 || i === "2" ? i = 1 : (i === 1 || i === "1") && (i = 2), i === "1" || i === true || i === "true" || i === "open" || i === "opened" ? i = 1 : (i === "2" || i === "tilt" || i === "tilted") && (i = 2), n = i), e.slideOid && (n = this.state.values[`${e.slideOid}.val`], (n === 2 || n === "2") && (n = 2), n === "1" || n === true || n === "true" || n === "open" || n === "opened" ? n = 1 : (n === "2" || n === "tilt" || n === "tilted") && (n = 2), e.handleOid || (i = n));
      let l = null;
      if (e.type) {
        let s = Math.round(e.borderWidth / 3);
        s < 1 && (s = 1);
        const a = {
          borderWidth: s,
          transitionProperty: "transform",
          transitionDuration: "0.3s"
        };
        if (e.type === "left" || e.type === "right" ? (a.top = "50%", a.width = e.borderWidth, a.height = "10%") : (e.type === "top" || e.type === "bottom") && (a.left = "50%", a.height = e.borderWidth, a.width = "10%"), e.type === "left" ? a.left = `calc(100% - ${s * 2 + e.borderWidth}px)` : e.type === "bottom" && (a.top = `calc(100% - ${s * 2 + e.borderWidth}px)`), i) if (e.type === "right") {
          const h = Math.round(s + e.borderWidth / 2);
          a.transformOrigin = `${h}px ${h}px`, a.top = `calc(50% + ${h}px)`, i === 1 ? a.transform = "rotate(-90deg)" : i === 2 && (a.transform = "rotate(180deg)");
        } else if (e.type === "bottom") {
          const h = Math.round(s + e.borderWidth / 2);
          a.transformOrigin = `${h}px ${h}px`, i === 1 ? a.transform = "rotate(-90deg)" : i === 2 && (a.transform = "rotate(180deg)");
        } else i === 1 ? a.transform = "rotate(90deg)" : i === 2 && (a.transform = "rotate(180deg)");
        l = r.jsx("div", {
          className: "vis-2-blinds-handle",
          style: {
            ...u.blindHandle,
            ...i === 2 ? u.blindHandleTiltedBG : void 0,
            ...a
          }
        });
      }
      return r.jsx("div", {
        className: "vis-2-blinds-outside",
        style: {
          ...u.blindBlind1,
          borderWidth: e.borderWidth,
          borderColor: "#a9a7a8",
          flex: e.flex || 1
        },
        children: r.jsx("div", {
          className: "vis-2-blinds-inside",
          style: {
            ...u.blindBlind2,
            borderWidth: e.borderWidth
          },
          onClick: o.customOid ? (s) => {
            s.preventDefault(), s.stopPropagation(), this.lastClick = Date.now(), this.setState({
              showBlindsDialog: t,
              showBlindsDialogIndexOfButton: e.indexOfButton
            });
          } : void 0,
          children: r.jsxs("div", {
            style: u.blindBlind3,
            className: "vis-2-blinds-inside-2",
            children: [
              r.jsx("div", {
                style: {
                  ...u.blindBlind,
                  height: `${100 - o.shutterPos}%`
                },
                className: "vis-2-blinds-closed"
              }),
              r.jsx("div", {
                className: "vis-2-blinds-opened",
                style: {
                  ...u.blindBlind4,
                  ...e.type ? u[`blindBlind4_${e.type}`] : void 0,
                  ...n === 1 && e.type ? u[`blindBlind4Opened_${e.type}`] : void 0,
                  ...n === 2 && e.type ? u.blindBlind4_tilted : void 0,
                  borderWidth: e.borderWidth,
                  borderColor: "#a5aaad"
                },
                children: l
              })
            ]
          })
        })
      }, t);
    }
    renderWindows(t, e) {
      let o, i;
      const n = parseFloat(this.state.rxData.ratio) || 1;
      i = t.height, o = Math.round(i * n), o > t.width && (o = t.width, i = Math.round(o / n));
      const l = t.width > t.height ? t.height : t.width;
      let s = parseFloat(this.state.rxData.borderWidth) || 2.5;
      s = Math.round(l * s / 10) / 10, s < 1 && (s = 1);
      const a = [], h = this.state.rxData.sashCount !== void 0 ? this.state.rxData.sashCount : 1;
      for (let m = 1; m <= h; m++) {
        const w = {
          slideOid: this.state.rxData[`slideSensor_oid${m}`],
          handleOid: this.state.rxData[`slideHandle_oid${m}`],
          type: this.state.rxData[`slideType${m}`],
          flex: this.state.rxData[`slideRatio${m}`],
          borderWidth: s,
          size: t,
          indexOfButton: e
        };
        a.push(this.renderOneWindow(m, w));
      }
      const c = {
        paddingTop: s,
        paddingBottom: s - 1,
        paddingRight: s + 1,
        paddingLeft: s + 1,
        width: o,
        height: i,
        display: "flex",
        alignItems: "stretch",
        margin: "auto"
      };
      return r.jsx("div", {
        style: c,
        children: a
      });
    }
  };
});
export {
  R as B,
  H as S,
  __tla
};
