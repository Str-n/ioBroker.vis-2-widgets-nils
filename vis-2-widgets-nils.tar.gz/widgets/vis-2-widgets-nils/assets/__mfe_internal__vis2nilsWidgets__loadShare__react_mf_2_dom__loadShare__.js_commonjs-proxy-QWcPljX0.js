import { g as _, __tla as __tla_0 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
import { _ as e, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react_mf_2_dom__loadShare__.js-DYAq8PKT.js";
let m;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  m = _(e);
});
export {
  __tla,
  m as r
};
