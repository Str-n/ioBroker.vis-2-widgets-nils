import { f as ne, d as O, c as ae, __tla as __tla_0 } from "./capitalize-BPb0zFhT.js";
import { __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__prop_mf_2_types__loadShare__.js-Btvp0r21.js";
let Be, kt, B, Wt, Et, G, at, it, Pt, ze, _e, Xe, Ne, He, Ue, _, Me, De, Le, Qe, S, mt, Kt, ot, Se, N, Ie, k, pe, T, H, Y, We, I, st, Ve, Ze, et, qe, ut, Je, nt, tt, rt, ct, xe, m, Z, ft, te, dt, lt, Ye, Fe, p, V, P, W, vt, Q, Ge, Lt, zt, C, ht, U, Ot, _t, ue, Rt, Bt, At, Tt, Ht, de, Nt, le, we, $e, Te, jt, L, be, ge, ye, M, y, me, Mt, It, Gt;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  const he = (e) => {
    const t = Object.keys(e).map((r) => ({
      key: r,
      val: e[r]
    })) || [];
    return t.sort((r, n) => r.val - n.val), t.reduce((r, n) => ({
      ...r,
      [n.key]: n.val
    }), {});
  };
  ye = function(e) {
    const { values: t = {
      xs: 0,
      sm: 600,
      md: 900,
      lg: 1200,
      xl: 1536
    }, unit: r = "px", step: n = 5, ...s } = e, o = he(t), i = Object.keys(o);
    function a(l) {
      return `@media (min-width:${typeof t[l] == "number" ? t[l] : l}${r})`;
    }
    function u(l) {
      return `@media (max-width:${(typeof t[l] == "number" ? t[l] : l) - n / 100}${r})`;
    }
    function c(l, h) {
      const d = i.indexOf(h);
      return `@media (min-width:${typeof t[l] == "number" ? t[l] : l}${r}) and (max-width:${(d !== -1 && typeof t[i[d]] == "number" ? t[i[d]] : h) - n / 100}${r})`;
    }
    function g(l) {
      return i.indexOf(l) + 1 < i.length ? c(l, i[i.indexOf(l) + 1]) : a(l);
    }
    function f(l) {
      const h = i.indexOf(l);
      return h === 0 ? a(i[1]) : h === i.length - 1 ? u(i[h]) : c(l, i[i.indexOf(l) + 1]).replace("@media", "@media not all and");
    }
    return {
      keys: i,
      values: o,
      up: a,
      down: u,
      between: c,
      only: g,
      not: f,
      unit: r,
      ...s
    };
  };
  be = function(e, t = Number.MIN_SAFE_INTEGER, r = Number.MAX_SAFE_INTEGER) {
    return Math.max(t, Math.min(e, r));
  };
  function J(e, t = 0, r = 1) {
    return be(e, t, r);
  }
  xe = function(e) {
    e = e.slice(1);
    const t = new RegExp(`.{1,${e.length >= 6 ? 2 : 1}}`, "g");
    let r = e.match(t);
    return r && r[0].length === 1 && (r = r.map((n) => n + n)), r ? `rgb${r.length === 4 ? "a" : ""}(${r.map((n, s) => s < 3 ? parseInt(n, 16) : Math.round(parseInt(n, 16) / 255 * 1e3) / 1e3).join(", ")})` : "";
  };
  function Ce(e) {
    const t = e.toString(16);
    return t.length === 1 ? `0${t}` : t;
  }
  T = function(e) {
    if (e.type) return e;
    if (e.charAt(0) === "#") return T(xe(e));
    const t = e.indexOf("("), r = e.substring(0, t);
    if (![
      "rgb",
      "rgba",
      "hsl",
      "hsla",
      "color"
    ].includes(r)) throw new Error(ne(9, e));
    let n = e.substring(t + 1, e.length - 1), s;
    if (r === "color") {
      if (n = n.split(" "), s = n.shift(), n.length === 4 && n[3].charAt(0) === "/" && (n[3] = n[3].slice(1)), ![
        "srgb",
        "display-p3",
        "a98-rgb",
        "prophoto-rgb",
        "rec-2020"
      ].includes(s)) throw new Error(ne(10, s));
    } else n = n.split(",");
    return n = n.map((o) => parseFloat(o)), {
      type: r,
      values: n,
      colorSpace: s
    };
  };
  Se = (e) => {
    const t = T(e);
    return t.values.slice(0, 3).map((r, n) => t.type.includes("hsl") && n !== 0 ? `${r}%` : r).join(" ");
  };
  Tt = (e, t) => {
    try {
      return Se(e);
    } catch {
      return e;
    }
  };
  W = function(e) {
    const { type: t, colorSpace: r } = e;
    let { values: n } = e;
    return t.includes("rgb") ? n = n.map((s, o) => o < 3 ? parseInt(s, 10) : s) : t.includes("hsl") && (n[1] = `${n[1]}%`, n[2] = `${n[2]}%`), t.includes("color") ? n = `${r} ${n.join(" ")}` : n = `${n.join(", ")}`, `${t}(${n})`;
  };
  vt = function(e) {
    if (e.startsWith("#")) return e;
    const { values: t } = T(e);
    return `#${t.map((r, n) => Ce(n === 3 ? Math.round(255 * r) : r)).join("")}`;
  };
  we = function(e) {
    e = T(e);
    const { values: t } = e, r = t[0], n = t[1] / 100, s = t[2] / 100, o = n * Math.min(s, 1 - s), i = (c, g = (c + r / 30) % 12) => s - o * Math.max(Math.min(g - 3, 9 - g, 1), -1);
    let a = "rgb";
    const u = [
      Math.round(i(0) * 255),
      Math.round(i(8) * 255),
      Math.round(i(4) * 255)
    ];
    return e.type === "hsla" && (a += "a", u.push(t[3])), W({
      type: a,
      values: u
    });
  };
  Y = function(e) {
    e = T(e);
    let t = e.type === "hsl" || e.type === "hsla" ? T(we(e)).values : e.values;
    return t = t.map((r) => (e.type !== "color" && (r /= 255), r <= 0.03928 ? r / 12.92 : ((r + 0.055) / 1.055) ** 2.4)), Number((0.2126 * t[0] + 0.7152 * t[1] + 0.0722 * t[2]).toFixed(3));
  };
  At = function(e, t) {
    const r = Y(e), n = Y(t);
    return (Math.max(r, n) + 0.05) / (Math.min(r, n) + 0.05);
  };
  $e = function(e, t) {
    return e = T(e), t = J(t), (e.type === "rgb" || e.type === "hsl") && (e.type += "a"), e.type === "color" ? e.values[3] = `/${t}` : e.values[3] = t, W(e);
  };
  Bt = function(e, t, r) {
    try {
      return $e(e, t);
    } catch {
      return e;
    }
  };
  ue = function(e, t) {
    if (e = T(e), t = J(t), e.type.includes("hsl")) e.values[2] *= 1 - t;
    else if (e.type.includes("rgb") || e.type.includes("color")) for (let r = 0; r < 3; r += 1) e.values[r] *= 1 - t;
    return W(e);
  };
  jt = function(e, t, r) {
    try {
      return ue(e, t);
    } catch {
      return e;
    }
  };
  le = function(e, t) {
    if (e = T(e), t = J(t), e.type.includes("hsl")) e.values[2] += (100 - e.values[2]) * t;
    else if (e.type.includes("rgb")) for (let r = 0; r < 3; r += 1) e.values[r] += (255 - e.values[r]) * t;
    else if (e.type.includes("color")) for (let r = 0; r < 3; r += 1) e.values[r] += (1 - e.values[r]) * t;
    return W(e);
  };
  Ot = function(e, t, r) {
    try {
      return le(e, t);
    } catch {
      return e;
    }
  };
  Te = function(e, t = 0.15) {
    return Y(e) > 0.5 ? ue(e, t) : le(e, t);
  };
  Rt = function(e, t, r) {
    try {
      return Te(e, t);
    } catch {
      return e;
    }
  };
  Pt = function(e, t, r, n = 1) {
    const s = (u, c) => Math.round((u ** (1 / n) * (1 - r) + c ** (1 / n) * r) ** n), o = T(e), i = T(t), a = [
      s(o.values[0], i.values[0]),
      s(o.values[1], i.values[1]),
      s(o.values[2], i.values[2])
    ];
    return W({
      type: "rgb",
      values: a
    });
  };
  function R(e, t) {
    return t ? O(e, t, {
      clone: false
    }) : e;
  }
  function se(e, t) {
    if (!e.containerQueries) return t;
    const r = Object.keys(t).filter((n) => n.startsWith("@container")).sort((n, s) => {
      var _a, _b;
      const o = /min-width:\s*([0-9.]+)/;
      return +(((_a = n.match(o)) == null ? void 0 : _a[1]) || 0) - +(((_b = s.match(o)) == null ? void 0 : _b[1]) || 0);
    });
    return r.length ? r.reduce((n, s) => {
      const o = t[s];
      return delete n[s], n[s] = o, n;
    }, {
      ...t
    }) : t;
  }
  function ve(e, t) {
    return t === "@" || t.startsWith("@") && (e.some((r) => t.startsWith(`@${r}`)) || !!t.match(/^@\d/));
  }
  function Ae(e, t) {
    const r = t.match(/^@([^/]+)?\/?(.+)?$/);
    if (!r) return null;
    const [, n, s] = r, o = Number.isNaN(+n) ? n || 0 : +n;
    return e.containerQueries(s).up(o);
  }
  Be = function(e) {
    const t = (o, i) => o.replace("@media", i ? `@container ${i}` : "@container");
    function r(o, i) {
      o.up = (...a) => t(e.breakpoints.up(...a), i), o.down = (...a) => t(e.breakpoints.down(...a), i), o.between = (...a) => t(e.breakpoints.between(...a), i), o.only = (...a) => t(e.breakpoints.only(...a), i), o.not = (...a) => {
        const u = t(e.breakpoints.not(...a), i);
        return u.includes("not all and") ? u.replace("not all and ", "").replace("min-width:", "width<").replace("max-width:", "width>").replace("and", "or") : u;
      };
    }
    const n = {}, s = (o) => (r(n, o), n);
    return r(s), {
      ...e,
      containerQueries: s
    };
  };
  const z = {
    xs: 0,
    sm: 600,
    md: 900,
    lg: 1200,
    xl: 1536
  }, F = {
    keys: [
      "xs",
      "sm",
      "md",
      "lg",
      "xl"
    ],
    up: (e) => `@media (min-width:${z[e]}px)`
  }, je = {
    containerQueries: (e) => ({
      up: (t) => {
        let r = typeof t == "number" ? t : z[t] || t;
        return typeof r == "number" && (r = `${r}px`), e ? `@container ${e} (min-width:${r})` : `@container (min-width:${r})`;
      }
    })
  };
  B = function(e, t, r) {
    const n = e.theme || {};
    if (Array.isArray(t)) {
      const o = n.breakpoints || F;
      return t.reduce((i, a, u) => (i[o.up(o.keys[u])] = r(t[u]), i), {});
    }
    if (typeof t == "object") {
      const o = n.breakpoints || F;
      return Object.keys(t).reduce((i, a) => {
        if (ve(o.keys, a)) {
          const u = Ae(n.containerQueries ? n : je, a);
          u && (i[u] = r(t[a], a));
        } else if (Object.keys(o.values || z).includes(a)) {
          const u = o.up(a);
          i[u] = r(t[a], a);
        } else {
          const u = a;
          i[u] = t[u];
        }
        return i;
      }, {});
    }
    return r(t);
  };
  Kt = function(e) {
    const t = (r) => {
      const n = r.theme || {}, s = e(r), o = n.breakpoints || F, i = o.keys.reduce((a, u) => (r[u] && (a = a || {}, a[o.up(u)] = e({
        theme: n,
        ...r[u]
      })), a), null);
      return R(s, i);
    };
    return t.propTypes = {}, t.filterProps = [
      "xs",
      "sm",
      "md",
      "lg",
      "xl",
      ...e.filterProps
    ], t;
  };
  function ce(e = {}) {
    var _a;
    return ((_a = e.keys) == null ? void 0 : _a.reduce((r, n) => {
      const s = e.up(n);
      return r[s] = {}, r;
    }, {})) || {};
  }
  function q(e, t) {
    return e.reduce((r, n) => {
      const s = r[n];
      return (!s || Object.keys(s).length === 0) && delete r[n], r;
    }, t);
  }
  Et = function(e, ...t) {
    const r = ce(e), n = [
      r,
      ...t
    ].reduce((s, o) => O(s, o), {});
    return q(Object.keys(r), n);
  };
  function Oe(e, t) {
    if (typeof e != "object") return {};
    const r = {}, n = Object.keys(t);
    return Array.isArray(e) ? n.forEach((s, o) => {
      o < e.length && (r[s] = true);
    }) : n.forEach((s) => {
      e[s] != null && (r[s] = true);
    }), r;
  }
  Wt = function({ values: e, breakpoints: t, base: r }) {
    const n = r || Oe(e, t), s = Object.keys(n);
    if (s.length === 0) return e;
    let o;
    return s.reduce((i, a, u) => (Array.isArray(e) ? (i[a] = e[u] != null ? e[u] : e[o], o = u) : typeof e == "object" ? (i[a] = e[a] != null ? e[a] : e[o], o = a) : i[a] = e, i), {});
  };
  L = function(e, t, r = true) {
    if (!t || typeof t != "string") return null;
    if (e && e.vars && r) {
      const n = `vars.${t}`.split(".").reduce((s, o) => s && s[o] ? s[o] : null, e);
      if (n != null) return n;
    }
    return t.split(".").reduce((n, s) => n && n[s] != null ? n[s] : null, e);
  };
  I = function(e, t, r, n = r) {
    let s;
    return typeof e == "function" ? s = e(r) : Array.isArray(e) ? s = e[r] || n : s = L(e, r) || n, t && (s = t(s, n, e)), s;
  };
  y = function(e) {
    const { prop: t, cssProperty: r = e.prop, themeKey: n, transform: s } = e, o = (i) => {
      if (i[t] == null) return null;
      const a = i[t], u = i.theme, c = L(u, n) || {};
      return B(i, a, (f) => {
        let l = I(c, s, f);
        return f === l && typeof f == "string" && (l = I(c, s, `${t}${f === "default" ? "" : ae(f)}`, f)), r === false ? l : {
          [r]: l
        };
      });
    };
    return o.propTypes = {}, o.filterProps = [
      t
    ], o;
  };
  function Re(e) {
    const t = {};
    return (r) => (t[r] === void 0 && (t[r] = e(r)), t[r]);
  }
  let Pe, Ke, oe, Ee, fe;
  Pe = {
    m: "margin",
    p: "padding"
  };
  Ke = {
    t: "Top",
    r: "Right",
    b: "Bottom",
    l: "Left",
    x: [
      "Left",
      "Right"
    ],
    y: [
      "Top",
      "Bottom"
    ]
  };
  oe = {
    marginX: "mx",
    marginY: "my",
    paddingX: "px",
    paddingY: "py"
  };
  Ee = Re((e) => {
    if (e.length > 2) if (oe[e]) e = oe[e];
    else return [
      e
    ];
    const [t, r] = e.split(""), n = Pe[t], s = Ke[r] || "";
    return Array.isArray(s) ? s.map((o) => n + o) : [
      n + s
    ];
  });
  Z = [
    "m",
    "mt",
    "mr",
    "mb",
    "ml",
    "mx",
    "my",
    "margin",
    "marginTop",
    "marginRight",
    "marginBottom",
    "marginLeft",
    "marginX",
    "marginY",
    "marginInline",
    "marginInlineStart",
    "marginInlineEnd",
    "marginBlock",
    "marginBlockStart",
    "marginBlockEnd"
  ];
  V = [
    "p",
    "pt",
    "pr",
    "pb",
    "pl",
    "px",
    "py",
    "padding",
    "paddingTop",
    "paddingRight",
    "paddingBottom",
    "paddingLeft",
    "paddingX",
    "paddingY",
    "paddingInline",
    "paddingInlineStart",
    "paddingInlineEnd",
    "paddingBlock",
    "paddingBlockStart",
    "paddingBlockEnd"
  ];
  fe = [
    ...Z,
    ...V
  ];
  k = function(e, t, r, n) {
    const s = L(e, t, true) ?? r;
    return typeof s == "number" || typeof s == "string" ? (o) => typeof o == "string" ? o : typeof s == "string" ? `calc(${o} * ${s})` : s * o : Array.isArray(s) ? (o) => {
      if (typeof o == "string") return o;
      const i = Math.abs(o), a = s[i];
      return o >= 0 ? a : typeof a == "number" ? -a : `-${a}`;
    } : typeof s == "function" ? s : () => {
    };
  };
  de = function(e) {
    return k(e, "spacing", 8);
  };
  G = function(e, t) {
    return typeof t == "string" || t == null ? t : e(t);
  };
  We = function(e, t) {
    return (r) => e.reduce((n, s) => (n[s] = G(t, r), n), {});
  };
  function ke(e, t, r, n) {
    if (!t.includes(r)) return null;
    const s = Ee(r), o = We(s, n), i = e[r];
    return B(e, i, o);
  }
  function ee(e, t) {
    const r = de(e.theme);
    return Object.keys(e).map((n) => ke(e, t, n, r)).reduce(R, {});
  }
  m = function(e) {
    return ee(e, Z);
  };
  m.propTypes = {};
  m.filterProps = Z;
  p = function(e) {
    return ee(e, V);
  };
  p.propTypes = {};
  p.filterProps = V;
  me = function(e) {
    return ee(e, fe);
  };
  me.propTypes = {};
  me.filterProps = fe;
  Ge = {
    borderRadius: 4
  };
  Ie = function(e = 8, t = de({
    spacing: e
  })) {
    if (e.mui) return e;
    const r = (...n) => (n.length === 0 ? [
      1
    ] : n).map((o) => {
      const i = t(o);
      return typeof i == "number" ? `${i}px` : i;
    }).join(" ");
    return r.mui = true, r;
  };
  M = function(...e) {
    const t = e.reduce((n, s) => (s.filterProps.forEach((o) => {
      n[o] = s;
    }), n), {}), r = (n) => Object.keys(n).reduce((s, o) => t[o] ? R(s, t[o](n)) : s, {});
    return r.propTypes = {}, r.filterProps = e.reduce((n, s) => n.concat(s.filterProps), []), r;
  };
  S = function(e) {
    return typeof e != "number" ? e : `${e}px solid`;
  };
  function w(e, t) {
    return y({
      prop: e,
      themeKey: "borders",
      transform: t
    });
  }
  ze = w("border", S);
  Le = w("borderTop", S);
  Me = w("borderRight", S);
  _e = w("borderBottom", S);
  He = w("borderLeft", S);
  Ne = w("borderColor");
  Qe = w("borderTopColor");
  De = w("borderRightColor");
  Xe = w("borderBottomColor");
  Ue = w("borderLeftColor");
  Ye = w("outline", S);
  Fe = w("outlineColor");
  _ = (e) => {
    if (e.borderRadius !== void 0 && e.borderRadius !== null) {
      const t = k(e.theme, "shape.borderRadius", 4), r = (n) => ({
        borderRadius: G(t, n)
      });
      return B(e, e.borderRadius, r);
    }
    return null;
  };
  _.propTypes = {};
  _.filterProps = [
    "borderRadius"
  ];
  kt = M(ze, Le, Me, _e, He, Ne, Qe, De, Xe, Ue, _, Ye, Fe);
  H = (e) => {
    if (e.gap !== void 0 && e.gap !== null) {
      const t = k(e.theme, "spacing", 8), r = (n) => ({
        gap: G(t, n)
      });
      return B(e, e.gap, r);
    }
    return null;
  };
  H.propTypes = {};
  H.filterProps = [
    "gap"
  ];
  N = (e) => {
    if (e.columnGap !== void 0 && e.columnGap !== null) {
      const t = k(e.theme, "spacing", 8), r = (n) => ({
        columnGap: G(t, n)
      });
      return B(e, e.columnGap, r);
    }
    return null;
  };
  N.propTypes = {};
  N.filterProps = [
    "columnGap"
  ];
  Q = (e) => {
    if (e.rowGap !== void 0 && e.rowGap !== null) {
      const t = k(e.theme, "spacing", 8), r = (n) => ({
        rowGap: G(t, n)
      });
      return B(e, e.rowGap, r);
    }
    return null;
  };
  Q.propTypes = {};
  Q.filterProps = [
    "rowGap"
  ];
  qe = y({
    prop: "gridColumn"
  });
  Je = y({
    prop: "gridRow"
  });
  Ze = y({
    prop: "gridAutoFlow"
  });
  Ve = y({
    prop: "gridAutoColumns"
  });
  et = y({
    prop: "gridAutoRows"
  });
  tt = y({
    prop: "gridTemplateColumns"
  });
  rt = y({
    prop: "gridTemplateRows"
  });
  nt = y({
    prop: "gridTemplateAreas"
  });
  st = y({
    prop: "gridArea"
  });
  Gt = M(H, N, Q, qe, Je, Ze, Ve, et, tt, rt, nt, st);
  P = function(e, t) {
    return t === "grey" ? t : e;
  };
  ot = y({
    prop: "color",
    themeKey: "palette",
    transform: P
  });
  it = y({
    prop: "bgcolor",
    cssProperty: "backgroundColor",
    themeKey: "palette",
    transform: P
  });
  at = y({
    prop: "backgroundColor",
    themeKey: "palette",
    transform: P
  });
  It = M(ot, it, at);
  C = function(e) {
    return e <= 1 && e !== 0 ? `${e * 100}%` : e;
  };
  ut = y({
    prop: "width",
    transform: C
  });
  te = (e) => {
    if (e.maxWidth !== void 0 && e.maxWidth !== null) {
      const t = (r) => {
        var _a, _b, _c, _d, _e2;
        const n = ((_c = (_b = (_a = e.theme) == null ? void 0 : _a.breakpoints) == null ? void 0 : _b.values) == null ? void 0 : _c[r]) || z[r];
        return n ? ((_e2 = (_d = e.theme) == null ? void 0 : _d.breakpoints) == null ? void 0 : _e2.unit) !== "px" ? {
          maxWidth: `${n}${e.theme.breakpoints.unit}`
        } : {
          maxWidth: n
        } : {
          maxWidth: C(r)
        };
      };
      return B(e, e.maxWidth, t);
    }
    return null;
  };
  te.filterProps = [
    "maxWidth"
  ];
  lt = y({
    prop: "minWidth",
    transform: C
  });
  ct = y({
    prop: "height",
    transform: C
  });
  ft = y({
    prop: "maxHeight",
    transform: C
  });
  dt = y({
    prop: "minHeight",
    transform: C
  });
  zt = y({
    prop: "size",
    cssProperty: "width",
    transform: C
  });
  Lt = y({
    prop: "size",
    cssProperty: "height",
    transform: C
  });
  mt = y({
    prop: "boxSizing"
  });
  Mt = M(ut, te, lt, ct, ft, dt, mt);
  pe = {
    border: {
      themeKey: "borders",
      transform: S
    },
    borderTop: {
      themeKey: "borders",
      transform: S
    },
    borderRight: {
      themeKey: "borders",
      transform: S
    },
    borderBottom: {
      themeKey: "borders",
      transform: S
    },
    borderLeft: {
      themeKey: "borders",
      transform: S
    },
    borderColor: {
      themeKey: "palette"
    },
    borderTopColor: {
      themeKey: "palette"
    },
    borderRightColor: {
      themeKey: "palette"
    },
    borderBottomColor: {
      themeKey: "palette"
    },
    borderLeftColor: {
      themeKey: "palette"
    },
    outline: {
      themeKey: "borders",
      transform: S
    },
    outlineColor: {
      themeKey: "palette"
    },
    borderRadius: {
      themeKey: "shape.borderRadius",
      style: _
    },
    color: {
      themeKey: "palette",
      transform: P
    },
    bgcolor: {
      themeKey: "palette",
      cssProperty: "backgroundColor",
      transform: P
    },
    backgroundColor: {
      themeKey: "palette",
      transform: P
    },
    p: {
      style: p
    },
    pt: {
      style: p
    },
    pr: {
      style: p
    },
    pb: {
      style: p
    },
    pl: {
      style: p
    },
    px: {
      style: p
    },
    py: {
      style: p
    },
    padding: {
      style: p
    },
    paddingTop: {
      style: p
    },
    paddingRight: {
      style: p
    },
    paddingBottom: {
      style: p
    },
    paddingLeft: {
      style: p
    },
    paddingX: {
      style: p
    },
    paddingY: {
      style: p
    },
    paddingInline: {
      style: p
    },
    paddingInlineStart: {
      style: p
    },
    paddingInlineEnd: {
      style: p
    },
    paddingBlock: {
      style: p
    },
    paddingBlockStart: {
      style: p
    },
    paddingBlockEnd: {
      style: p
    },
    m: {
      style: m
    },
    mt: {
      style: m
    },
    mr: {
      style: m
    },
    mb: {
      style: m
    },
    ml: {
      style: m
    },
    mx: {
      style: m
    },
    my: {
      style: m
    },
    margin: {
      style: m
    },
    marginTop: {
      style: m
    },
    marginRight: {
      style: m
    },
    marginBottom: {
      style: m
    },
    marginLeft: {
      style: m
    },
    marginX: {
      style: m
    },
    marginY: {
      style: m
    },
    marginInline: {
      style: m
    },
    marginInlineStart: {
      style: m
    },
    marginInlineEnd: {
      style: m
    },
    marginBlock: {
      style: m
    },
    marginBlockStart: {
      style: m
    },
    marginBlockEnd: {
      style: m
    },
    displayPrint: {
      cssProperty: false,
      transform: (e) => ({
        "@media print": {
          display: e
        }
      })
    },
    display: {},
    overflow: {},
    textOverflow: {},
    visibility: {},
    whiteSpace: {},
    flexBasis: {},
    flexDirection: {},
    flexWrap: {},
    justifyContent: {},
    alignItems: {},
    alignContent: {},
    order: {},
    flex: {},
    flexGrow: {},
    flexShrink: {},
    alignSelf: {},
    justifyItems: {},
    justifySelf: {},
    gap: {
      style: H
    },
    rowGap: {
      style: Q
    },
    columnGap: {
      style: N
    },
    gridColumn: {},
    gridRow: {},
    gridAutoFlow: {},
    gridAutoColumns: {},
    gridAutoRows: {},
    gridTemplateColumns: {},
    gridTemplateRows: {},
    gridTemplateAreas: {},
    gridArea: {},
    position: {},
    zIndex: {
      themeKey: "zIndex"
    },
    top: {},
    right: {},
    bottom: {},
    left: {},
    boxShadow: {
      themeKey: "shadows"
    },
    width: {
      transform: C
    },
    maxWidth: {
      style: te
    },
    minWidth: {
      transform: C
    },
    height: {
      transform: C
    },
    maxHeight: {
      transform: C
    },
    minHeight: {
      transform: C
    },
    boxSizing: {},
    font: {
      themeKey: "font"
    },
    fontFamily: {
      themeKey: "typography"
    },
    fontSize: {
      themeKey: "typography"
    },
    fontStyle: {
      themeKey: "typography"
    },
    fontWeight: {
      themeKey: "typography"
    },
    letterSpacing: {},
    textTransform: {},
    lineHeight: {},
    textAlign: {},
    typography: {
      cssProperty: false,
      themeKey: "typography"
    }
  };
  function pt(...e) {
    const t = e.reduce((n, s) => n.concat(Object.keys(s)), []), r = new Set(t);
    return e.every((n) => r.size === Object.keys(n).length);
  }
  function gt(e, t) {
    return typeof e == "function" ? e(t) : e;
  }
  ht = function() {
    function e(r, n, s, o) {
      const i = {
        [r]: n,
        theme: s
      }, a = o[r];
      if (!a) return {
        [r]: n
      };
      const { cssProperty: u = r, themeKey: c, transform: g, style: f } = a;
      if (n == null) return null;
      if (c === "typography" && n === "inherit") return {
        [r]: n
      };
      const l = L(s, c) || {};
      return f ? f(i) : B(i, n, (d) => {
        let v = I(l, g, d);
        return d === v && typeof d == "string" && (v = I(l, g, `${r}${d === "default" ? "" : ae(d)}`, d)), u === false ? v : {
          [u]: v
        };
      });
    }
    function t(r) {
      const { sx: n, theme: s = {}, nested: o } = r || {};
      if (!n) return null;
      const i = s.unstable_sxConfig ?? pe;
      function a(u) {
        let c = u;
        if (typeof u == "function") c = u(s);
        else if (typeof u != "object") return u;
        if (!c) return null;
        const g = ce(s.breakpoints), f = Object.keys(g);
        let l = g;
        return Object.keys(c).forEach((h) => {
          const d = gt(c[h], s);
          if (d != null) if (typeof d == "object") if (i[h]) l = R(l, e(h, d, s, i));
          else {
            const v = B({
              theme: s
            }, d, (D) => ({
              [h]: D
            }));
            pt(v, d) ? l[h] = t({
              sx: d,
              theme: s,
              nested: true
            }) : l = R(l, v);
          }
          else l = R(l, e(h, d, s, i));
        }), !o && s.modularCssLayers ? {
          "@layer sx": se(s, q(f, l))
        } : se(s, q(f, l));
      }
      return Array.isArray(n) ? n.map(a) : a(n);
    }
    return t;
  };
  ge = ht();
  ge.filterProps = [
    "sx"
  ];
  function yt(e, t) {
    var _a;
    const r = this;
    if (r.vars) {
      if (!((_a = r.colorSchemes) == null ? void 0 : _a[e]) || typeof r.getColorSchemeSelector != "function") return {};
      let n = r.getColorSchemeSelector(e);
      return n === "&" ? t : ((n.includes("data-") || n.includes(".")) && (n = `*:where(${n.replace(/\s*&$/, "")}) &`), {
        [n]: t
      });
    }
    return r.palette.mode === e ? t : {};
  }
  _t = function(e = {}, ...t) {
    const { breakpoints: r = {}, palette: n = {}, spacing: s, shape: o = {}, ...i } = e, a = ye(r), u = Ie(s);
    let c = O({
      breakpoints: a,
      direction: "ltr",
      components: {},
      palette: {
        mode: "light",
        ...n
      },
      spacing: u,
      shape: {
        ...Ge,
        ...o
      }
    }, i);
    return c = Be(c), c.applyStyles = yt, c = t.reduce((g, f) => O(g, f), c), c.unstable_sxConfig = {
      ...pe,
      ...i == null ? void 0 : i.unstable_sxConfig
    }, c.unstable_sx = function(f) {
      return ge({
        sx: f,
        theme: this
      });
    }, c;
  };
  const ie = (e, t, r, n = []) => {
    let s = e;
    t.forEach((o, i) => {
      i === t.length - 1 ? Array.isArray(s) ? s[Number(o)] = r : s && typeof s == "object" && (s[o] = r) : s && typeof s == "object" && (s[o] || (s[o] = n.includes(o) ? [] : {}), s = s[o]);
    });
  }, bt = (e, t, r) => {
    function n(s, o = [], i = []) {
      Object.entries(s).forEach(([a, u]) => {
        (!r || r && !r([
          ...o,
          a
        ])) && u != null && (typeof u == "object" && Object.keys(u).length > 0 ? n(u, [
          ...o,
          a
        ], Array.isArray(u) ? [
          ...i,
          a
        ] : i) : t([
          ...o,
          a
        ], u, i));
      });
    }
    n(e);
  }, xt = (e, t) => typeof t == "number" ? [
    "lineHeight",
    "fontWeight",
    "opacity",
    "zIndex"
  ].some((n) => e.includes(n)) || e[e.length - 1].toLowerCase().includes("opacity") ? t : `${t}px` : t;
  U = function(e, t) {
    const { prefix: r, shouldSkipGeneratingVar: n } = t || {}, s = {}, o = {}, i = {};
    return bt(e, (a, u, c) => {
      if ((typeof u == "string" || typeof u == "number") && (!n || !n(a, u))) {
        const g = `--${r ? `${r}-` : ""}${a.join("-")}`, f = xt(a, u);
        Object.assign(s, {
          [g]: f
        }), ie(o, a, `var(${g})`, c), ie(i, a, `var(${g}, ${f})`, c);
      }
    }, (a) => a[0] === "vars"), {
      css: s,
      vars: o,
      varsWithDefaults: i
    };
  };
  Ht = function(e, t = {}) {
    const { getSelector: r = D, disableCssColorScheme: n, colorSchemeSelector: s } = t, { colorSchemes: o = {}, components: i, defaultColorScheme: a = "light", ...u } = e, { vars: c, css: g, varsWithDefaults: f } = U(u, t);
    let l = f;
    const h = {}, { [a]: d, ...v } = o;
    if (Object.entries(v || {}).forEach(([b, $]) => {
      const { vars: x, css: K, varsWithDefaults: X } = U($, t);
      l = O(l, X), h[b] = {
        css: K,
        vars: x
      };
    }), d) {
      const { css: b, vars: $, varsWithDefaults: x } = U(d, t);
      l = O(l, x), h[a] = {
        css: b,
        vars: $
      };
    }
    function D(b, $) {
      var _a, _b;
      let x = s;
      if (s === "class" && (x = ".%s"), s === "data" && (x = "[data-%s]"), (s == null ? void 0 : s.startsWith("data-")) && !s.includes("%s") && (x = `[${s}="%s"]`), b) {
        if (x === "media") return e.defaultColorScheme === b ? ":root" : {
          [`@media (prefers-color-scheme: ${((_b = (_a = o[b]) == null ? void 0 : _a.palette) == null ? void 0 : _b.mode) || b})`]: {
            ":root": $
          }
        };
        if (x) return e.defaultColorScheme === b ? `:root, ${x.replace("%s", String(b))}` : x.replace("%s", String(b));
      }
      return ":root";
    }
    return {
      vars: l,
      generateThemeVars: () => {
        let b = {
          ...c
        };
        return Object.entries(h).forEach(([, { vars: $ }]) => {
          b = O(b, $);
        }), b;
      },
      generateStyleSheets: () => {
        var _a, _b;
        const b = [], $ = e.defaultColorScheme || "light";
        function x(A, j) {
          Object.keys(j).length && b.push(typeof A == "string" ? {
            [A]: {
              ...j
            }
          } : A);
        }
        x(r(void 0, {
          ...g
        }), g);
        const { [$]: K, ...X } = h;
        if (K) {
          const { css: A } = K, j = (_b = (_a = o[$]) == null ? void 0 : _a.palette) == null ? void 0 : _b.mode, E = !n && j ? {
            colorScheme: j,
            ...A
          } : {
            ...A
          };
          x(r($, {
            ...E
          }), E);
        }
        return Object.entries(X).forEach(([A, { css: j }]) => {
          var _a2, _b2;
          const E = (_b2 = (_a2 = o[A]) == null ? void 0 : _a2.palette) == null ? void 0 : _b2.mode, re = !n && E ? {
            colorScheme: E,
            ...j
          } : {
            ...j
          };
          x(r(A, {
            ...re
          }), re);
        }), b;
      }
    };
  };
  Nt = function(e) {
    return function(r) {
      return e === "media" ? `@media (prefers-color-scheme: ${r})` : e ? e.startsWith("data-") && !e.includes("%s") ? `[${e}="${r}"] &` : e === "class" ? `.${r} &` : e === "data" ? `[data-${r}] &` : `${e.replace("%s", r)} &` : "&";
    };
  };
});
export {
  Be as $,
  kt as A,
  B,
  Wt as C,
  Et as D,
  G as E,
  at as F,
  it as G,
  Pt as H,
  ze as I,
  _e as J,
  Xe as K,
  Ne as L,
  He as M,
  Ue as N,
  _ as O,
  Me as P,
  De as Q,
  Le as R,
  Qe as S,
  S as T,
  mt as U,
  Kt as V,
  ot as W,
  Se as X,
  N as Y,
  Ie as Z,
  k as _,
  __tla,
  pe as a,
  T as a0,
  H as a1,
  Y as a2,
  We as a3,
  I as a4,
  st as a5,
  Ve as a6,
  Ze as a7,
  et as a8,
  qe as a9,
  ut as aA,
  Je as aa,
  nt as ab,
  tt as ac,
  rt as ad,
  ct as ae,
  xe as af,
  m as ag,
  Z as ah,
  ft as ai,
  te as aj,
  dt as ak,
  lt as al,
  Ye as am,
  Fe as an,
  p as ao,
  V as ap,
  P as aq,
  W as ar,
  vt as as,
  Q as at,
  Ge as au,
  Lt as av,
  zt as aw,
  C as ax,
  ht as ay,
  U as az,
  Ot as b,
  _t as c,
  ue as d,
  Rt as e,
  Bt as f,
  At as g,
  Tt as h,
  Ht as i,
  de as j,
  Nt as k,
  le as l,
  we as m,
  $e as n,
  Te as o,
  jt as p,
  L as q,
  be as r,
  ge as s,
  ye as t,
  M as u,
  y as v,
  me as w,
  Mt as x,
  It as y,
  Gt as z
};
