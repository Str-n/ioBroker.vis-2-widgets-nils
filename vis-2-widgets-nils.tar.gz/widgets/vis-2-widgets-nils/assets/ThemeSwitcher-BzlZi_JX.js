import { j as t, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { _ as r, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { e as i, c as s, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CA-kW2vj.js";
import { G as l } from "./Generic-CC2u2WPj.js";
import { __tla as __tla_3 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
import { __tla as __tla_4 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
let h;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  h = class extends l {
    static getWidgetInfo() {
      return {
        id: "tplMaterial2ThemeSwitcher",
        visSet: "vis-2-widgets-nils",
        visName: "Theme switcher",
        visWidgetLabel: "theme_switcher",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                label: "theme_type",
                type: "select",
                options: [
                  {
                    value: "system",
                    label: "Browser"
                  },
                  {
                    value: "static",
                    label: "Static"
                  },
                  {
                    value: "variable",
                    label: "Variable"
                  }
                ],
                default: "system",
                name: "themeType"
              },
              {
                name: "themeName",
                type: "select",
                noTranslation: true,
                options: [
                  {
                    value: "dark",
                    label: "dark"
                  },
                  {
                    value: "light",
                    label: "light"
                  }
                ],
                default: "light",
                label: "theme_name",
                hidden: (e) => e.themeType === "system"
              },
              {
                name: "variant",
                type: "select",
                options: [
                  {
                    value: "contained",
                    label: "Contained"
                  },
                  {
                    value: "text",
                    label: "Text"
                  },
                  {
                    value: "outlined",
                    label: "Outlined"
                  }
                ],
                default: "outlined",
                label: "variant",
                hidden: (e) => e.themeType !== "variable"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: 48,
          height: 48,
          position: "absolute"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_theme_switcher.png"
      };
    }
    componentDidMount() {
      super.componentDidMount();
      let e;
      window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? e = "dark" : e = "light", this.state.rxData.themeType === "system" ? (window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", this.onThemeChanged), this.setState({
        themeName: e
      }, () => this.setViewTheme(e))) : this.state.rxData.themeType === "static" ? e = this.state.rxData.themeName : this.state.rxData.themeType === "variable" && (e = window.localStorage.getItem("App.themeName") || (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")), this.setState({
        themeName: e
      }, () => this.setViewTheme(e));
    }
    setViewTheme(e) {
      var _a, _b;
      (_b = (_a = this.props.context) == null ? void 0 : _a.toggleTheme) == null ? void 0 : _b.call(_a, e || this.state.rxData.themeName);
    }
    onThemeChanged = (e) => this.setState({
      themeName: e.matches ? "dark" : "light"
    });
    componentWillUnmount() {
      this.state.rxData.themeType === "system" && window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change", this.onThemeChanged);
    }
    getWidgetInfo() {
      return h.getWidgetInfo();
    }
    renderWidgetBody(e) {
      return super.renderWidgetBody(e), this.state.rxData.themeType === "system" || this.state.rxData.themeType === "static" ? this.props.editMode ? t.jsx("div", {
        style: {
          display: "flex",
          alignItems: "center",
          width: "100%",
          height: "100%"
        },
        children: t.jsx(i, {
          style: {
            width: "100%",
            textAlign: "center"
          },
          themeName: this.state.themeName,
          toggleTheme: () => {
          },
          t: s.t
        })
      }) : null : this.state.rxData.themeType === "variable" ? t.jsx(r, {
        variant: this.state.rxData.variant,
        style: {
          width: "100%",
          height: "100%"
        },
        onClick: (m) => {
          m.stopPropagation();
          const a = this.state.themeName === "dark" ? "light" : "dark";
          window.localStorage.setItem("App.themeName", a), this.setState({
            themeName: a
          }, () => this.setViewTheme(a));
        },
        children: t.jsx(i, {
          themeName: this.state.themeName,
          toggleTheme: () => {
          },
          t: s.t
        })
      }) : null;
    }
  };
});
export {
  __tla,
  h as default
};
