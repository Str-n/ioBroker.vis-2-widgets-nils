import { j as s, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { a as x, b as g, d as f, _ as h, x as y, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { J as D, K as _, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CRxa-Ic2.js";
import { d as b, _ as $, __tla as __tla_3 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CA-kW2vj.js";
import { G as r } from "./Generic-CC2u2WPj.js";
import { P as j, __tla as __tla_4 } from "./PinCodeDialog-1pjxuXxA.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
import { __tla as __tla_6 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
let u;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })()
]).then(async () => {
  const c = {
    timerDialog: {
      textAlign: "center"
    },
    timerSeconds: {
      fontSize: "200%",
      padding: 40
    },
    lockedButton: {
      display: "flex",
      width: "100%",
      justifyContent: "center",
      alignItems: "center",
      flex: 1,
      gap: 8
    },
    unlockedButtons: {
      display: "flex",
      width: "100%",
      justifyContent: "space-around",
      alignItems: "center",
      flex: 1,
      gap: 8
    },
    lockButton: {
      display: "flex",
      gap: 8,
      alignItems: "center"
    },
    icon: {
      height: 20
    },
    status: {
      display: "flex",
      alignItems: "center"
    },
    noCardContainer: {
      width: "100%",
      height: "100%",
      display: "flex",
      flexDirection: "column"
    },
    noCardLocked: {
      width: "100%",
      textAlign: "right"
    }
  };
  u = class extends r {
    timerInterval;
    lastRxData = "";
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        dialog: false,
        objects: [],
        timerDialog: null,
        pinInput: "",
        invalidPin: false,
        timerSeconds: 0
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2Security",
        visSet: "vis-2-widgets-nils",
        visName: "Security",
        visWidgetLabel: "security",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "disarmText",
                label: "disarm_text"
              },
              {
                name: "securityOffText",
                label: "security_off_text"
              },
              {
                name: "buttonsCount",
                label: "buttons_count",
                type: "number",
                default: 1
              }
            ]
          },
          {
            name: "buttons",
            indexFrom: 1,
            indexTo: "buttonsCount",
            fields: [
              {
                name: "oid",
                type: "id",
                label: "oid",
                onChange: async (t, i, o, a) => {
                  if (i[t.name]) {
                    const n = await a.getObject(i[t.name]);
                    let e = false;
                    if (n == null ? void 0 : n.common) {
                      if (n.common.color && i[`color${t.index}`] !== n.common.color && (i[`color${t.index}`] = n.common.color, e = true), n.common.name) {
                        const l = n.common.name ? r.getText(n.common.name) : "";
                        i[`name${t.index}`] !== l && (i[`name${t.index}`] = l, e = true);
                      }
                      e && o(i);
                    }
                  }
                }
              },
              {
                name: "name",
                label: "name",
                default: r.t("default_button_name")
              },
              {
                name: "color",
                type: "color",
                label: "color"
              },
              {
                name: "icon",
                type: "image",
                label: "icon"
              },
              {
                name: "iconSmall",
                type: "icon64",
                label: "small_icon",
                hidden: "!!data.icon"
              },
              {
                name: "pincode",
                label: "pincode",
                onChange: (t, i, o) => (i[`pincode${t.index}`] = (i[`pincode${t.index}`] || "").replace(/[^0-9]/g, ""), o(i), Promise.resolve()),
                hidden: (t, i) => !!t[`pincode-oid${i}`]
              },
              {
                name: "pincode-oid",
                type: "id",
                label: "pincode_oid",
                hidden: (t, i) => !!t[`pincode${i}`]
              },
              {
                name: "pincodeReturnButton",
                type: "select",
                options: [
                  "submit",
                  "backspace"
                ],
                default: "submit",
                label: "pincode_return_button",
                hidden: (t, i) => !!t[`pincode-oid${i}`] && !!t[`pincode${i}`]
              },
              {
                name: "timerSeconds",
                type: "number",
                label: "timer_seconds"
              },
              {
                name: "timerSeconds-oid",
                type: "id",
                label: "timer_seconds_oid"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 240,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_security.png"
      };
    }
    getWidgetInfo() {
      return u.getWidgetInfo();
    }
    async propertiesUpdate() {
      var _a, _b, _c, _d;
      const t = JSON.stringify(this.state.rxData);
      if (this.lastRxData === t) return;
      this.lastRxData = t;
      const i = [], o = [];
      for (let n = 1; n <= this.state.rxData.buttonsCount; n++) this.state.rxData[`oid${n}`] && this.state.rxData[`oid${n}`] !== "nothing_selected" && o.push(this.state.rxData[`oid${n}`]);
      const a = o.length ? await this.props.context.socket.getObjectsById(o) : {};
      for (let n = 1; n <= this.state.rxData.buttonsCount; n++) {
        const e = a[this.state.rxData[`oid${n}`]];
        if (!e) {
          i[n] = {
            common: {},
            _id: this.state.rxData[`oid${n}`],
            isChart: false
          };
          continue;
        }
        e.common || (e.common = {});
        const l = !!(e.common.custom && e.common.custom[(_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory]);
        if (!this.state.rxData[`icon${n}`] && !e.common.icon && (e.type === "state" || e.type === "channel")) {
          const p = this.state.rxData[`oid${n}`].split("."), d = await this.props.context.socket.getObject(p.slice(0, -1).join("."));
          if (!((_c = d == null ? void 0 : d.common) == null ? void 0 : _c.icon) && (e.type === "state" || e.type === "channel")) {
            const m = await this.props.context.socket.getObject(p.slice(0, -2).join("."));
            ((_d = m == null ? void 0 : m.common) == null ? void 0 : _d.icon) && (e.common.icon = m.common.icon, (m.type === "instance" || m.type === "adapter") && (e.common.icon = `../${m.common.name}.admin/${e.common.icon}`));
          } else e.common.icon = d.common.icon, (d.type === "instance" || d.type === "adapter") && (e.common.icon = `../${d.common.name}.admin/${e.common.icon}`);
        }
        i[n] = {
          common: e.common,
          _id: e._id,
          isChart: l
        };
      }
      JSON.stringify(i) !== JSON.stringify(this.state.objects) && this.setState({
        objects: i
      });
    }
    async onRxDataChanged() {
      await this.propertiesUpdate();
    }
    async componentDidMount() {
      super.componentDidMount(), await this.propertiesUpdate();
    }
    componentWillUnmount() {
      this.timerInterval && clearInterval(this.timerInterval), this.timerInterval = void 0, super.componentWillUnmount();
    }
    renderUnlockDialog() {
      let t = null, i = "", o = "submit";
      for (let a = 1; a <= this.state.rxData.buttonsCount; a++) if (this.getPropertyValue(`oid${a}`)) {
        t = this.state.rxData[`oid${a}`], i = this.getPinCode(a), o = this.state.rxData[`pincodeReturnButton${a}`] === "backspace" ? "backspace" : "submit";
        break;
      }
      return this.state.dialog ? s.jsx(j, {
        pinCode: i,
        pinCodeReturnButton: o,
        onClose: (a) => {
          a && t && this.props.context.setValue(t, false), this.setState({
            dialog: false
          });
        }
      }) : null;
    }
    renderTimerDialog() {
      if (this.state.timerDialog === null) return null;
      const t = () => {
        const o = this.state.timerDialog;
        this.setState({
          timerDialog: null
        }), this.state.rxData[`timerSeconds-oid${o}`] && this.props.context.setValue(this.state.rxData[`timerSeconds-oid${o}`], -1), clearInterval(this.timerInterval);
      }, i = this.state.timerDialog;
      return s.jsxs(x, {
        open: true,
        onClose: t,
        style: c.timerDialog,
        children: [
          s.jsx(g, {
            children: r.t("lock_after", (this.state.rxData[`timerSeconds${i}`] || 0).toString())
          }),
          s.jsxs(f, {
            children: [
              s.jsx("div", {
                style: c.timerSeconds,
                children: this.state.timerSeconds
              }),
              s.jsx("div", {
                children: s.jsx(h, {
                  onClick: t,
                  variant: "contained",
                  children: r.t("lock_cancel")
                })
              })
            ]
          })
        ]
      });
    }
    startTimer(t) {
      const i = this.state.rxData[`timerSeconds${t}`];
      this.setState({
        timerSeconds: i,
        timerDialog: t
      }), this.state.rxData[`timerSeconds-oid${t}`] && this.props.context.setValue(this.state.rxData[`timerSeconds-oid${t}`], i), this.timerInterval = setInterval(() => {
        const o = this.state.timerSeconds - 1;
        this.setState({
          timerSeconds: o
        }), o || (this.state.rxData[`oid${t}`] ? this.props.context.setValue(this.state.rxData[`oid${t}`], true) : this.setState({
          message: r.t("no_oid")
        }), this.state.rxData[`timerSeconds-oid${t}`] && this.props.context.setValue(this.state.rxData[`timerSeconds-oid${t}`], 0), this.timerInterval && clearInterval(this.timerInterval), this.setState({
          timerDialog: null
        }));
      }, 1e3);
    }
    getPinCode(t) {
      return this.state.rxData[`pincode-oid${t}`] ? this.getPropertyValue(`pincode-oid${t}`) : this.state.rxData[`pincode${t}`];
    }
    renderMessageDialog() {
      return this.state.message ? s.jsx(b, {
        text: this.state.message,
        onClose: () => this.setState({
          message: null
        })
      }) : null;
    }
    renderWidgetBody(t) {
      var _a, _b;
      super.renderWidgetBody(t);
      const i = [];
      let o = null;
      for (let e = 1; e <= this.state.rxData.buttonsCount; e++) i.push({
        i: e,
        oid: this.state.rxData[`oid${e}`],
        name: this.state.rxData[`name${e}`],
        color: this.state.rxData[`color${e}`],
        icon: this.state.rxData[`icon${e}`] || this.state.rxData[`iconSmall${e}`] || ((_b = (_a = this.state.objects[e]) == null ? void 0 : _a.common) == null ? void 0 : _b.icon)
      }), this.getPropertyValue(`oid${e}`) && (o = i[i.length - 1]);
      const a = s.jsxs(s.Fragment, {
        children: [
          this.renderUnlockDialog(),
          this.renderTimerDialog(),
          this.renderMessageDialog(),
          o ? s.jsx("div", {
            style: c.lockedButton,
            children: s.jsx(h, {
              variant: "contained",
              onClick: () => {
                this.getPinCode(o.i) ? this.setState({
                  dialog: true,
                  pinInput: ""
                }) : this.props.context.setValue(o.oid, false);
              },
              children: this.state.rxData.disarmText || r.t("unlock")
            })
          }) : s.jsx("div", {
            style: c.unlockedButtons,
            children: i.map((e, l) => s.jsx(h, {
              variant: "contained",
              style: {
                backgroundColor: e.color
              },
              onClick: () => {
                this.state.rxData[`timerSeconds${e.i}`] ? this.startTimer(e.i) : e.oid ? this.props.context.setValue(e.oid, true) : this.setState({
                  message: r.t("no_oid")
                });
              },
              children: s.jsxs("span", {
                style: c.lockButton,
                children: [
                  e.icon ? s.jsx($, {
                    style: c.icon,
                    src: e.icon,
                    alt: ""
                  }) : null,
                  e.name
                ]
              })
            }, l))
          })
        ]
      }), n = s.jsx(y, {
        label: s.jsx("span", {
          style: c.status,
          children: o ? s.jsxs(s.Fragment, {
            children: [
              s.jsx(D, {}),
              o.name
            ]
          }) : s.jsxs(s.Fragment, {
            children: [
              s.jsx(_, {}),
              this.state.rxData.securityOffText || r.t("security_off")
            ]
          })
        }),
        style: {
          backgroundColor: o ? "orange" : "green",
          color: o ? "black" : "white"
        }
      });
      return this.state.rxData.noCard || t.widget.usedInWidget ? s.jsxs("div", {
        style: c.noCardContainer,
        children: [
          s.jsx("div", {
            style: c.noCardLocked,
            children: n
          }),
          a
        ]
      }) : this.wrapContent(a, n, {
        boxSizing: "border-box",
        paddingBottom: 10,
        height: "100%"
      });
    }
  };
});
export {
  __tla,
  u as default
};
