import { j as r, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { a as F, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { a6 as at, a7 as ot, L as nt, a8 as rt, a9 as lt, bx as ht, __tla as __tla_2 } from "./installSVGRenderer-zkbrQCl1.js";
import { _ as y, g as I, p as N, q as z, a as A, b as U, c as _, d as B, r as M, j as ct, k as ut, l as dt, m as E, s as mt, t as K, e as x, f as pt, u as q, v as gt, w as ft, __tla as __tla_3 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { p as V, q as k, r as L, a as yt, s as Y, t as G, u as bt, v as H, w as vt, x as Q, c as wt, d as xt, e as $t, _ as W, y as jt, z as Dt, A as _t, B as St, C as Ct, D as It, E as kt, F as Tt, __tla as __tla_4 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CRxa-Ic2.js";
import { R as C, a as X, h as Ot, r as Vt, b as P, c as Wt, d as Pt, e as R, S as Rt, f as Nt, W as At, T as Bt, g as Z, i as Mt, __tla as __tla_5 } from "./RGBLight-Cl_-MUmI.js";
import { C as Et, __tla as __tla_6 } from "./index-Be4Nqivf.js";
import { _ as S, b as Lt, __tla as __tla_7 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CA-kW2vj.js";
import { G as g } from "./Generic-CC2u2WPj.js";
import { B as Gt, S as Ht, __tla as __tla_8 } from "./BlindsBase-6ShuDYpR.js";
import { D as Jt, L as Ft, __tla as __tla_9 } from "./LockIcon-CF8CnQX5.js";
import { v as tt, F as zt, V as Ut, a as Kt, b as et, c as st, d as T, __tla as __tla_10 } from "./Vacuum-B-771_zz.js";
import { __tla as __tla_11 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
import "./tslib.es6-BuLyYyFn.js";
import "./extends-CF3RwP-h.js";
import "./objectWithoutPropertiesLoose-Dsqj8S3w.js";
import { __tla as __tla_12 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_system__loadShare__.js-yqXflbgy.js";
let it;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_9;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_10;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_11;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_12;
    } catch {
    }
  })()
]).then(async () => {
  function qt(j) {
    return r.jsxs("svg", {
      width: 361,
      height: 361,
      viewBox: "0 0 361 361",
      ...j,
      children: [
        r.jsx("path", {
          d: "M267.826 263.303c0 3.91-3.156 7.082-7.05 7.082l-157.885.021c-3.894 0-7.05-3.171-7.05-7.083v-157.5c0-3.911 3.156-7.083 7.05-7.083l157.885-.021c3.894 0 7.05 3.172 7.05 7.083v157.501z",
          fill: "none",
          stroke: "currentColor",
          strokeWidth: 10,
          strokeMiterlimit: 10
        }),
        r.jsx("path", {
          d: "M258.5 185.584h6.639c2.726 0 5-2.274 5-5s-2.274-5-5-5H258.5c-2.726 0-5 2.274-5 5s2.274 5 5 5z",
          fill: "currentColor"
        }),
        r.jsx("path", {
          d: "M267.826 103.208c0 2.485-2.711 4.5-6.053 4.5l-159.88.021c-3.342 0-6.052-2.015-6.052-4.5v-9c0-2.485 2.71-4.5 6.052-4.5l159.88-.021c3.342 0 6.053 2.015 6.053 4.5v9z",
          fill: "none",
          stroke: "currentColor",
          strokeWidth: 10,
          strokeMiterlimit: 10
        })
      ]
    });
  }
  function Yt() {
    return r.jsxs("svg", {
      viewBox: "0 0 24 24",
      xmlns: "http://www.w3.org/2000/svg",
      children: [
        r.jsx("path", {
          strokeWidth: "1",
          fill: "none",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          stroke: "currentColor",
          d: "M21 12a9 9 0 1 1 -18 0a9 9 0 0 1 18 0z"
        }),
        r.jsx("path", {
          strokeWidth: "1",
          fill: "none",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          stroke: "currentColor",
          d: "M14 9a2 2 0 1 1 -4 0a2 2 0 0 1 4 0z"
        }),
        r.jsx("path", {
          strokeWidth: "2",
          fill: "none",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          stroke: "currentColor",
          d: "M12 16h.01"
        })
      ]
    });
  }
  const Qt = [
    "influxdb",
    "sql",
    "history"
  ];
  nt([
    rt,
    lt,
    ht
  ]);
  async function w(j, t, e, s, a) {
    var _a;
    if (t[j.name] && ((_a = await s.getObject(t[j.name])) == null ? void 0 : _a.common)) {
      const o = t[j.name].split(".");
      o.pop();
      const c = await s.getObjectViewSystem("state", `${o.join(".")}.`, `${o.join(".")}.\u9999`);
      if (c) {
        let d = false;
        Object.values(c).forEach((h) => {
          var _a2;
          const n = (_a2 = h.common) == null ? void 0 : _a2.role;
          if (n && C[n] && (!t[n] || t[n] === "nothing_selected") && j.name !== n && (d = true, C[n] === "rgb" ? t[`oid${a}`] = h._id : t[C[n] + a] = h._id, C[n] === "color_temperature")) {
            const l = h.common;
            !t[`ct_min${a}`] && l.min && (t[`ct_min${a}`] = l.min), !t[`ct_max${a}`] && l.max && (t[`ct_max${a}`] = l.max);
          }
        }), d && e(t);
      }
    }
  }
  const $ = async (j, t, e, s, a) => {
    if (t[j.name]) {
      const i = await s.getObject(t[j.name]);
      if (i == null ? void 0 : i.common) {
        let o = i._id.split(".");
        o.pop();
        let c = await s.getObject(o.join("."));
        if (!c) return;
        (c.type === "channel" || c.type === "folder") && (o.pop(), c = await s.getObject(o.join("."))), c.type !== "device" && (o = i._id.split("."), o.pop());
        const d = await s.getObjectViewSystem("state", `${o.join(".")}.`, `${o.join(".")}.\u9999`);
        if (d) {
          let h = false;
          t[`type${a}`] !== "vacuum" && t[j.name].startsWith("mihome-vacuum.") && (h = true, t[`type${a}`] = "vacuum"), Object.keys(T).forEach((n) => {
            t[`vacuum-${n}-oid${a}`] || Object.values(d).forEach((l) => {
              var _a;
              if (l._id.split(".").includes("rooms")) {
                t[`vacuum-use-rooms${a}`] || (h = true, t[`vacuum-use-rooms${a}`] = true);
                return;
              }
              const m = (_a = l.common) == null ? void 0 : _a.role, v = T[n].role;
              if (v && !(m == null ? void 0 : m.includes(v))) return;
              const D = T[n].name;
              D && !l._id.split(".").pop().toLowerCase().includes(D) || (h = true, t[`vacuum-${n}-oid${a}`] = l._id);
            });
          }), h && e(t);
        }
      }
    }
  }, u = {
    intermediate: {
      opacity: 0.2
    },
    text: {
      textTransform: "none"
    },
    button: {
      display: "block",
      width: "100%",
      overflow: "hidden",
      textOverflow: "ellipsis"
    },
    buttonInactive: {
      opacity: 0.6
    },
    iconButton: {
      width: "100%",
      height: 40,
      display: "block",
      alignItems: "center",
      flexDirection: "column",
      justifyContent: "center"
    },
    iconSwitch: {
      width: 40,
      height: 40,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    },
    cardsHolder: {
      display: "flex",
      justifyContent: "space-between",
      width: "100%",
      alignItems: "center",
      gap: 16,
      position: "relative"
    },
    buttonDiv: {
      display: "inline-block",
      width: 120,
      height: 80,
      textAlign: "center",
      position: "relative"
    },
    iconCustom: {
      maxWidth: 40,
      maxHeight: 40
    },
    controlElement: {
      maxWidth: "50%"
    },
    selectLabel: {
      top: 12,
      left: -13
    },
    widgetContainer: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      position: "relative"
    },
    buttonsContainer: {
      width: "100%",
      display: "flex",
      justifyContent: "center",
      alignItems: "center"
    },
    infoData: {
      textAlign: "center",
      minWidth: 58
    },
    value: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center"
    },
    secondaryValueDiv: {
      marginLeft: 4,
      fontSize: "smaller",
      opacity: 0.6,
      whiteSpace: "nowrap"
    },
    secondaryValue: {
      marginLeft: 4,
      whiteSpace: "nowrap"
    },
    rgbSliderContainer: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      width: "100%"
    },
    rgbDialogContainer: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      maxWidth: 400
    },
    rgbWheel: {
      display: "flex",
      justifyContent: "center"
    },
    rgbDialog: {
      maxWidth: 400
    },
    thermostatCircleDiv: {
      width: "100%",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-end",
      "& svg circle": {
        cursor: "pointer"
      },
      "&>div": {
        margin: "auto",
        "&>div": {
          top: "35% !important"
        }
      }
    },
    thermostatButtonsDiv: {
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
      position: "absolute",
      bottom: 8,
      left: 0
    },
    thermostatNewValueLight: {
      animation: "vis-2-widgets-nils-newValueAnimationLight 2s ease-in-out"
    },
    thermostatNewValueDark: {
      animation: "vis-2-widgets-nils-newValueAnimationDark 2s ease-in-out"
    },
    thermostatDesiredTemp: {
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      width: "100%",
      left: 0,
      transform: "none"
    },
    lockPinGrid: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gridGap: "10px"
    },
    lockPinInput: {
      padding: "10px 0px"
    },
    lockSvgIcon: {},
    vacuumBattery: {
      display: "flex",
      alignItems: "center",
      gap: 4
    },
    vacuumSensorsContainer: {
      overflow: "auto"
    },
    vacuumSensors: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 4,
      minWidth: "min-content"
    },
    vacuumButtons: {
      display: "flex",
      alignItems: "center",
      gap: 4
    },
    vacuumContent: {
      width: "100%",
      height: "100%",
      overflow: "auto"
    },
    vacuumMapContainer: {
      flex: 1
    },
    vacuumTopPanel: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    },
    vacuumBottomPanel: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    },
    vacuumSensorCard: {
      boxShadow: "none",
      backgroundColor: "transparent",
      backgroundImage: "none"
    },
    vacuumSensorCardContent: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      textAlign: "center",
      padding: 2,
      paddingBottom: 2
    },
    vacuumSensorBigText: {
      fontSize: 20
    },
    vacuumSensorSmallText: {
      fontSize: 12
    },
    vacuumImage: {
      width: "100%",
      height: "100%",
      objectFit: "contain",
      color: "grey"
    },
    vacuumSpeedContainer: {
      gap: 4,
      display: "flex",
      alignItems: "center"
    },
    tooltip: {
      pointerEvents: "none"
    },
    disabledOverlay: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      userSelect: "none",
      pointerEvents: "none",
      zIndex: 100
    },
    ...Ht
  };
  it = class extends Gt {
    timeouts = {};
    history = [];
    _refs = [];
    widgetRef = {};
    lastRxData = "";
    doNotWantIncludeWidgets;
    updateDialogChartInterval = null;
    updateChartInterval = null;
    customStyle;
    updateTimeout = null;
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        showControlDialog: null,
        inputValue: "",
        showSetButton: [],
        inputValues: [],
        objects: [],
        historyData: {},
        chartWidth: {},
        chartHeight: {},
        sketch: {},
        secondaryObjects: [],
        dialogPin: null,
        invalidPin: false,
        lockPinInput: "",
        showRoomsMenu: null,
        controlValue: null
      }, this.doNotWantIncludeWidgets = this.state.rxData.doNotWantIncludeWidgets;
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2Switches",
        visSet: "vis-2-widgets-nils",
        visName: "Switches",
        visWidgetLabel: "switches_or_buttons",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                noBinding: false
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "data.noCard === true"
              },
              {
                name: "count",
                type: "number",
                default: 2,
                label: "count"
              },
              {
                name: "type",
                type: "select",
                label: "type",
                options: [
                  {
                    value: "lines",
                    label: "lines"
                  },
                  {
                    value: "buttons",
                    label: "buttons"
                  }
                ],
                default: "lines"
              },
              {
                name: "allSwitch",
                type: "checkbox",
                default: true,
                label: "show_all_switch",
                hidden: 'data.type !== "lines"',
                noBinding: false
              },
              {
                name: "orientation",
                type: "select",
                options: [
                  {
                    value: "h",
                    label: "horizontal"
                  },
                  {
                    value: "v",
                    label: "vertical"
                  },
                  {
                    value: "f",
                    label: "flexible"
                  }
                ],
                default: "horizontal",
                label: "orientation",
                hidden: 'data.type !== "buttons"'
              },
              {
                label: "buttons_width",
                name: "buttonsWidth",
                hidden: 'data.type !== "buttons"',
                type: "slider",
                default: 120,
                min: 40,
                max: 300
              },
              {
                label: "doNotWantIncludeWidgets",
                name: "doNotWantIncludeWidgets",
                type: "checkbox",
                default: false
              }
            ]
          },
          {
            name: "switch",
            label: "group_switch",
            indexFrom: 1,
            indexTo: "count",
            fields: [
              {
                name: "oid",
                type: "id",
                label: "oid",
                hidden: 'data["widget" + index]',
                onChange: async (t, e, s, a, i) => {
                  var _a;
                  if (e[t.name]) {
                    if (e[t.name].startsWith("mihome-vacuum.")) {
                      await $(t, e, s, a, i);
                      return;
                    }
                    const o = await a.getObject(e[t.name]);
                    if (((_a = o == null ? void 0 : o.common) == null ? void 0 : _a.role) && (o.common.role.includes("level.temperature") || o.common.role.includes("rgb") || o.common.role.includes("lock"))) {
                      const c = e[t.name].split(".");
                      c.pop();
                      const d = await a.getObjectViewSystem("state", `${c.join(".")}.`, `${c.join(".")}.\u9999`);
                      if (d) {
                        let h = false;
                        e[`type${i}`] !== "thermostat" && o.common.role.includes("level.temperature") && (h = true, e[`type${i}`] = "thermostat"), e[`type${i}`] !== "rgb" && o.common.role.includes("rgb") && (h = true, e[`type${i}`] = "rgb"), e[`type${i}`] !== "lock" && o.common.role.includes("lock") && (h = true, e[`type${i}`] = "lock"), o.common.role.includes("level.temperature") ? Object.values(d).forEach((n) => {
                          var _a2;
                          const l = (_a2 = n.common) == null ? void 0 : _a2.role;
                          (l == null ? void 0 : l.includes("value.temperature")) ? (e[`actual${i}`] = n._id, h = true) : (l == null ? void 0 : l.includes("power")) ? (e[`switch${i}`] = n._id, h = true) : (l == null ? void 0 : l.includes("boost")) ? (e[`boost${i}`] = n._id, h = true) : (l == null ? void 0 : l.includes("party")) && (e[`party${i}`] = n._id, h = true);
                        }) : o.common.role.includes("rgb") ? (e[`rgbType${i}`] !== "rgb" && o.common.role.includes("rgbw") ? (h = true, e[`rgbType${i}`] = "rgbw") : e[`rgbType${i}`] !== "rgb" && (h = true, e[`rgbType${i}`] = "rgb"), Object.values(d).forEach((n) => {
                          var _a2;
                          const l = (_a2 = n.common) == null ? void 0 : _a2.role;
                          l && C[l] && (!e[l] || e[l] === "nothing_selected") && t.name !== l && (h = true, C[l] === "rgb" ? e[`oid${i}`] = n._id : e[C[l] + i] = n._id);
                        })) : o.common.role.includes("lock") && Object.values(d).forEach((n) => {
                          var _a2;
                          const l = (_a2 = n.common) == null ? void 0 : _a2.role;
                          (l == null ? void 0 : l.includes("button")) ? (e[`open${i}`] = n._id, h = true) : (l == null ? void 0 : l.includes("working")) && (e[`working${i}`] = n._id, h = true);
                        }), h && s(e);
                      }
                    }
                  }
                }
              },
              {
                name: "type",
                type: "select",
                label: "type",
                options: [
                  {
                    value: "auto",
                    label: "auto"
                  },
                  {
                    value: "switch",
                    label: "switch"
                  },
                  {
                    value: "button",
                    label: "button"
                  },
                  {
                    value: "info",
                    label: "info"
                  },
                  {
                    value: "input",
                    label: "input"
                  },
                  {
                    value: "slider",
                    label: "slider"
                  },
                  {
                    value: "select",
                    label: "select"
                  },
                  {
                    value: "blinds",
                    label: "blinds"
                  },
                  {
                    value: "thermostat",
                    label: "thermostat"
                  },
                  {
                    value: "rgb",
                    label: "rgb"
                  },
                  {
                    value: "lock",
                    label: "lock"
                  },
                  {
                    value: "vacuum",
                    label: "vacuum"
                  }
                ],
                hidden: '!data["oid" + index]',
                default: "auto"
              },
              {
                name: "noIcon",
                type: "checkbox",
                label: "no_icon",
                hidden: 'data.type === "buttons" && !!data["widget" + index]',
                noBinding: false
              },
              {
                name: "icon",
                type: "image",
                label: "icon",
                hidden: '!!data["iconSmall" + index] || data["type" + index] === "blinds" || data["noIcon" + index] === true || (data.type === "buttons" && !!data["widget" + index])'
              },
              {
                name: "iconSmall",
                type: "icon64",
                label: "small_icon",
                hidden: '!!data["icon" + index] || data["type" + index] === "blinds" || data["noIcon" + index] === true || (data.type === "buttons" && !!data["widget" + index])'
              },
              {
                name: "iconEnabled",
                type: "image",
                label: "icon_active",
                hidden: '!data["oid" + index] || !!data["iconEnabledSmall" + index] || data["type" + index] === "blinds" || data["noIcon" + index] === true || (data.type === "buttons" && !!data["widget" + index])'
              },
              {
                name: "iconEnabledSmall",
                type: "icon64",
                label: "small_icon_active",
                hidden: '!data["oid" + index] || !!data["iconEnabled" + index] || data["type" + index] === "blinds" || data["noIcon" + index] === true || (data.type === "buttons" && !!data["widget" + index])'
              },
              {
                name: "color",
                type: "color",
                label: "color",
                hidden: '!data["oid" + index] || data["type" + index] === "blinds" || data["widget" + index]'
              },
              {
                name: "colorEnabled",
                type: "color",
                label: "color_active",
                hidden: 'data["type" + index] === "blinds" || data["widget" + index]'
              },
              {
                label: "invert_position",
                type: "checkbox",
                hidden: '!data["oid" + index] || data["type" + index] !== "blinds"',
                name: "slideInvert",
                noBinding: false
              },
              {
                name: "title",
                type: "text",
                label: "title",
                hidden: 'data.type === "buttons" && !!data["widget" + index]'
              },
              {
                name: "unit",
                type: "text",
                noButton: true,
                label: "unit",
                hidden: 'data["type" + index] === "button" || data["type" + index] === "switch" || data["widget" + index]'
              },
              {
                name: "step",
                label: "values_step",
                hidden: '!data["oid" + index] || (data["type" + index] !== "select" && data["type" + index] !== "thermostat")'
              },
              {
                name: "hideChart",
                type: "checkbox",
                label: "hide_chart",
                noBinding: false,
                hidden: '!data["oid" + index] || data["type" + index] !== "info"'
              },
              {
                name: "chartPeriod",
                type: "select",
                options: [
                  {
                    value: "10",
                    label: "10_minutes"
                  },
                  {
                    value: "30",
                    label: "30_minutes"
                  },
                  {
                    value: "60",
                    label: "1_hour"
                  },
                  {
                    value: "120",
                    label: "2_hours"
                  },
                  {
                    value: "180",
                    label: "3_hours"
                  },
                  {
                    value: "360",
                    label: "6_hours"
                  },
                  {
                    value: "720",
                    label: "12_hours"
                  },
                  {
                    value: "1440",
                    label: "1_day"
                  },
                  {
                    value: "2880",
                    label: "2_days"
                  },
                  {
                    value: "10080",
                    label: "1_week"
                  }
                ],
                default: "60",
                label: "chart_period",
                hidden: '!data["oid" + index] || data["type" + index] !== "info" || data["hideChart" + index] === true'
              },
              {
                name: "buttonText",
                type: "text",
                noButton: true,
                label: "button_text",
                hidden: 'data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonIcon" + index] || !!data["buttonImage" + index]'
              },
              {
                name: "buttonIcon",
                type: "icon64",
                label: "button_icon",
                hidden: 'data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonText" + index] || !!data["buttonImage" + index]'
              },
              {
                name: "buttonImage",
                type: "image",
                label: "button_image",
                hidden: 'data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonText" + index] || !!data["buttonIcon" + index]'
              },
              {
                name: "buttonIconActive",
                type: "icon64",
                label: "button_icon",
                hidden: 'data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonText" + index] || !!data["buttonImageActive" + index]'
              },
              {
                name: "buttonImageActive",
                type: "image",
                label: "button_image",
                hidden: 'data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonText" + index] || !!data["buttonIconActive" + index]'
              },
              {
                name: "infoInactiveText",
                type: "text",
                noButton: true,
                label: "info_inactive_text",
                hidden: '!data["oid" + index] || data["type" + index] !== "info" || !!data["infoInactiveIcon" + index] || !!data["infoInactiveImage" + index]'
              },
              {
                name: "infoActiveText",
                type: "text",
                noButton: true,
                label: "info_active_text",
                hidden: '!data["oid" + index] || data["type" + index] !== "info" || !!data["infoActiveIcon" + index] || !!data["infoActiveImage" + index]'
              },
              {
                name: "infoInactiveIcon",
                type: "icon64",
                label: "info_inactive_icon",
                hidden: '!data["oid" + index] || data["type" + index] !== "info" || !!data["infoInactiveText" + index] || !!data["infoInactiveImage" + index]'
              },
              {
                name: "infoActiveIcon",
                type: "icon64",
                label: "info_active_icon",
                hidden: '!data["oid" + index] || data["type" + index] !== "info" || !!data["infoActiveText" + index] || !!data["infoActiveImage" + index]'
              },
              {
                name: "infoInactiveImage",
                type: "image",
                label: "info_inactive_image",
                hidden: '!data["oid" + index] || data["type" + index] !== "info" || !!data["infoInactiveIcon" + index] || !!data["infoInactiveText" + index]'
              },
              {
                name: "infoActiveImage",
                type: "image",
                label: "info_active_image",
                hidden: '!data["oid" + index] || data["type" + index] !== "info" || !!data["infoActiveIcon" + index] || !!data["infoActiveText" + index]'
              },
              {
                name: "infoInactiveColor",
                type: "color",
                label: "info_inactive_color",
                hidden: '!data["oid" + index] || data["type" + index] !== "info"'
              },
              {
                name: "infoActiveColor",
                type: "color",
                label: "info_active_color",
                hidden: '!data["oid" + index] || data["type" + index] !== "info"'
              },
              {
                name: "widget",
                type: "widget",
                label: "widget_id",
                hidden: '!!data["oid" + index]',
                noBinding: true,
                checkUsage: true
              },
              {
                name: "height",
                type: "slider",
                min: 40,
                max: 500,
                label: "height",
                hidden: '!data["widget" + index]'
              },
              {
                name: "position",
                type: "slider",
                min: 0,
                max: 500,
                label: "position",
                hidden: '!data["widget" + index] || data.type !== "lines"'
              },
              {
                name: "hide",
                type: "checkbox",
                label: "hide",
                tooltip: "hide_tooltip",
                noBinding: false
              },
              {
                name: "actual",
                type: "id",
                label: "actual_oid",
                hidden: '!!data["widget" + index] || data["type" + index] !== "thermostat"'
              },
              {
                name: "boost",
                type: "id",
                label: "mode_boost",
                hidden: '!!data["widget" + index] || data["type" + index] !== "thermostat"'
              },
              {
                name: "party",
                type: "id",
                label: "mode_party",
                hidden: '!!data["widget" + index] || data["type" + index] !== "thermostat"'
              },
              {
                name: "switch",
                type: "id",
                label: "switch",
                onChange: w,
                hidden: '!!data["widget" + index] || (data["type" + index] !== "rgb" || data["type" + index] !== "thermostat")'
              },
              {
                name: "brightness",
                type: "id",
                label: "brightness",
                onChange: w,
                hidden: '!!data["widget" + index] || data["type" + index] !== "rgb"'
              },
              {
                name: "rgbType",
                label: "rgbType",
                type: "select",
                noTranslation: true,
                options: [
                  "rgb",
                  "rgbw",
                  "r/g/b",
                  "r/g/b/w",
                  "hue/sat/lum",
                  "ct"
                ],
                onChange: w,
                hidden: '!!data["widget" + index] || data["type" + index] !== "rgb"'
              },
              {
                name: "red",
                type: "id",
                label: "red",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "r/g/b" && t[`rgbType${e}`] !== "r/g/b/w",
                onChange: w
              },
              {
                name: "green",
                type: "id",
                label: "green",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "r/g/b" && t[`rgbType${e}`] !== "r/g/b/w",
                onChange: w
              },
              {
                name: "blue",
                type: "id",
                label: "blue",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "r/g/b" && t[`rgbType${e}`] !== "r/g/b/w",
                onChange: w
              },
              {
                name: "white",
                type: "id",
                label: "white",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "r/g/b/w" && t[`rgbType${e}`] !== "rgbw",
                onChange: w
              },
              {
                name: "color_temperature",
                type: "id",
                label: "color_temperature",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "ct",
                onChange: w
              },
              {
                name: "ct_min",
                type: "number",
                min: 500,
                max: 1e4,
                label: "color_temperature_min",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "ct" || !t[`color_temperature${e}`]
              },
              {
                name: "ct_max",
                type: "number",
                min: 500,
                max: 1e4,
                label: "color_temperature_max",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "ct" || !t[`color_temperature${e}`]
              },
              {
                name: "hue",
                type: "id",
                label: "hue",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "hue/sat/lum",
                onChange: w
              },
              {
                name: "saturation",
                type: "id",
                label: "saturation",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "hue/sat/lum",
                onChange: w
              },
              {
                name: "luminance",
                type: "id",
                label: "luminance",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "hue/sat/lum",
                onChange: w
              },
              {
                name: "hideBrightness",
                type: "checkbox",
                label: "hideBrightness",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "rgb" && t[`rgbType${e}`] !== "rgbw" && t[`rgbType${e}`] !== "r/g/b" && t[`rgbType${e}`] !== "r/g/b/w",
                onChange: w,
                noBinding: false
              },
              {
                name: "whiteMode",
                type: "checkbox",
                label: "whiteMode",
                tooltip: "whiteModeTooltip",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "rgbw" && t[`rgbType${e}`] !== "r/g/b/w",
                onChange: w
              },
              {
                name: "noRgbPalette",
                type: "checkbox",
                label: "noRgbPalette",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "rgb" || t[`rgbType${e}`] !== "rgb" && t[`rgbType${e}`] !== "rgbw" && t[`rgbType${e}`] !== "r/g/b" && t[`rgbType${e}`] !== "r/g/b/w",
                onChange: w
              },
              {
                name: "open",
                type: "id",
                label: "doorOpen-oid",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock"
              },
              {
                name: "working",
                type: "id",
                label: "lockWorking-oid",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock"
              },
              {
                name: "sensor",
                type: "id",
                label: "doorSensor-oid",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock"
              },
              {
                name: "pincode",
                label: "pincode",
                onChange: (t, e, s, a, i) => (e[`pincode${i}`] && e[`pincode${i}`].match(/[^0-9]/g) && (e[`pincode${i}`] = e[`pincode${i}`].replace(/[^0-9]/g, ""), s(e)), Promise.resolve()),
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock" || !!t[`oid-pincode${e}`]
              },
              {
                name: "oid-pincode",
                type: "id",
                label: "pincode_oid",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock" || !!t[`pincode${e}`]
              },
              {
                name: "doNotConfirm",
                type: "checkbox",
                label: "doNotConfirm",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock" || !!t[`oid-pincode${e}`] && !!t[`pincode${e}`]
              },
              {
                name: "noLockAnimation",
                label: "noLockAnimation",
                type: "checkbox",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock" || !t[`oid${e}`]
              },
              {
                name: "lockColor",
                label: "Lock color",
                type: "color",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock" || !t[`oid${e}`] || !!t[`noLockAnimation${e}`]
              },
              {
                name: "pincodeReturnButton",
                type: "select",
                options: [
                  "submit",
                  "backspace"
                ],
                default: "submit",
                label: "pincode_return_button",
                hidden: (t, e) => !!t[`widget${e}`] || t[`type${e}`] !== "lock" || !!t[`oid-pincode${e}`] && !!t[`pincode${e}`]
              },
              {
                name: "timeout",
                label: "controlTimeout",
                tooltip: "timeout_tooltip",
                type: "slider",
                min: 0,
                max: 2e3,
                default: 500,
                hidden: '!!data["widget" + index] || (data["type" + index] !== "rgb" && data["type" + index] !== "slider" && data["type" + index] !== "thermostat")'
              },
              {
                label: "status",
                name: "vacuum-status-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "battery",
                name: "vacuum-battery-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "is_charging",
                name: "vacuum-is-charging-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "fan_speed",
                name: "vacuum-fan-speed-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "sensors_left",
                name: "vacuum-sensors-left-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "filter_left",
                name: "vacuum-filter-left-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "main_brush_left",
                name: "vacuum-main-brush-left-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "side_brush_left",
                name: "vacuum-side-brush-left-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "cleaning_count",
                name: "vacuum-cleaning-count-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "rooms",
                name: "vacuum-use-rooms",
                type: "checkbox",
                tooltip: "rooms_tooltip",
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "map64",
                name: "vacuum-map64-oid",
                type: "id",
                onChange: $,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "useDefaultPicture",
                name: "vacuum-use-default-picture",
                type: "checkbox",
                default: true,
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum" || !!data["vacuum-map64-oid"]'
              },
              {
                label: "ownImage",
                name: "vacuum-own-image",
                type: "image",
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum" || !!data["vacuum-map64-oid"] || !data["vacuum-use-default-picture"]'
              },
              {
                label: "start",
                name: "vacuum-start-oid",
                type: "id",
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "home",
                name: "vacuum-home-oid",
                type: "id",
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                label: "pause",
                name: "vacuum-pause-oid",
                type: "id",
                hidden: '!!data["widget" + index] || data["type" + index] !== "vacuum"'
              },
              {
                type: "delimiter",
                name: "delimiter"
              },
              {
                label: "visibility-oid",
                name: "visibility-oid",
                type: "id"
              },
              {
                label: "visibility-cond",
                name: "visibility-cond",
                type: "select",
                options: [
                  "==",
                  "!=",
                  "<=",
                  ">=",
                  "<",
                  ">",
                  "consist",
                  "not consist",
                  "exist",
                  "not exist"
                ],
                noTranslation: true,
                default: "==",
                hidden: '!data["visibility-oid" + index]'
              },
              {
                label: "visibility-val",
                name: "visibility-val",
                type: "text",
                default: "1",
                hidden: '!data["visibility-oid" + index]'
              },
              {
                label: "visibility-no-hide",
                name: "visibility-no-hide",
                type: "checkbox",
                hidden: '!data["visibility-oid" + index]',
                noBinding: false
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_switches.png"
      };
    }
    getWidgetInfo() {
      return it.getWidgetInfo();
    }
    onStateUpdated(t) {
      var _a;
      ((_a = this.state.controlValue) == null ? void 0 : _a.id) === t && this.setState({
        controlValue: {
          id: t,
          value: this.state.controlValue.value,
          changed: true
        }
      });
    }
    async propertiesUpdate() {
      var _a, _b, _c, _d, _e, _f, _g, _h;
      const t = JSON.stringify(this.state.rxData);
      if (this.lastRxData === t) return;
      this.lastRxData = t;
      const e = [], s = [], a = [];
      for (let o = 1; o <= this.state.rxData.count; o++) this.state.rxData[`type${o}`] === "rgb" ? this.rgbObjectIDs(o, a) : this.state.rxData[`type${o}`] === "thermostat" ? this.thermostatObjectIDs(o, a) : this.state.rxData[`type${o}`] === "vacuum" ? this.vacuumObjectIDs(o, a) : this.state.rxData[`oid${o}`] && this.state.rxData[`oid${o}`] !== "nothing_selected" && a.push(this.state.rxData[`oid${o}`]);
      const i = a.length ? await this.props.context.socket.getObjectsById(a) : {};
      for (let o = 1; o <= this.state.rxData.count; o++) if (this.state.rxData[`type${o}`] === "rgb") this.rgbReadObjects(o, i, e, s);
      else if (this.state.rxData[`type${o}`] === "thermostat") this.thermostatReadObjects(o, i, e, s);
      else if (this.state.rxData[`type${o}`] === "vacuum") await this.vacuumReadObjects(o, i, e, s);
      else if (this.state.rxData[`oid${o}`] && this.state.rxData[`oid${o}`] !== "nothing_selected") {
        const c = i[this.state.rxData[`oid${o}`]];
        if (!c) {
          e[o] = {
            common: {}
          };
          continue;
        }
        c.common || (c.common = {});
        let d = this.state.rxData[`type${o}`];
        if (d === "auto" && (c.common.write === false ? d = "info" : c.common.states && c.common.write !== false ? d = "select" : c.common.type === "number" && c.common.max !== void 0 ? d = "slider" : c.common.type === "boolean" && c.common.write !== false ? d = "switch" : c.common.type === "boolean" && c.common.read === false ? d = "button" : d = "input"), c.common.type === "number" && ((_a = c.common).max ?? (_a.max = 100), (_b = c.common).min ?? (_b.min = 0)), Array.isArray(c.common.states)) {
          const h = {};
          c.common.states.forEach((n) => h[n] = n), c.common.states = h;
        }
        if ((_c = c.common).unit || (_c.unit = this.state.rxData[`unit${o}`]), this.state.rxData[`noIcon${o}`] === true || this.state.rxData[`noIcon${o}`] === "true") c.common.icon = void 0;
        else if (!this.state.rxData[`icon${o}`] && !this.state.rxData[`iconSmall${o}`] && !c.common.icon && (c.type === "state" || c.type === "channel")) {
          const h = this.state.rxData[`oid${o}`].split("."), n = await this.props.context.socket.getObject(h.slice(0, -1).join("."));
          if (!((_d = n == null ? void 0 : n.common) == null ? void 0 : _d.icon) && (c.type === "state" || c.type === "channel")) {
            const l = await this.props.context.socket.getObject(h.slice(0, -2).join("."));
            ((_e = l == null ? void 0 : l.common) == null ? void 0 : _e.icon) && (c.common.icon = g.getObjectIcon(l, l._id) || void 0);
          } else c.common.icon = g.getObjectIcon(n, n._id) || void 0;
        }
        d === "blinds" && (c.common.unit = "%"), e[o] = {
          common: c.common,
          _id: c._id,
          widgetType: d
        }, this.widgetRef[o] && delete this.widgetRef[o];
      } else this.state.rxData[`widget${o}`] ? (e[o] = this.state.rxData[`widget${o}`], (_f = this.widgetRef)[o] || (_f[o] = F.createRef())) : this.widgetRef[o] && (delete this.widgetRef[o], e[o] = null);
      this.doNotWantIncludeWidgets !== !!this.state.rxData.doNotWantIncludeWidgets && (this.doNotWantIncludeWidgets = !!this.state.rxData.doNotWantIncludeWidgets, (_h = (_g = this.props).askView) == null ? void 0 : _h.call(_g, "update", {
        id: this.props.id,
        uuid: this.uuid,
        doNotWantIncludeWidgets: !!this.state.rxData.doNotWantIncludeWidgets
      })), (JSON.stringify(e) !== JSON.stringify(this.state.objects) || JSON.stringify(s) !== JSON.stringify(this.state.secondaryObjects)) && this.setState({
        objects: e,
        secondaryObjects: s
      });
    }
    async componentDidMount() {
      super.componentDidMount(), await this.propertiesUpdate(), this.doNotWantIncludeWidgets = !!this.state.rxData.doNotWantIncludeWidgets, this.props.askView && this.props.askView("update", {
        id: this.props.id,
        uuid: this.uuid,
        canHaveWidgets: true,
        doNotWantIncludeWidgets: !!this.state.rxData.doNotWantIncludeWidgets
      });
    }
    onCommand(t, e) {
      const s = super.onCommand(t, e);
      if (s === false && t === "include") {
        let a = false;
        for (let c = 1; c <= this.state.rxData.count; c++) if (!this.state.rxData[`oid${c}`] && !this.state.rxData[`widget${c}`] && !this.state.rxData[`title${c}`]) {
          a = c;
          break;
        }
        const i = JSON.parse(JSON.stringify(this.props.context.views)), o = i[this.props.view].widgets[this.props.id];
        return a || (o.data.count++, a = o.data.count), o.data[`widget${a}`] = e, this.props.context.changeProject(i), true;
      }
      return s;
    }
    componentWillUnmount() {
      this.updateDialogChartInterval && (clearInterval(this.updateDialogChartInterval), this.updateDialogChartInterval = null), this.updateChartInterval && (clearInterval(this.updateChartInterval), this.updateChartInterval = null), this.rgbDestroy();
    }
    async onRxDataChanged() {
      await this.propertiesUpdate();
    }
    isOn(t, e) {
      const s = this.state.objects[t];
      if (!s || typeof s == "string") return false;
      const a = s;
      return e || (e = this.state.values), a.widgetType === "rgb" || a.widgetType === "thermostat" || a.widgetType === "vacuum" ? e[`${this.state.rxData[`switch${t}`]}.val`] : a.common.type === "number" ? e[`${a._id}.val`] !== a.common.min : !!e[`${a._id}.val`];
    }
    getStateIcon(t) {
      var _a;
      const e = this.state.objects[t];
      let s, a;
      if (this.state.rxData[`noIcon${t}`] === true || this.state.rxData[`noIcon${t}`] === "true") return;
      this.isOn(t) && (s = this.state.rxData[`iconEnabled${t}`] || this.state.rxData[`iconEnabledSmall${t}`]), s || (s = this.state.rxData[`icon${t}`] || this.state.rxData[`iconSmall${t}`]), s || (s = typeof e == "object" ? (_a = e == null ? void 0 : e.common) == null ? void 0 : _a.icon : void 0);
      const i = this.isOn(t), o = this.getColor(t, i);
      return s ? a = r.jsx(S, {
        src: s,
        style: {
          ...u.iconCustom,
          width: 40,
          height: 40,
          color: o
        }
      }) : typeof e == "object" && (e == null ? void 0 : e.widgetType) === "blinds" ? a = r.jsx(qt, {
        style: {
          color: o
        }
      }) : typeof e == "object" && (e == null ? void 0 : e.widgetType) === "vacuum" ? a = r.jsx(Yt, {}) : typeof e == "object" && (e == null ? void 0 : e.widgetType) === "thermostat" ? this.state.rxData[`switch${t}`] && this.state.values[`${this.state.rxData[`switch${t}`]}.val`] ? a = r.jsx(W, {
        color: "primary",
        style: {
          color: o
        }
      }) : a = r.jsx(W, {}) : typeof e == "object" && (e == null ? void 0 : e.widgetType) === "lock" ? i ? a = r.jsx(H, {
        color: "primary",
        style: {
          color: o
        }
      }) : a = r.jsx(Q, {
        style: {
          color: o
        }
      }) : typeof e == "object" && (e == null ? void 0 : e.widgetType) === "rgb" ? this.state.rxData[`switch${t}`] ? this.state.values[`${this.state.rxData[`switch${t}`]}.val`] ? a = r.jsx(k, {
        color: "primary",
        style: {
          color: o
        }
      }) : a = r.jsx(V, {
        style: {
          color: o
        }
      }) : this.state.rxData[`brightness${t}`] ? this.state.values[`${this.state.rxData[`brightness${t}`]}.val`] ? a = r.jsx(k, {
        color: "primary",
        style: {
          color: o
        }
      }) : a = r.jsx(V, {
        style: {
          color: o
        }
      }) : a = r.jsx(k, {
        color: "primary",
        style: {
          color: o
        }
      }) : i ? a = r.jsx(k, {
        color: "primary",
        style: {
          color: o
        }
      }) : a = r.jsx(V, {
        style: {
          color: o
        }
      }), a;
    }
    getColor(t, e) {
      var _a, _b;
      const s = this.state.objects[t];
      if (typeof s != "string") return e === void 0 && (e = this.isOn(t)), e ? this.state.rxData[`colorEnabled${t}`] || this.state.rxData[`color${t}`] || ((_a = s == null ? void 0 : s.common) == null ? void 0 : _a.color) : this.state.rxData[`color${t}`] || ((_b = s == null ? void 0 : s.common) == null ? void 0 : _b.color);
    }
    changeSwitch = (t) => {
      if (!this.state.objects[t] || typeof this.state.objects[t] == "string") return;
      const e = this.state.objects[t];
      if (e.widgetType === "rgb" || e.widgetType === "lock" || e.widgetType === "vacuum" || e.widgetType === "thermostat") this.setState({
        showControlDialog: t
      });
      else if (e.widgetType === "slider" || e.widgetType === "input" || e.widgetType === "select" || e.widgetType === "info") e.widgetType === "info" && (this.updateDialogChartInterval || (this.updateDialogChartInterval = setInterval(() => this.updateCharts(), 6e4)), this.updateCharts(t)), this.setState({
        showControlDialog: t,
        inputValue: this.state.values[`${e._id}.val`]
      });
      else if (e.widgetType === "button") e.common.max !== void 0 ? this.props.context.setValue(this.state.rxData[`oid${t}`], e.common.max) : this.props.context.setValue(this.state.rxData[`oid${t}`], true);
      else {
        const s = JSON.parse(JSON.stringify(this.state.values)), a = `${e._id}.val`;
        e.common.type === "number" ? s[a] = s[a] === e.common.max ? e.common.min : e.common.max : s[a] = !s[a], this.setState({
          values: s
        }), this.props.context.setValue(this.state.rxData[`oid${t}`], s[a]);
      }
    };
    buttonPressed(t, e) {
      this.props.context.setValue(this.state.rxData[`oid${t}`], e);
    }
    setOnOff(t, e) {
      if (!this.state.objects[t] || typeof this.state.objects[t] == "string") return;
      const s = this.state.objects[t], a = JSON.parse(JSON.stringify(this.state.values)), i = `${s._id}.val`;
      a[i] = e ? s.common.max : s.common.min, this.setState({
        values: a
      }), this.props.context.setValue(this.state.rxData[`oid${t}`], a[i]);
    }
    controlSpecificState(t, e) {
      if (!this.state.objects[t] || typeof this.state.objects[t] == "string") return;
      const s = this.state.objects[t], a = JSON.parse(JSON.stringify(this.state.values)), i = `${s._id}.val`;
      s.common.type === "number" ? e = parseFloat(e) : s.common.type === "boolean" && (e = e === "true" || e === true), a[i] = e, this.setState({
        values: a,
        showControlDialog: null
      }), this.props.context.setValue(this.state.rxData[`oid${t}`], a[i]);
    }
    finishChanging() {
      if (this.state.controlValue) {
        const t = {
          controlValue: null
        };
        if (!this.state.controlValue.changed) {
          const e = JSON.parse(JSON.stringify(this.state.values));
          e[`${this.state.controlValue.id}.val`] = this.state.controlValue.value, t.values = e;
        }
        this.setState(t);
      }
    }
    renderControlDialog() {
      var _a, _b;
      const t = this.state.showControlDialog;
      if (t !== null) {
        if (!this.state.objects[t] || typeof this.state.objects[t] == "string") return;
        const e = this.state.objects[t], s = this.state.values[`${e._id}.val`];
        let a;
        if (e.widgetType === "select") {
          let i;
          if (e.common.states) i = Object.keys(e.common.states).map((o, c) => r.jsx(y, {
            style: {
              ...s !== o ? u.buttonInactive : void 0,
              ...this.customStyle
            },
            variant: "contained",
            color: s === o ? "primary" : "grey",
            onClick: () => this.controlSpecificState(t, o),
            children: e.common.states[o]
          }, `${o}_${c}`));
          else if (e.common.type === "number") {
            i = [];
            const o = e.common.min === void 0 ? 0 : e.common.min, c = e.common.max === void 0 ? 100 : e.common.max, d = parseInt(this.state.rxData[`step${t}`], 10) || (e.common.step === void 0 ? (c - o) / 10 : e.common.step);
            i = [];
            for (let h = o; h <= c; h += d) i.push(r.jsx(y, {
              style: {
                ...s !== h ? u.buttonInactive : void 0,
                ...this.customStyle
              },
              variant: "contained",
              color: s === h ? "primary" : "grey",
              onClick: () => this.controlSpecificState(t, h),
              children: h + (e.common.unit || "")
            }, h));
          }
          a = r.jsx("div", {
            style: {
              width: "100%",
              textAlign: "center",
              display: "flex",
              flexWrap: "wrap",
              gap: 4,
              alignItems: "center",
              justifyContent: "center"
            },
            children: i
          });
        } else e.widgetType === "slider" ? a = r.jsxs(r.Fragment, {
          children: [
            r.jsxs("div", {
              style: {
                width: "100%",
                marginBottom: 20
              },
              children: [
                r.jsxs(y, {
                  style: {
                    ...s === e.common.min ? void 0 : u.buttonInactive,
                    width: "50%",
                    ...this.customStyle
                  },
                  color: "grey",
                  onClick: () => {
                    this.setOnOff(t, false), this.setState({
                      showControlDialog: null
                    });
                  },
                  children: [
                    r.jsx(V, {}),
                    g.t("OFF").replace("vis_2_widgets_material_", "")
                  ]
                }),
                r.jsxs(y, {
                  style: {
                    ...s === e.common.max ? void 0 : u.buttonInactive,
                    width: "50%",
                    ...this.customStyle
                  },
                  color: "primary",
                  onClick: () => {
                    this.setOnOff(t, true), this.setState({
                      showControlDialog: null
                    });
                  },
                  children: [
                    r.jsx(k, {}),
                    g.t("ON").replace("vis_2_widgets_material_", "")
                  ]
                })
              ]
            }),
            r.jsx("div", {
              style: {
                width: "100%"
              },
              children: r.jsx(I, {
                size: "small",
                value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === e._id ? this.state.controlValue.value : s,
                step: parseFloat(this.state.rxData[`step${t}`]) || void 0,
                valueLabelDisplay: "auto",
                min: e.common.min,
                max: e.common.max,
                onChangeCommitted: () => this.finishChanging(),
                onChange: (i, o) => {
                  var _a2;
                  return this.setState({
                    controlValue: {
                      id: e._id,
                      value: o,
                      changed: !!((_a2 = this.state.controlValue) == null ? void 0 : _a2.changed)
                    }
                  }, () => this.props.context.setValue(e._id, o));
                }
              })
            })
          ]
        }) : e.widgetType === "rgb" ? a = this.rgbRenderDialog(t) : e.widgetType === "thermostat" ? a = this.thermostatRenderDialog(t) : e.widgetType === "lock" || (e.widgetType === "vacuum" ? a = this.vacuumRenderDialog(t) : e.widgetType === "info" ? this._refs[t] ? (setTimeout(() => this.checkChartWidth(), 50), a = r.jsx("div", {
          style: {
            width: "100%",
            minWidth: 500,
            height: "100%",
            minHeight: 300
          },
          ref: this._refs[t],
          children: this.drawChart(t, {
            width: this.state.chartWidth[t],
            height: this.state.chartHeight[t],
            position: "relative",
            top: void 0,
            right: void 0,
            maxWidth: void 0,
            userSelect: void 0,
            pointerEvents: void 0
          })
        })) : a = r.jsx(K, {}) : a = r.jsxs("div", {
          style: {
            display: "flex",
            gap: 16
          },
          children: [
            r.jsx(N, {
              fullWidth: true,
              variant: "standard",
              value: this.state.inputValue === void 0 || this.state.inputValue === null ? "" : this.state.inputValue,
              slotProps: {
                input: {
                  endAdornment: e.common.unit ? r.jsx(z, {
                    position: "end",
                    children: e.common.unit
                  }) : void 0
                }
              },
              onKeyUp: (i) => {
                if (i.key === "Enter") {
                  const o = JSON.parse(JSON.stringify(this.state.values)), c = `${e._id}.val`;
                  o[c] = this.state.inputValue, this.setState({
                    values: o,
                    showControlDialog: null
                  }), e.common.type === "number" ? this.props.context.setValue(this.state.rxData[`oid${t}`], parseFloat(o[c])) : e.common.type === "boolean" ? this.props.context.setValue(this.state.rxData[`oid${t}`], o[c] === "true" || o[c] === true || o[c] === 1 || o[c] === "1" || o[c] === "on" || o[c] === "ON" || o[c] === "On" || o[c] === "ein" || o[c] === "EIN" || o[c] === "Ein" || o[c] === "an" || o[c] === "AN" || o[c] === "An") : this.props.context.setValue(this.state.rxData[`oid${t}`], o[c]);
                }
              },
              onChange: (i) => this.setState({
                inputValue: i.target.value
              })
            }),
            r.jsx(y, {
              variant: "contained",
              color: "primary",
              title: g.t("Set"),
              style: this.customStyle,
              onClick: () => {
                const i = JSON.parse(JSON.stringify(this.state.values)), o = `${e._id}.val`;
                i[o] = this.state.inputValue, this.setState({
                  values: i,
                  showControlDialog: null
                }), e.common.type === "number" ? this.props.context.setValue(this.state.rxData[`oid${t}`], parseFloat(i[o])) : e.common.type === "boolean" ? this.props.context.setValue(this.state.rxData[`oid${t}`], i[o] === "true" || i[o] === true || i[o] === 1 || i[o] === "1" || i[o] === "on" || i[o] === "ON" || i[o] === "On" || i[o] === "ein" || i[o] === "EIN" || i[o] === "Ein" || i[o] === "an" || i[o] === "AN" || i[o] === "An") : this.props.context.setValue(this.state.rxData[`oid${t}`], i[o]);
              },
              children: r.jsx(L, {})
            })
          ]
        }));
        return r.jsxs(A, {
          fullWidth: true,
          maxWidth: "sm",
          sx: {
            "& .MuiDialog-paper": u.rgbDialog
          },
          open: true,
          onClose: () => {
            this.updateDialogChartInterval && (clearInterval(this.updateDialogChartInterval), this.updateDialogChartInterval = null), this.setState({
              showControlDialog: null
            });
          },
          children: [
            r.jsxs(U, {
              children: [
                (this.state.rxData[`title${t}`] || g.getText((_b = e.common) == null ? void 0 : _b.name) || "").trim(),
                r.jsx(_, {
                  style: {
                    float: "right"
                  },
                  onClick: () => this.setState({
                    showControlDialog: null
                  }),
                  children: r.jsx(yt, {})
                })
              ]
            }),
            r.jsx(B, {
              children: a
            })
          ]
        });
      }
      return null;
    }
    renderWidgetInWidget(t, e, s) {
      var _a, _b, _c, _d, _e, _f, _g;
      const a = this.state.rxData[`widget${t}`], i = (_b = (_a = this.props.context.views[this.props.view]) == null ? void 0 : _a.widgets) == null ? void 0 : _b[a];
      if (i && a !== this.props.id) {
        this.widgetRef[t].current || setTimeout(() => this.forceUpdate(), 50);
        const o = e ? {
          justifyContent: "center"
        } : {
          margin: 8,
          justifyContent: "right"
        };
        return e ? (!this.state.rxData.orientation || this.state.rxData.orientation === "h" ? o.width = this.state.rxData[`width${t}`] || this.state.rxData.buttonsWidth || ((_c = i.style) == null ? void 0 : _c.width) || 120 : this.state.rxData.orientation === "v" ? o.height = this.state.rxData[`height${t}`] || this.state.rxData.buttonsHeight || ((_d = i.style) == null ? void 0 : _d.height) || 80 : this.state.rxData.orientation === "f" && (o.width = this.state.rxData[`width${t}`] || this.state.rxData.buttonsWidth || ((_e = i.style) == null ? void 0 : _e.width) || 120, o.height = this.state.rxData[`height${t}`] || this.state.rxData.buttonsHeight || ((_f = i.style) == null ? void 0 : _f.height) || 80), this.state.selectedOne && (o.border = "1px dashed gray", o.boxSizing = "border-box")) : (o.height = this.state.rxData[`height${t}`] || ((_g = i.style) == null ? void 0 : _g.height) || 80, o.marginRight = this.state.rxData[`position${t}`]), (!s || s === "disabled") && (o.opacity = 0.3), r.jsxs("div", {
          ref: this.widgetRef[t],
          style: {
            ...u.widgetContainer,
            ...o,
            ...s === "disabled" ? {
              pointerEvents: "none"
            } : void 0
          },
          children: [
            this.widgetRef[t].current ? this.getWidgetInWidget(this.props.view, a, {
              refParent: this.widgetRef[t]
            }) : null,
            s === "disabled" ? r.jsx("div", {
              style: u.disabledOverlay
            }) : null
          ]
        }, t);
      }
      return null;
    }
    renderLine(t) {
      var _a, _b, _c, _d;
      if (typeof this.state.objects[t] == "string") return this.renderWidgetInWidget(t, false, true);
      if (!this.state.objects[t]) return null;
      const e = this.state.objects[t];
      let s = this.state.values[`${e._id}.val`];
      if (e.widgetType === "rgb") {
        let h = null;
        this.state.secondaryObjects[t].switch && (h = this.getPropertyValue(`switch${t}`));
        let n;
        h ? n = this.state.rxData[`colorEnabled${t}`] || "#4DABF5" : n = this.state.rxData[`color${t}`] || (this.props.context.themeType === "dark" ? "#111" : "#eee");
        const l = this.state.rxData[`icon${t}`];
        let p;
        const m = {
          color: this.rgbGetColor(t)
        };
        return h === false && (m.opacity = 0.7), l !== void 0 ? l ? p = r.jsx(S, {
          src: l,
          style: m
        }) : (m.borderRadius = "50%", p = r.jsx("div", {
          style: m
        })) : p = r.jsx(G, {
          style: m
        }), r.jsx(_, {
          style: {
            backgroundColor: n,
            width: 36,
            height: 36
          },
          onClick: () => this.setState({
            showControlDialog: t
          }),
          children: p
        });
      }
      if (e.widgetType === "vacuum") return this.vacuumRenderButtons(t, true);
      if (e.widgetType === "lock") return this.lockRenderLine(t);
      if (e.widgetType === "button") {
        const h = this.state.rxData[`buttonText${t}`];
        let n = this.state.rxData[`buttonIcon${t}`] || this.state.rxData[`buttonImage${t}`];
        const l = this.state.rxData[`buttonIconActive${t}`] || this.state.rxData[`buttonImageActive${t}`];
        return l && (s === "1" || s === 1 || s === true || s === "true") && (n = l), r.jsx(y, {
          onKeyDown: () => this.buttonPressed(t, true),
          onKeyUp: () => this.buttonPressed(t, false),
          onMouseDown: () => this.buttonPressed(t, true),
          onMouseUp: () => this.buttonPressed(t, false),
          style: this.customStyle,
          children: h || (n ? r.jsx(S, {
            src: n,
            style: {
              width: 24,
              height: 24
            }
          }) : r.jsx(Y, {}))
        });
      }
      if (e.widgetType === "switch") return r.jsx(M, {
        checked: this.isOn(t),
        onChange: () => this.changeSwitch(t)
      });
      if (e.widgetType === "slider") {
        const h = e.common.min === void 0 ? 0 : e.common.min, n = e.common.max === void 0 ? 100 : e.common.max;
        return [
          r.jsx(I, {
            style: u.controlElement,
            size: "small",
            valueLabelDisplay: "auto",
            step: parseFloat(this.state.rxData[`step${t}`]) || void 0,
            value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === e._id ? this.state.controlValue.value : s ?? h,
            onChange: (l, p) => {
              var _a2;
              this.setState({
                controlValue: {
                  id: e._id,
                  value: p,
                  changed: !!((_a2 = this.state.controlValue) == null ? void 0 : _a2.changed)
                }
              }, () => {
                var _a3;
                let m = this.state.rxData[`timeout${t}`];
                (m == null || m === "") && (m = 500), m ? ((_a3 = this.timeouts)[t] || (_a3[t] = {}), this.timeouts[t][e._id] && clearTimeout(this.timeouts[t][e._id]), this.timeouts[t][e._id] = setTimeout((v) => {
                  this.timeouts[t][e._id] = null, this.props.context.setValue(e._id, v);
                }, parseInt(m, 10), p)) : this.props.context.setValue(e._id, p);
              });
            },
            onChangeCommitted: () => this.finishChanging(),
            min: h,
            max: n
          }, "slider"),
          r.jsx("div", {
            style: {
              width: 45
            },
            children: s + (e.common.unit ? ` ${e.common.unit}` : "")
          }, "value")
        ];
      }
      if (e.widgetType === "thermostat") {
        const h = e.common.min === void 0 ? 12 : e.common.min, n = e.common.max === void 0 ? 30 : e.common.max;
        let l;
        if (this.state.rxData[`actual${t}`] && (l = this.state.values[`${this.state.rxData[`actual${t}`]}.val`], (l || l === "0") && (l = l.toString(), l.includes(".")))) {
          const p = Math.round((parseFloat(l) || 0) * 10) / 10;
          this.props.context.systemConfig.common.isFloatComma ? l = p.toString().replace(".", ",") : l = p.toString();
        }
        return [
          r.jsx(I, {
            style: u.controlElement,
            size: "small",
            step: parseFloat(this.state.rxData[`step${t}`]) || void 0,
            valueLabelDisplay: "auto",
            value: ((_b = this.state.controlValue) == null ? void 0 : _b.id) === e._id ? this.state.controlValue.value : s ?? h,
            onChange: (p, m) => {
              var _a2;
              this.setState({
                controlValue: {
                  id: e._id,
                  value: m,
                  changed: !!((_a2 = this.state.controlValue) == null ? void 0 : _a2.changed)
                }
              }, () => {
                var _a3;
                let v = this.state.rxData[`timeout${t}`];
                (v == null || v === "") && (v = 500), v ? ((_a3 = this.timeouts)[t] || (_a3[t] = {}), this.timeouts[t][e._id] && clearTimeout(this.timeouts[t][e._id]), this.timeouts[t][e._id] = setTimeout((D) => {
                  this.timeouts[t][e._id] = null, this.props.context.setValue(e._id, D);
                }, parseInt(v, 10), m)) : this.props.context.setValue(e._id, m);
              });
            },
            onChangeCommitted: () => this.finishChanging(),
            min: h,
            max: n
          }, "slider"),
          r.jsxs("div", {
            onClick: () => this.setState({
              showControlDialog: t
            }),
            style: {
              width: 45,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              cursor: "pointer"
            },
            children: [
              r.jsx("div", {
                style: {
                  whiteSpace: "nowrap"
                },
                children: s + (e.common.unit ? ` ${e.common.unit}` : "")
              }),
              l ? r.jsx("div", {
                style: {
                  fontSize: "smaller",
                  opacity: 0.7,
                  whiteSpace: "nowrap"
                },
                children: l + (e.common.unit ? ` ${e.common.unit}` : "")
              }) : null
            ]
          }, "value")
        ];
      }
      if (e.widgetType === "input") return [
        r.jsx(N, {
          fullWidth: true,
          onFocus: () => {
            const h = [
              ...this.state.showSetButton
            ];
            h[t] = true;
            const n = [];
            n[t] = s ?? "", this.setState({
              showSetButton: h,
              inputValues: n
            });
          },
          onKeyUp: (h) => {
            if (h.key === "Enter") {
              const n = JSON.parse(JSON.stringify(this.state.values)), l = `${e._id}.val`;
              n[l] = this.state.inputValues[t], this.setState({
                values: n
              }), e.common.type === "number" ? this.props.context.setValue(this.state.rxData[`oid${t}`], parseFloat(n[l])) : e.common.type === "boolean" ? this.props.context.setValue(this.state.rxData[`oid${t}`], n[l] === "true" || n[l] === true || n[l] === 1 || n[l] === "1" || n[l] === "on" || n[l] === "ON" || n[l] === "On" || n[l] === "ein" || n[l] === "EIN" || n[l] === "Ein" || n[l] === "an" || n[l] === "AN" || n[l] === "An") : this.props.context.setValue(this.state.rxData[`oid${t}`], n[l]);
            }
          },
          onBlur: () => {
            setTimeout(() => {
              const h = [
                ...this.state.showSetButton
              ];
              h[t] = false, this.setState({
                showSetButton: h
              });
            }, 100);
          },
          variant: "standard",
          label: this.state.rxData[`title${t}`] || g.getText((_c = e == null ? void 0 : e.common) == null ? void 0 : _c.name) || "",
          value: this.state.showSetButton[t] ? this.state.inputValues[t] : s ?? "",
          slotProps: {
            input: {
              endAdornment: e.common.unit ? r.jsx(z, {
                position: "end",
                children: e.common.unit
              }) : void 0
            }
          },
          onChange: (h) => {
            const n = [];
            n[t] = h.target.value, this.setState({
              inputValues: n
            });
          }
        }, "input"),
        this.state.showSetButton[t] ? r.jsx(y, {
          variant: "contained",
          style: this.customStyle,
          onClick: () => {
            const h = JSON.parse(JSON.stringify(this.state.values)), n = `${e._id}.val`;
            h[n] = this.state.inputValues[t];
            const l = [
              ...this.state.showSetButton
            ];
            l[t] = false, this.setState({
              values: h,
              showSetButton: l
            }), e.common.type === "number" ? this.props.context.setValue(this.state.rxData[`oid${t}`], parseFloat(h[n].replace(",", "."))) : e.common.type === "boolean" ? this.props.context.setValue(this.state.rxData[`oid${t}`], h[n] === "true" || h[n] === true || h[n] === 1 || h[n] === "1" || h[n] === "on" || h[n] === "ON" || h[n] === "On" || h[n] === "ein" || h[n] === "EIN" || h[n] === "Ein" || h[n] === "an" || h[n] === "AN" || h[n] === "An") : this.props.context.setValue(this.state.rxData[`oid${t}`], h[n]);
          },
          children: r.jsx(L, {})
        }, "button") : null
      ];
      if (e.widgetType === "select") {
        let h;
        if (e.common.states) h = Object.keys(e.common.states).map((n) => ({
          label: e.common.states[n],
          value: n
        }));
        else if (e.common.type === "boolean") h = [
          {
            label: g.t("ON"),
            value: true
          },
          {
            label: g.t("OFF"),
            value: false
          }
        ];
        else if (e.common.type === "number") {
          const n = e.common.min === void 0 ? 0 : e.common.min, l = e.common.max === void 0 ? 100 : e.common.max, p = parseInt(this.state.rxData[`step${t}`], 10) || (e.common.step === void 0 ? (l - n) / 10 : e.common.step);
          h = [];
          for (let m = n; m <= l; m += p) h.push({
            label: m + (e.common.unit || ""),
            value: m
          }), s > m && s < m + p && h.push({
            label: s + (e.common.unit || ""),
            value: s
          });
        } else h = [];
        return r.jsxs(ct, {
          fullWidth: true,
          children: [
            r.jsx(ut, {
              style: h.find((n) => n.value === s) ? u.selectLabel : void 0,
              children: this.state.rxData[`title${t}`] || g.getText((_d = e == null ? void 0 : e.common) == null ? void 0 : _d.name) || ""
            }),
            r.jsx(dt, {
              variant: "standard",
              value: s !== void 0 ? s : "",
              onChange: (n) => {
                const l = JSON.parse(JSON.stringify(this.state.values)), p = `${e._id}.val`;
                l[p] = n.target.value, this.setState({
                  values: l
                }), this.props.context.setValue(this.state.rxData[`oid${t}`], l[p]);
              },
              children: h.map((n) => r.jsx(E, {
                value: n.value,
                children: n.label
              }, n.value))
            })
          ]
        });
      }
      if (e.common.type === "number") {
        if (e.widgetType === "blinds") {
          const h = this.getMinMaxPosition(1, t);
          s = parseFloat(s), s = (s - h.min) / (h.max - h.min) * 100, h.invert && (s = 100 - s);
        }
        s = this.formatValue(s);
      }
      this.checkHistory(t).catch((h) => window.alert(`Cannot check history: ${h}`)), s == null && (s = "--");
      let a, i, o, c = false;
      if (e.common.type === "boolean" || e.common.type === "number" || s === 0 || s === 1 || s === "0" || s === "1" || s === true || s === "true" || s === false || s === "false") {
        (s === true || s === "true" || s === 1 || s === "1" || s === "on" || s === "ON" || s === "On" || s === "ein" || s === "EIN" || s === "Ein" || s === "an" || s === "AN" || s === "An") && (c = true);
        const h = this.state.rxData[`infoInactiveColor${t}`] || this.state.rxData[`color${t}`];
        if (c) {
          const n = this.state.rxData[`infoActiveColor${t}`] || this.state.rxData[`colorEnabled${t}`], l = n && h && n !== h;
          a = this.state.rxData[`infoActiveIcon${t}`] || this.state.rxData[`infoActiveImage${t}`], !a && l && (a = this.state.rxData[`infoInactiveIcon${t}`] || this.state.rxData[`infoInactiveImage${t}`]), i = this.state.rxData[`infoActiveText${t}`], !i && l && (i = this.state.rxData[`infoInactiveText${t}`]), o = n || h;
        } else a = this.state.rxData[`infoInactiveIcon${t}`] || this.state.rxData[`infoInactiveImage${t}`], i = this.state.rxData[`infoInactiveText${t}`], o = h;
      }
      if (e.widgetType === "blinds") {
        let h = 40;
        const n = 40;
        h -= 0.12 * n, i = r.jsxs("div", {
          style: {
            display: "flex",
            alignItems: "center",
            gap: 8,
            cursor: "pointer"
          },
          children: [
            r.jsxs("span", {
              children: [
                s,
                "%"
              ]
            }),
            this.renderWindows({
              height: h,
              width: n
            }, t)
          ]
        });
      }
      let d;
      return i ? d = r.jsx("span", {
        style: {
          color: o
        },
        children: i
      }) : a ? d = r.jsx(S, {
        src: a,
        style: {
          width: 24,
          height: 24,
          color: o
        }
      }) : d = r.jsx("span", {
        style: {
          color: o
        },
        children: s + (e.common.unit ? ` ${e.common.unit}` : "")
      }), this._refs[t] && e.common.type === "number" ? (setTimeout(() => this.checkChartWidth(), 50), r.jsxs("div", {
        style: {
          flexGrow: 1,
          textAlign: "right",
          cursor: "pointer"
        },
        ref: this._refs[t],
        onClick: () => this.setState({
          showControlDialog: t
        }),
        children: [
          this.drawChart(t),
          d
        ]
      })) : r.jsx("div", {
        style: u.infoData,
        children: d
      });
    }
    checkChartWidth() {
      for (let t = 0; t < this._refs.length; ++t) {
        const e = this._refs[t];
        if (e == null ? void 0 : e.current) {
          const s = e.current.offsetWidth, a = e.current.offsetHeight;
          if (s !== this.state.chartWidth[t] || a !== this.state.chartHeight[t]) {
            const i = {
              ...this.state.chartWidth
            }, o = {
              ...this.state.chartHeight
            };
            i[t] = s, o[t] = a, this.setState({
              chartWidth: i,
              chartHeight: o
            });
          }
        }
      }
    }
    drawChart(t, e) {
      if (this.state.historyData[t] && this.state.chartWidth[t]) {
        const s = {
          height: 37,
          width: this.state.chartWidth[t],
          position: "absolute",
          right: 0,
          top: 0,
          maxWidth: 200,
          userSelect: "none",
          pointerEvents: "none",
          ...e
        };
        return r.jsx(at, {
          style: {
            ...u.chart,
            ...s
          },
          echarts: ot,
          option: this.state.historyData[t],
          notMerge: true,
          lazyUpdate: true,
          theme: this.props.context.themeType === "dark" ? "dark" : "",
          opts: {
            renderer: "svg"
          }
        });
      }
      return null;
    }
    async checkHistory(t, e) {
      var _a, _b;
      if (!this.state.objects[t] || typeof this.state.objects[t] == "string") return;
      const s = this.state.objects[t], a = s.common.custom;
      if (!a || this.state.rxData[`hideChart${t}`] === true || this.state.rxData[`hideChart${t}`] === "true") {
        s.common.history = false, this._refs[t] && (this._refs[t] = null), this.history[t] && (this.history[t] = null);
        let o = 0;
        for (let c = 0; c < this.history.length; c++) this.history[c] && o++;
        o || (this.updateChartInterval && (clearInterval(this.updateChartInterval), this.updateChartInterval = null), this.updateDialogChartInterval && (clearInterval(this.updateDialogChartInterval), this.updateDialogChartInterval = null), this.history = []), this.state.historyData[t] && setTimeout(() => {
          const c = {
            ...this.state.historyData
          };
          delete c[t], this.setState({
            historyData: c
          });
        }, 100);
        return;
      }
      if (s.common.history) return;
      s.common.history = true;
      let i;
      if (a[this.props.context.systemConfig.common.defaultHistory] && ((_a = await this.props.context.socket.getState(`system.adapter.${this.props.context.systemConfig.common.defaultHistory}.alive`)) == null ? void 0 : _a.val) && (i = this.props.context.systemConfig.common.defaultHistory), !i) {
        const o = Object.keys(a);
        for (let c = 0; c < o.length; c++) {
          if (o[c] === this.props.context.systemConfig.common.defaultHistory) continue;
          const d = o[c].split(".")[0];
          if (Qt.includes(d) && ((_b = await this.props.context.socket.getState(`system.adapter.${o[c]}.alive`)) == null ? void 0 : _b.val)) {
            i = o[c];
            break;
          }
        }
      }
      i && (this._refs[t] = this._refs[t] || F.createRef(), this.history[t] = i, e || (this.updateChartInterval || (this.updateChartInterval = setInterval(() => this.updateCharts(), 6e4)), this.updateCharts(t)));
    }
    updateCharts(t) {
      let e;
      if (t !== void 0) e = [
        t
      ];
      else {
        e = [];
        for (let s = 0; s < this.history.length; s++) this.history[s] && e.push(s);
      }
      for (let s = 0; s < e.length; s++) ((a) => {
        if (!this.state.objects[a] || typeof this.state.objects[a] == "string" || !this.state.objects[a]._id) return;
        const i = this.state.objects[a];
        this.props.context.socket.getHistory(i._id, {
          instance: this.history[a],
          start: Date.now() - (parseInt(this.state.rxData[`chartPeriod${a}`], 10) || 60) * 6e4,
          aggregate: "minmax",
          step: 6e4
        }).then((o) => {
          var _a, _b, _c, _d;
          if (o) {
            const c = {
              ...this.state.historyData
            }, d = [];
            let h = ((_a = o[0]) == null ? void 0 : _a.val) || 0, n = ((_b = o[0]) == null ? void 0 : _b.val) || 0;
            for (let b = 0; b < o.length; b++) {
              const f = o[b];
              f.val !== null && h > f.val && (h = f.val), f.val !== null && n < f.val && (n = f.val), d.push([
                f.ts,
                f.val
              ]);
            }
            const l = this.state.rxData.type !== "lines", p = {
              type: "line",
              showSymbol: false,
              data: d,
              lineStyle: {
                color: this.props.context.theme.palette.primary.main,
                opacity: 0.3
              },
              areaStyle: {
                opacity: 0.1
              }
            }, m = {
              type: "value",
              show: l,
              boundaryGap: [
                0,
                "100%"
              ],
              splitLine: {
                show: l
              },
              min: h,
              max: n
            };
            let v;
            if (l) {
              if (m.axisTick = {
                alignWithLabel: true
              }, m.axisLabel = {
                formatter: (b) => {
                  let f;
                  return this.props.context.systemConfig.common.isFloatComma ? f = b.toString().replace(",", ".") + (i.common.unit || "") : f = b + (i.common.unit || ""), f;
                },
                showMaxLabel: true,
                showMinLabel: true
              }, delete m.min, delete m.max, i.common.type === "boolean") p.step = "end", m.axisLabel.showMaxLabel = false, m.axisLabel.formatter = (b) => b === 1 ? "TRUE" : "FALSE", m.max = 1.5, m.interval = 1;
              else if (i.common.type === "number" && i.common.states) {
                p.step = "end", m.axisLabel.showMaxLabel = false, m.axisLabel.formatter = (f) => i.common.states[f] ?? f;
                const b = Object.keys(i.common.states);
                b.sort(), m.max = parseFloat(b[b.length - 1]) + 0.5, m.interval = 1;
              } else i.common.type === "number" && (i.common.min !== void 0 && i.common.max !== void 0 ? (m.max = i.common.max, m.min = i.common.min) : i.common.unit === "%" && (m.max = 100, m.min = 0));
              v = {
                trigger: "axis",
                formatter: (b) => {
                  const f = b[0], J = new Date(f.value[0]);
                  let O = f.value[1];
                  return O !== null && this.props.context.systemConfig.common.isFloatComma && (O = O.toString().replace(".", ",")), `${f.exact === false ? "i" : ""}${J.toLocaleString()}.${J.getMilliseconds().toString().padStart(3, "0")}: ${O}${i.common.unit || ""}`;
                },
                axisPointer: {
                  animation: true
                }
              };
            }
            c[a] = {
              backgroundColor: "transparent",
              grid: l ? {
                top: 10,
                right: 0
              } : {
                left: 2,
                right: 2,
                top: 2,
                bottom: 2
              },
              animation: false,
              xAxis: {
                type: "time",
                show: l
              },
              yAxis: m,
              series: [
                p
              ],
              tooltip: v
            };
            const D = {
              historyData: c
            };
            ((_d = (_c = this._refs[a]) == null ? void 0 : _c.current) == null ? void 0 : _d.offsetWidth) && (this.state.chartWidth[a] !== this._refs[a].current.offsetWidth || this.state.chartHeight[a] !== this._refs[a].current.offsetHeight) && (D.chartWidth = {
              ...this.state.chartWidth
            }, D.chartHeight = {
              ...this.state.chartHeight
            }, D.chartWidth[a] = this._refs[a].current.offsetWidth, D.chartHeight[a] = this._refs[a].current.offsetHeight), this.setState(D);
          }
        });
      })(e[s]);
    }
    renderButton(t, e) {
      var _a, _b, _c, _d, _e, _f, _g;
      const s = this.checkLineVisibility(t);
      if (!s && !this.props.editMode || !this.state.objects[t]) return null;
      if (typeof this.state.objects[t] == "string") return this.renderWidgetInWidget(t, true, s);
      const a = this.state.objects[t];
      let i, o = null;
      const c = {};
      if (a.widgetType !== "rgb" && (i = this.state.values[`${a._id}.val`], ((_a = a.common) == null ? void 0 : _a.type) === "number" || ((_b = a.common) == null ? void 0 : _b.states))) if (a.common.states && a.common.states[i] !== void 0) i = a.common.states[i];
      else {
        if (a.widgetType === "blinds") {
          const n = this.getMinMaxPosition(1, t);
          i = parseFloat(i), i = (i - n.min) / (n.max - n.min) * 100, n.invert && (i = 100 - i);
        }
        i = this.formatValue(i);
      }
      if (a.widgetType === "info") this.checkHistory(t).catch((n) => console.error(`Cannot read history: ${n}`));
      else if (a.widgetType === "blinds") {
        let n = 40;
        const l = 40;
        n -= 0.12 * l, e = this.renderWindows({
          height: n,
          width: l
        }, t);
      } else if (a.widgetType === "rgb") {
        let n = null;
        this.state.secondaryObjects[t].switch && (n = this.getPropertyValue(`switch${t}`)), c.backgroundColor = n === null || n ? this.rgbGetColor(t) : this.props.context.themeType === "dark" ? "#111" : "#eee", c.color = Lt.getInvertedColor(c.backgroundColor, this.props.context.themeType), e = r.jsx(G, {
          style: {
            color: n === null || n ? void 0 : this.rgbGetColor(t)
          }
        });
      } else if (a.widgetType === "thermostat") {
        const n = (_c = this.state.secondaryObjects[t]) == null ? void 0 : _c.actual;
        if (n) {
          const l = this.state.values[`${n._id}.val`];
          (l || l === 0) && (o = r.jsxs("div", {
            style: u.secondaryValueDiv,
            children: [
              "/",
              r.jsxs("span", {
                style: u.secondaryValue,
                children: [
                  this.formatValue(l, 1),
                  this.state.rxData[`unit${t}`] || ((_d = n.common) == null ? void 0 : _d.unit) || ""
                ]
              })
            ]
          }));
        }
      } else if (a.widgetType === "vacuum") {
        const n = this.vacuumGetValue(t, "status"), l = tt(n);
        e = r.jsx(st, {
          style: {
            color: l,
            width: "100%",
            height: "100%"
          }
        }), i = r.jsx("span", {
          style: {
            color: l
          },
          children: g.t(n).replace("vis_2_widgets_material_", "")
        });
      }
      let d = 120, h = 80;
      if (!this.state.rxData.orientation || this.state.rxData.orientation === "h" ? d = parseInt(this.state.rxData[`width${t}`], 10) || this.state.rxData.buttonsWidth || 120 : this.state.rxData.orientation === "v" ? h = this.state.rxData[`height${t}`] || this.state.rxData.buttonsHeight || 80 : this.state.rxData.orientation === "f" && (d = parseInt(this.state.rxData[`width${t}`], 10) || this.state.rxData.buttonsWidth || 120, h = this.state.rxData[`height${t}`] || this.state.rxData.buttonsHeight || 80), a.widgetType === "lock") return this.lockRenderLine(t, d, h);
      if (a.widgetType === "button") {
        const n = this.state.rxData[`title${t}`];
        let l = this.state.rxData[`icon${t}`] || this.state.rxData[`iconSmall${t}`];
        const p = this.state.rxData[`iconEnabled${t}`] || this.state.rxData[`iconEnabledSmall${t}`], m = i === "1" || i === 1 || i === true || i === "true";
        return p && m && (l = p), r.jsx(y, {
          onKeyDown: () => this.buttonPressed(t, true),
          onKeyUp: () => this.buttonPressed(t, false),
          onMouseDown: () => this.buttonPressed(t, true),
          onMouseUp: () => this.buttonPressed(t, false),
          style: {
            ...u.buttonDiv,
            width: d || void 0,
            height: h || void 0,
            border: this.state.selectedOne ? "1px dashed gray" : "none",
            boxSizing: "border-box",
            opacity: s && s !== "disabled" ? void 0 : 0.3,
            ...s === "disabled" ? {
              pointerEvents: "none"
            } : void 0,
            ...this.customStyle,
            color: m ? this.state.rxData[`colorEnabled${t}`] : this.state.rxData[`color${t}`]
          },
          startIcon: n && l ? r.jsx(S, {
            src: l,
            style: {
              width: 24,
              height: 24
            }
          }) : null,
          children: n || (l ? r.jsx(S, {
            src: l,
            style: {
              width: 24,
              height: 24
            }
          }) : r.jsx(Y, {}))
        });
      }
      return r.jsxs("div", {
        className: "test",
        style: {
          ...u.buttonDiv,
          width: d || void 0,
          height: h || void 0,
          border: this.state.selectedOne ? "1px dashed gray" : "none",
          boxSizing: "border-box",
          opacity: s && s !== "disabled" ? void 0 : 0.3,
          ...s === "disabled" ? {
            pointerEvents: "none"
          } : void 0
        },
        children: [
          r.jsxs(y, {
            onClick: () => this.changeSwitch(t),
            color: !((_e = a.common) == null ? void 0 : _e.states) && this.isOn(t) ? "primary" : "grey",
            style: {
              ...u.button,
              ...this.isOn(t) ? void 0 : u.buttonInactive,
              ...c
            },
            disabled: a.widgetType === "info" && (!this.history[t] || this.state.rxData[`hideChart${t}`] === true || this.state.rxData[`hideChart${t}`] === "true"),
            children: [
              e ? r.jsx("div", {
                style: u.iconButton,
                children: e
              }) : null,
              r.jsx("div", {
                style: {
                  ...u.text,
                  ...this.customStyle
                },
                children: this.state.rxData[`title${t}`] || g.getText((_f = a.common) == null ? void 0 : _f.name) || ""
              }),
              i != null || o ? r.jsxs("div", {
                style: u.value,
                children: [
                  r.jsx("div", {
                    children: i
                  }),
                  this.state.rxData[`unit${t}`] || ((_g = a.common) == null ? void 0 : _g.unit) || "",
                  o
                ]
              }) : null
            ]
          }),
          s === "disabled" ? r.jsx("div", {
            style: u.disabledOverlay
          }) : null
        ]
      }, t);
    }
    lockRenderUnlockDialog() {
      if (this.state.dialogPin === null) return null;
      const t = this.state.dialogPin.index, e = this.lockGetPinCode(t), s = this.state.rxData[`pincodeReturnButton${t}`] === "backspace" ? "backspace" : "submit";
      return r.jsxs(A, {
        open: true,
        onClose: () => this.setState({
          dialogPin: null
        }),
        children: [
          r.jsx(U, {
            children: g.t("enter_pin")
          }),
          r.jsxs(B, {
            children: [
              r.jsx("div", {
                style: u.lockPinInput,
                children: r.jsx(N, {
                  variant: "outlined",
                  fullWidth: true,
                  type: this.state.invalidPin ? "text" : "password",
                  slotProps: {
                    input: {
                      readOnly: true,
                      style: {
                        textAlign: "center",
                        color: this.state.invalidPin ? "#ff3e3e" : "inherit"
                      }
                    }
                  },
                  value: this.state.invalidPin ? g.t("invalid_pin") : this.state.lockPinInput
                })
              }),
              r.jsx("div", {
                style: u.lockPinGrid,
                children: [
                  1,
                  2,
                  3,
                  4,
                  5,
                  6,
                  7,
                  8,
                  9,
                  "R",
                  0,
                  s
                ].map((a) => {
                  let i = a;
                  return a === "backspace" ? i = r.jsx(Tt, {}) : a === "submit" && (i = r.jsx(L, {})), r.jsx(y, {
                    variant: "outlined",
                    title: a === "R" ? this.state.lockPinInput ? g.t("reset") : g.t("close") : a === s ? "enter" : "",
                    onClick: () => {
                      if (a === "submit") this.state.lockPinInput === e ? (this.state.dialogPin.oid === "open" ? this.props.context.setValue(this.state.rxData[`open${t}`], true) : this.props.context.setValue(this.state.rxData[`oid${t}`], true), this.setState({
                        dialogPin: null
                      })) : (this.setState({
                        lockPinInput: "",
                        invalidPin: true
                      }), setTimeout(() => this.setState({
                        invalidPin: false
                      }), 500));
                      else if (a === "backspace") this.setState({
                        lockPinInput: this.state.lockPinInput.slice(0, -1)
                      });
                      else if (a === "R") this.state.lockPinInput ? this.setState({
                        lockPinInput: ""
                      }) : this.setState({
                        dialogPin: null
                      });
                      else {
                        const o = this.state.lockPinInput + a;
                        this.setState({
                          lockPinInput: o
                        }), s === "backspace" && o === e && (this.state.dialogPin.oid === "open" ? this.props.context.setValue(this.state.rxData[`open${t}`], true) : this.props.context.setValue(this.state.rxData[`oid${t}`], true), this.setState({
                          dialogPin: null
                        }));
                      }
                    },
                    children: i === "R" ? this.state.lockPinInput ? "R" : "x" : i
                  }, a);
                })
              })
            ]
          })
        ]
      });
    }
    lockGetPinCode(t) {
      return this.state.rxData[`oid-pincode${t}`] ? this.getPropertyValue(`oid-pincode${t}`) : this.state.rxData[`pincode${t}`];
    }
    lockRenderConfirmDialog() {
      if (!this.state.lockConfirmDialog) return null;
      const t = this.state.lockConfirmDialog.index;
      return r.jsxs(A, {
        open: true,
        onClose: () => this.setState({
          lockConfirmDialog: null
        }),
        children: [
          r.jsx(B, {
            children: g.t("please_confirm")
          }),
          r.jsxs(mt, {
            children: [
              r.jsx(y, {
                variant: "contained",
                color: "primary",
                onClick: () => {
                  this.setState({
                    lockConfirmDialog: null
                  }), this.state.lockConfirmDialog.oid === "open" ? this.props.context.setValue(this.state.rxData[`open${t}`], true) : this.props.context.setValue(this.state.rxData[`oid${t}`], true);
                },
                startIcon: this.state.lockConfirmDialog.oid === "open" ? r.jsx(bt, {}) : r.jsx(H, {}),
                children: g.t("Open")
              }),
              r.jsx(y, {
                variant: "contained",
                color: "grey",
                autoFocus: true,
                onClick: () => this.setState({
                  lockConfirmDialog: null
                }),
                startIcon: r.jsx(vt, {}),
                children: g.t("Cancel")
              })
            ]
          })
        ]
      });
    }
    lockRenderLine(t, e, s) {
      if (!this.state.objects[t] || typeof this.state.objects[t] == "string") return null;
      const a = this.state.objects[t];
      let i = 30;
      e && (i = Math.min((e - 32) / 2, s - 16));
      const o = this.state.rxData[`sensor${t}`] && this.getPropertyValue(`sensor${t}`), c = this.getPropertyValue(`oid${t}`), d = this.state.rxData[`working${t}`] && this.getPropertyValue(`working${t}`), h = r.jsxs("div", {
        style: {
          display: "flex"
        },
        children: [
          this.state.rxData[`sensor${t}`] || this.state.rxData[`open${t}`] ? r.jsx(_, {
            disabled: !this.state.rxData[`open${t}`],
            title: this.state.rxData[`open${t}`] ? g.t("open_door") : void 0,
            onClick: () => {
              this.lockGetPinCode(t) ? this.setState({
                dialogPin: {
                  oid: "open",
                  index: t
                },
                lockPinInput: ""
              }) : this.state.rxData[`doNotConfirm${t}`] ? this.props.context.setValue(this.state.rxData[`open${t}`], true) : this.setState({
                lockConfirmDialog: {
                  oid: "open",
                  index: t
                }
              });
            },
            children: r.jsx(Jt, {
              open: o,
              size: i
            })
          }, "door") : null,
          this.state.rxData[`oid${t}`] ? r.jsxs(_, {
            title: c ? g.t("close_lock") : g.t("open_lock"),
            onClick: () => {
              !c && this.lockGetPinCode(t) ? this.setState({
                dialogPin: {
                  oid: "oid",
                  index: t
                },
                lockPinInput: ""
              }) : c || this.state.rxData[`doNotConfirm${t}`] ? this.props.context.setValue(this.state.rxData[`oid${t}`], !this.getPropertyValue(`oid${t}`)) : this.setState({
                lockConfirmDialog: {
                  oid: "oid",
                  index: t
                }
              });
            },
            children: [
              d ? r.jsx(K, {
                style: u.workingIcon,
                size: i
              }) : null,
              r.jsx("style", {
                children: `
.iob-lock {
    transition: transform 0.5s ease;
    transform-origin: 15px 60px;
}
.iob-lock-opened {
    transform: rotate(-30deg);
}
.iob-lock-closed {
    transform: rotate(0deg);
}
`
              }),
              this.state.rxData[`noLockAnimation${t}`] ? c ? r.jsx(H, {
                style: {
                  ...u.lockSvgIcon,
                  width: i,
                  height: i
                },
                sx: (l) => ({
                  color: l.palette.primary.main
                })
              }) : r.jsx(Q, {
                style: {
                  ...u.lockSvgIcon,
                  width: i,
                  height: i
                }
              }) : r.jsx(Ft, {
                className: c ? "iob-lock iob-lock-opened" : "iob-lock iob-lock-closed",
                opened: c,
                style: {
                  color: this.state.rxData[`lockColor${t}`],
                  height: i,
                  width: "auto"
                }
              })
            ]
          }, "lock") : null
        ]
      });
      if (!e) return h;
      const n = this.state.rxData[`title${t}`] || g.getText(a.common.name) || "";
      return n ? r.jsxs("div", {
        style: {
          ...u.buttonDiv,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          width: e || void 0,
          height: s || void 0,
          border: this.state.selectedOne ? "1px dashed gray" : "none",
          boxSizing: "border-box"
        },
        children: [
          h,
          r.jsx("div", {
            children: n
          })
        ]
      }, t) : h;
    }
    thermostatObjectIDs(t, e) {
      [
        "oid",
        "actual",
        "boost",
        "party"
      ].forEach((a) => {
        const i = `${a}${t}`;
        this.state.rxData[i] && this.state.rxData[i] !== "nothing_selected" && e.push(this.state.rxData[i]);
      });
    }
    thermostatReadObjects(t, e, s, a) {
      var _a, _b;
      let i = this.state.rxData[`oid${t}`];
      if (e[i]) {
        const o = e[i];
        s[t] = {
          widgetType: "thermostat",
          common: o.common,
          _id: i
        }, s[t].common.min = ((_a = o == null ? void 0 : o.common) == null ? void 0 : _a.min) === void 0 ? 12 : o.common.min, s[t].common.max = ((_b = o == null ? void 0 : o.common) == null ? void 0 : _b.max) === void 0 ? 30 : o.common.max;
      } else s[t] = {
        widgetType: "thermostat",
        common: {},
        _id: i
      };
      i = this.state.rxData[`actual${t}`], a[t] = {}, e[i] ? a[t].actual = {
        common: e[i].common,
        _id: i,
        type: "state",
        native: {}
      } : a[t] = null;
    }
    thermIsWithPowerButton(t) {
      return !!this.state.rxData[`switch${t}`] && this.state.rxData[`switch${t}`] !== "nothing_selected";
    }
    thermIsWithModeButtons(t) {
      return !!((this.state.rxData[`party${t}`] || this.state.rxData[`boost${t}`]) && (!this.state.rxData[`switch${t}`] || this.state.values[`${this.state.rxData[`switch${t}`]}.val`]));
    }
    thermostatRenderDialog(t) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      if (!this.state.objects[t] || typeof this.state.objects[t] == "string") return null;
      const e = this.state.objects[t];
      let s = null;
      e._id && (s = this.state.values[`${e._id}.val`], s === void 0 && (s = null), s !== null && e.common.min !== void 0 && s < e.common.min ? s = e.common.min : s !== null && e.common.max !== void 0 && s > e.common.max && (s = e.common.max), s === null && e.common.min !== void 0 && e.common.max !== void 0 && (s = (e.common.max - e.common.min) / 2 + e.common.min));
      const a = (_a = this.state.secondaryObjects[t]) == null ? void 0 : _a.actual;
      let i = null;
      a && (i = this.state.values[`${a._id}.val`], i === void 0 && (i = null));
      let o = window.innerWidth > window.innerHeight ? window.innerHeight : window.innerWidth;
      o > 200 && (o = 200);
      let c = Math.round(o / 25);
      c < 8 && (c = 8), i = i !== null ? this.formatValue(i, 1) : null;
      const d = ((_f = (_e = (_d = (_c = (_b = this.props.customSettings) == null ? void 0 : _b.viewStyle) == null ? void 0 : _c.overrides) == null ? void 0 : _d.palette) == null ? void 0 : _e.primary) == null ? void 0 : _f.main) || ((_g = this.props.context.theme) == null ? void 0 : _g.palette.primary.main) || "#448aff", h = [];
      if (this.thermIsWithModeButtons(t)) {
        if (this.state.rxData[`party${t}`]) {
          let n = this.state.values[`${this.state.rxData[`party${t}`]}.val`];
          n == null ? n = false : n = n === "1" || n === "true" || n === true, h.push(r.jsx(y, {
            color: n ? "primary" : "grey",
            onClick: () => {
              let l = this.state.values[`${this.state.rxData[`party${t}`]}.val`];
              l == null ? l = false : l = l === "1" || l === "true" || l === true;
              const p = JSON.parse(JSON.stringify(this.state.values));
              p[`${this.state.rxData[`party${t}`]}.val`] = !l, this.setState(p), this.props.context.setValue(this.state.rxData[`party${t}`], !l);
            },
            startIcon: r.jsx(wt, {}),
            children: g.t("Party")
          }, "party"));
        }
        if (this.state.rxData[`boost${t}`]) {
          let n = this.state.values[`${this.state.rxData[`boost${t}`]}.val`];
          n == null ? n = false : n = n === "1" || n === "true" || n === true, h.push(r.jsx(y, {
            color: n ? "primary" : "grey",
            onClick: () => {
              let l = this.state.values[`${this.state.rxData[`boost${t}`]}.val`];
              l == null ? l = false : l = l === "1" || l === "true" || l === true;
              const p = JSON.parse(JSON.stringify(this.state.values));
              p[`${this.state.rxData[`boost${t}`]}.val`] = !l, this.setState(p), this.props.context.setValue(this.state.rxData[`boost${t}`], !l);
            },
            startIcon: r.jsx(xt, {}),
            children: g.t("Boost")
          }, "boost"));
        }
      }
      return this.thermIsWithPowerButton(t) && h.push(r.jsx(x, {
        title: g.t("power").replace("vis_2_widgets_material_", ""),
        slotProps: {
          popper: {
            sx: u.tooltip
          }
        },
        children: r.jsx(_, {
          color: this.state.values[`${this.state.rxData[`switch${t}`]}.val`] ? "primary" : "grey",
          onClick: () => {
            const n = JSON.parse(JSON.stringify(this.state.values)), l = `${this.state.rxData[`switch${t}`]}.val`;
            n[l] = !n[l], this.setState(n), this.props.context.setValue(this.state.rxData[`switch${t}`], n[l]);
          },
          children: r.jsx($t, {})
        })
      }, "power")), r.jsxs(pt, {
        component: "div",
        sx: u.thermostatCircleDiv,
        style: {
          height: "100%"
        },
        children: [
          o && e ? r.jsxs(Et, {
            minValue: e.common.min,
            maxValue: e.common.max,
            size: o,
            arcColor: d,
            arcBackgroundColor: this.props.context.themeType === "dark" ? "#DDD" : "#222",
            startAngle: 40,
            handleSize: c,
            endAngle: 320,
            handle1: {
              value: s || 0,
              onChange: (n) => {
                const l = JSON.parse(JSON.stringify(this.state.values));
                this.state.rxData[`step${t}`] === "0.5" ? l[`${e._id}.val`] = Math.round(n * 2) / 2 : l[`${e._id}.val`] = Math.round(n), this.setState({
                  values: l
                });
              }
            },
            onControlFinished: () => this.props.context.setValue(e._id, this.state.values[`${e._id}.val`]),
            children: [
              s !== null ? r.jsx(x, {
                title: g.t("desired_temperature"),
                slotProps: {
                  popper: {
                    sx: u.tooltip
                  }
                },
                children: r.jsxs("div", {
                  style: {
                    ...u.thermostatDesiredTemp,
                    fontSize: Math.round(o / 6),
                    ...this.customStyle
                  },
                  children: [
                    r.jsx(W, {
                      style: {
                        width: o / 8,
                        height: o / 8
                      }
                    }),
                    r.jsxs("div", {
                      style: {
                        display: "flex",
                        alignItems: "top",
                        ...this.customStyle
                      },
                      children: [
                        this.formatValue(s),
                        r.jsx("span", {
                          style: {
                            fontSize: Math.round(o / 12),
                            fontWeight: "normal"
                          },
                          children: this.state.rxData[`unit${t}`] || ((_h = e.common) == null ? void 0 : _h.unit)
                        })
                      ]
                    })
                  ]
                })
              }) : null,
              i !== null ? r.jsx("style", {
                children: `
@keyframes vis-2-widgets-nils-newValueAnimationLight {
    0% {
        color: #00bd00;
    },
    80% {
        color: #008000;
    },
    100% {
        color: #000;
    }
}

@keyframes vis-2-widgets-nils-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: #ffffff;
    }
}                          
                            `
              }) : null,
              i !== null ? r.jsx(x, {
                title: g.t("actual_temperature"),
                slotProps: {
                  popper: {
                    sx: u.tooltip
                  }
                },
                children: r.jsxs("div", {
                  style: {
                    ...this.props.context.themeType === "dark" ? u.thermostatNewValueDark : u.thermostatNewValueLight,
                    fontSize: Math.round(o * 0.6 / 6),
                    opacity: 0.7,
                    ...this.customStyle
                  },
                  children: [
                    i,
                    this.state.rxData[`unit${t}`] || ((_i = a == null ? void 0 : a.common) == null ? void 0 : _i.unit)
                  ]
                }, `${i}valText`)
              }) : null
            ]
          }) : null,
          r.jsx("div", {
            style: {
              ...u.thermostatButtonsDiv,
              bottom: 8
            },
            children: h
          })
        ]
      });
    }
    rgbGetIdMin = (t, e) => {
      var _a, _b, _c, _d;
      return e === "color_temperature" ? parseInt(this.state.rxData[`ct_min${t}`], 10) || ((_b = (_a = this.state.secondaryObjects[t][e]) == null ? void 0 : _a.common) == null ? void 0 : _b.min) || 0 : ((_d = (_c = this.state.secondaryObjects[t][e]) == null ? void 0 : _c.common) == null ? void 0 : _d.min) || 0;
    };
    rgbGetIdMax = (t, e) => {
      var _a, _b, _c, _d;
      return e === "color_temperature" ? parseInt(this.state.rxData[`ct_max${t}`] || ((_b = (_a = this.state.secondaryObjects[t][e]) == null ? void 0 : _a.common) == null ? void 0 : _b.max), 10) || 0 : ((_d = (_c = this.state.secondaryObjects[t][e]) == null ? void 0 : _c.common) == null ? void 0 : _d.min) || 0;
    };
    rgbSetId = (t, e, s, a) => {
      var _a, _b;
      if (this.state.secondaryObjects[t][e]) {
        this.timeouts || (this.timeouts = {}), (_a = this.timeouts)[t] || (_a[t] = {});
        const i = this.state.rxData[e + t];
        if (this.timeouts[t][e] && clearTimeout(this.timeouts[t][e]), a) this.setState({
          controlValue: {
            id: i,
            value: s,
            changed: !!((_b = this.state.controlValue) == null ? void 0 : _b.changed)
          }
        }, () => {
          this.timeouts[t][e] = setTimeout(() => {
            this.timeouts[t][e] = null, this.props.context.setValue(i, s);
          }, parseInt(this.state.rxData[`timeout${t}`], 10) || 200);
        });
        else if (e === "switch" || e === "white_mode") {
          const o = {
            ...this.state.values,
            [`switch${t}.val`]: s
          };
          this.setState({
            values: o
          }, () => {
            this.props.context.setValue(this.state.rxData[`switch${t}`], s);
          });
        } else {
          const o = {
            ...this.state.values,
            [`${i}.val`]: s
          };
          this.setState({
            values: o
          }, () => {
            this.timeouts[t][e] = setTimeout(() => {
              this.timeouts[t][e] = null, this.props.context.setValue(i, s);
            }, parseInt(this.state.rxData[`timeout${t}`], 10) || 200);
          });
        }
      }
    };
    rgbObjectIDs(t, e) {
      X.forEach((s) => {
        const a = `${s}${t}`;
        this.state.rxData[a] && this.state.rxData[a] !== "nothing_selected" && e.push(this.state.rxData[a]);
      }), e.push(this.state.rxData[`oid${t}`]);
    }
    rgbReadObjects(t, e, s, a) {
      var _a, _b, _c, _d, _e;
      const i = {};
      if (X.forEach((o) => {
        const c = `${o}${t}`, d = this.state.rxData[c];
        if (d) {
          const h = e[d];
          h && (i[o] = h);
        }
      }), i.oid = e[this.state.rxData[`oid${t}`]], a[t] = i, i.color_temperature) {
        const o = [], c = parseInt(this.state.rxData[`ct_min${t}`] || ((_b = (_a = i.color_temperature) == null ? void 0 : _a.common) == null ? void 0 : _b.min) || "0", 10) || 2700, d = parseInt(this.state.rxData[`ct_max${t}`] || ((_d = (_c = i.color_temperature) == null ? void 0 : _c.common) == null ? void 0 : _d.max) || "0", 10) || 6e3, h = (d - c) / 20;
        for (let n = c; n <= d; n += h) o.push(Z(n));
        i.color_temperature.colors = o;
      }
      s[t] = {
        widgetType: "rgb",
        common: (_e = i.oid) == null ? void 0 : _e.common,
        _id: this.state.rxData[`oid${t}`]
      };
    }
    rgbDestroy() {
      if (this.timeouts) for (const t in this.timeouts) for (const e in this.timeouts[t]) this.timeouts[t][e] && (clearTimeout(this.timeouts[t][e]), this.timeouts[t][e] = null);
    }
    rgbIsOnlyHue = (t) => this.state.rxData[`rgbType${t}`] === "hue/sat/lum" && (!this.state.secondaryObjects[t].saturation || !this.state.secondaryObjects[t].luminance);
    rgbGetWheelColor = (t) => {
      let e = {
        h: 0,
        s: 0,
        v: 0,
        a: 1
      };
      if (this.state.rxData[`rgbType${t}`] === "hue/sat/lum") e = Ot({
        h: this.getPropertyValue(`hue${t}`),
        s: this.rgbIsOnlyHue(t) ? 100 : this.getPropertyValue(`saturation${t}`),
        l: this.rgbIsOnlyHue(t) ? 50 : this.getPropertyValue(`luminance${t}`),
        a: 1
      });
      else if (this.state.rxData[`rgbType${t}`] === "r/g/b" || this.state.rxData[`rgbType${t}`] === "r/g/b/w") e = Vt({
        r: this.getPropertyValue(`red${t}`),
        g: this.getPropertyValue(`green${t}`),
        b: this.getPropertyValue(`blue${t}`),
        a: 1
      });
      else if (this.state.rxData[`rgbType${t}`] === "rgb") try {
        const s = this.getPropertyValue(`oid${t}`) || "";
        s && s.length >= 4 ? e = P(s) : e = P("#000000");
      } catch (s) {
        console.error(s);
      }
      else if (this.state.rxData[`rgbType${t}`] === "rgbw") try {
        const s = this.getPropertyValue(`oid${t}`) || "";
        s && s.length >= 4 ? e = P(s) : e = P("#000000");
      } catch (s) {
        console.error(s);
      }
      return (this.state.rxData[`hideBrightness${t}`] === true || this.state.rxData[`hideBrightness${t}`] === "true") && (e.v = 100), e;
    };
    rgbSetWheelColor = (t, e) => {
      if (this.state.rxData[`rgbType${t}`] === "hue/sat/lum") {
        const s = Wt(e);
        this.rgbSetId(t, "hue", s.h), this.rgbIsOnlyHue(t) || (this.rgbSetId(t, "saturation", s.s), this.rgbSetId(t, "luminance", s.l));
      } else if (this.state.rxData[`rgbType${t}`] === "r/g/b" || this.state.rxData[`rgbType${t}`] === "r/g/b/w") {
        const s = Pt(e);
        this.rgbSetId(t, "red", s.r), this.rgbSetId(t, "green", s.g), this.rgbSetId(t, "blue", s.b);
      } else if (this.state.rxData[`rgbType${t}`] === "rgb") this.rgbSetId(t, "oid", R(e));
      else if (this.state.rxData[`rgbType${t}`] === "rgbw") if (this.state.secondaryObjects[t].white) this.rgbSetId(t, "oid", R(e));
      else {
        let s = this.getPropertyValue(`oid${t}`) || "#00000000";
        s = R(e) + s.substring(7), this.rgbSetId(t, "oid", s);
      }
    };
    rgbGetWhite = (t) => {
      var _a;
      if (this.state.rxData[`rgbType${t}`] === "r/g/b/w") return this.getPropertyValue(`white${t}`);
      if (this.state.rxData[`rgbType${t}`] === "rgbw") {
        if (this.state.secondaryObjects[t].white) return this.getPropertyValue(`white${t}`);
        const e = (_a = this.getPropertyValue(`oid${t}`)) == null ? void 0 : _a.substring(7);
        return parseInt(e, 16);
      }
      return 0;
    };
    rgbGetWhiteId = (t) => this.state.rxData[`rgbType${t}`] === "r/g/b/w" ? this.state.rxData[`white${t}`] : this.state.rxData[`rgbType${t}`] === "rgbw" ? this.state.secondaryObjects[t].white ? this.state.rxData[`white${t}`] : this.state.rxData[`oid${t}`] : "";
    rgbSetWhite = (t, e) => {
      if (this.state.rxData[`rgbType${t}`] === "r/g/b/w") this.rgbSetId(t, "white", e, true);
      else if (this.state.rxData[`rgbType${t}`] === "rgbw") if (this.state.secondaryObjects[t].white) this.rgbSetId(t, "white", e, true);
      else {
        let s = this.getPropertyValue(`oid${t}`) || "#00000000";
        s = s.substring(0, 7) + e.toString(16).padStart(2, "0"), this.rgbSetId(t, "oid", s, true);
      }
    };
    rgbSetWhiteMode = (t, e) => {
      this.state.rxData[`white_mode${t}`] || this.rgbSetId(t, "white_mode", !!e);
    };
    rgbGetWhiteMode = (t) => this.state.rxData[`white_mode${t}`] ? this.getPropertyValue(`white_mode${t}`) : null;
    rgbIsRgb = (t) => (this.state.rxData[`rgbType${t}`] === "rgb" || this.state.rxData[`rgbType${t}`] === "rgbw") && this.state.rxData[`oid${t}`] ? true : (this.state.rxData[`rgbType${t}`] === "r/g/b" || this.state.rxData[`rgbType${t}`] === "r/g/b/w") && !!this.state.secondaryObjects[t].red && !!this.state.secondaryObjects[t].green && !!this.state.secondaryObjects[t].blue;
    rgbIsWhite = (t) => this.state.rxData[`rgbType${t}`] === "rgbw" && !!this.state.rxData[`oid${t}`] || this.state.rxData[`rgbType${t}`] === "r/g/b/w" && !!this.state.secondaryObjects[t].white;
    rgbIsHSL = (t) => this.state.rxData[`rgbType${t}`] === "hue/sat/lum" && !!this.state.secondaryObjects[t].hue;
    rgbRenderSwitch(t) {
      return this.state.secondaryObjects[t].switch && r.jsxs("div", {
        style: {
          ...u.rgbSliderContainer,
          justifyContent: "center"
        },
        children: [
          g.t("Off"),
          r.jsx(M, {
            checked: this.getPropertyValue(`switch${t}`) || false,
            onChange: (e) => this.rgbSetId(t, "switch", e.target.checked)
          }),
          g.t("On")
        ]
      });
    }
    rgbRenderBrightness(t) {
      var _a;
      return this.state.secondaryObjects[t].brightness && r.jsxs("div", {
        style: u.rgbSliderContainer,
        children: [
          r.jsx(x, {
            title: g.t("Brightness"),
            slotProps: {
              popper: {
                sx: u.tooltip
              }
            },
            children: r.jsx(jt, {})
          }),
          r.jsx(I, {
            min: this.rgbGetIdMin(t, "brightness") || 0,
            max: this.rgbGetIdMax(t, "brightness") || 100,
            valueLabelDisplay: "auto",
            value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === this.state.rxData[`brightness${t}`] ? this.state.controlValue.value : this.getPropertyValue(`brightness${t}`) || 0,
            onChange: (e, s) => this.rgbSetId(t, "brightness", s, true),
            onChangeCommitted: () => this.finishChanging()
          })
        ]
      });
    }
    rgbRenderSketch(t) {
      return r.jsx("div", {
        className: "dark",
        style: u.rgbWheel,
        children: r.jsx(Rt, {
          color: this.rgbGetWheelColor(t),
          disableAlpha: true,
          onChange: (e) => this.rgbSetWheelColor(t, e.hsva)
        })
      });
    }
    rgbRenderWheelTypeSwitch(t, e, s, a) {
      return !e || a === null && this.state.rxData[`noRgbPalette${t}`] ? null : !this.rgbIsOnlyHue(t) && r.jsxs("div", {
        style: {
          textAlign: s ? "right" : void 0
        },
        children: [
          a !== null ? r.jsx(x, {
            title: g.t("Switch white mode"),
            slotProps: {
              popper: {
                sx: u.tooltip
              }
            },
            children: r.jsx(_, {
              onClick: () => this.rgbSetWhiteMode(t, !a),
              color: a ? "primary" : "default",
              children: r.jsx(Dt, {})
            })
          }) : null,
          !this.state.rxData[`noRgbPalette${t}`] && a !== true ? r.jsx(x, {
            title: g.t("Switch color picker"),
            slotProps: {
              popper: {
                sx: u.tooltip
              }
            },
            children: r.jsx(_, {
              onClick: () => {
                const i = JSON.parse(JSON.stringify(this.state.sketch));
                i[t] = !i[t], this.setState({
                  sketch: i
                });
              },
              children: r.jsx(G, {})
            })
          }) : null
        ]
      });
    }
    rgbRenderBrightnessSlider(t, e, s) {
      return !e || this.state.sketch[t] || s || this.state.rxData[`hideBrightness${t}`] === true || this.state.rxData[`hideBrightness${t}`] === "true" ? null : !this.rgbIsOnlyHue(t) && r.jsx(Nt, {
        hsva: this.rgbGetWheelColor(t),
        onChange: (a) => this.rgbSetWheelColor(t, {
          ...this.rgbGetWheelColor(t),
          ...a
        })
      });
    }
    rgbRenderWheel(t, e, s) {
      return !e || s === true ? null : this.state.sketch[t] ? this.rgbRenderSketch(t) : r.jsx("div", {
        style: u.rgbWheel,
        children: r.jsx(At, {
          color: this.rgbGetWheelColor(t),
          onChange: (a) => {
            a = JSON.parse(JSON.stringify(a)), this.rgbSetWheelColor(t, a.hsva);
          }
        })
      });
    }
    rgbRenderWhite(t) {
      var _a;
      if (!this.rgbIsWhite(t)) return null;
      let e, s;
      this.state.secondaryObjects[t].white ? (e = this.rgbGetIdMin(t, "white") || 0, s = this.rgbGetIdMax(t, "white") || 100) : (e = 0, s = 255);
      const a = this.rgbGetWhiteId(t);
      return r.jsxs("div", {
        style: u.rgbSliderContainer,
        children: [
          r.jsx(Bt, {
            style: {
              width: 24,
              height: 24
            }
          }),
          r.jsx(I, {
            min: e,
            max: s,
            valueLabelDisplay: "auto",
            value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === a ? this.state.controlValue.value : this.rgbGetWhite(t) || 0,
            onChange: (i, o) => this.rgbSetWhite(t, o),
            onChangeCommitted: () => this.finishChanging()
          })
        ]
      });
    }
    rgbRenderColorTemperature(t, e) {
      var _a;
      if (this.state.rxData[`rgbType${t}`] !== "ct" || e) return null;
      const s = this.state.rxData[`color_temperature${t}`];
      return r.jsxs("div", {
        style: u.rgbSliderContainer,
        children: [
          r.jsx(x, {
            title: g.t("Color temperature"),
            slotProps: {
              popper: {
                sx: u.tooltip
              }
            },
            children: r.jsx(W, {})
          }),
          r.jsx("div", {
            style: {
              ...u.rgbSliderContainer,
              background: `linear-gradient(to right, ${this.state.secondaryObjects[t].color_temperature.colors.map((a) => `rgb(${a.red}, ${a.green}, ${a.blue})`).join(", ")})`,
              flex: "1",
              borderRadius: 4
            },
            children: r.jsx(I, {
              valueLabelDisplay: "auto",
              min: this.rgbGetIdMin(t, "color_temperature") || 2700,
              max: this.rgbGetIdMax(t, "color_temperature") || 6e3,
              value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === s ? this.state.controlValue.value : this.state.values[`${s}.val`] || 0,
              onChange: (a, i) => this.rgbSetId(t, "color_temperature", i, true),
              onChangeCommitted: () => this.finishChanging()
            })
          })
        ]
      });
    }
    rgbRenderDialog(t) {
      const e = this.rgbIsRgb(t) || this.rgbIsHSL(t), s = !!this.rgbGetWhiteMode(t);
      return r.jsxs("div", {
        style: u.rgbDialogContainer,
        children: [
          this.rgbRenderSwitch(t),
          this.rgbRenderBrightness(t),
          this.rgbRenderWhite(t),
          this.rgbRenderWheelTypeSwitch(t, e, false, s),
          this.rgbRenderWheel(t, e, s),
          this.rgbRenderBrightnessSlider(t, e, s),
          this.rgbRenderColorTemperature(t, s)
        ]
      });
    }
    rgbGetColor = (t) => {
      if (this.state.rxData[`rgbType${t}`] === "ct") {
        const e = Z(this.getPropertyValue(`color_temperature${t}`));
        return Mt({
          r: e.red,
          g: e.green,
          b: e.blue
        });
      }
      return R(this.rgbGetWheelColor(t));
    };
    vacuumObjectIDs(t, e) {
      const s = Object.keys(T);
      for (let a = 0; a < s.length; a++) {
        const i = this.state.rxData[`vacuum-${s[a]}-oid${t}`];
        i && e.push(i);
      }
    }
    async vacuumReadObjects(t, e, s, a) {
      a[t] = {}, s[t] = {
        widgetType: "vacuum",
        common: {
          name: g.t("vacuum")
        },
        _id: ""
      };
      const i = Object.keys(T);
      Object.values(e).forEach((o) => {
        const c = i.find((d) => this.state.rxData[`vacuum-${d}-oid${t}`] === o._id);
        c && (a[t][c] = o);
      }), a[t].rooms = await this.vacuumLoadRooms(t);
    }
    async vacuumLoadRooms(t) {
      if (this.state.rxData[`vacuum-use-rooms${t}`] && this.state.rxData[`vacuum-status-oid${t}`]) {
        const e = this.state.rxData[`vacuum-status-oid${t}`].split(".");
        if (e.length === 4) {
          e.pop(), e.pop(), e.push("rooms");
          const s = await this.props.context.socket.getObjectViewSystem("channel", `${e.join(".")}.room`, `${e.join(".")}.room\u9999`), a = [];
          return Object.keys(s).forEach((i) => {
            var _a;
            return a.push({
              value: `${i}.roomClean`,
              label: g.getText(((_a = s[i].common) == null ? void 0 : _a.name) || i.split(".").pop() || "")
            });
          }), a.sort((i, o) => i.label.localeCompare(o.label)), a;
        }
      }
      return null;
    }
    vacuumGetValue(t, e, s) {
      var _a;
      const a = this.vacuumGetObj(t, e);
      if (!a) return null;
      const i = this.state.values[`${a._id}.val`];
      return !s && ((_a = a.common) == null ? void 0 : _a.states) && a.common.states !== void 0 && a.common.states[i] !== null ? a.common.states[i] : i;
    }
    vacuumGetObj(t, e) {
      if (this.state.secondaryObjects[t]) return this.state.secondaryObjects[t][e];
    }
    vacuumRenderBattery(t) {
      var _a;
      return this.vacuumGetObj(t, "battery") ? r.jsxs("div", {
        style: u.vacuumBattery,
        children: [
          this.vacuumGetObj(t, "is-charging") && this.vacuumGetValue(t, "is-charging") ? r.jsx(_t, {}) : r.jsx(St, {}),
          this.vacuumGetValue(t, "battery") || 0,
          " ",
          (_a = this.vacuumGetObj(t, "battery").common) == null ? void 0 : _a.unit
        ]
      }) : null;
    }
    vacuumRenderSpeed(t) {
      const e = this.vacuumGetObj(t, "fan-speed");
      if (!e) return null;
      let s = {};
      if (Array.isArray(e.common.states)) {
        const i = {};
        e.common.states.forEach((o) => i[o] = o), s = i;
      } else s = e.common.states || {};
      let a = this.vacuumGetValue(t, "fan-speed", true);
      return a == null && (a = ""), a = a.toString(), [
        r.jsx(y, {
          style: u.vacuumSpeedContainer,
          endIcon: r.jsx(zt, {}),
          onClick: (i) => {
            i.stopPropagation(), this.setState({
              showSpeedMenu: i.currentTarget
            });
          },
          children: s[a] !== void 0 && s[a] !== null ? g.t(s[a]).replace("vis_2_widgets_material_", "") : a
        }, "speed"),
        this.state.showSpeedMenu ? r.jsx(q, {
          open: true,
          anchorEl: this.state.showSpeedMenu,
          onClose: () => this.setState({
            showSpeedMenu: null
          }),
          children: Object.keys(s).map((i) => r.jsx(E, {
            selected: a === i,
            onClick: () => {
              const o = i;
              this.setState({
                showSpeedMenu: null
              }, () => this.props.context.setValue(this.state.rxData[`vacuum-fan-speed-oid${t}`], o));
            },
            children: g.t(s[i]).replace("vis_2_widgets_material_", "")
          }, i))
        }, "speedMenu") : null
      ];
    }
    vacuumRenderRooms(t) {
      var _a;
      const e = (_a = this.state.secondaryObjects[t]) == null ? void 0 : _a.rooms;
      return (e == null ? void 0 : e.length) ? [
        r.jsx(y, {
          variant: "outlined",
          color: "grey",
          onClick: (s) => this.setState({
            showRoomsMenu: s.currentTarget
          }),
          children: g.t("Room")
        }, "rooms"),
        this.state.showRoomsMenu ? r.jsx(q, {
          onClose: () => this.setState({
            showRoomsMenu: null
          }),
          open: true,
          anchorEl: this.state.showRoomsMenu,
          children: e.map((s) => r.jsx(E, {
            value: s.value,
            onClick: () => {
              const a = s.value;
              this.setState({
                showRoomsMenu: null
              }, () => this.props.context.setValue(a, true));
            },
            children: s.label
          }, s.value))
        }, "roomsMenu") : null
      ] : null;
    }
    vacuumRenderSensors(t) {
      const e = [
        "filter-left",
        "side-brush-left",
        "main-brush-left",
        "sensors-left",
        "cleaning-count"
      ].filter((s) => this.vacuumGetObj(t, s));
      return e.length ? r.jsx("div", {
        style: u.vacuumSensorsContainer,
        children: r.jsx("div", {
          style: u.vacuumSensors,
          children: e.map((s) => {
            const a = this.vacuumGetObj(t, s);
            return r.jsx(gt, {
              style: u.vacuumSensorCard,
              children: r.jsxs(ft, {
                style: {
                  ...u.vacuumSensorCardContent,
                  paddingBottom: 2
                },
                children: [
                  r.jsxs("div", {
                    children: [
                      r.jsx("span", {
                        style: u.vacuumSensorBigText,
                        children: this.vacuumGetValue(t, s) || 0
                      }),
                      " ",
                      r.jsx("span", {
                        style: u.vacuumSensorSmallText,
                        children: a.common.unit
                      })
                    ]
                  }),
                  r.jsx("div", {
                    children: r.jsx("span", {
                      style: u.vacuumSensorSmallText,
                      children: g.t(s.replaceAll("-", "_"))
                    })
                  })
                ]
              })
            }, s);
          })
        })
      }) : null;
    }
    vacuumRenderButtons(t, e) {
      let s;
      const a = this.vacuumGetObj(t, "status");
      let i, o;
      return a && (i = this.vacuumGetValue(t, "status"), s = tt(i), typeof i == "boolean" ? (o = i ? "cleaning" : "pause", i = i ? "Cleaning" : "Pause") : (i == null && (i = ""), i = i.toString(), o = i.toLowerCase())), r.jsxs("div", {
        style: {
          ...u.vacuumButtons,
          cursor: e ? "pointer" : void 0
        },
        onClick: e ? (c) => {
          c.stopPropagation(), c.preventDefault(), this.setState({
            showControlDialog: t
          });
        } : void 0,
        children: [
          this.vacuumGetObj(t, "start") && (!o || !Ut.includes(o)) && r.jsx(x, {
            title: g.t("Start"),
            slotProps: {
              popper: {
                sx: u.tooltip
              }
            },
            children: r.jsx(_, {
              onClick: e ? void 0 : () => this.props.context.setValue(this.state.rxData[`vacuum-start-oid${t}`], true),
              children: r.jsx(Ct, {})
            })
          }),
          this.vacuumGetObj(t, "pause") && (!o || !Kt.includes(o)) && (!o || !et.includes(o)) && r.jsx(x, {
            title: g.t("Pause"),
            slotProps: {
              popper: {
                sx: u.tooltip
              }
            },
            children: r.jsx(_, {
              onClick: e ? void 0 : () => this.props.context.setValue(this.state.rxData[`vacuum-pause-oid${t}`], true),
              children: r.jsx(It, {})
            })
          }),
          this.vacuumGetObj(t, "home") && (!o || !et.includes(o)) && r.jsx(x, {
            title: g.t("Home"),
            slotProps: {
              popper: {
                sx: u.tooltip
              }
            },
            children: r.jsx(_, {
              onClick: e ? void 0 : () => this.props.context.setValue(this.state.rxData[`vacuum-home-oid${t}`], true),
              children: r.jsx(kt, {})
            })
          }),
          a && r.jsx(x, {
            title: g.t("Status"),
            slotProps: {
              popper: {
                sx: u.tooltip
              }
            },
            children: r.jsx("div", {
              style: {
                color: s
              },
              children: g.t((i || "").toString()).replace("vis_2_widgets_material_", "")
            })
          })
        ]
      });
    }
    vacuumRenderMap(t) {
      const e = this.vacuumGetObj(t, "map64");
      return e ? r.jsx("img", {
        src: this.state.values[`${e._id}.val`],
        alt: "vacuum",
        style: u.vacuumImage
      }) : this.state.rxData[`vacuum-use-default-picture${t}`] ? r.jsx(st, {
        style: u.vacuumImage
      }) : this.state.rxData[`vacuum-own-image${t}`] ? r.jsx(S, {
        src: this.state.rxData[`vacuum-own-image${t}`],
        style: u.vacuumImage
      }) : null;
    }
    vacuumRenderDialog(t) {
      const e = this.vacuumRenderRooms(t), s = this.vacuumRenderBattery(t);
      let a = 0;
      e ? a += 36 : s && (a += 24);
      const i = this.vacuumRenderSensors(t);
      i && (a += 46);
      const o = this.vacuumRenderButtons(t), c = this.vacuumRenderSpeed(t);
      (o || e) && (a += 40);
      const d = this.vacuumRenderMap(t);
      return r.jsxs("div", {
        style: u.vacuumContent,
        children: [
          s || e ? r.jsxs("div", {
            style: u.vacuumTopPanel,
            children: [
              e,
              s
            ]
          }) : null,
          d ? r.jsx("div", {
            style: {
              ...u.vacuumMapContainer,
              height: `calc(100% - ${a}px)`,
              width: "100%"
            },
            children: d
          }) : null,
          i,
          o || c ? r.jsxs("div", {
            style: u.vacuumBottomPanel,
            children: [
              o,
              c
            ]
          }) : null
        ]
      });
    }
    checkLineVisibility(t) {
      const e = this.state.rxData[`visibility-oid${t}`];
      if (!e) return true;
      const s = this.state.rxData[`visibility-cond${t}`] || "==";
      let a = this.state.values[`${e}.val`];
      if (a == null) return s === "not exist";
      let i = this.state.rxData[`visibility-val${t}`];
      const o = this.state.rxData[`visibility-no-hide${t}`] === true || this.state.rxData[`visibility-no-hide${t}`] === "true" ? "disabled" : false;
      if (i == null) return s === "not exist";
      if (a === "null" && s !== "exist" && s !== "not exist") return false;
      const c = typeof a;
      switch (c === "boolean" || a === "false" || a === "true" ? i = i === "true" || i === true || i === 1 || i === "1" : c === "number" ? i = parseFloat(i) : c === "object" && (a = JSON.stringify(a)), s) {
        case "==":
          return i = i.toString(), a = a.toString(), a === "1" && (a = "true"), i === "1" && (i = "true"), a === "0" && (a = "false"), i === "0" && (i = "false"), i !== a ? true : o;
        case "!=":
          return i = i.toString(), a = a.toString(), a === "1" && (a = "true"), i === "1" && (i = "true"), a === "0" && (a = "false"), i === "0" && (i = "false"), i === a ? true : o;
        case ">=":
          return a < i ? true : o;
        case "<=":
          return a > i ? true : o;
        case ">":
          return a <= i ? true : o;
        case "<":
          return a >= i ? true : o;
        case "consist":
          return i = i.toString(), a = a.toString(), a.toString().includes(i) ? o : true;
        case "not consist":
          return i = i.toString(), a = a.toString(), a.toString().includes(i) ? true : o;
        case "exist":
          return a === "null";
        case "not exist":
          return a !== "null" ? true : o;
        default:
          return console.log(`[${this.props.id} / Line ${t}] Unknown visibility condition: ${s}`), false;
      }
    }
    renderWidgetBody(t) {
      super.renderWidgetBody(t), this.customStyle = {}, this.state.rxStyle && (this.state.rxStyle["font-weight"] && (this.customStyle.fontWeight = this.state.rxStyle["font-weight"]), this.state.rxStyle["font-size"] && (this.customStyle.fontSize = this.state.rxStyle["font-size"]), this.state.rxStyle["font-family"] && (this.customStyle.fontFamily = this.state.rxStyle["font-family"]), this.state.rxStyle["font-style"] && (this.customStyle.fontStyle = this.state.rxStyle["font-style"]), this.state.rxStyle["word-spacing"] && (this.customStyle.wordSpacing = this.state.rxStyle["word-spacing"]), this.state.rxStyle["letter-spacing"] && (this.customStyle.letterSpacing = this.state.rxStyle["letter-spacing"]));
      const e = JSON.stringify(this.state.rxData);
      this.lastRxData !== e && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
        this.updateTimeout = null, await this.propertiesUpdate();
      }, 50)));
      let s = null, a;
      const i = [];
      for (let n = 0; n < this.state.objects.length; n++) this.state.objects[n] && this.state.rxData[`hide${n}`] !== true && this.state.rxData[`hide${n}`] !== "true" && i.push(n);
      this.state.rxData.type === "lines" && i.filter((n) => typeof this.state.objects[n] != "string").find((n) => this.state.objects[n].widgetType === "switch") && (s = i.filter((n) => this.state.objects[n].widgetType === "switch").every((n) => this.isOn(n)), a = !!i.filter((n) => this.state.objects[n].widgetType === "switch").find((n) => this.isOn(n) !== s));
      const o = i.map((n) => this.getStateIcon(n)), c = !!o.find((n) => n), d = r.jsxs(r.Fragment, {
        children: [
          this.lockRenderUnlockDialog(),
          this.lockRenderConfirmDialog(),
          this.renderControlDialog(),
          this.renderBlindsDialog(),
          this.state.rxData.type === "lines" ? i.map((n, l) => {
            var _a;
            const p = this.checkLineVisibility(n);
            if (!this.props.editMode && !p) return null;
            const m = {};
            return this.state.rxData[`widget${n}`] && this.state.rxData[`height${n}`] && (m.height = this.state.rxData[`widget${n}`]), (!p || p === "disabled") && (m.opacity = 0.3), r.jsxs("div", {
              style: {
                ...u.cardsHolder,
                ...m,
                ...p === "disabled" ? {
                  pointerEvents: "none"
                } : void 0
              },
              children: [
                r.jsxs("span", {
                  style: {
                    display: "inline-flex",
                    alignItems: "center"
                  },
                  children: [
                    c ? r.jsx("span", {
                      style: u.iconSwitch,
                      children: o[l]
                    }) : null,
                    this.state.objects[n].widgetType !== "input" && this.state.objects[n].widgetType !== "select" ? r.jsx("span", {
                      style: {
                        color: this.getColor(n),
                        paddingLeft: 16
                      },
                      children: this.state.rxData[`title${n}`] || g.getText((_a = this.state.objects[n].common) == null ? void 0 : _a.name) || ""
                    }) : null
                  ]
                }),
                this.renderLine(n),
                p === "disabled" ? r.jsx("div", {
                  style: u.disabledOverlay
                }) : null
              ]
            }, n);
          }) : r.jsx("div", {
            style: {
              ...u.buttonsContainer,
              flexWrap: this.state.rxData.orientation && this.state.rxData.orientation !== "h" ? "wrap" : "nowrap"
            },
            children: i.map((n, l) => this.renderButton(n, c ? o[l] : void 0))
          })
        ]
      });
      let h = (this.state.rxData.allSwitch === true || this.state.rxData.allSwitch === "true") && i.length > 1 && s !== null ? r.jsx(M, {
        checked: s,
        style: a ? u.intermediate : void 0,
        onChange: () => {
          const n = JSON.parse(JSON.stringify(this.state.values));
          for (let l = 0; l <= i.length; l++) {
            const p = this.state.objects[i[l]];
            if (p && typeof p == "object" && p._id && p.widgetType === "switch") {
              const m = `${p._id}.val`;
              p.common.type === "boolean" ? (n[m] = !s, this.props.context.setValue(p._id, n[m])) : p.common.type === "number" ? (n[m] = s ? p.common.min : p.common.max, this.props.context.setValue(p._id, n[m])) : (n[m] = !s, this.props.context.setValue(p._id, n[m] ? "true" : "false"));
            }
          }
          this.setState({
            values: n
          });
        }
      }) : null;
      return this.state.rxData.noCard === true || this.state.rxData.noCard === "true" || t.widget.usedInWidget ? d : (!this.state.rxData.widgetTitle && h && (h = r.jsx("div", {
        style: {
          textAlign: "right",
          width: "100%"
        },
        children: h
      })), this.wrapContent(d, h));
    }
  };
});
export {
  __tla,
  it as default
};
