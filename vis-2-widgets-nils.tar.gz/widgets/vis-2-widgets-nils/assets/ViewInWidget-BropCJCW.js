import { j as a, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { a as u, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { G as p } from "./Generic-CC2u2WPj.js";
import { __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
let l;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  const w = {
    overlay: {
      zIndex: 999,
      top: 0,
      bottom: 0,
      position: "absolute",
      left: 0,
      right: 0
    }
  };
  l = class extends p {
    refContainer = u.createRef();
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        width: 0
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2ViewInWidget",
        visSet: "vis-2-widgets-nils",
        visWidgetLabel: "view_in_widget",
        visName: "View in Widget",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "view",
                label: "view",
                type: "select-views",
                multiple: false
              },
              {
                name: "button",
                label: "view_button",
                type: "checkbox"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_view.png"
      };
    }
    getWidgetInfo() {
      return l.getWidgetInfo();
    }
    componentDidMount() {
      super.componentDidMount(), this.recalculateWidth();
    }
    recalculateWidth() {
      this.refContainer.current && this.refContainer.current.clientWidth !== this.state.width && this.setState({
        width: this.refContainer.current.clientWidth
      });
    }
    componentWillUnmount() {
      super.componentWillUnmount();
    }
    componentDidUpdate(t, i) {
      super.componentDidUpdate(t, i), this.recalculateWidth();
    }
    onNavigate() {
      window.vis.changeView(this.state.rxData.view, this.state.rxData.view);
    }
    renderWidgetBody(t) {
      super.renderWidgetBody(t);
      const i = this.state.rxData.view;
      if (i === this.props.view) return a.jsx("div", {
        className: "vis-widget-body",
        style: {
          overflow: "hidden",
          position: "absolute"
        },
        children: "Cannot use recursive views"
      });
      let r;
      if (this.state.width && this.state.rxData.button && this.props.refParent.current && this.refContainer.current) {
        const d = this.refContainer.current.offsetWidth, c = this.refContainer.current.offsetHeight;
        let s = this.props.refParent.current, h = 0;
        for (; s.className.includes("vis-view") && h < 5; ) s = s.parentNode, h += 1;
        if (s) {
          const f = s.offsetWidth, n = d / f;
          r = {
            transform: `scale(${n})`,
            transformOrigin: "top left",
            width: `${1 / n * 100}%`,
            height: `${1 / n * 100 * (c / d)}%`,
            cursor: "pointer"
          };
        }
      }
      const e = this.state.rxData.noCard || t.widget.usedInWidget, o = a.jsxs("div", {
        style: {
          overflow: "hidden",
          position: "absolute",
          top: !e && this.state.rxData.widgetTitle ? 53 : e ? 0 : 16,
          left: e ? 0 : 8,
          width: e ? "100%" : "calc(100% - 16px)",
          height: !e && this.state.rxData.widgetTitle ? "calc(100% - 68px)" : e ? "100%" : "calc(100% - 32px)",
          textAlign: "center",
          lineHeight: this.state.height ? `${this.state.height}px` : void 0,
          fontFamily: this.state.rxStyle["font-family"],
          textShadow: this.state.rxStyle["text-shadow"],
          fontStyle: this.state.rxStyle["font-style"],
          fontWeight: this.state.rxStyle["font-weight"],
          fontVariant: this.state.rxStyle["font-variant"]
        },
        ref: this.refContainer,
        children: [
          this.state.editMode || this.state.rxData.button ? a.jsx("div", {
            style: {
              ...w.overlay,
              cursor: this.state.editMode ? void 0 : "pointer"
            },
            onClick: !this.state.editMode && this.state.rxData.button ? () => this.onNavigate() : void 0
          }) : null,
          i ? this.getWidgetView(i, {
            style: r
          }) : null
        ]
      });
      return this.state.rxData.noCard || t.widget.usedInWidget ? o : this.wrapContent(o, null);
    }
  };
});
export {
  __tla,
  l as default
};
