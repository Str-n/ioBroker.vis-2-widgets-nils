const r = ["history", "sql", "influxdb"];
class l extends window.visRxWidget {
  getPropertyValue = (t) => this.state.values[`${this.state.rxData[t]}.val`];
  static getI18nPrefix() {
    return "vis_2_widgets_material_";
  }
  static getHistoryInstance(t, s) {
    var _a;
    if ((_a = t == null ? void 0 : t.common) == null ? void 0 : _a.custom) {
      if (t.common.custom[s]) return s;
      for (const n in t.common.custom) if (r.includes(n.split(".")[0])) return n;
    }
    return null;
  }
  async getParentObject(t) {
    const s = t.split(".");
    s.pop();
    const n = s.join(".");
    return await this.props.context.socket.getObject(n);
  }
  static getObjectIcon(t, s, n) {
    n || (n = "../..");
    let c = "";
    const i = t == null ? void 0 : t.common;
    if (i) {
      const e = i.icon;
      if (e) if (e.startsWith("data:image/")) c = e;
      else if (e.includes(".")) {
        let a;
        t.type === "instance" || t.type === "adapter" ? c = `${n}/adapter/${i.name}/${e}` : s && s.startsWith("system.adapter.") ? (a = s.split(".", 3), e[0] === "/" ? a[2] += e : a[2] += `/${e}`, c = `${n}/adapter/${a[2]}`) : (a = s.split(".", 2), e[0] === "/" ? a[0] += e : a[0] += `/${e}`, c = `${n}/adapter/${a[0]}`);
      } else return null;
    }
    return c || null;
  }
}
export {
  l as G
};
