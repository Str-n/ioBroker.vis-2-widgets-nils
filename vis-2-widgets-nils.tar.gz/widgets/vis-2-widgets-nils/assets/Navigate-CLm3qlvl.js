import { j as S, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { _ as Me, D as Et, E as Z, p as Mr, c as Oa, a as Ta, b as Na, d as Ma, F as La, o as Fa, G as Ga, H as $a, I as ka, s as Wa, m as Ua, J as Ha, K as ja, u as Va, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { _ as sr, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CA-kW2vj.js";
import { G as se } from "./Generic-CC2u2WPj.js";
import { P as qa, __tla as __tla_3 } from "./PinCodeDialog-1pjxuXxA.js";
import { a as N, n as fn, f as ie, m as ae, g as Qr, o as za, e as O, k as _r, _ as Ya, __tla as __tla_4 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { _ as gn } from "./inheritsLoose-CWawPfk8.js";
import { _ as C } from "./extends-CF3RwP-h.js";
import { t as Ja } from "./toPropertyKey-DCwh5dYN.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsWidgets__loadShare__prop_mf_2_types__loadShare__.js-Btvp0r21.js";
import { h as Pt } from "./hoist-non-react-statics.cjs-DPP7vwYz.js";
import { b as Ka, R as Xa, __tla as __tla_6 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react_mf_2_dom__loadShare__.js-DYAq8PKT.js";
import { _ as cr } from "./objectWithoutPropertiesLoose-Dsqj8S3w.js";
import { Y as Za, Z as Qa, r as _a, a as ei, __tla as __tla_7 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CRxa-Ic2.js";
import { __tla as __tla_8 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
let Ba;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })()
]).then(async () => {
  function ri(e, r, t) {
    return (r = Ja(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: true,
      configurable: true,
      writable: true
    }) : e[r] = t, e;
  }
  function At(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var n = Object.getOwnPropertySymbols(e);
      r && (n = n.filter(function(a) {
        return Object.getOwnPropertyDescriptor(e, a).enumerable;
      })), t.push.apply(t, n);
    }
    return t;
  }
  function Bt(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = arguments[r] != null ? arguments[r] : {};
      r % 2 ? At(Object(t), true).forEach(function(n) {
        ri(e, n, t[n]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : At(Object(t)).forEach(function(n) {
        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
      });
    }
    return e;
  }
  function H(e) {
    return "Minified Redux error #" + e + "; visit https://redux.js.org/Errors?code=" + e + " for the full message or use the non-minified dev environment for full errors. ";
  }
  var Rt = (function() {
    return typeof Symbol == "function" && Symbol.observable || "@@observable";
  })(), Ot = function() {
    return Math.random().toString(36).substring(7).split("").join(".");
  }, Tt = {
    INIT: "@@redux/INIT" + Ot(),
    REPLACE: "@@redux/REPLACE" + Ot()
  };
  function ti(e) {
    if (typeof e != "object" || e === null) return false;
    for (var r = e; Object.getPrototypeOf(r) !== null; ) r = Object.getPrototypeOf(r);
    return Object.getPrototypeOf(e) === r;
  }
  function mn(e, r, t) {
    var n;
    if (typeof r == "function" && typeof t == "function" || typeof t == "function" && typeof arguments[3] == "function") throw new Error(H(0));
    if (typeof r == "function" && typeof t > "u" && (t = r, r = void 0), typeof t < "u") {
      if (typeof t != "function") throw new Error(H(1));
      return t(mn)(e, r);
    }
    if (typeof e != "function") throw new Error(H(2));
    var a = e, i = r, o = [], l = o, s = false;
    function d() {
      l === o && (l = o.slice());
    }
    function p() {
      if (s) throw new Error(H(3));
      return i;
    }
    function u(g) {
      if (typeof g != "function") throw new Error(H(4));
      if (s) throw new Error(H(5));
      var m = true;
      return d(), l.push(g), function() {
        if (m) {
          if (s) throw new Error(H(6));
          m = false, d();
          var h = l.indexOf(g);
          l.splice(h, 1), o = null;
        }
      };
    }
    function c(g) {
      if (!ti(g)) throw new Error(H(7));
      if (typeof g.type > "u") throw new Error(H(8));
      if (s) throw new Error(H(9));
      try {
        s = true, i = a(i, g);
      } finally {
        s = false;
      }
      for (var m = o = l, b = 0; b < m.length; b++) {
        var h = m[b];
        h();
      }
      return g;
    }
    function v(g) {
      if (typeof g != "function") throw new Error(H(10));
      a = g, c({
        type: Tt.REPLACE
      });
    }
    function f() {
      var g, m = u;
      return g = {
        subscribe: function(h) {
          if (typeof h != "object" || h === null) throw new Error(H(11));
          function x() {
            h.next && h.next(p());
          }
          x();
          var D = m(x);
          return {
            unsubscribe: D
          };
        }
      }, g[Rt] = function() {
        return this;
      }, g;
    }
    return c({
      type: Tt.INIT
    }), n = {
      dispatch: c,
      subscribe: u,
      getState: p,
      replaceReducer: v
    }, n[Rt] = f, n;
  }
  function Nt(e, r) {
    return function() {
      return r(e.apply(this, arguments));
    };
  }
  function Mt(e, r) {
    if (typeof e == "function") return Nt(e, r);
    if (typeof e != "object" || e === null) throw new Error(H(16));
    var t = {};
    for (var n in e) {
      var a = e[n];
      typeof a == "function" && (t[n] = Nt(a, r));
    }
    return t;
  }
  function bn() {
    for (var e = arguments.length, r = new Array(e), t = 0; t < e; t++) r[t] = arguments[t];
    return r.length === 0 ? function(n) {
      return n;
    } : r.length === 1 ? r[0] : r.reduce(function(n, a) {
      return function() {
        return n(a.apply(void 0, arguments));
      };
    });
  }
  function ni() {
    for (var e = arguments.length, r = new Array(e), t = 0; t < e; t++) r[t] = arguments[t];
    return function(n) {
      return function() {
        var a = n.apply(void 0, arguments), i = function() {
          throw new Error(H(15));
        }, o = {
          getState: a.getState,
          dispatch: function() {
            return i.apply(void 0, arguments);
          }
        }, l = r.map(function(s) {
          return s(o);
        });
        return i = bn.apply(void 0, l)(a.dispatch), Bt(Bt({}, a), {}, {
          dispatch: i
        });
      };
    };
  }
  var hn = N.createContext(null);
  function ai(e) {
    e();
  }
  var yn = ai, ii = function(r) {
    return yn = r;
  }, oi = function() {
    return yn;
  };
  function li() {
    var e = oi(), r = null, t = null;
    return {
      clear: function() {
        r = null, t = null;
      },
      notify: function() {
        e(function() {
          for (var a = r; a; ) a.callback(), a = a.next;
        });
      },
      get: function() {
        for (var a = [], i = r; i; ) a.push(i), i = i.next;
        return a;
      },
      subscribe: function(a) {
        var i = true, o = t = {
          callback: a,
          next: null,
          prev: t
        };
        return o.prev ? o.prev.next = o : r = o, function() {
          !i || r === null || (i = false, o.next ? o.next.prev = o.prev : t = o.prev, o.prev ? o.prev.next = o.next : r = o.next);
        };
      }
    };
  }
  var Lt = {
    notify: function() {
    },
    get: function() {
      return [];
    }
  };
  function Dn(e, r) {
    var t, n = Lt;
    function a(u) {
      return s(), n.subscribe(u);
    }
    function i() {
      n.notify();
    }
    function o() {
      p.onStateChange && p.onStateChange();
    }
    function l() {
      return !!t;
    }
    function s() {
      t || (t = r ? r.addNestedSub(o) : e.subscribe(o), n = li());
    }
    function d() {
      t && (t(), t = void 0, n.clear(), n = Lt);
    }
    var p = {
      addNestedSub: a,
      notifyNestedSubs: i,
      handleChangeWrapper: o,
      isSubscribed: l,
      trySubscribe: s,
      tryUnsubscribe: d,
      getListeners: function() {
        return n;
      }
    };
    return p;
  }
  var xn = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u" ? fn : ie;
  function si(e) {
    var r = e.store, t = e.context, n = e.children, a = ae(function() {
      var l = Dn(r);
      return {
        store: r,
        subscription: l
      };
    }, [
      r
    ]), i = ae(function() {
      return r.getState();
    }, [
      r
    ]);
    xn(function() {
      var l = a.subscription;
      return l.onStateChange = l.notifyNestedSubs, l.trySubscribe(), i !== r.getState() && l.notifyNestedSubs(), function() {
        l.tryUnsubscribe(), l.onStateChange = null;
      };
    }, [
      a,
      i
    ]);
    var o = t || hn;
    return N.createElement(o.Provider, {
      value: a
    }, n);
  }
  var In = {
    exports: {}
  }, T = {};
  var yr = 60103, Dr = 60106, He = 60107, je = 60108, Ve = 60114, qe = 60109, ze = 60110, Ye = 60112, Je = 60113, et = 60120, Ke = 60115, Xe = 60116, Sn = 60121, wn = 60122, Cn = 60117, En = 60129, Pn = 60131;
  if (typeof Symbol == "function" && Symbol.for) {
    var k = Symbol.for;
    yr = k("react.element"), Dr = k("react.portal"), He = k("react.fragment"), je = k("react.strict_mode"), Ve = k("react.profiler"), qe = k("react.provider"), ze = k("react.context"), Ye = k("react.forward_ref"), Je = k("react.suspense"), et = k("react.suspense_list"), Ke = k("react.memo"), Xe = k("react.lazy"), Sn = k("react.block"), wn = k("react.server.block"), Cn = k("react.fundamental"), En = k("react.debug_trace_mode"), Pn = k("react.legacy_hidden");
  }
  function ne(e) {
    if (typeof e == "object" && e !== null) {
      var r = e.$$typeof;
      switch (r) {
        case yr:
          switch (e = e.type, e) {
            case He:
            case Ve:
            case je:
            case Je:
            case et:
              return e;
            default:
              switch (e = e && e.$$typeof, e) {
                case ze:
                case Ye:
                case Xe:
                case Ke:
                case qe:
                  return e;
                default:
                  return r;
              }
          }
        case Dr:
          return r;
      }
    }
  }
  var ui = qe, ci = yr, di = Ye, pi = He, vi = Xe, fi = Ke, gi = Dr, mi = Ve, bi = je, hi = Je;
  T.ContextConsumer = ze;
  T.ContextProvider = ui;
  T.Element = ci;
  T.ForwardRef = di;
  T.Fragment = pi;
  T.Lazy = vi;
  T.Memo = fi;
  T.Portal = gi;
  T.Profiler = mi;
  T.StrictMode = bi;
  T.Suspense = hi;
  T.isAsyncMode = function() {
    return false;
  };
  T.isConcurrentMode = function() {
    return false;
  };
  T.isContextConsumer = function(e) {
    return ne(e) === ze;
  };
  T.isContextProvider = function(e) {
    return ne(e) === qe;
  };
  T.isElement = function(e) {
    return typeof e == "object" && e !== null && e.$$typeof === yr;
  };
  T.isForwardRef = function(e) {
    return ne(e) === Ye;
  };
  T.isFragment = function(e) {
    return ne(e) === He;
  };
  T.isLazy = function(e) {
    return ne(e) === Xe;
  };
  T.isMemo = function(e) {
    return ne(e) === Ke;
  };
  T.isPortal = function(e) {
    return ne(e) === Dr;
  };
  T.isProfiler = function(e) {
    return ne(e) === Ve;
  };
  T.isStrictMode = function(e) {
    return ne(e) === je;
  };
  T.isSuspense = function(e) {
    return ne(e) === Je;
  };
  T.isValidElementType = function(e) {
    return typeof e == "string" || typeof e == "function" || e === He || e === Ve || e === En || e === je || e === Je || e === et || e === Pn || typeof e == "object" && e !== null && (e.$$typeof === Xe || e.$$typeof === Ke || e.$$typeof === qe || e.$$typeof === ze || e.$$typeof === Ye || e.$$typeof === Cn || e.$$typeof === Sn || e[0] === wn);
  };
  T.typeOf = ne;
  In.exports = T;
  var yi = In.exports, Di = [
    "getDisplayName",
    "methodName",
    "renderCountProp",
    "shouldHandleStateChanges",
    "storeKey",
    "withRef",
    "forwardRef",
    "context"
  ], xi = [
    "reactReduxForwardedRef"
  ], Ii = [], Si = [
    null,
    null
  ];
  function wi(e, r) {
    var t = e[1];
    return [
      r.payload,
      t + 1
    ];
  }
  function Ft(e, r, t) {
    xn(function() {
      return e.apply(void 0, r);
    }, t);
  }
  function Ci(e, r, t, n, a, i, o) {
    e.current = n, r.current = a, t.current = false, i.current && (i.current = null, o());
  }
  function Ei(e, r, t, n, a, i, o, l, s, d) {
    if (e) {
      var p = false, u = null, c = function() {
        if (!p) {
          var g = r.getState(), m, b;
          try {
            m = n(g, a.current);
          } catch (h) {
            b = h, u = h;
          }
          b || (u = null), m === i.current ? o.current || s() : (i.current = m, l.current = m, o.current = true, d({
            type: "STORE_UPDATED",
            payload: {
              error: b
            }
          }));
        }
      };
      t.onStateChange = c, t.trySubscribe(), c();
      var v = function() {
        if (p = true, t.tryUnsubscribe(), t.onStateChange = null, u) throw u;
      };
      return v;
    }
  }
  var Pi = function() {
    return [
      null,
      0
    ];
  };
  function Ai(e, r) {
    r === void 0 && (r = {});
    var t = r, n = t.getDisplayName, a = n === void 0 ? function(x) {
      return "ConnectAdvanced(" + x + ")";
    } : n, i = t.methodName, o = i === void 0 ? "connectAdvanced" : i, l = t.renderCountProp, s = l === void 0 ? void 0 : l, d = t.shouldHandleStateChanges, p = d === void 0 ? true : d, u = t.storeKey, c = u === void 0 ? "store" : u;
    t.withRef;
    var v = t.forwardRef, f = v === void 0 ? false : v, g = t.context, m = g === void 0 ? hn : g, b = cr(t, Di), h = m;
    return function(D) {
      var E = D.displayName || D.name || "Component", w = a(E), B = C({}, b, {
        getDisplayName: a,
        methodName: o,
        renderCountProp: s,
        shouldHandleStateChanges: p,
        storeKey: c,
        displayName: w,
        wrappedComponentName: E,
        WrappedComponent: D
      }), M = b.pure;
      function P(F) {
        return e(F.dispatch, B);
      }
      var L = M ? ae : function(F) {
        return F();
      };
      function R(F) {
        var K = ae(function() {
          var Re = F.reactReduxForwardedRef, Nr = cr(F, xi);
          return [
            F.context,
            Re,
            Nr
          ];
        }, [
          F
        ]), X = K[0], he = K[1], oe = K[2], ye = ae(function() {
          return X && X.Consumer && yi.isContextConsumer(N.createElement(X.Consumer, null)) ? X : h;
        }, [
          X,
          h
        ]), re = Qr(ye), fe = !!F.store && !!F.store.getState && !!F.store.dispatch;
        re && re.store;
        var j = fe ? F.store : re.store, Be = ae(function() {
          return P(j);
        }, [
          j
        ]), _e = ae(function() {
          if (!p) return Si;
          var Re = Dn(j, fe ? null : re.subscription), Nr = Re.notifyNestedSubs.bind(Re);
          return [
            Re,
            Nr
          ];
        }, [
          j,
          fe,
          re
        ]), le = _e[0], er = _e[1], rr = ae(function() {
          return fe ? re : C({}, re, {
            subscription: le
          });
        }, [
          fe,
          re,
          le
        ]), tr = za(wi, Ii, Pi), Ar = tr[0], De = Ar[0], Br = tr[1];
        if (De && De.error) throw De.error;
        var wt = O(), Rr = O(oe), nr = O(), Ct = O(false), Or = L(function() {
          return nr.current && oe === Rr.current ? nr.current : Be(j.getState(), oe);
        }, [
          j,
          De,
          oe
        ]);
        Ft(Ci, [
          Rr,
          wt,
          Ct,
          oe,
          Or,
          nr,
          er
        ]), Ft(Ei, [
          p,
          j,
          le,
          Be,
          Rr,
          wt,
          Ct,
          nr,
          er,
          Br
        ], [
          j,
          le,
          Be
        ]);
        var Tr = ae(function() {
          return N.createElement(D, C({}, Or, {
            ref: he
          }));
        }, [
          he,
          D,
          Or
        ]), Ra = ae(function() {
          return p ? N.createElement(ye.Provider, {
            value: rr
          }, Tr) : Tr;
        }, [
          ye,
          Tr,
          rr
        ]);
        return Ra;
      }
      var Y = M ? N.memo(R) : R;
      if (Y.WrappedComponent = D, Y.displayName = R.displayName = w, f) {
        var J = N.forwardRef(function(K, X) {
          return N.createElement(Y, C({}, K, {
            reactReduxForwardedRef: X
          }));
        });
        return J.displayName = w, J.WrappedComponent = D, Pt(J, D);
      }
      return Pt(Y, D);
    };
  }
  function Gt(e, r) {
    return e === r ? e !== 0 || r !== 0 || 1 / e === 1 / r : e !== e && r !== r;
  }
  function Lr(e, r) {
    if (Gt(e, r)) return true;
    if (typeof e != "object" || e === null || typeof r != "object" || r === null) return false;
    var t = Object.keys(e), n = Object.keys(r);
    if (t.length !== n.length) return false;
    for (var a = 0; a < t.length; a++) if (!Object.prototype.hasOwnProperty.call(r, t[a]) || !Gt(e[t[a]], r[t[a]])) return false;
    return true;
  }
  function Bi(e, r) {
    var t = {}, n = function(o) {
      var l = e[o];
      typeof l == "function" && (t[o] = function() {
        return r(l.apply(void 0, arguments));
      });
    };
    for (var a in e) n(a);
    return t;
  }
  function rt(e) {
    return function(t, n) {
      var a = e(t, n);
      function i() {
        return a;
      }
      return i.dependsOnOwnProps = false, i;
    };
  }
  function $t(e) {
    return e.dependsOnOwnProps !== null && e.dependsOnOwnProps !== void 0 ? !!e.dependsOnOwnProps : e.length !== 1;
  }
  function An(e, r) {
    return function(n, a) {
      a.displayName;
      var i = function(l, s) {
        return i.dependsOnOwnProps ? i.mapToProps(l, s) : i.mapToProps(l);
      };
      return i.dependsOnOwnProps = true, i.mapToProps = function(l, s) {
        i.mapToProps = e, i.dependsOnOwnProps = $t(e);
        var d = i(l, s);
        return typeof d == "function" && (i.mapToProps = d, i.dependsOnOwnProps = $t(d), d = i(l, s)), d;
      }, i;
    };
  }
  function Ri(e) {
    return typeof e == "function" ? An(e) : void 0;
  }
  function Oi(e) {
    return e ? void 0 : rt(function(r) {
      return {
        dispatch: r
      };
    });
  }
  function Ti(e) {
    return e && typeof e == "object" ? rt(function(r) {
      return Bi(e, r);
    }) : void 0;
  }
  const Ni = [
    Ri,
    Oi,
    Ti
  ];
  function Mi(e) {
    return typeof e == "function" ? An(e) : void 0;
  }
  function Li(e) {
    return e ? void 0 : rt(function() {
      return {};
    });
  }
  const Fi = [
    Mi,
    Li
  ];
  function Gi(e, r, t) {
    return C({}, t, e, r);
  }
  function $i(e) {
    return function(t, n) {
      n.displayName;
      var a = n.pure, i = n.areMergedPropsEqual, o = false, l;
      return function(d, p, u) {
        var c = e(d, p, u);
        return o ? (!a || !i(c, l)) && (l = c) : (o = true, l = c), l;
      };
    };
  }
  function ki(e) {
    return typeof e == "function" ? $i(e) : void 0;
  }
  function Wi(e) {
    return e ? void 0 : function() {
      return Gi;
    };
  }
  const Ui = [
    ki,
    Wi
  ];
  var Hi = [
    "initMapStateToProps",
    "initMapDispatchToProps",
    "initMergeProps"
  ];
  function ji(e, r, t, n) {
    return function(i, o) {
      return t(e(i, o), r(n, o), o);
    };
  }
  function Vi(e, r, t, n, a) {
    var i = a.areStatesEqual, o = a.areOwnPropsEqual, l = a.areStatePropsEqual, s = false, d, p, u, c, v;
    function f(x, D) {
      return d = x, p = D, u = e(d, p), c = r(n, p), v = t(u, c, p), s = true, v;
    }
    function g() {
      return u = e(d, p), r.dependsOnOwnProps && (c = r(n, p)), v = t(u, c, p), v;
    }
    function m() {
      return e.dependsOnOwnProps && (u = e(d, p)), r.dependsOnOwnProps && (c = r(n, p)), v = t(u, c, p), v;
    }
    function b() {
      var x = e(d, p), D = !l(x, u);
      return u = x, D && (v = t(u, c, p)), v;
    }
    function h(x, D) {
      var E = !o(D, p), w = !i(x, d, D, p);
      return d = x, p = D, E && w ? g() : E ? m() : w ? b() : v;
    }
    return function(D, E) {
      return s ? h(D, E) : f(D, E);
    };
  }
  function qi(e, r) {
    var t = r.initMapStateToProps, n = r.initMapDispatchToProps, a = r.initMergeProps, i = cr(r, Hi), o = t(e, i), l = n(e, i), s = a(e, i), d = i.pure ? Vi : ji;
    return d(o, l, s, e, i);
  }
  var zi = [
    "pure",
    "areStatesEqual",
    "areOwnPropsEqual",
    "areStatePropsEqual",
    "areMergedPropsEqual"
  ];
  function Fr(e, r, t) {
    for (var n = r.length - 1; n >= 0; n--) {
      var a = r[n](e);
      if (a) return a;
    }
    return function(i, o) {
      throw new Error("Invalid value of type " + typeof e + " for " + t + " argument when connecting component " + o.wrappedComponentName + ".");
    };
  }
  function Yi(e, r) {
    return e === r;
  }
  function Ji(e) {
    var r = e === void 0 ? {} : e, t = r.connectHOC, n = t === void 0 ? Ai : t, a = r.mapStateToPropsFactories, i = a === void 0 ? Fi : a, o = r.mapDispatchToPropsFactories, l = o === void 0 ? Ni : o, s = r.mergePropsFactories, d = s === void 0 ? Ui : s, p = r.selectorFactory, u = p === void 0 ? qi : p;
    return function(v, f, g, m) {
      m === void 0 && (m = {});
      var b = m, h = b.pure, x = h === void 0 ? true : h, D = b.areStatesEqual, E = D === void 0 ? Yi : D, w = b.areOwnPropsEqual, B = w === void 0 ? Lr : w, M = b.areStatePropsEqual, P = M === void 0 ? Lr : M, L = b.areMergedPropsEqual, R = L === void 0 ? Lr : L, Y = cr(b, zi), J = Fr(v, i, "mapStateToProps"), F = Fr(f, l, "mapDispatchToProps"), K = Fr(g, d, "mergeProps");
      return n(u, C({
        methodName: "connect",
        getDisplayName: function(he) {
          return "Connect(" + he + ")";
        },
        shouldHandleStateChanges: !!v,
        initMapStateToProps: J,
        initMapDispatchToProps: F,
        initMergeProps: K,
        pure: x,
        areStatesEqual: E,
        areOwnPropsEqual: B,
        areStatePropsEqual: P,
        areMergedPropsEqual: R
      }, Y));
    };
  }
  const Bn = Ji();
  ii(Ka);
  function Ki(e, r) {
    if (e.length !== r.length) return false;
    for (var t = 0; t < e.length; t++) if (e[t] !== r[t]) return false;
    return true;
  }
  function Rn(e, r) {
    var t = _r(function() {
      return {
        inputs: r,
        result: e()
      };
    })[0], n = O(true), a = O(t), i = n.current || !!(r && a.current.inputs && Ki(r, a.current.inputs)), o = i ? a.current : {
      inputs: r,
      result: e()
    };
    return ie(function() {
      n.current = false, a.current = o;
    }, [
      o
    ]), o.result;
  }
  function Xi(e, r) {
    return Rn(function() {
      return e;
    }, r);
  }
  var A = Rn, I = Xi, Zi = "Invariant failed";
  function Qi(e, r) {
    throw new Error(Zi);
  }
  var te = function(r) {
    var t = r.top, n = r.right, a = r.bottom, i = r.left, o = n - i, l = a - t, s = {
      top: t,
      right: n,
      bottom: a,
      left: i,
      width: o,
      height: l,
      x: i,
      y: t,
      center: {
        x: (n + i) / 2,
        y: (a + t) / 2
      }
    };
    return s;
  }, tt = function(r, t) {
    return {
      top: r.top - t.top,
      left: r.left - t.left,
      bottom: r.bottom + t.bottom,
      right: r.right + t.right
    };
  }, kt = function(r, t) {
    return {
      top: r.top + t.top,
      left: r.left + t.left,
      bottom: r.bottom - t.bottom,
      right: r.right - t.right
    };
  }, _i = function(r, t) {
    return {
      top: r.top + t.y,
      left: r.left + t.x,
      bottom: r.bottom + t.y,
      right: r.right + t.x
    };
  }, Gr = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }, nt = function(r) {
    var t = r.borderBox, n = r.margin, a = n === void 0 ? Gr : n, i = r.border, o = i === void 0 ? Gr : i, l = r.padding, s = l === void 0 ? Gr : l, d = te(tt(t, a)), p = te(kt(t, o)), u = te(kt(p, s));
    return {
      marginBox: d,
      borderBox: te(t),
      paddingBox: p,
      contentBox: u,
      margin: a,
      border: o,
      padding: s
    };
  }, Q = function(r) {
    var t = r.slice(0, -2), n = r.slice(-2);
    if (n !== "px") return 0;
    var a = Number(t);
    return isNaN(a) && Qi(), a;
  }, eo = function() {
    return {
      x: window.pageXOffset,
      y: window.pageYOffset
    };
  }, dr = function(r, t) {
    var n = r.borderBox, a = r.border, i = r.margin, o = r.padding, l = _i(n, t);
    return nt({
      borderBox: l,
      border: a,
      margin: i,
      padding: o
    });
  }, pr = function(r, t) {
    return t === void 0 && (t = eo()), dr(r, t);
  }, On = function(r, t) {
    var n = {
      top: Q(t.marginTop),
      right: Q(t.marginRight),
      bottom: Q(t.marginBottom),
      left: Q(t.marginLeft)
    }, a = {
      top: Q(t.paddingTop),
      right: Q(t.paddingRight),
      bottom: Q(t.paddingBottom),
      left: Q(t.paddingLeft)
    }, i = {
      top: Q(t.borderTopWidth),
      right: Q(t.borderRightWidth),
      bottom: Q(t.borderBottomWidth),
      left: Q(t.borderLeftWidth)
    };
    return nt({
      borderBox: r,
      margin: n,
      padding: a,
      border: i
    });
  }, Tn = function(r) {
    var t = r.getBoundingClientRect(), n = window.getComputedStyle(r);
    return On(t, n);
  }, Wt = Number.isNaN || function(r) {
    return typeof r == "number" && r !== r;
  };
  function ro(e, r) {
    return !!(e === r || Wt(e) && Wt(r));
  }
  function to(e, r) {
    if (e.length !== r.length) return false;
    for (var t = 0; t < e.length; t++) if (!ro(e[t], r[t])) return false;
    return true;
  }
  function G(e, r) {
    r === void 0 && (r = to);
    var t, n = [], a, i = false;
    function o() {
      for (var l = [], s = 0; s < arguments.length; s++) l[s] = arguments[s];
      return i && t === this && r(l, n) || (a = e.apply(this, l), i = true, t = this, n = l), a;
    }
    return o;
  }
  var Ge = function(r) {
    var t = [], n = null, a = function() {
      for (var o = arguments.length, l = new Array(o), s = 0; s < o; s++) l[s] = arguments[s];
      t = l, !n && (n = requestAnimationFrame(function() {
        n = null, r.apply(void 0, t);
      }));
    };
    return a.cancel = function() {
      n && (cancelAnimationFrame(n), n = null);
    }, a;
  };
  function Nn(e, r) {
  }
  Nn.bind(null, "warn");
  Nn.bind(null, "error");
  function ue() {
  }
  function no(e, r) {
    return C({}, e, {}, r);
  }
  function _(e, r, t) {
    var n = r.map(function(a) {
      var i = no(t, a.options);
      return e.addEventListener(a.eventName, a.fn, i), function() {
        e.removeEventListener(a.eventName, a.fn, i);
      };
    });
    return function() {
      n.forEach(function(i) {
        i();
      });
    };
  }
  var ao = "Invariant failed";
  function vr(e) {
    this.message = e;
  }
  vr.prototype.toString = function() {
    return this.message;
  };
  function y(e, r) {
    throw new vr(ao);
  }
  var io = (function(e) {
    gn(r, e);
    function r() {
      for (var n, a = arguments.length, i = new Array(a), o = 0; o < a; o++) i[o] = arguments[o];
      return n = e.call.apply(e, [
        this
      ].concat(i)) || this, n.callbacks = null, n.unbind = ue, n.onWindowError = function(l) {
        var s = n.getCallbacks();
        s.isDragging() && s.tryAbort();
        var d = l.error;
        d instanceof vr && l.preventDefault();
      }, n.getCallbacks = function() {
        if (!n.callbacks) throw new Error("Unable to find AppCallbacks in <ErrorBoundary/>");
        return n.callbacks;
      }, n.setCallbacks = function(l) {
        n.callbacks = l;
      }, n;
    }
    var t = r.prototype;
    return t.componentDidMount = function() {
      this.unbind = _(window, [
        {
          eventName: "error",
          fn: this.onWindowError
        }
      ]);
    }, t.componentDidCatch = function(a) {
      if (a instanceof vr) {
        this.setState({});
        return;
      }
      throw a;
    }, t.componentWillUnmount = function() {
      this.unbind();
    }, t.render = function() {
      return this.props.children(this.setCallbacks);
    }, r;
  })(N.Component), oo = `
  Press space bar to start a drag.
  When dragging you can use the arrow keys to move the item around and escape to cancel.
  Some screen readers may require you to be in focus mode or to use your pass through key
`, fr = function(r) {
    return r + 1;
  }, lo = function(r) {
    return `
  You have lifted an item in position ` + fr(r.source.index) + `
`;
  }, Mn = function(r, t) {
    var n = r.droppableId === t.droppableId, a = fr(r.index), i = fr(t.index);
    return n ? `
      You have moved the item from position ` + a + `
      to position ` + i + `
    ` : `
    You have moved the item from position ` + a + `
    in list ` + r.droppableId + `
    to list ` + t.droppableId + `
    in position ` + i + `
  `;
  }, Ln = function(r, t, n) {
    var a = t.droppableId === n.droppableId;
    return a ? `
      The item ` + r + `
      has been combined with ` + n.draggableId : `
      The item ` + r + `
      in list ` + t.droppableId + `
      has been combined with ` + n.draggableId + `
      in list ` + n.droppableId + `
    `;
  }, so = function(r) {
    var t = r.destination;
    if (t) return Mn(r.source, t);
    var n = r.combine;
    return n ? Ln(r.draggableId, r.source, n) : "You are over an area that cannot be dropped on";
  }, Ut = function(r) {
    return `
  The item has returned to its starting position
  of ` + fr(r.index) + `
`;
  }, uo = function(r) {
    if (r.reason === "CANCEL") return `
      Movement cancelled.
      ` + Ut(r.source) + `
    `;
    var t = r.destination, n = r.combine;
    return t ? `
      You have dropped the item.
      ` + Mn(r.source, t) + `
    ` : n ? `
      You have dropped the item.
      ` + Ln(r.draggableId, r.source, n) + `
    ` : `
    The item has been dropped while not over a drop area.
    ` + Ut(r.source) + `
  `;
  }, ur = {
    dragHandleUsageInstructions: oo,
    onDragStart: lo,
    onDragUpdate: so,
    onDragEnd: uo
  }, $ = {
    x: 0,
    y: 0
  }, W = function(r, t) {
    return {
      x: r.x + t.x,
      y: r.y + t.y
    };
  }, V = function(r, t) {
    return {
      x: r.x - t.x,
      y: r.y - t.y
    };
  }, ce = function(r, t) {
    return r.x === t.x && r.y === t.y;
  }, Ee = function(r) {
    return {
      x: r.x !== 0 ? -r.x : 0,
      y: r.y !== 0 ? -r.y : 0
    };
  }, be = function(r, t, n) {
    var a;
    return n === void 0 && (n = 0), a = {}, a[r] = t, a[r === "x" ? "y" : "x"] = n, a;
  }, $e = function(r, t) {
    return Math.sqrt(Math.pow(t.x - r.x, 2) + Math.pow(t.y - r.y, 2));
  }, Ht = function(r, t) {
    return Math.min.apply(Math, t.map(function(n) {
      return $e(r, n);
    }));
  }, Fn = function(r) {
    return function(t) {
      return {
        x: r(t.x),
        y: r(t.y)
      };
    };
  }, co = (function(e, r) {
    var t = te({
      top: Math.max(r.top, e.top),
      right: Math.min(r.right, e.right),
      bottom: Math.min(r.bottom, e.bottom),
      left: Math.max(r.left, e.left)
    });
    return t.width <= 0 || t.height <= 0 ? null : t;
  }), Ze = function(r, t) {
    return {
      top: r.top + t.y,
      left: r.left + t.x,
      bottom: r.bottom + t.y,
      right: r.right + t.x
    };
  }, jt = function(r) {
    return [
      {
        x: r.left,
        y: r.top
      },
      {
        x: r.right,
        y: r.top
      },
      {
        x: r.left,
        y: r.bottom
      },
      {
        x: r.right,
        y: r.bottom
      }
    ];
  }, po = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  }, vo = function(r, t) {
    return t ? Ze(r, t.scroll.diff.displacement) : r;
  }, fo = function(r, t, n) {
    if (n && n.increasedBy) {
      var a;
      return C({}, r, (a = {}, a[t.end] = r[t.end] + n.increasedBy[t.line], a));
    }
    return r;
  }, go = function(r, t) {
    return t && t.shouldClipSubject ? co(t.pageMarginBox, r) : te(r);
  }, Se = (function(e) {
    var r = e.page, t = e.withPlaceholder, n = e.axis, a = e.frame, i = vo(r.marginBox, a), o = fo(i, n, t), l = go(o, a);
    return {
      page: r,
      withPlaceholder: t,
      active: l
    };
  }), at = (function(e, r) {
    e.frame || y();
    var t = e.frame, n = V(r, t.scroll.initial), a = Ee(n), i = C({}, t, {
      scroll: {
        initial: t.scroll.initial,
        current: r,
        diff: {
          value: n,
          displacement: a
        },
        max: t.scroll.max
      }
    }), o = Se({
      page: e.subject.page,
      withPlaceholder: e.subject.withPlaceholder,
      axis: e.axis,
      frame: i
    }), l = C({}, e, {
      frame: i,
      subject: o
    });
    return l;
  });
  function gr(e) {
    return Object.values ? Object.values(e) : Object.keys(e).map(function(r) {
      return e[r];
    });
  }
  function it(e, r) {
    if (e.findIndex) return e.findIndex(r);
    for (var t = 0; t < e.length; t++) if (r(e[t])) return t;
    return -1;
  }
  function ve(e, r) {
    if (e.find) return e.find(r);
    var t = it(e, r);
    if (t !== -1) return e[t];
  }
  function Gn(e) {
    return Array.prototype.slice.call(e);
  }
  var $n = G(function(e) {
    return e.reduce(function(r, t) {
      return r[t.descriptor.id] = t, r;
    }, {});
  }), kn = G(function(e) {
    return e.reduce(function(r, t) {
      return r[t.descriptor.id] = t, r;
    }, {});
  }), xr = G(function(e) {
    return gr(e);
  }), mo = G(function(e) {
    return gr(e);
  }), Pe = G(function(e, r) {
    var t = mo(r).filter(function(n) {
      return e === n.descriptor.droppableId;
    }).sort(function(n, a) {
      return n.descriptor.index - a.descriptor.index;
    });
    return t;
  });
  function ot(e) {
    return e.at && e.at.type === "REORDER" ? e.at.destination : null;
  }
  function Ir(e) {
    return e.at && e.at.type === "COMBINE" ? e.at.combine : null;
  }
  var Sr = G(function(e, r) {
    return r.filter(function(t) {
      return t.descriptor.id !== e.descriptor.id;
    });
  }), bo = (function(e) {
    var r = e.isMovingForward, t = e.draggable, n = e.destination, a = e.insideDestination, i = e.previousImpact;
    if (!n.isCombineEnabled) return null;
    var o = ot(i);
    if (!o) return null;
    function l(g) {
      var m = {
        type: "COMBINE",
        combine: {
          draggableId: g,
          droppableId: n.descriptor.id
        }
      };
      return C({}, i, {
        at: m
      });
    }
    var s = i.displaced.all, d = s.length ? s[0] : null;
    if (r) return d ? l(d) : null;
    var p = Sr(t, a);
    if (!d) {
      if (!p.length) return null;
      var u = p[p.length - 1];
      return l(u.descriptor.id);
    }
    var c = it(p, function(g) {
      return g.descriptor.id === d;
    });
    c === -1 && y();
    var v = c - 1;
    if (v < 0) return null;
    var f = p[v];
    return l(f.descriptor.id);
  }), Ae = (function(e, r) {
    return e.descriptor.droppableId === r.descriptor.id;
  }), Wn = {
    point: $,
    value: 0
  }, ke = {
    invisible: {},
    visible: {},
    all: []
  }, ho = {
    displaced: ke,
    displacedBy: Wn,
    at: null
  }, ee = (function(e, r) {
    return function(t) {
      return e <= t && t <= r;
    };
  }), Un = (function(e) {
    var r = ee(e.top, e.bottom), t = ee(e.left, e.right);
    return function(n) {
      var a = r(n.top) && r(n.bottom) && t(n.left) && t(n.right);
      if (a) return true;
      var i = r(n.top) || r(n.bottom), o = t(n.left) || t(n.right), l = i && o;
      if (l) return true;
      var s = n.top < e.top && n.bottom > e.bottom, d = n.left < e.left && n.right > e.right, p = s && d;
      if (p) return true;
      var u = s && o || d && i;
      return u;
    };
  }), yo = (function(e) {
    var r = ee(e.top, e.bottom), t = ee(e.left, e.right);
    return function(n) {
      var a = r(n.top) && r(n.bottom) && t(n.left) && t(n.right);
      return a;
    };
  }), lt = {
    direction: "vertical",
    line: "y",
    crossAxisLine: "x",
    start: "top",
    end: "bottom",
    size: "height",
    crossAxisStart: "left",
    crossAxisEnd: "right",
    crossAxisSize: "width"
  }, Hn = {
    direction: "horizontal",
    line: "x",
    crossAxisLine: "y",
    start: "left",
    end: "right",
    size: "width",
    crossAxisStart: "top",
    crossAxisEnd: "bottom",
    crossAxisSize: "height"
  }, Do = (function(e) {
    return function(r) {
      var t = ee(r.top, r.bottom), n = ee(r.left, r.right);
      return function(a) {
        return e === lt ? t(a.top) && t(a.bottom) : n(a.left) && n(a.right);
      };
    };
  }), xo = function(r, t) {
    var n = t.frame ? t.frame.scroll.diff.displacement : $;
    return Ze(r, n);
  }, Io = function(r, t, n) {
    return t.subject.active ? n(t.subject.active)(r) : false;
  }, So = function(r, t, n) {
    return n(t)(r);
  }, st = function(r) {
    var t = r.target, n = r.destination, a = r.viewport, i = r.withDroppableDisplacement, o = r.isVisibleThroughFrameFn, l = i ? xo(t, n) : t;
    return Io(l, n, o) && So(l, a, o);
  }, wo = function(r) {
    return st(C({}, r, {
      isVisibleThroughFrameFn: Un
    }));
  }, jn = function(r) {
    return st(C({}, r, {
      isVisibleThroughFrameFn: yo
    }));
  }, Co = function(r) {
    return st(C({}, r, {
      isVisibleThroughFrameFn: Do(r.destination.axis)
    }));
  }, Eo = function(r, t, n) {
    if (typeof n == "boolean") return n;
    if (!t) return true;
    var a = t.invisible, i = t.visible;
    if (a[r]) return false;
    var o = i[r];
    return o ? o.shouldAnimate : true;
  };
  function Po(e, r) {
    var t = e.page.marginBox, n = {
      top: r.point.y,
      right: 0,
      bottom: 0,
      left: r.point.x
    };
    return te(tt(t, n));
  }
  function We(e) {
    var r = e.afterDragging, t = e.destination, n = e.displacedBy, a = e.viewport, i = e.forceShouldAnimate, o = e.last;
    return r.reduce(function(s, d) {
      var p = Po(d, n), u = d.descriptor.id;
      s.all.push(u);
      var c = wo({
        target: p,
        destination: t,
        viewport: a,
        withDroppableDisplacement: true
      });
      if (!c) return s.invisible[d.descriptor.id] = true, s;
      var v = Eo(u, o, i), f = {
        draggableId: u,
        shouldAnimate: v
      };
      return s.visible[u] = f, s;
    }, {
      all: [],
      visible: {},
      invisible: {}
    });
  }
  function Ao(e, r) {
    if (!e.length) return 0;
    var t = e[e.length - 1].descriptor.index;
    return r.inHomeList ? t : t + 1;
  }
  function Vt(e) {
    var r = e.insideDestination, t = e.inHomeList, n = e.displacedBy, a = e.destination, i = Ao(r, {
      inHomeList: t
    });
    return {
      displaced: ke,
      displacedBy: n,
      at: {
        type: "REORDER",
        destination: {
          droppableId: a.descriptor.id,
          index: i
        }
      }
    };
  }
  function mr(e) {
    var r = e.draggable, t = e.insideDestination, n = e.destination, a = e.viewport, i = e.displacedBy, o = e.last, l = e.index, s = e.forceShouldAnimate, d = Ae(r, n);
    if (l == null) return Vt({
      insideDestination: t,
      inHomeList: d,
      displacedBy: i,
      destination: n
    });
    var p = ve(t, function(g) {
      return g.descriptor.index === l;
    });
    if (!p) return Vt({
      insideDestination: t,
      inHomeList: d,
      displacedBy: i,
      destination: n
    });
    var u = Sr(r, t), c = t.indexOf(p), v = u.slice(c), f = We({
      afterDragging: v,
      destination: n,
      displacedBy: i,
      last: o,
      viewport: a.frame,
      forceShouldAnimate: s
    });
    return {
      displaced: f,
      displacedBy: i,
      at: {
        type: "REORDER",
        destination: {
          droppableId: n.descriptor.id,
          index: l
        }
      }
    };
  }
  function pe(e, r) {
    return !!r.effected[e];
  }
  var Bo = (function(e) {
    var r = e.isMovingForward, t = e.destination, n = e.draggables, a = e.combine, i = e.afterCritical;
    if (!t.isCombineEnabled) return null;
    var o = a.draggableId, l = n[o], s = l.descriptor.index, d = pe(o, i);
    return d ? r ? s : s - 1 : r ? s + 1 : s;
  }), Ro = (function(e) {
    var r = e.isMovingForward, t = e.isInHomeList, n = e.insideDestination, a = e.location;
    if (!n.length) return null;
    var i = a.index, o = r ? i + 1 : i - 1, l = n[0].descriptor.index, s = n[n.length - 1].descriptor.index, d = t ? s : s + 1;
    return o < l || o > d ? null : o;
  }), Oo = (function(e) {
    var r = e.isMovingForward, t = e.isInHomeList, n = e.draggable, a = e.draggables, i = e.destination, o = e.insideDestination, l = e.previousImpact, s = e.viewport, d = e.afterCritical, p = l.at;
    if (p || y(), p.type === "REORDER") {
      var u = Ro({
        isMovingForward: r,
        isInHomeList: t,
        location: p.destination,
        insideDestination: o
      });
      return u == null ? null : mr({
        draggable: n,
        insideDestination: o,
        destination: i,
        viewport: s,
        last: l.displaced,
        displacedBy: l.displacedBy,
        index: u
      });
    }
    var c = Bo({
      isMovingForward: r,
      destination: i,
      displaced: l.displaced,
      draggables: a,
      combine: p.combine,
      afterCritical: d
    });
    return c == null ? null : mr({
      draggable: n,
      insideDestination: o,
      destination: i,
      viewport: s,
      last: l.displaced,
      displacedBy: l.displacedBy,
      index: c
    });
  }), To = (function(e) {
    var r = e.displaced, t = e.afterCritical, n = e.combineWith, a = e.displacedBy, i = !!(r.visible[n] || r.invisible[n]);
    return pe(n, t) ? i ? $ : Ee(a.point) : i ? a.point : $;
  }), No = (function(e) {
    var r = e.afterCritical, t = e.impact, n = e.draggables, a = Ir(t);
    a || y();
    var i = a.draggableId, o = n[i].page.borderBox.center, l = To({
      displaced: t.displaced,
      afterCritical: r,
      combineWith: i,
      displacedBy: t.displacedBy
    });
    return W(o, l);
  }), Vn = function(r, t) {
    return t.margin[r.start] + t.borderBox[r.size] / 2;
  }, Mo = function(r, t) {
    return t.margin[r.end] + t.borderBox[r.size] / 2;
  }, ut = function(r, t, n) {
    return t[r.crossAxisStart] + n.margin[r.crossAxisStart] + n.borderBox[r.crossAxisSize] / 2;
  }, qt = function(r) {
    var t = r.axis, n = r.moveRelativeTo, a = r.isMoving;
    return be(t.line, n.marginBox[t.end] + Vn(t, a), ut(t, n.marginBox, a));
  }, zt = function(r) {
    var t = r.axis, n = r.moveRelativeTo, a = r.isMoving;
    return be(t.line, n.marginBox[t.start] - Mo(t, a), ut(t, n.marginBox, a));
  }, Lo = function(r) {
    var t = r.axis, n = r.moveInto, a = r.isMoving;
    return be(t.line, n.contentBox[t.start] + Vn(t, a), ut(t, n.contentBox, a));
  }, Fo = (function(e) {
    var r = e.impact, t = e.draggable, n = e.draggables, a = e.droppable, i = e.afterCritical, o = Pe(a.descriptor.id, n), l = t.page, s = a.axis;
    if (!o.length) return Lo({
      axis: s,
      moveInto: a.page,
      isMoving: l
    });
    var d = r.displaced, p = r.displacedBy, u = d.all[0];
    if (u) {
      var c = n[u];
      if (pe(u, i)) return zt({
        axis: s,
        moveRelativeTo: c.page,
        isMoving: l
      });
      var v = dr(c.page, p.point);
      return zt({
        axis: s,
        moveRelativeTo: v,
        isMoving: l
      });
    }
    var f = o[o.length - 1];
    if (f.descriptor.id === t.descriptor.id) return l.borderBox.center;
    if (pe(f.descriptor.id, i)) {
      var g = dr(f.page, Ee(i.displacedBy.point));
      return qt({
        axis: s,
        moveRelativeTo: g,
        isMoving: l
      });
    }
    return qt({
      axis: s,
      moveRelativeTo: f.page,
      isMoving: l
    });
  }), zr = (function(e, r) {
    var t = e.frame;
    return t ? W(r, t.scroll.diff.displacement) : r;
  }), Go = function(r) {
    var t = r.impact, n = r.draggable, a = r.droppable, i = r.draggables, o = r.afterCritical, l = n.page.borderBox.center, s = t.at;
    return !a || !s ? l : s.type === "REORDER" ? Fo({
      impact: t,
      draggable: n,
      draggables: i,
      droppable: a,
      afterCritical: o
    }) : No({
      impact: t,
      draggables: i,
      afterCritical: o
    });
  }, wr = (function(e) {
    var r = Go(e), t = e.droppable, n = t ? zr(t, r) : r;
    return n;
  }), qn = (function(e, r) {
    var t = V(r, e.scroll.initial), n = Ee(t), a = te({
      top: r.y,
      bottom: r.y + e.frame.height,
      left: r.x,
      right: r.x + e.frame.width
    }), i = {
      frame: a,
      scroll: {
        initial: e.scroll.initial,
        max: e.scroll.max,
        current: r,
        diff: {
          value: t,
          displacement: n
        }
      }
    };
    return i;
  });
  function Yt(e, r) {
    return e.map(function(t) {
      return r[t];
    });
  }
  function $o(e, r) {
    for (var t = 0; t < r.length; t++) {
      var n = r[t].visible[e];
      if (n) return n;
    }
    return null;
  }
  var ko = (function(e) {
    var r = e.impact, t = e.viewport, n = e.destination, a = e.draggables, i = e.maxScrollChange, o = qn(t, W(t.scroll.current, i)), l = n.frame ? at(n, W(n.frame.scroll.current, i)) : n, s = r.displaced, d = We({
      afterDragging: Yt(s.all, a),
      destination: n,
      displacedBy: r.displacedBy,
      viewport: o.frame,
      last: s,
      forceShouldAnimate: false
    }), p = We({
      afterDragging: Yt(s.all, a),
      destination: l,
      displacedBy: r.displacedBy,
      viewport: t.frame,
      last: s,
      forceShouldAnimate: false
    }), u = {}, c = {}, v = [
      s,
      d,
      p
    ];
    s.all.forEach(function(g) {
      var m = $o(g, v);
      if (m) {
        c[g] = m;
        return;
      }
      u[g] = true;
    });
    var f = C({}, r, {
      displaced: {
        all: s.all,
        invisible: u,
        visible: c
      }
    });
    return f;
  }), Wo = (function(e, r) {
    return W(e.scroll.diff.displacement, r);
  }), ct = (function(e) {
    var r = e.pageBorderBoxCenter, t = e.draggable, n = e.viewport, a = Wo(n, r), i = V(a, t.page.borderBox.center);
    return W(t.client.borderBox.center, i);
  }), zn = (function(e) {
    var r = e.draggable, t = e.destination, n = e.newPageBorderBoxCenter, a = e.viewport, i = e.withDroppableDisplacement, o = e.onlyOnMainAxis, l = o === void 0 ? false : o, s = V(n, r.page.borderBox.center), d = Ze(r.page.borderBox, s), p = {
      target: d,
      destination: t,
      withDroppableDisplacement: i,
      viewport: a
    };
    return l ? Co(p) : jn(p);
  }), Uo = (function(e) {
    var r = e.isMovingForward, t = e.draggable, n = e.destination, a = e.draggables, i = e.previousImpact, o = e.viewport, l = e.previousPageBorderBoxCenter, s = e.previousClientSelection, d = e.afterCritical;
    if (!n.isEnabled) return null;
    var p = Pe(n.descriptor.id, a), u = Ae(t, n), c = bo({
      isMovingForward: r,
      draggable: t,
      destination: n,
      insideDestination: p,
      previousImpact: i
    }) || Oo({
      isMovingForward: r,
      isInHomeList: u,
      draggable: t,
      draggables: a,
      destination: n,
      insideDestination: p,
      previousImpact: i,
      viewport: o,
      afterCritical: d
    });
    if (!c) return null;
    var v = wr({
      impact: c,
      draggable: t,
      droppable: n,
      draggables: a,
      afterCritical: d
    }), f = zn({
      draggable: t,
      destination: n,
      newPageBorderBoxCenter: v,
      viewport: o.frame,
      withDroppableDisplacement: false,
      onlyOnMainAxis: true
    });
    if (f) {
      var g = ct({
        pageBorderBoxCenter: v,
        draggable: t,
        viewport: o
      });
      return {
        clientSelection: g,
        impact: c,
        scrollJumpRequest: null
      };
    }
    var m = V(v, l), b = ko({
      impact: c,
      viewport: o,
      destination: n,
      draggables: a,
      maxScrollChange: m
    });
    return {
      clientSelection: s,
      impact: b,
      scrollJumpRequest: m
    };
  }), U = function(r) {
    var t = r.subject.active;
    return t || y(), t;
  }, Ho = (function(e) {
    var r = e.isMovingForward, t = e.pageBorderBoxCenter, n = e.source, a = e.droppables, i = e.viewport, o = n.subject.active;
    if (!o) return null;
    var l = n.axis, s = ee(o[l.start], o[l.end]), d = xr(a).filter(function(u) {
      return u !== n;
    }).filter(function(u) {
      return u.isEnabled;
    }).filter(function(u) {
      return !!u.subject.active;
    }).filter(function(u) {
      return Un(i.frame)(U(u));
    }).filter(function(u) {
      var c = U(u);
      return r ? o[l.crossAxisEnd] < c[l.crossAxisEnd] : c[l.crossAxisStart] < o[l.crossAxisStart];
    }).filter(function(u) {
      var c = U(u), v = ee(c[l.start], c[l.end]);
      return s(c[l.start]) || s(c[l.end]) || v(o[l.start]) || v(o[l.end]);
    }).sort(function(u, c) {
      var v = U(u)[l.crossAxisStart], f = U(c)[l.crossAxisStart];
      return r ? v - f : f - v;
    }).filter(function(u, c, v) {
      return U(u)[l.crossAxisStart] === U(v[0])[l.crossAxisStart];
    });
    if (!d.length) return null;
    if (d.length === 1) return d[0];
    var p = d.filter(function(u) {
      var c = ee(U(u)[l.start], U(u)[l.end]);
      return c(t[l.line]);
    });
    return p.length === 1 ? p[0] : p.length > 1 ? p.sort(function(u, c) {
      return U(u)[l.start] - U(c)[l.start];
    })[0] : d.sort(function(u, c) {
      var v = Ht(t, jt(U(u))), f = Ht(t, jt(U(c)));
      return v !== f ? v - f : U(u)[l.start] - U(c)[l.start];
    })[0];
  }), Jt = function(r, t) {
    var n = r.page.borderBox.center;
    return pe(r.descriptor.id, t) ? V(n, t.displacedBy.point) : n;
  }, jo = function(r, t) {
    var n = r.page.borderBox;
    return pe(r.descriptor.id, t) ? Ze(n, Ee(t.displacedBy.point)) : n;
  }, Vo = (function(e) {
    var r = e.pageBorderBoxCenter, t = e.viewport, n = e.destination, a = e.insideDestination, i = e.afterCritical, o = a.filter(function(l) {
      return jn({
        target: jo(l, i),
        destination: n,
        viewport: t.frame,
        withDroppableDisplacement: true
      });
    }).sort(function(l, s) {
      var d = $e(r, zr(n, Jt(l, i))), p = $e(r, zr(n, Jt(s, i)));
      return d < p ? -1 : p < d ? 1 : l.descriptor.index - s.descriptor.index;
    });
    return o[0] || null;
  }), Qe = G(function(r, t) {
    var n = t[r.line];
    return {
      value: n,
      point: be(r.line, n)
    };
  }), qo = function(r, t, n) {
    var a = r.axis;
    if (r.descriptor.mode === "virtual") return be(a.line, t[a.line]);
    var i = r.subject.page.contentBox[a.size], o = Pe(r.descriptor.id, n), l = o.reduce(function(p, u) {
      return p + u.client.marginBox[a.size];
    }, 0), s = l + t[a.line], d = s - i;
    return d <= 0 ? null : be(a.line, d);
  }, Yn = function(r, t) {
    return C({}, r, {
      scroll: C({}, r.scroll, {
        max: t
      })
    });
  }, Jn = function(r, t, n) {
    var a = r.frame;
    Ae(t, r) && y(), r.subject.withPlaceholder && y();
    var i = Qe(r.axis, t.displaceBy).point, o = qo(r, i, n), l = {
      placeholderSize: i,
      increasedBy: o,
      oldFrameMaxScroll: r.frame ? r.frame.scroll.max : null
    };
    if (!a) {
      var s = Se({
        page: r.subject.page,
        withPlaceholder: l,
        axis: r.axis,
        frame: r.frame
      });
      return C({}, r, {
        subject: s
      });
    }
    var d = o ? W(a.scroll.max, o) : a.scroll.max, p = Yn(a, d), u = Se({
      page: r.subject.page,
      withPlaceholder: l,
      axis: r.axis,
      frame: p
    });
    return C({}, r, {
      subject: u,
      frame: p
    });
  }, zo = function(r) {
    var t = r.subject.withPlaceholder;
    t || y();
    var n = r.frame;
    if (!n) {
      var a = Se({
        page: r.subject.page,
        axis: r.axis,
        frame: null,
        withPlaceholder: null
      });
      return C({}, r, {
        subject: a
      });
    }
    var i = t.oldFrameMaxScroll;
    i || y();
    var o = Yn(n, i), l = Se({
      page: r.subject.page,
      axis: r.axis,
      frame: o,
      withPlaceholder: null
    });
    return C({}, r, {
      subject: l,
      frame: o
    });
  }, Yo = (function(e) {
    var r = e.previousPageBorderBoxCenter, t = e.moveRelativeTo, n = e.insideDestination, a = e.draggable, i = e.draggables, o = e.destination, l = e.viewport, s = e.afterCritical;
    if (!t) {
      if (n.length) return null;
      var d = {
        displaced: ke,
        displacedBy: Wn,
        at: {
          type: "REORDER",
          destination: {
            droppableId: o.descriptor.id,
            index: 0
          }
        }
      }, p = wr({
        impact: d,
        draggable: a,
        droppable: o,
        draggables: i,
        afterCritical: s
      }), u = Ae(a, o) ? o : Jn(o, a, i), c = zn({
        draggable: a,
        destination: u,
        newPageBorderBoxCenter: p,
        viewport: l.frame,
        withDroppableDisplacement: false,
        onlyOnMainAxis: true
      });
      return c ? d : null;
    }
    var v = r[o.axis.line] <= t.page.borderBox.center[o.axis.line], f = (function() {
      var m = t.descriptor.index;
      return t.descriptor.id === a.descriptor.id || v ? m : m + 1;
    })(), g = Qe(o.axis, a.displaceBy);
    return mr({
      draggable: a,
      insideDestination: n,
      destination: o,
      viewport: l,
      displacedBy: g,
      last: ke,
      index: f
    });
  }), Jo = (function(e) {
    var r = e.isMovingForward, t = e.previousPageBorderBoxCenter, n = e.draggable, a = e.isOver, i = e.draggables, o = e.droppables, l = e.viewport, s = e.afterCritical, d = Ho({
      isMovingForward: r,
      pageBorderBoxCenter: t,
      source: a,
      droppables: o,
      viewport: l
    });
    if (!d) return null;
    var p = Pe(d.descriptor.id, i), u = Vo({
      pageBorderBoxCenter: t,
      viewport: l,
      destination: d,
      insideDestination: p,
      afterCritical: s
    }), c = Yo({
      previousPageBorderBoxCenter: t,
      destination: d,
      draggable: n,
      draggables: i,
      moveRelativeTo: u,
      insideDestination: p,
      viewport: l,
      afterCritical: s
    });
    if (!c) return null;
    var v = wr({
      impact: c,
      draggable: n,
      droppable: d,
      draggables: i,
      afterCritical: s
    }), f = ct({
      pageBorderBoxCenter: v,
      draggable: n,
      viewport: l
    });
    return {
      clientSelection: f,
      impact: c,
      scrollJumpRequest: null
    };
  }), q = (function(e) {
    var r = e.at;
    return r ? r.type === "REORDER" ? r.destination.droppableId : r.combine.droppableId : null;
  }), Ko = function(r, t) {
    var n = q(r);
    return n ? t[n] : null;
  }, Xo = (function(e) {
    var r = e.state, t = e.type, n = Ko(r.impact, r.dimensions.droppables), a = !!n, i = r.dimensions.droppables[r.critical.droppable.id], o = n || i, l = o.axis.direction, s = l === "vertical" && (t === "MOVE_UP" || t === "MOVE_DOWN") || l === "horizontal" && (t === "MOVE_LEFT" || t === "MOVE_RIGHT");
    if (s && !a) return null;
    var d = t === "MOVE_DOWN" || t === "MOVE_RIGHT", p = r.dimensions.draggables[r.critical.draggable.id], u = r.current.page.borderBoxCenter, c = r.dimensions, v = c.draggables, f = c.droppables;
    return s ? Uo({
      isMovingForward: d,
      previousPageBorderBoxCenter: u,
      draggable: p,
      destination: o,
      draggables: v,
      viewport: r.viewport,
      previousClientSelection: r.current.client.selection,
      previousImpact: r.impact,
      afterCritical: r.afterCritical
    }) : Jo({
      isMovingForward: d,
      previousPageBorderBoxCenter: u,
      draggable: p,
      isOver: o,
      draggables: v,
      droppables: f,
      viewport: r.viewport,
      afterCritical: r.afterCritical
    });
  });
  function me(e) {
    return e.phase === "DRAGGING" || e.phase === "COLLECTING";
  }
  function Kn(e) {
    var r = ee(e.top, e.bottom), t = ee(e.left, e.right);
    return function(a) {
      return r(a.y) && t(a.x);
    };
  }
  function Zo(e, r) {
    return e.left < r.right && e.right > r.left && e.top < r.bottom && e.bottom > r.top;
  }
  function Qo(e) {
    var r = e.pageBorderBox, t = e.draggable, n = e.candidates, a = t.page.borderBox.center, i = n.map(function(o) {
      var l = o.axis, s = be(o.axis.line, r.center[l.line], o.page.borderBox.center[l.crossAxisLine]);
      return {
        id: o.descriptor.id,
        distance: $e(a, s)
      };
    }).sort(function(o, l) {
      return l.distance - o.distance;
    });
    return i[0] ? i[0].id : null;
  }
  function _o(e) {
    var r = e.pageBorderBox, t = e.draggable, n = e.droppables, a = xr(n).filter(function(i) {
      if (!i.isEnabled) return false;
      var o = i.subject.active;
      if (!o || !Zo(r, o)) return false;
      if (Kn(o)(r.center)) return true;
      var l = i.axis, s = o.center[l.crossAxisLine], d = r[l.crossAxisStart], p = r[l.crossAxisEnd], u = ee(o[l.crossAxisStart], o[l.crossAxisEnd]), c = u(d), v = u(p);
      return !c && !v ? true : c ? d < s : p > s;
    });
    return a.length ? a.length === 1 ? a[0].descriptor.id : Qo({
      pageBorderBox: r,
      draggable: t,
      candidates: a
    }) : null;
  }
  var Xn = function(r, t) {
    return te(Ze(r, t));
  }, el = (function(e, r) {
    var t = e.frame;
    return t ? Xn(r, t.scroll.diff.value) : r;
  });
  function Zn(e) {
    var r = e.displaced, t = e.id;
    return !!(r.visible[t] || r.invisible[t]);
  }
  function rl(e) {
    var r = e.draggable, t = e.closest, n = e.inHomeList;
    return t ? n && t.descriptor.index > r.descriptor.index ? t.descriptor.index - 1 : t.descriptor.index : null;
  }
  var tl = (function(e) {
    var r = e.pageBorderBoxWithDroppableScroll, t = e.draggable, n = e.destination, a = e.insideDestination, i = e.last, o = e.viewport, l = e.afterCritical, s = n.axis, d = Qe(n.axis, t.displaceBy), p = d.value, u = r[s.start], c = r[s.end], v = Sr(t, a), f = ve(v, function(m) {
      var b = m.descriptor.id, h = m.page.borderBox.center[s.line], x = pe(b, l), D = Zn({
        displaced: i,
        id: b
      });
      return x ? D ? c <= h : u < h - p : D ? c <= h + p : u < h;
    }), g = rl({
      draggable: t,
      closest: f,
      inHomeList: Ae(t, n)
    });
    return mr({
      draggable: t,
      insideDestination: a,
      destination: n,
      viewport: o,
      last: i,
      displacedBy: d,
      index: g
    });
  }), nl = 4, al = (function(e) {
    var r = e.draggable, t = e.pageBorderBoxWithDroppableScroll, n = e.previousImpact, a = e.destination, i = e.insideDestination, o = e.afterCritical;
    if (!a.isCombineEnabled) return null;
    var l = a.axis, s = Qe(a.axis, r.displaceBy), d = s.value, p = t[l.start], u = t[l.end], c = Sr(r, i), v = ve(c, function(g) {
      var m = g.descriptor.id, b = g.page.borderBox, h = b[l.size], x = h / nl, D = pe(m, o), E = Zn({
        displaced: n.displaced,
        id: m
      });
      return D ? E ? u > b[l.start] + x && u < b[l.end] - x : p > b[l.start] - d + x && p < b[l.end] - d - x : E ? u > b[l.start] + d + x && u < b[l.end] + d - x : p > b[l.start] + x && p < b[l.end] - x;
    });
    if (!v) return null;
    var f = {
      displacedBy: s,
      displaced: n.displaced,
      at: {
        type: "COMBINE",
        combine: {
          draggableId: v.descriptor.id,
          droppableId: a.descriptor.id
        }
      }
    };
    return f;
  }), Qn = (function(e) {
    var r = e.pageOffset, t = e.draggable, n = e.draggables, a = e.droppables, i = e.previousImpact, o = e.viewport, l = e.afterCritical, s = Xn(t.page.borderBox, r), d = _o({
      pageBorderBox: s,
      draggable: t,
      droppables: a
    });
    if (!d) return ho;
    var p = a[d], u = Pe(p.descriptor.id, n), c = el(p, s);
    return al({
      pageBorderBoxWithDroppableScroll: c,
      draggable: t,
      previousImpact: i,
      destination: p,
      insideDestination: u,
      afterCritical: l
    }) || tl({
      pageBorderBoxWithDroppableScroll: c,
      draggable: t,
      destination: p,
      insideDestination: u,
      last: i.displaced,
      viewport: o,
      afterCritical: l
    });
  }), dt = (function(e, r) {
    var t;
    return C({}, e, (t = {}, t[r.descriptor.id] = r, t));
  }), il = function(r) {
    var t = r.previousImpact, n = r.impact, a = r.droppables, i = q(t), o = q(n);
    if (!i || i === o) return a;
    var l = a[i];
    if (!l.subject.withPlaceholder) return a;
    var s = zo(l);
    return dt(a, s);
  }, ol = (function(e) {
    var r = e.draggable, t = e.draggables, n = e.droppables, a = e.previousImpact, i = e.impact, o = il({
      previousImpact: a,
      impact: i,
      droppables: n
    }), l = q(i);
    if (!l) return o;
    var s = n[l];
    if (Ae(r, s) || s.subject.withPlaceholder) return o;
    var d = Jn(s, r, t);
    return dt(o, d);
  }), Le = (function(e) {
    var r = e.state, t = e.clientSelection, n = e.dimensions, a = e.viewport, i = e.impact, o = e.scrollJumpRequest, l = a || r.viewport, s = n || r.dimensions, d = t || r.current.client.selection, p = V(d, r.initial.client.selection), u = {
      offset: p,
      selection: d,
      borderBoxCenter: W(r.initial.client.borderBoxCenter, p)
    }, c = {
      selection: W(u.selection, l.scroll.current),
      borderBoxCenter: W(u.borderBoxCenter, l.scroll.current),
      offset: W(u.offset, l.scroll.diff.value)
    }, v = {
      client: u,
      page: c
    };
    if (r.phase === "COLLECTING") return C({
      phase: "COLLECTING"
    }, r, {
      dimensions: s,
      viewport: l,
      current: v
    });
    var f = s.draggables[r.critical.draggable.id], g = i || Qn({
      pageOffset: c.offset,
      draggable: f,
      draggables: s.draggables,
      droppables: s.droppables,
      previousImpact: r.impact,
      viewport: l,
      afterCritical: r.afterCritical
    }), m = ol({
      draggable: f,
      impact: g,
      previousImpact: r.impact,
      draggables: s.draggables,
      droppables: s.droppables
    }), b = C({}, r, {
      current: v,
      dimensions: {
        draggables: s.draggables,
        droppables: m
      },
      impact: g,
      viewport: l,
      scrollJumpRequest: o || null,
      forceShouldAnimate: o ? false : null
    });
    return b;
  });
  function ll(e, r) {
    return e.map(function(t) {
      return r[t];
    });
  }
  var _n = (function(e) {
    var r = e.impact, t = e.viewport, n = e.draggables, a = e.destination, i = e.forceShouldAnimate, o = r.displaced, l = ll(o.all, n), s = We({
      afterDragging: l,
      destination: a,
      displacedBy: r.displacedBy,
      viewport: t.frame,
      forceShouldAnimate: i,
      last: o
    });
    return C({}, r, {
      displaced: s
    });
  }), ea = (function(e) {
    var r = e.impact, t = e.draggable, n = e.droppable, a = e.draggables, i = e.viewport, o = e.afterCritical, l = wr({
      impact: r,
      draggable: t,
      draggables: a,
      droppable: n,
      afterCritical: o
    });
    return ct({
      pageBorderBoxCenter: l,
      draggable: t,
      viewport: i
    });
  }), ra = (function(e) {
    var r = e.state, t = e.dimensions, n = e.viewport;
    r.movementMode !== "SNAP" && y();
    var a = r.impact, i = n || r.viewport, o = t || r.dimensions, l = o.draggables, s = o.droppables, d = l[r.critical.draggable.id], p = q(a);
    p || y();
    var u = s[p], c = _n({
      impact: a,
      viewport: i,
      destination: u,
      draggables: l
    }), v = ea({
      impact: c,
      draggable: d,
      droppable: u,
      draggables: l,
      viewport: i,
      afterCritical: r.afterCritical
    });
    return Le({
      impact: c,
      clientSelection: v,
      state: r,
      dimensions: o,
      viewport: i
    });
  }), sl = (function(e) {
    return {
      index: e.index,
      droppableId: e.droppableId
    };
  }), ta = (function(e) {
    var r = e.draggable, t = e.home, n = e.draggables, a = e.viewport, i = Qe(t.axis, r.displaceBy), o = Pe(t.descriptor.id, n), l = o.indexOf(r);
    l === -1 && y();
    var s = o.slice(l + 1), d = s.reduce(function(v, f) {
      return v[f.descriptor.id] = true, v;
    }, {}), p = {
      inVirtualList: t.descriptor.mode === "virtual",
      displacedBy: i,
      effected: d
    }, u = We({
      afterDragging: s,
      destination: t,
      displacedBy: i,
      last: null,
      viewport: a.frame,
      forceShouldAnimate: false
    }), c = {
      displaced: u,
      displacedBy: i,
      at: {
        type: "REORDER",
        destination: sl(r.descriptor)
      }
    };
    return {
      impact: c,
      afterCritical: p
    };
  }), ul = (function(e, r) {
    return {
      draggables: e.draggables,
      droppables: dt(e.droppables, r)
    };
  }), cl = (function(e) {
    var r = e.draggable, t = e.offset, n = e.initialWindowScroll, a = dr(r.client, t), i = pr(a, n), o = C({}, r, {
      placeholder: C({}, r.placeholder, {
        client: a
      }),
      client: a,
      page: i
    });
    return o;
  }), dl = (function(e) {
    var r = e.frame;
    return r || y(), r;
  }), pl = (function(e) {
    var r = e.additions, t = e.updatedDroppables, n = e.viewport, a = n.scroll.diff.value;
    return r.map(function(i) {
      var o = i.descriptor.droppableId, l = t[o], s = dl(l), d = s.scroll.diff.value, p = W(a, d), u = cl({
        draggable: i,
        offset: p,
        initialWindowScroll: n.scroll.initial
      });
      return u;
    });
  }), vl = (function(e) {
    var r = e.state, t = e.published, n = t.modified.map(function(x) {
      var D = r.dimensions.droppables[x.droppableId], E = at(D, x.scroll);
      return E;
    }), a = C({}, r.dimensions.droppables, {}, $n(n)), i = kn(pl({
      additions: t.additions,
      updatedDroppables: a,
      viewport: r.viewport
    })), o = C({}, r.dimensions.draggables, {}, i);
    t.removals.forEach(function(x) {
      delete o[x];
    });
    var l = {
      droppables: a,
      draggables: o
    }, s = q(r.impact), d = s ? l.droppables[s] : null, p = l.draggables[r.critical.draggable.id], u = l.droppables[r.critical.droppable.id], c = ta({
      draggable: p,
      home: u,
      draggables: o,
      viewport: r.viewport
    }), v = c.impact, f = c.afterCritical, g = d && d.isCombineEnabled ? r.impact : v, m = Qn({
      pageOffset: r.current.page.offset,
      draggable: l.draggables[r.critical.draggable.id],
      draggables: l.draggables,
      droppables: l.droppables,
      previousImpact: g,
      viewport: r.viewport,
      afterCritical: f
    }), b = C({
      phase: "DRAGGING"
    }, r, {
      phase: "DRAGGING",
      impact: m,
      onLiftImpact: v,
      dimensions: l,
      afterCritical: f,
      forceShouldAnimate: false
    });
    if (r.phase === "COLLECTING") return b;
    var h = C({
      phase: "DROP_PENDING"
    }, b, {
      phase: "DROP_PENDING",
      reason: r.reason,
      isWaiting: false
    });
    return h;
  }), Yr = function(r) {
    return r.movementMode === "SNAP";
  }, $r = function(r, t, n) {
    var a = ul(r.dimensions, t);
    return !Yr(r) || n ? Le({
      state: r,
      dimensions: a
    }) : ra({
      state: r,
      dimensions: a
    });
  };
  function kr(e) {
    return e.isDragging && e.movementMode === "SNAP" ? C({
      phase: "DRAGGING"
    }, e, {
      scrollJumpRequest: null
    }) : e;
  }
  var Kt = {
    phase: "IDLE",
    completed: null,
    shouldFlush: false
  }, fl = (function(e, r) {
    if (e === void 0 && (e = Kt), r.type === "FLUSH") return C({}, Kt, {
      shouldFlush: true
    });
    if (r.type === "INITIAL_PUBLISH") {
      e.phase !== "IDLE" && y();
      var t = r.payload, n = t.critical, a = t.clientSelection, i = t.viewport, o = t.dimensions, l = t.movementMode, s = o.draggables[n.draggable.id], d = o.droppables[n.droppable.id], p = {
        selection: a,
        borderBoxCenter: s.client.borderBox.center,
        offset: $
      }, u = {
        client: p,
        page: {
          selection: W(p.selection, i.scroll.initial),
          borderBoxCenter: W(p.selection, i.scroll.initial),
          offset: W(p.selection, i.scroll.diff.value)
        }
      }, c = xr(o.droppables).every(function(Br) {
        return !Br.isFixedOnPage;
      }), v = ta({
        draggable: s,
        home: d,
        draggables: o.draggables,
        viewport: i
      }), f = v.impact, g = v.afterCritical, m = {
        phase: "DRAGGING",
        isDragging: true,
        critical: n,
        movementMode: l,
        dimensions: o,
        initial: u,
        current: u,
        isWindowScrollAllowed: c,
        impact: f,
        afterCritical: g,
        onLiftImpact: f,
        viewport: i,
        scrollJumpRequest: null,
        forceShouldAnimate: null
      };
      return m;
    }
    if (r.type === "COLLECTION_STARTING") {
      if (e.phase === "COLLECTING" || e.phase === "DROP_PENDING") return e;
      e.phase !== "DRAGGING" && y();
      var b = C({
        phase: "COLLECTING"
      }, e, {
        phase: "COLLECTING"
      });
      return b;
    }
    if (r.type === "PUBLISH_WHILE_DRAGGING") return e.phase === "COLLECTING" || e.phase === "DROP_PENDING" || y(), vl({
      state: e,
      published: r.payload
    });
    if (r.type === "MOVE") {
      if (e.phase === "DROP_PENDING") return e;
      me(e) || y();
      var h = r.payload.client;
      return ce(h, e.current.client.selection) ? e : Le({
        state: e,
        clientSelection: h,
        impact: Yr(e) ? e.impact : null
      });
    }
    if (r.type === "UPDATE_DROPPABLE_SCROLL") {
      if (e.phase === "DROP_PENDING" || e.phase === "COLLECTING") return kr(e);
      me(e) || y();
      var x = r.payload, D = x.id, E = x.newScroll, w = e.dimensions.droppables[D];
      if (!w) return e;
      var B = at(w, E);
      return $r(e, B, false);
    }
    if (r.type === "UPDATE_DROPPABLE_IS_ENABLED") {
      if (e.phase === "DROP_PENDING") return e;
      me(e) || y();
      var M = r.payload, P = M.id, L = M.isEnabled, R = e.dimensions.droppables[P];
      R || y(), R.isEnabled === L && y();
      var Y = C({}, R, {
        isEnabled: L
      });
      return $r(e, Y, true);
    }
    if (r.type === "UPDATE_DROPPABLE_IS_COMBINE_ENABLED") {
      if (e.phase === "DROP_PENDING") return e;
      me(e) || y();
      var J = r.payload, F = J.id, K = J.isCombineEnabled, X = e.dimensions.droppables[F];
      X || y(), X.isCombineEnabled === K && y();
      var he = C({}, X, {
        isCombineEnabled: K
      });
      return $r(e, he, true);
    }
    if (r.type === "MOVE_BY_WINDOW_SCROLL") {
      if (e.phase === "DROP_PENDING" || e.phase === "DROP_ANIMATING") return e;
      me(e) || y(), e.isWindowScrollAllowed || y();
      var oe = r.payload.newScroll;
      if (ce(e.viewport.scroll.current, oe)) return kr(e);
      var ye = qn(e.viewport, oe);
      return Yr(e) ? ra({
        state: e,
        viewport: ye
      }) : Le({
        state: e,
        viewport: ye
      });
    }
    if (r.type === "UPDATE_VIEWPORT_MAX_SCROLL") {
      if (!me(e)) return e;
      var re = r.payload.maxScroll;
      if (ce(re, e.viewport.scroll.max)) return e;
      var fe = C({}, e.viewport, {
        scroll: C({}, e.viewport.scroll, {
          max: re
        })
      });
      return C({
        phase: "DRAGGING"
      }, e, {
        viewport: fe
      });
    }
    if (r.type === "MOVE_UP" || r.type === "MOVE_DOWN" || r.type === "MOVE_LEFT" || r.type === "MOVE_RIGHT") {
      if (e.phase === "COLLECTING" || e.phase === "DROP_PENDING") return e;
      e.phase !== "DRAGGING" && y();
      var j = Xo({
        state: e,
        type: r.type
      });
      return j ? Le({
        state: e,
        impact: j.impact,
        clientSelection: j.clientSelection,
        scrollJumpRequest: j.scrollJumpRequest
      }) : e;
    }
    if (r.type === "DROP_PENDING") {
      var Be = r.payload.reason;
      e.phase !== "COLLECTING" && y();
      var _e = C({
        phase: "DROP_PENDING"
      }, e, {
        phase: "DROP_PENDING",
        isWaiting: true,
        reason: Be
      });
      return _e;
    }
    if (r.type === "DROP_ANIMATE") {
      var le = r.payload, er = le.completed, rr = le.dropDuration, tr = le.newHomeClientOffset;
      e.phase === "DRAGGING" || e.phase === "DROP_PENDING" || y();
      var Ar = {
        phase: "DROP_ANIMATING",
        completed: er,
        dropDuration: rr,
        newHomeClientOffset: tr,
        dimensions: e.dimensions
      };
      return Ar;
    }
    if (r.type === "DROP_COMPLETE") {
      var De = r.payload.completed;
      return {
        phase: "IDLE",
        completed: De,
        shouldFlush: false
      };
    }
    return e;
  }), gl = function(r) {
    return {
      type: "BEFORE_INITIAL_CAPTURE",
      payload: r
    };
  }, ml = function(r) {
    return {
      type: "LIFT",
      payload: r
    };
  }, bl = function(r) {
    return {
      type: "INITIAL_PUBLISH",
      payload: r
    };
  }, hl = function(r) {
    return {
      type: "PUBLISH_WHILE_DRAGGING",
      payload: r
    };
  }, yl = function() {
    return {
      type: "COLLECTION_STARTING",
      payload: null
    };
  }, Dl = function(r) {
    return {
      type: "UPDATE_DROPPABLE_SCROLL",
      payload: r
    };
  }, xl = function(r) {
    return {
      type: "UPDATE_DROPPABLE_IS_ENABLED",
      payload: r
    };
  }, Il = function(r) {
    return {
      type: "UPDATE_DROPPABLE_IS_COMBINE_ENABLED",
      payload: r
    };
  }, na = function(r) {
    return {
      type: "MOVE",
      payload: r
    };
  }, Sl = function(r) {
    return {
      type: "MOVE_BY_WINDOW_SCROLL",
      payload: r
    };
  }, wl = function(r) {
    return {
      type: "UPDATE_VIEWPORT_MAX_SCROLL",
      payload: r
    };
  }, Cl = function() {
    return {
      type: "MOVE_UP",
      payload: null
    };
  }, El = function() {
    return {
      type: "MOVE_DOWN",
      payload: null
    };
  }, Pl = function() {
    return {
      type: "MOVE_RIGHT",
      payload: null
    };
  }, Al = function() {
    return {
      type: "MOVE_LEFT",
      payload: null
    };
  }, pt = function() {
    return {
      type: "FLUSH",
      payload: null
    };
  }, Bl = function(r) {
    return {
      type: "DROP_ANIMATE",
      payload: r
    };
  }, vt = function(r) {
    return {
      type: "DROP_COMPLETE",
      payload: r
    };
  }, aa = function(r) {
    return {
      type: "DROP",
      payload: r
    };
  }, Rl = function(r) {
    return {
      type: "DROP_PENDING",
      payload: r
    };
  }, ia = function() {
    return {
      type: "DROP_ANIMATION_FINISHED",
      payload: null
    };
  }, Ol = (function(e) {
    return function(r) {
      var t = r.getState, n = r.dispatch;
      return function(a) {
        return function(i) {
          if (i.type !== "LIFT") {
            a(i);
            return;
          }
          var o = i.payload, l = o.id, s = o.clientSelection, d = o.movementMode, p = t();
          p.phase === "DROP_ANIMATING" && n(vt({
            completed: p.completed
          })), t().phase !== "IDLE" && y(), n(pt()), n(gl({
            draggableId: l,
            movementMode: d
          }));
          var u = {
            shouldPublishImmediately: d === "SNAP"
          }, c = {
            draggableId: l,
            scrollOptions: u
          }, v = e.startPublishing(c), f = v.critical, g = v.dimensions, m = v.viewport;
          n(bl({
            critical: f,
            dimensions: g,
            clientSelection: s,
            movementMode: d,
            viewport: m
          }));
        };
      };
    };
  }), Tl = (function(e) {
    return function() {
      return function(r) {
        return function(t) {
          t.type === "INITIAL_PUBLISH" && e.dragging(), t.type === "DROP_ANIMATE" && e.dropping(t.payload.completed.result.reason), (t.type === "FLUSH" || t.type === "DROP_COMPLETE") && e.resting(), r(t);
        };
      };
    };
  }), ft = {
    outOfTheWay: "cubic-bezier(0.2, 0, 0, 1)",
    drop: "cubic-bezier(.2,1,.1,1)"
  }, Ue = {
    opacity: {
      drop: 0,
      combining: 0.7
    },
    scale: {
      drop: 0.75
    }
  }, gt = {
    outOfTheWay: 0.2,
    minDropTime: 0.33,
    maxDropTime: 0.55
  }, ge = gt.outOfTheWay + "s " + ft.outOfTheWay, Fe = {
    fluid: "opacity " + ge,
    snap: "transform " + ge + ", opacity " + ge,
    drop: function(r) {
      var t = r + "s " + ft.drop;
      return "transform " + t + ", opacity " + t;
    },
    outOfTheWay: "transform " + ge,
    placeholder: "height " + ge + ", width " + ge + ", margin " + ge
  }, Xt = function(r) {
    return ce(r, $) ? null : "translate(" + r.x + "px, " + r.y + "px)";
  }, Jr = {
    moveTo: Xt,
    drop: function(r, t) {
      var n = Xt(r);
      return n ? t ? n + " scale(" + Ue.scale.drop + ")" : n : null;
    }
  }, Kr = gt.minDropTime, oa = gt.maxDropTime, Nl = oa - Kr, Zt = 1500, Ml = 0.6, Ll = (function(e) {
    var r = e.current, t = e.destination, n = e.reason, a = $e(r, t);
    if (a <= 0) return Kr;
    if (a >= Zt) return oa;
    var i = a / Zt, o = Kr + Nl * i, l = n === "CANCEL" ? o * Ml : o;
    return Number(l.toFixed(2));
  }), Fl = (function(e) {
    var r = e.impact, t = e.draggable, n = e.dimensions, a = e.viewport, i = e.afterCritical, o = n.draggables, l = n.droppables, s = q(r), d = s ? l[s] : null, p = l[t.descriptor.droppableId], u = ea({
      impact: r,
      draggable: t,
      draggables: o,
      afterCritical: i,
      droppable: d || p,
      viewport: a
    }), c = V(u, t.client.borderBox.center);
    return c;
  }), Gl = (function(e) {
    var r = e.draggables, t = e.reason, n = e.lastImpact, a = e.home, i = e.viewport, o = e.onLiftImpact;
    if (!n.at || t !== "DROP") {
      var l = _n({
        draggables: r,
        impact: o,
        destination: a,
        viewport: i,
        forceShouldAnimate: true
      });
      return {
        impact: l,
        didDropInsideDroppable: false
      };
    }
    if (n.at.type === "REORDER") return {
      impact: n,
      didDropInsideDroppable: true
    };
    var s = C({}, n, {
      displaced: ke
    });
    return {
      impact: s,
      didDropInsideDroppable: true
    };
  }), $l = (function(e) {
    var r = e.getState, t = e.dispatch;
    return function(n) {
      return function(a) {
        if (a.type !== "DROP") {
          n(a);
          return;
        }
        var i = r(), o = a.payload.reason;
        if (i.phase === "COLLECTING") {
          t(Rl({
            reason: o
          }));
          return;
        }
        if (i.phase !== "IDLE") {
          var l = i.phase === "DROP_PENDING" && i.isWaiting;
          l && y(), i.phase === "DRAGGING" || i.phase === "DROP_PENDING" || y();
          var s = i.critical, d = i.dimensions, p = d.draggables[i.critical.draggable.id], u = Gl({
            reason: o,
            lastImpact: i.impact,
            afterCritical: i.afterCritical,
            onLiftImpact: i.onLiftImpact,
            home: i.dimensions.droppables[i.critical.droppable.id],
            viewport: i.viewport,
            draggables: i.dimensions.draggables
          }), c = u.impact, v = u.didDropInsideDroppable, f = v ? ot(c) : null, g = v ? Ir(c) : null, m = {
            index: s.draggable.index,
            droppableId: s.droppable.id
          }, b = {
            draggableId: p.descriptor.id,
            type: p.descriptor.type,
            source: m,
            reason: o,
            mode: i.movementMode,
            destination: f,
            combine: g
          }, h = Fl({
            impact: c,
            draggable: p,
            dimensions: d,
            viewport: i.viewport,
            afterCritical: i.afterCritical
          }), x = {
            critical: i.critical,
            afterCritical: i.afterCritical,
            result: b,
            impact: c
          }, D = !ce(i.current.client.offset, h) || !!b.combine;
          if (!D) {
            t(vt({
              completed: x
            }));
            return;
          }
          var E = Ll({
            current: i.current.client.offset,
            destination: h,
            reason: o
          }), w = {
            newHomeClientOffset: h,
            dropDuration: E,
            completed: x
          };
          t(Bl(w));
        }
      };
    };
  }), la = (function() {
    return {
      x: window.pageXOffset,
      y: window.pageYOffset
    };
  });
  function kl(e) {
    return {
      eventName: "scroll",
      options: {
        passive: true,
        capture: false
      },
      fn: function(t) {
        t.target !== window && t.target !== window.document || e();
      }
    };
  }
  function Wl(e) {
    var r = e.onWindowScroll;
    function t() {
      r(la());
    }
    var n = Ge(t), a = kl(n), i = ue;
    function o() {
      return i !== ue;
    }
    function l() {
      o() && y(), i = _(window, [
        a
      ]);
    }
    function s() {
      o() || y(), n.cancel(), i(), i = ue;
    }
    return {
      start: l,
      stop: s,
      isActive: o
    };
  }
  var Ul = function(r) {
    return r.type === "DROP_COMPLETE" || r.type === "DROP_ANIMATE" || r.type === "FLUSH";
  }, Hl = (function(e) {
    var r = Wl({
      onWindowScroll: function(n) {
        e.dispatch(Sl({
          newScroll: n
        }));
      }
    });
    return function(t) {
      return function(n) {
        !r.isActive() && n.type === "INITIAL_PUBLISH" && r.start(), r.isActive() && Ul(n) && r.stop(), t(n);
      };
    };
  }), jl = (function(e) {
    var r = false, t = false, n = setTimeout(function() {
      t = true;
    }), a = function(o) {
      r || t || (r = true, e(o), clearTimeout(n));
    };
    return a.wasCalled = function() {
      return r;
    }, a;
  }), Vl = (function() {
    var e = [], r = function(i) {
      var o = it(e, function(d) {
        return d.timerId === i;
      });
      o === -1 && y();
      var l = e.splice(o, 1), s = l[0];
      s.callback();
    }, t = function(i) {
      var o = setTimeout(function() {
        return r(o);
      }), l = {
        timerId: o,
        callback: i
      };
      e.push(l);
    }, n = function() {
      if (e.length) {
        var i = [].concat(e);
        e.length = 0, i.forEach(function(o) {
          clearTimeout(o.timerId), o.callback();
        });
      }
    };
    return {
      add: t,
      flush: n
    };
  }), ql = function(r, t) {
    return r == null && t == null ? true : r == null || t == null ? false : r.droppableId === t.droppableId && r.index === t.index;
  }, zl = function(r, t) {
    return r == null && t == null ? true : r == null || t == null ? false : r.draggableId === t.draggableId && r.droppableId === t.droppableId;
  }, Yl = function(r, t) {
    if (r === t) return true;
    var n = r.draggable.id === t.draggable.id && r.draggable.droppableId === t.draggable.droppableId && r.draggable.type === t.draggable.type && r.draggable.index === t.draggable.index, a = r.droppable.id === t.droppable.id && r.droppable.type === t.droppable.type;
    return n && a;
  }, Oe = function(r, t) {
    t();
  }, ar = function(r, t) {
    return {
      draggableId: r.draggable.id,
      type: r.droppable.type,
      source: {
        droppableId: r.droppable.id,
        index: r.draggable.index
      },
      mode: t
    };
  }, Wr = function(r, t, n, a) {
    if (!r) {
      n(a(t));
      return;
    }
    var i = jl(n), o = {
      announce: i
    };
    r(t, o), i.wasCalled() || n(a(t));
  }, Jl = (function(e, r) {
    var t = Vl(), n = null, a = function(c, v) {
      n && y(), Oe("onBeforeCapture", function() {
        var f = e().onBeforeCapture;
        if (f) {
          var g = {
            draggableId: c,
            mode: v
          };
          f(g);
        }
      });
    }, i = function(c, v) {
      n && y(), Oe("onBeforeDragStart", function() {
        var f = e().onBeforeDragStart;
        f && f(ar(c, v));
      });
    }, o = function(c, v) {
      n && y();
      var f = ar(c, v);
      n = {
        mode: v,
        lastCritical: c,
        lastLocation: f.source,
        lastCombine: null
      }, t.add(function() {
        Oe("onDragStart", function() {
          return Wr(e().onDragStart, f, r, ur.onDragStart);
        });
      });
    }, l = function(c, v) {
      var f = ot(v), g = Ir(v);
      n || y();
      var m = !Yl(c, n.lastCritical);
      m && (n.lastCritical = c);
      var b = !ql(n.lastLocation, f);
      b && (n.lastLocation = f);
      var h = !zl(n.lastCombine, g);
      if (h && (n.lastCombine = g), !(!m && !b && !h)) {
        var x = C({}, ar(c, n.mode), {
          combine: g,
          destination: f
        });
        t.add(function() {
          Oe("onDragUpdate", function() {
            return Wr(e().onDragUpdate, x, r, ur.onDragUpdate);
          });
        });
      }
    }, s = function() {
      n || y(), t.flush();
    }, d = function(c) {
      n || y(), n = null, Oe("onDragEnd", function() {
        return Wr(e().onDragEnd, c, r, ur.onDragEnd);
      });
    }, p = function() {
      if (n) {
        var c = C({}, ar(n.lastCritical, n.mode), {
          combine: null,
          destination: null,
          reason: "CANCEL"
        });
        d(c);
      }
    };
    return {
      beforeCapture: a,
      beforeStart: i,
      start: o,
      update: l,
      flush: s,
      drop: d,
      abort: p
    };
  }), Kl = (function(e, r) {
    var t = Jl(e, r);
    return function(n) {
      return function(a) {
        return function(i) {
          if (i.type === "BEFORE_INITIAL_CAPTURE") {
            t.beforeCapture(i.payload.draggableId, i.payload.movementMode);
            return;
          }
          if (i.type === "INITIAL_PUBLISH") {
            var o = i.payload.critical;
            t.beforeStart(o, i.payload.movementMode), a(i), t.start(o, i.payload.movementMode);
            return;
          }
          if (i.type === "DROP_COMPLETE") {
            var l = i.payload.completed.result;
            t.flush(), a(i), t.drop(l);
            return;
          }
          if (a(i), i.type === "FLUSH") {
            t.abort();
            return;
          }
          var s = n.getState();
          s.phase === "DRAGGING" && t.update(s.critical, s.impact);
        };
      };
    };
  }), Xl = (function(e) {
    return function(r) {
      return function(t) {
        if (t.type !== "DROP_ANIMATION_FINISHED") {
          r(t);
          return;
        }
        var n = e.getState();
        n.phase !== "DROP_ANIMATING" && y(), e.dispatch(vt({
          completed: n.completed
        }));
      };
    };
  }), Zl = (function(e) {
    var r = null, t = null;
    function n() {
      t && (cancelAnimationFrame(t), t = null), r && (r(), r = null);
    }
    return function(a) {
      return function(i) {
        if ((i.type === "FLUSH" || i.type === "DROP_COMPLETE" || i.type === "DROP_ANIMATION_FINISHED") && n(), a(i), i.type === "DROP_ANIMATE") {
          var o = {
            eventName: "scroll",
            options: {
              capture: true,
              passive: false,
              once: true
            },
            fn: function() {
              var s = e.getState();
              s.phase === "DROP_ANIMATING" && e.dispatch(ia());
            }
          };
          t = requestAnimationFrame(function() {
            t = null, r = _(window, [
              o
            ]);
          });
        }
      };
    };
  }), Ql = (function(e) {
    return function() {
      return function(r) {
        return function(t) {
          (t.type === "DROP_COMPLETE" || t.type === "FLUSH" || t.type === "DROP_ANIMATE") && e.stopPublishing(), r(t);
        };
      };
    };
  }), _l = (function(e) {
    var r = false;
    return function() {
      return function(t) {
        return function(n) {
          if (n.type === "INITIAL_PUBLISH") {
            r = true, e.tryRecordFocus(n.payload.critical.draggable.id), t(n), e.tryRestoreFocusRecorded();
            return;
          }
          if (t(n), !!r) {
            if (n.type === "FLUSH") {
              r = false, e.tryRestoreFocusRecorded();
              return;
            }
            if (n.type === "DROP_COMPLETE") {
              r = false;
              var a = n.payload.completed.result;
              a.combine && e.tryShiftRecord(a.draggableId, a.combine.draggableId), e.tryRestoreFocusRecorded();
            }
          }
        };
      };
    };
  }), es = function(r) {
    return r.type === "DROP_COMPLETE" || r.type === "DROP_ANIMATE" || r.type === "FLUSH";
  }, rs = (function(e) {
    return function(r) {
      return function(t) {
        return function(n) {
          if (es(n)) {
            e.stop(), t(n);
            return;
          }
          if (n.type === "INITIAL_PUBLISH") {
            t(n);
            var a = r.getState();
            a.phase !== "DRAGGING" && y(), e.start(a);
            return;
          }
          t(n), e.scroll(r.getState());
        };
      };
    };
  }), ts = (function(e) {
    return function(r) {
      return function(t) {
        if (r(t), t.type === "PUBLISH_WHILE_DRAGGING") {
          var n = e.getState();
          n.phase === "DROP_PENDING" && (n.isWaiting || e.dispatch(aa({
            reason: n.reason
          })));
        }
      };
    };
  }), ns = bn, as = (function(e) {
    var r = e.dimensionMarshal, t = e.focusMarshal, n = e.styleMarshal, a = e.getResponders, i = e.announce, o = e.autoScroller;
    return mn(fl, ns(ni(Tl(n), Ql(r), Ol(r), $l, Xl, Zl, ts, rs(o), Hl, _l(t), Kl(a, i))));
  }), Ur = function() {
    return {
      additions: {},
      removals: {},
      modified: {}
    };
  };
  function is(e) {
    var r = e.registry, t = e.callbacks, n = Ur(), a = null, i = function() {
      a || (t.collectionStarting(), a = requestAnimationFrame(function() {
        a = null;
        var p = n, u = p.additions, c = p.removals, v = p.modified, f = Object.keys(u).map(function(b) {
          return r.draggable.getById(b).getDimension($);
        }).sort(function(b, h) {
          return b.descriptor.index - h.descriptor.index;
        }), g = Object.keys(v).map(function(b) {
          var h = r.droppable.getById(b), x = h.callbacks.getScrollWhileDragging();
          return {
            droppableId: b,
            scroll: x
          };
        }), m = {
          additions: f,
          removals: Object.keys(c),
          modified: g
        };
        n = Ur(), t.publish(m);
      }));
    }, o = function(p) {
      var u = p.descriptor.id;
      n.additions[u] = p, n.modified[p.descriptor.droppableId] = true, n.removals[u] && delete n.removals[u], i();
    }, l = function(p) {
      var u = p.descriptor;
      n.removals[u.id] = true, n.modified[u.droppableId] = true, n.additions[u.id] && delete n.additions[u.id], i();
    }, s = function() {
      a && (cancelAnimationFrame(a), a = null, n = Ur());
    };
    return {
      add: o,
      remove: l,
      stop: s
    };
  }
  var sa = (function(e) {
    var r = e.scrollHeight, t = e.scrollWidth, n = e.height, a = e.width, i = V({
      x: t,
      y: r
    }, {
      x: a,
      y: n
    }), o = {
      x: Math.max(0, i.x),
      y: Math.max(0, i.y)
    };
    return o;
  }), ua = (function() {
    var e = document.documentElement;
    return e || y(), e;
  }), ca = (function() {
    var e = ua(), r = sa({
      scrollHeight: e.scrollHeight,
      scrollWidth: e.scrollWidth,
      width: e.clientWidth,
      height: e.clientHeight
    });
    return r;
  }), os = (function() {
    var e = la(), r = ca(), t = e.y, n = e.x, a = ua(), i = a.clientWidth, o = a.clientHeight, l = n + i, s = t + o, d = te({
      top: t,
      left: n,
      right: l,
      bottom: s
    }), p = {
      frame: d,
      scroll: {
        initial: e,
        current: e,
        max: r,
        diff: {
          value: $,
          displacement: $
        }
      }
    };
    return p;
  }), ls = (function(e) {
    var r = e.critical, t = e.scrollOptions, n = e.registry, a = os(), i = a.scroll.current, o = r.droppable, l = n.droppable.getAllByType(o.type).map(function(u) {
      return u.callbacks.getDimensionAndWatchScroll(i, t);
    }), s = n.draggable.getAllByType(r.draggable.type).map(function(u) {
      return u.getDimension(i);
    }), d = {
      draggables: kn(s),
      droppables: $n(l)
    }, p = {
      dimensions: d,
      critical: r,
      viewport: a
    };
    return p;
  });
  function Qt(e, r, t) {
    if (t.descriptor.id === r.id || t.descriptor.type !== r.type) return false;
    var n = e.droppable.getById(t.descriptor.droppableId);
    return n.descriptor.mode === "virtual";
  }
  var ss = (function(e, r) {
    var t = null, n = is({
      callbacks: {
        publish: r.publishWhileDragging,
        collectionStarting: r.collectionStarting
      },
      registry: e
    }), a = function(v, f) {
      e.droppable.exists(v) || y(), t && r.updateDroppableIsEnabled({
        id: v,
        isEnabled: f
      });
    }, i = function(v, f) {
      t && (e.droppable.exists(v) || y(), r.updateDroppableIsCombineEnabled({
        id: v,
        isCombineEnabled: f
      }));
    }, o = function(v, f) {
      t && (e.droppable.exists(v) || y(), r.updateDroppableScroll({
        id: v,
        newScroll: f
      }));
    }, l = function(v, f) {
      t && e.droppable.getById(v).callbacks.scroll(f);
    }, s = function() {
      if (t) {
        n.stop();
        var v = t.critical.droppable;
        e.droppable.getAllByType(v.type).forEach(function(f) {
          return f.callbacks.dragStopped();
        }), t.unsubscribe(), t = null;
      }
    }, d = function(v) {
      t || y();
      var f = t.critical.draggable;
      v.type === "ADDITION" && Qt(e, f, v.value) && n.add(v.value), v.type === "REMOVAL" && Qt(e, f, v.value) && n.remove(v.value);
    }, p = function(v) {
      t && y();
      var f = e.draggable.getById(v.draggableId), g = e.droppable.getById(f.descriptor.droppableId), m = {
        draggable: f.descriptor,
        droppable: g.descriptor
      }, b = e.subscribe(d);
      return t = {
        critical: m,
        unsubscribe: b
      }, ls({
        critical: m,
        registry: e,
        scrollOptions: v.scrollOptions
      });
    }, u = {
      updateDroppableIsEnabled: a,
      updateDroppableIsCombineEnabled: i,
      scrollDroppable: l,
      updateDroppableScroll: o,
      startPublishing: p,
      stopPublishing: s
    };
    return u;
  }), da = (function(e, r) {
    return e.phase === "IDLE" ? true : e.phase !== "DROP_ANIMATING" || e.completed.result.draggableId === r ? false : e.completed.result.reason === "DROP";
  }), us = (function(e) {
    window.scrollBy(e.x, e.y);
  }), cs = G(function(e) {
    return xr(e).filter(function(r) {
      return !(!r.isEnabled || !r.frame);
    });
  }), ds = function(r, t) {
    var n = ve(cs(t), function(a) {
      return a.frame || y(), Kn(a.frame.pageMarginBox)(r);
    });
    return n;
  }, ps = (function(e) {
    var r = e.center, t = e.destination, n = e.droppables;
    if (t) {
      var a = n[t];
      return a.frame ? a : null;
    }
    var i = ds(r, n);
    return i;
  }), de = {
    startFromPercentage: 0.25,
    maxScrollAtPercentage: 0.05,
    maxPixelScroll: 28,
    ease: function(r) {
      return Math.pow(r, 2);
    },
    durationDampening: {
      stopDampeningAt: 1200,
      accelerateAt: 360
    }
  }, vs = (function(e, r) {
    var t = e[r.size] * de.startFromPercentage, n = e[r.size] * de.maxScrollAtPercentage, a = {
      startScrollingFrom: t,
      maxScrollValueAt: n
    };
    return a;
  }), pa = (function(e) {
    var r = e.startOfRange, t = e.endOfRange, n = e.current, a = t - r;
    if (a === 0) return 0;
    var i = n - r, o = i / a;
    return o;
  }), mt = 1, fs = (function(e, r) {
    if (e > r.startScrollingFrom) return 0;
    if (e <= r.maxScrollValueAt) return de.maxPixelScroll;
    if (e === r.startScrollingFrom) return mt;
    var t = pa({
      startOfRange: r.maxScrollValueAt,
      endOfRange: r.startScrollingFrom,
      current: e
    }), n = 1 - t, a = de.maxPixelScroll * de.ease(n);
    return Math.ceil(a);
  }), _t = de.durationDampening.accelerateAt, en = de.durationDampening.stopDampeningAt, gs = (function(e, r) {
    var t = r, n = en, a = Date.now(), i = a - t;
    if (i >= en) return e;
    if (i < _t) return mt;
    var o = pa({
      startOfRange: _t,
      endOfRange: n,
      current: i
    }), l = e * de.ease(o);
    return Math.ceil(l);
  }), rn = (function(e) {
    var r = e.distanceToEdge, t = e.thresholds, n = e.dragStartTime, a = e.shouldUseTimeDampening, i = fs(r, t);
    return i === 0 ? 0 : a ? Math.max(gs(i, n), mt) : i;
  }), tn = (function(e) {
    var r = e.container, t = e.distanceToEdges, n = e.dragStartTime, a = e.axis, i = e.shouldUseTimeDampening, o = vs(r, a), l = t[a.end] < t[a.start];
    return l ? rn({
      distanceToEdge: t[a.end],
      thresholds: o,
      dragStartTime: n,
      shouldUseTimeDampening: i
    }) : -1 * rn({
      distanceToEdge: t[a.start],
      thresholds: o,
      dragStartTime: n,
      shouldUseTimeDampening: i
    });
  }), ms = (function(e) {
    var r = e.container, t = e.subject, n = e.proposedScroll, a = t.height > r.height, i = t.width > r.width;
    return !i && !a ? n : i && a ? null : {
      x: i ? 0 : n.x,
      y: a ? 0 : n.y
    };
  }), bs = Fn(function(e) {
    return e === 0 ? 0 : e;
  }), va = (function(e) {
    var r = e.dragStartTime, t = e.container, n = e.subject, a = e.center, i = e.shouldUseTimeDampening, o = {
      top: a.y - t.top,
      right: t.right - a.x,
      bottom: t.bottom - a.y,
      left: a.x - t.left
    }, l = tn({
      container: t,
      distanceToEdges: o,
      dragStartTime: r,
      axis: lt,
      shouldUseTimeDampening: i
    }), s = tn({
      container: t,
      distanceToEdges: o,
      dragStartTime: r,
      axis: Hn,
      shouldUseTimeDampening: i
    }), d = bs({
      x: s,
      y: l
    });
    if (ce(d, $)) return null;
    var p = ms({
      container: t,
      subject: n,
      proposedScroll: d
    });
    return p ? ce(p, $) ? null : p : null;
  }), hs = Fn(function(e) {
    return e === 0 ? 0 : e > 0 ? 1 : -1;
  }), bt = /* @__PURE__ */ (function() {
    var e = function(t, n) {
      return t < 0 ? t : t > n ? t - n : 0;
    };
    return function(r) {
      var t = r.current, n = r.max, a = r.change, i = W(t, a), o = {
        x: e(i.x, n.x),
        y: e(i.y, n.y)
      };
      return ce(o, $) ? null : o;
    };
  })(), fa = function(r) {
    var t = r.max, n = r.current, a = r.change, i = {
      x: Math.max(n.x, t.x),
      y: Math.max(n.y, t.y)
    }, o = hs(a), l = bt({
      max: i,
      current: n,
      change: o
    });
    return !l || o.x !== 0 && l.x === 0 || o.y !== 0 && l.y === 0;
  }, ht = function(r, t) {
    return fa({
      current: r.scroll.current,
      max: r.scroll.max,
      change: t
    });
  }, ys = function(r, t) {
    if (!ht(r, t)) return null;
    var n = r.scroll.max, a = r.scroll.current;
    return bt({
      current: a,
      max: n,
      change: t
    });
  }, yt = function(r, t) {
    var n = r.frame;
    return n ? fa({
      current: n.scroll.current,
      max: n.scroll.max,
      change: t
    }) : false;
  }, Ds = function(r, t) {
    var n = r.frame;
    return !n || !yt(r, t) ? null : bt({
      current: n.scroll.current,
      max: n.scroll.max,
      change: t
    });
  }, xs = (function(e) {
    var r = e.viewport, t = e.subject, n = e.center, a = e.dragStartTime, i = e.shouldUseTimeDampening, o = va({
      dragStartTime: a,
      container: r.frame,
      subject: t,
      center: n,
      shouldUseTimeDampening: i
    });
    return o && ht(r, o) ? o : null;
  }), Is = (function(e) {
    var r = e.droppable, t = e.subject, n = e.center, a = e.dragStartTime, i = e.shouldUseTimeDampening, o = r.frame;
    if (!o) return null;
    var l = va({
      dragStartTime: a,
      container: o.pageMarginBox,
      subject: t,
      center: n,
      shouldUseTimeDampening: i
    });
    return l && yt(r, l) ? l : null;
  }), nn = (function(e) {
    var r = e.state, t = e.dragStartTime, n = e.shouldUseTimeDampening, a = e.scrollWindow, i = e.scrollDroppable, o = r.current.page.borderBoxCenter, l = r.dimensions.draggables[r.critical.draggable.id], s = l.page.marginBox;
    if (r.isWindowScrollAllowed) {
      var d = r.viewport, p = xs({
        dragStartTime: t,
        viewport: d,
        subject: s,
        center: o,
        shouldUseTimeDampening: n
      });
      if (p) {
        a(p);
        return;
      }
    }
    var u = ps({
      center: o,
      destination: q(r.impact),
      droppables: r.dimensions.droppables
    });
    if (u) {
      var c = Is({
        dragStartTime: t,
        droppable: u,
        subject: s,
        center: o,
        shouldUseTimeDampening: n
      });
      c && i(u.descriptor.id, c);
    }
  }), Ss = (function(e) {
    var r = e.scrollWindow, t = e.scrollDroppable, n = Ge(r), a = Ge(t), i = null, o = function(p) {
      i || y();
      var u = i, c = u.shouldUseTimeDampening, v = u.dragStartTime;
      nn({
        state: p,
        scrollWindow: n,
        scrollDroppable: a,
        dragStartTime: v,
        shouldUseTimeDampening: c
      });
    }, l = function(p) {
      i && y();
      var u = Date.now(), c = false, v = function() {
        c = true;
      };
      nn({
        state: p,
        dragStartTime: 0,
        shouldUseTimeDampening: false,
        scrollWindow: v,
        scrollDroppable: v
      }), i = {
        dragStartTime: u,
        shouldUseTimeDampening: c
      }, c && o(p);
    }, s = function() {
      i && (n.cancel(), a.cancel(), i = null);
    };
    return {
      start: l,
      stop: s,
      scroll: o
    };
  }), ws = (function(e) {
    var r = e.move, t = e.scrollDroppable, n = e.scrollWindow, a = function(d, p) {
      var u = W(d.current.client.selection, p);
      r({
        client: u
      });
    }, i = function(d, p) {
      if (!yt(d, p)) return p;
      var u = Ds(d, p);
      if (!u) return t(d.descriptor.id, p), null;
      var c = V(p, u);
      t(d.descriptor.id, c);
      var v = V(p, c);
      return v;
    }, o = function(d, p, u) {
      if (!d || !ht(p, u)) return u;
      var c = ys(p, u);
      if (!c) return n(u), null;
      var v = V(u, c);
      n(v);
      var f = V(u, v);
      return f;
    }, l = function(d) {
      var p = d.scrollJumpRequest;
      if (p) {
        var u = q(d.impact);
        u || y();
        var c = i(d.dimensions.droppables[u], p);
        if (c) {
          var v = d.viewport, f = o(d.isWindowScrollAllowed, v, c);
          f && a(d, f);
        }
      }
    };
    return l;
  }), Cs = (function(e) {
    var r = e.scrollDroppable, t = e.scrollWindow, n = e.move, a = Ss({
      scrollWindow: t,
      scrollDroppable: r
    }), i = ws({
      move: n,
      scrollWindow: t,
      scrollDroppable: r
    }), o = function(d) {
      if (d.phase === "DRAGGING") {
        if (d.movementMode === "FLUID") {
          a.scroll(d);
          return;
        }
        d.scrollJumpRequest && i(d);
      }
    }, l = {
      scroll: o,
      start: a.start,
      stop: a.stop
    };
    return l;
  }), we = "data-rbd", Ce = (function() {
    var e = we + "-drag-handle";
    return {
      base: e,
      draggableId: e + "-draggable-id",
      contextId: e + "-context-id"
    };
  })(), Xr = (function() {
    var e = we + "-draggable";
    return {
      base: e,
      contextId: e + "-context-id",
      id: e + "-id"
    };
  })(), Es = (function() {
    var e = we + "-droppable";
    return {
      base: e,
      contextId: e + "-context-id",
      id: e + "-id"
    };
  })(), an = {
    contextId: we + "-scroll-container-context-id"
  }, Ps = function(r) {
    return function(t) {
      return "[" + t + '="' + r + '"]';
    };
  }, Te = function(r, t) {
    return r.map(function(n) {
      var a = n.styles[t];
      return a ? n.selector + " { " + a + " }" : "";
    }).join(" ");
  }, As = "pointer-events: none;", Bs = (function(e) {
    var r = Ps(e), t = (function() {
      var l = `
      cursor: -webkit-grab;
      cursor: grab;
    `;
      return {
        selector: r(Ce.contextId),
        styles: {
          always: `
          -webkit-touch-callout: none;
          -webkit-tap-highlight-color: rgba(0,0,0,0);
          touch-action: manipulation;
        `,
          resting: l,
          dragging: As,
          dropAnimating: l
        }
      };
    })(), n = (function() {
      var l = `
      transition: ` + Fe.outOfTheWay + `;
    `;
      return {
        selector: r(Xr.contextId),
        styles: {
          dragging: l,
          dropAnimating: l,
          userCancel: l
        }
      };
    })(), a = {
      selector: r(Es.contextId),
      styles: {
        always: "overflow-anchor: none;"
      }
    }, i = {
      selector: "body",
      styles: {
        dragging: `
        cursor: grabbing;
        cursor: -webkit-grabbing;
        user-select: none;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        overflow-anchor: none;
      `
      }
    }, o = [
      n,
      t,
      a,
      i
    ];
    return {
      always: Te(o, "always"),
      resting: Te(o, "resting"),
      dragging: Te(o, "dragging"),
      dropAnimating: Te(o, "dropAnimating"),
      userCancel: Te(o, "userCancel")
    };
  }), z = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u" ? fn : ie, Hr = function() {
    var r = document.querySelector("head");
    return r || y(), r;
  }, on = function(r) {
    var t = document.createElement("style");
    return r && t.setAttribute("nonce", r), t.type = "text/css", t;
  };
  function Rs(e, r) {
    var t = A(function() {
      return Bs(e);
    }, [
      e
    ]), n = O(null), a = O(null), i = I(G(function(u) {
      var c = a.current;
      c || y(), c.textContent = u;
    }), []), o = I(function(u) {
      var c = n.current;
      c || y(), c.textContent = u;
    }, []);
    z(function() {
      !n.current && !a.current || y();
      var u = on(r), c = on(r);
      return n.current = u, a.current = c, u.setAttribute(we + "-always", e), c.setAttribute(we + "-dynamic", e), Hr().appendChild(u), Hr().appendChild(c), o(t.always), i(t.resting), function() {
        var v = function(g) {
          var m = g.current;
          m || y(), Hr().removeChild(m), g.current = null;
        };
        v(n), v(a);
      };
    }, [
      r,
      o,
      i,
      t.always,
      t.resting,
      e
    ]);
    var l = I(function() {
      return i(t.dragging);
    }, [
      i,
      t.dragging
    ]), s = I(function(u) {
      if (u === "DROP") {
        i(t.dropAnimating);
        return;
      }
      i(t.userCancel);
    }, [
      i,
      t.dropAnimating,
      t.userCancel
    ]), d = I(function() {
      a.current && i(t.resting);
    }, [
      i,
      t.resting
    ]), p = A(function() {
      return {
        dragging: l,
        dropping: s,
        resting: d
      };
    }, [
      l,
      s,
      d
    ]);
    return p;
  }
  var ga = (function(e) {
    return e && e.ownerDocument ? e.ownerDocument.defaultView : window;
  });
  function Cr(e) {
    return e instanceof ga(e).HTMLElement;
  }
  function Os(e, r) {
    var t = "[" + Ce.contextId + '="' + e + '"]', n = Gn(document.querySelectorAll(t));
    if (!n.length) return null;
    var a = ve(n, function(i) {
      return i.getAttribute(Ce.draggableId) === r;
    });
    return !a || !Cr(a) ? null : a;
  }
  function Ts(e) {
    var r = O({}), t = O(null), n = O(null), a = O(false), i = I(function(c, v) {
      var f = {
        id: c,
        focus: v
      };
      return r.current[c] = f, function() {
        var m = r.current, b = m[c];
        b !== f && delete m[c];
      };
    }, []), o = I(function(c) {
      var v = Os(e, c);
      v && v !== document.activeElement && v.focus();
    }, [
      e
    ]), l = I(function(c, v) {
      t.current === c && (t.current = v);
    }, []), s = I(function() {
      n.current || a.current && (n.current = requestAnimationFrame(function() {
        n.current = null;
        var c = t.current;
        c && o(c);
      }));
    }, [
      o
    ]), d = I(function(c) {
      t.current = null;
      var v = document.activeElement;
      v && v.getAttribute(Ce.draggableId) === c && (t.current = c);
    }, []);
    z(function() {
      return a.current = true, function() {
        a.current = false;
        var c = n.current;
        c && cancelAnimationFrame(c);
      };
    }, []);
    var p = A(function() {
      return {
        register: i,
        tryRecordFocus: d,
        tryRestoreFocusRecorded: s,
        tryShiftRecord: l
      };
    }, [
      i,
      d,
      s,
      l
    ]);
    return p;
  }
  function Ns() {
    var e = {
      draggables: {},
      droppables: {}
    }, r = [];
    function t(u) {
      return r.push(u), function() {
        var v = r.indexOf(u);
        v !== -1 && r.splice(v, 1);
      };
    }
    function n(u) {
      r.length && r.forEach(function(c) {
        return c(u);
      });
    }
    function a(u) {
      return e.draggables[u] || null;
    }
    function i(u) {
      var c = a(u);
      return c || y(), c;
    }
    var o = {
      register: function(c) {
        e.draggables[c.descriptor.id] = c, n({
          type: "ADDITION",
          value: c
        });
      },
      update: function(c, v) {
        var f = e.draggables[v.descriptor.id];
        f && f.uniqueId === c.uniqueId && (delete e.draggables[v.descriptor.id], e.draggables[c.descriptor.id] = c);
      },
      unregister: function(c) {
        var v = c.descriptor.id, f = a(v);
        f && c.uniqueId === f.uniqueId && (delete e.draggables[v], n({
          type: "REMOVAL",
          value: c
        }));
      },
      getById: i,
      findById: a,
      exists: function(c) {
        return !!a(c);
      },
      getAllByType: function(c) {
        return gr(e.draggables).filter(function(v) {
          return v.descriptor.type === c;
        });
      }
    };
    function l(u) {
      return e.droppables[u] || null;
    }
    function s(u) {
      var c = l(u);
      return c || y(), c;
    }
    var d = {
      register: function(c) {
        e.droppables[c.descriptor.id] = c;
      },
      unregister: function(c) {
        var v = l(c.descriptor.id);
        v && c.uniqueId === v.uniqueId && delete e.droppables[c.descriptor.id];
      },
      getById: s,
      findById: l,
      exists: function(c) {
        return !!l(c);
      },
      getAllByType: function(c) {
        return gr(e.droppables).filter(function(v) {
          return v.descriptor.type === c;
        });
      }
    };
    function p() {
      e.draggables = {}, e.droppables = {}, r.length = 0;
    }
    return {
      draggable: o,
      droppable: d,
      subscribe: t,
      clean: p
    };
  }
  function Ms() {
    var e = A(Ns, []);
    return ie(function() {
      return function() {
        requestAnimationFrame(e.clean);
      };
    }, [
      e
    ]), e;
  }
  var Dt = N.createContext(null), br = (function() {
    var e = document.body;
    return e || y(), e;
  }), Ls = {
    position: "absolute",
    width: "1px",
    height: "1px",
    margin: "-1px",
    border: "0",
    padding: "0",
    overflow: "hidden",
    clip: "rect(0 0 0 0)",
    "clip-path": "inset(100%)"
  }, Fs = function(r) {
    return "rbd-announcement-" + r;
  };
  function Gs(e) {
    var r = A(function() {
      return Fs(e);
    }, [
      e
    ]), t = O(null);
    ie(function() {
      var i = document.createElement("div");
      return t.current = i, i.id = r, i.setAttribute("aria-live", "assertive"), i.setAttribute("aria-atomic", "true"), C(i.style, Ls), br().appendChild(i), function() {
        setTimeout(function() {
          var s = br();
          s.contains(i) && s.removeChild(i), i === t.current && (t.current = null);
        });
      };
    }, [
      r
    ]);
    var n = I(function(a) {
      var i = t.current;
      if (i) {
        i.textContent = a;
        return;
      }
    }, []);
    return n;
  }
  var $s = 0, ks = {
    separator: "::"
  };
  function xt(e, r) {
    return r === void 0 && (r = ks), A(function() {
      return "" + e + r.separator + $s++;
    }, [
      r.separator,
      e
    ]);
  }
  function Ws(e) {
    var r = e.contextId, t = e.uniqueId;
    return "rbd-hidden-text-" + r + "-" + t;
  }
  function Us(e) {
    var r = e.contextId, t = e.text, n = xt("hidden-text", {
      separator: "-"
    }), a = A(function() {
      return Ws({
        contextId: r,
        uniqueId: n
      });
    }, [
      n,
      r
    ]);
    return ie(function() {
      var o = document.createElement("div");
      return o.id = a, o.textContent = t, o.style.display = "none", br().appendChild(o), function() {
        var s = br();
        s.contains(o) && s.removeChild(o);
      };
    }, [
      a,
      t
    ]), a;
  }
  var Er = N.createContext(null);
  function ma(e) {
    var r = O(e);
    return ie(function() {
      r.current = e;
    }), r;
  }
  function Hs() {
    var e = null;
    function r() {
      return !!e;
    }
    function t(o) {
      return o === e;
    }
    function n(o) {
      e && y();
      var l = {
        abandon: o
      };
      return e = l, l;
    }
    function a() {
      e || y(), e = null;
    }
    function i() {
      e && (e.abandon(), a());
    }
    return {
      isClaimed: r,
      isActive: t,
      claim: n,
      release: a,
      tryAbandon: i
    };
  }
  var js = 9, Vs = 13, It = 27, ba = 32, qs = 33, zs = 34, Ys = 35, Js = 36, Ks = 37, Xs = 38, Zs = 39, Qs = 40, ir, _s = (ir = {}, ir[Vs] = true, ir[js] = true, ir), ha = (function(e) {
    _s[e.keyCode] && e.preventDefault();
  }), Pr = (function() {
    var e = "visibilitychange";
    if (typeof document > "u") return e;
    var r = [
      e,
      "ms" + e,
      "webkit" + e,
      "moz" + e,
      "o" + e
    ], t = ve(r, function(n) {
      return "on" + n in document;
    });
    return t || e;
  })(), ya = 0, ln = 5;
  function eu(e, r) {
    return Math.abs(r.x - e.x) >= ln || Math.abs(r.y - e.y) >= ln;
  }
  var sn = {
    type: "IDLE"
  };
  function ru(e) {
    var r = e.cancel, t = e.completed, n = e.getPhase, a = e.setPhase;
    return [
      {
        eventName: "mousemove",
        fn: function(o) {
          var l = o.button, s = o.clientX, d = o.clientY;
          if (l === ya) {
            var p = {
              x: s,
              y: d
            }, u = n();
            if (u.type === "DRAGGING") {
              o.preventDefault(), u.actions.move(p);
              return;
            }
            u.type !== "PENDING" && y();
            var c = u.point;
            if (eu(c, p)) {
              o.preventDefault();
              var v = u.actions.fluidLift(p);
              a({
                type: "DRAGGING",
                actions: v
              });
            }
          }
        }
      },
      {
        eventName: "mouseup",
        fn: function(o) {
          var l = n();
          if (l.type !== "DRAGGING") {
            r();
            return;
          }
          o.preventDefault(), l.actions.drop({
            shouldBlockNextClick: true
          }), t();
        }
      },
      {
        eventName: "mousedown",
        fn: function(o) {
          n().type === "DRAGGING" && o.preventDefault(), r();
        }
      },
      {
        eventName: "keydown",
        fn: function(o) {
          var l = n();
          if (l.type === "PENDING") {
            r();
            return;
          }
          if (o.keyCode === It) {
            o.preventDefault(), r();
            return;
          }
          ha(o);
        }
      },
      {
        eventName: "resize",
        fn: r
      },
      {
        eventName: "scroll",
        options: {
          passive: true,
          capture: false
        },
        fn: function() {
          n().type === "PENDING" && r();
        }
      },
      {
        eventName: "webkitmouseforcedown",
        fn: function(o) {
          var l = n();
          if (l.type === "IDLE" && y(), l.actions.shouldRespectForcePress()) {
            r();
            return;
          }
          o.preventDefault();
        }
      },
      {
        eventName: Pr,
        fn: r
      }
    ];
  }
  function tu(e) {
    var r = O(sn), t = O(ue), n = A(function() {
      return {
        eventName: "mousedown",
        fn: function(u) {
          if (!u.defaultPrevented && u.button === ya && !(u.ctrlKey || u.metaKey || u.shiftKey || u.altKey)) {
            var c = e.findClosestDraggableId(u);
            if (c) {
              var v = e.tryGetLock(c, o, {
                sourceEvent: u
              });
              if (v) {
                u.preventDefault();
                var f = {
                  x: u.clientX,
                  y: u.clientY
                };
                t.current(), d(v, f);
              }
            }
          }
        }
      };
    }, [
      e
    ]), a = A(function() {
      return {
        eventName: "webkitmouseforcewillbegin",
        fn: function(u) {
          if (!u.defaultPrevented) {
            var c = e.findClosestDraggableId(u);
            if (c) {
              var v = e.findOptionsForDraggable(c);
              v && (v.shouldRespectForcePress || e.canGetLock(c) && u.preventDefault());
            }
          }
        }
      };
    }, [
      e
    ]), i = I(function() {
      var u = {
        passive: false,
        capture: true
      };
      t.current = _(window, [
        a,
        n
      ], u);
    }, [
      a,
      n
    ]), o = I(function() {
      var p = r.current;
      p.type !== "IDLE" && (r.current = sn, t.current(), i());
    }, [
      i
    ]), l = I(function() {
      var p = r.current;
      o(), p.type === "DRAGGING" && p.actions.cancel({
        shouldBlockNextClick: true
      }), p.type === "PENDING" && p.actions.abort();
    }, [
      o
    ]), s = I(function() {
      var u = {
        capture: true,
        passive: false
      }, c = ru({
        cancel: l,
        completed: o,
        getPhase: function() {
          return r.current;
        },
        setPhase: function(f) {
          r.current = f;
        }
      });
      t.current = _(window, c, u);
    }, [
      l,
      o
    ]), d = I(function(u, c) {
      r.current.type !== "IDLE" && y(), r.current = {
        type: "PENDING",
        point: c,
        actions: u
      }, s();
    }, [
      s
    ]);
    z(function() {
      return i(), function() {
        t.current();
      };
    }, [
      i
    ]);
  }
  var xe;
  function nu() {
  }
  var au = (xe = {}, xe[zs] = true, xe[qs] = true, xe[Js] = true, xe[Ys] = true, xe);
  function iu(e, r) {
    function t() {
      r(), e.cancel();
    }
    function n() {
      r(), e.drop();
    }
    return [
      {
        eventName: "keydown",
        fn: function(i) {
          if (i.keyCode === It) {
            i.preventDefault(), t();
            return;
          }
          if (i.keyCode === ba) {
            i.preventDefault(), n();
            return;
          }
          if (i.keyCode === Qs) {
            i.preventDefault(), e.moveDown();
            return;
          }
          if (i.keyCode === Xs) {
            i.preventDefault(), e.moveUp();
            return;
          }
          if (i.keyCode === Zs) {
            i.preventDefault(), e.moveRight();
            return;
          }
          if (i.keyCode === Ks) {
            i.preventDefault(), e.moveLeft();
            return;
          }
          if (au[i.keyCode]) {
            i.preventDefault();
            return;
          }
          ha(i);
        }
      },
      {
        eventName: "mousedown",
        fn: t
      },
      {
        eventName: "mouseup",
        fn: t
      },
      {
        eventName: "click",
        fn: t
      },
      {
        eventName: "touchstart",
        fn: t
      },
      {
        eventName: "resize",
        fn: t
      },
      {
        eventName: "wheel",
        fn: t,
        options: {
          passive: true
        }
      },
      {
        eventName: Pr,
        fn: t
      }
    ];
  }
  function ou(e) {
    var r = O(nu), t = A(function() {
      return {
        eventName: "keydown",
        fn: function(i) {
          if (i.defaultPrevented || i.keyCode !== ba) return;
          var o = e.findClosestDraggableId(i);
          if (!o) return;
          var l = e.tryGetLock(o, p, {
            sourceEvent: i
          });
          if (!l) return;
          i.preventDefault();
          var s = true, d = l.snapLift();
          r.current();
          function p() {
            s || y(), s = false, r.current(), n();
          }
          r.current = _(window, iu(d, p), {
            capture: true,
            passive: false
          });
        }
      };
    }, [
      e
    ]), n = I(function() {
      var i = {
        passive: false,
        capture: true
      };
      r.current = _(window, [
        t
      ], i);
    }, [
      t
    ]);
    z(function() {
      return n(), function() {
        r.current();
      };
    }, [
      n
    ]);
  }
  var jr = {
    type: "IDLE"
  }, lu = 120, su = 0.15;
  function uu(e) {
    var r = e.cancel, t = e.getPhase;
    return [
      {
        eventName: "orientationchange",
        fn: r
      },
      {
        eventName: "resize",
        fn: r
      },
      {
        eventName: "contextmenu",
        fn: function(a) {
          a.preventDefault();
        }
      },
      {
        eventName: "keydown",
        fn: function(a) {
          if (t().type !== "DRAGGING") {
            r();
            return;
          }
          a.keyCode === It && a.preventDefault(), r();
        }
      },
      {
        eventName: Pr,
        fn: r
      }
    ];
  }
  function cu(e) {
    var r = e.cancel, t = e.completed, n = e.getPhase;
    return [
      {
        eventName: "touchmove",
        options: {
          capture: false
        },
        fn: function(i) {
          var o = n();
          if (o.type !== "DRAGGING") {
            r();
            return;
          }
          o.hasMoved = true;
          var l = i.touches[0], s = l.clientX, d = l.clientY, p = {
            x: s,
            y: d
          };
          i.preventDefault(), o.actions.move(p);
        }
      },
      {
        eventName: "touchend",
        fn: function(i) {
          var o = n();
          if (o.type !== "DRAGGING") {
            r();
            return;
          }
          i.preventDefault(), o.actions.drop({
            shouldBlockNextClick: true
          }), t();
        }
      },
      {
        eventName: "touchcancel",
        fn: function(i) {
          if (n().type !== "DRAGGING") {
            r();
            return;
          }
          i.preventDefault(), r();
        }
      },
      {
        eventName: "touchforcechange",
        fn: function(i) {
          var o = n();
          o.type === "IDLE" && y();
          var l = i.touches[0];
          if (l) {
            var s = l.force >= su;
            if (s) {
              var d = o.actions.shouldRespectForcePress();
              if (o.type === "PENDING") {
                d && r();
                return;
              }
              if (d) {
                if (o.hasMoved) {
                  i.preventDefault();
                  return;
                }
                r();
                return;
              }
              i.preventDefault();
            }
          }
        }
      },
      {
        eventName: Pr,
        fn: r
      }
    ];
  }
  function du(e) {
    var r = O(jr), t = O(ue), n = I(function() {
      return r.current;
    }, []), a = I(function(v) {
      r.current = v;
    }, []), i = A(function() {
      return {
        eventName: "touchstart",
        fn: function(v) {
          if (!v.defaultPrevented) {
            var f = e.findClosestDraggableId(v);
            if (f) {
              var g = e.tryGetLock(f, l, {
                sourceEvent: v
              });
              if (g) {
                var m = v.touches[0], b = m.clientX, h = m.clientY, x = {
                  x: b,
                  y: h
                };
                t.current(), u(g, x);
              }
            }
          }
        }
      };
    }, [
      e
    ]), o = I(function() {
      var v = {
        capture: true,
        passive: false
      };
      t.current = _(window, [
        i
      ], v);
    }, [
      i
    ]), l = I(function() {
      var c = r.current;
      c.type !== "IDLE" && (c.type === "PENDING" && clearTimeout(c.longPressTimerId), a(jr), t.current(), o());
    }, [
      o,
      a
    ]), s = I(function() {
      var c = r.current;
      l(), c.type === "DRAGGING" && c.actions.cancel({
        shouldBlockNextClick: true
      }), c.type === "PENDING" && c.actions.abort();
    }, [
      l
    ]), d = I(function() {
      var v = {
        capture: true,
        passive: false
      }, f = {
        cancel: s,
        completed: l,
        getPhase: n
      }, g = _(window, cu(f), v), m = _(window, uu(f), v);
      t.current = function() {
        g(), m();
      };
    }, [
      s,
      n,
      l
    ]), p = I(function() {
      var v = n();
      v.type !== "PENDING" && y();
      var f = v.actions.fluidLift(v.point);
      a({
        type: "DRAGGING",
        actions: f,
        hasMoved: false
      });
    }, [
      n,
      a
    ]), u = I(function(v, f) {
      n().type !== "IDLE" && y();
      var g = setTimeout(p, lu);
      a({
        type: "PENDING",
        point: f,
        actions: v,
        longPressTimerId: g
      }), d();
    }, [
      d,
      n,
      a,
      p
    ]);
    z(function() {
      return o(), function() {
        t.current();
        var f = n();
        f.type === "PENDING" && (clearTimeout(f.longPressTimerId), a(jr));
      };
    }, [
      n,
      o,
      a
    ]), z(function() {
      var v = _(window, [
        {
          eventName: "touchmove",
          fn: function() {
          },
          options: {
            capture: false,
            passive: false
          }
        }
      ]);
      return v;
    }, []);
  }
  var pu = {
    input: true,
    button: true,
    textarea: true,
    select: true,
    option: true,
    optgroup: true,
    video: true,
    audio: true
  };
  function Da(e, r) {
    if (r == null) return false;
    var t = !!pu[r.tagName.toLowerCase()];
    if (t) return true;
    var n = r.getAttribute("contenteditable");
    return n === "true" || n === "" ? true : r === e ? false : Da(e, r.parentElement);
  }
  function vu(e, r) {
    var t = r.target;
    return Cr(t) ? Da(e, t) : false;
  }
  var fu = (function(e) {
    return te(e.getBoundingClientRect()).center;
  });
  function gu(e) {
    return e instanceof ga(e).Element;
  }
  var mu = (function() {
    var e = "matches";
    if (typeof document > "u") return e;
    var r = [
      e,
      "msMatchesSelector",
      "webkitMatchesSelector"
    ], t = ve(r, function(n) {
      return n in Element.prototype;
    });
    return t || e;
  })();
  function xa(e, r) {
    return e == null ? null : e[mu](r) ? e : xa(e.parentElement, r);
  }
  function bu(e, r) {
    return e.closest ? e.closest(r) : xa(e, r);
  }
  function hu(e) {
    return "[" + Ce.contextId + '="' + e + '"]';
  }
  function yu(e, r) {
    var t = r.target;
    if (!gu(t)) return null;
    var n = hu(e), a = bu(t, n);
    return !a || !Cr(a) ? null : a;
  }
  function Du(e, r) {
    var t = yu(e, r);
    return t ? t.getAttribute(Ce.draggableId) : null;
  }
  function xu(e, r) {
    var t = "[" + Xr.contextId + '="' + e + '"]', n = Gn(document.querySelectorAll(t)), a = ve(n, function(i) {
      return i.getAttribute(Xr.id) === r;
    });
    return !a || !Cr(a) ? null : a;
  }
  function Iu(e) {
    e.preventDefault();
  }
  function or(e) {
    var r = e.expected, t = e.phase, n = e.isLockActive;
    return e.shouldWarn, !(!n() || r !== t);
  }
  function Ia(e) {
    var r = e.lockAPI, t = e.store, n = e.registry, a = e.draggableId;
    if (r.isClaimed()) return false;
    var i = n.draggable.findById(a);
    return !(!i || !i.options.isEnabled || !da(t.getState(), a));
  }
  function Su(e) {
    var r = e.lockAPI, t = e.contextId, n = e.store, a = e.registry, i = e.draggableId, o = e.forceSensorStop, l = e.sourceEvent, s = Ia({
      lockAPI: r,
      store: n,
      registry: a,
      draggableId: i
    });
    if (!s) return null;
    var d = a.draggable.getById(i), p = xu(t, d.descriptor.id);
    if (!p || l && !d.options.canDragInteractiveElements && vu(p, l)) return null;
    var u = r.claim(o || ue), c = "PRE_DRAG";
    function v() {
      return d.options.shouldRespectForcePress;
    }
    function f() {
      return r.isActive(u);
    }
    function g(w, B) {
      or({
        expected: w,
        phase: c,
        isLockActive: f,
        shouldWarn: true
      }) && n.dispatch(B());
    }
    var m = g.bind(null, "DRAGGING");
    function b(w) {
      function B() {
        r.release(), c = "COMPLETED";
      }
      c !== "PRE_DRAG" && (B(), c !== "PRE_DRAG" && y()), n.dispatch(ml(w.liftActionArgs)), c = "DRAGGING";
      function M(P, L) {
        if (L === void 0 && (L = {
          shouldBlockNextClick: false
        }), w.cleanup(), L.shouldBlockNextClick) {
          var R = _(window, [
            {
              eventName: "click",
              fn: Iu,
              options: {
                once: true,
                passive: false,
                capture: true
              }
            }
          ]);
          setTimeout(R);
        }
        B(), n.dispatch(aa({
          reason: P
        }));
      }
      return C({
        isActive: function() {
          return or({
            expected: "DRAGGING",
            phase: c,
            isLockActive: f,
            shouldWarn: false
          });
        },
        shouldRespectForcePress: v,
        drop: function(L) {
          return M("DROP", L);
        },
        cancel: function(L) {
          return M("CANCEL", L);
        }
      }, w.actions);
    }
    function h(w) {
      var B = Ge(function(P) {
        m(function() {
          return na({
            client: P
          });
        });
      }), M = b({
        liftActionArgs: {
          id: i,
          clientSelection: w,
          movementMode: "FLUID"
        },
        cleanup: function() {
          return B.cancel();
        },
        actions: {
          move: B
        }
      });
      return C({}, M, {
        move: B
      });
    }
    function x() {
      var w = {
        moveUp: function() {
          return m(Cl);
        },
        moveRight: function() {
          return m(Pl);
        },
        moveDown: function() {
          return m(El);
        },
        moveLeft: function() {
          return m(Al);
        }
      };
      return b({
        liftActionArgs: {
          id: i,
          clientSelection: fu(p),
          movementMode: "SNAP"
        },
        cleanup: ue,
        actions: w
      });
    }
    function D() {
      var w = or({
        expected: "PRE_DRAG",
        phase: c,
        isLockActive: f,
        shouldWarn: true
      });
      w && r.release();
    }
    var E = {
      isActive: function() {
        return or({
          expected: "PRE_DRAG",
          phase: c,
          isLockActive: f,
          shouldWarn: false
        });
      },
      shouldRespectForcePress: v,
      fluidLift: h,
      snapLift: x,
      abort: D
    };
    return E;
  }
  var wu = [
    tu,
    ou,
    du
  ];
  function Cu(e) {
    var r = e.contextId, t = e.store, n = e.registry, a = e.customSensors, i = e.enableDefaultSensors, o = [].concat(i ? wu : [], a || []), l = _r(function() {
      return Hs();
    })[0], s = I(function(h, x) {
      h.isDragging && !x.isDragging && l.tryAbandon();
    }, [
      l
    ]);
    z(function() {
      var h = t.getState(), x = t.subscribe(function() {
        var D = t.getState();
        s(h, D), h = D;
      });
      return x;
    }, [
      l,
      t,
      s
    ]), z(function() {
      return l.tryAbandon;
    }, [
      l.tryAbandon
    ]);
    for (var d = I(function(b) {
      return Ia({
        lockAPI: l,
        registry: n,
        store: t,
        draggableId: b
      });
    }, [
      l,
      n,
      t
    ]), p = I(function(b, h, x) {
      return Su({
        lockAPI: l,
        registry: n,
        contextId: r,
        store: t,
        draggableId: b,
        forceSensorStop: h,
        sourceEvent: x && x.sourceEvent ? x.sourceEvent : null
      });
    }, [
      r,
      l,
      n,
      t
    ]), u = I(function(b) {
      return Du(r, b);
    }, [
      r
    ]), c = I(function(b) {
      var h = n.draggable.findById(b);
      return h ? h.options : null;
    }, [
      n.draggable
    ]), v = I(function() {
      l.isClaimed() && (l.tryAbandon(), t.getState().phase !== "IDLE" && t.dispatch(pt()));
    }, [
      l,
      t
    ]), f = I(l.isClaimed, [
      l
    ]), g = A(function() {
      return {
        canGetLock: d,
        tryGetLock: p,
        findClosestDraggableId: u,
        findOptionsForDraggable: c,
        tryReleaseLock: v,
        isLockClaimed: f
      };
    }, [
      d,
      p,
      u,
      c,
      v,
      f
    ]), m = 0; m < o.length; m++) o[m](g);
  }
  var Eu = function(r) {
    return {
      onBeforeCapture: r.onBeforeCapture,
      onBeforeDragStart: r.onBeforeDragStart,
      onDragStart: r.onDragStart,
      onDragEnd: r.onDragEnd,
      onDragUpdate: r.onDragUpdate
    };
  };
  function Ne(e) {
    return e.current || y(), e.current;
  }
  function Pu(e) {
    var r = e.contextId, t = e.setCallbacks, n = e.sensors, a = e.nonce, i = e.dragHandleUsageInstructions, o = O(null), l = ma(e), s = I(function() {
      return Eu(l.current);
    }, [
      l
    ]), d = Gs(r), p = Us({
      contextId: r,
      text: i
    }), u = Rs(r, a), c = I(function(P) {
      Ne(o).dispatch(P);
    }, []), v = A(function() {
      return Mt({
        publishWhileDragging: hl,
        updateDroppableScroll: Dl,
        updateDroppableIsEnabled: xl,
        updateDroppableIsCombineEnabled: Il,
        collectionStarting: yl
      }, c);
    }, [
      c
    ]), f = Ms(), g = A(function() {
      return ss(f, v);
    }, [
      f,
      v
    ]), m = A(function() {
      return Cs(C({
        scrollWindow: us,
        scrollDroppable: g.scrollDroppable
      }, Mt({
        move: na
      }, c)));
    }, [
      g.scrollDroppable,
      c
    ]), b = Ts(r), h = A(function() {
      return as({
        announce: d,
        autoScroller: m,
        dimensionMarshal: g,
        focusMarshal: b,
        getResponders: s,
        styleMarshal: u
      });
    }, [
      d,
      m,
      g,
      b,
      s,
      u
    ]);
    o.current = h;
    var x = I(function() {
      var P = Ne(o), L = P.getState();
      L.phase !== "IDLE" && P.dispatch(pt());
    }, []), D = I(function() {
      var P = Ne(o).getState();
      return P.isDragging || P.phase === "DROP_ANIMATING";
    }, []), E = A(function() {
      return {
        isDragging: D,
        tryAbort: x
      };
    }, [
      D,
      x
    ]);
    t(E);
    var w = I(function(P) {
      return da(Ne(o).getState(), P);
    }, []), B = I(function() {
      return me(Ne(o).getState());
    }, []), M = A(function() {
      return {
        marshal: g,
        focus: b,
        contextId: r,
        canLift: w,
        isMovementAllowed: B,
        dragHandleUsageInstructionsId: p,
        registry: f
      };
    }, [
      r,
      g,
      p,
      b,
      w,
      B,
      f
    ]);
    return Cu({
      contextId: r,
      store: h,
      registry: f,
      customSensors: n,
      enableDefaultSensors: e.enableDefaultSensors !== false
    }), ie(function() {
      return x;
    }, [
      x
    ]), N.createElement(Er.Provider, {
      value: M
    }, N.createElement(si, {
      context: Dt,
      store: h
    }, e.children));
  }
  var Au = 0;
  function Bu() {
    return A(function() {
      return "" + Au++;
    }, []);
  }
  function Ru(e) {
    var r = Bu(), t = e.dragHandleUsageInstructions || ur.dragHandleUsageInstructions;
    return N.createElement(io, null, function(n) {
      return N.createElement(Pu, {
        nonce: e.nonce,
        contextId: r,
        setCallbacks: n,
        dragHandleUsageInstructions: t,
        enableDefaultSensors: e.enableDefaultSensors,
        sensors: e.sensors,
        onBeforeCapture: e.onBeforeCapture,
        onBeforeDragStart: e.onBeforeDragStart,
        onDragStart: e.onDragStart,
        onDragUpdate: e.onDragUpdate,
        onDragEnd: e.onDragEnd
      }, e.children);
    });
  }
  var Sa = function(r) {
    return function(t) {
      return r === t;
    };
  }, Ou = Sa("scroll"), Tu = Sa("auto"), un = function(r, t) {
    return t(r.overflowX) || t(r.overflowY);
  }, Nu = function(r) {
    var t = window.getComputedStyle(r), n = {
      overflowX: t.overflowX,
      overflowY: t.overflowY
    };
    return un(n, Ou) || un(n, Tu);
  }, Mu = function() {
    return false;
  }, Lu = function e(r) {
    return r == null ? null : r === document.body ? Mu() ? r : null : r === document.documentElement ? null : Nu(r) ? r : e(r.parentElement);
  }, Zr = (function(e) {
    return {
      x: e.scrollLeft,
      y: e.scrollTop
    };
  }), Fu = function e(r) {
    if (!r) return false;
    var t = window.getComputedStyle(r);
    return t.position === "fixed" ? true : e(r.parentElement);
  }, Gu = (function(e) {
    var r = Lu(e), t = Fu(e);
    return {
      closestScrollable: r,
      isFixedOnPage: t
    };
  }), $u = (function(e) {
    var r = e.descriptor, t = e.isEnabled, n = e.isCombineEnabled, a = e.isFixedOnPage, i = e.direction, o = e.client, l = e.page, s = e.closest, d = (function() {
      if (!s) return null;
      var v = s.scrollSize, f = s.client, g = sa({
        scrollHeight: v.scrollHeight,
        scrollWidth: v.scrollWidth,
        height: f.paddingBox.height,
        width: f.paddingBox.width
      });
      return {
        pageMarginBox: s.page.marginBox,
        frameClient: f,
        scrollSize: v,
        shouldClipSubject: s.shouldClipSubject,
        scroll: {
          initial: s.scroll,
          current: s.scroll,
          max: g,
          diff: {
            value: $,
            displacement: $
          }
        }
      };
    })(), p = i === "vertical" ? lt : Hn, u = Se({
      page: l,
      withPlaceholder: null,
      axis: p,
      frame: d
    }), c = {
      descriptor: r,
      isCombineEnabled: n,
      isFixedOnPage: a,
      axis: p,
      isEnabled: t,
      client: o,
      page: l,
      frame: d,
      subject: u
    };
    return c;
  }), ku = function(r, t) {
    var n = Tn(r);
    if (!t || r !== t) return n;
    var a = n.paddingBox.top - t.scrollTop, i = n.paddingBox.left - t.scrollLeft, o = a + t.scrollHeight, l = i + t.scrollWidth, s = {
      top: a,
      right: l,
      bottom: o,
      left: i
    }, d = tt(s, n.border), p = nt({
      borderBox: d,
      margin: n.margin,
      border: n.border,
      padding: n.padding
    });
    return p;
  }, Wu = (function(e) {
    var r = e.ref, t = e.descriptor, n = e.env, a = e.windowScroll, i = e.direction, o = e.isDropDisabled, l = e.isCombineEnabled, s = e.shouldClipSubject, d = n.closestScrollable, p = ku(r, d), u = pr(p, a), c = (function() {
      if (!d) return null;
      var f = Tn(d), g = {
        scrollHeight: d.scrollHeight,
        scrollWidth: d.scrollWidth
      };
      return {
        client: f,
        page: pr(f, a),
        scroll: Zr(d),
        scrollSize: g,
        shouldClipSubject: s
      };
    })(), v = $u({
      descriptor: t,
      isEnabled: !o,
      isCombineEnabled: l,
      isFixedOnPage: n.isFixedOnPage,
      direction: i,
      client: p,
      page: u,
      closest: c
    });
    return v;
  }), Uu = {
    passive: false
  }, Hu = {
    passive: true
  }, cn = (function(e) {
    return e.shouldPublishImmediately ? Uu : Hu;
  });
  function hr(e) {
    var r = Qr(e);
    return r || y(), r;
  }
  var lr = function(r) {
    return r && r.env.closestScrollable || null;
  };
  function ju(e) {
    var r = O(null), t = hr(Er), n = xt("droppable"), a = t.registry, i = t.marshal, o = ma(e), l = A(function() {
      return {
        id: e.droppableId,
        type: e.type,
        mode: e.mode
      };
    }, [
      e.droppableId,
      e.mode,
      e.type
    ]), s = O(l), d = A(function() {
      return G(function(D, E) {
        r.current || y();
        var w = {
          x: D,
          y: E
        };
        i.updateDroppableScroll(l.id, w);
      });
    }, [
      l.id,
      i
    ]), p = I(function() {
      var D = r.current;
      return !D || !D.env.closestScrollable ? $ : Zr(D.env.closestScrollable);
    }, []), u = I(function() {
      var D = p();
      d(D.x, D.y);
    }, [
      p,
      d
    ]), c = A(function() {
      return Ge(u);
    }, [
      u
    ]), v = I(function() {
      var D = r.current, E = lr(D);
      D && E || y();
      var w = D.scrollOptions;
      if (w.shouldPublishImmediately) {
        u();
        return;
      }
      c();
    }, [
      c,
      u
    ]), f = I(function(D, E) {
      r.current && y();
      var w = o.current, B = w.getDroppableRef();
      B || y();
      var M = Gu(B), P = {
        ref: B,
        descriptor: l,
        env: M,
        scrollOptions: E
      };
      r.current = P;
      var L = Wu({
        ref: B,
        descriptor: l,
        env: M,
        windowScroll: D,
        direction: w.direction,
        isDropDisabled: w.isDropDisabled,
        isCombineEnabled: w.isCombineEnabled,
        shouldClipSubject: !w.ignoreContainerClipping
      }), R = M.closestScrollable;
      return R && (R.setAttribute(an.contextId, t.contextId), R.addEventListener("scroll", v, cn(P.scrollOptions))), L;
    }, [
      t.contextId,
      l,
      v,
      o
    ]), g = I(function() {
      var D = r.current, E = lr(D);
      return D && E || y(), Zr(E);
    }, []), m = I(function() {
      var D = r.current;
      D || y();
      var E = lr(D);
      r.current = null, E && (c.cancel(), E.removeAttribute(an.contextId), E.removeEventListener("scroll", v, cn(D.scrollOptions)));
    }, [
      v,
      c
    ]), b = I(function(D) {
      var E = r.current;
      E || y();
      var w = lr(E);
      w || y(), w.scrollTop += D.y, w.scrollLeft += D.x;
    }, []), h = A(function() {
      return {
        getDimensionAndWatchScroll: f,
        getScrollWhileDragging: g,
        dragStopped: m,
        scroll: b
      };
    }, [
      m,
      f,
      g,
      b
    ]), x = A(function() {
      return {
        uniqueId: n,
        descriptor: l,
        callbacks: h
      };
    }, [
      h,
      l,
      n
    ]);
    z(function() {
      return s.current = x.descriptor, a.droppable.register(x), function() {
        r.current && m(), a.droppable.unregister(x);
      };
    }, [
      h,
      l,
      m,
      x,
      i,
      a.droppable
    ]), z(function() {
      r.current && i.updateDroppableIsEnabled(s.current.id, !e.isDropDisabled);
    }, [
      e.isDropDisabled,
      i
    ]), z(function() {
      r.current && i.updateDroppableIsCombineEnabled(s.current.id, e.isCombineEnabled);
    }, [
      e.isCombineEnabled,
      i
    ]);
  }
  function Vr() {
  }
  var dn = {
    width: 0,
    height: 0,
    margin: po
  }, Vu = function(r) {
    var t = r.isAnimatingOpenOnMount, n = r.placeholder, a = r.animate;
    return t || a === "close" ? dn : {
      height: n.client.borderBox.height,
      width: n.client.borderBox.width,
      margin: n.client.margin
    };
  }, qu = function(r) {
    var t = r.isAnimatingOpenOnMount, n = r.placeholder, a = r.animate, i = Vu({
      isAnimatingOpenOnMount: t,
      placeholder: n,
      animate: a
    });
    return {
      display: n.display,
      boxSizing: "border-box",
      width: i.width,
      height: i.height,
      marginTop: i.margin.top,
      marginRight: i.margin.right,
      marginBottom: i.margin.bottom,
      marginLeft: i.margin.left,
      flexShrink: "0",
      flexGrow: "0",
      pointerEvents: "none",
      transition: a !== "none" ? Fe.placeholder : null
    };
  };
  function zu(e) {
    var r = O(null), t = I(function() {
      r.current && (clearTimeout(r.current), r.current = null);
    }, []), n = e.animate, a = e.onTransitionEnd, i = e.onClose, o = e.contextId, l = _r(e.animate === "open"), s = l[0], d = l[1];
    ie(function() {
      return s ? n !== "open" ? (t(), d(false), Vr) : r.current ? Vr : (r.current = setTimeout(function() {
        r.current = null, d(false);
      }), t) : Vr;
    }, [
      n,
      s,
      t
    ]);
    var p = I(function(c) {
      c.propertyName === "height" && (a(), n === "close" && i());
    }, [
      n,
      i,
      a
    ]), u = qu({
      isAnimatingOpenOnMount: s,
      animate: e.animate,
      placeholder: e.placeholder
    });
    return N.createElement(e.placeholder.tagName, {
      style: u,
      "data-rbd-placeholder-context-id": o,
      onTransitionEnd: p,
      ref: e.innerRef
    });
  }
  var Yu = N.memo(zu), St = N.createContext(null), Ju = (function(e) {
    gn(r, e);
    function r() {
      for (var n, a = arguments.length, i = new Array(a), o = 0; o < a; o++) i[o] = arguments[o];
      return n = e.call.apply(e, [
        this
      ].concat(i)) || this, n.state = {
        isVisible: !!n.props.on,
        data: n.props.on,
        animate: n.props.shouldAnimate && n.props.on ? "open" : "none"
      }, n.onClose = function() {
        n.state.animate === "close" && n.setState({
          isVisible: false
        });
      }, n;
    }
    r.getDerivedStateFromProps = function(a, i) {
      return a.shouldAnimate ? a.on ? {
        isVisible: true,
        data: a.on,
        animate: "open"
      } : i.isVisible ? {
        isVisible: true,
        data: i.data,
        animate: "close"
      } : {
        isVisible: false,
        animate: "close",
        data: null
      } : {
        isVisible: !!a.on,
        data: a.on,
        animate: "none"
      };
    };
    var t = r.prototype;
    return t.render = function() {
      if (!this.state.isVisible) return null;
      var a = {
        onClose: this.onClose,
        data: this.state.data,
        animate: this.state.animate
      };
      return this.props.children(a);
    }, r;
  })(N.PureComponent), pn = {
    dragging: 5e3,
    dropAnimating: 4500
  }, Ku = function(r, t) {
    return t ? Fe.drop(t.duration) : r ? Fe.snap : Fe.fluid;
  }, Xu = function(r, t) {
    return r ? t ? Ue.opacity.drop : Ue.opacity.combining : null;
  }, Zu = function(r) {
    return r.forceShouldAnimate != null ? r.forceShouldAnimate : r.mode === "SNAP";
  };
  function Qu(e) {
    var r = e.dimension, t = r.client, n = e.offset, a = e.combineWith, i = e.dropping, o = !!a, l = Zu(e), s = !!i, d = s ? Jr.drop(n, o) : Jr.moveTo(n), p = {
      position: "fixed",
      top: t.marginBox.top,
      left: t.marginBox.left,
      boxSizing: "border-box",
      width: t.borderBox.width,
      height: t.borderBox.height,
      transition: Ku(l, i),
      transform: d,
      opacity: Xu(o, s),
      zIndex: s ? pn.dropAnimating : pn.dragging,
      pointerEvents: "none"
    };
    return p;
  }
  function _u(e) {
    return {
      transform: Jr.moveTo(e.offset),
      transition: e.shouldAnimateDisplacement ? null : "none"
    };
  }
  function ec(e) {
    return e.type === "DRAGGING" ? Qu(e) : _u(e);
  }
  function rc(e, r, t) {
    t === void 0 && (t = $);
    var n = window.getComputedStyle(r), a = r.getBoundingClientRect(), i = On(a, n), o = pr(i, t), l = {
      client: i,
      tagName: r.tagName.toLowerCase(),
      display: n.display
    }, s = {
      x: i.marginBox.width,
      y: i.marginBox.height
    }, d = {
      descriptor: e,
      placeholder: l,
      displaceBy: s,
      client: i,
      page: o
    };
    return d;
  }
  function tc(e) {
    var r = xt("draggable"), t = e.descriptor, n = e.registry, a = e.getDraggableRef, i = e.canDragInteractiveElements, o = e.shouldRespectForcePress, l = e.isEnabled, s = A(function() {
      return {
        canDragInteractiveElements: i,
        shouldRespectForcePress: o,
        isEnabled: l
      };
    }, [
      i,
      l,
      o
    ]), d = I(function(v) {
      var f = a();
      return f || y(), rc(t, f, v);
    }, [
      t,
      a
    ]), p = A(function() {
      return {
        uniqueId: r,
        descriptor: t,
        options: s,
        getDimension: d
      };
    }, [
      t,
      d,
      s,
      r
    ]), u = O(p), c = O(true);
    z(function() {
      return n.draggable.register(u.current), function() {
        return n.draggable.unregister(u.current);
      };
    }, [
      n.draggable
    ]), z(function() {
      if (c.current) {
        c.current = false;
        return;
      }
      var v = u.current;
      u.current = p, n.draggable.update(p, v);
    }, [
      p,
      n.draggable
    ]);
  }
  function nc(e) {
    e.preventDefault();
  }
  function ac(e) {
    var r = O(null), t = I(function(P) {
      r.current = P;
    }, []), n = I(function() {
      return r.current;
    }, []), a = hr(Er), i = a.contextId, o = a.dragHandleUsageInstructionsId, l = a.registry, s = hr(St), d = s.type, p = s.droppableId, u = A(function() {
      return {
        id: e.draggableId,
        index: e.index,
        type: d,
        droppableId: p
      };
    }, [
      e.draggableId,
      e.index,
      d,
      p
    ]), c = e.children, v = e.draggableId, f = e.isEnabled, g = e.shouldRespectForcePress, m = e.canDragInteractiveElements, b = e.isClone, h = e.mapped, x = e.dropAnimationFinished;
    if (!b) {
      var D = A(function() {
        return {
          descriptor: u,
          registry: l,
          getDraggableRef: n,
          canDragInteractiveElements: m,
          shouldRespectForcePress: g,
          isEnabled: f
        };
      }, [
        u,
        l,
        n,
        m,
        g,
        f
      ]);
      tc(D);
    }
    var E = A(function() {
      return f ? {
        tabIndex: 0,
        role: "button",
        "aria-describedby": o,
        "data-rbd-drag-handle-draggable-id": v,
        "data-rbd-drag-handle-context-id": i,
        draggable: false,
        onDragStart: nc
      } : null;
    }, [
      i,
      o,
      v,
      f
    ]), w = I(function(P) {
      h.type === "DRAGGING" && h.dropping && P.propertyName === "transform" && x();
    }, [
      x,
      h
    ]), B = A(function() {
      var P = ec(h), L = h.type === "DRAGGING" && h.dropping ? w : null, R = {
        innerRef: t,
        draggableProps: {
          "data-rbd-draggable-context-id": i,
          "data-rbd-draggable-id": v,
          style: P,
          onTransitionEnd: L
        },
        dragHandleProps: E
      };
      return R;
    }, [
      i,
      E,
      v,
      h,
      w,
      t
    ]), M = A(function() {
      return {
        draggableId: u.id,
        type: u.type,
        source: {
          index: u.index,
          droppableId: u.droppableId
        }
      };
    }, [
      u.droppableId,
      u.id,
      u.index,
      u.type
    ]);
    return c(B, h.snapshot, M);
  }
  var wa = (function(e, r) {
    return e === r;
  }), Ca = (function(e) {
    var r = e.combine, t = e.destination;
    return t ? t.droppableId : r ? r.droppableId : null;
  }), ic = function(r) {
    return r.combine ? r.combine.draggableId : null;
  }, oc = function(r) {
    return r.at && r.at.type === "COMBINE" ? r.at.combine.draggableId : null;
  };
  function lc() {
    var e = G(function(a, i) {
      return {
        x: a,
        y: i
      };
    }), r = G(function(a, i, o, l, s) {
      return {
        isDragging: true,
        isClone: i,
        isDropAnimating: !!s,
        dropAnimation: s,
        mode: a,
        draggingOver: o,
        combineWith: l,
        combineTargetFor: null
      };
    }), t = G(function(a, i, o, l, s, d, p) {
      return {
        mapped: {
          type: "DRAGGING",
          dropping: null,
          draggingOver: s,
          combineWith: d,
          mode: i,
          offset: a,
          dimension: o,
          forceShouldAnimate: p,
          snapshot: r(i, l, s, d, null)
        }
      };
    }), n = function(i, o) {
      if (i.isDragging) {
        if (i.critical.draggable.id !== o.draggableId) return null;
        var l = i.current.client.offset, s = i.dimensions.draggables[o.draggableId], d = q(i.impact), p = oc(i.impact), u = i.forceShouldAnimate;
        return t(e(l.x, l.y), i.movementMode, s, o.isClone, d, p, u);
      }
      if (i.phase === "DROP_ANIMATING") {
        var c = i.completed;
        if (c.result.draggableId !== o.draggableId) return null;
        var v = o.isClone, f = i.dimensions.draggables[o.draggableId], g = c.result, m = g.mode, b = Ca(g), h = ic(g), x = i.dropDuration, D = {
          duration: x,
          curve: ft.drop,
          moveTo: i.newHomeClientOffset,
          opacity: h ? Ue.opacity.drop : null,
          scale: h ? Ue.scale.drop : null
        };
        return {
          mapped: {
            type: "DRAGGING",
            offset: i.newHomeClientOffset,
            dimension: f,
            dropping: D,
            draggingOver: b,
            combineWith: h,
            mode: m,
            forceShouldAnimate: null,
            snapshot: r(m, v, b, h, D)
          }
        };
      }
      return null;
    };
    return n;
  }
  function Ea(e) {
    return {
      isDragging: false,
      isDropAnimating: false,
      isClone: false,
      dropAnimation: null,
      mode: null,
      draggingOver: null,
      combineTargetFor: e,
      combineWith: null
    };
  }
  var sc = {
    mapped: {
      type: "SECONDARY",
      offset: $,
      combineTargetFor: null,
      shouldAnimateDisplacement: true,
      snapshot: Ea(null)
    }
  };
  function uc() {
    var e = G(function(o, l) {
      return {
        x: o,
        y: l
      };
    }), r = G(Ea), t = G(function(o, l, s) {
      return l === void 0 && (l = null), {
        mapped: {
          type: "SECONDARY",
          offset: o,
          combineTargetFor: l,
          shouldAnimateDisplacement: s,
          snapshot: r(l)
        }
      };
    }), n = function(l) {
      return l ? t($, l, true) : null;
    }, a = function(l, s, d, p) {
      var u = d.displaced.visible[l], c = !!(p.inVirtualList && p.effected[l]), v = Ir(d), f = v && v.draggableId === l ? s : null;
      if (!u) {
        if (!c) return n(f);
        if (d.displaced.invisible[l]) return null;
        var g = Ee(p.displacedBy.point), m = e(g.x, g.y);
        return t(m, f, true);
      }
      if (c) return n(f);
      var b = d.displacedBy.point, h = e(b.x, b.y);
      return t(h, f, u.shouldAnimate);
    }, i = function(l, s) {
      if (l.isDragging) return l.critical.draggable.id === s.draggableId ? null : a(s.draggableId, l.critical.draggable.id, l.impact, l.afterCritical);
      if (l.phase === "DROP_ANIMATING") {
        var d = l.completed;
        return d.result.draggableId === s.draggableId ? null : a(s.draggableId, d.result.draggableId, d.impact, d.afterCritical);
      }
      return null;
    };
    return i;
  }
  var cc = function() {
    var r = lc(), t = uc(), n = function(i, o) {
      return r(i, o) || t(i, o) || sc;
    };
    return n;
  }, dc = {
    dropAnimationFinished: ia
  }, pc = Bn(cc, dc, null, {
    context: Dt,
    pure: true,
    areStatePropsEqual: wa
  })(ac);
  function Pa(e) {
    var r = hr(St), t = r.isUsingCloneFor;
    return t === e.draggableId && !e.isClone ? null : N.createElement(pc, e);
  }
  function vc(e) {
    var r = typeof e.isDragDisabled == "boolean" ? !e.isDragDisabled : true, t = !!e.disableInteractiveElementBlocking, n = !!e.shouldRespectForcePress;
    return N.createElement(Pa, C({}, e, {
      isClone: false,
      isEnabled: r,
      canDragInteractiveElements: t,
      shouldRespectForcePress: n
    }));
  }
  function fc(e) {
    var r = Qr(Er);
    r || y();
    var t = r.contextId, n = r.isMovementAllowed, a = O(null), i = O(null), o = e.children, l = e.droppableId, s = e.type, d = e.mode, p = e.direction, u = e.ignoreContainerClipping, c = e.isDropDisabled, v = e.isCombineEnabled, f = e.snapshot, g = e.useClone, m = e.updateViewportMaxScroll, b = e.getContainerForClone, h = I(function() {
      return a.current;
    }, []), x = I(function(R) {
      a.current = R;
    }, []);
    I(function() {
      return i.current;
    }, []);
    var D = I(function(R) {
      i.current = R;
    }, []), E = I(function() {
      n() && m({
        maxScroll: ca()
      });
    }, [
      n,
      m
    ]);
    ju({
      droppableId: l,
      type: s,
      mode: d,
      direction: p,
      isDropDisabled: c,
      isCombineEnabled: v,
      ignoreContainerClipping: u,
      getDroppableRef: h
    });
    var w = N.createElement(Ju, {
      on: e.placeholder,
      shouldAnimate: e.shouldAnimatePlaceholder
    }, function(R) {
      var Y = R.onClose, J = R.data, F = R.animate;
      return N.createElement(Yu, {
        placeholder: J,
        onClose: Y,
        innerRef: D,
        animate: F,
        contextId: t,
        onTransitionEnd: E
      });
    }), B = A(function() {
      return {
        innerRef: x,
        placeholder: w,
        droppableProps: {
          "data-rbd-droppable-id": l,
          "data-rbd-droppable-context-id": t
        }
      };
    }, [
      t,
      l,
      w,
      x
    ]), M = g ? g.dragging.draggableId : null, P = A(function() {
      return {
        droppableId: l,
        type: s,
        isUsingCloneFor: M
      };
    }, [
      l,
      M,
      s
    ]);
    function L() {
      if (!g) return null;
      var R = g.dragging, Y = g.render, J = N.createElement(Pa, {
        draggableId: R.draggableId,
        index: R.source.index,
        isClone: true,
        isEnabled: true,
        shouldRespectForcePress: false,
        canDragInteractiveElements: true
      }, function(F, K) {
        return Y(F, K, R);
      });
      return Xa.createPortal(J, b());
    }
    return N.createElement(St.Provider, {
      value: P
    }, o(B, f), L());
  }
  var qr = function(r, t) {
    return r === t.droppable.type;
  }, vn = function(r, t) {
    return t.draggables[r.draggable.id];
  }, gc = function() {
    var r = {
      placeholder: null,
      shouldAnimatePlaceholder: true,
      snapshot: {
        isDraggingOver: false,
        draggingOverWith: null,
        draggingFromThisWith: null,
        isUsingPlaceholder: false
      },
      useClone: null
    }, t = C({}, r, {
      shouldAnimatePlaceholder: false
    }), n = G(function(o) {
      return {
        draggableId: o.id,
        type: o.type,
        source: {
          index: o.index,
          droppableId: o.droppableId
        }
      };
    }), a = G(function(o, l, s, d, p, u) {
      var c = p.descriptor.id, v = p.descriptor.droppableId === o;
      if (v) {
        var f = u ? {
          render: u,
          dragging: n(p.descriptor)
        } : null, g = {
          isDraggingOver: s,
          draggingOverWith: s ? c : null,
          draggingFromThisWith: c,
          isUsingPlaceholder: true
        };
        return {
          placeholder: p.placeholder,
          shouldAnimatePlaceholder: false,
          snapshot: g,
          useClone: f
        };
      }
      if (!l) return t;
      if (!d) return r;
      var m = {
        isDraggingOver: s,
        draggingOverWith: c,
        draggingFromThisWith: null,
        isUsingPlaceholder: true
      };
      return {
        placeholder: p.placeholder,
        shouldAnimatePlaceholder: true,
        snapshot: m,
        useClone: null
      };
    }), i = function(l, s) {
      var d = s.droppableId, p = s.type, u = !s.isDropDisabled, c = s.renderClone;
      if (l.isDragging) {
        var v = l.critical;
        if (!qr(p, v)) return t;
        var f = vn(v, l.dimensions), g = q(l.impact) === d;
        return a(d, u, g, g, f, c);
      }
      if (l.phase === "DROP_ANIMATING") {
        var m = l.completed;
        if (!qr(p, m.critical)) return t;
        var b = vn(m.critical, l.dimensions);
        return a(d, u, Ca(m.result) === d, q(m.impact) === d, b, c);
      }
      if (l.phase === "IDLE" && l.completed && !l.shouldFlush) {
        var h = l.completed;
        if (!qr(p, h.critical)) return t;
        var x = q(h.impact) === d, D = !!(h.impact.at && h.impact.at.type === "COMBINE"), E = h.critical.droppable.id === d;
        return x ? D ? r : t : E ? r : t;
      }
      return t;
    };
    return i;
  }, mc = {
    updateViewportMaxScroll: wl
  };
  function bc() {
    return document.body || y(), document.body;
  }
  var hc = {
    mode: "standard",
    type: "DEFAULT",
    direction: "vertical",
    isDropDisabled: false,
    isCombineEnabled: false,
    ignoreContainerClipping: false,
    renderClone: null,
    getContainerForClone: bc
  }, Aa = Bn(gc, mc, null, {
    context: Dt,
    pure: true,
    areStatePropsEqual: wa
  })(fc);
  Aa.defaultProps = hc;
  class Ie extends Ya {
    constructor(r) {
      super(r), this.state = {
        count: r.data.count,
        editLines: [],
        originalData: JSON.stringify(r.data),
        ...Ie.widgetData2State(r.data),
        open: false,
        showEditDialog: null
      };
    }
    static getDerivedStateFromProps(r, t) {
      return JSON.stringify(r.data) !== t.originalData ? {
        originalData: JSON.stringify(r.data),
        ...Ie.widgetData2State(r.data)
      } : null;
    }
    static widgetData2State(r) {
      const t = [];
      for (let n = 1; n <= r.count; n++) t.push({
        view: r[`view${n}`],
        link: r[`link${n}`],
        linkSelf: r[`linkSelf${n}`],
        linkHidden: r[`linkHidden${n}`],
        icon: r[`icon${n}`],
        iconSmall: r[`iconSmall${n}`],
        iconEnabled: r[`iconEnabled${n}`],
        iconEnabledSmall: r[`iconEnabledSmall${n}`],
        color: r[`color${n}`],
        colorEnabled: r[`colorEnabled${n}`],
        title: r[`title${n}`],
        titleEnabled: r[`titleEnabled${n}`],
        pinCode: r[`pinCode${n}`],
        oidPinCode: r[`oid-pinCode${n}`],
        disabled: r[`disabled${n}`],
        hide: r[`hide${n}`]
      });
      return {
        editLines: t,
        count: r.count
      };
    }
    static state2WidgetData(r, t) {
      const n = {
        ...t
      };
      for (let a = 1; a <= r.count; a++) {
        const i = r.editLines[a - 1];
        n[`view${a}`] = i.view, n[`link${a}`] = i.link, n[`linkSelf${a}`] = i.linkSelf, n[`linkHidden${a}`] = i.linkHidden, n[`icon${a}`] = i.icon, n[`iconSmall${a}`] = i.iconSmall, n[`iconEnabled${a}`] = i.iconEnabled, n[`iconEnabledSmall${a}`] = i.iconEnabledSmall, n[`color${a}`] = i.color, n[`colorEnabled${a}`] = i.colorEnabled, n[`title${a}`] = i.title, n[`titleEnabled${a}`] = i.titleEnabled, n[`pinCode${a}`] = i.pinCode, n[`oid-pinCode${a}`] = i.oidPinCode, n[`disabled${a}`] = i.disabled, n[`hide${a}`] = i.hide;
      }
      return n;
    }
    isSelected() {
      return false;
    }
    renderButton(r) {
      var _a2, _b, _c, _d, _e, _f, _g, _h, _i2;
      const t = this.props.views[r.view];
      let n = this.isSelected() ? r.colorEnabled || r.color || ((_a2 = t == null ? void 0 : t.settings) == null ? void 0 : _a2.navigationSelectedColor) : void 0;
      n || (n = r.color || ((_b = t == null ? void 0 : t.settings) == null ? void 0 : _b.navigationColor) || ((_c = t == null ? void 0 : t.settings) == null ? void 0 : _c.navigationBarColor));
      let a = this.isSelected() ? r.titleEnabled : "";
      a || (a = r.title || ((_d = t == null ? void 0 : t.settings) == null ? void 0 : _d.navigationTitle) || ((_e = t == null ? void 0 : t.settings) == null ? void 0 : _e.navigationBarText) || ""), a || (a = r.view || "");
      let i = "", o = null;
      return this.isSelected() && (i = r.iconEnabled || r.iconEnabledSmall), i || (i = r.icon || r.iconSmall), i || (i = r.view ? ((_f = t == null ? void 0 : t.settings) == null ? void 0 : _f.navigationIcon) || ((_g = t == null ? void 0 : t.settings) == null ? void 0 : _g.navigationImage) || ((_h = t == null ? void 0 : t.settings) == null ? void 0 : _h.navigationBarIcon) || ((_i2 = t == null ? void 0 : t.settings) == null ? void 0 : _i2.navigationBarImage) : ""), i && (o = S.jsx(sr, {
        src: i,
        style: {
          width: 24,
          height: 24
        }
      })), S.jsx(Me, {
        variant: "contained",
        style: {
          color: n,
          whiteSpace: "nowrap"
        },
        startIcon: o,
        children: a
      });
    }
    renderLine(r) {
      return S.jsx(vc, {
        draggableId: r.toString(),
        index: r,
        children: (t, n) => S.jsxs(Et, {
          ref: t.innerRef,
          ...t.draggableProps,
          style: {
            ...t.draggableProps.style,
            backgroundColor: n.isDragging ? "#334455" : void 0
          },
          children: [
            S.jsx(Z, {
              children: S.jsx("div", {
                ...t.dragHandleProps,
                style: {
                  display: "inline-block",
                  width: 24,
                  marginRight: 8
                },
                children: S.jsx(Za, {})
              })
            }),
            S.jsx(Z, {
              children: S.jsx(Mr, {
                variant: "standard",
                value: this.state.editLines[r].title,
                onChange: (a) => {
                  const i = [
                    ...this.state.editLines
                  ];
                  i[r].title = a.target.value, this.setState({
                    editLines: i
                  });
                }
              })
            }),
            S.jsx(Z, {
              children: S.jsx(Mr, {
                variant: "standard",
                value: this.state.editLines[r].titleEnabled,
                onChange: (a) => {
                  const i = [
                    ...this.state.editLines
                  ];
                  i[r].titleEnabled = a.target.value, this.setState({
                    editLines: i
                  });
                }
              })
            }),
            S.jsx(Z, {
              children: S.jsx(Mr, {
                variant: "standard",
                value: this.state.editLines[r].pinCode,
                onChange: (a) => {
                  const i = [
                    ...this.state.editLines
                  ];
                  i[r].pinCode = a.target.value, this.setState({
                    editLines: i
                  });
                }
              })
            }),
            S.jsx(Z, {
              children: this.renderButton(this.state.editLines[r])
            }),
            S.jsx(Z, {
              children: S.jsx(Oa, {
                onClick: () => this.setState({
                  editLines: this.state.editLines.filter((a, i) => i !== r)
                }),
                children: S.jsx(Qa, {})
              })
            })
          ]
        }, r)
      }, r);
    }
    renderDialog() {
      return this.state.open ? S.jsxs(Ta, {
        maxWidth: "xl",
        fullWidth: true,
        open: true,
        onClose: () => {
          this.setState({
            open: false
          });
        },
        children: [
          S.jsx(Na, {
            children: se.t("Re-order")
          }),
          S.jsx(Ma, {
            children: S.jsx(La, {
              component: Fa,
              children: S.jsxs(Ga, {
                size: "small",
                children: [
                  S.jsx($a, {
                    children: S.jsxs(Et, {
                      children: [
                        S.jsx(Z, {}),
                        S.jsx(Z, {
                          children: se.t("title")
                        }),
                        S.jsx(Z, {
                          children: se.t("titleEnabled")
                        }),
                        S.jsx(Z, {
                          children: se.t("pincode")
                        }),
                        S.jsx(Z, {}),
                        S.jsx(Z, {})
                      ]
                    })
                  }),
                  S.jsx(Ru, {
                    onDragEnd: (r) => {
                      const t = [
                        ...this.state.editLines
                      ], [n] = t.splice(r.source.index, 1);
                      t.splice(r.destination.index, 0, n), this.setState({
                        editLines: t
                      });
                    },
                    children: S.jsx(Aa, {
                      droppableId: "items",
                      type: "ROW",
                      children: (r, t) => S.jsxs(ka, {
                        ref: r.innerRef,
                        ...r.droppableProps,
                        style: {
                          backgroundColor: t.isDraggingOver ? "#112233" : void 0
                        },
                        children: [
                          this.state.editLines.map((n, a) => this.renderLine(a)),
                          r.placeholder
                        ]
                      })
                    })
                  })
                ]
              })
            })
          }),
          S.jsxs(Wa, {
            children: [
              S.jsx(Me, {
                variant: "contained",
                disabled: this.state.originalData === JSON.stringify(Ie.state2WidgetData(this.state, this.props.data)),
                onClick: () => {
                  this.setState({
                    open: false
                  }), this.props.setData(Ie.state2WidgetData(this.state, this.props.data));
                },
                color: "primary",
                startIcon: S.jsx(_a, {}),
                children: se.t("Apply")
              }),
              S.jsx(Me, {
                variant: "contained",
                onClick: () => this.setState({
                  open: false
                }),
                color: "grey",
                startIcon: S.jsx(ei, {}),
                children: se.t("Close")
              })
            ]
          })
        ]
      }) : null;
    }
    render() {
      return S.jsxs("div", {
        children: [
          S.jsx(Me, {
            disabled: this.props.selectedWidgets.length > 1,
            variant: "contained",
            onClick: () => this.setState({
              open: true
            }),
            children: se.t("Re-order")
          }),
          this.renderDialog()
        ]
      });
    }
  }
  Ba = class extends se {
    constructor(r) {
      super(r), this.state = {
        ...this.state,
        dialogPin: null,
        menuTarget: null,
        invalidPin: false,
        lockPinInput: ""
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2Navigate",
        visSet: "vis-2-widgets-nils",
        visName: "Navigate",
        visWidgetLabel: "navigate",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox"
              },
              {
                name: "variant",
                label: "variant",
                type: "select",
                options: [
                  "text",
                  "outlined",
                  "contained"
                ]
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "title",
                label: "title",
                type: "text"
              },
              {
                name: "icon",
                type: "image",
                label: "icon",
                hidden: '!!data["iconSmall" + index]'
              },
              {
                name: "iconSmall",
                type: "icon64",
                label: "small_icon",
                hidden: '!!data["icon" + index]'
              },
              {
                name: "showCurrentView",
                type: "checkbox",
                label: "show_current_view",
                noBinding: false,
                hidden: (r) => {
                  const t = r;
                  for (let n = 1; n <= t.count; n++) if (t[`view${n}`]) return false;
                  return true;
                }
              },
              {
                name: "pinCodeReturnButton",
                type: "select",
                options: [
                  "submit",
                  "backspace"
                ],
                default: "submit",
                label: "pincode_return_button",
                hidden: (r) => {
                  const t = r;
                  for (let n = 1; n <= t.count; n++) if (t[`oid-pinCode${n}`] || t[`pinCode${n}`]) return false;
                  return true;
                }
              },
              {
                name: "count",
                type: "number",
                default: 1,
                label: "count"
              },
              {
                label: "",
                name: "_settings",
                type: "custom",
                component: (r, t, n, a) => S.jsx(Ie, {
                  data: t,
                  setData: (i) => {
                    n(i);
                  },
                  Editor: a.Editor,
                  views: a.context.views,
                  selectedWidgets: a.selectedWidgets
                })
              }
            ]
          },
          {
            name: "item",
            label: "group_item",
            indexFrom: 1,
            indexTo: "count",
            fields: [
              {
                name: "view",
                type: "views",
                label: "view",
                hidden: '!!data["link" + index]'
              },
              {
                name: "link",
                type: "text",
                label: "URL",
                hidden: '!!data["view" + index]'
              },
              {
                name: "title",
                type: "text",
                label: "title",
                noButton: true
              },
              {
                name: "titleEnabled",
                type: "text",
                label: "titleEnabled",
                noButton: true,
                hidden: '!data["view" + index]'
              },
              {
                name: "icon",
                type: "image",
                label: "icon",
                hidden: '!!data["iconSmall" + index] || (!data["view" + index] && !data["link" + index])'
              },
              {
                name: "iconSmall",
                type: "icon64",
                label: "small_icon",
                hidden: '!!data["icon" + index] || (!data["view" + index] && !data["link" + index])'
              },
              {
                name: "iconEnabled",
                type: "image",
                label: "icon_active",
                hidden: '!!data["iconEnabledSmall" + index] || !data["view" + index]'
              },
              {
                name: "iconEnabledSmall",
                type: "icon64",
                label: "small_icon_active",
                hidden: '!!data["iconEnabled" + index] || !data["view" + index]'
              },
              {
                name: "color",
                type: "color",
                label: "color",
                hidden: '!data["view" + index] && !data["link" + index]'
              },
              {
                name: "colorEnabled",
                type: "color",
                label: "color_active",
                hidden: '!data["view" + index]'
              },
              {
                name: "hide",
                type: "checkbox",
                label: "hide",
                tooltip: "hide_tooltip",
                noBinding: false,
                hidden: '!data["view" + index] && !data["link" + index]'
              },
              {
                name: "disabled",
                type: "checkbox",
                label: "disabled",
                noBinding: false,
                hidden: '!data["view" + index] && !data["link" + index]'
              },
              {
                name: "pinCode",
                label: "pincode",
                onChange: (r, t, n, a, i) => {
                  var _a2;
                  const o = t;
                  return ((_a2 = o[`pinCode${i}`]) == null ? void 0 : _a2.match(/[^0-9]/g)) && (o[`pinCode${i}`] = o[`pinCode${i}`].replace(/[^0-9]/g, ""), n(o)), Promise.resolve();
                },
                hidden: '!!data["oid-pinCode" + index] || (!data["view" + index] && !data["link" + index])'
              },
              {
                name: "oid-pinCode",
                type: "id",
                label: "pincode_oid",
                hidden: '!!data["pinCode" + index] || (!data["view" + index] && !data["link" + index])'
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 72,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_navigate.png"
      };
    }
    getWidgetInfo() {
      return Ba.getWidgetInfo();
    }
    isSelected(r) {
      return this.state.rxData[`view${r}`] === this.props.view;
    }
    getStateIcon(r) {
      var _a2, _b, _c, _d, _e, _f, _g, _h;
      let t = "", n = null;
      return this.isSelected(r) && (t = this.state.rxData[`iconEnabled${r}`] || this.state.rxData[`iconEnabledSmall${r}`]), t || (t = this.state.rxData[`icon${r}`] || this.state.rxData[`iconSmall${r}`]), t || (t = this.state.rxData[`view${r}`] ? ((_b = (_a2 = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _a2.settings) == null ? void 0 : _b.navigationIcon) || ((_d = (_c = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _c.settings) == null ? void 0 : _d.navigationImage) || ((_f = (_e = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _e.settings) == null ? void 0 : _f.navigationBarIcon) || ((_h = (_g = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _g.settings) == null ? void 0 : _h.navigationBarImage) : ""), t && (n = S.jsx(sr, {
        src: t,
        style: {
          width: 24,
          height: 24
        }
      })), n;
    }
    getColor(r) {
      var _a2, _b, _c, _d, _e, _f;
      let t = this.isSelected(r) ? this.state.rxData[`colorEnabled${r}`] || this.state.rxData[`color${r}`] || ((_b = (_a2 = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _a2.settings) == null ? void 0 : _b.navigationSelectedColor) : void 0;
      return t || (t = this.state.rxData[`color${r}`] || ((_d = (_c = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _c.settings) == null ? void 0 : _d.navigationColor) || ((_f = (_e = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _e.settings) == null ? void 0 : _f.navigationBarColor)), t;
    }
    renderUnlockDialog() {
      return this.state.dialogPin ? S.jsx(qa, {
        pinCode: this.getPinCode(this.state.dialogPin),
        pinCodeReturnButton: this.state.rxData.pinCodeReturnButton === "backspace" ? "backspace" : "submit",
        onClose: (r) => {
          r && this.onItemClick(this.state.dialogPin, true), this.setState({
            dialogPin: null
          });
        }
      }) : null;
    }
    getTitle(r) {
      var _a2, _b, _c, _d;
      let t = this.isSelected(r) ? this.state.rxData[`titleEnabled${r}`] : "";
      return t || (t = this.state.rxData[`title${r}`] || ((_b = (_a2 = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _a2.settings) == null ? void 0 : _b.navigationTitle) || ((_d = (_c = this.props.context.views[this.state.rxData[`view${r}`]]) == null ? void 0 : _c.settings) == null ? void 0 : _d.navigationBarText) || ""), t || (t = this.state.rxData[`view${r}`] || ""), t;
    }
    renderMenu() {
      var _a2, _b, _c, _d;
      if (!this.state.menuTarget) return null;
      const r = [];
      for (let a = 1; a <= this.state.rxData.count; a++) r[a] = this.getStateIcon(a);
      const t = !!r.find((a) => a), n = [];
      for (let a = 1; a <= this.state.rxData.count; a++) if ((this.state.rxData[`link${a}`] || this.state.rxData[`view${a}`]) && this.state.rxData[`hide${a}`] !== true && this.state.rxData[`hide${a}`] !== "true") {
        let i = this.isSelected(a) ? this.state.rxData[`titleEnabled${a}`] : "";
        i || (i = this.state.rxData[`title${a}`] || ((_b = (_a2 = this.props.context.views[this.state.rxData[`view${a}`]]) == null ? void 0 : _a2.settings) == null ? void 0 : _b.navigationTitle) || ((_d = (_c = this.props.context.views[this.state.rxData[`view${a}`]]) == null ? void 0 : _c.settings) == null ? void 0 : _d.navigationBarText) || ""), i || (i = this.state.rxData[`view${a}`] || ""), n.push(S.jsxs(Ua, {
          style: {
            color: this.getColor(a)
          },
          selected: this.isSelected(a),
          onClick: () => this.setState({
            menuTarget: null
          }, () => this.onItemClick(a)),
          disabled: this.state.rxData[`disabled${a}`] === true || this.state.rxData[`disabled${a}`] === "true",
          children: [
            t ? S.jsx(Ha, {
              children: S.jsx(sr, {
                src: r[a],
                style: {
                  height: 24,
                  width: "auto"
                }
              })
            }) : null,
            S.jsx(ja, {
              children: i
            })
          ]
        }, a));
      }
      return S.jsx(Va, {
        open: true,
        anchorEl: this.state.menuTarget,
        onClose: () => this.setState({
          menuTarget: null
        }),
        children: n
      });
    }
    getPinCode(r) {
      return this.state.rxData[`oid-pinCode${r}`] ? this.getPropertyValue(`oid-pinCode${r}`) : this.state.rxData[`pinCode${r}`];
    }
    onItemClick(r, t) {
      if (this.state.rxData[`disabled${r}`] === true || this.state.rxData[`disabled${r}`] === "true") return;
      if (!t && this.getPinCode(r)) {
        this.setState({
          dialogPin: r
        });
        return;
      }
      const n = this.state.rxData[`link${r}`], a = this.state.rxData[`linkSelf${r}`] === true || this.state.rxData[`linkSelf${r}`] === "true", i = this.state.rxData[`linkHidden${r}`] === true || this.state.rxData[`linkHidden${r}`] === "true", o = this.state.rxData[`view${r}`];
      if (n) if (a) window.location.href = n;
      else if (i) try {
        fetch(n).catch((l) => console.warn(`Cannot call "${n}": ${l}`));
      } catch (l) {
        console.warn(`Cannot call "${n}": ${l.toString()}`);
      }
      else window.open(n, "_blank");
      else o && this.props.context.changeView(o, o);
    }
    onClick(r) {
      r.stopPropagation();
      let t = 0, n = null;
      for (let a = 1; a <= this.state.rxData.count; a++) (this.state.rxData[`link${a}`] || this.state.rxData[`view${a}`]) && this.state.rxData[`hide${a}`] !== true && this.state.rxData[`hide${a}`] !== "true" && (t++, n = a);
      t > 1 ? this.setState({
        menuTarget: r.target
      }) : n !== null && this.onItemClick(n);
    }
    renderWidgetBody(r) {
      var _a2;
      super.renderWidgetBody(r);
      let t = "", n = null, a = "";
      if (this.state.rxData.showCurrentView) {
        for (let o = 1; o <= this.state.rxData.count; o++) if (this.props.view === this.state.rxData[`view${o}`]) {
          t = this.getTitle(o) || "", a = this.getColor(o) || "", n = this.getStateIcon(o);
          break;
        }
      }
      t || (t = this.state.rxData.title || this.state.rxData.widgetTitle || ""), a || (a = ((_a2 = this.state.rxStyle) == null ? void 0 : _a2.color) || void 0), n || (n = this.state.rxData.icon || this.state.rxData.iconSmall ? S.jsx(sr, {
        src: this.state.rxData.icon || this.state.rxData.iconSmall,
        style: {
          height: 24,
          width: "auto"
        }
      }) : null);
      const i = S.jsxs(S.Fragment, {
        children: [
          this.renderUnlockDialog(),
          this.renderMenu(),
          S.jsx(Me, {
            variant: this.state.rxData.variant,
            onClick: (o) => this.onClick(o),
            startIcon: n,
            style: {
              color: a
            },
            children: t
          })
        ]
      });
      return this.wrapContent(i);
    }
  };
});
export {
  __tla,
  Ba as default
};
