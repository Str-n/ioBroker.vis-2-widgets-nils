import { j as g, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { a as it, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { L as lt, M as ct, N as ut, O as ht, P as ft, Q as dt, R as gt, S as pt, T as et, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CRxa-Ic2.js";
import { v as mt, w as bt, c as q, g as nt, __tla as __tla_3 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { G as vt } from "./Generic-CC2u2WPj.js";
import { __tla as __tla_4 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
let L;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  const X = {
    aliceblue: [
      240,
      248,
      255
    ],
    antiquewhite: [
      250,
      235,
      215
    ],
    aqua: [
      0,
      255,
      255
    ],
    aquamarine: [
      127,
      255,
      212
    ],
    azure: [
      240,
      255,
      255
    ],
    beige: [
      245,
      245,
      220
    ],
    bisque: [
      255,
      228,
      196
    ],
    black: [
      0,
      0,
      0
    ],
    blanchedalmond: [
      255,
      235,
      205
    ],
    blue: [
      0,
      0,
      255
    ],
    blueviolet: [
      138,
      43,
      226
    ],
    brown: [
      165,
      42,
      42
    ],
    burlywood: [
      222,
      184,
      135
    ],
    cadetblue: [
      95,
      158,
      160
    ],
    chartreuse: [
      127,
      255,
      0
    ],
    chocolate: [
      210,
      105,
      30
    ],
    coral: [
      255,
      127,
      80
    ],
    cornflowerblue: [
      100,
      149,
      237
    ],
    cornsilk: [
      255,
      248,
      220
    ],
    crimson: [
      220,
      20,
      60
    ],
    cyan: [
      0,
      255,
      255
    ],
    darkblue: [
      0,
      0,
      139
    ],
    darkcyan: [
      0,
      139,
      139
    ],
    darkgoldenrod: [
      184,
      134,
      11
    ],
    darkgray: [
      169,
      169,
      169
    ],
    darkgreen: [
      0,
      100,
      0
    ],
    darkgrey: [
      169,
      169,
      169
    ],
    darkkhaki: [
      189,
      183,
      107
    ],
    darkmagenta: [
      139,
      0,
      139
    ],
    darkolivegreen: [
      85,
      107,
      47
    ],
    darkorange: [
      255,
      140,
      0
    ],
    darkorchid: [
      153,
      50,
      204
    ],
    darkred: [
      139,
      0,
      0
    ],
    darksalmon: [
      233,
      150,
      122
    ],
    darkseagreen: [
      143,
      188,
      143
    ],
    darkslateblue: [
      72,
      61,
      139
    ],
    darkslategray: [
      47,
      79,
      79
    ],
    darkslategrey: [
      47,
      79,
      79
    ],
    darkturquoise: [
      0,
      206,
      209
    ],
    darkviolet: [
      148,
      0,
      211
    ],
    deeppink: [
      255,
      20,
      147
    ],
    deepskyblue: [
      0,
      191,
      255
    ],
    dimgray: [
      105,
      105,
      105
    ],
    dimgrey: [
      105,
      105,
      105
    ],
    dodgerblue: [
      30,
      144,
      255
    ],
    firebrick: [
      178,
      34,
      34
    ],
    floralwhite: [
      255,
      250,
      240
    ],
    forestgreen: [
      34,
      139,
      34
    ],
    fuchsia: [
      255,
      0,
      255
    ],
    gainsboro: [
      220,
      220,
      220
    ],
    ghostwhite: [
      248,
      248,
      255
    ],
    gold: [
      255,
      215,
      0
    ],
    goldenrod: [
      218,
      165,
      32
    ],
    gray: [
      128,
      128,
      128
    ],
    green: [
      0,
      128,
      0
    ],
    greenyellow: [
      173,
      255,
      47
    ],
    grey: [
      128,
      128,
      128
    ],
    honeydew: [
      240,
      255,
      240
    ],
    hotpink: [
      255,
      105,
      180
    ],
    indianred: [
      205,
      92,
      92
    ],
    indigo: [
      75,
      0,
      130
    ],
    ivory: [
      255,
      255,
      240
    ],
    khaki: [
      240,
      230,
      140
    ],
    lavender: [
      230,
      230,
      250
    ],
    lavenderblush: [
      255,
      240,
      245
    ],
    lawngreen: [
      124,
      252,
      0
    ],
    lemonchiffon: [
      255,
      250,
      205
    ],
    lightblue: [
      173,
      216,
      230
    ],
    lightcoral: [
      240,
      128,
      128
    ],
    lightcyan: [
      224,
      255,
      255
    ],
    lightgoldenrodyellow: [
      250,
      250,
      210
    ],
    lightgray: [
      211,
      211,
      211
    ],
    lightgreen: [
      144,
      238,
      144
    ],
    lightgrey: [
      211,
      211,
      211
    ],
    lightpink: [
      255,
      182,
      193
    ],
    lightsalmon: [
      255,
      160,
      122
    ],
    lightseagreen: [
      32,
      178,
      170
    ],
    lightskyblue: [
      135,
      206,
      250
    ],
    lightslategray: [
      119,
      136,
      153
    ],
    lightslategrey: [
      119,
      136,
      153
    ],
    lightsteelblue: [
      176,
      196,
      222
    ],
    lightyellow: [
      255,
      255,
      224
    ],
    lime: [
      0,
      255,
      0
    ],
    limegreen: [
      50,
      205,
      50
    ],
    linen: [
      250,
      240,
      230
    ],
    magenta: [
      255,
      0,
      255
    ],
    maroon: [
      128,
      0,
      0
    ],
    mediumaquamarine: [
      102,
      205,
      170
    ],
    mediumblue: [
      0,
      0,
      205
    ],
    mediumorchid: [
      186,
      85,
      211
    ],
    mediumpurple: [
      147,
      112,
      219
    ],
    mediumseagreen: [
      60,
      179,
      113
    ],
    mediumslateblue: [
      123,
      104,
      238
    ],
    mediumspringgreen: [
      0,
      250,
      154
    ],
    mediumturquoise: [
      72,
      209,
      204
    ],
    mediumvioletred: [
      199,
      21,
      133
    ],
    midnightblue: [
      25,
      25,
      112
    ],
    mintcream: [
      245,
      255,
      250
    ],
    mistyrose: [
      255,
      228,
      225
    ],
    moccasin: [
      255,
      228,
      181
    ],
    navajowhite: [
      255,
      222,
      173
    ],
    navy: [
      0,
      0,
      128
    ],
    oldlace: [
      253,
      245,
      230
    ],
    olive: [
      128,
      128,
      0
    ],
    olivedrab: [
      107,
      142,
      35
    ],
    orange: [
      255,
      165,
      0
    ],
    orangered: [
      255,
      69,
      0
    ],
    orchid: [
      218,
      112,
      214
    ],
    palegoldenrod: [
      238,
      232,
      170
    ],
    palegreen: [
      152,
      251,
      152
    ],
    paleturquoise: [
      175,
      238,
      238
    ],
    palevioletred: [
      219,
      112,
      147
    ],
    papayawhip: [
      255,
      239,
      213
    ],
    peachpuff: [
      255,
      218,
      185
    ],
    peru: [
      205,
      133,
      63
    ],
    pink: [
      255,
      192,
      203
    ],
    plum: [
      221,
      160,
      221
    ],
    powderblue: [
      176,
      224,
      230
    ],
    purple: [
      128,
      0,
      128
    ],
    rebeccapurple: [
      102,
      51,
      153
    ],
    red: [
      255,
      0,
      0
    ],
    rosybrown: [
      188,
      143,
      143
    ],
    royalblue: [
      65,
      105,
      225
    ],
    saddlebrown: [
      139,
      69,
      19
    ],
    salmon: [
      250,
      128,
      114
    ],
    sandybrown: [
      244,
      164,
      96
    ],
    seagreen: [
      46,
      139,
      87
    ],
    seashell: [
      255,
      245,
      238
    ],
    sienna: [
      160,
      82,
      45
    ],
    silver: [
      192,
      192,
      192
    ],
    skyblue: [
      135,
      206,
      235
    ],
    slateblue: [
      106,
      90,
      205
    ],
    slategray: [
      112,
      128,
      144
    ],
    slategrey: [
      112,
      128,
      144
    ],
    snow: [
      255,
      250,
      250
    ],
    springgreen: [
      0,
      255,
      127
    ],
    steelblue: [
      70,
      130,
      180
    ],
    tan: [
      210,
      180,
      140
    ],
    teal: [
      0,
      128,
      128
    ],
    thistle: [
      216,
      191,
      216
    ],
    tomato: [
      255,
      99,
      71
    ],
    turquoise: [
      64,
      224,
      208
    ],
    violet: [
      238,
      130,
      238
    ],
    wheat: [
      245,
      222,
      179
    ],
    white: [
      255,
      255,
      255
    ],
    whitesmoke: [
      245,
      245,
      245
    ],
    yellow: [
      255,
      255,
      0
    ],
    yellowgreen: [
      154,
      205,
      50
    ]
  };
  for (const t in X) Object.freeze(X[t]);
  const V = Object.freeze(X), ot = /* @__PURE__ */ Object.create(null);
  for (const t in V) Object.hasOwn(V, t) && (ot[V[t]] = t);
  const M = {
    to: {},
    get: {}
  };
  M.get = function(t) {
    const e = t.slice(0, 3).toLowerCase();
    let n, o;
    switch (e) {
      case "hsl": {
        n = M.get.hsl(t), o = "hsl";
        break;
      }
      case "hwb": {
        n = M.get.hwb(t), o = "hwb";
        break;
      }
      default: {
        n = M.get.rgb(t), o = "rgb";
        break;
      }
    }
    return n ? {
      model: o,
      value: n
    } : null;
  };
  M.get.rgb = function(t) {
    if (!t) return null;
    const e = /^#([a-f\d]{3,4})$/i, n = /^#([a-f\d]{6})([a-f\d]{2})?$/i, o = /^rgba?\(\s*([+-]?(?:\d*\.)?\d+(?:e\d+)?)(?=[\s,])\s*(?:,\s*)?([+-]?(?:\d*\.)?\d+(?:e\d+)?)(?=[\s,])\s*(?:,\s*)?([+-]?(?:\d*\.)?\d+(?:e\d+)?)\s*(?:[\s,|/]\s*([+-]?(?:\d*\.)?\d+(?:e\d+)?)(%?)\s*)?\)$/i, s = /^rgba?\(\s*([+-]?[\d.]+)%\s*,?\s*([+-]?[\d.]+)%\s*,?\s*([+-]?[\d.]+)%\s*(?:[\s,|/]\s*([+-]?[\d.]+)(%?)\s*)?\)$/i, a = /^(\w+)$/;
    let r = [
      0,
      0,
      0,
      1
    ], i, l, c;
    if (i = t.match(n)) {
      for (c = i[2], i = i[1], l = 0; l < 3; l++) {
        const h = l * 2;
        r[l] = Number.parseInt(i.slice(h, h + 2), 16);
      }
      c && (r[3] = Number.parseInt(c, 16) / 255);
    } else if (i = t.match(e)) {
      for (i = i[1], c = i[3], l = 0; l < 3; l++) r[l] = Number.parseInt(i[l] + i[l], 16);
      c && (r[3] = Number.parseInt(c + c, 16) / 255);
    } else if (i = t.match(o)) {
      for (l = 0; l < 3; l++) r[l] = Number.parseFloat(i[l + 1]);
      i[4] && (r[3] = i[5] ? Number.parseFloat(i[4]) * 0.01 : Number.parseFloat(i[4]));
    } else if (i = t.match(s)) {
      for (l = 0; l < 3; l++) r[l] = Math.round(Number.parseFloat(i[l + 1]) * 2.55);
      i[4] && (r[3] = i[5] ? Number.parseFloat(i[4]) * 0.01 : Number.parseFloat(i[4]));
    } else return (i = t.toLowerCase().match(a)) ? i[1] === "transparent" ? [
      0,
      0,
      0,
      0
    ] : Object.hasOwn(V, i[1]) ? (r = V[i[1]].slice(), r[3] = 1, r) : null : null;
    for (l = 0; l < 3; l++) r[l] = E(r[l], 0, 255);
    return r[3] = E(r[3], 0, 1), r;
  };
  M.get.hsl = function(t) {
    if (!t) return null;
    const e = /^hsla?\(\s*([+-]?(?:\d{0,3}\.)?\d+)(?:deg)?\s*,?\s*([+-]?[\d.]+)%\s*,?\s*([+-]?[\d.]+)%\s*(?:[,|/]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:e[+-]?\d+)?)\s*)?\)$/i, n = t.match(e);
    if (n) {
      const o = Number.parseFloat(n[4]), s = (Number.parseFloat(n[1]) % 360 + 360) % 360, a = E(Number.parseFloat(n[2]), 0, 100), r = E(Number.parseFloat(n[3]), 0, 100), i = E(Number.isNaN(o) ? 1 : o, 0, 1);
      return [
        s,
        a,
        r,
        i
      ];
    }
    return null;
  };
  M.get.hwb = function(t) {
    if (!t) return null;
    const e = /^hwb\(\s*([+-]?\d{0,3}(?:\.\d+)?)(?:deg)?\s*[\s,]\s*([+-]?[\d.]+)%\s*[\s,]\s*([+-]?[\d.]+)%\s*(?:[\s,]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:e[+-]?\d+)?)\s*)?\)$/i, n = t.match(e);
    if (n) {
      const o = Number.parseFloat(n[4]), s = (Number.parseFloat(n[1]) % 360 + 360) % 360, a = E(Number.parseFloat(n[2]), 0, 100), r = E(Number.parseFloat(n[3]), 0, 100), i = E(Number.isNaN(o) ? 1 : o, 0, 1);
      return [
        s,
        a,
        r,
        i
      ];
    }
    return null;
  };
  M.to.hex = function(...t) {
    return "#" + R(t[0]) + R(t[1]) + R(t[2]) + (t[3] < 1 ? R(Math.round(t[3] * 255)) : "");
  };
  M.to.rgb = function(...t) {
    return t.length < 4 || t[3] === 1 ? "rgb(" + Math.round(t[0]) + ", " + Math.round(t[1]) + ", " + Math.round(t[2]) + ")" : "rgba(" + Math.round(t[0]) + ", " + Math.round(t[1]) + ", " + Math.round(t[2]) + ", " + t[3] + ")";
  };
  M.to.rgb.percent = function(...t) {
    const e = Math.round(t[0] / 255 * 100), n = Math.round(t[1] / 255 * 100), o = Math.round(t[2] / 255 * 100);
    return t.length < 4 || t[3] === 1 ? "rgb(" + e + "%, " + n + "%, " + o + "%)" : "rgba(" + e + "%, " + n + "%, " + o + "%, " + t[3] + ")";
  };
  M.to.hsl = function(...t) {
    return t.length < 4 || t[3] === 1 ? "hsl(" + t[0] + ", " + t[1] + "%, " + t[2] + "%)" : "hsla(" + t[0] + ", " + t[1] + "%, " + t[2] + "%, " + t[3] + ")";
  };
  M.to.hwb = function(...t) {
    let e = "";
    return t.length >= 4 && t[3] !== 1 && (e = ", " + t[3]), "hwb(" + t[0] + ", " + t[1] + "%, " + t[2] + "%" + e + ")";
  };
  M.to.keyword = function(...t) {
    return ot[t.slice(0, 3)];
  };
  function E(t, e, n) {
    return Math.min(Math.max(e, t), n);
  }
  function R(t) {
    const e = Math.round(t).toString(16).toUpperCase();
    return e.length < 2 ? "0" + e : e;
  }
  const st = {};
  for (const t of Object.keys(V)) st[V[t]] = t;
  const u = {
    rgb: {
      channels: 3,
      labels: "rgb"
    },
    hsl: {
      channels: 3,
      labels: "hsl"
    },
    hsv: {
      channels: 3,
      labels: "hsv"
    },
    hwb: {
      channels: 3,
      labels: "hwb"
    },
    cmyk: {
      channels: 4,
      labels: "cmyk"
    },
    xyz: {
      channels: 3,
      labels: "xyz"
    },
    lab: {
      channels: 3,
      labels: "lab"
    },
    oklab: {
      channels: 3,
      labels: [
        "okl",
        "oka",
        "okb"
      ]
    },
    lch: {
      channels: 3,
      labels: "lch"
    },
    oklch: {
      channels: 3,
      labels: [
        "okl",
        "okc",
        "okh"
      ]
    },
    hex: {
      channels: 1,
      labels: [
        "hex"
      ]
    },
    keyword: {
      channels: 1,
      labels: [
        "keyword"
      ]
    },
    ansi16: {
      channels: 1,
      labels: [
        "ansi16"
      ]
    },
    ansi256: {
      channels: 1,
      labels: [
        "ansi256"
      ]
    },
    hcg: {
      channels: 3,
      labels: [
        "h",
        "c",
        "g"
      ]
    },
    apple: {
      channels: 3,
      labels: [
        "r16",
        "g16",
        "b16"
      ]
    },
    gray: {
      channels: 1,
      labels: [
        "gray"
      ]
    }
  }, P = (6 / 29) ** 3;
  function W(t) {
    const e = t > 31308e-7 ? 1.055 * t ** 0.4166666666666667 - 0.055 : t * 12.92;
    return Math.min(Math.max(0, e), 1);
  }
  function $(t) {
    return t > 0.04045 ? ((t + 0.055) / 1.055) ** 2.4 : t / 12.92;
  }
  for (const t of Object.keys(u)) {
    if (!("channels" in u[t])) throw new Error("missing channels property: " + t);
    if (!("labels" in u[t])) throw new Error("missing channel labels property: " + t);
    if (u[t].labels.length !== u[t].channels) throw new Error("channel and label counts mismatch: " + t);
    const { channels: e, labels: n } = u[t];
    delete u[t].channels, delete u[t].labels, Object.defineProperty(u[t], "channels", {
      value: e
    }), Object.defineProperty(u[t], "labels", {
      value: n
    });
  }
  u.rgb.hsl = function(t) {
    const e = t[0] / 255, n = t[1] / 255, o = t[2] / 255, s = Math.min(e, n, o), a = Math.max(e, n, o), r = a - s;
    let i, l;
    switch (a) {
      case s: {
        i = 0;
        break;
      }
      case e: {
        i = (n - o) / r;
        break;
      }
      case n: {
        i = 2 + (o - e) / r;
        break;
      }
      case o: {
        i = 4 + (e - n) / r;
        break;
      }
    }
    i = Math.min(i * 60, 360), i < 0 && (i += 360);
    const c = (s + a) / 2;
    return a === s ? l = 0 : c <= 0.5 ? l = r / (a + s) : l = r / (2 - a - s), [
      i,
      l * 100,
      c * 100
    ];
  };
  u.rgb.hsv = function(t) {
    let e, n, o, s, a;
    const r = t[0] / 255, i = t[1] / 255, l = t[2] / 255, c = Math.max(r, i, l), h = c - Math.min(r, i, l), d = function(f) {
      return (c - f) / 6 / h + 1 / 2;
    };
    if (h === 0) s = 0, a = 0;
    else {
      switch (a = h / c, e = d(r), n = d(i), o = d(l), c) {
        case r: {
          s = o - n;
          break;
        }
        case i: {
          s = 1 / 3 + e - o;
          break;
        }
        case l: {
          s = 2 / 3 + n - e;
          break;
        }
      }
      s < 0 ? s += 1 : s > 1 && (s -= 1);
    }
    return [
      s * 360,
      a * 100,
      c * 100
    ];
  };
  u.rgb.hwb = function(t) {
    const e = t[0], n = t[1];
    let o = t[2];
    const s = u.rgb.hsl(t)[0], a = 1 / 255 * Math.min(e, Math.min(n, o));
    return o = 1 - 1 / 255 * Math.max(e, Math.max(n, o)), [
      s,
      a * 100,
      o * 100
    ];
  };
  u.rgb.oklab = function(t) {
    const e = $(t[0] / 255), n = $(t[1] / 255), o = $(t[2] / 255), s = Math.cbrt(0.4122214708 * e + 0.5363325363 * n + 0.0514459929 * o), a = Math.cbrt(0.2119034982 * e + 0.6806995451 * n + 0.1073969566 * o), r = Math.cbrt(0.0883024619 * e + 0.2817188376 * n + 0.6299787005 * o), i = 0.2104542553 * s + 0.793617785 * a - 0.0040720468 * r, l = 1.9779984951 * s - 2.428592205 * a + 0.4505937099 * r, c = 0.0259040371 * s + 0.7827717662 * a - 0.808675766 * r;
    return [
      i * 100,
      l * 100,
      c * 100
    ];
  };
  u.rgb.cmyk = function(t) {
    const e = t[0] / 255, n = t[1] / 255, o = t[2] / 255, s = Math.min(1 - e, 1 - n, 1 - o), a = (1 - e - s) / (1 - s) || 0, r = (1 - n - s) / (1 - s) || 0, i = (1 - o - s) / (1 - s) || 0;
    return [
      a * 100,
      r * 100,
      i * 100,
      s * 100
    ];
  };
  function yt(t, e) {
    return (t[0] - e[0]) ** 2 + (t[1] - e[1]) ** 2 + (t[2] - e[2]) ** 2;
  }
  u.rgb.keyword = function(t) {
    const e = st[t];
    if (e) return e;
    let n = Number.POSITIVE_INFINITY, o;
    for (const s of Object.keys(V)) {
      const a = V[s], r = yt(t, a);
      r < n && (n = r, o = s);
    }
    return o;
  };
  u.keyword.rgb = function(t) {
    return [
      ...V[t]
    ];
  };
  u.rgb.xyz = function(t) {
    const e = $(t[0] / 255), n = $(t[1] / 255), o = $(t[2] / 255), s = e * 0.4124564 + n * 0.3575761 + o * 0.1804375, a = e * 0.2126729 + n * 0.7151522 + o * 0.072175, r = e * 0.0193339 + n * 0.119192 + o * 0.9503041;
    return [
      s * 100,
      a * 100,
      r * 100
    ];
  };
  u.rgb.lab = function(t) {
    const e = u.rgb.xyz(t);
    let n = e[0], o = e[1], s = e[2];
    n /= 95.047, o /= 100, s /= 108.883, n = n > P ? n ** (1 / 3) : 7.787 * n + 16 / 116, o = o > P ? o ** (1 / 3) : 7.787 * o + 16 / 116, s = s > P ? s ** (1 / 3) : 7.787 * s + 16 / 116;
    const a = 116 * o - 16, r = 500 * (n - o), i = 200 * (o - s);
    return [
      a,
      r,
      i
    ];
  };
  u.hsl.rgb = function(t) {
    const e = t[0] / 360, n = t[1] / 100, o = t[2] / 100;
    let s, a;
    if (n === 0) return a = o * 255, [
      a,
      a,
      a
    ];
    const r = o < 0.5 ? o * (1 + n) : o + n - o * n, i = 2 * o - r, l = [
      0,
      0,
      0
    ];
    for (let c = 0; c < 3; c++) s = e + 1 / 3 * -(c - 1), s < 0 && s++, s > 1 && s--, 6 * s < 1 ? a = i + (r - i) * 6 * s : 2 * s < 1 ? a = r : 3 * s < 2 ? a = i + (r - i) * (2 / 3 - s) * 6 : a = i, l[c] = a * 255;
    return l;
  };
  u.hsl.hsv = function(t) {
    const e = t[0];
    let n = t[1] / 100, o = t[2] / 100, s = n;
    const a = Math.max(o, 0.01);
    o *= 2, n *= o <= 1 ? o : 2 - o, s *= a <= 1 ? a : 2 - a;
    const r = (o + n) / 2, i = o === 0 ? 2 * s / (a + s) : 2 * n / (o + n);
    return [
      e,
      i * 100,
      r * 100
    ];
  };
  u.hsv.rgb = function(t) {
    const e = t[0] / 60, n = t[1] / 100;
    let o = t[2] / 100;
    const s = Math.floor(e) % 6, a = e - Math.floor(e), r = 255 * o * (1 - n), i = 255 * o * (1 - n * a), l = 255 * o * (1 - n * (1 - a));
    switch (o *= 255, s) {
      case 0:
        return [
          o,
          l,
          r
        ];
      case 1:
        return [
          i,
          o,
          r
        ];
      case 2:
        return [
          r,
          o,
          l
        ];
      case 3:
        return [
          r,
          i,
          o
        ];
      case 4:
        return [
          l,
          r,
          o
        ];
      case 5:
        return [
          o,
          r,
          i
        ];
    }
  };
  u.hsv.hsl = function(t) {
    const e = t[0], n = t[1] / 100, o = t[2] / 100, s = Math.max(o, 0.01);
    let a, r;
    r = (2 - n) * o;
    const i = (2 - n) * s;
    return a = n * s, a /= i <= 1 ? i : 2 - i, a = a || 0, r /= 2, [
      e,
      a * 100,
      r * 100
    ];
  };
  u.hwb.rgb = function(t) {
    const e = t[0] / 360;
    let n = t[1] / 100, o = t[2] / 100;
    const s = n + o;
    let a;
    s > 1 && (n /= s, o /= s);
    const r = Math.floor(6 * e), i = 1 - o;
    a = 6 * e - r, (r & 1) !== 0 && (a = 1 - a);
    const l = n + a * (i - n);
    let c, h, d;
    switch (r) {
      default:
      case 6:
      case 0: {
        c = i, h = l, d = n;
        break;
      }
      case 1: {
        c = l, h = i, d = n;
        break;
      }
      case 2: {
        c = n, h = i, d = l;
        break;
      }
      case 3: {
        c = n, h = l, d = i;
        break;
      }
      case 4: {
        c = l, h = n, d = i;
        break;
      }
      case 5: {
        c = i, h = n, d = l;
        break;
      }
    }
    return [
      c * 255,
      h * 255,
      d * 255
    ];
  };
  u.cmyk.rgb = function(t) {
    const e = t[0] / 100, n = t[1] / 100, o = t[2] / 100, s = t[3] / 100, a = 1 - Math.min(1, e * (1 - s) + s), r = 1 - Math.min(1, n * (1 - s) + s), i = 1 - Math.min(1, o * (1 - s) + s);
    return [
      a * 255,
      r * 255,
      i * 255
    ];
  };
  u.xyz.rgb = function(t) {
    const e = t[0] / 100, n = t[1] / 100, o = t[2] / 100;
    let s, a, r;
    return s = e * 3.2404542 + n * -1.5371385 + o * -0.4985314, a = e * -0.969266 + n * 1.8760108 + o * 0.041556, r = e * 0.0556434 + n * -0.2040259 + o * 1.0572252, s = W(s), a = W(a), r = W(r), [
      s * 255,
      a * 255,
      r * 255
    ];
  };
  u.xyz.lab = function(t) {
    let e = t[0], n = t[1], o = t[2];
    e /= 95.047, n /= 100, o /= 108.883, e = e > P ? e ** (1 / 3) : 7.787 * e + 16 / 116, n = n > P ? n ** (1 / 3) : 7.787 * n + 16 / 116, o = o > P ? o ** (1 / 3) : 7.787 * o + 16 / 116;
    const s = 116 * n - 16, a = 500 * (e - n), r = 200 * (n - o);
    return [
      s,
      a,
      r
    ];
  };
  u.xyz.oklab = function(t) {
    const e = t[0] / 100, n = t[1] / 100, o = t[2] / 100, s = Math.cbrt(0.8189330101 * e + 0.3618667424 * n - 0.1288597137 * o), a = Math.cbrt(0.0329845436 * e + 0.9293118715 * n + 0.0361456387 * o), r = Math.cbrt(0.0482003018 * e + 0.2643662691 * n + 0.633851707 * o), i = 0.2104542553 * s + 0.793617785 * a - 0.0040720468 * r, l = 1.9779984951 * s - 2.428592205 * a + 0.4505937099 * r, c = 0.0259040371 * s + 0.7827717662 * a - 0.808675766 * r;
    return [
      i * 100,
      l * 100,
      c * 100
    ];
  };
  u.oklab.oklch = function(t) {
    return u.lab.lch(t);
  };
  u.oklab.xyz = function(t) {
    const e = t[0] / 100, n = t[1] / 100, o = t[2] / 100, s = (0.999999998 * e + 0.396337792 * n + 0.215803758 * o) ** 3, a = (1.000000008 * e - 0.105561342 * n - 0.063854175 * o) ** 3, r = (1.000000055 * e - 0.089484182 * n - 1.291485538 * o) ** 3, i = 1.227013851 * s - 0.55779998 * a + 0.281256149 * r, l = -0.040580178 * s + 1.11225687 * a - 0.071676679 * r, c = -0.076381285 * s - 0.421481978 * a + 1.58616322 * r;
    return [
      i * 100,
      l * 100,
      c * 100
    ];
  };
  u.oklab.rgb = function(t) {
    const e = t[0] / 100, n = t[1] / 100, o = t[2] / 100, s = (e + 0.3963377774 * n + 0.2158037573 * o) ** 3, a = (e - 0.1055613458 * n - 0.0638541728 * o) ** 3, r = (e - 0.0894841775 * n - 1.291485548 * o) ** 3, i = W(4.0767416621 * s - 3.3077115913 * a + 0.2309699292 * r), l = W(-1.2684380046 * s + 2.6097574011 * a - 0.3413193965 * r), c = W(-0.0041960863 * s - 0.7034186147 * a + 1.707614701 * r);
    return [
      i * 255,
      l * 255,
      c * 255
    ];
  };
  u.oklch.oklab = function(t) {
    return u.lch.lab(t);
  };
  u.lab.xyz = function(t) {
    const e = t[0], n = t[1], o = t[2];
    let s, a, r;
    a = (e + 16) / 116, s = n / 500 + a, r = a - o / 200;
    const i = a ** 3, l = s ** 3, c = r ** 3;
    return a = i > P ? i : (a - 16 / 116) / 7.787, s = l > P ? l : (s - 16 / 116) / 7.787, r = c > P ? c : (r - 16 / 116) / 7.787, s *= 95.047, a *= 100, r *= 108.883, [
      s,
      a,
      r
    ];
  };
  u.lab.lch = function(t) {
    const e = t[0], n = t[1], o = t[2];
    let s;
    s = Math.atan2(o, n) * 360 / 2 / Math.PI, s < 0 && (s += 360);
    const r = Math.sqrt(n * n + o * o);
    return [
      e,
      r,
      s
    ];
  };
  u.lch.lab = function(t) {
    const e = t[0], n = t[1], s = t[2] / 360 * 2 * Math.PI, a = n * Math.cos(s), r = n * Math.sin(s);
    return [
      e,
      a,
      r
    ];
  };
  u.rgb.ansi16 = function(t, e = null) {
    const [n, o, s] = t;
    let a = e === null ? u.rgb.hsv(t)[2] : e;
    if (a = Math.round(a / 50), a === 0) return 30;
    let r = 30 + (Math.round(s / 255) << 2 | Math.round(o / 255) << 1 | Math.round(n / 255));
    return a === 2 && (r += 60), r;
  };
  u.hsv.ansi16 = function(t) {
    return u.rgb.ansi16(u.hsv.rgb(t), t[2]);
  };
  u.rgb.ansi256 = function(t) {
    const e = t[0], n = t[1], o = t[2];
    return e >> 4 === n >> 4 && n >> 4 === o >> 4 ? e < 8 ? 16 : e > 248 ? 231 : Math.round((e - 8) / 247 * 24) + 232 : 16 + 36 * Math.round(e / 255 * 5) + 6 * Math.round(n / 255 * 5) + Math.round(o / 255 * 5);
  };
  u.ansi16.rgb = function(t) {
    t = t[0];
    let e = t % 10;
    if (e === 0 || e === 7) return t > 50 && (e += 3.5), e = e / 10.5 * 255, [
      e,
      e,
      e
    ];
    const n = (Math.trunc(t > 50) + 1) * 0.5, o = (e & 1) * n * 255, s = (e >> 1 & 1) * n * 255, a = (e >> 2 & 1) * n * 255;
    return [
      o,
      s,
      a
    ];
  };
  u.ansi256.rgb = function(t) {
    if (t = t[0], t >= 232) {
      const a = (t - 232) * 10 + 8;
      return [
        a,
        a,
        a
      ];
    }
    t -= 16;
    let e;
    const n = Math.floor(t / 36) / 5 * 255, o = Math.floor((e = t % 36) / 6) / 5 * 255, s = e % 6 / 5 * 255;
    return [
      n,
      o,
      s
    ];
  };
  u.rgb.hex = function(t) {
    const n = (((Math.round(t[0]) & 255) << 16) + ((Math.round(t[1]) & 255) << 8) + (Math.round(t[2]) & 255)).toString(16).toUpperCase();
    return "000000".slice(n.length) + n;
  };
  u.hex.rgb = function(t) {
    const e = t.toString(16).match(/[a-f\d]{6}|[a-f\d]{3}/i);
    if (!e) return [
      0,
      0,
      0
    ];
    let n = e[0];
    e[0].length === 3 && (n = [
      ...n
    ].map((i) => i + i).join(""));
    const o = Number.parseInt(n, 16), s = o >> 16 & 255, a = o >> 8 & 255, r = o & 255;
    return [
      s,
      a,
      r
    ];
  };
  u.rgb.hcg = function(t) {
    const e = t[0] / 255, n = t[1] / 255, o = t[2] / 255, s = Math.max(Math.max(e, n), o), a = Math.min(Math.min(e, n), o), r = s - a;
    let i;
    const l = r < 1 ? a / (1 - r) : 0;
    return r <= 0 ? i = 0 : s === e ? i = (n - o) / r % 6 : s === n ? i = 2 + (o - e) / r : i = 4 + (e - n) / r, i /= 6, i %= 1, [
      i * 360,
      r * 100,
      l * 100
    ];
  };
  u.hsl.hcg = function(t) {
    const e = t[1] / 100, n = t[2] / 100, o = n < 0.5 ? 2 * e * n : 2 * e * (1 - n);
    let s = 0;
    return o < 1 && (s = (n - 0.5 * o) / (1 - o)), [
      t[0],
      o * 100,
      s * 100
    ];
  };
  u.hsv.hcg = function(t) {
    const e = t[1] / 100, n = t[2] / 100, o = e * n;
    let s = 0;
    return o < 1 && (s = (n - o) / (1 - o)), [
      t[0],
      o * 100,
      s * 100
    ];
  };
  u.hcg.rgb = function(t) {
    const e = t[0] / 360, n = t[1] / 100, o = t[2] / 100;
    if (n === 0) return [
      o * 255,
      o * 255,
      o * 255
    ];
    const s = [
      0,
      0,
      0
    ], a = e % 1 * 6, r = a % 1, i = 1 - r;
    let l = 0;
    switch (Math.floor(a)) {
      case 0: {
        s[0] = 1, s[1] = r, s[2] = 0;
        break;
      }
      case 1: {
        s[0] = i, s[1] = 1, s[2] = 0;
        break;
      }
      case 2: {
        s[0] = 0, s[1] = 1, s[2] = r;
        break;
      }
      case 3: {
        s[0] = 0, s[1] = i, s[2] = 1;
        break;
      }
      case 4: {
        s[0] = r, s[1] = 0, s[2] = 1;
        break;
      }
      default:
        s[0] = 1, s[1] = 0, s[2] = i;
    }
    return l = (1 - n) * o, [
      (n * s[0] + l) * 255,
      (n * s[1] + l) * 255,
      (n * s[2] + l) * 255
    ];
  };
  u.hcg.hsv = function(t) {
    const e = t[1] / 100, n = t[2] / 100, o = e + n * (1 - e);
    let s = 0;
    return o > 0 && (s = e / o), [
      t[0],
      s * 100,
      o * 100
    ];
  };
  u.hcg.hsl = function(t) {
    const e = t[1] / 100, o = t[2] / 100 * (1 - e) + 0.5 * e;
    let s = 0;
    return o > 0 && o < 0.5 ? s = e / (2 * o) : o >= 0.5 && o < 1 && (s = e / (2 * (1 - o))), [
      t[0],
      s * 100,
      o * 100
    ];
  };
  u.hcg.hwb = function(t) {
    const e = t[1] / 100, n = t[2] / 100, o = e + n * (1 - e);
    return [
      t[0],
      (o - e) * 100,
      (1 - o) * 100
    ];
  };
  u.hwb.hcg = function(t) {
    const e = t[1] / 100, o = 1 - t[2] / 100, s = o - e;
    let a = 0;
    return s < 1 && (a = (o - s) / (1 - s)), [
      t[0],
      s * 100,
      a * 100
    ];
  };
  u.apple.rgb = function(t) {
    return [
      t[0] / 65535 * 255,
      t[1] / 65535 * 255,
      t[2] / 65535 * 255
    ];
  };
  u.rgb.apple = function(t) {
    return [
      t[0] / 255 * 65535,
      t[1] / 255 * 65535,
      t[2] / 255 * 65535
    ];
  };
  u.gray.rgb = function(t) {
    return [
      t[0] / 100 * 255,
      t[0] / 100 * 255,
      t[0] / 100 * 255
    ];
  };
  u.gray.hsl = function(t) {
    return [
      0,
      0,
      t[0]
    ];
  };
  u.gray.hsv = u.gray.hsl;
  u.gray.hwb = function(t) {
    return [
      0,
      100,
      t[0]
    ];
  };
  u.gray.cmyk = function(t) {
    return [
      0,
      0,
      0,
      t[0]
    ];
  };
  u.gray.lab = function(t) {
    return [
      t[0],
      0,
      0
    ];
  };
  u.gray.hex = function(t) {
    const e = Math.round(t[0] / 100 * 255) & 255, o = ((e << 16) + (e << 8) + e).toString(16).toUpperCase();
    return "000000".slice(o.length) + o;
  };
  u.rgb.gray = function(t) {
    return [
      (t[0] + t[1] + t[2]) / 3 / 255 * 100
    ];
  };
  function _t() {
    const t = {}, e = Object.keys(u);
    for (let { length: n } = e, o = 0; o < n; o++) t[e[o]] = {
      distance: -1,
      parent: null
    };
    return t;
  }
  function xt(t) {
    const e = _t(), n = [
      t
    ];
    for (e[t].distance = 0; n.length > 0; ) {
      const o = n.pop(), s = Object.keys(u[o]);
      for (let { length: a } = s, r = 0; r < a; r++) {
        const i = s[r], l = e[i];
        l.distance === -1 && (l.distance = e[o].distance + 1, l.parent = o, n.unshift(i));
      }
    }
    return e;
  }
  function wt(t, e) {
    return function(n) {
      return e(t(n));
    };
  }
  function kt(t, e) {
    const n = [
      e[t].parent,
      t
    ];
    let o = u[e[t].parent][t], s = e[t].parent;
    for (; e[s].parent; ) n.unshift(e[s].parent), o = wt(u[e[s].parent][s], o), s = e[s].parent;
    return o.conversion = n, o;
  }
  function Mt(t) {
    const e = xt(t), n = {}, o = Object.keys(e);
    for (let { length: s } = o, a = 0; a < s; a++) {
      const r = o[a];
      e[r].parent !== null && (n[r] = kt(r, e));
    }
    return n;
  }
  const D = {}, Ct = Object.keys(u);
  function jt(t) {
    const e = function(...n) {
      const o = n[0];
      return o == null ? o : (o.length > 1 && (n = o), t(n));
    };
    return "conversion" in t && (e.conversion = t.conversion), e;
  }
  function Dt(t) {
    const e = function(...n) {
      const o = n[0];
      if (o == null) return o;
      o.length > 1 && (n = o);
      const s = t(n);
      if (typeof s == "object") for (let { length: a } = s, r = 0; r < a; r++) s[r] = Math.round(s[r]);
      return s;
    };
    return "conversion" in t && (e.conversion = t.conversion), e;
  }
  for (const t of Ct) {
    D[t] = {}, Object.defineProperty(D[t], "channels", {
      value: u[t].channels
    }), Object.defineProperty(D[t], "labels", {
      value: u[t].labels
    });
    const e = Mt(t), n = Object.keys(e);
    for (const o of n) {
      const s = e[o];
      D[t][o] = Dt(s), D[t][o].raw = jt(s);
    }
  }
  const at = [
    "keyword",
    "gray",
    "hex"
  ], Y = {};
  for (const t of Object.keys(D)) Y[[
    ...D[t].labels
  ].sort().join("")] = t;
  const Z = {};
  function j(t, e) {
    if (!(this instanceof j)) return new j(t, e);
    if (e && e in at && (e = null), e && !(e in D)) throw new Error("Unknown model: " + e);
    let n, o;
    if (t == null) this.model = "rgb", this.color = [
      0,
      0,
      0
    ], this.valpha = 1;
    else if (t instanceof j) this.model = t.model, this.color = [
      ...t.color
    ], this.valpha = t.valpha;
    else if (typeof t == "string") {
      const s = M.get(t);
      if (s === null) throw new Error("Unable to parse color from string: " + t);
      this.model = s.model, o = D[this.model].channels, this.color = s.value.slice(0, o), this.valpha = typeof s.value[o] == "number" ? s.value[o] : 1;
    } else if (t.length > 0) {
      this.model = e || "rgb", o = D[this.model].channels;
      const s = Array.prototype.slice.call(t, 0, o);
      this.color = tt(s, o), this.valpha = typeof t[o] == "number" ? t[o] : 1;
    } else if (typeof t == "number") this.model = "rgb", this.color = [
      t >> 16 & 255,
      t >> 8 & 255,
      t & 255
    ], this.valpha = 1;
    else {
      this.valpha = 1;
      const s = Object.keys(t);
      "alpha" in t && (s.splice(s.indexOf("alpha"), 1), this.valpha = typeof t.alpha == "number" ? t.alpha : 0);
      const a = s.sort().join("");
      if (!(a in Y)) throw new Error("Unable to parse color from object: " + JSON.stringify(t));
      this.model = Y[a];
      const { labels: r } = D[this.model], i = [];
      for (n = 0; n < r.length; n++) i.push(t[r[n]]);
      this.color = tt(i);
    }
    if (Z[this.model]) for (o = D[this.model].channels, n = 0; n < o; n++) {
      const s = Z[this.model][n];
      s && (this.color[n] = s(this.color[n]));
    }
    this.valpha = Math.max(0, Math.min(1, this.valpha)), Object.freeze && Object.freeze(this);
  }
  j.prototype = {
    toString() {
      return this.string();
    },
    toJSON() {
      return this[this.model]();
    },
    string(t) {
      let e = this.model in M.to ? this : this.rgb();
      e = e.round(typeof t == "number" ? t : 1);
      const n = e.valpha === 1 ? e.color : [
        ...e.color,
        this.valpha
      ];
      return M.to[e.model](...n);
    },
    percentString(t) {
      const e = this.rgb().round(typeof t == "number" ? t : 1), n = e.valpha === 1 ? e.color : [
        ...e.color,
        this.valpha
      ];
      return M.to.rgb.percent(...n);
    },
    array() {
      return this.valpha === 1 ? [
        ...this.color
      ] : [
        ...this.color,
        this.valpha
      ];
    },
    object() {
      const t = {}, { channels: e } = D[this.model], { labels: n } = D[this.model];
      for (let o = 0; o < e; o++) t[n[o]] = this.color[o];
      return this.valpha !== 1 && (t.alpha = this.valpha), t;
    },
    unitArray() {
      const t = this.rgb().color;
      return t[0] /= 255, t[1] /= 255, t[2] /= 255, this.valpha !== 1 && t.push(this.valpha), t;
    },
    unitObject() {
      const t = this.rgb().object();
      return t.r /= 255, t.g /= 255, t.b /= 255, this.valpha !== 1 && (t.alpha = this.valpha), t;
    },
    round(t) {
      return t = Math.max(t || 0, 0), new j([
        ...this.color.map(It(t)),
        this.valpha
      ], this.model);
    },
    alpha(t) {
      return t !== void 0 ? new j([
        ...this.color,
        Math.max(0, Math.min(1, t))
      ], this.model) : this.valpha;
    },
    red: x("rgb", 0, k(255)),
    green: x("rgb", 1, k(255)),
    blue: x("rgb", 2, k(255)),
    hue: x([
      "hsl",
      "hsv",
      "hsl",
      "hwb",
      "hcg"
    ], 0, (t) => (t % 360 + 360) % 360),
    saturationl: x("hsl", 1, k(100)),
    lightness: x("hsl", 2, k(100)),
    saturationv: x("hsv", 1, k(100)),
    value: x("hsv", 2, k(100)),
    chroma: x("hcg", 1, k(100)),
    gray: x("hcg", 2, k(100)),
    white: x("hwb", 1, k(100)),
    wblack: x("hwb", 2, k(100)),
    cyan: x("cmyk", 0, k(100)),
    magenta: x("cmyk", 1, k(100)),
    yellow: x("cmyk", 2, k(100)),
    black: x("cmyk", 3, k(100)),
    x: x("xyz", 0, k(95.047)),
    y: x("xyz", 1, k(100)),
    z: x("xyz", 2, k(108.833)),
    l: x("lab", 0, k(100)),
    a: x("lab", 1),
    b: x("lab", 2),
    keyword(t) {
      return t !== void 0 ? new j(t) : D[this.model].keyword(this.color);
    },
    hex(t) {
      return t !== void 0 ? new j(t) : M.to.hex(...this.rgb().round().color);
    },
    hexa(t) {
      if (t !== void 0) return new j(t);
      const e = this.rgb().round().color;
      let n = Math.round(this.valpha * 255).toString(16).toUpperCase();
      return n.length === 1 && (n = "0" + n), M.to.hex(...e) + n;
    },
    rgbNumber() {
      const t = this.rgb().color;
      return (t[0] & 255) << 16 | (t[1] & 255) << 8 | t[2] & 255;
    },
    luminosity() {
      const t = this.rgb().color, e = [];
      for (const [n, o] of t.entries()) {
        const s = o / 255;
        e[n] = s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
      }
      return 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
    },
    contrast(t) {
      const e = this.luminosity(), n = t.luminosity();
      return e > n ? (e + 0.05) / (n + 0.05) : (n + 0.05) / (e + 0.05);
    },
    level(t) {
      const e = this.contrast(t);
      return e >= 7 ? "AAA" : e >= 4.5 ? "AA" : "";
    },
    isDark() {
      const t = this.rgb().color;
      return (t[0] * 2126 + t[1] * 7152 + t[2] * 722) / 1e4 < 128;
    },
    isLight() {
      return !this.isDark();
    },
    negate() {
      const t = this.rgb();
      for (let e = 0; e < 3; e++) t.color[e] = 255 - t.color[e];
      return t;
    },
    lighten(t) {
      const e = this.hsl();
      return e.color[2] += e.color[2] * t, e;
    },
    darken(t) {
      const e = this.hsl();
      return e.color[2] -= e.color[2] * t, e;
    },
    saturate(t) {
      const e = this.hsl();
      return e.color[1] += e.color[1] * t, e;
    },
    desaturate(t) {
      const e = this.hsl();
      return e.color[1] -= e.color[1] * t, e;
    },
    whiten(t) {
      const e = this.hwb();
      return e.color[1] += e.color[1] * t, e;
    },
    blacken(t) {
      const e = this.hwb();
      return e.color[2] += e.color[2] * t, e;
    },
    grayscale() {
      const t = this.rgb().color, e = t[0] * 0.3 + t[1] * 0.59 + t[2] * 0.11;
      return j.rgb(e, e, e);
    },
    fade(t) {
      return this.alpha(this.valpha - this.valpha * t);
    },
    opaquer(t) {
      return this.alpha(this.valpha + this.valpha * t);
    },
    rotate(t) {
      const e = this.hsl();
      let n = e.color[0];
      return n = (n + t) % 360, n = n < 0 ? 360 + n : n, e.color[0] = n, e;
    },
    mix(t, e) {
      if (!t || !t.rgb) throw new Error('Argument to "mix" was not a Color instance, but rather an instance of ' + typeof t);
      const n = t.rgb(), o = this.rgb(), s = e === void 0 ? 0.5 : e, a = 2 * s - 1, r = n.alpha() - o.alpha(), i = ((a * r === -1 ? a : (a + r) / (1 + a * r)) + 1) / 2, l = 1 - i;
      return j.rgb(i * n.red() + l * o.red(), i * n.green() + l * o.green(), i * n.blue() + l * o.blue(), n.alpha() * s + o.alpha() * (1 - s));
    }
  };
  for (const t of Object.keys(D)) {
    if (at.includes(t)) continue;
    const { channels: e } = D[t];
    j.prototype[t] = function(...n) {
      return this.model === t ? new j(this) : n.length > 0 ? new j(n, t) : new j([
        ...Tt(D[this.model][t].raw(this.color)),
        this.valpha
      ], t);
    }, j[t] = function(...n) {
      let o = n[0];
      return typeof o == "number" && (o = tt(n, e)), new j(o, t);
    };
  }
  function St(t, e) {
    return Number(t.toFixed(e));
  }
  function It(t) {
    return function(e) {
      return St(e, t);
    };
  }
  function x(t, e, n) {
    t = Array.isArray(t) ? t : [
      t
    ];
    for (const o of t) (Z[o] || (Z[o] = []))[e] = n;
    return t = t[0], function(o) {
      let s;
      return o !== void 0 ? (n && (o = n(o)), s = this[t](), s.color[e] = o, s) : (s = this[t]().color[e], n && (s = n(s)), s);
    };
  }
  function k(t) {
    return function(e) {
      return Math.max(0, Math.min(t, e));
    };
  }
  function Tt(t) {
    return Array.isArray(t) ? t : [
      t
    ];
  }
  function tt(t, e) {
    for (let n = 0; n < e; n++) typeof t[n] != "number" && (t[n] = 0);
    return t;
  }
  function U() {
    return U = Object.assign ? Object.assign.bind() : function(t) {
      for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e];
        for (var o in n) ({}).hasOwnProperty.call(n, o) && (t[o] = n[o]);
      }
      return t;
    }, U.apply(null, arguments);
  }
  var B = function(t, e) {
    return t < e ? -1 : t > e ? 1 : 0;
  }, rt = function(t) {
    return t.reduce(function(e, n) {
      return e + n;
    }, 0);
  }, Ft = (function() {
    function t(n) {
      this.colors = n;
    }
    var e = t.prototype;
    return e.palette = function() {
      return this.colors;
    }, e.map = function(n) {
      return n;
    }, t;
  })(), zt = (function() {
    function t(a, r, i) {
      return (a << 10) + (r << 5) + i;
    }
    function e(a) {
      var r = [], i = false;
      function l() {
        r.sort(a), i = true;
      }
      return {
        push: function(c) {
          r.push(c), i = false;
        },
        peek: function(c) {
          return i || l(), c === void 0 && (c = r.length - 1), r[c];
        },
        pop: function() {
          return i || l(), r.pop();
        },
        size: function() {
          return r.length;
        },
        map: function(c) {
          return r.map(c);
        },
        debug: function() {
          return i || l(), r;
        }
      };
    }
    function n(a, r, i, l, c, h, d) {
      var f = this;
      f.r1 = a, f.r2 = r, f.g1 = i, f.g2 = l, f.b1 = c, f.b2 = h, f.histo = d;
    }
    function o() {
      this.vboxes = new e(function(a, r) {
        return B(a.vbox.count() * a.vbox.volume(), r.vbox.count() * r.vbox.volume());
      });
    }
    function s(a, r) {
      if (r.count()) {
        var i = r.r2 - r.r1 + 1, l = r.g2 - r.g1 + 1, c = Math.max.apply(null, [
          i,
          l,
          r.b2 - r.b1 + 1
        ]);
        if (r.count() == 1) return [
          r.copy()
        ];
        var h, d, f, y, w = 0, _ = [], C = [];
        if (c == i) for (h = r.r1; h <= r.r2; h++) {
          for (y = 0, d = r.g1; d <= r.g2; d++) for (f = r.b1; f <= r.b2; f++) y += a[t(h, d, f)] || 0;
          _[h] = w += y;
        }
        else if (c == l) for (h = r.g1; h <= r.g2; h++) {
          for (y = 0, d = r.r1; d <= r.r2; d++) for (f = r.b1; f <= r.b2; f++) y += a[t(d, h, f)] || 0;
          _[h] = w += y;
        }
        else for (h = r.b1; h <= r.b2; h++) {
          for (y = 0, d = r.r1; d <= r.r2; d++) for (f = r.g1; f <= r.g2; f++) y += a[t(d, f, h)] || 0;
          _[h] = w += y;
        }
        return _.forEach(function(I, p) {
          C[p] = w - I;
        }), (function(I) {
          var p, b, m, v, S, z = I + "1", T = I + "2", O = 0;
          for (h = r[z]; h <= r[T]; h++) if (_[h] > w / 2) {
            for (m = r.copy(), v = r.copy(), S = (p = h - r[z]) <= (b = r[T] - h) ? Math.min(r[T] - 1, ~~(h + b / 2)) : Math.max(r[z], ~~(h - 1 - p / 2)); !_[S]; ) S++;
            for (O = C[S]; !O && _[S - 1]; ) O = C[--S];
            return m[T] = S, v[z] = m[T] + 1, [
              m,
              v
            ];
          }
        })(c == i ? "r" : c == l ? "g" : "b");
      }
    }
    return n.prototype = {
      volume: function(a) {
        var r = this;
        return r._volume && !a || (r._volume = (r.r2 - r.r1 + 1) * (r.g2 - r.g1 + 1) * (r.b2 - r.b1 + 1)), r._volume;
      },
      count: function(a) {
        var r = this, i = r.histo;
        if (!r._count_set || a) {
          var l, c, h, d = 0;
          for (l = r.r1; l <= r.r2; l++) for (c = r.g1; c <= r.g2; c++) for (h = r.b1; h <= r.b2; h++) d += i[t(l, c, h)] || 0;
          r._count = d, r._count_set = true;
        }
        return r._count;
      },
      copy: function() {
        var a = this;
        return new n(a.r1, a.r2, a.g1, a.g2, a.b1, a.b2, a.histo);
      },
      avg: function(a) {
        var r = this, i = r.histo;
        if (!r._avg || a) {
          var l, c, h, d, f = 0, y = 0, w = 0, _ = 0;
          if (r.r1 === r.r2 && r.g1 === r.g2 && r.b1 === r.b2) r._avg = [
            r.r1 << 3,
            r.g1 << 3,
            r.b1 << 3
          ];
          else {
            for (c = r.r1; c <= r.r2; c++) for (h = r.g1; h <= r.g2; h++) for (d = r.b1; d <= r.b2; d++) f += l = i[t(c, h, d)] || 0, y += l * (c + 0.5) * 8, w += l * (h + 0.5) * 8, _ += l * (d + 0.5) * 8;
            r._avg = f ? [
              ~~(y / f),
              ~~(w / f),
              ~~(_ / f)
            ] : [
              ~~(8 * (r.r1 + r.r2 + 1) / 2),
              ~~(8 * (r.g1 + r.g2 + 1) / 2),
              ~~(8 * (r.b1 + r.b2 + 1) / 2)
            ];
          }
        }
        return r._avg;
      },
      contains: function(a) {
        var r = this, i = a[0] >> 3;
        return gval = a[1] >> 3, bval = a[2] >> 3, i >= r.r1 && i <= r.r2 && gval >= r.g1 && gval <= r.g2 && bval >= r.b1 && bval <= r.b2;
      }
    }, o.prototype = {
      push: function(a) {
        this.vboxes.push({
          vbox: a,
          color: a.avg()
        });
      },
      palette: function() {
        return this.vboxes.map(function(a) {
          return a.color;
        });
      },
      size: function() {
        return this.vboxes.size();
      },
      map: function(a) {
        for (var r = this.vboxes, i = 0; i < r.size(); i++) if (r.peek(i).vbox.contains(a)) return r.peek(i).color;
        return this.nearest(a);
      },
      nearest: function(a) {
        for (var r, i, l, c = this.vboxes, h = 0; h < c.size(); h++) ((i = Math.sqrt(Math.pow(a[0] - c.peek(h).color[0], 2) + Math.pow(a[1] - c.peek(h).color[1], 2) + Math.pow(a[2] - c.peek(h).color[2], 2))) < r || r === void 0) && (r = i, l = c.peek(h).color);
        return l;
      },
      forcebw: function() {
        var a = this.vboxes;
        a.sort(function(c, h) {
          return B(rt(c.color), rt(h.color));
        });
        var r = a[0].color;
        r[0] < 5 && r[1] < 5 && r[2] < 5 && (a[0].color = [
          0,
          0,
          0
        ]);
        var i = a.length - 1, l = a[i].color;
        l[0] > 251 && l[1] > 251 && l[2] > 251 && (a[i].color = [
          255,
          255,
          255
        ]);
      }
    }, {
      quantize: function(a, r) {
        if (!Number.isInteger(r) || r < 1 || r > 256) throw new Error("Invalid maximum color count. It must be an integer between 1 and 256.");
        if (!a.length || r < 2 || r > 256 || !a.length || r < 2 || r > 256) return false;
        for (var i = [], l = /* @__PURE__ */ new Set(), c = 0; c < a.length; c++) {
          var h = a[c], d = h.join(",");
          l.has(d) || (l.add(d), i.push(h));
        }
        if (i.length <= r) return new Ft(i);
        var f = (function(p) {
          var b, m = new Array(32768);
          return p.forEach(function(v) {
            b = t(v[0] >> 3, v[1] >> 3, v[2] >> 3), m[b] = (m[b] || 0) + 1;
          }), m;
        })(a);
        f.forEach(function() {
        });
        var y = (function(p, b) {
          var m, v, S, z = 1e6, T = 0, O = 1e6, H = 0, K = 1e6, G = 0;
          return p.forEach(function(J) {
            (m = J[0] >> 3) < z ? z = m : m > T && (T = m), (v = J[1] >> 3) < O ? O = v : v > H && (H = v), (S = J[2] >> 3) < K ? K = S : S > G && (G = S);
          }), new n(z, T, O, H, K, G, b);
        })(a, f), w = new e(function(p, b) {
          return B(p.count(), b.count());
        });
        function _(p, b) {
          for (var m, v = p.size(), S = 0; S < 1e3; ) {
            if (v >= b || S++ > 1e3) return;
            if ((m = p.pop()).count()) {
              var z = s(f, m), T = z[0], O = z[1];
              if (!T) return;
              p.push(T), O && (p.push(O), v++);
            } else p.push(m), S++;
          }
        }
        w.push(y), _(w, 0.75 * r);
        for (var C = new e(function(p, b) {
          return B(p.count() * p.volume(), b.count() * b.volume());
        }); w.size(); ) C.push(w.pop());
        _(C, r);
        for (var I = new o(); C.size(); ) I.push(C.pop());
        return I;
      }
    };
  })().quantize, Q = function(t, e, n, o) {
    for (var s, a, r, i, l, c = o || {}, h = c.ignoreWhite, d = h === void 0 || h, f = c.whiteThreshold, y = f === void 0 ? 250 : f, w = c.alphaThreshold, _ = w === void 0 ? 125 : w, C = c.minSaturation, I = C === void 0 ? 0 : C, p = t, b = [], m = 0; m < e; m += n) if (a = p[0 + (s = 4 * m)], r = p[s + 1], i = p[s + 2], !((l = p[s + 3]) !== void 0 && l < _ || d && a > y && r > y && i > y)) {
      if (I > 0) {
        var v = Math.max(a, r, i);
        if (v === 0 || (v - Math.min(a, r, i)) / v < I) continue;
      }
      b.push([
        a,
        r,
        i
      ]);
    }
    return b;
  }, Ot = function(t) {
    var e = t.colorCount, n = t.quality;
    if (e !== void 0 && Number.isInteger(e)) {
      if (e === 1) throw new Error("colorCount should be between 2 and 20. To get one color, call getColor() instead of getPalette()");
      e = Math.max(e, 2), e = Math.min(e, 20);
    } else e = 10;
    return (n === void 0 || !Number.isInteger(n) || n < 1) && (n = 10), {
      colorCount: e,
      quality: n,
      ignoreWhite: t.ignoreWhite === void 0 || !!t.ignoreWhite,
      whiteThreshold: typeof t.whiteThreshold == "number" ? t.whiteThreshold : 250,
      alphaThreshold: typeof t.alphaThreshold == "number" ? t.alphaThreshold : 125,
      minSaturation: typeof t.minSaturation == "number" ? Math.max(0, Math.min(1, t.minSaturation)) : 0
    };
  }, A = function() {
  };
  A.prototype.getColor = function(t, e) {
    if (typeof e == "object" && e !== null) {
      var n = this.getPalette(t, U({
        colorCount: 5
      }, e));
      return n === null ? null : n[0];
    }
    var o = this.getPalette(t, 5, e);
    return o === null ? null : o[0];
  }, A.prototype.getPalette = function(t, e, n) {
    var o, s, a, r = {
      ignoreWhite: (o = Ot(typeof e == "object" && e !== null ? {
        colorCount: e.colorCount,
        quality: e.quality,
        ignoreWhite: e.ignoreWhite,
        whiteThreshold: e.whiteThreshold,
        alphaThreshold: e.alphaThreshold,
        minSaturation: e.minSaturation
      } : {
        colorCount: e,
        quality: n
      })).ignoreWhite,
      whiteThreshold: o.whiteThreshold,
      alphaThreshold: o.alphaThreshold,
      minSaturation: o.minSaturation
    };
    if (!t) throw new Error("sourceImage is required");
    if (t instanceof HTMLImageElement) {
      if (!t.complete) throw new Error('Image has not finished loading. Wait for the "load" event before calling getColor/getPalette.');
      if (!t.naturalWidth) throw new Error("Image has no dimensions. It may not have loaded successfully.");
    }
    try {
      var i = (function(f) {
        if (f instanceof HTMLImageElement) {
          var y = document.createElement("canvas"), w = y.getContext("2d"), _ = y.width = f.naturalWidth, C = y.height = f.naturalHeight;
          return w.drawImage(f, 0, 0, _, C), {
            imageData: w.getImageData(0, 0, _, C),
            pixelCount: _ * C
          };
        }
        if (f instanceof HTMLCanvasElement) {
          var I = f.getContext("2d"), p = f.width, b = f.height;
          return {
            imageData: I.getImageData(0, 0, p, b),
            pixelCount: p * b
          };
        }
        if (typeof ImageData < "u" && f instanceof ImageData) return {
          imageData: f,
          pixelCount: f.width * f.height
        };
        if (typeof ImageBitmap < "u" && f instanceof ImageBitmap) {
          var m = document.createElement("canvas"), v = m.getContext("2d");
          return m.width = f.width, m.height = f.height, v.drawImage(f, 0, 0), {
            imageData: v.getImageData(0, 0, f.width, f.height),
            pixelCount: f.width * f.height
          };
        }
        throw new Error("Unsupported source type. Expected HTMLImageElement, HTMLCanvasElement, ImageData, or ImageBitmap.");
      })(t);
      s = i.imageData, a = i.pixelCount;
    } catch (f) {
      throw f.name === "SecurityError" ? new Error('Image is tainted by cross-origin data. Add crossorigin="anonymous" to the <img> tag and ensure the server sends appropriate CORS headers.', {
        cause: f
      }) : f;
    }
    var l = Q(s.data, a, o.quality, r);
    l.length === 0 && (l = Q(s.data, a, o.quality, U({}, r, {
      ignoreWhite: false
    }))), l.length === 0 && (l = Q(s.data, a, o.quality, U({}, r, {
      ignoreWhite: false,
      alphaThreshold: 0
    })));
    var c = zt(l, o.colorCount), h = c ? c.palette() : null;
    if (h) return h;
    var d = (function(f, y, w) {
      for (var _ = f, C = 0, I = 0, p = 0, b = 0, m = 0; m < y; m += w) {
        var v = 4 * m;
        C += _[v], I += _[v + 1], p += _[v + 2], b++;
      }
      return b === 0 ? null : [
        Math.round(C / b),
        Math.round(I / b),
        Math.round(p / b)
      ];
    })(s.data, a, o.quality);
    return d ? [
      d
    ] : null;
  }, A.prototype.getColorFromUrl = function(t, e, n) {
    var o = this, s = document.createElement("img");
    s.addEventListener("load", function() {
      var a = o.getPalette(s, 5, n);
      e(a ? a[0] : null, t);
    }), s.src = t;
  }, A.prototype.getImageData = function(t, e) {
    var n = new XMLHttpRequest();
    n.open("GET", t, true), n.responseType = "arraybuffer", n.onload = function() {
      if (this.status == 200) {
        for (var o = new Uint8Array(this.response), s = new Array(o.length), a = 0; a < o.length; a++) s[a] = String.fromCharCode(o[a]);
        var r = s.join(""), i = window.btoa(r);
        e("data:image/png;base64," + i);
      }
    }, n.send();
  }, A.prototype.getColorAsync = function(t, e, n) {
    var o = this;
    this.getImageData(t, function(s) {
      var a = document.createElement("img");
      a.addEventListener("load", function() {
        var r = o.getPalette(a, 5, n);
        e(r ? r[0] : null, this);
      }), a.src = s;
    });
  };
  const N = {
    content: {
      display: "flex",
      flex: 1,
      flexDirection: "column",
      justifyContent: "center",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
      position: "relative"
    },
    volume: {
      display: "flex",
      alignItems: "center",
      gap: 10
    },
    seek: {
      display: "flex",
      alignItems: "center",
      gap: 10
    },
    buttons: {
      display: "flex"
    },
    mode: {
      display: "flex"
    },
    title: {
      fontSize: "140%",
      minHeight: 29.6
    },
    artist: {
      minHeight: 21.6
    },
    zIndex: {
      zIndex: 1
    },
    player: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "center"
    },
    volumeSlider: (t) => ({
      color: t.palette.mode === "dark" ? "#fff" : "rgba(0,0,0,0.87)",
      "& .MuiSlider-track": {
        border: "none"
      },
      "& .MuiSlider-thumb": {
        width: 24,
        height: 24,
        backgroundColor: "#fff",
        "&:before": {
          boxShadow: "0 4px 8px rgba(0,0,0,0.4)"
        },
        "&:hover, &.Mui-focusVisible, &.Mui-active": {
          boxShadow: "none"
        }
      }
    })
  }, Nt = [
    "title",
    "artist",
    "cover",
    "state",
    "duration",
    "elapsed",
    "prev",
    "next",
    "volume",
    "mute",
    "repeat",
    "shuffle"
  ], F = async (t, e, n, o) => {
    if (e[t.name]) {
      const s = await o.getObject(e[t.name]);
      if (s && s.common) {
        const a = e[t.name].split(".");
        a.pop();
        const r = await o.getObjectViewSystem("state", `${a.join(".")}.`, `${a.join(".")}.\u9999`);
        if (r) {
          const i = [
            ...Nt
          ];
          Object.values(r).forEach((l) => {
            var _a, _b, _c;
            const c = (_c = (_b = (_a = l == null ? void 0 : l.common) == null ? void 0 : _a.role) == null ? void 0 : _b.match(/^(media\.mode|media|button|level)\.(.*)$/)) == null ? void 0 : _c[2];
            c && i.includes(c) && (!e[c] || e[c] === "nothing_selected") && t.name !== c && (i.splice(i.indexOf(c), 1), e[c] = l._id);
          }), n(e);
        }
      }
    }
  };
  L = class extends vt {
    coverRef = it.createRef();
    setVolumeTimer = null;
    constructor(e) {
      super(e), this.state = {
        ...this.state,
        volume: 0,
        volumeObject: null
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2Player",
        visSet: "vis-2-widgets-nils",
        visName: "Player",
        visWidgetLabel: "player",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "title",
                onChange: F,
                type: "id",
                label: "title"
              },
              {
                name: "artist",
                onChange: F,
                type: "id",
                label: "artist"
              },
              {
                name: "cover",
                onChange: F,
                type: "id",
                label: "cover"
              },
              {
                name: "color",
                type: "color",
                label: "color"
              },
              {
                name: "state",
                onChange: F,
                type: "id",
                label: "state"
              },
              {
                name: "duration",
                onChange: F,
                type: "id",
                label: "duration"
              },
              {
                name: "elapsed",
                onChange: F,
                type: "id",
                label: "elapsed"
              },
              {
                name: "prev",
                onChange: F,
                type: "id",
                label: "prev"
              },
              {
                name: "next",
                onChange: F,
                type: "id",
                label: "next"
              },
              {
                name: "volume",
                onChange: F,
                type: "id",
                label: "volume"
              },
              {
                name: "mute",
                onChange: F,
                type: "id",
                label: "mute"
              },
              {
                name: "repeat",
                onChange: F,
                type: "id",
                label: "repeat"
              },
              {
                name: "shuffle",
                onChange: F,
                type: "id",
                label: "shuffle"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 240,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_player.png"
      };
    }
    getWidgetInfo() {
      return L.getWidgetInfo();
    }
    async propertiesUpdate() {
      try {
        const e = await this.props.context.socket.getObject(this.state.rxData.volume);
        if (e) {
          const n = await this.props.context.socket.getState(this.state.rxData.volume);
          this.setState({
            volumeObject: e,
            volume: (n == null ? void 0 : n.val) || 0
          });
        }
      } catch {
      }
    }
    async componentDidMount() {
      super.componentDidMount(), await this.propertiesUpdate();
    }
    componentWillUnmount() {
      this.setVolumeTimer && (clearTimeout(this.setVolumeTimer), this.setVolumeTimer = null), super.componentWillUnmount();
    }
    async onRxDataChanged(e) {
      e.volume !== this.state.rxData.volume && await this.propertiesUpdate();
    }
    onStateUpdated(e, n) {
      e === this.state.rxData.volume && this.setState({
        volume: (n == null ? void 0 : n.val) || 0
      });
    }
    static getTimeString = (e) => e == null ? "-:-" : `${Math.floor(e / 60)}:${Math.floor(e % 60).toString().padStart(2, "0")}`;
    getColor() {
      return (this.state.rxData.color ? j(this.state.rxData.color).rgb().array() : null) || this.state.coverColor;
    }
    wrapContent(e, n, o, s, a) {
      const r = this.getColor();
      let i;
      r && (i = (r[0] + r[1] + r[2]) / 3 < 128 ? "white" : "black");
      let l = this.getPropertyValue("cover");
      return (l == null ? void 0 : l.startsWith("/")) && (l = `..${l}`), g.jsxs(mt, {
        style: {
          width: "calc(100% - 8px)",
          height: "calc(100% - 8px)",
          margin: 4,
          position: "relative",
          backgroundImage: "none",
          backgroundColor: r ? `rgb(${r.join(", ")}` : void 0,
          color: i
        },
        onClick: a,
        className: "playerContent",
        children: [
          g.jsx("style", {
            children: i ? `
                .playerContent button:not(.MuiIconButton-colorPrimary) .MuiSvgIcon-root {
                    color: ${i};
                }
            ` : null
          }),
          l ? g.jsx("div", {
            style: {
              position: "absolute",
              width: "100%",
              height: "100%",
              top: 0,
              left: 0
            },
            children: g.jsxs("div", {
              style: {
                position: "relative",
                width: "100%",
                height: "100%"
              },
              children: [
                g.jsx("img", {
                  src: l,
                  alt: "cover",
                  crossOrigin: "anonymous",
                  ref: this.coverRef,
                  style: {
                    maxWidth: 0,
                    maxHeight: 0,
                    position: "absolute"
                  },
                  onLoad: () => {
                    const c = this.coverRef.current, d = new A().getColor(c);
                    this.setState({
                      coverColor: d
                    });
                  }
                }),
                g.jsx("div", {
                  style: {
                    width: "70%",
                    height: "100%",
                    backgroundImage: `url(${l})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                    backgroundRepeat: "no-repeat",
                    position: "absolute",
                    right: 0
                  }
                }),
                g.jsx("div", {
                  style: {
                    position: "absolute",
                    width: "70%",
                    height: "100%",
                    right: 0,
                    backgroundImage: r ? `linear-gradient(to right, rgb(${r.join(", ")}), rgba(${r.join(", ")}, 0))` : void 0
                  }
                })
              ]
            })
          }) : null,
          g.jsxs(bt, {
            style: {
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              height: "100%",
              position: "relative",
              ...o
            },
            children: [
              this.state.rxData.widgetTitle ? g.jsxs("div", {
                style: {
                  display: "flex",
                  justifyContent: "space-between",
                  width: "100%",
                  alignItems: "center"
                },
                children: [
                  g.jsx("div", {
                    style: {
                      fontSize: 24,
                      paddingTop: 0,
                      paddingBottom: 4,
                      ...s
                    },
                    children: this.state.rxData.widgetTitle
                  }),
                  n || null
                ]
              }) : n || null,
              e
            ]
          })
        ]
      });
    }
    renderWidgetBody(e) {
      var _a, _b, _c, _d;
      super.renderWidgetBody(e);
      let n = null;
      this.state.rxData.repeat && (parseInt(this.getPropertyValue("repeat")) === 1 ? n = g.jsx(pt, {}) : parseInt(this.getPropertyValue("repeat")) === 2 ? n = g.jsx(et, {}) : n = g.jsx(et, {}));
      const o = this.getColor();
      let s;
      o && (s = (o[0] + o[1] + o[2]) / 3 < 128 ? "white" : "black");
      const a = this.getPropertyValue("state");
      let r = this.getPropertyValue("title"), i = this.getPropertyValue("artist");
      !r && this.props.editMode && (r = "---"), !i && this.props.editMode && (i = "---");
      const l = g.jsxs("div", {
        style: N.content,
        children: [
          g.jsx("div", {
            style: N.zIndex,
            children: g.jsxs("div", {
              style: N.player,
              children: [
                this.state.rxData.title && this.state.rxData.title !== "nothing_selected" ? g.jsx("div", {
                  style: N.title,
                  children: r
                }) : null,
                this.state.rxData.artist && this.state.rxData.artist !== "nothing_selected" ? g.jsx("div", {
                  style: N.artist,
                  children: i
                }) : null,
                this.state.rxData.shuffle && this.state.rxData.shuffle !== "nothing_selected" || this.state.rxData.repeat && this.state.rxData.repeat !== "nothing_selected" ? g.jsxs("div", {
                  style: N.mode,
                  children: [
                    this.state.rxData.repeat && this.state.rxData.volume !== "nothing_selected" ? g.jsx(q, {
                      color: this.getPropertyValue("repeat") ? "primary" : void 0,
                      onClick: () => {
                        let c;
                        parseInt(this.getPropertyValue("repeat")) === 1 ? c = 2 : parseInt(this.getPropertyValue("repeat")) === 2 ? c = 0 : c = 1, this.props.context.setValue(this.state.rxData.repeat, c);
                      },
                      children: n
                    }) : null,
                    this.state.rxData.shuffle && this.state.rxData.shuffle !== "nothing_selected" ? g.jsx(q, {
                      color: this.getPropertyValue("shuffle") ? "primary" : void 0,
                      onClick: () => this.props.context.setValue(this.state.rxData.shuffle, !this.getPropertyValue("shuffle")),
                      children: g.jsx(lt, {})
                    }) : null
                  ]
                }) : null,
                g.jsxs("div", {
                  style: N.buttons,
                  children: [
                    this.state.rxData.prev && this.state.rxData.prev !== "nothing_selected" ? g.jsx(q, {
                      onClick: () => this.props.context.setValue(this.state.rxData.prev, true),
                      children: g.jsx(ct, {
                        fontSize: "large"
                      })
                    }) : null,
                    g.jsx(q, {
                      onClick: () => {
                        const c = this.getPropertyValue("state");
                        typeof c == "string" ? this.props.context.setValue(this.state.rxData.state, c === "play" ? "pause" : "play") : this.props.context.setValue(this.state.rxData.state, !c);
                      },
                      children: a === "play" || a === true ? g.jsx(ut, {
                        fontSize: "large"
                      }) : g.jsx(ht, {
                        fontSize: "large"
                      })
                    }),
                    this.state.rxData.next && this.state.rxData.volume !== "nothing_selected" ? g.jsx(q, {
                      onClick: () => this.props.context.setValue(this.state.rxData.next, true),
                      children: g.jsx(ft, {
                        fontSize: "large"
                      })
                    }) : null
                  ]
                })
              ]
            })
          }),
          g.jsxs("div", {
            style: N.seek,
            children: [
              this.state.rxData.elapsed && this.state.rxData.elapsed !== "nothing_selected" ? L.getTimeString(this.getPropertyValue("elapsed")) : null,
              this.state.rxData.duration && this.state.rxData.duration !== "nothing_selected" ? g.jsx(nt, {
                style: {
                  color: s
                },
                sx: (c) => ({
                  color: c.palette.mode === "dark" ? "#fff" : "rgba(0,0,0,0.87)",
                  height: 4,
                  "& .MuiSlider-thumb": {
                    width: 8,
                    height: 8,
                    transition: "0.3s cubic-bezier(.47,1.64,.41,.8)",
                    "&:before": {
                      boxShadow: "0 2px 12px 0 rgba(0,0,0,0.4)"
                    },
                    "&.Mui-active": {
                      width: 20,
                      height: 20
                    },
                    "&:hover, &.Mui-focusVisible": {
                      boxShadow: `0px 0px 0px 8px ${c.palette.mode === "dark" || s === "white" ? "rgb(255 255 255 / 16%)" : "rgb(0 0 0 / 16%)"}`
                    }
                  },
                  "& .MuiSlider-rail": {
                    opacity: 0.28
                  }
                }),
                size: "small",
                min: 0,
                max: this.getPropertyValue("duration") || 0,
                value: this.getPropertyValue("elapsed") || 0,
                valueLabelDisplay: "auto",
                valueLabelFormat: L.getTimeString,
                slotProps: {
                  input: {
                    readOnly: true
                  }
                }
              }) : null,
              this.state.rxData.duration && this.state.rxData.duration !== "nothing_selected" ? L.getTimeString(this.getPropertyValue("duration")) : null
            ]
          }),
          this.state.rxData.volume && this.state.rxData.volume !== "nothing_selected" || this.state.rxData.mute && this.state.rxData.mute !== "nothing_selected" ? g.jsxs("div", {
            style: N.volume,
            children: [
              this.state.rxData.mute ? g.jsx(q, {
                onClick: () => this.props.context.setValue(this.state.rxData.mute, !this.getPropertyValue("mute")),
                children: this.getPropertyValue("mute") ? g.jsx(dt, {}) : g.jsx(gt, {})
              }) : null,
              this.state.rxData.volume && this.state.rxData.volume !== "nothing_selected" ? g.jsx(nt, {
                sx: N.volumeSlider,
                style: {
                  color: s
                },
                min: ((_b = (_a = this.state.volumeObject) == null ? void 0 : _a.common) == null ? void 0 : _b.min) || 0,
                max: ((_d = (_c = this.state.volumeObject) == null ? void 0 : _c.common) == null ? void 0 : _d.max) || 100,
                value: this.state.volume,
                valueLabelDisplay: "auto",
                onChange: (c, h) => {
                  this.setState({
                    volume: h
                  }, () => {
                    this.setVolumeTimer && clearTimeout(this.setVolumeTimer), this.setVolumeTimer = setTimeout(() => {
                      this.setVolumeTimer = null, this.props.context.setValue(this.state.rxData.volume, this.state.volume);
                    }, 200);
                  });
                }
              }) : null
            ]
          }) : null
        ]
      });
      return this.state.rxData.noCard || e.widget.usedInWidget ? g.jsx("div", {
        style: {
          width: "100%",
          height: "100%"
        },
        children: l
      }) : this.wrapContent(l, null, {
        boxSizing: "border-box",
        paddingBottom: 10
      });
    }
  };
});
export {
  __tla,
  L as default
};
