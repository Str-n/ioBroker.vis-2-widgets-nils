import { j as D, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { e as zt, f as ct, g as Pa, h as La, i as ze, j as Ee, a as Et, k as vi, l as Ta, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { a as Sa, b as Ca, c as Nn, d as ka, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { a as Oa, U as za, __tla as __tla_3 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CRxa-Ic2.js";
import { G as yi } from "./Generic-CC2u2WPj.js";
import { a as Ea, __tla as __tla_4 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react_mf_2_dom__loadShare__.js-DYAq8PKT.js";
let Jn;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  function Ma(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
  }
  function Aa(c, l) {
    for (var s = 0; s < l.length; s++) {
      const d = l[s];
      if (typeof d != "string" && !Array.isArray(d)) {
        for (const f in d) if (f !== "default" && !(f in c)) {
          const m = Object.getOwnPropertyDescriptor(d, f);
          m && Object.defineProperty(c, f, m.get ? m : {
            enumerable: true,
            get: () => d[f]
          });
        }
      }
    }
    return Object.freeze(Object.defineProperty(c, Symbol.toStringTag, {
      value: "Module"
    }));
  }
  var Oe = {
    exports: {}
  };
  var Za = Oe.exports;
  (function(c, l) {
    (function(s, d) {
      d(l);
    })(Za, (function(s) {
      var d = "1.9.4";
      function f(t) {
        var e, i, n, o;
        for (i = 1, n = arguments.length; i < n; i++) {
          o = arguments[i];
          for (e in o) t[e] = o[e];
        }
        return t;
      }
      var m = Object.create || /* @__PURE__ */ (function() {
        function t() {
        }
        return function(e) {
          return t.prototype = e, new t();
        };
      })();
      function g(t, e) {
        var i = Array.prototype.slice;
        if (t.bind) return t.bind.apply(t, i.call(arguments, 1));
        var n = i.call(arguments, 2);
        return function() {
          return t.apply(e, n.length ? n.concat(i.call(arguments)) : arguments);
        };
      }
      var v = 0;
      function _(t) {
        return "_leaflet_id" in t || (t._leaflet_id = ++v), t._leaflet_id;
      }
      function E(t, e, i) {
        var n, o, a, r;
        return r = function() {
          n = false, o && (a.apply(i, o), o = false);
        }, a = function() {
          n ? o = arguments : (t.apply(i, arguments), setTimeout(r, e), n = true);
        }, a;
      }
      function b(t, e, i) {
        var n = e[1], o = e[0], a = n - o;
        return t === n && i ? t : ((t - o) % a + a) % a + o;
      }
      function T() {
        return false;
      }
      function K(t, e) {
        if (e === false) return t;
        var i = Math.pow(10, e === void 0 ? 6 : e);
        return Math.round(t * i) / i;
      }
      function nt(t) {
        return t.trim ? t.trim() : t.replace(/^\s+|\s+$/g, "");
      }
      function dt(t) {
        return nt(t).split(/\s+/);
      }
      function I(t, e) {
        Object.prototype.hasOwnProperty.call(t, "options") || (t.options = t.options ? m(t.options) : {});
        for (var i in e) t.options[i] = e[i];
        return t.options;
      }
      function se(t, e, i) {
        var n = [];
        for (var o in t) n.push(encodeURIComponent(i ? o.toUpperCase() : o) + "=" + encodeURIComponent(t[o]));
        return (!e || e.indexOf("?") === -1 ? "?" : "&") + n.join("&");
      }
      var he = /\{ *([\w_ -]+) *\}/g;
      function Lt(t, e) {
        return t.replace(he, function(i, n) {
          var o = e[n];
          if (o === void 0) throw new Error("No value provided for variable " + i);
          return typeof o == "function" && (o = o(e)), o;
        });
      }
      var ot = Array.isArray || function(t) {
        return Object.prototype.toString.call(t) === "[object Array]";
      };
      function Ze(t, e) {
        for (var i = 0; i < t.length; i++) if (t[i] === e) return i;
        return -1;
      }
      var le = "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=";
      function Ie(t) {
        return window["webkit" + t] || window["moz" + t] || window["ms" + t];
      }
      var Pi = 0;
      function Li(t) {
        var e = +/* @__PURE__ */ new Date(), i = Math.max(0, 16 - (e - Pi));
        return Pi = e + i, window.setTimeout(t, i);
      }
      var Be = window.requestAnimationFrame || Ie("RequestAnimationFrame") || Li, Ti = window.cancelAnimationFrame || Ie("CancelAnimationFrame") || Ie("CancelRequestAnimationFrame") || function(t) {
        window.clearTimeout(t);
      };
      function q(t, e, i) {
        if (i && Be === Li) t.call(e);
        else return Be.call(window, g(t, e));
      }
      function $(t) {
        t && Ti.call(window, t);
      }
      var Yn = {
        __proto__: null,
        extend: f,
        create: m,
        bind: g,
        get lastId() {
          return v;
        },
        stamp: _,
        throttle: E,
        wrapNum: b,
        falseFn: T,
        formatNum: K,
        trim: nt,
        splitWords: dt,
        setOptions: I,
        getParamString: se,
        template: Lt,
        isArray: ot,
        indexOf: Ze,
        emptyImageUrl: le,
        requestFn: Be,
        cancelFn: Ti,
        requestAnimFrame: q,
        cancelAnimFrame: $
      };
      function ft() {
      }
      ft.extend = function(t) {
        var e = function() {
          I(this), this.initialize && this.initialize.apply(this, arguments), this.callInitHooks();
        }, i = e.__super__ = this.prototype, n = m(i);
        n.constructor = e, e.prototype = n;
        for (var o in this) Object.prototype.hasOwnProperty.call(this, o) && o !== "prototype" && o !== "__super__" && (e[o] = this[o]);
        return t.statics && f(e, t.statics), t.includes && (Xn(t.includes), f.apply(null, [
          n
        ].concat(t.includes))), f(n, t), delete n.statics, delete n.includes, n.options && (n.options = i.options ? m(i.options) : {}, f(n.options, t.options)), n._initHooks = [], n.callInitHooks = function() {
          if (!this._initHooksCalled) {
            i.callInitHooks && i.callInitHooks.call(this), this._initHooksCalled = true;
            for (var a = 0, r = n._initHooks.length; a < r; a++) n._initHooks[a].call(this);
          }
        }, e;
      }, ft.include = function(t) {
        var e = this.prototype.options;
        return f(this.prototype, t), t.options && (this.prototype.options = e, this.mergeOptions(t.options)), this;
      }, ft.mergeOptions = function(t) {
        return f(this.prototype.options, t), this;
      }, ft.addInitHook = function(t) {
        var e = Array.prototype.slice.call(arguments, 1), i = typeof t == "function" ? t : function() {
          this[t].apply(this, e);
        };
        return this.prototype._initHooks = this.prototype._initHooks || [], this.prototype._initHooks.push(i), this;
      };
      function Xn(t) {
        if (!(typeof L > "u" || !L || !L.Mixin)) {
          t = ot(t) ? t : [
            t
          ];
          for (var e = 0; e < t.length; e++) t[e] === L.Mixin.Events && console.warn("Deprecated include of L.Mixin.Events: this property will be removed in future releases, please inherit from L.Evented instead.", new Error().stack);
        }
      }
      var Q = {
        on: function(t, e, i) {
          if (typeof t == "object") for (var n in t) this._on(n, t[n], e);
          else {
            t = dt(t);
            for (var o = 0, a = t.length; o < a; o++) this._on(t[o], e, i);
          }
          return this;
        },
        off: function(t, e, i) {
          if (!arguments.length) delete this._events;
          else if (typeof t == "object") for (var n in t) this._off(n, t[n], e);
          else {
            t = dt(t);
            for (var o = arguments.length === 1, a = 0, r = t.length; a < r; a++) o ? this._off(t[a]) : this._off(t[a], e, i);
          }
          return this;
        },
        _on: function(t, e, i, n) {
          if (typeof e != "function") {
            console.warn("wrong listener type: " + typeof e);
            return;
          }
          if (this._listens(t, e, i) === false) {
            i === this && (i = void 0);
            var o = {
              fn: e,
              ctx: i
            };
            n && (o.once = true), this._events = this._events || {}, this._events[t] = this._events[t] || [], this._events[t].push(o);
          }
        },
        _off: function(t, e, i) {
          var n, o, a;
          if (this._events && (n = this._events[t], !!n)) {
            if (arguments.length === 1) {
              if (this._firingCount) for (o = 0, a = n.length; o < a; o++) n[o].fn = T;
              delete this._events[t];
              return;
            }
            if (typeof e != "function") {
              console.warn("wrong listener type: " + typeof e);
              return;
            }
            var r = this._listens(t, e, i);
            if (r !== false) {
              var h = n[r];
              this._firingCount && (h.fn = T, this._events[t] = n = n.slice()), n.splice(r, 1);
            }
          }
        },
        fire: function(t, e, i) {
          if (!this.listens(t, i)) return this;
          var n = f({}, e, {
            type: t,
            target: this,
            sourceTarget: e && e.sourceTarget || this
          });
          if (this._events) {
            var o = this._events[t];
            if (o) {
              this._firingCount = this._firingCount + 1 || 1;
              for (var a = 0, r = o.length; a < r; a++) {
                var h = o[a], u = h.fn;
                h.once && this.off(t, u, h.ctx), u.call(h.ctx || this, n);
              }
              this._firingCount--;
            }
          }
          return i && this._propagateEvent(n), this;
        },
        listens: function(t, e, i, n) {
          typeof t != "string" && console.warn('"string" type argument expected');
          var o = e;
          typeof e != "function" && (n = !!e, o = void 0, i = void 0);
          var a = this._events && this._events[t];
          if (a && a.length && this._listens(t, o, i) !== false) return true;
          if (n) {
            for (var r in this._eventParents) if (this._eventParents[r].listens(t, e, i, n)) return true;
          }
          return false;
        },
        _listens: function(t, e, i) {
          if (!this._events) return false;
          var n = this._events[t] || [];
          if (!e) return !!n.length;
          i === this && (i = void 0);
          for (var o = 0, a = n.length; o < a; o++) if (n[o].fn === e && n[o].ctx === i) return o;
          return false;
        },
        once: function(t, e, i) {
          if (typeof t == "object") for (var n in t) this._on(n, t[n], e, true);
          else {
            t = dt(t);
            for (var o = 0, a = t.length; o < a; o++) this._on(t[o], e, i, true);
          }
          return this;
        },
        addEventParent: function(t) {
          return this._eventParents = this._eventParents || {}, this._eventParents[_(t)] = t, this;
        },
        removeEventParent: function(t) {
          return this._eventParents && delete this._eventParents[_(t)], this;
        },
        _propagateEvent: function(t) {
          for (var e in this._eventParents) this._eventParents[e].fire(t.type, f({
            layer: t.target,
            propagatedFrom: t.target
          }, t), true);
        }
      };
      Q.addEventListener = Q.on, Q.removeEventListener = Q.clearAllEventListeners = Q.off, Q.addOneTimeEventListener = Q.once, Q.fireEvent = Q.fire, Q.hasEventListeners = Q.listens;
      var Ut = ft.extend(Q);
      function M(t, e, i) {
        this.x = i ? Math.round(t) : t, this.y = i ? Math.round(e) : e;
      }
      var Mi = Math.trunc || function(t) {
        return t > 0 ? Math.floor(t) : Math.ceil(t);
      };
      M.prototype = {
        clone: function() {
          return new M(this.x, this.y);
        },
        add: function(t) {
          return this.clone()._add(P(t));
        },
        _add: function(t) {
          return this.x += t.x, this.y += t.y, this;
        },
        subtract: function(t) {
          return this.clone()._subtract(P(t));
        },
        _subtract: function(t) {
          return this.x -= t.x, this.y -= t.y, this;
        },
        divideBy: function(t) {
          return this.clone()._divideBy(t);
        },
        _divideBy: function(t) {
          return this.x /= t, this.y /= t, this;
        },
        multiplyBy: function(t) {
          return this.clone()._multiplyBy(t);
        },
        _multiplyBy: function(t) {
          return this.x *= t, this.y *= t, this;
        },
        scaleBy: function(t) {
          return new M(this.x * t.x, this.y * t.y);
        },
        unscaleBy: function(t) {
          return new M(this.x / t.x, this.y / t.y);
        },
        round: function() {
          return this.clone()._round();
        },
        _round: function() {
          return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
        },
        floor: function() {
          return this.clone()._floor();
        },
        _floor: function() {
          return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this;
        },
        ceil: function() {
          return this.clone()._ceil();
        },
        _ceil: function() {
          return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this;
        },
        trunc: function() {
          return this.clone()._trunc();
        },
        _trunc: function() {
          return this.x = Mi(this.x), this.y = Mi(this.y), this;
        },
        distanceTo: function(t) {
          t = P(t);
          var e = t.x - this.x, i = t.y - this.y;
          return Math.sqrt(e * e + i * i);
        },
        equals: function(t) {
          return t = P(t), t.x === this.x && t.y === this.y;
        },
        contains: function(t) {
          return t = P(t), Math.abs(t.x) <= Math.abs(this.x) && Math.abs(t.y) <= Math.abs(this.y);
        },
        toString: function() {
          return "Point(" + K(this.x) + ", " + K(this.y) + ")";
        }
      };
      function P(t, e, i) {
        return t instanceof M ? t : ot(t) ? new M(t[0], t[1]) : t == null ? t : typeof t == "object" && "x" in t && "y" in t ? new M(t.x, t.y) : new M(t, e, i);
      }
      function N(t, e) {
        if (t) for (var i = e ? [
          t,
          e
        ] : t, n = 0, o = i.length; n < o; n++) this.extend(i[n]);
      }
      N.prototype = {
        extend: function(t) {
          var e, i;
          if (!t) return this;
          if (t instanceof M || typeof t[0] == "number" || "x" in t) e = i = P(t);
          else if (t = J(t), e = t.min, i = t.max, !e || !i) return this;
          return !this.min && !this.max ? (this.min = e.clone(), this.max = i.clone()) : (this.min.x = Math.min(e.x, this.min.x), this.max.x = Math.max(i.x, this.max.x), this.min.y = Math.min(e.y, this.min.y), this.max.y = Math.max(i.y, this.max.y)), this;
        },
        getCenter: function(t) {
          return P((this.min.x + this.max.x) / 2, (this.min.y + this.max.y) / 2, t);
        },
        getBottomLeft: function() {
          return P(this.min.x, this.max.y);
        },
        getTopRight: function() {
          return P(this.max.x, this.min.y);
        },
        getTopLeft: function() {
          return this.min;
        },
        getBottomRight: function() {
          return this.max;
        },
        getSize: function() {
          return this.max.subtract(this.min);
        },
        contains: function(t) {
          var e, i;
          return typeof t[0] == "number" || t instanceof M ? t = P(t) : t = J(t), t instanceof N ? (e = t.min, i = t.max) : e = i = t, e.x >= this.min.x && i.x <= this.max.x && e.y >= this.min.y && i.y <= this.max.y;
        },
        intersects: function(t) {
          t = J(t);
          var e = this.min, i = this.max, n = t.min, o = t.max, a = o.x >= e.x && n.x <= i.x, r = o.y >= e.y && n.y <= i.y;
          return a && r;
        },
        overlaps: function(t) {
          t = J(t);
          var e = this.min, i = this.max, n = t.min, o = t.max, a = o.x > e.x && n.x < i.x, r = o.y > e.y && n.y < i.y;
          return a && r;
        },
        isValid: function() {
          return !!(this.min && this.max);
        },
        pad: function(t) {
          var e = this.min, i = this.max, n = Math.abs(e.x - i.x) * t, o = Math.abs(e.y - i.y) * t;
          return J(P(e.x - n, e.y - o), P(i.x + n, i.y + o));
        },
        equals: function(t) {
          return t ? (t = J(t), this.min.equals(t.getTopLeft()) && this.max.equals(t.getBottomRight())) : false;
        }
      };
      function J(t, e) {
        return !t || t instanceof N ? t : new N(t, e);
      }
      function Y(t, e) {
        if (t) for (var i = e ? [
          t,
          e
        ] : t, n = 0, o = i.length; n < o; n++) this.extend(i[n]);
      }
      Y.prototype = {
        extend: function(t) {
          var e = this._southWest, i = this._northEast, n, o;
          if (t instanceof Z) n = t, o = t;
          else if (t instanceof Y) {
            if (n = t._southWest, o = t._northEast, !n || !o) return this;
          } else return t ? this.extend(O(t) || F(t)) : this;
          return !e && !i ? (this._southWest = new Z(n.lat, n.lng), this._northEast = new Z(o.lat, o.lng)) : (e.lat = Math.min(n.lat, e.lat), e.lng = Math.min(n.lng, e.lng), i.lat = Math.max(o.lat, i.lat), i.lng = Math.max(o.lng, i.lng)), this;
        },
        pad: function(t) {
          var e = this._southWest, i = this._northEast, n = Math.abs(e.lat - i.lat) * t, o = Math.abs(e.lng - i.lng) * t;
          return new Y(new Z(e.lat - n, e.lng - o), new Z(i.lat + n, i.lng + o));
        },
        getCenter: function() {
          return new Z((this._southWest.lat + this._northEast.lat) / 2, (this._southWest.lng + this._northEast.lng) / 2);
        },
        getSouthWest: function() {
          return this._southWest;
        },
        getNorthEast: function() {
          return this._northEast;
        },
        getNorthWest: function() {
          return new Z(this.getNorth(), this.getWest());
        },
        getSouthEast: function() {
          return new Z(this.getSouth(), this.getEast());
        },
        getWest: function() {
          return this._southWest.lng;
        },
        getSouth: function() {
          return this._southWest.lat;
        },
        getEast: function() {
          return this._northEast.lng;
        },
        getNorth: function() {
          return this._northEast.lat;
        },
        contains: function(t) {
          typeof t[0] == "number" || t instanceof Z || "lat" in t ? t = O(t) : t = F(t);
          var e = this._southWest, i = this._northEast, n, o;
          return t instanceof Y ? (n = t.getSouthWest(), o = t.getNorthEast()) : n = o = t, n.lat >= e.lat && o.lat <= i.lat && n.lng >= e.lng && o.lng <= i.lng;
        },
        intersects: function(t) {
          t = F(t);
          var e = this._southWest, i = this._northEast, n = t.getSouthWest(), o = t.getNorthEast(), a = o.lat >= e.lat && n.lat <= i.lat, r = o.lng >= e.lng && n.lng <= i.lng;
          return a && r;
        },
        overlaps: function(t) {
          t = F(t);
          var e = this._southWest, i = this._northEast, n = t.getSouthWest(), o = t.getNorthEast(), a = o.lat > e.lat && n.lat < i.lat, r = o.lng > e.lng && n.lng < i.lng;
          return a && r;
        },
        toBBoxString: function() {
          return [
            this.getWest(),
            this.getSouth(),
            this.getEast(),
            this.getNorth()
          ].join(",");
        },
        equals: function(t, e) {
          return t ? (t = F(t), this._southWest.equals(t.getSouthWest(), e) && this._northEast.equals(t.getNorthEast(), e)) : false;
        },
        isValid: function() {
          return !!(this._southWest && this._northEast);
        }
      };
      function F(t, e) {
        return t instanceof Y ? t : new Y(t, e);
      }
      function Z(t, e, i) {
        if (isNaN(t) || isNaN(e)) throw new Error("Invalid LatLng object: (" + t + ", " + e + ")");
        this.lat = +t, this.lng = +e, i !== void 0 && (this.alt = +i);
      }
      Z.prototype = {
        equals: function(t, e) {
          if (!t) return false;
          t = O(t);
          var i = Math.max(Math.abs(this.lat - t.lat), Math.abs(this.lng - t.lng));
          return i <= (e === void 0 ? 1e-9 : e);
        },
        toString: function(t) {
          return "LatLng(" + K(this.lat, t) + ", " + K(this.lng, t) + ")";
        },
        distanceTo: function(t) {
          return bt.distance(this, O(t));
        },
        wrap: function() {
          return bt.wrapLatLng(this);
        },
        toBounds: function(t) {
          var e = 180 * t / 40075017, i = e / Math.cos(Math.PI / 180 * this.lat);
          return F([
            this.lat - e,
            this.lng - i
          ], [
            this.lat + e,
            this.lng + i
          ]);
        },
        clone: function() {
          return new Z(this.lat, this.lng, this.alt);
        }
      };
      function O(t, e, i) {
        return t instanceof Z ? t : ot(t) && typeof t[0] != "object" ? t.length === 3 ? new Z(t[0], t[1], t[2]) : t.length === 2 ? new Z(t[0], t[1]) : null : t == null ? t : typeof t == "object" && "lat" in t ? new Z(t.lat, "lng" in t ? t.lng : t.lon, t.alt) : e === void 0 ? null : new Z(t, e, i);
      }
      var pt = {
        latLngToPoint: function(t, e) {
          var i = this.projection.project(t), n = this.scale(e);
          return this.transformation._transform(i, n);
        },
        pointToLatLng: function(t, e) {
          var i = this.scale(e), n = this.transformation.untransform(t, i);
          return this.projection.unproject(n);
        },
        project: function(t) {
          return this.projection.project(t);
        },
        unproject: function(t) {
          return this.projection.unproject(t);
        },
        scale: function(t) {
          return 256 * Math.pow(2, t);
        },
        zoom: function(t) {
          return Math.log(t / 256) / Math.LN2;
        },
        getProjectedBounds: function(t) {
          if (this.infinite) return null;
          var e = this.projection.bounds, i = this.scale(t), n = this.transformation.transform(e.min, i), o = this.transformation.transform(e.max, i);
          return new N(n, o);
        },
        infinite: false,
        wrapLatLng: function(t) {
          var e = this.wrapLng ? b(t.lng, this.wrapLng, true) : t.lng, i = this.wrapLat ? b(t.lat, this.wrapLat, true) : t.lat, n = t.alt;
          return new Z(i, e, n);
        },
        wrapLatLngBounds: function(t) {
          var e = t.getCenter(), i = this.wrapLatLng(e), n = e.lat - i.lat, o = e.lng - i.lng;
          if (n === 0 && o === 0) return t;
          var a = t.getSouthWest(), r = t.getNorthEast(), h = new Z(a.lat - n, a.lng - o), u = new Z(r.lat - n, r.lng - o);
          return new Y(h, u);
        }
      }, bt = f({}, pt, {
        wrapLng: [
          -180,
          180
        ],
        R: 6371e3,
        distance: function(t, e) {
          var i = Math.PI / 180, n = t.lat * i, o = e.lat * i, a = Math.sin((e.lat - t.lat) * i / 2), r = Math.sin((e.lng - t.lng) * i / 2), h = a * a + Math.cos(n) * Math.cos(o) * r * r, u = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
          return this.R * u;
        }
      }), Si = 6378137, De = {
        R: Si,
        MAX_LATITUDE: 85.0511287798,
        project: function(t) {
          var e = Math.PI / 180, i = this.MAX_LATITUDE, n = Math.max(Math.min(i, t.lat), -i), o = Math.sin(n * e);
          return new M(this.R * t.lng * e, this.R * Math.log((1 + o) / (1 - o)) / 2);
        },
        unproject: function(t) {
          var e = 180 / Math.PI;
          return new Z((2 * Math.atan(Math.exp(t.y / this.R)) - Math.PI / 2) * e, t.x * e / this.R);
        },
        bounds: (function() {
          var t = Si * Math.PI;
          return new N([
            -t,
            -t
          ], [
            t,
            t
          ]);
        })()
      };
      function Ne(t, e, i, n) {
        if (ot(t)) {
          this._a = t[0], this._b = t[1], this._c = t[2], this._d = t[3];
          return;
        }
        this._a = t, this._b = e, this._c = i, this._d = n;
      }
      Ne.prototype = {
        transform: function(t, e) {
          return this._transform(t.clone(), e);
        },
        _transform: function(t, e) {
          return e = e || 1, t.x = e * (this._a * t.x + this._b), t.y = e * (this._c * t.y + this._d), t;
        },
        untransform: function(t, e) {
          return e = e || 1, new M((t.x / e - this._b) / this._a, (t.y / e - this._d) / this._c);
        }
      };
      function jt(t, e, i, n) {
        return new Ne(t, e, i, n);
      }
      var Re = f({}, bt, {
        code: "EPSG:3857",
        projection: De,
        transformation: (function() {
          var t = 0.5 / (Math.PI * De.R);
          return jt(t, 0.5, -t, 0.5);
        })()
      }), Qn = f({}, Re, {
        code: "EPSG:900913"
      });
      function Ci(t) {
        return document.createElementNS("http://www.w3.org/2000/svg", t);
      }
      function ki(t, e) {
        var i = "", n, o, a, r, h, u;
        for (n = 0, a = t.length; n < a; n++) {
          for (h = t[n], o = 0, r = h.length; o < r; o++) u = h[o], i += (o ? "L" : "M") + u.x + " " + u.y;
          i += e ? x.svg ? "z" : "x" : "";
        }
        return i || "M0 0";
      }
      var He = document.documentElement.style, ue = "ActiveXObject" in window, $n = ue && !document.addEventListener, Oi = "msLaunchUri" in navigator && !("documentMode" in document), Fe = st("webkit"), zi = st("android"), Ei = st("android 2") || st("android 3"), to = parseInt(/WebKit\/([0-9]+)|$/.exec(navigator.userAgent)[1], 10), eo = zi && st("Google") && to < 537 && !("AudioNode" in window), We = !!window.opera, Ai = !Oi && st("chrome"), Zi = st("gecko") && !Fe && !We && !ue, io = !Ai && st("safari"), Ii = st("phantom"), Bi = "OTransition" in He, no = navigator.platform.indexOf("Win") === 0, Di = ue && "transition" in He, Ue = "WebKitCSSMatrix" in window && "m11" in new window.WebKitCSSMatrix() && !Ei, Ni = "MozPerspective" in He, oo = !window.L_DISABLE_3D && (Di || Ue || Ni) && !Bi && !Ii, Gt = typeof orientation < "u" || st("mobile"), ao = Gt && Fe, ro = Gt && Ue, Ri = !window.PointerEvent && window.MSPointerEvent, Hi = !!(window.PointerEvent || Ri), Fi = "ontouchstart" in window || !!window.TouchEvent, so = !window.L_NO_TOUCH && (Fi || Hi), ho = Gt && We, lo = Gt && Zi, uo = (window.devicePixelRatio || window.screen.deviceXDPI / window.screen.logicalXDPI) > 1, co = (function() {
        var t = false;
        try {
          var e = Object.defineProperty({}, "passive", {
            get: function() {
              t = true;
            }
          });
          window.addEventListener("testPassiveEventSupport", T, e), window.removeEventListener("testPassiveEventSupport", T, e);
        } catch {
        }
        return t;
      })(), fo = (function() {
        return !!document.createElement("canvas").getContext;
      })(), je = !!(document.createElementNS && Ci("svg").createSVGRect), po = !!je && (function() {
        var t = document.createElement("div");
        return t.innerHTML = "<svg/>", (t.firstChild && t.firstChild.namespaceURI) === "http://www.w3.org/2000/svg";
      })(), mo = !je && (function() {
        try {
          var t = document.createElement("div");
          t.innerHTML = '<v:shape adj="1"/>';
          var e = t.firstChild;
          return e.style.behavior = "url(#default#VML)", e && typeof e.adj == "object";
        } catch {
          return false;
        }
      })(), _o = navigator.platform.indexOf("Mac") === 0, go = navigator.platform.indexOf("Linux") === 0;
      function st(t) {
        return navigator.userAgent.toLowerCase().indexOf(t) >= 0;
      }
      var x = {
        ie: ue,
        ielt9: $n,
        edge: Oi,
        webkit: Fe,
        android: zi,
        android23: Ei,
        androidStock: eo,
        opera: We,
        chrome: Ai,
        gecko: Zi,
        safari: io,
        phantom: Ii,
        opera12: Bi,
        win: no,
        ie3d: Di,
        webkit3d: Ue,
        gecko3d: Ni,
        any3d: oo,
        mobile: Gt,
        mobileWebkit: ao,
        mobileWebkit3d: ro,
        msPointer: Ri,
        pointer: Hi,
        touch: so,
        touchNative: Fi,
        mobileOpera: ho,
        mobileGecko: lo,
        retina: uo,
        passiveEvents: co,
        canvas: fo,
        svg: je,
        vml: mo,
        inlineSvg: po,
        mac: _o,
        linux: go
      }, Wi = x.msPointer ? "MSPointerDown" : "pointerdown", Ui = x.msPointer ? "MSPointerMove" : "pointermove", ji = x.msPointer ? "MSPointerUp" : "pointerup", Gi = x.msPointer ? "MSPointerCancel" : "pointercancel", Ge = {
        touchstart: Wi,
        touchmove: Ui,
        touchend: ji,
        touchcancel: Gi
      }, Vi = {
        touchstart: Po,
        touchmove: ce,
        touchend: ce,
        touchcancel: ce
      }, At = {}, Ki = false;
      function vo(t, e, i) {
        return e === "touchstart" && wo(), Vi[e] ? (i = Vi[e].bind(this, i), t.addEventListener(Ge[e], i, false), i) : (console.warn("wrong event specified:", e), T);
      }
      function yo(t, e, i) {
        if (!Ge[e]) {
          console.warn("wrong event specified:", e);
          return;
        }
        t.removeEventListener(Ge[e], i, false);
      }
      function xo(t) {
        At[t.pointerId] = t;
      }
      function bo(t) {
        At[t.pointerId] && (At[t.pointerId] = t);
      }
      function qi(t) {
        delete At[t.pointerId];
      }
      function wo() {
        Ki || (document.addEventListener(Wi, xo, true), document.addEventListener(Ui, bo, true), document.addEventListener(ji, qi, true), document.addEventListener(Gi, qi, true), Ki = true);
      }
      function ce(t, e) {
        if (e.pointerType !== (e.MSPOINTER_TYPE_MOUSE || "mouse")) {
          e.touches = [];
          for (var i in At) e.touches.push(At[i]);
          e.changedTouches = [
            e
          ], t(e);
        }
      }
      function Po(t, e) {
        e.MSPOINTER_TYPE_TOUCH && e.pointerType === e.MSPOINTER_TYPE_TOUCH && G(e), ce(t, e);
      }
      function Lo(t) {
        var e = {}, i, n;
        for (n in t) i = t[n], e[n] = i && i.bind ? i.bind(t) : i;
        return t = e, e.type = "dblclick", e.detail = 2, e.isTrusted = false, e._simulated = true, e;
      }
      var To = 200;
      function Mo(t, e) {
        t.addEventListener("dblclick", e);
        var i = 0, n;
        function o(a) {
          if (a.detail !== 1) {
            n = a.detail;
            return;
          }
          if (!(a.pointerType === "mouse" || a.sourceCapabilities && !a.sourceCapabilities.firesTouchEvents)) {
            var r = $i(a);
            if (!(r.some(function(u) {
              return u instanceof HTMLLabelElement && u.attributes.for;
            }) && !r.some(function(u) {
              return u instanceof HTMLInputElement || u instanceof HTMLSelectElement;
            }))) {
              var h = Date.now();
              h - i <= To ? (n++, n === 2 && e(Lo(a))) : n = 1, i = h;
            }
          }
        }
        return t.addEventListener("click", o), {
          dblclick: e,
          simDblclick: o
        };
      }
      function So(t, e) {
        t.removeEventListener("dblclick", e.dblclick), t.removeEventListener("click", e.simDblclick);
      }
      var Ve = pe([
        "transform",
        "webkitTransform",
        "OTransform",
        "MozTransform",
        "msTransform"
      ]), Vt = pe([
        "webkitTransition",
        "transition",
        "OTransition",
        "MozTransition",
        "msTransition"
      ]), Ji = Vt === "webkitTransition" || Vt === "OTransition" ? Vt + "End" : "transitionend";
      function Yi(t) {
        return typeof t == "string" ? document.getElementById(t) : t;
      }
      function Kt(t, e) {
        var i = t.style[e] || t.currentStyle && t.currentStyle[e];
        if ((!i || i === "auto") && document.defaultView) {
          var n = document.defaultView.getComputedStyle(t, null);
          i = n ? n[e] : null;
        }
        return i === "auto" ? null : i;
      }
      function A(t, e, i) {
        var n = document.createElement(t);
        return n.className = e || "", i && i.appendChild(n), n;
      }
      function R(t) {
        var e = t.parentNode;
        e && e.removeChild(t);
      }
      function de(t) {
        for (; t.firstChild; ) t.removeChild(t.firstChild);
      }
      function Zt(t) {
        var e = t.parentNode;
        e && e.lastChild !== t && e.appendChild(t);
      }
      function It(t) {
        var e = t.parentNode;
        e && e.firstChild !== t && e.insertBefore(t, e.firstChild);
      }
      function Ke(t, e) {
        if (t.classList !== void 0) return t.classList.contains(e);
        var i = fe(t);
        return i.length > 0 && new RegExp("(^|\\s)" + e + "(\\s|$)").test(i);
      }
      function C(t, e) {
        if (t.classList !== void 0) for (var i = dt(e), n = 0, o = i.length; n < o; n++) t.classList.add(i[n]);
        else if (!Ke(t, e)) {
          var a = fe(t);
          qe(t, (a ? a + " " : "") + e);
        }
      }
      function H(t, e) {
        t.classList !== void 0 ? t.classList.remove(e) : qe(t, nt((" " + fe(t) + " ").replace(" " + e + " ", " ")));
      }
      function qe(t, e) {
        t.className.baseVal === void 0 ? t.className = e : t.className.baseVal = e;
      }
      function fe(t) {
        return t.correspondingElement && (t = t.correspondingElement), t.className.baseVal === void 0 ? t.className : t.className.baseVal;
      }
      function tt(t, e) {
        "opacity" in t.style ? t.style.opacity = e : "filter" in t.style && Co(t, e);
      }
      function Co(t, e) {
        var i = false, n = "DXImageTransform.Microsoft.Alpha";
        try {
          i = t.filters.item(n);
        } catch {
          if (e === 1) return;
        }
        e = Math.round(e * 100), i ? (i.Enabled = e !== 100, i.Opacity = e) : t.style.filter += " progid:" + n + "(opacity=" + e + ")";
      }
      function pe(t) {
        for (var e = document.documentElement.style, i = 0; i < t.length; i++) if (t[i] in e) return t[i];
        return false;
      }
      function Tt(t, e, i) {
        var n = e || new M(0, 0);
        t.style[Ve] = (x.ie3d ? "translate(" + n.x + "px," + n.y + "px)" : "translate3d(" + n.x + "px," + n.y + "px,0)") + (i ? " scale(" + i + ")" : "");
      }
      function W(t, e) {
        t._leaflet_pos = e, x.any3d ? Tt(t, e) : (t.style.left = e.x + "px", t.style.top = e.y + "px");
      }
      function Mt(t) {
        return t._leaflet_pos || new M(0, 0);
      }
      var qt, Jt, Je;
      if ("onselectstart" in document) qt = function() {
        S(window, "selectstart", G);
      }, Jt = function() {
        B(window, "selectstart", G);
      };
      else {
        var Yt = pe([
          "userSelect",
          "WebkitUserSelect",
          "OUserSelect",
          "MozUserSelect",
          "msUserSelect"
        ]);
        qt = function() {
          if (Yt) {
            var t = document.documentElement.style;
            Je = t[Yt], t[Yt] = "none";
          }
        }, Jt = function() {
          Yt && (document.documentElement.style[Yt] = Je, Je = void 0);
        };
      }
      function Ye() {
        S(window, "dragstart", G);
      }
      function Xe() {
        B(window, "dragstart", G);
      }
      var me, Qe;
      function $e(t) {
        for (; t.tabIndex === -1; ) t = t.parentNode;
        t.style && (_e(), me = t, Qe = t.style.outlineStyle, t.style.outlineStyle = "none", S(window, "keydown", _e));
      }
      function _e() {
        me && (me.style.outlineStyle = Qe, me = void 0, Qe = void 0, B(window, "keydown", _e));
      }
      function Xi(t) {
        do
          t = t.parentNode;
        while ((!t.offsetWidth || !t.offsetHeight) && t !== document.body);
        return t;
      }
      function ti(t) {
        var e = t.getBoundingClientRect();
        return {
          x: e.width / t.offsetWidth || 1,
          y: e.height / t.offsetHeight || 1,
          boundingClientRect: e
        };
      }
      var ko = {
        __proto__: null,
        TRANSFORM: Ve,
        TRANSITION: Vt,
        TRANSITION_END: Ji,
        get: Yi,
        getStyle: Kt,
        create: A,
        remove: R,
        empty: de,
        toFront: Zt,
        toBack: It,
        hasClass: Ke,
        addClass: C,
        removeClass: H,
        setClass: qe,
        getClass: fe,
        setOpacity: tt,
        testProp: pe,
        setTransform: Tt,
        setPosition: W,
        getPosition: Mt,
        get disableTextSelection() {
          return qt;
        },
        get enableTextSelection() {
          return Jt;
        },
        disableImageDrag: Ye,
        enableImageDrag: Xe,
        preventOutline: $e,
        restoreOutline: _e,
        getSizedParentNode: Xi,
        getScale: ti
      };
      function S(t, e, i, n) {
        if (e && typeof e == "object") for (var o in e) ii(t, o, e[o], i);
        else {
          e = dt(e);
          for (var a = 0, r = e.length; a < r; a++) ii(t, e[a], i, n);
        }
        return this;
      }
      var ht = "_leaflet_events";
      function B(t, e, i, n) {
        if (arguments.length === 1) Qi(t), delete t[ht];
        else if (e && typeof e == "object") for (var o in e) ni(t, o, e[o], i);
        else if (e = dt(e), arguments.length === 2) Qi(t, function(h) {
          return Ze(e, h) !== -1;
        });
        else for (var a = 0, r = e.length; a < r; a++) ni(t, e[a], i, n);
        return this;
      }
      function Qi(t, e) {
        for (var i in t[ht]) {
          var n = i.split(/\d/)[0];
          (!e || e(n)) && ni(t, n, null, null, i);
        }
      }
      var ei = {
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        wheel: !("onwheel" in window) && "mousewheel"
      };
      function ii(t, e, i, n) {
        var o = e + _(i) + (n ? "_" + _(n) : "");
        if (t[ht] && t[ht][o]) return this;
        var a = function(h) {
          return i.call(n || t, h || window.event);
        }, r = a;
        !x.touchNative && x.pointer && e.indexOf("touch") === 0 ? a = vo(t, e, a) : x.touch && e === "dblclick" ? a = Mo(t, a) : "addEventListener" in t ? e === "touchstart" || e === "touchmove" || e === "wheel" || e === "mousewheel" ? t.addEventListener(ei[e] || e, a, x.passiveEvents ? {
          passive: false
        } : false) : e === "mouseenter" || e === "mouseleave" ? (a = function(h) {
          h = h || window.event, ai(t, h) && r(h);
        }, t.addEventListener(ei[e], a, false)) : t.addEventListener(e, r, false) : t.attachEvent("on" + e, a), t[ht] = t[ht] || {}, t[ht][o] = a;
      }
      function ni(t, e, i, n, o) {
        o = o || e + _(i) + (n ? "_" + _(n) : "");
        var a = t[ht] && t[ht][o];
        if (!a) return this;
        !x.touchNative && x.pointer && e.indexOf("touch") === 0 ? yo(t, e, a) : x.touch && e === "dblclick" ? So(t, a) : "removeEventListener" in t ? t.removeEventListener(ei[e] || e, a, false) : t.detachEvent("on" + e, a), t[ht][o] = null;
      }
      function St(t) {
        return t.stopPropagation ? t.stopPropagation() : t.originalEvent ? t.originalEvent._stopped = true : t.cancelBubble = true, this;
      }
      function oi(t) {
        return ii(t, "wheel", St), this;
      }
      function Xt(t) {
        return S(t, "mousedown touchstart dblclick contextmenu", St), t._leaflet_disable_click = true, this;
      }
      function G(t) {
        return t.preventDefault ? t.preventDefault() : t.returnValue = false, this;
      }
      function Ct(t) {
        return G(t), St(t), this;
      }
      function $i(t) {
        if (t.composedPath) return t.composedPath();
        for (var e = [], i = t.target; i; ) e.push(i), i = i.parentNode;
        return e;
      }
      function tn(t, e) {
        if (!e) return new M(t.clientX, t.clientY);
        var i = ti(e), n = i.boundingClientRect;
        return new M((t.clientX - n.left) / i.x - e.clientLeft, (t.clientY - n.top) / i.y - e.clientTop);
      }
      var Oo = x.linux && x.chrome ? window.devicePixelRatio : x.mac ? window.devicePixelRatio * 3 : window.devicePixelRatio > 0 ? 2 * window.devicePixelRatio : 1;
      function en(t) {
        return x.edge ? t.wheelDeltaY / 2 : t.deltaY && t.deltaMode === 0 ? -t.deltaY / Oo : t.deltaY && t.deltaMode === 1 ? -t.deltaY * 20 : t.deltaY && t.deltaMode === 2 ? -t.deltaY * 60 : t.deltaX || t.deltaZ ? 0 : t.wheelDelta ? (t.wheelDeltaY || t.wheelDelta) / 2 : t.detail && Math.abs(t.detail) < 32765 ? -t.detail * 20 : t.detail ? t.detail / -32765 * 60 : 0;
      }
      function ai(t, e) {
        var i = e.relatedTarget;
        if (!i) return true;
        try {
          for (; i && i !== t; ) i = i.parentNode;
        } catch {
          return false;
        }
        return i !== t;
      }
      var zo = {
        __proto__: null,
        on: S,
        off: B,
        stopPropagation: St,
        disableScrollPropagation: oi,
        disableClickPropagation: Xt,
        preventDefault: G,
        stop: Ct,
        getPropagationPath: $i,
        getMousePosition: tn,
        getWheelDelta: en,
        isExternalTarget: ai,
        addListener: S,
        removeListener: B
      }, nn = Ut.extend({
        run: function(t, e, i, n) {
          this.stop(), this._el = t, this._inProgress = true, this._duration = i || 0.25, this._easeOutPower = 1 / Math.max(n || 0.5, 0.2), this._startPos = Mt(t), this._offset = e.subtract(this._startPos), this._startTime = +/* @__PURE__ */ new Date(), this.fire("start"), this._animate();
        },
        stop: function() {
          this._inProgress && (this._step(true), this._complete());
        },
        _animate: function() {
          this._animId = q(this._animate, this), this._step();
        },
        _step: function(t) {
          var e = +/* @__PURE__ */ new Date() - this._startTime, i = this._duration * 1e3;
          e < i ? this._runFrame(this._easeOut(e / i), t) : (this._runFrame(1), this._complete());
        },
        _runFrame: function(t, e) {
          var i = this._startPos.add(this._offset.multiplyBy(t));
          e && i._round(), W(this._el, i), this.fire("step");
        },
        _complete: function() {
          $(this._animId), this._inProgress = false, this.fire("end");
        },
        _easeOut: function(t) {
          return 1 - Math.pow(1 - t, this._easeOutPower);
        }
      }), z = Ut.extend({
        options: {
          crs: Re,
          center: void 0,
          zoom: void 0,
          minZoom: void 0,
          maxZoom: void 0,
          layers: [],
          maxBounds: void 0,
          renderer: void 0,
          zoomAnimation: true,
          zoomAnimationThreshold: 4,
          fadeAnimation: true,
          markerZoomAnimation: true,
          transform3DLimit: 8388608,
          zoomSnap: 1,
          zoomDelta: 1,
          trackResize: true
        },
        initialize: function(t, e) {
          e = I(this, e), this._handlers = [], this._layers = {}, this._zoomBoundLayers = {}, this._sizeChanged = true, this._initContainer(t), this._initLayout(), this._onResize = g(this._onResize, this), this._initEvents(), e.maxBounds && this.setMaxBounds(e.maxBounds), e.zoom !== void 0 && (this._zoom = this._limitZoom(e.zoom)), e.center && e.zoom !== void 0 && this.setView(O(e.center), e.zoom, {
            reset: true
          }), this.callInitHooks(), this._zoomAnimated = Vt && x.any3d && !x.mobileOpera && this.options.zoomAnimation, this._zoomAnimated && (this._createAnimProxy(), S(this._proxy, Ji, this._catchTransitionEnd, this)), this._addLayers(this.options.layers);
        },
        setView: function(t, e, i) {
          if (e = e === void 0 ? this._zoom : this._limitZoom(e), t = this._limitCenter(O(t), e, this.options.maxBounds), i = i || {}, this._stop(), this._loaded && !i.reset && i !== true) {
            i.animate !== void 0 && (i.zoom = f({
              animate: i.animate
            }, i.zoom), i.pan = f({
              animate: i.animate,
              duration: i.duration
            }, i.pan));
            var n = this._zoom !== e ? this._tryAnimatedZoom && this._tryAnimatedZoom(t, e, i.zoom) : this._tryAnimatedPan(t, i.pan);
            if (n) return clearTimeout(this._sizeTimer), this;
          }
          return this._resetView(t, e, i.pan && i.pan.noMoveStart), this;
        },
        setZoom: function(t, e) {
          return this._loaded ? this.setView(this.getCenter(), t, {
            zoom: e
          }) : (this._zoom = t, this);
        },
        zoomIn: function(t, e) {
          return t = t || (x.any3d ? this.options.zoomDelta : 1), this.setZoom(this._zoom + t, e);
        },
        zoomOut: function(t, e) {
          return t = t || (x.any3d ? this.options.zoomDelta : 1), this.setZoom(this._zoom - t, e);
        },
        setZoomAround: function(t, e, i) {
          var n = this.getZoomScale(e), o = this.getSize().divideBy(2), a = t instanceof M ? t : this.latLngToContainerPoint(t), r = a.subtract(o).multiplyBy(1 - 1 / n), h = this.containerPointToLatLng(o.add(r));
          return this.setView(h, e, {
            zoom: i
          });
        },
        _getBoundsCenterZoom: function(t, e) {
          e = e || {}, t = t.getBounds ? t.getBounds() : F(t);
          var i = P(e.paddingTopLeft || e.padding || [
            0,
            0
          ]), n = P(e.paddingBottomRight || e.padding || [
            0,
            0
          ]), o = this.getBoundsZoom(t, false, i.add(n));
          if (o = typeof e.maxZoom == "number" ? Math.min(e.maxZoom, o) : o, o === 1 / 0) return {
            center: t.getCenter(),
            zoom: o
          };
          var a = n.subtract(i).divideBy(2), r = this.project(t.getSouthWest(), o), h = this.project(t.getNorthEast(), o), u = this.unproject(r.add(h).divideBy(2).add(a), o);
          return {
            center: u,
            zoom: o
          };
        },
        fitBounds: function(t, e) {
          if (t = F(t), !t.isValid()) throw new Error("Bounds are not valid.");
          var i = this._getBoundsCenterZoom(t, e);
          return this.setView(i.center, i.zoom, e);
        },
        fitWorld: function(t) {
          return this.fitBounds([
            [
              -90,
              -180
            ],
            [
              90,
              180
            ]
          ], t);
        },
        panTo: function(t, e) {
          return this.setView(t, this._zoom, {
            pan: e
          });
        },
        panBy: function(t, e) {
          if (t = P(t).round(), e = e || {}, !t.x && !t.y) return this.fire("moveend");
          if (e.animate !== true && !this.getSize().contains(t)) return this._resetView(this.unproject(this.project(this.getCenter()).add(t)), this.getZoom()), this;
          if (this._panAnim || (this._panAnim = new nn(), this._panAnim.on({
            step: this._onPanTransitionStep,
            end: this._onPanTransitionEnd
          }, this)), e.noMoveStart || this.fire("movestart"), e.animate !== false) {
            C(this._mapPane, "leaflet-pan-anim");
            var i = this._getMapPanePos().subtract(t).round();
            this._panAnim.run(this._mapPane, i, e.duration || 0.25, e.easeLinearity);
          } else this._rawPanBy(t), this.fire("move").fire("moveend");
          return this;
        },
        flyTo: function(t, e, i) {
          if (i = i || {}, i.animate === false || !x.any3d) return this.setView(t, e, i);
          this._stop();
          var n = this.project(this.getCenter()), o = this.project(t), a = this.getSize(), r = this._zoom;
          t = O(t), e = e === void 0 ? r : e;
          var h = Math.max(a.x, a.y), u = h * this.getZoomScale(r, e), p = o.distanceTo(n) || 1, y = 1.42, w = y * y;
          function k(U) {
            var Ce = U ? -1 : 1, ya = U ? u : h, xa = u * u - h * h + Ce * w * w * p * p, ba = 2 * ya * w * p, _i = xa / ba, Dn = Math.sqrt(_i * _i + 1) - _i, wa = Dn < 1e-9 ? -18 : Math.log(Dn);
            return wa;
          }
          function V(U) {
            return (Math.exp(U) - Math.exp(-U)) / 2;
          }
          function j(U) {
            return (Math.exp(U) + Math.exp(-U)) / 2;
          }
          function it(U) {
            return V(U) / j(U);
          }
          var X = k(0);
          function Ft(U) {
            return h * (j(X) / j(X + y * U));
          }
          function ma(U) {
            return h * (j(X) * it(X + y * U) - V(X)) / w;
          }
          function _a(U) {
            return 1 - Math.pow(1 - U, 1.5);
          }
          var ga = Date.now(), In = (k(1) - X) / y, va = i.duration ? 1e3 * i.duration : 1e3 * In * 0.8;
          function Bn() {
            var U = (Date.now() - ga) / va, Ce = _a(U) * In;
            U <= 1 ? (this._flyToFrame = q(Bn, this), this._move(this.unproject(n.add(o.subtract(n).multiplyBy(ma(Ce) / p)), r), this.getScaleZoom(h / Ft(Ce), r), {
              flyTo: true
            })) : this._move(t, e)._moveEnd(true);
          }
          return this._moveStart(true, i.noMoveStart), Bn.call(this), this;
        },
        flyToBounds: function(t, e) {
          var i = this._getBoundsCenterZoom(t, e);
          return this.flyTo(i.center, i.zoom, e);
        },
        setMaxBounds: function(t) {
          return t = F(t), this.listens("moveend", this._panInsideMaxBounds) && this.off("moveend", this._panInsideMaxBounds), t.isValid() ? (this.options.maxBounds = t, this._loaded && this._panInsideMaxBounds(), this.on("moveend", this._panInsideMaxBounds)) : (this.options.maxBounds = null, this);
        },
        setMinZoom: function(t) {
          var e = this.options.minZoom;
          return this.options.minZoom = t, this._loaded && e !== t && (this.fire("zoomlevelschange"), this.getZoom() < this.options.minZoom) ? this.setZoom(t) : this;
        },
        setMaxZoom: function(t) {
          var e = this.options.maxZoom;
          return this.options.maxZoom = t, this._loaded && e !== t && (this.fire("zoomlevelschange"), this.getZoom() > this.options.maxZoom) ? this.setZoom(t) : this;
        },
        panInsideBounds: function(t, e) {
          this._enforcingBounds = true;
          var i = this.getCenter(), n = this._limitCenter(i, this._zoom, F(t));
          return i.equals(n) || this.panTo(n, e), this._enforcingBounds = false, this;
        },
        panInside: function(t, e) {
          e = e || {};
          var i = P(e.paddingTopLeft || e.padding || [
            0,
            0
          ]), n = P(e.paddingBottomRight || e.padding || [
            0,
            0
          ]), o = this.project(this.getCenter()), a = this.project(t), r = this.getPixelBounds(), h = J([
            r.min.add(i),
            r.max.subtract(n)
          ]), u = h.getSize();
          if (!h.contains(a)) {
            this._enforcingBounds = true;
            var p = a.subtract(h.getCenter()), y = h.extend(a).getSize().subtract(u);
            o.x += p.x < 0 ? -y.x : y.x, o.y += p.y < 0 ? -y.y : y.y, this.panTo(this.unproject(o), e), this._enforcingBounds = false;
          }
          return this;
        },
        invalidateSize: function(t) {
          if (!this._loaded) return this;
          t = f({
            animate: false,
            pan: true
          }, t === true ? {
            animate: true
          } : t);
          var e = this.getSize();
          this._sizeChanged = true, this._lastCenter = null;
          var i = this.getSize(), n = e.divideBy(2).round(), o = i.divideBy(2).round(), a = n.subtract(o);
          return !a.x && !a.y ? this : (t.animate && t.pan ? this.panBy(a) : (t.pan && this._rawPanBy(a), this.fire("move"), t.debounceMoveend ? (clearTimeout(this._sizeTimer), this._sizeTimer = setTimeout(g(this.fire, this, "moveend"), 200)) : this.fire("moveend")), this.fire("resize", {
            oldSize: e,
            newSize: i
          }));
        },
        stop: function() {
          return this.setZoom(this._limitZoom(this._zoom)), this.options.zoomSnap || this.fire("viewreset"), this._stop();
        },
        locate: function(t) {
          if (t = this._locateOptions = f({
            timeout: 1e4,
            watch: false
          }, t), !("geolocation" in navigator)) return this._handleGeolocationError({
            code: 0,
            message: "Geolocation not supported."
          }), this;
          var e = g(this._handleGeolocationResponse, this), i = g(this._handleGeolocationError, this);
          return t.watch ? this._locationWatchId = navigator.geolocation.watchPosition(e, i, t) : navigator.geolocation.getCurrentPosition(e, i, t), this;
        },
        stopLocate: function() {
          return navigator.geolocation && navigator.geolocation.clearWatch && navigator.geolocation.clearWatch(this._locationWatchId), this._locateOptions && (this._locateOptions.setView = false), this;
        },
        _handleGeolocationError: function(t) {
          if (this._container._leaflet_id) {
            var e = t.code, i = t.message || (e === 1 ? "permission denied" : e === 2 ? "position unavailable" : "timeout");
            this._locateOptions.setView && !this._loaded && this.fitWorld(), this.fire("locationerror", {
              code: e,
              message: "Geolocation error: " + i + "."
            });
          }
        },
        _handleGeolocationResponse: function(t) {
          if (this._container._leaflet_id) {
            var e = t.coords.latitude, i = t.coords.longitude, n = new Z(e, i), o = n.toBounds(t.coords.accuracy * 2), a = this._locateOptions;
            if (a.setView) {
              var r = this.getBoundsZoom(o);
              this.setView(n, a.maxZoom ? Math.min(r, a.maxZoom) : r);
            }
            var h = {
              latlng: n,
              bounds: o,
              timestamp: t.timestamp
            };
            for (var u in t.coords) typeof t.coords[u] == "number" && (h[u] = t.coords[u]);
            this.fire("locationfound", h);
          }
        },
        addHandler: function(t, e) {
          if (!e) return this;
          var i = this[t] = new e(this);
          return this._handlers.push(i), this.options[t] && i.enable(), this;
        },
        remove: function() {
          if (this._initEvents(true), this.options.maxBounds && this.off("moveend", this._panInsideMaxBounds), this._containerId !== this._container._leaflet_id) throw new Error("Map container is being reused by another instance");
          try {
            delete this._container._leaflet_id, delete this._containerId;
          } catch {
            this._container._leaflet_id = void 0, this._containerId = void 0;
          }
          this._locationWatchId !== void 0 && this.stopLocate(), this._stop(), R(this._mapPane), this._clearControlPos && this._clearControlPos(), this._resizeRequest && ($(this._resizeRequest), this._resizeRequest = null), this._clearHandlers(), this._loaded && this.fire("unload");
          var t;
          for (t in this._layers) this._layers[t].remove();
          for (t in this._panes) R(this._panes[t]);
          return this._layers = [], this._panes = [], delete this._mapPane, delete this._renderer, this;
        },
        createPane: function(t, e) {
          var i = "leaflet-pane" + (t ? " leaflet-" + t.replace("Pane", "") + "-pane" : ""), n = A("div", i, e || this._mapPane);
          return t && (this._panes[t] = n), n;
        },
        getCenter: function() {
          return this._checkIfLoaded(), this._lastCenter && !this._moved() ? this._lastCenter.clone() : this.layerPointToLatLng(this._getCenterLayerPoint());
        },
        getZoom: function() {
          return this._zoom;
        },
        getBounds: function() {
          var t = this.getPixelBounds(), e = this.unproject(t.getBottomLeft()), i = this.unproject(t.getTopRight());
          return new Y(e, i);
        },
        getMinZoom: function() {
          return this.options.minZoom === void 0 ? this._layersMinZoom || 0 : this.options.minZoom;
        },
        getMaxZoom: function() {
          return this.options.maxZoom === void 0 ? this._layersMaxZoom === void 0 ? 1 / 0 : this._layersMaxZoom : this.options.maxZoom;
        },
        getBoundsZoom: function(t, e, i) {
          t = F(t), i = P(i || [
            0,
            0
          ]);
          var n = this.getZoom() || 0, o = this.getMinZoom(), a = this.getMaxZoom(), r = t.getNorthWest(), h = t.getSouthEast(), u = this.getSize().subtract(i), p = J(this.project(h, n), this.project(r, n)).getSize(), y = x.any3d ? this.options.zoomSnap : 1, w = u.x / p.x, k = u.y / p.y, V = e ? Math.max(w, k) : Math.min(w, k);
          return n = this.getScaleZoom(V, n), y && (n = Math.round(n / (y / 100)) * (y / 100), n = e ? Math.ceil(n / y) * y : Math.floor(n / y) * y), Math.max(o, Math.min(a, n));
        },
        getSize: function() {
          return (!this._size || this._sizeChanged) && (this._size = new M(this._container.clientWidth || 0, this._container.clientHeight || 0), this._sizeChanged = false), this._size.clone();
        },
        getPixelBounds: function(t, e) {
          var i = this._getTopLeftPoint(t, e);
          return new N(i, i.add(this.getSize()));
        },
        getPixelOrigin: function() {
          return this._checkIfLoaded(), this._pixelOrigin;
        },
        getPixelWorldBounds: function(t) {
          return this.options.crs.getProjectedBounds(t === void 0 ? this.getZoom() : t);
        },
        getPane: function(t) {
          return typeof t == "string" ? this._panes[t] : t;
        },
        getPanes: function() {
          return this._panes;
        },
        getContainer: function() {
          return this._container;
        },
        getZoomScale: function(t, e) {
          var i = this.options.crs;
          return e = e === void 0 ? this._zoom : e, i.scale(t) / i.scale(e);
        },
        getScaleZoom: function(t, e) {
          var i = this.options.crs;
          e = e === void 0 ? this._zoom : e;
          var n = i.zoom(t * i.scale(e));
          return isNaN(n) ? 1 / 0 : n;
        },
        project: function(t, e) {
          return e = e === void 0 ? this._zoom : e, this.options.crs.latLngToPoint(O(t), e);
        },
        unproject: function(t, e) {
          return e = e === void 0 ? this._zoom : e, this.options.crs.pointToLatLng(P(t), e);
        },
        layerPointToLatLng: function(t) {
          var e = P(t).add(this.getPixelOrigin());
          return this.unproject(e);
        },
        latLngToLayerPoint: function(t) {
          var e = this.project(O(t))._round();
          return e._subtract(this.getPixelOrigin());
        },
        wrapLatLng: function(t) {
          return this.options.crs.wrapLatLng(O(t));
        },
        wrapLatLngBounds: function(t) {
          return this.options.crs.wrapLatLngBounds(F(t));
        },
        distance: function(t, e) {
          return this.options.crs.distance(O(t), O(e));
        },
        containerPointToLayerPoint: function(t) {
          return P(t).subtract(this._getMapPanePos());
        },
        layerPointToContainerPoint: function(t) {
          return P(t).add(this._getMapPanePos());
        },
        containerPointToLatLng: function(t) {
          var e = this.containerPointToLayerPoint(P(t));
          return this.layerPointToLatLng(e);
        },
        latLngToContainerPoint: function(t) {
          return this.layerPointToContainerPoint(this.latLngToLayerPoint(O(t)));
        },
        mouseEventToContainerPoint: function(t) {
          return tn(t, this._container);
        },
        mouseEventToLayerPoint: function(t) {
          return this.containerPointToLayerPoint(this.mouseEventToContainerPoint(t));
        },
        mouseEventToLatLng: function(t) {
          return this.layerPointToLatLng(this.mouseEventToLayerPoint(t));
        },
        _initContainer: function(t) {
          var e = this._container = Yi(t);
          if (e) {
            if (e._leaflet_id) throw new Error("Map container is already initialized.");
          } else throw new Error("Map container not found.");
          S(e, "scroll", this._onScroll, this), this._containerId = _(e);
        },
        _initLayout: function() {
          var t = this._container;
          this._fadeAnimated = this.options.fadeAnimation && x.any3d, C(t, "leaflet-container" + (x.touch ? " leaflet-touch" : "") + (x.retina ? " leaflet-retina" : "") + (x.ielt9 ? " leaflet-oldie" : "") + (x.safari ? " leaflet-safari" : "") + (this._fadeAnimated ? " leaflet-fade-anim" : ""));
          var e = Kt(t, "position");
          e !== "absolute" && e !== "relative" && e !== "fixed" && e !== "sticky" && (t.style.position = "relative"), this._initPanes(), this._initControlPos && this._initControlPos();
        },
        _initPanes: function() {
          var t = this._panes = {};
          this._paneRenderers = {}, this._mapPane = this.createPane("mapPane", this._container), W(this._mapPane, new M(0, 0)), this.createPane("tilePane"), this.createPane("overlayPane"), this.createPane("shadowPane"), this.createPane("markerPane"), this.createPane("tooltipPane"), this.createPane("popupPane"), this.options.markerZoomAnimation || (C(t.markerPane, "leaflet-zoom-hide"), C(t.shadowPane, "leaflet-zoom-hide"));
        },
        _resetView: function(t, e, i) {
          W(this._mapPane, new M(0, 0));
          var n = !this._loaded;
          this._loaded = true, e = this._limitZoom(e), this.fire("viewprereset");
          var o = this._zoom !== e;
          this._moveStart(o, i)._move(t, e)._moveEnd(o), this.fire("viewreset"), n && this.fire("load");
        },
        _moveStart: function(t, e) {
          return t && this.fire("zoomstart"), e || this.fire("movestart"), this;
        },
        _move: function(t, e, i, n) {
          e === void 0 && (e = this._zoom);
          var o = this._zoom !== e;
          return this._zoom = e, this._lastCenter = t, this._pixelOrigin = this._getNewPixelOrigin(t), n ? i && i.pinch && this.fire("zoom", i) : ((o || i && i.pinch) && this.fire("zoom", i), this.fire("move", i)), this;
        },
        _moveEnd: function(t) {
          return t && this.fire("zoomend"), this.fire("moveend");
        },
        _stop: function() {
          return $(this._flyToFrame), this._panAnim && this._panAnim.stop(), this;
        },
        _rawPanBy: function(t) {
          W(this._mapPane, this._getMapPanePos().subtract(t));
        },
        _getZoomSpan: function() {
          return this.getMaxZoom() - this.getMinZoom();
        },
        _panInsideMaxBounds: function() {
          this._enforcingBounds || this.panInsideBounds(this.options.maxBounds);
        },
        _checkIfLoaded: function() {
          if (!this._loaded) throw new Error("Set map center and zoom first.");
        },
        _initEvents: function(t) {
          this._targets = {}, this._targets[_(this._container)] = this;
          var e = t ? B : S;
          e(this._container, "click dblclick mousedown mouseup mouseover mouseout mousemove contextmenu keypress keydown keyup", this._handleDOMEvent, this), this.options.trackResize && e(window, "resize", this._onResize, this), x.any3d && this.options.transform3DLimit && (t ? this.off : this.on).call(this, "moveend", this._onMoveEnd);
        },
        _onResize: function() {
          $(this._resizeRequest), this._resizeRequest = q(function() {
            this.invalidateSize({
              debounceMoveend: true
            });
          }, this);
        },
        _onScroll: function() {
          this._container.scrollTop = 0, this._container.scrollLeft = 0;
        },
        _onMoveEnd: function() {
          var t = this._getMapPanePos();
          Math.max(Math.abs(t.x), Math.abs(t.y)) >= this.options.transform3DLimit && this._resetView(this.getCenter(), this.getZoom());
        },
        _findEventTargets: function(t, e) {
          for (var i = [], n, o = e === "mouseout" || e === "mouseover", a = t.target || t.srcElement, r = false; a; ) {
            if (n = this._targets[_(a)], n && (e === "click" || e === "preclick") && this._draggableMoved(n)) {
              r = true;
              break;
            }
            if (n && n.listens(e, true) && (o && !ai(a, t) || (i.push(n), o)) || a === this._container) break;
            a = a.parentNode;
          }
          return !i.length && !r && !o && this.listens(e, true) && (i = [
            this
          ]), i;
        },
        _isClickDisabled: function(t) {
          for (; t && t !== this._container; ) {
            if (t._leaflet_disable_click) return true;
            t = t.parentNode;
          }
        },
        _handleDOMEvent: function(t) {
          var e = t.target || t.srcElement;
          if (!(!this._loaded || e._leaflet_disable_events || t.type === "click" && this._isClickDisabled(e))) {
            var i = t.type;
            i === "mousedown" && $e(e), this._fireDOMEvent(t, i);
          }
        },
        _mouseEvents: [
          "click",
          "dblclick",
          "mouseover",
          "mouseout",
          "contextmenu"
        ],
        _fireDOMEvent: function(t, e, i) {
          if (t.type === "click") {
            var n = f({}, t);
            n.type = "preclick", this._fireDOMEvent(n, n.type, i);
          }
          var o = this._findEventTargets(t, e);
          if (i) {
            for (var a = [], r = 0; r < i.length; r++) i[r].listens(e, true) && a.push(i[r]);
            o = a.concat(o);
          }
          if (o.length) {
            e === "contextmenu" && G(t);
            var h = o[0], u = {
              originalEvent: t
            };
            if (t.type !== "keypress" && t.type !== "keydown" && t.type !== "keyup") {
              var p = h.getLatLng && (!h._radius || h._radius <= 10);
              u.containerPoint = p ? this.latLngToContainerPoint(h.getLatLng()) : this.mouseEventToContainerPoint(t), u.layerPoint = this.containerPointToLayerPoint(u.containerPoint), u.latlng = p ? h.getLatLng() : this.layerPointToLatLng(u.layerPoint);
            }
            for (r = 0; r < o.length; r++) if (o[r].fire(e, u, true), u.originalEvent._stopped || o[r].options.bubblingMouseEvents === false && Ze(this._mouseEvents, e) !== -1) return;
          }
        },
        _draggableMoved: function(t) {
          return t = t.dragging && t.dragging.enabled() ? t : this, t.dragging && t.dragging.moved() || this.boxZoom && this.boxZoom.moved();
        },
        _clearHandlers: function() {
          for (var t = 0, e = this._handlers.length; t < e; t++) this._handlers[t].disable();
        },
        whenReady: function(t, e) {
          return this._loaded ? t.call(e || this, {
            target: this
          }) : this.on("load", t, e), this;
        },
        _getMapPanePos: function() {
          return Mt(this._mapPane) || new M(0, 0);
        },
        _moved: function() {
          var t = this._getMapPanePos();
          return t && !t.equals([
            0,
            0
          ]);
        },
        _getTopLeftPoint: function(t, e) {
          var i = t && e !== void 0 ? this._getNewPixelOrigin(t, e) : this.getPixelOrigin();
          return i.subtract(this._getMapPanePos());
        },
        _getNewPixelOrigin: function(t, e) {
          var i = this.getSize()._divideBy(2);
          return this.project(t, e)._subtract(i)._add(this._getMapPanePos())._round();
        },
        _latLngToNewLayerPoint: function(t, e, i) {
          var n = this._getNewPixelOrigin(i, e);
          return this.project(t, e)._subtract(n);
        },
        _latLngBoundsToNewLayerBounds: function(t, e, i) {
          var n = this._getNewPixelOrigin(i, e);
          return J([
            this.project(t.getSouthWest(), e)._subtract(n),
            this.project(t.getNorthWest(), e)._subtract(n),
            this.project(t.getSouthEast(), e)._subtract(n),
            this.project(t.getNorthEast(), e)._subtract(n)
          ]);
        },
        _getCenterLayerPoint: function() {
          return this.containerPointToLayerPoint(this.getSize()._divideBy(2));
        },
        _getCenterOffset: function(t) {
          return this.latLngToLayerPoint(t).subtract(this._getCenterLayerPoint());
        },
        _limitCenter: function(t, e, i) {
          if (!i) return t;
          var n = this.project(t, e), o = this.getSize().divideBy(2), a = new N(n.subtract(o), n.add(o)), r = this._getBoundsOffset(a, i, e);
          return Math.abs(r.x) <= 1 && Math.abs(r.y) <= 1 ? t : this.unproject(n.add(r), e);
        },
        _limitOffset: function(t, e) {
          if (!e) return t;
          var i = this.getPixelBounds(), n = new N(i.min.add(t), i.max.add(t));
          return t.add(this._getBoundsOffset(n, e));
        },
        _getBoundsOffset: function(t, e, i) {
          var n = J(this.project(e.getNorthEast(), i), this.project(e.getSouthWest(), i)), o = n.min.subtract(t.min), a = n.max.subtract(t.max), r = this._rebound(o.x, -a.x), h = this._rebound(o.y, -a.y);
          return new M(r, h);
        },
        _rebound: function(t, e) {
          return t + e > 0 ? Math.round(t - e) / 2 : Math.max(0, Math.ceil(t)) - Math.max(0, Math.floor(e));
        },
        _limitZoom: function(t) {
          var e = this.getMinZoom(), i = this.getMaxZoom(), n = x.any3d ? this.options.zoomSnap : 1;
          return n && (t = Math.round(t / n) * n), Math.max(e, Math.min(i, t));
        },
        _onPanTransitionStep: function() {
          this.fire("move");
        },
        _onPanTransitionEnd: function() {
          H(this._mapPane, "leaflet-pan-anim"), this.fire("moveend");
        },
        _tryAnimatedPan: function(t, e) {
          var i = this._getCenterOffset(t)._trunc();
          return (e && e.animate) !== true && !this.getSize().contains(i) ? false : (this.panBy(i, e), true);
        },
        _createAnimProxy: function() {
          var t = this._proxy = A("div", "leaflet-proxy leaflet-zoom-animated");
          this._panes.mapPane.appendChild(t), this.on("zoomanim", function(e) {
            var i = Ve, n = this._proxy.style[i];
            Tt(this._proxy, this.project(e.center, e.zoom), this.getZoomScale(e.zoom, 1)), n === this._proxy.style[i] && this._animatingZoom && this._onZoomTransitionEnd();
          }, this), this.on("load moveend", this._animMoveEnd, this), this._on("unload", this._destroyAnimProxy, this);
        },
        _destroyAnimProxy: function() {
          R(this._proxy), this.off("load moveend", this._animMoveEnd, this), delete this._proxy;
        },
        _animMoveEnd: function() {
          var t = this.getCenter(), e = this.getZoom();
          Tt(this._proxy, this.project(t, e), this.getZoomScale(e, 1));
        },
        _catchTransitionEnd: function(t) {
          this._animatingZoom && t.propertyName.indexOf("transform") >= 0 && this._onZoomTransitionEnd();
        },
        _nothingToAnimate: function() {
          return !this._container.getElementsByClassName("leaflet-zoom-animated").length;
        },
        _tryAnimatedZoom: function(t, e, i) {
          if (this._animatingZoom) return true;
          if (i = i || {}, !this._zoomAnimated || i.animate === false || this._nothingToAnimate() || Math.abs(e - this._zoom) > this.options.zoomAnimationThreshold) return false;
          var n = this.getZoomScale(e), o = this._getCenterOffset(t)._divideBy(1 - 1 / n);
          return i.animate !== true && !this.getSize().contains(o) ? false : (q(function() {
            this._moveStart(true, i.noMoveStart || false)._animateZoom(t, e, true);
          }, this), true);
        },
        _animateZoom: function(t, e, i, n) {
          this._mapPane && (i && (this._animatingZoom = true, this._animateToCenter = t, this._animateToZoom = e, C(this._mapPane, "leaflet-zoom-anim")), this.fire("zoomanim", {
            center: t,
            zoom: e,
            noUpdate: n
          }), this._tempFireZoomEvent || (this._tempFireZoomEvent = this._zoom !== this._animateToZoom), this._move(this._animateToCenter, this._animateToZoom, void 0, true), setTimeout(g(this._onZoomTransitionEnd, this), 250));
        },
        _onZoomTransitionEnd: function() {
          this._animatingZoom && (this._mapPane && H(this._mapPane, "leaflet-zoom-anim"), this._animatingZoom = false, this._move(this._animateToCenter, this._animateToZoom, void 0, true), this._tempFireZoomEvent && this.fire("zoom"), delete this._tempFireZoomEvent, this.fire("move"), this._moveEnd(true));
        }
      });
      function Eo(t, e) {
        return new z(t, e);
      }
      var at = ft.extend({
        options: {
          position: "topright"
        },
        initialize: function(t) {
          I(this, t);
        },
        getPosition: function() {
          return this.options.position;
        },
        setPosition: function(t) {
          var e = this._map;
          return e && e.removeControl(this), this.options.position = t, e && e.addControl(this), this;
        },
        getContainer: function() {
          return this._container;
        },
        addTo: function(t) {
          this.remove(), this._map = t;
          var e = this._container = this.onAdd(t), i = this.getPosition(), n = t._controlCorners[i];
          return C(e, "leaflet-control"), i.indexOf("bottom") !== -1 ? n.insertBefore(e, n.firstChild) : n.appendChild(e), this._map.on("unload", this.remove, this), this;
        },
        remove: function() {
          return this._map ? (R(this._container), this.onRemove && this.onRemove(this._map), this._map.off("unload", this.remove, this), this._map = null, this) : this;
        },
        _refocusOnMap: function(t) {
          this._map && t && t.screenX > 0 && t.screenY > 0 && this._map.getContainer().focus();
        }
      }), Qt = function(t) {
        return new at(t);
      };
      z.include({
        addControl: function(t) {
          return t.addTo(this), this;
        },
        removeControl: function(t) {
          return t.remove(), this;
        },
        _initControlPos: function() {
          var t = this._controlCorners = {}, e = "leaflet-", i = this._controlContainer = A("div", e + "control-container", this._container);
          function n(o, a) {
            var r = e + o + " " + e + a;
            t[o + a] = A("div", r, i);
          }
          n("top", "left"), n("top", "right"), n("bottom", "left"), n("bottom", "right");
        },
        _clearControlPos: function() {
          for (var t in this._controlCorners) R(this._controlCorners[t]);
          R(this._controlContainer), delete this._controlCorners, delete this._controlContainer;
        }
      });
      var on = at.extend({
        options: {
          collapsed: true,
          position: "topright",
          autoZIndex: true,
          hideSingleBase: false,
          sortLayers: false,
          sortFunction: function(t, e, i, n) {
            return i < n ? -1 : n < i ? 1 : 0;
          }
        },
        initialize: function(t, e, i) {
          I(this, i), this._layerControlInputs = [], this._layers = [], this._lastZIndex = 0, this._handlingClick = false, this._preventClick = false;
          for (var n in t) this._addLayer(t[n], n);
          for (n in e) this._addLayer(e[n], n, true);
        },
        onAdd: function(t) {
          this._initLayout(), this._update(), this._map = t, t.on("zoomend", this._checkDisabledLayers, this);
          for (var e = 0; e < this._layers.length; e++) this._layers[e].layer.on("add remove", this._onLayerChange, this);
          return this._container;
        },
        addTo: function(t) {
          return at.prototype.addTo.call(this, t), this._expandIfNotCollapsed();
        },
        onRemove: function() {
          this._map.off("zoomend", this._checkDisabledLayers, this);
          for (var t = 0; t < this._layers.length; t++) this._layers[t].layer.off("add remove", this._onLayerChange, this);
        },
        addBaseLayer: function(t, e) {
          return this._addLayer(t, e), this._map ? this._update() : this;
        },
        addOverlay: function(t, e) {
          return this._addLayer(t, e, true), this._map ? this._update() : this;
        },
        removeLayer: function(t) {
          t.off("add remove", this._onLayerChange, this);
          var e = this._getLayer(_(t));
          return e && this._layers.splice(this._layers.indexOf(e), 1), this._map ? this._update() : this;
        },
        expand: function() {
          C(this._container, "leaflet-control-layers-expanded"), this._section.style.height = null;
          var t = this._map.getSize().y - (this._container.offsetTop + 50);
          return t < this._section.clientHeight ? (C(this._section, "leaflet-control-layers-scrollbar"), this._section.style.height = t + "px") : H(this._section, "leaflet-control-layers-scrollbar"), this._checkDisabledLayers(), this;
        },
        collapse: function() {
          return H(this._container, "leaflet-control-layers-expanded"), this;
        },
        _initLayout: function() {
          var t = "leaflet-control-layers", e = this._container = A("div", t), i = this.options.collapsed;
          e.setAttribute("aria-haspopup", true), Xt(e), oi(e);
          var n = this._section = A("section", t + "-list");
          i && (this._map.on("click", this.collapse, this), S(e, {
            mouseenter: this._expandSafely,
            mouseleave: this.collapse
          }, this));
          var o = this._layersLink = A("a", t + "-toggle", e);
          o.href = "#", o.title = "Layers", o.setAttribute("role", "button"), S(o, {
            keydown: function(a) {
              a.keyCode === 13 && this._expandSafely();
            },
            click: function(a) {
              G(a), this._expandSafely();
            }
          }, this), i || this.expand(), this._baseLayersList = A("div", t + "-base", n), this._separator = A("div", t + "-separator", n), this._overlaysList = A("div", t + "-overlays", n), e.appendChild(n);
        },
        _getLayer: function(t) {
          for (var e = 0; e < this._layers.length; e++) if (this._layers[e] && _(this._layers[e].layer) === t) return this._layers[e];
        },
        _addLayer: function(t, e, i) {
          this._map && t.on("add remove", this._onLayerChange, this), this._layers.push({
            layer: t,
            name: e,
            overlay: i
          }), this.options.sortLayers && this._layers.sort(g(function(n, o) {
            return this.options.sortFunction(n.layer, o.layer, n.name, o.name);
          }, this)), this.options.autoZIndex && t.setZIndex && (this._lastZIndex++, t.setZIndex(this._lastZIndex)), this._expandIfNotCollapsed();
        },
        _update: function() {
          if (!this._container) return this;
          de(this._baseLayersList), de(this._overlaysList), this._layerControlInputs = [];
          var t, e, i, n, o = 0;
          for (i = 0; i < this._layers.length; i++) n = this._layers[i], this._addItem(n), e = e || n.overlay, t = t || !n.overlay, o += n.overlay ? 0 : 1;
          return this.options.hideSingleBase && (t = t && o > 1, this._baseLayersList.style.display = t ? "" : "none"), this._separator.style.display = e && t ? "" : "none", this;
        },
        _onLayerChange: function(t) {
          this._handlingClick || this._update();
          var e = this._getLayer(_(t.target)), i = e.overlay ? t.type === "add" ? "overlayadd" : "overlayremove" : t.type === "add" ? "baselayerchange" : null;
          i && this._map.fire(i, e);
        },
        _createRadioElement: function(t, e) {
          var i = '<input type="radio" class="leaflet-control-layers-selector" name="' + t + '"' + (e ? ' checked="checked"' : "") + "/>", n = document.createElement("div");
          return n.innerHTML = i, n.firstChild;
        },
        _addItem: function(t) {
          var e = document.createElement("label"), i = this._map.hasLayer(t.layer), n;
          t.overlay ? (n = document.createElement("input"), n.type = "checkbox", n.className = "leaflet-control-layers-selector", n.defaultChecked = i) : n = this._createRadioElement("leaflet-base-layers_" + _(this), i), this._layerControlInputs.push(n), n.layerId = _(t.layer), S(n, "click", this._onInputClick, this);
          var o = document.createElement("span");
          o.innerHTML = " " + t.name;
          var a = document.createElement("span");
          e.appendChild(a), a.appendChild(n), a.appendChild(o);
          var r = t.overlay ? this._overlaysList : this._baseLayersList;
          return r.appendChild(e), this._checkDisabledLayers(), e;
        },
        _onInputClick: function() {
          if (!this._preventClick) {
            var t = this._layerControlInputs, e, i, n = [], o = [];
            this._handlingClick = true;
            for (var a = t.length - 1; a >= 0; a--) e = t[a], i = this._getLayer(e.layerId).layer, e.checked ? n.push(i) : e.checked || o.push(i);
            for (a = 0; a < o.length; a++) this._map.hasLayer(o[a]) && this._map.removeLayer(o[a]);
            for (a = 0; a < n.length; a++) this._map.hasLayer(n[a]) || this._map.addLayer(n[a]);
            this._handlingClick = false, this._refocusOnMap();
          }
        },
        _checkDisabledLayers: function() {
          for (var t = this._layerControlInputs, e, i, n = this._map.getZoom(), o = t.length - 1; o >= 0; o--) e = t[o], i = this._getLayer(e.layerId).layer, e.disabled = i.options.minZoom !== void 0 && n < i.options.minZoom || i.options.maxZoom !== void 0 && n > i.options.maxZoom;
        },
        _expandIfNotCollapsed: function() {
          return this._map && !this.options.collapsed && this.expand(), this;
        },
        _expandSafely: function() {
          var t = this._section;
          this._preventClick = true, S(t, "click", G), this.expand();
          var e = this;
          setTimeout(function() {
            B(t, "click", G), e._preventClick = false;
          });
        }
      }), Ao = function(t, e, i) {
        return new on(t, e, i);
      }, ri = at.extend({
        options: {
          position: "topleft",
          zoomInText: '<span aria-hidden="true">+</span>',
          zoomInTitle: "Zoom in",
          zoomOutText: '<span aria-hidden="true">&#x2212;</span>',
          zoomOutTitle: "Zoom out"
        },
        onAdd: function(t) {
          var e = "leaflet-control-zoom", i = A("div", e + " leaflet-bar"), n = this.options;
          return this._zoomInButton = this._createButton(n.zoomInText, n.zoomInTitle, e + "-in", i, this._zoomIn), this._zoomOutButton = this._createButton(n.zoomOutText, n.zoomOutTitle, e + "-out", i, this._zoomOut), this._updateDisabled(), t.on("zoomend zoomlevelschange", this._updateDisabled, this), i;
        },
        onRemove: function(t) {
          t.off("zoomend zoomlevelschange", this._updateDisabled, this);
        },
        disable: function() {
          return this._disabled = true, this._updateDisabled(), this;
        },
        enable: function() {
          return this._disabled = false, this._updateDisabled(), this;
        },
        _zoomIn: function(t) {
          !this._disabled && this._map._zoom < this._map.getMaxZoom() && this._map.zoomIn(this._map.options.zoomDelta * (t.shiftKey ? 3 : 1));
        },
        _zoomOut: function(t) {
          !this._disabled && this._map._zoom > this._map.getMinZoom() && this._map.zoomOut(this._map.options.zoomDelta * (t.shiftKey ? 3 : 1));
        },
        _createButton: function(t, e, i, n, o) {
          var a = A("a", i, n);
          return a.innerHTML = t, a.href = "#", a.title = e, a.setAttribute("role", "button"), a.setAttribute("aria-label", e), Xt(a), S(a, "click", Ct), S(a, "click", o, this), S(a, "click", this._refocusOnMap, this), a;
        },
        _updateDisabled: function() {
          var t = this._map, e = "leaflet-disabled";
          H(this._zoomInButton, e), H(this._zoomOutButton, e), this._zoomInButton.setAttribute("aria-disabled", "false"), this._zoomOutButton.setAttribute("aria-disabled", "false"), (this._disabled || t._zoom === t.getMinZoom()) && (C(this._zoomOutButton, e), this._zoomOutButton.setAttribute("aria-disabled", "true")), (this._disabled || t._zoom === t.getMaxZoom()) && (C(this._zoomInButton, e), this._zoomInButton.setAttribute("aria-disabled", "true"));
        }
      });
      z.mergeOptions({
        zoomControl: true
      }), z.addInitHook(function() {
        this.options.zoomControl && (this.zoomControl = new ri(), this.addControl(this.zoomControl));
      });
      var Zo = function(t) {
        return new ri(t);
      }, an = at.extend({
        options: {
          position: "bottomleft",
          maxWidth: 100,
          metric: true,
          imperial: true
        },
        onAdd: function(t) {
          var e = "leaflet-control-scale", i = A("div", e), n = this.options;
          return this._addScales(n, e + "-line", i), t.on(n.updateWhenIdle ? "moveend" : "move", this._update, this), t.whenReady(this._update, this), i;
        },
        onRemove: function(t) {
          t.off(this.options.updateWhenIdle ? "moveend" : "move", this._update, this);
        },
        _addScales: function(t, e, i) {
          t.metric && (this._mScale = A("div", e, i)), t.imperial && (this._iScale = A("div", e, i));
        },
        _update: function() {
          var t = this._map, e = t.getSize().y / 2, i = t.distance(t.containerPointToLatLng([
            0,
            e
          ]), t.containerPointToLatLng([
            this.options.maxWidth,
            e
          ]));
          this._updateScales(i);
        },
        _updateScales: function(t) {
          this.options.metric && t && this._updateMetric(t), this.options.imperial && t && this._updateImperial(t);
        },
        _updateMetric: function(t) {
          var e = this._getRoundNum(t), i = e < 1e3 ? e + " m" : e / 1e3 + " km";
          this._updateScale(this._mScale, i, e / t);
        },
        _updateImperial: function(t) {
          var e = t * 3.2808399, i, n, o;
          e > 5280 ? (i = e / 5280, n = this._getRoundNum(i), this._updateScale(this._iScale, n + " mi", n / i)) : (o = this._getRoundNum(e), this._updateScale(this._iScale, o + " ft", o / e));
        },
        _updateScale: function(t, e, i) {
          t.style.width = Math.round(this.options.maxWidth * i) + "px", t.innerHTML = e;
        },
        _getRoundNum: function(t) {
          var e = Math.pow(10, (Math.floor(t) + "").length - 1), i = t / e;
          return i = i >= 10 ? 10 : i >= 5 ? 5 : i >= 3 ? 3 : i >= 2 ? 2 : 1, e * i;
        }
      }), Io = function(t) {
        return new an(t);
      }, Bo = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="12" height="8" viewBox="0 0 12 8" class="leaflet-attribution-flag"><path fill="#4C7BE1" d="M0 0h12v4H0z"/><path fill="#FFD500" d="M0 4h12v3H0z"/><path fill="#E0BC00" d="M0 7h12v1H0z"/></svg>', si = at.extend({
        options: {
          position: "bottomright",
          prefix: '<a href="https://leafletjs.com" title="A JavaScript library for interactive maps">' + (x.inlineSvg ? Bo + " " : "") + "Leaflet</a>"
        },
        initialize: function(t) {
          I(this, t), this._attributions = {};
        },
        onAdd: function(t) {
          t.attributionControl = this, this._container = A("div", "leaflet-control-attribution"), Xt(this._container);
          for (var e in t._layers) t._layers[e].getAttribution && this.addAttribution(t._layers[e].getAttribution());
          return this._update(), t.on("layeradd", this._addAttribution, this), this._container;
        },
        onRemove: function(t) {
          t.off("layeradd", this._addAttribution, this);
        },
        _addAttribution: function(t) {
          t.layer.getAttribution && (this.addAttribution(t.layer.getAttribution()), t.layer.once("remove", function() {
            this.removeAttribution(t.layer.getAttribution());
          }, this));
        },
        setPrefix: function(t) {
          return this.options.prefix = t, this._update(), this;
        },
        addAttribution: function(t) {
          return t ? (this._attributions[t] || (this._attributions[t] = 0), this._attributions[t]++, this._update(), this) : this;
        },
        removeAttribution: function(t) {
          return t ? (this._attributions[t] && (this._attributions[t]--, this._update()), this) : this;
        },
        _update: function() {
          if (this._map) {
            var t = [];
            for (var e in this._attributions) this._attributions[e] && t.push(e);
            var i = [];
            this.options.prefix && i.push(this.options.prefix), t.length && i.push(t.join(", ")), this._container.innerHTML = i.join(' <span aria-hidden="true">|</span> ');
          }
        }
      });
      z.mergeOptions({
        attributionControl: true
      }), z.addInitHook(function() {
        this.options.attributionControl && new si().addTo(this);
      });
      var Do = function(t) {
        return new si(t);
      };
      at.Layers = on, at.Zoom = ri, at.Scale = an, at.Attribution = si, Qt.layers = Ao, Qt.zoom = Zo, Qt.scale = Io, Qt.attribution = Do;
      var lt = ft.extend({
        initialize: function(t) {
          this._map = t;
        },
        enable: function() {
          return this._enabled ? this : (this._enabled = true, this.addHooks(), this);
        },
        disable: function() {
          return this._enabled ? (this._enabled = false, this.removeHooks(), this) : this;
        },
        enabled: function() {
          return !!this._enabled;
        }
      });
      lt.addTo = function(t, e) {
        return t.addHandler(e, this), this;
      };
      var No = {
        Events: Q
      }, rn = x.touch ? "touchstart mousedown" : "mousedown", wt = Ut.extend({
        options: {
          clickTolerance: 3
        },
        initialize: function(t, e, i, n) {
          I(this, n), this._element = t, this._dragStartTarget = e || t, this._preventOutline = i;
        },
        enable: function() {
          this._enabled || (S(this._dragStartTarget, rn, this._onDown, this), this._enabled = true);
        },
        disable: function() {
          this._enabled && (wt._dragging === this && this.finishDrag(true), B(this._dragStartTarget, rn, this._onDown, this), this._enabled = false, this._moved = false);
        },
        _onDown: function(t) {
          if (this._enabled && (this._moved = false, !Ke(this._element, "leaflet-zoom-anim"))) {
            if (t.touches && t.touches.length !== 1) {
              wt._dragging === this && this.finishDrag();
              return;
            }
            if (!(wt._dragging || t.shiftKey || t.which !== 1 && t.button !== 1 && !t.touches) && (wt._dragging = this, this._preventOutline && $e(this._element), Ye(), qt(), !this._moving)) {
              this.fire("down");
              var e = t.touches ? t.touches[0] : t, i = Xi(this._element);
              this._startPoint = new M(e.clientX, e.clientY), this._startPos = Mt(this._element), this._parentScale = ti(i);
              var n = t.type === "mousedown";
              S(document, n ? "mousemove" : "touchmove", this._onMove, this), S(document, n ? "mouseup" : "touchend touchcancel", this._onUp, this);
            }
          }
        },
        _onMove: function(t) {
          if (this._enabled) {
            if (t.touches && t.touches.length > 1) {
              this._moved = true;
              return;
            }
            var e = t.touches && t.touches.length === 1 ? t.touches[0] : t, i = new M(e.clientX, e.clientY)._subtract(this._startPoint);
            !i.x && !i.y || Math.abs(i.x) + Math.abs(i.y) < this.options.clickTolerance || (i.x /= this._parentScale.x, i.y /= this._parentScale.y, G(t), this._moved || (this.fire("dragstart"), this._moved = true, C(document.body, "leaflet-dragging"), this._lastTarget = t.target || t.srcElement, window.SVGElementInstance && this._lastTarget instanceof window.SVGElementInstance && (this._lastTarget = this._lastTarget.correspondingUseElement), C(this._lastTarget, "leaflet-drag-target")), this._newPos = this._startPos.add(i), this._moving = true, this._lastEvent = t, this._updatePosition());
          }
        },
        _updatePosition: function() {
          var t = {
            originalEvent: this._lastEvent
          };
          this.fire("predrag", t), W(this._element, this._newPos), this.fire("drag", t);
        },
        _onUp: function() {
          this._enabled && this.finishDrag();
        },
        finishDrag: function(t) {
          H(document.body, "leaflet-dragging"), this._lastTarget && (H(this._lastTarget, "leaflet-drag-target"), this._lastTarget = null), B(document, "mousemove touchmove", this._onMove, this), B(document, "mouseup touchend touchcancel", this._onUp, this), Xe(), Jt();
          var e = this._moved && this._moving;
          this._moving = false, wt._dragging = false, e && this.fire("dragend", {
            noInertia: t,
            distance: this._newPos.distanceTo(this._startPos)
          });
        }
      });
      function sn(t, e, i) {
        var n, o = [
          1,
          4,
          2,
          8
        ], a, r, h, u, p, y, w, k;
        for (a = 0, y = t.length; a < y; a++) t[a]._code = kt(t[a], e);
        for (h = 0; h < 4; h++) {
          for (w = o[h], n = [], a = 0, y = t.length, r = y - 1; a < y; r = a++) u = t[a], p = t[r], u._code & w ? p._code & w || (k = ge(p, u, w, e, i), k._code = kt(k, e), n.push(k)) : (p._code & w && (k = ge(p, u, w, e, i), k._code = kt(k, e), n.push(k)), n.push(u));
          t = n;
        }
        return t;
      }
      function hn(t, e) {
        var i, n, o, a, r, h, u, p, y;
        if (!t || t.length === 0) throw new Error("latlngs not passed");
        et(t) || (console.warn("latlngs are not flat! Only the first ring will be used"), t = t[0]);
        var w = O([
          0,
          0
        ]), k = F(t), V = k.getNorthWest().distanceTo(k.getSouthWest()) * k.getNorthEast().distanceTo(k.getNorthWest());
        V < 1700 && (w = hi(t));
        var j = t.length, it = [];
        for (i = 0; i < j; i++) {
          var X = O(t[i]);
          it.push(e.project(O([
            X.lat - w.lat,
            X.lng - w.lng
          ])));
        }
        for (h = u = p = 0, i = 0, n = j - 1; i < j; n = i++) o = it[i], a = it[n], r = o.y * a.x - a.y * o.x, u += (o.x + a.x) * r, p += (o.y + a.y) * r, h += r * 3;
        h === 0 ? y = it[0] : y = [
          u / h,
          p / h
        ];
        var Ft = e.unproject(P(y));
        return O([
          Ft.lat + w.lat,
          Ft.lng + w.lng
        ]);
      }
      function hi(t) {
        for (var e = 0, i = 0, n = 0, o = 0; o < t.length; o++) {
          var a = O(t[o]);
          e += a.lat, i += a.lng, n++;
        }
        return O([
          e / n,
          i / n
        ]);
      }
      var Ro = {
        __proto__: null,
        clipPolygon: sn,
        polygonCenter: hn,
        centroid: hi
      };
      function ln(t, e) {
        if (!e || !t.length) return t.slice();
        var i = e * e;
        return t = Wo(t, i), t = Fo(t, i), t;
      }
      function un(t, e, i) {
        return Math.sqrt($t(t, e, i, true));
      }
      function Ho(t, e, i) {
        return $t(t, e, i);
      }
      function Fo(t, e) {
        var i = t.length, n = typeof Uint8Array < "u" ? Uint8Array : Array, o = new n(i);
        o[0] = o[i - 1] = 1, li(t, o, e, 0, i - 1);
        var a, r = [];
        for (a = 0; a < i; a++) o[a] && r.push(t[a]);
        return r;
      }
      function li(t, e, i, n, o) {
        var a = 0, r, h, u;
        for (h = n + 1; h <= o - 1; h++) u = $t(t[h], t[n], t[o], true), u > a && (r = h, a = u);
        a > i && (e[r] = 1, li(t, e, i, n, r), li(t, e, i, r, o));
      }
      function Wo(t, e) {
        for (var i = [
          t[0]
        ], n = 1, o = 0, a = t.length; n < a; n++) Uo(t[n], t[o]) > e && (i.push(t[n]), o = n);
        return o < a - 1 && i.push(t[a - 1]), i;
      }
      var cn;
      function dn(t, e, i, n, o) {
        var a = n ? cn : kt(t, i), r = kt(e, i), h, u, p;
        for (cn = r; ; ) {
          if (!(a | r)) return [
            t,
            e
          ];
          if (a & r) return false;
          h = a || r, u = ge(t, e, h, i, o), p = kt(u, i), h === a ? (t = u, a = p) : (e = u, r = p);
        }
      }
      function ge(t, e, i, n, o) {
        var a = e.x - t.x, r = e.y - t.y, h = n.min, u = n.max, p, y;
        return i & 8 ? (p = t.x + a * (u.y - t.y) / r, y = u.y) : i & 4 ? (p = t.x + a * (h.y - t.y) / r, y = h.y) : i & 2 ? (p = u.x, y = t.y + r * (u.x - t.x) / a) : i & 1 && (p = h.x, y = t.y + r * (h.x - t.x) / a), new M(p, y, o);
      }
      function kt(t, e) {
        var i = 0;
        return t.x < e.min.x ? i |= 1 : t.x > e.max.x && (i |= 2), t.y < e.min.y ? i |= 4 : t.y > e.max.y && (i |= 8), i;
      }
      function Uo(t, e) {
        var i = e.x - t.x, n = e.y - t.y;
        return i * i + n * n;
      }
      function $t(t, e, i, n) {
        var o = e.x, a = e.y, r = i.x - o, h = i.y - a, u = r * r + h * h, p;
        return u > 0 && (p = ((t.x - o) * r + (t.y - a) * h) / u, p > 1 ? (o = i.x, a = i.y) : p > 0 && (o += r * p, a += h * p)), r = t.x - o, h = t.y - a, n ? r * r + h * h : new M(o, a);
      }
      function et(t) {
        return !ot(t[0]) || typeof t[0][0] != "object" && typeof t[0][0] < "u";
      }
      function fn(t) {
        return console.warn("Deprecated use of _flat, please use L.LineUtil.isFlat instead."), et(t);
      }
      function pn(t, e) {
        var i, n, o, a, r, h, u, p;
        if (!t || t.length === 0) throw new Error("latlngs not passed");
        et(t) || (console.warn("latlngs are not flat! Only the first ring will be used"), t = t[0]);
        var y = O([
          0,
          0
        ]), w = F(t), k = w.getNorthWest().distanceTo(w.getSouthWest()) * w.getNorthEast().distanceTo(w.getNorthWest());
        k < 1700 && (y = hi(t));
        var V = t.length, j = [];
        for (i = 0; i < V; i++) {
          var it = O(t[i]);
          j.push(e.project(O([
            it.lat - y.lat,
            it.lng - y.lng
          ])));
        }
        for (i = 0, n = 0; i < V - 1; i++) n += j[i].distanceTo(j[i + 1]) / 2;
        if (n === 0) p = j[0];
        else for (i = 0, a = 0; i < V - 1; i++) if (r = j[i], h = j[i + 1], o = r.distanceTo(h), a += o, a > n) {
          u = (a - n) / o, p = [
            h.x - u * (h.x - r.x),
            h.y - u * (h.y - r.y)
          ];
          break;
        }
        var X = e.unproject(P(p));
        return O([
          X.lat + y.lat,
          X.lng + y.lng
        ]);
      }
      var jo = {
        __proto__: null,
        simplify: ln,
        pointToSegmentDistance: un,
        closestPointOnSegment: Ho,
        clipSegment: dn,
        _getEdgeIntersection: ge,
        _getBitCode: kt,
        _sqClosestPointOnSegment: $t,
        isFlat: et,
        _flat: fn,
        polylineCenter: pn
      }, ui = {
        project: function(t) {
          return new M(t.lng, t.lat);
        },
        unproject: function(t) {
          return new Z(t.y, t.x);
        },
        bounds: new N([
          -180,
          -90
        ], [
          180,
          90
        ])
      }, ci = {
        R: 6378137,
        R_MINOR: 6356752314245179e-9,
        bounds: new N([
          -2003750834279e-5,
          -1549657073972e-5
        ], [
          2003750834279e-5,
          1876465623138e-5
        ]),
        project: function(t) {
          var e = Math.PI / 180, i = this.R, n = t.lat * e, o = this.R_MINOR / i, a = Math.sqrt(1 - o * o), r = a * Math.sin(n), h = Math.tan(Math.PI / 4 - n / 2) / Math.pow((1 - r) / (1 + r), a / 2);
          return n = -i * Math.log(Math.max(h, 1e-10)), new M(t.lng * e * i, n);
        },
        unproject: function(t) {
          for (var e = 180 / Math.PI, i = this.R, n = this.R_MINOR / i, o = Math.sqrt(1 - n * n), a = Math.exp(-t.y / i), r = Math.PI / 2 - 2 * Math.atan(a), h = 0, u = 0.1, p; h < 15 && Math.abs(u) > 1e-7; h++) p = o * Math.sin(r), p = Math.pow((1 - p) / (1 + p), o / 2), u = Math.PI / 2 - 2 * Math.atan(a * p) - r, r += u;
          return new Z(r * e, t.x * e / i);
        }
      }, Go = {
        __proto__: null,
        LonLat: ui,
        Mercator: ci,
        SphericalMercator: De
      }, Vo = f({}, bt, {
        code: "EPSG:3395",
        projection: ci,
        transformation: (function() {
          var t = 0.5 / (Math.PI * ci.R);
          return jt(t, 0.5, -t, 0.5);
        })()
      }), mn = f({}, bt, {
        code: "EPSG:4326",
        projection: ui,
        transformation: jt(1 / 180, 1, -1 / 180, 0.5)
      }), Ko = f({}, pt, {
        projection: ui,
        transformation: jt(1, 0, -1, 0),
        scale: function(t) {
          return Math.pow(2, t);
        },
        zoom: function(t) {
          return Math.log(t) / Math.LN2;
        },
        distance: function(t, e) {
          var i = e.lng - t.lng, n = e.lat - t.lat;
          return Math.sqrt(i * i + n * n);
        },
        infinite: true
      });
      pt.Earth = bt, pt.EPSG3395 = Vo, pt.EPSG3857 = Re, pt.EPSG900913 = Qn, pt.EPSG4326 = mn, pt.Simple = Ko;
      var rt = Ut.extend({
        options: {
          pane: "overlayPane",
          attribution: null,
          bubblingMouseEvents: true
        },
        addTo: function(t) {
          return t.addLayer(this), this;
        },
        remove: function() {
          return this.removeFrom(this._map || this._mapToAdd);
        },
        removeFrom: function(t) {
          return t && t.removeLayer(this), this;
        },
        getPane: function(t) {
          return this._map.getPane(t ? this.options[t] || t : this.options.pane);
        },
        addInteractiveTarget: function(t) {
          return this._map._targets[_(t)] = this, this;
        },
        removeInteractiveTarget: function(t) {
          return delete this._map._targets[_(t)], this;
        },
        getAttribution: function() {
          return this.options.attribution;
        },
        _layerAdd: function(t) {
          var e = t.target;
          if (e.hasLayer(this)) {
            if (this._map = e, this._zoomAnimated = e._zoomAnimated, this.getEvents) {
              var i = this.getEvents();
              e.on(i, this), this.once("remove", function() {
                e.off(i, this);
              }, this);
            }
            this.onAdd(e), this.fire("add"), e.fire("layeradd", {
              layer: this
            });
          }
        }
      });
      z.include({
        addLayer: function(t) {
          if (!t._layerAdd) throw new Error("The provided object is not a Layer.");
          var e = _(t);
          return this._layers[e] ? this : (this._layers[e] = t, t._mapToAdd = this, t.beforeAdd && t.beforeAdd(this), this.whenReady(t._layerAdd, t), this);
        },
        removeLayer: function(t) {
          var e = _(t);
          return this._layers[e] ? (this._loaded && t.onRemove(this), delete this._layers[e], this._loaded && (this.fire("layerremove", {
            layer: t
          }), t.fire("remove")), t._map = t._mapToAdd = null, this) : this;
        },
        hasLayer: function(t) {
          return _(t) in this._layers;
        },
        eachLayer: function(t, e) {
          for (var i in this._layers) t.call(e, this._layers[i]);
          return this;
        },
        _addLayers: function(t) {
          t = t ? ot(t) ? t : [
            t
          ] : [];
          for (var e = 0, i = t.length; e < i; e++) this.addLayer(t[e]);
        },
        _addZoomLimit: function(t) {
          (!isNaN(t.options.maxZoom) || !isNaN(t.options.minZoom)) && (this._zoomBoundLayers[_(t)] = t, this._updateZoomLevels());
        },
        _removeZoomLimit: function(t) {
          var e = _(t);
          this._zoomBoundLayers[e] && (delete this._zoomBoundLayers[e], this._updateZoomLevels());
        },
        _updateZoomLevels: function() {
          var t = 1 / 0, e = -1 / 0, i = this._getZoomSpan();
          for (var n in this._zoomBoundLayers) {
            var o = this._zoomBoundLayers[n].options;
            t = o.minZoom === void 0 ? t : Math.min(t, o.minZoom), e = o.maxZoom === void 0 ? e : Math.max(e, o.maxZoom);
          }
          this._layersMaxZoom = e === -1 / 0 ? void 0 : e, this._layersMinZoom = t === 1 / 0 ? void 0 : t, i !== this._getZoomSpan() && this.fire("zoomlevelschange"), this.options.maxZoom === void 0 && this._layersMaxZoom && this.getZoom() > this._layersMaxZoom && this.setZoom(this._layersMaxZoom), this.options.minZoom === void 0 && this._layersMinZoom && this.getZoom() < this._layersMinZoom && this.setZoom(this._layersMinZoom);
        }
      });
      var Bt = rt.extend({
        initialize: function(t, e) {
          I(this, e), this._layers = {};
          var i, n;
          if (t) for (i = 0, n = t.length; i < n; i++) this.addLayer(t[i]);
        },
        addLayer: function(t) {
          var e = this.getLayerId(t);
          return this._layers[e] = t, this._map && this._map.addLayer(t), this;
        },
        removeLayer: function(t) {
          var e = t in this._layers ? t : this.getLayerId(t);
          return this._map && this._layers[e] && this._map.removeLayer(this._layers[e]), delete this._layers[e], this;
        },
        hasLayer: function(t) {
          var e = typeof t == "number" ? t : this.getLayerId(t);
          return e in this._layers;
        },
        clearLayers: function() {
          return this.eachLayer(this.removeLayer, this);
        },
        invoke: function(t) {
          var e = Array.prototype.slice.call(arguments, 1), i, n;
          for (i in this._layers) n = this._layers[i], n[t] && n[t].apply(n, e);
          return this;
        },
        onAdd: function(t) {
          this.eachLayer(t.addLayer, t);
        },
        onRemove: function(t) {
          this.eachLayer(t.removeLayer, t);
        },
        eachLayer: function(t, e) {
          for (var i in this._layers) t.call(e, this._layers[i]);
          return this;
        },
        getLayer: function(t) {
          return this._layers[t];
        },
        getLayers: function() {
          var t = [];
          return this.eachLayer(t.push, t), t;
        },
        setZIndex: function(t) {
          return this.invoke("setZIndex", t);
        },
        getLayerId: function(t) {
          return _(t);
        }
      }), qo = function(t, e) {
        return new Bt(t, e);
      }, mt = Bt.extend({
        addLayer: function(t) {
          return this.hasLayer(t) ? this : (t.addEventParent(this), Bt.prototype.addLayer.call(this, t), this.fire("layeradd", {
            layer: t
          }));
        },
        removeLayer: function(t) {
          return this.hasLayer(t) ? (t in this._layers && (t = this._layers[t]), t.removeEventParent(this), Bt.prototype.removeLayer.call(this, t), this.fire("layerremove", {
            layer: t
          })) : this;
        },
        setStyle: function(t) {
          return this.invoke("setStyle", t);
        },
        bringToFront: function() {
          return this.invoke("bringToFront");
        },
        bringToBack: function() {
          return this.invoke("bringToBack");
        },
        getBounds: function() {
          var t = new Y();
          for (var e in this._layers) {
            var i = this._layers[e];
            t.extend(i.getBounds ? i.getBounds() : i.getLatLng());
          }
          return t;
        }
      }), Jo = function(t, e) {
        return new mt(t, e);
      }, Dt = ft.extend({
        options: {
          popupAnchor: [
            0,
            0
          ],
          tooltipAnchor: [
            0,
            0
          ],
          crossOrigin: false
        },
        initialize: function(t) {
          I(this, t);
        },
        createIcon: function(t) {
          return this._createIcon("icon", t);
        },
        createShadow: function(t) {
          return this._createIcon("shadow", t);
        },
        _createIcon: function(t, e) {
          var i = this._getIconUrl(t);
          if (!i) {
            if (t === "icon") throw new Error("iconUrl not set in Icon options (see the docs).");
            return null;
          }
          var n = this._createImg(i, e && e.tagName === "IMG" ? e : null);
          return this._setIconStyles(n, t), (this.options.crossOrigin || this.options.crossOrigin === "") && (n.crossOrigin = this.options.crossOrigin === true ? "" : this.options.crossOrigin), n;
        },
        _setIconStyles: function(t, e) {
          var i = this.options, n = i[e + "Size"];
          typeof n == "number" && (n = [
            n,
            n
          ]);
          var o = P(n), a = P(e === "shadow" && i.shadowAnchor || i.iconAnchor || o && o.divideBy(2, true));
          t.className = "leaflet-marker-" + e + " " + (i.className || ""), a && (t.style.marginLeft = -a.x + "px", t.style.marginTop = -a.y + "px"), o && (t.style.width = o.x + "px", t.style.height = o.y + "px");
        },
        _createImg: function(t, e) {
          return e = e || document.createElement("img"), e.src = t, e;
        },
        _getIconUrl: function(t) {
          return x.retina && this.options[t + "RetinaUrl"] || this.options[t + "Url"];
        }
      });
      function Yo(t) {
        return new Dt(t);
      }
      var te = Dt.extend({
        options: {
          iconUrl: "marker-icon.png",
          iconRetinaUrl: "marker-icon-2x.png",
          shadowUrl: "marker-shadow.png",
          iconSize: [
            25,
            41
          ],
          iconAnchor: [
            12,
            41
          ],
          popupAnchor: [
            1,
            -34
          ],
          tooltipAnchor: [
            16,
            -28
          ],
          shadowSize: [
            41,
            41
          ]
        },
        _getIconUrl: function(t) {
          return typeof te.imagePath != "string" && (te.imagePath = this._detectIconPath()), (this.options.imagePath || te.imagePath) + Dt.prototype._getIconUrl.call(this, t);
        },
        _stripUrl: function(t) {
          var e = function(i, n, o) {
            var a = n.exec(i);
            return a && a[o];
          };
          return t = e(t, /^url\((['"])?(.+)\1\)$/, 2), t && e(t, /^(.*)marker-icon\.png$/, 1);
        },
        _detectIconPath: function() {
          var t = A("div", "leaflet-default-icon-path", document.body), e = Kt(t, "background-image") || Kt(t, "backgroundImage");
          if (document.body.removeChild(t), e = this._stripUrl(e), e) return e;
          var i = document.querySelector('link[href$="leaflet.css"]');
          return i ? i.href.substring(0, i.href.length - 11 - 1) : "";
        }
      }), _n = lt.extend({
        initialize: function(t) {
          this._marker = t;
        },
        addHooks: function() {
          var t = this._marker._icon;
          this._draggable || (this._draggable = new wt(t, t, true)), this._draggable.on({
            dragstart: this._onDragStart,
            predrag: this._onPreDrag,
            drag: this._onDrag,
            dragend: this._onDragEnd
          }, this).enable(), C(t, "leaflet-marker-draggable");
        },
        removeHooks: function() {
          this._draggable.off({
            dragstart: this._onDragStart,
            predrag: this._onPreDrag,
            drag: this._onDrag,
            dragend: this._onDragEnd
          }, this).disable(), this._marker._icon && H(this._marker._icon, "leaflet-marker-draggable");
        },
        moved: function() {
          return this._draggable && this._draggable._moved;
        },
        _adjustPan: function(t) {
          var e = this._marker, i = e._map, n = this._marker.options.autoPanSpeed, o = this._marker.options.autoPanPadding, a = Mt(e._icon), r = i.getPixelBounds(), h = i.getPixelOrigin(), u = J(r.min._subtract(h).add(o), r.max._subtract(h).subtract(o));
          if (!u.contains(a)) {
            var p = P((Math.max(u.max.x, a.x) - u.max.x) / (r.max.x - u.max.x) - (Math.min(u.min.x, a.x) - u.min.x) / (r.min.x - u.min.x), (Math.max(u.max.y, a.y) - u.max.y) / (r.max.y - u.max.y) - (Math.min(u.min.y, a.y) - u.min.y) / (r.min.y - u.min.y)).multiplyBy(n);
            i.panBy(p, {
              animate: false
            }), this._draggable._newPos._add(p), this._draggable._startPos._add(p), W(e._icon, this._draggable._newPos), this._onDrag(t), this._panRequest = q(this._adjustPan.bind(this, t));
          }
        },
        _onDragStart: function() {
          this._oldLatLng = this._marker.getLatLng(), this._marker.closePopup && this._marker.closePopup(), this._marker.fire("movestart").fire("dragstart");
        },
        _onPreDrag: function(t) {
          this._marker.options.autoPan && ($(this._panRequest), this._panRequest = q(this._adjustPan.bind(this, t)));
        },
        _onDrag: function(t) {
          var e = this._marker, i = e._shadow, n = Mt(e._icon), o = e._map.layerPointToLatLng(n);
          i && W(i, n), e._latlng = o, t.latlng = o, t.oldLatLng = this._oldLatLng, e.fire("move", t).fire("drag", t);
        },
        _onDragEnd: function(t) {
          $(this._panRequest), delete this._oldLatLng, this._marker.fire("moveend").fire("dragend", t);
        }
      }), ve = rt.extend({
        options: {
          icon: new te(),
          interactive: true,
          keyboard: true,
          title: "",
          alt: "Marker",
          zIndexOffset: 0,
          opacity: 1,
          riseOnHover: false,
          riseOffset: 250,
          pane: "markerPane",
          shadowPane: "shadowPane",
          bubblingMouseEvents: false,
          autoPanOnFocus: true,
          draggable: false,
          autoPan: false,
          autoPanPadding: [
            50,
            50
          ],
          autoPanSpeed: 10
        },
        initialize: function(t, e) {
          I(this, e), this._latlng = O(t);
        },
        onAdd: function(t) {
          this._zoomAnimated = this._zoomAnimated && t.options.markerZoomAnimation, this._zoomAnimated && t.on("zoomanim", this._animateZoom, this), this._initIcon(), this.update();
        },
        onRemove: function(t) {
          this.dragging && this.dragging.enabled() && (this.options.draggable = true, this.dragging.removeHooks()), delete this.dragging, this._zoomAnimated && t.off("zoomanim", this._animateZoom, this), this._removeIcon(), this._removeShadow();
        },
        getEvents: function() {
          return {
            zoom: this.update,
            viewreset: this.update
          };
        },
        getLatLng: function() {
          return this._latlng;
        },
        setLatLng: function(t) {
          var e = this._latlng;
          return this._latlng = O(t), this.update(), this.fire("move", {
            oldLatLng: e,
            latlng: this._latlng
          });
        },
        setZIndexOffset: function(t) {
          return this.options.zIndexOffset = t, this.update();
        },
        getIcon: function() {
          return this.options.icon;
        },
        setIcon: function(t) {
          return this.options.icon = t, this._map && (this._initIcon(), this.update()), this._popup && this.bindPopup(this._popup, this._popup.options), this;
        },
        getElement: function() {
          return this._icon;
        },
        update: function() {
          if (this._icon && this._map) {
            var t = this._map.latLngToLayerPoint(this._latlng).round();
            this._setPos(t);
          }
          return this;
        },
        _initIcon: function() {
          var t = this.options, e = "leaflet-zoom-" + (this._zoomAnimated ? "animated" : "hide"), i = t.icon.createIcon(this._icon), n = false;
          i !== this._icon && (this._icon && this._removeIcon(), n = true, t.title && (i.title = t.title), i.tagName === "IMG" && (i.alt = t.alt || "")), C(i, e), t.keyboard && (i.tabIndex = "0", i.setAttribute("role", "button")), this._icon = i, t.riseOnHover && this.on({
            mouseover: this._bringToFront,
            mouseout: this._resetZIndex
          }), this.options.autoPanOnFocus && S(i, "focus", this._panOnFocus, this);
          var o = t.icon.createShadow(this._shadow), a = false;
          o !== this._shadow && (this._removeShadow(), a = true), o && (C(o, e), o.alt = ""), this._shadow = o, t.opacity < 1 && this._updateOpacity(), n && this.getPane().appendChild(this._icon), this._initInteraction(), o && a && this.getPane(t.shadowPane).appendChild(this._shadow);
        },
        _removeIcon: function() {
          this.options.riseOnHover && this.off({
            mouseover: this._bringToFront,
            mouseout: this._resetZIndex
          }), this.options.autoPanOnFocus && B(this._icon, "focus", this._panOnFocus, this), R(this._icon), this.removeInteractiveTarget(this._icon), this._icon = null;
        },
        _removeShadow: function() {
          this._shadow && R(this._shadow), this._shadow = null;
        },
        _setPos: function(t) {
          this._icon && W(this._icon, t), this._shadow && W(this._shadow, t), this._zIndex = t.y + this.options.zIndexOffset, this._resetZIndex();
        },
        _updateZIndex: function(t) {
          this._icon && (this._icon.style.zIndex = this._zIndex + t);
        },
        _animateZoom: function(t) {
          var e = this._map._latLngToNewLayerPoint(this._latlng, t.zoom, t.center).round();
          this._setPos(e);
        },
        _initInteraction: function() {
          if (this.options.interactive && (C(this._icon, "leaflet-interactive"), this.addInteractiveTarget(this._icon), _n)) {
            var t = this.options.draggable;
            this.dragging && (t = this.dragging.enabled(), this.dragging.disable()), this.dragging = new _n(this), t && this.dragging.enable();
          }
        },
        setOpacity: function(t) {
          return this.options.opacity = t, this._map && this._updateOpacity(), this;
        },
        _updateOpacity: function() {
          var t = this.options.opacity;
          this._icon && tt(this._icon, t), this._shadow && tt(this._shadow, t);
        },
        _bringToFront: function() {
          this._updateZIndex(this.options.riseOffset);
        },
        _resetZIndex: function() {
          this._updateZIndex(0);
        },
        _panOnFocus: function() {
          var t = this._map;
          if (t) {
            var e = this.options.icon.options, i = e.iconSize ? P(e.iconSize) : P(0, 0), n = e.iconAnchor ? P(e.iconAnchor) : P(0, 0);
            t.panInside(this._latlng, {
              paddingTopLeft: n,
              paddingBottomRight: i.subtract(n)
            });
          }
        },
        _getPopupAnchor: function() {
          return this.options.icon.options.popupAnchor;
        },
        _getTooltipAnchor: function() {
          return this.options.icon.options.tooltipAnchor;
        }
      });
      function Xo(t, e) {
        return new ve(t, e);
      }
      var Pt = rt.extend({
        options: {
          stroke: true,
          color: "#3388ff",
          weight: 3,
          opacity: 1,
          lineCap: "round",
          lineJoin: "round",
          dashArray: null,
          dashOffset: null,
          fill: false,
          fillColor: null,
          fillOpacity: 0.2,
          fillRule: "evenodd",
          interactive: true,
          bubblingMouseEvents: true
        },
        beforeAdd: function(t) {
          this._renderer = t.getRenderer(this);
        },
        onAdd: function() {
          this._renderer._initPath(this), this._reset(), this._renderer._addPath(this);
        },
        onRemove: function() {
          this._renderer._removePath(this);
        },
        redraw: function() {
          return this._map && this._renderer._updatePath(this), this;
        },
        setStyle: function(t) {
          return I(this, t), this._renderer && (this._renderer._updateStyle(this), this.options.stroke && t && Object.prototype.hasOwnProperty.call(t, "weight") && this._updateBounds()), this;
        },
        bringToFront: function() {
          return this._renderer && this._renderer._bringToFront(this), this;
        },
        bringToBack: function() {
          return this._renderer && this._renderer._bringToBack(this), this;
        },
        getElement: function() {
          return this._path;
        },
        _reset: function() {
          this._project(), this._update();
        },
        _clickTolerance: function() {
          return (this.options.stroke ? this.options.weight / 2 : 0) + (this._renderer.options.tolerance || 0);
        }
      }), ye = Pt.extend({
        options: {
          fill: true,
          radius: 10
        },
        initialize: function(t, e) {
          I(this, e), this._latlng = O(t), this._radius = this.options.radius;
        },
        setLatLng: function(t) {
          var e = this._latlng;
          return this._latlng = O(t), this.redraw(), this.fire("move", {
            oldLatLng: e,
            latlng: this._latlng
          });
        },
        getLatLng: function() {
          return this._latlng;
        },
        setRadius: function(t) {
          return this.options.radius = this._radius = t, this.redraw();
        },
        getRadius: function() {
          return this._radius;
        },
        setStyle: function(t) {
          var e = t && t.radius || this._radius;
          return Pt.prototype.setStyle.call(this, t), this.setRadius(e), this;
        },
        _project: function() {
          this._point = this._map.latLngToLayerPoint(this._latlng), this._updateBounds();
        },
        _updateBounds: function() {
          var t = this._radius, e = this._radiusY || t, i = this._clickTolerance(), n = [
            t + i,
            e + i
          ];
          this._pxBounds = new N(this._point.subtract(n), this._point.add(n));
        },
        _update: function() {
          this._map && this._updatePath();
        },
        _updatePath: function() {
          this._renderer._updateCircle(this);
        },
        _empty: function() {
          return this._radius && !this._renderer._bounds.intersects(this._pxBounds);
        },
        _containsPoint: function(t) {
          return t.distanceTo(this._point) <= this._radius + this._clickTolerance();
        }
      });
      function Qo(t, e) {
        return new ye(t, e);
      }
      var di = ye.extend({
        initialize: function(t, e, i) {
          if (typeof e == "number" && (e = f({}, i, {
            radius: e
          })), I(this, e), this._latlng = O(t), isNaN(this.options.radius)) throw new Error("Circle radius cannot be NaN");
          this._mRadius = this.options.radius;
        },
        setRadius: function(t) {
          return this._mRadius = t, this.redraw();
        },
        getRadius: function() {
          return this._mRadius;
        },
        getBounds: function() {
          var t = [
            this._radius,
            this._radiusY || this._radius
          ];
          return new Y(this._map.layerPointToLatLng(this._point.subtract(t)), this._map.layerPointToLatLng(this._point.add(t)));
        },
        setStyle: Pt.prototype.setStyle,
        _project: function() {
          var t = this._latlng.lng, e = this._latlng.lat, i = this._map, n = i.options.crs;
          if (n.distance === bt.distance) {
            var o = Math.PI / 180, a = this._mRadius / bt.R / o, r = i.project([
              e + a,
              t
            ]), h = i.project([
              e - a,
              t
            ]), u = r.add(h).divideBy(2), p = i.unproject(u).lat, y = Math.acos((Math.cos(a * o) - Math.sin(e * o) * Math.sin(p * o)) / (Math.cos(e * o) * Math.cos(p * o))) / o;
            (isNaN(y) || y === 0) && (y = a / Math.cos(Math.PI / 180 * e)), this._point = u.subtract(i.getPixelOrigin()), this._radius = isNaN(y) ? 0 : u.x - i.project([
              p,
              t - y
            ]).x, this._radiusY = u.y - r.y;
          } else {
            var w = n.unproject(n.project(this._latlng).subtract([
              this._mRadius,
              0
            ]));
            this._point = i.latLngToLayerPoint(this._latlng), this._radius = this._point.x - i.latLngToLayerPoint(w).x;
          }
          this._updateBounds();
        }
      });
      function $o(t, e, i) {
        return new di(t, e, i);
      }
      var _t = Pt.extend({
        options: {
          smoothFactor: 1,
          noClip: false
        },
        initialize: function(t, e) {
          I(this, e), this._setLatLngs(t);
        },
        getLatLngs: function() {
          return this._latlngs;
        },
        setLatLngs: function(t) {
          return this._setLatLngs(t), this.redraw();
        },
        isEmpty: function() {
          return !this._latlngs.length;
        },
        closestLayerPoint: function(t) {
          for (var e = 1 / 0, i = null, n = $t, o, a, r = 0, h = this._parts.length; r < h; r++) for (var u = this._parts[r], p = 1, y = u.length; p < y; p++) {
            o = u[p - 1], a = u[p];
            var w = n(t, o, a, true);
            w < e && (e = w, i = n(t, o, a));
          }
          return i && (i.distance = Math.sqrt(e)), i;
        },
        getCenter: function() {
          if (!this._map) throw new Error("Must add layer to map before using getCenter()");
          return pn(this._defaultShape(), this._map.options.crs);
        },
        getBounds: function() {
          return this._bounds;
        },
        addLatLng: function(t, e) {
          return e = e || this._defaultShape(), t = O(t), e.push(t), this._bounds.extend(t), this.redraw();
        },
        _setLatLngs: function(t) {
          this._bounds = new Y(), this._latlngs = this._convertLatLngs(t);
        },
        _defaultShape: function() {
          return et(this._latlngs) ? this._latlngs : this._latlngs[0];
        },
        _convertLatLngs: function(t) {
          for (var e = [], i = et(t), n = 0, o = t.length; n < o; n++) i ? (e[n] = O(t[n]), this._bounds.extend(e[n])) : e[n] = this._convertLatLngs(t[n]);
          return e;
        },
        _project: function() {
          var t = new N();
          this._rings = [], this._projectLatlngs(this._latlngs, this._rings, t), this._bounds.isValid() && t.isValid() && (this._rawPxBounds = t, this._updateBounds());
        },
        _updateBounds: function() {
          var t = this._clickTolerance(), e = new M(t, t);
          this._rawPxBounds && (this._pxBounds = new N([
            this._rawPxBounds.min.subtract(e),
            this._rawPxBounds.max.add(e)
          ]));
        },
        _projectLatlngs: function(t, e, i) {
          var n = t[0] instanceof Z, o = t.length, a, r;
          if (n) {
            for (r = [], a = 0; a < o; a++) r[a] = this._map.latLngToLayerPoint(t[a]), i.extend(r[a]);
            e.push(r);
          } else for (a = 0; a < o; a++) this._projectLatlngs(t[a], e, i);
        },
        _clipPoints: function() {
          var t = this._renderer._bounds;
          if (this._parts = [], !(!this._pxBounds || !this._pxBounds.intersects(t))) {
            if (this.options.noClip) {
              this._parts = this._rings;
              return;
            }
            var e = this._parts, i, n, o, a, r, h, u;
            for (i = 0, o = 0, a = this._rings.length; i < a; i++) for (u = this._rings[i], n = 0, r = u.length; n < r - 1; n++) h = dn(u[n], u[n + 1], t, n, true), h && (e[o] = e[o] || [], e[o].push(h[0]), (h[1] !== u[n + 1] || n === r - 2) && (e[o].push(h[1]), o++));
          }
        },
        _simplifyPoints: function() {
          for (var t = this._parts, e = this.options.smoothFactor, i = 0, n = t.length; i < n; i++) t[i] = ln(t[i], e);
        },
        _update: function() {
          this._map && (this._clipPoints(), this._simplifyPoints(), this._updatePath());
        },
        _updatePath: function() {
          this._renderer._updatePoly(this);
        },
        _containsPoint: function(t, e) {
          var i, n, o, a, r, h, u = this._clickTolerance();
          if (!this._pxBounds || !this._pxBounds.contains(t)) return false;
          for (i = 0, a = this._parts.length; i < a; i++) for (h = this._parts[i], n = 0, r = h.length, o = r - 1; n < r; o = n++) if (!(!e && n === 0) && un(t, h[o], h[n]) <= u) return true;
          return false;
        }
      });
      function ta(t, e) {
        return new _t(t, e);
      }
      _t._flat = fn;
      var Nt = _t.extend({
        options: {
          fill: true
        },
        isEmpty: function() {
          return !this._latlngs.length || !this._latlngs[0].length;
        },
        getCenter: function() {
          if (!this._map) throw new Error("Must add layer to map before using getCenter()");
          return hn(this._defaultShape(), this._map.options.crs);
        },
        _convertLatLngs: function(t) {
          var e = _t.prototype._convertLatLngs.call(this, t), i = e.length;
          return i >= 2 && e[0] instanceof Z && e[0].equals(e[i - 1]) && e.pop(), e;
        },
        _setLatLngs: function(t) {
          _t.prototype._setLatLngs.call(this, t), et(this._latlngs) && (this._latlngs = [
            this._latlngs
          ]);
        },
        _defaultShape: function() {
          return et(this._latlngs[0]) ? this._latlngs[0] : this._latlngs[0][0];
        },
        _clipPoints: function() {
          var t = this._renderer._bounds, e = this.options.weight, i = new M(e, e);
          if (t = new N(t.min.subtract(i), t.max.add(i)), this._parts = [], !(!this._pxBounds || !this._pxBounds.intersects(t))) {
            if (this.options.noClip) {
              this._parts = this._rings;
              return;
            }
            for (var n = 0, o = this._rings.length, a; n < o; n++) a = sn(this._rings[n], t, true), a.length && this._parts.push(a);
          }
        },
        _updatePath: function() {
          this._renderer._updatePoly(this, true);
        },
        _containsPoint: function(t) {
          var e = false, i, n, o, a, r, h, u, p;
          if (!this._pxBounds || !this._pxBounds.contains(t)) return false;
          for (a = 0, u = this._parts.length; a < u; a++) for (i = this._parts[a], r = 0, p = i.length, h = p - 1; r < p; h = r++) n = i[r], o = i[h], n.y > t.y != o.y > t.y && t.x < (o.x - n.x) * (t.y - n.y) / (o.y - n.y) + n.x && (e = !e);
          return e || _t.prototype._containsPoint.call(this, t, true);
        }
      });
      function ea(t, e) {
        return new Nt(t, e);
      }
      var gt = mt.extend({
        initialize: function(t, e) {
          I(this, e), this._layers = {}, t && this.addData(t);
        },
        addData: function(t) {
          var e = ot(t) ? t : t.features, i, n, o;
          if (e) {
            for (i = 0, n = e.length; i < n; i++) o = e[i], (o.geometries || o.geometry || o.features || o.coordinates) && this.addData(o);
            return this;
          }
          var a = this.options;
          if (a.filter && !a.filter(t)) return this;
          var r = xe(t, a);
          return r ? (r.feature = Pe(t), r.defaultOptions = r.options, this.resetStyle(r), a.onEachFeature && a.onEachFeature(t, r), this.addLayer(r)) : this;
        },
        resetStyle: function(t) {
          return t === void 0 ? this.eachLayer(this.resetStyle, this) : (t.options = f({}, t.defaultOptions), this._setLayerStyle(t, this.options.style), this);
        },
        setStyle: function(t) {
          return this.eachLayer(function(e) {
            this._setLayerStyle(e, t);
          }, this);
        },
        _setLayerStyle: function(t, e) {
          t.setStyle && (typeof e == "function" && (e = e(t.feature)), t.setStyle(e));
        }
      });
      function xe(t, e) {
        var i = t.type === "Feature" ? t.geometry : t, n = i ? i.coordinates : null, o = [], a = e && e.pointToLayer, r = e && e.coordsToLatLng || fi, h, u, p, y;
        if (!n && !i) return null;
        switch (i.type) {
          case "Point":
            return h = r(n), gn(a, t, h, e);
          case "MultiPoint":
            for (p = 0, y = n.length; p < y; p++) h = r(n[p]), o.push(gn(a, t, h, e));
            return new mt(o);
          case "LineString":
          case "MultiLineString":
            return u = be(n, i.type === "LineString" ? 0 : 1, r), new _t(u, e);
          case "Polygon":
          case "MultiPolygon":
            return u = be(n, i.type === "Polygon" ? 1 : 2, r), new Nt(u, e);
          case "GeometryCollection":
            for (p = 0, y = i.geometries.length; p < y; p++) {
              var w = xe({
                geometry: i.geometries[p],
                type: "Feature",
                properties: t.properties
              }, e);
              w && o.push(w);
            }
            return new mt(o);
          case "FeatureCollection":
            for (p = 0, y = i.features.length; p < y; p++) {
              var k = xe(i.features[p], e);
              k && o.push(k);
            }
            return new mt(o);
          default:
            throw new Error("Invalid GeoJSON object.");
        }
      }
      function gn(t, e, i, n) {
        return t ? t(e, i) : new ve(i, n && n.markersInheritOptions && n);
      }
      function fi(t) {
        return new Z(t[1], t[0], t[2]);
      }
      function be(t, e, i) {
        for (var n = [], o = 0, a = t.length, r; o < a; o++) r = e ? be(t[o], e - 1, i) : (i || fi)(t[o]), n.push(r);
        return n;
      }
      function pi(t, e) {
        return t = O(t), t.alt !== void 0 ? [
          K(t.lng, e),
          K(t.lat, e),
          K(t.alt, e)
        ] : [
          K(t.lng, e),
          K(t.lat, e)
        ];
      }
      function we(t, e, i, n) {
        for (var o = [], a = 0, r = t.length; a < r; a++) o.push(e ? we(t[a], et(t[a]) ? 0 : e - 1, i, n) : pi(t[a], n));
        return !e && i && o.length > 0 && o.push(o[0].slice()), o;
      }
      function Rt(t, e) {
        return t.feature ? f({}, t.feature, {
          geometry: e
        }) : Pe(e);
      }
      function Pe(t) {
        return t.type === "Feature" || t.type === "FeatureCollection" ? t : {
          type: "Feature",
          properties: {},
          geometry: t
        };
      }
      var mi = {
        toGeoJSON: function(t) {
          return Rt(this, {
            type: "Point",
            coordinates: pi(this.getLatLng(), t)
          });
        }
      };
      ve.include(mi), di.include(mi), ye.include(mi), _t.include({
        toGeoJSON: function(t) {
          var e = !et(this._latlngs), i = we(this._latlngs, e ? 1 : 0, false, t);
          return Rt(this, {
            type: (e ? "Multi" : "") + "LineString",
            coordinates: i
          });
        }
      }), Nt.include({
        toGeoJSON: function(t) {
          var e = !et(this._latlngs), i = e && !et(this._latlngs[0]), n = we(this._latlngs, i ? 2 : e ? 1 : 0, true, t);
          return e || (n = [
            n
          ]), Rt(this, {
            type: (i ? "Multi" : "") + "Polygon",
            coordinates: n
          });
        }
      }), Bt.include({
        toMultiPoint: function(t) {
          var e = [];
          return this.eachLayer(function(i) {
            e.push(i.toGeoJSON(t).geometry.coordinates);
          }), Rt(this, {
            type: "MultiPoint",
            coordinates: e
          });
        },
        toGeoJSON: function(t) {
          var e = this.feature && this.feature.geometry && this.feature.geometry.type;
          if (e === "MultiPoint") return this.toMultiPoint(t);
          var i = e === "GeometryCollection", n = [];
          return this.eachLayer(function(o) {
            if (o.toGeoJSON) {
              var a = o.toGeoJSON(t);
              if (i) n.push(a.geometry);
              else {
                var r = Pe(a);
                r.type === "FeatureCollection" ? n.push.apply(n, r.features) : n.push(r);
              }
            }
          }), i ? Rt(this, {
            geometries: n,
            type: "GeometryCollection"
          }) : {
            type: "FeatureCollection",
            features: n
          };
        }
      });
      function vn(t, e) {
        return new gt(t, e);
      }
      var ia = vn, Le = rt.extend({
        options: {
          opacity: 1,
          alt: "",
          interactive: false,
          crossOrigin: false,
          errorOverlayUrl: "",
          zIndex: 1,
          className: ""
        },
        initialize: function(t, e, i) {
          this._url = t, this._bounds = F(e), I(this, i);
        },
        onAdd: function() {
          this._image || (this._initImage(), this.options.opacity < 1 && this._updateOpacity()), this.options.interactive && (C(this._image, "leaflet-interactive"), this.addInteractiveTarget(this._image)), this.getPane().appendChild(this._image), this._reset();
        },
        onRemove: function() {
          R(this._image), this.options.interactive && this.removeInteractiveTarget(this._image);
        },
        setOpacity: function(t) {
          return this.options.opacity = t, this._image && this._updateOpacity(), this;
        },
        setStyle: function(t) {
          return t.opacity && this.setOpacity(t.opacity), this;
        },
        bringToFront: function() {
          return this._map && Zt(this._image), this;
        },
        bringToBack: function() {
          return this._map && It(this._image), this;
        },
        setUrl: function(t) {
          return this._url = t, this._image && (this._image.src = t), this;
        },
        setBounds: function(t) {
          return this._bounds = F(t), this._map && this._reset(), this;
        },
        getEvents: function() {
          var t = {
            zoom: this._reset,
            viewreset: this._reset
          };
          return this._zoomAnimated && (t.zoomanim = this._animateZoom), t;
        },
        setZIndex: function(t) {
          return this.options.zIndex = t, this._updateZIndex(), this;
        },
        getBounds: function() {
          return this._bounds;
        },
        getElement: function() {
          return this._image;
        },
        _initImage: function() {
          var t = this._url.tagName === "IMG", e = this._image = t ? this._url : A("img");
          if (C(e, "leaflet-image-layer"), this._zoomAnimated && C(e, "leaflet-zoom-animated"), this.options.className && C(e, this.options.className), e.onselectstart = T, e.onmousemove = T, e.onload = g(this.fire, this, "load"), e.onerror = g(this._overlayOnError, this, "error"), (this.options.crossOrigin || this.options.crossOrigin === "") && (e.crossOrigin = this.options.crossOrigin === true ? "" : this.options.crossOrigin), this.options.zIndex && this._updateZIndex(), t) {
            this._url = e.src;
            return;
          }
          e.src = this._url, e.alt = this.options.alt;
        },
        _animateZoom: function(t) {
          var e = this._map.getZoomScale(t.zoom), i = this._map._latLngBoundsToNewLayerBounds(this._bounds, t.zoom, t.center).min;
          Tt(this._image, i, e);
        },
        _reset: function() {
          var t = this._image, e = new N(this._map.latLngToLayerPoint(this._bounds.getNorthWest()), this._map.latLngToLayerPoint(this._bounds.getSouthEast())), i = e.getSize();
          W(t, e.min), t.style.width = i.x + "px", t.style.height = i.y + "px";
        },
        _updateOpacity: function() {
          tt(this._image, this.options.opacity);
        },
        _updateZIndex: function() {
          this._image && this.options.zIndex !== void 0 && this.options.zIndex !== null && (this._image.style.zIndex = this.options.zIndex);
        },
        _overlayOnError: function() {
          this.fire("error");
          var t = this.options.errorOverlayUrl;
          t && this._url !== t && (this._url = t, this._image.src = t);
        },
        getCenter: function() {
          return this._bounds.getCenter();
        }
      }), na = function(t, e, i) {
        return new Le(t, e, i);
      }, yn = Le.extend({
        options: {
          autoplay: true,
          loop: true,
          keepAspectRatio: true,
          muted: false,
          playsInline: true
        },
        _initImage: function() {
          var t = this._url.tagName === "VIDEO", e = this._image = t ? this._url : A("video");
          if (C(e, "leaflet-image-layer"), this._zoomAnimated && C(e, "leaflet-zoom-animated"), this.options.className && C(e, this.options.className), e.onselectstart = T, e.onmousemove = T, e.onloadeddata = g(this.fire, this, "load"), t) {
            for (var i = e.getElementsByTagName("source"), n = [], o = 0; o < i.length; o++) n.push(i[o].src);
            this._url = i.length > 0 ? n : [
              e.src
            ];
            return;
          }
          ot(this._url) || (this._url = [
            this._url
          ]), !this.options.keepAspectRatio && Object.prototype.hasOwnProperty.call(e.style, "objectFit") && (e.style.objectFit = "fill"), e.autoplay = !!this.options.autoplay, e.loop = !!this.options.loop, e.muted = !!this.options.muted, e.playsInline = !!this.options.playsInline;
          for (var a = 0; a < this._url.length; a++) {
            var r = A("source");
            r.src = this._url[a], e.appendChild(r);
          }
        }
      });
      function oa(t, e, i) {
        return new yn(t, e, i);
      }
      var xn = Le.extend({
        _initImage: function() {
          var t = this._image = this._url;
          C(t, "leaflet-image-layer"), this._zoomAnimated && C(t, "leaflet-zoom-animated"), this.options.className && C(t, this.options.className), t.onselectstart = T, t.onmousemove = T;
        }
      });
      function aa(t, e, i) {
        return new xn(t, e, i);
      }
      var ut = rt.extend({
        options: {
          interactive: false,
          offset: [
            0,
            0
          ],
          className: "",
          pane: void 0,
          content: ""
        },
        initialize: function(t, e) {
          t && (t instanceof Z || ot(t)) ? (this._latlng = O(t), I(this, e)) : (I(this, t), this._source = e), this.options.content && (this._content = this.options.content);
        },
        openOn: function(t) {
          return t = arguments.length ? t : this._source._map, t.hasLayer(this) || t.addLayer(this), this;
        },
        close: function() {
          return this._map && this._map.removeLayer(this), this;
        },
        toggle: function(t) {
          return this._map ? this.close() : (arguments.length ? this._source = t : t = this._source, this._prepareOpen(), this.openOn(t._map)), this;
        },
        onAdd: function(t) {
          this._zoomAnimated = t._zoomAnimated, this._container || this._initLayout(), t._fadeAnimated && tt(this._container, 0), clearTimeout(this._removeTimeout), this.getPane().appendChild(this._container), this.update(), t._fadeAnimated && tt(this._container, 1), this.bringToFront(), this.options.interactive && (C(this._container, "leaflet-interactive"), this.addInteractiveTarget(this._container));
        },
        onRemove: function(t) {
          t._fadeAnimated ? (tt(this._container, 0), this._removeTimeout = setTimeout(g(R, void 0, this._container), 200)) : R(this._container), this.options.interactive && (H(this._container, "leaflet-interactive"), this.removeInteractiveTarget(this._container));
        },
        getLatLng: function() {
          return this._latlng;
        },
        setLatLng: function(t) {
          return this._latlng = O(t), this._map && (this._updatePosition(), this._adjustPan()), this;
        },
        getContent: function() {
          return this._content;
        },
        setContent: function(t) {
          return this._content = t, this.update(), this;
        },
        getElement: function() {
          return this._container;
        },
        update: function() {
          this._map && (this._container.style.visibility = "hidden", this._updateContent(), this._updateLayout(), this._updatePosition(), this._container.style.visibility = "", this._adjustPan());
        },
        getEvents: function() {
          var t = {
            zoom: this._updatePosition,
            viewreset: this._updatePosition
          };
          return this._zoomAnimated && (t.zoomanim = this._animateZoom), t;
        },
        isOpen: function() {
          return !!this._map && this._map.hasLayer(this);
        },
        bringToFront: function() {
          return this._map && Zt(this._container), this;
        },
        bringToBack: function() {
          return this._map && It(this._container), this;
        },
        _prepareOpen: function(t) {
          var e = this._source;
          if (!e._map) return false;
          if (e instanceof mt) {
            e = null;
            var i = this._source._layers;
            for (var n in i) if (i[n]._map) {
              e = i[n];
              break;
            }
            if (!e) return false;
            this._source = e;
          }
          if (!t) if (e.getCenter) t = e.getCenter();
          else if (e.getLatLng) t = e.getLatLng();
          else if (e.getBounds) t = e.getBounds().getCenter();
          else throw new Error("Unable to get source layer LatLng.");
          return this.setLatLng(t), this._map && this.update(), true;
        },
        _updateContent: function() {
          if (this._content) {
            var t = this._contentNode, e = typeof this._content == "function" ? this._content(this._source || this) : this._content;
            if (typeof e == "string") t.innerHTML = e;
            else {
              for (; t.hasChildNodes(); ) t.removeChild(t.firstChild);
              t.appendChild(e);
            }
            this.fire("contentupdate");
          }
        },
        _updatePosition: function() {
          if (this._map) {
            var t = this._map.latLngToLayerPoint(this._latlng), e = P(this.options.offset), i = this._getAnchor();
            this._zoomAnimated ? W(this._container, t.add(i)) : e = e.add(t).add(i);
            var n = this._containerBottom = -e.y, o = this._containerLeft = -Math.round(this._containerWidth / 2) + e.x;
            this._container.style.bottom = n + "px", this._container.style.left = o + "px";
          }
        },
        _getAnchor: function() {
          return [
            0,
            0
          ];
        }
      });
      z.include({
        _initOverlay: function(t, e, i, n) {
          var o = e;
          return o instanceof t || (o = new t(n).setContent(e)), i && o.setLatLng(i), o;
        }
      }), rt.include({
        _initOverlay: function(t, e, i, n) {
          var o = i;
          return o instanceof t ? (I(o, n), o._source = this) : (o = e && !n ? e : new t(n, this), o.setContent(i)), o;
        }
      });
      var Te = ut.extend({
        options: {
          pane: "popupPane",
          offset: [
            0,
            7
          ],
          maxWidth: 300,
          minWidth: 50,
          maxHeight: null,
          autoPan: true,
          autoPanPaddingTopLeft: null,
          autoPanPaddingBottomRight: null,
          autoPanPadding: [
            5,
            5
          ],
          keepInView: false,
          closeButton: true,
          autoClose: true,
          closeOnEscapeKey: true,
          className: ""
        },
        openOn: function(t) {
          return t = arguments.length ? t : this._source._map, !t.hasLayer(this) && t._popup && t._popup.options.autoClose && t.removeLayer(t._popup), t._popup = this, ut.prototype.openOn.call(this, t);
        },
        onAdd: function(t) {
          ut.prototype.onAdd.call(this, t), t.fire("popupopen", {
            popup: this
          }), this._source && (this._source.fire("popupopen", {
            popup: this
          }, true), this._source instanceof Pt || this._source.on("preclick", St));
        },
        onRemove: function(t) {
          ut.prototype.onRemove.call(this, t), t.fire("popupclose", {
            popup: this
          }), this._source && (this._source.fire("popupclose", {
            popup: this
          }, true), this._source instanceof Pt || this._source.off("preclick", St));
        },
        getEvents: function() {
          var t = ut.prototype.getEvents.call(this);
          return (this.options.closeOnClick !== void 0 ? this.options.closeOnClick : this._map.options.closePopupOnClick) && (t.preclick = this.close), this.options.keepInView && (t.moveend = this._adjustPan), t;
        },
        _initLayout: function() {
          var t = "leaflet-popup", e = this._container = A("div", t + " " + (this.options.className || "") + " leaflet-zoom-animated"), i = this._wrapper = A("div", t + "-content-wrapper", e);
          if (this._contentNode = A("div", t + "-content", i), Xt(e), oi(this._contentNode), S(e, "contextmenu", St), this._tipContainer = A("div", t + "-tip-container", e), this._tip = A("div", t + "-tip", this._tipContainer), this.options.closeButton) {
            var n = this._closeButton = A("a", t + "-close-button", e);
            n.setAttribute("role", "button"), n.setAttribute("aria-label", "Close popup"), n.href = "#close", n.innerHTML = '<span aria-hidden="true">&#215;</span>', S(n, "click", function(o) {
              G(o), this.close();
            }, this);
          }
        },
        _updateLayout: function() {
          var t = this._contentNode, e = t.style;
          e.width = "", e.whiteSpace = "nowrap";
          var i = t.offsetWidth;
          i = Math.min(i, this.options.maxWidth), i = Math.max(i, this.options.minWidth), e.width = i + 1 + "px", e.whiteSpace = "", e.height = "";
          var n = t.offsetHeight, o = this.options.maxHeight, a = "leaflet-popup-scrolled";
          o && n > o ? (e.height = o + "px", C(t, a)) : H(t, a), this._containerWidth = this._container.offsetWidth;
        },
        _animateZoom: function(t) {
          var e = this._map._latLngToNewLayerPoint(this._latlng, t.zoom, t.center), i = this._getAnchor();
          W(this._container, e.add(i));
        },
        _adjustPan: function() {
          if (this.options.autoPan) {
            if (this._map._panAnim && this._map._panAnim.stop(), this._autopanning) {
              this._autopanning = false;
              return;
            }
            var t = this._map, e = parseInt(Kt(this._container, "marginBottom"), 10) || 0, i = this._container.offsetHeight + e, n = this._containerWidth, o = new M(this._containerLeft, -i - this._containerBottom);
            o._add(Mt(this._container));
            var a = t.layerPointToContainerPoint(o), r = P(this.options.autoPanPadding), h = P(this.options.autoPanPaddingTopLeft || r), u = P(this.options.autoPanPaddingBottomRight || r), p = t.getSize(), y = 0, w = 0;
            a.x + n + u.x > p.x && (y = a.x + n - p.x + u.x), a.x - y - h.x < 0 && (y = a.x - h.x), a.y + i + u.y > p.y && (w = a.y + i - p.y + u.y), a.y - w - h.y < 0 && (w = a.y - h.y), (y || w) && (this.options.keepInView && (this._autopanning = true), t.fire("autopanstart").panBy([
              y,
              w
            ]));
          }
        },
        _getAnchor: function() {
          return P(this._source && this._source._getPopupAnchor ? this._source._getPopupAnchor() : [
            0,
            0
          ]);
        }
      }), ra = function(t, e) {
        return new Te(t, e);
      };
      z.mergeOptions({
        closePopupOnClick: true
      }), z.include({
        openPopup: function(t, e, i) {
          return this._initOverlay(Te, t, e, i).openOn(this), this;
        },
        closePopup: function(t) {
          return t = arguments.length ? t : this._popup, t && t.close(), this;
        }
      }), rt.include({
        bindPopup: function(t, e) {
          return this._popup = this._initOverlay(Te, this._popup, t, e), this._popupHandlersAdded || (this.on({
            click: this._openPopup,
            keypress: this._onKeyPress,
            remove: this.closePopup,
            move: this._movePopup
          }), this._popupHandlersAdded = true), this;
        },
        unbindPopup: function() {
          return this._popup && (this.off({
            click: this._openPopup,
            keypress: this._onKeyPress,
            remove: this.closePopup,
            move: this._movePopup
          }), this._popupHandlersAdded = false, this._popup = null), this;
        },
        openPopup: function(t) {
          return this._popup && (this instanceof mt || (this._popup._source = this), this._popup._prepareOpen(t || this._latlng) && this._popup.openOn(this._map)), this;
        },
        closePopup: function() {
          return this._popup && this._popup.close(), this;
        },
        togglePopup: function() {
          return this._popup && this._popup.toggle(this), this;
        },
        isPopupOpen: function() {
          return this._popup ? this._popup.isOpen() : false;
        },
        setPopupContent: function(t) {
          return this._popup && this._popup.setContent(t), this;
        },
        getPopup: function() {
          return this._popup;
        },
        _openPopup: function(t) {
          if (!(!this._popup || !this._map)) {
            Ct(t);
            var e = t.layer || t.target;
            if (this._popup._source === e && !(e instanceof Pt)) {
              this._map.hasLayer(this._popup) ? this.closePopup() : this.openPopup(t.latlng);
              return;
            }
            this._popup._source = e, this.openPopup(t.latlng);
          }
        },
        _movePopup: function(t) {
          this._popup.setLatLng(t.latlng);
        },
        _onKeyPress: function(t) {
          t.originalEvent.keyCode === 13 && this._openPopup(t);
        }
      });
      var Me = ut.extend({
        options: {
          pane: "tooltipPane",
          offset: [
            0,
            0
          ],
          direction: "auto",
          permanent: false,
          sticky: false,
          opacity: 0.9
        },
        onAdd: function(t) {
          ut.prototype.onAdd.call(this, t), this.setOpacity(this.options.opacity), t.fire("tooltipopen", {
            tooltip: this
          }), this._source && (this.addEventParent(this._source), this._source.fire("tooltipopen", {
            tooltip: this
          }, true));
        },
        onRemove: function(t) {
          ut.prototype.onRemove.call(this, t), t.fire("tooltipclose", {
            tooltip: this
          }), this._source && (this.removeEventParent(this._source), this._source.fire("tooltipclose", {
            tooltip: this
          }, true));
        },
        getEvents: function() {
          var t = ut.prototype.getEvents.call(this);
          return this.options.permanent || (t.preclick = this.close), t;
        },
        _initLayout: function() {
          var t = "leaflet-tooltip", e = t + " " + (this.options.className || "") + " leaflet-zoom-" + (this._zoomAnimated ? "animated" : "hide");
          this._contentNode = this._container = A("div", e), this._container.setAttribute("role", "tooltip"), this._container.setAttribute("id", "leaflet-tooltip-" + _(this));
        },
        _updateLayout: function() {
        },
        _adjustPan: function() {
        },
        _setPosition: function(t) {
          var e, i, n = this._map, o = this._container, a = n.latLngToContainerPoint(n.getCenter()), r = n.layerPointToContainerPoint(t), h = this.options.direction, u = o.offsetWidth, p = o.offsetHeight, y = P(this.options.offset), w = this._getAnchor();
          h === "top" ? (e = u / 2, i = p) : h === "bottom" ? (e = u / 2, i = 0) : h === "center" ? (e = u / 2, i = p / 2) : h === "right" ? (e = 0, i = p / 2) : h === "left" ? (e = u, i = p / 2) : r.x < a.x ? (h = "right", e = 0, i = p / 2) : (h = "left", e = u + (y.x + w.x) * 2, i = p / 2), t = t.subtract(P(e, i, true)).add(y).add(w), H(o, "leaflet-tooltip-right"), H(o, "leaflet-tooltip-left"), H(o, "leaflet-tooltip-top"), H(o, "leaflet-tooltip-bottom"), C(o, "leaflet-tooltip-" + h), W(o, t);
        },
        _updatePosition: function() {
          var t = this._map.latLngToLayerPoint(this._latlng);
          this._setPosition(t);
        },
        setOpacity: function(t) {
          this.options.opacity = t, this._container && tt(this._container, t);
        },
        _animateZoom: function(t) {
          var e = this._map._latLngToNewLayerPoint(this._latlng, t.zoom, t.center);
          this._setPosition(e);
        },
        _getAnchor: function() {
          return P(this._source && this._source._getTooltipAnchor && !this.options.sticky ? this._source._getTooltipAnchor() : [
            0,
            0
          ]);
        }
      }), sa = function(t, e) {
        return new Me(t, e);
      };
      z.include({
        openTooltip: function(t, e, i) {
          return this._initOverlay(Me, t, e, i).openOn(this), this;
        },
        closeTooltip: function(t) {
          return t.close(), this;
        }
      }), rt.include({
        bindTooltip: function(t, e) {
          return this._tooltip && this.isTooltipOpen() && this.unbindTooltip(), this._tooltip = this._initOverlay(Me, this._tooltip, t, e), this._initTooltipInteractions(), this._tooltip.options.permanent && this._map && this._map.hasLayer(this) && this.openTooltip(), this;
        },
        unbindTooltip: function() {
          return this._tooltip && (this._initTooltipInteractions(true), this.closeTooltip(), this._tooltip = null), this;
        },
        _initTooltipInteractions: function(t) {
          if (!(!t && this._tooltipHandlersAdded)) {
            var e = t ? "off" : "on", i = {
              remove: this.closeTooltip,
              move: this._moveTooltip
            };
            this._tooltip.options.permanent ? i.add = this._openTooltip : (i.mouseover = this._openTooltip, i.mouseout = this.closeTooltip, i.click = this._openTooltip, this._map ? this._addFocusListeners() : i.add = this._addFocusListeners), this._tooltip.options.sticky && (i.mousemove = this._moveTooltip), this[e](i), this._tooltipHandlersAdded = !t;
          }
        },
        openTooltip: function(t) {
          return this._tooltip && (this instanceof mt || (this._tooltip._source = this), this._tooltip._prepareOpen(t) && (this._tooltip.openOn(this._map), this.getElement ? this._setAriaDescribedByOnLayer(this) : this.eachLayer && this.eachLayer(this._setAriaDescribedByOnLayer, this))), this;
        },
        closeTooltip: function() {
          if (this._tooltip) return this._tooltip.close();
        },
        toggleTooltip: function() {
          return this._tooltip && this._tooltip.toggle(this), this;
        },
        isTooltipOpen: function() {
          return this._tooltip.isOpen();
        },
        setTooltipContent: function(t) {
          return this._tooltip && this._tooltip.setContent(t), this;
        },
        getTooltip: function() {
          return this._tooltip;
        },
        _addFocusListeners: function() {
          this.getElement ? this._addFocusListenersOnLayer(this) : this.eachLayer && this.eachLayer(this._addFocusListenersOnLayer, this);
        },
        _addFocusListenersOnLayer: function(t) {
          var e = typeof t.getElement == "function" && t.getElement();
          e && (S(e, "focus", function() {
            this._tooltip._source = t, this.openTooltip();
          }, this), S(e, "blur", this.closeTooltip, this));
        },
        _setAriaDescribedByOnLayer: function(t) {
          var e = typeof t.getElement == "function" && t.getElement();
          e && e.setAttribute("aria-describedby", this._tooltip._container.id);
        },
        _openTooltip: function(t) {
          if (!(!this._tooltip || !this._map)) {
            if (this._map.dragging && this._map.dragging.moving() && !this._openOnceFlag) {
              this._openOnceFlag = true;
              var e = this;
              this._map.once("moveend", function() {
                e._openOnceFlag = false, e._openTooltip(t);
              });
              return;
            }
            this._tooltip._source = t.layer || t.target, this.openTooltip(this._tooltip.options.sticky ? t.latlng : void 0);
          }
        },
        _moveTooltip: function(t) {
          var e = t.latlng, i, n;
          this._tooltip.options.sticky && t.originalEvent && (i = this._map.mouseEventToContainerPoint(t.originalEvent), n = this._map.containerPointToLayerPoint(i), e = this._map.layerPointToLatLng(n)), this._tooltip.setLatLng(e);
        }
      });
      var bn = Dt.extend({
        options: {
          iconSize: [
            12,
            12
          ],
          html: false,
          bgPos: null,
          className: "leaflet-div-icon"
        },
        createIcon: function(t) {
          var e = t && t.tagName === "DIV" ? t : document.createElement("div"), i = this.options;
          if (i.html instanceof Element ? (de(e), e.appendChild(i.html)) : e.innerHTML = i.html !== false ? i.html : "", i.bgPos) {
            var n = P(i.bgPos);
            e.style.backgroundPosition = -n.x + "px " + -n.y + "px";
          }
          return this._setIconStyles(e, "icon"), e;
        },
        createShadow: function() {
          return null;
        }
      });
      function ha(t) {
        return new bn(t);
      }
      Dt.Default = te;
      var ee = rt.extend({
        options: {
          tileSize: 256,
          opacity: 1,
          updateWhenIdle: x.mobile,
          updateWhenZooming: true,
          updateInterval: 200,
          zIndex: 1,
          bounds: null,
          minZoom: 0,
          maxZoom: void 0,
          maxNativeZoom: void 0,
          minNativeZoom: void 0,
          noWrap: false,
          pane: "tilePane",
          className: "",
          keepBuffer: 2
        },
        initialize: function(t) {
          I(this, t);
        },
        onAdd: function() {
          this._initContainer(), this._levels = {}, this._tiles = {}, this._resetView();
        },
        beforeAdd: function(t) {
          t._addZoomLimit(this);
        },
        onRemove: function(t) {
          this._removeAllTiles(), R(this._container), t._removeZoomLimit(this), this._container = null, this._tileZoom = void 0;
        },
        bringToFront: function() {
          return this._map && (Zt(this._container), this._setAutoZIndex(Math.max)), this;
        },
        bringToBack: function() {
          return this._map && (It(this._container), this._setAutoZIndex(Math.min)), this;
        },
        getContainer: function() {
          return this._container;
        },
        setOpacity: function(t) {
          return this.options.opacity = t, this._updateOpacity(), this;
        },
        setZIndex: function(t) {
          return this.options.zIndex = t, this._updateZIndex(), this;
        },
        isLoading: function() {
          return this._loading;
        },
        redraw: function() {
          if (this._map) {
            this._removeAllTiles();
            var t = this._clampZoom(this._map.getZoom());
            t !== this._tileZoom && (this._tileZoom = t, this._updateLevels()), this._update();
          }
          return this;
        },
        getEvents: function() {
          var t = {
            viewprereset: this._invalidateAll,
            viewreset: this._resetView,
            zoom: this._resetView,
            moveend: this._onMoveEnd
          };
          return this.options.updateWhenIdle || (this._onMove || (this._onMove = E(this._onMoveEnd, this.options.updateInterval, this)), t.move = this._onMove), this._zoomAnimated && (t.zoomanim = this._animateZoom), t;
        },
        createTile: function() {
          return document.createElement("div");
        },
        getTileSize: function() {
          var t = this.options.tileSize;
          return t instanceof M ? t : new M(t, t);
        },
        _updateZIndex: function() {
          this._container && this.options.zIndex !== void 0 && this.options.zIndex !== null && (this._container.style.zIndex = this.options.zIndex);
        },
        _setAutoZIndex: function(t) {
          for (var e = this.getPane().children, i = -t(-1 / 0, 1 / 0), n = 0, o = e.length, a; n < o; n++) a = e[n].style.zIndex, e[n] !== this._container && a && (i = t(i, +a));
          isFinite(i) && (this.options.zIndex = i + t(-1, 1), this._updateZIndex());
        },
        _updateOpacity: function() {
          if (this._map && !x.ielt9) {
            tt(this._container, this.options.opacity);
            var t = +/* @__PURE__ */ new Date(), e = false, i = false;
            for (var n in this._tiles) {
              var o = this._tiles[n];
              if (!(!o.current || !o.loaded)) {
                var a = Math.min(1, (t - o.loaded) / 200);
                tt(o.el, a), a < 1 ? e = true : (o.active ? i = true : this._onOpaqueTile(o), o.active = true);
              }
            }
            i && !this._noPrune && this._pruneTiles(), e && ($(this._fadeFrame), this._fadeFrame = q(this._updateOpacity, this));
          }
        },
        _onOpaqueTile: T,
        _initContainer: function() {
          this._container || (this._container = A("div", "leaflet-layer " + (this.options.className || "")), this._updateZIndex(), this.options.opacity < 1 && this._updateOpacity(), this.getPane().appendChild(this._container));
        },
        _updateLevels: function() {
          var t = this._tileZoom, e = this.options.maxZoom;
          if (t !== void 0) {
            for (var i in this._levels) i = Number(i), this._levels[i].el.children.length || i === t ? (this._levels[i].el.style.zIndex = e - Math.abs(t - i), this._onUpdateLevel(i)) : (R(this._levels[i].el), this._removeTilesAtZoom(i), this._onRemoveLevel(i), delete this._levels[i]);
            var n = this._levels[t], o = this._map;
            return n || (n = this._levels[t] = {}, n.el = A("div", "leaflet-tile-container leaflet-zoom-animated", this._container), n.el.style.zIndex = e, n.origin = o.project(o.unproject(o.getPixelOrigin()), t).round(), n.zoom = t, this._setZoomTransform(n, o.getCenter(), o.getZoom()), T(n.el.offsetWidth), this._onCreateLevel(n)), this._level = n, n;
          }
        },
        _onUpdateLevel: T,
        _onRemoveLevel: T,
        _onCreateLevel: T,
        _pruneTiles: function() {
          if (this._map) {
            var t, e, i = this._map.getZoom();
            if (i > this.options.maxZoom || i < this.options.minZoom) {
              this._removeAllTiles();
              return;
            }
            for (t in this._tiles) e = this._tiles[t], e.retain = e.current;
            for (t in this._tiles) if (e = this._tiles[t], e.current && !e.active) {
              var n = e.coords;
              this._retainParent(n.x, n.y, n.z, n.z - 5) || this._retainChildren(n.x, n.y, n.z, n.z + 2);
            }
            for (t in this._tiles) this._tiles[t].retain || this._removeTile(t);
          }
        },
        _removeTilesAtZoom: function(t) {
          for (var e in this._tiles) this._tiles[e].coords.z === t && this._removeTile(e);
        },
        _removeAllTiles: function() {
          for (var t in this._tiles) this._removeTile(t);
        },
        _invalidateAll: function() {
          for (var t in this._levels) R(this._levels[t].el), this._onRemoveLevel(Number(t)), delete this._levels[t];
          this._removeAllTiles(), this._tileZoom = void 0;
        },
        _retainParent: function(t, e, i, n) {
          var o = Math.floor(t / 2), a = Math.floor(e / 2), r = i - 1, h = new M(+o, +a);
          h.z = +r;
          var u = this._tileCoordsToKey(h), p = this._tiles[u];
          return p && p.active ? (p.retain = true, true) : (p && p.loaded && (p.retain = true), r > n ? this._retainParent(o, a, r, n) : false);
        },
        _retainChildren: function(t, e, i, n) {
          for (var o = 2 * t; o < 2 * t + 2; o++) for (var a = 2 * e; a < 2 * e + 2; a++) {
            var r = new M(o, a);
            r.z = i + 1;
            var h = this._tileCoordsToKey(r), u = this._tiles[h];
            if (u && u.active) {
              u.retain = true;
              continue;
            } else u && u.loaded && (u.retain = true);
            i + 1 < n && this._retainChildren(o, a, i + 1, n);
          }
        },
        _resetView: function(t) {
          var e = t && (t.pinch || t.flyTo);
          this._setView(this._map.getCenter(), this._map.getZoom(), e, e);
        },
        _animateZoom: function(t) {
          this._setView(t.center, t.zoom, true, t.noUpdate);
        },
        _clampZoom: function(t) {
          var e = this.options;
          return e.minNativeZoom !== void 0 && t < e.minNativeZoom ? e.minNativeZoom : e.maxNativeZoom !== void 0 && e.maxNativeZoom < t ? e.maxNativeZoom : t;
        },
        _setView: function(t, e, i, n) {
          var o = Math.round(e);
          this.options.maxZoom !== void 0 && o > this.options.maxZoom || this.options.minZoom !== void 0 && o < this.options.minZoom ? o = void 0 : o = this._clampZoom(o);
          var a = this.options.updateWhenZooming && o !== this._tileZoom;
          (!n || a) && (this._tileZoom = o, this._abortLoading && this._abortLoading(), this._updateLevels(), this._resetGrid(), o !== void 0 && this._update(t), i || this._pruneTiles(), this._noPrune = !!i), this._setZoomTransforms(t, e);
        },
        _setZoomTransforms: function(t, e) {
          for (var i in this._levels) this._setZoomTransform(this._levels[i], t, e);
        },
        _setZoomTransform: function(t, e, i) {
          var n = this._map.getZoomScale(i, t.zoom), o = t.origin.multiplyBy(n).subtract(this._map._getNewPixelOrigin(e, i)).round();
          x.any3d ? Tt(t.el, o, n) : W(t.el, o);
        },
        _resetGrid: function() {
          var t = this._map, e = t.options.crs, i = this._tileSize = this.getTileSize(), n = this._tileZoom, o = this._map.getPixelWorldBounds(this._tileZoom);
          o && (this._globalTileRange = this._pxBoundsToTileRange(o)), this._wrapX = e.wrapLng && !this.options.noWrap && [
            Math.floor(t.project([
              0,
              e.wrapLng[0]
            ], n).x / i.x),
            Math.ceil(t.project([
              0,
              e.wrapLng[1]
            ], n).x / i.y)
          ], this._wrapY = e.wrapLat && !this.options.noWrap && [
            Math.floor(t.project([
              e.wrapLat[0],
              0
            ], n).y / i.x),
            Math.ceil(t.project([
              e.wrapLat[1],
              0
            ], n).y / i.y)
          ];
        },
        _onMoveEnd: function() {
          !this._map || this._map._animatingZoom || this._update();
        },
        _getTiledPixelBounds: function(t) {
          var e = this._map, i = e._animatingZoom ? Math.max(e._animateToZoom, e.getZoom()) : e.getZoom(), n = e.getZoomScale(i, this._tileZoom), o = e.project(t, this._tileZoom).floor(), a = e.getSize().divideBy(n * 2);
          return new N(o.subtract(a), o.add(a));
        },
        _update: function(t) {
          var e = this._map;
          if (e) {
            var i = this._clampZoom(e.getZoom());
            if (t === void 0 && (t = e.getCenter()), this._tileZoom !== void 0) {
              var n = this._getTiledPixelBounds(t), o = this._pxBoundsToTileRange(n), a = o.getCenter(), r = [], h = this.options.keepBuffer, u = new N(o.getBottomLeft().subtract([
                h,
                -h
              ]), o.getTopRight().add([
                h,
                -h
              ]));
              if (!(isFinite(o.min.x) && isFinite(o.min.y) && isFinite(o.max.x) && isFinite(o.max.y))) throw new Error("Attempted to load an infinite number of tiles");
              for (var p in this._tiles) {
                var y = this._tiles[p].coords;
                (y.z !== this._tileZoom || !u.contains(new M(y.x, y.y))) && (this._tiles[p].current = false);
              }
              if (Math.abs(i - this._tileZoom) > 1) {
                this._setView(t, i);
                return;
              }
              for (var w = o.min.y; w <= o.max.y; w++) for (var k = o.min.x; k <= o.max.x; k++) {
                var V = new M(k, w);
                if (V.z = this._tileZoom, !!this._isValidTile(V)) {
                  var j = this._tiles[this._tileCoordsToKey(V)];
                  j ? j.current = true : r.push(V);
                }
              }
              if (r.sort(function(X, Ft) {
                return X.distanceTo(a) - Ft.distanceTo(a);
              }), r.length !== 0) {
                this._loading || (this._loading = true, this.fire("loading"));
                var it = document.createDocumentFragment();
                for (k = 0; k < r.length; k++) this._addTile(r[k], it);
                this._level.el.appendChild(it);
              }
            }
          }
        },
        _isValidTile: function(t) {
          var e = this._map.options.crs;
          if (!e.infinite) {
            var i = this._globalTileRange;
            if (!e.wrapLng && (t.x < i.min.x || t.x > i.max.x) || !e.wrapLat && (t.y < i.min.y || t.y > i.max.y)) return false;
          }
          if (!this.options.bounds) return true;
          var n = this._tileCoordsToBounds(t);
          return F(this.options.bounds).overlaps(n);
        },
        _keyToBounds: function(t) {
          return this._tileCoordsToBounds(this._keyToTileCoords(t));
        },
        _tileCoordsToNwSe: function(t) {
          var e = this._map, i = this.getTileSize(), n = t.scaleBy(i), o = n.add(i), a = e.unproject(n, t.z), r = e.unproject(o, t.z);
          return [
            a,
            r
          ];
        },
        _tileCoordsToBounds: function(t) {
          var e = this._tileCoordsToNwSe(t), i = new Y(e[0], e[1]);
          return this.options.noWrap || (i = this._map.wrapLatLngBounds(i)), i;
        },
        _tileCoordsToKey: function(t) {
          return t.x + ":" + t.y + ":" + t.z;
        },
        _keyToTileCoords: function(t) {
          var e = t.split(":"), i = new M(+e[0], +e[1]);
          return i.z = +e[2], i;
        },
        _removeTile: function(t) {
          var e = this._tiles[t];
          e && (R(e.el), delete this._tiles[t], this.fire("tileunload", {
            tile: e.el,
            coords: this._keyToTileCoords(t)
          }));
        },
        _initTile: function(t) {
          C(t, "leaflet-tile");
          var e = this.getTileSize();
          t.style.width = e.x + "px", t.style.height = e.y + "px", t.onselectstart = T, t.onmousemove = T, x.ielt9 && this.options.opacity < 1 && tt(t, this.options.opacity);
        },
        _addTile: function(t, e) {
          var i = this._getTilePos(t), n = this._tileCoordsToKey(t), o = this.createTile(this._wrapCoords(t), g(this._tileReady, this, t));
          this._initTile(o), this.createTile.length < 2 && q(g(this._tileReady, this, t, null, o)), W(o, i), this._tiles[n] = {
            el: o,
            coords: t,
            current: true
          }, e.appendChild(o), this.fire("tileloadstart", {
            tile: o,
            coords: t
          });
        },
        _tileReady: function(t, e, i) {
          e && this.fire("tileerror", {
            error: e,
            tile: i,
            coords: t
          });
          var n = this._tileCoordsToKey(t);
          i = this._tiles[n], i && (i.loaded = +/* @__PURE__ */ new Date(), this._map._fadeAnimated ? (tt(i.el, 0), $(this._fadeFrame), this._fadeFrame = q(this._updateOpacity, this)) : (i.active = true, this._pruneTiles()), e || (C(i.el, "leaflet-tile-loaded"), this.fire("tileload", {
            tile: i.el,
            coords: t
          })), this._noTilesToLoad() && (this._loading = false, this.fire("load"), x.ielt9 || !this._map._fadeAnimated ? q(this._pruneTiles, this) : setTimeout(g(this._pruneTiles, this), 250)));
        },
        _getTilePos: function(t) {
          return t.scaleBy(this.getTileSize()).subtract(this._level.origin);
        },
        _wrapCoords: function(t) {
          var e = new M(this._wrapX ? b(t.x, this._wrapX) : t.x, this._wrapY ? b(t.y, this._wrapY) : t.y);
          return e.z = t.z, e;
        },
        _pxBoundsToTileRange: function(t) {
          var e = this.getTileSize();
          return new N(t.min.unscaleBy(e).floor(), t.max.unscaleBy(e).ceil().subtract([
            1,
            1
          ]));
        },
        _noTilesToLoad: function() {
          for (var t in this._tiles) if (!this._tiles[t].loaded) return false;
          return true;
        }
      });
      function la(t) {
        return new ee(t);
      }
      var Ht = ee.extend({
        options: {
          minZoom: 0,
          maxZoom: 18,
          subdomains: "abc",
          errorTileUrl: "",
          zoomOffset: 0,
          tms: false,
          zoomReverse: false,
          detectRetina: false,
          crossOrigin: false,
          referrerPolicy: false
        },
        initialize: function(t, e) {
          this._url = t, e = I(this, e), e.detectRetina && x.retina && e.maxZoom > 0 ? (e.tileSize = Math.floor(e.tileSize / 2), e.zoomReverse ? (e.zoomOffset--, e.minZoom = Math.min(e.maxZoom, e.minZoom + 1)) : (e.zoomOffset++, e.maxZoom = Math.max(e.minZoom, e.maxZoom - 1)), e.minZoom = Math.max(0, e.minZoom)) : e.zoomReverse ? e.minZoom = Math.min(e.maxZoom, e.minZoom) : e.maxZoom = Math.max(e.minZoom, e.maxZoom), typeof e.subdomains == "string" && (e.subdomains = e.subdomains.split("")), this.on("tileunload", this._onTileRemove);
        },
        setUrl: function(t, e) {
          return this._url === t && e === void 0 && (e = true), this._url = t, e || this.redraw(), this;
        },
        createTile: function(t, e) {
          var i = document.createElement("img");
          return S(i, "load", g(this._tileOnLoad, this, e, i)), S(i, "error", g(this._tileOnError, this, e, i)), (this.options.crossOrigin || this.options.crossOrigin === "") && (i.crossOrigin = this.options.crossOrigin === true ? "" : this.options.crossOrigin), typeof this.options.referrerPolicy == "string" && (i.referrerPolicy = this.options.referrerPolicy), i.alt = "", i.src = this.getTileUrl(t), i;
        },
        getTileUrl: function(t) {
          var e = {
            r: x.retina ? "@2x" : "",
            s: this._getSubdomain(t),
            x: t.x,
            y: t.y,
            z: this._getZoomForUrl()
          };
          if (this._map && !this._map.options.crs.infinite) {
            var i = this._globalTileRange.max.y - t.y;
            this.options.tms && (e.y = i), e["-y"] = i;
          }
          return Lt(this._url, f(e, this.options));
        },
        _tileOnLoad: function(t, e) {
          x.ielt9 ? setTimeout(g(t, this, null, e), 0) : t(null, e);
        },
        _tileOnError: function(t, e, i) {
          var n = this.options.errorTileUrl;
          n && e.getAttribute("src") !== n && (e.src = n), t(i, e);
        },
        _onTileRemove: function(t) {
          t.tile.onload = null;
        },
        _getZoomForUrl: function() {
          var t = this._tileZoom, e = this.options.maxZoom, i = this.options.zoomReverse, n = this.options.zoomOffset;
          return i && (t = e - t), t + n;
        },
        _getSubdomain: function(t) {
          var e = Math.abs(t.x + t.y) % this.options.subdomains.length;
          return this.options.subdomains[e];
        },
        _abortLoading: function() {
          var t, e;
          for (t in this._tiles) if (this._tiles[t].coords.z !== this._tileZoom && (e = this._tiles[t].el, e.onload = T, e.onerror = T, !e.complete)) {
            e.src = le;
            var i = this._tiles[t].coords;
            R(e), delete this._tiles[t], this.fire("tileabort", {
              tile: e,
              coords: i
            });
          }
        },
        _removeTile: function(t) {
          var e = this._tiles[t];
          if (e) return e.el.setAttribute("src", le), ee.prototype._removeTile.call(this, t);
        },
        _tileReady: function(t, e, i) {
          if (!(!this._map || i && i.getAttribute("src") === le)) return ee.prototype._tileReady.call(this, t, e, i);
        }
      });
      function wn(t, e) {
        return new Ht(t, e);
      }
      var Pn = Ht.extend({
        defaultWmsParams: {
          service: "WMS",
          request: "GetMap",
          layers: "",
          styles: "",
          format: "image/jpeg",
          transparent: false,
          version: "1.1.1"
        },
        options: {
          crs: null,
          uppercase: false
        },
        initialize: function(t, e) {
          this._url = t;
          var i = f({}, this.defaultWmsParams);
          for (var n in e) n in this.options || (i[n] = e[n]);
          e = I(this, e);
          var o = e.detectRetina && x.retina ? 2 : 1, a = this.getTileSize();
          i.width = a.x * o, i.height = a.y * o, this.wmsParams = i;
        },
        onAdd: function(t) {
          this._crs = this.options.crs || t.options.crs, this._wmsVersion = parseFloat(this.wmsParams.version);
          var e = this._wmsVersion >= 1.3 ? "crs" : "srs";
          this.wmsParams[e] = this._crs.code, Ht.prototype.onAdd.call(this, t);
        },
        getTileUrl: function(t) {
          var e = this._tileCoordsToNwSe(t), i = this._crs, n = J(i.project(e[0]), i.project(e[1])), o = n.min, a = n.max, r = (this._wmsVersion >= 1.3 && this._crs === mn ? [
            o.y,
            o.x,
            a.y,
            a.x
          ] : [
            o.x,
            o.y,
            a.x,
            a.y
          ]).join(","), h = Ht.prototype.getTileUrl.call(this, t);
          return h + se(this.wmsParams, h, this.options.uppercase) + (this.options.uppercase ? "&BBOX=" : "&bbox=") + r;
        },
        setParams: function(t, e) {
          return f(this.wmsParams, t), e || this.redraw(), this;
        }
      });
      function ua(t, e) {
        return new Pn(t, e);
      }
      Ht.WMS = Pn, wn.wms = ua;
      var vt = rt.extend({
        options: {
          padding: 0.1
        },
        initialize: function(t) {
          I(this, t), _(this), this._layers = this._layers || {};
        },
        onAdd: function() {
          this._container || (this._initContainer(), C(this._container, "leaflet-zoom-animated")), this.getPane().appendChild(this._container), this._update(), this.on("update", this._updatePaths, this);
        },
        onRemove: function() {
          this.off("update", this._updatePaths, this), this._destroyContainer();
        },
        getEvents: function() {
          var t = {
            viewreset: this._reset,
            zoom: this._onZoom,
            moveend: this._update,
            zoomend: this._onZoomEnd
          };
          return this._zoomAnimated && (t.zoomanim = this._onAnimZoom), t;
        },
        _onAnimZoom: function(t) {
          this._updateTransform(t.center, t.zoom);
        },
        _onZoom: function() {
          this._updateTransform(this._map.getCenter(), this._map.getZoom());
        },
        _updateTransform: function(t, e) {
          var i = this._map.getZoomScale(e, this._zoom), n = this._map.getSize().multiplyBy(0.5 + this.options.padding), o = this._map.project(this._center, e), a = n.multiplyBy(-i).add(o).subtract(this._map._getNewPixelOrigin(t, e));
          x.any3d ? Tt(this._container, a, i) : W(this._container, a);
        },
        _reset: function() {
          this._update(), this._updateTransform(this._center, this._zoom);
          for (var t in this._layers) this._layers[t]._reset();
        },
        _onZoomEnd: function() {
          for (var t in this._layers) this._layers[t]._project();
        },
        _updatePaths: function() {
          for (var t in this._layers) this._layers[t]._update();
        },
        _update: function() {
          var t = this.options.padding, e = this._map.getSize(), i = this._map.containerPointToLayerPoint(e.multiplyBy(-t)).round();
          this._bounds = new N(i, i.add(e.multiplyBy(1 + t * 2)).round()), this._center = this._map.getCenter(), this._zoom = this._map.getZoom();
        }
      }), Ln = vt.extend({
        options: {
          tolerance: 0
        },
        getEvents: function() {
          var t = vt.prototype.getEvents.call(this);
          return t.viewprereset = this._onViewPreReset, t;
        },
        _onViewPreReset: function() {
          this._postponeUpdatePaths = true;
        },
        onAdd: function() {
          vt.prototype.onAdd.call(this), this._draw();
        },
        _initContainer: function() {
          var t = this._container = document.createElement("canvas");
          S(t, "mousemove", this._onMouseMove, this), S(t, "click dblclick mousedown mouseup contextmenu", this._onClick, this), S(t, "mouseout", this._handleMouseOut, this), t._leaflet_disable_events = true, this._ctx = t.getContext("2d");
        },
        _destroyContainer: function() {
          $(this._redrawRequest), delete this._ctx, R(this._container), B(this._container), delete this._container;
        },
        _updatePaths: function() {
          if (!this._postponeUpdatePaths) {
            var t;
            this._redrawBounds = null;
            for (var e in this._layers) t = this._layers[e], t._update();
            this._redraw();
          }
        },
        _update: function() {
          if (!(this._map._animatingZoom && this._bounds)) {
            vt.prototype._update.call(this);
            var t = this._bounds, e = this._container, i = t.getSize(), n = x.retina ? 2 : 1;
            W(e, t.min), e.width = n * i.x, e.height = n * i.y, e.style.width = i.x + "px", e.style.height = i.y + "px", x.retina && this._ctx.scale(2, 2), this._ctx.translate(-t.min.x, -t.min.y), this.fire("update");
          }
        },
        _reset: function() {
          vt.prototype._reset.call(this), this._postponeUpdatePaths && (this._postponeUpdatePaths = false, this._updatePaths());
        },
        _initPath: function(t) {
          this._updateDashArray(t), this._layers[_(t)] = t;
          var e = t._order = {
            layer: t,
            prev: this._drawLast,
            next: null
          };
          this._drawLast && (this._drawLast.next = e), this._drawLast = e, this._drawFirst = this._drawFirst || this._drawLast;
        },
        _addPath: function(t) {
          this._requestRedraw(t);
        },
        _removePath: function(t) {
          var e = t._order, i = e.next, n = e.prev;
          i ? i.prev = n : this._drawLast = n, n ? n.next = i : this._drawFirst = i, delete t._order, delete this._layers[_(t)], this._requestRedraw(t);
        },
        _updatePath: function(t) {
          this._extendRedrawBounds(t), t._project(), t._update(), this._requestRedraw(t);
        },
        _updateStyle: function(t) {
          this._updateDashArray(t), this._requestRedraw(t);
        },
        _updateDashArray: function(t) {
          if (typeof t.options.dashArray == "string") {
            var e = t.options.dashArray.split(/[, ]+/), i = [], n, o;
            for (o = 0; o < e.length; o++) {
              if (n = Number(e[o]), isNaN(n)) return;
              i.push(n);
            }
            t.options._dashArray = i;
          } else t.options._dashArray = t.options.dashArray;
        },
        _requestRedraw: function(t) {
          this._map && (this._extendRedrawBounds(t), this._redrawRequest = this._redrawRequest || q(this._redraw, this));
        },
        _extendRedrawBounds: function(t) {
          if (t._pxBounds) {
            var e = (t.options.weight || 0) + 1;
            this._redrawBounds = this._redrawBounds || new N(), this._redrawBounds.extend(t._pxBounds.min.subtract([
              e,
              e
            ])), this._redrawBounds.extend(t._pxBounds.max.add([
              e,
              e
            ]));
          }
        },
        _redraw: function() {
          this._redrawRequest = null, this._redrawBounds && (this._redrawBounds.min._floor(), this._redrawBounds.max._ceil()), this._clear(), this._draw(), this._redrawBounds = null;
        },
        _clear: function() {
          var t = this._redrawBounds;
          if (t) {
            var e = t.getSize();
            this._ctx.clearRect(t.min.x, t.min.y, e.x, e.y);
          } else this._ctx.save(), this._ctx.setTransform(1, 0, 0, 1, 0, 0), this._ctx.clearRect(0, 0, this._container.width, this._container.height), this._ctx.restore();
        },
        _draw: function() {
          var t, e = this._redrawBounds;
          if (this._ctx.save(), e) {
            var i = e.getSize();
            this._ctx.beginPath(), this._ctx.rect(e.min.x, e.min.y, i.x, i.y), this._ctx.clip();
          }
          this._drawing = true;
          for (var n = this._drawFirst; n; n = n.next) t = n.layer, (!e || t._pxBounds && t._pxBounds.intersects(e)) && t._updatePath();
          this._drawing = false, this._ctx.restore();
        },
        _updatePoly: function(t, e) {
          if (this._drawing) {
            var i, n, o, a, r = t._parts, h = r.length, u = this._ctx;
            if (h) {
              for (u.beginPath(), i = 0; i < h; i++) {
                for (n = 0, o = r[i].length; n < o; n++) a = r[i][n], u[n ? "lineTo" : "moveTo"](a.x, a.y);
                e && u.closePath();
              }
              this._fillStroke(u, t);
            }
          }
        },
        _updateCircle: function(t) {
          if (!(!this._drawing || t._empty())) {
            var e = t._point, i = this._ctx, n = Math.max(Math.round(t._radius), 1), o = (Math.max(Math.round(t._radiusY), 1) || n) / n;
            o !== 1 && (i.save(), i.scale(1, o)), i.beginPath(), i.arc(e.x, e.y / o, n, 0, Math.PI * 2, false), o !== 1 && i.restore(), this._fillStroke(i, t);
          }
        },
        _fillStroke: function(t, e) {
          var i = e.options;
          i.fill && (t.globalAlpha = i.fillOpacity, t.fillStyle = i.fillColor || i.color, t.fill(i.fillRule || "evenodd")), i.stroke && i.weight !== 0 && (t.setLineDash && t.setLineDash(e.options && e.options._dashArray || []), t.globalAlpha = i.opacity, t.lineWidth = i.weight, t.strokeStyle = i.color, t.lineCap = i.lineCap, t.lineJoin = i.lineJoin, t.stroke());
        },
        _onClick: function(t) {
          for (var e = this._map.mouseEventToLayerPoint(t), i, n, o = this._drawFirst; o; o = o.next) i = o.layer, i.options.interactive && i._containsPoint(e) && (!(t.type === "click" || t.type === "preclick") || !this._map._draggableMoved(i)) && (n = i);
          this._fireEvent(n ? [
            n
          ] : false, t);
        },
        _onMouseMove: function(t) {
          if (!(!this._map || this._map.dragging.moving() || this._map._animatingZoom)) {
            var e = this._map.mouseEventToLayerPoint(t);
            this._handleMouseHover(t, e);
          }
        },
        _handleMouseOut: function(t) {
          var e = this._hoveredLayer;
          e && (H(this._container, "leaflet-interactive"), this._fireEvent([
            e
          ], t, "mouseout"), this._hoveredLayer = null, this._mouseHoverThrottled = false);
        },
        _handleMouseHover: function(t, e) {
          if (!this._mouseHoverThrottled) {
            for (var i, n, o = this._drawFirst; o; o = o.next) i = o.layer, i.options.interactive && i._containsPoint(e) && (n = i);
            n !== this._hoveredLayer && (this._handleMouseOut(t), n && (C(this._container, "leaflet-interactive"), this._fireEvent([
              n
            ], t, "mouseover"), this._hoveredLayer = n)), this._fireEvent(this._hoveredLayer ? [
              this._hoveredLayer
            ] : false, t), this._mouseHoverThrottled = true, setTimeout(g(function() {
              this._mouseHoverThrottled = false;
            }, this), 32);
          }
        },
        _fireEvent: function(t, e, i) {
          this._map._fireDOMEvent(e, i || e.type, t);
        },
        _bringToFront: function(t) {
          var e = t._order;
          if (e) {
            var i = e.next, n = e.prev;
            if (i) i.prev = n;
            else return;
            n ? n.next = i : i && (this._drawFirst = i), e.prev = this._drawLast, this._drawLast.next = e, e.next = null, this._drawLast = e, this._requestRedraw(t);
          }
        },
        _bringToBack: function(t) {
          var e = t._order;
          if (e) {
            var i = e.next, n = e.prev;
            if (n) n.next = i;
            else return;
            i ? i.prev = n : n && (this._drawLast = n), e.prev = null, e.next = this._drawFirst, this._drawFirst.prev = e, this._drawFirst = e, this._requestRedraw(t);
          }
        }
      });
      function Tn(t) {
        return x.canvas ? new Ln(t) : null;
      }
      var ie = (function() {
        try {
          return document.namespaces.add("lvml", "urn:schemas-microsoft-com:vml"), function(t) {
            return document.createElement("<lvml:" + t + ' class="lvml">');
          };
        } catch {
        }
        return function(t) {
          return document.createElement("<" + t + ' xmlns="urn:schemas-microsoft.com:vml" class="lvml">');
        };
      })(), ca = {
        _initContainer: function() {
          this._container = A("div", "leaflet-vml-container");
        },
        _update: function() {
          this._map._animatingZoom || (vt.prototype._update.call(this), this.fire("update"));
        },
        _initPath: function(t) {
          var e = t._container = ie("shape");
          C(e, "leaflet-vml-shape " + (this.options.className || "")), e.coordsize = "1 1", t._path = ie("path"), e.appendChild(t._path), this._updateStyle(t), this._layers[_(t)] = t;
        },
        _addPath: function(t) {
          var e = t._container;
          this._container.appendChild(e), t.options.interactive && t.addInteractiveTarget(e);
        },
        _removePath: function(t) {
          var e = t._container;
          R(e), t.removeInteractiveTarget(e), delete this._layers[_(t)];
        },
        _updateStyle: function(t) {
          var e = t._stroke, i = t._fill, n = t.options, o = t._container;
          o.stroked = !!n.stroke, o.filled = !!n.fill, n.stroke ? (e || (e = t._stroke = ie("stroke")), o.appendChild(e), e.weight = n.weight + "px", e.color = n.color, e.opacity = n.opacity, n.dashArray ? e.dashStyle = ot(n.dashArray) ? n.dashArray.join(" ") : n.dashArray.replace(/( *, *)/g, " ") : e.dashStyle = "", e.endcap = n.lineCap.replace("butt", "flat"), e.joinstyle = n.lineJoin) : e && (o.removeChild(e), t._stroke = null), n.fill ? (i || (i = t._fill = ie("fill")), o.appendChild(i), i.color = n.fillColor || n.color, i.opacity = n.fillOpacity) : i && (o.removeChild(i), t._fill = null);
        },
        _updateCircle: function(t) {
          var e = t._point.round(), i = Math.round(t._radius), n = Math.round(t._radiusY || i);
          this._setPath(t, t._empty() ? "M0 0" : "AL " + e.x + "," + e.y + " " + i + "," + n + " 0," + 65535 * 360);
        },
        _setPath: function(t, e) {
          t._path.v = e;
        },
        _bringToFront: function(t) {
          Zt(t._container);
        },
        _bringToBack: function(t) {
          It(t._container);
        }
      }, Se = x.vml ? ie : Ci, ne = vt.extend({
        _initContainer: function() {
          this._container = Se("svg"), this._container.setAttribute("pointer-events", "none"), this._rootGroup = Se("g"), this._container.appendChild(this._rootGroup);
        },
        _destroyContainer: function() {
          R(this._container), B(this._container), delete this._container, delete this._rootGroup, delete this._svgSize;
        },
        _update: function() {
          if (!(this._map._animatingZoom && this._bounds)) {
            vt.prototype._update.call(this);
            var t = this._bounds, e = t.getSize(), i = this._container;
            (!this._svgSize || !this._svgSize.equals(e)) && (this._svgSize = e, i.setAttribute("width", e.x), i.setAttribute("height", e.y)), W(i, t.min), i.setAttribute("viewBox", [
              t.min.x,
              t.min.y,
              e.x,
              e.y
            ].join(" ")), this.fire("update");
          }
        },
        _initPath: function(t) {
          var e = t._path = Se("path");
          t.options.className && C(e, t.options.className), t.options.interactive && C(e, "leaflet-interactive"), this._updateStyle(t), this._layers[_(t)] = t;
        },
        _addPath: function(t) {
          this._rootGroup || this._initContainer(), this._rootGroup.appendChild(t._path), t.addInteractiveTarget(t._path);
        },
        _removePath: function(t) {
          R(t._path), t.removeInteractiveTarget(t._path), delete this._layers[_(t)];
        },
        _updatePath: function(t) {
          t._project(), t._update();
        },
        _updateStyle: function(t) {
          var e = t._path, i = t.options;
          e && (i.stroke ? (e.setAttribute("stroke", i.color), e.setAttribute("stroke-opacity", i.opacity), e.setAttribute("stroke-width", i.weight), e.setAttribute("stroke-linecap", i.lineCap), e.setAttribute("stroke-linejoin", i.lineJoin), i.dashArray ? e.setAttribute("stroke-dasharray", i.dashArray) : e.removeAttribute("stroke-dasharray"), i.dashOffset ? e.setAttribute("stroke-dashoffset", i.dashOffset) : e.removeAttribute("stroke-dashoffset")) : e.setAttribute("stroke", "none"), i.fill ? (e.setAttribute("fill", i.fillColor || i.color), e.setAttribute("fill-opacity", i.fillOpacity), e.setAttribute("fill-rule", i.fillRule || "evenodd")) : e.setAttribute("fill", "none"));
        },
        _updatePoly: function(t, e) {
          this._setPath(t, ki(t._parts, e));
        },
        _updateCircle: function(t) {
          var e = t._point, i = Math.max(Math.round(t._radius), 1), n = Math.max(Math.round(t._radiusY), 1) || i, o = "a" + i + "," + n + " 0 1,0 ", a = t._empty() ? "M0 0" : "M" + (e.x - i) + "," + e.y + o + i * 2 + ",0 " + o + -i * 2 + ",0 ";
          this._setPath(t, a);
        },
        _setPath: function(t, e) {
          t._path.setAttribute("d", e);
        },
        _bringToFront: function(t) {
          Zt(t._path);
        },
        _bringToBack: function(t) {
          It(t._path);
        }
      });
      x.vml && ne.include(ca);
      function Mn(t) {
        return x.svg || x.vml ? new ne(t) : null;
      }
      z.include({
        getRenderer: function(t) {
          var e = t.options.renderer || this._getPaneRenderer(t.options.pane) || this.options.renderer || this._renderer;
          return e || (e = this._renderer = this._createRenderer()), this.hasLayer(e) || this.addLayer(e), e;
        },
        _getPaneRenderer: function(t) {
          if (t === "overlayPane" || t === void 0) return false;
          var e = this._paneRenderers[t];
          return e === void 0 && (e = this._createRenderer({
            pane: t
          }), this._paneRenderers[t] = e), e;
        },
        _createRenderer: function(t) {
          return this.options.preferCanvas && Tn(t) || Mn(t);
        }
      });
      var Sn = Nt.extend({
        initialize: function(t, e) {
          Nt.prototype.initialize.call(this, this._boundsToLatLngs(t), e);
        },
        setBounds: function(t) {
          return this.setLatLngs(this._boundsToLatLngs(t));
        },
        _boundsToLatLngs: function(t) {
          return t = F(t), [
            t.getSouthWest(),
            t.getNorthWest(),
            t.getNorthEast(),
            t.getSouthEast()
          ];
        }
      });
      function da(t, e) {
        return new Sn(t, e);
      }
      ne.create = Se, ne.pointsToPath = ki, gt.geometryToLayer = xe, gt.coordsToLatLng = fi, gt.coordsToLatLngs = be, gt.latLngToCoords = pi, gt.latLngsToCoords = we, gt.getFeature = Rt, gt.asFeature = Pe, z.mergeOptions({
        boxZoom: true
      });
      var Cn = lt.extend({
        initialize: function(t) {
          this._map = t, this._container = t._container, this._pane = t._panes.overlayPane, this._resetStateTimeout = 0, t.on("unload", this._destroy, this);
        },
        addHooks: function() {
          S(this._container, "mousedown", this._onMouseDown, this);
        },
        removeHooks: function() {
          B(this._container, "mousedown", this._onMouseDown, this);
        },
        moved: function() {
          return this._moved;
        },
        _destroy: function() {
          R(this._pane), delete this._pane;
        },
        _resetState: function() {
          this._resetStateTimeout = 0, this._moved = false;
        },
        _clearDeferredResetState: function() {
          this._resetStateTimeout !== 0 && (clearTimeout(this._resetStateTimeout), this._resetStateTimeout = 0);
        },
        _onMouseDown: function(t) {
          if (!t.shiftKey || t.which !== 1 && t.button !== 1) return false;
          this._clearDeferredResetState(), this._resetState(), qt(), Ye(), this._startPoint = this._map.mouseEventToContainerPoint(t), S(document, {
            contextmenu: Ct,
            mousemove: this._onMouseMove,
            mouseup: this._onMouseUp,
            keydown: this._onKeyDown
          }, this);
        },
        _onMouseMove: function(t) {
          this._moved || (this._moved = true, this._box = A("div", "leaflet-zoom-box", this._container), C(this._container, "leaflet-crosshair"), this._map.fire("boxzoomstart")), this._point = this._map.mouseEventToContainerPoint(t);
          var e = new N(this._point, this._startPoint), i = e.getSize();
          W(this._box, e.min), this._box.style.width = i.x + "px", this._box.style.height = i.y + "px";
        },
        _finish: function() {
          this._moved && (R(this._box), H(this._container, "leaflet-crosshair")), Jt(), Xe(), B(document, {
            contextmenu: Ct,
            mousemove: this._onMouseMove,
            mouseup: this._onMouseUp,
            keydown: this._onKeyDown
          }, this);
        },
        _onMouseUp: function(t) {
          if (!(t.which !== 1 && t.button !== 1) && (this._finish(), !!this._moved)) {
            this._clearDeferredResetState(), this._resetStateTimeout = setTimeout(g(this._resetState, this), 0);
            var e = new Y(this._map.containerPointToLatLng(this._startPoint), this._map.containerPointToLatLng(this._point));
            this._map.fitBounds(e).fire("boxzoomend", {
              boxZoomBounds: e
            });
          }
        },
        _onKeyDown: function(t) {
          t.keyCode === 27 && (this._finish(), this._clearDeferredResetState(), this._resetState());
        }
      });
      z.addInitHook("addHandler", "boxZoom", Cn), z.mergeOptions({
        doubleClickZoom: true
      });
      var kn = lt.extend({
        addHooks: function() {
          this._map.on("dblclick", this._onDoubleClick, this);
        },
        removeHooks: function() {
          this._map.off("dblclick", this._onDoubleClick, this);
        },
        _onDoubleClick: function(t) {
          var e = this._map, i = e.getZoom(), n = e.options.zoomDelta, o = t.originalEvent.shiftKey ? i - n : i + n;
          e.options.doubleClickZoom === "center" ? e.setZoom(o) : e.setZoomAround(t.containerPoint, o);
        }
      });
      z.addInitHook("addHandler", "doubleClickZoom", kn), z.mergeOptions({
        dragging: true,
        inertia: true,
        inertiaDeceleration: 3400,
        inertiaMaxSpeed: 1 / 0,
        easeLinearity: 0.2,
        worldCopyJump: false,
        maxBoundsViscosity: 0
      });
      var On = lt.extend({
        addHooks: function() {
          if (!this._draggable) {
            var t = this._map;
            this._draggable = new wt(t._mapPane, t._container), this._draggable.on({
              dragstart: this._onDragStart,
              drag: this._onDrag,
              dragend: this._onDragEnd
            }, this), this._draggable.on("predrag", this._onPreDragLimit, this), t.options.worldCopyJump && (this._draggable.on("predrag", this._onPreDragWrap, this), t.on("zoomend", this._onZoomEnd, this), t.whenReady(this._onZoomEnd, this));
          }
          C(this._map._container, "leaflet-grab leaflet-touch-drag"), this._draggable.enable(), this._positions = [], this._times = [];
        },
        removeHooks: function() {
          H(this._map._container, "leaflet-grab"), H(this._map._container, "leaflet-touch-drag"), this._draggable.disable();
        },
        moved: function() {
          return this._draggable && this._draggable._moved;
        },
        moving: function() {
          return this._draggable && this._draggable._moving;
        },
        _onDragStart: function() {
          var t = this._map;
          if (t._stop(), this._map.options.maxBounds && this._map.options.maxBoundsViscosity) {
            var e = F(this._map.options.maxBounds);
            this._offsetLimit = J(this._map.latLngToContainerPoint(e.getNorthWest()).multiplyBy(-1), this._map.latLngToContainerPoint(e.getSouthEast()).multiplyBy(-1).add(this._map.getSize())), this._viscosity = Math.min(1, Math.max(0, this._map.options.maxBoundsViscosity));
          } else this._offsetLimit = null;
          t.fire("movestart").fire("dragstart"), t.options.inertia && (this._positions = [], this._times = []);
        },
        _onDrag: function(t) {
          if (this._map.options.inertia) {
            var e = this._lastTime = +/* @__PURE__ */ new Date(), i = this._lastPos = this._draggable._absPos || this._draggable._newPos;
            this._positions.push(i), this._times.push(e), this._prunePositions(e);
          }
          this._map.fire("move", t).fire("drag", t);
        },
        _prunePositions: function(t) {
          for (; this._positions.length > 1 && t - this._times[0] > 50; ) this._positions.shift(), this._times.shift();
        },
        _onZoomEnd: function() {
          var t = this._map.getSize().divideBy(2), e = this._map.latLngToLayerPoint([
            0,
            0
          ]);
          this._initialWorldOffset = e.subtract(t).x, this._worldWidth = this._map.getPixelWorldBounds().getSize().x;
        },
        _viscousLimit: function(t, e) {
          return t - (t - e) * this._viscosity;
        },
        _onPreDragLimit: function() {
          if (!(!this._viscosity || !this._offsetLimit)) {
            var t = this._draggable._newPos.subtract(this._draggable._startPos), e = this._offsetLimit;
            t.x < e.min.x && (t.x = this._viscousLimit(t.x, e.min.x)), t.y < e.min.y && (t.y = this._viscousLimit(t.y, e.min.y)), t.x > e.max.x && (t.x = this._viscousLimit(t.x, e.max.x)), t.y > e.max.y && (t.y = this._viscousLimit(t.y, e.max.y)), this._draggable._newPos = this._draggable._startPos.add(t);
          }
        },
        _onPreDragWrap: function() {
          var t = this._worldWidth, e = Math.round(t / 2), i = this._initialWorldOffset, n = this._draggable._newPos.x, o = (n - e + i) % t + e - i, a = (n + e + i) % t - e - i, r = Math.abs(o + i) < Math.abs(a + i) ? o : a;
          this._draggable._absPos = this._draggable._newPos.clone(), this._draggable._newPos.x = r;
        },
        _onDragEnd: function(t) {
          var e = this._map, i = e.options, n = !i.inertia || t.noInertia || this._times.length < 2;
          if (e.fire("dragend", t), n) e.fire("moveend");
          else {
            this._prunePositions(+/* @__PURE__ */ new Date());
            var o = this._lastPos.subtract(this._positions[0]), a = (this._lastTime - this._times[0]) / 1e3, r = i.easeLinearity, h = o.multiplyBy(r / a), u = h.distanceTo([
              0,
              0
            ]), p = Math.min(i.inertiaMaxSpeed, u), y = h.multiplyBy(p / u), w = p / (i.inertiaDeceleration * r), k = y.multiplyBy(-w / 2).round();
            !k.x && !k.y ? e.fire("moveend") : (k = e._limitOffset(k, e.options.maxBounds), q(function() {
              e.panBy(k, {
                duration: w,
                easeLinearity: r,
                noMoveStart: true,
                animate: true
              });
            }));
          }
        }
      });
      z.addInitHook("addHandler", "dragging", On), z.mergeOptions({
        keyboard: true,
        keyboardPanDelta: 80
      });
      var zn = lt.extend({
        keyCodes: {
          left: [
            37
          ],
          right: [
            39
          ],
          down: [
            40
          ],
          up: [
            38
          ],
          zoomIn: [
            187,
            107,
            61,
            171
          ],
          zoomOut: [
            189,
            109,
            54,
            173
          ]
        },
        initialize: function(t) {
          this._map = t, this._setPanDelta(t.options.keyboardPanDelta), this._setZoomDelta(t.options.zoomDelta);
        },
        addHooks: function() {
          var t = this._map._container;
          t.tabIndex <= 0 && (t.tabIndex = "0"), S(t, {
            focus: this._onFocus,
            blur: this._onBlur,
            mousedown: this._onMouseDown
          }, this), this._map.on({
            focus: this._addHooks,
            blur: this._removeHooks
          }, this);
        },
        removeHooks: function() {
          this._removeHooks(), B(this._map._container, {
            focus: this._onFocus,
            blur: this._onBlur,
            mousedown: this._onMouseDown
          }, this), this._map.off({
            focus: this._addHooks,
            blur: this._removeHooks
          }, this);
        },
        _onMouseDown: function() {
          if (!this._focused) {
            var t = document.body, e = document.documentElement, i = t.scrollTop || e.scrollTop, n = t.scrollLeft || e.scrollLeft;
            this._map._container.focus(), window.scrollTo(n, i);
          }
        },
        _onFocus: function() {
          this._focused = true, this._map.fire("focus");
        },
        _onBlur: function() {
          this._focused = false, this._map.fire("blur");
        },
        _setPanDelta: function(t) {
          var e = this._panKeys = {}, i = this.keyCodes, n, o;
          for (n = 0, o = i.left.length; n < o; n++) e[i.left[n]] = [
            -1 * t,
            0
          ];
          for (n = 0, o = i.right.length; n < o; n++) e[i.right[n]] = [
            t,
            0
          ];
          for (n = 0, o = i.down.length; n < o; n++) e[i.down[n]] = [
            0,
            t
          ];
          for (n = 0, o = i.up.length; n < o; n++) e[i.up[n]] = [
            0,
            -1 * t
          ];
        },
        _setZoomDelta: function(t) {
          var e = this._zoomKeys = {}, i = this.keyCodes, n, o;
          for (n = 0, o = i.zoomIn.length; n < o; n++) e[i.zoomIn[n]] = t;
          for (n = 0, o = i.zoomOut.length; n < o; n++) e[i.zoomOut[n]] = -t;
        },
        _addHooks: function() {
          S(document, "keydown", this._onKeyDown, this);
        },
        _removeHooks: function() {
          B(document, "keydown", this._onKeyDown, this);
        },
        _onKeyDown: function(t) {
          if (!(t.altKey || t.ctrlKey || t.metaKey)) {
            var e = t.keyCode, i = this._map, n;
            if (e in this._panKeys) {
              if (!i._panAnim || !i._panAnim._inProgress) if (n = this._panKeys[e], t.shiftKey && (n = P(n).multiplyBy(3)), i.options.maxBounds && (n = i._limitOffset(P(n), i.options.maxBounds)), i.options.worldCopyJump) {
                var o = i.wrapLatLng(i.unproject(i.project(i.getCenter()).add(n)));
                i.panTo(o);
              } else i.panBy(n);
            } else if (e in this._zoomKeys) i.setZoom(i.getZoom() + (t.shiftKey ? 3 : 1) * this._zoomKeys[e]);
            else if (e === 27 && i._popup && i._popup.options.closeOnEscapeKey) i.closePopup();
            else return;
            Ct(t);
          }
        }
      });
      z.addInitHook("addHandler", "keyboard", zn), z.mergeOptions({
        scrollWheelZoom: true,
        wheelDebounceTime: 40,
        wheelPxPerZoomLevel: 60
      });
      var En = lt.extend({
        addHooks: function() {
          S(this._map._container, "wheel", this._onWheelScroll, this), this._delta = 0;
        },
        removeHooks: function() {
          B(this._map._container, "wheel", this._onWheelScroll, this);
        },
        _onWheelScroll: function(t) {
          var e = en(t), i = this._map.options.wheelDebounceTime;
          this._delta += e, this._lastMousePos = this._map.mouseEventToContainerPoint(t), this._startTime || (this._startTime = +/* @__PURE__ */ new Date());
          var n = Math.max(i - (+/* @__PURE__ */ new Date() - this._startTime), 0);
          clearTimeout(this._timer), this._timer = setTimeout(g(this._performZoom, this), n), Ct(t);
        },
        _performZoom: function() {
          var t = this._map, e = t.getZoom(), i = this._map.options.zoomSnap || 0;
          t._stop();
          var n = this._delta / (this._map.options.wheelPxPerZoomLevel * 4), o = 4 * Math.log(2 / (1 + Math.exp(-Math.abs(n)))) / Math.LN2, a = i ? Math.ceil(o / i) * i : o, r = t._limitZoom(e + (this._delta > 0 ? a : -a)) - e;
          this._delta = 0, this._startTime = null, r && (t.options.scrollWheelZoom === "center" ? t.setZoom(e + r) : t.setZoomAround(this._lastMousePos, e + r));
        }
      });
      z.addInitHook("addHandler", "scrollWheelZoom", En);
      var fa = 600;
      z.mergeOptions({
        tapHold: x.touchNative && x.safari && x.mobile,
        tapTolerance: 15
      });
      var An = lt.extend({
        addHooks: function() {
          S(this._map._container, "touchstart", this._onDown, this);
        },
        removeHooks: function() {
          B(this._map._container, "touchstart", this._onDown, this);
        },
        _onDown: function(t) {
          if (clearTimeout(this._holdTimeout), t.touches.length === 1) {
            var e = t.touches[0];
            this._startPos = this._newPos = new M(e.clientX, e.clientY), this._holdTimeout = setTimeout(g(function() {
              this._cancel(), this._isTapValid() && (S(document, "touchend", G), S(document, "touchend touchcancel", this._cancelClickPrevent), this._simulateEvent("contextmenu", e));
            }, this), fa), S(document, "touchend touchcancel contextmenu", this._cancel, this), S(document, "touchmove", this._onMove, this);
          }
        },
        _cancelClickPrevent: function t() {
          B(document, "touchend", G), B(document, "touchend touchcancel", t);
        },
        _cancel: function() {
          clearTimeout(this._holdTimeout), B(document, "touchend touchcancel contextmenu", this._cancel, this), B(document, "touchmove", this._onMove, this);
        },
        _onMove: function(t) {
          var e = t.touches[0];
          this._newPos = new M(e.clientX, e.clientY);
        },
        _isTapValid: function() {
          return this._newPos.distanceTo(this._startPos) <= this._map.options.tapTolerance;
        },
        _simulateEvent: function(t, e) {
          var i = new MouseEvent(t, {
            bubbles: true,
            cancelable: true,
            view: window,
            screenX: e.screenX,
            screenY: e.screenY,
            clientX: e.clientX,
            clientY: e.clientY
          });
          i._simulated = true, e.target.dispatchEvent(i);
        }
      });
      z.addInitHook("addHandler", "tapHold", An), z.mergeOptions({
        touchZoom: x.touch,
        bounceAtZoomLimits: true
      });
      var Zn = lt.extend({
        addHooks: function() {
          C(this._map._container, "leaflet-touch-zoom"), S(this._map._container, "touchstart", this._onTouchStart, this);
        },
        removeHooks: function() {
          H(this._map._container, "leaflet-touch-zoom"), B(this._map._container, "touchstart", this._onTouchStart, this);
        },
        _onTouchStart: function(t) {
          var e = this._map;
          if (!(!t.touches || t.touches.length !== 2 || e._animatingZoom || this._zooming)) {
            var i = e.mouseEventToContainerPoint(t.touches[0]), n = e.mouseEventToContainerPoint(t.touches[1]);
            this._centerPoint = e.getSize()._divideBy(2), this._startLatLng = e.containerPointToLatLng(this._centerPoint), e.options.touchZoom !== "center" && (this._pinchStartLatLng = e.containerPointToLatLng(i.add(n)._divideBy(2))), this._startDist = i.distanceTo(n), this._startZoom = e.getZoom(), this._moved = false, this._zooming = true, e._stop(), S(document, "touchmove", this._onTouchMove, this), S(document, "touchend touchcancel", this._onTouchEnd, this), G(t);
          }
        },
        _onTouchMove: function(t) {
          if (!(!t.touches || t.touches.length !== 2 || !this._zooming)) {
            var e = this._map, i = e.mouseEventToContainerPoint(t.touches[0]), n = e.mouseEventToContainerPoint(t.touches[1]), o = i.distanceTo(n) / this._startDist;
            if (this._zoom = e.getScaleZoom(o, this._startZoom), !e.options.bounceAtZoomLimits && (this._zoom < e.getMinZoom() && o < 1 || this._zoom > e.getMaxZoom() && o > 1) && (this._zoom = e._limitZoom(this._zoom)), e.options.touchZoom === "center") {
              if (this._center = this._startLatLng, o === 1) return;
            } else {
              var a = i._add(n)._divideBy(2)._subtract(this._centerPoint);
              if (o === 1 && a.x === 0 && a.y === 0) return;
              this._center = e.unproject(e.project(this._pinchStartLatLng, this._zoom).subtract(a), this._zoom);
            }
            this._moved || (e._moveStart(true, false), this._moved = true), $(this._animRequest);
            var r = g(e._move, e, this._center, this._zoom, {
              pinch: true,
              round: false
            }, void 0);
            this._animRequest = q(r, this, true), G(t);
          }
        },
        _onTouchEnd: function() {
          if (!this._moved || !this._zooming) {
            this._zooming = false;
            return;
          }
          this._zooming = false, $(this._animRequest), B(document, "touchmove", this._onTouchMove, this), B(document, "touchend touchcancel", this._onTouchEnd, this), this._map.options.zoomAnimation ? this._map._animateZoom(this._center, this._map._limitZoom(this._zoom), true, this._map.options.zoomSnap) : this._map._resetView(this._center, this._map._limitZoom(this._zoom));
        }
      });
      z.addInitHook("addHandler", "touchZoom", Zn), z.BoxZoom = Cn, z.DoubleClickZoom = kn, z.Drag = On, z.Keyboard = zn, z.ScrollWheelZoom = En, z.TapHold = An, z.TouchZoom = Zn, s.Bounds = N, s.Browser = x, s.CRS = pt, s.Canvas = Ln, s.Circle = di, s.CircleMarker = ye, s.Class = ft, s.Control = at, s.DivIcon = bn, s.DivOverlay = ut, s.DomEvent = zo, s.DomUtil = ko, s.Draggable = wt, s.Evented = Ut, s.FeatureGroup = mt, s.GeoJSON = gt, s.GridLayer = ee, s.Handler = lt, s.Icon = Dt, s.ImageOverlay = Le, s.LatLng = Z, s.LatLngBounds = Y, s.Layer = rt, s.LayerGroup = Bt, s.LineUtil = jo, s.Map = z, s.Marker = ve, s.Mixin = No, s.Path = Pt, s.Point = M, s.PolyUtil = Ro, s.Polygon = Nt, s.Polyline = _t, s.Popup = Te, s.PosAnimation = nn, s.Projection = Go, s.Rectangle = Sn, s.Renderer = vt, s.SVG = ne, s.SVGOverlay = xn, s.TileLayer = Ht, s.Tooltip = Me, s.Transformation = Ne, s.Util = Yn, s.VideoOverlay = yn, s.bind = g, s.bounds = J, s.canvas = Tn, s.circle = $o, s.circleMarker = Qo, s.control = Qt, s.divIcon = ha, s.extend = f, s.featureGroup = Jo, s.geoJSON = vn, s.geoJson = ia, s.gridLayer = la, s.icon = Yo, s.imageOverlay = na, s.latLng = O, s.latLngBounds = F, s.layerGroup = qo, s.map = Eo, s.marker = Xo, s.point = P, s.polygon = ea, s.polyline = ta, s.popup = ra, s.rectangle = da, s.setOptions = I, s.stamp = _, s.svg = Mn, s.svgOverlay = aa, s.tileLayer = wn, s.tooltip = sa, s.transformation = jt, s.version = d, s.videoOverlay = oa;
      var pa = window.L;
      s.noConflict = function() {
        return window.L = pa, this;
      }, window.L = s;
    }));
  })(Oe, Oe.exports);
  var xt = Oe.exports;
  const yt = Ma(xt), Ia = Aa({
    __proto__: null,
    default: yt
  }, [
    xt
  ]);
  var oe = {
    exports: {}
  };
  (function(c, l) {
    typeof define == "function" && define.amd ? define([
      "leaflet"
    ], l) : typeof modules == "object" && oe.exports ? oe.exports = l(yt || Ia) : l(L);
  })(void 0, (c) => (c.TileLayer.Provider = c.TileLayer.extend({
    initialize(l, s) {
      const d = c.TileLayer.Provider.providers, f = l.split("."), m = f[0], g = f[1];
      if (!d[m]) throw new Error(`No such provider (${m})`);
      let v = {
        url: d[m].url,
        options: d[m].options
      };
      if (g && "variants" in d[m]) {
        if (!(g in d[m].variants)) throw new Error(`No such variant of ${m} (${g})`);
        const b = d[m].variants[g];
        let T;
        typeof b == "string" ? T = {
          variant: b
        } : T = b.options, v = {
          url: b.url || v.url,
          options: c.Util.extend({}, v.options, T)
        };
      }
      const _ = (b) => b.includes("{attribution.") ? b.replace(/\{attribution.(\w*)}/g, (T, K) => _(d[K].options.attribution)) : b;
      v.options.attribution = _(v.options.attribution);
      const E = c.Util.extend({}, v.options, s);
      c.TileLayer.prototype.initialize.call(this, v.url, E);
    }
  }), c.TileLayer.Provider.providers = {
    OpenStreetMap: {
      url: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
      options: {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      },
      variants: {
        Mapnik: {},
        DE: {
          url: "https://{s}.tile.openstreetmap.de/{z}/{x}/{y}.png",
          options: {
            maxZoom: 18
          }
        },
        CH: {
          url: "https://tile.osm.ch/switzerland/{z}/{x}/{y}.png",
          options: {
            maxZoom: 18,
            bounds: [
              [
                45,
                5
              ],
              [
                48,
                11
              ]
            ]
          }
        },
        France: {
          url: "https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png",
          options: {
            maxZoom: 20,
            attribution: "&copy; OpenStreetMap France | {attribution.OpenStreetMap}"
          }
        },
        HOT: {
          url: "https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png",
          options: {
            attribution: '{attribution.OpenStreetMap}, Tiles style by <a href="https://www.hotosm.org/" target="_blank">Humanitarian OpenStreetMap Team</a> hosted by <a href="https://openstreetmap.fr/" target="_blank">OpenStreetMap France</a>'
          }
        },
        BZH: {
          url: "https://tile.openstreetmap.bzh/br/{z}/{x}/{y}.png",
          options: {
            attribution: '{attribution.OpenStreetMap}, Tiles courtesy of <a href="http://www.openstreetmap.bzh/" target="_blank">Breton OpenStreetMap Team</a>',
            bounds: [
              [
                46.2,
                -5.5
              ],
              [
                50,
                0.7
              ]
            ]
          }
        }
      }
    },
    MapTilesAPI: {
      url: "https://maptiles.p.rapidapi.com/{variant}/{z}/{x}/{y}.png?rapidapi-key={apikey}",
      options: {
        attribution: '&copy; <a href="http://www.maptilesapi.com/">MapTiles API</a>, {attribution.OpenStreetMap}',
        variant: "en/map/v1",
        apikey: "<insert your api key here>",
        maxZoom: 19
      },
      variants: {
        OSMEnglish: {
          options: {
            variant: "en/map/v1"
          }
        },
        OSMFrancais: {
          options: {
            variant: "fr/map/v1"
          }
        },
        OSMEspagnol: {
          options: {
            variant: "es/map/v1"
          }
        }
      }
    },
    OpenSeaMap: {
      url: "https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png",
      options: {
        attribution: 'Map data: &copy; <a href="http://www.openseamap.org">OpenSeaMap</a> contributors'
      }
    },
    OPNVKarte: {
      url: "https://tileserver.memomaps.de/tilegen/{z}/{x}/{y}.png",
      options: {
        maxZoom: 18,
        attribution: 'Map <a href="https://memomaps.de/">memomaps.de</a> <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, map data {attribution.OpenStreetMap}'
      }
    },
    OpenTopoMap: {
      url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
      options: {
        maxZoom: 17,
        attribution: 'Map data: {attribution.OpenStreetMap}, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
      }
    },
    OpenRailwayMap: {
      url: "https://{s}.tiles.openrailwaymap.org/standard/{z}/{x}/{y}.png",
      options: {
        maxZoom: 19,
        attribution: 'Map data: {attribution.OpenStreetMap} | Map style: &copy; <a href="https://www.OpenRailwayMap.org">OpenRailwayMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
      }
    },
    OpenFireMap: {
      url: "http://openfiremap.org/hytiles/{z}/{x}/{y}.png",
      options: {
        maxZoom: 19,
        attribution: 'Map data: {attribution.OpenStreetMap} | Map style: &copy; <a href="http://www.openfiremap.org">OpenFireMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
      }
    },
    SafeCast: {
      url: "https://s3.amazonaws.com/te512.safecast.org/{z}/{x}/{y}.png",
      options: {
        maxZoom: 16,
        attribution: 'Map data: {attribution.OpenStreetMap} | Map style: &copy; <a href="https://blog.safecast.org/about/">SafeCast</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
      }
    },
    Stadia: {
      url: "https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png",
      options: {
        maxZoom: 20,
        attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
      },
      variants: {
        AlidadeSmooth: {
          url: "https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png"
        },
        AlidadeSmoothDark: {
          url: "https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png"
        },
        OSMBright: {
          url: "https://tiles.stadiamaps.com/tiles/osm_bright/{z}/{x}/{y}{r}.png"
        },
        Outdoors: {
          url: "https://tiles.stadiamaps.com/tiles/outdoors/{z}/{x}/{y}{r}.png"
        }
      }
    },
    Thunderforest: {
      url: "https://{s}.tile.thunderforest.com/{variant}/{z}/{x}/{y}.png?apikey={apikey}",
      options: {
        attribution: '&copy; <a href="http://www.thunderforest.com/">Thunderforest</a>, {attribution.OpenStreetMap}',
        variant: "cycle",
        apikey: "<insert your api key here>",
        maxZoom: 22
      },
      variants: {
        OpenCycleMap: "cycle",
        Transport: {
          options: {
            variant: "transport"
          }
        },
        TransportDark: {
          options: {
            variant: "transport-dark"
          }
        },
        SpinalMap: {
          options: {
            variant: "spinal-map"
          }
        },
        Landscape: "landscape",
        Outdoors: "outdoors",
        Pioneer: "pioneer",
        MobileAtlas: "mobile-atlas",
        Neighbourhood: "neighbourhood"
      }
    },
    CyclOSM: {
      url: "https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png",
      options: {
        maxZoom: 20,
        attribution: '<a href="https://github.com/cyclosm/cyclosm-cartocss-style/releases" title="CyclOSM - Open Bicycle render">CyclOSM</a> | Map data: {attribution.OpenStreetMap}'
      }
    },
    Jawg: {
      url: "https://{s}.tile.jawg.io/{variant}/{z}/{x}/{y}{r}.png?access-token={accessToken}",
      options: {
        attribution: '<a href="http://jawg.io" title="Tiles Courtesy of Jawg Maps" target="_blank">&copy; <b>Jawg</b>Maps</a> {attribution.OpenStreetMap}',
        minZoom: 0,
        maxZoom: 22,
        subdomains: "abcd",
        variant: "jawg-terrain",
        accessToken: "<insert your access token here>"
      },
      variants: {
        Streets: "jawg-streets",
        Terrain: "jawg-terrain",
        Sunny: "jawg-sunny",
        Dark: "jawg-dark",
        Light: "jawg-light",
        Matrix: "jawg-matrix"
      }
    },
    MapBox: {
      url: "https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}{r}?access_token={accessToken}",
      options: {
        attribution: '&copy; <a href="https://www.mapbox.com/about/maps/" target="_blank">Mapbox</a> {attribution.OpenStreetMap} <a href="https://www.mapbox.com/map-feedback/" target="_blank">Improve this map</a>',
        tileSize: 512,
        maxZoom: 18,
        zoomOffset: -1,
        id: "mapbox/streets-v11",
        accessToken: "<insert your access token here>"
      }
    },
    MapTiler: {
      url: "https://api.maptiler.com/maps/{variant}/{z}/{x}/{y}{r}.{ext}?key={key}",
      options: {
        attribution: '<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> <a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>',
        variant: "streets",
        ext: "png",
        key: "<insert your MapTiler Cloud API key here>",
        tileSize: 512,
        zoomOffset: -1,
        minZoom: 0,
        maxZoom: 21
      },
      variants: {
        Streets: "streets",
        Basic: "basic",
        Bright: "bright",
        Pastel: "pastel",
        Positron: "positron",
        Hybrid: {
          options: {
            variant: "hybrid",
            ext: "jpg"
          }
        },
        Toner: "toner",
        Topo: "topo",
        Voyager: "voyager"
      }
    },
    Stamen: {
      url: "https://stamen-tiles-{s}.a.ssl.fastly.net/{variant}/{z}/{x}/{y}{r}.{ext}",
      options: {
        attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data {attribution.OpenStreetMap}',
        subdomains: "abcd",
        minZoom: 0,
        maxZoom: 20,
        variant: "toner",
        ext: "png"
      },
      variants: {
        Toner: "toner",
        TonerBackground: "toner-background",
        TonerHybrid: "toner-hybrid",
        TonerLines: "toner-lines",
        TonerLabels: "toner-labels",
        TonerLite: "toner-lite",
        Watercolor: {
          url: "https://stamen-tiles-{s}.a.ssl.fastly.net/{variant}/{z}/{x}/{y}.{ext}",
          options: {
            variant: "watercolor",
            ext: "jpg",
            minZoom: 1,
            maxZoom: 16
          }
        },
        Terrain: {
          options: {
            variant: "terrain",
            minZoom: 0,
            maxZoom: 18
          }
        },
        TerrainBackground: {
          options: {
            variant: "terrain-background",
            minZoom: 0,
            maxZoom: 18
          }
        },
        TerrainLabels: {
          options: {
            variant: "terrain-labels",
            minZoom: 0,
            maxZoom: 18
          }
        },
        TopOSMRelief: {
          url: "https://stamen-tiles-{s}.a.ssl.fastly.net/{variant}/{z}/{x}/{y}.{ext}",
          options: {
            variant: "toposm-color-relief",
            ext: "jpg",
            bounds: [
              [
                22,
                -132
              ],
              [
                51,
                -56
              ]
            ]
          }
        },
        TopOSMFeatures: {
          options: {
            variant: "toposm-features",
            bounds: [
              [
                22,
                -132
              ],
              [
                51,
                -56
              ]
            ],
            opacity: 0.9
          }
        }
      }
    },
    TomTom: {
      url: "https://{s}.api.tomtom.com/map/1/tile/{variant}/{style}/{z}/{x}/{y}.{ext}?key={apikey}",
      options: {
        variant: "basic",
        maxZoom: 22,
        attribution: `<a href="https://tomtom.com" target="_blank">&copy;  1992 - ${(/* @__PURE__ */ new Date()).getFullYear()} TomTom.</a> `,
        subdomains: "abcd",
        style: "main",
        ext: "png",
        apikey: "<insert your API key here>"
      },
      variants: {
        Basic: "basic",
        Hybrid: "hybrid",
        Labels: "labels"
      }
    },
    Esri: {
      url: "https://server.arcgisonline.com/ArcGIS/rest/services/{variant}/MapServer/tile/{z}/{y}/{x}",
      options: {
        variant: "World_Street_Map",
        attribution: "Tiles &copy; Esri"
      },
      variants: {
        WorldStreetMap: {
          options: {
            attribution: "{attribution.Esri} &mdash; Source: Esri, DeLorme, NAVTEQ, USGS, Intermap, iPC, NRCAN, Esri Japan, METI, Esri China (Hong Kong), Esri (Thailand), TomTom, 2012"
          }
        },
        DeLorme: {
          options: {
            variant: "Specialty/DeLorme_World_Base_Map",
            minZoom: 1,
            maxZoom: 11,
            attribution: "{attribution.Esri} &mdash; Copyright: &copy;2012 DeLorme"
          }
        },
        WorldTopoMap: {
          options: {
            variant: "World_Topo_Map",
            attribution: "{attribution.Esri} &mdash; Esri, DeLorme, NAVTEQ, TomTom, Intermap, iPC, USGS, FAO, NPS, NRCAN, GeoBase, Kadaster NL, Ordnance Survey, Esri Japan, METI, Esri China (Hong Kong), and the GIS User Community"
          }
        },
        WorldImagery: {
          options: {
            variant: "World_Imagery",
            attribution: "{attribution.Esri} &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community"
          }
        },
        WorldTerrain: {
          options: {
            variant: "World_Terrain_Base",
            maxZoom: 13,
            attribution: "{attribution.Esri} &mdash; Source: USGS, Esri, TANA, DeLorme, and NPS"
          }
        },
        WorldShadedRelief: {
          options: {
            variant: "World_Shaded_Relief",
            maxZoom: 13,
            attribution: "{attribution.Esri} &mdash; Source: Esri"
          }
        },
        WorldPhysical: {
          options: {
            variant: "World_Physical_Map",
            maxZoom: 8,
            attribution: "{attribution.Esri} &mdash; Source: US National Park Service"
          }
        },
        OceanBasemap: {
          options: {
            variant: "Ocean_Basemap",
            maxZoom: 13,
            attribution: "{attribution.Esri} &mdash; Sources: GEBCO, NOAA, CHS, OSU, UNH, CSUMB, National Geographic, DeLorme, NAVTEQ, and Esri"
          }
        },
        NatGeoWorldMap: {
          options: {
            variant: "NatGeo_World_Map",
            maxZoom: 16,
            attribution: "{attribution.Esri} &mdash; National Geographic, Esri, DeLorme, NAVTEQ, UNEP-WCMC, USGS, NASA, ESA, METI, NRCAN, GEBCO, NOAA, iPC"
          }
        },
        WorldGrayCanvas: {
          options: {
            variant: "Canvas/World_Light_Gray_Base",
            maxZoom: 16,
            attribution: "{attribution.Esri} &mdash; Esri, DeLorme, NAVTEQ"
          }
        }
      }
    },
    OpenWeatherMap: {
      url: "http://{s}.tile.openweathermap.org/map/{variant}/{z}/{x}/{y}.png?appid={apiKey}",
      options: {
        maxZoom: 19,
        attribution: 'Map data &copy; <a href="http://openweathermap.org">OpenWeatherMap</a>',
        apiKey: "<insert your api key here>",
        opacity: 0.5
      },
      variants: {
        Clouds: "clouds",
        CloudsClassic: "clouds_cls",
        Precipitation: "precipitation",
        PrecipitationClassic: "precipitation_cls",
        Rain: "rain",
        RainClassic: "rain_cls",
        Pressure: "pressure",
        PressureContour: "pressure_cntr",
        Wind: "wind",
        Temperature: "temp",
        Snow: "snow"
      }
    },
    HERE: {
      url: "https://{s}.{base}.maps.api.here.com/maptile/2.1/{type}/{mapID}/{variant}/{z}/{x}/{y}/{size}/{format}?app_id={app_id}&app_code={app_code}&lg={language}",
      options: {
        attribution: `Map &copy; 1987-${(/* @__PURE__ */ new Date()).getFullYear()} <a href="http://developer.here.com">HERE</a>`,
        subdomains: "1234",
        mapID: "newest",
        app_id: "<insert your app_id here>",
        app_code: "<insert your app_code here>",
        base: "base",
        variant: "normal.day",
        maxZoom: 20,
        type: "maptile",
        language: "eng",
        format: "png8",
        size: "256"
      },
      variants: {
        normalDay: "normal.day",
        normalDayCustom: "normal.day.custom",
        normalDayGrey: "normal.day.grey",
        normalDayMobile: "normal.day.mobile",
        normalDayGreyMobile: "normal.day.grey.mobile",
        normalDayTransit: "normal.day.transit",
        normalDayTransitMobile: "normal.day.transit.mobile",
        normalDayTraffic: {
          options: {
            variant: "normal.traffic.day",
            base: "traffic",
            type: "traffictile"
          }
        },
        normalNight: "normal.night",
        normalNightMobile: "normal.night.mobile",
        normalNightGrey: "normal.night.grey",
        normalNightGreyMobile: "normal.night.grey.mobile",
        normalNightTransit: "normal.night.transit",
        normalNightTransitMobile: "normal.night.transit.mobile",
        reducedDay: "reduced.day",
        reducedNight: "reduced.night",
        basicMap: {
          options: {
            type: "basetile"
          }
        },
        mapLabels: {
          options: {
            type: "labeltile",
            format: "png"
          }
        },
        trafficFlow: {
          options: {
            base: "traffic",
            type: "flowtile"
          }
        },
        carnavDayGrey: "carnav.day.grey",
        hybridDay: {
          options: {
            base: "aerial",
            variant: "hybrid.day"
          }
        },
        hybridDayMobile: {
          options: {
            base: "aerial",
            variant: "hybrid.day.mobile"
          }
        },
        hybridDayTransit: {
          options: {
            base: "aerial",
            variant: "hybrid.day.transit"
          }
        },
        hybridDayGrey: {
          options: {
            base: "aerial",
            variant: "hybrid.grey.day"
          }
        },
        hybridDayTraffic: {
          options: {
            variant: "hybrid.traffic.day",
            base: "traffic",
            type: "traffictile"
          }
        },
        pedestrianDay: "pedestrian.day",
        pedestrianNight: "pedestrian.night",
        satelliteDay: {
          options: {
            base: "aerial",
            variant: "satellite.day"
          }
        },
        terrainDay: {
          options: {
            base: "aerial",
            variant: "terrain.day"
          }
        },
        terrainDayMobile: {
          options: {
            base: "aerial",
            variant: "terrain.day.mobile"
          }
        }
      }
    },
    HEREv3: {
      url: "https://{s}.{base}.maps.ls.hereapi.com/maptile/2.1/{type}/{mapID}/{variant}/{z}/{x}/{y}/{size}/{format}?apiKey={apiKey}&lg={language}",
      options: {
        attribution: `Map &copy; 1987-${(/* @__PURE__ */ new Date()).getFullYear()} <a href="http://developer.here.com">HERE</a>`,
        subdomains: "1234",
        mapID: "newest",
        apiKey: "<insert your apiKey here>",
        base: "base",
        variant: "normal.day",
        maxZoom: 20,
        type: "maptile",
        language: "eng",
        format: "png8",
        size: "256"
      },
      variants: {
        normalDay: "normal.day",
        normalDayCustom: "normal.day.custom",
        normalDayGrey: "normal.day.grey",
        normalDayMobile: "normal.day.mobile",
        normalDayGreyMobile: "normal.day.grey.mobile",
        normalDayTransit: "normal.day.transit",
        normalDayTransitMobile: "normal.day.transit.mobile",
        normalNight: "normal.night",
        normalNightMobile: "normal.night.mobile",
        normalNightGrey: "normal.night.grey",
        normalNightGreyMobile: "normal.night.grey.mobile",
        normalNightTransit: "normal.night.transit",
        normalNightTransitMobile: "normal.night.transit.mobile",
        reducedDay: "reduced.day",
        reducedNight: "reduced.night",
        basicMap: {
          options: {
            type: "basetile"
          }
        },
        mapLabels: {
          options: {
            type: "labeltile",
            format: "png"
          }
        },
        trafficFlow: {
          options: {
            base: "traffic",
            type: "flowtile"
          }
        },
        carnavDayGrey: "carnav.day.grey",
        hybridDay: {
          options: {
            base: "aerial",
            variant: "hybrid.day"
          }
        },
        hybridDayMobile: {
          options: {
            base: "aerial",
            variant: "hybrid.day.mobile"
          }
        },
        hybridDayTransit: {
          options: {
            base: "aerial",
            variant: "hybrid.day.transit"
          }
        },
        hybridDayGrey: {
          options: {
            base: "aerial",
            variant: "hybrid.grey.day"
          }
        },
        pedestrianDay: "pedestrian.day",
        pedestrianNight: "pedestrian.night",
        satelliteDay: {
          options: {
            base: "aerial",
            variant: "satellite.day"
          }
        },
        terrainDay: {
          options: {
            base: "aerial",
            variant: "terrain.day"
          }
        },
        terrainDayMobile: {
          options: {
            base: "aerial",
            variant: "terrain.day.mobile"
          }
        }
      }
    },
    FreeMapSK: {
      url: "https://{s}.freemap.sk/T/{z}/{x}/{y}.jpeg",
      options: {
        minZoom: 8,
        maxZoom: 16,
        subdomains: "abcd",
        bounds: [
          [
            47.204642,
            15.996093
          ],
          [
            49.830896,
            22.576904
          ]
        ],
        attribution: '{attribution.OpenStreetMap}, visualization CC-By-SA 2.0 <a href="http://freemap.sk">Freemap.sk</a>'
      }
    },
    MtbMap: {
      url: "http://tile.mtbmap.cz/mtbmap_tiles/{z}/{x}/{y}.png",
      options: {
        attribution: "{attribution.OpenStreetMap} &amp; USGS"
      }
    },
    CartoDB: {
      url: "https://{s}.basemaps.cartocdn.com/{variant}/{z}/{x}/{y}{r}.png",
      options: {
        attribution: '{attribution.OpenStreetMap} &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: "abcd",
        maxZoom: 20,
        variant: "light_all"
      },
      variants: {
        Positron: "light_all",
        PositronNoLabels: "light_nolabels",
        PositronOnlyLabels: "light_only_labels",
        DarkMatter: "dark_all",
        DarkMatterNoLabels: "dark_nolabels",
        DarkMatterOnlyLabels: "dark_only_labels",
        Voyager: "rastertiles/voyager",
        VoyagerNoLabels: "rastertiles/voyager_nolabels",
        VoyagerOnlyLabels: "rastertiles/voyager_only_labels",
        VoyagerLabelsUnder: "rastertiles/voyager_labels_under"
      }
    },
    HikeBike: {
      url: "https://tiles.wmflabs.org/{variant}/{z}/{x}/{y}.png",
      options: {
        maxZoom: 19,
        attribution: "{attribution.OpenStreetMap}",
        variant: "hikebike"
      },
      variants: {
        HikeBike: {},
        HillShading: {
          options: {
            maxZoom: 15,
            variant: "hillshading"
          }
        }
      }
    },
    BasemapAT: {
      url: "https://maps{s}.wien.gv.at/basemap/{variant}/{type}/google3857/{z}/{y}/{x}.{format}",
      options: {
        maxZoom: 19,
        attribution: 'Datenquelle: <a href="https://www.basemap.at">basemap.at</a>',
        subdomains: [
          "",
          "1",
          "2",
          "3",
          "4"
        ],
        type: "normal",
        format: "png",
        bounds: [
          [
            46.35877,
            8.782379
          ],
          [
            49.037872,
            17.189532
          ]
        ],
        variant: "geolandbasemap"
      },
      variants: {
        basemap: {
          options: {
            maxZoom: 20,
            variant: "geolandbasemap"
          }
        },
        grau: "bmapgrau",
        overlay: "bmapoverlay",
        terrain: {
          options: {
            variant: "bmapgelaende",
            type: "grau",
            format: "jpeg"
          }
        },
        surface: {
          options: {
            variant: "bmapoberflaeche",
            type: "grau",
            format: "jpeg"
          }
        },
        highdpi: {
          options: {
            variant: "bmaphidpi",
            format: "jpeg"
          }
        },
        orthofoto: {
          options: {
            maxZoom: 20,
            variant: "bmaporthofoto30cm",
            format: "jpeg"
          }
        }
      }
    },
    nlmaps: {
      url: "https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0/{variant}/EPSG:3857/{z}/{x}/{y}.png",
      options: {
        minZoom: 6,
        maxZoom: 19,
        bounds: [
          [
            50.5,
            3.25
          ],
          [
            54,
            7.6
          ]
        ],
        attribution: 'Kaartgegevens &copy; <a href="https://www.kadaster.nl">Kadaster</a>'
      },
      variants: {
        standaard: "standaard",
        pastel: "pastel",
        grijs: "grijs",
        water: "water",
        luchtfoto: {
          url: "https://service.pdok.nl/hwh/luchtfotorgb/wmts/v1_0/Actueel_ortho25/EPSG:3857/{z}/{x}/{y}.jpeg"
        }
      }
    },
    NASAGIBS: {
      url: "https://map1.vis.earthdata.nasa.gov/wmts-webmerc/{variant}/default/{time}/{tilematrixset}{maxZoom}/{z}/{y}/{x}.{format}",
      options: {
        attribution: 'Imagery provided by services from the Global Imagery Browse Services (GIBS), operated by the NASA/GSFC/Earth Science Data and Information System (<a href="https://earthdata.nasa.gov">ESDIS</a>) with funding provided by NASA/HQ.',
        bounds: [
          [
            -85.0511287776,
            -179.999999975
          ],
          [
            85.0511287776,
            179.999999975
          ]
        ],
        minZoom: 1,
        maxZoom: 9,
        format: "jpg",
        time: "",
        tilematrixset: "GoogleMapsCompatible_Level"
      },
      variants: {
        ModisTerraTrueColorCR: "MODIS_Terra_CorrectedReflectance_TrueColor",
        ModisTerraBands367CR: "MODIS_Terra_CorrectedReflectance_Bands367",
        ViirsEarthAtNight2012: {
          options: {
            variant: "VIIRS_CityLights_2012",
            maxZoom: 8
          }
        },
        ModisTerraLSTDay: {
          options: {
            variant: "MODIS_Terra_Land_Surface_Temp_Day",
            format: "png",
            maxZoom: 7,
            opacity: 0.75
          }
        },
        ModisTerraSnowCover: {
          options: {
            variant: "MODIS_Terra_NDSI_Snow_Cover",
            format: "png",
            maxZoom: 8,
            opacity: 0.75
          }
        },
        ModisTerraAOD: {
          options: {
            variant: "MODIS_Terra_Aerosol",
            format: "png",
            maxZoom: 6,
            opacity: 0.75
          }
        },
        ModisTerraChlorophyll: {
          options: {
            variant: "MODIS_Terra_Chlorophyll_A",
            format: "png",
            maxZoom: 7,
            opacity: 0.75
          }
        }
      }
    },
    NLS: {
      url: "https://nls-{s}.tileserver.com/nls/{z}/{x}/{y}.jpg",
      options: {
        attribution: '<a href="http://geo.nls.uk/maps/">National Library of Scotland Historic Maps</a>',
        bounds: [
          [
            49.6,
            -12
          ],
          [
            61.7,
            3
          ]
        ],
        minZoom: 1,
        maxZoom: 18,
        subdomains: "0123"
      }
    },
    JusticeMap: {
      url: "https://www.justicemap.org/tile/{size}/{variant}/{z}/{x}/{y}.png",
      options: {
        attribution: '<a href="http://www.justicemap.org/terms.php">Justice Map</a>',
        size: "county",
        bounds: [
          [
            14,
            -180
          ],
          [
            72,
            -56
          ]
        ]
      },
      variants: {
        income: "income",
        americanIndian: "indian",
        asian: "asian",
        black: "black",
        hispanic: "hispanic",
        multi: "multi",
        nonWhite: "nonwhite",
        white: "white",
        plurality: "plural"
      }
    },
    GeoportailFrance: {
      url: "https://wxs.ign.fr/{apikey}/geoportail/wmts?REQUEST=GetTile&SERVICE=WMTS&VERSION=1.0.0&STYLE={style}&TILEMATRIXSET=PM&FORMAT={format}&LAYER={variant}&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}",
      options: {
        attribution: '<a target="_blank" href="https://www.geoportail.gouv.fr/">Geoportail France</a>',
        bounds: [
          [
            -75,
            -180
          ],
          [
            81,
            180
          ]
        ],
        minZoom: 2,
        maxZoom: 18,
        apikey: "choisirgeoportail",
        format: "image/png",
        style: "normal",
        variant: "GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2"
      },
      variants: {
        plan: "GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2",
        parcels: {
          options: {
            variant: "CADASTRALPARCELS.PARCELLAIRE_EXPRESS",
            style: "PCI vecteur",
            maxZoom: 20
          }
        },
        orthos: {
          options: {
            maxZoom: 19,
            format: "image/jpeg",
            variant: "ORTHOIMAGERY.ORTHOPHOTOS"
          }
        }
      }
    },
    OneMapSG: {
      url: "https://maps-{s}.onemap.sg/v3/{variant}/{z}/{x}/{y}.png",
      options: {
        variant: "Default",
        minZoom: 11,
        maxZoom: 18,
        bounds: [
          [
            1.56073,
            104.11475
          ],
          [
            1.16,
            103.502
          ]
        ],
        attribution: '<img src="https://docs.onemap.sg/maps/images/oneMap64-01.png" alt="attribution" style="height:20px;width:20px;"/> New OneMap | Map data &copy; contributors, <a href="http://SLA.gov.sg">Singapore Land Authority</a>'
      },
      variants: {
        Default: "Default",
        Night: "Night",
        Original: "Original",
        Grey: "Grey",
        LandLot: "LandLot"
      }
    },
    USGS: {
      url: "https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}",
      options: {
        maxZoom: 20,
        attribution: 'Tiles courtesy of the <a href="https://usgs.gov/">U.S. Geological Survey</a>'
      },
      variants: {
        USTopo: {},
        USImagery: {
          url: "https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}"
        },
        USImageryTopo: {
          url: "https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryTopo/MapServer/tile/{z}/{y}/{x}"
        }
      }
    },
    WaymarkedTrails: {
      url: "https://tile.waymarkedtrails.org/{variant}/{z}/{x}/{y}.png",
      options: {
        maxZoom: 18,
        attribution: 'Map data: {attribution.OpenStreetMap} | Map style: &copy; <a href="https://waymarkedtrails.org">waymarkedtrails.org</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
      },
      variants: {
        hiking: "hiking",
        cycling: "cycling",
        mtb: "mtb",
        slopes: "slopes",
        riding: "riding",
        skating: "skating"
      }
    },
    OpenAIP: {
      url: "https://{s}.tile.maps.openaip.net/geowebcache/service/tms/1.0.0/openaip_basemap@EPSG%3A900913@png/{z}/{x}/{y}.{ext}",
      options: {
        attribution: '<a href="https://www.openaip.net/">openAIP Data</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-NC-SA</a>)',
        ext: "png",
        minZoom: 4,
        maxZoom: 14,
        tms: true,
        detectRetina: true,
        subdomains: "12"
      }
    },
    OpenSnowMap: {
      url: "https://tiles.opensnowmap.org/{variant}/{z}/{x}/{y}.png",
      options: {
        minZoom: 9,
        maxZoom: 18,
        attribution: 'Map data: {attribution.OpenStreetMap} & ODbL, &copy; <a href="https://www.opensnowmap.org/iframes/data.html">www.opensnowmap.org</a> <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>'
      },
      variants: {
        pistes: "pistes"
      }
    },
    AzureMaps: {
      url: "https://atlas.microsoft.com/map/tile?api-version={apiVersion}&tilesetId={variant}&x={x}&y={y}&zoom={z}&language={language}&subscription-key={subscriptionKey}",
      options: {
        attribution: "See https://docs.microsoft.com/en-us/rest/api/maps/render-v2/get-map-tile for details.",
        apiVersion: "2.0",
        variant: "microsoft.imagery",
        subscriptionKey: "<insert your subscription key here>",
        language: "en-US"
      },
      variants: {
        MicrosoftImagery: "microsoft.imagery",
        MicrosoftBaseDarkGrey: "microsoft.base.darkgrey",
        MicrosoftBaseRoad: "microsoft.base.road",
        MicrosoftBaseHybridRoad: "microsoft.base.hybrid.road",
        MicrosoftTerraMain: "microsoft.terra.main",
        MicrosoftWeatherInfraredMain: {
          url: "https://atlas.microsoft.com/map/tile?api-version={apiVersion}&tilesetId={variant}&x={x}&y={y}&zoom={z}&timeStamp={timeStamp}&language={language}&subscription-key={subscriptionKey}",
          options: {
            timeStamp: "2021-05-08T09:03:00Z",
            attribution: "See https://docs.microsoft.com/en-us/rest/api/maps/render-v2/get-map-tile#uri-parameters for details.",
            variant: "microsoft.weather.infrared.main"
          }
        },
        MicrosoftWeatherRadarMain: {
          url: "https://atlas.microsoft.com/map/tile?api-version={apiVersion}&tilesetId={variant}&x={x}&y={y}&zoom={z}&timeStamp={timeStamp}&language={language}&subscription-key={subscriptionKey}",
          options: {
            timeStamp: "2021-05-08T09:03:00Z",
            attribution: "See https://docs.microsoft.com/en-us/rest/api/maps/render-v2/get-map-tile#uri-parameters for details.",
            variant: "microsoft.weather.radar.main"
          }
        }
      }
    },
    SwissFederalGeoportal: {
      url: "https://wmts.geo.admin.ch/1.0.0/{variant}/default/current/3857/{z}/{x}/{y}.jpeg",
      options: {
        attribution: '&copy; <a href="https://www.swisstopo.admin.ch/">swisstopo</a>',
        minZoom: 2,
        maxZoom: 18,
        bounds: [
          [
            45.398181,
            5.140242
          ],
          [
            48.230651,
            11.47757
          ]
        ]
      },
      variants: {
        NationalMapColor: "ch.swisstopo.pixelkarte-farbe",
        NationalMapGrey: "ch.swisstopo.pixelkarte-grau",
        SWISSIMAGE: {
          options: {
            variant: "ch.swisstopo.swissimage",
            maxZoom: 19
          }
        }
      }
    }
  }, c.tileLayer.provider = function(l, s) {
    return new c.TileLayer.Provider(l, s);
  }, c));
  (oe.exports == null ? {} : oe.exports).default || oe.exports;
  function Fn(c, l) {
    const s = zt(l);
    ct(function() {
      l !== s.current && c.attributionControl != null && (s.current != null && c.attributionControl.removeAttribution(s.current), l != null && c.attributionControl.addAttribution(l)), s.current = l;
    }, [
      c,
      l
    ]);
  }
  function Ba(c, l, s) {
    l.center !== s.center && c.setLatLng(l.center), l.radius != null && l.radius !== s.radius && c.setRadius(l.radius);
  }
  const Da = 1;
  function Na(c) {
    return Object.freeze({
      __version: Da,
      map: c
    });
  }
  function bi(c, l) {
    return Object.freeze({
      ...c,
      ...l
    });
  }
  const Wn = La(null), Un = Wn.Provider;
  function ae() {
    const c = Pa(Wn);
    if (c == null) throw new Error("No context provided: useLeafletContext() can only be used in a descendant of <MapContainer>");
    return c;
  }
  function jn(c) {
    function l(s, d) {
      const { instance: f, context: m } = c(s).current;
      return Ee(d, () => f), s.children == null ? null : Et.createElement(Un, {
        value: m
      }, s.children);
    }
    return ze(l);
  }
  function Ra(c) {
    function l(s, d) {
      const [f, m] = vi(false), { instance: g } = c(s, m).current;
      Ee(d, () => g), ct(function() {
        f && g.update();
      }, [
        g,
        f,
        s.children
      ]);
      const v = g._contentNode;
      return v ? Ea(s.children, v) : null;
    }
    return ze(l);
  }
  function Gn(c) {
    function l(s, d) {
      const { instance: f } = c(s).current;
      return Ee(d, () => f), null;
    }
    return ze(l);
  }
  function Ha(c) {
    return function(s) {
      const d = ae(), f = c(s, d), { instance: m } = f.current, g = zt(s.position), { position: v } = s;
      return ct(function() {
        return m.addTo(d.map), function() {
          m.remove();
        };
      }, [
        d.map,
        m
      ]), ct(function() {
        v != null && v !== g.current && (m.setPosition(v), g.current = v);
      }, [
        m,
        v
      ]), f;
    };
  }
  function wi(c, l) {
    const s = zt();
    ct(function() {
      return l != null && c.instance.on(l), s.current = l, function() {
        s.current != null && c.instance.off(s.current), s.current = null;
      };
    }, [
      c,
      l
    ]);
  }
  function Ae(c, l) {
    const s = c.pane ?? l.pane;
    return s ? {
      ...c,
      pane: s
    } : c;
  }
  function Fa(c, l) {
    return function(d, f) {
      const m = ae(), g = c(Ae(d, m), m);
      return Fn(m.map, d.attribution), wi(g.current, d.eventHandlers), l(g.current, m, d, f), g;
    };
  }
  function Wt(c, l, s) {
    return Object.freeze({
      instance: c,
      context: l,
      container: s
    });
  }
  function re(c, l) {
    return l == null ? function(d, f) {
      const m = zt();
      return m.current || (m.current = c(d, f)), m;
    } : function(d, f) {
      const m = zt();
      m.current || (m.current = c(d, f));
      const g = zt(d), { instance: v } = m.current;
      return ct(function() {
        g.current !== d && (l(v, d, g.current), g.current = d);
      }, [
        v,
        d,
        f
      ]), m;
    };
  }
  function Vn(c, l) {
    ct(function() {
      return (l.layerContainer ?? l.map).addLayer(c.instance), function() {
        var _a;
        (_a = l.layerContainer) == null ? void 0 : _a.removeLayer(c.instance), l.map.removeLayer(c.instance);
      };
    }, [
      l,
      c
    ]);
  }
  function Kn(c) {
    return function(s) {
      const d = ae(), f = c(Ae(s, d), d);
      return Fn(d.map, s.attribution), wi(f.current, s.eventHandlers), Vn(f.current, d), f;
    };
  }
  function Wa(c, l) {
    const s = zt();
    ct(function() {
      if (l.pathOptions !== s.current) {
        const f = l.pathOptions ?? {};
        c.instance.setStyle(f), s.current = f;
      }
    }, [
      c,
      l
    ]);
  }
  function Ua(c) {
    return function(s) {
      const d = ae(), f = c(Ae(s, d), d);
      return wi(f.current, s.eventHandlers), Vn(f.current, d), Wa(f.current, s), f;
    };
  }
  function ja(c) {
    function l(f, m) {
      return Wt(c(f), m);
    }
    const s = re(l), d = Ha(s);
    return Gn(d);
  }
  function Ga(c, l) {
    const s = re(c, l), d = Kn(s);
    return jn(d);
  }
  function Va(c, l) {
    const s = re(c), d = Fa(s, l);
    return Ra(d);
  }
  function qn(c, l) {
    const s = re(c, l), d = Ua(s);
    return jn(d);
  }
  function Ka(c, l) {
    const s = re(c, l), d = Kn(s);
    return Gn(d);
  }
  function qa(c, l, s) {
    const { opacity: d, zIndex: f } = l;
    d != null && d !== s.opacity && c.setOpacity(d), f != null && f !== s.zIndex && c.setZIndex(f);
  }
  function Ja() {
    return ae().map;
  }
  const Ya = qn(function({ center: l, children: s, ...d }, f) {
    const m = new xt.Circle(l, d);
    return Wt(m, bi(f, {
      overlayContainer: m
    }));
  }, Ba);
  function xi() {
    return xi = Object.assign || function(c) {
      for (var l = 1; l < arguments.length; l++) {
        var s = arguments[l];
        for (var d in s) Object.prototype.hasOwnProperty.call(s, d) && (c[d] = s[d]);
      }
      return c;
    }, xi.apply(this, arguments);
  }
  function Xa({ bounds: c, boundsOptions: l, center: s, children: d, className: f, id: m, placeholder: g, style: v, whenReady: _, zoom: E, ...b }, T) {
    const [K] = vi({
      className: f,
      id: m,
      style: v
    }), [nt, dt] = vi(null);
    Ee(T, () => (nt == null ? void 0 : nt.map) ?? null, [
      nt
    ]);
    const I = Ta((he) => {
      if (he !== null && nt === null) {
        const Lt = new xt.Map(he, b);
        s != null && E != null ? Lt.setView(s, E) : c != null && Lt.fitBounds(c, l), _ != null && Lt.whenReady(_), dt(Na(Lt));
      }
    }, []);
    ct(() => () => {
      nt == null ? void 0 : nt.map.remove();
    }, [
      nt
    ]);
    const se = nt ? Et.createElement(Un, {
      value: nt
    }, d) : g ?? null;
    return Et.createElement("div", xi({}, K, {
      ref: I
    }), se);
  }
  const Qa = ze(Xa), $a = Ga(function({ position: l, ...s }, d) {
    const f = new xt.Marker(l, s);
    return Wt(f, bi(d, {
      overlayContainer: f
    }));
  }, function(l, s, d) {
    s.position !== d.position && l.setLatLng(s.position), s.icon != null && s.icon !== d.icon && l.setIcon(s.icon), s.zIndexOffset != null && s.zIndexOffset !== d.zIndexOffset && l.setZIndexOffset(s.zIndexOffset), s.opacity != null && s.opacity !== d.opacity && l.setOpacity(s.opacity), l.dragging != null && s.draggable !== d.draggable && (s.draggable === true ? l.dragging.enable() : l.dragging.disable());
  }), tr = qn(function({ positions: l, ...s }, d) {
    const f = new xt.Polyline(l, s);
    return Wt(f, bi(d, {
      overlayContainer: f
    }));
  }, function(l, s, d) {
    s.positions !== d.positions && l.setLatLngs(s.positions);
  }), er = Va(function(l, s) {
    const d = new xt.Popup(l, s.overlayContainer);
    return Wt(d, s);
  }, function(l, s, { position: d }, f) {
    ct(function() {
      const { instance: g } = l;
      function v(E) {
        E.popup === g && (g.update(), f(true));
      }
      function _(E) {
        E.popup === g && f(false);
      }
      return s.map.on({
        popupopen: v,
        popupclose: _
      }), s.overlayContainer == null ? (d != null && g.setLatLng(d), g.openOn(s.map)) : s.overlayContainer.bindPopup(g), function() {
        var _a;
        s.map.off({
          popupopen: v,
          popupclose: _
        }), (_a = s.overlayContainer) == null ? void 0 : _a.unbindPopup(), s.map.removeLayer(g);
      };
    }, [
      l,
      s,
      f,
      d
    ]);
  }), ir = Ka(function({ url: l, ...s }, d) {
    const f = new xt.TileLayer(l, Ae(s, d));
    return Wt(f, d);
  }, function(l, s, d) {
    qa(l, s, d);
    const { url: f } = s;
    f != null && f !== d.url && l.setUrl(f);
  }), nr = ja(function(l) {
    return new xt.Control.Zoom(l);
  }), or = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAABSCAMAAAAhFXfZAAAC91BMVEVMaXEzeak2f7I4g7g3g7cua5gzeKg8hJo3grY4g7c3grU0gLI2frE0daAubJc2gbQwd6QzeKk2gLMtd5sxdKIua5g1frA2f7IydaM0e6w2fq41fK01eqo3grgubJgta5cxdKI1f7AydaQydaMxc6EubJgvbJkwcZ4ubZkwcJwubZgubJcydqUydKIxapgubJctbJcubZcubJcvbJYubJcvbZkubJctbJctbZcubJg2f7AubJcrbZcubJcubJcua5g3grY0fq8ubJcubJdEkdEwhsw6i88vhswuhcsuhMtBjMgthMsrg8srgss6is8qgcs8i9A9iMYtg8spgcoogMo7hcMngMonf8olfso4gr8kfck5iM8jfMk4iM8he8k1fro7itAgesk2hs8eecgzfLcofssdeMg0hc4cd8g2hcsxeLQbdsgZdcgxeLImfcszhM0vda4xgckzhM4xg84wf8Yxgs4udKsvfcQucqhUndROmdM1fK0wcZ8vb5w0eqpQm9MzeKhXoNVcpdYydKNWn9VZotVKltJFjsIwcJ1Rms9OlslLmtH///8+kc9epdYzd6dbo9VHkMM2f7FHmNBClM8ydqVcpNY9hro3gLM9hLczealQmcw3fa46f7A8gLMxc6I3eagyc6FIldJMl9JSnNRSntNNl9JPnNJFi75UnM9ZodVKksg8kM45jc09e6ZHltFBk883gbRBh7pDk9EwcaBzn784g7dKkcY2i81Om9M7j85Llc81is09g7Q4grY/j9A0eqxKmdFFltBEjcXf6fFImdBCiLxJl9FGlNFBi78yiMxVndEvbpo6js74+vx+psPP3+o/ks5HkcpGmNCjwdZCkNDM3ehYoNJEls+lxNkxh8xHks0+jdC1zd5Lg6r+/v/H2ufz9/o3jM3t8/edvdM/k89Th61OiLBSjbZklbaTt9BfptdjmL1AicBHj8hGk9FAgK1dkLNTjLRekrdClc/k7fM0icy0y9tgp9c4jc2NtM9Dlc8zicxeXZn3AAAAQ3RSTlMAHDdTb4yPA+LtnEQmC4L2EmHqB7XA0d0sr478x4/Yd5i1zOfyPkf1sLVq4Nh3FvjxopQ2/STNuFzUwFIwxKaejILpIBEV9wAABhVJREFUeF6s1NdyFEcYBeBeoQIhRAkLlRDGrhIgY3BJL8CVeKzuyXFzzjkn5ZxzzuScg3PO8cKzu70JkO0LfxdTU//pM9vTu7Xgf6KqOVTb9X7toRrVEfBf1HTVjZccrT/2by1VV928Yty9ZbVuucdz90frG8DBjl9pVApbOstvmMuvVgaNXSfAAd6pGxpy6yxf5ph43pS/4f3uoaGm2rdu72S9xzOvMymkZFq/ptDrk90mhW7e4zl7HLzhxGWPR20xmSxJ/VqldG5m9XhaVOA1DadsNh3Pu5L2N6QtPO/32JpqQBVVk20oy/Pi2s23WEvyfHbe1thadVQttvm7Llf65gGmXK67XtupyoM7HQhmXdLS8oGWJNeOJ3C5fG5XCEJnkez3/oFdsvgJ4l2ANZwhrJKk/7OSXa+3Vw2WJMlKnGkobouYk6T0TyX30klOUnTD9HJ5qpckL3EW/w4XF3Xd0FGywXUrstrclVsqz5Pd/sXFYyDnPdrLcQODmGOK47IZb4CmibmMn+MYRzFZ5jg33ZL/EJrWcszHmANy3ARBK/IXtciJy8VsitPSdE3uuHxzougojcUdr8/32atnz/ev3f/K5wtpxUTpcaI45zusVDpYtZi+jg0oU9b3x74h7+n9ABvYEZeKaVq0sh0AtLKsFtqNBdeT0MrSzwwlq9+x6xAO4tgOtSzbCjrNQQiNvQUbUEubvzBUeGw26yDCsRHCoLkTHDa7IdOLIThs/gHvChszh2CimE8peRs47cxANI0lYNB5y1DljpOF0IhzBDPOZnDOqYYbeGKECbPzWnXludPphw5c2YBq5zlwXphIbO4VDCZ0gnPfUO1TwZoYwAs2ExPCedAu9DAjfQUjzITQb3jNj0KG2Sgt6BHaQUdYzWz+XmBktOHwanXjaSTcwwziBcuMOtwBmqPrTOxFQR/DRKKPqyur0aiW6cULYsx6tBm0jXpR/AUWR6HRq9WVW6MRhIq5jLyjbaCTDCijyYJNpCajdyobP/eTw0iexBAKkJ3gA5KcQb2zBXsIBckn+xVv8jkZSaEFHE+jFEleAEfayRU0MouNoBmB/L50Ai/HSLIHxcrpCvnhSQAuakKp2C/YbCylJjXRVy/z3+Kv/RrNcCo+WUzlVEhzKffnTQnxeN9fWF88fiNCUdSTsaufaChKWInHeysygfpIqagoakW+vV20J8uyl6TyNKEZWV4oRSPyCkWpgOLSbkCObT8o2r6tlG58HQquf6O0v50tB7JM7F4EORd2dx/K0w/KHsVkLPaoYrwgP/y7krr3SSMA4zj+OBgmjYkxcdIJQyQRKgg2viX9Hddi9UBb29LrKR7CVVEEEXWojUkXNyfTNDE14W9gbHJNuhjDettN3ZvbOvdOqCD3Jp/9l+/wJE+9PkYGjx/fqkys3S2rMozM/o2106rfMUINo6hVqz+eu/hd1c4xTg0TAfy5kV+4UG6+IthHTU9woWmxuKNbTfuCSfovBCxq7EtHqvYL4Sm6F8GVxsSXHMQ07TOi1DKtZxjWaaIyi4CXWjxPccUw8WVbMYY5wxC1mzEyXMJWkllpRloi+Kkoq69sxBTlElF6aAxYUbjXNlhlDZilDnM4U5SlN5biRsRHnbx3mbeWjEh4mEyiuJDl5XcWVmX5GvNkFgLWZM5qwsop4/AWfLhU1cR7k1VVvcYCWRkOI6Xy5gmnphCYIkvzuNYzHzosq2oNk2RtSs8khfUOfHIDgR6ysYBaMpl4uEgk2U/oJTs9AaTSwma7dT69geAE2ZpEjUsn2ieJNHeKfrI3EcAGJ2ZaNgVuC8EBctCLc57P5u5led6IOBkIYkuQMrmmjChs4VkfOerHqSBkPzZlhe06RslZ3zMjk2sscqKwY0RcjKK+LWbzd7KiHhkncs/siFJ+V5eXxD34B8nVuJEpGJNmxN2gH3vSvp7J70tF+D1Ej8qUJD1TkErAND2GZwTFg/LubvmgiBG3SOvdlsqFQrkEzJCL1rstlnVFROixZoDDSuXQFHESwVGlcuQcMb/b42NgjLowh5MTDFE3vNB5qStRIErdCQEh6pLPR92anSUb/wAIhldAaDMpGgAAAABJRU5ErkJggg==", ar = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAApCAYAAADAk4LOAAAFgUlEQVR4Aa1XA5BjWRTN2oW17d3YaZtr2962HUzbDNpjszW24mRt28p47v7zq/bXZtrp/lWnXr337j3nPCe85NcypgSFdugCpW5YoDAMRaIMqRi6aKq5E3YqDQO3qAwjVWrD8Ncq/RBpykd8oZUb/kaJutow8r1aP9II0WmLKLIsJyv1w/kqw9Ch2MYdB++12Onxee/QMwvf4/Dk/Lfp/i4nxTXtOoQ4pW5Aj7wpici1A9erdAN2OH64x8OSP9j3Ft3b7aWkTg/Fm91siTra0f9on5sQr9INejH6CUUUpavjFNq1B+Oadhxmnfa8RfEmN8VNAsQhPqF55xHkMzz3jSmChWU6f7/XZKNH+9+hBLOHYozuKQPxyMPUKkrX/K0uWnfFaJGS1QPRtZsOPtr3NsW0uyh6NNCOkU3Yz+bXbT3I8G3xE5EXLXtCXbbqwCO9zPQYPRTZ5vIDXD7U+w7rFDEoUUf7ibHIR4y6bLVPXrz8JVZEql13trxwue/uDivd3fkWRbS6/IA2bID4uk0UpF1N8qLlbBlXs4Ee7HLTfV1j54APvODnSfOWBqtKVvjgLKzF5YdEk5ewRkGlK0i33Eofffc7HT56jD7/6U+qH3Cx7SBLNntH5YIPvODnyfIXZYRVDPqgHtLs5ABHD3YzLuespb7t79FY34DjMwrVrcTuwlT55YMPvOBnRrJ4VXTdNnYug5ucHLBjEpt30701A3Ts+HEa73u6dT3FNWwflY86eMHPk+Yu+i6pzUpRrW7SNDg5JHR4KapmM5Wv2E8Tfcb1HoqqHMHU+uWDD7zg54mz5/2BSnizi9T1Dg4QQXLToGNCkb6tb1NU+QAlGr1++eADrzhn/u8Q2YZhQVlZ5+CAOtqfbhmaUCS1ezNFVm2imDbPmPng5wmz+gwh+oHDce0eUtQ6OGDIyR0uUhUsoO3vfDmmgOezH0mZN59x7MBi++WDL1g/eEiU3avlidO671bkLfwbw5XV2P8Pzo0ydy4t2/0eu33xYSOMOD8hTf4CrBtGMSoXfPLchX+J0ruSePw3LZeK0juPJbYzrhkH0io7B3k164hiGvawhOKMLkrQLyVpZg8rHFW7E2uHOL888IBPlNZ1FPzstSJM694fWr6RwpvcJK60+0HCILTBzZLFNdtAzJaohze60T8qBzyh5ZuOg5e7uwQppofEmf2++DYvmySqGBuKaicF1blQjhuHdvCIMvp8whTTfZzI7RldpwtSzL+F1+wkdZ2TBOW2gIF88PBTzD/gpeREAMEbxnJcaJHNHrpzji0gQCS6hdkEeYt9DF/2qPcEC8RM28Hwmr3sdNyht00byAut2k3gufWNtgtOEOFGUwcXWNDbdNbpgBGxEvKkOQsxivJx33iow0Vw5S6SVTrpVq11ysA2Rp7gTfPfktc6zhtXBBC+adRLshf6sG2RfHPZ5EAc4sVZ83yCN00Fk/4kggu40ZTvIEm5g24qtU4KjBrx/BTTH8ifVASAG7gKrnWxJDcU7x8X6Ecczhm3o6YicvsLXWfh3Ch1W0k8x0nXF+0fFxgt4phz8QvypiwCCFKMqXCnqXExjq10beH+UUA7+nG6mdG/Pu0f3LgFcGrl2s0kNNjpmoJ9o4B29CMO8dMT4Q5ox8uitF6fqsrJOr8qnwNbRzv6hSnG5wP+64C7h9lp30hKNtKdWjtdkbuPA19nJ7Tz3zR/ibgARbhb4AlhavcBebmTHcFl2fvYEnW0ox9xMxKBS8btJ+KiEbq9zA4RthQXDhPa0T9TEe69gWupwc6uBUphquXgf+/FrIjweHQS4/pduMe5ERUMHUd9xv8ZR98CxkS4F2n3EUrUZ10EYNw7BWm9x1GiPssi3GgiGRDKWRYZfXlON+dfNbM+GgIwYdwAAAAASUVORK5CYII=", rr = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAQAAAACach9AAACMUlEQVR4Ae3ShY7jQBAE0Aoz/f9/HTMzhg1zrdKUrJbdx+Kd2nD8VNudfsL/Th///dyQN2TH6f3y/BGpC379rV+S+qqetBOxImNQXL8JCAr2V4iMQXHGNJxeCfZXhSRBcQMfvkOWUdtfzlLgAENmZDcmo2TVmt8OSM2eXxBp3DjHSMFutqS7SbmemzBiR+xpKCNUIRkdkkYxhAkyGoBvyQFEJEefwSmmvBfJuJ6aKqKWnAkvGZOaZXTUgFqYULWNSHUckZuR1HIIimUExutRxwzOLROIG4vKmCKQt364mIlhSyzAf1m9lHZHJZrlAOMMztRRiKimp/rpdJDc9Awry5xTZCte7FHtuS8wJgeYGrex28xNTd086Dik7vUMscQOa8y4DoGtCCSkAKlNwpgNtphjrC6MIHUkR6YWxxs6Sc5xqn222mmCRFzIt8lEdKx+ikCtg91qS2WpwVfBelJCiQJwvzixfI9cxZQWgiSJelKnwBElKYtDOb2MFbhmUigbReQBV0Cg4+qMXSxXSyGUn4UbF8l+7qdSGnTC0XLCmahIgUHLhLOhpVCtw4CzYXvLQWQbJNmxoCsOKAxSgBJno75avolkRw8iIAFcsdc02e9iyCd8tHwmeSSoKTowIgvscSGZUOA7PuCN5b2BX9mQM7S0wYhMNU74zgsPBj3HU7wguAfnxxjFQGBE6pwN+GjME9zHY7zGp8wVxMShYX9NXvEWD3HbwJf4giO4CFIQxXScH1/TM+04kkBiAAAAAElFTkSuQmCC";
  delete yt.Icon.Default.prototype._getIconUrl;
  yt.Icon.Default.mergeOptions({
    iconRetinaUrl: or,
    iconUrl: ar,
    shadowUrl: rr
  });
  const Rn = {
    mapContainer: {
      width: "100%",
      height: "100%"
    },
    dialogTitle: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  };
  function sr(c) {
    const l = Ja(), [s, d] = Et.useState(""), [f, m] = Et.useState(""), [g, v] = Et.useState("");
    if (JSON.stringify(c.rxData) !== s && c.markers.filter((_) => _.latitude && _.longitude).length || JSON.stringify(c.rxStyle) !== f || JSON.stringify(c.markers) !== g) {
      let _ = 0, E = 0;
      c.markers.forEach((b) => {
        _ += b.latitude || 0, E += b.longitude || 0;
      }), _ /= c.markers.length, E /= c.markers.length, l.setView([
        _,
        E
      ], parseInt(c.rxData.defaultZoom) || 18), c.markers.every((b) => l.getBounds().contains([
        b.latitude || 0,
        b.longitude || 0
      ])) || l.fitBounds(c.markers.map((b) => [
        b.latitude || 0,
        b.longitude || 0
      ])), d(JSON.stringify(c.rxData)), m(JSON.stringify(c.rxStyle)), v(JSON.stringify(c.markers));
    }
    return null;
  }
  const Ot = {
    default: {
      url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      title: "openstreetmap.de"
    },
    darkmatter: {
      url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
      attribution: '<a href="https://carto.com/attributions">CARTO</a>',
      title: "Dark matter"
    },
    stadiaosmbright: {
      url: "https://tiles.stadiamaps.com/tiles/osm_bright/{z}/{x}/{y}{r}.png",
      attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors',
      title: "Stadia OSM Bright"
    },
    esriworldimagery: {
      url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      attribution: "Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community",
      title: "Esri World Imagery"
    }
  };
  async function ke(c, l) {
    const s = c.split(".");
    s.pop();
    const d = s.join(".");
    return await l.getObject(d);
  }
  function gi(c) {
    return typeof c == "object" ? c[yi.getLanguage()] || c.en : c;
  }
  async function Hn(c, l, s, d) {
    var _a, _b, _c, _d, _e, _f;
    if (l[c.name]) {
      const f = await d.getObject(l[c.name]);
      let m = false, g = null, v = null;
      ((_a = f == null ? void 0 : f.common) == null ? void 0 : _a.color) ? (l[`color${c.index}`] = f.common.color, m = true) : f && (g = await ke(l[c.name], d), g && (g.type === "channel" || g.type === "device") && (((_b = g.common) == null ? void 0 : _b.color) ? (l[`name${c.index}`] = g.common.color, m = true) : (v = await ke(l[c.name], d), ((_c = v == null ? void 0 : v.common) == null ? void 0 : _c.color) && (l[`name${c.index}`] = v.common.color, m = true)))), ((_d = f == null ? void 0 : f.common) == null ? void 0 : _d.name) ? (m = true, l[`name${c.index}`] = gi(f.common.name)) : f && (g || (g = await ke(l[c.name], d)), g && (g.type === "channel" || g.type === "device") && (((_e = g.common) == null ? void 0 : _e.name) ? (l[`name${c.index}`] = gi(g.common.name), m = true) : (v || (v = await ke(l[c.name], d)), ((_f = v == null ? void 0 : v.common) == null ? void 0 : _f.name) && (l[`name${c.index}`] = gi(v.common.name), m = true)))), m && s(l);
    }
  }
  Jn = class extends yi {
    fillDataTimer = null;
    constructor(l) {
      super(l), this.state = {
        ...this.state,
        dialog: false,
        history: [],
        objects: []
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2Map",
        visSet: "vis-2-widgets-nils",
        visName: "Map",
        visWidgetLabel: "map",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox"
              },
              {
                name: "widgetTitle",
                label: "name"
              },
              {
                name: "markersCount",
                label: "markers_count",
                type: "number",
                default: 1
              },
              {
                name: "theme",
                label: "theme",
                type: "select",
                options: Object.keys(Ot).map((l) => ({
                  value: l,
                  label: Ot[l].title
                })),
                default: "default",
                noTranslation: true
              },
              {
                name: "themeUrl",
                label: "theme_url",
                hidden: (l) => l.theme && l.theme !== "default"
              },
              {
                name: "themeAttribution",
                label: "theme_attribution",
                hidden: (l) => l.theme && l.theme !== "default"
              },
              {
                name: "defaultZoom",
                label: "default_zoom",
                default: 12,
                type: "slider",
                min: 1,
                max: 25
              },
              {
                name: "noUserInteractions",
                label: "no_user_interactions",
                default: false,
                type: "checkbox"
              },
              {
                name: "hideZoomButtons",
                label: "hide_zoom",
                default: false,
                type: "checkbox",
                hidden: 'data["noUserInteractions"]'
              },
              {
                name: "hideFullScreenButton",
                label: "hide_full",
                default: false,
                type: "checkbox"
              }
            ]
          },
          {
            name: "markers",
            label: "markers",
            indexFrom: 1,
            indexTo: "markersCount",
            fields: [
              {
                name: "position",
                type: "id",
                label: "position",
                onChange: Hn,
                tooltip: "position_help"
              },
              {
                name: "longitude",
                hidden: (l, s) => !!l[`position${s}`],
                type: "id",
                label: "longitude",
                onChange: Hn
              },
              {
                name: "latitude",
                hidden: (l, s) => !!l[`position${s}`],
                type: "id",
                label: "latitude"
              },
              {
                name: "radius",
                type: "id",
                label: "radius",
                tooltip: "radius_tooltip"
              },
              {
                name: "name",
                label: "name"
              },
              {
                name: "color",
                type: "color",
                label: "color"
              },
              {
                name: "icon",
                type: "image",
                label: "icon"
              },
              {
                name: "useHistory",
                type: "checkbox",
                label: "use_history",
                default: true
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 240,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_map.png"
      };
    }
    getWidgetInfo() {
      return Jn.getWidgetInfo();
    }
    async propertiesUpdate() {
      var _a, _b, _c, _d, _e, _f;
      const l = ((_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory) || "history.0", s = {
        instance: ((_d = (_c = this.props.context.systemConfig) == null ? void 0 : _c.common) == null ? void 0 : _d.defaultHistory) || "history.0",
        from: false,
        ack: false,
        q: false,
        addID: false,
        end: (/* @__PURE__ */ new Date()).getTime(),
        count: 100
      }, d = [];
      for (let v = 1; v <= this.state.rxData.markersCount; v++) {
        const _ = yi.getHistoryInstance(this.state.objects[v], l);
        if (this.state.rxData[`position${v}`] && this.state.rxData[`useHistory${v}`] && _) {
          s.instance = _;
          const E = await this.props.context.socket.getHistory(this.state.rxData[`position${v}`], s);
          d[v] = E.filter((b) => b.val).sort((b, T) => b.ts > T.ts ? 1 : -1).map((b) => ({
            val: b.val,
            ts: b.ts
          }));
        }
      }
      this.setState({
        history: d
      });
      const f = [], m = [];
      for (let v = 1; v <= this.state.rxData.markersCount; v++) this.state.rxData[`position${v}`] && this.state.rxData[`position${v}`] !== "nothing_selected" && m.push(this.state.rxData[`oid${v}`]);
      const g = m.length ? await this.props.context.socket.getObjectsById(m) : {};
      for (let v = 1; v <= this.state.rxData.markersCount; v++) if (this.state.rxData[`position${v}`] && this.state.rxData[`position${v}`] !== "nothing_selected") {
        const _ = g[this.state.rxData[`position${v}`]];
        if (!_) {
          f[v] = {
            common: {},
            _id: this.state.rxData[`position${v}`]
          };
          continue;
        }
        if (_.common || (_.common = {}), !this.state.rxData[`icon${v}`] && !_.common.icon && (_.type === "state" || _.type === "channel")) {
          const E = this.state.rxData[`position${v}`].split("."), b = await this.props.context.socket.getObject(E.slice(0, -1).join("."));
          if (!((_e = b == null ? void 0 : b.common) == null ? void 0 : _e.icon) && (_.type === "state" || _.type === "channel")) {
            const T = await this.props.context.socket.getObject(E.slice(0, -2).join("."));
            ((_f = T == null ? void 0 : T.common) == null ? void 0 : _f.icon) && (_.common.icon = T.common.icon, (T.type === "instance" || T.type === "adapter") && (_.common.icon = `../${T.common.name}.admin/${_.common.icon}`));
          } else _.common.icon = b.common.icon, (b.type === "instance" || b.type === "adapter") && (_.common.icon = `../${b.common.name}.admin/${_.common.icon}`);
        }
        f[v] = {
          common: _.common,
          _id: _._id
        };
      }
      JSON.stringify(f) !== JSON.stringify(this.state.objects) && this.setState({
        objects: f
      });
    }
    async componentDidMount() {
      super.componentDidMount(), await this.propertiesUpdate(), this.fillDataTimer = setTimeout(() => {
        this.fillDataTimer = null, this.setState({
          forceShowMap: true
        });
      }, 2e3);
    }
    componentWillUnmount() {
      this.fillDataTimer && (clearTimeout(this.fillDataTimer), this.fillDataTimer = null);
    }
    async onRxDataChanged() {
      await this.propertiesUpdate();
    }
    async onStateUpdated() {
      await this.propertiesUpdate();
    }
    renderMap() {
      var _a, _b, _c;
      const l = [];
      for (let m = 1; m <= this.state.rxData.markersCount; m++) {
        const g = this.getPropertyValue(`position${m}`);
        let v;
        window.isFinite(this.state.rxData[`radius${m}`]) ? v = parseFloat(this.state.rxData[`radius${m}`]) : v = parseFloat(this.getPropertyValue(`radius${m}`)) || 0;
        const _ = g == null ? void 0 : g.toString().split(";");
        let E, b;
        (_ == null ? void 0 : _.length) === 2 ? (E = parseFloat(_[0]) || 0, b = parseFloat(_[1]) || 0) : (E = parseFloat(this.getPropertyValue(`longitude${m}`)) || 0, b = parseFloat(this.getPropertyValue(`latitude${m}`)) || 0);
        const T = {
          i: m,
          longitude: E,
          latitude: b,
          radius: v,
          name: this.state.rxData[`name${m}`],
          color: this.state.rxData[`color${m}`],
          icon: this.state.rxData[`icon${m}`] || ((_b = (_a = this.state.objects[m]) == null ? void 0 : _a.common) == null ? void 0 : _b.icon)
        };
        ((_c = T.icon) == null ? void 0 : _c.startsWith("_PRJ_NAME")) && (T.icon = T.icon.replace("_PRJ_NAME", `${this.props.context.adapterName}.${this.props.context.instance}/${this.props.context.projectName}/`)), (T.longitude || T.latitude) && l.push(T);
      }
      if (!l.length) return null;
      this.fillDataTimer && (clearTimeout(this.fillDataTimer), this.fillDataTimer = null);
      let s, d;
      this.state.rxData.theme && Ot[this.state.rxData.theme] ? (s = Ot[this.state.rxData.theme].url, d = Ot[this.state.rxData.theme].attribution) : this.state.rxData.themeUrl && (s = this.state.rxData.themeUrl, d = this.state.rxData.themeAttribution), s = s || Ot.default.url, d = d || Ot.default.attribution;
      const f = this.state.rxData.noUserInteractions ? {
        doubleClickZoom: false,
        closePopupOnClick: false,
        dragging: false,
        zoomSnap: 1,
        zoomDelta: 1,
        trackResize: false,
        touchZoom: false,
        scrollWheelZoom: false
      } : {};
      return D.jsxs(D.Fragment, {
        children: [
          D.jsx("style", {
            children: `.leaflet-control-attribution {
    display: none !important;
}
/*.leaflet-div-icon {
    border-radius: 50%;
}*/`
          }),
          D.jsxs(Qa, {
            style: Rn.mapContainer,
            scrollWheelZoom: true,
            zoom: parseFloat(this.state.rxData.defaultZoom) || 18,
            center: [
              0,
              0
            ],
            zoomControl: false,
            ...f,
            children: [
              D.jsx(ir, {
                attribution: d,
                url: s
              }),
              !this.state.rxData.hideZoomButtons && !this.state.rxData.noUserInteractions ? D.jsx(nr, {
                position: "bottomright"
              }) : null,
              l.map((m, g) => {
                var _a2;
                const v = ((_a2 = this.state.history[m.i]) == null ? void 0 : _a2.map((E) => {
                  const b = E.val.split(";");
                  return [
                    parseFloat(b[1] || "0"),
                    parseFloat(b[0] || "0")
                  ];
                })) || [];
                v.push([
                  m.latitude,
                  m.longitude
                ]);
                const _ = m.icon ? new yt.Icon({
                  iconUrl: m.icon,
                  iconRetinaUrl: m.icon,
                  iconAnchor: new yt.Point(16, 16),
                  popupAnchor: new yt.Point(0, -16),
                  shadowUrl: void 0,
                  shadowSize: void 0,
                  shadowAnchor: void 0,
                  iconSize: new yt.Point(32, 32),
                  className: "leaflet-div-icon"
                }) : new yt.Icon.Default();
                return D.jsxs(Et.Fragment, {
                  children: [
                    D.jsx($a, {
                      position: [
                        m.latitude,
                        m.longitude
                      ],
                      icon: _,
                      title: m.name,
                      eventHandlers: {
                        click: () => {
                          window.document.querySelectorAll(".leaflet-popup-close-button").forEach((E) => E.addEventListener("click", (b) => b.preventDefault()));
                        }
                      },
                      children: D.jsx(er, {
                        children: m.name
                      })
                    }),
                    this.state.history[m.i] ? v.map((E, b) => b < v.length - 1 && D.jsx(tr, {
                      pathOptions: {
                        color: m.color || "blue",
                        opacity: b + 1 / v.length
                      },
                      positions: [
                        E,
                        v[b + 1]
                      ]
                    }, b)) : null,
                    m.radius ? D.jsx(Ya, {
                      center: [
                        m.latitude,
                        m.longitude
                      ],
                      pathOptions: {
                        color: m.color || "blue"
                      },
                      radius: m.radius
                    }) : null
                  ]
                }, g);
              }),
              D.jsx(sr, {
                markers: l,
                rxData: this.state.rxData,
                rxStyle: this.state.rxStyle
              })
            ]
          }, `${s}_${!!this.state.rxData.noUserInteractions}`)
        ]
      });
    }
    renderDialog() {
      return D.jsxs(Sa, {
        open: !!this.state.dialog,
        fullScreen: true,
        onClose: () => this.setState({
          dialog: false
        }),
        children: [
          D.jsxs(Ca, {
            style: Rn.dialogTitle,
            children: [
              this.state.rxData.widgetTitle,
              D.jsx(Nn, {
                onClick: () => this.setState({
                  dialog: false
                }),
                children: D.jsx(Oa, {})
              })
            ]
          }),
          D.jsx(ka, {
            children: this.renderMap()
          })
        ]
      });
    }
    renderWidgetBody(l) {
      super.renderWidgetBody(l);
      const s = D.jsxs(D.Fragment, {
        children: [
          this.renderDialog(),
          this.renderMap()
        ]
      }), d = this.state.rxData.hideFullScreenButton ? null : D.jsx(Nn, {
        onClick: () => this.setState({
          dialog: true
        }),
        children: D.jsx(za, {
          style: {
            color: (this.state.rxData.noCard || l.widget.usedInWidget) && (!this.state.rxData.theme || this.state.rxData.theme === "default" || this.state.rxData.theme === "stadiaosmbright") ? "#111" : void 0
          }
        })
      });
      return this.state.rxData.noCard || l.widget.usedInWidget ? D.jsxs("div", {
        style: {
          width: "100%",
          height: "100%"
        },
        children: [
          D.jsx("div", {
            style: {
              position: "absolute",
              top: 0,
              right: 0,
              zIndex: 500
            },
            children: d
          }),
          s
        ]
      }) : this.wrapContent(s, this.state.rxData.widgetTitle ? d : D.jsxs("div", {
        style: {
          display: "flex",
          width: "100%"
        },
        children: [
          D.jsx("div", {
            style: {
              flex: 1
            }
          }),
          d
        ]
      }), {
        boxSizing: "border-box",
        paddingBottom: 10,
        height: "100%"
      });
    }
  };
});
export {
  __tla,
  Jn as default
};
