function u(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
function l(e, r) {
  for (var t = 0; t < r.length; t++) {
    const o = r[t];
    if (typeof o != "string" && !Array.isArray(o)) {
      for (const n in o) if (n !== "default" && !(n in e)) {
        const p = Object.getOwnPropertyDescriptor(o, n);
        p && Object.defineProperty(e, n, p.get ? p : { enumerable: true, get: () => o[n] });
      }
    }
  }
  return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }));
}
var s = { exports: {} }, m = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED", T = m, g = T;
function c() {
}
function i() {
}
i.resetWarningCache = c;
var h = function() {
  function e(o, n, p, b, d, f) {
    if (f !== g) {
      var a = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
      throw a.name = "Invariant Violation", a;
    }
  }
  e.isRequired = e;
  function r() {
    return e;
  }
  var t = { array: e, bigint: e, bool: e, func: e, number: e, object: e, string: e, symbol: e, any: e, arrayOf: r, element: e, elementType: e, instanceOf: r, node: e, objectOf: r, oneOf: r, oneOfType: r, shape: r, exact: r, checkPropTypes: i, resetWarningCache: c };
  return t.PropTypes = t, t;
};
s.exports = h();
var y = s.exports;
const _ = u(y), P = l({ __proto__: null, default: _ }, [y]);
export {
  P as i
};
