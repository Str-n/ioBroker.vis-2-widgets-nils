import { j as r, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { a as h, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { G as d } from "./Generic-CC2u2WPj.js";
import { __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
let n;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  n = class extends d {
    widgetRef = h.createRef();
    doNotWantIncludeWidgets;
    wakeUpInstalled;
    viewChangeInstalled;
    lastRefreshInterval;
    refreshInterval;
    lastWidget;
    constructor(e) {
      super(e), this.state = {
        ...this.state,
        q: Date.now()
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2Static",
        visSet: "vis-2-widgets-nils",
        visName: "Html template",
        visWidgetLabel: "html",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "html",
                type: "html",
                default: 'Admin Memory: <span style="color: #73b9ff">{system.adapter.admin.0.memHeapTotal.val}MB</span>',
                label: "html_template",
                hidden: (e) => !!e.iframe || !!e.image || !!e.image_oid || !!e.iframe_oid || !!e.widget
              },
              {
                name: "iframe",
                type: "url",
                label: "iframe_url",
                hidden: (e) => !!e.html || !!e.image || !!e.image_oid || !!e.iframe_oid || !!e.widget
              },
              {
                name: "iframe_oid",
                type: "id",
                label: "iframe_oid",
                hidden: (e) => !!e.html || !!e.image || !!e.image_oid || !!e.iframe || !!e.widget
              },
              {
                name: "image",
                type: "url",
                label: "image_url",
                hidden: (e) => !!e.iframe || !!e.html || !!e.image_oid || !!e.iframe_oid || !!e.widget
              },
              {
                name: "image_oid",
                type: "id",
                label: "image_oid",
                hidden: (e) => !!e.iframe || !!e.html || !!e.image || !!e.iframe_oid || !!e.widget
              },
              {
                name: "objectFit",
                type: "select",
                noTranslation: true,
                options: [
                  {
                    value: "fill",
                    label: "fill"
                  },
                  {
                    value: "contain",
                    label: "contain"
                  },
                  {
                    value: "cover",
                    label: "cover"
                  },
                  {
                    value: "none",
                    label: "none"
                  },
                  {
                    value: "scale-down",
                    label: "scale-down"
                  }
                ],
                default: "fill",
                label: "object_fit",
                hidden: (e) => !e.image && !e.image_oid
              },
              {
                name: "refreshInterval",
                type: "slider",
                min: 0,
                max: 18e4,
                step: 100,
                label: "refresh_interval",
                hidden: (e) => !!e.html || !!e.widget
              },
              {
                name: "refreshOnWakeUp",
                type: "checkbox",
                label: "refresh_on_wake_up",
                hidden: (e) => !!e.html || !!e.widget
              },
              {
                name: "refreshOnViewChange",
                type: "checkbox",
                label: "refresh_on_view_change",
                hidden: (e) => !!e.html || !!e.widget
              },
              {
                name: "scrollX",
                type: "checkbox",
                label: "scroll_x",
                hidden: (e) => !e.iframe && !e.iframe_oid
              },
              {
                name: "scrollY",
                type: "checkbox",
                label: "scroll_y",
                hidden: (e) => !e.iframe && !e.iframe_oid
              },
              {
                name: "seamless",
                type: "checkbox",
                label: "seamless",
                default: true,
                hidden: (e) => !e.iframe && !e.iframe_oid
              },
              {
                name: "noSandbox",
                type: "checkbox",
                label: "no_sandbox",
                default: true,
                hidden: (e) => !e.iframe && !e.iframe_oid
              },
              {
                name: "allowUserInteractions",
                type: "checkbox",
                label: "allow_user_interactions",
                default: true,
                hidden: (e) => !e.image && !e.image_oid
              },
              {
                name: "refreshWithNoQuery",
                type: "checkbox",
                label: "refresh_with_no_query",
                default: true,
                hidden: (e) => !e.image && !e.image_oid && !e.iframe && !e.iframe_oid
              },
              {
                name: "widget",
                type: "widget",
                label: "widget_id",
                hidden: (e) => !!e.image || !!e.image_oid || !!e.iframe || !!e.iframe_oid || !!e.html
              },
              {
                label: "doNotWantIncludeWidgets",
                name: "doNotWantIncludeWidgets",
                type: "checkbox",
                default: false
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_html.png"
      };
    }
    getWidgetInfo() {
      return n.getWidgetInfo();
    }
    componentDidMount() {
      var _a, _b;
      super.componentDidMount(), this.reinitInterval(), this.doNotWantIncludeWidgets = !!this.state.rxData.doNotWantIncludeWidgets, (_b = (_a = this.props).askView) == null ? void 0 : _b.call(_a, "update", {
        id: this.props.id,
        uuid: this.uuid,
        canHaveWidgets: true,
        doNotWantIncludeWidgets: !!this.state.rxData.doNotWantIncludeWidgets
      }), this.state.rxData.refreshOnWakeUp && !this.state.rxData.widget && (this.wakeUpInstalled = true, window.vis.onWakeUp(() => this.refresh(), this.props.id)), this.state.rxData.refreshOnViewChange && !this.state.rxData.widget && (this.viewChangeInstalled = true, window.vis.navChangeCallbacks.push({
        cb: (e) => e === this.props.view && this.refresh(),
        id: this.props.id
      }));
    }
    onCommand(e, a) {
      const i = super.onCommand(e, a);
      if (i === false && e === "include") {
        const s = JSON.parse(JSON.stringify(this.props.context.views)), t = s[this.props.view].widgets[this.props.id];
        return t.data.widget = a, this.props.context.changeProject(s), true;
      }
      return i;
    }
    reinitInterval() {
      const e = parseInt(this.state.rxData.refreshInterval, 10);
      (e !== this.lastRefreshInterval || this.state.rxData.widget !== this.lastWidget) && (this.refreshInterval && clearInterval(this.refreshInterval), this.refreshInterval = void 0, this.lastWidget = this.state.rxData.widget, this.lastRefreshInterval = e, e && !this.lastWidget && (this.refreshInterval = setInterval(() => this.refresh(), e)));
    }
    componentWillUnmount() {
      super.componentWillUnmount(), this.refreshInterval && clearInterval(this.refreshInterval), this.refreshInterval = void 0, this.wakeUpInstalled && (this.wakeUpInstalled = false, window.vis.onWakeUp(null, this.props.id)), this.viewChangeInstalled && (this.viewChangeInstalled = false, window.vis.navChangeCallbacks = window.vis.navChangeCallbacks.filter((e) => e.id !== this.props.id));
    }
    refresh() {
      this.setState({
        q: Date.now()
      });
    }
    getUrl() {
      let e = this.state.rxData.image || this.state.rxData.iframe;
      return this.state.rxData.iframe_oid && (e = this.state.values[`${this.state.rxData.iframe_oid}.val`]), this.state.rxData.image_oid && (e = this.state.values[`${this.state.rxData.image_oid}.val`]), this.state.rxData.refreshWithNoQuery || (e.includes("?") ? e += `&_=${this.state.q}` : e += `?_=${this.state.q}`), e;
    }
    renderWidgetBody(e) {
      var _a, _b;
      super.renderWidgetBody(e);
      const a = this.state.rxData.noCard || e.widget.usedInWidget;
      typeof this.doNotWantIncludeWidgets == "boolean" && this.doNotWantIncludeWidgets !== !!this.state.rxData.doNotWantIncludeWidgets && (this.doNotWantIncludeWidgets = !!this.state.rxData.doNotWantIncludeWidgets, setTimeout(() => this.props.askView && this.props.askView("update", {
        id: this.props.id,
        uuid: this.uuid,
        doNotWantIncludeWidgets: !!this.state.rxData.doNotWantIncludeWidgets
      }), 100));
      const i = {
        width: "100%",
        height: !a && this.state.rxData.widgetTitle ? "calc(100% - 36px)" : "100%",
        border: "0"
      };
      Object.keys(this.state.rxStyle).forEach((t) => {
        if (t !== "position" && t !== "top" && t !== "left" && t !== "width" && t !== "height" && this.state.rxStyle[t] !== void 0 && this.state.rxStyle[t] !== null) if (t.includes("-")) {
          const l = this.state.rxStyle[t];
          t = t.replace(/-./g, (o) => o[1].toUpperCase()), i[t] = l;
        } else i[t] = this.state.rxStyle[t];
      });
      let s;
      if (this.state.rxData.html && (s = r.jsx("div", {
        dangerouslySetInnerHTML: {
          __html: this.state.rxData.html
        },
        style: i
      })), this.state.rxData.iframe_oid || this.state.rxData.iframe) {
        const t = this.state.rxData.refreshWithNoQuery ? this.state.q : "element";
        this.reinitInterval(), i.overflowX = this.state.rxData.scrollX ? "scroll" : "hidden", i.overflowY = this.state.rxData.scrollY ? "scroll" : "hidden", s = r.jsx("iframe", {
          title: this.props.id,
          seamless: this.state.rxData.seamless,
          src: this.getUrl(),
          style: i,
          sandbox: this.state.rxData.noSandbox ? void 0 : "allow-scripts allow-same-origin allow-modals allow-forms allow-pointer-lock allow-popups"
        }, t);
      }
      if (this.state.rxData.image || this.state.rxData.image_oid) {
        const t = this.state.rxData.refreshWithNoQuery ? this.state.q : "element";
        this.reinitInterval(), this.state.rxData.allowUserInteractions && (i.touchAction = "none", i.userSelect = "none", i.pointerEvents = "none"), i.objectFit = this.state.rxData.objectFit, s = r.jsx("img", {
          src: this.getUrl(),
          style: i,
          alt: this.props.id
        }, t);
      }
      if (this.state.rxData.widget) {
        this.reinitInterval();
        const t = this.state.rxData.widget;
        ((_b = (_a = this.props.context.views[this.props.view]) == null ? void 0 : _a.widgets) == null ? void 0 : _b[t]) && this.getWidgetInWidget && t !== this.props.id && (this.widgetRef.current || setTimeout(() => this.forceUpdate(), 50), i.justifyContent = "center", i.display = "flex", i.alignItems = "center", s = r.jsx("div", {
          ref: this.widgetRef,
          style: i,
          children: this.widgetRef.current ? this.getWidgetInWidget(this.props.view, t, {
            refParent: this.widgetRef
          }) : null
        }));
      }
      return s = s || r.jsx("div", {
        style: i,
        children: "---"
      }), a ? s : this.wrapContent(s);
    }
  };
});
export {
  __tla,
  n as default
};
