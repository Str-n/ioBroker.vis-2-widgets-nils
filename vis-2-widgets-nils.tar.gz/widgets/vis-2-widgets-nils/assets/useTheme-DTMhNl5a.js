import { __tla as __tla_0 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { d as m, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_system__loadShare__.js-yqXflbgy.js";
import { d as t, T as o, __tla as __tla_2 } from "./defaultTheme-BzohoPAX.js";
let f;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  f = function() {
    const e = m(t);
    return e[o] || e;
  };
});
export {
  __tla,
  f as u
};
