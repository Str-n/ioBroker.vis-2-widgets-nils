let u, N, h, E, R;
let __tla = (async () => {
  function f(e, o) {
    for (var r = 0; r < o.length; r++) {
      const _ = o[r];
      if (typeof _ != "string" && !Array.isArray(_)) {
        for (const t in _) if (t !== "default" && !(t in e)) {
          const i = Object.getOwnPropertyDescriptor(_, t);
          i && Object.defineProperty(e, t, i.get ? i : {
            enumerable: true,
            get: () => _[t]
          });
        }
      }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
      value: "Module"
    }));
  }
  const a = "__mf_init____mf__virtual/__mfe_internal__vis2nilsWidgets__mf_v__runtimeInit__mf_v__.js__";
  let s = globalThis[a];
  if (!s) {
    let e, o;
    const r = new Promise((_, t) => {
      e = _, o = t;
    });
    s = globalThis[a] = {
      initPromise: r,
      initResolve: e,
      initReject: o
    }, typeof window > "u" && e({
      loadRemote: function() {
        return Promise.resolve(void 0);
      },
      loadShare: function() {
        return Promise.resolve(void 0);
      }
    });
  }
  let d, l, n, m, c, b, S, p, O, g, y, P, v;
  d = s.initPromise;
  l = d.then((e) => e.loadShare("react-dom", {
    customShareInfo: {
      shareConfig: {
        singleton: true,
        strictVersion: false,
        requiredVersion: "*"
      }
    }
  }));
  n = await l.then((e) => typeof e == "function" ? e() : e);
  m = n;
  u = n.__esModule ? n.default : n.default ?? n;
  ({ __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: c, createPortal: h, createRoot: b, findDOMNode: S, flushSync: R, hydrate: p, hydrateRoot: O, render: g, unmountComponentAtNode: y, unstable_batchedUpdates: E, unstable_renderSubtreeIntoContainer: P, version: v } = n);
  N = f({
    __proto__: null,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: c,
    createPortal: h,
    createRoot: b,
    default: u,
    findDOMNode: S,
    flushSync: R,
    hydrate: p,
    hydrateRoot: O,
    render: g,
    unmountComponentAtNode: y,
    unstable_batchedUpdates: E,
    unstable_renderSubtreeIntoContainer: P,
    version: v
  }, [
    m
  ]);
})();
export {
  u as R,
  N as _,
  __tla,
  h as a,
  E as b,
  R as c
};
