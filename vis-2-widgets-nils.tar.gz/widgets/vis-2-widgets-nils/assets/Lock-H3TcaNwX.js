import { j as o, __tla as __tla_0 } from "./jsx-runtime-BoEuoyzn.js";
import { a as u, d as m, s as f, _ as k, c, t as D, b as _, __tla as __tla_1 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-D6BQSU9w.js";
import { u as b, v as g, w as S, x as C, a as y, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CRxa-Ic2.js";
import { G as n } from "./Generic-CC2u2WPj.js";
import { D as j, L as v, __tla as __tla_3 } from "./LockIcon-CF8CnQX5.js";
import { P, __tla as __tla_4 } from "./PinCodeDialog-1pjxuXxA.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
import { __tla as __tla_6 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
let x;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })()
]).then(async () => {
  const h = {
    lockWorkingIcon: {
      position: "absolute",
      top: 10,
      left: 10
    },
    lockSvgIcon: {}
  };
  x = class extends n {
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        dialogPin: false,
        lockPinInput: "",
        invalidPin: false,
        confirmDialog: false
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplMaterial2Lock",
        visSet: "vis-2-widgets-nils",
        visName: "Lock",
        visWidgetLabel: "lock",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                hidden: "data.externalDialog === true",
                noBinding: false
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "data.noCard === true || data.externalDialog === true"
              },
              {
                name: "lock-oid",
                type: "id",
                label: "lock-oid",
                onChange: async (t, e, i, a) => {
                  if (e["lock-oid"]) {
                    const s = await a.getObject(e["lock-oid"]);
                    if (s && s.common && s.common.role === "switch.lock") {
                      const r = e[t.name].split(".");
                      r.pop();
                      const p = await a.getObjectViewSystem("state", `${r.join(".")}.`, `${r.join(".")}.\u9999`);
                      p && (Object.values(p).forEach((l) => {
                        var _a;
                        const d = (_a = l.common) == null ? void 0 : _a.role;
                        (d == null ? void 0 : d.startsWith("button")) ? e["doorOpen-oid"] = l._id : ((d == null ? void 0 : d.includes("direction")) || (d == null ? void 0 : d.includes("working"))) && (e["lockWorking-oid"] = l._id);
                      }), i(e));
                    }
                  }
                }
              },
              {
                name: "doorOpen-oid",
                type: "id",
                label: "doorOpen-oid"
              },
              {
                name: "lockWorking-oid",
                type: "id",
                label: "lockWorking-oid",
                hidden: (t) => !t["lock-oid"]
              },
              {
                name: "doorSensor-oid",
                type: "id",
                label: "doorSensor-oid"
              },
              {
                name: "pincode",
                label: "pincode",
                onChange: (t, e, i) => {
                  var _a;
                  return ((_a = e.pincode) == null ? void 0 : _a.match(/[^0-9]/g)) && (e.pincode = e.pincode.replace(/[^0-9]/g, ""), i(e)), Promise.resolve();
                },
                hidden: (t) => !!t["pincode-oid"]
              },
              {
                name: "pincode-oid",
                type: "id",
                label: "pincode_oid",
                hidden: (t) => !!t.pincode
              },
              {
                name: "doNotConfirm",
                type: "checkbox",
                label: "doNotConfirm",
                hidden: (t) => !!t.pincode || !!t["pincode-oid"],
                noBinding: false
              },
              {
                name: "pincodeReturnButton",
                type: "select",
                options: [
                  "submit",
                  "backspace"
                ],
                default: "submit",
                label: "pincode_return_button",
                hidden: (t) => !!t["pincode-oid"] && !!t.pincode
              },
              {
                name: "doorSize",
                label: "doorSize",
                type: "slider",
                min: 20,
                max: 500,
                default: 100,
                hidden: (t) => !t["doorOpen-oid"] && !t["doorSensor-oid"]
              },
              {
                name: "lockSize",
                label: "lockSize",
                type: "slider",
                min: 15,
                max: 500,
                default: 40,
                hidden: (t) => !t["lock-oid"]
              },
              {
                name: "noLockAnimation",
                label: "noLockAnimation",
                type: "checkbox",
                hidden: (t) => !t["lock-oid"],
                noBinding: false
              },
              {
                name: "lockColor",
                label: "Lock color",
                type: "color",
                hidden: (t) => !t["lock-oid"] || t.noLockAnimation === true || t.noLockAnimation === "true"
              },
              {
                name: "externalDialog",
                label: "use_as_dialog",
                type: "checkbox",
                tooltip: "use_as_dialog_tooltip",
                noBinding: false
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 240,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils/img/prev_lock.png"
      };
    }
    getWidgetInfo() {
      return x.getWidgetInfo();
    }
    lockRenderUnlockDialog() {
      return this.state.dialogPin ? o.jsx(P, {
        pinCode: this.lockGetPinCode(),
        pinCodeReturnButton: this.state.rxData.pincodeReturnButton === "backspace" ? "backspace" : "submit",
        onClose: (t) => {
          t && (this.state.dialogPin === "doorOpen-oid" ? this.props.context.setValue(this.state.rxData["doorOpen-oid"], true) : this.props.context.setValue(this.state.rxData["lock-oid"], true)), this.setState({
            dialogPin: false
          });
        }
      }) : null;
    }
    lockGetPinCode() {
      return this.state.rxData["pincode-oid"] ? this.getPropertyValue("pincode-oid") : this.state.rxData.pincode;
    }
    lockRenderConfirmDialog() {
      return this.state.confirmDialog ? o.jsxs(u, {
        open: true,
        onClose: () => this.setState({
          confirmDialog: false
        }),
        children: [
          o.jsx(m, {
            children: n.t("please_confirm")
          }),
          o.jsxs(f, {
            children: [
              o.jsx(k, {
                variant: "contained",
                color: "primary",
                onClick: () => {
                  this.setState({
                    confirmDialog: false
                  }), this.state.confirmDialog === "doorOpen-oid" ? this.props.context.setValue(this.state.rxData["doorOpen-oid"], true) : this.props.context.setValue(this.state.rxData["lock-oid"], true);
                },
                startIcon: this.state.confirmDialog === "doorOpen-oid" ? o.jsx(b, {}) : o.jsx(g, {}),
                children: n.t("Open")
              }),
              o.jsx(k, {
                variant: "contained",
                color: "grey",
                autoFocus: true,
                onClick: () => this.setState({
                  confirmDialog: false
                }),
                startIcon: o.jsx(S, {}),
                children: n.t("Cancel")
              })
            ]
          })
        ]
      }) : null;
    }
    onCommand(t) {
      const e = super.onCommand(t);
      if (e === false) {
        if (t === "openDialog") return this.setState({
          dialog: true
        }), true;
        if (t === "closeDialog") return this.setState({
          dialog: false
        }), true;
      }
      return e;
    }
    renderWidgetBody(t) {
      super.renderWidgetBody(t);
      const e = this.state.rxData["doorSensor-oid"] && this.getPropertyValue("doorSensor-oid"), i = this.getPropertyValue("lock-oid"), a = this.state.rxData["lockWorking-oid"] && this.getPropertyValue("lockWorking-oid");
      console.log(`Lock opened: ${i}, oid: ${this.state.rxData["lock-oid"]}, value: ${this.state.values[`${this.state.rxData["lock-oid"]}.val`]}`);
      const s = o.jsxs("div", {
        children: [
          this.lockRenderUnlockDialog(),
          this.lockRenderConfirmDialog(),
          this.state.rxData["doorSensor-oid"] || this.state.rxData["doorOpen-oid"] ? o.jsx(c, {
            disabled: !this.state.rxData["doorOpen-oid"],
            title: this.state.rxData["doorOpen-oid"] ? n.t("open_door") : void 0,
            onClick: () => {
              this.lockGetPinCode() ? this.setState({
                dialogPin: "doorOpen-oid",
                lockPinInput: ""
              }) : this.state.rxData.doNotConfirm === true || this.state.rxData.doNotConfirm === "true" ? this.props.context.setValue(this.state.rxData["doorOpen-oid"], true) : this.setState({
                confirmDialog: "doorOpen-oid"
              });
            },
            children: o.jsx(j, {
              open: e,
              size: this.state.rxData.doorSize
            })
          }) : null,
          this.state.rxData["lock-oid"] ? o.jsxs(c, {
            title: i ? n.t("close_lock") : n.t("open_lock"),
            onClick: () => {
              !i && this.lockGetPinCode() ? this.setState({
                dialogPin: "lock-oid",
                lockPinInput: ""
              }) : i || this.state.rxData.doNotConfirm === true || this.state.rxData.doNotConfirm === "true" ? this.props.context.setValue(this.state.rxData["lock-oid"], !this.getPropertyValue("lock-oid")) : this.setState({
                confirmDialog: "lock-oid"
              });
            },
            children: [
              o.jsx("style", {
                children: `
.iob-lock {
    transition: transform 0.5s ease;
    transform-origin: 15px 60px;
}
.iob-lock-opened {
    transform: rotate(-30deg);
}
.iob-lock-closed {
    transform: rotate(0deg);
}
`
              }),
              a && a !== 3 ? o.jsx(D, {
                style: h.lockWorkingIcon,
                size: this.state.rxData.lockSize || 40
              }) : null,
              this.state.rxData.noLockAnimation === true || this.state.rxData.noLockAnimation === "true" ? i ? o.jsx(g, {
                style: {
                  ...h.lockSvgIcon,
                  width: this.state.rxData.lockSize,
                  height: this.state.rxData.lockSize
                },
                sx: (r) => ({
                  color: r.palette.primary.main
                })
              }) : o.jsx(C, {
                style: {
                  ...h.lockSvgIcon,
                  width: this.state.rxData.lockSize,
                  height: this.state.rxData.lockSize
                }
              }) : o.jsx(v, {
                className: i ? "iob-lock iob-lock-opened" : "iob-lock iob-lock-closed",
                opened: i,
                style: {
                  color: this.state.rxData.lockColor,
                  height: this.state.rxData.lockSize,
                  width: "auto"
                }
              })
            ]
          }) : null
        ]
      });
      return (this.state.rxData.externalDialog === true || this.state.rxData.externalDialog === "true") && !this.props.editMode ? this.state.dialog ? o.jsxs(u, {
        open: true,
        onClose: () => this.setState({
          dialog: null
        }),
        children: [
          o.jsxs(_, {
            children: [
              this.state.rxData.widgetTitle,
              o.jsx(c, {
                style: {
                  float: "right",
                  zIndex: 2
                },
                onClick: () => this.setState({
                  dialog: null
                }),
                children: o.jsx(y, {})
              })
            ]
          }),
          o.jsx(m, {
            children: s
          })
        ]
      }) : null : this.state.rxData.noCard === true || this.state.rxData.noCard === "true" || t.widget.usedInWidget ? s : this.wrapContent(s, null, {
        boxSizing: "border-box",
        paddingBottom: 10,
        height: "100%"
      });
    }
  };
});
export {
  __tla,
  x as default
};
