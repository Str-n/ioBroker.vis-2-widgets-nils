const p = "modulepreload", y = function(u, i) {
  return new URL(u, i).href;
}, v = {}, w = function(i, a, f) {
  let d = Promise.resolve();
  if (a && a.length > 0) {
    let E = function(e) {
      return Promise.all(e.map((o) => Promise.resolve(o).then((s) => ({ status: "fulfilled", value: s }), (s) => ({ status: "rejected", reason: s }))));
    };
    const r = document.getElementsByTagName("link"), t = document.querySelector("meta[property=csp-nonce]"), m = (t == null ? void 0 : t.nonce) || (t == null ? void 0 : t.getAttribute("nonce"));
    d = E(a.map((e) => {
      if (e = y(e, f), e in v) return;
      v[e] = true;
      const o = e.endsWith(".css"), s = o ? '[rel="stylesheet"]' : "";
      if (f) for (let c = r.length - 1; c >= 0; c--) {
        const l = r[c];
        if (l.href === e && (!o || l.rel === "stylesheet")) return;
      }
      else if (document.querySelector(`link[href="${e}"]${s}`)) return;
      const n = document.createElement("link");
      if (n.rel = o ? "stylesheet" : p, o || (n.as = "script"), n.crossOrigin = "", n.href = e, m && n.setAttribute("nonce", m), document.head.appendChild(n), o) return new Promise((c, l) => {
        n.addEventListener("load", c), n.addEventListener("error", () => l(new Error(`Unable to preload CSS for ${e}`)));
      });
    }));
  }
  function h(r) {
    const t = new Event("vite:preloadError", { cancelable: true });
    if (t.payload = r, window.dispatchEvent(t), !t.defaultPrevented) throw r;
  }
  return d.then((r) => {
    for (const t of r || []) t.status === "rejected" && h(t.reason);
    return i().catch(h);
  });
};
export {
  w as _
};
