import { n as dt, u as ht, __tla as __tla_0 } from "./ThemeProvider-BU9BRLDr.js";
import { T as Kn, __tla as __tla_1 } from "./ThemeProvider-BU9BRLDr.js";
import { g as ze, m as Ke, h as pt, e as ne, f as Ue, c as vt, i as ve, r as gt, __tla as __tla_2 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js-Dh229usS.js";
import { _ as y } from "./extends-CF3RwP-h.js";
import { t as yt } from "./toPropertyKey-DCwh5dYN.js";
import { _ as qe } from "./inheritsLoose-CWawPfk8.js";
import { _ as xe } from "./assertThisInitialized-B9jnkVVz.js";
import { _ as mt } from "./objectWithoutPropertiesLoose-Dsqj8S3w.js";
import { j as V, __tla as __tla_3 } from "./jsx-runtime-BoEuoyzn.js";
import { __tla as __tla_4 } from "./__mfe_internal__vis2nilsWidgets__loadShare__prop_mf_2_types__loadShare__.js-Btvp0r21.js";
import { c as F, d as Pe, __tla as __tla_5 } from "./capitalize-BPb0zFhT.js";
import { c as we } from "./clsx-B-dksMZM.js";
import { h as ge } from "./hoist-non-react-statics.cjs-DPP7vwYz.js";
import { __tla as __tla_6 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
let En, pe, ln, Je, In, St, at, lt, ot, ut, on, Mn, J, $n, Vn, Gn, bn;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })()
]).then(async () => {
  const bt = [
    "checked",
    "disabled",
    "error",
    "focused",
    "focusVisible",
    "required",
    "expanded",
    "selected"
  ];
  Je = function(i = {}) {
    const { disableGlobal: t = false, productionPrefix: r = "jss", seed: e = "" } = i, n = e === "" ? "" : `${e}-`;
    let s = 0;
    const a = () => (s += 1, s);
    return (o, l) => {
      const f = l.options.name;
      if (f && f.startsWith("Mui") && !l.options.link && !t) {
        if (bt.includes(o.key)) return `Mui-${o.key}`;
        const c = `${n}${f}-${o.key}`;
        return !l.options.theme[dt] || e !== "" ? c : `${c}-${a()}`;
      }
      return `${n}${r}${a()}`;
    };
  };
  In = function(i) {
    return i;
  };
  St = function(i) {
    const { theme: t, name: r, props: e } = i;
    if (!t || !t.components || !t.components[r] || !t.components[r].defaultProps) return e;
    const n = {
      ...e
    }, s = t.components[r].defaultProps;
    let a;
    for (a in s) n[a] === void 0 && (n[a] = s[a]);
    return n;
  };
  var Ce = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(i) {
    return typeof i;
  } : function(i) {
    return i && typeof Symbol == "function" && i.constructor === Symbol && i !== Symbol.prototype ? "symbol" : typeof i;
  }, G = (typeof window > "u" ? "undefined" : Ce(window)) === "object" && (typeof document > "u" ? "undefined" : Ce(document)) === "object" && document.nodeType === 9;
  function Rt(i, t) {
    for (var r = 0; r < t.length; r++) {
      var e = t[r];
      e.enumerable = e.enumerable || false, e.configurable = true, "value" in e && (e.writable = true), Object.defineProperty(i, yt(e.key), e);
    }
  }
  function Le(i, t, r) {
    return t && Rt(i.prototype, t), Object.defineProperty(i, "prototype", {
      writable: false
    }), i;
  }
  var xt = {}.constructor;
  function ie(i) {
    if (i == null || typeof i != "object") return i;
    if (Array.isArray(i)) return i.map(ie);
    if (i.constructor !== xt) return i;
    var t = {};
    for (var r in i) t[r] = ie(i[r]);
    return t;
  }
  function ye(i, t, r) {
    i === void 0 && (i = "unnamed");
    var e = r.jss, n = ie(t), s = e.plugins.onCreateRule(i, n, r);
    return s || (i[0], null);
  }
  var ke = function(t, r) {
    for (var e = "", n = 0; n < t.length && t[n] !== "!important"; n++) e && (e += r), e += t[n];
    return e;
  }, C = function(t) {
    if (!Array.isArray(t)) return t;
    var r = "";
    if (Array.isArray(t[0])) for (var e = 0; e < t.length && t[e] !== "!important"; e++) r && (r += ", "), r += ke(t[e], " ");
    else r = ke(t, ", ");
    return t[t.length - 1] === "!important" && (r += " !important"), r;
  };
  function O(i) {
    return i && i.format === false ? {
      linebreak: "",
      space: ""
    } : {
      linebreak: `
`,
      space: " "
    };
  }
  function N(i, t) {
    for (var r = "", e = 0; e < t; e++) r += "  ";
    return r + i;
  }
  function $(i, t, r) {
    r === void 0 && (r = {});
    var e = "";
    if (!t) return e;
    var n = r, s = n.indent, a = s === void 0 ? 0 : s, o = t.fallbacks;
    r.format === false && (a = -1 / 0);
    var l = O(r), f = l.linebreak, c = l.space;
    if (i && a++, o) if (Array.isArray(o)) for (var d = 0; d < o.length; d++) {
      var g = o[d];
      for (var v in g) {
        var p = g[v];
        p != null && (e && (e += f), e += N(v + ":" + c + C(p) + ";", a));
      }
    }
    else for (var m in o) {
      var b = o[m];
      b != null && (e && (e += f), e += N(m + ":" + c + C(b) + ";", a));
    }
    for (var S in t) {
      var W = t[S];
      W != null && S !== "fallbacks" && (e && (e += f), e += N(S + ":" + c + C(W) + ";", a));
    }
    return !e && !r.allowEmpty || !i ? e : (a--, e && (e = "" + f + e + f), N("" + i + c + "{" + e, a) + N("}", a));
  }
  var Pt = /([[\].#*$><+~=|^:(),"'`\s])/g, je = typeof CSS < "u" && CSS.escape, me = (function(i) {
    return je ? je(i) : i.replace(Pt, "\\$1");
  }), Fe = (function() {
    function i(r, e, n) {
      this.type = "style", this.isProcessed = false;
      var s = n.sheet, a = n.Renderer;
      this.key = r, this.options = n, this.style = e, s ? this.renderer = s.renderer : a && (this.renderer = new a());
    }
    var t = i.prototype;
    return t.prop = function(e, n, s) {
      if (n === void 0) return this.style[e];
      var a = s ? s.force : false;
      if (!a && this.style[e] === n) return this;
      var o = n;
      (!s || s.process !== false) && (o = this.options.jss.plugins.onChangeValue(n, e, this));
      var l = o == null || o === false, f = e in this.style;
      if (l && !f && !a) return this;
      var c = l && f;
      if (c ? delete this.style[e] : this.style[e] = o, this.renderable && this.renderer) return c ? this.renderer.removeProperty(this.renderable, e) : this.renderer.setProperty(this.renderable, e, o), this;
      var d = this.options.sheet;
      return d && d.attached, this;
    }, i;
  })(), se = (function(i) {
    qe(t, i);
    function t(e, n, s) {
      var a;
      a = i.call(this, e, n, s) || this;
      var o = s.selector, l = s.scoped, f = s.sheet, c = s.generateId;
      return o ? a.selectorText = o : l !== false && (a.id = c(xe(xe(a)), f), a.selectorText = "." + me(a.id)), a;
    }
    var r = t.prototype;
    return r.applyTo = function(n) {
      var s = this.renderer;
      if (s) {
        var a = this.toJSON();
        for (var o in a) s.setProperty(n, o, a[o]);
      }
      return this;
    }, r.toJSON = function() {
      var n = {};
      for (var s in this.style) {
        var a = this.style[s];
        typeof a != "object" ? n[s] = a : Array.isArray(a) && (n[s] = C(a));
      }
      return n;
    }, r.toString = function(n) {
      var s = this.options.sheet, a = s ? s.options.link : false, o = a ? y({}, n, {
        allowEmpty: true
      }) : n;
      return $(this.selectorText, this.style, o);
    }, Le(t, [
      {
        key: "selector",
        set: function(n) {
          if (n !== this.selectorText) {
            this.selectorText = n;
            var s = this.renderer, a = this.renderable;
            if (!(!a || !s)) {
              var o = s.setSelector(a, n);
              o || s.replaceRule(a, this);
            }
          }
        },
        get: function() {
          return this.selectorText;
        }
      }
    ]), t;
  })(Fe), wt = {
    onCreateRule: function(t, r, e) {
      return t[0] === "@" || e.parent && e.parent.type === "keyframes" ? null : new se(t, r, e);
    }
  }, H = {
    indent: 1,
    children: true
  }, Ct = /@([\w-]+)/, kt = (function() {
    function i(r, e, n) {
      this.type = "conditional", this.isProcessed = false, this.key = r;
      var s = r.match(Ct);
      this.at = s ? s[1] : "unknown", this.query = n.name || "@" + this.at, this.options = n, this.rules = new q(y({}, n, {
        parent: this
      }));
      for (var a in e) this.rules.add(a, e[a]);
      this.rules.process();
    }
    var t = i.prototype;
    return t.getRule = function(e) {
      return this.rules.get(e);
    }, t.indexOf = function(e) {
      return this.rules.indexOf(e);
    }, t.addRule = function(e, n, s) {
      var a = this.rules.add(e, n, s);
      return a ? (this.options.jss.plugins.onProcessRule(a), a) : null;
    }, t.replaceRule = function(e, n, s) {
      var a = this.rules.replace(e, n, s);
      return a && this.options.jss.plugins.onProcessRule(a), a;
    }, t.toString = function(e) {
      e === void 0 && (e = H);
      var n = O(e), s = n.linebreak;
      if (e.indent == null && (e.indent = H.indent), e.children == null && (e.children = H.children), e.children === false) return this.query + " {}";
      var a = this.rules.toString(e);
      return a ? this.query + " {" + s + a + s + "}" : "";
    }, i;
  })(), jt = /@container|@media|@supports\s+/, _t = {
    onCreateRule: function(t, r, e) {
      return jt.test(t) ? new kt(t, r, e) : null;
    }
  }, B = {
    indent: 1,
    children: true
  }, Ot = /@keyframes\s+([\w-]+)/, ae = (function() {
    function i(r, e, n) {
      this.type = "keyframes", this.at = "@keyframes", this.isProcessed = false;
      var s = r.match(Ot);
      s && s[1] ? this.name = s[1] : this.name = "noname", this.key = this.type + "-" + this.name, this.options = n;
      var a = n.scoped, o = n.sheet, l = n.generateId;
      this.id = a === false ? this.name : me(l(this, o)), this.rules = new q(y({}, n, {
        parent: this
      }));
      for (var f in e) this.rules.add(f, e[f], y({}, n, {
        parent: this
      }));
      this.rules.process();
    }
    var t = i.prototype;
    return t.toString = function(e) {
      e === void 0 && (e = B);
      var n = O(e), s = n.linebreak;
      if (e.indent == null && (e.indent = B.indent), e.children == null && (e.children = B.children), e.children === false) return this.at + " " + this.id + " {}";
      var a = this.rules.toString(e);
      return a && (a = "" + s + a + s), this.at + " " + this.id + " {" + a + "}";
    }, i;
  })(), Tt = /@keyframes\s+/, Nt = /\$([\w-]+)/g, oe = function(t, r) {
    return typeof t == "string" ? t.replace(Nt, function(e, n) {
      return n in r ? r[n] : e;
    }) : t;
  }, _e = function(t, r, e) {
    var n = t[r], s = oe(n, e);
    s !== n && (t[r] = s);
  }, At = {
    onCreateRule: function(t, r, e) {
      return typeof t == "string" && Tt.test(t) ? new ae(t, r, e) : null;
    },
    onProcessStyle: function(t, r, e) {
      return r.type !== "style" || !e || ("animation-name" in t && _e(t, "animation-name", e.keyframes), "animation" in t && _e(t, "animation", e.keyframes)), t;
    },
    onChangeValue: function(t, r, e) {
      var n = e.options.sheet;
      if (!n) return t;
      switch (r) {
        case "animation":
          return oe(t, n.keyframes);
        case "animation-name":
          return oe(t, n.keyframes);
        default:
          return t;
      }
    }
  }, It = (function(i) {
    qe(t, i);
    function t() {
      return i.apply(this, arguments) || this;
    }
    var r = t.prototype;
    return r.toString = function(n) {
      var s = this.options.sheet, a = s ? s.options.link : false, o = a ? y({}, n, {
        allowEmpty: true
      }) : n;
      return $(this.key, this.style, o);
    }, t;
  })(Fe), Et = {
    onCreateRule: function(t, r, e) {
      return e.parent && e.parent.type === "keyframes" ? new It(t, r, e) : null;
    }
  }, Mt = (function() {
    function i(r, e, n) {
      this.type = "font-face", this.at = "@font-face", this.isProcessed = false, this.key = r, this.style = e, this.options = n;
    }
    var t = i.prototype;
    return t.toString = function(e) {
      var n = O(e), s = n.linebreak;
      if (Array.isArray(this.style)) {
        for (var a = "", o = 0; o < this.style.length; o++) a += $(this.at, this.style[o]), this.style[o + 1] && (a += s);
        return a;
      }
      return $(this.at, this.style, e);
    }, i;
  })(), $t = /@font-face/, Vt = {
    onCreateRule: function(t, r, e) {
      return $t.test(t) ? new Mt(t, r, e) : null;
    }
  }, Gt = (function() {
    function i(r, e, n) {
      this.type = "viewport", this.at = "@viewport", this.isProcessed = false, this.key = r, this.style = e, this.options = n;
    }
    var t = i.prototype;
    return t.toString = function(e) {
      return $(this.key, this.style, e);
    }, i;
  })(), Wt = {
    onCreateRule: function(t, r, e) {
      return t === "@viewport" || t === "@-ms-viewport" ? new Gt(t, r, e) : null;
    }
  }, zt = (function() {
    function i(r, e, n) {
      this.type = "simple", this.isProcessed = false, this.key = r, this.value = e, this.options = n;
    }
    var t = i.prototype;
    return t.toString = function(e) {
      if (Array.isArray(this.value)) {
        for (var n = "", s = 0; s < this.value.length; s++) n += this.key + " " + this.value[s] + ";", this.value[s + 1] && (n += `
`);
        return n;
      }
      return this.key + " " + this.value + ";";
    }, i;
  })(), Kt = {
    "@charset": true,
    "@import": true,
    "@namespace": true
  }, Ut = {
    onCreateRule: function(t, r, e) {
      return t in Kt ? new zt(t, r, e) : null;
    }
  }, Oe = [
    wt,
    _t,
    At,
    Et,
    Vt,
    Wt,
    Ut
  ], qt = {
    process: true
  }, Te = {
    force: true,
    process: true
  }, q = (function() {
    function i(r) {
      this.map = {}, this.raw = {}, this.index = [], this.counter = 0, this.options = r, this.classes = r.classes, this.keyframes = r.keyframes;
    }
    var t = i.prototype;
    return t.add = function(e, n, s) {
      var a = this.options, o = a.parent, l = a.sheet, f = a.jss, c = a.Renderer, d = a.generateId, g = a.scoped, v = y({
        classes: this.classes,
        parent: o,
        sheet: l,
        jss: f,
        Renderer: c,
        generateId: d,
        scoped: g,
        name: e,
        keyframes: this.keyframes,
        selector: void 0
      }, s), p = e;
      e in this.raw && (p = e + "-d" + this.counter++), this.raw[p] = n, p in this.classes && (v.selector = "." + me(this.classes[p]));
      var m = ye(p, n, v);
      if (!m) return null;
      this.register(m);
      var b = v.index === void 0 ? this.index.length : v.index;
      return this.index.splice(b, 0, m), m;
    }, t.replace = function(e, n, s) {
      var a = this.get(e), o = this.index.indexOf(a);
      a && this.remove(a);
      var l = s;
      return o !== -1 && (l = y({}, s, {
        index: o
      })), this.add(e, n, l);
    }, t.get = function(e) {
      return this.map[e];
    }, t.remove = function(e) {
      this.unregister(e), delete this.raw[e.key], this.index.splice(this.index.indexOf(e), 1);
    }, t.indexOf = function(e) {
      return this.index.indexOf(e);
    }, t.process = function() {
      var e = this.options.jss.plugins;
      this.index.slice(0).forEach(e.onProcessRule, e);
    }, t.register = function(e) {
      this.map[e.key] = e, e instanceof se ? (this.map[e.selector] = e, e.id && (this.classes[e.key] = e.id)) : e instanceof ae && this.keyframes && (this.keyframes[e.name] = e.id);
    }, t.unregister = function(e) {
      delete this.map[e.key], e instanceof se ? (delete this.map[e.selector], delete this.classes[e.key]) : e instanceof ae && delete this.keyframes[e.name];
    }, t.update = function() {
      var e, n, s;
      if (typeof (arguments.length <= 0 ? void 0 : arguments[0]) == "string" ? (e = arguments.length <= 0 ? void 0 : arguments[0], n = arguments.length <= 1 ? void 0 : arguments[1], s = arguments.length <= 2 ? void 0 : arguments[2]) : (n = arguments.length <= 0 ? void 0 : arguments[0], s = arguments.length <= 1 ? void 0 : arguments[1], e = null), e) this.updateOne(this.get(e), n, s);
      else for (var a = 0; a < this.index.length; a++) this.updateOne(this.index[a], n, s);
    }, t.updateOne = function(e, n, s) {
      s === void 0 && (s = qt);
      var a = this.options, o = a.jss.plugins, l = a.sheet;
      if (e.rules instanceof i) {
        e.rules.update(n, s);
        return;
      }
      var f = e.style;
      if (o.onUpdate(n, e, l, s), s.process && f && f !== e.style) {
        o.onProcessStyle(e.style, e, l);
        for (var c in e.style) {
          var d = e.style[c], g = f[c];
          d !== g && e.prop(c, d, Te);
        }
        for (var v in f) {
          var p = e.style[v], m = f[v];
          p == null && p !== m && e.prop(v, null, Te);
        }
      }
    }, t.toString = function(e) {
      for (var n = "", s = this.options.sheet, a = s ? s.options.link : false, o = O(e), l = o.linebreak, f = 0; f < this.index.length; f++) {
        var c = this.index[f], d = c.toString(e);
        !d && !a || (n && (n += l), n += d);
      }
      return n;
    }, i;
  })(), He = (function() {
    function i(r, e) {
      this.attached = false, this.deployed = false, this.classes = {}, this.keyframes = {}, this.options = y({}, e, {
        sheet: this,
        parent: this,
        classes: this.classes,
        keyframes: this.keyframes
      }), e.Renderer && (this.renderer = new e.Renderer(this)), this.rules = new q(this.options);
      for (var n in r) this.rules.add(n, r[n]);
      this.rules.process();
    }
    var t = i.prototype;
    return t.attach = function() {
      return this.attached ? this : (this.renderer && this.renderer.attach(), this.attached = true, this.deployed || this.deploy(), this);
    }, t.detach = function() {
      return this.attached ? (this.renderer && this.renderer.detach(), this.attached = false, this) : this;
    }, t.addRule = function(e, n, s) {
      var a = this.queue;
      this.attached && !a && (this.queue = []);
      var o = this.rules.add(e, n, s);
      return o ? (this.options.jss.plugins.onProcessRule(o), this.attached ? (this.deployed && (a ? a.push(o) : (this.insertRule(o), this.queue && (this.queue.forEach(this.insertRule, this), this.queue = void 0))), o) : (this.deployed = false, o)) : null;
    }, t.replaceRule = function(e, n, s) {
      var a = this.rules.get(e);
      if (!a) return this.addRule(e, n, s);
      var o = this.rules.replace(e, n, s);
      return o && this.options.jss.plugins.onProcessRule(o), this.attached ? (this.deployed && this.renderer && (o ? a.renderable && this.renderer.replaceRule(a.renderable, o) : this.renderer.deleteRule(a)), o) : (this.deployed = false, o);
    }, t.insertRule = function(e) {
      this.renderer && this.renderer.insertRule(e);
    }, t.addRules = function(e, n) {
      var s = [];
      for (var a in e) {
        var o = this.addRule(a, e[a], n);
        o && s.push(o);
      }
      return s;
    }, t.getRule = function(e) {
      return this.rules.get(e);
    }, t.deleteRule = function(e) {
      var n = typeof e == "object" ? e : this.rules.get(e);
      return !n || this.attached && !n.renderable ? false : (this.rules.remove(n), this.attached && n.renderable && this.renderer ? this.renderer.deleteRule(n.renderable) : true);
    }, t.indexOf = function(e) {
      return this.rules.indexOf(e);
    }, t.deploy = function() {
      return this.renderer && this.renderer.deploy(), this.deployed = true, this;
    }, t.update = function() {
      var e;
      return (e = this.rules).update.apply(e, arguments), this;
    }, t.updateOne = function(e, n, s) {
      return this.rules.updateOne(e, n, s), this;
    }, t.toString = function(e) {
      return this.rules.toString(e);
    }, i;
  })(), Jt = (function() {
    function i() {
      this.plugins = {
        internal: [],
        external: []
      }, this.registry = {};
    }
    var t = i.prototype;
    return t.onCreateRule = function(e, n, s) {
      for (var a = 0; a < this.registry.onCreateRule.length; a++) {
        var o = this.registry.onCreateRule[a](e, n, s);
        if (o) return o;
      }
      return null;
    }, t.onProcessRule = function(e) {
      if (!e.isProcessed) {
        for (var n = e.options.sheet, s = 0; s < this.registry.onProcessRule.length; s++) this.registry.onProcessRule[s](e, n);
        e.style && this.onProcessStyle(e.style, e, n), e.isProcessed = true;
      }
    }, t.onProcessStyle = function(e, n, s) {
      for (var a = 0; a < this.registry.onProcessStyle.length; a++) n.style = this.registry.onProcessStyle[a](n.style, n, s);
    }, t.onProcessSheet = function(e) {
      for (var n = 0; n < this.registry.onProcessSheet.length; n++) this.registry.onProcessSheet[n](e);
    }, t.onUpdate = function(e, n, s, a) {
      for (var o = 0; o < this.registry.onUpdate.length; o++) this.registry.onUpdate[o](e, n, s, a);
    }, t.onChangeValue = function(e, n, s) {
      for (var a = e, o = 0; o < this.registry.onChangeValue.length; o++) a = this.registry.onChangeValue[o](a, n, s);
      return a;
    }, t.use = function(e, n) {
      n === void 0 && (n = {
        queue: "external"
      });
      var s = this.plugins[n.queue];
      s.indexOf(e) === -1 && (s.push(e), this.registry = [].concat(this.plugins.external, this.plugins.internal).reduce(function(a, o) {
        for (var l in o) l in a && a[l].push(o[l]);
        return a;
      }, {
        onCreateRule: [],
        onProcessRule: [],
        onProcessStyle: [],
        onProcessSheet: [],
        onChangeValue: [],
        onUpdate: []
      }));
    }, i;
  })(), Be = (function() {
    function i() {
      this.registry = [];
    }
    var t = i.prototype;
    return t.add = function(e) {
      var n = this.registry, s = e.options.index;
      if (n.indexOf(e) === -1) {
        if (n.length === 0 || s >= this.index) {
          n.push(e);
          return;
        }
        for (var a = 0; a < n.length; a++) if (n[a].options.index > s) {
          n.splice(a, 0, e);
          return;
        }
      }
    }, t.reset = function() {
      this.registry = [];
    }, t.remove = function(e) {
      var n = this.registry.indexOf(e);
      this.registry.splice(n, 1);
    }, t.toString = function(e) {
      for (var n = e === void 0 ? {} : e, s = n.attached, a = mt(n, [
        "attached"
      ]), o = O(a), l = o.linebreak, f = "", c = 0; c < this.registry.length; c++) {
        var d = this.registry[c];
        s != null && d.attached !== s || (f && (f += l), f += d.toString(a));
      }
      return f;
    }, Le(i, [
      {
        key: "index",
        get: function() {
          return this.registry.length === 0 ? 0 : this.registry[this.registry.length - 1].options.index;
        }
      }
    ]), i;
  })(), E = new Be(), ue = typeof globalThis < "u" ? globalThis : typeof window < "u" && window.Math === Math ? window : typeof self < "u" && self.Math === Math ? self : Function("return this")(), le = "2f1acc6c3a606b082e5eef5e54414ffb";
  ue[le] == null && (ue[le] = 0);
  var Ne = ue[le]++, Ae = function(t) {
    t === void 0 && (t = {});
    var r = 0, e = function(s, a) {
      r += 1;
      var o = "", l = "";
      return a && (a.options.classNamePrefix && (l = a.options.classNamePrefix), a.options.jss.id != null && (o = String(a.options.jss.id))), t.minify ? "" + (l || "c") + Ne + o + r : l + s.key + "-" + Ne + (o ? "-" + o : "") + "-" + r;
    };
    return e;
  }, De = function(t) {
    var r;
    return function() {
      return r || (r = t()), r;
    };
  }, Lt = function(t, r) {
    try {
      return t.attributeStyleMap ? t.attributeStyleMap.get(r) : t.style.getPropertyValue(r);
    } catch {
      return "";
    }
  }, Ft = function(t, r, e) {
    try {
      var n = e;
      if (Array.isArray(e) && (n = C(e)), t.attributeStyleMap) t.attributeStyleMap.set(r, n);
      else {
        var s = n ? n.indexOf("!important") : -1, a = s > -1 ? n.substr(0, s - 1) : n;
        t.style.setProperty(r, a, s > -1 ? "important" : "");
      }
    } catch {
      return false;
    }
    return true;
  }, Ht = function(t, r) {
    try {
      t.attributeStyleMap ? t.attributeStyleMap.delete(r) : t.style.removeProperty(r);
    } catch {
    }
  }, Bt = function(t, r) {
    return t.selectorText = r, t.selectorText === r;
  }, Ze = De(function() {
    return document.querySelector("head");
  });
  function Dt(i, t) {
    for (var r = 0; r < i.length; r++) {
      var e = i[r];
      if (e.attached && e.options.index > t.index && e.options.insertionPoint === t.insertionPoint) return e;
    }
    return null;
  }
  function Zt(i, t) {
    for (var r = i.length - 1; r >= 0; r--) {
      var e = i[r];
      if (e.attached && e.options.insertionPoint === t.insertionPoint) return e;
    }
    return null;
  }
  function Qt(i) {
    for (var t = Ze(), r = 0; r < t.childNodes.length; r++) {
      var e = t.childNodes[r];
      if (e.nodeType === 8 && e.nodeValue.trim() === i) return e;
    }
    return null;
  }
  function Xt(i) {
    var t = E.registry;
    if (t.length > 0) {
      var r = Dt(t, i);
      if (r && r.renderer) return {
        parent: r.renderer.element.parentNode,
        node: r.renderer.element
      };
      if (r = Zt(t, i), r && r.renderer) return {
        parent: r.renderer.element.parentNode,
        node: r.renderer.element.nextSibling
      };
    }
    var e = i.insertionPoint;
    if (e && typeof e == "string") {
      var n = Qt(e);
      if (n) return {
        parent: n.parentNode,
        node: n.nextSibling
      };
    }
    return false;
  }
  function Yt(i, t) {
    var r = t.insertionPoint, e = Xt(t);
    if (e !== false && e.parent) {
      e.parent.insertBefore(i, e.node);
      return;
    }
    if (r && typeof r.nodeType == "number") {
      var n = r, s = n.parentNode;
      s && s.insertBefore(i, n.nextSibling);
      return;
    }
    Ze().appendChild(i);
  }
  var er = De(function() {
    var i = document.querySelector('meta[property="csp-nonce"]');
    return i ? i.getAttribute("content") : null;
  }), Ie = function(t, r, e) {
    try {
      "insertRule" in t ? t.insertRule(r, e) : "appendRule" in t && t.appendRule(r);
    } catch {
      return false;
    }
    return t.cssRules[e];
  }, Ee = function(t, r) {
    var e = t.cssRules.length;
    return r === void 0 || r > e ? e : r;
  }, tr = function() {
    var t = document.createElement("style");
    return t.textContent = `
`, t;
  }, rr = (function() {
    function i(r) {
      this.getPropertyValue = Lt, this.setProperty = Ft, this.removeProperty = Ht, this.setSelector = Bt, this.hasInsertedRules = false, this.cssRules = [], r && E.add(r), this.sheet = r;
      var e = this.sheet ? this.sheet.options : {}, n = e.media, s = e.meta, a = e.element;
      this.element = a || tr(), this.element.setAttribute("data-jss", ""), n && this.element.setAttribute("media", n), s && this.element.setAttribute("data-meta", s);
      var o = er();
      o && this.element.setAttribute("nonce", o);
    }
    var t = i.prototype;
    return t.attach = function() {
      if (!(this.element.parentNode || !this.sheet)) {
        Yt(this.element, this.sheet.options);
        var e = !!(this.sheet && this.sheet.deployed);
        this.hasInsertedRules && e && (this.hasInsertedRules = false, this.deploy());
      }
    }, t.detach = function() {
      if (this.sheet) {
        var e = this.element.parentNode;
        e && e.removeChild(this.element), this.sheet.options.link && (this.cssRules = [], this.element.textContent = `
`);
      }
    }, t.deploy = function() {
      var e = this.sheet;
      if (e) {
        if (e.options.link) {
          this.insertRules(e.rules);
          return;
        }
        this.element.textContent = `
` + e.toString() + `
`;
      }
    }, t.insertRules = function(e, n) {
      for (var s = 0; s < e.index.length; s++) this.insertRule(e.index[s], s, n);
    }, t.insertRule = function(e, n, s) {
      if (s === void 0 && (s = this.element.sheet), e.rules) {
        var a = e, o = s;
        if (e.type === "conditional" || e.type === "keyframes") {
          var l = Ee(s, n);
          if (o = Ie(s, a.toString({
            children: false
          }), l), o === false) return false;
          this.refCssRule(e, l, o);
        }
        return this.insertRules(a.rules, o), o;
      }
      var f = e.toString();
      if (!f) return false;
      var c = Ee(s, n), d = Ie(s, f, c);
      return d === false ? false : (this.hasInsertedRules = true, this.refCssRule(e, c, d), d);
    }, t.refCssRule = function(e, n, s) {
      e.renderable = s, e.options.parent instanceof He && this.cssRules.splice(n, 0, s);
    }, t.deleteRule = function(e) {
      var n = this.element.sheet, s = this.indexOf(e);
      return s === -1 ? false : (n.deleteRule(s), this.cssRules.splice(s, 1), true);
    }, t.indexOf = function(e) {
      return this.cssRules.indexOf(e);
    }, t.replaceRule = function(e, n) {
      var s = this.indexOf(e);
      return s === -1 ? false : (this.element.sheet.deleteRule(s), this.cssRules.splice(s, 1), this.insertRule(n, s));
    }, t.getRules = function() {
      return this.element.sheet.cssRules;
    }, i;
  })(), nr = 0, ir = (function() {
    function i(r) {
      this.id = nr++, this.version = "10.10.0", this.plugins = new Jt(), this.options = {
        id: {
          minify: false
        },
        createGenerateId: Ae,
        Renderer: G ? rr : null,
        plugins: []
      }, this.generateId = Ae({
        minify: false
      });
      for (var e = 0; e < Oe.length; e++) this.plugins.use(Oe[e], {
        queue: "internal"
      });
      this.setup(r);
    }
    var t = i.prototype;
    return t.setup = function(e) {
      return e === void 0 && (e = {}), e.createGenerateId && (this.options.createGenerateId = e.createGenerateId), e.id && (this.options.id = y({}, this.options.id, e.id)), (e.createGenerateId || e.id) && (this.generateId = this.options.createGenerateId(this.options.id)), e.insertionPoint != null && (this.options.insertionPoint = e.insertionPoint), "Renderer" in e && (this.options.Renderer = e.Renderer), e.plugins && this.use.apply(this, e.plugins), this;
    }, t.createStyleSheet = function(e, n) {
      n === void 0 && (n = {});
      var s = n, a = s.index;
      typeof a != "number" && (a = E.index === 0 ? 0 : E.index + 1);
      var o = new He(e, y({}, n, {
        jss: this,
        generateId: n.generateId || this.generateId,
        insertionPoint: this.options.insertionPoint,
        Renderer: this.options.Renderer,
        index: a
      }));
      return this.plugins.onProcessSheet(o), o;
    }, t.removeStyleSheet = function(e) {
      return e.detach(), E.remove(e), this;
    }, t.createRule = function(e, n, s) {
      if (n === void 0 && (n = {}), s === void 0 && (s = {}), typeof e == "object") return this.createRule(void 0, e, n);
      var a = y({}, s, {
        name: e,
        jss: this,
        Renderer: this.options.Renderer
      });
      a.generateId || (a.generateId = this.generateId), a.classes || (a.classes = {}), a.keyframes || (a.keyframes = {});
      var o = ye(e, n, a);
      return o && this.plugins.onProcessRule(o), o;
    }, t.use = function() {
      for (var e = this, n = arguments.length, s = new Array(n), a = 0; a < n; a++) s[a] = arguments[a];
      return s.forEach(function(o) {
        e.plugins.use(o);
      }), this;
    }, i;
  })(), be = function(t) {
    return new ir(t);
  }, Se = typeof CSS == "object" && CSS != null && "number" in CSS;
  function Qe(i) {
    var t = null;
    for (var r in i) {
      var e = i[r], n = typeof e;
      if (n === "function") t || (t = {}), t[r] = e;
      else if (n === "object" && e !== null && !Array.isArray(e)) {
        var s = Qe(e);
        s && (t || (t = {}), t[r] = s);
      }
    }
    return t;
  }
  be();
  var Xe = Date.now(), D = "fnValues" + Xe, Z = "fnStyle" + ++Xe, sr = function() {
    return {
      onCreateRule: function(r, e, n) {
        if (typeof e != "function") return null;
        var s = ye(r, {}, n);
        return s[Z] = e, s;
      },
      onProcessStyle: function(r, e) {
        if (D in e || Z in e) return r;
        var n = {};
        for (var s in r) {
          var a = r[s];
          typeof a == "function" && (delete r[s], n[s] = a);
        }
        return e[D] = n, r;
      },
      onUpdate: function(r, e, n, s) {
        var a = e, o = a[Z];
        o && (a.style = o(r) || {});
        var l = a[D];
        if (l) for (var f in l) a.prop(f, l[f](r), s);
      }
    };
  }, x = "@global", fe = "@global ", ar = (function() {
    function i(r, e, n) {
      this.type = "global", this.at = x, this.isProcessed = false, this.key = r, this.options = n, this.rules = new q(y({}, n, {
        parent: this
      }));
      for (var s in e) this.rules.add(s, e[s]);
      this.rules.process();
    }
    var t = i.prototype;
    return t.getRule = function(e) {
      return this.rules.get(e);
    }, t.addRule = function(e, n, s) {
      var a = this.rules.add(e, n, s);
      return a && this.options.jss.plugins.onProcessRule(a), a;
    }, t.replaceRule = function(e, n, s) {
      var a = this.rules.replace(e, n, s);
      return a && this.options.jss.plugins.onProcessRule(a), a;
    }, t.indexOf = function(e) {
      return this.rules.indexOf(e);
    }, t.toString = function(e) {
      return this.rules.toString(e);
    }, i;
  })(), or = (function() {
    function i(r, e, n) {
      this.type = "global", this.at = x, this.isProcessed = false, this.key = r, this.options = n;
      var s = r.substr(fe.length);
      this.rule = n.jss.createRule(s, e, y({}, n, {
        parent: this
      }));
    }
    var t = i.prototype;
    return t.toString = function(e) {
      return this.rule ? this.rule.toString(e) : "";
    }, i;
  })(), ur = /\s*,\s*/g;
  function Ye(i, t) {
    for (var r = i.split(ur), e = "", n = 0; n < r.length; n++) e += t + " " + r[n].trim(), r[n + 1] && (e += ", ");
    return e;
  }
  function lr(i, t) {
    var r = i.options, e = i.style, n = e ? e[x] : null;
    if (n) {
      for (var s in n) t.addRule(s, n[s], y({}, r, {
        selector: Ye(s, i.selector)
      }));
      delete e[x];
    }
  }
  function fr(i, t) {
    var r = i.options, e = i.style;
    for (var n in e) if (!(n[0] !== "@" || n.substr(0, x.length) !== x)) {
      var s = Ye(n.substr(x.length), i.selector);
      t.addRule(s, e[n], y({}, r, {
        selector: s
      })), delete e[n];
    }
  }
  function cr() {
    function i(r, e, n) {
      if (!r) return null;
      if (r === x) return new ar(r, e, n);
      if (r[0] === "@" && r.substr(0, fe.length) === fe) return new or(r, e, n);
      var s = n.parent;
      return s && (s.type === "global" || s.options.parent && s.options.parent.type === "global") && (n.scoped = false), !n.selector && n.scoped === false && (n.selector = r), null;
    }
    function t(r, e) {
      r.type !== "style" || !e || (lr(r, e), fr(r, e));
    }
    return {
      onCreateRule: i,
      onProcessRule: t
    };
  }
  var Me = /\s*,\s*/g, dr = /&/g, hr = /\$([\w-]+)/g;
  function pr() {
    function i(n, s) {
      return function(a, o) {
        var l = n.getRule(o) || s && s.getRule(o);
        return l ? l.selector : o;
      };
    }
    function t(n, s) {
      for (var a = s.split(Me), o = n.split(Me), l = "", f = 0; f < a.length; f++) for (var c = a[f], d = 0; d < o.length; d++) {
        var g = o[d];
        l && (l += ", "), l += g.indexOf("&") !== -1 ? g.replace(dr, c) : c + " " + g;
      }
      return l;
    }
    function r(n, s, a) {
      if (a) return y({}, a, {
        index: a.index + 1
      });
      var o = n.options.nestingLevel;
      o = o === void 0 ? 1 : o + 1;
      var l = y({}, n.options, {
        nestingLevel: o,
        index: s.indexOf(n) + 1
      });
      return delete l.name, l;
    }
    function e(n, s, a) {
      if (s.type !== "style") return n;
      var o = s, l = o.options.parent, f, c;
      for (var d in n) {
        var g = d.indexOf("&") !== -1, v = d[0] === "@";
        if (!(!g && !v)) {
          if (f = r(o, l, f), g) {
            var p = t(d, o.selector);
            c || (c = i(l, a)), p = p.replace(hr, c);
            var m = o.key + "-" + d;
            "replaceRule" in l ? l.replaceRule(m, n[d], y({}, f, {
              selector: p
            })) : l.addRule(m, n[d], y({}, f, {
              selector: p
            }));
          } else v && l.addRule(d, {}, f).addRule(o.key, n[d], {
            selector: o.selector
          });
          delete n[d];
        }
      }
      return n;
    }
    return {
      onProcessStyle: e
    };
  }
  var vr = /[A-Z]/g, gr = /^ms-/, Q = {};
  function yr(i) {
    return "-" + i.toLowerCase();
  }
  function et(i) {
    if (Q.hasOwnProperty(i)) return Q[i];
    var t = i.replace(vr, yr);
    return Q[i] = gr.test(t) ? "-" + t : t;
  }
  function U(i) {
    var t = {};
    for (var r in i) {
      var e = r.indexOf("--") === 0 ? r : et(r);
      t[e] = i[r];
    }
    return i.fallbacks && (Array.isArray(i.fallbacks) ? t.fallbacks = i.fallbacks.map(U) : t.fallbacks = U(i.fallbacks)), t;
  }
  function mr() {
    function i(r) {
      if (Array.isArray(r)) {
        for (var e = 0; e < r.length; e++) r[e] = U(r[e]);
        return r;
      }
      return U(r);
    }
    function t(r, e, n) {
      if (e.indexOf("--") === 0) return r;
      var s = et(e);
      return e === s ? r : (n.prop(s, r), null);
    }
    return {
      onProcessStyle: i,
      onChangeValue: t
    };
  }
  var u = Se && CSS ? CSS.px : "px", z = Se && CSS ? CSS.ms : "ms", k = Se && CSS ? CSS.percent : "%", br = {
    "animation-delay": z,
    "animation-duration": z,
    "background-position": u,
    "background-position-x": u,
    "background-position-y": u,
    "background-size": u,
    border: u,
    "border-bottom": u,
    "border-bottom-left-radius": u,
    "border-bottom-right-radius": u,
    "border-bottom-width": u,
    "border-left": u,
    "border-left-width": u,
    "border-radius": u,
    "border-right": u,
    "border-right-width": u,
    "border-top": u,
    "border-top-left-radius": u,
    "border-top-right-radius": u,
    "border-top-width": u,
    "border-width": u,
    "border-block": u,
    "border-block-end": u,
    "border-block-end-width": u,
    "border-block-start": u,
    "border-block-start-width": u,
    "border-block-width": u,
    "border-inline": u,
    "border-inline-end": u,
    "border-inline-end-width": u,
    "border-inline-start": u,
    "border-inline-start-width": u,
    "border-inline-width": u,
    "border-start-start-radius": u,
    "border-start-end-radius": u,
    "border-end-start-radius": u,
    "border-end-end-radius": u,
    margin: u,
    "margin-bottom": u,
    "margin-left": u,
    "margin-right": u,
    "margin-top": u,
    "margin-block": u,
    "margin-block-end": u,
    "margin-block-start": u,
    "margin-inline": u,
    "margin-inline-end": u,
    "margin-inline-start": u,
    padding: u,
    "padding-bottom": u,
    "padding-left": u,
    "padding-right": u,
    "padding-top": u,
    "padding-block": u,
    "padding-block-end": u,
    "padding-block-start": u,
    "padding-inline": u,
    "padding-inline-end": u,
    "padding-inline-start": u,
    "mask-position-x": u,
    "mask-position-y": u,
    "mask-size": u,
    height: u,
    width: u,
    "min-height": u,
    "max-height": u,
    "min-width": u,
    "max-width": u,
    bottom: u,
    left: u,
    top: u,
    right: u,
    inset: u,
    "inset-block": u,
    "inset-block-end": u,
    "inset-block-start": u,
    "inset-inline": u,
    "inset-inline-end": u,
    "inset-inline-start": u,
    "box-shadow": u,
    "text-shadow": u,
    "column-gap": u,
    "column-rule": u,
    "column-rule-width": u,
    "column-width": u,
    "font-size": u,
    "font-size-delta": u,
    "letter-spacing": u,
    "text-decoration-thickness": u,
    "text-indent": u,
    "text-stroke": u,
    "text-stroke-width": u,
    "word-spacing": u,
    motion: u,
    "motion-offset": u,
    outline: u,
    "outline-offset": u,
    "outline-width": u,
    perspective: u,
    "perspective-origin-x": k,
    "perspective-origin-y": k,
    "transform-origin": k,
    "transform-origin-x": k,
    "transform-origin-y": k,
    "transform-origin-z": k,
    "transition-delay": z,
    "transition-duration": z,
    "vertical-align": u,
    "flex-basis": u,
    "shape-margin": u,
    size: u,
    gap: u,
    grid: u,
    "grid-gap": u,
    "row-gap": u,
    "grid-row-gap": u,
    "grid-column-gap": u,
    "grid-template-rows": u,
    "grid-template-columns": u,
    "grid-auto-rows": u,
    "grid-auto-columns": u,
    "box-shadow-x": u,
    "box-shadow-y": u,
    "box-shadow-blur": u,
    "box-shadow-spread": u,
    "font-line-height": u,
    "text-shadow-x": u,
    "text-shadow-y": u,
    "text-shadow-blur": u
  };
  function tt(i) {
    var t = /(-[a-z])/g, r = function(a) {
      return a[1].toUpperCase();
    }, e = {};
    for (var n in i) e[n] = i[n], e[n.replace(t, r)] = i[n];
    return e;
  }
  var Sr = tt(br);
  function M(i, t, r) {
    if (t == null) return t;
    if (Array.isArray(t)) for (var e = 0; e < t.length; e++) t[e] = M(i, t[e], r);
    else if (typeof t == "object") if (i === "fallbacks") for (var n in t) t[n] = M(n, t[n], r);
    else for (var s in t) t[s] = M(i + "-" + s, t[s], r);
    else if (typeof t == "number" && isNaN(t) === false) {
      var a = r[i] || Sr[i];
      return a && !(t === 0 && a === u) ? typeof a == "function" ? a(t).toString() : "" + t + a : t.toString();
    }
    return t;
  }
  function Rr(i) {
    i === void 0 && (i = {});
    var t = tt(i);
    function r(n, s) {
      if (s.type !== "style") return n;
      for (var a in n) n[a] = M(a, n[a], t);
      return n;
    }
    function e(n, s) {
      return M(s, n, t);
    }
    return {
      onProcessStyle: r,
      onChangeValue: e
    };
  }
  function ce(i, t) {
    (t == null || t > i.length) && (t = i.length);
    for (var r = 0, e = Array(t); r < t; r++) e[r] = i[r];
    return e;
  }
  function xr(i) {
    if (Array.isArray(i)) return ce(i);
  }
  function Pr(i) {
    if (typeof Symbol < "u" && i[Symbol.iterator] != null || i["@@iterator"] != null) return Array.from(i);
  }
  function wr(i, t) {
    if (i) {
      if (typeof i == "string") return ce(i, t);
      var r = {}.toString.call(i).slice(8, -1);
      return r === "Object" && i.constructor && (r = i.constructor.name), r === "Map" || r === "Set" ? Array.from(i) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? ce(i, t) : void 0;
    }
  }
  function Cr() {
    throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  function kr(i) {
    return xr(i) || Pr(i) || wr(i) || Cr();
  }
  var A = "", de = "", rt = "", nt = "", jr = G && "ontouchstart" in document.documentElement;
  if (G) {
    var X = {
      Moz: "-moz-",
      ms: "-ms-",
      O: "-o-",
      Webkit: "-webkit-"
    }, _r = document.createElement("p"), Y = _r.style, Or = "Transform";
    for (var ee in X) if (ee + Or in Y) {
      A = ee, de = X[ee];
      break;
    }
    A === "Webkit" && "msHyphens" in Y && (A = "ms", de = X.ms, nt = "edge"), A === "Webkit" && "-apple-trailing-word" in Y && (rt = "apple");
  }
  var h = {
    js: A,
    css: de,
    vendor: rt,
    browser: nt,
    isTouch: jr
  };
  function Tr(i) {
    return i[1] === "-" || h.js === "ms" ? i : "@" + h.css + "keyframes" + i.substr(10);
  }
  var Nr = {
    noPrefill: [
      "appearance"
    ],
    supportedProperty: function(t) {
      return t !== "appearance" ? false : h.js === "ms" ? "-webkit-" + t : h.css + t;
    }
  }, Ar = {
    noPrefill: [
      "color-adjust"
    ],
    supportedProperty: function(t) {
      return t !== "color-adjust" ? false : h.js === "Webkit" ? h.css + "print-" + t : t;
    }
  }, Ir = /[-\s]+(.)?/g;
  function Er(i, t) {
    return t ? t.toUpperCase() : "";
  }
  function Re(i) {
    return i.replace(Ir, Er);
  }
  function P(i) {
    return Re("-" + i);
  }
  var Mr = {
    noPrefill: [
      "mask"
    ],
    supportedProperty: function(t, r) {
      if (!/^mask/.test(t)) return false;
      if (h.js === "Webkit") {
        var e = "mask-image";
        if (Re(e) in r) return t;
        if (h.js + P(e) in r) return h.css + t;
      }
      return t;
    }
  }, $r = {
    noPrefill: [
      "text-orientation"
    ],
    supportedProperty: function(t) {
      return t !== "text-orientation" ? false : h.vendor === "apple" && !h.isTouch ? h.css + t : t;
    }
  }, Vr = {
    noPrefill: [
      "transform"
    ],
    supportedProperty: function(t, r, e) {
      return t !== "transform" ? false : e.transform ? t : h.css + t;
    }
  }, Gr = {
    noPrefill: [
      "transition"
    ],
    supportedProperty: function(t, r, e) {
      return t !== "transition" ? false : e.transition ? t : h.css + t;
    }
  }, Wr = {
    noPrefill: [
      "writing-mode"
    ],
    supportedProperty: function(t) {
      return t !== "writing-mode" ? false : h.js === "Webkit" || h.js === "ms" && h.browser !== "edge" ? h.css + t : t;
    }
  }, zr = {
    noPrefill: [
      "user-select"
    ],
    supportedProperty: function(t) {
      return t !== "user-select" ? false : h.js === "Moz" || h.js === "ms" || h.vendor === "apple" ? h.css + t : t;
    }
  }, Kr = {
    supportedProperty: function(t, r) {
      if (!/^break-/.test(t)) return false;
      if (h.js === "Webkit") {
        var e = "WebkitColumn" + P(t);
        return e in r ? h.css + "column-" + t : false;
      }
      if (h.js === "Moz") {
        var n = "page" + P(t);
        return n in r ? "page-" + t : false;
      }
      return false;
    }
  }, Ur = {
    supportedProperty: function(t, r) {
      if (!/^(border|margin|padding)-inline/.test(t)) return false;
      if (h.js === "Moz") return t;
      var e = t.replace("-inline", "");
      return h.js + P(e) in r ? h.css + e : false;
    }
  }, qr = {
    supportedProperty: function(t, r) {
      return Re(t) in r ? t : false;
    }
  }, Jr = {
    supportedProperty: function(t, r) {
      var e = P(t);
      return t[0] === "-" || t[0] === "-" && t[1] === "-" ? t : h.js + e in r ? h.css + t : h.js !== "Webkit" && "Webkit" + e in r ? "-webkit-" + t : false;
    }
  }, Lr = {
    supportedProperty: function(t) {
      return t.substring(0, 11) !== "scroll-snap" ? false : h.js === "ms" ? "" + h.css + t : t;
    }
  }, Fr = {
    supportedProperty: function(t) {
      return t !== "overscroll-behavior" ? false : h.js === "ms" ? h.css + "scroll-chaining" : t;
    }
  }, Hr = {
    "flex-grow": "flex-positive",
    "flex-shrink": "flex-negative",
    "flex-basis": "flex-preferred-size",
    "justify-content": "flex-pack",
    order: "flex-order",
    "align-items": "flex-align",
    "align-content": "flex-line-pack"
  }, Br = {
    supportedProperty: function(t, r) {
      var e = Hr[t];
      return e && h.js + P(e) in r ? h.css + e : false;
    }
  }, it = {
    flex: "box-flex",
    "flex-grow": "box-flex",
    "flex-direction": [
      "box-orient",
      "box-direction"
    ],
    order: "box-ordinal-group",
    "align-items": "box-align",
    "flex-flow": [
      "box-orient",
      "box-direction"
    ],
    "justify-content": "box-pack"
  }, Dr = Object.keys(it), Zr = function(t) {
    return h.css + t;
  }, Qr = {
    supportedProperty: function(t, r, e) {
      var n = e.multiple;
      if (Dr.indexOf(t) > -1) {
        var s = it[t];
        if (!Array.isArray(s)) return h.js + P(s) in r ? h.css + s : false;
        if (!n) return false;
        for (var a = 0; a < s.length; a++) if (!(h.js + P(s[0]) in r)) return false;
        return s.map(Zr);
      }
      return false;
    }
  }, st = [
    Nr,
    Ar,
    Mr,
    $r,
    Vr,
    Gr,
    Wr,
    zr,
    Kr,
    Ur,
    qr,
    Jr,
    Lr,
    Fr,
    Br,
    Qr
  ], $e = st.filter(function(i) {
    return i.supportedProperty;
  }).map(function(i) {
    return i.supportedProperty;
  }), Xr = st.filter(function(i) {
    return i.noPrefill;
  }).reduce(function(i, t) {
    return i.push.apply(i, kr(t.noPrefill)), i;
  }, []), I, w = {};
  if (G) {
    I = document.createElement("p");
    var te = window.getComputedStyle(document.documentElement, "");
    for (var re in te) isNaN(re) || (w[te[re]] = te[re]);
    Xr.forEach(function(i) {
      return delete w[i];
    });
  }
  function he(i, t) {
    if (t === void 0 && (t = {}), !I) return i;
    if (w[i] != null) return w[i];
    (i === "transition" || i === "transform") && (t[i] = i in I.style);
    for (var r = 0; r < $e.length && (w[i] = $e[r](i, I.style, t), !w[i]); r++) ;
    try {
      I.style[i] = "";
    } catch {
      return false;
    }
    return w[i];
  }
  var j = {}, Yr = {
    transition: 1,
    "transition-property": 1,
    "-webkit-transition": 1,
    "-webkit-transition-property": 1
  }, en = /(^\s*[\w-]+)|, (\s*[\w-]+)(?![^()]*\))/g, R;
  function tn(i, t, r) {
    if (t === "var") return "var";
    if (t === "all") return "all";
    if (r === "all") return ", all";
    var e = t ? he(t) : ", " + he(r);
    return e || t || r;
  }
  G && (R = document.createElement("p"));
  function Ve(i, t) {
    var r = t;
    if (!R || i === "content") return t;
    if (typeof r != "string" || !isNaN(parseInt(r, 10))) return r;
    var e = i + r;
    if (j[e] != null) return j[e];
    try {
      R.style[i] = r;
    } catch {
      return j[e] = false, false;
    }
    if (Yr[i]) r = r.replace(en, tn);
    else if (R.style[i] === "" && (r = h.css + r, r === "-ms-flex" && (R.style[i] = "-ms-flexbox"), R.style[i] = r, R.style[i] === "")) return j[e] = false, false;
    return R.style[i] = "", j[e] = r, j[e];
  }
  function rn() {
    function i(n) {
      if (n.type === "keyframes") {
        var s = n;
        s.at = Tr(s.at);
      }
    }
    function t(n) {
      for (var s in n) {
        var a = n[s];
        if (s === "fallbacks" && Array.isArray(a)) {
          n[s] = a.map(t);
          continue;
        }
        var o = false, l = he(s);
        l && l !== s && (o = true);
        var f = false, c = Ve(l, C(a));
        c && c !== a && (f = true), (o || f) && (o && delete n[s], n[l || s] = c || a);
      }
      return n;
    }
    function r(n, s) {
      return s.type !== "style" ? n : t(n);
    }
    function e(n, s) {
      return Ve(s, C(n)) || n;
    }
    return {
      onProcessRule: i,
      onProcessStyle: r,
      onChangeValue: e
    };
  }
  function nn() {
    var i = function(r, e) {
      return r.length === e.length ? r > e ? 1 : -1 : r.length - e.length;
    };
    return {
      onProcessStyle: function(r, e) {
        if (e.type !== "style") return r;
        for (var n = {}, s = Object.keys(r).sort(i), a = 0; a < s.length; a++) n[s[a]] = r[s[a]];
        return n;
      }
    };
  }
  at = function() {
    return {
      plugins: [
        sr(),
        cr(),
        pr(),
        mr(),
        Rr(),
        typeof window > "u" ? null : rn(),
        nn()
      ]
    };
  };
  ot = function(i = {}) {
    const { baseClasses: t, newClasses: r, Component: e } = i;
    if (!r) return t;
    const n = {
      ...t
    };
    return Object.keys(r).forEach((s) => {
      r[s] && (n[s] = `${t[s]} ${r[s]}`);
    }), n;
  };
  const _ = {
    set: (i, t, r, e) => {
      let n = i.get(t);
      n || (n = /* @__PURE__ */ new Map(), i.set(t, n)), n.set(r, e);
    },
    get: (i, t, r) => {
      const e = i.get(t);
      return e ? e.get(r) : void 0;
    },
    delete: (i, t, r) => {
      i.get(t).delete(r);
    }
  };
  J = function() {
    const i = ht();
    return (i == null ? void 0 : i.$$material) ?? i;
  };
  let sn, an, un;
  sn = be(at());
  an = Je();
  on = /* @__PURE__ */ new Map();
  un = {
    disableGeneration: false,
    generateClassName: an,
    jss: sn,
    sheetsCache: null,
    sheetsManager: on,
    sheetsRegistry: null
  };
  pe = pt(un);
  let K;
  ln = function(i) {
    const { children: t, injectFirst: r = false, disableGeneration: e = false, ...n } = i, s = ze(pe), { generateClassName: a, jss: o, serverGenerateClassName: l, sheetsCache: f, sheetsManager: c, sheetsRegistry: d } = {
      ...s,
      ...n
    }, g = Ke(() => {
      const v = {
        disableGeneration: e,
        generateClassName: a,
        jss: o,
        serverGenerateClassName: l,
        sheetsCache: f,
        sheetsManager: c,
        sheetsRegistry: d
      };
      if (!v.jss.options.insertionPoint && r && typeof window < "u") {
        if (!K) {
          const p = document.head;
          K = document.createComment("mui-inject-first"), p.insertBefore(K, p.firstChild);
        }
        v.jss = be({
          plugins: at().plugins,
          insertionPoint: K
        });
      }
      return v;
    }, [
      r,
      e,
      a,
      o,
      l,
      f,
      c,
      d
    ]);
    return V.jsx(pe.Provider, {
      value: g,
      children: t
    });
  };
  let Ge = -1e9;
  function fn() {
    return Ge += 1, Ge;
  }
  function We(i) {
    return i.length === 0;
  }
  ut = function(i) {
    const { variant: t, ...r } = i;
    let e = t || "";
    return Object.keys(r).sort().forEach((n) => {
      n === "color" ? e += We(e) ? i[n] : F(i[n]) : e += `${We(e) ? n : F(n)}${F(i[n].toString())}`;
    }), e;
  };
  const cn = {};
  function dn(i) {
    const t = typeof i == "function";
    return {
      create: (r, e) => {
        let n;
        try {
          n = t ? i(r) : i;
        } catch (l) {
          throw l;
        }
        if (!e || !r.components || !r.components[e] || !r.components[e].styleOverrides && !r.components[e].variants) return n;
        const s = r.components[e].styleOverrides || {}, a = r.components[e].variants || [], o = {
          ...n
        };
        return Object.keys(s).forEach((l) => {
          o[l] = Pe(o[l] || {}, s[l]);
        }), a.forEach((l) => {
          const f = ut(l.props);
          o[f] = Pe(o[f] || {}, l.style);
        }), o;
      },
      options: {}
    };
  }
  function hn({ state: i, stylesOptions: t }, r, e) {
    if (t.disableGeneration) return r || {};
    i.cacheClasses || (i.cacheClasses = {
      value: null,
      lastProp: null,
      lastJSS: {}
    });
    let n = false;
    return i.classes !== i.cacheClasses.lastJSS && (i.cacheClasses.lastJSS = i.classes, n = true), r !== i.cacheClasses.lastProp && (i.cacheClasses.lastProp = r, n = true), n && (i.cacheClasses.value = ot({
      baseClasses: i.cacheClasses.lastJSS,
      newClasses: r,
      Component: e
    })), i.cacheClasses.value;
  }
  function pn({ state: i, theme: t, stylesOptions: r, stylesCreator: e, name: n }, s) {
    if (r.disableGeneration) return;
    let a = _.get(r.sheetsManager, e, t);
    a || (a = {
      refs: 0,
      staticSheet: null,
      dynamicStyles: null
    }, _.set(r.sheetsManager, e, t, a));
    const o = {
      ...e.options,
      ...r,
      theme: t,
      flip: typeof r.flip == "boolean" ? r.flip : t.direction === "rtl"
    };
    o.generateId = o.serverGenerateClassName || o.generateClassName;
    const l = r.sheetsRegistry;
    if (a.refs === 0) {
      let f;
      r.sheetsCache && (f = _.get(r.sheetsCache, e, t));
      const c = e.create(t, n);
      f || (f = r.jss.createStyleSheet(c, {
        link: false,
        ...o
      }), f.attach(), r.sheetsCache && _.set(r.sheetsCache, e, t, f)), l && l.add(f), a.staticSheet = f, a.dynamicStyles = Qe(c);
    }
    if (a.dynamicStyles) {
      const f = r.jss.createStyleSheet(a.dynamicStyles, {
        link: true,
        ...o
      });
      f.update(s), f.attach(), i.dynamicSheet = f, i.classes = ot({
        baseClasses: a.staticSheet.classes,
        newClasses: f.classes
      }), l && l.add(f);
    } else i.classes = a.staticSheet.classes;
    a.refs += 1;
  }
  function vn({ state: i }, t) {
    i.dynamicSheet && i.dynamicSheet.update(t);
  }
  function gn({ state: i, theme: t, stylesOptions: r, stylesCreator: e }) {
    if (r.disableGeneration) return;
    const n = _.get(r.sheetsManager, e, t);
    n.refs -= 1;
    const s = r.sheetsRegistry;
    n.refs === 0 && (_.delete(r.sheetsManager, e, t), r.jss.removeStyleSheet(n.staticSheet), s && s.remove(n.staticSheet)), i.dynamicSheet && (r.jss.removeStyleSheet(i.dynamicSheet), s && s.remove(i.dynamicSheet));
  }
  function yn(i, t) {
    const r = ne([]);
    let e;
    const n = Ke(() => ({}), t);
    r.current !== n && (r.current = n, e = i()), Ue(() => () => {
      e && e();
    }, [
      n
    ]);
  }
  lt = function(i, t = {}) {
    const { name: r, classNamePrefix: e, Component: n, defaultTheme: s = cn, ...a } = t, o = dn(i), l = r || e || "makeStyles";
    return o.options = {
      index: fn(),
      name: r,
      meta: l,
      classNamePrefix: l
    }, (c = {}) => {
      const d = J() || s, g = {
        ...ze(pe),
        ...a
      }, v = ne(), p = ne();
      return yn(() => {
        const b = {
          name: r,
          state: {},
          stylesCreator: o,
          stylesOptions: g,
          theme: d
        };
        return pn(b, c), p.current = false, v.current = b, () => {
          gn(b);
        };
      }, [
        d,
        o
      ]), Ue(() => {
        p.current && vn(v.current, c), p.current = true;
      }), hn(v.current, c.classes, n);
    };
  };
  En = class {
    constructor(t = {}) {
      this.options = t;
    }
    collect(t) {
      const r = /* @__PURE__ */ new Map();
      this.sheetsRegistry = new Be();
      const e = Je();
      return V.jsx(ln, {
        sheetsManager: r,
        serverGenerateClassName: e,
        sheetsRegistry: this.sheetsRegistry,
        ...this.options,
        children: t
      });
    }
    toString() {
      return this.sheetsRegistry ? this.sheetsRegistry.toString() : "";
    }
    getStyleElement(t) {
      return vt("style", {
        id: "jss-server-side",
        key: "jss-server-side",
        dangerouslySetInnerHTML: {
          __html: this.toString()
        },
        ...t
      });
    }
  };
  function mn(i, t) {
    const r = {};
    return Object.keys(i).forEach((e) => {
      t.includes(e) || (r[e] = i[e]);
    }), r;
  }
  Mn = function(i) {
    return (r, e = {}) => {
      const { name: n, ...s } = e;
      let a = n;
      const l = lt(typeof r == "function" ? (d) => ({
        root: (g) => r({
          theme: d,
          ...g
        })
      }) : {
        root: r
      }, {
        Component: i,
        name: n || i.displayName,
        classNamePrefix: a,
        ...s
      });
      let f;
      r.filterProps && (f = r.filterProps, delete r.filterProps), r.propTypes && (r.propTypes, delete r.propTypes);
      const c = ve(function(g, v) {
        const { children: p, className: m, clone: b, component: S, ...W } = g, ft = l(g), L = we(ft.root, m);
        let T = W;
        if (f && (T = mn(T, f)), b) return gt(p, {
          className: we(p.props.className, L),
          ...T
        });
        if (typeof p == "function") return p({
          className: L,
          ...T
        });
        const ct = S || i;
        return V.jsx(ct, {
          ref: v,
          className: L,
          ...T,
          children: p
        });
      });
      return ge(c, i), c;
    };
  };
  $n = (i, t) => {
    const { classes: r = {} } = i, e = J();
    let n = "";
    return e && e.components && e.components[t] && e.components[t].variants && e.components[t].variants.forEach((a) => {
      let o = true;
      Object.keys(a.props).forEach((l) => {
        i[l] !== a.props[l] && (o = false);
      }), o && (n = `${n}${r[ut(a.props)]} `);
    }), n;
  };
  Vn = (i, t = {}) => (r) => {
    const { defaultTheme: e, withTheme: n = false, name: s, ...a } = t;
    let o = s;
    const l = lt(i, {
      defaultTheme: e,
      Component: r,
      name: s || r.displayName,
      classNamePrefix: o,
      ...a
    }), f = ve(function(d, g) {
      const { classes: v, ...p } = d, m = l({
        ...r.defaultProps,
        ...d
      });
      let b, S = p;
      return (typeof s == "string" || n) && (b = J() || e, s && (S = St({
        theme: b,
        name: s,
        props: p
      })), n && !S.theme && (S.theme = b)), V.jsx(r, {
        ref: g,
        classes: m,
        ...S
      });
    });
    return ge(f, r), f;
  };
  bn = function(i = {}) {
    const { defaultTheme: t } = i;
    return (e) => {
      const n = ve(function(a, o) {
        const l = J() || t;
        return V.jsx(e, {
          theme: l,
          ref: o,
          ...a
        });
      });
      return ge(n, e), n;
    };
  };
  Gn = bn();
});
export {
  En as ServerStyleSheets,
  pe as StylesContext,
  ln as StylesProvider,
  Kn as ThemeProvider,
  __tla,
  Je as createGenerateClassName,
  In as createStyles,
  St as getThemeProps,
  at as jssPreset,
  lt as makeStyles,
  ot as mergeClasses,
  ut as propsToClassKey,
  on as sheetsManager,
  Mn as styled,
  J as useTheme,
  $n as useThemeVariants,
  Vn as withStyles,
  Gn as withTheme,
  bn as withThemeCreator
};
