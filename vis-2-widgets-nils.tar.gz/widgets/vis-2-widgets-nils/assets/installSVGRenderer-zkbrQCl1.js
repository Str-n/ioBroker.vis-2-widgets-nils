import { t as Ly } from "./tslib.es6-BuLyYyFn.js";
import { r as Oy, __tla as __tla_0 } from "./__mfe_internal__vis2nilsWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIx8xGyr.js";
let Sc, tn, Lg, nt, Nb, wo, lf, oe, ut, Z, W, rn, ty, wt, ot, G, dm, at, ne, xe, $e, Oh, dr, Oo, dc, fm, Re, ft, V, bd, Tl, y0, Gu, j, Nl, gc, V2, sx, lx, ux, No, Ul, In, n1, Pt, _b, on, zt, VM, jo, Qo, yb, vg, cg, Y2, zm, tx, ex, HC, zi, uf, Ig, vd, hr, kn, U2, rl, sb, Yr, ae, qC, bo, Hc, Fo, Ye, fy, vm, Wn, BC, nx, bt, ax, GC, YC, K, rx, VC, ix, en, pb, p0, r1, WC, Id, ox, FC, _d, $2, rs, po, go, Db, io, Fm, Us, Z2, H2, Xb, pe, G2, pl, Q2, Wt, W2, ka, To, Ie, J2, K2, j2, Et, ns, Ag, Ut, Ad, Ho, q2, fx, q, F, P, lt, yt, vt, B, Sf, ht, mt, ct, O, gg, Yt, Ei, Y, an, En, wb, X2, Xe, Vn, Ac, Fn;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function Ry(e) {
    if (Object.prototype.hasOwnProperty.call(e, "__esModule")) return e;
    var n = e.default;
    if (typeof n == "function") {
      var t = function r() {
        var o = false;
        try {
          o = this instanceof r;
        } catch {
        }
        return o ? Reflect.construct(n, arguments, this.constructor) : n.apply(this, arguments);
      };
      t.prototype = n.prototype;
    } else t = {};
    return Object.defineProperty(t, "__esModule", {
      value: true
    }), Object.keys(e).forEach(function(r) {
      var o = Object.getOwnPropertyDescriptor(e, r);
      Object.defineProperty(t, r, o.get ? o : {
        enumerable: true,
        get: function() {
          return e[r];
        }
      });
    }), t;
  }
  var xp = {};
  const Pp = Ry(Ly);
  var Be = {}, ze = {}, _s = {}, Kf;
  function ky() {
    return Kf || (Kf = 1, (function(e) {
      Object.defineProperty(e, "__esModule", {
        value: true
      }), e.default = void 0;
      var t = 1;
      e.default = function() {
        return "".concat(t++);
      };
    })(_s)), _s;
  }
  var Xn = {}, $n = {}, Ss = {}, jf;
  function Ip() {
    return jf || (jf = 1, (function(e) {
      Object.defineProperty(e, "__esModule", {
        value: true
      }), e.default = void 0, e.default = function(r) {
        var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 60, i = null;
        return function() {
          for (var a = this, o = arguments.length, s = new Array(o), u = 0; u < o; u++) s[u] = arguments[u];
          clearTimeout(i), i = setTimeout(function() {
            r.apply(a, s);
          }, n);
        };
      };
    })(Ss)), Ss;
  }
  var Ve = {}, Qf;
  function El() {
    return Qf || (Qf = 1, Object.defineProperty(Ve, "__esModule", {
      value: true
    }), Ve.SizeSensorId = Ve.SensorTabIndex = Ve.SensorClassName = void 0, Ve.SizeSensorId = "size-sensor-id", Ve.SensorClassName = "size-sensor-object", Ve.SensorTabIndex = "-1"), Ve;
  }
  var Jf;
  function Ny() {
    if (Jf) return $n;
    Jf = 1, Object.defineProperty($n, "__esModule", {
      value: true
    }), $n.createSensor = void 0;
    var e = r(Ip()), t = El();
    function r(n) {
      return n && n.__esModule ? n : {
        default: n
      };
    }
    return $n.createSensor = function(i, a) {
      var o = void 0, s = [], u = function() {
        getComputedStyle(i).position === "static" && (i.style.position = "relative");
        var p = document.createElement("object");
        return p.onload = function() {
          p.contentDocument.defaultView.addEventListener("resize", l), l();
        }, p.style.display = "block", p.style.position = "absolute", p.style.top = "0", p.style.left = "0", p.style.height = "100%", p.style.width = "100%", p.style.overflow = "hidden", p.style.pointerEvents = "none", p.style.zIndex = "-1", p.style.opacity = "0", p.setAttribute("class", t.SensorClassName), p.setAttribute("tabindex", t.SensorTabIndex), p.type = "text/html", i.appendChild(p), p.data = "about:blank", p;
      }, l = (0, e.default)(function() {
        s.forEach(function(v) {
          v(i);
        });
      }), f = function(p) {
        o || (o = u()), s.indexOf(p) === -1 && s.push(p);
      }, h = function() {
        o && o.parentNode && (o.contentDocument && o.contentDocument.defaultView.removeEventListener("resize", l), o.parentNode.removeChild(o), i.removeAttribute(t.SizeSensorId), o = void 0, s = [], a && a());
      }, c = function(p) {
        var y = s.indexOf(p);
        y !== -1 && s.splice(y, 1), s.length === 0 && o && h();
      };
      return {
        element: i,
        bind: f,
        destroy: h,
        unbind: c
      };
    }, $n;
  }
  var Zn = {}, th;
  function Fy() {
    if (th) return Zn;
    th = 1, Object.defineProperty(Zn, "__esModule", {
      value: true
    }), Zn.createSensor = void 0;
    var e = El(), t = r(Ip());
    function r(n) {
      return n && n.__esModule ? n : {
        default: n
      };
    }
    return Zn.createSensor = function(i, a) {
      var o = void 0, s = [], u = (0, t.default)(function() {
        s.forEach(function(v) {
          v(i);
        });
      }), l = function() {
        var p = new ResizeObserver(u);
        return p.observe(i), u(), p;
      }, f = function(p) {
        o || (o = l()), s.indexOf(p) === -1 && s.push(p);
      }, h = function() {
        o && o.disconnect(), s = [], o = void 0, i.removeAttribute(e.SizeSensorId), a && a();
      }, c = function(p) {
        var y = s.indexOf(p);
        y !== -1 && s.splice(y, 1), s.length === 0 && o && h();
      };
      return {
        element: i,
        bind: f,
        destroy: h,
        unbind: c
      };
    }, Zn;
  }
  var eh;
  function By() {
    if (eh) return Xn;
    eh = 1, Object.defineProperty(Xn, "__esModule", {
      value: true
    }), Xn.createSensor = void 0;
    var e = Ny(), t = Fy();
    return Xn.createSensor = typeof ResizeObserver < "u" ? t.createSensor : e.createSensor, Xn;
  }
  var rh;
  function zy() {
    if (rh) return ze;
    rh = 1, Object.defineProperty(ze, "__esModule", {
      value: true
    }), ze.removeSensor = ze.getSensor = ze.Sensors = void 0;
    var e = n(ky()), t = By(), r = El();
    function n(o) {
      return o && o.__esModule ? o : {
        default: o
      };
    }
    var i = ze.Sensors = {};
    function a(o) {
      o && i[o] && delete i[o];
    }
    return ze.getSensor = function(s) {
      var u = s.getAttribute(r.SizeSensorId);
      if (u && i[u]) return i[u];
      var l = (0, e.default)();
      s.setAttribute(r.SizeSensorId, l);
      var f = (0, t.createSensor)(s, function() {
        return a(l);
      });
      return i[l] = f, f;
    }, ze.removeSensor = function(s) {
      var u = s.element.getAttribute(r.SizeSensorId);
      s.destroy(), a(u);
    }, ze;
  }
  var nh;
  function Vy() {
    if (nh) return Be;
    nh = 1, Object.defineProperty(Be, "__esModule", {
      value: true
    }), Be.ver = Be.clear = Be.bind = void 0;
    var e = zy();
    return Be.bind = function(r, n) {
      var i = (0, e.getSensor)(r);
      return i.bind(n), function() {
        i.unbind(n);
      };
    }, Be.clear = function(r) {
      var n = (0, e.getSensor)(r);
      (0, e.removeSensor)(n);
    }, Be.ver = "1.0.3", Be;
  }
  var Kn = {}, ih;
  function Gy() {
    if (ih) return Kn;
    ih = 1, Object.defineProperty(Kn, "__esModule", {
      value: true
    }), Kn.pick = void 0;
    function e(t, r) {
      var n = {};
      return r.forEach(function(i) {
        n[i] = t[i];
      }), n;
    }
    return Kn.pick = e, Kn;
  }
  var jn = {}, ah;
  function Hy() {
    if (ah) return jn;
    ah = 1, Object.defineProperty(jn, "__esModule", {
      value: true
    }), jn.isFunction = void 0;
    function e(t) {
      return typeof t == "function";
    }
    return jn.isFunction = e, jn;
  }
  var Qn = {}, oh;
  function Uy() {
    if (oh) return Qn;
    oh = 1, Object.defineProperty(Qn, "__esModule", {
      value: true
    }), Qn.isString = void 0;
    function e(t) {
      return typeof t == "string";
    }
    return Qn.isString = e, Qn;
  }
  var Jn = {}, bs, sh;
  function Wy() {
    return sh || (sh = 1, bs = function e(t, r) {
      if (t === r) return true;
      if (t && r && typeof t == "object" && typeof r == "object") {
        if (t.constructor !== r.constructor) return false;
        var n, i, a;
        if (Array.isArray(t)) {
          if (n = t.length, n != r.length) return false;
          for (i = n; i-- !== 0; ) if (!e(t[i], r[i])) return false;
          return true;
        }
        if (t.constructor === RegExp) return t.source === r.source && t.flags === r.flags;
        if (t.valueOf !== Object.prototype.valueOf) return t.valueOf() === r.valueOf();
        if (t.toString !== Object.prototype.toString) return t.toString() === r.toString();
        if (a = Object.keys(t), n = a.length, n !== Object.keys(r).length) return false;
        for (i = n; i-- !== 0; ) if (!Object.prototype.hasOwnProperty.call(r, a[i])) return false;
        for (i = n; i-- !== 0; ) {
          var o = a[i];
          if (!e(t[o], r[o])) return false;
        }
        return true;
      }
      return t !== t && r !== r;
    }), bs;
  }
  var uh;
  function Yy() {
    if (uh) return Jn;
    uh = 1, Object.defineProperty(Jn, "__esModule", {
      value: true
    }), Jn.isEqual = void 0;
    var e = Pp, t = e.__importDefault(Wy());
    return Jn.isEqual = t.default, Jn;
  }
  Object.defineProperty(xp, "__esModule", {
    value: true
  });
  let Ce, lh, fh, hh, ws, qy, sn, Xy;
  Ce = Pp;
  lh = Ce.__importStar(Oy);
  fh = Vy();
  hh = Gy();
  ws = Hy();
  qy = Uy();
  sn = Yy();
  Xy = (function(e) {
    Ce.__extends(t, e);
    function t(r) {
      var n = e.call(this, r) || this;
      return n.echarts = r.echarts, n.ele = null, n.isInitialResize = true, n.eventHandlerRefs = {}, n;
    }
    return t.prototype.componentDidMount = function() {
      this.renderNewEcharts();
    }, t.prototype.componentDidUpdate = function(r) {
      var n = this.props.shouldSetOption;
      if (!((0, ws.isFunction)(n) && !n(r, this.props))) {
        if (!(0, sn.isEqual)(r.theme, this.props.theme) || !(0, sn.isEqual)(r.opts, this.props.opts)) {
          this.dispose(), this.renderNewEcharts();
          return;
        }
        var i = this.getEchartsInstance();
        (0, sn.isEqual)(r.onEvents, this.props.onEvents) || (this.unbindEvents(i), this.bindEvents(i, this.props.onEvents));
        var a = [
          "option",
          "notMerge",
          "replaceMerge",
          "lazyUpdate",
          "showLoading",
          "loadingOption"
        ];
        (0, sn.isEqual)((0, hh.pick)(this.props, a), (0, hh.pick)(r, a)) || this.updateEChartsOption(), (!(0, sn.isEqual)(r.style, this.props.style) || !(0, sn.isEqual)(r.className, this.props.className)) && this.resize();
      }
    }, t.prototype.componentWillUnmount = function() {
      this.dispose();
    }, t.prototype.initEchartsInstance = function() {
      return Ce.__awaiter(this, void 0, void 0, function() {
        var r = this;
        return Ce.__generator(this, function(n) {
          return [
            2,
            new Promise(function(i) {
              r.echarts.init(r.ele, r.props.theme, r.props.opts);
              var a = r.getEchartsInstance();
              a.on("finished", function() {
                var o = r.ele.clientWidth, s = r.ele.clientHeight;
                r.echarts.dispose(r.ele);
                var u = Ce.__assign({
                  width: o,
                  height: s
                }, r.props.opts);
                i(r.echarts.init(r.ele, r.props.theme, u));
              });
            })
          ];
        });
      });
    }, t.prototype.getEchartsInstance = function() {
      return this.echarts.getInstanceByDom(this.ele);
    }, t.prototype.dispose = function() {
      if (this.ele) {
        try {
          (0, fh.clear)(this.ele);
        } catch (r) {
          console.warn(r);
        }
        this.echarts.dispose(this.ele);
      }
    }, t.prototype.renderNewEcharts = function() {
      return Ce.__awaiter(this, void 0, void 0, function() {
        var r, n, i, a, o, s, u = this;
        return Ce.__generator(this, function(l) {
          switch (l.label) {
            case 0:
              return r = this.props, n = r.onEvents, i = r.onChartReady, a = r.autoResize, o = a === void 0 ? true : a, [
                4,
                this.initEchartsInstance()
              ];
            case 1:
              return l.sent(), s = this.updateEChartsOption(), this.bindEvents(s, n || {}), (0, ws.isFunction)(i) && i(s), this.ele && o && (0, fh.bind)(this.ele, function() {
                u.resize();
              }), [
                2
              ];
          }
        });
      });
    }, t.prototype.bindEvents = function(r, n) {
      var i = this, a = function(s, u) {
        if ((0, qy.isString)(s) && (0, ws.isFunction)(u)) {
          var l = function(f) {
            u(f, r);
          };
          r.on(s, l), i.eventHandlerRefs[s] = l;
        }
      };
      for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && a(o, n[o]);
    }, t.prototype.unbindEvents = function(r) {
      for (var n = 0, i = Object.entries(this.eventHandlerRefs); n < i.length; n++) {
        var a = i[n], o = a[0], s = a[1];
        r.off(o, s);
      }
      this.eventHandlerRefs = {};
    }, t.prototype.updateEChartsOption = function() {
      var r = this.props, n = r.option, i = r.notMerge, a = i === void 0 ? false : i, o = r.replaceMerge, s = o === void 0 ? null : o, u = r.lazyUpdate, l = u === void 0 ? false : u, f = r.showLoading, h = r.loadingOption, c = h === void 0 ? null : h, v = this.getEchartsInstance();
      return v.setOption(n, {
        notMerge: a,
        replaceMerge: s,
        lazyUpdate: l
      }), f ? v.showLoading(c) : v.hideLoading(), v;
    }, t.prototype.resize = function() {
      var r = this.getEchartsInstance();
      if (!this.isInitialResize) try {
        r.resize({
          width: "auto",
          height: "auto"
        });
      } catch (n) {
        console.warn(n);
      }
      this.isInitialResize = false;
    }, t.prototype.render = function() {
      var r = this, n = this.props, i = n.style, a = n.className, o = a === void 0 ? "" : a;
      n.echarts, n.option, n.theme, n.notMerge, n.replaceMerge, n.lazyUpdate, n.showLoading, n.loadingOption, n.opts, n.onChartReady, n.onEvents, n.shouldSetOption, n.autoResize;
      var s = Ce.__rest(n, [
        "style",
        "className",
        "echarts",
        "option",
        "theme",
        "notMerge",
        "replaceMerge",
        "lazyUpdate",
        "showLoading",
        "loadingOption",
        "opts",
        "onChartReady",
        "onEvents",
        "shouldSetOption",
        "autoResize"
      ]), u = Ce.__assign({
        height: 300
      }, i);
      return lh.default.createElement("div", Ce.__assign({
        ref: function(l) {
          r.ele = l;
        },
        style: u,
        className: "echarts-for-react ".concat(o)
      }, s));
    }, t;
  })(lh.PureComponent);
  V2 = xp.default = Xy;
  var Ou = function(e, t) {
    return Ou = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function(r, n) {
      r.__proto__ = n;
    } || function(r, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (r[i] = n[i]);
    }, Ou(e, t);
  };
  ft = function(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
    Ou(e, t);
    function r() {
      this.constructor = e;
    }
    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, new r());
  };
  let $y, Zy;
  $y = /* @__PURE__ */ (function() {
    function e() {
      this.firefox = false, this.ie = false, this.edge = false, this.newEdge = false, this.weChat = false;
    }
    return e;
  })();
  Zy = /* @__PURE__ */ (function() {
    function e() {
      this.browser = new $y(), this.node = false, this.wxa = false, this.worker = false, this.svgSupported = false, this.touchEventsSupported = false, this.pointerEventsSupported = false, this.domSupported = false, this.transformSupported = false, this.transform3dSupported = false, this.hasGlobalWindow = typeof window < "u";
    }
    return e;
  })();
  j = new Zy();
  typeof wx == "object" && typeof wx.getSystemInfoSync == "function" ? (j.wxa = true, j.touchEventsSupported = true) : typeof document > "u" && typeof self < "u" ? j.worker = true : !j.hasGlobalWindow || "Deno" in window ? (j.node = true, j.svgSupported = true) : Ky(navigator.userAgent, j);
  function Ky(e, t) {
    var r = t.browser, n = e.match(/Firefox\/([\d.]+)/), i = e.match(/MSIE\s([\d.]+)/) || e.match(/Trident\/.+?rv:(([\d.]+))/), a = e.match(/Edge?\/([\d.]+)/), o = /micromessenger/i.test(e);
    n && (r.firefox = true, r.version = n[1]), i && (r.ie = true, r.version = i[1]), a && (r.edge = true, r.version = a[1], r.newEdge = +a[1].split(".")[0] > 18), o && (r.weChat = true), t.svgSupported = typeof SVGRect < "u", t.touchEventsSupported = "ontouchstart" in window && !r.ie && !r.edge, t.pointerEventsSupported = "onpointerdown" in window && (r.edge || r.ie && +r.version >= 11), t.domSupported = typeof document < "u";
    var s = document.documentElement.style;
    t.transform3dSupported = (r.ie && "transition" in s || r.edge || "WebKitCSSMatrix" in window && "m11" in new WebKitCSSMatrix() || "MozPerspective" in s) && !("OTransition" in s), t.transformSupported = t.transform3dSupported || r.ie && +r.version >= 9;
  }
  var Ll = 12, Ap = "sans-serif", pr = Ll + "px " + Ap, jy = 20, Qy = 100, Jy = "007LLmW'55;N0500LLLLLLLLLL00NNNLzWW\\\\WQb\\0FWLg\\bWb\\WQ\\WrWWQ000CL5LLFLL0LL**F*gLLLL5F0LF\\FFF5.5N";
  function tm(e) {
    var t = {};
    if (typeof JSON > "u") return t;
    for (var r = 0; r < e.length; r++) {
      var n = String.fromCharCode(r + 32), i = (e.charCodeAt(r) - jy) / Qy;
      t[n] = i;
    }
    return t;
  }
  let em;
  em = tm(Jy);
  dr = {
    createCanvas: function() {
      return typeof document < "u" && document.createElement("canvas");
    },
    measureText: /* @__PURE__ */ (function() {
      var e, t;
      return function(r, n) {
        if (!e) {
          var i = dr.createCanvas();
          e = i && i.getContext("2d");
        }
        if (e) return t !== n && (t = e.font = n || pr), e.measureText(r);
        r = r || "", n = n || pr;
        var a = /((?:\d+)?\.?\d*)px/.exec(n), o = a && +a[1] || Ll, s = 0;
        if (n.indexOf("mono") >= 0) s = o * r.length;
        else for (var u = 0; u < r.length; u++) {
          var l = em[r[u]];
          s += l == null ? o : l * o;
        }
        return {
          width: s
        };
      };
    })(),
    loadImage: function(e, t, r) {
      var n = new Image();
      return n.onload = t, n.onerror = r, n.src = e, n;
    }
  };
  function Ep(e) {
    for (var t in dr) e[t] && (dr[t] = e[t]);
  }
  var Lp = Le([
    "Function",
    "RegExp",
    "Date",
    "Error",
    "CanvasGradient",
    "CanvasPattern",
    "Image",
    "Canvas"
  ], function(e, t) {
    return e["[object " + t + "]"] = true, e;
  }, {}), Rp = Le([
    "Int8",
    "Uint8",
    "Uint8Clamped",
    "Int16",
    "Uint16",
    "Int32",
    "Uint32",
    "Float32",
    "Float64"
  ], function(e, t) {
    return e["[object " + t + "Array]"] = true, e;
  }, {}), zn = Object.prototype.toString, Ro = Array.prototype, rm = Ro.forEach, nm = Ro.filter, Rl = Ro.slice, im = Ro.map, vh = function() {
  }.constructor, la = vh ? vh.prototype : null, Ol = "__proto__", am = 2311;
  function kl() {
    return am++;
  }
  Nl = function() {
    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
    typeof console < "u" && console.error.apply(console, e);
  };
  Z = function(e) {
    if (e == null || typeof e != "object") return e;
    var t = e, r = zn.call(e);
    if (r === "[object Array]") {
      if (!Pn(e)) {
        t = [];
        for (var n = 0, i = e.length; n < i; n++) t[n] = Z(e[n]);
      }
    } else if (Rp[r]) {
      if (!Pn(e)) {
        var a = e.constructor;
        if (a.from) t = a.from(e);
        else {
          t = new a(e.length);
          for (var n = 0, i = e.length; n < i; n++) t[n] = e[n];
        }
      }
    } else if (!Lp[r] && !Pn(e) && !io(e)) {
      t = {};
      for (var o in e) e.hasOwnProperty(o) && o !== Ol && (t[o] = Z(e[o]));
    }
    return t;
  };
  ct = function(e, t, r) {
    if (!G(t) || !G(e)) return r ? Z(t) : e;
    for (var n in t) if (t.hasOwnProperty(n) && n !== Ol) {
      var i = e[n], a = t[n];
      G(a) && G(i) && !B(a) && !B(i) && !io(a) && !io(i) && !ku(a) && !ku(i) && !Pn(a) && !Pn(i) ? ct(i, a, r) : (r || !(n in e)) && (e[n] = Z(t[n]));
    }
    return e;
  };
  function om(e, t) {
    for (var r = e[0], n = 1, i = e.length; n < i; n++) r = ct(r, e[n], t);
    return r;
  }
  O = function(e, t) {
    if (Object.assign) Object.assign(e, t);
    else for (var r in t) t.hasOwnProperty(r) && r !== Ol && (e[r] = t[r]);
    return e;
  };
  ht = function(e, t, r) {
    for (var n = K(t), i = 0, a = n.length; i < a; i++) {
      var o = n[i];
      (r ? t[o] != null : e[o] == null) && (e[o] = t[o]);
    }
    return e;
  };
  var sm = dr.createCanvas;
  vt = function(e, t) {
    if (e) {
      if (e.indexOf) return e.indexOf(t);
      for (var r = 0, n = e.length; r < n; r++) if (e[r] === t) return r;
    }
    return -1;
  };
  function Fl(e, t) {
    var r = e.prototype;
    function n() {
    }
    n.prototype = t.prototype, e.prototype = new n();
    for (var i in r) r.hasOwnProperty(i) && (e.prototype[i] = r[i]);
    e.prototype.constructor = e, e.superClass = t;
  }
  ae = function(e, t, r) {
    if (e = "prototype" in e ? e.prototype : e, t = "prototype" in t ? t.prototype : t, Object.getOwnPropertyNames) for (var n = Object.getOwnPropertyNames(t), i = 0; i < n.length; i++) {
      var a = n[i];
      a !== "constructor" && (r ? t[a] != null : e[a] == null) && (e[a] = t[a]);
    }
    else ht(e, t, r);
  };
  function Rt(e) {
    return !e || typeof e == "string" ? false : typeof e.length == "number";
  }
  P = function(e, t, r) {
    if (e && t) if (e.forEach && e.forEach === rm) e.forEach(t, r);
    else if (e.length === +e.length) for (var n = 0, i = e.length; n < i; n++) t.call(r, e[n], n, e);
    else for (var a in e) e.hasOwnProperty(a) && t.call(r, e[a], a, e);
  };
  F = function(e, t, r) {
    if (!e) return [];
    if (!t) return ko(e);
    if (e.map && e.map === im) return e.map(t, r);
    for (var n = [], i = 0, a = e.length; i < a; i++) n.push(t.call(r, e[i], i, e));
    return n;
  };
  function Le(e, t, r, n) {
    if (e && t) {
      for (var i = 0, a = e.length; i < a; i++) r = t.call(n, r, e[i], i, e);
      return r;
    }
  }
  yt = function(e, t, r) {
    if (!e) return [];
    if (!t) return ko(e);
    if (e.filter && e.filter === nm) return e.filter(t, r);
    for (var n = [], i = 0, a = e.length; i < a; i++) t.call(r, e[i], i, e) && n.push(e[i]);
    return n;
  };
  function um(e, t, r) {
    if (e && t) {
      for (var n = 0, i = e.length; n < i; n++) if (t.call(r, e[n], n, e)) return e[n];
    }
  }
  K = function(e) {
    if (!e) return [];
    if (Object.keys) return Object.keys(e);
    var t = [];
    for (var r in e) e.hasOwnProperty(r) && t.push(r);
    return t;
  };
  function lm(e, t) {
    for (var r = [], n = 2; n < arguments.length; n++) r[n - 2] = arguments[n];
    return function() {
      return e.apply(t, r.concat(Rl.call(arguments)));
    };
  }
  Y=value=>typeof value === "function";ut = la && Y(la.bind) ? la.call.bind(la.bind) : lm;
  Vn = function(e) {
    for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
    return function() {
      return e.apply(this, t.concat(Rl.call(arguments)));
    };
  };
  B = function(e) {
    return Array.isArray ? Array.isArray(e) : zn.call(e) === "[object Array]";
  };
  Y = function(e) {
    return typeof e == "function";
  };
  V = function(e) {
    return typeof e == "string";
  };
  function no(e) {
    return zn.call(e) === "[object String]";
  }
  lt = function(e) {
    return typeof e == "number";
  };
  G = function(e) {
    var t = typeof e;
    return t === "function" || !!e && t === "object";
  };
  function ku(e) {
    return !!Lp[zn.call(e)];
  }
  function Ot(e) {
    return !!Rp[zn.call(e)];
  }
  io = function(e) {
    return typeof e == "object" && typeof e.nodeType == "number" && typeof e.ownerDocument == "object";
  };
  Oo = function(e) {
    return e.colorStops != null;
  };
  fm = function(e) {
    return e.image != null;
  };
  function hm(e) {
    return zn.call(e) === "[object RegExp]";
  }
  function Bi(e) {
    return e !== e;
  }
  vm = function() {
    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
    for (var r = 0, n = e.length; r < n; r++) if (e[r] != null) return e[r];
  };
  W = function(e, t) {
    return e ?? t;
  };
  function Ci(e, t, r) {
    return e ?? t ?? r;
  }
  function ko(e) {
    for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
    return Rl.apply(e, t);
  }
  function Bl(e) {
    if (typeof e == "number") return [
      e,
      e,
      e,
      e
    ];
    var t = e.length;
    return t === 2 ? [
      e[0],
      e[1],
      e[0],
      e[1]
    ] : t === 3 ? [
      e[0],
      e[1],
      e[2],
      e[1]
    ] : e;
  }
  function $t(e, t) {
    if (!e) throw new Error(t);
  }
  Ie = function(e) {
    return e == null ? null : typeof e.trim == "function" ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
  };
  var Op = "__ec_primitive__";
  function ao(e) {
    e[Op] = true;
  }
  function Pn(e) {
    return e[Op];
  }
  var cm = (function() {
    function e() {
      this.data = {};
    }
    return e.prototype.delete = function(t) {
      var r = this.has(t);
      return r && delete this.data[t], r;
    }, e.prototype.has = function(t) {
      return this.data.hasOwnProperty(t);
    }, e.prototype.get = function(t) {
      return this.data[t];
    }, e.prototype.set = function(t, r) {
      return this.data[t] = r, this;
    }, e.prototype.keys = function() {
      return K(this.data);
    }, e.prototype.forEach = function(t) {
      var r = this.data;
      for (var n in r) r.hasOwnProperty(n) && t(r[n], n);
    }, e;
  })(), kp = typeof Map == "function";
  function pm() {
    return kp ? /* @__PURE__ */ new Map() : new cm();
  }
  var Np = (function() {
    function e(t) {
      var r = B(t);
      this.data = pm();
      var n = this;
      t instanceof e ? t.each(i) : t && P(t, i);
      function i(a, o) {
        r ? n.set(a, o) : n.set(o, a);
      }
    }
    return e.prototype.hasKey = function(t) {
      return this.data.has(t);
    }, e.prototype.get = function(t) {
      return this.data.get(t);
    }, e.prototype.set = function(t, r) {
      return this.data.set(t, r), r;
    }, e.prototype.each = function(t, r) {
      this.data.forEach(function(n, i) {
        t.call(r, n, i);
      });
    }, e.prototype.keys = function() {
      var t = this.data.keys();
      return kp ? Array.from(t) : t;
    }, e.prototype.removeKey = function(t) {
      this.data.delete(t);
    }, e;
  })();
  q = function(e) {
    return new Np(e);
  };
  function Fp(e, t) {
    for (var r = new e.constructor(e.length + t.length), n = 0; n < e.length; n++) r[n] = e[n];
    for (var i = e.length, n = 0; n < t.length; n++) r[n + i] = t[n];
    return r;
  }
  function ea(e, t) {
    var r;
    if (Object.create) r = Object.create(e);
    else {
      var n = function() {
      };
      n.prototype = e, r = new n();
    }
    return t && O(r, t), r;
  }
  dm = function(e) {
    var t = e.style;
    t.webkitUserSelect = "none", t.userSelect = "none", t.webkitTapHighlightColor = "rgba(0,0,0,0)", t["-webkit-touch-callout"] = "none";
  };
  tn = function(e, t) {
    return e.hasOwnProperty(t);
  };
  zt = function() {
  };
  var Di = 180 / Math.PI;
  const gm = Object.freeze(Object.defineProperty({
    __proto__: null,
    HashMap: Np,
    RADIAN_TO_DEGREE: Di,
    assert: $t,
    bind: ut,
    clone: Z,
    concatArray: Fp,
    createCanvas: sm,
    createHashMap: q,
    createObject: ea,
    curry: Vn,
    defaults: ht,
    disableUserSelect: dm,
    each: P,
    eqNaN: Bi,
    extend: O,
    filter: yt,
    find: um,
    guid: kl,
    hasOwn: tn,
    indexOf: vt,
    inherits: Fl,
    isArray: B,
    isArrayLike: Rt,
    isBuiltInObject: ku,
    isDom: io,
    isFunction: Y,
    isGradientObject: Oo,
    isImagePatternObject: fm,
    isNumber: lt,
    isObject: G,
    isPrimitive: Pn,
    isRegExp: hm,
    isString: V,
    isStringSafe: no,
    isTypedArray: Ot,
    keys: K,
    logError: Nl,
    map: F,
    merge: ct,
    mergeAll: om,
    mixin: ae,
    noop: zt,
    normalizeCssArray: Bl,
    reduce: Le,
    retrieve: vm,
    retrieve2: W,
    retrieve3: Ci,
    setAsPrimitive: ao,
    slice: ko,
    trim: Ie
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  var Nu = function(e, t) {
    return Nu = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function(r, n) {
      r.__proto__ = n;
    } || function(r, n) {
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (r[i] = n[i]);
    }, Nu(e, t);
  };
  ot = function(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
    Nu(e, t);
    function r() {
      this.constructor = e;
    }
    e.prototype = t === null ? Object.create(t) : (r.prototype = t.prototype, new r());
  };
  function nn(e, t) {
    return e == null && (e = 0), t == null && (t = 0), [
      e,
      t
    ];
  }
  function ym(e, t) {
    return e[0] = t[0], e[1] = t[1], e;
  }
  function Bp(e) {
    return [
      e[0],
      e[1]
    ];
  }
  function mm(e, t, r) {
    return e[0] = t, e[1] = r, e;
  }
  function Fu(e, t, r) {
    return e[0] = t[0] + r[0], e[1] = t[1] + r[1], e;
  }
  function _m(e, t, r, n) {
    return e[0] = t[0] + r[0] * n, e[1] = t[1] + r[1] * n, e;
  }
  function zp(e, t, r) {
    return e[0] = t[0] - r[0], e[1] = t[1] - r[1], e;
  }
  function zl(e) {
    return Math.sqrt(Vl(e));
  }
  var Sm = zl;
  function Vl(e) {
    return e[0] * e[0] + e[1] * e[1];
  }
  var bm = Vl;
  function wm(e, t, r) {
    return e[0] = t[0] * r[0], e[1] = t[1] * r[1], e;
  }
  function Tm(e, t, r) {
    return e[0] = t[0] / r[0], e[1] = t[1] / r[1], e;
  }
  function Mm(e, t) {
    return e[0] * t[0] + e[1] * t[1];
  }
  function Wa(e, t, r) {
    return e[0] = t[0] * r, e[1] = t[1] * r, e;
  }
  function Vp(e, t) {
    var r = zl(t);
    return r === 0 ? (e[0] = 0, e[1] = 0) : (e[0] = t[0] / r, e[1] = t[1] / r), e;
  }
  function oo(e, t) {
    return Math.sqrt((e[0] - t[0]) * (e[0] - t[0]) + (e[1] - t[1]) * (e[1] - t[1]));
  }
  var Gp = oo;
  function Hp(e, t) {
    return (e[0] - t[0]) * (e[0] - t[0]) + (e[1] - t[1]) * (e[1] - t[1]);
  }
  var $r = Hp;
  function Cm(e, t) {
    return e[0] = -t[0], e[1] = -t[1], e;
  }
  function Dm(e, t, r, n) {
    return e[0] = t[0] + n * (r[0] - t[0]), e[1] = t[1] + n * (r[1] - t[1]), e;
  }
  Ye = function(e, t, r) {
    var n = t[0], i = t[1];
    return e[0] = r[0] * n + r[2] * i + r[4], e[1] = r[1] * n + r[3] * i + r[5], e;
  };
  function or(e, t, r) {
    return e[0] = Math.min(t[0], r[0]), e[1] = Math.min(t[1], r[1]), e;
  }
  function sr(e, t, r) {
    return e[0] = Math.max(t[0], r[0]), e[1] = Math.max(t[1], r[1]), e;
  }
  const xm = Object.freeze(Object.defineProperty({
    __proto__: null,
    add: Fu,
    applyTransform: Ye,
    clone: Bp,
    copy: ym,
    create: nn,
    dist: Gp,
    distSquare: $r,
    distance: oo,
    distanceSquare: Hp,
    div: Tm,
    dot: Mm,
    len: zl,
    lenSquare: Vl,
    length: Sm,
    lengthSquare: bm,
    lerp: Dm,
    max: sr,
    min: or,
    mul: wm,
    negate: Cm,
    normalize: Vp,
    scale: Wa,
    scaleAndAdd: _m,
    set: mm,
    sub: zp
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  let un, Pm, Im;
  un = /* @__PURE__ */ (function() {
    function e(t, r) {
      this.target = t, this.topTarget = r && r.topTarget;
    }
    return e;
  })();
  Pm = (function() {
    function e(t) {
      this.handler = t, t.on("mousedown", this._dragStart, this), t.on("mousemove", this._drag, this), t.on("mouseup", this._dragEnd, this);
    }
    return e.prototype._dragStart = function(t) {
      for (var r = t.target; r && !r.draggable; ) r = r.parent || r.__hostTarget;
      r && (this._draggingTarget = r, r.dragging = true, this._x = t.offsetX, this._y = t.offsetY, this.handler.dispatchToElement(new un(r, t), "dragstart", t.event));
    }, e.prototype._drag = function(t) {
      var r = this._draggingTarget;
      if (r) {
        var n = t.offsetX, i = t.offsetY, a = n - this._x, o = i - this._y;
        this._x = n, this._y = i, r.drift(a, o, t), this.handler.dispatchToElement(new un(r, t), "drag", t.event);
        var s = this.handler.findHover(n, i, r).target, u = this._dropTarget;
        this._dropTarget = s, r !== s && (u && s !== u && this.handler.dispatchToElement(new un(u, t), "dragleave", t.event), s && s !== u && this.handler.dispatchToElement(new un(s, t), "dragenter", t.event));
      }
    }, e.prototype._dragEnd = function(t) {
      var r = this._draggingTarget;
      r && (r.dragging = false), this.handler.dispatchToElement(new un(r, t), "dragend", t.event), this._dropTarget && this.handler.dispatchToElement(new un(this._dropTarget, t), "drop", t.event), this._draggingTarget = null, this._dropTarget = null;
    }, e;
  })();
  $e = (function() {
    function e(t) {
      t && (this._$eventProcessor = t);
    }
    return e.prototype.on = function(t, r, n, i) {
      this._$handlers || (this._$handlers = {});
      var a = this._$handlers;
      if (typeof r == "function" && (i = n, n = r, r = null), !n || !t) return this;
      var o = this._$eventProcessor;
      r != null && o && o.normalizeQuery && (r = o.normalizeQuery(r)), a[t] || (a[t] = []);
      for (var s = 0; s < a[t].length; s++) if (a[t][s].h === n) return this;
      var u = {
        h: n,
        query: r,
        ctx: i || this,
        callAtLast: n.zrEventfulCallAtLast
      }, l = a[t].length - 1, f = a[t][l];
      return f && f.callAtLast ? a[t].splice(l, 0, u) : a[t].push(u), this;
    }, e.prototype.isSilent = function(t) {
      var r = this._$handlers;
      return !r || !r[t] || !r[t].length;
    }, e.prototype.off = function(t, r) {
      var n = this._$handlers;
      if (!n) return this;
      if (!t) return this._$handlers = {}, this;
      if (r) {
        if (n[t]) {
          for (var i = [], a = 0, o = n[t].length; a < o; a++) n[t][a].h !== r && i.push(n[t][a]);
          n[t] = i;
        }
        n[t] && n[t].length === 0 && delete n[t];
      } else delete n[t];
      return this;
    }, e.prototype.trigger = function(t) {
      for (var r = [], n = 1; n < arguments.length; n++) r[n - 1] = arguments[n];
      if (!this._$handlers) return this;
      var i = this._$handlers[t], a = this._$eventProcessor;
      if (i) for (var o = r.length, s = i.length, u = 0; u < s; u++) {
        var l = i[u];
        if (!(a && a.filter && l.query != null && !a.filter(t, l.query))) switch (o) {
          case 0:
            l.h.call(l.ctx);
            break;
          case 1:
            l.h.call(l.ctx, r[0]);
            break;
          case 2:
            l.h.call(l.ctx, r[0], r[1]);
            break;
          default:
            l.h.apply(l.ctx, r);
            break;
        }
      }
      return a && a.afterTrigger && a.afterTrigger(t), this;
    }, e.prototype.triggerWithContext = function(t) {
      for (var r = [], n = 1; n < arguments.length; n++) r[n - 1] = arguments[n];
      if (!this._$handlers) return this;
      var i = this._$handlers[t], a = this._$eventProcessor;
      if (i) for (var o = r.length, s = r[o - 1], u = i.length, l = 0; l < u; l++) {
        var f = i[l];
        if (!(a && a.filter && f.query != null && !a.filter(t, f.query))) switch (o) {
          case 0:
            f.h.call(s);
            break;
          case 1:
            f.h.call(s, r[0]);
            break;
          case 2:
            f.h.call(s, r[0], r[1]);
            break;
          default:
            f.h.apply(s, r.slice(1, o - 1));
            break;
        }
      }
      return a && a.afterTrigger && a.afterTrigger(t), this;
    }, e;
  })();
  Im = Math.log(2);
  function Bu(e, t, r, n, i, a) {
    var o = n + "-" + i, s = e.length;
    if (a.hasOwnProperty(o)) return a[o];
    if (t === 1) {
      var u = Math.round(Math.log((1 << s) - 1 & ~i) / Im);
      return e[r][u];
    }
    for (var l = n | 1 << r, f = r + 1; n & 1 << f; ) f++;
    for (var h = 0, c = 0, v = 0; c < s; c++) {
      var p = 1 << c;
      p & i || (h += (v % 2 ? -1 : 1) * e[r][c] * Bu(e, t - 1, f, l, i | p, a), v++);
    }
    return a[o] = h, h;
  }
  function ch(e, t) {
    var r = [
      [
        e[0],
        e[1],
        1,
        0,
        0,
        0,
        -t[0] * e[0],
        -t[0] * e[1]
      ],
      [
        0,
        0,
        0,
        e[0],
        e[1],
        1,
        -t[1] * e[0],
        -t[1] * e[1]
      ],
      [
        e[2],
        e[3],
        1,
        0,
        0,
        0,
        -t[2] * e[2],
        -t[2] * e[3]
      ],
      [
        0,
        0,
        0,
        e[2],
        e[3],
        1,
        -t[3] * e[2],
        -t[3] * e[3]
      ],
      [
        e[4],
        e[5],
        1,
        0,
        0,
        0,
        -t[4] * e[4],
        -t[4] * e[5]
      ],
      [
        0,
        0,
        0,
        e[4],
        e[5],
        1,
        -t[5] * e[4],
        -t[5] * e[5]
      ],
      [
        e[6],
        e[7],
        1,
        0,
        0,
        0,
        -t[6] * e[6],
        -t[6] * e[7]
      ],
      [
        0,
        0,
        0,
        e[6],
        e[7],
        1,
        -t[7] * e[6],
        -t[7] * e[7]
      ]
    ], n = {}, i = Bu(r, 8, 0, 0, 0, n);
    if (i !== 0) {
      for (var a = [], o = 0; o < 8; o++) for (var s = 0; s < 8; s++) a[s] == null && (a[s] = 0), a[s] += ((o + s) % 2 ? -1 : 1) * Bu(r, 7, o === 0 ? 1 : 0, 1 << o, 1 << s, n) / i * t[o];
      return function(u, l, f) {
        var h = l * a[6] + f * a[7] + 1;
        u[0] = (l * a[0] + f * a[1] + a[2]) / h, u[1] = (l * a[3] + f * a[4] + a[5]) / h;
      };
    }
  }
  var ph = "___zrEVENTSAVED", Ts = [];
  G2 = function(e, t, r, n, i) {
    return zu(Ts, t, n, i, true) && zu(e, r, Ts[0], Ts[1]);
  };
  function zu(e, t, r, n, i) {
    if (t.getBoundingClientRect && j.domSupported && !Up(t)) {
      var a = t[ph] || (t[ph] = {}), o = Am(t, a), s = Em(o, a, i);
      if (s) return s(e, r, n), true;
    }
    return false;
  }
  function Am(e, t) {
    var r = t.markers;
    if (r) return r;
    r = t.markers = [];
    for (var n = [
      "left",
      "right"
    ], i = [
      "top",
      "bottom"
    ], a = 0; a < 4; a++) {
      var o = document.createElement("div"), s = o.style, u = a % 2, l = (a >> 1) % 2;
      s.cssText = [
        "position: absolute",
        "visibility: hidden",
        "padding: 0",
        "margin: 0",
        "border-width: 0",
        "user-select: none",
        "width:0",
        "height:0",
        n[u] + ":0",
        i[l] + ":0",
        n[1 - u] + ":auto",
        i[1 - l] + ":auto",
        ""
      ].join("!important;"), e.appendChild(o), r.push(o);
    }
    return r;
  }
  function Em(e, t, r) {
    for (var n = r ? "invTrans" : "trans", i = t[n], a = t.srcCoords, o = [], s = [], u = true, l = 0; l < 4; l++) {
      var f = e[l].getBoundingClientRect(), h = 2 * l, c = f.left, v = f.top;
      o.push(c, v), u = u && a && c === a[h] && v === a[h + 1], s.push(e[l].offsetLeft, e[l].offsetTop);
    }
    return u && i ? i : (t.srcCoords = o, t[n] = r ? ch(s, o) : ch(o, s));
  }
  function Up(e) {
    return e.nodeName.toUpperCase() === "CANVAS";
  }
  var Lm = /([&<>"'])/g, Rm = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  Et = function(e) {
    return e == null ? "" : (e + "").replace(Lm, function(t, r) {
      return Rm[r];
    });
  };
  var Om = /^(?:mouse|pointer|contextmenu|drag|drop)|click/, Ms = [], km = j.browser.firefox && +j.browser.version.split(".")[0] < 39;
  function Vu(e, t, r, n) {
    return r = r || {}, n ? dh(e, t, r) : km && t.layerX != null && t.layerX !== t.offsetX ? (r.zrX = t.layerX, r.zrY = t.layerY) : t.offsetX != null ? (r.zrX = t.offsetX, r.zrY = t.offsetY) : dh(e, t, r), r;
  }
  function dh(e, t, r) {
    if (j.domSupported && e.getBoundingClientRect) {
      var n = t.clientX, i = t.clientY;
      if (Up(e)) {
        var a = e.getBoundingClientRect();
        r.zrX = n - a.left, r.zrY = i - a.top;
        return;
      } else if (zu(Ms, e, n, i)) {
        r.zrX = Ms[0], r.zrY = Ms[1];
        return;
      }
    }
    r.zrX = r.zrY = 0;
  }
  function Gl(e) {
    return e || window.event;
  }
  pe = function(e, t, r) {
    if (t = Gl(t), t.zrX != null) return t;
    var n = t.type, i = n && n.indexOf("touch") >= 0;
    if (i) {
      var o = n !== "touchend" ? t.targetTouches[0] : t.changedTouches[0];
      o && Vu(e, o, t, r);
    } else {
      Vu(e, t, t, r);
      var a = Nm(t);
      t.zrDelta = a ? a / 120 : -(t.detail || 0) / 3;
    }
    var s = t.button;
    return t.which == null && s !== void 0 && Om.test(t.type) && (t.which = s & 1 ? 1 : s & 2 ? 3 : s & 4 ? 2 : 0), t;
  };
  function Nm(e) {
    var t = e.wheelDelta;
    if (t) return t;
    var r = e.deltaX, n = e.deltaY;
    if (r == null || n == null) return t;
    var i = Math.abs(n !== 0 ? n : r), a = n > 0 ? -1 : n < 0 ? 1 : r > 0 ? -1 : 1;
    return 3 * i * a;
  }
  Fm = function(e, t, r, n) {
    e.addEventListener(t, r, n);
  };
  function Bm(e, t, r, n) {
    e.removeEventListener(t, r, n);
  }
  let Vm;
  zm = function(e) {
    e.preventDefault(), e.stopPropagation(), e.cancelBubble = true;
  };
  Vm = (function() {
    function e() {
      this._track = [];
    }
    return e.prototype.recognize = function(t, r, n) {
      return this._doTrack(t, r, n), this._recognize(t);
    }, e.prototype.clear = function() {
      return this._track.length = 0, this;
    }, e.prototype._doTrack = function(t, r, n) {
      var i = t.touches;
      if (i) {
        for (var a = {
          points: [],
          touches: [],
          target: r,
          event: t
        }, o = 0, s = i.length; o < s; o++) {
          var u = i[o], l = Vu(n, u, {});
          a.points.push([
            l.zrX,
            l.zrY
          ]), a.touches.push(u);
        }
        this._track.push(a);
      }
    }, e.prototype._recognize = function(t) {
      for (var r in Cs) if (Cs.hasOwnProperty(r)) {
        var n = Cs[r](this._track, t);
        if (n) return n;
      }
    }, e;
  })();
  function gh(e) {
    var t = e[1][0] - e[0][0], r = e[1][1] - e[0][1];
    return Math.sqrt(t * t + r * r);
  }
  function Gm(e) {
    return [
      (e[0][0] + e[1][0]) / 2,
      (e[0][1] + e[1][1]) / 2
    ];
  }
  var Cs = {
    pinch: function(e, t) {
      var r = e.length;
      if (r) {
        var n = (e[r - 1] || {}).points, i = (e[r - 2] || {}).points || n;
        if (i && i.length > 1 && n && n.length > 1) {
          var a = gh(n) / gh(i);
          !isFinite(a) && (a = 1), t.pinchScale = a;
          var o = Gm(n);
          return t.pinchX = o[0], t.pinchY = o[1], {
            type: "pinch",
            target: e[0].target,
            event: t
          };
        }
      }
    }
  };
  hr = function() {
    return [
      1,
      0,
      0,
      1,
      0,
      0
    ];
  };
  No = function(e) {
    return e[0] = 1, e[1] = 0, e[2] = 0, e[3] = 1, e[4] = 0, e[5] = 0, e;
  };
  function Hl(e, t) {
    return e[0] = t[0], e[1] = t[1], e[2] = t[2], e[3] = t[3], e[4] = t[4], e[5] = t[5], e;
  }
  In = function(e, t, r) {
    var n = t[0] * r[0] + t[2] * r[1], i = t[1] * r[0] + t[3] * r[1], a = t[0] * r[2] + t[2] * r[3], o = t[1] * r[2] + t[3] * r[3], s = t[0] * r[4] + t[2] * r[5] + t[4], u = t[1] * r[4] + t[3] * r[5] + t[5];
    return e[0] = n, e[1] = i, e[2] = a, e[3] = o, e[4] = s, e[5] = u, e;
  };
  zi = function(e, t, r) {
    return e[0] = t[0], e[1] = t[1], e[2] = t[2], e[3] = t[3], e[4] = t[4] + r[0], e[5] = t[5] + r[1], e;
  };
  Ul = function(e, t, r, n) {
    n === void 0 && (n = [
      0,
      0
    ]);
    var i = t[0], a = t[2], o = t[4], s = t[1], u = t[3], l = t[5], f = Math.sin(r), h = Math.cos(r);
    return e[0] = i * h + s * f, e[1] = -i * f + s * h, e[2] = a * h + u * f, e[3] = -a * f + h * u, e[4] = h * (o - n[0]) + f * (l - n[1]) + n[0], e[5] = h * (l - n[1]) - f * (o - n[0]) + n[1], e;
  };
  function Wp(e, t, r) {
    var n = r[0], i = r[1];
    return e[0] = t[0] * n, e[1] = t[1] * i, e[2] = t[2] * n, e[3] = t[3] * i, e[4] = t[4] * n, e[5] = t[5] * i, e;
  }
  Fo = function(e, t) {
    var r = t[0], n = t[2], i = t[4], a = t[1], o = t[3], s = t[5], u = r * o - a * n;
    return u ? (u = 1 / u, e[0] = o * u, e[1] = -a * u, e[2] = -n * u, e[3] = r * u, e[4] = (n * s - o * i) * u, e[5] = (a * i - r * s) * u, e) : null;
  };
  function Hm(e) {
    var t = hr();
    return Hl(t, e), t;
  }
  const Um = Object.freeze(Object.defineProperty({
    __proto__: null,
    clone: Hm,
    copy: Hl,
    create: hr,
    identity: No,
    invert: Fo,
    mul: In,
    rotate: Ul,
    scale: Wp,
    translate: zi
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  let it, fa, ha, Sr, br, wr, Tr, ti, ei, Yp;
  it = (function() {
    function e(t, r) {
      this.x = t || 0, this.y = r || 0;
    }
    return e.prototype.copy = function(t) {
      return this.x = t.x, this.y = t.y, this;
    }, e.prototype.clone = function() {
      return new e(this.x, this.y);
    }, e.prototype.set = function(t, r) {
      return this.x = t, this.y = r, this;
    }, e.prototype.equal = function(t) {
      return t.x === this.x && t.y === this.y;
    }, e.prototype.add = function(t) {
      return this.x += t.x, this.y += t.y, this;
    }, e.prototype.scale = function(t) {
      this.x *= t, this.y *= t;
    }, e.prototype.scaleAndAdd = function(t, r) {
      this.x += t.x * r, this.y += t.y * r;
    }, e.prototype.sub = function(t) {
      return this.x -= t.x, this.y -= t.y, this;
    }, e.prototype.dot = function(t) {
      return this.x * t.x + this.y * t.y;
    }, e.prototype.len = function() {
      return Math.sqrt(this.x * this.x + this.y * this.y);
    }, e.prototype.lenSquare = function() {
      return this.x * this.x + this.y * this.y;
    }, e.prototype.normalize = function() {
      var t = this.len();
      return this.x /= t, this.y /= t, this;
    }, e.prototype.distance = function(t) {
      var r = this.x - t.x, n = this.y - t.y;
      return Math.sqrt(r * r + n * n);
    }, e.prototype.distanceSquare = function(t) {
      var r = this.x - t.x, n = this.y - t.y;
      return r * r + n * n;
    }, e.prototype.negate = function() {
      return this.x = -this.x, this.y = -this.y, this;
    }, e.prototype.transform = function(t) {
      if (t) {
        var r = this.x, n = this.y;
        return this.x = t[0] * r + t[2] * n + t[4], this.y = t[1] * r + t[3] * n + t[5], this;
      }
    }, e.prototype.toArray = function(t) {
      return t[0] = this.x, t[1] = this.y, t;
    }, e.prototype.fromArray = function(t) {
      this.x = t[0], this.y = t[1];
    }, e.set = function(t, r, n) {
      t.x = r, t.y = n;
    }, e.copy = function(t, r) {
      t.x = r.x, t.y = r.y;
    }, e.len = function(t) {
      return Math.sqrt(t.x * t.x + t.y * t.y);
    }, e.lenSquare = function(t) {
      return t.x * t.x + t.y * t.y;
    }, e.dot = function(t, r) {
      return t.x * r.x + t.y * r.y;
    }, e.add = function(t, r, n) {
      t.x = r.x + n.x, t.y = r.y + n.y;
    }, e.sub = function(t, r, n) {
      t.x = r.x - n.x, t.y = r.y - n.y;
    }, e.scale = function(t, r, n) {
      t.x = r.x * n, t.y = r.y * n;
    }, e.scaleAndAdd = function(t, r, n, i) {
      t.x = r.x + n.x * i, t.y = r.y + n.y * i;
    }, e.lerp = function(t, r, n, i) {
      var a = 1 - i;
      t.x = a * r.x + i * n.x, t.y = a * r.y + i * n.y;
    }, e;
  })();
  fa = Math.min;
  ha = Math.max;
  Sr = new it();
  br = new it();
  wr = new it();
  Tr = new it();
  ti = new it();
  ei = new it();
  at = (function() {
    function e(t, r, n, i) {
      n < 0 && (t = t + n, n = -n), i < 0 && (r = r + i, i = -i), this.x = t, this.y = r, this.width = n, this.height = i;
    }
    return e.prototype.union = function(t) {
      var r = fa(t.x, this.x), n = fa(t.y, this.y);
      isFinite(this.x) && isFinite(this.width) ? this.width = ha(t.x + t.width, this.x + this.width) - r : this.width = t.width, isFinite(this.y) && isFinite(this.height) ? this.height = ha(t.y + t.height, this.y + this.height) - n : this.height = t.height, this.x = r, this.y = n;
    }, e.prototype.applyTransform = function(t) {
      e.applyTransform(this, this, t);
    }, e.prototype.calculateTransform = function(t) {
      var r = this, n = t.width / r.width, i = t.height / r.height, a = hr();
      return zi(a, a, [
        -r.x,
        -r.y
      ]), Wp(a, a, [
        n,
        i
      ]), zi(a, a, [
        t.x,
        t.y
      ]), a;
    }, e.prototype.intersect = function(t, r) {
      if (!t) return false;
      t instanceof e || (t = e.create(t));
      var n = this, i = n.x, a = n.x + n.width, o = n.y, s = n.y + n.height, u = t.x, l = t.x + t.width, f = t.y, h = t.y + t.height, c = !(a < u || l < i || s < f || h < o);
      if (r) {
        var v = 1 / 0, p = 0, y = Math.abs(a - u), g = Math.abs(l - i), d = Math.abs(s - f), m = Math.abs(h - o), _ = Math.min(y, g), S = Math.min(d, m);
        a < u || l < i ? _ > p && (p = _, y < g ? it.set(ei, -y, 0) : it.set(ei, g, 0)) : _ < v && (v = _, y < g ? it.set(ti, y, 0) : it.set(ti, -g, 0)), s < f || h < o ? S > p && (p = S, d < m ? it.set(ei, 0, -d) : it.set(ei, 0, m)) : _ < v && (v = _, d < m ? it.set(ti, 0, d) : it.set(ti, 0, -m));
      }
      return r && it.copy(r, c ? ti : ei), c;
    }, e.prototype.contain = function(t, r) {
      var n = this;
      return t >= n.x && t <= n.x + n.width && r >= n.y && r <= n.y + n.height;
    }, e.prototype.clone = function() {
      return new e(this.x, this.y, this.width, this.height);
    }, e.prototype.copy = function(t) {
      e.copy(this, t);
    }, e.prototype.plain = function() {
      return {
        x: this.x,
        y: this.y,
        width: this.width,
        height: this.height
      };
    }, e.prototype.isFinite = function() {
      return isFinite(this.x) && isFinite(this.y) && isFinite(this.width) && isFinite(this.height);
    }, e.prototype.isZero = function() {
      return this.width === 0 || this.height === 0;
    }, e.create = function(t) {
      return new e(t.x, t.y, t.width, t.height);
    }, e.copy = function(t, r) {
      t.x = r.x, t.y = r.y, t.width = r.width, t.height = r.height;
    }, e.applyTransform = function(t, r, n) {
      if (!n) {
        t !== r && e.copy(t, r);
        return;
      }
      if (n[1] < 1e-5 && n[1] > -1e-5 && n[2] < 1e-5 && n[2] > -1e-5) {
        var i = n[0], a = n[3], o = n[4], s = n[5];
        t.x = r.x * i + o, t.y = r.y * a + s, t.width = r.width * i, t.height = r.height * a, t.width < 0 && (t.x += t.width, t.width = -t.width), t.height < 0 && (t.y += t.height, t.height = -t.height);
        return;
      }
      Sr.x = wr.x = r.x, Sr.y = Tr.y = r.y, br.x = Tr.x = r.x + r.width, br.y = wr.y = r.y + r.height, Sr.transform(n), Tr.transform(n), br.transform(n), wr.transform(n), t.x = fa(Sr.x, br.x, wr.x, Tr.x), t.y = fa(Sr.y, br.y, wr.y, Tr.y);
      var u = ha(Sr.x, br.x, wr.x, Tr.x), l = ha(Sr.y, br.y, wr.y, Tr.y);
      t.width = u - t.x, t.height = l - t.y;
    }, e;
  })();
  Yp = "silent";
  function Wm(e, t, r) {
    return {
      type: e,
      event: r,
      target: t.target,
      topTarget: t.topTarget,
      cancelBubble: false,
      offsetX: r.zrX,
      offsetY: r.zrY,
      gestureEvent: r.gestureEvent,
      pinchX: r.pinchX,
      pinchY: r.pinchY,
      pinchScale: r.pinchScale,
      wheelDelta: r.zrDelta,
      zrByTouch: r.zrByTouch,
      which: r.which,
      stop: Ym
    };
  }
  function Ym() {
    zm(this.event);
  }
  var qm = (function(e) {
    ot(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.handler = null, r;
    }
    return t.prototype.dispose = function() {
    }, t.prototype.setCursor = function() {
    }, t;
  })($e), ri = /* @__PURE__ */ (function() {
    function e(t, r) {
      this.x = t, this.y = r;
    }
    return e;
  })(), Xm = [
    "click",
    "dblclick",
    "mousewheel",
    "mouseout",
    "mouseup",
    "mousedown",
    "mousemove",
    "contextmenu"
  ], Ds = new at(0, 0, 0, 0), qp = (function(e) {
    ot(t, e);
    function t(r, n, i, a, o) {
      var s = e.call(this) || this;
      return s._hovered = new ri(0, 0), s.storage = r, s.painter = n, s.painterRoot = a, s._pointerSize = o, i = i || new qm(), s.proxy = null, s.setHandlerProxy(i), s._draggingMgr = new Pm(s), s;
    }
    return t.prototype.setHandlerProxy = function(r) {
      this.proxy && this.proxy.dispose(), r && (P(Xm, function(n) {
        r.on && r.on(n, this[n], this);
      }, this), r.handler = this), this.proxy = r;
    }, t.prototype.mousemove = function(r) {
      var n = r.zrX, i = r.zrY, a = Xp(this, n, i), o = this._hovered, s = o.target;
      s && !s.__zr && (o = this.findHover(o.x, o.y), s = o.target);
      var u = this._hovered = a ? new ri(n, i) : this.findHover(n, i), l = u.target, f = this.proxy;
      f.setCursor && f.setCursor(l ? l.cursor : "default"), s && l !== s && this.dispatchToElement(o, "mouseout", r), this.dispatchToElement(u, "mousemove", r), l && l !== s && this.dispatchToElement(u, "mouseover", r);
    }, t.prototype.mouseout = function(r) {
      var n = r.zrEventControl;
      n !== "only_globalout" && this.dispatchToElement(this._hovered, "mouseout", r), n !== "no_globalout" && this.trigger("globalout", {
        type: "globalout",
        event: r
      });
    }, t.prototype.resize = function() {
      this._hovered = new ri(0, 0);
    }, t.prototype.dispatch = function(r, n) {
      var i = this[r];
      i && i.call(this, n);
    }, t.prototype.dispose = function() {
      this.proxy.dispose(), this.storage = null, this.proxy = null, this.painter = null;
    }, t.prototype.setCursorStyle = function(r) {
      var n = this.proxy;
      n.setCursor && n.setCursor(r);
    }, t.prototype.dispatchToElement = function(r, n, i) {
      r = r || {};
      var a = r.target;
      if (!(a && a.silent)) {
        for (var o = "on" + n, s = Wm(n, r, i); a && (a[o] && (s.cancelBubble = !!a[o].call(a, s)), a.trigger(n, s), a = a.__hostTarget ? a.__hostTarget : a.parent, !s.cancelBubble); ) ;
        s.cancelBubble || (this.trigger(n, s), this.painter && this.painter.eachOtherLayer && this.painter.eachOtherLayer(function(u) {
          typeof u[o] == "function" && u[o].call(u, s), u.trigger && u.trigger(n, s);
        }));
      }
    }, t.prototype.findHover = function(r, n, i) {
      var a = this.storage.getDisplayList(), o = new ri(r, n);
      if (yh(a, o, r, n, i), this._pointerSize && !o.target) {
        for (var s = [], u = this._pointerSize, l = u / 2, f = new at(r - l, n - l, u, u), h = a.length - 1; h >= 0; h--) {
          var c = a[h];
          c !== i && !c.ignore && !c.ignoreCoarsePointer && (!c.parent || !c.parent.ignoreCoarsePointer) && (Ds.copy(c.getBoundingRect()), c.transform && Ds.applyTransform(c.transform), Ds.intersect(f) && s.push(c));
        }
        if (s.length) for (var v = 4, p = Math.PI / 12, y = Math.PI * 2, g = 0; g < l; g += v) for (var d = 0; d < y; d += p) {
          var m = r + g * Math.cos(d), _ = n + g * Math.sin(d);
          if (yh(s, o, m, _, i), o.target) return o;
        }
      }
      return o;
    }, t.prototype.processGesture = function(r, n) {
      this._gestureMgr || (this._gestureMgr = new Vm());
      var i = this._gestureMgr;
      n === "start" && i.clear();
      var a = i.recognize(r, this.findHover(r.zrX, r.zrY, null).target, this.proxy.dom);
      if (n === "end" && i.clear(), a) {
        var o = a.type;
        r.gestureEvent = o;
        var s = new ri();
        s.target = a.target, this.dispatchToElement(s, o, a.event);
      }
    }, t;
  })($e);
  P([
    "click",
    "mousedown",
    "mouseup",
    "mousewheel",
    "dblclick",
    "contextmenu"
  ], function(e) {
    qp.prototype[e] = function(t) {
      var r = t.zrX, n = t.zrY, i = Xp(this, r, n), a, o;
      if ((e !== "mouseup" || !i) && (a = this.findHover(r, n), o = a.target), e === "mousedown") this._downEl = o, this._downPoint = [
        t.zrX,
        t.zrY
      ], this._upEl = o;
      else if (e === "mouseup") this._upEl = o;
      else if (e === "click") {
        if (this._downEl !== this._upEl || !this._downPoint || Gp(this._downPoint, [
          t.zrX,
          t.zrY
        ]) > 4) return;
        this._downPoint = null;
      }
      this.dispatchToElement(a, e, t);
    };
  });
  function $m(e, t, r) {
    if (e[e.rectHover ? "rectContain" : "contain"](t, r)) {
      for (var n = e, i = void 0, a = false; n; ) {
        if (n.ignoreClip && (a = true), !a) {
          var o = n.getClipPath();
          if (o && !o.contain(t, r)) return false;
        }
        n.silent && (i = true);
        var s = n.__hostTarget;
        n = s || n.parent;
      }
      return i ? Yp : true;
    }
    return false;
  }
  function yh(e, t, r, n, i) {
    for (var a = e.length - 1; a >= 0; a--) {
      var o = e[a], s = void 0;
      if (o !== i && !o.ignore && (s = $m(o, r, n)) && (!t.topTarget && (t.topTarget = o), s !== Yp)) {
        t.target = o;
        break;
      }
    }
  }
  function Xp(e, t, r) {
    var n = e.painter;
    return t < 0 || t > n.getWidth() || r < 0 || r > n.getHeight();
  }
  var $p = 32, ni = 7;
  function Zm(e) {
    for (var t = 0; e >= $p; ) t |= e & 1, e >>= 1;
    return e + t;
  }
  function mh(e, t, r, n) {
    var i = t + 1;
    if (i === r) return 1;
    if (n(e[i++], e[t]) < 0) {
      for (; i < r && n(e[i], e[i - 1]) < 0; ) i++;
      Km(e, t, i);
    } else for (; i < r && n(e[i], e[i - 1]) >= 0; ) i++;
    return i - t;
  }
  function Km(e, t, r) {
    for (r--; t < r; ) {
      var n = e[t];
      e[t++] = e[r], e[r--] = n;
    }
  }
  function _h(e, t, r, n, i) {
    for (n === t && n++; n < r; n++) {
      for (var a = e[n], o = t, s = n, u; o < s; ) u = o + s >>> 1, i(a, e[u]) < 0 ? s = u : o = u + 1;
      var l = n - o;
      switch (l) {
        case 3:
          e[o + 3] = e[o + 2];
        case 2:
          e[o + 2] = e[o + 1];
        case 1:
          e[o + 1] = e[o];
          break;
        default:
          for (; l > 0; ) e[o + l] = e[o + l - 1], l--;
      }
      e[o] = a;
    }
  }
  function xs(e, t, r, n, i, a) {
    var o = 0, s = 0, u = 1;
    if (a(e, t[r + i]) > 0) {
      for (s = n - i; u < s && a(e, t[r + i + u]) > 0; ) o = u, u = (u << 1) + 1, u <= 0 && (u = s);
      u > s && (u = s), o += i, u += i;
    } else {
      for (s = i + 1; u < s && a(e, t[r + i - u]) <= 0; ) o = u, u = (u << 1) + 1, u <= 0 && (u = s);
      u > s && (u = s);
      var l = o;
      o = i - u, u = i - l;
    }
    for (o++; o < u; ) {
      var f = o + (u - o >>> 1);
      a(e, t[r + f]) > 0 ? o = f + 1 : u = f;
    }
    return u;
  }
  function Ps(e, t, r, n, i, a) {
    var o = 0, s = 0, u = 1;
    if (a(e, t[r + i]) < 0) {
      for (s = i + 1; u < s && a(e, t[r + i - u]) < 0; ) o = u, u = (u << 1) + 1, u <= 0 && (u = s);
      u > s && (u = s);
      var l = o;
      o = i - u, u = i - l;
    } else {
      for (s = n - i; u < s && a(e, t[r + i + u]) >= 0; ) o = u, u = (u << 1) + 1, u <= 0 && (u = s);
      u > s && (u = s), o += i, u += i;
    }
    for (o++; o < u; ) {
      var f = o + (u - o >>> 1);
      a(e, t[r + f]) < 0 ? u = f : o = f + 1;
    }
    return u;
  }
  function jm(e, t) {
    var r = ni, n, i, a = 0, o = [];
    n = [], i = [];
    function s(v, p) {
      n[a] = v, i[a] = p, a += 1;
    }
    function u() {
      for (; a > 1; ) {
        var v = a - 2;
        if (v >= 1 && i[v - 1] <= i[v] + i[v + 1] || v >= 2 && i[v - 2] <= i[v] + i[v - 1]) i[v - 1] < i[v + 1] && v--;
        else if (i[v] > i[v + 1]) break;
        f(v);
      }
    }
    function l() {
      for (; a > 1; ) {
        var v = a - 2;
        v > 0 && i[v - 1] < i[v + 1] && v--, f(v);
      }
    }
    function f(v) {
      var p = n[v], y = i[v], g = n[v + 1], d = i[v + 1];
      i[v] = y + d, v === a - 3 && (n[v + 1] = n[v + 2], i[v + 1] = i[v + 2]), a--;
      var m = Ps(e[g], e, p, y, 0, t);
      p += m, y -= m, y !== 0 && (d = xs(e[p + y - 1], e, g, d, d - 1, t), d !== 0 && (y <= d ? h(p, y, g, d) : c(p, y, g, d)));
    }
    function h(v, p, y, g) {
      var d = 0;
      for (d = 0; d < p; d++) o[d] = e[v + d];
      var m = 0, _ = y, S = v;
      if (e[S++] = e[_++], --g === 0) {
        for (d = 0; d < p; d++) e[S + d] = o[m + d];
        return;
      }
      if (p === 1) {
        for (d = 0; d < g; d++) e[S + d] = e[_ + d];
        e[S + g] = o[m];
        return;
      }
      for (var T = r, b, w, D; ; ) {
        b = 0, w = 0, D = false;
        do
          if (t(e[_], o[m]) < 0) {
            if (e[S++] = e[_++], w++, b = 0, --g === 0) {
              D = true;
              break;
            }
          } else if (e[S++] = o[m++], b++, w = 0, --p === 1) {
            D = true;
            break;
          }
        while ((b | w) < T);
        if (D) break;
        do {
          if (b = Ps(e[_], o, m, p, 0, t), b !== 0) {
            for (d = 0; d < b; d++) e[S + d] = o[m + d];
            if (S += b, m += b, p -= b, p <= 1) {
              D = true;
              break;
            }
          }
          if (e[S++] = e[_++], --g === 0) {
            D = true;
            break;
          }
          if (w = xs(o[m], e, _, g, 0, t), w !== 0) {
            for (d = 0; d < w; d++) e[S + d] = e[_ + d];
            if (S += w, _ += w, g -= w, g === 0) {
              D = true;
              break;
            }
          }
          if (e[S++] = o[m++], --p === 1) {
            D = true;
            break;
          }
          T--;
        } while (b >= ni || w >= ni);
        if (D) break;
        T < 0 && (T = 0), T += 2;
      }
      if (r = T, r < 1 && (r = 1), p === 1) {
        for (d = 0; d < g; d++) e[S + d] = e[_ + d];
        e[S + g] = o[m];
      } else {
        if (p === 0) throw new Error();
        for (d = 0; d < p; d++) e[S + d] = o[m + d];
      }
    }
    function c(v, p, y, g) {
      var d = 0;
      for (d = 0; d < g; d++) o[d] = e[y + d];
      var m = v + p - 1, _ = g - 1, S = y + g - 1, T = 0, b = 0;
      if (e[S--] = e[m--], --p === 0) {
        for (T = S - (g - 1), d = 0; d < g; d++) e[T + d] = o[d];
        return;
      }
      if (g === 1) {
        for (S -= p, m -= p, b = S + 1, T = m + 1, d = p - 1; d >= 0; d--) e[b + d] = e[T + d];
        e[S] = o[_];
        return;
      }
      for (var w = r; ; ) {
        var D = 0, C = 0, M = false;
        do
          if (t(o[_], e[m]) < 0) {
            if (e[S--] = e[m--], D++, C = 0, --p === 0) {
              M = true;
              break;
            }
          } else if (e[S--] = o[_--], C++, D = 0, --g === 1) {
            M = true;
            break;
          }
        while ((D | C) < w);
        if (M) break;
        do {
          if (D = p - Ps(o[_], e, v, p, p - 1, t), D !== 0) {
            for (S -= D, m -= D, p -= D, b = S + 1, T = m + 1, d = D - 1; d >= 0; d--) e[b + d] = e[T + d];
            if (p === 0) {
              M = true;
              break;
            }
          }
          if (e[S--] = o[_--], --g === 1) {
            M = true;
            break;
          }
          if (C = g - xs(e[m], o, 0, g, g - 1, t), C !== 0) {
            for (S -= C, _ -= C, g -= C, b = S + 1, T = _ + 1, d = 0; d < C; d++) e[b + d] = o[T + d];
            if (g <= 1) {
              M = true;
              break;
            }
          }
          if (e[S--] = e[m--], --p === 0) {
            M = true;
            break;
          }
          w--;
        } while (D >= ni || C >= ni);
        if (M) break;
        w < 0 && (w = 0), w += 2;
      }
      if (r = w, r < 1 && (r = 1), g === 1) {
        for (S -= p, m -= p, b = S + 1, T = m + 1, d = p - 1; d >= 0; d--) e[b + d] = e[T + d];
        e[S] = o[_];
      } else {
        if (g === 0) throw new Error();
        for (T = S - (g - 1), d = 0; d < g; d++) e[T + d] = o[d];
      }
    }
    return {
      mergeRuns: u,
      forceMergeRuns: l,
      pushRun: s
    };
  }
  function Ya(e, t, r, n) {
    r || (r = 0), n || (n = e.length);
    var i = n - r;
    if (!(i < 2)) {
      var a = 0;
      if (i < $p) {
        a = mh(e, r, n, t), _h(e, r, n, r + a, t);
        return;
      }
      var o = jm(e, t), s = Zm(i);
      do {
        if (a = mh(e, r, n, t), a < s) {
          var u = i;
          u > s && (u = s), _h(e, r, r + u, r + a, t), a = u;
        }
        o.pushRun(r, a), o.mergeRuns(), i -= a, r += a;
      } while (i !== 0);
      o.forceMergeRuns();
    }
  }
  let mi, wn, Sh;
  xe = 1;
  mi = 2;
  wn = 4;
  Sh = false;
  function Is() {
    Sh || (Sh = true, console.warn("z / z2 / zlevel of displayable is invalid, which may cause unexpected errors"));
  }
  function bh(e, t) {
    return e.zlevel === t.zlevel ? e.z === t.z ? e.z2 - t.z2 : e.z - t.z : e.zlevel - t.zlevel;
  }
  let Qm;
  Qm = (function() {
    function e() {
      this._roots = [], this._displayList = [], this._displayListLen = 0, this.displayableSortFunc = bh;
    }
    return e.prototype.traverse = function(t, r) {
      for (var n = 0; n < this._roots.length; n++) this._roots[n].traverse(t, r);
    }, e.prototype.getDisplayList = function(t, r) {
      r = r || false;
      var n = this._displayList;
      return (t || !n.length) && this.updateDisplayList(r), n;
    }, e.prototype.updateDisplayList = function(t) {
      this._displayListLen = 0;
      for (var r = this._roots, n = this._displayList, i = 0, a = r.length; i < a; i++) this._updateAndAddDisplayable(r[i], null, t);
      n.length = this._displayListLen, Ya(n, bh);
    }, e.prototype._updateAndAddDisplayable = function(t, r, n) {
      if (!(t.ignore && !n)) {
        t.beforeUpdate(), t.update(), t.afterUpdate();
        var i = t.getClipPath();
        if (t.ignoreClip) r = null;
        else if (i) {
          r ? r = r.slice() : r = [];
          for (var a = i, o = t; a; ) a.parent = o, a.updateTransform(), r.push(a), o = a, a = a.getClipPath();
        }
        if (t.childrenRef) {
          for (var s = t.childrenRef(), u = 0; u < s.length; u++) {
            var l = s[u];
            t.__dirty && (l.__dirty |= xe), this._updateAndAddDisplayable(l, r, n);
          }
          t.__dirty = 0;
        } else {
          var f = t;
          r && r.length ? f.__clipPaths = r : f.__clipPaths && f.__clipPaths.length > 0 && (f.__clipPaths = []), isNaN(f.z) && (Is(), f.z = 0), isNaN(f.z2) && (Is(), f.z2 = 0), isNaN(f.zlevel) && (Is(), f.zlevel = 0), this._displayList[this._displayListLen++] = f;
        }
        var h = t.getDecalElement && t.getDecalElement();
        h && this._updateAndAddDisplayable(h, r, n);
        var c = t.getTextGuideLine();
        c && this._updateAndAddDisplayable(c, r, n);
        var v = t.getTextContent();
        v && this._updateAndAddDisplayable(v, r, n);
      }
    }, e.prototype.addRoot = function(t) {
      t.__zr && t.__zr.storage === this || this._roots.push(t);
    }, e.prototype.delRoot = function(t) {
      if (t instanceof Array) {
        for (var r = 0, n = t.length; r < n; r++) this.delRoot(t[r]);
        return;
      }
      var i = vt(this._roots, t);
      i >= 0 && this._roots.splice(i, 1);
    }, e.prototype.delAllRoots = function() {
      this._roots = [], this._displayList = [], this._displayListLen = 0;
    }, e.prototype.getRoots = function() {
      return this._roots;
    }, e.prototype.dispose = function() {
      this._displayList = null, this._roots = null;
    }, e;
  })();
  Gu = j.hasGlobalWindow && (window.requestAnimationFrame && window.requestAnimationFrame.bind(window) || window.msRequestAnimationFrame && window.msRequestAnimationFrame.bind(window) || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame) || function(e) {
    return setTimeout(e, 16);
  };
  var xi = {
    linear: function(e) {
      return e;
    },
    quadraticIn: function(e) {
      return e * e;
    },
    quadraticOut: function(e) {
      return e * (2 - e);
    },
    quadraticInOut: function(e) {
      return (e *= 2) < 1 ? 0.5 * e * e : -0.5 * (--e * (e - 2) - 1);
    },
    cubicIn: function(e) {
      return e * e * e;
    },
    cubicOut: function(e) {
      return --e * e * e + 1;
    },
    cubicInOut: function(e) {
      return (e *= 2) < 1 ? 0.5 * e * e * e : 0.5 * ((e -= 2) * e * e + 2);
    },
    quarticIn: function(e) {
      return e * e * e * e;
    },
    quarticOut: function(e) {
      return 1 - --e * e * e * e;
    },
    quarticInOut: function(e) {
      return (e *= 2) < 1 ? 0.5 * e * e * e * e : -0.5 * ((e -= 2) * e * e * e - 2);
    },
    quinticIn: function(e) {
      return e * e * e * e * e;
    },
    quinticOut: function(e) {
      return --e * e * e * e * e + 1;
    },
    quinticInOut: function(e) {
      return (e *= 2) < 1 ? 0.5 * e * e * e * e * e : 0.5 * ((e -= 2) * e * e * e * e + 2);
    },
    sinusoidalIn: function(e) {
      return 1 - Math.cos(e * Math.PI / 2);
    },
    sinusoidalOut: function(e) {
      return Math.sin(e * Math.PI / 2);
    },
    sinusoidalInOut: function(e) {
      return 0.5 * (1 - Math.cos(Math.PI * e));
    },
    exponentialIn: function(e) {
      return e === 0 ? 0 : Math.pow(1024, e - 1);
    },
    exponentialOut: function(e) {
      return e === 1 ? 1 : 1 - Math.pow(2, -10 * e);
    },
    exponentialInOut: function(e) {
      return e === 0 ? 0 : e === 1 ? 1 : (e *= 2) < 1 ? 0.5 * Math.pow(1024, e - 1) : 0.5 * (-Math.pow(2, -10 * (e - 1)) + 2);
    },
    circularIn: function(e) {
      return 1 - Math.sqrt(1 - e * e);
    },
    circularOut: function(e) {
      return Math.sqrt(1 - --e * e);
    },
    circularInOut: function(e) {
      return (e *= 2) < 1 ? -0.5 * (Math.sqrt(1 - e * e) - 1) : 0.5 * (Math.sqrt(1 - (e -= 2) * e) + 1);
    },
    elasticIn: function(e) {
      var t, r = 0.1, n = 0.4;
      return e === 0 ? 0 : e === 1 ? 1 : (!r || r < 1 ? (r = 1, t = n / 4) : t = n * Math.asin(1 / r) / (2 * Math.PI), -(r * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n)));
    },
    elasticOut: function(e) {
      var t, r = 0.1, n = 0.4;
      return e === 0 ? 0 : e === 1 ? 1 : (!r || r < 1 ? (r = 1, t = n / 4) : t = n * Math.asin(1 / r) / (2 * Math.PI), r * Math.pow(2, -10 * e) * Math.sin((e - t) * (2 * Math.PI) / n) + 1);
    },
    elasticInOut: function(e) {
      var t, r = 0.1, n = 0.4;
      return e === 0 ? 0 : e === 1 ? 1 : (!r || r < 1 ? (r = 1, t = n / 4) : t = n * Math.asin(1 / r) / (2 * Math.PI), (e *= 2) < 1 ? -0.5 * (r * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n)) : r * Math.pow(2, -10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n) * 0.5 + 1);
    },
    backIn: function(e) {
      var t = 1.70158;
      return e * e * ((t + 1) * e - t);
    },
    backOut: function(e) {
      var t = 1.70158;
      return --e * e * ((t + 1) * e + t) + 1;
    },
    backInOut: function(e) {
      var t = 2.5949095;
      return (e *= 2) < 1 ? 0.5 * (e * e * ((t + 1) * e - t)) : 0.5 * ((e -= 2) * e * ((t + 1) * e + t) + 2);
    },
    bounceIn: function(e) {
      return 1 - xi.bounceOut(1 - e);
    },
    bounceOut: function(e) {
      return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375 : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
    },
    bounceInOut: function(e) {
      return e < 0.5 ? xi.bounceIn(e * 2) * 0.5 : xi.bounceOut(e * 2 - 1) * 0.5 + 0.5;
    }
  }, va = Math.pow, vr = Math.sqrt, so = 1e-8, Zp = 1e-4, wh = vr(3), ca = 1 / 3, Pe = nn(), Jt = nn(), An = nn();
  function ur(e) {
    return e > -so && e < so;
  }
  function Kp(e) {
    return e > so || e < -so;
  }
  function Tt(e, t, r, n, i) {
    var a = 1 - i;
    return a * a * (a * e + 3 * i * t) + i * i * (i * n + 3 * a * r);
  }
  function Th(e, t, r, n, i) {
    var a = 1 - i;
    return 3 * (((t - e) * a + 2 * (r - t) * i) * a + (n - r) * i * i);
  }
  function uo(e, t, r, n, i, a) {
    var o = n + 3 * (t - r) - e, s = 3 * (r - t * 2 + e), u = 3 * (t - e), l = e - i, f = s * s - 3 * o * u, h = s * u - 9 * o * l, c = u * u - 3 * s * l, v = 0;
    if (ur(f) && ur(h)) if (ur(s)) a[0] = 0;
    else {
      var p = -u / s;
      p >= 0 && p <= 1 && (a[v++] = p);
    }
    else {
      var y = h * h - 4 * f * c;
      if (ur(y)) {
        var g = h / f, p = -s / o + g, d = -g / 2;
        p >= 0 && p <= 1 && (a[v++] = p), d >= 0 && d <= 1 && (a[v++] = d);
      } else if (y > 0) {
        var m = vr(y), _ = f * s + 1.5 * o * (-h + m), S = f * s + 1.5 * o * (-h - m);
        _ < 0 ? _ = -va(-_, ca) : _ = va(_, ca), S < 0 ? S = -va(-S, ca) : S = va(S, ca);
        var p = (-s - (_ + S)) / (3 * o);
        p >= 0 && p <= 1 && (a[v++] = p);
      } else {
        var T = (2 * f * s - 3 * o * h) / (2 * vr(f * f * f)), b = Math.acos(T) / 3, w = vr(f), D = Math.cos(b), p = (-s - 2 * w * D) / (3 * o), d = (-s + w * (D + wh * Math.sin(b))) / (3 * o), C = (-s + w * (D - wh * Math.sin(b))) / (3 * o);
        p >= 0 && p <= 1 && (a[v++] = p), d >= 0 && d <= 1 && (a[v++] = d), C >= 0 && C <= 1 && (a[v++] = C);
      }
    }
    return v;
  }
  function jp(e, t, r, n, i) {
    var a = 6 * r - 12 * t + 6 * e, o = 9 * t + 3 * n - 3 * e - 9 * r, s = 3 * t - 3 * e, u = 0;
    if (ur(o)) {
      if (Kp(a)) {
        var l = -s / a;
        l >= 0 && l <= 1 && (i[u++] = l);
      }
    } else {
      var f = a * a - 4 * o * s;
      if (ur(f)) i[0] = -a / (2 * o);
      else if (f > 0) {
        var h = vr(f), l = (-a + h) / (2 * o), c = (-a - h) / (2 * o);
        l >= 0 && l <= 1 && (i[u++] = l), c >= 0 && c <= 1 && (i[u++] = c);
      }
    }
    return u;
  }
  function lo(e, t, r, n, i, a) {
    var o = (t - e) * i + e, s = (r - t) * i + t, u = (n - r) * i + r, l = (s - o) * i + o, f = (u - s) * i + s, h = (f - l) * i + l;
    a[0] = e, a[1] = o, a[2] = l, a[3] = h, a[4] = h, a[5] = f, a[6] = u, a[7] = n;
  }
  function Jm(e, t, r, n, i, a, o, s, u, l, f) {
    var h, c = 5e-3, v = 1 / 0, p, y, g, d;
    Pe[0] = u, Pe[1] = l;
    for (var m = 0; m < 1; m += 0.05) Jt[0] = Tt(e, r, i, o, m), Jt[1] = Tt(t, n, a, s, m), g = $r(Pe, Jt), g < v && (h = m, v = g);
    v = 1 / 0;
    for (var _ = 0; _ < 32 && !(c < Zp); _++) p = h - c, y = h + c, Jt[0] = Tt(e, r, i, o, p), Jt[1] = Tt(t, n, a, s, p), g = $r(Jt, Pe), p >= 0 && g < v ? (h = p, v = g) : (An[0] = Tt(e, r, i, o, y), An[1] = Tt(t, n, a, s, y), d = $r(An, Pe), y <= 1 && d < v ? (h = y, v = d) : c *= 0.5);
    return vr(v);
  }
  function t_(e, t, r, n, i, a, o, s, u) {
    for (var l = e, f = t, h = 0, c = 1 / u, v = 1; v <= u; v++) {
      var p = v * c, y = Tt(e, r, i, o, p), g = Tt(t, n, a, s, p), d = y - l, m = g - f;
      h += Math.sqrt(d * d + m * m), l = y, f = g;
    }
    return h;
  }
  function Ft(e, t, r, n) {
    var i = 1 - n;
    return i * (i * e + 2 * n * t) + n * n * r;
  }
  function Mh(e, t, r, n) {
    return 2 * ((1 - n) * (t - e) + n * (r - t));
  }
  function e_(e, t, r, n, i) {
    var a = e - 2 * t + r, o = 2 * (t - e), s = e - n, u = 0;
    if (ur(a)) {
      if (Kp(o)) {
        var l = -s / o;
        l >= 0 && l <= 1 && (i[u++] = l);
      }
    } else {
      var f = o * o - 4 * a * s;
      if (ur(f)) {
        var l = -o / (2 * a);
        l >= 0 && l <= 1 && (i[u++] = l);
      } else if (f > 0) {
        var h = vr(f), l = (-o + h) / (2 * a), c = (-o - h) / (2 * a);
        l >= 0 && l <= 1 && (i[u++] = l), c >= 0 && c <= 1 && (i[u++] = c);
      }
    }
    return u;
  }
  function Qp(e, t, r) {
    var n = e + r - 2 * t;
    return n === 0 ? 0.5 : (e - t) / n;
  }
  function fo(e, t, r, n, i) {
    var a = (t - e) * n + e, o = (r - t) * n + t, s = (o - a) * n + a;
    i[0] = e, i[1] = a, i[2] = s, i[3] = s, i[4] = o, i[5] = r;
  }
  function r_(e, t, r, n, i, a, o, s, u) {
    var l, f = 5e-3, h = 1 / 0;
    Pe[0] = o, Pe[1] = s;
    for (var c = 0; c < 1; c += 0.05) {
      Jt[0] = Ft(e, r, i, c), Jt[1] = Ft(t, n, a, c);
      var v = $r(Pe, Jt);
      v < h && (l = c, h = v);
    }
    h = 1 / 0;
    for (var p = 0; p < 32 && !(f < Zp); p++) {
      var y = l - f, g = l + f;
      Jt[0] = Ft(e, r, i, y), Jt[1] = Ft(t, n, a, y);
      var v = $r(Jt, Pe);
      if (y >= 0 && v < h) l = y, h = v;
      else {
        An[0] = Ft(e, r, i, g), An[1] = Ft(t, n, a, g);
        var d = $r(An, Pe);
        g <= 1 && d < h ? (l = g, h = d) : f *= 0.5;
      }
    }
    return vr(h);
  }
  function n_(e, t, r, n, i, a, o) {
    for (var s = e, u = t, l = 0, f = 1 / o, h = 1; h <= o; h++) {
      var c = h * f, v = Ft(e, r, i, c), p = Ft(t, n, a, c), y = v - s, g = p - u;
      l += Math.sqrt(y * y + g * g), s = v, u = p;
    }
    return l;
  }
  var i_ = /cubic-bezier\(([0-9,\.e ]+)\)/;
  function Wl(e) {
    var t = e && i_.exec(e);
    if (t) {
      var r = t[1].split(","), n = +Ie(r[0]), i = +Ie(r[1]), a = +Ie(r[2]), o = +Ie(r[3]);
      if (isNaN(n + i + a + o)) return;
      var s = [];
      return function(u) {
        return u <= 0 ? 0 : u >= 1 ? 1 : uo(0, n, a, 1, u, s) && Tt(0, i, o, 1, s[0]);
      };
    }
  }
  var a_ = (function() {
    function e(t) {
      this._inited = false, this._startTime = 0, this._pausedTime = 0, this._paused = false, this._life = t.life || 1e3, this._delay = t.delay || 0, this.loop = t.loop || false, this.onframe = t.onframe || zt, this.ondestroy = t.ondestroy || zt, this.onrestart = t.onrestart || zt, t.easing && this.setEasing(t.easing);
    }
    return e.prototype.step = function(t, r) {
      if (this._inited || (this._startTime = t + this._delay, this._inited = true), this._paused) {
        this._pausedTime += r;
        return;
      }
      var n = this._life, i = t - this._startTime - this._pausedTime, a = i / n;
      a < 0 && (a = 0), a = Math.min(a, 1);
      var o = this.easingFunc, s = o ? o(a) : a;
      if (this.onframe(s), a === 1) if (this.loop) {
        var u = i % n;
        this._startTime = t - u, this._pausedTime = 0, this.onrestart();
      } else return true;
      return false;
    }, e.prototype.pause = function() {
      this._paused = true;
    }, e.prototype.resume = function() {
      this._paused = false;
    }, e.prototype.setEasing = function(t) {
      this.easing = t, this.easingFunc = Y(t) ? t : xi[t] || Wl(t);
    }, e;
  })(), Jp = /* @__PURE__ */ (function() {
    function e(t) {
      this.value = t;
    }
    return e;
  })(), o_ = (function() {
    function e() {
      this._len = 0;
    }
    return e.prototype.insert = function(t) {
      var r = new Jp(t);
      return this.insertEntry(r), r;
    }, e.prototype.insertEntry = function(t) {
      this.head ? (this.tail.next = t, t.prev = this.tail, t.next = null, this.tail = t) : this.head = this.tail = t, this._len++;
    }, e.prototype.remove = function(t) {
      var r = t.prev, n = t.next;
      r ? r.next = n : this.head = n, n ? n.prev = r : this.tail = r, t.next = t.prev = null, this._len--;
    }, e.prototype.len = function() {
      return this._len;
    }, e.prototype.clear = function() {
      this.head = this.tail = null, this._len = 0;
    }, e;
  })(), ra = (function() {
    function e(t) {
      this._list = new o_(), this._maxSize = 10, this._map = {}, this._maxSize = t;
    }
    return e.prototype.put = function(t, r) {
      var n = this._list, i = this._map, a = null;
      if (i[t] == null) {
        var o = n.len(), s = this._lastRemovedEntry;
        if (o >= this._maxSize && o > 0) {
          var u = n.head;
          n.remove(u), delete i[u.key], a = u.value, this._lastRemovedEntry = u;
        }
        s ? s.value = r : s = new Jp(r), s.key = t, n.insertEntry(s), i[t] = s;
      }
      return a;
    }, e.prototype.get = function(t) {
      var r = this._map[t], n = this._list;
      if (r != null) return r !== n.tail && (n.remove(r), n.insertEntry(r)), r.value;
    }, e.prototype.clear = function() {
      this._list.clear(), this._map = {};
    }, e.prototype.len = function() {
      return this._list.len();
    }, e;
  })(), Ch = {
    transparent: [
      0,
      0,
      0,
      0
    ],
    aliceblue: [
      240,
      248,
      255,
      1
    ],
    antiquewhite: [
      250,
      235,
      215,
      1
    ],
    aqua: [
      0,
      255,
      255,
      1
    ],
    aquamarine: [
      127,
      255,
      212,
      1
    ],
    azure: [
      240,
      255,
      255,
      1
    ],
    beige: [
      245,
      245,
      220,
      1
    ],
    bisque: [
      255,
      228,
      196,
      1
    ],
    black: [
      0,
      0,
      0,
      1
    ],
    blanchedalmond: [
      255,
      235,
      205,
      1
    ],
    blue: [
      0,
      0,
      255,
      1
    ],
    blueviolet: [
      138,
      43,
      226,
      1
    ],
    brown: [
      165,
      42,
      42,
      1
    ],
    burlywood: [
      222,
      184,
      135,
      1
    ],
    cadetblue: [
      95,
      158,
      160,
      1
    ],
    chartreuse: [
      127,
      255,
      0,
      1
    ],
    chocolate: [
      210,
      105,
      30,
      1
    ],
    coral: [
      255,
      127,
      80,
      1
    ],
    cornflowerblue: [
      100,
      149,
      237,
      1
    ],
    cornsilk: [
      255,
      248,
      220,
      1
    ],
    crimson: [
      220,
      20,
      60,
      1
    ],
    cyan: [
      0,
      255,
      255,
      1
    ],
    darkblue: [
      0,
      0,
      139,
      1
    ],
    darkcyan: [
      0,
      139,
      139,
      1
    ],
    darkgoldenrod: [
      184,
      134,
      11,
      1
    ],
    darkgray: [
      169,
      169,
      169,
      1
    ],
    darkgreen: [
      0,
      100,
      0,
      1
    ],
    darkgrey: [
      169,
      169,
      169,
      1
    ],
    darkkhaki: [
      189,
      183,
      107,
      1
    ],
    darkmagenta: [
      139,
      0,
      139,
      1
    ],
    darkolivegreen: [
      85,
      107,
      47,
      1
    ],
    darkorange: [
      255,
      140,
      0,
      1
    ],
    darkorchid: [
      153,
      50,
      204,
      1
    ],
    darkred: [
      139,
      0,
      0,
      1
    ],
    darksalmon: [
      233,
      150,
      122,
      1
    ],
    darkseagreen: [
      143,
      188,
      143,
      1
    ],
    darkslateblue: [
      72,
      61,
      139,
      1
    ],
    darkslategray: [
      47,
      79,
      79,
      1
    ],
    darkslategrey: [
      47,
      79,
      79,
      1
    ],
    darkturquoise: [
      0,
      206,
      209,
      1
    ],
    darkviolet: [
      148,
      0,
      211,
      1
    ],
    deeppink: [
      255,
      20,
      147,
      1
    ],
    deepskyblue: [
      0,
      191,
      255,
      1
    ],
    dimgray: [
      105,
      105,
      105,
      1
    ],
    dimgrey: [
      105,
      105,
      105,
      1
    ],
    dodgerblue: [
      30,
      144,
      255,
      1
    ],
    firebrick: [
      178,
      34,
      34,
      1
    ],
    floralwhite: [
      255,
      250,
      240,
      1
    ],
    forestgreen: [
      34,
      139,
      34,
      1
    ],
    fuchsia: [
      255,
      0,
      255,
      1
    ],
    gainsboro: [
      220,
      220,
      220,
      1
    ],
    ghostwhite: [
      248,
      248,
      255,
      1
    ],
    gold: [
      255,
      215,
      0,
      1
    ],
    goldenrod: [
      218,
      165,
      32,
      1
    ],
    gray: [
      128,
      128,
      128,
      1
    ],
    green: [
      0,
      128,
      0,
      1
    ],
    greenyellow: [
      173,
      255,
      47,
      1
    ],
    grey: [
      128,
      128,
      128,
      1
    ],
    honeydew: [
      240,
      255,
      240,
      1
    ],
    hotpink: [
      255,
      105,
      180,
      1
    ],
    indianred: [
      205,
      92,
      92,
      1
    ],
    indigo: [
      75,
      0,
      130,
      1
    ],
    ivory: [
      255,
      255,
      240,
      1
    ],
    khaki: [
      240,
      230,
      140,
      1
    ],
    lavender: [
      230,
      230,
      250,
      1
    ],
    lavenderblush: [
      255,
      240,
      245,
      1
    ],
    lawngreen: [
      124,
      252,
      0,
      1
    ],
    lemonchiffon: [
      255,
      250,
      205,
      1
    ],
    lightblue: [
      173,
      216,
      230,
      1
    ],
    lightcoral: [
      240,
      128,
      128,
      1
    ],
    lightcyan: [
      224,
      255,
      255,
      1
    ],
    lightgoldenrodyellow: [
      250,
      250,
      210,
      1
    ],
    lightgray: [
      211,
      211,
      211,
      1
    ],
    lightgreen: [
      144,
      238,
      144,
      1
    ],
    lightgrey: [
      211,
      211,
      211,
      1
    ],
    lightpink: [
      255,
      182,
      193,
      1
    ],
    lightsalmon: [
      255,
      160,
      122,
      1
    ],
    lightseagreen: [
      32,
      178,
      170,
      1
    ],
    lightskyblue: [
      135,
      206,
      250,
      1
    ],
    lightslategray: [
      119,
      136,
      153,
      1
    ],
    lightslategrey: [
      119,
      136,
      153,
      1
    ],
    lightsteelblue: [
      176,
      196,
      222,
      1
    ],
    lightyellow: [
      255,
      255,
      224,
      1
    ],
    lime: [
      0,
      255,
      0,
      1
    ],
    limegreen: [
      50,
      205,
      50,
      1
    ],
    linen: [
      250,
      240,
      230,
      1
    ],
    magenta: [
      255,
      0,
      255,
      1
    ],
    maroon: [
      128,
      0,
      0,
      1
    ],
    mediumaquamarine: [
      102,
      205,
      170,
      1
    ],
    mediumblue: [
      0,
      0,
      205,
      1
    ],
    mediumorchid: [
      186,
      85,
      211,
      1
    ],
    mediumpurple: [
      147,
      112,
      219,
      1
    ],
    mediumseagreen: [
      60,
      179,
      113,
      1
    ],
    mediumslateblue: [
      123,
      104,
      238,
      1
    ],
    mediumspringgreen: [
      0,
      250,
      154,
      1
    ],
    mediumturquoise: [
      72,
      209,
      204,
      1
    ],
    mediumvioletred: [
      199,
      21,
      133,
      1
    ],
    midnightblue: [
      25,
      25,
      112,
      1
    ],
    mintcream: [
      245,
      255,
      250,
      1
    ],
    mistyrose: [
      255,
      228,
      225,
      1
    ],
    moccasin: [
      255,
      228,
      181,
      1
    ],
    navajowhite: [
      255,
      222,
      173,
      1
    ],
    navy: [
      0,
      0,
      128,
      1
    ],
    oldlace: [
      253,
      245,
      230,
      1
    ],
    olive: [
      128,
      128,
      0,
      1
    ],
    olivedrab: [
      107,
      142,
      35,
      1
    ],
    orange: [
      255,
      165,
      0,
      1
    ],
    orangered: [
      255,
      69,
      0,
      1
    ],
    orchid: [
      218,
      112,
      214,
      1
    ],
    palegoldenrod: [
      238,
      232,
      170,
      1
    ],
    palegreen: [
      152,
      251,
      152,
      1
    ],
    paleturquoise: [
      175,
      238,
      238,
      1
    ],
    palevioletred: [
      219,
      112,
      147,
      1
    ],
    papayawhip: [
      255,
      239,
      213,
      1
    ],
    peachpuff: [
      255,
      218,
      185,
      1
    ],
    peru: [
      205,
      133,
      63,
      1
    ],
    pink: [
      255,
      192,
      203,
      1
    ],
    plum: [
      221,
      160,
      221,
      1
    ],
    powderblue: [
      176,
      224,
      230,
      1
    ],
    purple: [
      128,
      0,
      128,
      1
    ],
    red: [
      255,
      0,
      0,
      1
    ],
    rosybrown: [
      188,
      143,
      143,
      1
    ],
    royalblue: [
      65,
      105,
      225,
      1
    ],
    saddlebrown: [
      139,
      69,
      19,
      1
    ],
    salmon: [
      250,
      128,
      114,
      1
    ],
    sandybrown: [
      244,
      164,
      96,
      1
    ],
    seagreen: [
      46,
      139,
      87,
      1
    ],
    seashell: [
      255,
      245,
      238,
      1
    ],
    sienna: [
      160,
      82,
      45,
      1
    ],
    silver: [
      192,
      192,
      192,
      1
    ],
    skyblue: [
      135,
      206,
      235,
      1
    ],
    slateblue: [
      106,
      90,
      205,
      1
    ],
    slategray: [
      112,
      128,
      144,
      1
    ],
    slategrey: [
      112,
      128,
      144,
      1
    ],
    snow: [
      255,
      250,
      250,
      1
    ],
    springgreen: [
      0,
      255,
      127,
      1
    ],
    steelblue: [
      70,
      130,
      180,
      1
    ],
    tan: [
      210,
      180,
      140,
      1
    ],
    teal: [
      0,
      128,
      128,
      1
    ],
    thistle: [
      216,
      191,
      216,
      1
    ],
    tomato: [
      255,
      99,
      71,
      1
    ],
    turquoise: [
      64,
      224,
      208,
      1
    ],
    violet: [
      238,
      130,
      238,
      1
    ],
    wheat: [
      245,
      222,
      179,
      1
    ],
    white: [
      255,
      255,
      255,
      1
    ],
    whitesmoke: [
      245,
      245,
      245,
      1
    ],
    yellow: [
      255,
      255,
      0,
      1
    ],
    yellowgreen: [
      154,
      205,
      50,
      1
    ]
  };
  function ye(e) {
    return e = Math.round(e), e < 0 ? 0 : e > 255 ? 255 : e;
  }
  function s_(e) {
    return e = Math.round(e), e < 0 ? 0 : e > 360 ? 360 : e;
  }
  function Vi(e) {
    return e < 0 ? 0 : e > 1 ? 1 : e;
  }
  function As(e) {
    var t = e;
    return t.length && t.charAt(t.length - 1) === "%" ? ye(parseFloat(t) / 100 * 255) : ye(parseInt(t, 10));
  }
  function Zr(e) {
    var t = e;
    return t.length && t.charAt(t.length - 1) === "%" ? Vi(parseFloat(t) / 100) : Vi(parseFloat(t));
  }
  function Es(e, t, r) {
    return r < 0 ? r += 1 : r > 1 && (r -= 1), r * 6 < 1 ? e + (t - e) * r * 6 : r * 2 < 1 ? t : r * 3 < 2 ? e + (t - e) * (2 / 3 - r) * 6 : e;
  }
  function lr(e, t, r) {
    return e + (t - e) * r;
  }
  function Kt(e, t, r, n, i) {
    return e[0] = t, e[1] = r, e[2] = n, e[3] = i, e;
  }
  function Hu(e, t) {
    return e[0] = t[0], e[1] = t[1], e[2] = t[2], e[3] = t[3], e;
  }
  var td = new ra(20), pa = null;
  function ln(e, t) {
    pa && Hu(pa, t), pa = td.put(e, pa || t.slice());
  }
  Yt = function(e, t) {
    if (e) {
      t = t || [];
      var r = td.get(e);
      if (r) return Hu(t, r);
      e = e + "";
      var n = e.replace(/ /g, "").toLowerCase();
      if (n in Ch) return Hu(t, Ch[n]), ln(e, t), t;
      var i = n.length;
      if (n.charAt(0) === "#") {
        if (i === 4 || i === 5) {
          var a = parseInt(n.slice(1, 4), 16);
          if (!(a >= 0 && a <= 4095)) {
            Kt(t, 0, 0, 0, 1);
            return;
          }
          return Kt(t, (a & 3840) >> 4 | (a & 3840) >> 8, a & 240 | (a & 240) >> 4, a & 15 | (a & 15) << 4, i === 5 ? parseInt(n.slice(4), 16) / 15 : 1), ln(e, t), t;
        } else if (i === 7 || i === 9) {
          var a = parseInt(n.slice(1, 7), 16);
          if (!(a >= 0 && a <= 16777215)) {
            Kt(t, 0, 0, 0, 1);
            return;
          }
          return Kt(t, (a & 16711680) >> 16, (a & 65280) >> 8, a & 255, i === 9 ? parseInt(n.slice(7), 16) / 255 : 1), ln(e, t), t;
        }
        return;
      }
      var o = n.indexOf("("), s = n.indexOf(")");
      if (o !== -1 && s + 1 === i) {
        var u = n.substr(0, o), l = n.substr(o + 1, s - (o + 1)).split(","), f = 1;
        switch (u) {
          case "rgba":
            if (l.length !== 4) return l.length === 3 ? Kt(t, +l[0], +l[1], +l[2], 1) : Kt(t, 0, 0, 0, 1);
            f = Zr(l.pop());
          case "rgb":
            if (l.length >= 3) return Kt(t, As(l[0]), As(l[1]), As(l[2]), l.length === 3 ? f : Zr(l[3])), ln(e, t), t;
            Kt(t, 0, 0, 0, 1);
            return;
          case "hsla":
            if (l.length !== 4) {
              Kt(t, 0, 0, 0, 1);
              return;
            }
            return l[3] = Zr(l[3]), Uu(l, t), ln(e, t), t;
          case "hsl":
            if (l.length !== 3) {
              Kt(t, 0, 0, 0, 1);
              return;
            }
            return Uu(l, t), ln(e, t), t;
          default:
            return;
        }
      }
      Kt(t, 0, 0, 0, 1);
    }
  };
  function Uu(e, t) {
    var r = (parseFloat(e[0]) % 360 + 360) % 360 / 360, n = Zr(e[1]), i = Zr(e[2]), a = i <= 0.5 ? i * (n + 1) : i + n - i * n, o = i * 2 - a;
    return t = t || [], Kt(t, ye(Es(o, a, r + 1 / 3) * 255), ye(Es(o, a, r) * 255), ye(Es(o, a, r - 1 / 3) * 255), 1), e.length === 4 && (t[3] = e[3]), t;
  }
  function u_(e) {
    if (e) {
      var t = e[0] / 255, r = e[1] / 255, n = e[2] / 255, i = Math.min(t, r, n), a = Math.max(t, r, n), o = a - i, s = (a + i) / 2, u, l;
      if (o === 0) u = 0, l = 0;
      else {
        s < 0.5 ? l = o / (a + i) : l = o / (2 - a - i);
        var f = ((a - t) / 6 + o / 2) / o, h = ((a - r) / 6 + o / 2) / o, c = ((a - n) / 6 + o / 2) / o;
        t === a ? u = c - h : r === a ? u = 1 / 3 + f - c : n === a && (u = 2 / 3 + h - f), u < 0 && (u += 1), u > 1 && (u -= 1);
      }
      var v = [
        u * 360,
        l,
        s
      ];
      return e[3] != null && v.push(e[3]), v;
    }
  }
  function Wu(e, t) {
    var r = Yt(e);
    if (r) {
      for (var n = 0; n < 3; n++) t < 0 ? r[n] = r[n] * (1 - t) | 0 : r[n] = (255 - r[n]) * t + r[n] | 0, r[n] > 255 ? r[n] = 255 : r[n] < 0 && (r[n] = 0);
      return an(r, r.length === 4 ? "rgba" : "rgb");
    }
  }
  function l_(e) {
    var t = Yt(e);
    if (t) return ((1 << 24) + (t[0] << 16) + (t[1] << 8) + +t[2]).toString(16).slice(1);
  }
  function ed(e, t, r) {
    if (!(!(t && t.length) || !(e >= 0 && e <= 1))) {
      r = r || [];
      var n = e * (t.length - 1), i = Math.floor(n), a = Math.ceil(n), o = t[i], s = t[a], u = n - i;
      return r[0] = ye(lr(o[0], s[0], u)), r[1] = ye(lr(o[1], s[1], u)), r[2] = ye(lr(o[2], s[2], u)), r[3] = Vi(lr(o[3], s[3], u)), r;
    }
  }
  var f_ = ed;
  function Yl(e, t, r) {
    if (!(!(t && t.length) || !(e >= 0 && e <= 1))) {
      var n = e * (t.length - 1), i = Math.floor(n), a = Math.ceil(n), o = Yt(t[i]), s = Yt(t[a]), u = n - i, l = an([
        ye(lr(o[0], s[0], u)),
        ye(lr(o[1], s[1], u)),
        ye(lr(o[2], s[2], u)),
        Vi(lr(o[3], s[3], u))
      ], "rgba");
      return r ? {
        color: l,
        leftIndex: i,
        rightIndex: a,
        value: n
      } : l;
    }
  }
  var h_ = Yl;
  function v_(e, t, r, n) {
    var i = Yt(e);
    if (e) return i = u_(i), t != null && (i[0] = s_(t)), r != null && (i[1] = Zr(r)), n != null && (i[2] = Zr(n)), an(Uu(i), "rgba");
  }
  function c_(e, t) {
    var r = Yt(e);
    if (r && t != null) return r[3] = Vi(t), an(r, "rgba");
  }
  an = function(e, t) {
    if (!(!e || !e.length)) {
      var r = e[0] + "," + e[1] + "," + e[2];
      return (t === "rgba" || t === "hsva" || t === "hsla") && (r += "," + e[3]), t + "(" + r + ")";
    }
  };
  function Gi(e, t) {
    var r = Yt(e);
    return r ? (0.299 * r[0] + 0.587 * r[1] + 0.114 * r[2]) * r[3] / 255 + (1 - r[3]) * t : 0;
  }
  function p_() {
    return an([
      Math.round(Math.random() * 255),
      Math.round(Math.random() * 255),
      Math.round(Math.random() * 255)
    ], "rgb");
  }
  var Dh = new ra(100);
  function ho(e) {
    if (V(e)) {
      var t = Dh.get(e);
      return t || (t = Wu(e, -0.1), Dh.put(e, t)), t;
    } else if (Oo(e)) {
      var r = O({}, e);
      return r.colorStops = F(e.colorStops, function(n) {
        return {
          offset: n.offset,
          color: Wu(n.color, -0.1)
        };
      }), r;
    }
    return e;
  }
  const d_ = Object.freeze(Object.defineProperty({
    __proto__: null,
    fastLerp: ed,
    fastMapToColor: f_,
    lerp: Yl,
    lift: Wu,
    liftColor: ho,
    lum: Gi,
    mapToColor: h_,
    modifyAlpha: c_,
    modifyHSL: v_,
    parse: Yt,
    random: p_,
    stringify: an,
    toHex: l_
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  var vo = Math.round;
  function Hi(e) {
    var t;
    if (!e || e === "transparent") e = "none";
    else if (typeof e == "string" && e.indexOf("rgba") > -1) {
      var r = Yt(e);
      r && (e = "rgb(" + r[0] + "," + r[1] + "," + r[2] + ")", t = r[3]);
    }
    return {
      color: e,
      opacity: t ?? 1
    };
  }
  var xh = 1e-4;
  function fr(e) {
    return e < xh && e > -xh;
  }
  function da(e) {
    return vo(e * 1e3) / 1e3;
  }
  function Yu(e) {
    return vo(e * 1e4) / 1e4;
  }
  function g_(e) {
    return "matrix(" + da(e[0]) + "," + da(e[1]) + "," + da(e[2]) + "," + da(e[3]) + "," + Yu(e[4]) + "," + Yu(e[5]) + ")";
  }
  var y_ = {
    left: "start",
    right: "end",
    center: "middle",
    middle: "middle"
  };
  function m_(e, t, r) {
    return r === "top" ? e += t / 2 : r === "bottom" && (e -= t / 2), e;
  }
  function __(e) {
    return e && (e.shadowBlur || e.shadowOffsetX || e.shadowOffsetY);
  }
  function S_(e) {
    var t = e.style, r = e.getGlobalScale();
    return [
      t.shadowColor,
      (t.shadowBlur || 0).toFixed(2),
      (t.shadowOffsetX || 0).toFixed(2),
      (t.shadowOffsetY || 0).toFixed(2),
      r[0],
      r[1]
    ].join(",");
  }
  function rd(e) {
    return e && !!e.image;
  }
  function b_(e) {
    return e && !!e.svgElement;
  }
  function ql(e) {
    return rd(e) || b_(e);
  }
  function nd(e) {
    return e.type === "linear";
  }
  function id(e) {
    return e.type === "radial";
  }
  function ad(e) {
    return e && (e.type === "linear" || e.type === "radial");
  }
  function Bo(e) {
    return "url(#" + e + ")";
  }
  function od(e) {
    var t = e.getGlobalScale(), r = Math.max(t[0], t[1]);
    return Math.max(Math.ceil(Math.log(r) / Math.log(10)), 1);
  }
  function sd(e) {
    var t = e.x || 0, r = e.y || 0, n = (e.rotation || 0) * Di, i = W(e.scaleX, 1), a = W(e.scaleY, 1), o = e.skewX || 0, s = e.skewY || 0, u = [];
    return (t || r) && u.push("translate(" + t + "px," + r + "px)"), n && u.push("rotate(" + n + ")"), (i !== 1 || a !== 1) && u.push("scale(" + i + "," + a + ")"), (o || s) && u.push("skew(" + vo(o * Di) + "deg, " + vo(s * Di) + "deg)"), u.join(" ");
  }
  var w_ = (function() {
    return j.hasGlobalWindow && Y(window.btoa) ? function(e) {
      return window.btoa(unescape(encodeURIComponent(e)));
    } : typeof Buffer < "u" ? function(e) {
      return Buffer.from(e).toString("base64");
    } : function(e) {
      return null;
    };
  })(), qu = Array.prototype.slice;
  function Ue(e, t, r) {
    return (t - e) * r + e;
  }
  function Ls(e, t, r, n) {
    for (var i = t.length, a = 0; a < i; a++) e[a] = Ue(t[a], r[a], n);
    return e;
  }
  function T_(e, t, r, n) {
    for (var i = t.length, a = i && t[0].length, o = 0; o < i; o++) {
      e[o] || (e[o] = []);
      for (var s = 0; s < a; s++) e[o][s] = Ue(t[o][s], r[o][s], n);
    }
    return e;
  }
  function ga(e, t, r, n) {
    for (var i = t.length, a = 0; a < i; a++) e[a] = t[a] + r[a] * n;
    return e;
  }
  function Ph(e, t, r, n) {
    for (var i = t.length, a = i && t[0].length, o = 0; o < i; o++) {
      e[o] || (e[o] = []);
      for (var s = 0; s < a; s++) e[o][s] = t[o][s] + r[o][s] * n;
    }
    return e;
  }
  function M_(e, t) {
    for (var r = e.length, n = t.length, i = r > n ? t : e, a = Math.min(r, n), o = i[a - 1] || {
      color: [
        0,
        0,
        0,
        0
      ],
      offset: 0
    }, s = a; s < Math.max(r, n); s++) i.push({
      offset: o.offset,
      color: o.color.slice()
    });
  }
  function C_(e, t, r) {
    var n = e, i = t;
    if (!(!n.push || !i.push)) {
      var a = n.length, o = i.length;
      if (a !== o) {
        var s = a > o;
        if (s) n.length = o;
        else for (var u = a; u < o; u++) n.push(r === 1 ? i[u] : qu.call(i[u]));
      }
      for (var l = n[0] && n[0].length, u = 0; u < n.length; u++) if (r === 1) isNaN(n[u]) && (n[u] = i[u]);
      else for (var f = 0; f < l; f++) isNaN(n[u][f]) && (n[u][f] = i[u][f]);
    }
  }
  function qa(e) {
    if (Rt(e)) {
      var t = e.length;
      if (Rt(e[0])) {
        for (var r = [], n = 0; n < t; n++) r.push(qu.call(e[n]));
        return r;
      }
      return qu.call(e);
    }
    return e;
  }
  function Xa(e) {
    return e[0] = Math.floor(e[0]) || 0, e[1] = Math.floor(e[1]) || 0, e[2] = Math.floor(e[2]) || 0, e[3] = e[3] == null ? 1 : e[3], "rgba(" + e.join(",") + ")";
  }
  function D_(e) {
    return Rt(e && e[0]) ? 2 : 1;
  }
  var ya = 0, $a = 1, ud = 2, _i = 3, Xu = 4, $u = 5, Ih = 6;
  function Ah(e) {
    return e === Xu || e === $u;
  }
  function ma(e) {
    return e === $a || e === ud;
  }
  var ii = [
    0,
    0,
    0,
    0
  ], x_ = (function() {
    function e(t) {
      this.keyframes = [], this.discrete = false, this._invalid = false, this._needsSort = false, this._lastFr = 0, this._lastFrP = 0, this.propName = t;
    }
    return e.prototype.isFinished = function() {
      return this._finished;
    }, e.prototype.setFinished = function() {
      this._finished = true, this._additiveTrack && this._additiveTrack.setFinished();
    }, e.prototype.needsAnimate = function() {
      return this.keyframes.length >= 1;
    }, e.prototype.getAdditiveTrack = function() {
      return this._additiveTrack;
    }, e.prototype.addKeyframe = function(t, r, n) {
      this._needsSort = true;
      var i = this.keyframes, a = i.length, o = false, s = Ih, u = r;
      if (Rt(r)) {
        var l = D_(r);
        s = l, (l === 1 && !lt(r[0]) || l === 2 && !lt(r[0][0])) && (o = true);
      } else if (lt(r) && !Bi(r)) s = ya;
      else if (V(r)) if (!isNaN(+r)) s = ya;
      else {
        var f = Yt(r);
        f && (u = f, s = _i);
      }
      else if (Oo(r)) {
        var h = O({}, u);
        h.colorStops = F(r.colorStops, function(v) {
          return {
            offset: v.offset,
            color: Yt(v.color)
          };
        }), nd(r) ? s = Xu : id(r) && (s = $u), u = h;
      }
      a === 0 ? this.valType = s : (s !== this.valType || s === Ih) && (o = true), this.discrete = this.discrete || o;
      var c = {
        time: t,
        value: u,
        rawValue: r,
        percent: 0
      };
      return n && (c.easing = n, c.easingFunc = Y(n) ? n : xi[n] || Wl(n)), i.push(c), c;
    }, e.prototype.prepare = function(t, r) {
      var n = this.keyframes;
      this._needsSort && n.sort(function(y, g) {
        return y.time - g.time;
      });
      for (var i = this.valType, a = n.length, o = n[a - 1], s = this.discrete, u = ma(i), l = Ah(i), f = 0; f < a; f++) {
        var h = n[f], c = h.value, v = o.value;
        h.percent = h.time / t, s || (u && f !== a - 1 ? C_(c, v, i) : l && M_(c.colorStops, v.colorStops));
      }
      if (!s && i !== $u && r && this.needsAnimate() && r.needsAnimate() && i === r.valType && !r._finished) {
        this._additiveTrack = r;
        for (var p = n[0].value, f = 0; f < a; f++) i === ya ? n[f].additiveValue = n[f].value - p : i === _i ? n[f].additiveValue = ga([], n[f].value, p, -1) : ma(i) && (n[f].additiveValue = i === $a ? ga([], n[f].value, p, -1) : Ph([], n[f].value, p, -1));
      }
    }, e.prototype.step = function(t, r) {
      if (!this._finished) {
        this._additiveTrack && this._additiveTrack._finished && (this._additiveTrack = null);
        var n = this._additiveTrack != null, i = n ? "additiveValue" : "value", a = this.valType, o = this.keyframes, s = o.length, u = this.propName, l = a === _i, f, h = this._lastFr, c = Math.min, v, p;
        if (s === 1) v = p = o[0];
        else {
          if (r < 0) f = 0;
          else if (r < this._lastFrP) {
            var y = c(h + 1, s - 1);
            for (f = y; f >= 0 && !(o[f].percent <= r); f--) ;
            f = c(f, s - 2);
          } else {
            for (f = h; f < s && !(o[f].percent > r); f++) ;
            f = c(f - 1, s - 2);
          }
          p = o[f + 1], v = o[f];
        }
        if (v && p) {
          this._lastFr = f, this._lastFrP = r;
          var g = p.percent - v.percent, d = g === 0 ? 1 : c((r - v.percent) / g, 1);
          p.easingFunc && (d = p.easingFunc(d));
          var m = n ? this._additiveValue : l ? ii : t[u];
          if ((ma(a) || l) && !m && (m = this._additiveValue = []), this.discrete) t[u] = d < 1 ? v.rawValue : p.rawValue;
          else if (ma(a)) a === $a ? Ls(m, v[i], p[i], d) : T_(m, v[i], p[i], d);
          else if (Ah(a)) {
            var _ = v[i], S = p[i], T = a === Xu;
            t[u] = {
              type: T ? "linear" : "radial",
              x: Ue(_.x, S.x, d),
              y: Ue(_.y, S.y, d),
              colorStops: F(_.colorStops, function(w, D) {
                var C = S.colorStops[D];
                return {
                  offset: Ue(w.offset, C.offset, d),
                  color: Xa(Ls([], w.color, C.color, d))
                };
              }),
              global: S.global
            }, T ? (t[u].x2 = Ue(_.x2, S.x2, d), t[u].y2 = Ue(_.y2, S.y2, d)) : t[u].r = Ue(_.r, S.r, d);
          } else if (l) Ls(m, v[i], p[i], d), n || (t[u] = Xa(m));
          else {
            var b = Ue(v[i], p[i], d);
            n ? this._additiveValue = b : t[u] = b;
          }
          n && this._addToTarget(t);
        }
      }
    }, e.prototype._addToTarget = function(t) {
      var r = this.valType, n = this.propName, i = this._additiveValue;
      r === ya ? t[n] = t[n] + i : r === _i ? (Yt(t[n], ii), ga(ii, ii, i, 1), t[n] = Xa(ii)) : r === $a ? ga(t[n], t[n], i, 1) : r === ud && Ph(t[n], t[n], i, 1);
    }, e;
  })(), Xl = (function() {
    function e(t, r, n, i) {
      if (this._tracks = {}, this._trackKeys = [], this._maxTime = 0, this._started = 0, this._clip = null, this._target = t, this._loop = r, r && i) {
        Nl("Can' use additive animation on looped animation.");
        return;
      }
      this._additiveAnimators = i, this._allowDiscrete = n;
    }
    return e.prototype.getMaxTime = function() {
      return this._maxTime;
    }, e.prototype.getDelay = function() {
      return this._delay;
    }, e.prototype.getLoop = function() {
      return this._loop;
    }, e.prototype.getTarget = function() {
      return this._target;
    }, e.prototype.changeTarget = function(t) {
      this._target = t;
    }, e.prototype.when = function(t, r, n) {
      return this.whenWithKeys(t, r, K(r), n);
    }, e.prototype.whenWithKeys = function(t, r, n, i) {
      for (var a = this._tracks, o = 0; o < n.length; o++) {
        var s = n[o], u = a[s];
        if (!u) {
          u = a[s] = new x_(s);
          var l = void 0, f = this._getAdditiveTrack(s);
          if (f) {
            var h = f.keyframes, c = h[h.length - 1];
            l = c && c.value, f.valType === _i && l && (l = Xa(l));
          } else l = this._target[s];
          if (l == null) continue;
          t > 0 && u.addKeyframe(0, qa(l), i), this._trackKeys.push(s);
        }
        u.addKeyframe(t, qa(r[s]), i);
      }
      return this._maxTime = Math.max(this._maxTime, t), this;
    }, e.prototype.pause = function() {
      this._clip.pause(), this._paused = true;
    }, e.prototype.resume = function() {
      this._clip.resume(), this._paused = false;
    }, e.prototype.isPaused = function() {
      return !!this._paused;
    }, e.prototype.duration = function(t) {
      return this._maxTime = t, this._force = true, this;
    }, e.prototype._doneCallback = function() {
      this._setTracksFinished(), this._clip = null;
      var t = this._doneCbs;
      if (t) for (var r = t.length, n = 0; n < r; n++) t[n].call(this);
    }, e.prototype._abortedCallback = function() {
      this._setTracksFinished();
      var t = this.animation, r = this._abortedCbs;
      if (t && t.removeClip(this._clip), this._clip = null, r) for (var n = 0; n < r.length; n++) r[n].call(this);
    }, e.prototype._setTracksFinished = function() {
      for (var t = this._tracks, r = this._trackKeys, n = 0; n < r.length; n++) t[r[n]].setFinished();
    }, e.prototype._getAdditiveTrack = function(t) {
      var r, n = this._additiveAnimators;
      if (n) for (var i = 0; i < n.length; i++) {
        var a = n[i].getTrack(t);
        a && (r = a);
      }
      return r;
    }, e.prototype.start = function(t) {
      if (!(this._started > 0)) {
        this._started = 1;
        for (var r = this, n = [], i = this._maxTime || 0, a = 0; a < this._trackKeys.length; a++) {
          var o = this._trackKeys[a], s = this._tracks[o], u = this._getAdditiveTrack(o), l = s.keyframes, f = l.length;
          if (s.prepare(i, u), s.needsAnimate()) if (!this._allowDiscrete && s.discrete) {
            var h = l[f - 1];
            h && (r._target[s.propName] = h.rawValue), s.setFinished();
          } else n.push(s);
        }
        if (n.length || this._force) {
          var c = new a_({
            life: i,
            loop: this._loop,
            delay: this._delay || 0,
            onframe: function(v) {
              r._started = 2;
              var p = r._additiveAnimators;
              if (p) {
                for (var y = false, g = 0; g < p.length; g++) if (p[g]._clip) {
                  y = true;
                  break;
                }
                y || (r._additiveAnimators = null);
              }
              for (var g = 0; g < n.length; g++) n[g].step(r._target, v);
              var d = r._onframeCbs;
              if (d) for (var g = 0; g < d.length; g++) d[g](r._target, v);
            },
            ondestroy: function() {
              r._doneCallback();
            }
          });
          this._clip = c, this.animation && this.animation.addClip(c), t && c.setEasing(t);
        } else this._doneCallback();
        return this;
      }
    }, e.prototype.stop = function(t) {
      if (this._clip) {
        var r = this._clip;
        t && r.onframe(1), this._abortedCallback();
      }
    }, e.prototype.delay = function(t) {
      return this._delay = t, this;
    }, e.prototype.during = function(t) {
      return t && (this._onframeCbs || (this._onframeCbs = []), this._onframeCbs.push(t)), this;
    }, e.prototype.done = function(t) {
      return t && (this._doneCbs || (this._doneCbs = []), this._doneCbs.push(t)), this;
    }, e.prototype.aborted = function(t) {
      return t && (this._abortedCbs || (this._abortedCbs = []), this._abortedCbs.push(t)), this;
    }, e.prototype.getClip = function() {
      return this._clip;
    }, e.prototype.getTrack = function(t) {
      return this._tracks[t];
    }, e.prototype.getTracks = function() {
      var t = this;
      return F(this._trackKeys, function(r) {
        return t._tracks[r];
      });
    }, e.prototype.stopTracks = function(t, r) {
      if (!t.length || !this._clip) return true;
      for (var n = this._tracks, i = this._trackKeys, a = 0; a < t.length; a++) {
        var o = n[t[a]];
        o && !o.isFinished() && (r ? o.step(this._target, 1) : this._started === 1 && o.step(this._target, 0), o.setFinished());
      }
      for (var s = true, a = 0; a < i.length; a++) if (!n[i[a]].isFinished()) {
        s = false;
        break;
      }
      return s && this._abortedCallback(), s;
    }, e.prototype.saveTo = function(t, r, n) {
      if (t) {
        r = r || this._trackKeys;
        for (var i = 0; i < r.length; i++) {
          var a = r[i], o = this._tracks[a];
          if (!(!o || o.isFinished())) {
            var s = o.keyframes, u = s[n ? 0 : s.length - 1];
            u && (t[a] = qa(u.rawValue));
          }
        }
      }
    }, e.prototype.__changeFinalValue = function(t, r) {
      r = r || K(t);
      for (var n = 0; n < r.length; n++) {
        var i = r[n], a = this._tracks[i];
        if (a) {
          var o = a.keyframes;
          if (o.length > 1) {
            var s = o.pop();
            a.addKeyframe(s.time, t[i]), a.prepare(this._maxTime, a.getAdditiveTrack());
          }
        }
      }
    }, e;
  })();
  function Cn() {
    return (/* @__PURE__ */ new Date()).getTime();
  }
  var P_ = (function(e) {
    ot(t, e);
    function t(r) {
      var n = e.call(this) || this;
      return n._running = false, n._time = 0, n._pausedTime = 0, n._pauseStart = 0, n._paused = false, r = r || {}, n.stage = r.stage || {}, n;
    }
    return t.prototype.addClip = function(r) {
      r.animation && this.removeClip(r), this._head ? (this._tail.next = r, r.prev = this._tail, r.next = null, this._tail = r) : this._head = this._tail = r, r.animation = this;
    }, t.prototype.addAnimator = function(r) {
      r.animation = this;
      var n = r.getClip();
      n && this.addClip(n);
    }, t.prototype.removeClip = function(r) {
      if (r.animation) {
        var n = r.prev, i = r.next;
        n ? n.next = i : this._head = i, i ? i.prev = n : this._tail = n, r.next = r.prev = r.animation = null;
      }
    }, t.prototype.removeAnimator = function(r) {
      var n = r.getClip();
      n && this.removeClip(n), r.animation = null;
    }, t.prototype.update = function(r) {
      for (var n = Cn() - this._pausedTime, i = n - this._time, a = this._head; a; ) {
        var o = a.next, s = a.step(n, i);
        s && (a.ondestroy(), this.removeClip(a)), a = o;
      }
      this._time = n, r || (this.trigger("frame", i), this.stage.update && this.stage.update());
    }, t.prototype._startLoop = function() {
      var r = this;
      this._running = true;
      function n() {
        r._running && (Gu(n), !r._paused && r.update());
      }
      Gu(n);
    }, t.prototype.start = function() {
      this._running || (this._time = Cn(), this._pausedTime = 0, this._startLoop());
    }, t.prototype.stop = function() {
      this._running = false;
    }, t.prototype.pause = function() {
      this._paused || (this._pauseStart = Cn(), this._paused = true);
    }, t.prototype.resume = function() {
      this._paused && (this._pausedTime += Cn() - this._pauseStart, this._paused = false);
    }, t.prototype.clear = function() {
      for (var r = this._head; r; ) {
        var n = r.next;
        r.prev = r.next = r.animation = null, r = n;
      }
      this._head = this._tail = null;
    }, t.prototype.isFinished = function() {
      return this._head == null;
    }, t.prototype.animate = function(r, n) {
      n = n || {}, this.start();
      var i = new Xl(r, n.loop);
      return this.addAnimator(i), i;
    }, t;
  })($e), I_ = 300, Rs = j.domSupported, Os = (function() {
    var e = [
      "click",
      "dblclick",
      "mousewheel",
      "wheel",
      "mouseout",
      "mouseup",
      "mousedown",
      "mousemove",
      "contextmenu"
    ], t = [
      "touchstart",
      "touchend",
      "touchmove"
    ], r = {
      pointerdown: 1,
      pointerup: 1,
      pointermove: 1,
      pointerout: 1
    }, n = F(e, function(i) {
      var a = i.replace("mouse", "pointer");
      return r.hasOwnProperty(a) ? a : i;
    });
    return {
      mouse: e,
      touch: t,
      pointer: n
    };
  })(), Eh = {
    mouse: [
      "mousemove",
      "mouseup"
    ],
    pointer: [
      "pointermove",
      "pointerup"
    ]
  }, Lh = false;
  function Zu(e) {
    var t = e.pointerType;
    return t === "pen" || t === "touch";
  }
  function A_(e) {
    e.touching = true, e.touchTimer != null && (clearTimeout(e.touchTimer), e.touchTimer = null), e.touchTimer = setTimeout(function() {
      e.touching = false, e.touchTimer = null;
    }, 700);
  }
  function ks(e) {
    e && (e.zrByTouch = true);
  }
  function E_(e, t) {
    return pe(e.dom, new L_(e, t), true);
  }
  function ld(e, t) {
    for (var r = t, n = false; r && r.nodeType !== 9 && !(n = r.domBelongToZr || r !== t && r === e.painterRoot); ) r = r.parentNode;
    return n;
  }
  var L_ = /* @__PURE__ */ (function() {
    function e(t, r) {
      this.stopPropagation = zt, this.stopImmediatePropagation = zt, this.preventDefault = zt, this.type = r.type, this.target = this.currentTarget = t.dom, this.pointerType = r.pointerType, this.clientX = r.clientX, this.clientY = r.clientY;
    }
    return e;
  })(), de = {
    mousedown: function(e) {
      e = pe(this.dom, e), this.__mayPointerCapture = [
        e.zrX,
        e.zrY
      ], this.trigger("mousedown", e);
    },
    mousemove: function(e) {
      e = pe(this.dom, e);
      var t = this.__mayPointerCapture;
      t && (e.zrX !== t[0] || e.zrY !== t[1]) && this.__togglePointerCapture(true), this.trigger("mousemove", e);
    },
    mouseup: function(e) {
      e = pe(this.dom, e), this.__togglePointerCapture(false), this.trigger("mouseup", e);
    },
    mouseout: function(e) {
      e = pe(this.dom, e);
      var t = e.toElement || e.relatedTarget;
      ld(this, t) || (this.__pointerCapturing && (e.zrEventControl = "no_globalout"), this.trigger("mouseout", e));
    },
    wheel: function(e) {
      Lh = true, e = pe(this.dom, e), this.trigger("mousewheel", e);
    },
    mousewheel: function(e) {
      Lh || (e = pe(this.dom, e), this.trigger("mousewheel", e));
    },
    touchstart: function(e) {
      e = pe(this.dom, e), ks(e), this.__lastTouchMoment = /* @__PURE__ */ new Date(), this.handler.processGesture(e, "start"), de.mousemove.call(this, e), de.mousedown.call(this, e);
    },
    touchmove: function(e) {
      e = pe(this.dom, e), ks(e), this.handler.processGesture(e, "change"), de.mousemove.call(this, e);
    },
    touchend: function(e) {
      e = pe(this.dom, e), ks(e), this.handler.processGesture(e, "end"), de.mouseup.call(this, e), +/* @__PURE__ */ new Date() - +this.__lastTouchMoment < I_ && de.click.call(this, e);
    },
    pointerdown: function(e) {
      de.mousedown.call(this, e);
    },
    pointermove: function(e) {
      Zu(e) || de.mousemove.call(this, e);
    },
    pointerup: function(e) {
      de.mouseup.call(this, e);
    },
    pointerout: function(e) {
      Zu(e) || de.mouseout.call(this, e);
    }
  };
  P([
    "click",
    "dblclick",
    "contextmenu"
  ], function(e) {
    de[e] = function(t) {
      t = pe(this.dom, t), this.trigger(e, t);
    };
  });
  var Ku = {
    pointermove: function(e) {
      Zu(e) || Ku.mousemove.call(this, e);
    },
    pointerup: function(e) {
      Ku.mouseup.call(this, e);
    },
    mousemove: function(e) {
      this.trigger("mousemove", e);
    },
    mouseup: function(e) {
      var t = this.__pointerCapturing;
      this.__togglePointerCapture(false), this.trigger("mouseup", e), t && (e.zrEventControl = "only_globalout", this.trigger("mouseout", e));
    }
  };
  function R_(e, t) {
    var r = t.domHandlers;
    j.pointerEventsSupported ? P(Os.pointer, function(n) {
      Za(t, n, function(i) {
        r[n].call(e, i);
      });
    }) : (j.touchEventsSupported && P(Os.touch, function(n) {
      Za(t, n, function(i) {
        r[n].call(e, i), A_(t);
      });
    }), P(Os.mouse, function(n) {
      Za(t, n, function(i) {
        i = Gl(i), t.touching || r[n].call(e, i);
      });
    }));
  }
  function O_(e, t) {
    j.pointerEventsSupported ? P(Eh.pointer, r) : j.touchEventsSupported || P(Eh.mouse, r);
    function r(n) {
      function i(a) {
        a = Gl(a), ld(e, a.target) || (a = E_(e, a), t.domHandlers[n].call(e, a));
      }
      Za(t, n, i, {
        capture: true
      });
    }
  }
  function Za(e, t, r, n) {
    e.mounted[t] = r, e.listenerOpts[t] = n, Fm(e.domTarget, t, r, n);
  }
  function Ns(e) {
    var t = e.mounted;
    for (var r in t) t.hasOwnProperty(r) && Bm(e.domTarget, r, t[r], e.listenerOpts[r]);
    e.mounted = {};
  }
  var Rh = /* @__PURE__ */ (function() {
    function e(t, r) {
      this.mounted = {}, this.listenerOpts = {}, this.touching = false, this.domTarget = t, this.domHandlers = r;
    }
    return e;
  })(), k_ = (function(e) {
    ot(t, e);
    function t(r, n) {
      var i = e.call(this) || this;
      return i.__pointerCapturing = false, i.dom = r, i.painterRoot = n, i._localHandlerScope = new Rh(r, de), Rs && (i._globalHandlerScope = new Rh(document, Ku)), R_(i, i._localHandlerScope), i;
    }
    return t.prototype.dispose = function() {
      Ns(this._localHandlerScope), Rs && Ns(this._globalHandlerScope);
    }, t.prototype.setCursor = function(r) {
      this.dom.style && (this.dom.style.cursor = r || "default");
    }, t.prototype.__togglePointerCapture = function(r) {
      if (this.__mayPointerCapture = null, Rs && +this.__pointerCapturing ^ +r) {
        this.__pointerCapturing = r;
        var n = this._globalHandlerScope;
        r ? O_(this, n) : Ns(n);
      }
    }, t;
  })($e), fd = 1;
  j.hasGlobalWindow && (fd = Math.max(window.devicePixelRatio || window.screen && window.screen.deviceXDPI / window.screen.logicalXDPI || 1, 1));
  let ju, Qu, Ju, N_, kh, Nh;
  Oh = fd;
  ju = 0.4;
  Qu = "#333";
  Ju = "#ccc";
  N_ = "#eee";
  kh = No;
  Nh = 5e-5;
  function Mr(e) {
    return e > Nh || e < -Nh;
  }
  var Cr = [], fn = [], Fs = hr(), Bs = Math.abs, $l = (function() {
    function e() {
    }
    return e.prototype.getLocalTransform = function(t) {
      return e.getLocalTransform(this, t);
    }, e.prototype.setPosition = function(t) {
      this.x = t[0], this.y = t[1];
    }, e.prototype.setScale = function(t) {
      this.scaleX = t[0], this.scaleY = t[1];
    }, e.prototype.setSkew = function(t) {
      this.skewX = t[0], this.skewY = t[1];
    }, e.prototype.setOrigin = function(t) {
      this.originX = t[0], this.originY = t[1];
    }, e.prototype.needLocalTransform = function() {
      return Mr(this.rotation) || Mr(this.x) || Mr(this.y) || Mr(this.scaleX - 1) || Mr(this.scaleY - 1) || Mr(this.skewX) || Mr(this.skewY);
    }, e.prototype.updateTransform = function() {
      var t = this.parent && this.parent.transform, r = this.needLocalTransform(), n = this.transform;
      if (!(r || t)) {
        n && (kh(n), this.invTransform = null);
        return;
      }
      n = n || hr(), r ? this.getLocalTransform(n) : kh(n), t && (r ? In(n, t, n) : Hl(n, t)), this.transform = n, this._resolveGlobalScaleRatio(n);
    }, e.prototype._resolveGlobalScaleRatio = function(t) {
      var r = this.globalScaleRatio;
      if (r != null && r !== 1) {
        this.getGlobalScale(Cr);
        var n = Cr[0] < 0 ? -1 : 1, i = Cr[1] < 0 ? -1 : 1, a = ((Cr[0] - n) * r + n) / Cr[0] || 0, o = ((Cr[1] - i) * r + i) / Cr[1] || 0;
        t[0] *= a, t[1] *= a, t[2] *= o, t[3] *= o;
      }
      this.invTransform = this.invTransform || hr(), Fo(this.invTransform, t);
    }, e.prototype.getComputedTransform = function() {
      for (var t = this, r = []; t; ) r.push(t), t = t.parent;
      for (; t = r.pop(); ) t.updateTransform();
      return this.transform;
    }, e.prototype.setLocalTransform = function(t) {
      if (t) {
        var r = t[0] * t[0] + t[1] * t[1], n = t[2] * t[2] + t[3] * t[3], i = Math.atan2(t[1], t[0]), a = Math.PI / 2 + i - Math.atan2(t[3], t[2]);
        n = Math.sqrt(n) * Math.cos(a), r = Math.sqrt(r), this.skewX = a, this.skewY = 0, this.rotation = -i, this.x = +t[4], this.y = +t[5], this.scaleX = r, this.scaleY = n, this.originX = 0, this.originY = 0;
      }
    }, e.prototype.decomposeTransform = function() {
      if (this.transform) {
        var t = this.parent, r = this.transform;
        t && t.transform && (t.invTransform = t.invTransform || hr(), In(fn, t.invTransform, r), r = fn);
        var n = this.originX, i = this.originY;
        (n || i) && (Fs[4] = n, Fs[5] = i, In(fn, r, Fs), fn[4] -= n, fn[5] -= i, r = fn), this.setLocalTransform(r);
      }
    }, e.prototype.getGlobalScale = function(t) {
      var r = this.transform;
      return t = t || [], r ? (t[0] = Math.sqrt(r[0] * r[0] + r[1] * r[1]), t[1] = Math.sqrt(r[2] * r[2] + r[3] * r[3]), r[0] < 0 && (t[0] = -t[0]), r[3] < 0 && (t[1] = -t[1]), t) : (t[0] = 1, t[1] = 1, t);
    }, e.prototype.transformCoordToLocal = function(t, r) {
      var n = [
        t,
        r
      ], i = this.invTransform;
      return i && Ye(n, n, i), n;
    }, e.prototype.transformCoordToGlobal = function(t, r) {
      var n = [
        t,
        r
      ], i = this.transform;
      return i && Ye(n, n, i), n;
    }, e.prototype.getLineScale = function() {
      var t = this.transform;
      return t && Bs(t[0] - 1) > 1e-10 && Bs(t[3] - 1) > 1e-10 ? Math.sqrt(Bs(t[0] * t[3] - t[2] * t[1])) : 1;
    }, e.prototype.copyTransform = function(t) {
      hd(this, t);
    }, e.getLocalTransform = function(t, r) {
      r = r || [];
      var n = t.originX || 0, i = t.originY || 0, a = t.scaleX, o = t.scaleY, s = t.anchorX, u = t.anchorY, l = t.rotation || 0, f = t.x, h = t.y, c = t.skewX ? Math.tan(t.skewX) : 0, v = t.skewY ? Math.tan(-t.skewY) : 0;
      if (n || i || s || u) {
        var p = n + s, y = i + u;
        r[4] = -p * a - c * y * o, r[5] = -y * o - v * p * a;
      } else r[4] = r[5] = 0;
      return r[0] = a, r[3] = o, r[1] = v * a, r[2] = c * o, l && Ul(r, r, l), r[4] += n + f, r[5] += i + h, r;
    }, e.initDefaultProps = (function() {
      var t = e.prototype;
      t.scaleX = t.scaleY = t.globalScaleRatio = 1, t.x = t.y = t.originX = t.originY = t.skewX = t.skewY = t.rotation = t.anchorX = t.anchorY = 0;
    })(), e;
  })(), Ui = [
    "x",
    "y",
    "originX",
    "originY",
    "anchorX",
    "anchorY",
    "rotation",
    "scaleX",
    "scaleY",
    "skewX",
    "skewY"
  ];
  function hd(e, t) {
    for (var r = 0; r < Ui.length; r++) {
      var n = Ui[r];
      e[n] = t[n];
    }
  }
  var Fh = {};
  function qt(e, t) {
    t = t || pr;
    var r = Fh[t];
    r || (r = Fh[t] = new ra(500));
    var n = r.get(e);
    return n == null && (n = dr.measureText(e, t).width, r.put(e, n)), n;
  }
  function Bh(e, t, r, n) {
    var i = qt(e, t), a = zo(t), o = Si(0, i, r), s = Tn(0, a, n), u = new at(o, s, i, a);
    return u;
  }
  vd = function(e, t, r, n) {
    var i = ((e || "") + "").split(`
`), a = i.length;
    if (a === 1) return Bh(i[0], t, r, n);
    for (var o = new at(0, 0, 0, 0), s = 0; s < i.length; s++) {
      var u = Bh(i[s], t, r, n);
      s === 0 ? o.copy(u) : o.union(u);
    }
    return o;
  };
  function Si(e, t, r) {
    return r === "right" ? e -= t : r === "center" && (e -= t / 2), e;
  }
  function Tn(e, t, r) {
    return r === "middle" ? e -= t / 2 : r === "bottom" && (e -= t), e;
  }
  function zo(e) {
    return qt("\u56FD", e);
  }
  function gr(e, t) {
    return typeof e == "string" ? e.lastIndexOf("%") >= 0 ? parseFloat(e) / 100 * t : parseFloat(e) : e;
  }
  function cd(e, t, r) {
    var n = t.position || "inside", i = t.distance != null ? t.distance : 5, a = r.height, o = r.width, s = a / 2, u = r.x, l = r.y, f = "left", h = "top";
    if (n instanceof Array) u += gr(n[0], r.width), l += gr(n[1], r.height), f = null, h = null;
    else switch (n) {
      case "left":
        u -= i, l += s, f = "right", h = "middle";
        break;
      case "right":
        u += i + o, l += s, h = "middle";
        break;
      case "top":
        u += o / 2, l -= i, f = "center", h = "bottom";
        break;
      case "bottom":
        u += o / 2, l += a + i, f = "center";
        break;
      case "inside":
        u += o / 2, l += s, f = "center", h = "middle";
        break;
      case "insideLeft":
        u += i, l += s, h = "middle";
        break;
      case "insideRight":
        u += o - i, l += s, f = "right", h = "middle";
        break;
      case "insideTop":
        u += o / 2, l += i, f = "center";
        break;
      case "insideBottom":
        u += o / 2, l += a - i, f = "center", h = "bottom";
        break;
      case "insideTopLeft":
        u += i, l += i;
        break;
      case "insideTopRight":
        u += o - i, l += i, f = "right";
        break;
      case "insideBottomLeft":
        u += i, l += a - i, h = "bottom";
        break;
      case "insideBottomRight":
        u += o - i, l += a - i, f = "right", h = "bottom";
        break;
    }
    return e = e || {}, e.x = u, e.y = l, e.align = f, e.verticalAlign = h, e;
  }
  var zs = "__zr_normal__", Vs = Ui.concat([
    "ignore"
  ]), F_ = Le(Ui, function(e, t) {
    return e[t] = true, e;
  }, {
    ignore: false
  }), hn = {}, B_ = new at(0, 0, 0, 0), Vo = (function() {
    function e(t) {
      this.id = kl(), this.animators = [], this.currentStates = [], this.states = {}, this._init(t);
    }
    return e.prototype._init = function(t) {
      this.attr(t);
    }, e.prototype.drift = function(t, r, n) {
      switch (this.draggable) {
        case "horizontal":
          r = 0;
          break;
        case "vertical":
          t = 0;
          break;
      }
      var i = this.transform;
      i || (i = this.transform = [
        1,
        0,
        0,
        1,
        0,
        0
      ]), i[4] += t, i[5] += r, this.decomposeTransform(), this.markRedraw();
    }, e.prototype.beforeUpdate = function() {
    }, e.prototype.afterUpdate = function() {
    }, e.prototype.update = function() {
      this.updateTransform(), this.__dirty && this.updateInnerText();
    }, e.prototype.updateInnerText = function(t) {
      var r = this._textContent;
      if (r && (!r.ignore || t)) {
        this.textConfig || (this.textConfig = {});
        var n = this.textConfig, i = n.local, a = r.innerTransformable, o = void 0, s = void 0, u = false;
        a.parent = i ? this : null;
        var l = false;
        if (a.copyTransform(r), n.position != null) {
          var f = B_;
          n.layoutRect ? f.copy(n.layoutRect) : f.copy(this.getBoundingRect()), i || f.applyTransform(this.transform), this.calculateTextPosition ? this.calculateTextPosition(hn, n, f) : cd(hn, n, f), a.x = hn.x, a.y = hn.y, o = hn.align, s = hn.verticalAlign;
          var h = n.origin;
          if (h && n.rotation != null) {
            var c = void 0, v = void 0;
            h === "center" ? (c = f.width * 0.5, v = f.height * 0.5) : (c = gr(h[0], f.width), v = gr(h[1], f.height)), l = true, a.originX = -a.x + c + (i ? 0 : f.x), a.originY = -a.y + v + (i ? 0 : f.y);
          }
        }
        n.rotation != null && (a.rotation = n.rotation);
        var p = n.offset;
        p && (a.x += p[0], a.y += p[1], l || (a.originX = -p[0], a.originY = -p[1]));
        var y = n.inside == null ? typeof n.position == "string" && n.position.indexOf("inside") >= 0 : n.inside, g = this._innerTextDefaultStyle || (this._innerTextDefaultStyle = {}), d = void 0, m = void 0, _ = void 0;
        y && this.canBeInsideText() ? (d = n.insideFill, m = n.insideStroke, (d == null || d === "auto") && (d = this.getInsideTextFill()), (m == null || m === "auto") && (m = this.getInsideTextStroke(d), _ = true)) : (d = n.outsideFill, m = n.outsideStroke, (d == null || d === "auto") && (d = this.getOutsideFill()), (m == null || m === "auto") && (m = this.getOutsideStroke(d), _ = true)), d = d || "#000", (d !== g.fill || m !== g.stroke || _ !== g.autoStroke || o !== g.align || s !== g.verticalAlign) && (u = true, g.fill = d, g.stroke = m, g.autoStroke = _, g.align = o, g.verticalAlign = s, r.setDefaultTextStyle(g)), r.__dirty |= xe, u && r.dirtyStyle(true);
      }
    }, e.prototype.canBeInsideText = function() {
      return true;
    }, e.prototype.getInsideTextFill = function() {
      return "#fff";
    }, e.prototype.getInsideTextStroke = function(t) {
      return "#000";
    }, e.prototype.getOutsideFill = function() {
      return this.__zr && this.__zr.isDarkMode() ? Ju : Qu;
    }, e.prototype.getOutsideStroke = function(t) {
      var r = this.__zr && this.__zr.getBackgroundColor(), n = typeof r == "string" && Yt(r);
      n || (n = [
        255,
        255,
        255,
        1
      ]);
      for (var i = n[3], a = this.__zr.isDarkMode(), o = 0; o < 3; o++) n[o] = n[o] * i + (a ? 0 : 255) * (1 - i);
      return n[3] = 1, an(n, "rgba");
    }, e.prototype.traverse = function(t, r) {
    }, e.prototype.attrKV = function(t, r) {
      t === "textConfig" ? this.setTextConfig(r) : t === "textContent" ? this.setTextContent(r) : t === "clipPath" ? this.setClipPath(r) : t === "extra" ? (this.extra = this.extra || {}, O(this.extra, r)) : this[t] = r;
    }, e.prototype.hide = function() {
      this.ignore = true, this.markRedraw();
    }, e.prototype.show = function() {
      this.ignore = false, this.markRedraw();
    }, e.prototype.attr = function(t, r) {
      if (typeof t == "string") this.attrKV(t, r);
      else if (G(t)) for (var n = t, i = K(n), a = 0; a < i.length; a++) {
        var o = i[a];
        this.attrKV(o, t[o]);
      }
      return this.markRedraw(), this;
    }, e.prototype.saveCurrentToNormalState = function(t) {
      this._innerSaveToNormal(t);
      for (var r = this._normalState, n = 0; n < this.animators.length; n++) {
        var i = this.animators[n], a = i.__fromStateTransition;
        if (!(i.getLoop() || a && a !== zs)) {
          var o = i.targetName, s = o ? r[o] : r;
          i.saveTo(s);
        }
      }
    }, e.prototype._innerSaveToNormal = function(t) {
      var r = this._normalState;
      r || (r = this._normalState = {}), t.textConfig && !r.textConfig && (r.textConfig = this.textConfig), this._savePrimaryToNormal(t, r, Vs);
    }, e.prototype._savePrimaryToNormal = function(t, r, n) {
      for (var i = 0; i < n.length; i++) {
        var a = n[i];
        t[a] != null && !(a in r) && (r[a] = this[a]);
      }
    }, e.prototype.hasState = function() {
      return this.currentStates.length > 0;
    }, e.prototype.getState = function(t) {
      return this.states[t];
    }, e.prototype.ensureState = function(t) {
      var r = this.states;
      return r[t] || (r[t] = {}), r[t];
    }, e.prototype.clearStates = function(t) {
      this.useState(zs, false, t);
    }, e.prototype.useState = function(t, r, n, i) {
      var a = t === zs, o = this.hasState();
      if (!(!o && a)) {
        var s = this.currentStates, u = this.stateTransition;
        if (!(vt(s, t) >= 0 && (r || s.length === 1))) {
          var l;
          if (this.stateProxy && !a && (l = this.stateProxy(t)), l || (l = this.states && this.states[t]), !l && !a) {
            Nl("State " + t + " not exists.");
            return;
          }
          a || this.saveCurrentToNormalState(l);
          var f = !!(l && l.hoverLayer || i);
          f && this._toggleHoverLayerFlag(true), this._applyStateObj(t, l, this._normalState, r, !n && !this.__inHover && u && u.duration > 0, u);
          var h = this._textContent, c = this._textGuide;
          return h && h.useState(t, r, n, f), c && c.useState(t, r, n, f), a ? (this.currentStates = [], this._normalState = {}) : r ? this.currentStates.push(t) : this.currentStates = [
            t
          ], this._updateAnimationTargets(), this.markRedraw(), !f && this.__inHover && (this._toggleHoverLayerFlag(false), this.__dirty &= ~xe), l;
        }
      }
    }, e.prototype.useStates = function(t, r, n) {
      if (!t.length) this.clearStates();
      else {
        var i = [], a = this.currentStates, o = t.length, s = o === a.length;
        if (s) {
          for (var u = 0; u < o; u++) if (t[u] !== a[u]) {
            s = false;
            break;
          }
        }
        if (s) return;
        for (var u = 0; u < o; u++) {
          var l = t[u], f = void 0;
          this.stateProxy && (f = this.stateProxy(l, t)), f || (f = this.states[l]), f && i.push(f);
        }
        var h = i[o - 1], c = !!(h && h.hoverLayer || n);
        c && this._toggleHoverLayerFlag(true);
        var v = this._mergeStates(i), p = this.stateTransition;
        this.saveCurrentToNormalState(v), this._applyStateObj(t.join(","), v, this._normalState, false, !r && !this.__inHover && p && p.duration > 0, p);
        var y = this._textContent, g = this._textGuide;
        y && y.useStates(t, r, c), g && g.useStates(t, r, c), this._updateAnimationTargets(), this.currentStates = t.slice(), this.markRedraw(), !c && this.__inHover && (this._toggleHoverLayerFlag(false), this.__dirty &= ~xe);
      }
    }, e.prototype.isSilent = function() {
      for (var t = this.silent, r = this.parent; !t && r; ) {
        if (r.silent) {
          t = true;
          break;
        }
        r = r.parent;
      }
      return t;
    }, e.prototype._updateAnimationTargets = function() {
      for (var t = 0; t < this.animators.length; t++) {
        var r = this.animators[t];
        r.targetName && r.changeTarget(this[r.targetName]);
      }
    }, e.prototype.removeState = function(t) {
      var r = vt(this.currentStates, t);
      if (r >= 0) {
        var n = this.currentStates.slice();
        n.splice(r, 1), this.useStates(n);
      }
    }, e.prototype.replaceState = function(t, r, n) {
      var i = this.currentStates.slice(), a = vt(i, t), o = vt(i, r) >= 0;
      a >= 0 ? o ? i.splice(a, 1) : i[a] = r : n && !o && i.push(r), this.useStates(i);
    }, e.prototype.toggleState = function(t, r) {
      r ? this.useState(t, true) : this.removeState(t);
    }, e.prototype._mergeStates = function(t) {
      for (var r = {}, n, i = 0; i < t.length; i++) {
        var a = t[i];
        O(r, a), a.textConfig && (n = n || {}, O(n, a.textConfig));
      }
      return n && (r.textConfig = n), r;
    }, e.prototype._applyStateObj = function(t, r, n, i, a, o) {
      var s = !(r && i);
      r && r.textConfig ? (this.textConfig = O({}, i ? this.textConfig : n.textConfig), O(this.textConfig, r.textConfig)) : s && n.textConfig && (this.textConfig = n.textConfig);
      for (var u = {}, l = false, f = 0; f < Vs.length; f++) {
        var h = Vs[f], c = a && F_[h];
        r && r[h] != null ? c ? (l = true, u[h] = r[h]) : this[h] = r[h] : s && n[h] != null && (c ? (l = true, u[h] = n[h]) : this[h] = n[h]);
      }
      if (!a) for (var f = 0; f < this.animators.length; f++) {
        var v = this.animators[f], p = v.targetName;
        v.getLoop() || v.__changeFinalValue(p ? (r || n)[p] : r || n);
      }
      l && this._transitionState(t, u, o);
    }, e.prototype._attachComponent = function(t) {
      if (!(t.__zr && !t.__hostTarget) && t !== this) {
        var r = this.__zr;
        r && t.addSelfToZr(r), t.__zr = r, t.__hostTarget = this;
      }
    }, e.prototype._detachComponent = function(t) {
      t.__zr && t.removeSelfFromZr(t.__zr), t.__zr = null, t.__hostTarget = null;
    }, e.prototype.getClipPath = function() {
      return this._clipPath;
    }, e.prototype.setClipPath = function(t) {
      this._clipPath && this._clipPath !== t && this.removeClipPath(), this._attachComponent(t), this._clipPath = t, this.markRedraw();
    }, e.prototype.removeClipPath = function() {
      var t = this._clipPath;
      t && (this._detachComponent(t), this._clipPath = null, this.markRedraw());
    }, e.prototype.getTextContent = function() {
      return this._textContent;
    }, e.prototype.setTextContent = function(t) {
      var r = this._textContent;
      r !== t && (r && r !== t && this.removeTextContent(), t.innerTransformable = new $l(), this._attachComponent(t), this._textContent = t, this.markRedraw());
    }, e.prototype.setTextConfig = function(t) {
      this.textConfig || (this.textConfig = {}), O(this.textConfig, t), this.markRedraw();
    }, e.prototype.removeTextConfig = function() {
      this.textConfig = null, this.markRedraw();
    }, e.prototype.removeTextContent = function() {
      var t = this._textContent;
      t && (t.innerTransformable = null, this._detachComponent(t), this._textContent = null, this._innerTextDefaultStyle = null, this.markRedraw());
    }, e.prototype.getTextGuideLine = function() {
      return this._textGuide;
    }, e.prototype.setTextGuideLine = function(t) {
      this._textGuide && this._textGuide !== t && this.removeTextGuideLine(), this._attachComponent(t), this._textGuide = t, this.markRedraw();
    }, e.prototype.removeTextGuideLine = function() {
      var t = this._textGuide;
      t && (this._detachComponent(t), this._textGuide = null, this.markRedraw());
    }, e.prototype.markRedraw = function() {
      this.__dirty |= xe;
      var t = this.__zr;
      t && (this.__inHover ? t.refreshHover() : t.refresh()), this.__hostTarget && this.__hostTarget.markRedraw();
    }, e.prototype.dirty = function() {
      this.markRedraw();
    }, e.prototype._toggleHoverLayerFlag = function(t) {
      this.__inHover = t;
      var r = this._textContent, n = this._textGuide;
      r && (r.__inHover = t), n && (n.__inHover = t);
    }, e.prototype.addSelfToZr = function(t) {
      if (this.__zr !== t) {
        this.__zr = t;
        var r = this.animators;
        if (r) for (var n = 0; n < r.length; n++) t.animation.addAnimator(r[n]);
        this._clipPath && this._clipPath.addSelfToZr(t), this._textContent && this._textContent.addSelfToZr(t), this._textGuide && this._textGuide.addSelfToZr(t);
      }
    }, e.prototype.removeSelfFromZr = function(t) {
      if (this.__zr) {
        this.__zr = null;
        var r = this.animators;
        if (r) for (var n = 0; n < r.length; n++) t.animation.removeAnimator(r[n]);
        this._clipPath && this._clipPath.removeSelfFromZr(t), this._textContent && this._textContent.removeSelfFromZr(t), this._textGuide && this._textGuide.removeSelfFromZr(t);
      }
    }, e.prototype.animate = function(t, r, n) {
      var i = t ? this[t] : this, a = new Xl(i, r, n);
      return t && (a.targetName = t), this.addAnimator(a, t), a;
    }, e.prototype.addAnimator = function(t, r) {
      var n = this.__zr, i = this;
      t.during(function() {
        i.updateDuringAnimation(r);
      }).done(function() {
        var a = i.animators, o = vt(a, t);
        o >= 0 && a.splice(o, 1);
      }), this.animators.push(t), n && n.animation.addAnimator(t), n && n.wakeUp();
    }, e.prototype.updateDuringAnimation = function(t) {
      this.markRedraw();
    }, e.prototype.stopAnimation = function(t, r) {
      for (var n = this.animators, i = n.length, a = [], o = 0; o < i; o++) {
        var s = n[o];
        !t || t === s.scope ? s.stop(r) : a.push(s);
      }
      return this.animators = a, this;
    }, e.prototype.animateTo = function(t, r, n) {
      Gs(this, t, r, n);
    }, e.prototype.animateFrom = function(t, r, n) {
      Gs(this, t, r, n, true);
    }, e.prototype._transitionState = function(t, r, n, i) {
      for (var a = Gs(this, r, n, i), o = 0; o < a.length; o++) a[o].__fromStateTransition = t;
    }, e.prototype.getBoundingRect = function() {
      return null;
    }, e.prototype.getPaintRect = function() {
      return null;
    }, e.initDefaultProps = (function() {
      var t = e.prototype;
      t.type = "element", t.name = "", t.ignore = t.silent = t.isGroup = t.draggable = t.dragging = t.ignoreClip = t.__inHover = false, t.__dirty = xe;
      function r(n, i, a, o) {
        Object.defineProperty(t, n, {
          get: function() {
            if (!this[i]) {
              var u = this[i] = [];
              s(this, u);
            }
            return this[i];
          },
          set: function(u) {
            this[a] = u[0], this[o] = u[1], this[i] = u, s(this, u);
          }
        });
        function s(u, l) {
          Object.defineProperty(l, 0, {
            get: function() {
              return u[a];
            },
            set: function(f) {
              u[a] = f;
            }
          }), Object.defineProperty(l, 1, {
            get: function() {
              return u[o];
            },
            set: function(f) {
              u[o] = f;
            }
          });
        }
      }
      Object.defineProperty && (r("position", "_legacyPos", "x", "y"), r("scale", "_legacyScale", "scaleX", "scaleY"), r("origin", "_legacyOrigin", "originX", "originY"));
    })(), e;
  })();
  ae(Vo, $e);
  ae(Vo, $l);
  function Gs(e, t, r, n, i) {
    r = r || {};
    var a = [];
    pd(e, "", e, t, r, n, a, i);
    var o = a.length, s = false, u = r.done, l = r.aborted, f = function() {
      s = true, o--, o <= 0 && (s ? u && u() : l && l());
    }, h = function() {
      o--, o <= 0 && (s ? u && u() : l && l());
    };
    o || u && u(), a.length > 0 && r.during && a[0].during(function(p, y) {
      r.during(y);
    });
    for (var c = 0; c < a.length; c++) {
      var v = a[c];
      f && v.done(f), h && v.aborted(h), r.force && v.duration(r.duration), v.start(r.easing);
    }
    return a;
  }
  function Hs(e, t, r) {
    for (var n = 0; n < r; n++) e[n] = t[n];
  }
  function z_(e) {
    return Rt(e[0]);
  }
  function V_(e, t, r) {
    if (Rt(t[r])) if (Rt(e[r]) || (e[r] = []), Ot(t[r])) {
      var n = t[r].length;
      e[r].length !== n && (e[r] = new t[r].constructor(n), Hs(e[r], t[r], n));
    } else {
      var i = t[r], a = e[r], o = i.length;
      if (z_(i)) for (var s = i[0].length, u = 0; u < o; u++) a[u] ? Hs(a[u], i[u], s) : a[u] = Array.prototype.slice.call(i[u]);
      else Hs(a, i, o);
      a.length = i.length;
    }
    else e[r] = t[r];
  }
  function G_(e, t) {
    return e === t || Rt(e) && Rt(t) && H_(e, t);
  }
  function H_(e, t) {
    var r = e.length;
    if (r !== t.length) return false;
    for (var n = 0; n < r; n++) if (e[n] !== t[n]) return false;
    return true;
  }
  function pd(e, t, r, n, i, a, o, s) {
    for (var u = K(n), l = i.duration, f = i.delay, h = i.additive, c = i.setToFinal, v = !G(a), p = e.animators, y = [], g = 0; g < u.length; g++) {
      var d = u[g], m = n[d];
      if (m != null && r[d] != null && (v || a[d])) if (G(m) && !Rt(m) && !Oo(m)) {
        if (t) {
          s || (r[d] = m, e.updateDuringAnimation(t));
          continue;
        }
        pd(e, d, r[d], m, i, a && a[d], o, s);
      } else y.push(d);
      else s || (r[d] = m, e.updateDuringAnimation(t), y.push(d));
    }
    var _ = y.length;
    if (!h && _) for (var S = 0; S < p.length; S++) {
      var T = p[S];
      if (T.targetName === t) {
        var b = T.stopTracks(y);
        if (b) {
          var w = vt(p, T);
          p.splice(w, 1);
        }
      }
    }
    if (i.force || (y = yt(y, function(x) {
      return !G_(n[x], r[x]);
    }), _ = y.length), _ > 0 || i.force && !o.length) {
      var D = void 0, C = void 0, M = void 0;
      if (s) {
        C = {}, c && (D = {});
        for (var S = 0; S < _; S++) {
          var d = y[S];
          C[d] = r[d], c ? D[d] = n[d] : r[d] = n[d];
        }
      } else if (c) {
        M = {};
        for (var S = 0; S < _; S++) {
          var d = y[S];
          M[d] = qa(r[d]), V_(r, n, d);
        }
      }
      var T = new Xl(r, false, false, h ? yt(p, function(I) {
        return I.targetName === t;
      }) : null);
      T.targetName = t, i.scope && (T.scope = i.scope), c && D && T.whenWithKeys(0, D, y), M && T.whenWithKeys(0, M, y), T.whenWithKeys(l ?? 500, s ? C : n, y).delay(f || 0), e.addAnimator(T, t), o.push(T);
    }
  }
  oe = (function(e) {
    ot(t, e);
    function t(r) {
      var n = e.call(this) || this;
      return n.isGroup = true, n._children = [], n.attr(r), n;
    }
    return t.prototype.childrenRef = function() {
      return this._children;
    }, t.prototype.children = function() {
      return this._children.slice();
    }, t.prototype.childAt = function(r) {
      return this._children[r];
    }, t.prototype.childOfName = function(r) {
      for (var n = this._children, i = 0; i < n.length; i++) if (n[i].name === r) return n[i];
    }, t.prototype.childCount = function() {
      return this._children.length;
    }, t.prototype.add = function(r) {
      return r && r !== this && r.parent !== this && (this._children.push(r), this._doAdd(r)), this;
    }, t.prototype.addBefore = function(r, n) {
      if (r && r !== this && r.parent !== this && n && n.parent === this) {
        var i = this._children, a = i.indexOf(n);
        a >= 0 && (i.splice(a, 0, r), this._doAdd(r));
      }
      return this;
    }, t.prototype.replace = function(r, n) {
      var i = vt(this._children, r);
      return i >= 0 && this.replaceAt(n, i), this;
    }, t.prototype.replaceAt = function(r, n) {
      var i = this._children, a = i[n];
      if (r && r !== this && r.parent !== this && r !== a) {
        i[n] = r, a.parent = null;
        var o = this.__zr;
        o && a.removeSelfFromZr(o), this._doAdd(r);
      }
      return this;
    }, t.prototype._doAdd = function(r) {
      r.parent && r.parent.remove(r), r.parent = this;
      var n = this.__zr;
      n && n !== r.__zr && r.addSelfToZr(n), n && n.refresh();
    }, t.prototype.remove = function(r) {
      var n = this.__zr, i = this._children, a = vt(i, r);
      return a < 0 ? this : (i.splice(a, 1), r.parent = null, n && r.removeSelfFromZr(n), n && n.refresh(), this);
    }, t.prototype.removeAll = function() {
      for (var r = this._children, n = this.__zr, i = 0; i < r.length; i++) {
        var a = r[i];
        n && a.removeSelfFromZr(n), a.parent = null;
      }
      return r.length = 0, this;
    }, t.prototype.eachChild = function(r, n) {
      for (var i = this._children, a = 0; a < i.length; a++) {
        var o = i[a];
        r.call(n, o, a);
      }
      return this;
    }, t.prototype.traverse = function(r, n) {
      for (var i = 0; i < this._children.length; i++) {
        var a = this._children[i], o = r.call(n, a);
        a.isGroup && !o && a.traverse(r, n);
      }
      return this;
    }, t.prototype.addSelfToZr = function(r) {
      e.prototype.addSelfToZr.call(this, r);
      for (var n = 0; n < this._children.length; n++) {
        var i = this._children[n];
        i.addSelfToZr(r);
      }
    }, t.prototype.removeSelfFromZr = function(r) {
      e.prototype.removeSelfFromZr.call(this, r);
      for (var n = 0; n < this._children.length; n++) {
        var i = this._children[n];
        i.removeSelfFromZr(r);
      }
    }, t.prototype.getBoundingRect = function(r) {
      for (var n = new at(0, 0, 0, 0), i = r || this._children, a = [], o = null, s = 0; s < i.length; s++) {
        var u = i[s];
        if (!(u.ignore || u.invisible)) {
          var l = u.getBoundingRect(), f = u.getLocalTransform(a);
          f ? (at.applyTransform(n, l, f), o = o || n.clone(), o.union(n)) : (o = o || l.clone(), o.union(l));
        }
      }
      return o || n;
    }, t;
  })(Vo);
  oe.prototype.type = "group";
  var Ka = {}, Wr = {};
  function U_(e) {
    delete Wr[e];
  }
  function W_(e) {
    if (!e) return false;
    if (typeof e == "string") return Gi(e, 1) < ju;
    if (e.colorStops) {
      for (var t = e.colorStops, r = 0, n = t.length, i = 0; i < n; i++) r += Gi(t[i].color, 1);
      return r /= n, r < ju;
    }
    return false;
  }
  var Y_ = (function() {
    function e(t, r, n) {
      var i = this;
      this._sleepAfterStill = 10, this._stillFrameAccum = 0, this._needsRefresh = true, this._needsRefreshHover = true, this._darkMode = false, n = n || {}, this.dom = r, this.id = t;
      var a = new Qm(), o = n.renderer || "canvas";
      Ka[o] || (o = K(Ka)[0]), n.useDirtyRect = n.useDirtyRect == null ? false : n.useDirtyRect;
      var s = new Ka[o](r, a, n, t), u = n.ssr || s.ssrOnly;
      this.storage = a, this.painter = s;
      var l = !j.node && !j.worker && !u ? new k_(s.getViewportRoot(), s.root) : null, f = n.useCoarsePointer, h = f == null || f === "auto" ? j.touchEventsSupported : !!f, c = 44, v;
      h && (v = W(n.pointerSize, c)), this.handler = new qp(a, s, l, s.root, v), this.animation = new P_({
        stage: {
          update: u ? null : function() {
            return i._flush(true);
          }
        }
      }), u || this.animation.start();
    }
    return e.prototype.add = function(t) {
      this._disposed || !t || (this.storage.addRoot(t), t.addSelfToZr(this), this.refresh());
    }, e.prototype.remove = function(t) {
      this._disposed || !t || (this.storage.delRoot(t), t.removeSelfFromZr(this), this.refresh());
    }, e.prototype.configLayer = function(t, r) {
      this._disposed || (this.painter.configLayer && this.painter.configLayer(t, r), this.refresh());
    }, e.prototype.setBackgroundColor = function(t) {
      this._disposed || (this.painter.setBackgroundColor && this.painter.setBackgroundColor(t), this.refresh(), this._backgroundColor = t, this._darkMode = W_(t));
    }, e.prototype.getBackgroundColor = function() {
      return this._backgroundColor;
    }, e.prototype.setDarkMode = function(t) {
      this._darkMode = t;
    }, e.prototype.isDarkMode = function() {
      return this._darkMode;
    }, e.prototype.refreshImmediately = function(t) {
      this._disposed || (t || this.animation.update(true), this._needsRefresh = false, this.painter.refresh(), this._needsRefresh = false);
    }, e.prototype.refresh = function() {
      this._disposed || (this._needsRefresh = true, this.animation.start());
    }, e.prototype.flush = function() {
      this._disposed || this._flush(false);
    }, e.prototype._flush = function(t) {
      var r, n = Cn();
      this._needsRefresh && (r = true, this.refreshImmediately(t)), this._needsRefreshHover && (r = true, this.refreshHoverImmediately());
      var i = Cn();
      r ? (this._stillFrameAccum = 0, this.trigger("rendered", {
        elapsedTime: i - n
      })) : this._sleepAfterStill > 0 && (this._stillFrameAccum++, this._stillFrameAccum > this._sleepAfterStill && this.animation.stop());
    }, e.prototype.setSleepAfterStill = function(t) {
      this._sleepAfterStill = t;
    }, e.prototype.wakeUp = function() {
      this._disposed || (this.animation.start(), this._stillFrameAccum = 0);
    }, e.prototype.refreshHover = function() {
      this._needsRefreshHover = true;
    }, e.prototype.refreshHoverImmediately = function() {
      this._disposed || (this._needsRefreshHover = false, this.painter.refreshHover && this.painter.getType() === "canvas" && this.painter.refreshHover());
    }, e.prototype.resize = function(t) {
      this._disposed || (t = t || {}, this.painter.resize(t.width, t.height), this.handler.resize());
    }, e.prototype.clearAnimation = function() {
      this._disposed || this.animation.clear();
    }, e.prototype.getWidth = function() {
      if (!this._disposed) return this.painter.getWidth();
    }, e.prototype.getHeight = function() {
      if (!this._disposed) return this.painter.getHeight();
    }, e.prototype.setCursorStyle = function(t) {
      this._disposed || this.handler.setCursorStyle(t);
    }, e.prototype.findHover = function(t, r) {
      if (!this._disposed) return this.handler.findHover(t, r);
    }, e.prototype.on = function(t, r, n) {
      return this._disposed || this.handler.on(t, r, n), this;
    }, e.prototype.off = function(t, r) {
      this._disposed || this.handler.off(t, r);
    }, e.prototype.trigger = function(t, r) {
      this._disposed || this.handler.trigger(t, r);
    }, e.prototype.clear = function() {
      if (!this._disposed) {
        for (var t = this.storage.getRoots(), r = 0; r < t.length; r++) t[r] instanceof oe && t[r].removeSelfFromZr(this);
        this.storage.delAllRoots(), this.painter.clear();
      }
    }, e.prototype.dispose = function() {
      this._disposed || (this.animation.stop(), this.clear(), this.storage.dispose(), this.painter.dispose(), this.handler.dispose(), this.animation = this.storage = this.painter = this.handler = null, this._disposed = true, U_(this.id));
    }, e;
  })();
  function tl(e, t) {
    var r = new Y_(kl(), e, t);
    return Wr[r.id] = r, r;
  }
  function q_(e) {
    e.dispose();
  }
  function X_() {
    for (var e in Wr) Wr.hasOwnProperty(e) && Wr[e].dispose();
    Wr = {};
  }
  function $_(e) {
    return Wr[e];
  }
  function dd(e, t) {
    Ka[e] = t;
  }
  var el;
  function gd(e) {
    if (typeof el == "function") return el(e);
  }
  function yd(e) {
    el = e;
  }
  var Z_ = "5.6.1";
  const K_ = Object.freeze(Object.defineProperty({
    __proto__: null,
    dispose: q_,
    disposeAll: X_,
    getElementSSRData: gd,
    getInstance: $_,
    init: tl,
    registerPainter: dd,
    registerSSRDataGetter: yd,
    version: Z_
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  var zh = 1e-4, md = 20;
  function j_(e) {
    return e.replace(/^\s+|\s+$/g, "");
  }
  rl = function(e, t, r, n) {
    var i = t[0], a = t[1], o = r[0], s = r[1], u = a - i, l = s - o;
    if (u === 0) return l === 0 ? o : (o + s) / 2;
    if (n) if (u > 0) {
      if (e <= i) return o;
      if (e >= a) return s;
    } else {
      if (e >= i) return o;
      if (e <= a) return s;
    }
    else {
      if (e === i) return o;
      if (e === a) return s;
    }
    return (e - i) / u * l + o;
  };
  Ut = function(e, t) {
    switch (e) {
      case "center":
      case "middle":
        e = "50%";
        break;
      case "left":
      case "top":
        e = "0%";
        break;
      case "right":
      case "bottom":
        e = "100%";
        break;
    }
    return V(e) ? j_(e).match(/%$/) ? parseFloat(e) / 100 * t : parseFloat(e) : e == null ? NaN : +e;
  };
  bt = function(e, t, r) {
    return t == null && (t = 10), t = Math.min(Math.max(0, t), md), e = (+e).toFixed(t), r ? e : +e;
  };
  _d = function(e) {
    return e.sort(function(t, r) {
      return t - r;
    }), e;
  };
  function Ae(e) {
    if (e = +e, isNaN(e)) return 0;
    if (e > 1e-14) {
      for (var t = 1, r = 0; r < 15; r++, t *= 10) if (Math.round(e * t) / t === e) return r;
    }
    return Sd(e);
  }
  function Sd(e) {
    var t = e.toString().toLowerCase(), r = t.indexOf("e"), n = r > 0 ? +t.slice(r + 1) : 0, i = r > 0 ? r : t.length, a = t.indexOf("."), o = a < 0 ? 0 : i - 1 - a;
    return Math.max(0, o - n);
  }
  bd = function(e, t) {
    var r = Math.log, n = Math.LN10, i = Math.floor(r(e[1] - e[0]) / n), a = Math.round(r(Math.abs(t[1] - t[0])) / n), o = Math.min(Math.max(-i + a, 0), 20);
    return isFinite(o) ? o : 20;
  };
  function Q_(e, t, r) {
    if (!e[t]) return 0;
    var n = J_(e, r);
    return n[t] || 0;
  }
  function J_(e, t) {
    var r = Le(e, function(v, p) {
      return v + (isNaN(p) ? 0 : p);
    }, 0);
    if (r === 0) return [];
    for (var n = Math.pow(10, t), i = F(e, function(v) {
      return (isNaN(v) ? 0 : v) / r * n * 100;
    }), a = n * 100, o = F(i, function(v) {
      return Math.floor(v);
    }), s = Le(o, function(v, p) {
      return v + p;
    }, 0), u = F(i, function(v, p) {
      return v - o[p];
    }); s < a; ) {
      for (var l = Number.NEGATIVE_INFINITY, f = null, h = 0, c = u.length; h < c; ++h) u[h] > l && (l = u[h], f = h);
      ++o[f], u[f] = 0, ++s;
    }
    return F(o, function(v) {
      return v / n;
    });
  }
  function t1(e, t) {
    var r = Math.max(Ae(e), Ae(t)), n = e + t;
    return r > md ? n : bt(n, r);
  }
  var e1 = 9007199254740991;
  r1 = function(e) {
    var t = Math.PI * 2;
    return (e % t + t) % t;
  };
  n1 = function(e) {
    return e > -zh && e < zh;
  };
  var i1 = /^(?:(\d{4})(?:[-\/](\d{1,2})(?:[-\/](\d{1,2})(?:[T ](\d{1,2})(?::(\d{1,2})(?::(\d{1,2})(?:[.,](\d+))?)?)?(Z|[\+\-]\d\d:?\d\d)?)?)?)?)?$/;
  function ie(e) {
    if (e instanceof Date) return e;
    if (V(e)) {
      var t = i1.exec(e);
      if (!t) return /* @__PURE__ */ new Date(NaN);
      if (t[8]) {
        var r = +t[4] || 0;
        return t[8].toUpperCase() !== "Z" && (r -= +t[8].slice(0, 3)), new Date(Date.UTC(+t[1], +(t[2] || 1) - 1, +t[3] || 1, r, +(t[5] || 0), +t[6] || 0, t[7] ? +t[7].substring(0, 3) : 0));
      } else return new Date(+t[1], +(t[2] || 1) - 1, +t[3] || 1, +t[4] || 0, +(t[5] || 0), +t[6] || 0, t[7] ? +t[7].substring(0, 3) : 0);
    } else if (e == null) return /* @__PURE__ */ new Date(NaN);
    return new Date(Math.round(e));
  }
  function wd(e) {
    return Math.pow(10, Go(e));
  }
  function Go(e) {
    if (e === 0) return 0;
    var t = Math.floor(Math.log(e) / Math.LN10);
    return e / Math.pow(10, t) >= 10 && t++, t;
  }
  function Zl(e, t) {
    var r = Go(e), n = Math.pow(10, r), i = e / n, a;
    return t ? i < 1.5 ? a = 1 : i < 2.5 ? a = 2 : i < 4 ? a = 3 : i < 7 ? a = 5 : a = 10 : i < 1 ? a = 1 : i < 2 ? a = 2 : i < 3 ? a = 3 : i < 5 ? a = 5 : a = 10, e = a * n, r >= -20 ? +e.toFixed(r < 0 ? -r : 0) : e;
  }
  function a1(e, t) {
    var r = (e.length - 1) * t + 1, n = Math.floor(r), i = +e[n - 1], a = r - n;
    return a ? i + a * (e[n] - i) : i;
  }
  function o1(e) {
    e.sort(function(u, l) {
      return s(u, l, 0) ? -1 : 1;
    });
    for (var t = -1 / 0, r = 1, n = 0; n < e.length; ) {
      for (var i = e[n].interval, a = e[n].close, o = 0; o < 2; o++) i[o] <= t && (i[o] = t, a[o] = o ? 1 : 1 - r), t = i[o], r = a[o];
      i[0] === i[1] && a[0] * a[1] !== 1 ? e.splice(n, 1) : n++;
    }
    return e;
    function s(u, l, f) {
      return u.interval[f] < l.interval[f] || u.interval[f] === l.interval[f] && (u.close[f] - l.close[f] === (f ? -1 : 1) || !f && s(u, l, 1));
    }
  }
  function Wi(e) {
    var t = parseFloat(e);
    return t == e && (t !== 0 || !V(e) || e.indexOf("x") <= 0) ? t : NaN;
  }
  function Td(e) {
    return !isNaN(Wi(e));
  }
  function Md() {
    return Math.round(Math.random() * 9);
  }
  function Cd(e, t) {
    return t === 0 ? e : Cd(t, e % t);
  }
  function Vh(e, t) {
    return e == null ? t : t == null ? e : e * t / Cd(e, t);
  }
  Wt = function(e) {
    throw new Error(e);
  };
  function Gh(e, t, r) {
    return (t - e) * r + e;
  }
  var Dd = "series\0", xd = "\0_ec_\0";
  function Lt(e) {
    return e instanceof Array ? e : e == null ? [] : [
      e
    ];
  }
  function Hh(e, t, r) {
    if (e) {
      e[t] = e[t] || {}, e.emphasis = e.emphasis || {}, e.emphasis[t] = e.emphasis[t] || {};
      for (var n = 0, i = r.length; n < i; n++) {
        var a = r[n];
        !e.emphasis[t].hasOwnProperty(a) && e[t].hasOwnProperty(a) && (e.emphasis[t][a] = e[t][a]);
      }
    }
  }
  var Uh = [
    "fontStyle",
    "fontWeight",
    "fontSize",
    "fontFamily",
    "rich",
    "tag",
    "color",
    "textBorderColor",
    "textBorderWidth",
    "width",
    "height",
    "lineHeight",
    "align",
    "verticalAlign",
    "baseline",
    "shadowColor",
    "shadowBlur",
    "shadowOffsetX",
    "shadowOffsetY",
    "textShadowColor",
    "textShadowBlur",
    "textShadowOffsetX",
    "textShadowOffsetY",
    "backgroundColor",
    "borderColor",
    "borderWidth",
    "borderRadius",
    "padding"
  ];
  function Gn(e) {
    return G(e) && !B(e) && !(e instanceof Date) ? e.value : e;
  }
  function s1(e) {
    return G(e) && !(e instanceof Array);
  }
  function u1(e, t, r) {
    var n = r === "normalMerge", i = r === "replaceMerge", a = r === "replaceAll";
    e = e || [], t = (t || []).slice();
    var o = q();
    P(t, function(u, l) {
      if (!G(u)) {
        t[l] = null;
        return;
      }
    });
    var s = l1(e, o, r);
    return (n || i) && f1(s, e, o, t), n && h1(s, t), n || i ? v1(s, t, i) : a && c1(s, t), p1(s), s;
  }
  function l1(e, t, r) {
    var n = [];
    if (r === "replaceAll") return n;
    for (var i = 0; i < e.length; i++) {
      var a = e[i];
      a && a.id != null && t.set(a.id, i), n.push({
        existing: r === "replaceMerge" || Yi(a) ? null : a,
        newOption: null,
        keyInfo: null,
        brandNew: null
      });
    }
    return n;
  }
  function f1(e, t, r, n) {
    P(n, function(i, a) {
      if (!(!i || i.id == null)) {
        var o = Pi(i.id), s = r.get(o);
        if (s != null) {
          var u = e[s];
          $t(!u.newOption, 'Duplicated option on id "' + o + '".'), u.newOption = i, u.existing = t[s], n[a] = null;
        }
      }
    });
  }
  function h1(e, t) {
    P(t, function(r, n) {
      if (!(!r || r.name == null)) for (var i = 0; i < e.length; i++) {
        var a = e[i].existing;
        if (!e[i].newOption && a && (a.id == null || r.id == null) && !Yi(r) && !Yi(a) && Pd("name", a, r)) {
          e[i].newOption = r, t[n] = null;
          return;
        }
      }
    });
  }
  function v1(e, t, r) {
    P(t, function(n) {
      if (n) {
        for (var i, a = 0; (i = e[a]) && (i.newOption || Yi(i.existing) || i.existing && n.id != null && !Pd("id", n, i.existing)); ) a++;
        i ? (i.newOption = n, i.brandNew = r) : e.push({
          newOption: n,
          brandNew: r,
          existing: null,
          keyInfo: null
        }), a++;
      }
    });
  }
  function c1(e, t) {
    P(t, function(r) {
      e.push({
        newOption: r,
        brandNew: true,
        existing: null,
        keyInfo: null
      });
    });
  }
  function p1(e) {
    var t = q();
    P(e, function(r) {
      var n = r.existing;
      n && t.set(n.id, r);
    }), P(e, function(r) {
      var n = r.newOption;
      $t(!n || n.id == null || !t.get(n.id) || t.get(n.id) === r, "id duplicates: " + (n && n.id)), n && n.id != null && t.set(n.id, r), !r.keyInfo && (r.keyInfo = {});
    }), P(e, function(r, n) {
      var i = r.existing, a = r.newOption, o = r.keyInfo;
      if (G(a)) {
        if (o.name = a.name != null ? Pi(a.name) : i ? i.name : Dd + n, i) o.id = Pi(i.id);
        else if (a.id != null) o.id = Pi(a.id);
        else {
          var s = 0;
          do
            o.id = "\0" + o.name + "\0" + s++;
          while (t.get(o.id));
        }
        t.set(o.id, r);
      }
    });
  }
  function Pd(e, t, r) {
    var n = me(t[e], null), i = me(r[e], null);
    return n != null && i != null && n === i;
  }
  function Pi(e) {
    return me(e, "");
  }
  function me(e, t) {
    return e == null ? t : V(e) ? e : lt(e) || no(e) ? e + "" : t;
  }
  Id = function(e) {
    var t = e.name;
    return !!(t && t.indexOf(Dd));
  };
  function Yi(e) {
    return e && e.id != null && Pi(e.id).indexOf(xd) === 0;
  }
  H2 = function(e) {
    return xd + e;
  };
  function d1(e, t, r) {
    P(e, function(n) {
      var i = n.newOption;
      G(i) && (n.keyInfo.mainType = t, n.keyInfo.subType = g1(t, i, n.existing, r));
    });
  }
  function g1(e, t, r, n) {
    var i = t.type ? t.type : r ? r.subType : n.determineSubType(e, t);
    return i;
  }
  kn = function(e, t) {
    if (t.dataIndexInside != null) return t.dataIndexInside;
    if (t.dataIndex != null) return B(t.dataIndex) ? F(t.dataIndex, function(r) {
      return e.indexOfRawIndex(r);
    }) : e.indexOfRawIndex(t.dataIndex);
    if (t.name != null) return B(t.name) ? F(t.name, function(r) {
      return e.indexOfName(r);
    }) : e.indexOfName(t.name);
  };
  Pt = function() {
    var e = "__ec_inner_" + y1++;
    return function(t) {
      return t[e] || (t[e] = {});
    };
  };
  var y1 = Md();
  Us = function(e, t, r) {
    var n = Ad(t, r), i = n.mainTypeSpecified, a = n.queryOptionMap, o = n.others, s = o, u = r ? r.defaultMainType : null;
    return !i && u && a.set(u, {}), a.each(function(l, f) {
      var h = Ho(e, f, l, {
        useDefault: u === f,
        enableAll: r && r.enableAll != null ? r.enableAll : true,
        enableNone: r && r.enableNone != null ? r.enableNone : true
      });
      s[f + "Models"] = h.models, s[f + "Model"] = h.models[0];
    }), s;
  };
  Ad = function(e, t) {
    var r;
    if (V(e)) {
      var n = {};
      n[e + "Index"] = 0, r = n;
    } else r = e;
    var i = q(), a = {}, o = false;
    return P(r, function(s, u) {
      if (u === "dataIndex" || u === "dataIndexInside") {
        a[u] = s;
        return;
      }
      var l = u.match(/^(\w+)(Index|Id|Name)$/) || [], f = l[1], h = (l[2] || "").toLowerCase();
      if (!(!f || !h || t && t.includeMainTypes && vt(t.includeMainTypes, f) < 0)) {
        o = o || !!f;
        var c = i.get(f) || i.set(f, {});
        c[h] = s;
      }
    }), {
      mainTypeSpecified: o,
      queryOptionMap: i,
      others: a
    };
  };
  Yr = {
    useDefault: true,
    enableAll: false,
    enableNone: false
  };
  U2 = {
    useDefault: false,
    enableAll: true,
    enableNone: true
  };
  Ho = function(e, t, r, n) {
    n = n || Yr;
    var i = r.index, a = r.id, o = r.name, s = {
      models: null,
      specified: i != null || a != null || o != null
    };
    if (!s.specified) {
      var u = void 0;
      return s.models = n.useDefault && (u = e.getComponent(t)) ? [
        u
      ] : [], s;
    }
    return i === "none" || i === false ? ($t(n.enableNone, '`"none"` or `false` is not a valid value on index option.'), s.models = [], s) : (i === "all" && ($t(n.enableAll, '`"all"` is not a valid value on index option.'), i = a = o = null), s.models = e.queryComponents({
      mainType: t,
      index: i,
      id: a,
      name: o
    }), s);
  };
  function Ed(e, t, r) {
    e.setAttribute ? e.setAttribute(t, r) : e[t] = r;
  }
  function m1(e, t) {
    return e.getAttribute ? e.getAttribute(t) : e[t];
  }
  W2 = function(e) {
    return e === "auto" ? j.domSupported ? "html" : "richText" : e || "html";
  };
  function _1(e, t, r, n, i) {
    var a = t == null || t === "auto";
    if (n == null) return n;
    if (lt(n)) {
      var o = Gh(r || 0, n, i);
      return bt(o, a ? Math.max(Ae(r || 0), Ae(n)) : t);
    } else {
      if (V(n)) return i < 1 ? r : n;
      for (var s = [], u = r, l = n, f = Math.max(u ? u.length : 0, l.length), h = 0; h < f; ++h) {
        var c = e.getDimensionInfo(h);
        if (c && c.type === "ordinal") s[h] = (i < 1 && u ? u : l)[h];
        else {
          var v = u && u[h] ? u[h] : 0, p = l[h], o = Gh(v, p, i);
          s[h] = bt(o, a ? Math.max(Ae(v), Ae(p)) : t);
        }
      }
      return s;
    }
  }
  var S1 = ".", Dr = "___EC__COMPONENT__CONTAINER___", Ld = "___EC__EXTENDED_CLASS___";
  function Ee(e) {
    var t = {
      main: "",
      sub: ""
    };
    if (e) {
      var r = e.split(S1);
      t.main = r[0] || "", t.sub = r[1] || "";
    }
    return t;
  }
  function b1(e) {
    $t(/^[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)?$/.test(e), 'componentType "' + e + '" illegal');
  }
  function w1(e) {
    return !!(e && e[Ld]);
  }
  function Kl(e, t) {
    e.$constructor = e, e.extend = function(r) {
      var n = this, i;
      return T1(n) ? i = (function(a) {
        ft(o, a);
        function o() {
          return a.apply(this, arguments) || this;
        }
        return o;
      })(n) : (i = function() {
        (r.$constructor || n).apply(this, arguments);
      }, Fl(i, this)), O(i.prototype, r), i[Ld] = true, i.extend = this.extend, i.superCall = D1, i.superApply = x1, i.superClass = n, i;
    };
  }
  function T1(e) {
    return Y(e) && /^class\s/.test(Function.prototype.toString.call(e));
  }
  function Rd(e, t) {
    e.extend = t.extend;
  }
  var M1 = Math.round(Math.random() * 10);
  function C1(e) {
    var t = [
      "__\0is_clz",
      M1++
    ].join("_");
    e.prototype[t] = true, e.isInstance = function(r) {
      return !!(r && r[t]);
    };
  }
  function D1(e, t) {
    for (var r = [], n = 2; n < arguments.length; n++) r[n - 2] = arguments[n];
    return this.superClass.prototype[t].apply(e, r);
  }
  function x1(e, t, r) {
    return this.superClass.prototype[t].apply(e, r);
  }
  function Uo(e) {
    var t = {};
    e.registerClass = function(n) {
      var i = n.type || n.prototype.type;
      if (i) {
        b1(i), n.prototype.type = i;
        var a = Ee(i);
        if (!a.sub) t[a.main] = n;
        else if (a.sub !== Dr) {
          var o = r(a);
          o[a.sub] = n;
        }
      }
      return n;
    }, e.getClass = function(n, i, a) {
      var o = t[n];
      if (o && o[Dr] && (o = i ? o[i] : null), a && !o) throw new Error(i ? "Component " + n + "." + (i || "") + " is used but not imported." : n + ".type should be specified.");
      return o;
    }, e.getClassesByMainType = function(n) {
      var i = Ee(n), a = [], o = t[i.main];
      return o && o[Dr] ? P(o, function(s, u) {
        u !== Dr && a.push(s);
      }) : a.push(o), a;
    }, e.hasClass = function(n) {
      var i = Ee(n);
      return !!t[i.main];
    }, e.getAllClassMainTypes = function() {
      var n = [];
      return P(t, function(i, a) {
        n.push(a);
      }), n;
    }, e.hasSubTypes = function(n) {
      var i = Ee(n), a = t[i.main];
      return a && a[Dr];
    };
    function r(n) {
      var i = t[n.main];
      return (!i || !i[Dr]) && (i = t[n.main] = {}, i[Dr] = true), i;
    }
  }
  function qi(e, t) {
    for (var r = 0; r < e.length; r++) e[r][1] || (e[r][1] = e[r][0]);
    return t = t || false, function(n, i, a) {
      for (var o = {}, s = 0; s < e.length; s++) {
        var u = e[s][1];
        if (!(i && vt(i, u) >= 0 || a && vt(a, u) < 0)) {
          var l = n.getShallow(u, t);
          l != null && (o[e[s][0]] = l);
        }
      }
      return o;
    };
  }
  var P1 = [
    [
      "fill",
      "color"
    ],
    [
      "shadowBlur"
    ],
    [
      "shadowOffsetX"
    ],
    [
      "shadowOffsetY"
    ],
    [
      "opacity"
    ],
    [
      "shadowColor"
    ]
  ], I1 = qi(P1), A1 = (function() {
    function e() {
    }
    return e.prototype.getAreaStyle = function(t, r) {
      return I1(this, t, r);
    }, e;
  })(), nl = new ra(50);
  function E1(e) {
    if (typeof e == "string") {
      var t = nl.get(e);
      return t && t.image;
    } else return e;
  }
  function jl(e, t, r, n, i) {
    if (e) if (typeof e == "string") {
      if (t && t.__zrImageSrc === e || !r) return t;
      var a = nl.get(e), o = {
        hostEl: r,
        cb: n,
        cbPayload: i
      };
      return a ? (t = a.image, !Wo(t) && a.pending.push(o)) : (t = dr.loadImage(e, Wh, Wh), t.__zrImageSrc = e, nl.put(e, t.__cachedImgObj = {
        image: t,
        pending: [
          o
        ]
      })), t;
    } else return e;
    else return t;
  }
  function Wh() {
    var e = this.__cachedImgObj;
    this.onload = this.onerror = this.__cachedImgObj = null;
    for (var t = 0; t < e.pending.length; t++) {
      var r = e.pending[t], n = r.cb;
      n && n(this, r.cbPayload), r.hostEl.dirty();
    }
    e.pending.length = 0;
  }
  function Wo(e) {
    return e && e.width && e.height;
  }
  var Ws = /\{([a-zA-Z0-9_]+)\|([^}]*)\}/g;
  function L1(e, t, r, n, i) {
    var a = {};
    return Od(a, e, t, r, n, i), a.text;
  }
  function Od(e, t, r, n, i, a) {
    if (!r) {
      e.text = "", e.isTruncated = false;
      return;
    }
    var o = (t + "").split(`
`);
    a = kd(r, n, i, a);
    for (var s = false, u = {}, l = 0, f = o.length; l < f; l++) Nd(u, o[l], a), o[l] = u.textLine, s = s || u.isTruncated;
    e.text = o.join(`
`), e.isTruncated = s;
  }
  function kd(e, t, r, n) {
    n = n || {};
    var i = O({}, n);
    i.font = t, r = W(r, "..."), i.maxIterations = W(n.maxIterations, 2);
    var a = i.minChar = W(n.minChar, 0);
    i.cnCharWidth = qt("\u56FD", t);
    var o = i.ascCharWidth = qt("a", t);
    i.placeholder = W(n.placeholder, "");
    for (var s = e = Math.max(0, e - 1), u = 0; u < a && s >= o; u++) s -= o;
    var l = qt(r, t);
    return l > s && (r = "", l = 0), s = e - l, i.ellipsis = r, i.ellipsisWidth = l, i.contentWidth = s, i.containerWidth = e, i;
  }
  function Nd(e, t, r) {
    var n = r.containerWidth, i = r.font, a = r.contentWidth;
    if (!n) {
      e.textLine = "", e.isTruncated = false;
      return;
    }
    var o = qt(t, i);
    if (o <= n) {
      e.textLine = t, e.isTruncated = false;
      return;
    }
    for (var s = 0; ; s++) {
      if (o <= a || s >= r.maxIterations) {
        t += r.ellipsis;
        break;
      }
      var u = s === 0 ? R1(t, a, r.ascCharWidth, r.cnCharWidth) : o > 0 ? Math.floor(t.length * a / o) : 0;
      t = t.substr(0, u), o = qt(t, i);
    }
    t === "" && (t = r.placeholder), e.textLine = t, e.isTruncated = true;
  }
  function R1(e, t, r, n) {
    for (var i = 0, a = 0, o = e.length; a < o && i < t; a++) {
      var s = e.charCodeAt(a);
      i += 0 <= s && s <= 127 ? r : n;
    }
    return a;
  }
  function O1(e, t) {
    e != null && (e += "");
    var r = t.overflow, n = t.padding, i = t.font, a = r === "truncate", o = zo(i), s = W(t.lineHeight, o), u = !!t.backgroundColor, l = t.lineOverflow === "truncate", f = false, h = t.width, c;
    h != null && (r === "break" || r === "breakAll") ? c = e ? Fd(e, t.font, h, r === "breakAll", 0).lines : [] : c = e ? e.split(`
`) : [];
    var v = c.length * s, p = W(t.height, v);
    if (v > p && l) {
      var y = Math.floor(p / s);
      f = f || c.length > y, c = c.slice(0, y);
    }
    if (e && a && h != null) for (var g = kd(h, i, t.ellipsis, {
      minChar: t.truncateMinChar,
      placeholder: t.placeholder
    }), d = {}, m = 0; m < c.length; m++) Nd(d, c[m], g), c[m] = d.textLine, f = f || d.isTruncated;
    for (var _ = p, S = 0, m = 0; m < c.length; m++) S = Math.max(qt(c[m], i), S);
    h == null && (h = S);
    var T = S;
    return n && (_ += n[0] + n[2], T += n[1] + n[3], h += n[1] + n[3]), u && (T = h), {
      lines: c,
      height: p,
      outerWidth: T,
      outerHeight: _,
      lineHeight: s,
      calculatedLineHeight: o,
      contentWidth: S,
      contentHeight: v,
      width: h,
      isTruncated: f
    };
  }
  var k1 = /* @__PURE__ */ (function() {
    function e() {
    }
    return e;
  })(), Yh = /* @__PURE__ */ (function() {
    function e(t) {
      this.tokens = [], t && (this.tokens = t);
    }
    return e;
  })(), N1 = /* @__PURE__ */ (function() {
    function e() {
      this.width = 0, this.height = 0, this.contentWidth = 0, this.contentHeight = 0, this.outerWidth = 0, this.outerHeight = 0, this.lines = [], this.isTruncated = false;
    }
    return e;
  })();
  function F1(e, t) {
    var r = new N1();
    if (e != null && (e += ""), !e) return r;
    for (var n = t.width, i = t.height, a = t.overflow, o = (a === "break" || a === "breakAll") && n != null ? {
      width: n,
      accumWidth: 0,
      breakAll: a === "breakAll"
    } : null, s = Ws.lastIndex = 0, u; (u = Ws.exec(e)) != null; ) {
      var l = u.index;
      l > s && Ys(r, e.substring(s, l), t, o), Ys(r, u[2], t, o, u[1]), s = Ws.lastIndex;
    }
    s < e.length && Ys(r, e.substring(s, e.length), t, o);
    var f = [], h = 0, c = 0, v = t.padding, p = a === "truncate", y = t.lineOverflow === "truncate", g = {};
    function d(U, J, $) {
      U.width = J, U.lineHeight = $, h += $, c = Math.max(c, J);
    }
    t: for (var m = 0; m < r.lines.length; m++) {
      for (var _ = r.lines[m], S = 0, T = 0, b = 0; b < _.tokens.length; b++) {
        var w = _.tokens[b], D = w.styleName && t.rich[w.styleName] || {}, C = w.textPadding = D.padding, M = C ? C[1] + C[3] : 0, x = w.font = D.font || t.font;
        w.contentHeight = zo(x);
        var I = W(D.height, w.contentHeight);
        if (w.innerHeight = I, C && (I += C[0] + C[2]), w.height = I, w.lineHeight = Ci(D.lineHeight, t.lineHeight, I), w.align = D && D.align || t.align, w.verticalAlign = D && D.verticalAlign || "middle", y && i != null && h + w.lineHeight > i) {
          var A = r.lines.length;
          b > 0 ? (_.tokens = _.tokens.slice(0, b), d(_, T, S), r.lines = r.lines.slice(0, m + 1)) : r.lines = r.lines.slice(0, m), r.isTruncated = r.isTruncated || r.lines.length < A;
          break t;
        }
        var E = D.width, R = E == null || E === "auto";
        if (typeof E == "string" && E.charAt(E.length - 1) === "%") w.percentWidth = E, f.push(w), w.contentWidth = qt(w.text, x);
        else {
          if (R) {
            var L = D.backgroundColor, z = L && L.image;
            z && (z = E1(z), Wo(z) && (w.width = Math.max(w.width, z.width * I / z.height)));
          }
          var k = p && n != null ? n - T : null;
          k != null && k < w.width ? !R || k < M ? (w.text = "", w.width = w.contentWidth = 0) : (Od(g, w.text, k - M, x, t.ellipsis, {
            minChar: t.truncateMinChar
          }), w.text = g.text, r.isTruncated = r.isTruncated || g.isTruncated, w.width = w.contentWidth = qt(w.text, x)) : w.contentWidth = qt(w.text, x);
        }
        w.width += M, T += w.width, D && (S = Math.max(S, w.lineHeight));
      }
      d(_, T, S);
    }
    r.outerWidth = r.width = W(n, c), r.outerHeight = r.height = W(i, h), r.contentHeight = h, r.contentWidth = c, v && (r.outerWidth += v[1] + v[3], r.outerHeight += v[0] + v[2]);
    for (var m = 0; m < f.length; m++) {
      var w = f[m], N = w.percentWidth;
      w.width = parseInt(N, 10) / 100 * r.width;
    }
    return r;
  }
  function Ys(e, t, r, n, i) {
    var a = t === "", o = i && r.rich[i] || {}, s = e.lines, u = o.font || r.font, l = false, f, h;
    if (n) {
      var c = o.padding, v = c ? c[1] + c[3] : 0;
      if (o.width != null && o.width !== "auto") {
        var p = gr(o.width, n.width) + v;
        s.length > 0 && p + n.accumWidth > n.width && (f = t.split(`
`), l = true), n.accumWidth = p;
      } else {
        var y = Fd(t, u, n.width, n.breakAll, n.accumWidth);
        n.accumWidth = y.accumWidth + v, h = y.linesWidths, f = y.lines;
      }
    } else f = t.split(`
`);
    for (var g = 0; g < f.length; g++) {
      var d = f[g], m = new k1();
      if (m.styleName = i, m.text = d, m.isLineHolder = !d && !a, typeof o.width == "number" ? m.width = o.width : m.width = h ? h[g] : qt(d, u), !g && !l) {
        var _ = (s[s.length - 1] || (s[0] = new Yh())).tokens, S = _.length;
        S === 1 && _[0].isLineHolder ? _[0] = m : (d || !S || a) && _.push(m);
      } else s.push(new Yh([
        m
      ]));
    }
  }
  function B1(e) {
    var t = e.charCodeAt(0);
    return t >= 32 && t <= 591 || t >= 880 && t <= 4351 || t >= 4608 && t <= 5119 || t >= 7680 && t <= 8303;
  }
  var z1 = Le(",&?/;] ".split(""), function(e, t) {
    return e[t] = true, e;
  }, {});
  function V1(e) {
    return B1(e) ? !!z1[e] : true;
  }
  function Fd(e, t, r, n, i) {
    for (var a = [], o = [], s = "", u = "", l = 0, f = 0, h = 0; h < e.length; h++) {
      var c = e.charAt(h);
      if (c === `
`) {
        u && (s += u, f += l), a.push(s), o.push(f), s = "", u = "", l = 0, f = 0;
        continue;
      }
      var v = qt(c, t), p = n ? false : !V1(c);
      if (a.length ? f + v > r : i + f + v > r) {
        f ? (s || u) && (p ? (s || (s = u, u = "", l = 0, f = l), a.push(s), o.push(f - l), u += c, l += v, s = "", f = l) : (u && (s += u, u = "", l = 0), a.push(s), o.push(f), s = c, f = v)) : p ? (a.push(u), o.push(l), u = c, l = v) : (a.push(c), o.push(v));
        continue;
      }
      f += v, p ? (u += c, l += v) : (u && (s += u, u = "", l = 0), s += c);
    }
    return !a.length && !s && (s = e, u = "", l = 0), u && (s += u), s && (a.push(s), o.push(f)), a.length === 1 && (f += i), {
      accumWidth: f,
      lines: a,
      linesWidths: o
    };
  }
  var il = "__zr_style_" + Math.round(Math.random() * 10), Kr = {
    shadowBlur: 0,
    shadowOffsetX: 0,
    shadowOffsetY: 0,
    shadowColor: "#000",
    opacity: 1,
    blend: "source-over"
  }, Yo = {
    style: {
      shadowBlur: true,
      shadowOffsetX: true,
      shadowOffsetY: true,
      shadowColor: true,
      opacity: true
    }
  };
  Kr[il] = true;
  var qh = [
    "z",
    "z2",
    "invisible"
  ], G1 = [
    "invisible"
  ], na = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype._init = function(r) {
      for (var n = K(r), i = 0; i < n.length; i++) {
        var a = n[i];
        a === "style" ? this.useStyle(r[a]) : e.prototype.attrKV.call(this, a, r[a]);
      }
      this.style || this.useStyle({});
    }, t.prototype.beforeBrush = function() {
    }, t.prototype.afterBrush = function() {
    }, t.prototype.innerBeforeBrush = function() {
    }, t.prototype.innerAfterBrush = function() {
    }, t.prototype.shouldBePainted = function(r, n, i, a) {
      var o = this.transform;
      if (this.ignore || this.invisible || this.style.opacity === 0 || this.culling && H1(this, r, n) || o && !o[0] && !o[3]) return false;
      if (i && this.__clipPaths) {
        for (var s = 0; s < this.__clipPaths.length; ++s) if (this.__clipPaths[s].isZeroArea()) return false;
      }
      if (a && this.parent) for (var u = this.parent; u; ) {
        if (u.ignore) return false;
        u = u.parent;
      }
      return true;
    }, t.prototype.contain = function(r, n) {
      return this.rectContain(r, n);
    }, t.prototype.traverse = function(r, n) {
      r.call(n, this);
    }, t.prototype.rectContain = function(r, n) {
      var i = this.transformCoordToLocal(r, n), a = this.getBoundingRect();
      return a.contain(i[0], i[1]);
    }, t.prototype.getPaintRect = function() {
      var r = this._paintRect;
      if (!this._paintRect || this.__dirty) {
        var n = this.transform, i = this.getBoundingRect(), a = this.style, o = a.shadowBlur || 0, s = a.shadowOffsetX || 0, u = a.shadowOffsetY || 0;
        r = this._paintRect || (this._paintRect = new at(0, 0, 0, 0)), n ? at.applyTransform(r, i, n) : r.copy(i), (o || s || u) && (r.width += o * 2 + Math.abs(s), r.height += o * 2 + Math.abs(u), r.x = Math.min(r.x, r.x + s - o), r.y = Math.min(r.y, r.y + u - o));
        var l = this.dirtyRectTolerance;
        r.isZero() || (r.x = Math.floor(r.x - l), r.y = Math.floor(r.y - l), r.width = Math.ceil(r.width + 1 + l * 2), r.height = Math.ceil(r.height + 1 + l * 2));
      }
      return r;
    }, t.prototype.setPrevPaintRect = function(r) {
      r ? (this._prevPaintRect = this._prevPaintRect || new at(0, 0, 0, 0), this._prevPaintRect.copy(r)) : this._prevPaintRect = null;
    }, t.prototype.getPrevPaintRect = function() {
      return this._prevPaintRect;
    }, t.prototype.animateStyle = function(r) {
      return this.animate("style", r);
    }, t.prototype.updateDuringAnimation = function(r) {
      r === "style" ? this.dirtyStyle() : this.markRedraw();
    }, t.prototype.attrKV = function(r, n) {
      r !== "style" ? e.prototype.attrKV.call(this, r, n) : this.style ? this.setStyle(n) : this.useStyle(n);
    }, t.prototype.setStyle = function(r, n) {
      return typeof r == "string" ? this.style[r] = n : O(this.style, r), this.dirtyStyle(), this;
    }, t.prototype.dirtyStyle = function(r) {
      r || this.markRedraw(), this.__dirty |= mi, this._rect && (this._rect = null);
    }, t.prototype.dirty = function() {
      this.dirtyStyle();
    }, t.prototype.styleChanged = function() {
      return !!(this.__dirty & mi);
    }, t.prototype.styleUpdated = function() {
      this.__dirty &= ~mi;
    }, t.prototype.createStyle = function(r) {
      return ea(Kr, r);
    }, t.prototype.useStyle = function(r) {
      r[il] || (r = this.createStyle(r)), this.__inHover ? this.__hoverStyle = r : this.style = r, this.dirtyStyle();
    }, t.prototype.isStyleObject = function(r) {
      return r[il];
    }, t.prototype._innerSaveToNormal = function(r) {
      e.prototype._innerSaveToNormal.call(this, r);
      var n = this._normalState;
      r.style && !n.style && (n.style = this._mergeStyle(this.createStyle(), this.style)), this._savePrimaryToNormal(r, n, qh);
    }, t.prototype._applyStateObj = function(r, n, i, a, o, s) {
      e.prototype._applyStateObj.call(this, r, n, i, a, o, s);
      var u = !(n && a), l;
      if (n && n.style ? o ? a ? l = n.style : (l = this._mergeStyle(this.createStyle(), i.style), this._mergeStyle(l, n.style)) : (l = this._mergeStyle(this.createStyle(), a ? this.style : i.style), this._mergeStyle(l, n.style)) : u && (l = i.style), l) if (o) {
        var f = this.style;
        if (this.style = this.createStyle(u ? {} : f), u) for (var h = K(f), c = 0; c < h.length; c++) {
          var v = h[c];
          v in l && (l[v] = l[v], this.style[v] = f[v]);
        }
        for (var p = K(l), c = 0; c < p.length; c++) {
          var v = p[c];
          this.style[v] = this.style[v];
        }
        this._transitionState(r, {
          style: l
        }, s, this.getAnimationStyleProps());
      } else this.useStyle(l);
      for (var y = this.__inHover ? G1 : qh, c = 0; c < y.length; c++) {
        var v = y[c];
        n && n[v] != null ? this[v] = n[v] : u && i[v] != null && (this[v] = i[v]);
      }
    }, t.prototype._mergeStates = function(r) {
      for (var n = e.prototype._mergeStates.call(this, r), i, a = 0; a < r.length; a++) {
        var o = r[a];
        o.style && (i = i || {}, this._mergeStyle(i, o.style));
      }
      return i && (n.style = i), n;
    }, t.prototype._mergeStyle = function(r, n) {
      return O(r, n), r;
    }, t.prototype.getAnimationStyleProps = function() {
      return Yo;
    }, t.initDefaultProps = (function() {
      var r = t.prototype;
      r.type = "displayable", r.invisible = false, r.z = 0, r.z2 = 0, r.zlevel = 0, r.culling = false, r.cursor = "pointer", r.rectHover = false, r.incremental = false, r._rect = null, r.dirtyRectTolerance = 0, r.__dirty = xe | mi;
    })(), t;
  })(Vo), qs = new at(0, 0, 0, 0), Xs = new at(0, 0, 0, 0);
  function H1(e, t, r) {
    return qs.copy(e.getBoundingRect()), e.transform && qs.applyTransform(e.transform), Xs.width = t, Xs.height = r, !qs.intersect(Xs);
  }
  var te = Math.min, ee = Math.max, $s = Math.sin, Zs = Math.cos, xr = Math.PI * 2, _a = nn(), Sa = nn(), ba = nn();
  function Xh(e, t, r, n, i, a) {
    i[0] = te(e, r), i[1] = te(t, n), a[0] = ee(e, r), a[1] = ee(t, n);
  }
  var $h = [], Zh = [];
  function U1(e, t, r, n, i, a, o, s, u, l) {
    var f = jp, h = Tt, c = f(e, r, i, o, $h);
    u[0] = 1 / 0, u[1] = 1 / 0, l[0] = -1 / 0, l[1] = -1 / 0;
    for (var v = 0; v < c; v++) {
      var p = h(e, r, i, o, $h[v]);
      u[0] = te(p, u[0]), l[0] = ee(p, l[0]);
    }
    c = f(t, n, a, s, Zh);
    for (var v = 0; v < c; v++) {
      var y = h(t, n, a, s, Zh[v]);
      u[1] = te(y, u[1]), l[1] = ee(y, l[1]);
    }
    u[0] = te(e, u[0]), l[0] = ee(e, l[0]), u[0] = te(o, u[0]), l[0] = ee(o, l[0]), u[1] = te(t, u[1]), l[1] = ee(t, l[1]), u[1] = te(s, u[1]), l[1] = ee(s, l[1]);
  }
  function W1(e, t, r, n, i, a, o, s) {
    var u = Qp, l = Ft, f = ee(te(u(e, r, i), 1), 0), h = ee(te(u(t, n, a), 1), 0), c = l(e, r, i, f), v = l(t, n, a, h);
    o[0] = te(e, i, c), o[1] = te(t, a, v), s[0] = ee(e, i, c), s[1] = ee(t, a, v);
  }
  function Y1(e, t, r, n, i, a, o, s, u) {
    var l = or, f = sr, h = Math.abs(i - a);
    if (h % xr < 1e-4 && h > 1e-4) {
      s[0] = e - r, s[1] = t - n, u[0] = e + r, u[1] = t + n;
      return;
    }
    if (_a[0] = Zs(i) * r + e, _a[1] = $s(i) * n + t, Sa[0] = Zs(a) * r + e, Sa[1] = $s(a) * n + t, l(s, _a, Sa), f(u, _a, Sa), i = i % xr, i < 0 && (i = i + xr), a = a % xr, a < 0 && (a = a + xr), i > a && !o ? a += xr : i < a && o && (i += xr), o) {
      var c = a;
      a = i, i = c;
    }
    for (var v = 0; v < a; v += Math.PI / 2) v > i && (ba[0] = Zs(v) * r + e, ba[1] = $s(v) * n + t, l(s, ba, s), f(u, ba, u));
  }
  var Q = {
    M: 1,
    L: 2,
    C: 3,
    Q: 4,
    A: 5,
    Z: 6,
    R: 7
  }, Pr = [], Ir = [], be = [], je = [], we = [], Te = [], Ks = Math.min, js = Math.max, Ar = Math.cos, Er = Math.sin, Ge = Math.abs, al = Math.PI, ar = al * 2, Qs = typeof Float32Array < "u", ai = [];
  function Js(e) {
    var t = Math.round(e / al * 1e8) / 1e8;
    return t % 2 * al;
  }
  function q1(e, t) {
    var r = Js(e[0]);
    r < 0 && (r += ar);
    var n = r - e[0], i = e[1];
    i += n, !t && i - r >= ar ? i = r + ar : t && r - i >= ar ? i = r - ar : !t && r > i ? i = r + (ar - Js(r - i)) : t && r < i && (i = r - (ar - Js(i - r))), e[0] = r, e[1] = i;
  }
  var yr = (function() {
    function e(t) {
      this.dpr = 1, this._xi = 0, this._yi = 0, this._x0 = 0, this._y0 = 0, this._len = 0, t && (this._saveData = false), this._saveData && (this.data = []);
    }
    return e.prototype.increaseVersion = function() {
      this._version++;
    }, e.prototype.getVersion = function() {
      return this._version;
    }, e.prototype.setScale = function(t, r, n) {
      n = n || 0, n > 0 && (this._ux = Ge(n / Oh / t) || 0, this._uy = Ge(n / Oh / r) || 0);
    }, e.prototype.setDPR = function(t) {
      this.dpr = t;
    }, e.prototype.setContext = function(t) {
      this._ctx = t;
    }, e.prototype.getContext = function() {
      return this._ctx;
    }, e.prototype.beginPath = function() {
      return this._ctx && this._ctx.beginPath(), this.reset(), this;
    }, e.prototype.reset = function() {
      this._saveData && (this._len = 0), this._pathSegLen && (this._pathSegLen = null, this._pathLen = 0), this._version++;
    }, e.prototype.moveTo = function(t, r) {
      return this._drawPendingPt(), this.addData(Q.M, t, r), this._ctx && this._ctx.moveTo(t, r), this._x0 = t, this._y0 = r, this._xi = t, this._yi = r, this;
    }, e.prototype.lineTo = function(t, r) {
      var n = Ge(t - this._xi), i = Ge(r - this._yi), a = n > this._ux || i > this._uy;
      if (this.addData(Q.L, t, r), this._ctx && a && this._ctx.lineTo(t, r), a) this._xi = t, this._yi = r, this._pendingPtDist = 0;
      else {
        var o = n * n + i * i;
        o > this._pendingPtDist && (this._pendingPtX = t, this._pendingPtY = r, this._pendingPtDist = o);
      }
      return this;
    }, e.prototype.bezierCurveTo = function(t, r, n, i, a, o) {
      return this._drawPendingPt(), this.addData(Q.C, t, r, n, i, a, o), this._ctx && this._ctx.bezierCurveTo(t, r, n, i, a, o), this._xi = a, this._yi = o, this;
    }, e.prototype.quadraticCurveTo = function(t, r, n, i) {
      return this._drawPendingPt(), this.addData(Q.Q, t, r, n, i), this._ctx && this._ctx.quadraticCurveTo(t, r, n, i), this._xi = n, this._yi = i, this;
    }, e.prototype.arc = function(t, r, n, i, a, o) {
      this._drawPendingPt(), ai[0] = i, ai[1] = a, q1(ai, o), i = ai[0], a = ai[1];
      var s = a - i;
      return this.addData(Q.A, t, r, n, n, i, s, 0, o ? 0 : 1), this._ctx && this._ctx.arc(t, r, n, i, a, o), this._xi = Ar(a) * n + t, this._yi = Er(a) * n + r, this;
    }, e.prototype.arcTo = function(t, r, n, i, a) {
      return this._drawPendingPt(), this._ctx && this._ctx.arcTo(t, r, n, i, a), this;
    }, e.prototype.rect = function(t, r, n, i) {
      return this._drawPendingPt(), this._ctx && this._ctx.rect(t, r, n, i), this.addData(Q.R, t, r, n, i), this;
    }, e.prototype.closePath = function() {
      this._drawPendingPt(), this.addData(Q.Z);
      var t = this._ctx, r = this._x0, n = this._y0;
      return t && t.closePath(), this._xi = r, this._yi = n, this;
    }, e.prototype.fill = function(t) {
      t && t.fill(), this.toStatic();
    }, e.prototype.stroke = function(t) {
      t && t.stroke(), this.toStatic();
    }, e.prototype.len = function() {
      return this._len;
    }, e.prototype.setData = function(t) {
      var r = t.length;
      !(this.data && this.data.length === r) && Qs && (this.data = new Float32Array(r));
      for (var n = 0; n < r; n++) this.data[n] = t[n];
      this._len = r;
    }, e.prototype.appendPath = function(t) {
      t instanceof Array || (t = [
        t
      ]);
      for (var r = t.length, n = 0, i = this._len, a = 0; a < r; a++) n += t[a].len();
      Qs && this.data instanceof Float32Array && (this.data = new Float32Array(i + n));
      for (var a = 0; a < r; a++) for (var o = t[a].data, s = 0; s < o.length; s++) this.data[i++] = o[s];
      this._len = i;
    }, e.prototype.addData = function(t, r, n, i, a, o, s, u, l) {
      if (this._saveData) {
        var f = this.data;
        this._len + arguments.length > f.length && (this._expandData(), f = this.data);
        for (var h = 0; h < arguments.length; h++) f[this._len++] = arguments[h];
      }
    }, e.prototype._drawPendingPt = function() {
      this._pendingPtDist > 0 && (this._ctx && this._ctx.lineTo(this._pendingPtX, this._pendingPtY), this._pendingPtDist = 0);
    }, e.prototype._expandData = function() {
      if (!(this.data instanceof Array)) {
        for (var t = [], r = 0; r < this._len; r++) t[r] = this.data[r];
        this.data = t;
      }
    }, e.prototype.toStatic = function() {
      if (this._saveData) {
        this._drawPendingPt();
        var t = this.data;
        t instanceof Array && (t.length = this._len, Qs && this._len > 11 && (this.data = new Float32Array(t)));
      }
    }, e.prototype.getBoundingRect = function() {
      be[0] = be[1] = we[0] = we[1] = Number.MAX_VALUE, je[0] = je[1] = Te[0] = Te[1] = -Number.MAX_VALUE;
      var t = this.data, r = 0, n = 0, i = 0, a = 0, o;
      for (o = 0; o < this._len; ) {
        var s = t[o++], u = o === 1;
        switch (u && (r = t[o], n = t[o + 1], i = r, a = n), s) {
          case Q.M:
            r = i = t[o++], n = a = t[o++], we[0] = i, we[1] = a, Te[0] = i, Te[1] = a;
            break;
          case Q.L:
            Xh(r, n, t[o], t[o + 1], we, Te), r = t[o++], n = t[o++];
            break;
          case Q.C:
            U1(r, n, t[o++], t[o++], t[o++], t[o++], t[o], t[o + 1], we, Te), r = t[o++], n = t[o++];
            break;
          case Q.Q:
            W1(r, n, t[o++], t[o++], t[o], t[o + 1], we, Te), r = t[o++], n = t[o++];
            break;
          case Q.A:
            var l = t[o++], f = t[o++], h = t[o++], c = t[o++], v = t[o++], p = t[o++] + v;
            o += 1;
            var y = !t[o++];
            u && (i = Ar(v) * h + l, a = Er(v) * c + f), Y1(l, f, h, c, v, p, y, we, Te), r = Ar(p) * h + l, n = Er(p) * c + f;
            break;
          case Q.R:
            i = r = t[o++], a = n = t[o++];
            var g = t[o++], d = t[o++];
            Xh(i, a, i + g, a + d, we, Te);
            break;
          case Q.Z:
            r = i, n = a;
            break;
        }
        or(be, be, we), sr(je, je, Te);
      }
      return o === 0 && (be[0] = be[1] = je[0] = je[1] = 0), new at(be[0], be[1], je[0] - be[0], je[1] - be[1]);
    }, e.prototype._calculateLength = function() {
      var t = this.data, r = this._len, n = this._ux, i = this._uy, a = 0, o = 0, s = 0, u = 0;
      this._pathSegLen || (this._pathSegLen = []);
      for (var l = this._pathSegLen, f = 0, h = 0, c = 0; c < r; ) {
        var v = t[c++], p = c === 1;
        p && (a = t[c], o = t[c + 1], s = a, u = o);
        var y = -1;
        switch (v) {
          case Q.M:
            a = s = t[c++], o = u = t[c++];
            break;
          case Q.L: {
            var g = t[c++], d = t[c++], m = g - a, _ = d - o;
            (Ge(m) > n || Ge(_) > i || c === r - 1) && (y = Math.sqrt(m * m + _ * _), a = g, o = d);
            break;
          }
          case Q.C: {
            var S = t[c++], T = t[c++], g = t[c++], d = t[c++], b = t[c++], w = t[c++];
            y = t_(a, o, S, T, g, d, b, w, 10), a = b, o = w;
            break;
          }
          case Q.Q: {
            var S = t[c++], T = t[c++], g = t[c++], d = t[c++];
            y = n_(a, o, S, T, g, d, 10), a = g, o = d;
            break;
          }
          case Q.A:
            var D = t[c++], C = t[c++], M = t[c++], x = t[c++], I = t[c++], A = t[c++], E = A + I;
            c += 1, p && (s = Ar(I) * M + D, u = Er(I) * x + C), y = js(M, x) * Ks(ar, Math.abs(A)), a = Ar(E) * M + D, o = Er(E) * x + C;
            break;
          case Q.R: {
            s = a = t[c++], u = o = t[c++];
            var R = t[c++], L = t[c++];
            y = R * 2 + L * 2;
            break;
          }
          case Q.Z: {
            var m = s - a, _ = u - o;
            y = Math.sqrt(m * m + _ * _), a = s, o = u;
            break;
          }
        }
        y >= 0 && (l[h++] = y, f += y);
      }
      return this._pathLen = f, f;
    }, e.prototype.rebuildPath = function(t, r) {
      var n = this.data, i = this._ux, a = this._uy, o = this._len, s, u, l, f, h, c, v = r < 1, p, y, g = 0, d = 0, m, _ = 0, S, T;
      if (!(v && (this._pathSegLen || this._calculateLength(), p = this._pathSegLen, y = this._pathLen, m = r * y, !m))) t: for (var b = 0; b < o; ) {
        var w = n[b++], D = b === 1;
        switch (D && (l = n[b], f = n[b + 1], s = l, u = f), w !== Q.L && _ > 0 && (t.lineTo(S, T), _ = 0), w) {
          case Q.M:
            s = l = n[b++], u = f = n[b++], t.moveTo(l, f);
            break;
          case Q.L: {
            h = n[b++], c = n[b++];
            var C = Ge(h - l), M = Ge(c - f);
            if (C > i || M > a) {
              if (v) {
                var x = p[d++];
                if (g + x > m) {
                  var I = (m - g) / x;
                  t.lineTo(l * (1 - I) + h * I, f * (1 - I) + c * I);
                  break t;
                }
                g += x;
              }
              t.lineTo(h, c), l = h, f = c, _ = 0;
            } else {
              var A = C * C + M * M;
              A > _ && (S = h, T = c, _ = A);
            }
            break;
          }
          case Q.C: {
            var E = n[b++], R = n[b++], L = n[b++], z = n[b++], k = n[b++], N = n[b++];
            if (v) {
              var x = p[d++];
              if (g + x > m) {
                var I = (m - g) / x;
                lo(l, E, L, k, I, Pr), lo(f, R, z, N, I, Ir), t.bezierCurveTo(Pr[1], Ir[1], Pr[2], Ir[2], Pr[3], Ir[3]);
                break t;
              }
              g += x;
            }
            t.bezierCurveTo(E, R, L, z, k, N), l = k, f = N;
            break;
          }
          case Q.Q: {
            var E = n[b++], R = n[b++], L = n[b++], z = n[b++];
            if (v) {
              var x = p[d++];
              if (g + x > m) {
                var I = (m - g) / x;
                fo(l, E, L, I, Pr), fo(f, R, z, I, Ir), t.quadraticCurveTo(Pr[1], Ir[1], Pr[2], Ir[2]);
                break t;
              }
              g += x;
            }
            t.quadraticCurveTo(E, R, L, z), l = L, f = z;
            break;
          }
          case Q.A:
            var U = n[b++], J = n[b++], $ = n[b++], rt = n[b++], tt = n[b++], st = n[b++], Gt = n[b++], Fe = !n[b++], le = $ > rt ? $ : rt, St = Ge($ - rt) > 1e-3, dt = tt + st, H = false;
            if (v) {
              var x = p[d++];
              g + x > m && (dt = tt + st * (m - g) / x, H = true), g += x;
            }
            if (St && t.ellipse ? t.ellipse(U, J, $, rt, Gt, tt, dt, Fe) : t.arc(U, J, le, tt, dt, Fe), H) break t;
            D && (s = Ar(tt) * $ + U, u = Er(tt) * rt + J), l = Ar(dt) * $ + U, f = Er(dt) * rt + J;
            break;
          case Q.R:
            s = l = n[b], u = f = n[b + 1], h = n[b++], c = n[b++];
            var X = n[b++], fe = n[b++];
            if (v) {
              var x = p[d++];
              if (g + x > m) {
                var gt = m - g;
                t.moveTo(h, c), t.lineTo(h + Ks(gt, X), c), gt -= X, gt > 0 && t.lineTo(h + X, c + Ks(gt, fe)), gt -= fe, gt > 0 && t.lineTo(h + js(X - gt, 0), c + fe), gt -= X, gt > 0 && t.lineTo(h, c + js(fe - gt, 0));
                break t;
              }
              g += x;
            }
            t.rect(h, c, X, fe);
            break;
          case Q.Z:
            if (v) {
              var x = p[d++];
              if (g + x > m) {
                var I = (m - g) / x;
                t.lineTo(l * (1 - I) + s * I, f * (1 - I) + u * I);
                break t;
              }
              g += x;
            }
            t.closePath(), l = s, f = u;
        }
      }
    }, e.prototype.clone = function() {
      var t = new e(), r = this.data;
      return t.data = r.slice ? r.slice() : Array.prototype.slice.call(r), t._len = this._len, t;
    }, e.CMD = Q, e.initDefaultProps = (function() {
      var t = e.prototype;
      t._saveData = true, t._ux = 0, t._uy = 0, t._pendingPtDist = 0, t._version = 0;
    })(), e;
  })();
  function vn(e, t, r, n, i, a, o) {
    if (i === 0) return false;
    var s = i, u = 0, l = e;
    if (o > t + s && o > n + s || o < t - s && o < n - s || a > e + s && a > r + s || a < e - s && a < r - s) return false;
    if (e !== r) u = (t - n) / (e - r), l = (e * n - r * t) / (e - r);
    else return Math.abs(a - e) <= s / 2;
    var f = u * a - o + l, h = f * f / (u * u + 1);
    return h <= s / 2 * s / 2;
  }
  function X1(e, t, r, n, i, a, o, s, u, l, f) {
    if (u === 0) return false;
    var h = u;
    if (f > t + h && f > n + h && f > a + h && f > s + h || f < t - h && f < n - h && f < a - h && f < s - h || l > e + h && l > r + h && l > i + h && l > o + h || l < e - h && l < r - h && l < i - h && l < o - h) return false;
    var c = Jm(e, t, r, n, i, a, o, s, l, f);
    return c <= h / 2;
  }
  function $1(e, t, r, n, i, a, o, s, u) {
    if (o === 0) return false;
    var l = o;
    if (u > t + l && u > n + l && u > a + l || u < t - l && u < n - l && u < a - l || s > e + l && s > r + l && s > i + l || s < e - l && s < r - l && s < i - l) return false;
    var f = r_(e, t, r, n, i, a, s, u);
    return f <= l / 2;
  }
  var Kh = Math.PI * 2;
  function wa(e) {
    return e %= Kh, e < 0 && (e += Kh), e;
  }
  var oi = Math.PI * 2;
  function Z1(e, t, r, n, i, a, o, s, u) {
    if (o === 0) return false;
    var l = o;
    s -= e, u -= t;
    var f = Math.sqrt(s * s + u * u);
    if (f - l > r || f + l < r) return false;
    if (Math.abs(n - i) % oi < 1e-4) return true;
    if (a) {
      var h = n;
      n = wa(i), i = wa(h);
    } else n = wa(n), i = wa(i);
    n > i && (i += oi);
    var c = Math.atan2(u, s);
    return c < 0 && (c += oi), c >= n && c <= i || c + oi >= n && c + oi <= i;
  }
  function We(e, t, r, n, i, a) {
    if (a > t && a > n || a < t && a < n || n === t) return 0;
    var o = (a - t) / (n - t), s = n < t ? 1 : -1;
    (o === 1 || o === 0) && (s = n < t ? 0.5 : -0.5);
    var u = o * (r - e) + e;
    return u === i ? 1 / 0 : u > i ? s : 0;
  }
  var Qe = yr.CMD, Lr = Math.PI * 2, K1 = 1e-4;
  function j1(e, t) {
    return Math.abs(e - t) < K1;
  }
  var It = [
    -1,
    -1,
    -1
  ], Qt = [
    -1,
    -1
  ];
  function Q1() {
    var e = Qt[0];
    Qt[0] = Qt[1], Qt[1] = e;
  }
  function J1(e, t, r, n, i, a, o, s, u, l) {
    if (l > t && l > n && l > a && l > s || l < t && l < n && l < a && l < s) return 0;
    var f = uo(t, n, a, s, l, It);
    if (f === 0) return 0;
    for (var h = 0, c = -1, v = void 0, p = void 0, y = 0; y < f; y++) {
      var g = It[y], d = g === 0 || g === 1 ? 0.5 : 1, m = Tt(e, r, i, o, g);
      m < u || (c < 0 && (c = jp(t, n, a, s, Qt), Qt[1] < Qt[0] && c > 1 && Q1(), v = Tt(t, n, a, s, Qt[0]), c > 1 && (p = Tt(t, n, a, s, Qt[1]))), c === 2 ? g < Qt[0] ? h += v < t ? d : -d : g < Qt[1] ? h += p < v ? d : -d : h += s < p ? d : -d : g < Qt[0] ? h += v < t ? d : -d : h += s < v ? d : -d);
    }
    return h;
  }
  function tS(e, t, r, n, i, a, o, s) {
    if (s > t && s > n && s > a || s < t && s < n && s < a) return 0;
    var u = e_(t, n, a, s, It);
    if (u === 0) return 0;
    var l = Qp(t, n, a);
    if (l >= 0 && l <= 1) {
      for (var f = 0, h = Ft(t, n, a, l), c = 0; c < u; c++) {
        var v = It[c] === 0 || It[c] === 1 ? 0.5 : 1, p = Ft(e, r, i, It[c]);
        p < o || (It[c] < l ? f += h < t ? v : -v : f += a < h ? v : -v);
      }
      return f;
    } else {
      var v = It[0] === 0 || It[0] === 1 ? 0.5 : 1, p = Ft(e, r, i, It[0]);
      return p < o ? 0 : a < t ? v : -v;
    }
  }
  function eS(e, t, r, n, i, a, o, s) {
    if (s -= t, s > r || s < -r) return 0;
    var u = Math.sqrt(r * r - s * s);
    It[0] = -u, It[1] = u;
    var l = Math.abs(n - i);
    if (l < 1e-4) return 0;
    if (l >= Lr - 1e-4) {
      n = 0, i = Lr;
      var f = a ? 1 : -1;
      return o >= It[0] + e && o <= It[1] + e ? f : 0;
    }
    if (n > i) {
      var h = n;
      n = i, i = h;
    }
    n < 0 && (n += Lr, i += Lr);
    for (var c = 0, v = 0; v < 2; v++) {
      var p = It[v];
      if (p + e > o) {
        var y = Math.atan2(s, p), f = a ? 1 : -1;
        y < 0 && (y = Lr + y), (y >= n && y <= i || y + Lr >= n && y + Lr <= i) && (y > Math.PI / 2 && y < Math.PI * 1.5 && (f = -f), c += f);
      }
    }
    return c;
  }
  function Bd(e, t, r, n, i) {
    for (var a = e.data, o = e.len(), s = 0, u = 0, l = 0, f = 0, h = 0, c, v, p = 0; p < o; ) {
      var y = a[p++], g = p === 1;
      switch (y === Qe.M && p > 1 && (r || (s += We(u, l, f, h, n, i))), g && (u = a[p], l = a[p + 1], f = u, h = l), y) {
        case Qe.M:
          f = a[p++], h = a[p++], u = f, l = h;
          break;
        case Qe.L:
          if (r) {
            if (vn(u, l, a[p], a[p + 1], t, n, i)) return true;
          } else s += We(u, l, a[p], a[p + 1], n, i) || 0;
          u = a[p++], l = a[p++];
          break;
        case Qe.C:
          if (r) {
            if (X1(u, l, a[p++], a[p++], a[p++], a[p++], a[p], a[p + 1], t, n, i)) return true;
          } else s += J1(u, l, a[p++], a[p++], a[p++], a[p++], a[p], a[p + 1], n, i) || 0;
          u = a[p++], l = a[p++];
          break;
        case Qe.Q:
          if (r) {
            if ($1(u, l, a[p++], a[p++], a[p], a[p + 1], t, n, i)) return true;
          } else s += tS(u, l, a[p++], a[p++], a[p], a[p + 1], n, i) || 0;
          u = a[p++], l = a[p++];
          break;
        case Qe.A:
          var d = a[p++], m = a[p++], _ = a[p++], S = a[p++], T = a[p++], b = a[p++];
          p += 1;
          var w = !!(1 - a[p++]);
          c = Math.cos(T) * _ + d, v = Math.sin(T) * S + m, g ? (f = c, h = v) : s += We(u, l, c, v, n, i);
          var D = (n - d) * S / _ + d;
          if (r) {
            if (Z1(d, m, S, T, T + b, w, t, D, i)) return true;
          } else s += eS(d, m, S, T, T + b, w, D, i);
          u = Math.cos(T + b) * _ + d, l = Math.sin(T + b) * S + m;
          break;
        case Qe.R:
          f = u = a[p++], h = l = a[p++];
          var C = a[p++], M = a[p++];
          if (c = f + C, v = h + M, r) {
            if (vn(f, h, c, h, t, n, i) || vn(c, h, c, v, t, n, i) || vn(c, v, f, v, t, n, i) || vn(f, v, f, h, t, n, i)) return true;
          } else s += We(c, h, c, v, n, i), s += We(f, v, f, h, n, i);
          break;
        case Qe.Z:
          if (r) {
            if (vn(u, l, f, h, t, n, i)) return true;
          } else s += We(u, l, f, h, n, i);
          u = f, l = h;
          break;
      }
    }
    return !r && !j1(l, h) && (s += We(u, l, f, h, n, i) || 0), s !== 0;
  }
  function rS(e, t, r) {
    return Bd(e, 0, false, t, r);
  }
  function nS(e, t, r, n) {
    return Bd(e, t, true, r, n);
  }
  var co = ht({
    fill: "#000",
    stroke: null,
    strokePercent: 1,
    fillOpacity: 1,
    strokeOpacity: 1,
    lineDashOffset: 0,
    lineWidth: 1,
    lineCap: "butt",
    miterLimit: 10,
    strokeNoScale: false,
    strokeFirst: false
  }, Kr), iS = {
    style: ht({
      fill: true,
      stroke: true,
      strokePercent: true,
      fillOpacity: true,
      strokeOpacity: true,
      lineDashOffset: true,
      lineWidth: true,
      miterLimit: true
    }, Yo.style)
  }, tu = Ui.concat([
    "invisible",
    "culling",
    "z",
    "z2",
    "zlevel",
    "parent"
  ]), et = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.update = function() {
      var r = this;
      e.prototype.update.call(this);
      var n = this.style;
      if (n.decal) {
        var i = this._decalEl = this._decalEl || new t();
        i.buildPath === t.prototype.buildPath && (i.buildPath = function(u) {
          r.buildPath(u, r.shape);
        }), i.silent = true;
        var a = i.style;
        for (var o in n) a[o] !== n[o] && (a[o] = n[o]);
        a.fill = n.fill ? n.decal : null, a.decal = null, a.shadowColor = null, n.strokeFirst && (a.stroke = null);
        for (var s = 0; s < tu.length; ++s) i[tu[s]] = this[tu[s]];
        i.__dirty |= xe;
      } else this._decalEl && (this._decalEl = null);
    }, t.prototype.getDecalElement = function() {
      return this._decalEl;
    }, t.prototype._init = function(r) {
      var n = K(r);
      this.shape = this.getDefaultShape();
      var i = this.getDefaultStyle();
      i && this.useStyle(i);
      for (var a = 0; a < n.length; a++) {
        var o = n[a], s = r[o];
        o === "style" ? this.style ? O(this.style, s) : this.useStyle(s) : o === "shape" ? O(this.shape, s) : e.prototype.attrKV.call(this, o, s);
      }
      this.style || this.useStyle({});
    }, t.prototype.getDefaultStyle = function() {
      return null;
    }, t.prototype.getDefaultShape = function() {
      return {};
    }, t.prototype.canBeInsideText = function() {
      return this.hasFill();
    }, t.prototype.getInsideTextFill = function() {
      var r = this.style.fill;
      if (r !== "none") {
        if (V(r)) {
          var n = Gi(r, 0);
          return n > 0.5 ? Qu : n > 0.2 ? N_ : Ju;
        } else if (r) return Ju;
      }
      return Qu;
    }, t.prototype.getInsideTextStroke = function(r) {
      var n = this.style.fill;
      if (V(n)) {
        var i = this.__zr, a = !!(i && i.isDarkMode()), o = Gi(r, 0) < ju;
        if (a === o) return n;
      }
    }, t.prototype.buildPath = function(r, n, i) {
    }, t.prototype.pathUpdated = function() {
      this.__dirty &= ~wn;
    }, t.prototype.getUpdatedPathProxy = function(r) {
      return !this.path && this.createPathProxy(), this.path.beginPath(), this.buildPath(this.path, this.shape, r), this.path;
    }, t.prototype.createPathProxy = function() {
      this.path = new yr(false);
    }, t.prototype.hasStroke = function() {
      var r = this.style, n = r.stroke;
      return !(n == null || n === "none" || !(r.lineWidth > 0));
    }, t.prototype.hasFill = function() {
      var r = this.style, n = r.fill;
      return n != null && n !== "none";
    }, t.prototype.getBoundingRect = function() {
      var r = this._rect, n = this.style, i = !r;
      if (i) {
        var a = false;
        this.path || (a = true, this.createPathProxy());
        var o = this.path;
        (a || this.__dirty & wn) && (o.beginPath(), this.buildPath(o, this.shape, false), this.pathUpdated()), r = o.getBoundingRect();
      }
      if (this._rect = r, this.hasStroke() && this.path && this.path.len() > 0) {
        var s = this._rectStroke || (this._rectStroke = r.clone());
        if (this.__dirty || i) {
          s.copy(r);
          var u = n.strokeNoScale ? this.getLineScale() : 1, l = n.lineWidth;
          if (!this.hasFill()) {
            var f = this.strokeContainThreshold;
            l = Math.max(l, f ?? 4);
          }
          u > 1e-10 && (s.width += l / u, s.height += l / u, s.x -= l / u / 2, s.y -= l / u / 2);
        }
        return s;
      }
      return r;
    }, t.prototype.contain = function(r, n) {
      var i = this.transformCoordToLocal(r, n), a = this.getBoundingRect(), o = this.style;
      if (r = i[0], n = i[1], a.contain(r, n)) {
        var s = this.path;
        if (this.hasStroke()) {
          var u = o.lineWidth, l = o.strokeNoScale ? this.getLineScale() : 1;
          if (l > 1e-10 && (this.hasFill() || (u = Math.max(u, this.strokeContainThreshold)), nS(s, u / l, r, n))) return true;
        }
        if (this.hasFill()) return rS(s, r, n);
      }
      return false;
    }, t.prototype.dirtyShape = function() {
      this.__dirty |= wn, this._rect && (this._rect = null), this._decalEl && this._decalEl.dirtyShape(), this.markRedraw();
    }, t.prototype.dirty = function() {
      this.dirtyStyle(), this.dirtyShape();
    }, t.prototype.animateShape = function(r) {
      return this.animate("shape", r);
    }, t.prototype.updateDuringAnimation = function(r) {
      r === "style" ? this.dirtyStyle() : r === "shape" ? this.dirtyShape() : this.markRedraw();
    }, t.prototype.attrKV = function(r, n) {
      r === "shape" ? this.setShape(n) : e.prototype.attrKV.call(this, r, n);
    }, t.prototype.setShape = function(r, n) {
      var i = this.shape;
      return i || (i = this.shape = {}), typeof r == "string" ? i[r] = n : O(i, r), this.dirtyShape(), this;
    }, t.prototype.shapeChanged = function() {
      return !!(this.__dirty & wn);
    }, t.prototype.createStyle = function(r) {
      return ea(co, r);
    }, t.prototype._innerSaveToNormal = function(r) {
      e.prototype._innerSaveToNormal.call(this, r);
      var n = this._normalState;
      r.shape && !n.shape && (n.shape = O({}, this.shape));
    }, t.prototype._applyStateObj = function(r, n, i, a, o, s) {
      e.prototype._applyStateObj.call(this, r, n, i, a, o, s);
      var u = !(n && a), l;
      if (n && n.shape ? o ? a ? l = n.shape : (l = O({}, i.shape), O(l, n.shape)) : (l = O({}, a ? this.shape : i.shape), O(l, n.shape)) : u && (l = i.shape), l) if (o) {
        this.shape = O({}, this.shape);
        for (var f = {}, h = K(l), c = 0; c < h.length; c++) {
          var v = h[c];
          typeof l[v] == "object" ? this.shape[v] = l[v] : f[v] = l[v];
        }
        this._transitionState(r, {
          shape: f
        }, s);
      } else this.shape = l, this.dirtyShape();
    }, t.prototype._mergeStates = function(r) {
      for (var n = e.prototype._mergeStates.call(this, r), i, a = 0; a < r.length; a++) {
        var o = r[a];
        o.shape && (i = i || {}, this._mergeStyle(i, o.shape));
      }
      return i && (n.shape = i), n;
    }, t.prototype.getAnimationStyleProps = function() {
      return iS;
    }, t.prototype.isZeroArea = function() {
      return false;
    }, t.extend = function(r) {
      var n = (function(a) {
        ot(o, a);
        function o(s) {
          var u = a.call(this, s) || this;
          return r.init && r.init.call(u, s), u;
        }
        return o.prototype.getDefaultStyle = function() {
          return Z(r.style);
        }, o.prototype.getDefaultShape = function() {
          return Z(r.shape);
        }, o;
      })(t);
      for (var i in r) typeof r[i] == "function" && (n.prototype[i] = r[i]);
      return n;
    }, t.initDefaultProps = (function() {
      var r = t.prototype;
      r.type = "path", r.strokeContainThreshold = 5, r.segmentIgnoreThreshold = 0, r.subPixelOptimize = false, r.autoBatch = false, r.__dirty = xe | mi | wn;
    })(), t;
  })(na), aS = ht({
    strokeFirst: true,
    font: pr,
    x: 0,
    y: 0,
    textAlign: "left",
    textBaseline: "top",
    miterLimit: 2
  }, co), Xi = (function(e) {
    ot(t, e);
    function t() {
      return e !== null && e.apply(this, arguments) || this;
    }
    return t.prototype.hasStroke = function() {
      var r = this.style, n = r.stroke;
      return n != null && n !== "none" && r.lineWidth > 0;
    }, t.prototype.hasFill = function() {
      var r = this.style, n = r.fill;
      return n != null && n !== "none";
    }, t.prototype.createStyle = function(r) {
      return ea(aS, r);
    }, t.prototype.setBoundingRect = function(r) {
      this._rect = r;
    }, t.prototype.getBoundingRect = function() {
      var r = this.style;
      if (!this._rect) {
        var n = r.text;
        n != null ? n += "" : n = "";
        var i = vd(n, r.font, r.textAlign, r.textBaseline);
        if (i.x += r.x || 0, i.y += r.y || 0, this.hasStroke()) {
          var a = r.lineWidth;
          i.x -= a / 2, i.y -= a / 2, i.width += a, i.height += a;
        }
        this._rect = i;
      }
      return this._rect;
    }, t.initDefaultProps = (function() {
      var r = t.prototype;
      r.dirtyRectTolerance = 10;
    })(), t;
  })(na);
  Xi.prototype.type = "tspan";
  var oS = ht({
    x: 0,
    y: 0
  }, Kr), sS = {
    style: ht({
      x: true,
      y: true,
      width: true,
      height: true,
      sx: true,
      sy: true,
      sWidth: true,
      sHeight: true
    }, Yo.style)
  };
  function uS(e) {
    return !!(e && typeof e != "string" && e.width && e.height);
  }
  var Se = (function(e) {
    ot(t, e);
    function t() {
      return e !== null && e.apply(this, arguments) || this;
    }
    return t.prototype.createStyle = function(r) {
      return ea(oS, r);
    }, t.prototype._getSize = function(r) {
      var n = this.style, i = n[r];
      if (i != null) return i;
      var a = uS(n.image) ? n.image : this.__image;
      if (!a) return 0;
      var o = r === "width" ? "height" : "width", s = n[o];
      return s == null ? a[r] : a[r] / a[o] * s;
    }, t.prototype.getWidth = function() {
      return this._getSize("width");
    }, t.prototype.getHeight = function() {
      return this._getSize("height");
    }, t.prototype.getAnimationStyleProps = function() {
      return sS;
    }, t.prototype.getBoundingRect = function() {
      var r = this.style;
      return this._rect || (this._rect = new at(r.x || 0, r.y || 0, this.getWidth(), this.getHeight())), this._rect;
    }, t;
  })(na);
  Se.prototype.type = "image";
  function lS(e, t) {
    var r = t.x, n = t.y, i = t.width, a = t.height, o = t.r, s, u, l, f;
    i < 0 && (r = r + i, i = -i), a < 0 && (n = n + a, a = -a), typeof o == "number" ? s = u = l = f = o : o instanceof Array ? o.length === 1 ? s = u = l = f = o[0] : o.length === 2 ? (s = l = o[0], u = f = o[1]) : o.length === 3 ? (s = o[0], u = f = o[1], l = o[2]) : (s = o[0], u = o[1], l = o[2], f = o[3]) : s = u = l = f = 0;
    var h;
    s + u > i && (h = s + u, s *= i / h, u *= i / h), l + f > i && (h = l + f, l *= i / h, f *= i / h), u + l > a && (h = u + l, u *= a / h, l *= a / h), s + f > a && (h = s + f, s *= a / h, f *= a / h), e.moveTo(r + s, n), e.lineTo(r + i - u, n), u !== 0 && e.arc(r + i - u, n + u, u, -Math.PI / 2, 0), e.lineTo(r + i, n + a - l), l !== 0 && e.arc(r + i - l, n + a - l, l, 0, Math.PI / 2), e.lineTo(r + f, n + a), f !== 0 && e.arc(r + f, n + a - f, f, Math.PI / 2, Math.PI), e.lineTo(r, n + s), s !== 0 && e.arc(r + s, n + s, s, Math.PI, Math.PI * 1.5);
  }
  var Dn = Math.round;
  function zd(e, t, r) {
    if (t) {
      var n = t.x1, i = t.x2, a = t.y1, o = t.y2;
      e.x1 = n, e.x2 = i, e.y1 = a, e.y2 = o;
      var s = r && r.lineWidth;
      return s && (Dn(n * 2) === Dn(i * 2) && (e.x1 = e.x2 = qr(n, s, true)), Dn(a * 2) === Dn(o * 2) && (e.y1 = e.y2 = qr(a, s, true))), e;
    }
  }
  function Vd(e, t, r) {
    if (t) {
      var n = t.x, i = t.y, a = t.width, o = t.height;
      e.x = n, e.y = i, e.width = a, e.height = o;
      var s = r && r.lineWidth;
      return s && (e.x = qr(n, s, true), e.y = qr(i, s, true), e.width = Math.max(qr(n + a, s, false) - e.x, a === 0 ? 0 : 1), e.height = Math.max(qr(i + o, s, false) - e.y, o === 0 ? 0 : 1)), e;
    }
  }
  function qr(e, t, r) {
    if (!t) return e;
    var n = Dn(e * 2);
    return (n + Dn(t)) % 2 === 0 ? n / 2 : (n + (r ? 1 : -1)) / 2;
  }
  let fS, hS;
  fS = /* @__PURE__ */ (function() {
    function e() {
      this.x = 0, this.y = 0, this.width = 0, this.height = 0;
    }
    return e;
  })();
  hS = {};
  ne = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultShape = function() {
      return new fS();
    }, t.prototype.buildPath = function(r, n) {
      var i, a, o, s;
      if (this.subPixelOptimize) {
        var u = Vd(hS, n, this.style);
        i = u.x, a = u.y, o = u.width, s = u.height, u.r = n.r, n = u;
      } else i = n.x, a = n.y, o = n.width, s = n.height;
      n.r ? lS(r, n) : r.rect(i, a, o, s);
    }, t.prototype.isZeroArea = function() {
      return !this.shape.width || !this.shape.height;
    }, t;
  })(et);
  ne.prototype.type = "rect";
  let jh, Qh, vS, cS, pS, Jh;
  jh = {
    fill: "#000"
  };
  Qh = 2;
  vS = {
    style: ht({
      fill: true,
      stroke: true,
      fillOpacity: true,
      strokeOpacity: true,
      lineWidth: true,
      fontSize: true,
      lineHeight: true,
      width: true,
      height: true,
      textShadowColor: true,
      textShadowBlur: true,
      textShadowOffsetX: true,
      textShadowOffsetY: true,
      backgroundColor: true,
      padding: true,
      borderColor: true,
      borderWidth: true,
      borderRadius: true
    }, Yo.style)
  };
  Re = (function(e) {
    ot(t, e);
    function t(r) {
      var n = e.call(this) || this;
      return n.type = "text", n._children = [], n._defaultStyle = jh, n.attr(r), n;
    }
    return t.prototype.childrenRef = function() {
      return this._children;
    }, t.prototype.update = function() {
      e.prototype.update.call(this), this.styleChanged() && this._updateSubTexts();
      for (var r = 0; r < this._children.length; r++) {
        var n = this._children[r];
        n.zlevel = this.zlevel, n.z = this.z, n.z2 = this.z2, n.culling = this.culling, n.cursor = this.cursor, n.invisible = this.invisible;
      }
    }, t.prototype.updateTransform = function() {
      var r = this.innerTransformable;
      r ? (r.updateTransform(), r.transform && (this.transform = r.transform)) : e.prototype.updateTransform.call(this);
    }, t.prototype.getLocalTransform = function(r) {
      var n = this.innerTransformable;
      return n ? n.getLocalTransform(r) : e.prototype.getLocalTransform.call(this, r);
    }, t.prototype.getComputedTransform = function() {
      return this.__hostTarget && (this.__hostTarget.getComputedTransform(), this.__hostTarget.updateInnerText(true)), e.prototype.getComputedTransform.call(this);
    }, t.prototype._updateSubTexts = function() {
      this._childCursor = 0, dS(this.style), this.style.rich ? this._updateRichTexts() : this._updatePlainTexts(), this._children.length = this._childCursor, this.styleUpdated();
    }, t.prototype.addSelfToZr = function(r) {
      e.prototype.addSelfToZr.call(this, r);
      for (var n = 0; n < this._children.length; n++) this._children[n].__zr = r;
    }, t.prototype.removeSelfFromZr = function(r) {
      e.prototype.removeSelfFromZr.call(this, r);
      for (var n = 0; n < this._children.length; n++) this._children[n].__zr = null;
    }, t.prototype.getBoundingRect = function() {
      if (this.styleChanged() && this._updateSubTexts(), !this._rect) {
        for (var r = new at(0, 0, 0, 0), n = this._children, i = [], a = null, o = 0; o < n.length; o++) {
          var s = n[o], u = s.getBoundingRect(), l = s.getLocalTransform(i);
          l ? (r.copy(u), r.applyTransform(l), a = a || r.clone(), a.union(r)) : (a = a || u.clone(), a.union(u));
        }
        this._rect = a || r;
      }
      return this._rect;
    }, t.prototype.setDefaultTextStyle = function(r) {
      this._defaultStyle = r || jh;
    }, t.prototype.setTextContent = function(r) {
    }, t.prototype._mergeStyle = function(r, n) {
      if (!n) return r;
      var i = n.rich, a = r.rich || i && {};
      return O(r, n), i && a ? (this._mergeRich(a, i), r.rich = a) : a && (r.rich = a), r;
    }, t.prototype._mergeRich = function(r, n) {
      for (var i = K(n), a = 0; a < i.length; a++) {
        var o = i[a];
        r[o] = r[o] || {}, O(r[o], n[o]);
      }
    }, t.prototype.getAnimationStyleProps = function() {
      return vS;
    }, t.prototype._getOrCreateChild = function(r) {
      var n = this._children[this._childCursor];
      return (!n || !(n instanceof r)) && (n = new r()), this._children[this._childCursor++] = n, n.__zr = this.__zr, n.parent = this, n;
    }, t.prototype._updatePlainTexts = function() {
      var r = this.style, n = r.font || pr, i = r.padding, a = av(r), o = O1(a, r), s = eu(r), u = !!r.backgroundColor, l = o.outerHeight, f = o.outerWidth, h = o.contentWidth, c = o.lines, v = o.lineHeight, p = this._defaultStyle;
      this.isTruncated = !!o.isTruncated;
      var y = r.x || 0, g = r.y || 0, d = r.align || p.align || "left", m = r.verticalAlign || p.verticalAlign || "top", _ = y, S = Tn(g, o.contentHeight, m);
      if (s || i) {
        var T = Si(y, f, d), b = Tn(g, l, m);
        s && this._renderBackground(r, r, T, b, f, l);
      }
      S += v / 2, i && (_ = iv(y, d, i), m === "top" ? S += i[0] : m === "bottom" && (S -= i[2]));
      for (var w = 0, D = false, C = nv("fill" in r ? r.fill : (D = true, p.fill)), M = rv("stroke" in r ? r.stroke : !u && (!p.autoStroke || D) ? (w = Qh, p.stroke) : null), x = r.textShadowBlur > 0, I = r.width != null && (r.overflow === "truncate" || r.overflow === "break" || r.overflow === "breakAll"), A = o.calculatedLineHeight, E = 0; E < c.length; E++) {
        var R = this._getOrCreateChild(Xi), L = R.createStyle();
        R.useStyle(L), L.text = c[E], L.x = _, L.y = S, L.textAlign = d, L.textBaseline = "middle", L.opacity = r.opacity, L.strokeFirst = true, x && (L.shadowBlur = r.textShadowBlur || 0, L.shadowColor = r.textShadowColor || "transparent", L.shadowOffsetX = r.textShadowOffsetX || 0, L.shadowOffsetY = r.textShadowOffsetY || 0), L.stroke = M, L.fill = C, M && (L.lineWidth = r.lineWidth || w, L.lineDash = r.lineDash, L.lineDashOffset = r.lineDashOffset || 0), L.font = n, tv(L, r), S += v, I && R.setBoundingRect(new at(Si(L.x, h, L.textAlign), Tn(L.y, A, L.textBaseline), h, A));
      }
    }, t.prototype._updateRichTexts = function() {
      var r = this.style, n = av(r), i = F1(n, r), a = i.width, o = i.outerWidth, s = i.outerHeight, u = r.padding, l = r.x || 0, f = r.y || 0, h = this._defaultStyle, c = r.align || h.align, v = r.verticalAlign || h.verticalAlign;
      this.isTruncated = !!i.isTruncated;
      var p = Si(l, o, c), y = Tn(f, s, v), g = p, d = y;
      u && (g += u[3], d += u[0]);
      var m = g + a;
      eu(r) && this._renderBackground(r, r, p, y, o, s);
      for (var _ = !!r.backgroundColor, S = 0; S < i.lines.length; S++) {
        for (var T = i.lines[S], b = T.tokens, w = b.length, D = T.lineHeight, C = T.width, M = 0, x = g, I = m, A = w - 1, E = void 0; M < w && (E = b[M], !E.align || E.align === "left"); ) this._placeToken(E, r, D, d, x, "left", _), C -= E.width, x += E.width, M++;
        for (; A >= 0 && (E = b[A], E.align === "right"); ) this._placeToken(E, r, D, d, I, "right", _), C -= E.width, I -= E.width, A--;
        for (x += (a - (x - g) - (m - I) - C) / 2; M <= A; ) E = b[M], this._placeToken(E, r, D, d, x + E.width / 2, "center", _), x += E.width, M++;
        d += D;
      }
    }, t.prototype._placeToken = function(r, n, i, a, o, s, u) {
      var l = n.rich[r.styleName] || {};
      l.text = r.text;
      var f = r.verticalAlign, h = a + i / 2;
      f === "top" ? h = a + r.height / 2 : f === "bottom" && (h = a + i - r.height / 2);
      var c = !r.isLineHolder && eu(l);
      c && this._renderBackground(l, n, s === "right" ? o - r.width : s === "center" ? o - r.width / 2 : o, h - r.height / 2, r.width, r.height);
      var v = !!l.backgroundColor, p = r.textPadding;
      p && (o = iv(o, s, p), h -= r.height / 2 - p[0] - r.innerHeight / 2);
      var y = this._getOrCreateChild(Xi), g = y.createStyle();
      y.useStyle(g);
      var d = this._defaultStyle, m = false, _ = 0, S = nv("fill" in l ? l.fill : "fill" in n ? n.fill : (m = true, d.fill)), T = rv("stroke" in l ? l.stroke : "stroke" in n ? n.stroke : !v && !u && (!d.autoStroke || m) ? (_ = Qh, d.stroke) : null), b = l.textShadowBlur > 0 || n.textShadowBlur > 0;
      g.text = r.text, g.x = o, g.y = h, b && (g.shadowBlur = l.textShadowBlur || n.textShadowBlur || 0, g.shadowColor = l.textShadowColor || n.textShadowColor || "transparent", g.shadowOffsetX = l.textShadowOffsetX || n.textShadowOffsetX || 0, g.shadowOffsetY = l.textShadowOffsetY || n.textShadowOffsetY || 0), g.textAlign = s, g.textBaseline = "middle", g.font = r.font || pr, g.opacity = Ci(l.opacity, n.opacity, 1), tv(g, l), T && (g.lineWidth = Ci(l.lineWidth, n.lineWidth, _), g.lineDash = W(l.lineDash, n.lineDash), g.lineDashOffset = n.lineDashOffset || 0, g.stroke = T), S && (g.fill = S);
      var w = r.contentWidth, D = r.contentHeight;
      y.setBoundingRect(new at(Si(g.x, w, g.textAlign), Tn(g.y, D, g.textBaseline), w, D));
    }, t.prototype._renderBackground = function(r, n, i, a, o, s) {
      var u = r.backgroundColor, l = r.borderWidth, f = r.borderColor, h = u && u.image, c = u && !h, v = r.borderRadius, p = this, y, g;
      if (c || r.lineHeight || l && f) {
        y = this._getOrCreateChild(ne), y.useStyle(y.createStyle()), y.style.fill = null;
        var d = y.shape;
        d.x = i, d.y = a, d.width = o, d.height = s, d.r = v, y.dirtyShape();
      }
      if (c) {
        var m = y.style;
        m.fill = u || null, m.fillOpacity = W(r.fillOpacity, 1);
      } else if (h) {
        g = this._getOrCreateChild(Se), g.onload = function() {
          p.dirtyStyle();
        };
        var _ = g.style;
        _.image = u.image, _.x = i, _.y = a, _.width = o, _.height = s;
      }
      if (l && f) {
        var m = y.style;
        m.lineWidth = l, m.stroke = f, m.strokeOpacity = W(r.strokeOpacity, 1), m.lineDash = r.borderDash, m.lineDashOffset = r.borderDashOffset || 0, y.strokeContainThreshold = 0, y.hasFill() && y.hasStroke() && (m.strokeFirst = true, m.lineWidth *= 2);
      }
      var S = (y || g).style;
      S.shadowBlur = r.shadowBlur || 0, S.shadowColor = r.shadowColor || "transparent", S.shadowOffsetX = r.shadowOffsetX || 0, S.shadowOffsetY = r.shadowOffsetY || 0, S.opacity = Ci(r.opacity, n.opacity, 1);
    }, t.makeFont = function(r) {
      var n = "";
      return Hd(r) && (n = [
        r.fontStyle,
        r.fontWeight,
        Gd(r.fontSize),
        r.fontFamily || "sans-serif"
      ].join(" ")), n && Ie(n) || r.textFont || r.font;
    }, t;
  })(na);
  cS = {
    left: true,
    right: 1,
    center: 1
  };
  pS = {
    top: 1,
    bottom: 1,
    middle: 1
  };
  Jh = [
    "fontStyle",
    "fontWeight",
    "fontSize",
    "fontFamily"
  ];
  function Gd(e) {
    return typeof e == "string" && (e.indexOf("px") !== -1 || e.indexOf("rem") !== -1 || e.indexOf("em") !== -1) ? e : isNaN(+e) ? Ll + "px" : e + "px";
  }
  function tv(e, t) {
    for (var r = 0; r < Jh.length; r++) {
      var n = Jh[r], i = t[n];
      i != null && (e[n] = i);
    }
  }
  function Hd(e) {
    return e.fontSize != null || e.fontFamily || e.fontWeight;
  }
  function dS(e) {
    return ev(e), P(e.rich, ev), e;
  }
  function ev(e) {
    if (e) {
      e.font = Re.makeFont(e);
      var t = e.align;
      t === "middle" && (t = "center"), e.align = t == null || cS[t] ? t : "left";
      var r = e.verticalAlign;
      r === "center" && (r = "middle"), e.verticalAlign = r == null || pS[r] ? r : "top";
      var n = e.padding;
      n && (e.padding = Bl(e.padding));
    }
  }
  function rv(e, t) {
    return e == null || t <= 0 || e === "transparent" || e === "none" ? null : e.image || e.colorStops ? "#000" : e;
  }
  function nv(e) {
    return e == null || e === "none" ? null : e.image || e.colorStops ? "#000" : e;
  }
  function iv(e, t, r) {
    return t === "right" ? e - r[1] : t === "center" ? e + r[3] / 2 - r[1] / 2 : e + r[3];
  }
  function av(e) {
    var t = e.text;
    return t != null && (t += ""), t;
  }
  function eu(e) {
    return !!(e.backgroundColor || e.lineHeight || e.borderWidth && e.borderColor);
  }
  let gS, ov, sv, Ud, Ql, Jl, qo, Xo, Oe, uv, yS, mS, jr, ja, Ii, Qa, Ai;
  mt = Pt();
  gS = function(e, t, r, n) {
    if (n) {
      var i = mt(n);
      i.dataIndex = r, i.dataType = t, i.seriesIndex = e, i.ssrType = "chart", n.type === "group" && n.traverse(function(a) {
        var o = mt(a);
        o.seriesIndex = e, o.dataIndex = r, o.dataType = t, o.ssrType = "chart";
      });
    }
  };
  ov = 1;
  sv = {};
  Ud = Pt();
  Ql = Pt();
  Jl = 0;
  qo = 1;
  Xo = 2;
  Oe = [
    "emphasis",
    "blur",
    "select"
  ];
  uv = [
    "normal",
    "emphasis",
    "blur",
    "select"
  ];
  yS = 10;
  mS = 9;
  jr = "highlight";
  ja = "downplay";
  Ii = "select";
  Qa = "unselect";
  Ai = "toggleSelect";
  function cn(e) {
    return e != null && e !== "none";
  }
  function $o(e, t, r) {
    e.onHoverStateChange && (e.hoverState || 0) !== r && e.onHoverStateChange(t), e.hoverState = r;
  }
  function Wd(e) {
    $o(e, "emphasis", Xo);
  }
  function Yd(e) {
    e.hoverState === Xo && $o(e, "normal", Jl);
  }
  function tf(e) {
    $o(e, "blur", qo);
  }
  function qd(e) {
    e.hoverState === qo && $o(e, "normal", Jl);
  }
  function _S(e) {
    e.selected = true;
  }
  function SS(e) {
    e.selected = false;
  }
  function lv(e, t, r) {
    t(e, r);
  }
  function Ze(e, t, r) {
    lv(e, t, r), e.isGroup && e.traverse(function(n) {
      lv(n, t, r);
    });
  }
  function fv(e, t) {
    switch (t) {
      case "emphasis":
        e.hoverState = Xo;
        break;
      case "normal":
        e.hoverState = Jl;
        break;
      case "blur":
        e.hoverState = qo;
        break;
      case "select":
        e.selected = true;
    }
  }
  function bS(e, t, r, n) {
    for (var i = e.style, a = {}, o = 0; o < t.length; o++) {
      var s = t[o], u = i[s];
      a[s] = u ?? (n && n[s]);
    }
    for (var o = 0; o < e.animators.length; o++) {
      var l = e.animators[o];
      l.__fromStateTransition && l.__fromStateTransition.indexOf(r) < 0 && l.targetName === "style" && l.saveTo(a, t);
    }
    return a;
  }
  function wS(e, t, r, n) {
    var i = r && vt(r, "select") >= 0, a = false;
    if (e instanceof et) {
      var o = Ud(e), s = i && o.selectFill || o.normalFill, u = i && o.selectStroke || o.normalStroke;
      if (cn(s) || cn(u)) {
        n = n || {};
        var l = n.style || {};
        l.fill === "inherit" ? (a = true, n = O({}, n), l = O({}, l), l.fill = s) : !cn(l.fill) && cn(s) ? (a = true, n = O({}, n), l = O({}, l), l.fill = ho(s)) : !cn(l.stroke) && cn(u) && (a || (n = O({}, n), l = O({}, l)), l.stroke = ho(u)), n.style = l;
      }
    }
    if (n && n.z2 == null) {
      a || (n = O({}, n));
      var f = e.z2EmphasisLift;
      n.z2 = e.z2 + (f ?? yS);
    }
    return n;
  }
  function TS(e, t, r) {
    if (r && r.z2 == null) {
      r = O({}, r);
      var n = e.z2SelectLift;
      r.z2 = e.z2 + (n ?? mS);
    }
    return r;
  }
  function MS(e, t, r) {
    var n = vt(e.currentStates, t) >= 0, i = e.style.opacity, a = n ? null : bS(e, [
      "opacity"
    ], t, {
      opacity: 1
    });
    r = r || {};
    var o = r.style || {};
    return o.opacity == null && (r = O({}, r), o = O({
      opacity: n ? i : a.opacity * 0.1
    }, o), r.style = o), r;
  }
  function ru(e, t) {
    var r = this.states[e];
    if (this.style) {
      if (e === "emphasis") return wS(this, e, t, r);
      if (e === "blur") return MS(this, e, r);
      if (e === "select") return TS(this, e, r);
    }
    return r;
  }
  function CS(e) {
    e.stateProxy = ru;
    var t = e.getTextContent(), r = e.getTextGuideLine();
    t && (t.stateProxy = ru), r && (r.stateProxy = ru);
  }
  function hv(e, t) {
    !Kd(e, t) && !e.__highByOuter && Ze(e, Wd);
  }
  function vv(e, t) {
    !Kd(e, t) && !e.__highByOuter && Ze(e, Yd);
  }
  po = function(e, t) {
    e.__highByOuter |= 1 << (t || 0), Ze(e, Wd);
  };
  go = function(e, t) {
    !(e.__highByOuter &= ~(1 << (t || 0))) && Ze(e, Yd);
  };
  function DS(e) {
    Ze(e, tf);
  }
  function Xd(e) {
    Ze(e, qd);
  }
  function $d(e) {
    Ze(e, _S);
  }
  function Zd(e) {
    Ze(e, SS);
  }
  function Kd(e, t) {
    return e.__highDownSilentOnTouch && t.zrByTouch;
  }
  function jd(e) {
    var t = e.getModel(), r = [], n = [];
    t.eachComponent(function(i, a) {
      var o = Ql(a), s = i === "series", u = s ? e.getViewOfSeriesModel(a) : e.getViewOfComponentModel(a);
      !s && n.push(u), o.isBlured && (u.group.traverse(function(l) {
        qd(l);
      }), s && r.push(a)), o.isBlured = false;
    }), P(n, function(i) {
      i && i.toggleBlurSeries && i.toggleBlurSeries(r, false, t);
    });
  }
  function ol(e, t, r, n) {
    var i = n.getModel();
    r = r || "coordinateSystem";
    function a(l, f) {
      for (var h = 0; h < f.length; h++) {
        var c = l.getItemGraphicEl(f[h]);
        c && Xd(c);
      }
    }
    if (e != null && !(!t || t === "none")) {
      var o = i.getSeriesByIndex(e), s = o.coordinateSystem;
      s && s.master && (s = s.master);
      var u = [];
      i.eachSeries(function(l) {
        var f = o === l, h = l.coordinateSystem;
        h && h.master && (h = h.master);
        var c = h && s ? h === s : f;
        if (!(r === "series" && !f || r === "coordinateSystem" && !c || t === "series" && f)) {
          var v = n.getViewOfSeriesModel(l);
          if (v.group.traverse(function(g) {
            g.__highByOuter && f && t === "self" || tf(g);
          }), Rt(t)) a(l.getData(), t);
          else if (G(t)) for (var p = K(t), y = 0; y < p.length; y++) a(l.getData(p[y]), t[p[y]]);
          u.push(l), Ql(l).isBlured = true;
        }
      }), i.eachComponent(function(l, f) {
        if (l !== "series") {
          var h = n.getViewOfComponentModel(f);
          h && h.toggleBlurSeries && h.toggleBlurSeries(u, true, i);
        }
      });
    }
  }
  function sl(e, t, r) {
    if (!(e == null || t == null)) {
      var n = r.getModel().getComponent(e, t);
      if (n) {
        Ql(n).isBlured = true;
        var i = r.getViewOfComponentModel(n);
        !i || !i.focusBlurEnabled || i.group.traverse(function(a) {
          tf(a);
        });
      }
    }
  }
  function xS(e, t, r) {
    var n = e.seriesIndex, i = e.getData(t.dataType);
    if (i) {
      var a = kn(i, t);
      a = (B(a) ? a[0] : a) || 0;
      var o = i.getItemGraphicEl(a);
      if (!o) for (var s = i.count(), u = 0; !o && u < s; ) o = i.getItemGraphicEl(u++);
      if (o) {
        var l = mt(o);
        ol(n, l.focus, l.blurScope, r);
      } else {
        var f = e.get([
          "emphasis",
          "focus"
        ]), h = e.get([
          "emphasis",
          "blurScope"
        ]);
        f != null && ol(n, f, h, r);
      }
    }
  }
  function ef(e, t, r, n) {
    var i = {
      focusSelf: false,
      dispatchers: null
    };
    if (e == null || e === "series" || t == null || r == null) return i;
    var a = n.getModel().getComponent(e, t);
    if (!a) return i;
    var o = n.getViewOfComponentModel(a);
    if (!o || !o.findHighDownDispatchers) return i;
    for (var s = o.findHighDownDispatchers(r), u, l = 0; l < s.length; l++) if (mt(s[l]).focus === "self") {
      u = true;
      break;
    }
    return {
      focusSelf: u,
      dispatchers: s
    };
  }
  function PS(e, t, r) {
    var n = mt(e), i = ef(n.componentMainType, n.componentIndex, n.componentHighDownName, r), a = i.dispatchers, o = i.focusSelf;
    a ? (o && sl(n.componentMainType, n.componentIndex, r), P(a, function(s) {
      return hv(s, t);
    })) : (ol(n.seriesIndex, n.focus, n.blurScope, r), n.focus === "self" && sl(n.componentMainType, n.componentIndex, r), hv(e, t));
  }
  function IS(e, t, r) {
    jd(r);
    var n = mt(e), i = ef(n.componentMainType, n.componentIndex, n.componentHighDownName, r).dispatchers;
    i ? P(i, function(a) {
      return vv(a, t);
    }) : vv(e, t);
  }
  function AS(e, t, r) {
    if (fl(t)) {
      var n = t.dataType, i = e.getData(n), a = kn(i, t);
      B(a) || (a = [
        a
      ]), e[t.type === Ai ? "toggleSelect" : t.type === Ii ? "select" : "unselect"](a, n);
    }
  }
  function cv(e) {
    var t = e.getAllData();
    P(t, function(r) {
      var n = r.data, i = r.type;
      n.eachItemGraphicEl(function(a, o) {
        e.isSelected(o, i) ? $d(a) : Zd(a);
      });
    });
  }
  function ES(e) {
    var t = [];
    return e.eachSeries(function(r) {
      var n = r.getAllData();
      P(n, function(i) {
        i.data;
        var a = i.type, o = r.getSelectedDataIndices();
        if (o.length > 0) {
          var s = {
            dataIndex: o,
            seriesIndex: r.seriesIndex
          };
          a != null && (s.dataType = a), t.push(s);
        }
      });
    }), t;
  }
  Ei = function(e, t, r) {
    Qd(e, true), Ze(e, CS), RS(e, t, r);
  };
  function LS(e) {
    Qd(e, false);
  }
  function ul(e, t, r, n) {
    n ? LS(e) : Ei(e, t, r);
  }
  function RS(e, t, r) {
    var n = mt(e);
    t != null ? (n.focus = t, n.blurScope = r) : n.focus && (n.focus = null);
  }
  var pv = [
    "emphasis",
    "blur",
    "select"
  ], OS = {
    itemStyle: "getItemStyle",
    lineStyle: "getLineStyle",
    areaStyle: "getAreaStyle"
  };
  function dv(e, t, r, n) {
    r = r || "itemStyle";
    for (var i = 0; i < pv.length; i++) {
      var a = pv[i], o = t.getModel([
        a,
        r
      ]), s = e.ensureState(a);
      s.style = o[OS[r]]();
    }
  }
  function Qd(e, t) {
    var r = t === false, n = e;
    e.highDownSilentOnTouch && (n.__highDownSilentOnTouch = e.highDownSilentOnTouch), (!r || n.__highDownDispatcher) && (n.__highByOuter = n.__highByOuter || 0, n.__highDownDispatcher = !r);
  }
  function ll(e) {
    return !!(e && e.__highDownDispatcher);
  }
  function kS(e) {
    var t = sv[e];
    return t == null && ov <= 32 && (t = sv[e] = ov++), t;
  }
  function fl(e) {
    var t = e.type;
    return t === Ii || t === Qa || t === Ai;
  }
  function gv(e) {
    var t = e.type;
    return t === jr || t === ja;
  }
  function NS(e) {
    var t = Ud(e);
    t.normalFill = e.style.fill, t.normalStroke = e.style.stroke;
    var r = e.states.select || {};
    t.selectFill = r.style && r.style.fill || null, t.selectStroke = r.style && r.style.stroke || null;
  }
  var pn = yr.CMD, FS = [
    [],
    [],
    []
  ], yv = Math.sqrt, BS = Math.atan2;
  function zS(e, t) {
    if (t) {
      var r = e.data, n = e.len(), i, a, o, s, u, l, f = pn.M, h = pn.C, c = pn.L, v = pn.R, p = pn.A, y = pn.Q;
      for (o = 0, s = 0; o < n; ) {
        switch (i = r[o++], s = o, a = 0, i) {
          case f:
            a = 1;
            break;
          case c:
            a = 1;
            break;
          case h:
            a = 3;
            break;
          case y:
            a = 2;
            break;
          case p:
            var g = t[4], d = t[5], m = yv(t[0] * t[0] + t[1] * t[1]), _ = yv(t[2] * t[2] + t[3] * t[3]), S = BS(-t[1] / _, t[0] / m);
            r[o] *= m, r[o++] += g, r[o] *= _, r[o++] += d, r[o++] *= m, r[o++] *= _, r[o++] += S, r[o++] += S, o += 2, s = o;
            break;
          case v:
            l[0] = r[o++], l[1] = r[o++], Ye(l, l, t), r[s++] = l[0], r[s++] = l[1], l[0] += r[o++], l[1] += r[o++], Ye(l, l, t), r[s++] = l[0], r[s++] = l[1];
        }
        for (u = 0; u < a; u++) {
          var T = FS[u];
          T[0] = r[o++], T[1] = r[o++], Ye(T, T, t), r[s++] = T[0], r[s++] = T[1];
        }
      }
      e.increaseVersion();
    }
  }
  var nu = Math.sqrt, Ta = Math.sin, Ma = Math.cos, si = Math.PI;
  function mv(e) {
    return Math.sqrt(e[0] * e[0] + e[1] * e[1]);
  }
  function hl(e, t) {
    return (e[0] * t[0] + e[1] * t[1]) / (mv(e) * mv(t));
  }
  function _v(e, t) {
    return (e[0] * t[1] < e[1] * t[0] ? -1 : 1) * Math.acos(hl(e, t));
  }
  function Sv(e, t, r, n, i, a, o, s, u, l, f) {
    var h = u * (si / 180), c = Ma(h) * (e - r) / 2 + Ta(h) * (t - n) / 2, v = -1 * Ta(h) * (e - r) / 2 + Ma(h) * (t - n) / 2, p = c * c / (o * o) + v * v / (s * s);
    p > 1 && (o *= nu(p), s *= nu(p));
    var y = (i === a ? -1 : 1) * nu((o * o * (s * s) - o * o * (v * v) - s * s * (c * c)) / (o * o * (v * v) + s * s * (c * c))) || 0, g = y * o * v / s, d = y * -s * c / o, m = (e + r) / 2 + Ma(h) * g - Ta(h) * d, _ = (t + n) / 2 + Ta(h) * g + Ma(h) * d, S = _v([
      1,
      0
    ], [
      (c - g) / o,
      (v - d) / s
    ]), T = [
      (c - g) / o,
      (v - d) / s
    ], b = [
      (-1 * c - g) / o,
      (-1 * v - d) / s
    ], w = _v(T, b);
    if (hl(T, b) <= -1 && (w = si), hl(T, b) >= 1 && (w = 0), w < 0) {
      var D = Math.round(w / si * 1e6) / 1e6;
      w = si * 2 + D % 2 * si;
    }
    f.addData(l, m, _, o, s, S, w, h, a);
  }
  var VS = /([mlvhzcqtsa])([^mlvhzcqtsa]*)/ig, GS = /-?([0-9]*\.)?[0-9]+([eE]-?[0-9]+)?/g;
  function HS(e) {
    var t = new yr();
    if (!e) return t;
    var r = 0, n = 0, i = r, a = n, o, s = yr.CMD, u = e.match(VS);
    if (!u) return t;
    for (var l = 0; l < u.length; l++) {
      for (var f = u[l], h = f.charAt(0), c = void 0, v = f.match(GS) || [], p = v.length, y = 0; y < p; y++) v[y] = parseFloat(v[y]);
      for (var g = 0; g < p; ) {
        var d = void 0, m = void 0, _ = void 0, S = void 0, T = void 0, b = void 0, w = void 0, D = r, C = n, M = void 0, x = void 0;
        switch (h) {
          case "l":
            r += v[g++], n += v[g++], c = s.L, t.addData(c, r, n);
            break;
          case "L":
            r = v[g++], n = v[g++], c = s.L, t.addData(c, r, n);
            break;
          case "m":
            r += v[g++], n += v[g++], c = s.M, t.addData(c, r, n), i = r, a = n, h = "l";
            break;
          case "M":
            r = v[g++], n = v[g++], c = s.M, t.addData(c, r, n), i = r, a = n, h = "L";
            break;
          case "h":
            r += v[g++], c = s.L, t.addData(c, r, n);
            break;
          case "H":
            r = v[g++], c = s.L, t.addData(c, r, n);
            break;
          case "v":
            n += v[g++], c = s.L, t.addData(c, r, n);
            break;
          case "V":
            n = v[g++], c = s.L, t.addData(c, r, n);
            break;
          case "C":
            c = s.C, t.addData(c, v[g++], v[g++], v[g++], v[g++], v[g++], v[g++]), r = v[g - 2], n = v[g - 1];
            break;
          case "c":
            c = s.C, t.addData(c, v[g++] + r, v[g++] + n, v[g++] + r, v[g++] + n, v[g++] + r, v[g++] + n), r += v[g - 2], n += v[g - 1];
            break;
          case "S":
            d = r, m = n, M = t.len(), x = t.data, o === s.C && (d += r - x[M - 4], m += n - x[M - 3]), c = s.C, D = v[g++], C = v[g++], r = v[g++], n = v[g++], t.addData(c, d, m, D, C, r, n);
            break;
          case "s":
            d = r, m = n, M = t.len(), x = t.data, o === s.C && (d += r - x[M - 4], m += n - x[M - 3]), c = s.C, D = r + v[g++], C = n + v[g++], r += v[g++], n += v[g++], t.addData(c, d, m, D, C, r, n);
            break;
          case "Q":
            D = v[g++], C = v[g++], r = v[g++], n = v[g++], c = s.Q, t.addData(c, D, C, r, n);
            break;
          case "q":
            D = v[g++] + r, C = v[g++] + n, r += v[g++], n += v[g++], c = s.Q, t.addData(c, D, C, r, n);
            break;
          case "T":
            d = r, m = n, M = t.len(), x = t.data, o === s.Q && (d += r - x[M - 4], m += n - x[M - 3]), r = v[g++], n = v[g++], c = s.Q, t.addData(c, d, m, r, n);
            break;
          case "t":
            d = r, m = n, M = t.len(), x = t.data, o === s.Q && (d += r - x[M - 4], m += n - x[M - 3]), r += v[g++], n += v[g++], c = s.Q, t.addData(c, d, m, r, n);
            break;
          case "A":
            _ = v[g++], S = v[g++], T = v[g++], b = v[g++], w = v[g++], D = r, C = n, r = v[g++], n = v[g++], c = s.A, Sv(D, C, r, n, b, w, _, S, T, c, t);
            break;
          case "a":
            _ = v[g++], S = v[g++], T = v[g++], b = v[g++], w = v[g++], D = r, C = n, r += v[g++], n += v[g++], c = s.A, Sv(D, C, r, n, b, w, _, S, T, c, t);
            break;
        }
      }
      (h === "z" || h === "Z") && (c = s.Z, t.addData(c), r = i, n = a), o = c;
    }
    return t.toStatic(), t;
  }
  var Jd = (function(e) {
    ot(t, e);
    function t() {
      return e !== null && e.apply(this, arguments) || this;
    }
    return t.prototype.applyTransform = function(r) {
    }, t;
  })(et);
  function tg(e) {
    return e.setData != null;
  }
  function eg(e, t) {
    var r = HS(e), n = O({}, t);
    return n.buildPath = function(i) {
      if (tg(i)) {
        i.setData(r.data);
        var a = i.getContext();
        a && i.rebuildPath(a, 1);
      } else {
        var a = i;
        r.rebuildPath(a, 1);
      }
    }, n.applyTransform = function(i) {
      zS(r, i), this.dirtyShape();
    }, n;
  }
  function US(e, t) {
    return new Jd(eg(e, t));
  }
  function WS(e, t) {
    var r = eg(e, t), n = (function(i) {
      ot(a, i);
      function a(o) {
        var s = i.call(this, o) || this;
        return s.applyTransform = r.applyTransform, s.buildPath = r.buildPath, s;
      }
      return a;
    })(Jd);
    return n;
  }
  function YS(e, t) {
    for (var r = [], n = e.length, i = 0; i < n; i++) {
      var a = e[i];
      r.push(a.getUpdatedPathProxy(true));
    }
    var o = new et(t);
    return o.createPathProxy(), o.buildPath = function(s) {
      if (tg(s)) {
        s.appendPath(r);
        var u = s.getContext();
        u && s.rebuildPath(u, 1);
      }
    }, o;
  }
  var qS = /* @__PURE__ */ (function() {
    function e() {
      this.cx = 0, this.cy = 0, this.r = 0;
    }
    return e;
  })(), ia = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultShape = function() {
      return new qS();
    }, t.prototype.buildPath = function(r, n) {
      r.moveTo(n.cx + n.r, n.cy), r.arc(n.cx, n.cy, n.r, 0, Math.PI * 2);
    }, t;
  })(et);
  ia.prototype.type = "circle";
  var XS = /* @__PURE__ */ (function() {
    function e() {
      this.cx = 0, this.cy = 0, this.rx = 0, this.ry = 0;
    }
    return e;
  })(), Zo = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultShape = function() {
      return new XS();
    }, t.prototype.buildPath = function(r, n) {
      var i = 0.5522848, a = n.cx, o = n.cy, s = n.rx, u = n.ry, l = s * i, f = u * i;
      r.moveTo(a - s, o), r.bezierCurveTo(a - s, o - f, a - l, o - u, a, o - u), r.bezierCurveTo(a + l, o - u, a + s, o - f, a + s, o), r.bezierCurveTo(a + s, o + f, a + l, o + u, a, o + u), r.bezierCurveTo(a - l, o + u, a - s, o + f, a - s, o), r.closePath();
    }, t;
  })(et);
  Zo.prototype.type = "ellipse";
  var rg = Math.PI, iu = rg * 2, Rr = Math.sin, dn = Math.cos, $S = Math.acos, Mt = Math.atan2, bv = Math.abs, Li = Math.sqrt, bi = Math.max, Me = Math.min, ce = 1e-4;
  function ZS(e, t, r, n, i, a, o, s) {
    var u = r - e, l = n - t, f = o - i, h = s - a, c = h * u - f * l;
    if (!(c * c < ce)) return c = (f * (t - a) - h * (e - i)) / c, [
      e + c * u,
      t + c * l
    ];
  }
  function Ca(e, t, r, n, i, a, o) {
    var s = e - r, u = t - n, l = (o ? a : -a) / Li(s * s + u * u), f = l * u, h = -l * s, c = e + f, v = t + h, p = r + f, y = n + h, g = (c + p) / 2, d = (v + y) / 2, m = p - c, _ = y - v, S = m * m + _ * _, T = i - a, b = c * y - p * v, w = (_ < 0 ? -1 : 1) * Li(bi(0, T * T * S - b * b)), D = (b * _ - m * w) / S, C = (-b * m - _ * w) / S, M = (b * _ + m * w) / S, x = (-b * m + _ * w) / S, I = D - g, A = C - d, E = M - g, R = x - d;
    return I * I + A * A > E * E + R * R && (D = M, C = x), {
      cx: D,
      cy: C,
      x0: -f,
      y0: -h,
      x1: D * (i / T - 1),
      y1: C * (i / T - 1)
    };
  }
  function KS(e) {
    var t;
    if (B(e)) {
      var r = e.length;
      if (!r) return e;
      r === 1 ? t = [
        e[0],
        e[0],
        0,
        0
      ] : r === 2 ? t = [
        e[0],
        e[0],
        e[1],
        e[1]
      ] : r === 3 ? t = e.concat(e[2]) : t = e;
    } else t = [
      e,
      e,
      e,
      e
    ];
    return t;
  }
  function jS(e, t) {
    var r, n = bi(t.r, 0), i = bi(t.r0 || 0, 0), a = n > 0, o = i > 0;
    if (!(!a && !o)) {
      if (a || (n = i, i = 0), i > n) {
        var s = n;
        n = i, i = s;
      }
      var u = t.startAngle, l = t.endAngle;
      if (!(isNaN(u) || isNaN(l))) {
        var f = t.cx, h = t.cy, c = !!t.clockwise, v = bv(l - u), p = v > iu && v % iu;
        if (p > ce && (v = p), !(n > ce)) e.moveTo(f, h);
        else if (v > iu - ce) e.moveTo(f + n * dn(u), h + n * Rr(u)), e.arc(f, h, n, u, l, !c), i > ce && (e.moveTo(f + i * dn(l), h + i * Rr(l)), e.arc(f, h, i, l, u, c));
        else {
          var y = void 0, g = void 0, d = void 0, m = void 0, _ = void 0, S = void 0, T = void 0, b = void 0, w = void 0, D = void 0, C = void 0, M = void 0, x = void 0, I = void 0, A = void 0, E = void 0, R = n * dn(u), L = n * Rr(u), z = i * dn(l), k = i * Rr(l), N = v > ce;
          if (N) {
            var U = t.cornerRadius;
            U && (r = KS(U), y = r[0], g = r[1], d = r[2], m = r[3]);
            var J = bv(n - i) / 2;
            if (_ = Me(J, d), S = Me(J, m), T = Me(J, y), b = Me(J, g), C = w = bi(_, S), M = D = bi(T, b), (w > ce || D > ce) && (x = n * dn(l), I = n * Rr(l), A = i * dn(u), E = i * Rr(u), v < rg)) {
              var $ = ZS(R, L, A, E, x, I, z, k);
              if ($) {
                var rt = R - $[0], tt = L - $[1], st = x - $[0], Gt = I - $[1], Fe = 1 / Rr($S((rt * st + tt * Gt) / (Li(rt * rt + tt * tt) * Li(st * st + Gt * Gt))) / 2), le = Li($[0] * $[0] + $[1] * $[1]);
                C = Me(w, (n - le) / (Fe + 1)), M = Me(D, (i - le) / (Fe - 1));
              }
            }
          }
          if (!N) e.moveTo(f + R, h + L);
          else if (C > ce) {
            var St = Me(d, C), dt = Me(m, C), H = Ca(A, E, R, L, n, St, c), X = Ca(x, I, z, k, n, dt, c);
            e.moveTo(f + H.cx + H.x0, h + H.cy + H.y0), C < w && St === dt ? e.arc(f + H.cx, h + H.cy, C, Mt(H.y0, H.x0), Mt(X.y0, X.x0), !c) : (St > 0 && e.arc(f + H.cx, h + H.cy, St, Mt(H.y0, H.x0), Mt(H.y1, H.x1), !c), e.arc(f, h, n, Mt(H.cy + H.y1, H.cx + H.x1), Mt(X.cy + X.y1, X.cx + X.x1), !c), dt > 0 && e.arc(f + X.cx, h + X.cy, dt, Mt(X.y1, X.x1), Mt(X.y0, X.x0), !c));
          } else e.moveTo(f + R, h + L), e.arc(f, h, n, u, l, !c);
          if (!(i > ce) || !N) e.lineTo(f + z, h + k);
          else if (M > ce) {
            var St = Me(y, M), dt = Me(g, M), H = Ca(z, k, x, I, i, -dt, c), X = Ca(R, L, A, E, i, -St, c);
            e.lineTo(f + H.cx + H.x0, h + H.cy + H.y0), M < D && St === dt ? e.arc(f + H.cx, h + H.cy, M, Mt(H.y0, H.x0), Mt(X.y0, X.x0), !c) : (dt > 0 && e.arc(f + H.cx, h + H.cy, dt, Mt(H.y0, H.x0), Mt(H.y1, H.x1), !c), e.arc(f, h, i, Mt(H.cy + H.y1, H.cx + H.x1), Mt(X.cy + X.y1, X.cx + X.x1), c), St > 0 && e.arc(f + X.cx, h + X.cy, St, Mt(X.y1, X.x1), Mt(X.y0, X.x0), !c));
          } else e.lineTo(f + z, h + k), e.arc(f, h, i, l, u, c);
        }
        e.closePath();
      }
    }
  }
  var QS = /* @__PURE__ */ (function() {
    function e() {
      this.cx = 0, this.cy = 0, this.r0 = 0, this.r = 0, this.startAngle = 0, this.endAngle = Math.PI * 2, this.clockwise = true, this.cornerRadius = 0;
    }
    return e;
  })(), aa = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultShape = function() {
      return new QS();
    }, t.prototype.buildPath = function(r, n) {
      jS(r, n);
    }, t.prototype.isZeroArea = function() {
      return this.shape.startAngle === this.shape.endAngle || this.shape.r === this.shape.r0;
    }, t;
  })(et);
  aa.prototype.type = "sector";
  var JS = /* @__PURE__ */ (function() {
    function e() {
      this.cx = 0, this.cy = 0, this.r = 0, this.r0 = 0;
    }
    return e;
  })(), Ko = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultShape = function() {
      return new JS();
    }, t.prototype.buildPath = function(r, n) {
      var i = n.cx, a = n.cy, o = Math.PI * 2;
      r.moveTo(i + n.r, a), r.arc(i, a, n.r, 0, o, false), r.moveTo(i + n.r0, a), r.arc(i, a, n.r0, 0, o, true);
    }, t;
  })(et);
  Ko.prototype.type = "ring";
  function tb(e, t, r, n) {
    var i = [], a = [], o = [], s = [], u, l, f, h;
    if (n) {
      f = [
        1 / 0,
        1 / 0
      ], h = [
        -1 / 0,
        -1 / 0
      ];
      for (var c = 0, v = e.length; c < v; c++) or(f, f, e[c]), sr(h, h, e[c]);
      or(f, f, n[0]), sr(h, h, n[1]);
    }
    for (var c = 0, v = e.length; c < v; c++) {
      var p = e[c];
      if (r) u = e[c ? c - 1 : v - 1], l = e[(c + 1) % v];
      else if (c === 0 || c === v - 1) {
        i.push(Bp(e[c]));
        continue;
      } else u = e[c - 1], l = e[c + 1];
      zp(a, l, u), Wa(a, a, t);
      var y = oo(p, u), g = oo(p, l), d = y + g;
      d !== 0 && (y /= d, g /= d), Wa(o, a, -y), Wa(s, a, g);
      var m = Fu([], p, o), _ = Fu([], p, s);
      n && (sr(m, m, f), or(m, m, h), sr(_, _, f), or(_, _, h)), i.push(m), i.push(_);
    }
    return r && i.push(i.shift()), i;
  }
  function ng(e, t, r) {
    var n = t.smooth, i = t.points;
    if (i && i.length >= 2) {
      if (n) {
        var a = tb(i, n, r, t.smoothConstraint);
        e.moveTo(i[0][0], i[0][1]);
        for (var o = i.length, s = 0; s < (r ? o : o - 1); s++) {
          var u = a[s * 2], l = a[s * 2 + 1], f = i[(s + 1) % o];
          e.bezierCurveTo(u[0], u[1], l[0], l[1], f[0], f[1]);
        }
      } else {
        e.moveTo(i[0][0], i[0][1]);
        for (var s = 1, h = i.length; s < h; s++) e.lineTo(i[s][0], i[s][1]);
      }
      r && e.closePath();
    }
  }
  let eb;
  eb = /* @__PURE__ */ (function() {
    function e() {
      this.points = null, this.smooth = 0, this.smoothConstraint = null;
    }
    return e;
  })();
  jo = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultShape = function() {
      return new eb();
    }, t.prototype.buildPath = function(r, n) {
      ng(r, n, true);
    }, t;
  })(et);
  jo.prototype.type = "polygon";
  let rb;
  rb = /* @__PURE__ */ (function() {
    function e() {
      this.points = null, this.percent = 1, this.smooth = 0, this.smoothConstraint = null;
    }
    return e;
  })();
  Qo = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      };
    }, t.prototype.getDefaultShape = function() {
      return new rb();
    }, t.prototype.buildPath = function(r, n) {
      ng(r, n, false);
    }, t;
  })(et);
  Qo.prototype.type = "polyline";
  let nb, ib;
  nb = {};
  ib = /* @__PURE__ */ (function() {
    function e() {
      this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.percent = 1;
    }
    return e;
  })();
  en = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      };
    }, t.prototype.getDefaultShape = function() {
      return new ib();
    }, t.prototype.buildPath = function(r, n) {
      var i, a, o, s;
      if (this.subPixelOptimize) {
        var u = zd(nb, n, this.style);
        i = u.x1, a = u.y1, o = u.x2, s = u.y2;
      } else i = n.x1, a = n.y1, o = n.x2, s = n.y2;
      var l = n.percent;
      l !== 0 && (r.moveTo(i, a), l < 1 && (o = i * (1 - l) + o * l, s = a * (1 - l) + s * l), r.lineTo(o, s));
    }, t.prototype.pointAt = function(r) {
      var n = this.shape;
      return [
        n.x1 * (1 - r) + n.x2 * r,
        n.y1 * (1 - r) + n.y2 * r
      ];
    }, t;
  })(et);
  en.prototype.type = "line";
  var kt = [], ab = /* @__PURE__ */ (function() {
    function e() {
      this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.cpx1 = 0, this.cpy1 = 0, this.percent = 1;
    }
    return e;
  })();
  function wv(e, t, r) {
    var n = e.cpx2, i = e.cpy2;
    return n != null || i != null ? [
      (r ? Th : Tt)(e.x1, e.cpx1, e.cpx2, e.x2, t),
      (r ? Th : Tt)(e.y1, e.cpy1, e.cpy2, e.y2, t)
    ] : [
      (r ? Mh : Ft)(e.x1, e.cpx1, e.x2, t),
      (r ? Mh : Ft)(e.y1, e.cpy1, e.y2, t)
    ];
  }
  var Jo = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      };
    }, t.prototype.getDefaultShape = function() {
      return new ab();
    }, t.prototype.buildPath = function(r, n) {
      var i = n.x1, a = n.y1, o = n.x2, s = n.y2, u = n.cpx1, l = n.cpy1, f = n.cpx2, h = n.cpy2, c = n.percent;
      c !== 0 && (r.moveTo(i, a), f == null || h == null ? (c < 1 && (fo(i, u, o, c, kt), u = kt[1], o = kt[2], fo(a, l, s, c, kt), l = kt[1], s = kt[2]), r.quadraticCurveTo(u, l, o, s)) : (c < 1 && (lo(i, u, f, o, c, kt), u = kt[1], f = kt[2], o = kt[3], lo(a, l, h, s, c, kt), l = kt[1], h = kt[2], s = kt[3]), r.bezierCurveTo(u, l, f, h, o, s)));
    }, t.prototype.pointAt = function(r) {
      return wv(this.shape, r, false);
    }, t.prototype.tangentAt = function(r) {
      var n = wv(this.shape, r, true);
      return Vp(n, n);
    }, t;
  })(et);
  Jo.prototype.type = "bezier-curve";
  var ob = /* @__PURE__ */ (function() {
    function e() {
      this.cx = 0, this.cy = 0, this.r = 0, this.startAngle = 0, this.endAngle = Math.PI * 2, this.clockwise = true;
    }
    return e;
  })(), oa = (function(e) {
    ot(t, e);
    function t(r) {
      return e.call(this, r) || this;
    }
    return t.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      };
    }, t.prototype.getDefaultShape = function() {
      return new ob();
    }, t.prototype.buildPath = function(r, n) {
      var i = n.cx, a = n.cy, o = Math.max(n.r, 0), s = n.startAngle, u = n.endAngle, l = n.clockwise, f = Math.cos(s), h = Math.sin(s);
      r.moveTo(f * o + i, h * o + a), r.arc(i, a, o, s, u, !l);
    }, t;
  })(et);
  oa.prototype.type = "arc";
  let rf, ig, nf, ag, Or, kr, Da, xa, ub, og, lb;
  rf = (function(e) {
    ot(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.type = "compound", r;
    }
    return t.prototype._updatePathDirty = function() {
      for (var r = this.shape.paths, n = this.shapeChanged(), i = 0; i < r.length; i++) n = n || r[i].shapeChanged();
      n && this.dirtyShape();
    }, t.prototype.beforeBrush = function() {
      this._updatePathDirty();
      for (var r = this.shape.paths || [], n = this.getGlobalScale(), i = 0; i < r.length; i++) r[i].path || r[i].createPathProxy(), r[i].path.setScale(n[0], n[1], r[i].segmentIgnoreThreshold);
    }, t.prototype.buildPath = function(r, n) {
      for (var i = n.paths || [], a = 0; a < i.length; a++) i[a].buildPath(r, i[a].shape, true);
    }, t.prototype.afterBrush = function() {
      for (var r = this.shape.paths || [], n = 0; n < r.length; n++) r[n].pathUpdated();
    }, t.prototype.getBoundingRect = function() {
      return this._updatePathDirty.call(this), et.prototype.getBoundingRect.call(this);
    }, t;
  })(et);
  ig = (function() {
    function e(t) {
      this.colorStops = t || [];
    }
    return e.prototype.addColorStop = function(t, r) {
      this.colorStops.push({
        offset: t,
        color: r
      });
    }, e;
  })();
  nf = (function(e) {
    ot(t, e);
    function t(r, n, i, a, o, s) {
      var u = e.call(this, o) || this;
      return u.x = r ?? 0, u.y = n ?? 0, u.x2 = i ?? 1, u.y2 = a ?? 0, u.type = "linear", u.global = s || false, u;
    }
    return t;
  })(ig);
  ag = (function(e) {
    ot(t, e);
    function t(r, n, i, a, o) {
      var s = e.call(this, a) || this;
      return s.x = r ?? 0.5, s.y = n ?? 0.5, s.r = i ?? 0.5, s.type = "radial", s.global = o || false, s;
    }
    return t;
  })(ig);
  Or = [
    0,
    0
  ];
  kr = [
    0,
    0
  ];
  Da = new it();
  xa = new it();
  sb = (function() {
    function e(t, r) {
      this._corners = [], this._axes = [], this._origin = [
        0,
        0
      ];
      for (var n = 0; n < 4; n++) this._corners[n] = new it();
      for (var n = 0; n < 2; n++) this._axes[n] = new it();
      t && this.fromBoundingRect(t, r);
    }
    return e.prototype.fromBoundingRect = function(t, r) {
      var n = this._corners, i = this._axes, a = t.x, o = t.y, s = a + t.width, u = o + t.height;
      if (n[0].set(a, o), n[1].set(s, o), n[2].set(s, u), n[3].set(a, u), r) for (var l = 0; l < 4; l++) n[l].transform(r);
      it.sub(i[0], n[1], n[0]), it.sub(i[1], n[3], n[0]), i[0].normalize(), i[1].normalize();
      for (var l = 0; l < 2; l++) this._origin[l] = i[l].dot(n[0]);
    }, e.prototype.intersect = function(t, r) {
      var n = true, i = !r;
      return Da.set(1 / 0, 1 / 0), xa.set(0, 0), !this._intersectCheckOneSide(this, t, Da, xa, i, 1) && (n = false, i) || !this._intersectCheckOneSide(t, this, Da, xa, i, -1) && (n = false, i) || i || it.copy(r, n ? Da : xa), n;
    }, e.prototype._intersectCheckOneSide = function(t, r, n, i, a, o) {
      for (var s = true, u = 0; u < 2; u++) {
        var l = this._axes[u];
        if (this._getProjMinMaxOnAxis(u, t._corners, Or), this._getProjMinMaxOnAxis(u, r._corners, kr), Or[1] < kr[0] || Or[0] > kr[1]) {
          if (s = false, a) return s;
          var f = Math.abs(kr[0] - Or[1]), h = Math.abs(Or[0] - kr[1]);
          Math.min(f, h) > i.len() && (f < h ? it.scale(i, l, -f * o) : it.scale(i, l, h * o));
        } else if (n) {
          var f = Math.abs(kr[0] - Or[1]), h = Math.abs(Or[0] - kr[1]);
          Math.min(f, h) < n.len() && (f < h ? it.scale(n, l, f * o) : it.scale(n, l, -h * o));
        }
      }
      return s;
    }, e.prototype._getProjMinMaxOnAxis = function(t, r, n) {
      for (var i = this._axes[t], a = this._origin, o = r[0].dot(i) + a[t], s = o, u = o, l = 1; l < r.length; l++) {
        var f = r[l].dot(i) + a[t];
        s = Math.min(f, s), u = Math.max(f, u);
      }
      n[0] = s, n[1] = u;
    }, e;
  })();
  ub = [];
  og = (function(e) {
    ot(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.notClear = true, r.incremental = true, r._displayables = [], r._temporaryDisplayables = [], r._cursor = 0, r;
    }
    return t.prototype.traverse = function(r, n) {
      r.call(n, this);
    }, t.prototype.useStyle = function() {
      this.style = {};
    }, t.prototype.getCursor = function() {
      return this._cursor;
    }, t.prototype.innerAfterBrush = function() {
      this._cursor = this._displayables.length;
    }, t.prototype.clearDisplaybles = function() {
      this._displayables = [], this._temporaryDisplayables = [], this._cursor = 0, this.markRedraw(), this.notClear = false;
    }, t.prototype.clearTemporalDisplayables = function() {
      this._temporaryDisplayables = [];
    }, t.prototype.addDisplayable = function(r, n) {
      n ? this._temporaryDisplayables.push(r) : this._displayables.push(r), this.markRedraw();
    }, t.prototype.addDisplayables = function(r, n) {
      n = n || false;
      for (var i = 0; i < r.length; i++) this.addDisplayable(r[i], n);
    }, t.prototype.getDisplayables = function() {
      return this._displayables;
    }, t.prototype.getTemporalDisplayables = function() {
      return this._temporaryDisplayables;
    }, t.prototype.eachPendingDisplayable = function(r) {
      for (var n = this._cursor; n < this._displayables.length; n++) r && r(this._displayables[n]);
      for (var n = 0; n < this._temporaryDisplayables.length; n++) r && r(this._temporaryDisplayables[n]);
    }, t.prototype.update = function() {
      this.updateTransform();
      for (var r = this._cursor; r < this._displayables.length; r++) {
        var n = this._displayables[r];
        n.parent = this, n.update(), n.parent = null;
      }
      for (var r = 0; r < this._temporaryDisplayables.length; r++) {
        var n = this._temporaryDisplayables[r];
        n.parent = this, n.update(), n.parent = null;
      }
    }, t.prototype.getBoundingRect = function() {
      if (!this._rect) {
        for (var r = new at(1 / 0, 1 / 0, -1 / 0, -1 / 0), n = 0; n < this._displayables.length; n++) {
          var i = this._displayables[n], a = i.getBoundingRect().clone();
          i.needLocalTransform() && a.applyTransform(i.getLocalTransform(ub)), r.union(a);
        }
        this._rect = r;
      }
      return this._rect;
    }, t.prototype.contain = function(r, n) {
      var i = this.transformCoordToLocal(r, n), a = this.getBoundingRect();
      if (a.contain(i[0], i[1])) for (var o = 0; o < this._displayables.length; o++) {
        var s = this._displayables[o];
        if (s.contain(r, n)) return true;
      }
      return false;
    }, t;
  })(na);
  lb = Pt();
  function fb(e, t, r, n, i) {
    var a;
    if (t && t.ecModel) {
      var o = t.ecModel.getUpdatePayload();
      a = o && o.animation;
    }
    var s = t && t.isAnimationEnabled(), u = e === "update";
    if (s) {
      var l = void 0, f = void 0, h = void 0;
      n ? (l = W(n.duration, 200), f = W(n.easing, "cubicOut"), h = 0) : (l = t.getShallow(u ? "animationDurationUpdate" : "animationDuration"), f = t.getShallow(u ? "animationEasingUpdate" : "animationEasing"), h = t.getShallow(u ? "animationDelayUpdate" : "animationDelay")), a && (a.duration != null && (l = a.duration), a.easing != null && (f = a.easing), a.delay != null && (h = a.delay)), Y(h) && (h = h(r, i)), Y(l) && (l = l(r));
      var c = {
        duration: l || 0,
        delay: h,
        easing: f
      };
      return c;
    } else return null;
  }
  function af(e, t, r, n, i, a, o) {
    var s = false, u;
    Y(i) ? (o = a, a = i, i = null) : G(i) && (a = i.cb, o = i.during, s = i.isFrom, u = i.removeOpt, i = i.dataIndex);
    var l = e === "leave";
    l || t.stopAnimation("leave");
    var f = fb(e, n, i, l ? u || {} : null, n && n.getAnimationDelayParams ? n.getAnimationDelayParams(t, i) : null);
    if (f && f.duration > 0) {
      var h = f.duration, c = f.delay, v = f.easing, p = {
        duration: h,
        delay: c || 0,
        easing: v,
        done: a,
        force: !!a || !!o,
        setToFinal: !l,
        scope: e,
        during: o
      };
      s ? t.animateFrom(r, p) : t.animateTo(r, p);
    } else t.stopAnimation(), !s && t.attr(r), o && o(1), a && a();
  }
  rn = function(e, t, r, n, i, a) {
    af("update", e, t, r, n, i, a);
  };
  function Hn(e, t, r, n, i, a) {
    af("enter", e, t, r, n, i, a);
  }
  function Ri(e) {
    if (!e.__zr) return true;
    for (var t = 0; t < e.animators.length; t++) {
      var r = e.animators[t];
      if (r.scope === "leave") return true;
    }
    return false;
  }
  function yo(e, t, r, n, i, a) {
    Ri(e) || af("leave", e, t, r, n, i, a);
  }
  function Tv(e, t, r, n) {
    e.removeTextContent(), e.removeTextGuideLine(), yo(e, {
      style: {
        opacity: 0
      }
    }, t, r, n);
  }
  function hb(e, t, r) {
    function n() {
      e.parent && e.parent.remove(e);
    }
    e.isGroup ? e.traverse(function(i) {
      i.isGroup || Tv(i, t, r, n);
    }) : Tv(e, t, r, n);
  }
  function vb(e) {
    lb(e).oldStyle = e.style;
  }
  var mo = Math.max, _o = Math.min, vl = {};
  function sg(e) {
    return et.extend(e);
  }
  var cb = WS;
  function ug(e, t) {
    return cb(e, t);
  }
  function se(e, t) {
    vl[e] = t;
  }
  function lg(e) {
    if (vl.hasOwnProperty(e)) return vl[e];
  }
  function ts(e, t, r, n) {
    var i = US(e, t);
    return r && (n === "center" && (r = fg(r, i.getBoundingRect())), sf(i, r)), i;
  }
  function of(e, t, r) {
    var n = new Se({
      style: {
        image: e,
        x: t.x,
        y: t.y,
        width: t.width,
        height: t.height
      },
      onload: function(i) {
        if (r === "center") {
          var a = {
            width: i.width,
            height: i.height
          };
          n.setStyle(fg(t, a));
        }
      }
    });
    return n;
  }
  function fg(e, t) {
    var r = t.width / t.height, n = e.height * r, i;
    n <= e.width ? i = e.height : (n = e.width, i = n / r);
    var a = e.x + e.width / 2, o = e.y + e.height / 2;
    return {
      x: a - n / 2,
      y: o - i / 2,
      width: n,
      height: i
    };
  }
  var hg = YS;
  function sf(e, t) {
    if (e.applyTransform) {
      var r = e.getBoundingRect(), n = r.calculateTransform(t);
      e.applyTransform(n);
    }
  }
  pb = function(e, t) {
    return zd(e, e, {
      lineWidth: t
    }), e;
  };
  function db(e) {
    return Vd(e.shape, e.shape, e.style), e;
  }
  var gb = qr;
  vg = function(e, t) {
    for (var r = No([]); e && e !== t; ) In(r, e.getLocalTransform(), r), e = e.parent;
    return r;
  };
  uf = function(e, t, r) {
    return t && !Rt(t) && (t = $l.getLocalTransform(t)), r && (t = Fo([], t)), Ye([], e, t);
  };
  yb = function(e, t, r) {
    var n = t[4] === 0 || t[5] === 0 || t[0] === 0 ? 1 : Math.abs(2 * t[4] / t[0]), i = t[4] === 0 || t[5] === 0 || t[2] === 0 ? 1 : Math.abs(2 * t[4] / t[2]), a = [
      e === "left" ? -n : e === "right" ? n : 0,
      e === "top" ? -i : e === "bottom" ? i : 0
    ];
    return a = uf(a, t, r), Math.abs(a[0]) > Math.abs(a[1]) ? a[0] > 0 ? "right" : "left" : a[1] > 0 ? "bottom" : "top";
  };
  function Mv(e) {
    return !e.isGroup;
  }
  function mb(e) {
    return e.shape != null;
  }
  _b = function(e, t, r) {
    if (!e || !t) return;
    function n(o) {
      var s = {};
      return o.traverse(function(u) {
        Mv(u) && u.anid && (s[u.anid] = u);
      }), s;
    }
    function i(o) {
      var s = {
        x: o.x,
        y: o.y,
        rotation: o.rotation
      };
      return mb(o) && (s.shape = O({}, o.shape)), s;
    }
    var a = n(e);
    t.traverse(function(o) {
      if (Mv(o) && o.anid) {
        var s = a[o.anid];
        if (s) {
          var u = i(o);
          o.attr(i(s)), rn(o, u, r, mt(o).dataIndex);
        }
      }
    });
  };
  cg = function(e, t) {
    return F(e, function(r) {
      var n = r[0];
      n = mo(n, t.x), n = _o(n, t.x + t.width);
      var i = r[1];
      return i = mo(i, t.y), i = _o(i, t.y + t.height), [
        n,
        i
      ];
    });
  };
  function pg(e, t) {
    var r = mo(e.x, t.x), n = _o(e.x + e.width, t.x + t.width), i = mo(e.y, t.y), a = _o(e.y + e.height, t.y + t.height);
    if (n >= r && a >= i) return {
      x: r,
      y: i,
      width: n - r,
      height: a - i
    };
  }
  lf = function(e, t, r) {
    var n = O({
      rectHover: true
    }, t), i = n.style = {
      strokeNoScale: true
    };
    if (r = r || {
      x: -1,
      y: -1,
      width: 2,
      height: 2
    }, e) return e.indexOf("image://") === 0 ? (i.image = e.slice(8), ht(i, r), new Se(n)) : ts(e.replace("path://", ""), n, r, "center");
  };
  function Sb(e, t, r, n, i) {
    for (var a = 0, o = i[i.length - 1]; a < i.length; a++) {
      var s = i[a];
      if (dg(e, t, r, n, s[0], s[1], o[0], o[1])) return true;
      o = s;
    }
  }
  function dg(e, t, r, n, i, a, o, s) {
    var u = r - e, l = n - t, f = o - i, h = s - a, c = au(f, h, u, l);
    if (bb(c)) return false;
    var v = e - i, p = t - a, y = au(v, p, u, l) / c;
    if (y < 0 || y > 1) return false;
    var g = au(v, p, f, h) / c;
    return !(g < 0 || g > 1);
  }
  function au(e, t, r, n) {
    return e * n - r * t;
  }
  function bb(e) {
    return e <= 1e-6 && e >= -1e-6;
  }
  wb = function(e) {
    var t = e.itemTooltipOption, r = e.componentModel, n = e.itemName, i = V(t) ? {
      formatter: t
    } : t, a = r.mainType, o = r.componentIndex, s = {
      componentType: a,
      name: n,
      $vars: [
        "name"
      ]
    };
    s[a + "Index"] = o;
    var u = e.formatterParamsExtra;
    u && P(K(u), function(f) {
      tn(s, f) || (s[f] = u[f], s.$vars.push(f));
    });
    var l = mt(e.el);
    l.componentMainType = a, l.componentIndex = o, l.tooltipConfig = {
      name: n,
      option: ht({
        content: n,
        encodeHTMLContent: true,
        formatterParams: s
      }, i)
    };
  };
  function Cv(e, t) {
    var r;
    e.isGroup && (r = t(e)), r || e.traverse(t);
  }
  function ff(e, t) {
    if (e) if (B(e)) for (var r = 0; r < e.length; r++) Cv(e[r], t);
    else Cv(e, t);
  }
  se("circle", ia);
  se("ellipse", Zo);
  se("sector", aa);
  se("ring", Ko);
  se("polygon", jo);
  se("polyline", Qo);
  se("rect", ne);
  se("line", en);
  se("bezierCurve", Jo);
  se("arc", oa);
  Y2 = Object.freeze(Object.defineProperty({
    __proto__: null,
    Arc: oa,
    BezierCurve: Jo,
    BoundingRect: at,
    Circle: ia,
    CompoundPath: rf,
    Ellipse: Zo,
    Group: oe,
    Image: Se,
    IncrementalDisplayable: og,
    Line: en,
    LinearGradient: nf,
    OrientedBoundingRect: sb,
    Path: et,
    Point: it,
    Polygon: jo,
    Polyline: Qo,
    RadialGradient: ag,
    Rect: ne,
    Ring: Ko,
    Sector: aa,
    Text: Re,
    applyTransform: uf,
    clipPointsByRect: cg,
    clipRectByRect: pg,
    createIcon: lf,
    extendPath: ug,
    extendShape: sg,
    getShapeClass: lg,
    getTransform: vg,
    groupTransition: _b,
    initProps: Hn,
    isElementRemoved: Ri,
    lineLineIntersect: dg,
    linePolygonIntersect: Sb,
    makeImage: of,
    makePath: ts,
    mergePath: hg,
    registerShape: se,
    removeElement: yo,
    removeElementWithFadeOut: hb,
    resizePath: sf,
    setTooltipConfig: wb,
    subPixelOptimize: gb,
    subPixelOptimizeLine: pb,
    subPixelOptimizeRect: db,
    transformDirection: yb,
    traverseElements: ff,
    updateProps: rn
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  var es = {};
  function Tb(e, t) {
    for (var r = 0; r < Oe.length; r++) {
      var n = Oe[r], i = t[n], a = e.ensureState(n);
      a.style = a.style || {}, a.style.text = i;
    }
    var o = e.currentStates.slice();
    e.clearStates(true), e.setStyle({
      text: t.normal
    }), e.useStates(o, true);
  }
  function Dv(e, t, r) {
    var n = e.labelFetcher, i = e.labelDataIndex, a = e.labelDimIndex, o = t.normal, s;
    n && (s = n.getFormattedLabel(i, "normal", null, a, o && o.get("formatter"), r != null ? {
      interpolatedValue: r
    } : null)), s == null && (s = Y(e.defaultText) ? e.defaultText(i, e, r) : e.defaultText);
    for (var u = {
      normal: s
    }, l = 0; l < Oe.length; l++) {
      var f = Oe[l], h = t[f];
      u[f] = W(n ? n.getFormattedLabel(i, f, null, a, h && h.get("formatter")) : null, s);
    }
    return u;
  }
  gg = function(e, t, r, n) {
    r = r || es;
    for (var i = e instanceof Re, a = false, o = 0; o < uv.length; o++) {
      var s = t[uv[o]];
      if (s && s.getShallow("show")) {
        a = true;
        break;
      }
    }
    var u = i ? e : e.getTextContent();
    if (a) {
      i || (u || (u = new Re(), e.setTextContent(u)), e.stateProxy && (u.stateProxy = e.stateProxy));
      var l = Dv(r, t), f = t.normal, h = !!f.getShallow("show"), c = En(f, n && n.normal, r, false, !i);
      c.text = l.normal, i || e.setTextConfig(xv(f, r, false));
      for (var o = 0; o < Oe.length; o++) {
        var v = Oe[o], s = t[v];
        if (s) {
          var p = u.ensureState(v), y = !!W(s.getShallow("show"), h);
          if (y !== h && (p.ignore = !y), p.style = En(s, n && n[v], r, true, !i), p.style.text = l[v], !i) {
            var g = e.ensureState(v);
            g.textConfig = xv(s, r, true);
          }
        }
      }
      u.silent = !!f.getShallow("silent"), u.style.x != null && (c.x = u.style.x), u.style.y != null && (c.y = u.style.y), u.ignore = !h, u.useStyle(c), u.dirty(), r.enableTextSetter && (yg(u).setLabelText = function(d) {
        var m = Dv(r, t, d);
        Tb(u, m);
      });
    } else u && (u.ignore = true);
    e.dirty();
  };
  function hf(e, t) {
    t = t || "label";
    for (var r = {
      normal: e.getModel(t)
    }, n = 0; n < Oe.length; n++) {
      var i = Oe[n];
      r[i] = e.getModel([
        i,
        t
      ]);
    }
    return r;
  }
  En = function(e, t, r, n, i) {
    var a = {};
    return Mb(a, e, r, n, i), t && O(a, t), a;
  };
  function xv(e, t, r) {
    t = t || {};
    var n = {}, i, a = e.getShallow("rotate"), o = W(e.getShallow("distance"), r ? null : 5), s = e.getShallow("offset");
    return i = e.getShallow("position") || (r ? null : "inside"), i === "outside" && (i = t.defaultOutsidePosition || "top"), i != null && (n.position = i), s != null && (n.offset = s), a != null && (a *= Math.PI / 180, n.rotation = a), o != null && (n.distance = o), n.outsideFill = e.get("color") === "inherit" ? t.inheritColor || null : "auto", n;
  }
  function Mb(e, t, r, n, i) {
    r = r || es;
    var a = t.ecModel, o = a && a.option.textStyle, s = Cb(t), u;
    if (s) {
      u = {};
      for (var l in s) if (s.hasOwnProperty(l)) {
        var f = t.getModel([
          "rich",
          l
        ]);
        Ev(u[l] = {}, f, o, r, n, i, false, true);
      }
    }
    u && (e.rich = u);
    var h = t.get("overflow");
    h && (e.overflow = h);
    var c = t.get("minMargin");
    c != null && (e.margin = c), Ev(e, t, o, r, n, i, true, false);
  }
  function Cb(e) {
    for (var t; e && e !== e.ecModel; ) {
      var r = (e.option || es).rich;
      if (r) {
        t = t || {};
        for (var n = K(r), i = 0; i < n.length; i++) {
          var a = n[i];
          t[a] = 1;
        }
      }
      e = e.parentModel;
    }
    return t;
  }
  var Pv = [
    "fontStyle",
    "fontWeight",
    "fontSize",
    "fontFamily",
    "textShadowColor",
    "textShadowBlur",
    "textShadowOffsetX",
    "textShadowOffsetY"
  ], Iv = [
    "align",
    "lineHeight",
    "width",
    "height",
    "tag",
    "verticalAlign",
    "ellipsis"
  ], Av = [
    "padding",
    "borderWidth",
    "borderRadius",
    "borderDashOffset",
    "backgroundColor",
    "borderColor",
    "shadowColor",
    "shadowBlur",
    "shadowOffsetX",
    "shadowOffsetY"
  ];
  function Ev(e, t, r, n, i, a, o, s) {
    r = !i && r || es;
    var u = n && n.inheritColor, l = t.getShallow("color"), f = t.getShallow("textBorderColor"), h = W(t.getShallow("opacity"), r.opacity);
    (l === "inherit" || l === "auto") && (u ? l = u : l = null), (f === "inherit" || f === "auto") && (u ? f = u : f = null), a || (l = l || r.color, f = f || r.textBorderColor), l != null && (e.fill = l), f != null && (e.stroke = f);
    var c = W(t.getShallow("textBorderWidth"), r.textBorderWidth);
    c != null && (e.lineWidth = c);
    var v = W(t.getShallow("textBorderType"), r.textBorderType);
    v != null && (e.lineDash = v);
    var p = W(t.getShallow("textBorderDashOffset"), r.textBorderDashOffset);
    p != null && (e.lineDashOffset = p), !i && h == null && !s && (h = n && n.defaultOpacity), h != null && (e.opacity = h), !i && !a && e.fill == null && n.inheritColor && (e.fill = n.inheritColor);
    for (var y = 0; y < Pv.length; y++) {
      var g = Pv[y], d = W(t.getShallow(g), r[g]);
      d != null && (e[g] = d);
    }
    for (var y = 0; y < Iv.length; y++) {
      var g = Iv[y], d = t.getShallow(g);
      d != null && (e[g] = d);
    }
    if (e.verticalAlign == null) {
      var m = t.getShallow("baseline");
      m != null && (e.verticalAlign = m);
    }
    if (!o || !n.disableBox) {
      for (var y = 0; y < Av.length; y++) {
        var g = Av[y], d = t.getShallow(g);
        d != null && (e[g] = d);
      }
      var _ = t.getShallow("borderType");
      _ != null && (e.borderDash = _), (e.backgroundColor === "auto" || e.backgroundColor === "inherit") && u && (e.backgroundColor = u), (e.borderColor === "auto" || e.borderColor === "inherit") && u && (e.borderColor = u);
    }
  }
  Db = function(e, t) {
    var r = t && t.getModel("textStyle");
    return Ie([
      e.fontStyle || r && r.getShallow("fontStyle") || "",
      e.fontWeight || r && r.getShallow("fontWeight") || "",
      (e.fontSize || r && r.getShallow("fontSize") || 12) + "px",
      e.fontFamily || r && r.getShallow("fontFamily") || "sans-serif"
    ].join(" "));
  };
  let yg, xb, ou, su, Pb, mg, Ib, Ab, _g, Eb, Lb;
  yg = Pt();
  xb = [
    "textStyle",
    "color"
  ];
  ou = [
    "fontStyle",
    "fontWeight",
    "fontSize",
    "fontFamily",
    "padding",
    "lineHeight",
    "rich",
    "width",
    "height",
    "overflow"
  ];
  su = new Re();
  Pb = (function() {
    function e() {
    }
    return e.prototype.getTextColor = function(t) {
      var r = this.ecModel;
      return this.getShallow("color") || (!t && r ? r.get(xb) : null);
    }, e.prototype.getFont = function() {
      return Db({
        fontStyle: this.getShallow("fontStyle"),
        fontWeight: this.getShallow("fontWeight"),
        fontSize: this.getShallow("fontSize"),
        fontFamily: this.getShallow("fontFamily")
      }, this.ecModel);
    }, e.prototype.getTextRect = function(t) {
      for (var r = {
        text: t,
        verticalAlign: this.getShallow("verticalAlign") || this.getShallow("baseline")
      }, n = 0; n < ou.length; n++) r[ou[n]] = this.getShallow(ou[n]);
      return su.useStyle(r), su.update(), su.getBoundingRect();
    }, e;
  })();
  mg = [
    [
      "lineWidth",
      "width"
    ],
    [
      "stroke",
      "color"
    ],
    [
      "opacity"
    ],
    [
      "shadowBlur"
    ],
    [
      "shadowOffsetX"
    ],
    [
      "shadowOffsetY"
    ],
    [
      "shadowColor"
    ],
    [
      "lineDash",
      "type"
    ],
    [
      "lineDashOffset",
      "dashOffset"
    ],
    [
      "lineCap",
      "cap"
    ],
    [
      "lineJoin",
      "join"
    ],
    [
      "miterLimit"
    ]
  ];
  Ib = qi(mg);
  Ab = (function() {
    function e() {
    }
    return e.prototype.getLineStyle = function(t) {
      return Ib(this, t);
    }, e;
  })();
  _g = [
    [
      "fill",
      "color"
    ],
    [
      "stroke",
      "borderColor"
    ],
    [
      "lineWidth",
      "borderWidth"
    ],
    [
      "opacity"
    ],
    [
      "shadowBlur"
    ],
    [
      "shadowOffsetX"
    ],
    [
      "shadowOffsetY"
    ],
    [
      "shadowColor"
    ],
    [
      "lineDash",
      "borderType"
    ],
    [
      "lineDashOffset",
      "borderDashOffset"
    ],
    [
      "lineCap",
      "borderCap"
    ],
    [
      "lineJoin",
      "borderJoin"
    ],
    [
      "miterLimit",
      "borderMiterLimit"
    ]
  ];
  Eb = qi(_g);
  Lb = (function() {
    function e() {
    }
    return e.prototype.getItemStyle = function(t, r) {
      return Eb(this, t, r);
    }, e;
  })();
  wt = (function() {
    function e(t, r, n) {
      this.parentModel = r, this.ecModel = n, this.option = t;
    }
    return e.prototype.init = function(t, r, n) {
    }, e.prototype.mergeOption = function(t, r) {
      ct(this.option, t, true);
    }, e.prototype.get = function(t, r) {
      return t == null ? this.option : this._doGet(this.parsePath(t), !r && this.parentModel);
    }, e.prototype.getShallow = function(t, r) {
      var n = this.option, i = n == null ? n : n[t];
      if (i == null && !r) {
        var a = this.parentModel;
        a && (i = a.getShallow(t));
      }
      return i;
    }, e.prototype.getModel = function(t, r) {
      var n = t != null, i = n ? this.parsePath(t) : null, a = n ? this._doGet(i) : this.option;
      return r = r || this.parentModel && this.parentModel.getModel(this.resolveParentPath(i)), new e(a, r, this.ecModel);
    }, e.prototype.isEmpty = function() {
      return this.option == null;
    }, e.prototype.restoreData = function() {
    }, e.prototype.clone = function() {
      var t = this.constructor;
      return new t(Z(this.option));
    }, e.prototype.parsePath = function(t) {
      return typeof t == "string" ? t.split(".") : t;
    }, e.prototype.resolveParentPath = function(t) {
      return t;
    }, e.prototype.isAnimationEnabled = function() {
      if (!j.node && this.option) {
        if (this.option.animation != null) return !!this.option.animation;
        if (this.parentModel) return this.parentModel.isAnimationEnabled();
      }
    }, e.prototype._doGet = function(t, r) {
      var n = this.option;
      if (!t) return n;
      for (var i = 0; i < t.length && !(t[i] && (n = n && typeof n == "object" ? n[t[i]] : null, n == null)); i++) ;
      return n == null && r && (n = r._doGet(this.resolveParentPath(t), r.parentModel)), n;
    }, e;
  })();
  Kl(wt);
  C1(wt);
  ae(wt, Ab);
  ae(wt, Lb);
  ae(wt, A1);
  ae(wt, Pb);
  var Rb = Math.round(Math.random() * 10);
  rs = function(e) {
    return [
      e || "",
      Rb++
    ].join("_");
  };
  function Ob(e) {
    var t = {};
    e.registerSubTypeDefaulter = function(r, n) {
      var i = Ee(r);
      t[i.main] = n;
    }, e.determineSubType = function(r, n) {
      var i = n.type;
      if (!i) {
        var a = Ee(r).main;
        e.hasSubTypes(r) && t[a] && (i = t[a](n));
      }
      return i;
    };
  }
  function kb(e, t) {
    e.topologicalTravel = function(a, o, s, u) {
      if (!a.length) return;
      var l = r(o), f = l.graph, h = l.noEntryList, c = {};
      for (P(a, function(m) {
        c[m] = true;
      }); h.length; ) {
        var v = h.pop(), p = f[v], y = !!c[v];
        y && (s.call(u, v, p.originalDeps.slice()), delete c[v]), P(p.successor, y ? d : g);
      }
      P(c, function() {
        var m = "";
        throw new Error(m);
      });
      function g(m) {
        f[m].entryCount--, f[m].entryCount === 0 && h.push(m);
      }
      function d(m) {
        c[m] = true, g(m);
      }
    };
    function r(a) {
      var o = {}, s = [];
      return P(a, function(u) {
        var l = n(o, u), f = l.originalDeps = t(u), h = i(f, a);
        l.entryCount = h.length, l.entryCount === 0 && s.push(u), P(h, function(c) {
          vt(l.predecessor, c) < 0 && l.predecessor.push(c);
          var v = n(o, c);
          vt(v.successor, c) < 0 && v.successor.push(u);
        });
      }), {
        graph: o,
        noEntryList: s
      };
    }
    function n(a, o) {
      return a[o] || (a[o] = {
        predecessor: [],
        successor: []
      }), a[o];
    }
    function i(a, o) {
      var s = [];
      return P(a, function(u) {
        vt(o, u) >= 0 && s.push(u);
      }), s;
    }
  }
  Nb = function(e, t) {
    return ct(ct({}, e, true), t, true);
  };
  const Fb = {
    time: {
      month: [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
      ],
      monthAbbr: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec"
      ],
      dayOfWeek: [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
      ],
      dayOfWeekAbbr: [
        "Sun",
        "Mon",
        "Tue",
        "Wed",
        "Thu",
        "Fri",
        "Sat"
      ]
    },
    legend: {
      selector: {
        all: "All",
        inverse: "Inv"
      }
    },
    toolbox: {
      brush: {
        title: {
          rect: "Box Select",
          polygon: "Lasso Select",
          lineX: "Horizontally Select",
          lineY: "Vertically Select",
          keep: "Keep Selections",
          clear: "Clear Selections"
        }
      },
      dataView: {
        title: "Data View",
        lang: [
          "Data View",
          "Close",
          "Refresh"
        ]
      },
      dataZoom: {
        title: {
          zoom: "Zoom",
          back: "Zoom Reset"
        }
      },
      magicType: {
        title: {
          line: "Switch to Line Chart",
          bar: "Switch to Bar Chart",
          stack: "Stack",
          tiled: "Tile"
        }
      },
      restore: {
        title: "Restore"
      },
      saveAsImage: {
        title: "Save as Image",
        lang: [
          "Right Click to Save Image"
        ]
      }
    },
    series: {
      typeNames: {
        pie: "Pie chart",
        bar: "Bar chart",
        line: "Line chart",
        scatter: "Scatter plot",
        effectScatter: "Ripple scatter plot",
        radar: "Radar chart",
        tree: "Tree",
        treemap: "Treemap",
        boxplot: "Boxplot",
        candlestick: "Candlestick",
        k: "K line chart",
        heatmap: "Heat map",
        map: "Map",
        parallel: "Parallel coordinate map",
        lines: "Line graph",
        graph: "Relationship graph",
        sankey: "Sankey diagram",
        funnel: "Funnel chart",
        gauge: "Gauge",
        pictorialBar: "Pictorial bar",
        themeRiver: "Theme River Map",
        sunburst: "Sunburst",
        custom: "Custom chart",
        chart: "Chart"
      }
    },
    aria: {
      general: {
        withTitle: 'This is a chart about "{title}"',
        withoutTitle: "This is a chart"
      },
      series: {
        single: {
          prefix: "",
          withName: " with type {seriesType} named {seriesName}.",
          withoutName: " with type {seriesType}."
        },
        multiple: {
          prefix: ". It consists of {seriesCount} series count.",
          withName: " The {seriesId} series is a {seriesType} representing {seriesName}.",
          withoutName: " The {seriesId} series is a {seriesType}.",
          separator: {
            middle: "",
            end: ""
          }
        }
      },
      data: {
        allData: "The data is as follows: ",
        partialData: "The first {displayCnt} items are: ",
        withName: "the data for {name} is {value}",
        withoutName: "{value}",
        separator: {
          middle: ", ",
          end: ". "
        }
      }
    }
  }, Bb = {
    time: {
      month: [
        "\u4E00\u6708",
        "\u4E8C\u6708",
        "\u4E09\u6708",
        "\u56DB\u6708",
        "\u4E94\u6708",
        "\u516D\u6708",
        "\u4E03\u6708",
        "\u516B\u6708",
        "\u4E5D\u6708",
        "\u5341\u6708",
        "\u5341\u4E00\u6708",
        "\u5341\u4E8C\u6708"
      ],
      monthAbbr: [
        "1\u6708",
        "2\u6708",
        "3\u6708",
        "4\u6708",
        "5\u6708",
        "6\u6708",
        "7\u6708",
        "8\u6708",
        "9\u6708",
        "10\u6708",
        "11\u6708",
        "12\u6708"
      ],
      dayOfWeek: [
        "\u661F\u671F\u65E5",
        "\u661F\u671F\u4E00",
        "\u661F\u671F\u4E8C",
        "\u661F\u671F\u4E09",
        "\u661F\u671F\u56DB",
        "\u661F\u671F\u4E94",
        "\u661F\u671F\u516D"
      ],
      dayOfWeekAbbr: [
        "\u65E5",
        "\u4E00",
        "\u4E8C",
        "\u4E09",
        "\u56DB",
        "\u4E94",
        "\u516D"
      ]
    },
    legend: {
      selector: {
        all: "\u5168\u9009",
        inverse: "\u53CD\u9009"
      }
    },
    toolbox: {
      brush: {
        title: {
          rect: "\u77E9\u5F62\u9009\u62E9",
          polygon: "\u5708\u9009",
          lineX: "\u6A2A\u5411\u9009\u62E9",
          lineY: "\u7EB5\u5411\u9009\u62E9",
          keep: "\u4FDD\u6301\u9009\u62E9",
          clear: "\u6E05\u9664\u9009\u62E9"
        }
      },
      dataView: {
        title: "\u6570\u636E\u89C6\u56FE",
        lang: [
          "\u6570\u636E\u89C6\u56FE",
          "\u5173\u95ED",
          "\u5237\u65B0"
        ]
      },
      dataZoom: {
        title: {
          zoom: "\u533A\u57DF\u7F29\u653E",
          back: "\u533A\u57DF\u7F29\u653E\u8FD8\u539F"
        }
      },
      magicType: {
        title: {
          line: "\u5207\u6362\u4E3A\u6298\u7EBF\u56FE",
          bar: "\u5207\u6362\u4E3A\u67F1\u72B6\u56FE",
          stack: "\u5207\u6362\u4E3A\u5806\u53E0",
          tiled: "\u5207\u6362\u4E3A\u5E73\u94FA"
        }
      },
      restore: {
        title: "\u8FD8\u539F"
      },
      saveAsImage: {
        title: "\u4FDD\u5B58\u4E3A\u56FE\u7247",
        lang: [
          "\u53F3\u952E\u53E6\u5B58\u4E3A\u56FE\u7247"
        ]
      }
    },
    series: {
      typeNames: {
        pie: "\u997C\u56FE",
        bar: "\u67F1\u72B6\u56FE",
        line: "\u6298\u7EBF\u56FE",
        scatter: "\u6563\u70B9\u56FE",
        effectScatter: "\u6D9F\u6F2A\u6563\u70B9\u56FE",
        radar: "\u96F7\u8FBE\u56FE",
        tree: "\u6811\u56FE",
        treemap: "\u77E9\u5F62\u6811\u56FE",
        boxplot: "\u7BB1\u578B\u56FE",
        candlestick: "K\u7EBF\u56FE",
        k: "K\u7EBF\u56FE",
        heatmap: "\u70ED\u529B\u56FE",
        map: "\u5730\u56FE",
        parallel: "\u5E73\u884C\u5750\u6807\u56FE",
        lines: "\u7EBF\u56FE",
        graph: "\u5173\u7CFB\u56FE",
        sankey: "\u6851\u57FA\u56FE",
        funnel: "\u6F0F\u6597\u56FE",
        gauge: "\u4EEA\u8868\u76D8\u56FE",
        pictorialBar: "\u8C61\u5F62\u67F1\u56FE",
        themeRiver: "\u4E3B\u9898\u6CB3\u6D41\u56FE",
        sunburst: "\u65ED\u65E5\u56FE",
        custom: "\u81EA\u5B9A\u4E49\u56FE\u8868",
        chart: "\u56FE\u8868"
      }
    },
    aria: {
      general: {
        withTitle: "\u8FD9\u662F\u4E00\u4E2A\u5173\u4E8E\u201C{title}\u201D\u7684\u56FE\u8868\u3002",
        withoutTitle: "\u8FD9\u662F\u4E00\u4E2A\u56FE\u8868\uFF0C"
      },
      series: {
        single: {
          prefix: "",
          withName: "\u56FE\u8868\u7C7B\u578B\u662F{seriesType}\uFF0C\u8868\u793A{seriesName}\u3002",
          withoutName: "\u56FE\u8868\u7C7B\u578B\u662F{seriesType}\u3002"
        },
        multiple: {
          prefix: "\u5B83\u7531{seriesCount}\u4E2A\u56FE\u8868\u7CFB\u5217\u7EC4\u6210\u3002",
          withName: "\u7B2C{seriesId}\u4E2A\u7CFB\u5217\u662F\u4E00\u4E2A\u8868\u793A{seriesName}\u7684{seriesType}\uFF0C",
          withoutName: "\u7B2C{seriesId}\u4E2A\u7CFB\u5217\u662F\u4E00\u4E2A{seriesType}\uFF0C",
          separator: {
            middle: "\uFF1B",
            end: "\u3002"
          }
        }
      },
      data: {
        allData: "\u5176\u6570\u636E\u662F\u2014\u2014",
        partialData: "\u5176\u4E2D\uFF0C\u524D{displayCnt}\u9879\u662F\u2014\u2014",
        withName: "{name}\u7684\u6570\u636E\u662F{value}",
        withoutName: "{value}",
        separator: {
          middle: "\uFF0C",
          end: ""
        }
      }
    }
  };
  var So = "ZH", vf = "EN", Ln = vf, Ja = {}, cf = {}, Sg = j.domSupported ? (function() {
    var e = (document.documentElement.lang || navigator.language || navigator.browserLanguage || Ln).toUpperCase();
    return e.indexOf(So) > -1 ? So : Ln;
  })() : Ln;
  function pf(e, t) {
    e = e.toUpperCase(), cf[e] = new wt(t), Ja[e] = t;
  }
  function zb(e) {
    if (V(e)) {
      var t = Ja[e.toUpperCase()] || {};
      return e === So || e === vf ? Z(t) : ct(Z(t), Z(Ja[Ln]), false);
    } else return ct(Z(e), Z(Ja[Ln]), false);
  }
  function Vb(e) {
    return cf[e];
  }
  function Gb() {
    return cf[Ln];
  }
  pf(vf, Fb);
  pf(So, Bb);
  var df = 1e3, gf = df * 60, Oi = gf * 60, re = Oi * 24, Lv = re * 365, wi = {
    year: "{yyyy}",
    month: "{MMM}",
    day: "{d}",
    hour: "{HH}:{mm}",
    minute: "{HH}:{mm}",
    second: "{HH}:{mm}:{ss}",
    millisecond: "{HH}:{mm}:{ss} {SSS}",
    none: "{yyyy}-{MM}-{dd} {HH}:{mm}:{ss} {SSS}"
  }, Pa = "{yyyy}-{MM}-{dd}", Rv = {
    year: "{yyyy}",
    month: "{yyyy}-{MM}",
    day: Pa,
    hour: Pa + " " + wi.hour,
    minute: Pa + " " + wi.minute,
    second: Pa + " " + wi.second,
    millisecond: wi.none
  }, uu = [
    "year",
    "month",
    "day",
    "hour",
    "minute",
    "second",
    "millisecond"
  ], bg = [
    "year",
    "half-year",
    "quarter",
    "month",
    "week",
    "half-week",
    "day",
    "half-day",
    "quarter-day",
    "hour",
    "minute",
    "second",
    "millisecond"
  ];
  function At(e, t) {
    return e += "", "0000".substr(0, t - e.length) + e;
  }
  function Rn(e) {
    switch (e) {
      case "half-year":
      case "quarter":
        return "month";
      case "week":
      case "half-week":
        return "day";
      case "half-day":
      case "quarter-day":
        return "hour";
      default:
        return e;
    }
  }
  function Hb(e) {
    return e === Rn(e);
  }
  function Ub(e) {
    switch (e) {
      case "year":
      case "month":
        return "day";
      case "millisecond":
        return "millisecond";
      default:
        return "second";
    }
  }
  ns = function(e, t, r, n) {
    var i = ie(e), a = i[yf(r)](), o = i[On(r)]() + 1, s = Math.floor((o - 1) / 3) + 1, u = i[is(r)](), l = i["get" + (r ? "UTC" : "") + "Day"](), f = i[$i(r)](), h = (f - 1) % 12 + 1, c = i[as(r)](), v = i[os(r)](), p = i[ss(r)](), y = f >= 12 ? "pm" : "am", g = y.toUpperCase(), d = n instanceof wt ? n : Vb(n || Sg) || Gb(), m = d.getModel("time"), _ = m.get("month"), S = m.get("monthAbbr"), T = m.get("dayOfWeek"), b = m.get("dayOfWeekAbbr");
    return (t || "").replace(/{a}/g, y + "").replace(/{A}/g, g + "").replace(/{yyyy}/g, a + "").replace(/{yy}/g, At(a % 100 + "", 2)).replace(/{Q}/g, s + "").replace(/{MMMM}/g, _[o - 1]).replace(/{MMM}/g, S[o - 1]).replace(/{MM}/g, At(o, 2)).replace(/{M}/g, o + "").replace(/{dd}/g, At(u, 2)).replace(/{d}/g, u + "").replace(/{eeee}/g, T[l]).replace(/{ee}/g, b[l]).replace(/{e}/g, l + "").replace(/{HH}/g, At(f, 2)).replace(/{H}/g, f + "").replace(/{hh}/g, At(h + "", 2)).replace(/{h}/g, h + "").replace(/{mm}/g, At(c, 2)).replace(/{m}/g, c + "").replace(/{ss}/g, At(v, 2)).replace(/{s}/g, v + "").replace(/{SSS}/g, At(p, 3)).replace(/{S}/g, p + "");
  };
  function Wb(e, t, r, n, i) {
    var a = null;
    if (V(r)) a = r;
    else if (Y(r)) a = r(e.value, t, {
      level: e.level
    });
    else {
      var o = O({}, wi);
      if (e.level > 0) for (var s = 0; s < uu.length; ++s) o[uu[s]] = "{primary|" + o[uu[s]] + "}";
      var u = r ? r.inherit === false ? r : ht(r, o) : o, l = wg(e.value, i);
      if (u[l]) a = u[l];
      else if (u.inherit) {
        for (var f = bg.indexOf(l), s = f - 1; s >= 0; --s) if (u[l]) {
          a = u[l];
          break;
        }
        a = a || o.none;
      }
      if (B(a)) {
        var h = e.level == null ? 0 : e.level >= 0 ? e.level : a.length + e.level;
        h = Math.min(h, a.length - 1), a = a[h];
      }
    }
    return ns(new Date(e.value), a, i, n);
  }
  function wg(e, t) {
    var r = ie(e), n = r[On(t)]() + 1, i = r[is(t)](), a = r[$i(t)](), o = r[as(t)](), s = r[os(t)](), u = r[ss(t)](), l = u === 0, f = l && s === 0, h = f && o === 0, c = h && a === 0, v = c && i === 1, p = v && n === 1;
    return p ? "year" : v ? "month" : c ? "day" : h ? "hour" : f ? "minute" : l ? "second" : "millisecond";
  }
  function Ov(e, t, r) {
    var n = lt(e) ? ie(e) : e;
    switch (t = t || wg(e, r), t) {
      case "year":
        return n[yf(r)]();
      case "half-year":
        return n[On(r)]() >= 6 ? 1 : 0;
      case "quarter":
        return Math.floor((n[On(r)]() + 1) / 4);
      case "month":
        return n[On(r)]();
      case "day":
        return n[is(r)]();
      case "half-day":
        return n[$i(r)]() / 24;
      case "hour":
        return n[$i(r)]();
      case "minute":
        return n[as(r)]();
      case "second":
        return n[os(r)]();
      case "millisecond":
        return n[ss(r)]();
    }
  }
  function yf(e) {
    return e ? "getUTCFullYear" : "getFullYear";
  }
  function On(e) {
    return e ? "getUTCMonth" : "getMonth";
  }
  function is(e) {
    return e ? "getUTCDate" : "getDate";
  }
  function $i(e) {
    return e ? "getUTCHours" : "getHours";
  }
  function as(e) {
    return e ? "getUTCMinutes" : "getMinutes";
  }
  function os(e) {
    return e ? "getUTCSeconds" : "getSeconds";
  }
  function ss(e) {
    return e ? "getUTCMilliseconds" : "getMilliseconds";
  }
  function Yb(e) {
    return e ? "setUTCFullYear" : "setFullYear";
  }
  function Tg(e) {
    return e ? "setUTCMonth" : "setMonth";
  }
  function Mg(e) {
    return e ? "setUTCDate" : "setDate";
  }
  function Cg(e) {
    return e ? "setUTCHours" : "setHours";
  }
  function Dg(e) {
    return e ? "setUTCMinutes" : "setMinutes";
  }
  function xg(e) {
    return e ? "setUTCSeconds" : "setSeconds";
  }
  function Pg(e) {
    return e ? "setUTCMilliseconds" : "setMilliseconds";
  }
  function qb(e, t, r, n, i, a, o, s) {
    var u = new Re({
      style: {
        text: e,
        font: t,
        align: r,
        verticalAlign: n,
        padding: i,
        rich: a,
        overflow: o ? "truncate" : null,
        lineHeight: s
      }
    });
    return u.getBoundingRect();
  }
  function mf(e) {
    if (!Td(e)) return V(e) ? e : "-";
    var t = (e + "").split(".");
    return t[0].replace(/(\d{1,3})(?=(?:\d{3})+(?!\d))/g, "$1,") + (t.length > 1 ? "." + t[1] : "");
  }
  Xb = function(e, t) {
    return e = (e || "").toLowerCase().replace(/-(.)/g, function(r, n) {
      return n.toUpperCase();
    }), t && e && (e = e.charAt(0).toUpperCase() + e.slice(1)), e;
  };
  Ig = Bl;
  function cl(e, t, r) {
    var n = "{yyyy}-{MM}-{dd} {HH}:{mm}:{ss}";
    function i(f) {
      return f && Ie(f) ? f : "-";
    }
    function a(f) {
      return !!(f != null && !isNaN(f) && isFinite(f));
    }
    var o = t === "time", s = e instanceof Date;
    if (o || s) {
      var u = o ? ie(e) : e;
      if (isNaN(+u)) {
        if (s) return "-";
      } else return ns(u, n, r);
    }
    if (t === "ordinal") return no(e) ? i(e) : lt(e) && a(e) ? e + "" : "-";
    var l = Wi(e);
    return a(l) ? mf(l) : no(e) ? i(e) : typeof e == "boolean" ? e + "" : "-";
  }
  var kv = [
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g"
  ], lu = function(e, t) {
    return "{" + e + (t ?? "") + "}";
  };
  Ag = function(e, t, r) {
    B(t) || (t = [
      t
    ]);
    var n = t.length;
    if (!n) return "";
    for (var i = t[0].$vars || [], a = 0; a < i.length; a++) {
      var o = kv[a];
      e = e.replace(lu(o), lu(o, 0));
    }
    for (var s = 0; s < n; s++) for (var u = 0; u < i.length; u++) {
      var l = t[s][i[u]];
      e = e.replace(lu(kv[u], s), r ? Et(l) : l);
    }
    return e;
  };
  function Eg(e, t) {
    var r = V(e) ? {
      color: e,
      extraCssText: t
    } : e || {}, n = r.color, i = r.type;
    t = r.extraCssText;
    var a = r.renderMode || "html";
    if (!n) return "";
    if (a === "html") return i === "subItem" ? '<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:' + Et(n) + ";" + (t || "") + '"></span>' : '<span style="display:inline-block;margin-right:4px;border-radius:10px;width:10px;height:10px;background-color:' + Et(n) + ";" + (t || "") + '"></span>';
    var o = r.markerId || "markerX";
    return {
      renderMode: a,
      content: "{" + o + "|}  ",
      style: i === "subItem" ? {
        width: 4,
        height: 4,
        borderRadius: 2,
        backgroundColor: n
      } : {
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: n
      }
    };
  }
  function $b(e, t, r) {
    (e === "week" || e === "month" || e === "quarter" || e === "half-year" || e === "year") && (e = `MM-dd
yyyy`);
    var n = ie(t), i = r ? "getUTC" : "get", a = n[i + "FullYear"](), o = n[i + "Month"]() + 1, s = n[i + "Date"](), u = n[i + "Hours"](), l = n[i + "Minutes"](), f = n[i + "Seconds"](), h = n[i + "Milliseconds"]();
    return e = e.replace("MM", At(o, 2)).replace("M", o).replace("yyyy", a).replace("yy", At(a % 100 + "", 2)).replace("dd", At(s, 2)).replace("d", s).replace("hh", At(u, 2)).replace("h", u).replace("mm", At(l, 2)).replace("m", l).replace("ss", At(f, 2)).replace("s", f).replace("SSS", At(h, 3)), e;
  }
  function Zb(e) {
    return e && e.charAt(0).toUpperCase() + e.substr(1);
  }
  pl = function(e, t) {
    return t = t || "transparent", V(e) ? e : G(e) && e.colorStops && (e.colorStops[0] || {}).color || t;
  };
  q2 = function(e, t) {
    if (t === "_blank" || t === "blank") {
      var r = window.open();
      r.opener = null, r.location.href = e;
    } else window.open(e, t);
  };
  var to = P, Kb = [
    "left",
    "right",
    "top",
    "bottom",
    "width",
    "height"
  ], Ia = [
    [
      "width",
      "left",
      "right"
    ],
    [
      "height",
      "top",
      "bottom"
    ]
  ];
  function _f(e, t, r, n, i) {
    var a = 0, o = 0;
    n == null && (n = 1 / 0), i == null && (i = 1 / 0);
    var s = 0;
    t.eachChild(function(u, l) {
      var f = u.getBoundingRect(), h = t.childAt(l + 1), c = h && h.getBoundingRect(), v, p;
      if (e === "horizontal") {
        var y = f.width + (c ? -c.x + f.x : 0);
        v = a + y, v > n || u.newline ? (a = 0, v = y, o += s + r, s = f.height) : s = Math.max(s, f.height);
      } else {
        var g = f.height + (c ? -c.y + f.y : 0);
        p = o + g, p > i || u.newline ? (a += s + r, o = 0, p = g, s = f.width) : s = Math.max(s, f.width);
      }
      u.newline || (u.x = a, u.y = o, u.markRedraw(), e === "horizontal" ? a = v + r : o = p + r);
    });
  }
  X2 = _f;
  Vn(_f, "vertical");
  Vn(_f, "horizontal");
  Sf = function(e, t, r) {
    r = Ig(r || 0);
    var n = t.width, i = t.height, a = Ut(e.left, n), o = Ut(e.top, i), s = Ut(e.right, n), u = Ut(e.bottom, i), l = Ut(e.width, n), f = Ut(e.height, i), h = r[2] + r[0], c = r[1] + r[3], v = e.aspect;
    switch (isNaN(l) && (l = n - s - c - a), isNaN(f) && (f = i - u - h - o), v != null && (isNaN(l) && isNaN(f) && (v > n / i ? l = n * 0.8 : f = i * 0.8), isNaN(l) && (l = v * f), isNaN(f) && (f = l / v)), isNaN(a) && (a = n - s - l - c), isNaN(o) && (o = i - u - f - h), e.left || e.right) {
      case "center":
        a = n / 2 - l / 2 - r[3];
        break;
      case "right":
        a = n - l - c;
        break;
    }
    switch (e.top || e.bottom) {
      case "middle":
      case "center":
        o = i / 2 - f / 2 - r[0];
        break;
      case "bottom":
        o = i - f - h;
        break;
    }
    a = a || 0, o = o || 0, isNaN(l) && (l = n - c - a - (s || 0)), isNaN(f) && (f = i - h - o - (u || 0));
    var p = new at(a + r[3], o + r[0], l, f);
    return p.margin = r, p;
  };
  $2 = function(e, t, r, n, i, a) {
    a = a || e, a.x = e.x, a.y = e.y;
    var o;
    if (o = e.getBoundingRect(), e.needLocalTransform()) {
      var s = e.getLocalTransform();
      o = o.clone(), o.applyTransform(s);
    }
    var u = Sf(ht({
      width: o.width,
      height: o.height
    }, t), r, n), l = u.x - o.x, f = u.y - o.y;
    return a.x += l, a.y += f, a === e && e.markRedraw(), true;
  };
  bo = function(e) {
    var t = e.layoutMode || e.constructor.layoutMode;
    return G(t) ? t : t ? {
      type: t
    } : null;
  };
  wo = function(e, t, r) {
    var n = r && r.ignoreSize;
    !B(n) && (n = [
      n,
      n
    ]);
    var i = o(Ia[0], 0), a = o(Ia[1], 1);
    l(Ia[0], e, i), l(Ia[1], e, a);
    function o(f, h) {
      var c = {}, v = 0, p = {}, y = 0, g = 2;
      if (to(f, function(_) {
        p[_] = e[_];
      }), to(f, function(_) {
        s(t, _) && (c[_] = p[_] = t[_]), u(c, _) && v++, u(p, _) && y++;
      }), n[h]) return u(t, f[1]) ? p[f[2]] = null : u(t, f[2]) && (p[f[1]] = null), p;
      if (y === g || !v) return p;
      if (v >= g) return c;
      for (var d = 0; d < f.length; d++) {
        var m = f[d];
        if (!s(c, m) && s(e, m)) {
          c[m] = e[m];
          break;
        }
      }
      return c;
    }
    function s(f, h) {
      return f.hasOwnProperty(h);
    }
    function u(f, h) {
      return f[h] != null && f[h] !== "auto";
    }
    function l(f, h, c) {
      to(f, function(v) {
        h[v] = c[v];
      });
    }
  };
  Lg = function(e) {
    return jb({}, e);
  };
  function jb(e, t) {
    return t && e && to(Kb, function(r) {
      t.hasOwnProperty(r) && (e[r] = t[r]);
    }), e;
  }
  let Qb;
  Qb = Pt();
  nt = (function(e) {
    ft(t, e);
    function t(r, n, i) {
      var a = e.call(this, r, n, i) || this;
      return a.uid = rs("ec_cpt_model"), a;
    }
    return t.prototype.init = function(r, n, i) {
      this.mergeDefaultAndTheme(r, i);
    }, t.prototype.mergeDefaultAndTheme = function(r, n) {
      var i = bo(this), a = i ? Lg(r) : {}, o = n.getTheme();
      ct(r, o.get(this.mainType)), ct(r, this.getDefaultOption()), i && wo(r, a, i);
    }, t.prototype.mergeOption = function(r, n) {
      ct(this.option, r, true);
      var i = bo(this);
      i && wo(this.option, r, i);
    }, t.prototype.optionUpdated = function(r, n) {
    }, t.prototype.getDefaultOption = function() {
      var r = this.constructor;
      if (!w1(r)) return r.defaultOption;
      var n = Qb(this);
      if (!n.defaultOption) {
        for (var i = [], a = r; a; ) {
          var o = a.prototype.defaultOption;
          o && i.push(o), a = a.superClass;
        }
        for (var s = {}, u = i.length - 1; u >= 0; u--) s = ct(s, i[u], true);
        n.defaultOption = s;
      }
      return n.defaultOption;
    }, t.prototype.getReferringComponents = function(r, n) {
      var i = r + "Index", a = r + "Id";
      return Ho(this.ecModel, r, {
        index: this.get(i, true),
        id: this.get(a, true)
      }, n);
    }, t.prototype.getBoxLayoutParams = function() {
      var r = this;
      return {
        left: r.get("left"),
        top: r.get("top"),
        right: r.get("right"),
        bottom: r.get("bottom"),
        width: r.get("width"),
        height: r.get("height")
      };
    }, t.prototype.getZLevelKey = function() {
      return "";
    }, t.prototype.setZLevel = function(r) {
      this.option.zlevel = r;
    }, t.protoInitialize = (function() {
      var r = t.prototype;
      r.type = "component", r.id = "", r.name = "", r.mainType = "", r.subType = "", r.componentIndex = 0;
    })(), t;
  })(wt);
  Rd(nt, wt);
  Uo(nt);
  Ob(nt);
  kb(nt, Jb);
  function Jb(e) {
    var t = [];
    return P(nt.getClassesByMainType(e), function(r) {
      t = t.concat(r.dependencies || r.prototype.dependencies || []);
    }), t = F(t, function(r) {
      return Ee(r).main;
    }), e !== "dataset" && vt(t, "dataset") <= 0 && t.unshift("dataset"), t;
  }
  var Rg = "";
  typeof navigator < "u" && (Rg = navigator.platform || "");
  var gn = "rgba(0, 0, 0, 0.2)";
  const tw = {
    darkMode: "auto",
    colorBy: "series",
    color: [
      "#5470c6",
      "#91cc75",
      "#fac858",
      "#ee6666",
      "#73c0de",
      "#3ba272",
      "#fc8452",
      "#9a60b4",
      "#ea7ccc"
    ],
    gradientColor: [
      "#f6efa6",
      "#d88273",
      "#bf444c"
    ],
    aria: {
      decal: {
        decals: [
          {
            color: gn,
            dashArrayX: [
              1,
              0
            ],
            dashArrayY: [
              2,
              5
            ],
            symbolSize: 1,
            rotation: Math.PI / 6
          },
          {
            color: gn,
            symbol: "circle",
            dashArrayX: [
              [
                8,
                8
              ],
              [
                0,
                8,
                8,
                0
              ]
            ],
            dashArrayY: [
              6,
              0
            ],
            symbolSize: 0.8
          },
          {
            color: gn,
            dashArrayX: [
              1,
              0
            ],
            dashArrayY: [
              4,
              3
            ],
            rotation: -Math.PI / 4
          },
          {
            color: gn,
            dashArrayX: [
              [
                6,
                6
              ],
              [
                0,
                6,
                6,
                0
              ]
            ],
            dashArrayY: [
              6,
              0
            ]
          },
          {
            color: gn,
            dashArrayX: [
              [
                1,
                0
              ],
              [
                1,
                6
              ]
            ],
            dashArrayY: [
              1,
              0,
              6,
              0
            ],
            rotation: Math.PI / 4
          },
          {
            color: gn,
            symbol: "triangle",
            dashArrayX: [
              [
                9,
                9
              ],
              [
                0,
                9,
                9,
                0
              ]
            ],
            dashArrayY: [
              7,
              2
            ],
            symbolSize: 0.75
          }
        ]
      }
    },
    textStyle: {
      fontFamily: Rg.match(/^Win/) ? "Microsoft YaHei" : "sans-serif",
      fontSize: 12,
      fontStyle: "normal",
      fontWeight: "normal"
    },
    blendMode: null,
    stateAnimation: {
      duration: 300,
      easing: "cubicOut"
    },
    animation: "auto",
    animationDuration: 1e3,
    animationDurationUpdate: 500,
    animationEasing: "cubicInOut",
    animationEasingUpdate: "cubicInOut",
    animationThreshold: 2e3,
    progressiveThreshold: 3e3,
    progressive: 400,
    hoverLayerThreshold: 3e3,
    useUTC: false
  };
  var Og = q([
    "tooltip",
    "label",
    "itemName",
    "itemId",
    "itemGroupId",
    "itemChildGroupId",
    "seriesName"
  ]), ue = "original", Vt = "arrayRows", ke = "objectRows", Ke = "keyedColumns", cr = "typedArray", kg = "unknown", qe = "column", Un = "row", Ht = {
    Must: 1,
    Might: 2,
    Not: 3
  }, Ng = Pt();
  function ew(e) {
    Ng(e).datasetMap = q();
  }
  function rw(e, t, r) {
    var n = {}, i = Fg(t);
    if (!i || !e) return n;
    var a = [], o = [], s = t.ecModel, u = Ng(s).datasetMap, l = i.uid + "_" + r.seriesLayoutBy, f, h;
    e = e.slice(), P(e, function(y, g) {
      var d = G(y) ? y : e[g] = {
        name: y
      };
      d.type === "ordinal" && f == null && (f = g, h = p(d)), n[d.name] = [];
    });
    var c = u.get(l) || u.set(l, {
      categoryWayDim: h,
      valueWayDim: 0
    });
    P(e, function(y, g) {
      var d = y.name, m = p(y);
      if (f == null) {
        var _ = c.valueWayDim;
        v(n[d], _, m), v(o, _, m), c.valueWayDim += m;
      } else if (f === g) v(n[d], 0, m), v(a, 0, m);
      else {
        var _ = c.categoryWayDim;
        v(n[d], _, m), v(o, _, m), c.categoryWayDim += m;
      }
    });
    function v(y, g, d) {
      for (var m = 0; m < d; m++) y.push(g + m);
    }
    function p(y) {
      var g = y.dimsDef;
      return g ? g.length : 1;
    }
    return a.length && (n.itemName = a), o.length && (n.seriesName = o), n;
  }
  function Fg(e) {
    var t = e.get("data", true);
    if (!t) return Ho(e.ecModel, "dataset", {
      index: e.get("datasetIndex", true),
      id: e.get("datasetId", true)
    }, Yr).models[0];
  }
  function nw(e) {
    return !e.get("transform", true) && !e.get("fromTransformResult", true) ? [] : Ho(e.ecModel, "dataset", {
      index: e.get("fromDatasetIndex", true),
      id: e.get("fromDatasetId", true)
    }, Yr).models;
  }
  function Bg(e, t) {
    return iw(e.data, e.sourceFormat, e.seriesLayoutBy, e.dimensionsDefine, e.startIndex, t);
  }
  function iw(e, t, r, n, i, a) {
    var o, s = 5;
    if (Ot(e)) return Ht.Not;
    var u, l;
    if (n) {
      var f = n[a];
      G(f) ? (u = f.name, l = f.type) : V(f) && (u = f);
    }
    if (l != null) return l === "ordinal" ? Ht.Must : Ht.Not;
    if (t === Vt) {
      var h = e;
      if (r === Un) {
        for (var c = h[a], v = 0; v < (c || []).length && v < s; v++) if ((o = S(c[i + v])) != null) return o;
      } else for (var v = 0; v < h.length && v < s; v++) {
        var p = h[i + v];
        if (p && (o = S(p[a])) != null) return o;
      }
    } else if (t === ke) {
      var y = e;
      if (!u) return Ht.Not;
      for (var v = 0; v < y.length && v < s; v++) {
        var g = y[v];
        if (g && (o = S(g[u])) != null) return o;
      }
    } else if (t === Ke) {
      var d = e;
      if (!u) return Ht.Not;
      var c = d[u];
      if (!c || Ot(c)) return Ht.Not;
      for (var v = 0; v < c.length && v < s; v++) if ((o = S(c[v])) != null) return o;
    } else if (t === ue) for (var m = e, v = 0; v < m.length && v < s; v++) {
      var g = m[v], _ = Gn(g);
      if (!B(_)) return Ht.Not;
      if ((o = S(_[a])) != null) return o;
    }
    function S(T) {
      var b = V(T);
      if (T != null && Number.isFinite(Number(T)) && T !== "") return b ? Ht.Might : Ht.Not;
      if (b && T !== "-") return Ht.Must;
    }
    return Ht.Not;
  }
  var dl = q();
  Z2 = function(e, t) {
    $t(dl.get(e) == null && t), dl.set(e, t);
  };
  function aw(e, t, r) {
    var n = dl.get(t);
    if (!n) return r;
    var i = n(e);
    return i ? r.concat(i) : r;
  }
  var Nv = Pt();
  Pt();
  var bf = (function() {
    function e() {
    }
    return e.prototype.getColorFromPalette = function(t, r, n) {
      var i = Lt(this.get("color", true)), a = this.get("colorLayer", true);
      return sw(this, Nv, i, a, t, r, n);
    }, e.prototype.clearColorPalette = function() {
      uw(this, Nv);
    }, e;
  })();
  function ow(e, t) {
    for (var r = e.length, n = 0; n < r; n++) if (e[n].length > t) return e[n];
    return e[r - 1];
  }
  function sw(e, t, r, n, i, a, o) {
    a = a || e;
    var s = t(a), u = s.paletteIdx || 0, l = s.paletteNameMap = s.paletteNameMap || {};
    if (l.hasOwnProperty(i)) return l[i];
    var f = o == null || !n ? r : ow(n, o);
    if (f = f || r, !(!f || !f.length)) {
      var h = f[u];
      return i && (l[i] = h), s.paletteIdx = (u + 1) % f.length, h;
    }
  }
  function uw(e, t) {
    t(e).paletteIdx = 0, t(e).paletteNameMap = {};
  }
  var Aa, ui, Fv, Bv = "\0_ec_inner", lw = 1, wf = (function(e) {
    ft(t, e);
    function t() {
      return e !== null && e.apply(this, arguments) || this;
    }
    return t.prototype.init = function(r, n, i, a, o, s) {
      a = a || {}, this.option = null, this._theme = new wt(a), this._locale = new wt(o), this._optionManager = s;
    }, t.prototype.setOption = function(r, n, i) {
      var a = Gv(n);
      this._optionManager.setOption(r, i, a), this._resetOption(null, a);
    }, t.prototype.resetOption = function(r, n) {
      return this._resetOption(r, Gv(n));
    }, t.prototype._resetOption = function(r, n) {
      var i = false, a = this._optionManager;
      if (!r || r === "recreate") {
        var o = a.mountOption(r === "recreate");
        !this.option || r === "recreate" ? Fv(this, o) : (this.restoreData(), this._mergeOption(o, n)), i = true;
      }
      if ((r === "timeline" || r === "media") && this.restoreData(), !r || r === "recreate" || r === "timeline") {
        var s = a.getTimelineOption(this);
        s && (i = true, this._mergeOption(s, n));
      }
      if (!r || r === "recreate" || r === "media") {
        var u = a.getMediaOption(this);
        u.length && P(u, function(l) {
          i = true, this._mergeOption(l, n);
        }, this);
      }
      return i;
    }, t.prototype.mergeOption = function(r) {
      this._mergeOption(r, null);
    }, t.prototype._mergeOption = function(r, n) {
      var i = this.option, a = this._componentsMap, o = this._componentsCount, s = [], u = q(), l = n && n.replaceMergeMainTypeMap;
      ew(this), P(r, function(h, c) {
        h != null && (nt.hasClass(c) ? c && (s.push(c), u.set(c, true)) : i[c] = i[c] == null ? Z(h) : ct(i[c], h, true));
      }), l && l.each(function(h, c) {
        nt.hasClass(c) && !u.get(c) && (s.push(c), u.set(c, true));
      }), nt.topologicalTravel(s, nt.getAllClassMainTypes(), f, this);
      function f(h) {
        var c = aw(this, h, Lt(r[h])), v = a.get(h), p = v ? l && l.get(h) ? "replaceMerge" : "normalMerge" : "replaceAll", y = u1(v, c, p);
        d1(y, h, nt), i[h] = null, a.set(h, null), o.set(h, 0);
        var g = [], d = [], m = 0, _;
        P(y, function(S, T) {
          var b = S.existing, w = S.newOption;
          if (!w) b && (b.mergeOption({}, this), b.optionUpdated({}, false));
          else {
            var D = h === "series", C = nt.getClass(h, S.keyInfo.subType, !D);
            if (!C) return;
            if (h === "tooltip") {
              if (_) return;
              _ = true;
            }
            if (b && b.constructor === C) b.name = S.keyInfo.name, b.mergeOption(w, this), b.optionUpdated(w, false);
            else {
              var M = O({
                componentIndex: T
              }, S.keyInfo);
              b = new C(w, this, this, M), O(b, M), S.brandNew && (b.__requireNewView = true), b.init(w, this, this), b.optionUpdated(null, true);
            }
          }
          b ? (g.push(b.option), d.push(b), m++) : (g.push(void 0), d.push(void 0));
        }, this), i[h] = g, a.set(h, d), o.set(h, m), h === "series" && Aa(this);
      }
      this._seriesIndices || Aa(this);
    }, t.prototype.getOption = function() {
      var r = Z(this.option);
      return P(r, function(n, i) {
        if (nt.hasClass(i)) {
          for (var a = Lt(n), o = a.length, s = false, u = o - 1; u >= 0; u--) a[u] && !Yi(a[u]) ? s = true : (a[u] = null, !s && o--);
          a.length = o, r[i] = a;
        }
      }), delete r[Bv], r;
    }, t.prototype.getTheme = function() {
      return this._theme;
    }, t.prototype.getLocaleModel = function() {
      return this._locale;
    }, t.prototype.setUpdatePayload = function(r) {
      this._payload = r;
    }, t.prototype.getUpdatePayload = function() {
      return this._payload;
    }, t.prototype.getComponent = function(r, n) {
      var i = this._componentsMap.get(r);
      if (i) {
        var a = i[n || 0];
        if (a) return a;
        if (n == null) {
          for (var o = 0; o < i.length; o++) if (i[o]) return i[o];
        }
      }
    }, t.prototype.queryComponents = function(r) {
      var n = r.mainType;
      if (!n) return [];
      var i = r.index, a = r.id, o = r.name, s = this._componentsMap.get(n);
      if (!s || !s.length) return [];
      var u;
      return i != null ? (u = [], P(Lt(i), function(l) {
        s[l] && u.push(s[l]);
      })) : a != null ? u = zv("id", a, s) : o != null ? u = zv("name", o, s) : u = yt(s, function(l) {
        return !!l;
      }), Vv(u, r);
    }, t.prototype.findComponents = function(r) {
      var n = r.query, i = r.mainType, a = s(n), o = a ? this.queryComponents(a) : yt(this._componentsMap.get(i), function(l) {
        return !!l;
      });
      return u(Vv(o, r));
      function s(l) {
        var f = i + "Index", h = i + "Id", c = i + "Name";
        return l && (l[f] != null || l[h] != null || l[c] != null) ? {
          mainType: i,
          index: l[f],
          id: l[h],
          name: l[c]
        } : null;
      }
      function u(l) {
        return r.filter ? yt(l, r.filter) : l;
      }
    }, t.prototype.eachComponent = function(r, n, i) {
      var a = this._componentsMap;
      if (Y(r)) {
        var o = n, s = r;
        a.each(function(h, c) {
          for (var v = 0; h && v < h.length; v++) {
            var p = h[v];
            p && s.call(o, c, p, p.componentIndex);
          }
        });
      } else for (var u = V(r) ? a.get(r) : G(r) ? this.findComponents(r) : null, l = 0; u && l < u.length; l++) {
        var f = u[l];
        f && n.call(i, f, f.componentIndex);
      }
    }, t.prototype.getSeriesByName = function(r) {
      var n = me(r, null);
      return yt(this._componentsMap.get("series"), function(i) {
        return !!i && n != null && i.name === n;
      });
    }, t.prototype.getSeriesByIndex = function(r) {
      return this._componentsMap.get("series")[r];
    }, t.prototype.getSeriesByType = function(r) {
      return yt(this._componentsMap.get("series"), function(n) {
        return !!n && n.subType === r;
      });
    }, t.prototype.getSeries = function() {
      return yt(this._componentsMap.get("series"), function(r) {
        return !!r;
      });
    }, t.prototype.getSeriesCount = function() {
      return this._componentsCount.get("series");
    }, t.prototype.eachSeries = function(r, n) {
      ui(this), P(this._seriesIndices, function(i) {
        var a = this._componentsMap.get("series")[i];
        r.call(n, a, i);
      }, this);
    }, t.prototype.eachRawSeries = function(r, n) {
      P(this._componentsMap.get("series"), function(i) {
        i && r.call(n, i, i.componentIndex);
      });
    }, t.prototype.eachSeriesByType = function(r, n, i) {
      ui(this), P(this._seriesIndices, function(a) {
        var o = this._componentsMap.get("series")[a];
        o.subType === r && n.call(i, o, a);
      }, this);
    }, t.prototype.eachRawSeriesByType = function(r, n, i) {
      return P(this.getSeriesByType(r), n, i);
    }, t.prototype.isSeriesFiltered = function(r) {
      return ui(this), this._seriesIndicesMap.get(r.componentIndex) == null;
    }, t.prototype.getCurrentSeriesIndices = function() {
      return (this._seriesIndices || []).slice();
    }, t.prototype.filterSeries = function(r, n) {
      ui(this);
      var i = [];
      P(this._seriesIndices, function(a) {
        var o = this._componentsMap.get("series")[a];
        r.call(n, o, a) && i.push(a);
      }, this), this._seriesIndices = i, this._seriesIndicesMap = q(i);
    }, t.prototype.restoreData = function(r) {
      Aa(this);
      var n = this._componentsMap, i = [];
      n.each(function(a, o) {
        nt.hasClass(o) && i.push(o);
      }), nt.topologicalTravel(i, nt.getAllClassMainTypes(), function(a) {
        P(n.get(a), function(o) {
          o && (a !== "series" || !fw(o, r)) && o.restoreData();
        });
      });
    }, t.internalField = (function() {
      Aa = function(r) {
        var n = r._seriesIndices = [];
        P(r._componentsMap.get("series"), function(i) {
          i && n.push(i.componentIndex);
        }), r._seriesIndicesMap = q(n);
      }, ui = function(r) {
      }, Fv = function(r, n) {
        r.option = {}, r.option[Bv] = lw, r._componentsMap = q({
          series: []
        }), r._componentsCount = q();
        var i = n.aria;
        G(i) && i.enabled == null && (i.enabled = true), hw(n, r._theme.option), ct(n, tw, false), r._mergeOption(n, null);
      };
    })(), t;
  })(wt);
  function fw(e, t) {
    if (t) {
      var r = t.seriesIndex, n = t.seriesId, i = t.seriesName;
      return r != null && e.componentIndex !== r || n != null && e.id !== n || i != null && e.name !== i;
    }
  }
  function hw(e, t) {
    var r = e.color && !e.colorLayer;
    P(t, function(n, i) {
      i === "colorLayer" && r || nt.hasClass(i) || (typeof n == "object" ? e[i] = e[i] ? ct(e[i], n, false) : Z(n) : e[i] == null && (e[i] = n));
    });
  }
  function zv(e, t, r) {
    if (B(t)) {
      var n = q();
      return P(t, function(a) {
        if (a != null) {
          var o = me(a, null);
          o != null && n.set(a, true);
        }
      }), yt(r, function(a) {
        return a && n.get(a[e]);
      });
    } else {
      var i = me(t, null);
      return yt(r, function(a) {
        return a && i != null && a[e] === i;
      });
    }
  }
  function Vv(e, t) {
    return t.hasOwnProperty("subType") ? yt(e, function(r) {
      return r && r.subType === t.subType;
    }) : e;
  }
  function Gv(e) {
    var t = q();
    return e && P(Lt(e.replaceMerge), function(r) {
      t.set(r, true);
    }), {
      replaceMergeMainTypeMap: t
    };
  }
  ae(wf, bf);
  var vw = [
    "getDom",
    "getZr",
    "getWidth",
    "getHeight",
    "getDevicePixelRatio",
    "dispatchAction",
    "isSSR",
    "isDisposed",
    "on",
    "off",
    "getDataURL",
    "getConnectedDataURL",
    "getOption",
    "getId",
    "updateLabelLayout"
  ], zg = /* @__PURE__ */ (function() {
    function e(t) {
      P(vw, function(r) {
        this[r] = ut(t[r], t);
      }, this);
    }
    return e;
  })(), fu = {}, us = (function() {
    function e() {
      this._coordinateSystems = [];
    }
    return e.prototype.create = function(t, r) {
      var n = [];
      P(fu, function(i, a) {
        var o = i.create(t, r);
        n = n.concat(o || []);
      }), this._coordinateSystems = n;
    }, e.prototype.update = function(t, r) {
      P(this._coordinateSystems, function(n) {
        n.update && n.update(t, r);
      });
    }, e.prototype.getCoordinateSystems = function() {
      return this._coordinateSystems.slice();
    }, e.register = function(t, r) {
      fu[t] = r;
    }, e.get = function(t) {
      return fu[t];
    }, e;
  })(), cw = /^(min|max)?(.+)$/, pw = (function() {
    function e(t) {
      this._timelineOptions = [], this._mediaList = [], this._currentMediaIndices = [], this._api = t;
    }
    return e.prototype.setOption = function(t, r, n) {
      t && (P(Lt(t.series), function(o) {
        o && o.data && Ot(o.data) && ao(o.data);
      }), P(Lt(t.dataset), function(o) {
        o && o.source && Ot(o.source) && ao(o.source);
      })), t = Z(t);
      var i = this._optionBackup, a = dw(t, r, !i);
      this._newBaseOption = a.baseOption, i ? (a.timelineOptions.length && (i.timelineOptions = a.timelineOptions), a.mediaList.length && (i.mediaList = a.mediaList), a.mediaDefault && (i.mediaDefault = a.mediaDefault)) : this._optionBackup = a;
    }, e.prototype.mountOption = function(t) {
      var r = this._optionBackup;
      return this._timelineOptions = r.timelineOptions, this._mediaList = r.mediaList, this._mediaDefault = r.mediaDefault, this._currentMediaIndices = [], Z(t ? r.baseOption : this._newBaseOption);
    }, e.prototype.getTimelineOption = function(t) {
      var r, n = this._timelineOptions;
      if (n.length) {
        var i = t.getComponent("timeline");
        i && (r = Z(n[i.getCurrentIndex()]));
      }
      return r;
    }, e.prototype.getMediaOption = function(t) {
      var r = this._api.getWidth(), n = this._api.getHeight(), i = this._mediaList, a = this._mediaDefault, o = [], s = [];
      if (!i.length && !a) return s;
      for (var u = 0, l = i.length; u < l; u++) gw(i[u].query, r, n) && o.push(u);
      return !o.length && a && (o = [
        -1
      ]), o.length && !mw(o, this._currentMediaIndices) && (s = F(o, function(f) {
        return Z(f === -1 ? a.option : i[f].option);
      })), this._currentMediaIndices = o, s;
    }, e;
  })();
  function dw(e, t, r) {
    var n = [], i, a, o = e.baseOption, s = e.timeline, u = e.options, l = e.media, f = !!e.media, h = !!(u || s || o && o.timeline);
    o ? (a = o, a.timeline || (a.timeline = s)) : ((h || f) && (e.options = e.media = null), a = e), f && B(l) && P(l, function(v) {
      v && v.option && (v.query ? n.push(v) : i || (i = v));
    }), c(a), P(u, function(v) {
      return c(v);
    }), P(n, function(v) {
      return c(v.option);
    });
    function c(v) {
      P(t, function(p) {
        p(v, r);
      });
    }
    return {
      baseOption: a,
      timelineOptions: u || [],
      mediaDefault: i,
      mediaList: n
    };
  }
  function gw(e, t, r) {
    var n = {
      width: t,
      height: r,
      aspectratio: t / r
    }, i = true;
    return P(e, function(a, o) {
      var s = o.match(cw);
      if (!(!s || !s[1] || !s[2])) {
        var u = s[1], l = s[2].toLowerCase();
        yw(n[l], a, u) || (i = false);
      }
    }), i;
  }
  function yw(e, t, r) {
    return r === "min" ? e >= t : r === "max" ? e <= t : e === t;
  }
  function mw(e, t) {
    return e.join(",") === t.join(",");
  }
  var he = P, Zi = G, Hv = [
    "areaStyle",
    "lineStyle",
    "nodeStyle",
    "linkStyle",
    "chordStyle",
    "label",
    "labelLine"
  ];
  function hu(e) {
    var t = e && e.itemStyle;
    if (t) for (var r = 0, n = Hv.length; r < n; r++) {
      var i = Hv[r], a = t.normal, o = t.emphasis;
      a && a[i] && (e[i] = e[i] || {}, e[i].normal ? ct(e[i].normal, a[i]) : e[i].normal = a[i], a[i] = null), o && o[i] && (e[i] = e[i] || {}, e[i].emphasis ? ct(e[i].emphasis, o[i]) : e[i].emphasis = o[i], o[i] = null);
    }
  }
  function xt(e, t, r) {
    if (e && e[t] && (e[t].normal || e[t].emphasis)) {
      var n = e[t].normal, i = e[t].emphasis;
      n && (r ? (e[t].normal = e[t].emphasis = null, ht(e[t], n)) : e[t] = n), i && (e.emphasis = e.emphasis || {}, e.emphasis[t] = i, i.focus && (e.emphasis.focus = i.focus), i.blurScope && (e.emphasis.blurScope = i.blurScope));
    }
  }
  function Ti(e) {
    xt(e, "itemStyle"), xt(e, "lineStyle"), xt(e, "areaStyle"), xt(e, "label"), xt(e, "labelLine"), xt(e, "upperLabel"), xt(e, "edgeLabel");
  }
  function pt(e, t) {
    var r = Zi(e) && e[t], n = Zi(r) && r.textStyle;
    if (n) for (var i = 0, a = Uh.length; i < a; i++) {
      var o = Uh[i];
      n.hasOwnProperty(o) && (r[o] = n[o]);
    }
  }
  function jt(e) {
    e && (Ti(e), pt(e, "label"), e.emphasis && pt(e.emphasis, "label"));
  }
  function _w(e) {
    if (Zi(e)) {
      hu(e), Ti(e), pt(e, "label"), pt(e, "upperLabel"), pt(e, "edgeLabel"), e.emphasis && (pt(e.emphasis, "label"), pt(e.emphasis, "upperLabel"), pt(e.emphasis, "edgeLabel"));
      var t = e.markPoint;
      t && (hu(t), jt(t));
      var r = e.markLine;
      r && (hu(r), jt(r));
      var n = e.markArea;
      n && jt(n);
      var i = e.data;
      if (e.type === "graph") {
        i = i || e.nodes;
        var a = e.links || e.edges;
        if (a && !Ot(a)) for (var o = 0; o < a.length; o++) jt(a[o]);
        P(e.categories, function(l) {
          Ti(l);
        });
      }
      if (i && !Ot(i)) for (var o = 0; o < i.length; o++) jt(i[o]);
      if (t = e.markPoint, t && t.data) for (var s = t.data, o = 0; o < s.length; o++) jt(s[o]);
      if (r = e.markLine, r && r.data) for (var u = r.data, o = 0; o < u.length; o++) B(u[o]) ? (jt(u[o][0]), jt(u[o][1])) : jt(u[o]);
      e.type === "gauge" ? (pt(e, "axisLabel"), pt(e, "title"), pt(e, "detail")) : e.type === "treemap" ? (xt(e.breadcrumb, "itemStyle"), P(e.levels, function(l) {
        Ti(l);
      })) : e.type === "tree" && Ti(e.leaves);
    }
  }
  function He(e) {
    return B(e) ? e : e ? [
      e
    ] : [];
  }
  function Uv(e) {
    return (B(e) ? e[0] : e) || {};
  }
  function Sw(e, t) {
    he(He(e.series), function(n) {
      Zi(n) && _w(n);
    });
    var r = [
      "xAxis",
      "yAxis",
      "radiusAxis",
      "angleAxis",
      "singleAxis",
      "parallelAxis",
      "radar"
    ];
    t && r.push("valueAxis", "categoryAxis", "logAxis", "timeAxis"), he(r, function(n) {
      he(He(e[n]), function(i) {
        i && (pt(i, "axisLabel"), pt(i.axisPointer, "label"));
      });
    }), he(He(e.parallel), function(n) {
      var i = n && n.parallelAxisDefault;
      pt(i, "axisLabel"), pt(i && i.axisPointer, "label");
    }), he(He(e.calendar), function(n) {
      xt(n, "itemStyle"), pt(n, "dayLabel"), pt(n, "monthLabel"), pt(n, "yearLabel");
    }), he(He(e.radar), function(n) {
      pt(n, "name"), n.name && n.axisName == null && (n.axisName = n.name, delete n.name), n.nameGap != null && n.axisNameGap == null && (n.axisNameGap = n.nameGap, delete n.nameGap);
    }), he(He(e.geo), function(n) {
      Zi(n) && (jt(n), he(He(n.regions), function(i) {
        jt(i);
      }));
    }), he(He(e.timeline), function(n) {
      jt(n), xt(n, "label"), xt(n, "itemStyle"), xt(n, "controlStyle", true);
      var i = n.data;
      B(i) && P(i, function(a) {
        G(a) && (xt(a, "label"), xt(a, "itemStyle"));
      });
    }), he(He(e.toolbox), function(n) {
      xt(n, "iconStyle"), he(n.feature, function(i) {
        xt(i, "iconStyle");
      });
    }), pt(Uv(e.axisPointer), "label"), pt(Uv(e.tooltip).axisPointer, "label");
  }
  function bw(e, t) {
    for (var r = t.split(","), n = e, i = 0; i < r.length && (n = n && n[r[i]], n != null); i++) ;
    return n;
  }
  function ww(e, t, r, n) {
    for (var i = t.split(","), a = e, o, s = 0; s < i.length - 1; s++) o = i[s], a[o] == null && (a[o] = {}), a = a[o];
    a[i[s]] == null && (a[i[s]] = r);
  }
  function Wv(e) {
    e && P(Tw, function(t) {
      t[0] in e && !(t[1] in e) && (e[t[1]] = e[t[0]]);
    });
  }
  var Tw = [
    [
      "x",
      "left"
    ],
    [
      "y",
      "top"
    ],
    [
      "x2",
      "right"
    ],
    [
      "y2",
      "bottom"
    ]
  ], Mw = [
    "grid",
    "geo",
    "parallel",
    "legend",
    "toolbox",
    "title",
    "visualMap",
    "dataZoom",
    "timeline"
  ], vu = [
    [
      "borderRadius",
      "barBorderRadius"
    ],
    [
      "borderColor",
      "barBorderColor"
    ],
    [
      "borderWidth",
      "barBorderWidth"
    ]
  ];
  function li(e) {
    var t = e && e.itemStyle;
    if (t) for (var r = 0; r < vu.length; r++) {
      var n = vu[r][1], i = vu[r][0];
      t[n] != null && (t[i] = t[n]);
    }
  }
  function Yv(e) {
    e && e.alignTo === "edge" && e.margin != null && e.edgeDistance == null && (e.edgeDistance = e.margin);
  }
  function qv(e) {
    e && e.downplay && !e.blur && (e.blur = e.downplay);
  }
  function Cw(e) {
    e && e.focusNodeAdjacency != null && (e.emphasis = e.emphasis || {}, e.emphasis.focus == null && (e.emphasis.focus = "adjacency"));
  }
  function Vg(e, t) {
    if (e) for (var r = 0; r < e.length; r++) t(e[r]), e[r] && Vg(e[r].children, t);
  }
  function Gg(e, t) {
    Sw(e, t), e.series = Lt(e.series), P(e.series, function(r) {
      if (G(r)) {
        var n = r.type;
        if (n === "line") r.clipOverflow != null && (r.clip = r.clipOverflow);
        else if (n === "pie" || n === "gauge") {
          r.clockWise != null && (r.clockwise = r.clockWise), Yv(r.label);
          var i = r.data;
          if (i && !Ot(i)) for (var a = 0; a < i.length; a++) Yv(i[a]);
          r.hoverOffset != null && (r.emphasis = r.emphasis || {}, (r.emphasis.scaleSize = null) && (r.emphasis.scaleSize = r.hoverOffset));
        } else if (n === "gauge") {
          var o = bw(r, "pointer.color");
          o != null && ww(r, "itemStyle.color", o);
        } else if (n === "bar") {
          li(r), li(r.backgroundStyle), li(r.emphasis);
          var i = r.data;
          if (i && !Ot(i)) for (var a = 0; a < i.length; a++) typeof i[a] == "object" && (li(i[a]), li(i[a] && i[a].emphasis));
        } else if (n === "sunburst") {
          var s = r.highlightPolicy;
          s && (r.emphasis = r.emphasis || {}, r.emphasis.focus || (r.emphasis.focus = s)), qv(r), Vg(r.data, qv);
        } else n === "graph" || n === "sankey" ? Cw(r) : n === "map" && (r.mapType && !r.map && (r.map = r.mapType), r.mapLocation && ht(r, r.mapLocation));
        r.hoverAnimation != null && (r.emphasis = r.emphasis || {}, r.emphasis && r.emphasis.scale == null && (r.emphasis.scale = r.hoverAnimation)), Wv(r);
      }
    }), e.dataRange && (e.visualMap = e.dataRange), P(Mw, function(r) {
      var n = e[r];
      n && (B(n) || (n = [
        n
      ]), P(n, function(i) {
        Wv(i);
      }));
    });
  }
  function Dw(e) {
    var t = q();
    e.eachSeries(function(r) {
      var n = r.get("stack");
      if (n) {
        var i = t.get(n) || t.set(n, []), a = r.getData(), o = {
          stackResultDimension: a.getCalculationInfo("stackResultDimension"),
          stackedOverDimension: a.getCalculationInfo("stackedOverDimension"),
          stackedDimension: a.getCalculationInfo("stackedDimension"),
          stackedByDimension: a.getCalculationInfo("stackedByDimension"),
          isStackedByIndex: a.getCalculationInfo("isStackedByIndex"),
          data: a,
          seriesModel: r
        };
        if (!o.stackedDimension || !(o.isStackedByIndex || o.stackedByDimension)) return;
        i.length && a.setCalculationInfo("stackedOnSeries", i[i.length - 1].seriesModel), i.push(o);
      }
    }), t.each(xw);
  }
  function xw(e) {
    P(e, function(t, r) {
      var n = [], i = [
        NaN,
        NaN
      ], a = [
        t.stackResultDimension,
        t.stackedOverDimension
      ], o = t.data, s = t.isStackedByIndex, u = t.seriesModel.get("stackStrategy") || "samesign";
      o.modify(a, function(l, f, h) {
        var c = o.get(t.stackedDimension, h);
        if (isNaN(c)) return i;
        var v, p;
        s ? p = o.getRawIndex(h) : v = o.get(t.stackedByDimension, h);
        for (var y = NaN, g = r - 1; g >= 0; g--) {
          var d = e[g];
          if (s || (p = d.data.rawIndexOf(d.stackedByDimension, v)), p >= 0) {
            var m = d.data.getByRawIndex(d.stackResultDimension, p);
            if (u === "all" || u === "positive" && m > 0 || u === "negative" && m < 0 || u === "samesign" && c >= 0 && m > 0 || u === "samesign" && c <= 0 && m < 0) {
              c = t1(c, m), y = m;
              break;
            }
          }
        }
        return n[0] = c, n[1] = y, n;
      });
    });
  }
  var ls = /* @__PURE__ */ (function() {
    function e(t) {
      this.data = t.data || (t.sourceFormat === Ke ? {} : []), this.sourceFormat = t.sourceFormat || kg, this.seriesLayoutBy = t.seriesLayoutBy || qe, this.startIndex = t.startIndex || 0, this.dimensionsDetectedCount = t.dimensionsDetectedCount, this.metaRawOption = t.metaRawOption;
      var r = this.dimensionsDefine = t.dimensionsDefine;
      if (r) for (var n = 0; n < r.length; n++) {
        var i = r[n];
        i.type == null && Bg(this, n) === Ht.Must && (i.type = "ordinal");
      }
    }
    return e;
  })();
  function Tf(e) {
    return e instanceof ls;
  }
  function gl(e, t, r) {
    r = r || Ug(e);
    var n = t.seriesLayoutBy, i = Iw(e, r, n, t.sourceHeader, t.dimensions), a = new ls({
      data: e,
      sourceFormat: r,
      seriesLayoutBy: n,
      dimensionsDefine: i.dimensionsDefine,
      startIndex: i.startIndex,
      dimensionsDetectedCount: i.dimensionsDetectedCount,
      metaRawOption: Z(t)
    });
    return a;
  }
  function Hg(e) {
    return new ls({
      data: e,
      sourceFormat: Ot(e) ? cr : ue
    });
  }
  function Pw(e) {
    return new ls({
      data: e.data,
      sourceFormat: e.sourceFormat,
      seriesLayoutBy: e.seriesLayoutBy,
      dimensionsDefine: Z(e.dimensionsDefine),
      startIndex: e.startIndex,
      dimensionsDetectedCount: e.dimensionsDetectedCount
    });
  }
  function Ug(e) {
    var t = kg;
    if (Ot(e)) t = cr;
    else if (B(e)) {
      e.length === 0 && (t = Vt);
      for (var r = 0, n = e.length; r < n; r++) {
        var i = e[r];
        if (i != null) {
          if (B(i) || Ot(i)) {
            t = Vt;
            break;
          } else if (G(i)) {
            t = ke;
            break;
          }
        }
      }
    } else if (G(e)) {
      for (var a in e) if (tn(e, a) && Rt(e[a])) {
        t = Ke;
        break;
      }
    }
    return t;
  }
  function Iw(e, t, r, n, i) {
    var a, o;
    if (!e) return {
      dimensionsDefine: Xv(i),
      startIndex: o,
      dimensionsDetectedCount: a
    };
    if (t === Vt) {
      var s = e;
      n === "auto" || n == null ? $v(function(l) {
        l != null && l !== "-" && (V(l) ? o == null && (o = 1) : o = 0);
      }, r, s, 10) : o = lt(n) ? n : n ? 1 : 0, !i && o === 1 && (i = [], $v(function(l, f) {
        i[f] = l != null ? l + "" : "";
      }, r, s, 1 / 0)), a = i ? i.length : r === Un ? s.length : s[0] ? s[0].length : null;
    } else if (t === ke) i || (i = Aw(e));
    else if (t === Ke) i || (i = [], P(e, function(l, f) {
      i.push(f);
    }));
    else if (t === ue) {
      var u = Gn(e[0]);
      a = B(u) && u.length || 1;
    }
    return {
      startIndex: o,
      dimensionsDefine: Xv(i),
      dimensionsDetectedCount: a
    };
  }
  function Aw(e) {
    for (var t = 0, r; t < e.length && !(r = e[t++]); ) ;
    if (r) return K(r);
  }
  function Xv(e) {
    if (e) {
      var t = q();
      return F(e, function(r, n) {
        r = G(r) ? r : {
          name: r
        };
        var i = {
          name: r.name,
          displayName: r.displayName,
          type: r.type
        };
        if (i.name == null) return i;
        i.name += "", i.displayName == null && (i.displayName = i.name);
        var a = t.get(i.name);
        return a ? i.name += "-" + a.count++ : t.set(i.name, {
          count: 1
        }), i;
      });
    }
  }
  function $v(e, t, r, n) {
    if (t === Un) for (var i = 0; i < r.length && i < n; i++) e(r[i] ? r[i][0] : null, i);
    else for (var a = r[0] || [], i = 0; i < a.length && i < n; i++) e(a[i], i);
  }
  function Wg(e) {
    var t = e.sourceFormat;
    return t === ke || t === Ke;
  }
  var Nr, Fr, Br, Zv, Kv, Yg = (function() {
    function e(t, r) {
      var n = Tf(t) ? t : Hg(t);
      this._source = n;
      var i = this._data = n.data;
      n.sourceFormat === cr && (this._offset = 0, this._dimSize = r, this._data = i), Kv(this, i, n);
    }
    return e.prototype.getSource = function() {
      return this._source;
    }, e.prototype.count = function() {
      return 0;
    }, e.prototype.getItem = function(t, r) {
    }, e.prototype.appendData = function(t) {
    }, e.prototype.clean = function() {
    }, e.protoInitialize = (function() {
      var t = e.prototype;
      t.pure = false, t.persistent = true;
    })(), e.internalField = (function() {
      var t;
      Kv = function(o, s, u) {
        var l = u.sourceFormat, f = u.seriesLayoutBy, h = u.startIndex, c = u.dimensionsDefine, v = Zv[Mf(l, f)];
        if (O(o, v), l === cr) o.getItem = r, o.count = i, o.fillStorage = n;
        else {
          var p = qg(l, f);
          o.getItem = ut(p, null, s, h, c);
          var y = Xg(l, f);
          o.count = ut(y, null, s, h, c);
        }
      };
      var r = function(o, s) {
        o = o - this._offset, s = s || [];
        for (var u = this._data, l = this._dimSize, f = l * o, h = 0; h < l; h++) s[h] = u[f + h];
        return s;
      }, n = function(o, s, u, l) {
        for (var f = this._data, h = this._dimSize, c = 0; c < h; c++) {
          for (var v = l[c], p = v[0] == null ? 1 / 0 : v[0], y = v[1] == null ? -1 / 0 : v[1], g = s - o, d = u[c], m = 0; m < g; m++) {
            var _ = f[m * h + c];
            d[o + m] = _, _ < p && (p = _), _ > y && (y = _);
          }
          v[0] = p, v[1] = y;
        }
      }, i = function() {
        return this._data ? this._data.length / this._dimSize : 0;
      };
      Zv = (t = {}, t[Vt + "_" + qe] = {
        pure: true,
        appendData: a
      }, t[Vt + "_" + Un] = {
        pure: true,
        appendData: function() {
          throw new Error('Do not support appendData when set seriesLayoutBy: "row".');
        }
      }, t[ke] = {
        pure: true,
        appendData: a
      }, t[Ke] = {
        pure: true,
        appendData: function(o) {
          var s = this._data;
          P(o, function(u, l) {
            for (var f = s[l] || (s[l] = []), h = 0; h < (u || []).length; h++) f.push(u[h]);
          });
        }
      }, t[ue] = {
        appendData: a
      }, t[cr] = {
        persistent: false,
        pure: true,
        appendData: function(o) {
          this._data = o;
        },
        clean: function() {
          this._offset += this.count(), this._data = null;
        }
      }, t);
      function a(o) {
        for (var s = 0; s < o.length; s++) this._data.push(o[s]);
      }
    })(), e;
  })(), jv = function(e, t, r, n) {
    return e[n];
  }, Ew = (Nr = {}, Nr[Vt + "_" + qe] = function(e, t, r, n) {
    return e[n + t];
  }, Nr[Vt + "_" + Un] = function(e, t, r, n, i) {
    n += t;
    for (var a = i || [], o = e, s = 0; s < o.length; s++) {
      var u = o[s];
      a[s] = u ? u[n] : null;
    }
    return a;
  }, Nr[ke] = jv, Nr[Ke] = function(e, t, r, n, i) {
    for (var a = i || [], o = 0; o < r.length; o++) {
      var s = r[o].name, u = e[s];
      a[o] = u ? u[n] : null;
    }
    return a;
  }, Nr[ue] = jv, Nr);
  function qg(e, t) {
    var r = Ew[Mf(e, t)];
    return r;
  }
  var Qv = function(e, t, r) {
    return e.length;
  }, Lw = (Fr = {}, Fr[Vt + "_" + qe] = function(e, t, r) {
    return Math.max(0, e.length - t);
  }, Fr[Vt + "_" + Un] = function(e, t, r) {
    var n = e[0];
    return n ? Math.max(0, n.length - t) : 0;
  }, Fr[ke] = Qv, Fr[Ke] = function(e, t, r) {
    var n = r[0].name, i = e[n];
    return i ? i.length : 0;
  }, Fr[ue] = Qv, Fr);
  function Xg(e, t) {
    var r = Lw[Mf(e, t)];
    return r;
  }
  var cu = function(e, t, r) {
    return e[t];
  }, Rw = (Br = {}, Br[Vt] = cu, Br[ke] = function(e, t, r) {
    return e[r];
  }, Br[Ke] = cu, Br[ue] = function(e, t, r) {
    var n = Gn(e);
    return n instanceof Array ? n[t] : n;
  }, Br[cr] = cu, Br);
  function $g(e) {
    var t = Rw[e];
    return t;
  }
  function Mf(e, t) {
    return e === Vt ? e + "_" + t : e;
  }
  function Nn(e, t, r) {
    if (e) {
      var n = e.getRawDataItem(t);
      if (n != null) {
        var i = e.getStore(), a = i.getSource().sourceFormat;
        if (r != null) {
          var o = e.getDimensionIndex(r), s = i.getDimensionProperty(o);
          return $g(a)(n, o, s);
        } else {
          var u = n;
          return a === ue && (u = Gn(n)), u;
        }
      }
    }
  }
  var Ow = /\{@(.+?)\}/g, Zg = (function() {
    function e() {
    }
    return e.prototype.getDataParams = function(t, r) {
      var n = this.getData(r), i = this.getRawValue(t, r), a = n.getRawIndex(t), o = n.getName(t), s = n.getRawDataItem(t), u = n.getItemVisual(t, "style"), l = u && u[n.getItemVisual(t, "drawType") || "fill"], f = u && u.stroke, h = this.mainType, c = h === "series", v = n.userOutput && n.userOutput.get();
      return {
        componentType: h,
        componentSubType: this.subType,
        componentIndex: this.componentIndex,
        seriesType: c ? this.subType : null,
        seriesIndex: this.seriesIndex,
        seriesId: c ? this.id : null,
        seriesName: c ? this.name : null,
        name: o,
        dataIndex: a,
        data: s,
        dataType: r,
        value: i,
        color: l,
        borderColor: f,
        dimensionNames: v ? v.fullDimensions : null,
        encode: v ? v.encode : null,
        $vars: [
          "seriesName",
          "name",
          "value"
        ]
      };
    }, e.prototype.getFormattedLabel = function(t, r, n, i, a, o) {
      r = r || "normal";
      var s = this.getData(n), u = this.getDataParams(t, n);
      if (o && (u.value = o.interpolatedValue), i != null && B(u.value) && (u.value = u.value[i]), !a) {
        var l = s.getItemModel(t);
        a = l.get(r === "normal" ? [
          "label",
          "formatter"
        ] : [
          r,
          "label",
          "formatter"
        ]);
      }
      if (Y(a)) return u.status = r, u.dimensionIndex = i, a(u);
      if (V(a)) {
        var f = Ag(a, u);
        return f.replace(Ow, function(h, c) {
          var v = c.length, p = c;
          p.charAt(0) === "[" && p.charAt(v - 1) === "]" && (p = +p.slice(1, v - 1));
          var y = Nn(s, t, p);
          if (o && B(o.interpolatedValue)) {
            var g = s.getDimensionIndex(p);
            g >= 0 && (y = o.interpolatedValue[g]);
          }
          return y != null ? y + "" : "";
        });
      }
    }, e.prototype.getRawValue = function(t, r) {
      return Nn(this.getData(r), t);
    }, e.prototype.formatTooltip = function(t, r, n) {
    }, e;
  })();
  K2 = function(e) {
    var t, r;
    return G(e) ? e.type && (r = e) : t = e, {
      text: t,
      frag: r
    };
  };
  function ki(e) {
    return new kw(e);
  }
  var kw = (function() {
    function e(t) {
      t = t || {}, this._reset = t.reset, this._plan = t.plan, this._count = t.count, this._onDirty = t.onDirty, this._dirty = true;
    }
    return e.prototype.perform = function(t) {
      var r = this._upstream, n = t && t.skip;
      if (this._dirty && r) {
        var i = this.context;
        i.data = i.outputData = r.context.outputData;
      }
      this.__pipeline && (this.__pipeline.currentTask = this);
      var a;
      this._plan && !n && (a = this._plan(this.context));
      var o = f(this._modBy), s = this._modDataCount || 0, u = f(t && t.modBy), l = t && t.modDataCount || 0;
      (o !== u || s !== l) && (a = "reset");
      function f(m) {
        return !(m >= 1) && (m = 1), m;
      }
      var h;
      (this._dirty || a === "reset") && (this._dirty = false, h = this._doReset(n)), this._modBy = u, this._modDataCount = l;
      var c = t && t.step;
      if (r ? this._dueEnd = r._outputDueEnd : this._dueEnd = this._count ? this._count(this.context) : 1 / 0, this._progress) {
        var v = this._dueIndex, p = Math.min(c != null ? this._dueIndex + c : 1 / 0, this._dueEnd);
        if (!n && (h || v < p)) {
          var y = this._progress;
          if (B(y)) for (var g = 0; g < y.length; g++) this._doProgress(y[g], v, p, u, l);
          else this._doProgress(y, v, p, u, l);
        }
        this._dueIndex = p;
        var d = this._settedOutputEnd != null ? this._settedOutputEnd : p;
        this._outputDueEnd = d;
      } else this._dueIndex = this._outputDueEnd = this._settedOutputEnd != null ? this._settedOutputEnd : this._dueEnd;
      return this.unfinished();
    }, e.prototype.dirty = function() {
      this._dirty = true, this._onDirty && this._onDirty(this.context);
    }, e.prototype._doProgress = function(t, r, n, i, a) {
      Jv.reset(r, n, i, a), this._callingProgress = t, this._callingProgress({
        start: r,
        end: n,
        count: n - r,
        next: Jv.next
      }, this.context);
    }, e.prototype._doReset = function(t) {
      this._dueIndex = this._outputDueEnd = this._dueEnd = 0, this._settedOutputEnd = null;
      var r, n;
      !t && this._reset && (r = this._reset(this.context), r && r.progress && (n = r.forceFirstProgress, r = r.progress), B(r) && !r.length && (r = null)), this._progress = r, this._modBy = this._modDataCount = null;
      var i = this._downstream;
      return i && i.dirty(), n;
    }, e.prototype.unfinished = function() {
      return this._progress && this._dueIndex < this._dueEnd;
    }, e.prototype.pipe = function(t) {
      (this._downstream !== t || this._dirty) && (this._downstream = t, t._upstream = this, t.dirty());
    }, e.prototype.dispose = function() {
      this._disposed || (this._upstream && (this._upstream._downstream = null), this._downstream && (this._downstream._upstream = null), this._dirty = false, this._disposed = true);
    }, e.prototype.getUpstream = function() {
      return this._upstream;
    }, e.prototype.getDownstream = function() {
      return this._downstream;
    }, e.prototype.setOutputEnd = function(t) {
      this._outputDueEnd = this._settedOutputEnd = t;
    }, e;
  })(), Jv = /* @__PURE__ */ (function() {
    var e, t, r, n, i, a = {
      reset: function(u, l, f, h) {
        t = u, e = l, r = f, n = h, i = Math.ceil(n / r), a.next = r > 1 && n > 0 ? s : o;
      }
    };
    return a;
    function o() {
      return t < e ? t++ : null;
    }
    function s() {
      var u = t % i * r + Math.ceil(t / i), l = t >= e ? null : u < n ? u : t;
      return t++, l;
    }
  })();
  function eo(e, t) {
    var r = t && t.type;
    return r === "ordinal" ? e : (r === "time" && !lt(e) && e != null && e !== "-" && (e = +ie(e)), e == null || e === "" ? NaN : Number(e));
  }
  q({
    number: function(e) {
      return parseFloat(e);
    },
    time: function(e) {
      return +ie(e);
    },
    trim: function(e) {
      return V(e) ? Ie(e) : e;
    }
  });
  var Nw = (function() {
    function e(t, r) {
      var n = t === "desc";
      this._resultLT = n ? 1 : -1, r == null && (r = n ? "min" : "max"), this._incomparable = r === "min" ? -1 / 0 : 1 / 0;
    }
    return e.prototype.evaluate = function(t, r) {
      var n = lt(t) ? t : Wi(t), i = lt(r) ? r : Wi(r), a = isNaN(n), o = isNaN(i);
      if (a && (n = this._incomparable), o && (i = this._incomparable), a && o) {
        var s = V(t), u = V(r);
        s && (n = u ? t : 0), u && (i = s ? r : 0);
      }
      return n < i ? this._resultLT : n > i ? -this._resultLT : 0;
    }, e;
  })(), Fw = (function() {
    function e() {
    }
    return e.prototype.getRawData = function() {
      throw new Error("not supported");
    }, e.prototype.getRawDataItem = function(t) {
      throw new Error("not supported");
    }, e.prototype.cloneRawData = function() {
    }, e.prototype.getDimensionInfo = function(t) {
    }, e.prototype.cloneAllDimensionInfo = function() {
    }, e.prototype.count = function() {
    }, e.prototype.retrieveValue = function(t, r) {
    }, e.prototype.retrieveValueFromItem = function(t, r) {
    }, e.prototype.convertValue = function(t, r) {
      return eo(t, r);
    }, e;
  })();
  function Bw(e, t) {
    var r = new Fw(), n = e.data, i = r.sourceFormat = e.sourceFormat, a = e.startIndex, o = "";
    e.seriesLayoutBy !== qe && Wt(o);
    var s = [], u = {}, l = e.dimensionsDefine;
    if (l) P(l, function(y, g) {
      var d = y.name, m = {
        index: g,
        name: d,
        displayName: y.displayName
      };
      if (s.push(m), d != null) {
        var _ = "";
        tn(u, d) && Wt(_), u[d] = m;
      }
    });
    else for (var f = 0; f < e.dimensionsDetectedCount; f++) s.push({
      index: f
    });
    var h = qg(i, qe);
    t.__isBuiltIn && (r.getRawDataItem = function(y) {
      return h(n, a, s, y);
    }, r.getRawData = ut(zw, null, e)), r.cloneRawData = ut(Vw, null, e);
    var c = Xg(i, qe);
    r.count = ut(c, null, n, a, s);
    var v = $g(i);
    r.retrieveValue = function(y, g) {
      var d = h(n, a, s, y);
      return p(d, g);
    };
    var p = r.retrieveValueFromItem = function(y, g) {
      if (y != null) {
        var d = s[g];
        if (d) return v(y, g, d.name);
      }
    };
    return r.getDimensionInfo = ut(Gw, null, s, u), r.cloneAllDimensionInfo = ut(Hw, null, s), r;
  }
  function zw(e) {
    var t = e.sourceFormat;
    if (!Cf(t)) {
      var r = "";
      Wt(r);
    }
    return e.data;
  }
  function Vw(e) {
    var t = e.sourceFormat, r = e.data;
    if (!Cf(t)) {
      var n = "";
      Wt(n);
    }
    if (t === Vt) {
      for (var i = [], a = 0, o = r.length; a < o; a++) i.push(r[a].slice());
      return i;
    } else if (t === ke) {
      for (var i = [], a = 0, o = r.length; a < o; a++) i.push(O({}, r[a]));
      return i;
    }
  }
  function Gw(e, t, r) {
    if (r != null) {
      if (lt(r) || !isNaN(r) && !tn(t, r)) return e[r];
      if (tn(t, r)) return t[r];
    }
  }
  function Hw(e) {
    return Z(e);
  }
  var Kg = q();
  function Uw(e) {
    e = Z(e);
    var t = e.type, r = "";
    t || Wt(r);
    var n = t.split(":");
    n.length !== 2 && Wt(r);
    var i = false;
    n[0] === "echarts" && (t = n[1], i = true), e.__isBuiltIn = i, Kg.set(t, e);
  }
  function Ww(e, t, r) {
    var n = Lt(e), i = n.length, a = "";
    i || Wt(a);
    for (var o = 0, s = i; o < s; o++) {
      var u = n[o];
      t = Yw(u, t), o !== s - 1 && (t.length = Math.max(t.length, 1));
    }
    return t;
  }
  function Yw(e, t, r, n) {
    var i = "";
    t.length || Wt(i), G(e) || Wt(i);
    var a = e.type, o = Kg.get(a);
    o || Wt(i);
    var s = F(t, function(l) {
      return Bw(l, o);
    }), u = Lt(o.transform({
      upstream: s[0],
      upstreamList: s,
      config: Z(e.config)
    }));
    return F(u, function(l, f) {
      var h = "";
      G(l) || Wt(h), l.data || Wt(h);
      var c = Ug(l.data);
      Cf(c) || Wt(h);
      var v, p = t[0];
      if (p && f === 0 && !l.dimensions) {
        var y = p.startIndex;
        y && (l.data = p.data.slice(0, y).concat(l.data)), v = {
          seriesLayoutBy: qe,
          sourceHeader: y,
          dimensions: p.metaRawOption.dimensions
        };
      } else v = {
        seriesLayoutBy: qe,
        sourceHeader: 0,
        dimensions: l.dimensions
      };
      return gl(l.data, v, null);
    });
  }
  function Cf(e) {
    return e === Vt || e === ke;
  }
  var fs = "undefined", qw = typeof Uint32Array === fs ? Array : Uint32Array, Xw = typeof Uint16Array === fs ? Array : Uint16Array, jg = typeof Int32Array === fs ? Array : Int32Array, tc = typeof Float64Array === fs ? Array : Float64Array, Qg = {
    float: tc,
    int: jg,
    ordinal: Array,
    number: Array,
    time: tc
  }, pu;
  function yn(e) {
    return e > 65535 ? qw : Xw;
  }
  function mn() {
    return [
      1 / 0,
      -1 / 0
    ];
  }
  function $w(e) {
    var t = e.constructor;
    return t === Array ? e.slice() : new t(e);
  }
  function ec(e, t, r, n, i) {
    var a = Qg[r || "float"];
    if (i) {
      var o = e[t], s = o && o.length;
      if (s !== n) {
        for (var u = new a(n), l = 0; l < s; l++) u[l] = o[l];
        e[t] = u;
      }
    } else e[t] = new a(n);
  }
  var yl = (function() {
    function e() {
      this._chunks = [], this._rawExtent = [], this._extent = [], this._count = 0, this._rawCount = 0, this._calcDimNameToIdx = q();
    }
    return e.prototype.initData = function(t, r, n) {
      this._provider = t, this._chunks = [], this._indices = null, this.getRawIndex = this._getRawIdxIdentity;
      var i = t.getSource(), a = this.defaultDimValueGetter = pu[i.sourceFormat];
      this._dimValueGetter = n || a, this._rawExtent = [], Wg(i), this._dimensions = F(r, function(o) {
        return {
          type: o.type,
          property: o.property
        };
      }), this._initDataFromProvider(0, t.count());
    }, e.prototype.getProvider = function() {
      return this._provider;
    }, e.prototype.getSource = function() {
      return this._provider.getSource();
    }, e.prototype.ensureCalculationDimension = function(t, r) {
      var n = this._calcDimNameToIdx, i = this._dimensions, a = n.get(t);
      if (a != null) {
        if (i[a].type === r) return a;
      } else a = i.length;
      return i[a] = {
        type: r
      }, n.set(t, a), this._chunks[a] = new Qg[r || "float"](this._rawCount), this._rawExtent[a] = mn(), a;
    }, e.prototype.collectOrdinalMeta = function(t, r) {
      var n = this._chunks[t], i = this._dimensions[t], a = this._rawExtent, o = i.ordinalOffset || 0, s = n.length;
      o === 0 && (a[t] = mn());
      for (var u = a[t], l = o; l < s; l++) {
        var f = n[l] = r.parseAndCollect(n[l]);
        isNaN(f) || (u[0] = Math.min(f, u[0]), u[1] = Math.max(f, u[1]));
      }
      i.ordinalMeta = r, i.ordinalOffset = s, i.type = "ordinal";
    }, e.prototype.getOrdinalMeta = function(t) {
      var r = this._dimensions[t], n = r.ordinalMeta;
      return n;
    }, e.prototype.getDimensionProperty = function(t) {
      var r = this._dimensions[t];
      return r && r.property;
    }, e.prototype.appendData = function(t) {
      var r = this._provider, n = this.count();
      r.appendData(t);
      var i = r.count();
      return r.persistent || (i += n), n < i && this._initDataFromProvider(n, i, true), [
        n,
        i
      ];
    }, e.prototype.appendValues = function(t, r) {
      for (var n = this._chunks, i = this._dimensions, a = i.length, o = this._rawExtent, s = this.count(), u = s + Math.max(t.length, r || 0), l = 0; l < a; l++) {
        var f = i[l];
        ec(n, l, f.type, u, true);
      }
      for (var h = [], c = s; c < u; c++) for (var v = c - s, p = 0; p < a; p++) {
        var f = i[p], y = pu.arrayRows.call(this, t[v] || h, f.property, v, p);
        n[p][c] = y;
        var g = o[p];
        y < g[0] && (g[0] = y), y > g[1] && (g[1] = y);
      }
      return this._rawCount = this._count = u, {
        start: s,
        end: u
      };
    }, e.prototype._initDataFromProvider = function(t, r, n) {
      for (var i = this._provider, a = this._chunks, o = this._dimensions, s = o.length, u = this._rawExtent, l = F(o, function(m) {
        return m.property;
      }), f = 0; f < s; f++) {
        var h = o[f];
        u[f] || (u[f] = mn()), ec(a, f, h.type, r, n);
      }
      if (i.fillStorage) i.fillStorage(t, r, a, u);
      else for (var c = [], v = t; v < r; v++) {
        c = i.getItem(v, c);
        for (var p = 0; p < s; p++) {
          var y = a[p], g = this._dimValueGetter(c, l[p], v, p);
          y[v] = g;
          var d = u[p];
          g < d[0] && (d[0] = g), g > d[1] && (d[1] = g);
        }
      }
      !i.persistent && i.clean && i.clean(), this._rawCount = this._count = r, this._extent = [];
    }, e.prototype.count = function() {
      return this._count;
    }, e.prototype.get = function(t, r) {
      if (!(r >= 0 && r < this._count)) return NaN;
      var n = this._chunks[t];
      return n ? n[this.getRawIndex(r)] : NaN;
    }, e.prototype.getValues = function(t, r) {
      var n = [], i = [];
      if (r == null) {
        r = t, t = [];
        for (var a = 0; a < this._dimensions.length; a++) i.push(a);
      } else i = t;
      for (var a = 0, o = i.length; a < o; a++) n.push(this.get(i[a], r));
      return n;
    }, e.prototype.getByRawIndex = function(t, r) {
      if (!(r >= 0 && r < this._rawCount)) return NaN;
      var n = this._chunks[t];
      return n ? n[r] : NaN;
    }, e.prototype.getSum = function(t) {
      var r = this._chunks[t], n = 0;
      if (r) for (var i = 0, a = this.count(); i < a; i++) {
        var o = this.get(t, i);
        isNaN(o) || (n += o);
      }
      return n;
    }, e.prototype.getMedian = function(t) {
      var r = [];
      this.each([
        t
      ], function(a) {
        isNaN(a) || r.push(a);
      });
      var n = r.sort(function(a, o) {
        return a - o;
      }), i = this.count();
      return i === 0 ? 0 : i % 2 === 1 ? n[(i - 1) / 2] : (n[i / 2] + n[i / 2 - 1]) / 2;
    }, e.prototype.indexOfRawIndex = function(t) {
      if (t >= this._rawCount || t < 0) return -1;
      if (!this._indices) return t;
      var r = this._indices, n = r[t];
      if (n != null && n < this._count && n === t) return t;
      for (var i = 0, a = this._count - 1; i <= a; ) {
        var o = (i + a) / 2 | 0;
        if (r[o] < t) i = o + 1;
        else if (r[o] > t) a = o - 1;
        else return o;
      }
      return -1;
    }, e.prototype.indicesOfNearest = function(t, r, n) {
      var i = this._chunks, a = i[t], o = [];
      if (!a) return o;
      n == null && (n = 1 / 0);
      for (var s = 1 / 0, u = -1, l = 0, f = 0, h = this.count(); f < h; f++) {
        var c = this.getRawIndex(f), v = r - a[c], p = Math.abs(v);
        p <= n && ((p < s || p === s && v >= 0 && u < 0) && (s = p, u = v, l = 0), v === u && (o[l++] = f));
      }
      return o.length = l, o;
    }, e.prototype.getIndices = function() {
      var t, r = this._indices;
      if (r) {
        var n = r.constructor, i = this._count;
        if (n === Array) {
          t = new n(i);
          for (var a = 0; a < i; a++) t[a] = r[a];
        } else t = new n(r.buffer, 0, i);
      } else {
        var n = yn(this._rawCount);
        t = new n(this.count());
        for (var a = 0; a < t.length; a++) t[a] = a;
      }
      return t;
    }, e.prototype.filter = function(t, r) {
      if (!this._count) return this;
      for (var n = this.clone(), i = n.count(), a = yn(n._rawCount), o = new a(i), s = [], u = t.length, l = 0, f = t[0], h = n._chunks, c = 0; c < i; c++) {
        var v = void 0, p = n.getRawIndex(c);
        if (u === 0) v = r(c);
        else if (u === 1) {
          var y = h[f][p];
          v = r(y, c);
        } else {
          for (var g = 0; g < u; g++) s[g] = h[t[g]][p];
          s[g] = c, v = r.apply(null, s);
        }
        v && (o[l++] = p);
      }
      return l < i && (n._indices = o), n._count = l, n._extent = [], n._updateGetRawIdx(), n;
    }, e.prototype.selectRange = function(t) {
      var r = this.clone(), n = r._count;
      if (!n) return this;
      var i = K(t), a = i.length;
      if (!a) return this;
      var o = r.count(), s = yn(r._rawCount), u = new s(o), l = 0, f = i[0], h = t[f][0], c = t[f][1], v = r._chunks, p = false;
      if (!r._indices) {
        var y = 0;
        if (a === 1) {
          for (var g = v[i[0]], d = 0; d < n; d++) {
            var m = g[d];
            (m >= h && m <= c || isNaN(m)) && (u[l++] = y), y++;
          }
          p = true;
        } else if (a === 2) {
          for (var g = v[i[0]], _ = v[i[1]], S = t[i[1]][0], T = t[i[1]][1], d = 0; d < n; d++) {
            var m = g[d], b = _[d];
            (m >= h && m <= c || isNaN(m)) && (b >= S && b <= T || isNaN(b)) && (u[l++] = y), y++;
          }
          p = true;
        }
      }
      if (!p) if (a === 1) for (var d = 0; d < o; d++) {
        var w = r.getRawIndex(d), m = v[i[0]][w];
        (m >= h && m <= c || isNaN(m)) && (u[l++] = w);
      }
      else for (var d = 0; d < o; d++) {
        for (var D = true, w = r.getRawIndex(d), C = 0; C < a; C++) {
          var M = i[C], m = v[M][w];
          (m < t[M][0] || m > t[M][1]) && (D = false);
        }
        D && (u[l++] = r.getRawIndex(d));
      }
      return l < o && (r._indices = u), r._count = l, r._extent = [], r._updateGetRawIdx(), r;
    }, e.prototype.map = function(t, r) {
      var n = this.clone(t);
      return this._updateDims(n, t, r), n;
    }, e.prototype.modify = function(t, r) {
      this._updateDims(this, t, r);
    }, e.prototype._updateDims = function(t, r, n) {
      for (var i = t._chunks, a = [], o = r.length, s = t.count(), u = [], l = t._rawExtent, f = 0; f < r.length; f++) l[r[f]] = mn();
      for (var h = 0; h < s; h++) {
        for (var c = t.getRawIndex(h), v = 0; v < o; v++) u[v] = i[r[v]][c];
        u[o] = h;
        var p = n && n.apply(null, u);
        if (p != null) {
          typeof p != "object" && (a[0] = p, p = a);
          for (var f = 0; f < p.length; f++) {
            var y = r[f], g = p[f], d = l[y], m = i[y];
            m && (m[c] = g), g < d[0] && (d[0] = g), g > d[1] && (d[1] = g);
          }
        }
      }
    }, e.prototype.lttbDownSample = function(t, r) {
      var n = this.clone([
        t
      ], true), i = n._chunks, a = i[t], o = this.count(), s = 0, u = Math.floor(1 / r), l = this.getRawIndex(0), f, h, c, v = new (yn(this._rawCount))(Math.min((Math.ceil(o / u) + 2) * 2, o));
      v[s++] = l;
      for (var p = 1; p < o - 1; p += u) {
        for (var y = Math.min(p + u, o - 1), g = Math.min(p + u * 2, o), d = (g + y) / 2, m = 0, _ = y; _ < g; _++) {
          var S = this.getRawIndex(_), T = a[S];
          isNaN(T) || (m += T);
        }
        m /= g - y;
        var b = p, w = Math.min(p + u, o), D = p - 1, C = a[l];
        f = -1, c = b;
        for (var M = -1, x = 0, _ = b; _ < w; _++) {
          var S = this.getRawIndex(_), T = a[S];
          if (isNaN(T)) {
            x++, M < 0 && (M = S);
            continue;
          }
          h = Math.abs((D - d) * (T - C) - (D - _) * (m - C)), h > f && (f = h, c = S);
        }
        x > 0 && x < w - b && (v[s++] = Math.min(M, c), c = Math.max(M, c)), v[s++] = c, l = c;
      }
      return v[s++] = this.getRawIndex(o - 1), n._count = s, n._indices = v, n.getRawIndex = this._getRawIdx, n;
    }, e.prototype.minmaxDownSample = function(t, r) {
      for (var n = this.clone([
        t
      ], true), i = n._chunks, a = Math.floor(1 / r), o = i[t], s = this.count(), u = new (yn(this._rawCount))(Math.ceil(s / a) * 2), l = 0, f = 0; f < s; f += a) {
        var h = f, c = o[this.getRawIndex(h)], v = f, p = o[this.getRawIndex(v)], y = a;
        f + a > s && (y = s - f);
        for (var g = 0; g < y; g++) {
          var d = this.getRawIndex(f + g), m = o[d];
          m < c && (c = m, h = f + g), m > p && (p = m, v = f + g);
        }
        var _ = this.getRawIndex(h), S = this.getRawIndex(v);
        h < v ? (u[l++] = _, u[l++] = S) : (u[l++] = S, u[l++] = _);
      }
      return n._count = l, n._indices = u, n._updateGetRawIdx(), n;
    }, e.prototype.downSample = function(t, r, n, i) {
      for (var a = this.clone([
        t
      ], true), o = a._chunks, s = [], u = Math.floor(1 / r), l = o[t], f = this.count(), h = a._rawExtent[t] = mn(), c = new (yn(this._rawCount))(Math.ceil(f / u)), v = 0, p = 0; p < f; p += u) {
        u > f - p && (u = f - p, s.length = u);
        for (var y = 0; y < u; y++) {
          var g = this.getRawIndex(p + y);
          s[y] = l[g];
        }
        var d = n(s), m = this.getRawIndex(Math.min(p + i(s, d) || 0, f - 1));
        l[m] = d, d < h[0] && (h[0] = d), d > h[1] && (h[1] = d), c[v++] = m;
      }
      return a._count = v, a._indices = c, a._updateGetRawIdx(), a;
    }, e.prototype.each = function(t, r) {
      if (this._count) for (var n = t.length, i = this._chunks, a = 0, o = this.count(); a < o; a++) {
        var s = this.getRawIndex(a);
        switch (n) {
          case 0:
            r(a);
            break;
          case 1:
            r(i[t[0]][s], a);
            break;
          case 2:
            r(i[t[0]][s], i[t[1]][s], a);
            break;
          default:
            for (var u = 0, l = []; u < n; u++) l[u] = i[t[u]][s];
            l[u] = a, r.apply(null, l);
        }
      }
    }, e.prototype.getDataExtent = function(t) {
      var r = this._chunks[t], n = mn();
      if (!r) return n;
      var i = this.count(), a = !this._indices, o;
      if (a) return this._rawExtent[t].slice();
      if (o = this._extent[t], o) return o.slice();
      o = n;
      for (var s = o[0], u = o[1], l = 0; l < i; l++) {
        var f = this.getRawIndex(l), h = r[f];
        h < s && (s = h), h > u && (u = h);
      }
      return o = [
        s,
        u
      ], this._extent[t] = o, o;
    }, e.prototype.getRawDataItem = function(t) {
      var r = this.getRawIndex(t);
      if (this._provider.persistent) return this._provider.getItem(r);
      for (var n = [], i = this._chunks, a = 0; a < i.length; a++) n.push(i[a][r]);
      return n;
    }, e.prototype.clone = function(t, r) {
      var n = new e(), i = this._chunks, a = t && Le(t, function(s, u) {
        return s[u] = true, s;
      }, {});
      if (a) for (var o = 0; o < i.length; o++) n._chunks[o] = a[o] ? $w(i[o]) : i[o];
      else n._chunks = i;
      return this._copyCommonProps(n), r || (n._indices = this._cloneIndices()), n._updateGetRawIdx(), n;
    }, e.prototype._copyCommonProps = function(t) {
      t._count = this._count, t._rawCount = this._rawCount, t._provider = this._provider, t._dimensions = this._dimensions, t._extent = Z(this._extent), t._rawExtent = Z(this._rawExtent);
    }, e.prototype._cloneIndices = function() {
      if (this._indices) {
        var t = this._indices.constructor, r = void 0;
        if (t === Array) {
          var n = this._indices.length;
          r = new t(n);
          for (var i = 0; i < n; i++) r[i] = this._indices[i];
        } else r = new t(this._indices);
        return r;
      }
      return null;
    }, e.prototype._getRawIdxIdentity = function(t) {
      return t;
    }, e.prototype._getRawIdx = function(t) {
      return t < this._count && t >= 0 ? this._indices[t] : -1;
    }, e.prototype._updateGetRawIdx = function() {
      this.getRawIndex = this._indices ? this._getRawIdx : this._getRawIdxIdentity;
    }, e.internalField = (function() {
      function t(r, n, i, a) {
        return eo(r[a], this._dimensions[a]);
      }
      pu = {
        arrayRows: t,
        objectRows: function(r, n, i, a) {
          return eo(r[n], this._dimensions[a]);
        },
        keyedColumns: t,
        original: function(r, n, i, a) {
          var o = r && (r.value == null ? r : r.value);
          return eo(o instanceof Array ? o[a] : o, this._dimensions[a]);
        },
        typedArray: function(r, n, i, a) {
          return r[a];
        }
      };
    })(), e;
  })(), Zw = (function() {
    function e(t) {
      this._sourceList = [], this._storeList = [], this._upstreamSignList = [], this._versionSignBase = 0, this._dirty = true, this._sourceHost = t;
    }
    return e.prototype.dirty = function() {
      this._setLocalSource([], []), this._storeList = [], this._dirty = true;
    }, e.prototype._setLocalSource = function(t, r) {
      this._sourceList = t, this._upstreamSignList = r, this._versionSignBase++, this._versionSignBase > 9e10 && (this._versionSignBase = 0);
    }, e.prototype._getVersionSign = function() {
      return this._sourceHost.uid + "_" + this._versionSignBase;
    }, e.prototype.prepareSource = function() {
      this._isDirty() && (this._createSource(), this._dirty = false);
    }, e.prototype._createSource = function() {
      this._setLocalSource([], []);
      var t = this._sourceHost, r = this._getUpstreamSourceManagers(), n = !!r.length, i, a;
      if (Ea(t)) {
        var o = t, s = void 0, u = void 0, l = void 0;
        if (n) {
          var f = r[0];
          f.prepareSource(), l = f.getSource(), s = l.data, u = l.sourceFormat, a = [
            f._getVersionSign()
          ];
        } else s = o.get("data", true), u = Ot(s) ? cr : ue, a = [];
        var h = this._getSourceMetaRawOption() || {}, c = l && l.metaRawOption || {}, v = W(h.seriesLayoutBy, c.seriesLayoutBy) || null, p = W(h.sourceHeader, c.sourceHeader), y = W(h.dimensions, c.dimensions), g = v !== c.seriesLayoutBy || !!p != !!c.sourceHeader || y;
        i = g ? [
          gl(s, {
            seriesLayoutBy: v,
            sourceHeader: p,
            dimensions: y
          }, u)
        ] : [];
      } else {
        var d = t;
        if (n) {
          var m = this._applyTransform(r);
          i = m.sourceList, a = m.upstreamSignList;
        } else {
          var _ = d.get("source", true);
          i = [
            gl(_, this._getSourceMetaRawOption(), null)
          ], a = [];
        }
      }
      this._setLocalSource(i, a);
    }, e.prototype._applyTransform = function(t) {
      var r = this._sourceHost, n = r.get("transform", true), i = r.get("fromTransformResult", true);
      if (i != null) {
        var a = "";
        t.length !== 1 && rc(a);
      }
      var o, s = [], u = [];
      return P(t, function(l) {
        l.prepareSource();
        var f = l.getSource(i || 0), h = "";
        i != null && !f && rc(h), s.push(f), u.push(l._getVersionSign());
      }), n ? o = Ww(n, s, {
        datasetIndex: r.componentIndex
      }) : i != null && (o = [
        Pw(s[0])
      ]), {
        sourceList: o,
        upstreamSignList: u
      };
    }, e.prototype._isDirty = function() {
      if (this._dirty) return true;
      for (var t = this._getUpstreamSourceManagers(), r = 0; r < t.length; r++) {
        var n = t[r];
        if (n._isDirty() || this._upstreamSignList[r] !== n._getVersionSign()) return true;
      }
    }, e.prototype.getSource = function(t) {
      t = t || 0;
      var r = this._sourceList[t];
      if (!r) {
        var n = this._getUpstreamSourceManagers();
        return n[0] && n[0].getSource(t);
      }
      return r;
    }, e.prototype.getSharedDataStore = function(t) {
      var r = t.makeStoreSchema();
      return this._innerGetDataStore(r.dimensions, t.source, r.hash);
    }, e.prototype._innerGetDataStore = function(t, r, n) {
      var i = 0, a = this._storeList, o = a[i];
      o || (o = a[i] = {});
      var s = o[n];
      if (!s) {
        var u = this._getUpstreamSourceManagers()[0];
        Ea(this._sourceHost) && u ? s = u._innerGetDataStore(t, r, n) : (s = new yl(), s.initData(new Yg(r, t.length), t)), o[n] = s;
      }
      return s;
    }, e.prototype._getUpstreamSourceManagers = function() {
      var t = this._sourceHost;
      if (Ea(t)) {
        var r = Fg(t);
        return r ? [
          r.getSourceManager()
        ] : [];
      } else return F(nw(t), function(n) {
        return n.getSourceManager();
      });
    }, e.prototype._getSourceMetaRawOption = function() {
      var t = this._sourceHost, r, n, i;
      if (Ea(t)) r = t.get("seriesLayoutBy", true), n = t.get("sourceHeader", true), i = t.get("dimensions", true);
      else if (!this._getUpstreamSourceManagers().length) {
        var a = t;
        r = a.get("seriesLayoutBy", true), n = a.get("sourceHeader", true), i = a.get("dimensions", true);
      }
      return {
        seriesLayoutBy: r,
        sourceHeader: n,
        dimensions: i
      };
    }, e;
  })();
  function Ea(e) {
    return e.mainType === "series";
  }
  function rc(e) {
    throw new Error(e);
  }
  var Kw = "line-height:1";
  function Jg(e) {
    var t = e.lineHeight;
    return t == null ? Kw : "line-height:" + Et(t + "") + "px";
  }
  function t0(e, t) {
    var r = e.color || "#6e7079", n = e.fontSize || 12, i = e.fontWeight || "400", a = e.color || "#464646", o = e.fontSize || 14, s = e.fontWeight || "900";
    return t === "html" ? {
      nameStyle: "font-size:" + Et(n + "") + "px;color:" + Et(r) + ";font-weight:" + Et(i + ""),
      valueStyle: "font-size:" + Et(o + "") + "px;color:" + Et(a) + ";font-weight:" + Et(s + "")
    } : {
      nameStyle: {
        fontSize: n,
        fill: r,
        fontWeight: i
      },
      valueStyle: {
        fontSize: o,
        fill: a,
        fontWeight: s
      }
    };
  }
  var jw = [
    0,
    10,
    20,
    30
  ], Qw = [
    "",
    `
`,
    `

`,
    `


`
  ];
  To = function(e, t) {
    return t.type = e, t;
  };
  function ml(e) {
    return e.type === "section";
  }
  function e0(e) {
    return ml(e) ? Jw : tT;
  }
  function r0(e) {
    if (ml(e)) {
      var t = 0, r = e.blocks.length, n = r > 1 || r > 0 && !e.noHeader;
      return P(e.blocks, function(i) {
        var a = r0(i);
        a >= t && (t = a + +(n && (!a || ml(i) && !i.noHeader)));
      }), t;
    }
    return 0;
  }
  function Jw(e, t, r, n) {
    var i = t.noHeader, a = eT(r0(t)), o = [], s = t.blocks || [];
    $t(!s || B(s)), s = s || [];
    var u = e.orderMode;
    if (t.sortBlocks && u) {
      s = s.slice();
      var l = {
        valueAsc: "asc",
        valueDesc: "desc"
      };
      if (tn(l, u)) {
        var f = new Nw(l[u], null);
        s.sort(function(y, g) {
          return f.evaluate(y.sortParam, g.sortParam);
        });
      } else u === "seriesDesc" && s.reverse();
    }
    P(s, function(y, g) {
      var d = t.valueFormatter, m = e0(y)(d ? O(O({}, e), {
        valueFormatter: d
      }) : e, y, g > 0 ? a.html : 0, n);
      m != null && o.push(m);
    });
    var h = e.renderMode === "richText" ? o.join(a.richText) : _l(n, o.join(""), i ? r : a.html);
    if (i) return h;
    var c = cl(t.header, "ordinal", e.useUTC), v = t0(n, e.renderMode).nameStyle, p = Jg(n);
    return e.renderMode === "richText" ? n0(e, c, v) + a.richText + h : _l(n, '<div style="' + v + ";" + p + ';">' + Et(c) + "</div>" + h, r);
  }
  function tT(e, t, r, n) {
    var i = e.renderMode, a = t.noName, o = t.noValue, s = !t.markerType, u = t.name, l = e.useUTC, f = t.valueFormatter || e.valueFormatter || function(S) {
      return S = B(S) ? S : [
        S
      ], F(S, function(T, b) {
        return cl(T, B(v) ? v[b] : v, l);
      });
    };
    if (!(a && o)) {
      var h = s ? "" : e.markupStyleCreator.makeTooltipMarker(t.markerType, t.markerColor || "#333", i), c = a ? "" : cl(u, "ordinal", l), v = t.valueType, p = o ? [] : f(t.value, t.dataIndex), y = !s || !a, g = !s && a, d = t0(n, i), m = d.nameStyle, _ = d.valueStyle;
      return i === "richText" ? (s ? "" : h) + (a ? "" : n0(e, c, m)) + (o ? "" : iT(e, p, y, g, _)) : _l(n, (s ? "" : h) + (a ? "" : rT(c, !s, m)) + (o ? "" : nT(p, y, g, _)), r);
    }
  }
  j2 = function(e, t, r, n, i, a) {
    if (e) {
      var o = e0(e), s = {
        useUTC: i,
        renderMode: r,
        orderMode: n,
        markupStyleCreator: t,
        valueFormatter: e.valueFormatter
      };
      return o(s, e, 0, a);
    }
  };
  function eT(e) {
    return {
      html: jw[e],
      richText: Qw[e]
    };
  }
  function _l(e, t, r) {
    var n = '<div style="clear:both"></div>', i = "margin: " + r + "px 0 0", a = Jg(e);
    return '<div style="' + i + ";" + a + ';">' + t + n + "</div>";
  }
  function rT(e, t, r) {
    var n = t ? "margin-left:2px" : "";
    return '<span style="' + r + ";" + n + '">' + Et(e) + "</span>";
  }
  function nT(e, t, r, n) {
    var i = r ? "10px" : "20px", a = t ? "float:right;margin-left:" + i : "";
    return e = B(e) ? e : [
      e
    ], '<span style="' + a + ";" + n + '">' + F(e, function(o) {
      return Et(o);
    }).join("&nbsp;&nbsp;") + "</span>";
  }
  function n0(e, t, r) {
    return e.markupStyleCreator.wrapRichTextStyle(t, r);
  }
  function iT(e, t, r, n, i) {
    var a = [
      i
    ], o = n ? 10 : 20;
    return r && a.push({
      padding: [
        0,
        0,
        0,
        o
      ],
      align: "right"
    }), e.markupStyleCreator.wrapRichTextStyle(B(t) ? t.join("  ") : t, a);
  }
  function aT(e, t) {
    var r = e.getData().getItemVisual(t, "style"), n = r[e.visualDrawType];
    return pl(n);
  }
  Q2 = function(e, t) {
    var r = e.get("padding");
    return r ?? (t === "richText" ? [
      8,
      10
    ] : 10);
  };
  J2 = (function() {
    function e() {
      this.richTextStyles = {}, this._nextStyleNameId = Md();
    }
    return e.prototype._generateStyleName = function() {
      return "__EC_aUTo_" + this._nextStyleNameId++;
    }, e.prototype.makeTooltipMarker = function(t, r, n) {
      var i = n === "richText" ? this._generateStyleName() : null, a = Eg({
        color: r,
        type: t,
        renderMode: n,
        markerId: i
      });
      return V(a) ? a : (this.richTextStyles[i] = a.style, a.content);
    }, e.prototype.wrapRichTextStyle = function(t, r) {
      var n = {};
      B(r) ? P(r, function(a) {
        return O(n, a);
      }) : O(n, r);
      var i = this._generateStyleName();
      return this.richTextStyles[i] = n, "{" + i + "|" + t + "}";
    }, e;
  })();
  function oT(e) {
    var t = e.series, r = e.dataIndex, n = e.multipleSeries, i = t.getData(), a = i.mapDimensionsAll("defaultedTooltip"), o = a.length, s = t.getRawValue(r), u = B(s), l = aT(t, r), f, h, c, v;
    if (o > 1 || u && !o) {
      var p = sT(s, t, r, a, l);
      f = p.inlineValues, h = p.inlineValueTypes, c = p.blocks, v = p.inlineValues[0];
    } else if (o) {
      var y = i.getDimensionInfo(a[0]);
      v = f = Nn(i, r, a[0]), h = y.type;
    } else v = f = u ? s[0] : s;
    var g = Id(t), d = g && t.name || "", m = i.getName(r), _ = n ? d : m;
    return To("section", {
      header: d,
      noHeader: n || !g,
      sortParam: v,
      blocks: [
        To("nameValue", {
          markerType: "item",
          markerColor: l,
          name: _,
          noName: !Ie(_),
          value: f,
          valueType: h,
          dataIndex: r
        })
      ].concat(c || [])
    });
  }
  function sT(e, t, r, n, i) {
    var a = t.getData(), o = Le(e, function(h, c, v) {
      var p = a.getDimensionInfo(v);
      return h = h || p && p.tooltip !== false && p.displayName != null;
    }, false), s = [], u = [], l = [];
    n.length ? P(n, function(h) {
      f(Nn(a, r, h), h);
    }) : P(e, f);
    function f(h, c) {
      var v = a.getDimensionInfo(c);
      !v || v.otherDims.tooltip === false || (o ? l.push(To("nameValue", {
        markerType: "subItem",
        markerColor: i,
        name: v.displayName,
        value: h,
        valueType: v.type
      })) : (s.push(h), u.push(v.type)));
    }
    return {
      inlineValues: s,
      inlineValueTypes: u,
      blocks: l
    };
  }
  var Je = Pt();
  function La(e, t) {
    return e.getName(t) || e.getId(t);
  }
  var uT = "__universalTransitionEnabled", _e = (function(e) {
    ft(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r._selectedDataIndicesMap = {}, r;
    }
    return t.prototype.init = function(r, n, i) {
      this.seriesIndex = this.componentIndex, this.dataTask = ki({
        count: fT,
        reset: hT
      }), this.dataTask.context = {
        model: this
      }, this.mergeDefaultAndTheme(r, i);
      var a = Je(this).sourceManager = new Zw(this);
      a.prepareSource();
      var o = this.getInitialData(r, i);
      ic(o, this), this.dataTask.context.data = o, Je(this).dataBeforeProcessed = o, nc(this), this._initSelectedMapFromData(o);
    }, t.prototype.mergeDefaultAndTheme = function(r, n) {
      var i = bo(this), a = i ? Lg(r) : {}, o = this.subType;
      nt.hasClass(o) && (o += "Series"), ct(r, n.getTheme().get(this.subType)), ct(r, this.getDefaultOption()), Hh(r, "label", [
        "show"
      ]), this.fillDataTextStyle(r.data), i && wo(r, a, i);
    }, t.prototype.mergeOption = function(r, n) {
      r = ct(this.option, r, true), this.fillDataTextStyle(r.data);
      var i = bo(this);
      i && wo(this.option, r, i);
      var a = Je(this).sourceManager;
      a.dirty(), a.prepareSource();
      var o = this.getInitialData(r, n);
      ic(o, this), this.dataTask.dirty(), this.dataTask.context.data = o, Je(this).dataBeforeProcessed = o, nc(this), this._initSelectedMapFromData(o);
    }, t.prototype.fillDataTextStyle = function(r) {
      if (r && !Ot(r)) for (var n = [
        "show"
      ], i = 0; i < r.length; i++) r[i] && r[i].label && Hh(r[i], "label", n);
    }, t.prototype.getInitialData = function(r, n) {
    }, t.prototype.appendData = function(r) {
      var n = this.getRawData();
      n.appendData(r.data);
    }, t.prototype.getData = function(r) {
      var n = Sl(this);
      if (n) {
        var i = n.context.data;
        return r == null || !i.getLinkedData ? i : i.getLinkedData(r);
      } else return Je(this).data;
    }, t.prototype.getAllData = function() {
      var r = this.getData();
      return r && r.getLinkedDataAll ? r.getLinkedDataAll() : [
        {
          data: r
        }
      ];
    }, t.prototype.setData = function(r) {
      var n = Sl(this);
      if (n) {
        var i = n.context;
        i.outputData = r, n !== this.dataTask && (i.data = r);
      }
      Je(this).data = r;
    }, t.prototype.getEncode = function() {
      var r = this.get("encode", true);
      if (r) return q(r);
    }, t.prototype.getSourceManager = function() {
      return Je(this).sourceManager;
    }, t.prototype.getSource = function() {
      return this.getSourceManager().getSource();
    }, t.prototype.getRawData = function() {
      return Je(this).dataBeforeProcessed;
    }, t.prototype.getColorBy = function() {
      var r = this.get("colorBy");
      return r || "series";
    }, t.prototype.isColorBySeries = function() {
      return this.getColorBy() === "series";
    }, t.prototype.getBaseAxis = function() {
      var r = this.coordinateSystem;
      return r && r.getBaseAxis && r.getBaseAxis();
    }, t.prototype.formatTooltip = function(r, n, i) {
      return oT({
        series: this,
        dataIndex: r,
        multipleSeries: n
      });
    }, t.prototype.isAnimationEnabled = function() {
      var r = this.ecModel;
      if (j.node && !(r && r.ssr)) return false;
      var n = this.getShallow("animation");
      return n && this.getData().count() > this.getShallow("animationThreshold") && (n = false), !!n;
    }, t.prototype.restoreData = function() {
      this.dataTask.dirty();
    }, t.prototype.getColorFromPalette = function(r, n, i) {
      var a = this.ecModel, o = bf.prototype.getColorFromPalette.call(this, r, n, i);
      return o || (o = a.getColorFromPalette(r, n, i)), o;
    }, t.prototype.coordDimToDataDim = function(r) {
      return this.getRawData().mapDimensionsAll(r);
    }, t.prototype.getProgressive = function() {
      return this.get("progressive");
    }, t.prototype.getProgressiveThreshold = function() {
      return this.get("progressiveThreshold");
    }, t.prototype.select = function(r, n) {
      this._innerSelect(this.getData(n), r);
    }, t.prototype.unselect = function(r, n) {
      var i = this.option.selectedMap;
      if (i) {
        var a = this.option.selectedMode, o = this.getData(n);
        if (a === "series" || i === "all") {
          this.option.selectedMap = {}, this._selectedDataIndicesMap = {};
          return;
        }
        for (var s = 0; s < r.length; s++) {
          var u = r[s], l = La(o, u);
          i[l] = false, this._selectedDataIndicesMap[l] = -1;
        }
      }
    }, t.prototype.toggleSelect = function(r, n) {
      for (var i = [], a = 0; a < r.length; a++) i[0] = r[a], this.isSelected(r[a], n) ? this.unselect(i, n) : this.select(i, n);
    }, t.prototype.getSelectedDataIndices = function() {
      if (this.option.selectedMap === "all") return [].slice.call(this.getData().getIndices());
      for (var r = this._selectedDataIndicesMap, n = K(r), i = [], a = 0; a < n.length; a++) {
        var o = r[n[a]];
        o >= 0 && i.push(o);
      }
      return i;
    }, t.prototype.isSelected = function(r, n) {
      var i = this.option.selectedMap;
      if (!i) return false;
      var a = this.getData(n);
      return (i === "all" || i[La(a, r)]) && !a.getItemModel(r).get([
        "select",
        "disabled"
      ]);
    }, t.prototype.isUniversalTransitionEnabled = function() {
      if (this[uT]) return true;
      var r = this.option.universalTransition;
      return r ? r === true ? true : r && r.enabled : false;
    }, t.prototype._innerSelect = function(r, n) {
      var i, a, o = this.option, s = o.selectedMode, u = n.length;
      if (!(!s || !u)) {
        if (s === "series") o.selectedMap = "all";
        else if (s === "multiple") {
          G(o.selectedMap) || (o.selectedMap = {});
          for (var l = o.selectedMap, f = 0; f < u; f++) {
            var h = n[f], c = La(r, h);
            l[c] = true, this._selectedDataIndicesMap[c] = r.getRawIndex(h);
          }
        } else if (s === "single" || s === true) {
          var v = n[u - 1], c = La(r, v);
          o.selectedMap = (i = {}, i[c] = true, i), this._selectedDataIndicesMap = (a = {}, a[c] = r.getRawIndex(v), a);
        }
      }
    }, t.prototype._initSelectedMapFromData = function(r) {
      if (!this.option.selectedMap) {
        var n = [];
        r.hasItemOption && r.each(function(i) {
          var a = r.getRawDataItem(i);
          a && a.selected && n.push(i);
        }), n.length > 0 && this._innerSelect(r, n);
      }
    }, t.registerClass = function(r) {
      return nt.registerClass(r);
    }, t.protoInitialize = (function() {
      var r = t.prototype;
      r.type = "series.__base__", r.seriesIndex = 0, r.ignoreStyleOnData = false, r.hasSymbolVisual = false, r.defaultSymbol = "circle", r.visualStyleAccessPath = "itemStyle", r.visualDrawType = "fill";
    })(), t;
  })(nt);
  ae(_e, Zg);
  ae(_e, bf);
  Rd(_e, nt);
  function nc(e) {
    var t = e.name;
    Id(e) || (e.name = lT(e) || t);
  }
  function lT(e) {
    var t = e.getRawData(), r = t.mapDimensionsAll("seriesName"), n = [];
    return P(r, function(i) {
      var a = t.getDimensionInfo(i);
      a.displayName && n.push(a.displayName);
    }), n.join(" ");
  }
  function fT(e) {
    return e.model.getRawData().count();
  }
  function hT(e) {
    var t = e.model;
    return t.setData(t.getRawData().cloneShallow()), vT;
  }
  function vT(e, t) {
    t.outputData && e.end > t.outputData.count() && t.model.getRawData().cloneShallow(t.outputData);
  }
  function ic(e, t) {
    P(Fp(e.CHANGABLE_METHODS, e.DOWNSAMPLE_METHODS), function(r) {
      e.wrapMethod(r, Vn(cT, t));
    });
  }
  function cT(e, t) {
    var r = Sl(e);
    return r && r.setOutputEnd((t || this).count()), t;
  }
  function Sl(e) {
    var t = (e.ecModel || {}).scheduler, r = t && t.getPipeline(e.uid);
    if (r) {
      var n = r.currentTask;
      if (n) {
        var i = n.agentStubMap;
        i && (n = i.get(e.uid));
      }
      return n;
    }
  }
  Xe = (function() {
    function e() {
      this.group = new oe(), this.uid = rs("viewComponent");
    }
    return e.prototype.init = function(t, r) {
    }, e.prototype.render = function(t, r, n, i) {
    }, e.prototype.dispose = function(t, r) {
    }, e.prototype.updateView = function(t, r, n, i) {
    }, e.prototype.updateLayout = function(t, r, n, i) {
    }, e.prototype.updateVisual = function(t, r, n, i) {
    }, e.prototype.toggleBlurSeries = function(t, r, n) {
    }, e.prototype.eachRendered = function(t) {
      var r = this.group;
      r && r.traverse(t);
    }, e;
  })();
  Kl(Xe);
  Uo(Xe);
  function i0() {
    var e = Pt();
    return function(t) {
      var r = e(t), n = t.pipelineContext, i = !!r.large, a = !!r.progressiveRender, o = r.large = !!(n && n.large), s = r.progressiveRender = !!(n && n.progressiveRender);
      return (i !== o || a !== s) && "reset";
    };
  }
  var a0 = Pt(), pT = i0(), Xt = (function() {
    function e() {
      this.group = new oe(), this.uid = rs("viewChart"), this.renderTask = ki({
        plan: dT,
        reset: gT
      }), this.renderTask.context = {
        view: this
      };
    }
    return e.prototype.init = function(t, r) {
    }, e.prototype.render = function(t, r, n, i) {
    }, e.prototype.highlight = function(t, r, n, i) {
      var a = t.getData(i && i.dataType);
      a && oc(a, i, "emphasis");
    }, e.prototype.downplay = function(t, r, n, i) {
      var a = t.getData(i && i.dataType);
      a && oc(a, i, "normal");
    }, e.prototype.remove = function(t, r) {
      this.group.removeAll();
    }, e.prototype.dispose = function(t, r) {
    }, e.prototype.updateView = function(t, r, n, i) {
      this.render(t, r, n, i);
    }, e.prototype.updateLayout = function(t, r, n, i) {
      this.render(t, r, n, i);
    }, e.prototype.updateVisual = function(t, r, n, i) {
      this.render(t, r, n, i);
    }, e.prototype.eachRendered = function(t) {
      ff(this.group, t);
    }, e.markUpdateMethod = function(t, r) {
      a0(t).updateMethod = r;
    }, e.protoInitialize = (function() {
      var t = e.prototype;
      t.type = "chart";
    })(), e;
  })();
  function ac(e, t, r) {
    e && ll(e) && (t === "emphasis" ? po : go)(e, r);
  }
  function oc(e, t, r) {
    var n = kn(e, t), i = t && t.highlightKey != null ? kS(t.highlightKey) : null;
    n != null ? P(Lt(n), function(a) {
      ac(e.getItemGraphicEl(a), r, i);
    }) : e.eachItemGraphicEl(function(a) {
      ac(a, r, i);
    });
  }
  Kl(Xt);
  Uo(Xt);
  function dT(e) {
    return pT(e.model);
  }
  function gT(e) {
    var t = e.model, r = e.ecModel, n = e.api, i = e.payload, a = t.pipelineContext.progressiveRender, o = e.view, s = i && a0(i).updateMethod, u = a ? "incrementalPrepareRender" : s && o[s] ? s : "render";
    return u !== "render" && o[u](t, r, n, i), yT[u];
  }
  var yT = {
    incrementalPrepareRender: {
      progress: function(e, t) {
        t.view.incrementalRender(e, t.model, t.ecModel, t.api, t.payload);
      }
    },
    render: {
      forceFirstProgress: true,
      progress: function(e, t) {
        t.view.render(t.model, t.ecModel, t.api, t.payload);
      }
    }
  }, Mo = "\0__throttleOriginMethod", sc = "\0__throttleRate", uc = "\0__throttleType";
  function Df(e, t, r) {
    var n, i = 0, a = 0, o = null, s, u, l, f;
    t = t || 0;
    function h() {
      a = (/* @__PURE__ */ new Date()).getTime(), o = null, e.apply(u, l || []);
    }
    var c = function() {
      for (var v = [], p = 0; p < arguments.length; p++) v[p] = arguments[p];
      n = (/* @__PURE__ */ new Date()).getTime(), u = this, l = v;
      var y = f || t, g = f || r;
      f = null, s = n - (g ? i : a) - y, clearTimeout(o), g ? o = setTimeout(h, y) : s >= 0 ? h() : o = setTimeout(h, -s), i = n;
    };
    return c.clear = function() {
      o && (clearTimeout(o), o = null);
    }, c.debounceNextCall = function(v) {
      f = v;
    }, c;
  }
  tx = function(e, t, r, n) {
    var i = e[t];
    if (i) {
      var a = i[Mo] || i, o = i[uc], s = i[sc];
      if (s !== r || o !== n) {
        if (r == null || !n) return e[t] = a;
        i = e[t] = Df(a, r, n === "debounce"), i[Mo] = a, i[uc] = n, i[sc] = r;
      }
      return i;
    }
  };
  ex = function(e, t) {
    var r = e[t];
    r && r[Mo] && (r.clear && r.clear(), e[t] = r[Mo]);
  };
  var lc = Pt(), fc = {
    itemStyle: qi(_g, true),
    lineStyle: qi(mg, true)
  }, mT = {
    lineStyle: "stroke",
    itemStyle: "fill"
  };
  function o0(e, t) {
    var r = e.visualStyleMapper || fc[t];
    return r || (console.warn("Unknown style type '" + t + "'."), fc.itemStyle);
  }
  function s0(e, t) {
    var r = e.visualDrawType || mT[t];
    return r || (console.warn("Unknown style type '" + t + "'."), "fill");
  }
  var _T = {
    createOnAllSeries: true,
    performRawSeries: true,
    reset: function(e, t) {
      var r = e.getData(), n = e.visualStyleAccessPath || "itemStyle", i = e.getModel(n), a = o0(e, n), o = a(i), s = i.getShallow("decal");
      s && (r.setVisual("decal", s), s.dirty = true);
      var u = s0(e, n), l = o[u], f = Y(l) ? l : null, h = o.fill === "auto" || o.stroke === "auto";
      if (!o[u] || f || h) {
        var c = e.getColorFromPalette(e.name, null, t.getSeriesCount());
        o[u] || (o[u] = c, r.setVisual("colorFromPalette", true)), o.fill = o.fill === "auto" || Y(o.fill) ? c : o.fill, o.stroke = o.stroke === "auto" || Y(o.stroke) ? c : o.stroke;
      }
      if (r.setVisual("style", o), r.setVisual("drawType", u), !t.isSeriesFiltered(e) && f) return r.setVisual("colorFromPalette", false), {
        dataEach: function(v, p) {
          var y = e.getDataParams(p), g = O({}, o);
          g[u] = f(y), v.setItemVisual(p, "style", g);
        }
      };
    }
  }, fi = new wt(), ST = {
    createOnAllSeries: true,
    performRawSeries: true,
    reset: function(e, t) {
      if (!(e.ignoreStyleOnData || t.isSeriesFiltered(e))) {
        var r = e.getData(), n = e.visualStyleAccessPath || "itemStyle", i = o0(e, n), a = r.getVisual("drawType");
        return {
          dataEach: r.hasItemOption ? function(o, s) {
            var u = o.getRawDataItem(s);
            if (u && u[n]) {
              fi.option = u[n];
              var l = i(fi), f = o.ensureUniqueItemVisual(s, "style");
              O(f, l), fi.option.decal && (o.setItemVisual(s, "decal", fi.option.decal), fi.option.decal.dirty = true), a in l && o.setItemVisual(s, "colorFromPalette", false);
            }
          } : null
        };
      }
    }
  }, bT = {
    performRawSeries: true,
    overallReset: function(e) {
      var t = q();
      e.eachSeries(function(r) {
        var n = r.getColorBy();
        if (!r.isColorBySeries()) {
          var i = r.type + "-" + n, a = t.get(i);
          a || (a = {}, t.set(i, a)), lc(r).scope = a;
        }
      }), e.eachSeries(function(r) {
        if (!(r.isColorBySeries() || e.isSeriesFiltered(r))) {
          var n = r.getRawData(), i = {}, a = r.getData(), o = lc(r).scope, s = r.visualStyleAccessPath || "itemStyle", u = s0(r, s);
          a.each(function(l) {
            var f = a.getRawIndex(l);
            i[f] = l;
          }), n.each(function(l) {
            var f = i[l], h = a.getItemVisual(f, "colorFromPalette");
            if (h) {
              var c = a.ensureUniqueItemVisual(f, "style"), v = n.getName(l) || l + "", p = n.count();
              c[u] = r.getColorFromPalette(v, o, p);
            }
          });
        }
      });
    }
  }, Ra = Math.PI;
  function wT(e, t) {
    t = t || {}, ht(t, {
      text: "loading",
      textColor: "#000",
      fontSize: 12,
      fontWeight: "normal",
      fontStyle: "normal",
      fontFamily: "sans-serif",
      maskColor: "rgba(255, 255, 255, 0.8)",
      showSpinner: true,
      color: "#5470c6",
      spinnerRadius: 10,
      lineWidth: 5,
      zlevel: 0
    });
    var r = new oe(), n = new ne({
      style: {
        fill: t.maskColor
      },
      zlevel: t.zlevel,
      z: 1e4
    });
    r.add(n);
    var i = new Re({
      style: {
        text: t.text,
        fill: t.textColor,
        fontSize: t.fontSize,
        fontWeight: t.fontWeight,
        fontStyle: t.fontStyle,
        fontFamily: t.fontFamily
      },
      zlevel: t.zlevel,
      z: 10001
    }), a = new ne({
      style: {
        fill: "none"
      },
      textContent: i,
      textConfig: {
        position: "right",
        distance: 10
      },
      zlevel: t.zlevel,
      z: 10001
    });
    r.add(a);
    var o;
    return t.showSpinner && (o = new oa({
      shape: {
        startAngle: -Ra / 2,
        endAngle: -Ra / 2 + 0.1,
        r: t.spinnerRadius
      },
      style: {
        stroke: t.color,
        lineCap: "round",
        lineWidth: t.lineWidth
      },
      zlevel: t.zlevel,
      z: 10001
    }), o.animateShape(true).when(1e3, {
      endAngle: Ra * 3 / 2
    }).start("circularInOut"), o.animateShape(true).when(1e3, {
      startAngle: Ra * 3 / 2
    }).delay(300).start("circularInOut"), r.add(o)), r.resize = function() {
      var s = i.getBoundingRect().width, u = t.showSpinner ? t.spinnerRadius : 0, l = (e.getWidth() - u * 2 - (t.showSpinner && s ? 10 : 0) - s) / 2 - (t.showSpinner && s ? 0 : 5 + s / 2) + (t.showSpinner ? 0 : s / 2) + (s ? 0 : u), f = e.getHeight() / 2;
      t.showSpinner && o.setShape({
        cx: l,
        cy: f
      }), a.setShape({
        x: l - u,
        y: f - u,
        width: u * 2,
        height: u * 2
      }), n.setShape({
        x: 0,
        y: 0,
        width: e.getWidth(),
        height: e.getHeight()
      });
    }, r.resize(), r;
  }
  var u0 = (function() {
    function e(t, r, n, i) {
      this._stageTaskMap = q(), this.ecInstance = t, this.api = r, n = this._dataProcessorHandlers = n.slice(), i = this._visualHandlers = i.slice(), this._allHandlers = n.concat(i);
    }
    return e.prototype.restoreData = function(t, r) {
      t.restoreData(r), this._stageTaskMap.each(function(n) {
        var i = n.overallTask;
        i && i.dirty();
      });
    }, e.prototype.getPerformArgs = function(t, r) {
      if (t.__pipeline) {
        var n = this._pipelineMap.get(t.__pipeline.id), i = n.context, a = !r && n.progressiveEnabled && (!i || i.progressiveRender) && t.__idxInPipeline > n.blockIndex, o = a ? n.step : null, s = i && i.modDataCount, u = s != null ? Math.ceil(s / o) : null;
        return {
          step: o,
          modBy: u,
          modDataCount: s
        };
      }
    }, e.prototype.getPipeline = function(t) {
      return this._pipelineMap.get(t);
    }, e.prototype.updateStreamModes = function(t, r) {
      var n = this._pipelineMap.get(t.uid), i = t.getData(), a = i.count(), o = n.progressiveEnabled && r.incrementalPrepareRender && a >= n.threshold, s = t.get("large") && a >= t.get("largeThreshold"), u = t.get("progressiveChunkMode") === "mod" ? a : null;
      t.pipelineContext = n.context = {
        progressiveRender: o,
        modDataCount: u,
        large: s
      };
    }, e.prototype.restorePipelines = function(t) {
      var r = this, n = r._pipelineMap = q();
      t.eachSeries(function(i) {
        var a = i.getProgressive(), o = i.uid;
        n.set(o, {
          id: o,
          head: null,
          tail: null,
          threshold: i.getProgressiveThreshold(),
          progressiveEnabled: a && !(i.preventIncremental && i.preventIncremental()),
          blockIndex: -1,
          step: Math.round(a || 700),
          count: 0
        }), r._pipe(i, i.dataTask);
      });
    }, e.prototype.prepareStageTasks = function() {
      var t = this._stageTaskMap, r = this.api.getModel(), n = this.api;
      P(this._allHandlers, function(i) {
        var a = t.get(i.uid) || t.set(i.uid, {}), o = "";
        $t(!(i.reset && i.overallReset), o), i.reset && this._createSeriesStageTask(i, a, r, n), i.overallReset && this._createOverallStageTask(i, a, r, n);
      }, this);
    }, e.prototype.prepareView = function(t, r, n, i) {
      var a = t.renderTask, o = a.context;
      o.model = r, o.ecModel = n, o.api = i, a.__block = !t.incrementalPrepareRender, this._pipe(r, a);
    }, e.prototype.performDataProcessorTasks = function(t, r) {
      this._performStageTasks(this._dataProcessorHandlers, t, r, {
        block: true
      });
    }, e.prototype.performVisualTasks = function(t, r, n) {
      this._performStageTasks(this._visualHandlers, t, r, n);
    }, e.prototype._performStageTasks = function(t, r, n, i) {
      i = i || {};
      var a = false, o = this;
      P(t, function(u, l) {
        if (!(i.visualType && i.visualType !== u.visualType)) {
          var f = o._stageTaskMap.get(u.uid), h = f.seriesTaskMap, c = f.overallTask;
          if (c) {
            var v, p = c.agentStubMap;
            p.each(function(g) {
              s(i, g) && (g.dirty(), v = true);
            }), v && c.dirty(), o.updatePayload(c, n);
            var y = o.getPerformArgs(c, i.block);
            p.each(function(g) {
              g.perform(y);
            }), c.perform(y) && (a = true);
          } else h && h.each(function(g, d) {
            s(i, g) && g.dirty();
            var m = o.getPerformArgs(g, i.block);
            m.skip = !u.performRawSeries && r.isSeriesFiltered(g.context.model), o.updatePayload(g, n), g.perform(m) && (a = true);
          });
        }
      });
      function s(u, l) {
        return u.setDirty && (!u.dirtyMap || u.dirtyMap.get(l.__pipeline.id));
      }
      this.unfinished = a || this.unfinished;
    }, e.prototype.performSeriesTasks = function(t) {
      var r;
      t.eachSeries(function(n) {
        r = n.dataTask.perform() || r;
      }), this.unfinished = r || this.unfinished;
    }, e.prototype.plan = function() {
      this._pipelineMap.each(function(t) {
        var r = t.tail;
        do {
          if (r.__block) {
            t.blockIndex = r.__idxInPipeline;
            break;
          }
          r = r.getUpstream();
        } while (r);
      });
    }, e.prototype.updatePayload = function(t, r) {
      r !== "remain" && (t.context.payload = r);
    }, e.prototype._createSeriesStageTask = function(t, r, n, i) {
      var a = this, o = r.seriesTaskMap, s = r.seriesTaskMap = q(), u = t.seriesType, l = t.getTargetSeries;
      t.createOnAllSeries ? n.eachRawSeries(f) : u ? n.eachRawSeriesByType(u, f) : l && l(n, i).each(f);
      function f(h) {
        var c = h.uid, v = s.set(c, o && o.get(c) || ki({
          plan: xT,
          reset: PT,
          count: AT
        }));
        v.context = {
          model: h,
          ecModel: n,
          api: i,
          useClearVisual: t.isVisual && !t.isLayout,
          plan: t.plan,
          reset: t.reset,
          scheduler: a
        }, a._pipe(h, v);
      }
    }, e.prototype._createOverallStageTask = function(t, r, n, i) {
      var a = this, o = r.overallTask = r.overallTask || ki({
        reset: TT
      });
      o.context = {
        ecModel: n,
        api: i,
        overallReset: t.overallReset,
        scheduler: a
      };
      var s = o.agentStubMap, u = o.agentStubMap = q(), l = t.seriesType, f = t.getTargetSeries, h = true, c = false, v = "";
      $t(!t.createOnAllSeries, v), l ? n.eachRawSeriesByType(l, p) : f ? f(n, i).each(p) : (h = false, P(n.getSeries(), p));
      function p(y) {
        var g = y.uid, d = u.set(g, s && s.get(g) || (c = true, ki({
          reset: MT,
          onDirty: DT
        })));
        d.context = {
          model: y,
          overallProgress: h
        }, d.agent = o, d.__block = h, a._pipe(y, d);
      }
      c && o.dirty();
    }, e.prototype._pipe = function(t, r) {
      var n = t.uid, i = this._pipelineMap.get(n);
      !i.head && (i.head = r), i.tail && i.tail.pipe(r), i.tail = r, r.__idxInPipeline = i.count++, r.__pipeline = i;
    }, e.wrapStageHandler = function(t, r) {
      return Y(t) && (t = {
        overallReset: t,
        seriesType: ET(t)
      }), t.uid = rs("stageHandler"), r && (t.visualType = r), t;
    }, e;
  })();
  function TT(e) {
    e.overallReset(e.ecModel, e.api, e.payload);
  }
  function MT(e) {
    return e.overallProgress && CT;
  }
  function CT() {
    this.agent.dirty(), this.getDownstream().dirty();
  }
  function DT() {
    this.agent && this.agent.dirty();
  }
  function xT(e) {
    return e.plan ? e.plan(e.model, e.ecModel, e.api, e.payload) : null;
  }
  function PT(e) {
    e.useClearVisual && e.data.clearAllVisual();
    var t = e.resetDefines = Lt(e.reset(e.model, e.ecModel, e.api, e.payload));
    return t.length > 1 ? F(t, function(r, n) {
      return l0(n);
    }) : IT;
  }
  var IT = l0(0);
  function l0(e) {
    return function(t, r) {
      var n = r.data, i = r.resetDefines[e];
      if (i && i.dataEach) for (var a = t.start; a < t.end; a++) i.dataEach(n, a);
      else i && i.progress && i.progress(t, n);
    };
  }
  function AT(e) {
    return e.data.count();
  }
  function ET(e) {
    Co = null;
    try {
      e(Ki, f0);
    } catch {
    }
    return Co;
  }
  var Ki = {}, f0 = {}, Co;
  h0(Ki, wf);
  h0(f0, zg);
  Ki.eachSeriesByType = Ki.eachRawSeriesByType = function(e) {
    Co = e;
  };
  Ki.eachComponent = function(e) {
    e.mainType === "series" && e.subType && (Co = e.subType);
  };
  function h0(e, t) {
    for (var r in t.prototype) e[r] = zt;
  }
  var hc = [
    "#37A2DA",
    "#32C5E9",
    "#67E0E3",
    "#9FE6B8",
    "#FFDB5C",
    "#ff9f7f",
    "#fb7293",
    "#E062AE",
    "#E690D1",
    "#e7bcf3",
    "#9d96f5",
    "#8378EA",
    "#96BFFF"
  ];
  const LT = {
    color: hc,
    colorLayer: [
      [
        "#37A2DA",
        "#ffd85c",
        "#fd7b5f"
      ],
      [
        "#37A2DA",
        "#67E0E3",
        "#FFDB5C",
        "#ff9f7f",
        "#E062AE",
        "#9d96f5"
      ],
      [
        "#37A2DA",
        "#32C5E9",
        "#9FE6B8",
        "#FFDB5C",
        "#ff9f7f",
        "#fb7293",
        "#e7bcf3",
        "#8378EA",
        "#96BFFF"
      ],
      hc
    ]
  };
  var Dt = "#B9B8CE", vc = "#100C2A", Oa = function() {
    return {
      axisLine: {
        lineStyle: {
          color: Dt
        }
      },
      splitLine: {
        lineStyle: {
          color: "#484753"
        }
      },
      splitArea: {
        areaStyle: {
          color: [
            "rgba(255,255,255,0.02)",
            "rgba(255,255,255,0.05)"
          ]
        }
      },
      minorSplitLine: {
        lineStyle: {
          color: "#20203B"
        }
      }
    };
  }, cc = [
    "#4992ff",
    "#7cffb2",
    "#fddd60",
    "#ff6e76",
    "#58d9f9",
    "#05c091",
    "#ff8a45",
    "#8d48e3",
    "#dd79ff"
  ], v0 = {
    darkMode: true,
    color: cc,
    backgroundColor: vc,
    axisPointer: {
      lineStyle: {
        color: "#817f91"
      },
      crossStyle: {
        color: "#817f91"
      },
      label: {
        color: "#fff"
      }
    },
    legend: {
      textStyle: {
        color: Dt
      },
      pageTextStyle: {
        color: Dt
      }
    },
    textStyle: {
      color: Dt
    },
    title: {
      textStyle: {
        color: "#EEF1FA"
      },
      subtextStyle: {
        color: "#B9B8CE"
      }
    },
    toolbox: {
      iconStyle: {
        borderColor: Dt
      }
    },
    dataZoom: {
      borderColor: "#71708A",
      textStyle: {
        color: Dt
      },
      brushStyle: {
        color: "rgba(135,163,206,0.3)"
      },
      handleStyle: {
        color: "#353450",
        borderColor: "#C5CBE3"
      },
      moveHandleStyle: {
        color: "#B0B6C3",
        opacity: 0.3
      },
      fillerColor: "rgba(135,163,206,0.2)",
      emphasis: {
        handleStyle: {
          borderColor: "#91B7F2",
          color: "#4D587D"
        },
        moveHandleStyle: {
          color: "#636D9A",
          opacity: 0.7
        }
      },
      dataBackground: {
        lineStyle: {
          color: "#71708A",
          width: 1
        },
        areaStyle: {
          color: "#71708A"
        }
      },
      selectedDataBackground: {
        lineStyle: {
          color: "#87A3CE"
        },
        areaStyle: {
          color: "#87A3CE"
        }
      }
    },
    visualMap: {
      textStyle: {
        color: Dt
      }
    },
    timeline: {
      lineStyle: {
        color: Dt
      },
      label: {
        color: Dt
      },
      controlStyle: {
        color: Dt,
        borderColor: Dt
      }
    },
    calendar: {
      itemStyle: {
        color: vc
      },
      dayLabel: {
        color: Dt
      },
      monthLabel: {
        color: Dt
      },
      yearLabel: {
        color: Dt
      }
    },
    timeAxis: Oa(),
    logAxis: Oa(),
    valueAxis: Oa(),
    categoryAxis: Oa(),
    line: {
      symbol: "circle"
    },
    graph: {
      color: cc
    },
    gauge: {
      title: {
        color: Dt
      },
      axisLine: {
        lineStyle: {
          color: [
            [
              1,
              "rgba(207,212,219,0.2)"
            ]
          ]
        }
      },
      axisLabel: {
        color: Dt
      },
      detail: {
        color: "#EEF1FA"
      }
    },
    candlestick: {
      itemStyle: {
        color: "#f64e56",
        color0: "#54ea92",
        borderColor: "#f64e56",
        borderColor0: "#54ea92"
      }
    }
  };
  v0.categoryAxis.splitLine.show = false;
  var RT = (function() {
    function e() {
    }
    return e.prototype.normalizeQuery = function(t) {
      var r = {}, n = {}, i = {};
      if (V(t)) {
        var a = Ee(t);
        r.mainType = a.main || null, r.subType = a.sub || null;
      } else {
        var o = [
          "Index",
          "Name",
          "Id"
        ], s = {
          name: 1,
          dataIndex: 1,
          dataType: 1
        };
        P(t, function(u, l) {
          for (var f = false, h = 0; h < o.length; h++) {
            var c = o[h], v = l.lastIndexOf(c);
            if (v > 0 && v === l.length - c.length) {
              var p = l.slice(0, v);
              p !== "data" && (r.mainType = p, r[c.toLowerCase()] = u, f = true);
            }
          }
          s.hasOwnProperty(l) && (n[l] = u, f = true), f || (i[l] = u);
        });
      }
      return {
        cptQuery: r,
        dataQuery: n,
        otherQuery: i
      };
    }, e.prototype.filter = function(t, r) {
      var n = this.eventInfo;
      if (!n) return true;
      var i = n.targetEl, a = n.packedEvent, o = n.model, s = n.view;
      if (!o || !s) return true;
      var u = r.cptQuery, l = r.dataQuery;
      return f(u, o, "mainType") && f(u, o, "subType") && f(u, o, "index", "componentIndex") && f(u, o, "name") && f(u, o, "id") && f(l, a, "name") && f(l, a, "dataIndex") && f(l, a, "dataType") && (!s.filterForExposedEvent || s.filterForExposedEvent(t, r.otherQuery, i, a));
      function f(h, c, v, p) {
        return h[v] == null || c[p || v] === h[v];
      }
    }, e.prototype.afterTrigger = function() {
      this.eventInfo = null;
    }, e;
  })(), bl = [
    "symbol",
    "symbolSize",
    "symbolRotate",
    "symbolOffset"
  ], pc = bl.concat([
    "symbolKeepAspect"
  ]), OT = {
    createOnAllSeries: true,
    performRawSeries: true,
    reset: function(e, t) {
      var r = e.getData();
      if (e.legendIcon && r.setVisual("legendIcon", e.legendIcon), !e.hasSymbolVisual) return;
      for (var n = {}, i = {}, a = false, o = 0; o < bl.length; o++) {
        var s = bl[o], u = e.get(s);
        Y(u) ? (a = true, i[s] = u) : n[s] = u;
      }
      if (n.symbol = n.symbol || e.defaultSymbol, r.setVisual(O({
        legendIcon: e.legendIcon || n.symbol,
        symbolKeepAspect: e.get("symbolKeepAspect")
      }, n)), t.isSeriesFiltered(e)) return;
      var l = K(i);
      function f(h, c) {
        for (var v = e.getRawValue(c), p = e.getDataParams(c), y = 0; y < l.length; y++) {
          var g = l[y];
          h.setItemVisual(c, g, i[g](v, p));
        }
      }
      return {
        dataEach: a ? f : null
      };
    }
  }, kT = {
    createOnAllSeries: true,
    performRawSeries: true,
    reset: function(e, t) {
      if (!e.hasSymbolVisual || t.isSeriesFiltered(e)) return;
      var r = e.getData();
      function n(i, a) {
        for (var o = i.getItemModel(a), s = 0; s < pc.length; s++) {
          var u = pc[s], l = o.getShallow(u, true);
          l != null && i.setItemVisual(a, u, l);
        }
      }
      return {
        dataEach: r.hasItemOption ? n : null
      };
    }
  };
  function NT(e, t, r) {
    switch (r) {
      case "color":
        var n = e.getItemVisual(t, "style");
        return n[e.getVisual("drawType")];
      case "opacity":
        return e.getItemVisual(t, "style").opacity;
      case "symbol":
      case "symbolSize":
      case "liftZ":
        return e.getItemVisual(t, r);
    }
  }
  function FT(e, t) {
    switch (t) {
      case "color":
        var r = e.getVisual("style");
        return r[e.getVisual("drawType")];
      case "opacity":
        return e.getVisual("style").opacity;
      case "symbol":
      case "symbolSize":
      case "liftZ":
        return e.getVisual(t);
    }
  }
  function _n(e, t, r, n, i) {
    var a = e + t;
    r.isSilent(a) || n.eachComponent({
      mainType: "series",
      subType: "pie"
    }, function(o) {
      for (var s = o.seriesIndex, u = o.option.selectedMap, l = i.selected, f = 0; f < l.length; f++) if (l[f].seriesIndex === s) {
        var h = o.getData(), c = kn(h, i.fromActionPayload);
        r.trigger(a, {
          type: a,
          seriesId: o.id,
          name: B(c) ? h.getName(c[0]) : h.getName(c),
          selected: V(u) ? u : O({}, u)
        });
      }
    });
  }
  function BT(e, t, r) {
    e.on("selectchanged", function(n) {
      var i = r.getModel();
      n.isFromClick ? (_n("map", "selectchanged", t, i, n), _n("pie", "selectchanged", t, i, n)) : n.fromAction === "select" ? (_n("map", "selected", t, i, n), _n("pie", "selected", t, i, n)) : n.fromAction === "unselect" && (_n("map", "unselected", t, i, n), _n("pie", "unselected", t, i, n));
    });
  }
  ka = function(e, t, r) {
    for (var n; e && !(t(e) && (n = e, r)); ) e = e.__hostTarget || e.parent;
    return n;
  };
  var zT = Math.round(Math.random() * 9), VT = typeof Object.defineProperty == "function", GT = (function() {
    function e() {
      this._id = "__ec_inner_" + zT++;
    }
    return e.prototype.get = function(t) {
      return this._guard(t)[this._id];
    }, e.prototype.set = function(t, r) {
      var n = this._guard(t);
      return VT ? Object.defineProperty(n, this._id, {
        value: r,
        enumerable: false,
        configurable: true
      }) : n[this._id] = r, this;
    }, e.prototype.delete = function(t) {
      return this.has(t) ? (delete this._guard(t)[this._id], true) : false;
    }, e.prototype.has = function(t) {
      return !!this._guard(t)[this._id];
    }, e.prototype._guard = function(t) {
      if (t !== Object(t)) throw TypeError("Value of WeakMap is not a non-null object.");
      return t;
    }, e;
  })(), HT = et.extend({
    type: "triangle",
    shape: {
      cx: 0,
      cy: 0,
      width: 0,
      height: 0
    },
    buildPath: function(e, t) {
      var r = t.cx, n = t.cy, i = t.width / 2, a = t.height / 2;
      e.moveTo(r, n - a), e.lineTo(r + i, n + a), e.lineTo(r - i, n + a), e.closePath();
    }
  }), UT = et.extend({
    type: "diamond",
    shape: {
      cx: 0,
      cy: 0,
      width: 0,
      height: 0
    },
    buildPath: function(e, t) {
      var r = t.cx, n = t.cy, i = t.width / 2, a = t.height / 2;
      e.moveTo(r, n - a), e.lineTo(r + i, n), e.lineTo(r, n + a), e.lineTo(r - i, n), e.closePath();
    }
  }), WT = et.extend({
    type: "pin",
    shape: {
      x: 0,
      y: 0,
      width: 0,
      height: 0
    },
    buildPath: function(e, t) {
      var r = t.x, n = t.y, i = t.width / 5 * 3, a = Math.max(i, t.height), o = i / 2, s = o * o / (a - o), u = n - a + o + s, l = Math.asin(s / o), f = Math.cos(l) * o, h = Math.sin(l), c = Math.cos(l), v = o * 0.6, p = o * 0.7;
      e.moveTo(r - f, u + s), e.arc(r, u, o, Math.PI - l, Math.PI * 2 + l), e.bezierCurveTo(r + f - h * v, u + s + c * v, r, n - p, r, n), e.bezierCurveTo(r, n - p, r - f + h * v, u + s + c * v, r - f, u + s), e.closePath();
    }
  }), YT = et.extend({
    type: "arrow",
    shape: {
      x: 0,
      y: 0,
      width: 0,
      height: 0
    },
    buildPath: function(e, t) {
      var r = t.height, n = t.width, i = t.x, a = t.y, o = n / 3 * 2;
      e.moveTo(i, a), e.lineTo(i + o, a + r), e.lineTo(i, a + r / 4 * 3), e.lineTo(i - o, a + r), e.lineTo(i, a), e.closePath();
    }
  }), qT = {
    line: en,
    rect: ne,
    roundRect: ne,
    square: ne,
    circle: ia,
    diamond: UT,
    pin: WT,
    arrow: YT,
    triangle: HT
  }, XT = {
    line: function(e, t, r, n, i) {
      i.x1 = e, i.y1 = t + n / 2, i.x2 = e + r, i.y2 = t + n / 2;
    },
    rect: function(e, t, r, n, i) {
      i.x = e, i.y = t, i.width = r, i.height = n;
    },
    roundRect: function(e, t, r, n, i) {
      i.x = e, i.y = t, i.width = r, i.height = n, i.r = Math.min(r, n) / 4;
    },
    square: function(e, t, r, n, i) {
      var a = Math.min(r, n);
      i.x = e, i.y = t, i.width = a, i.height = a;
    },
    circle: function(e, t, r, n, i) {
      i.cx = e + r / 2, i.cy = t + n / 2, i.r = Math.min(r, n) / 2;
    },
    diamond: function(e, t, r, n, i) {
      i.cx = e + r / 2, i.cy = t + n / 2, i.width = r, i.height = n;
    },
    pin: function(e, t, r, n, i) {
      i.x = e + r / 2, i.y = t + n / 2, i.width = r, i.height = n;
    },
    arrow: function(e, t, r, n, i) {
      i.x = e + r / 2, i.y = t + n / 2, i.width = r, i.height = n;
    },
    triangle: function(e, t, r, n, i) {
      i.cx = e + r / 2, i.cy = t + n / 2, i.width = r, i.height = n;
    }
  }, wl = {};
  P(qT, function(e, t) {
    wl[t] = new e();
  });
  var $T = et.extend({
    type: "symbol",
    shape: {
      symbolType: "",
      x: 0,
      y: 0,
      width: 0,
      height: 0
    },
    calculateTextPosition: function(e, t, r) {
      var n = cd(e, t, r), i = this.shape;
      return i && i.symbolType === "pin" && t.position === "inside" && (n.y = r.y + r.height * 0.4), n;
    },
    buildPath: function(e, t, r) {
      var n = t.symbolType;
      if (n !== "none") {
        var i = wl[n];
        i || (n = "rect", i = wl[n]), XT[n](t.x, t.y, t.width, t.height, i.shape), i.buildPath(e, i.shape, r);
      }
    }
  });
  function ZT(e, t) {
    if (this.type !== "image") {
      var r = this.style;
      this.__isEmptyBrush ? (r.stroke = e, r.fill = t || "#fff", r.lineWidth = 2) : this.shape.symbolType === "line" ? r.stroke = e : r.fill = e, this.markRedraw();
    }
  }
  Fn = function(e, t, r, n, i, a, o) {
    var s = e.indexOf("empty") === 0;
    s && (e = e.substr(5, 1).toLowerCase() + e.substr(6));
    var u;
    return e.indexOf("image://") === 0 ? u = of(e.slice(8), new at(t, r, n, i), o ? "center" : "cover") : e.indexOf("path://") === 0 ? u = ts(e.slice(7), {}, new at(t, r, n, i), o ? "center" : "cover") : u = new $T({
      shape: {
        symbolType: e,
        x: t,
        y: r,
        width: n,
        height: i
      }
    }), u.__isEmptyBrush = s, u.setColor = ZT, a && u.setColor(a), u;
  };
  function c0(e) {
    return B(e) || (e = [
      +e,
      +e
    ]), [
      e[0] || 0,
      e[1] || 0
    ];
  }
  p0 = function(e, t) {
    if (e != null) return B(e) || (e = [
      e,
      e
    ]), [
      Ut(e[0], t[0]) || 0,
      Ut(W(e[1], e[0]), t[1]) || 0
    ];
  };
  function Xr(e) {
    return isFinite(e);
  }
  function KT(e, t, r) {
    var n = t.x == null ? 0 : t.x, i = t.x2 == null ? 1 : t.x2, a = t.y == null ? 0 : t.y, o = t.y2 == null ? 0 : t.y2;
    t.global || (n = n * r.width + r.x, i = i * r.width + r.x, a = a * r.height + r.y, o = o * r.height + r.y), n = Xr(n) ? n : 0, i = Xr(i) ? i : 1, a = Xr(a) ? a : 0, o = Xr(o) ? o : 0;
    var s = e.createLinearGradient(n, a, i, o);
    return s;
  }
  function jT(e, t, r) {
    var n = r.width, i = r.height, a = Math.min(n, i), o = t.x == null ? 0.5 : t.x, s = t.y == null ? 0.5 : t.y, u = t.r == null ? 0.5 : t.r;
    t.global || (o = o * n + r.x, s = s * i + r.y, u = u * a), o = Xr(o) ? o : 0.5, s = Xr(s) ? s : 0.5, u = u >= 0 && Xr(u) ? u : 0.5;
    var l = e.createRadialGradient(o, s, 0, o, s, u);
    return l;
  }
  dc = function(e, t, r) {
    for (var n = t.type === "radial" ? jT(e, t, r) : KT(e, t, r), i = t.colorStops, a = 0; a < i.length; a++) n.addColorStop(i[a].offset, i[a].color);
    return n;
  };
  function QT(e, t) {
    if (e === t || !e && !t) return false;
    if (!e || !t || e.length !== t.length) return true;
    for (var r = 0; r < e.length; r++) if (e[r] !== t[r]) return true;
    return false;
  }
  function Na(e) {
    return parseInt(e, 10);
  }
  gc = function(e, t, r) {
    var n = [
      "width",
      "height"
    ][t], i = [
      "clientWidth",
      "clientHeight"
    ][t], a = [
      "paddingLeft",
      "paddingTop"
    ][t], o = [
      "paddingRight",
      "paddingBottom"
    ][t];
    if (r[n] != null && r[n] !== "auto") return parseFloat(r[n]);
    var s = document.defaultView.getComputedStyle(e);
    return (e[i] || Na(s[n]) || Na(e.style[n])) - (Na(s[a]) || 0) - (Na(s[o]) || 0) | 0;
  };
  function JT(e, t) {
    return !e || e === "solid" || !(t > 0) ? null : e === "dashed" ? [
      4 * t,
      2 * t
    ] : e === "dotted" ? [
      t
    ] : lt(e) ? [
      e
    ] : B(e) ? e : null;
  }
  function xf(e) {
    var t = e.style, r = t.lineDash && t.lineWidth > 0 && JT(t.lineDash, t.lineWidth), n = t.lineDashOffset;
    if (r) {
      var i = t.strokeNoScale && e.getLineScale ? e.getLineScale() : 1;
      i && i !== 1 && (r = F(r, function(a) {
        return a / i;
      }), n /= i);
    }
    return [
      r,
      n
    ];
  }
  var tM = new yr(true);
  function Do(e) {
    var t = e.stroke;
    return !(t == null || t === "none" || !(e.lineWidth > 0));
  }
  function yc(e) {
    return typeof e == "string" && e !== "none";
  }
  function xo(e) {
    var t = e.fill;
    return t != null && t !== "none";
  }
  function mc(e, t) {
    if (t.fillOpacity != null && t.fillOpacity !== 1) {
      var r = e.globalAlpha;
      e.globalAlpha = t.fillOpacity * t.opacity, e.fill(), e.globalAlpha = r;
    } else e.fill();
  }
  function _c(e, t) {
    if (t.strokeOpacity != null && t.strokeOpacity !== 1) {
      var r = e.globalAlpha;
      e.globalAlpha = t.strokeOpacity * t.opacity, e.stroke(), e.globalAlpha = r;
    } else e.stroke();
  }
  Sc = function(e, t, r) {
    var n = jl(t.image, t.__image, r);
    if (Wo(n)) {
      var i = e.createPattern(n, t.repeat || "repeat");
      if (typeof DOMMatrix == "function" && i && i.setTransform) {
        var a = new DOMMatrix();
        a.translateSelf(t.x || 0, t.y || 0), a.rotateSelf(0, 0, (t.rotation || 0) * Di), a.scaleSelf(t.scaleX || 1, t.scaleY || 1), i.setTransform(a);
      }
      return i;
    }
  };
  function eM(e, t, r, n) {
    var i, a = Do(r), o = xo(r), s = r.strokePercent, u = s < 1, l = !t.path;
    (!t.silent || u) && l && t.createPathProxy();
    var f = t.path || tM, h = t.__dirty;
    if (!n) {
      var c = r.fill, v = r.stroke, p = o && !!c.colorStops, y = a && !!v.colorStops, g = o && !!c.image, d = a && !!v.image, m = void 0, _ = void 0, S = void 0, T = void 0, b = void 0;
      (p || y) && (b = t.getBoundingRect()), p && (m = h ? dc(e, c, b) : t.__canvasFillGradient, t.__canvasFillGradient = m), y && (_ = h ? dc(e, v, b) : t.__canvasStrokeGradient, t.__canvasStrokeGradient = _), g && (S = h || !t.__canvasFillPattern ? Sc(e, c, t) : t.__canvasFillPattern, t.__canvasFillPattern = S), d && (T = h || !t.__canvasStrokePattern ? Sc(e, v, t) : t.__canvasStrokePattern, t.__canvasStrokePattern = S), p ? e.fillStyle = m : g && (S ? e.fillStyle = S : o = false), y ? e.strokeStyle = _ : d && (T ? e.strokeStyle = T : a = false);
    }
    var w = t.getGlobalScale();
    f.setScale(w[0], w[1], t.segmentIgnoreThreshold);
    var D, C;
    e.setLineDash && r.lineDash && (i = xf(t), D = i[0], C = i[1]);
    var M = true;
    (l || h & wn) && (f.setDPR(e.dpr), u ? f.setContext(null) : (f.setContext(e), M = false), f.reset(), t.buildPath(f, t.shape, n), f.toStatic(), t.pathUpdated()), M && f.rebuildPath(e, u ? s : 1), D && (e.setLineDash(D), e.lineDashOffset = C), n || (r.strokeFirst ? (a && _c(e, r), o && mc(e, r)) : (o && mc(e, r), a && _c(e, r))), D && e.setLineDash([]);
  }
  function rM(e, t, r) {
    var n = t.__image = jl(r.image, t.__image, t, t.onload);
    if (!(!n || !Wo(n))) {
      var i = r.x || 0, a = r.y || 0, o = t.getWidth(), s = t.getHeight(), u = n.width / n.height;
      if (o == null && s != null ? o = s * u : s == null && o != null ? s = o / u : o == null && s == null && (o = n.width, s = n.height), r.sWidth && r.sHeight) {
        var l = r.sx || 0, f = r.sy || 0;
        e.drawImage(n, l, f, r.sWidth, r.sHeight, i, a, o, s);
      } else if (r.sx && r.sy) {
        var l = r.sx, f = r.sy, h = o - l, c = s - f;
        e.drawImage(n, l, f, h, c, i, a, o, s);
      } else e.drawImage(n, i, a, o, s);
    }
  }
  function nM(e, t, r) {
    var n, i = r.text;
    if (i != null && (i += ""), i) {
      e.font = r.font || pr, e.textAlign = r.textAlign, e.textBaseline = r.textBaseline;
      var a = void 0, o = void 0;
      e.setLineDash && r.lineDash && (n = xf(t), a = n[0], o = n[1]), a && (e.setLineDash(a), e.lineDashOffset = o), r.strokeFirst ? (Do(r) && e.strokeText(i, r.x, r.y), xo(r) && e.fillText(i, r.x, r.y)) : (xo(r) && e.fillText(i, r.x, r.y), Do(r) && e.strokeText(i, r.x, r.y)), a && e.setLineDash([]);
    }
  }
  var bc = [
    "shadowBlur",
    "shadowOffsetX",
    "shadowOffsetY"
  ], wc = [
    [
      "lineCap",
      "butt"
    ],
    [
      "lineJoin",
      "miter"
    ],
    [
      "miterLimit",
      10
    ]
  ];
  function d0(e, t, r, n, i) {
    var a = false;
    if (!n && (r = r || {}, t === r)) return false;
    if (n || t.opacity !== r.opacity) {
      Bt(e, i), a = true;
      var o = Math.max(Math.min(t.opacity, 1), 0);
      e.globalAlpha = isNaN(o) ? Kr.opacity : o;
    }
    (n || t.blend !== r.blend) && (a || (Bt(e, i), a = true), e.globalCompositeOperation = t.blend || Kr.blend);
    for (var s = 0; s < bc.length; s++) {
      var u = bc[s];
      (n || t[u] !== r[u]) && (a || (Bt(e, i), a = true), e[u] = e.dpr * (t[u] || 0));
    }
    return (n || t.shadowColor !== r.shadowColor) && (a || (Bt(e, i), a = true), e.shadowColor = t.shadowColor || Kr.shadowColor), a;
  }
  function Tc(e, t, r, n, i) {
    var a = ji(t, i.inHover), o = n ? null : r && ji(r, i.inHover) || {};
    if (a === o) return false;
    var s = d0(e, a, o, n, i);
    if ((n || a.fill !== o.fill) && (s || (Bt(e, i), s = true), yc(a.fill) && (e.fillStyle = a.fill)), (n || a.stroke !== o.stroke) && (s || (Bt(e, i), s = true), yc(a.stroke) && (e.strokeStyle = a.stroke)), (n || a.opacity !== o.opacity) && (s || (Bt(e, i), s = true), e.globalAlpha = a.opacity == null ? 1 : a.opacity), t.hasStroke()) {
      var u = a.lineWidth, l = u / (a.strokeNoScale && t.getLineScale ? t.getLineScale() : 1);
      e.lineWidth !== l && (s || (Bt(e, i), s = true), e.lineWidth = l);
    }
    for (var f = 0; f < wc.length; f++) {
      var h = wc[f], c = h[0];
      (n || a[c] !== o[c]) && (s || (Bt(e, i), s = true), e[c] = a[c] || h[1]);
    }
    return s;
  }
  function iM(e, t, r, n, i) {
    return d0(e, ji(t, i.inHover), r && ji(r, i.inHover), n, i);
  }
  function g0(e, t) {
    var r = t.transform, n = e.dpr || 1;
    r ? e.setTransform(n * r[0], n * r[1], n * r[2], n * r[3], n * r[4], n * r[5]) : e.setTransform(n, 0, 0, n, 0, 0);
  }
  function aM(e, t, r) {
    for (var n = false, i = 0; i < e.length; i++) {
      var a = e[i];
      n = n || a.isZeroArea(), g0(t, a), t.beginPath(), a.buildPath(t, a.shape), t.clip();
    }
    r.allClipped = n;
  }
  function oM(e, t) {
    return e && t ? e[0] !== t[0] || e[1] !== t[1] || e[2] !== t[2] || e[3] !== t[3] || e[4] !== t[4] || e[5] !== t[5] : !(!e && !t);
  }
  var Mc = 1, Cc = 2, Dc = 3, xc = 4;
  function sM(e) {
    var t = xo(e), r = Do(e);
    return !(e.lineDash || !(+t ^ +r) || t && typeof e.fill != "string" || r && typeof e.stroke != "string" || e.strokePercent < 1 || e.strokeOpacity < 1 || e.fillOpacity < 1);
  }
  function Bt(e, t) {
    t.batchFill && e.fill(), t.batchStroke && e.stroke(), t.batchFill = "", t.batchStroke = "";
  }
  function ji(e, t) {
    return t && e.__hoverStyle || e.style;
  }
  y0 = function(e, t) {
    Tl(e, t, {
      inHover: false,
      viewWidth: 0,
      viewHeight: 0
    }, true);
  };
  Tl = function(e, t, r, n) {
    var i = t.transform;
    if (!t.shouldBePainted(r.viewWidth, r.viewHeight, false, false)) {
      t.__dirty &= ~xe, t.__isRendered = false;
      return;
    }
    var a = t.__clipPaths, o = r.prevElClipPaths, s = false, u = false;
    if ((!o || QT(a, o)) && (o && o.length && (Bt(e, r), e.restore(), u = s = true, r.prevElClipPaths = null, r.allClipped = false, r.prevEl = null), a && a.length && (Bt(e, r), e.save(), aM(a, e, r), s = true), r.prevElClipPaths = a), r.allClipped) {
      t.__isRendered = false;
      return;
    }
    t.beforeBrush && t.beforeBrush(), t.innerBeforeBrush();
    var l = r.prevEl;
    l || (u = s = true);
    var f = t instanceof et && t.autoBatch && sM(t.style);
    s || oM(i, l.transform) ? (Bt(e, r), g0(e, t)) : f || Bt(e, r);
    var h = ji(t, r.inHover);
    t instanceof et ? (r.lastDrawType !== Mc && (u = true, r.lastDrawType = Mc), Tc(e, t, l, u, r), (!f || !r.batchFill && !r.batchStroke) && e.beginPath(), eM(e, t, h, f), f && (r.batchFill = h.fill || "", r.batchStroke = h.stroke || "")) : t instanceof Xi ? (r.lastDrawType !== Dc && (u = true, r.lastDrawType = Dc), Tc(e, t, l, u, r), nM(e, t, h)) : t instanceof Se ? (r.lastDrawType !== Cc && (u = true, r.lastDrawType = Cc), iM(e, t, l, u, r), rM(e, t, h)) : t.getTemporalDisplayables && (r.lastDrawType !== xc && (u = true, r.lastDrawType = xc), uM(e, t, r)), f && n && Bt(e, r), t.innerAfterBrush(), t.afterBrush && t.afterBrush(), r.prevEl = t, t.__dirty = 0, t.__isRendered = true;
  };
  function uM(e, t, r) {
    var n = t.getDisplayables(), i = t.getTemporalDisplayables();
    e.save();
    var a = {
      prevElClipPaths: null,
      prevEl: null,
      allClipped: false,
      viewWidth: r.viewWidth,
      viewHeight: r.viewHeight,
      inHover: r.inHover
    }, o, s;
    for (o = t.getCursor(), s = n.length; o < s; o++) {
      var u = n[o];
      u.beforeBrush && u.beforeBrush(), u.innerBeforeBrush(), Tl(e, u, a, o === s - 1), u.innerAfterBrush(), u.afterBrush && u.afterBrush(), a.prevEl = u;
    }
    for (var l = 0, f = i.length; l < f; l++) {
      var u = i[l];
      u.beforeBrush && u.beforeBrush(), u.innerBeforeBrush(), Tl(e, u, a, l === f - 1), u.innerAfterBrush(), u.afterBrush && u.afterBrush(), a.prevEl = u;
    }
    t.clearTemporalDisplayables(), t.notClear = true, e.restore();
  }
  var du = new GT(), Pc = new ra(100), Ic = [
    "symbol",
    "symbolSize",
    "symbolKeepAspect",
    "color",
    "backgroundColor",
    "dashArrayX",
    "dashArrayY",
    "maxTileWidth",
    "maxTileHeight"
  ];
  Ac = function(e, t) {
    if (e === "none") return null;
    var r = t.getDevicePixelRatio(), n = t.getZr(), i = n.painter.type === "svg";
    e.dirty && du.delete(e);
    var a = du.get(e);
    if (a) return a;
    var o = ht(e, {
      symbol: "rect",
      symbolSize: 1,
      symbolKeepAspect: true,
      color: "rgba(0, 0, 0, 0.2)",
      backgroundColor: null,
      dashArrayX: 5,
      dashArrayY: 5,
      rotation: 0,
      maxTileWidth: 512,
      maxTileHeight: 512
    });
    o.backgroundColor === "none" && (o.backgroundColor = null);
    var s = {
      repeat: "repeat"
    };
    return u(s), s.rotation = o.rotation, s.scaleX = s.scaleY = i ? 1 : 1 / r, du.set(e, s), e.dirty = false, s;
    function u(l) {
      for (var f = [
        r
      ], h = true, c = 0; c < Ic.length; ++c) {
        var v = o[Ic[c]];
        if (v != null && !B(v) && !V(v) && !lt(v) && typeof v != "boolean") {
          h = false;
          break;
        }
        f.push(v);
      }
      var p;
      if (h) {
        p = f.join(",") + (i ? "-svg" : "");
        var y = Pc.get(p);
        y && (i ? l.svgElement = y : l.image = y);
      }
      var g = _0(o.dashArrayX), d = lM(o.dashArrayY), m = m0(o.symbol), _ = fM(g), S = S0(d), T = !i && dr.createCanvas(), b = i && {
        tag: "g",
        attrs: {},
        key: "dcl",
        children: []
      }, w = C(), D;
      T && (T.width = w.width * r, T.height = w.height * r, D = T.getContext("2d")), M(), h && Pc.put(p, T || b), l.image = T, l.svgElement = b, l.svgWidth = w.width, l.svgHeight = w.height;
      function C() {
        for (var x = 1, I = 0, A = _.length; I < A; ++I) x = Vh(x, _[I]);
        for (var E = 1, I = 0, A = m.length; I < A; ++I) E = Vh(E, m[I].length);
        x *= E;
        var R = S * _.length * m.length;
        return {
          width: Math.max(1, Math.min(x, o.maxTileWidth)),
          height: Math.max(1, Math.min(R, o.maxTileHeight))
        };
      }
      function M() {
        D && (D.clearRect(0, 0, T.width, T.height), o.backgroundColor && (D.fillStyle = o.backgroundColor, D.fillRect(0, 0, T.width, T.height)));
        for (var x = 0, I = 0; I < d.length; ++I) x += d[I];
        if (x <= 0) return;
        for (var A = -S, E = 0, R = 0, L = 0; A < w.height; ) {
          if (E % 2 === 0) {
            for (var z = R / 2 % m.length, k = 0, N = 0, U = 0; k < w.width * 2; ) {
              for (var J = 0, I = 0; I < g[L].length; ++I) J += g[L][I];
              if (J <= 0) break;
              if (N % 2 === 0) {
                var $ = (1 - o.symbolSize) * 0.5, rt = k + g[L][N] * $, tt = A + d[E] * $, st = g[L][N] * o.symbolSize, Gt = d[E] * o.symbolSize, Fe = U / 2 % m[z].length;
                le(rt, tt, st, Gt, m[z][Fe]);
              }
              k += g[L][N], ++U, ++N, N === g[L].length && (N = 0);
            }
            ++L, L === g.length && (L = 0);
          }
          A += d[E], ++R, ++E, E === d.length && (E = 0);
        }
        function le(St, dt, H, X, fe) {
          var gt = i ? 1 : r, qn = Fn(fe, St * gt, dt * gt, H * gt, X * gt, o.color, o.symbolKeepAspect);
          if (i) {
            var _r = n.painter.renderOneToVNode(qn);
            _r && b.children.push(_r);
          } else y0(D, qn);
        }
      }
    }
  };
  function m0(e) {
    if (!e || e.length === 0) return [
      [
        "rect"
      ]
    ];
    if (V(e)) return [
      [
        e
      ]
    ];
    for (var t = true, r = 0; r < e.length; ++r) if (!V(e[r])) {
      t = false;
      break;
    }
    if (t) return m0([
      e
    ]);
    for (var n = [], r = 0; r < e.length; ++r) V(e[r]) ? n.push([
      e[r]
    ]) : n.push(e[r]);
    return n;
  }
  function _0(e) {
    if (!e || e.length === 0) return [
      [
        0,
        0
      ]
    ];
    if (lt(e)) {
      var t = Math.ceil(e);
      return [
        [
          t,
          t
        ]
      ];
    }
    for (var r = true, n = 0; n < e.length; ++n) if (!lt(e[n])) {
      r = false;
      break;
    }
    if (r) return _0([
      e
    ]);
    for (var i = [], n = 0; n < e.length; ++n) if (lt(e[n])) {
      var t = Math.ceil(e[n]);
      i.push([
        t,
        t
      ]);
    } else {
      var t = F(e[n], function(s) {
        return Math.ceil(s);
      });
      t.length % 2 === 1 ? i.push(t.concat(t)) : i.push(t);
    }
    return i;
  }
  function lM(e) {
    if (!e || typeof e == "object" && e.length === 0) return [
      0,
      0
    ];
    if (lt(e)) {
      var t = Math.ceil(e);
      return [
        t,
        t
      ];
    }
    var r = F(e, function(n) {
      return Math.ceil(n);
    });
    return e.length % 2 ? r.concat(r) : r;
  }
  function fM(e) {
    return F(e, function(t) {
      return S0(t);
    });
  }
  function S0(e) {
    for (var t = 0, r = 0; r < e.length; ++r) t += e[r];
    return e.length % 2 === 1 ? t * 2 : t;
  }
  function hM(e, t) {
    e.eachRawSeries(function(r) {
      if (!e.isSeriesFiltered(r)) {
        var n = r.getData();
        n.hasItemVisual() && n.each(function(o) {
          var s = n.getItemVisual(o, "decal");
          if (s) {
            var u = n.ensureUniqueItemVisual(o, "style");
            u.decal = Ac(s, t);
          }
        });
        var i = n.getVisual("decal");
        if (i) {
          var a = n.getVisual("style");
          a.decal = Ac(i, t);
        }
      }
    });
  }
  var ge = new $e(), b0 = {};
  function vM(e, t) {
    b0[e] = t;
  }
  function w0(e) {
    return b0[e];
  }
  var cM = "5.6.0", pM = {
    zrender: "5.6.1"
  }, dM = 1, gM = 800, yM = 900, mM = 1e3, _M = 2e3, SM = 5e3, T0 = 1e3, bM = 1100, Pf = 2e3, M0 = 3e3, wM = 4e3, hs = 4500, TM = 4600, MM = 5e3, CM = 6e3, C0 = 7e3, D0 = {
    PROCESSOR: {
      FILTER: mM,
      SERIES_FILTER: gM,
      STATISTIC: SM
    },
    VISUAL: {
      LAYOUT: T0,
      PROGRESSIVE_LAYOUT: bM,
      GLOBAL: Pf,
      CHART: M0,
      POST_CHART_LAYOUT: TM,
      COMPONENT: wM,
      BRUSH: MM,
      CHART_ITEM: hs,
      ARIA: CM,
      DECAL: C0
    }
  }, Ct = "__flagInMainProcess", Nt = "__pendingUpdate", gu = "__needsUpdateStatus", Ec = /^[a-zA-Z0-9_]+$/, yu = "__connectUpdateStatus", Lc = 0, DM = 1, xM = 2;
  function x0(e) {
    return function() {
      for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
      if (this.isDisposed()) {
        this.id;
        return;
      }
      return I0(this, e, t);
    };
  }
  function P0(e) {
    return function() {
      for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
      return I0(this, e, t);
    };
  }
  function I0(e, t, r) {
    return r[0] = r[0] && r[0].toLowerCase(), $e.prototype[t].apply(e, r);
  }
  var A0 = (function(e) {
    ft(t, e);
    function t() {
      return e !== null && e.apply(this, arguments) || this;
    }
    return t;
  })($e), E0 = A0.prototype;
  E0.on = P0("on");
  E0.off = P0("off");
  var Sn, mu, Fa, tr, _u, Su, bu, hi, vi, Rc, Oc, wu, kc, Ba, Nc, L0, Zt, Fc, Po = (function(e) {
    ft(t, e);
    function t(r, n, i) {
      var a = e.call(this, new RT()) || this;
      a._chartsViews = [], a._chartsMap = {}, a._componentsViews = [], a._componentsMap = {}, a._pendingActions = [], i = i || {}, V(n) && (n = R0[n]), a._dom = r;
      var o = "canvas", s = "auto", u = false;
      i.ssr && yd(function(c) {
        var v = mt(c), p = v.dataIndex;
        if (p != null) {
          var y = q();
          return y.set("series_index", v.seriesIndex), y.set("data_index", p), v.ssrType && y.set("ssr_type", v.ssrType), y;
        }
      });
      var l = a._zr = tl(r, {
        renderer: i.renderer || o,
        devicePixelRatio: i.devicePixelRatio,
        width: i.width,
        height: i.height,
        ssr: i.ssr,
        useDirtyRect: W(i.useDirtyRect, u),
        useCoarsePointer: W(i.useCoarsePointer, s),
        pointerSize: i.pointerSize
      });
      a._ssr = i.ssr, a._throttledZrFlush = Df(ut(l.flush, l), 17), n = Z(n), n && Gg(n, true), a._theme = n, a._locale = zb(i.locale || Sg), a._coordSysMgr = new us();
      var f = a._api = Nc(a);
      function h(c, v) {
        return c.__prio - v.__prio;
      }
      return Ya(Ao, h), Ya(Ml, h), a._scheduler = new u0(a, f, Ml, Ao), a._messageCenter = new A0(), a._initEvents(), a.resize = ut(a.resize, a), l.animation.on("frame", a._onframe, a), Rc(l, a), Oc(l, a), ao(a), a;
    }
    return t.prototype._onframe = function() {
      if (!this._disposed) {
        Fc(this);
        var r = this._scheduler;
        if (this[Nt]) {
          var n = this[Nt].silent;
          this[Ct] = true;
          try {
            Sn(this), tr.update.call(this, null, this[Nt].updateParams);
          } catch (u) {
            throw this[Ct] = false, this[Nt] = null, u;
          }
          this._zr.flush(), this[Ct] = false, this[Nt] = null, hi.call(this, n), vi.call(this, n);
        } else if (r.unfinished) {
          var i = dM, a = this._model, o = this._api;
          r.unfinished = false;
          do {
            var s = +/* @__PURE__ */ new Date();
            r.performSeriesTasks(a), r.performDataProcessorTasks(a), Su(this, a), r.performVisualTasks(a), Ba(this, this._model, o, "remain", {}), i -= +/* @__PURE__ */ new Date() - s;
          } while (i > 0 && r.unfinished);
          r.unfinished || this._zr.flush();
        }
      }
    }, t.prototype.getDom = function() {
      return this._dom;
    }, t.prototype.getId = function() {
      return this.id;
    }, t.prototype.getZr = function() {
      return this._zr;
    }, t.prototype.isSSR = function() {
      return this._ssr;
    }, t.prototype.setOption = function(r, n, i) {
      if (!this[Ct]) {
        if (this._disposed) {
          this.id;
          return;
        }
        var a, o, s;
        if (G(n) && (i = n.lazyUpdate, a = n.silent, o = n.replaceMerge, s = n.transition, n = n.notMerge), this[Ct] = true, !this._model || n) {
          var u = new pw(this._api), l = this._theme, f = this._model = new wf();
          f.scheduler = this._scheduler, f.ssr = this._ssr, f.init(null, null, null, l, this._locale, u);
        }
        this._model.setOption(r, {
          replaceMerge: o
        }, Cl);
        var h = {
          seriesTransition: s,
          optionChanged: true
        };
        if (i) this[Nt] = {
          silent: a,
          updateParams: h
        }, this[Ct] = false, this.getZr().wakeUp();
        else {
          try {
            Sn(this), tr.update.call(this, null, h);
          } catch (c) {
            throw this[Nt] = null, this[Ct] = false, c;
          }
          this._ssr || this._zr.flush(), this[Nt] = null, this[Ct] = false, hi.call(this, a), vi.call(this, a);
        }
      }
    }, t.prototype.setTheme = function() {
    }, t.prototype.getModel = function() {
      return this._model;
    }, t.prototype.getOption = function() {
      return this._model && this._model.getOption();
    }, t.prototype.getWidth = function() {
      return this._zr.getWidth();
    }, t.prototype.getHeight = function() {
      return this._zr.getHeight();
    }, t.prototype.getDevicePixelRatio = function() {
      return this._zr.painter.dpr || j.hasGlobalWindow && window.devicePixelRatio || 1;
    }, t.prototype.getRenderedCanvas = function(r) {
      return this.renderToCanvas(r);
    }, t.prototype.renderToCanvas = function(r) {
      r = r || {};
      var n = this._zr.painter;
      return n.getRenderedCanvas({
        backgroundColor: r.backgroundColor || this._model.get("backgroundColor"),
        pixelRatio: r.pixelRatio || this.getDevicePixelRatio()
      });
    }, t.prototype.renderToSVGString = function(r) {
      r = r || {};
      var n = this._zr.painter;
      return n.renderToString({
        useViewBox: r.useViewBox
      });
    }, t.prototype.getSvgDataURL = function() {
      if (j.svgSupported) {
        var r = this._zr, n = r.storage.getDisplayList();
        return P(n, function(i) {
          i.stopAnimation(null, true);
        }), r.painter.toDataURL();
      }
    }, t.prototype.getDataURL = function(r) {
      if (this._disposed) {
        this.id;
        return;
      }
      r = r || {};
      var n = r.excludeComponents, i = this._model, a = [], o = this;
      P(n, function(u) {
        i.eachComponent({
          mainType: u
        }, function(l) {
          var f = o._componentsMap[l.__viewId];
          f.group.ignore || (a.push(f), f.group.ignore = true);
        });
      });
      var s = this._zr.painter.getType() === "svg" ? this.getSvgDataURL() : this.renderToCanvas(r).toDataURL("image/" + (r && r.type || "png"));
      return P(a, function(u) {
        u.group.ignore = false;
      }), s;
    }, t.prototype.getConnectedDataURL = function(r) {
      if (this._disposed) {
        this.id;
        return;
      }
      var n = r.type === "svg", i = this.group, a = Math.min, o = Math.max, s = 1 / 0;
      if (Eo[i]) {
        var u = s, l = s, f = -s, h = -s, c = [], v = r && r.pixelRatio || this.getDevicePixelRatio();
        P(Qr, function(_, S) {
          if (_.group === i) {
            var T = n ? _.getZr().painter.getSvgDom().innerHTML : _.renderToCanvas(Z(r)), b = _.getDom().getBoundingClientRect();
            u = a(b.left, u), l = a(b.top, l), f = o(b.right, f), h = o(b.bottom, h), c.push({
              dom: T,
              left: b.left,
              top: b.top
            });
          }
        }), u *= v, l *= v, f *= v, h *= v;
        var p = f - u, y = h - l, g = dr.createCanvas(), d = tl(g, {
          renderer: n ? "svg" : "canvas"
        });
        if (d.resize({
          width: p,
          height: y
        }), n) {
          var m = "";
          return P(c, function(_) {
            var S = _.left - u, T = _.top - l;
            m += '<g transform="translate(' + S + "," + T + ')">' + _.dom + "</g>";
          }), d.painter.getSvgRoot().innerHTML = m, r.connectedBackgroundColor && d.painter.setBackgroundColor(r.connectedBackgroundColor), d.refreshImmediately(), d.painter.toDataURL();
        } else return r.connectedBackgroundColor && d.add(new ne({
          shape: {
            x: 0,
            y: 0,
            width: p,
            height: y
          },
          style: {
            fill: r.connectedBackgroundColor
          }
        })), P(c, function(_) {
          var S = new Se({
            style: {
              x: _.left * v - u,
              y: _.top * v - l,
              image: _.dom
            }
          });
          d.add(S);
        }), d.refreshImmediately(), g.toDataURL("image/" + (r && r.type || "png"));
      } else return this.getDataURL(r);
    }, t.prototype.convertToPixel = function(r, n) {
      return _u(this, "convertToPixel", r, n);
    }, t.prototype.convertFromPixel = function(r, n) {
      return _u(this, "convertFromPixel", r, n);
    }, t.prototype.containPixel = function(r, n) {
      if (this._disposed) {
        this.id;
        return;
      }
      var i = this._model, a, o = Us(i, r);
      return P(o, function(s, u) {
        u.indexOf("Models") >= 0 && P(s, function(l) {
          var f = l.coordinateSystem;
          if (f && f.containPoint) a = a || !!f.containPoint(n);
          else if (u === "seriesModels") {
            var h = this._chartsMap[l.__viewId];
            h && h.containPoint && (a = a || h.containPoint(n, l));
          }
        }, this);
      }, this), !!a;
    }, t.prototype.getVisual = function(r, n) {
      var i = this._model, a = Us(i, r, {
        defaultMainType: "series"
      }), o = a.seriesModel, s = o.getData(), u = a.hasOwnProperty("dataIndexInside") ? a.dataIndexInside : a.hasOwnProperty("dataIndex") ? s.indexOfRawIndex(a.dataIndex) : null;
      return u != null ? NT(s, u, n) : FT(s, n);
    }, t.prototype.getViewOfComponentModel = function(r) {
      return this._componentsMap[r.__viewId];
    }, t.prototype.getViewOfSeriesModel = function(r) {
      return this._chartsMap[r.__viewId];
    }, t.prototype._initEvents = function() {
      var r = this;
      P(PM, function(n) {
        var i = function(a) {
          var o = r.getModel(), s = a.target, u, l = n === "globalout";
          if (l ? u = {} : s && ka(s, function(p) {
            var y = mt(p);
            if (y && y.dataIndex != null) {
              var g = y.dataModel || o.getSeriesByIndex(y.seriesIndex);
              return u = g && g.getDataParams(y.dataIndex, y.dataType, s) || {}, true;
            } else if (y.eventData) return u = O({}, y.eventData), true;
          }, true), u) {
            var f = u.componentType, h = u.componentIndex;
            (f === "markLine" || f === "markPoint" || f === "markArea") && (f = "series", h = u.seriesIndex);
            var c = f && h != null && o.getComponent(f, h), v = c && r[c.mainType === "series" ? "_chartsMap" : "_componentsMap"][c.__viewId];
            u.event = a, u.type = n, r._$eventProcessor.eventInfo = {
              targetEl: s,
              packedEvent: u,
              model: c,
              view: v
            }, r.trigger(n, u);
          }
        };
        i.zrEventfulCallAtLast = true, r._zr.on(n, i, r);
      }), P(Ni, function(n, i) {
        r._messageCenter.on(i, function(a) {
          this.trigger(i, a);
        }, r);
      }), P([
        "selectchanged"
      ], function(n) {
        r._messageCenter.on(n, function(i) {
          this.trigger(n, i);
        }, r);
      }), BT(this._messageCenter, this, this._api);
    }, t.prototype.isDisposed = function() {
      return this._disposed;
    }, t.prototype.clear = function() {
      if (this._disposed) {
        this.id;
        return;
      }
      this.setOption({
        series: []
      }, true);
    }, t.prototype.dispose = function() {
      if (this._disposed) {
        this.id;
        return;
      }
      this._disposed = true;
      var r = this.getDom();
      r && Ed(this.getDom(), Af, "");
      var n = this, i = n._api, a = n._model;
      P(n._componentsViews, function(o) {
        o.dispose(a, i);
      }), P(n._chartsViews, function(o) {
        o.dispose(a, i);
      }), n._zr.dispose(), n._dom = n._model = n._chartsMap = n._componentsMap = n._chartsViews = n._componentsViews = n._scheduler = n._api = n._zr = n._throttledZrFlush = n._theme = n._coordSysMgr = n._messageCenter = null, delete Qr[n.id];
    }, t.prototype.resize = function(r) {
      if (!this[Ct]) {
        if (this._disposed) {
          this.id;
          return;
        }
        this._zr.resize(r);
        var n = this._model;
        if (this._loadingFX && this._loadingFX.resize(), !!n) {
          var i = n.resetOption("media"), a = r && r.silent;
          this[Nt] && (a == null && (a = this[Nt].silent), i = true, this[Nt] = null), this[Ct] = true;
          try {
            i && Sn(this), tr.update.call(this, {
              type: "resize",
              animation: O({
                duration: 0
              }, r && r.animation)
            });
          } catch (o) {
            throw this[Ct] = false, o;
          }
          this[Ct] = false, hi.call(this, a), vi.call(this, a);
        }
      }
    }, t.prototype.showLoading = function(r, n) {
      if (this._disposed) {
        this.id;
        return;
      }
      if (G(r) && (n = r, r = ""), r = r || "default", this.hideLoading(), !!Dl[r]) {
        var i = Dl[r](this._api, n), a = this._zr;
        this._loadingFX = i, a.add(i);
      }
    }, t.prototype.hideLoading = function() {
      if (this._disposed) {
        this.id;
        return;
      }
      this._loadingFX && this._zr.remove(this._loadingFX), this._loadingFX = null;
    }, t.prototype.makeActionFromEvent = function(r) {
      var n = O({}, r);
      return n.type = Ni[r.type], n;
    }, t.prototype.dispatchAction = function(r, n) {
      if (this._disposed) {
        this.id;
        return;
      }
      if (G(n) || (n = {
        silent: !!n
      }), !!Io[r.type] && this._model) {
        if (this[Ct]) {
          this._pendingActions.push(r);
          return;
        }
        var i = n.silent;
        bu.call(this, r, i);
        var a = n.flush;
        a ? this._zr.flush() : a !== false && j.browser.weChat && this._throttledZrFlush(), hi.call(this, i), vi.call(this, i);
      }
    }, t.prototype.updateLabelLayout = function() {
      ge.trigger("series:layoutlabels", this._model, this._api, {
        updatedSeries: []
      });
    }, t.prototype.appendData = function(r) {
      if (this._disposed) {
        this.id;
        return;
      }
      var n = r.seriesIndex, i = this.getModel(), a = i.getSeriesByIndex(n);
      a.appendData(r), this._scheduler.unfinished = true, this.getZr().wakeUp();
    }, t.internalField = (function() {
      Sn = function(h) {
        var c = h._scheduler;
        c.restorePipelines(h._model), c.prepareStageTasks(), mu(h, true), mu(h, false), c.plan();
      }, mu = function(h, c) {
        for (var v = h._model, p = h._scheduler, y = c ? h._componentsViews : h._chartsViews, g = c ? h._componentsMap : h._chartsMap, d = h._zr, m = h._api, _ = 0; _ < y.length; _++) y[_].__alive = false;
        c ? v.eachComponent(function(b, w) {
          b !== "series" && S(w);
        }) : v.eachSeries(S);
        function S(b) {
          var w = b.__requireNewView;
          b.__requireNewView = false;
          var D = "_ec_" + b.id + "_" + b.type, C = !w && g[D];
          if (!C) {
            var M = Ee(b.type), x = c ? Xe.getClass(M.main, M.sub) : Xt.getClass(M.sub);
            C = new x(), C.init(v, m), g[D] = C, y.push(C), d.add(C.group);
          }
          b.__viewId = C.__id = D, C.__alive = true, C.__model = b, C.group.__ecComponentInfo = {
            mainType: b.mainType,
            index: b.componentIndex
          }, !c && p.prepareView(C, b, v, m);
        }
        for (var _ = 0; _ < y.length; ) {
          var T = y[_];
          T.__alive ? _++ : (!c && T.renderTask.dispose(), d.remove(T.group), T.dispose(v, m), y.splice(_, 1), g[T.__id] === T && delete g[T.__id], T.__id = T.group.__ecComponentInfo = null);
        }
      }, Fa = function(h, c, v, p, y) {
        var g = h._model;
        if (g.setUpdatePayload(v), !p) {
          P([].concat(h._componentsViews).concat(h._chartsViews), T);
          return;
        }
        var d = {};
        d[p + "Id"] = v[p + "Id"], d[p + "Index"] = v[p + "Index"], d[p + "Name"] = v[p + "Name"];
        var m = {
          mainType: p,
          query: d
        };
        y && (m.subType = y);
        var _ = v.excludeSeriesId, S;
        _ != null && (S = q(), P(Lt(_), function(b) {
          var w = me(b, null);
          w != null && S.set(w, true);
        })), g && g.eachComponent(m, function(b) {
          var w = S && S.get(b.id) != null;
          if (!w) if (gv(v)) if (b instanceof _e) v.type === jr && !v.notBlur && !b.get([
            "emphasis",
            "disabled"
          ]) && xS(b, v, h._api);
          else {
            var D = ef(b.mainType, b.componentIndex, v.name, h._api), C = D.focusSelf, M = D.dispatchers;
            v.type === jr && C && !v.notBlur && sl(b.mainType, b.componentIndex, h._api), M && P(M, function(x) {
              v.type === jr ? po(x) : go(x);
            });
          }
          else fl(v) && b instanceof _e && (AS(b, v, h._api), cv(b), Zt(h));
        }, h), g && g.eachComponent(m, function(b) {
          var w = S && S.get(b.id) != null;
          w || T(h[p === "series" ? "_chartsMap" : "_componentsMap"][b.__viewId]);
        }, h);
        function T(b) {
          b && b.__alive && b[c] && b[c](b.__model, g, h._api, v);
        }
      }, tr = {
        prepareAndUpdate: function(h) {
          Sn(this), tr.update.call(this, h, {
            optionChanged: h.newOption != null
          });
        },
        update: function(h, c) {
          var v = this._model, p = this._api, y = this._zr, g = this._coordSysMgr, d = this._scheduler;
          if (v) {
            v.setUpdatePayload(h), d.restoreData(v, h), d.performSeriesTasks(v), g.create(v, p), d.performDataProcessorTasks(v, h), Su(this, v), g.update(v, p), r(v), d.performVisualTasks(v, h), wu(this, v, p, h, c);
            var m = v.get("backgroundColor") || "transparent", _ = v.get("darkMode");
            y.setBackgroundColor(m), _ != null && _ !== "auto" && y.setDarkMode(_), ge.trigger("afterupdate", v, p);
          }
        },
        updateTransform: function(h) {
          var c = this, v = this._model, p = this._api;
          if (v) {
            v.setUpdatePayload(h);
            var y = [];
            v.eachComponent(function(d, m) {
              if (d !== "series") {
                var _ = c.getViewOfComponentModel(m);
                if (_ && _.__alive) if (_.updateTransform) {
                  var S = _.updateTransform(m, v, p, h);
                  S && S.update && y.push(_);
                } else y.push(_);
              }
            });
            var g = q();
            v.eachSeries(function(d) {
              var m = c._chartsMap[d.__viewId];
              if (m.updateTransform) {
                var _ = m.updateTransform(d, v, p, h);
                _ && _.update && g.set(d.uid, 1);
              } else g.set(d.uid, 1);
            }), r(v), this._scheduler.performVisualTasks(v, h, {
              setDirty: true,
              dirtyMap: g
            }), Ba(this, v, p, h, {}, g), ge.trigger("afterupdate", v, p);
          }
        },
        updateView: function(h) {
          var c = this._model;
          c && (c.setUpdatePayload(h), Xt.markUpdateMethod(h, "updateView"), r(c), this._scheduler.performVisualTasks(c, h, {
            setDirty: true
          }), wu(this, c, this._api, h, {}), ge.trigger("afterupdate", c, this._api));
        },
        updateVisual: function(h) {
          var c = this, v = this._model;
          v && (v.setUpdatePayload(h), v.eachSeries(function(p) {
            p.getData().clearAllVisual();
          }), Xt.markUpdateMethod(h, "updateVisual"), r(v), this._scheduler.performVisualTasks(v, h, {
            visualType: "visual",
            setDirty: true
          }), v.eachComponent(function(p, y) {
            if (p !== "series") {
              var g = c.getViewOfComponentModel(y);
              g && g.__alive && g.updateVisual(y, v, c._api, h);
            }
          }), v.eachSeries(function(p) {
            var y = c._chartsMap[p.__viewId];
            y.updateVisual(p, v, c._api, h);
          }), ge.trigger("afterupdate", v, this._api));
        },
        updateLayout: function(h) {
          tr.update.call(this, h);
        }
      }, _u = function(h, c, v, p) {
        if (h._disposed) {
          h.id;
          return;
        }
        for (var y = h._model, g = h._coordSysMgr.getCoordinateSystems(), d, m = Us(y, v), _ = 0; _ < g.length; _++) {
          var S = g[_];
          if (S[c] && (d = S[c](y, m, p)) != null) return d;
        }
      }, Su = function(h, c) {
        var v = h._chartsMap, p = h._scheduler;
        c.eachSeries(function(y) {
          p.updateStreamModes(y, v[y.__viewId]);
        });
      }, bu = function(h, c) {
        var v = this, p = this.getModel(), y = h.type, g = h.escapeConnect, d = Io[y], m = d.actionInfo, _ = (m.update || "update").split(":"), S = _.pop(), T = _[0] != null && Ee(_[0]);
        this[Ct] = true;
        var b = [
          h
        ], w = false;
        h.batch && (w = true, b = F(h.batch, function(E) {
          return E = ht(O({}, E), h), E.batch = null, E;
        }));
        var D = [], C, M = fl(h), x = gv(h);
        if (x && jd(this._api), P(b, function(E) {
          if (C = d.action(E, v._model, v._api), C = C || O({}, E), C.type = m.event || C.type, D.push(C), x) {
            var R = Ad(h), L = R.queryOptionMap, z = R.mainTypeSpecified, k = z ? L.keys()[0] : "series";
            Fa(v, S, E, k), Zt(v);
          } else M ? (Fa(v, S, E, "series"), Zt(v)) : T && Fa(v, S, E, T.main, T.sub);
        }), S !== "none" && !x && !M && !T) try {
          this[Nt] ? (Sn(this), tr.update.call(this, h), this[Nt] = null) : tr[S].call(this, h);
        } catch (E) {
          throw this[Ct] = false, E;
        }
        if (w ? C = {
          type: m.event || y,
          escapeConnect: g,
          batch: D
        } : C = D[0], this[Ct] = false, !c) {
          var I = this._messageCenter;
          if (I.trigger(C.type, C), M) {
            var A = {
              type: "selectchanged",
              escapeConnect: g,
              selected: ES(p),
              isFromClick: h.isFromClick || false,
              fromAction: h.type,
              fromActionPayload: h
            };
            I.trigger(A.type, A);
          }
        }
      }, hi = function(h) {
        for (var c = this._pendingActions; c.length; ) {
          var v = c.shift();
          bu.call(this, v, h);
        }
      }, vi = function(h) {
        !h && this.trigger("updated");
      }, Rc = function(h, c) {
        h.on("rendered", function(v) {
          c.trigger("rendered", v), h.animation.isFinished() && !c[Nt] && !c._scheduler.unfinished && !c._pendingActions.length && c.trigger("finished");
        });
      }, Oc = function(h, c) {
        h.on("mouseover", function(v) {
          var p = v.target, y = ka(p, ll);
          y && (PS(y, v, c._api), Zt(c));
        }).on("mouseout", function(v) {
          var p = v.target, y = ka(p, ll);
          y && (IS(y, v, c._api), Zt(c));
        }).on("click", function(v) {
          var p = v.target, y = ka(p, function(m) {
            return mt(m).dataIndex != null;
          }, true);
          if (y) {
            var g = y.selected ? "unselect" : "select", d = mt(y);
            c._api.dispatchAction({
              type: g,
              dataType: d.dataType,
              dataIndexInside: d.dataIndex,
              seriesIndex: d.seriesIndex,
              isFromClick: true
            });
          }
        });
      };
      function r(h) {
        h.clearColorPalette(), h.eachSeries(function(c) {
          c.clearColorPalette();
        });
      }
      function n(h) {
        var c = [], v = [], p = false;
        if (h.eachComponent(function(m, _) {
          var S = _.get("zlevel") || 0, T = _.get("z") || 0, b = _.getZLevelKey();
          p = p || !!b, (m === "series" ? v : c).push({
            zlevel: S,
            z: T,
            idx: _.componentIndex,
            type: m,
            key: b
          });
        }), p) {
          var y = c.concat(v), g, d;
          Ya(y, function(m, _) {
            return m.zlevel === _.zlevel ? m.z - _.z : m.zlevel - _.zlevel;
          }), P(y, function(m) {
            var _ = h.getComponent(m.type, m.idx), S = m.zlevel, T = m.key;
            g != null && (S = Math.max(g, S)), T ? (S === g && T !== d && S++, d = T) : d && (S === g && S++, d = ""), g = S, _.setZLevel(S);
          });
        }
      }
      wu = function(h, c, v, p, y) {
        n(c), kc(h, c, v, p, y), P(h._chartsViews, function(g) {
          g.__alive = false;
        }), Ba(h, c, v, p, y), P(h._chartsViews, function(g) {
          g.__alive || g.remove(c, v);
        });
      }, kc = function(h, c, v, p, y, g) {
        P(g || h._componentsViews, function(d) {
          var m = d.__model;
          l(m, d), d.render(m, c, v, p), s(m, d), f(m, d);
        });
      }, Ba = function(h, c, v, p, y, g) {
        var d = h._scheduler;
        y = O(y || {}, {
          updatedSeries: c.getSeries()
        }), ge.trigger("series:beforeupdate", c, v, y);
        var m = false;
        c.eachSeries(function(_) {
          var S = h._chartsMap[_.__viewId];
          S.__alive = true;
          var T = S.renderTask;
          d.updatePayload(T, p), l(_, S), g && g.get(_.uid) && T.dirty(), T.perform(d.getPerformArgs(T)) && (m = true), S.group.silent = !!_.get("silent"), o(_, S), cv(_);
        }), d.unfinished = m || d.unfinished, ge.trigger("series:layoutlabels", c, v, y), ge.trigger("series:transition", c, v, y), c.eachSeries(function(_) {
          var S = h._chartsMap[_.__viewId];
          s(_, S), f(_, S);
        }), a(h, c), ge.trigger("series:afterupdate", c, v, y);
      }, Zt = function(h) {
        h[gu] = true, h.getZr().wakeUp();
      }, Fc = function(h) {
        h[gu] && (h.getZr().storage.traverse(function(c) {
          Ri(c) || i(c);
        }), h[gu] = false);
      };
      function i(h) {
        for (var c = [], v = h.currentStates, p = 0; p < v.length; p++) {
          var y = v[p];
          y === "emphasis" || y === "blur" || y === "select" || c.push(y);
        }
        h.selected && h.states.select && c.push("select"), h.hoverState === Xo && h.states.emphasis ? c.push("emphasis") : h.hoverState === qo && h.states.blur && c.push("blur"), h.useStates(c);
      }
      function a(h, c) {
        var v = h._zr, p = v.storage, y = 0;
        p.traverse(function(g) {
          g.isGroup || y++;
        }), y > c.get("hoverLayerThreshold") && !j.node && !j.worker && c.eachSeries(function(g) {
          if (!g.preventUsingHoverLayer) {
            var d = h._chartsMap[g.__viewId];
            d.__alive && d.eachRendered(function(m) {
              m.states.emphasis && (m.states.emphasis.hoverLayer = true);
            });
          }
        });
      }
      function o(h, c) {
        var v = h.get("blendMode") || null;
        c.eachRendered(function(p) {
          p.isGroup || (p.style.blend = v);
        });
      }
      function s(h, c) {
        if (!h.preventAutoZ) {
          var v = h.get("z") || 0, p = h.get("zlevel") || 0;
          c.eachRendered(function(y) {
            return u(y, v, p, -1 / 0), true;
          });
        }
      }
      function u(h, c, v, p) {
        var y = h.getTextContent(), g = h.getTextGuideLine(), d = h.isGroup;
        if (d) for (var m = h.childrenRef(), _ = 0; _ < m.length; _++) p = Math.max(u(m[_], c, v, p), p);
        else h.z = c, h.zlevel = v, p = Math.max(h.z2, p);
        if (y && (y.z = c, y.zlevel = v, isFinite(p) && (y.z2 = p + 2)), g) {
          var S = h.textGuideLineConfig;
          g.z = c, g.zlevel = v, isFinite(p) && (g.z2 = p + (S && S.showAbove ? 1 : -1));
        }
        return p;
      }
      function l(h, c) {
        c.eachRendered(function(v) {
          if (!Ri(v)) {
            var p = v.getTextContent(), y = v.getTextGuideLine();
            v.stateTransition && (v.stateTransition = null), p && p.stateTransition && (p.stateTransition = null), y && y.stateTransition && (y.stateTransition = null), v.hasState() ? (v.prevStates = v.currentStates, v.clearStates()) : v.prevStates && (v.prevStates = null);
          }
        });
      }
      function f(h, c) {
        var v = h.getModel("stateAnimation"), p = h.isAnimationEnabled(), y = v.get("duration"), g = y > 0 ? {
          duration: y,
          delay: v.get("delay"),
          easing: v.get("easing")
        } : null;
        c.eachRendered(function(d) {
          if (d.states && d.states.emphasis) {
            if (Ri(d)) return;
            if (d instanceof et && NS(d), d.__dirty) {
              var m = d.prevStates;
              m && d.useStates(m);
            }
            if (p) {
              d.stateTransition = g;
              var _ = d.getTextContent(), S = d.getTextGuideLine();
              _ && (_.stateTransition = g), S && (S.stateTransition = g);
            }
            d.__dirty && i(d);
          }
        });
      }
      Nc = function(h) {
        return new ((function(c) {
          ft(v, c);
          function v() {
            return c !== null && c.apply(this, arguments) || this;
          }
          return v.prototype.getCoordinateSystems = function() {
            return h._coordSysMgr.getCoordinateSystems();
          }, v.prototype.getComponentByElement = function(p) {
            for (; p; ) {
              var y = p.__ecComponentInfo;
              if (y != null) return h._model.getComponent(y.mainType, y.index);
              p = p.parent;
            }
          }, v.prototype.enterEmphasis = function(p, y) {
            po(p, y), Zt(h);
          }, v.prototype.leaveEmphasis = function(p, y) {
            go(p, y), Zt(h);
          }, v.prototype.enterBlur = function(p) {
            DS(p), Zt(h);
          }, v.prototype.leaveBlur = function(p) {
            Xd(p), Zt(h);
          }, v.prototype.enterSelect = function(p) {
            $d(p), Zt(h);
          }, v.prototype.leaveSelect = function(p) {
            Zd(p), Zt(h);
          }, v.prototype.getModel = function() {
            return h.getModel();
          }, v.prototype.getViewOfComponentModel = function(p) {
            return h.getViewOfComponentModel(p);
          }, v.prototype.getViewOfSeriesModel = function(p) {
            return h.getViewOfSeriesModel(p);
          }, v;
        })(zg))(h);
      }, L0 = function(h) {
        function c(v, p) {
          for (var y = 0; y < v.length; y++) {
            var g = v[y];
            g[yu] = p;
          }
        }
        P(Ni, function(v, p) {
          h._messageCenter.on(p, function(y) {
            if (Eo[h.group] && h[yu] !== Lc) {
              if (y && y.escapeConnect) return;
              var g = h.makeActionFromEvent(y), d = [];
              P(Qr, function(m) {
                m !== h && m.group === h.group && d.push(m);
              }), c(d, Lc), P(d, function(m) {
                m[yu] !== DM && m.dispatchAction(g);
              }), c(d, xM);
            }
          });
        });
      };
    })(), t;
  })($e), If = Po.prototype;
  If.on = x0("on");
  If.off = x0("off");
  If.one = function(e, t, r) {
    var n = this;
    function i() {
      for (var a = [], o = 0; o < arguments.length; o++) a[o] = arguments[o];
      t && t.apply && t.apply(this, a), n.off(e, i);
    }
    this.on.call(this, e, i, r);
  };
  var PM = [
    "click",
    "dblclick",
    "mouseover",
    "mouseout",
    "mousemove",
    "mousedown",
    "mouseup",
    "globalout",
    "contextmenu"
  ];
  var Io = {}, Ni = {}, Ml = [], Cl = [], Ao = [], R0 = {}, Dl = {}, Qr = {}, Eo = {}, IM = +/* @__PURE__ */ new Date() - 0, AM = +/* @__PURE__ */ new Date() - 0, Af = "_echarts_instance_";
  function EM(e, t, r) {
    var n = !(r && r.ssr);
    if (n) {
      var i = Ef(e);
      if (i) return i;
    }
    var a = new Po(e, t, r);
    return a.id = "ec_" + IM++, Qr[a.id] = a, n && Ed(e, Af, a.id), L0(a), ge.trigger("afterinit", a), a;
  }
  function LM(e) {
    if (B(e)) {
      var t = e;
      e = null, P(t, function(r) {
        r.group != null && (e = r.group);
      }), e = e || "g_" + AM++, P(t, function(r) {
        r.group = e;
      });
    }
    return Eo[e] = true, e;
  }
  function O0(e) {
    Eo[e] = false;
  }
  var RM = O0;
  function OM(e) {
    V(e) ? e = Qr[e] : e instanceof Po || (e = Ef(e)), e instanceof Po && !e.isDisposed() && e.dispose();
  }
  function Ef(e) {
    return Qr[m1(e, Af)];
  }
  function kM(e) {
    return Qr[e];
  }
  function Lf(e, t) {
    R0[e] = t;
  }
  function Rf(e) {
    vt(Cl, e) < 0 && Cl.push(e);
  }
  function Of(e, t) {
    kf(Ml, e, t, _M);
  }
  function k0(e) {
    vs("afterinit", e);
  }
  function N0(e) {
    vs("afterupdate", e);
  }
  function vs(e, t) {
    ge.on(e, t);
  }
  on = function(e, t, r) {
    Y(t) && (r = t, t = "");
    var n = G(e) ? e.type : [
      e,
      e = {
        event: t
      }
    ][0];
    e.event = (e.event || n).toLowerCase(), t = e.event, !Ni[t] && ($t(Ec.test(n) && Ec.test(t)), Io[n] || (Io[n] = {
      action: r,
      actionInfo: e
    }), Ni[t] = n);
  };
  function F0(e, t) {
    us.register(e, t);
  }
  function NM(e) {
    var t = us.get(e);
    if (t) return t.getDimensionsInfo ? t.getDimensionsInfo() : t.dimensions.slice();
  }
  function B0(e, t) {
    kf(Ao, e, t, T0, "layout");
  }
  function mr(e, t) {
    kf(Ao, e, t, M0, "visual");
  }
  var Bc = [];
  function kf(e, t, r, n, i) {
    if ((Y(t) || G(t)) && (r = t, t = n), !(vt(Bc, r) >= 0)) {
      Bc.push(r);
      var a = u0.wrapStageHandler(r, i);
      a.__prio = t, a.__raw = r, e.push(a);
    }
  }
  function Nf(e, t) {
    Dl[e] = t;
  }
  function FM(e) {
    Ep({
      createCanvas: e
    });
  }
  function z0(e, t, r) {
    var n = w0("registerMap");
    n && n(e, t, r);
  }
  function BM(e) {
    var t = w0("getMap");
    return t && t(e);
  }
  var V0 = Uw;
  mr(Pf, _T);
  mr(hs, ST);
  mr(hs, bT);
  mr(Pf, OT);
  mr(hs, kT);
  mr(C0, hM);
  Rf(Gg);
  Of(yM, Dw);
  Nf("default", wT);
  on({
    type: jr,
    event: jr,
    update: jr
  }, zt);
  on({
    type: ja,
    event: ja,
    update: ja
  }, zt);
  on({
    type: Ii,
    event: Ii,
    update: Ii
  }, zt);
  on({
    type: Qa,
    event: Qa,
    update: Qa
  }, zt);
  on({
    type: Ai,
    event: Ai,
    update: Ai
  }, zt);
  Lf("light", LT);
  Lf("dark", v0);
  var zM = {};
  function ci(e) {
    return e == null ? 0 : e.length || 1;
  }
  function zc(e) {
    return e;
  }
  let GM;
  VM = (function() {
    function e(t, r, n, i, a, o) {
      this._old = t, this._new = r, this._oldKeyGetter = n || zc, this._newKeyGetter = i || zc, this.context = a, this._diffModeMultiple = o === "multiple";
    }
    return e.prototype.add = function(t) {
      return this._add = t, this;
    }, e.prototype.update = function(t) {
      return this._update = t, this;
    }, e.prototype.updateManyToOne = function(t) {
      return this._updateManyToOne = t, this;
    }, e.prototype.updateOneToMany = function(t) {
      return this._updateOneToMany = t, this;
    }, e.prototype.updateManyToMany = function(t) {
      return this._updateManyToMany = t, this;
    }, e.prototype.remove = function(t) {
      return this._remove = t, this;
    }, e.prototype.execute = function() {
      this[this._diffModeMultiple ? "_executeMultiple" : "_executeOneToOne"]();
    }, e.prototype._executeOneToOne = function() {
      var t = this._old, r = this._new, n = {}, i = new Array(t.length), a = new Array(r.length);
      this._initIndexMap(t, null, i, "_oldKeyGetter"), this._initIndexMap(r, n, a, "_newKeyGetter");
      for (var o = 0; o < t.length; o++) {
        var s = i[o], u = n[s], l = ci(u);
        if (l > 1) {
          var f = u.shift();
          u.length === 1 && (n[s] = u[0]), this._update && this._update(f, o);
        } else l === 1 ? (n[s] = null, this._update && this._update(u, o)) : this._remove && this._remove(o);
      }
      this._performRestAdd(a, n);
    }, e.prototype._executeMultiple = function() {
      var t = this._old, r = this._new, n = {}, i = {}, a = [], o = [];
      this._initIndexMap(t, n, a, "_oldKeyGetter"), this._initIndexMap(r, i, o, "_newKeyGetter");
      for (var s = 0; s < a.length; s++) {
        var u = a[s], l = n[u], f = i[u], h = ci(l), c = ci(f);
        if (h > 1 && c === 1) this._updateManyToOne && this._updateManyToOne(f, l), i[u] = null;
        else if (h === 1 && c > 1) this._updateOneToMany && this._updateOneToMany(f, l), i[u] = null;
        else if (h === 1 && c === 1) this._update && this._update(f, l), i[u] = null;
        else if (h > 1 && c > 1) this._updateManyToMany && this._updateManyToMany(f, l), i[u] = null;
        else if (h > 1) for (var v = 0; v < h; v++) this._remove && this._remove(l[v]);
        else this._remove && this._remove(l);
      }
      this._performRestAdd(o, i);
    }, e.prototype._performRestAdd = function(t, r) {
      for (var n = 0; n < t.length; n++) {
        var i = t[n], a = r[i], o = ci(a);
        if (o > 1) for (var s = 0; s < o; s++) this._add && this._add(a[s]);
        else o === 1 && this._add && this._add(a);
        r[i] = null;
      }
    }, e.prototype._initIndexMap = function(t, r, n, i) {
      for (var a = this._diffModeMultiple, o = 0; o < t.length; o++) {
        var s = "_ec_" + this[i](t[o], o);
        if (a || (n[o] = s), !!r) {
          var u = r[s], l = ci(u);
          l === 0 ? (r[s] = o, a && n.push(s)) : l === 1 ? r[s] = [
            u,
            o
          ] : u.push(o);
        }
      }
    }, e;
  })();
  GM = (function() {
    function e(t, r) {
      this._encode = t, this._schema = r;
    }
    return e.prototype.get = function() {
      return {
        fullDimensions: this._getFullDimensionNames(),
        encode: this._encode
      };
    }, e.prototype._getFullDimensionNames = function() {
      return this._cachedDimNames || (this._cachedDimNames = this._schema ? this._schema.makeOutputDimensionNames() : []), this._cachedDimNames;
    }, e;
  })();
  function HM(e, t) {
    var r = {}, n = r.encode = {}, i = q(), a = [], o = [], s = {};
    P(e.dimensions, function(c) {
      var v = e.getDimensionInfo(c), p = v.coordDim;
      if (p) {
        var y = v.coordDimIndex;
        Tu(n, p)[y] = c, v.isExtraCoord || (i.set(p, 1), WM(v.type) && (a[0] = c), Tu(s, p)[y] = e.getDimensionIndex(v.name)), v.defaultTooltip && o.push(c);
      }
      Og.each(function(g, d) {
        var m = Tu(n, d), _ = v.otherDims[d];
        _ != null && _ !== false && (m[_] = v.name);
      });
    });
    var u = [], l = {};
    i.each(function(c, v) {
      var p = n[v];
      l[v] = p[0], u = u.concat(p);
    }), r.dataDimsOnCoord = u, r.dataDimIndicesOnCoord = F(u, function(c) {
      return e.getDimensionInfo(c).storeDimIndex;
    }), r.encodeFirstDimNotExtra = l;
    var f = n.label;
    f && f.length && (a = f.slice());
    var h = n.tooltip;
    return h && h.length ? o = h.slice() : o.length || (o = a.slice()), n.defaultedLabel = a, n.defaultedTooltip = o, r.userOutput = new GM(s, t), r;
  }
  function Tu(e, t) {
    return e.hasOwnProperty(t) || (e[t] = []), e[t];
  }
  function UM(e) {
    return e === "category" ? "ordinal" : e === "time" ? "time" : "float";
  }
  function WM(e) {
    return !(e === "ordinal" || e === "time");
  }
  var ro = /* @__PURE__ */ (function() {
    function e(t) {
      this.otherDims = {}, t != null && O(this, t);
    }
    return e;
  })(), YM = Pt(), qM = {
    float: "f",
    int: "i",
    ordinal: "o",
    number: "n",
    time: "t"
  }, G0 = (function() {
    function e(t) {
      this.dimensions = t.dimensions, this._dimOmitted = t.dimensionOmitted, this.source = t.source, this._fullDimCount = t.fullDimensionCount, this._updateDimOmitted(t.dimensionOmitted);
    }
    return e.prototype.isDimensionOmitted = function() {
      return this._dimOmitted;
    }, e.prototype._updateDimOmitted = function(t) {
      this._dimOmitted = t, t && (this._dimNameMap || (this._dimNameMap = W0(this.source)));
    }, e.prototype.getSourceDimensionIndex = function(t) {
      return W(this._dimNameMap.get(t), -1);
    }, e.prototype.getSourceDimension = function(t) {
      var r = this.source.dimensionsDefine;
      if (r) return r[t];
    }, e.prototype.makeStoreSchema = function() {
      for (var t = this._fullDimCount, r = Wg(this.source), n = !Y0(t), i = "", a = [], o = 0, s = 0; o < t; o++) {
        var u = void 0, l = void 0, f = void 0, h = this.dimensions[s];
        if (h && h.storeDimIndex === o) u = r ? h.name : null, l = h.type, f = h.ordinalMeta, s++;
        else {
          var c = this.getSourceDimension(o);
          c && (u = r ? c.name : null, l = c.type);
        }
        a.push({
          property: u,
          type: l,
          ordinalMeta: f
        }), r && u != null && (!h || !h.isCalculationCoord) && (i += n ? u.replace(/\`/g, "`1").replace(/\$/g, "`2") : u), i += "$", i += qM[l] || "f", f && (i += f.uid), i += "$";
      }
      var v = this.source, p = [
        v.seriesLayoutBy,
        v.startIndex,
        i
      ].join("$$");
      return {
        dimensions: a,
        hash: p
      };
    }, e.prototype.makeOutputDimensionNames = function() {
      for (var t = [], r = 0, n = 0; r < this._fullDimCount; r++) {
        var i = void 0, a = this.dimensions[n];
        if (a && a.storeDimIndex === r) a.isCalculationCoord || (i = a.name), n++;
        else {
          var o = this.getSourceDimension(r);
          o && (i = o.name);
        }
        t.push(i);
      }
      return t;
    }, e.prototype.appendCalculationDimension = function(t) {
      this.dimensions.push(t), t.isCalculationCoord = true, this._fullDimCount++, this._updateDimOmitted(true);
    }, e;
  })();
  function H0(e) {
    return e instanceof G0;
  }
  function U0(e) {
    for (var t = q(), r = 0; r < (e || []).length; r++) {
      var n = e[r], i = G(n) ? n.name : n;
      i != null && t.get(i) == null && t.set(i, r);
    }
    return t;
  }
  function W0(e) {
    var t = YM(e);
    return t.dimNameMap || (t.dimNameMap = U0(e.dimensionsDefine));
  }
  function Y0(e) {
    return e > 30;
  }
  var pi = G, er = F, XM = typeof Int32Array > "u" ? Array : Int32Array, $M = "e\0\0", Vc = -1, ZM = [
    "hasItemOption",
    "_nameList",
    "_idList",
    "_invertedIndicesMap",
    "_dimSummary",
    "userOutput",
    "_rawData",
    "_dimValueGetter",
    "_nameDimIdx",
    "_idDimIdx",
    "_nameRepeatCount"
  ], KM = [
    "_approximateExtent"
  ], Gc, za, di, gi, Mu, yi, Cu, Ff = (function() {
    function e(t, r) {
      this.type = "list", this._dimOmitted = false, this._nameList = [], this._idList = [], this._visual = {}, this._layout = {}, this._itemVisuals = [], this._itemLayouts = [], this._graphicEls = [], this._approximateExtent = {}, this._calculationInfo = {}, this.hasItemOption = false, this.TRANSFERABLE_METHODS = [
        "cloneShallow",
        "downSample",
        "minmaxDownSample",
        "lttbDownSample",
        "map"
      ], this.CHANGABLE_METHODS = [
        "filterSelf",
        "selectRange"
      ], this.DOWNSAMPLE_METHODS = [
        "downSample",
        "minmaxDownSample",
        "lttbDownSample"
      ];
      var n, i = false;
      H0(t) ? (n = t.dimensions, this._dimOmitted = t.isDimensionOmitted(), this._schema = t) : (i = true, n = t), n = n || [
        "x",
        "y"
      ];
      for (var a = {}, o = [], s = {}, u = false, l = {}, f = 0; f < n.length; f++) {
        var h = n[f], c = V(h) ? new ro({
          name: h
        }) : h instanceof ro ? h : new ro(h), v = c.name;
        c.type = c.type || "float", c.coordDim || (c.coordDim = v, c.coordDimIndex = 0);
        var p = c.otherDims = c.otherDims || {};
        o.push(v), a[v] = c, l[v] != null && (u = true), c.createInvertedIndices && (s[v] = []), p.itemName === 0 && (this._nameDimIdx = f), p.itemId === 0 && (this._idDimIdx = f), i && (c.storeDimIndex = f);
      }
      if (this.dimensions = o, this._dimInfos = a, this._initGetDimensionInfo(u), this.hostModel = r, this._invertedIndicesMap = s, this._dimOmitted) {
        var y = this._dimIdxToName = q();
        P(o, function(g) {
          y.set(a[g].storeDimIndex, g);
        });
      }
    }
    return e.prototype.getDimension = function(t) {
      var r = this._recognizeDimIndex(t);
      if (r == null) return t;
      if (r = t, !this._dimOmitted) return this.dimensions[r];
      var n = this._dimIdxToName.get(r);
      if (n != null) return n;
      var i = this._schema.getSourceDimension(r);
      if (i) return i.name;
    }, e.prototype.getDimensionIndex = function(t) {
      var r = this._recognizeDimIndex(t);
      if (r != null) return r;
      if (t == null) return -1;
      var n = this._getDimInfo(t);
      return n ? n.storeDimIndex : this._dimOmitted ? this._schema.getSourceDimensionIndex(t) : -1;
    }, e.prototype._recognizeDimIndex = function(t) {
      if (lt(t) || t != null && !isNaN(t) && !this._getDimInfo(t) && (!this._dimOmitted || this._schema.getSourceDimensionIndex(t) < 0)) return +t;
    }, e.prototype._getStoreDimIndex = function(t) {
      var r = this.getDimensionIndex(t);
      return r;
    }, e.prototype.getDimensionInfo = function(t) {
      return this._getDimInfo(this.getDimension(t));
    }, e.prototype._initGetDimensionInfo = function(t) {
      var r = this._dimInfos;
      this._getDimInfo = t ? function(n) {
        return r.hasOwnProperty(n) ? r[n] : void 0;
      } : function(n) {
        return r[n];
      };
    }, e.prototype.getDimensionsOnCoord = function() {
      return this._dimSummary.dataDimsOnCoord.slice();
    }, e.prototype.mapDimension = function(t, r) {
      var n = this._dimSummary;
      if (r == null) return n.encodeFirstDimNotExtra[t];
      var i = n.encode[t];
      return i ? i[r] : null;
    }, e.prototype.mapDimensionsAll = function(t) {
      var r = this._dimSummary, n = r.encode[t];
      return (n || []).slice();
    }, e.prototype.getStore = function() {
      return this._store;
    }, e.prototype.initData = function(t, r, n) {
      var i = this, a;
      if (t instanceof yl && (a = t), !a) {
        var o = this.dimensions, s = Tf(t) || Rt(t) ? new Yg(t, o.length) : t;
        a = new yl();
        var u = er(o, function(l) {
          return {
            type: i._dimInfos[l].type,
            property: l
          };
        });
        a.initData(s, u, n);
      }
      this._store = a, this._nameList = (r || []).slice(), this._idList = [], this._nameRepeatCount = {}, this._doInit(0, a.count()), this._dimSummary = HM(this, this._schema), this.userOutput = this._dimSummary.userOutput;
    }, e.prototype.appendData = function(t) {
      var r = this._store.appendData(t);
      this._doInit(r[0], r[1]);
    }, e.prototype.appendValues = function(t, r) {
      var n = this._store.appendValues(t, r && r.length), i = n.start, a = n.end, o = this._shouldMakeIdFromName();
      if (this._updateOrdinalMeta(), r) for (var s = i; s < a; s++) {
        var u = s - i;
        this._nameList[s] = r[u], o && Cu(this, s);
      }
    }, e.prototype._updateOrdinalMeta = function() {
      for (var t = this._store, r = this.dimensions, n = 0; n < r.length; n++) {
        var i = this._dimInfos[r[n]];
        i.ordinalMeta && t.collectOrdinalMeta(i.storeDimIndex, i.ordinalMeta);
      }
    }, e.prototype._shouldMakeIdFromName = function() {
      var t = this._store.getProvider();
      return this._idDimIdx == null && t.getSource().sourceFormat !== cr && !t.fillStorage;
    }, e.prototype._doInit = function(t, r) {
      if (!(t >= r)) {
        var n = this._store, i = n.getProvider();
        this._updateOrdinalMeta();
        var a = this._nameList, o = this._idList, s = i.getSource().sourceFormat, u = s === ue;
        if (u && !i.pure) for (var l = [], f = t; f < r; f++) {
          var h = i.getItem(f, l);
          if (!this.hasItemOption && s1(h) && (this.hasItemOption = true), h) {
            var c = h.name;
            a[f] == null && c != null && (a[f] = me(c, null));
            var v = h.id;
            o[f] == null && v != null && (o[f] = me(v, null));
          }
        }
        if (this._shouldMakeIdFromName()) for (var f = t; f < r; f++) Cu(this, f);
        Gc(this);
      }
    }, e.prototype.getApproximateExtent = function(t) {
      return this._approximateExtent[t] || this._store.getDataExtent(this._getStoreDimIndex(t));
    }, e.prototype.setApproximateExtent = function(t, r) {
      r = this.getDimension(r), this._approximateExtent[r] = t.slice();
    }, e.prototype.getCalculationInfo = function(t) {
      return this._calculationInfo[t];
    }, e.prototype.setCalculationInfo = function(t, r) {
      pi(t) ? O(this._calculationInfo, t) : this._calculationInfo[t] = r;
    }, e.prototype.getName = function(t) {
      var r = this.getRawIndex(t), n = this._nameList[r];
      return n == null && this._nameDimIdx != null && (n = di(this, this._nameDimIdx, r)), n == null && (n = ""), n;
    }, e.prototype._getCategory = function(t, r) {
      var n = this._store.get(t, r), i = this._store.getOrdinalMeta(t);
      return i ? i.categories[n] : n;
    }, e.prototype.getId = function(t) {
      return za(this, this.getRawIndex(t));
    }, e.prototype.count = function() {
      return this._store.count();
    }, e.prototype.get = function(t, r) {
      var n = this._store, i = this._dimInfos[t];
      if (i) return n.get(i.storeDimIndex, r);
    }, e.prototype.getByRawIndex = function(t, r) {
      var n = this._store, i = this._dimInfos[t];
      if (i) return n.getByRawIndex(i.storeDimIndex, r);
    }, e.prototype.getIndices = function() {
      return this._store.getIndices();
    }, e.prototype.getDataExtent = function(t) {
      return this._store.getDataExtent(this._getStoreDimIndex(t));
    }, e.prototype.getSum = function(t) {
      return this._store.getSum(this._getStoreDimIndex(t));
    }, e.prototype.getMedian = function(t) {
      return this._store.getMedian(this._getStoreDimIndex(t));
    }, e.prototype.getValues = function(t, r) {
      var n = this, i = this._store;
      return B(t) ? i.getValues(er(t, function(a) {
        return n._getStoreDimIndex(a);
      }), r) : i.getValues(t);
    }, e.prototype.hasValue = function(t) {
      for (var r = this._dimSummary.dataDimIndicesOnCoord, n = 0, i = r.length; n < i; n++) if (isNaN(this._store.get(r[n], t))) return false;
      return true;
    }, e.prototype.indexOfName = function(t) {
      for (var r = 0, n = this._store.count(); r < n; r++) if (this.getName(r) === t) return r;
      return -1;
    }, e.prototype.getRawIndex = function(t) {
      return this._store.getRawIndex(t);
    }, e.prototype.indexOfRawIndex = function(t) {
      return this._store.indexOfRawIndex(t);
    }, e.prototype.rawIndexOf = function(t, r) {
      var n = t && this._invertedIndicesMap[t], i = n && n[r];
      return i == null || isNaN(i) ? Vc : i;
    }, e.prototype.indicesOfNearest = function(t, r, n) {
      return this._store.indicesOfNearest(this._getStoreDimIndex(t), r, n);
    }, e.prototype.each = function(t, r, n) {
      Y(t) && (n = r, r = t, t = []);
      var i = n || this, a = er(gi(t), this._getStoreDimIndex, this);
      this._store.each(a, i ? ut(r, i) : r);
    }, e.prototype.filterSelf = function(t, r, n) {
      Y(t) && (n = r, r = t, t = []);
      var i = n || this, a = er(gi(t), this._getStoreDimIndex, this);
      return this._store = this._store.filter(a, i ? ut(r, i) : r), this;
    }, e.prototype.selectRange = function(t) {
      var r = this, n = {}, i = K(t);
      return P(i, function(a) {
        var o = r._getStoreDimIndex(a);
        n[o] = t[a];
      }), this._store = this._store.selectRange(n), this;
    }, e.prototype.mapArray = function(t, r, n) {
      Y(t) && (n = r, r = t, t = []), n = n || this;
      var i = [];
      return this.each(t, function() {
        i.push(r && r.apply(this, arguments));
      }, n), i;
    }, e.prototype.map = function(t, r, n, i) {
      var a = n || i || this, o = er(gi(t), this._getStoreDimIndex, this), s = yi(this);
      return s._store = this._store.map(o, a ? ut(r, a) : r), s;
    }, e.prototype.modify = function(t, r, n, i) {
      var a = n || i || this, o = er(gi(t), this._getStoreDimIndex, this);
      this._store.modify(o, a ? ut(r, a) : r);
    }, e.prototype.downSample = function(t, r, n, i) {
      var a = yi(this);
      return a._store = this._store.downSample(this._getStoreDimIndex(t), r, n, i), a;
    }, e.prototype.minmaxDownSample = function(t, r) {
      var n = yi(this);
      return n._store = this._store.minmaxDownSample(this._getStoreDimIndex(t), r), n;
    }, e.prototype.lttbDownSample = function(t, r) {
      var n = yi(this);
      return n._store = this._store.lttbDownSample(this._getStoreDimIndex(t), r), n;
    }, e.prototype.getRawDataItem = function(t) {
      return this._store.getRawDataItem(t);
    }, e.prototype.getItemModel = function(t) {
      var r = this.hostModel, n = this.getRawDataItem(t);
      return new wt(n, r, r && r.ecModel);
    }, e.prototype.diff = function(t) {
      var r = this;
      return new VM(t ? t.getStore().getIndices() : [], this.getStore().getIndices(), function(n) {
        return za(t, n);
      }, function(n) {
        return za(r, n);
      });
    }, e.prototype.getVisual = function(t) {
      var r = this._visual;
      return r && r[t];
    }, e.prototype.setVisual = function(t, r) {
      this._visual = this._visual || {}, pi(t) ? O(this._visual, t) : this._visual[t] = r;
    }, e.prototype.getItemVisual = function(t, r) {
      var n = this._itemVisuals[t], i = n && n[r];
      return i ?? this.getVisual(r);
    }, e.prototype.hasItemVisual = function() {
      return this._itemVisuals.length > 0;
    }, e.prototype.ensureUniqueItemVisual = function(t, r) {
      var n = this._itemVisuals, i = n[t];
      i || (i = n[t] = {});
      var a = i[r];
      return a == null && (a = this.getVisual(r), B(a) ? a = a.slice() : pi(a) && (a = O({}, a)), i[r] = a), a;
    }, e.prototype.setItemVisual = function(t, r, n) {
      var i = this._itemVisuals[t] || {};
      this._itemVisuals[t] = i, pi(r) ? O(i, r) : i[r] = n;
    }, e.prototype.clearAllVisual = function() {
      this._visual = {}, this._itemVisuals = [];
    }, e.prototype.setLayout = function(t, r) {
      pi(t) ? O(this._layout, t) : this._layout[t] = r;
    }, e.prototype.getLayout = function(t) {
      return this._layout[t];
    }, e.prototype.getItemLayout = function(t) {
      return this._itemLayouts[t];
    }, e.prototype.setItemLayout = function(t, r, n) {
      this._itemLayouts[t] = n ? O(this._itemLayouts[t] || {}, r) : r;
    }, e.prototype.clearItemLayouts = function() {
      this._itemLayouts.length = 0;
    }, e.prototype.setItemGraphicEl = function(t, r) {
      var n = this.hostModel && this.hostModel.seriesIndex;
      gS(n, this.dataType, t, r), this._graphicEls[t] = r;
    }, e.prototype.getItemGraphicEl = function(t) {
      return this._graphicEls[t];
    }, e.prototype.eachItemGraphicEl = function(t, r) {
      P(this._graphicEls, function(n, i) {
        n && t && t.call(r, n, i);
      });
    }, e.prototype.cloneShallow = function(t) {
      return t || (t = new e(this._schema ? this._schema : er(this.dimensions, this._getDimInfo, this), this.hostModel)), Mu(t, this), t._store = this._store, t;
    }, e.prototype.wrapMethod = function(t, r) {
      var n = this[t];
      Y(n) && (this.__wrappedMethods = this.__wrappedMethods || [], this.__wrappedMethods.push(t), this[t] = function() {
        var i = n.apply(this, arguments);
        return r.apply(this, [
          i
        ].concat(ko(arguments)));
      });
    }, e.internalField = (function() {
      Gc = function(t) {
        var r = t._invertedIndicesMap;
        P(r, function(n, i) {
          var a = t._dimInfos[i], o = a.ordinalMeta, s = t._store;
          if (o) {
            n = r[i] = new XM(o.categories.length);
            for (var u = 0; u < n.length; u++) n[u] = Vc;
            for (var u = 0; u < s.count(); u++) n[s.get(a.storeDimIndex, u)] = u;
          }
        });
      }, di = function(t, r, n) {
        return me(t._getCategory(r, n), null);
      }, za = function(t, r) {
        var n = t._idList[r];
        return n == null && t._idDimIdx != null && (n = di(t, t._idDimIdx, r)), n == null && (n = $M + r), n;
      }, gi = function(t) {
        return B(t) || (t = t != null ? [
          t
        ] : []), t;
      }, yi = function(t) {
        var r = new e(t._schema ? t._schema : er(t.dimensions, t._getDimInfo, t), t.hostModel);
        return Mu(r, t), r;
      }, Mu = function(t, r) {
        P(ZM.concat(r.__wrappedMethods || []), function(n) {
          r.hasOwnProperty(n) && (t[n] = r[n]);
        }), t.__wrappedMethods = r.__wrappedMethods, P(KM, function(n) {
          t[n] = Z(r[n]);
        }), t._calculationInfo = O({}, r._calculationInfo);
      }, Cu = function(t, r) {
        var n = t._nameList, i = t._idList, a = t._nameDimIdx, o = t._idDimIdx, s = n[r], u = i[r];
        if (s == null && a != null && (n[r] = s = di(t, a, r)), u == null && o != null && (i[r] = u = di(t, o, r)), u == null && s != null) {
          var l = t._nameRepeatCount, f = l[s] = (l[s] || 0) + 1;
          u = s, f > 1 && (u += "__ec__" + f), i[r] = u;
        }
      };
    })(), e;
  })();
  function jM(e, t) {
    return q0(e, t).dimensions;
  }
  function q0(e, t) {
    Tf(e) || (e = Hg(e)), t = t || {};
    var r = t.coordDimensions || [], n = t.dimensionsDefine || e.dimensionsDefine || [], i = q(), a = [], o = JM(e, r, n, t.dimensionsCount), s = t.canOmitUnusedDimensions && Y0(o), u = n === e.dimensionsDefine, l = u ? W0(e) : U0(n), f = t.encodeDefine;
    !f && t.encodeDefaulter && (f = t.encodeDefaulter(e, o));
    for (var h = q(f), c = new jg(o), v = 0; v < c.length; v++) c[v] = -1;
    function p(C) {
      var M = c[C];
      if (M < 0) {
        var x = n[C], I = G(x) ? x : {
          name: x
        }, A = new ro(), E = I.name;
        E != null && l.get(E) != null && (A.name = A.displayName = E), I.type != null && (A.type = I.type), I.displayName != null && (A.displayName = I.displayName);
        var R = a.length;
        return c[C] = R, A.storeDimIndex = C, a.push(A), A;
      }
      return a[M];
    }
    if (!s) for (var v = 0; v < o; v++) p(v);
    h.each(function(C, M) {
      var x = Lt(C).slice();
      if (x.length === 1 && !V(x[0]) && x[0] < 0) {
        h.set(M, false);
        return;
      }
      var I = h.set(M, []);
      P(x, function(A, E) {
        var R = V(A) ? l.get(A) : A;
        R != null && R < o && (I[E] = R, g(p(R), M, E));
      });
    });
    var y = 0;
    P(r, function(C) {
      var M, x, I, A;
      if (V(C)) M = C, A = {};
      else {
        A = C, M = A.name;
        var E = A.ordinalMeta;
        A.ordinalMeta = null, A = O({}, A), A.ordinalMeta = E, x = A.dimsDef, I = A.otherDims, A.name = A.coordDim = A.coordDimIndex = A.dimsDef = A.otherDims = null;
      }
      var R = h.get(M);
      if (R !== false) {
        if (R = Lt(R), !R.length) for (var L = 0; L < (x && x.length || 1); L++) {
          for (; y < o && p(y).coordDim != null; ) y++;
          y < o && R.push(y++);
        }
        P(R, function(z, k) {
          var N = p(z);
          if (u && A.type != null && (N.type = A.type), g(ht(N, A), M, k), N.name == null && x) {
            var U = x[k];
            !G(U) && (U = {
              name: U
            }), N.name = N.displayName = U.name, N.defaultTooltip = U.defaultTooltip;
          }
          I && ht(N.otherDims, I);
        });
      }
    });
    function g(C, M, x) {
      Og.get(M) != null ? C.otherDims[M] = x : (C.coordDim = M, C.coordDimIndex = x, i.set(M, true));
    }
    var d = t.generateCoord, m = t.generateCoordCount, _ = m != null;
    m = d ? m || 1 : 0;
    var S = d || "value";
    function T(C) {
      C.name == null && (C.name = C.coordDim);
    }
    if (s) P(a, function(C) {
      T(C);
    }), a.sort(function(C, M) {
      return C.storeDimIndex - M.storeDimIndex;
    });
    else for (var b = 0; b < o; b++) {
      var w = p(b), D = w.coordDim;
      D == null && (w.coordDim = tC(S, i, _), w.coordDimIndex = 0, (!d || m <= 0) && (w.isExtraCoord = true), m--), T(w), w.type == null && (Bg(e, b) === Ht.Must || w.isExtraCoord && (w.otherDims.itemName != null || w.otherDims.seriesName != null)) && (w.type = "ordinal");
    }
    return QM(a), new G0({
      source: e,
      dimensions: a,
      fullDimensionCount: o,
      dimensionOmitted: s
    });
  }
  function QM(e) {
    for (var t = q(), r = 0; r < e.length; r++) {
      var n = e[r], i = n.name, a = t.get(i) || 0;
      a > 0 && (n.name = i + (a - 1)), a++, t.set(i, a);
    }
  }
  function JM(e, t, r, n) {
    var i = Math.max(e.dimensionsDetectedCount || 1, t.length, r.length, n || 0);
    return P(t, function(a) {
      var o;
      G(a) && (o = a.dimsDef) && (i = Math.max(i, o.length));
    }), i;
  }
  function tC(e, t, r) {
    if (r || t.hasKey(e)) {
      for (var n = 0; t.hasKey(e + n); ) n++;
      e += n;
    }
    return t.set(e, true), e;
  }
  var eC = /* @__PURE__ */ (function() {
    function e(t) {
      this.coordSysDims = [], this.axisMap = q(), this.categoryAxisMap = q(), this.coordSysName = t;
    }
    return e;
  })();
  function rC(e) {
    var t = e.get("coordinateSystem"), r = new eC(t), n = nC[t];
    if (n) return n(e, r, r.axisMap, r.categoryAxisMap), r;
  }
  var nC = {
    cartesian2d: function(e, t, r, n) {
      var i = e.getReferringComponents("xAxis", Yr).models[0], a = e.getReferringComponents("yAxis", Yr).models[0];
      t.coordSysDims = [
        "x",
        "y"
      ], r.set("x", i), r.set("y", a), bn(i) && (n.set("x", i), t.firstCategoryDimIndex = 0), bn(a) && (n.set("y", a), t.firstCategoryDimIndex == null && (t.firstCategoryDimIndex = 1));
    },
    singleAxis: function(e, t, r, n) {
      var i = e.getReferringComponents("singleAxis", Yr).models[0];
      t.coordSysDims = [
        "single"
      ], r.set("single", i), bn(i) && (n.set("single", i), t.firstCategoryDimIndex = 0);
    },
    polar: function(e, t, r, n) {
      var i = e.getReferringComponents("polar", Yr).models[0], a = i.findAxisModel("radiusAxis"), o = i.findAxisModel("angleAxis");
      t.coordSysDims = [
        "radius",
        "angle"
      ], r.set("radius", a), r.set("angle", o), bn(a) && (n.set("radius", a), t.firstCategoryDimIndex = 0), bn(o) && (n.set("angle", o), t.firstCategoryDimIndex == null && (t.firstCategoryDimIndex = 1));
    },
    geo: function(e, t, r, n) {
      t.coordSysDims = [
        "lng",
        "lat"
      ];
    },
    parallel: function(e, t, r, n) {
      var i = e.ecModel, a = i.getComponent("parallel", e.get("parallelIndex")), o = t.coordSysDims = a.dimensions.slice();
      P(a.parallelAxisIndex, function(s, u) {
        var l = i.getComponent("parallelAxis", s), f = o[u];
        r.set(f, l), bn(l) && (n.set(f, l), t.firstCategoryDimIndex == null && (t.firstCategoryDimIndex = u));
      });
    }
  };
  function bn(e) {
    return e.get("type") === "category";
  }
  function X0(e, t, r) {
    r = r || {};
    var n = r.byIndex, i = r.stackedCoordDimension, a, o, s;
    iC(t) ? a = t : (o = t.schema, a = o.dimensions, s = t.store);
    var u = !!(e && e.get("stack")), l, f, h, c;
    if (P(a, function(m, _) {
      V(m) && (a[_] = m = {
        name: m
      }), u && !m.isExtraCoord && (!n && !l && m.ordinalMeta && (l = m), !f && m.type !== "ordinal" && m.type !== "time" && (!i || i === m.coordDim) && (f = m));
    }), f && !n && !l && (n = true), f) {
      h = "__\0ecstackresult_" + e.id, c = "__\0ecstackedover_" + e.id, l && (l.createInvertedIndices = true);
      var v = f.coordDim, p = f.type, y = 0;
      P(a, function(m) {
        m.coordDim === v && y++;
      });
      var g = {
        name: h,
        coordDim: v,
        coordDimIndex: y,
        type: p,
        isExtraCoord: true,
        isCalculationCoord: true,
        storeDimIndex: a.length
      }, d = {
        name: c,
        coordDim: c,
        coordDimIndex: y + 1,
        type: p,
        isExtraCoord: true,
        isCalculationCoord: true,
        storeDimIndex: a.length + 1
      };
      o ? (s && (g.storeDimIndex = s.ensureCalculationDimension(c, p), d.storeDimIndex = s.ensureCalculationDimension(h, p)), o.appendCalculationDimension(g), o.appendCalculationDimension(d)) : (a.push(g), a.push(d));
    }
    return {
      stackedDimension: f && f.name,
      stackedByDimension: l && l.name,
      isStackedByIndex: n,
      stackedOverDimension: c,
      stackResultDimension: h
    };
  }
  function iC(e) {
    return !H0(e.schema);
  }
  function Bn(e, t) {
    return !!t && t === e.getCalculationInfo("stackedDimension");
  }
  function $0(e, t) {
    return Bn(e, t) ? e.getCalculationInfo("stackResultDimension") : t;
  }
  function aC(e, t) {
    var r = e.get("coordinateSystem"), n = us.get(r), i;
    return t && t.coordSysDims && (i = F(t.coordSysDims, function(a) {
      var o = {
        name: a
      }, s = t.axisMap.get(a);
      if (s) {
        var u = s.get("type");
        o.type = UM(u);
      }
      return o;
    })), i || (i = n && (n.getDimensionsInfo ? n.getDimensionsInfo() : n.dimensions.slice()) || [
      "x",
      "y"
    ]), i;
  }
  function oC(e, t, r) {
    var n, i;
    return r && P(e, function(a, o) {
      var s = a.coordDim, u = r.categoryAxisMap.get(s);
      u && (n == null && (n = o), a.ordinalMeta = u.getOrdinalMeta(), t && (a.createInvertedIndices = true)), a.otherDims.itemName != null && (i = true);
    }), !i && n != null && (e[n].otherDims.itemName = 0), n;
  }
  function Z0(e, t, r) {
    r = r || {};
    var n = t.getSourceManager(), i, a = false;
    i = n.getSource(), a = i.sourceFormat === ue;
    var o = rC(t), s = aC(t, o), u = r.useEncodeDefaulter, l = Y(u) ? u : u ? Vn(rw, s, t) : null, f = {
      coordDimensions: s,
      generateCoord: r.generateCoord,
      encodeDefine: t.getEncode(),
      encodeDefaulter: l,
      canOmitUnusedDimensions: !a
    }, h = q0(i, f), c = oC(h.dimensions, r.createInvertedIndices, o), v = a ? null : n.getSharedDataStore(h), p = X0(t, {
      schema: h,
      store: v
    }), y = new Ff(h, t);
    y.setCalculationInfo(p);
    var g = c != null && sC(i) ? function(d, m, _, S) {
      return S === c ? _ : this.defaultDimValueGetter(d, m, _, S);
    } : null;
    return y.hasItemOption = false, y.initData(a ? i : v, null, g), y;
  }
  function sC(e) {
    if (e.sourceFormat === ue) {
      var t = uC(e.data || []);
      return !B(Gn(t));
    }
  }
  function uC(e) {
    for (var t = 0; t < e.length && e[t] == null; ) t++;
    return e[t];
  }
  var Ne = (function() {
    function e(t) {
      this._setting = t || {}, this._extent = [
        1 / 0,
        -1 / 0
      ];
    }
    return e.prototype.getSetting = function(t) {
      return this._setting[t];
    }, e.prototype.unionExtent = function(t) {
      var r = this._extent;
      t[0] < r[0] && (r[0] = t[0]), t[1] > r[1] && (r[1] = t[1]);
    }, e.prototype.unionExtentFromData = function(t, r) {
      this.unionExtent(t.getApproximateExtent(r));
    }, e.prototype.getExtent = function() {
      return this._extent.slice();
    }, e.prototype.setExtent = function(t, r) {
      var n = this._extent;
      isNaN(t) || (n[0] = t), isNaN(r) || (n[1] = r);
    }, e.prototype.isInExtentRange = function(t) {
      return this._extent[0] <= t && this._extent[1] >= t;
    }, e.prototype.isBlank = function() {
      return this._isBlank;
    }, e.prototype.setBlank = function(t) {
      this._isBlank = t;
    }, e;
  })();
  Uo(Ne);
  let lC;
  lC = 0;
  Hc = (function() {
    function e(t) {
      this.categories = t.categories || [], this._needCollect = t.needCollect, this._deduplication = t.deduplication, this.uid = ++lC;
    }
    return e.createByAxisModel = function(t) {
      var r = t.option, n = r.data, i = n && F(n, fC);
      return new e({
        categories: i,
        needCollect: !i,
        deduplication: r.dedplication !== false
      });
    }, e.prototype.getOrdinal = function(t) {
      return this._getOrCreateMap().get(t);
    }, e.prototype.parseAndCollect = function(t) {
      var r, n = this._needCollect;
      if (!V(t) && !n) return t;
      if (n && !this._deduplication) return r = this.categories.length, this.categories[r] = t, r;
      var i = this._getOrCreateMap();
      return r = i.get(t), r == null && (n ? (r = this.categories.length, this.categories[r] = t, i.set(t, r)) : r = NaN), r;
    }, e.prototype._getOrCreateMap = function() {
      return this._map || (this._map = q(this.categories));
    }, e;
  })();
  function fC(e) {
    return G(e) && e.value != null ? e.value : e + "";
  }
  rx = function(e) {
    return e.type === "interval" || e.type === "log";
  };
  function hC(e, t, r, n) {
    var i = {}, a = e[1] - e[0], o = i.interval = Zl(a / t, true);
    r != null && o < r && (o = i.interval = r), n != null && o > n && (o = i.interval = n);
    var s = i.intervalPrecision = K0(o), u = i.niceTickExtent = [
      bt(Math.ceil(e[0] / o) * o, s),
      bt(Math.floor(e[1] / o) * o, s)
    ];
    return vC(u, e), i;
  }
  nx = function(e) {
    var t = Math.pow(10, Go(e)), r = e / t;
    return r ? r === 2 ? r = 3 : r === 3 ? r = 5 : r *= 2 : r = 1, bt(r * t);
  };
  function K0(e) {
    return Ae(e) + 2;
  }
  function Uc(e, t, r) {
    e[t] = Math.max(Math.min(e[t], r[1]), r[0]);
  }
  function vC(e, t) {
    !isFinite(e[0]) && (e[0] = t[0]), !isFinite(e[1]) && (e[1] = t[1]), Uc(e, 0, t), Uc(e, 1, t), e[0] > e[1] && (e[0] = e[1]);
  }
  function cs(e, t) {
    return e >= t[0] && e <= t[1];
  }
  function ps(e, t) {
    return t[1] === t[0] ? 0.5 : (e - t[0]) / (t[1] - t[0]);
  }
  function ds(e, t) {
    return e * (t[1] - t[0]) + t[0];
  }
  var gs = (function(e) {
    ft(t, e);
    function t(r) {
      var n = e.call(this, r) || this;
      n.type = "ordinal";
      var i = n.getSetting("ordinalMeta");
      return i || (i = new Hc({})), B(i) && (i = new Hc({
        categories: F(i, function(a) {
          return G(a) ? a.value : a;
        })
      })), n._ordinalMeta = i, n._extent = n.getSetting("extent") || [
        0,
        i.categories.length - 1
      ], n;
    }
    return t.prototype.parse = function(r) {
      return r == null ? NaN : V(r) ? this._ordinalMeta.getOrdinal(r) : Math.round(r);
    }, t.prototype.contain = function(r) {
      return r = this.parse(r), cs(r, this._extent) && this._ordinalMeta.categories[r] != null;
    }, t.prototype.normalize = function(r) {
      return r = this._getTickNumber(this.parse(r)), ps(r, this._extent);
    }, t.prototype.scale = function(r) {
      return r = Math.round(ds(r, this._extent)), this.getRawOrdinalNumber(r);
    }, t.prototype.getTicks = function() {
      for (var r = [], n = this._extent, i = n[0]; i <= n[1]; ) r.push({
        value: i
      }), i++;
      return r;
    }, t.prototype.getMinorTicks = function(r) {
    }, t.prototype.setSortInfo = function(r) {
      if (r == null) {
        this._ordinalNumbersByTick = this._ticksByOrdinalNumber = null;
        return;
      }
      for (var n = r.ordinalNumbers, i = this._ordinalNumbersByTick = [], a = this._ticksByOrdinalNumber = [], o = 0, s = this._ordinalMeta.categories.length, u = Math.min(s, n.length); o < u; ++o) {
        var l = n[o];
        i[o] = l, a[l] = o;
      }
      for (var f = 0; o < s; ++o) {
        for (; a[f] != null; ) f++;
        i.push(f), a[f] = o;
      }
    }, t.prototype._getTickNumber = function(r) {
      var n = this._ticksByOrdinalNumber;
      return n && r >= 0 && r < n.length ? n[r] : r;
    }, t.prototype.getRawOrdinalNumber = function(r) {
      var n = this._ordinalNumbersByTick;
      return n && r >= 0 && r < n.length ? n[r] : r;
    }, t.prototype.getLabel = function(r) {
      if (!this.isBlank()) {
        var n = this.getRawOrdinalNumber(r.value), i = this._ordinalMeta.categories[n];
        return i == null ? "" : i + "";
      }
    }, t.prototype.count = function() {
      return this._extent[1] - this._extent[0] + 1;
    }, t.prototype.unionExtentFromData = function(r, n) {
      this.unionExtent(r.getApproximateExtent(n));
    }, t.prototype.isInExtentRange = function(r) {
      return r = this._getTickNumber(r), this._extent[0] <= r && this._extent[1] >= r;
    }, t.prototype.getOrdinalMeta = function() {
      return this._ordinalMeta;
    }, t.prototype.calcNiceTicks = function() {
    }, t.prototype.calcNiceExtent = function() {
    }, t.type = "ordinal", t;
  })(Ne);
  Ne.registerClass(gs);
  let zr;
  zr = bt;
  Wn = (function(e) {
    ft(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.type = "interval", r._interval = 0, r._intervalPrecision = 2, r;
    }
    return t.prototype.parse = function(r) {
      return r;
    }, t.prototype.contain = function(r) {
      return cs(r, this._extent);
    }, t.prototype.normalize = function(r) {
      return ps(r, this._extent);
    }, t.prototype.scale = function(r) {
      return ds(r, this._extent);
    }, t.prototype.setExtent = function(r, n) {
      var i = this._extent;
      isNaN(r) || (i[0] = parseFloat(r)), isNaN(n) || (i[1] = parseFloat(n));
    }, t.prototype.unionExtent = function(r) {
      var n = this._extent;
      r[0] < n[0] && (n[0] = r[0]), r[1] > n[1] && (n[1] = r[1]), this.setExtent(n[0], n[1]);
    }, t.prototype.getInterval = function() {
      return this._interval;
    }, t.prototype.setInterval = function(r) {
      this._interval = r, this._niceExtent = this._extent.slice(), this._intervalPrecision = K0(r);
    }, t.prototype.getTicks = function(r) {
      var n = this._interval, i = this._extent, a = this._niceExtent, o = this._intervalPrecision, s = [];
      if (!n) return s;
      var u = 1e4;
      i[0] < a[0] && (r ? s.push({
        value: zr(a[0] - n, o)
      }) : s.push({
        value: i[0]
      }));
      for (var l = a[0]; l <= a[1] && (s.push({
        value: l
      }), l = zr(l + n, o), l !== s[s.length - 1].value); ) if (s.length > u) return [];
      var f = s.length ? s[s.length - 1].value : a[1];
      return i[1] > f && (r ? s.push({
        value: zr(f + n, o)
      }) : s.push({
        value: i[1]
      })), s;
    }, t.prototype.getMinorTicks = function(r) {
      for (var n = this.getTicks(true), i = [], a = this.getExtent(), o = 1; o < n.length; o++) {
        for (var s = n[o], u = n[o - 1], l = 0, f = [], h = s.value - u.value, c = h / r; l < r - 1; ) {
          var v = zr(u.value + (l + 1) * c);
          v > a[0] && v < a[1] && f.push(v), l++;
        }
        i.push(f);
      }
      return i;
    }, t.prototype.getLabel = function(r, n) {
      if (r == null) return "";
      var i = n && n.precision;
      i == null ? i = Ae(r.value) || 0 : i === "auto" && (i = this._intervalPrecision);
      var a = zr(r.value, i, true);
      return mf(a);
    }, t.prototype.calcNiceTicks = function(r, n, i) {
      r = r || 5;
      var a = this._extent, o = a[1] - a[0];
      if (isFinite(o)) {
        o < 0 && (o = -o, a.reverse());
        var s = hC(a, r, n, i);
        this._intervalPrecision = s.intervalPrecision, this._interval = s.interval, this._niceExtent = s.niceTickExtent;
      }
    }, t.prototype.calcNiceExtent = function(r) {
      var n = this._extent;
      if (n[0] === n[1]) if (n[0] !== 0) {
        var i = Math.abs(n[0]);
        r.fixMax || (n[1] += i / 2), n[0] -= i / 2;
      } else n[1] = 1;
      var a = n[1] - n[0];
      isFinite(a) || (n[0] = 0, n[1] = 1), this.calcNiceTicks(r.splitNumber, r.minInterval, r.maxInterval);
      var o = this._interval;
      r.fixMin || (n[0] = zr(Math.floor(n[0] / o) * o)), r.fixMax || (n[1] = zr(Math.ceil(n[1] / o) * o));
    }, t.prototype.setNiceExtent = function(r, n) {
      this._niceExtent = [
        r,
        n
      ];
    }, t.type = "interval", t;
  })(Ne);
  Ne.registerClass(Wn);
  var j0 = typeof Float32Array < "u", cC = j0 ? Float32Array : Array;
  function xn(e) {
    return B(e) ? j0 ? new Float32Array(e) : e : new cC(e);
  }
  var pC = "__ec_stack_";
  function dC(e) {
    return e.get("stack") || pC + e.seriesIndex;
  }
  function Q0(e) {
    return e.dim + e.index;
  }
  function gC(e, t) {
    var r = [];
    return t.eachSeriesByType(e, function(n) {
      bC(n) && r.push(n);
    }), r;
  }
  function yC(e) {
    var t = {};
    P(e, function(u) {
      var l = u.coordinateSystem, f = l.getBaseAxis();
      if (!(f.type !== "time" && f.type !== "value")) for (var h = u.getData(), c = f.dim + "_" + f.index, v = h.getDimensionIndex(h.mapDimension(f.dim)), p = h.getStore(), y = 0, g = p.count(); y < g; ++y) {
        var d = p.get(v, y);
        t[c] ? t[c].push(d) : t[c] = [
          d
        ];
      }
    });
    var r = {};
    for (var n in t) if (t.hasOwnProperty(n)) {
      var i = t[n];
      if (i) {
        i.sort(function(u, l) {
          return u - l;
        });
        for (var a = null, o = 1; o < i.length; ++o) {
          var s = i[o] - i[o - 1];
          s > 0 && (a = a === null ? s : Math.min(a, s));
        }
        r[n] = a;
      }
    }
    return r;
  }
  function mC(e) {
    var t = yC(e), r = [];
    return P(e, function(n) {
      var i = n.coordinateSystem, a = i.getBaseAxis(), o = a.getExtent(), s;
      if (a.type === "category") s = a.getBandWidth();
      else if (a.type === "value" || a.type === "time") {
        var u = a.dim + "_" + a.index, l = t[u], f = Math.abs(o[1] - o[0]), h = a.scale.getExtent(), c = Math.abs(h[1] - h[0]);
        s = l ? f / c * l : f;
      } else {
        var v = n.getData();
        s = Math.abs(o[1] - o[0]) / v.count();
      }
      var p = Ut(n.get("barWidth"), s), y = Ut(n.get("barMaxWidth"), s), g = Ut(n.get("barMinWidth") || (wC(n) ? 0.5 : 1), s), d = n.get("barGap"), m = n.get("barCategoryGap");
      r.push({
        bandWidth: s,
        barWidth: p,
        barMaxWidth: y,
        barMinWidth: g,
        barGap: d,
        barCategoryGap: m,
        axisKey: Q0(a),
        stackId: dC(n)
      });
    }), _C(r);
  }
  function _C(e) {
    var t = {};
    P(e, function(n, i) {
      var a = n.axisKey, o = n.bandWidth, s = t[a] || {
        bandWidth: o,
        remainedWidth: o,
        autoWidthCount: 0,
        categoryGap: null,
        gap: "20%",
        stacks: {}
      }, u = s.stacks;
      t[a] = s;
      var l = n.stackId;
      u[l] || s.autoWidthCount++, u[l] = u[l] || {
        width: 0,
        maxWidth: 0
      };
      var f = n.barWidth;
      f && !u[l].width && (u[l].width = f, f = Math.min(s.remainedWidth, f), s.remainedWidth -= f);
      var h = n.barMaxWidth;
      h && (u[l].maxWidth = h);
      var c = n.barMinWidth;
      c && (u[l].minWidth = c);
      var v = n.barGap;
      v != null && (s.gap = v);
      var p = n.barCategoryGap;
      p != null && (s.categoryGap = p);
    });
    var r = {};
    return P(t, function(n, i) {
      r[i] = {};
      var a = n.stacks, o = n.bandWidth, s = n.categoryGap;
      if (s == null) {
        var u = K(a).length;
        s = Math.max(35 - u * 4, 15) + "%";
      }
      var l = Ut(s, o), f = Ut(n.gap, 1), h = n.remainedWidth, c = n.autoWidthCount, v = (h - l) / (c + (c - 1) * f);
      v = Math.max(v, 0), P(a, function(d) {
        var m = d.maxWidth, _ = d.minWidth;
        if (d.width) {
          var S = d.width;
          m && (S = Math.min(S, m)), _ && (S = Math.max(S, _)), d.width = S, h -= S + f * S, c--;
        } else {
          var S = v;
          m && m < S && (S = Math.min(m, h)), _ && _ > S && (S = _), S !== v && (d.width = S, h -= S + f * S, c--);
        }
      }), v = (h - l) / (c + (c - 1) * f), v = Math.max(v, 0);
      var p = 0, y;
      P(a, function(d, m) {
        d.width || (d.width = v), y = d, p += d.width * (1 + f);
      }), y && (p -= y.width * f);
      var g = -p / 2;
      P(a, function(d, m) {
        r[i][m] = r[i][m] || {
          bandWidth: o,
          offset: g,
          width: d.width
        }, g += d.width * (1 + f);
      });
    }), r;
  }
  function SC(e, t, r) {
    if (e && t) {
      var n = e[Q0(t)];
      return n;
    }
  }
  function bC(e) {
    return e.coordinateSystem && e.coordinateSystem.type === "cartesian2d";
  }
  function wC(e) {
    return e.pipelineContext && e.pipelineContext.large;
  }
  var TC = function(e, t, r, n) {
    for (; r < n; ) {
      var i = r + n >>> 1;
      e[i][1] < t ? r = i + 1 : n = i;
    }
    return r;
  }, Bf = (function(e) {
    ft(t, e);
    function t(r) {
      var n = e.call(this, r) || this;
      return n.type = "time", n;
    }
    return t.prototype.getLabel = function(r) {
      var n = this.getSetting("useUTC");
      return ns(r.value, Rv[Ub(Rn(this._minLevelUnit))] || Rv.second, n, this.getSetting("locale"));
    }, t.prototype.getFormattedLabel = function(r, n, i) {
      var a = this.getSetting("useUTC"), o = this.getSetting("locale");
      return Wb(r, n, i, o, a);
    }, t.prototype.getTicks = function() {
      var r = this._interval, n = this._extent, i = [];
      if (!r) return i;
      i.push({
        value: n[0],
        level: 0
      });
      var a = this.getSetting("useUTC"), o = AC(this._minLevelUnit, this._approxInterval, a, n);
      return i = i.concat(o), i.push({
        value: n[1],
        level: 0
      }), i;
    }, t.prototype.calcNiceExtent = function(r) {
      var n = this._extent;
      if (n[0] === n[1] && (n[0] -= re, n[1] += re), n[1] === -1 / 0 && n[0] === 1 / 0) {
        var i = /* @__PURE__ */ new Date();
        n[1] = +new Date(i.getFullYear(), i.getMonth(), i.getDate()), n[0] = n[1] - re;
      }
      this.calcNiceTicks(r.splitNumber, r.minInterval, r.maxInterval);
    }, t.prototype.calcNiceTicks = function(r, n, i) {
      r = r || 10;
      var a = this._extent, o = a[1] - a[0];
      this._approxInterval = o / r, n != null && this._approxInterval < n && (this._approxInterval = n), i != null && this._approxInterval > i && (this._approxInterval = i);
      var s = Va.length, u = Math.min(TC(Va, this._approxInterval, 0, s), s - 1);
      this._interval = Va[u][1], this._minLevelUnit = Va[Math.max(u - 1, 0)][0];
    }, t.prototype.parse = function(r) {
      return lt(r) ? r : +ie(r);
    }, t.prototype.contain = function(r) {
      return cs(this.parse(r), this._extent);
    }, t.prototype.normalize = function(r) {
      return ps(this.parse(r), this._extent);
    }, t.prototype.scale = function(r) {
      return ds(r, this._extent);
    }, t.type = "time", t;
  })(Wn), Va = [
    [
      "second",
      df
    ],
    [
      "minute",
      gf
    ],
    [
      "hour",
      Oi
    ],
    [
      "quarter-day",
      Oi * 6
    ],
    [
      "half-day",
      Oi * 12
    ],
    [
      "day",
      re * 1.2
    ],
    [
      "half-week",
      re * 3.5
    ],
    [
      "week",
      re * 7
    ],
    [
      "month",
      re * 31
    ],
    [
      "quarter",
      re * 95
    ],
    [
      "half-year",
      Lv / 2
    ],
    [
      "year",
      Lv
    ]
  ];
  function MC(e, t, r, n) {
    var i = ie(t), a = ie(r), o = function(p) {
      return Ov(i, p, n) === Ov(a, p, n);
    }, s = function() {
      return o("year");
    }, u = function() {
      return s() && o("month");
    }, l = function() {
      return u() && o("day");
    }, f = function() {
      return l() && o("hour");
    }, h = function() {
      return f() && o("minute");
    }, c = function() {
      return h() && o("second");
    }, v = function() {
      return c() && o("millisecond");
    };
    switch (e) {
      case "year":
        return s();
      case "month":
        return u();
      case "day":
        return l();
      case "hour":
        return f();
      case "minute":
        return h();
      case "second":
        return c();
      case "millisecond":
        return v();
    }
  }
  function CC(e, t) {
    return e /= re, e > 16 ? 16 : e > 7.5 ? 7 : e > 3.5 ? 4 : e > 1.5 ? 2 : 1;
  }
  function DC(e) {
    var t = 30 * re;
    return e /= t, e > 6 ? 6 : e > 3 ? 3 : e > 2 ? 2 : 1;
  }
  function xC(e) {
    return e /= Oi, e > 12 ? 12 : e > 6 ? 6 : e > 3.5 ? 4 : e > 2 ? 2 : 1;
  }
  function Wc(e, t) {
    return e /= t ? gf : df, e > 30 ? 30 : e > 20 ? 20 : e > 15 ? 15 : e > 10 ? 10 : e > 5 ? 5 : e > 2 ? 2 : 1;
  }
  function PC(e) {
    return Zl(e, true);
  }
  function IC(e, t, r) {
    var n = new Date(e);
    switch (Rn(t)) {
      case "year":
      case "month":
        n[Tg(r)](0);
      case "day":
        n[Mg(r)](1);
      case "hour":
        n[Cg(r)](0);
      case "minute":
        n[Dg(r)](0);
      case "second":
        n[xg(r)](0), n[Pg(r)](0);
    }
    return n.getTime();
  }
  function AC(e, t, r, n) {
    var i = 1e4, a = bg, o = 0;
    function s(M, x, I, A, E, R, L) {
      for (var z = new Date(x), k = x, N = z[A](); k < I && k <= n[1]; ) L.push({
        value: k
      }), N += M, z[E](N), k = z.getTime();
      L.push({
        value: k,
        notAdd: true
      });
    }
    function u(M, x, I) {
      var A = [], E = !x.length;
      if (!MC(Rn(M), n[0], n[1], r)) {
        E && (x = [
          {
            value: IC(new Date(n[0]), M, r)
          },
          {
            value: n[1]
          }
        ]);
        for (var R = 0; R < x.length - 1; R++) {
          var L = x[R].value, z = x[R + 1].value;
          if (L !== z) {
            var k = void 0, N = void 0, U = void 0, J = false;
            switch (M) {
              case "year":
                k = Math.max(1, Math.round(t / re / 365)), N = yf(r), U = Yb(r);
                break;
              case "half-year":
              case "quarter":
              case "month":
                k = DC(t), N = On(r), U = Tg(r);
                break;
              case "week":
              case "half-week":
              case "day":
                k = CC(t), N = is(r), U = Mg(r), J = true;
                break;
              case "half-day":
              case "quarter-day":
              case "hour":
                k = xC(t), N = $i(r), U = Cg(r);
                break;
              case "minute":
                k = Wc(t, true), N = as(r), U = Dg(r);
                break;
              case "second":
                k = Wc(t, false), N = os(r), U = xg(r);
                break;
              case "millisecond":
                k = PC(t), N = ss(r), U = Pg(r);
                break;
            }
            s(k, L, z, N, U, J, A), M === "year" && I.length > 1 && R === 0 && I.unshift({
              value: I[0].value - k
            });
          }
        }
        for (var R = 0; R < A.length; R++) I.push(A[R]);
        return A;
      }
    }
    for (var l = [], f = [], h = 0, c = 0, v = 0; v < a.length && o++ < i; ++v) {
      var p = Rn(a[v]);
      if (Hb(a[v])) {
        u(a[v], l[l.length - 1] || [], f);
        var y = a[v + 1] ? Rn(a[v + 1]) : null;
        if (p !== y) {
          if (f.length) {
            c = h, f.sort(function(M, x) {
              return M.value - x.value;
            });
            for (var g = [], d = 0; d < f.length; ++d) {
              var m = f[d].value;
              (d === 0 || f[d - 1].value !== m) && (g.push(f[d]), m >= n[0] && m <= n[1] && h++);
            }
            var _ = (n[1] - n[0]) / t;
            if (h > _ * 1.5 && c > _ / 1.5 || (l.push(g), h > _ || e === a[v])) break;
          }
          f = [];
        }
      }
    }
    for (var S = yt(F(l, function(M) {
      return yt(M, function(x) {
        return x.value >= n[0] && x.value <= n[1] && !x.notAdd;
      });
    }), function(M) {
      return M.length > 0;
    }), T = [], b = S.length - 1, v = 0; v < S.length; ++v) for (var w = S[v], D = 0; D < w.length; ++D) T.push({
      value: w[D].value,
      level: b - v
    });
    T.sort(function(M, x) {
      return M.value - x.value;
    });
    for (var C = [], v = 0; v < T.length; ++v) (v === 0 || T[v].value !== T[v - 1].value) && C.push(T[v]);
    return C;
  }
  Ne.registerClass(Bf);
  var Yc = Ne.prototype, Fi = Wn.prototype, EC = bt, LC = Math.floor, RC = Math.ceil, Ga = Math.pow, ve = Math.log, zf = (function(e) {
    ft(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.type = "log", r.base = 10, r._originalScale = new Wn(), r._interval = 0, r;
    }
    return t.prototype.getTicks = function(r) {
      var n = this._originalScale, i = this._extent, a = n.getExtent(), o = Fi.getTicks.call(this, r);
      return F(o, function(s) {
        var u = s.value, l = bt(Ga(this.base, u));
        return l = u === i[0] && this._fixMin ? Ha(l, a[0]) : l, l = u === i[1] && this._fixMax ? Ha(l, a[1]) : l, {
          value: l
        };
      }, this);
    }, t.prototype.setExtent = function(r, n) {
      var i = ve(this.base);
      r = ve(Math.max(0, r)) / i, n = ve(Math.max(0, n)) / i, Fi.setExtent.call(this, r, n);
    }, t.prototype.getExtent = function() {
      var r = this.base, n = Yc.getExtent.call(this);
      n[0] = Ga(r, n[0]), n[1] = Ga(r, n[1]);
      var i = this._originalScale, a = i.getExtent();
      return this._fixMin && (n[0] = Ha(n[0], a[0])), this._fixMax && (n[1] = Ha(n[1], a[1])), n;
    }, t.prototype.unionExtent = function(r) {
      this._originalScale.unionExtent(r);
      var n = this.base;
      r[0] = ve(r[0]) / ve(n), r[1] = ve(r[1]) / ve(n), Yc.unionExtent.call(this, r);
    }, t.prototype.unionExtentFromData = function(r, n) {
      this.unionExtent(r.getApproximateExtent(n));
    }, t.prototype.calcNiceTicks = function(r) {
      r = r || 10;
      var n = this._extent, i = n[1] - n[0];
      if (!(i === 1 / 0 || i <= 0)) {
        var a = wd(i), o = r / i * a;
        for (o <= 0.5 && (a *= 10); !isNaN(a) && Math.abs(a) < 1 && Math.abs(a) > 0; ) a *= 10;
        var s = [
          bt(RC(n[0] / a) * a),
          bt(LC(n[1] / a) * a)
        ];
        this._interval = a, this._niceExtent = s;
      }
    }, t.prototype.calcNiceExtent = function(r) {
      Fi.calcNiceExtent.call(this, r), this._fixMin = r.fixMin, this._fixMax = r.fixMax;
    }, t.prototype.parse = function(r) {
      return r;
    }, t.prototype.contain = function(r) {
      return r = ve(r) / ve(this.base), cs(r, this._extent);
    }, t.prototype.normalize = function(r) {
      return r = ve(r) / ve(this.base), ps(r, this._extent);
    }, t.prototype.scale = function(r) {
      return r = ds(r, this._extent), Ga(this.base, r);
    }, t.type = "log", t;
  })(Ne), J0 = zf.prototype;
  J0.getMinorTicks = Fi.getMinorTicks;
  J0.getLabel = Fi.getLabel;
  function Ha(e, t) {
    return EC(e, Ae(t));
  }
  Ne.registerClass(zf);
  var OC = (function() {
    function e(t, r, n) {
      this._prepareParams(t, r, n);
    }
    return e.prototype._prepareParams = function(t, r, n) {
      n[1] < n[0] && (n = [
        NaN,
        NaN
      ]), this._dataMin = n[0], this._dataMax = n[1];
      var i = this._isOrdinal = t.type === "ordinal";
      this._needCrossZero = t.type === "interval" && r.getNeedCrossZero && r.getNeedCrossZero();
      var a = r.get("min", true);
      a == null && (a = r.get("startValue", true));
      var o = this._modelMinRaw = a;
      Y(o) ? this._modelMinNum = Ua(t, o({
        min: n[0],
        max: n[1]
      })) : o !== "dataMin" && (this._modelMinNum = Ua(t, o));
      var s = this._modelMaxRaw = r.get("max", true);
      if (Y(s) ? this._modelMaxNum = Ua(t, s({
        min: n[0],
        max: n[1]
      })) : s !== "dataMax" && (this._modelMaxNum = Ua(t, s)), i) this._axisDataLen = r.getCategories().length;
      else {
        var u = r.get("boundaryGap"), l = B(u) ? u : [
          u || 0,
          u || 0
        ];
        typeof l[0] == "boolean" || typeof l[1] == "boolean" ? this._boundaryGapInner = [
          0,
          0
        ] : this._boundaryGapInner = [
          gr(l[0], 1),
          gr(l[1], 1)
        ];
      }
    }, e.prototype.calculate = function() {
      var t = this._isOrdinal, r = this._dataMin, n = this._dataMax, i = this._axisDataLen, a = this._boundaryGapInner, o = t ? null : n - r || Math.abs(r), s = this._modelMinRaw === "dataMin" ? r : this._modelMinNum, u = this._modelMaxRaw === "dataMax" ? n : this._modelMaxNum, l = s != null, f = u != null;
      s == null && (s = t ? i ? 0 : NaN : r - a[0] * o), u == null && (u = t ? i ? i - 1 : NaN : n + a[1] * o), (s == null || !isFinite(s)) && (s = NaN), (u == null || !isFinite(u)) && (u = NaN);
      var h = Bi(s) || Bi(u) || t && !i;
      this._needCrossZero && (s > 0 && u > 0 && !l && (s = 0), s < 0 && u < 0 && !f && (u = 0));
      var c = this._determinedMin, v = this._determinedMax;
      return c != null && (s = c, l = true), v != null && (u = v, f = true), {
        min: s,
        max: u,
        minFixed: l,
        maxFixed: f,
        isBlank: h
      };
    }, e.prototype.modifyDataMinMax = function(t, r) {
      this[NC[t]] = r;
    }, e.prototype.setDeterminedMinMax = function(t, r) {
      var n = kC[t];
      this[n] = r;
    }, e.prototype.freeze = function() {
      this.frozen = true;
    }, e;
  })(), kC = {
    min: "_determinedMin",
    max: "_determinedMax"
  }, NC = {
    min: "_dataMin",
    max: "_dataMax"
  };
  FC = function(e, t, r) {
    var n = e.rawExtentInfo;
    return n || (n = new OC(e, t, r), e.rawExtentInfo = n, n);
  };
  function Ua(e, t) {
    return t == null ? null : Bi(t) ? NaN : e.parse(t);
  }
  BC = function(e, t) {
    var r = e.type, n = FC(e, t, e.getExtent()).calculate();
    e.setBlank(n.isBlank);
    var i = n.min, a = n.max, o = t.ecModel;
    if (o && r === "time") {
      var s = gC("bar", o), u = false;
      if (P(s, function(h) {
        u = u || h.getBaseAxis() === t.axis;
      }), u) {
        var l = mC(s), f = zC(i, a, t, l);
        i = f.min, a = f.max;
      }
    }
    return {
      extent: [
        i,
        a
      ],
      fixMin: n.minFixed,
      fixMax: n.maxFixed
    };
  };
  function zC(e, t, r, n) {
    var i = r.axis.getExtent(), a = Math.abs(i[1] - i[0]), o = SC(n, r.axis);
    if (o === void 0) return {
      min: e,
      max: t
    };
    var s = 1 / 0;
    P(o, function(v) {
      s = Math.min(v.offset, s);
    });
    var u = -1 / 0;
    P(o, function(v) {
      u = Math.max(v.offset + v.width, u);
    }), s = Math.abs(s), u = Math.abs(u);
    var l = s + u, f = t - e, h = 1 - (s + u) / a, c = f / h - f;
    return t += c * (u / l), e -= c * (s / l), {
      min: e,
      max: t
    };
  }
  VC = function(e, t) {
    var r = t, n = BC(e, r), i = n.extent, a = r.get("splitNumber");
    e instanceof zf && (e.base = r.get("logBase"));
    var o = e.type, s = r.get("interval"), u = o === "interval" || o === "time";
    e.setExtent(i[0], i[1]), e.calcNiceExtent({
      splitNumber: a,
      fixMin: n.fixMin,
      fixMax: n.fixMax,
      minInterval: u ? r.get("minInterval") : null,
      maxInterval: u ? r.get("maxInterval") : null
    }), s != null && e.setInterval && e.setInterval(s);
  };
  GC = function(e, t) {
    if (t = t || e.get("type"), t) switch (t) {
      case "category":
        return new gs({
          ordinalMeta: e.getOrdinalMeta ? e.getOrdinalMeta() : e.getCategories(),
          extent: [
            1 / 0,
            -1 / 0
          ]
        });
      case "time":
        return new Bf({
          locale: e.ecModel.getLocaleModel(),
          useUTC: e.ecModel.get("useUTC")
        });
      default:
        return new (Ne.getClass(t) || Wn)();
    }
  };
  ix = function(e) {
    var t = e.scale.getExtent(), r = t[0], n = t[1];
    return !(r > 0 && n > 0 || r < 0 && n < 0);
  };
  function Yn(e) {
    var t = e.getLabelModel().get("formatter"), r = e.type === "category" ? e.scale.getExtent()[0] : null;
    return e.scale.type === "time" ? /* @__PURE__ */ (function(n) {
      return function(i, a) {
        return e.scale.getFormattedLabel(i, a, n);
      };
    })(t) : V(t) ? /* @__PURE__ */ (function(n) {
      return function(i) {
        var a = e.scale.getLabel(i), o = n.replace("{value}", a ?? "");
        return o;
      };
    })(t) : Y(t) ? /* @__PURE__ */ (function(n) {
      return function(i, a) {
        return r != null && (a = i.value - r), n(HC(e, i), a, i.level != null ? {
          level: i.level
        } : null);
      };
    })(t) : function(n) {
      return e.scale.getLabel(n);
    };
  }
  HC = function(e, t) {
    return e.type === "category" ? e.scale.getLabel(t) : t.value;
  };
  ax = function(e) {
    var t = e.model, r = e.scale;
    if (!(!t.get([
      "axisLabel",
      "show"
    ]) || r.isBlank())) {
      var n, i, a = r.getExtent();
      r instanceof gs ? i = r.count() : (n = r.getTicks(), i = n.length);
      var o = e.getLabelModel(), s = Yn(e), u, l = 1;
      i > 40 && (l = Math.ceil(i / 40));
      for (var f = 0; f < i; f += l) {
        var h = n ? n[f] : {
          value: a[0] + f
        }, c = s(h, f), v = o.getTextRect(c), p = UC(v, o.get("rotate") || 0);
        u ? u.union(p) : u = p;
      }
      return u;
    }
  };
  function UC(e, t) {
    var r = t * Math.PI / 180, n = e.width, i = e.height, a = n * Math.abs(Math.cos(r)) + Math.abs(i * Math.sin(r)), o = n * Math.abs(Math.sin(r)) + Math.abs(i * Math.cos(r)), s = new at(e.x, e.y, a, o);
    return s;
  }
  function Vf(e) {
    var t = e.get("interval");
    return t ?? "auto";
  }
  WC = function(e) {
    return e.type === "category" && Vf(e.getLabelModel()) === 0;
  };
  YC = function(e, t) {
    var r = {};
    return P(e.mapDimensionsAll(t), function(n) {
      r[$0(e, n)] = true;
    }), K(r);
  };
  ox = function(e, t, r) {
    t && P(YC(t, r), function(n) {
      var i = t.getApproximateExtent(n);
      i[0] < e[0] && (e[0] = i[0]), i[1] > e[1] && (e[1] = i[1]);
    });
  };
  qC = (function() {
    function e() {
    }
    return e.prototype.getNeedCrossZero = function() {
      var t = this.option;
      return !t.scale;
    }, e.prototype.getCoordSysModel = function() {
    }, e;
  })();
  function XC(e) {
    return Z0(null, e);
  }
  var $C = {
    isDimensionStacked: Bn,
    enableDataStack: X0,
    getStackedDimension: $0
  };
  function ZC(e, t) {
    var r = t;
    t instanceof wt || (r = new wt(t));
    var n = GC(r);
    return n.setExtent(e[0], e[1]), VC(n, r), n;
  }
  function KC(e) {
    ae(e, qC);
  }
  function jC(e, t) {
    return t = t || {}, En(e, null, null, t.state !== "normal");
  }
  const QC = Object.freeze(Object.defineProperty({
    __proto__: null,
    createDimensions: jM,
    createList: XC,
    createScale: ZC,
    createSymbol: Fn,
    createTextStyle: jC,
    dataStack: $C,
    enableHoverEmphasis: Ei,
    getECData: mt,
    getLayoutRect: Sf,
    mixinAxisModelCommonMethods: KC
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  var qc = [], JC = {
    registerPreprocessor: Rf,
    registerProcessor: Of,
    registerPostInit: k0,
    registerPostUpdate: N0,
    registerUpdateLifecycle: vs,
    registerAction: on,
    registerCoordinateSystem: F0,
    registerLayout: B0,
    registerVisual: mr,
    registerTransform: V0,
    registerLoading: Nf,
    registerMap: z0,
    registerImpl: vM,
    PRIORITY: D0,
    ComponentModel: nt,
    ComponentView: Xe,
    SeriesModel: _e,
    ChartView: Xt,
    registerComponentModel: function(e) {
      nt.registerClass(e);
    },
    registerComponentView: function(e) {
      Xe.registerClass(e);
    },
    registerSeriesModel: function(e) {
      _e.registerClass(e);
    },
    registerChartView: function(e) {
      Xt.registerClass(e);
    },
    registerSubTypeDefaulter: function(e, t) {
      nt.registerSubTypeDefaulter(e, t);
    },
    registerPainter: function(e, t) {
      dd(e, t);
    }
  };
  ty = function(e) {
    if (B(e)) {
      P(e, function(t) {
        ty(t);
      });
      return;
    }
    vt(qc, e) >= 0 || (qc.push(e), Y(e) && (e = {
      install: e
    }), e.install(JC));
  };
  var tD = 1e-8;
  function Xc(e, t) {
    return Math.abs(e - t) < tD;
  }
  function $c(e, t, r) {
    var n = 0, i = e[0];
    if (!i) return false;
    for (var a = 1; a < e.length; a++) {
      var o = e[a];
      n += We(i[0], i[1], o[0], o[1], t, r), i = o;
    }
    var s = e[0];
    return (!Xc(i[0], s[0]) || !Xc(i[1], s[1])) && (n += We(i[0], i[1], s[0], s[1], t, r)), n !== 0;
  }
  var eD = [];
  function Du(e, t) {
    for (var r = 0; r < e.length; r++) Ye(e[r], e[r], t);
  }
  function Zc(e, t, r, n) {
    for (var i = 0; i < e.length; i++) {
      var a = e[i];
      n && (a = n.project(a)), a && isFinite(a[0]) && isFinite(a[1]) && (or(t, t, a), sr(r, r, a));
    }
  }
  function rD(e) {
    for (var t = 0, r = 0, n = 0, i = e.length, a = e[i - 1][0], o = e[i - 1][1], s = 0; s < i; s++) {
      var u = e[s][0], l = e[s][1], f = a * l - u * o;
      t += f, r += (a + u) * f, n += (o + l) * f, a = u, o = l;
    }
    return t ? [
      r / t / 3,
      n / t / 3,
      t
    ] : [
      e[0][0] || 0,
      e[0][1] || 0
    ];
  }
  var ey = (function() {
    function e(t) {
      this.name = t;
    }
    return e.prototype.setCenter = function(t) {
      this._center = t;
    }, e.prototype.getCenter = function() {
      var t = this._center;
      return t || (t = this._center = this.calcCenter()), t;
    }, e;
  })(), Kc = /* @__PURE__ */ (function() {
    function e(t, r) {
      this.type = "polygon", this.exterior = t, this.interiors = r;
    }
    return e;
  })(), jc = /* @__PURE__ */ (function() {
    function e(t) {
      this.type = "linestring", this.points = t;
    }
    return e;
  })(), nD = (function(e) {
    ft(t, e);
    function t(r, n, i) {
      var a = e.call(this, r) || this;
      return a.type = "geoJSON", a.geometries = n, a._center = i && [
        i[0],
        i[1]
      ], a;
    }
    return t.prototype.calcCenter = function() {
      for (var r = this.geometries, n, i = 0, a = 0; a < r.length; a++) {
        var o = r[a], s = o.exterior, u = s && s.length;
        u > i && (n = o, i = u);
      }
      if (n) return rD(n.exterior);
      var l = this.getBoundingRect();
      return [
        l.x + l.width / 2,
        l.y + l.height / 2
      ];
    }, t.prototype.getBoundingRect = function(r) {
      var n = this._rect;
      if (n && !r) return n;
      var i = [
        1 / 0,
        1 / 0
      ], a = [
        -1 / 0,
        -1 / 0
      ], o = this.geometries;
      return P(o, function(s) {
        s.type === "polygon" ? Zc(s.exterior, i, a, r) : P(s.points, function(u) {
          Zc(u, i, a, r);
        });
      }), isFinite(i[0]) && isFinite(i[1]) && isFinite(a[0]) && isFinite(a[1]) || (i[0] = i[1] = a[0] = a[1] = 0), n = new at(i[0], i[1], a[0] - i[0], a[1] - i[1]), r || (this._rect = n), n;
    }, t.prototype.contain = function(r) {
      var n = this.getBoundingRect(), i = this.geometries;
      if (!n.contain(r[0], r[1])) return false;
      t: for (var a = 0, o = i.length; a < o; a++) {
        var s = i[a];
        if (s.type === "polygon") {
          var u = s.exterior, l = s.interiors;
          if ($c(u, r[0], r[1])) {
            for (var f = 0; f < (l ? l.length : 0); f++) if ($c(l[f], r[0], r[1])) continue t;
            return true;
          }
        }
      }
      return false;
    }, t.prototype.transformTo = function(r, n, i, a) {
      var o = this.getBoundingRect(), s = o.width / o.height;
      i ? a || (a = i / s) : i = s * a;
      for (var u = new at(r, n, i, a), l = o.calculateTransform(u), f = this.geometries, h = 0; h < f.length; h++) {
        var c = f[h];
        c.type === "polygon" ? (Du(c.exterior, l), P(c.interiors, function(v) {
          Du(v, l);
        })) : P(c.points, function(v) {
          Du(v, l);
        });
      }
      o = this._rect, o.copy(u), this._center = [
        o.x + o.width / 2,
        o.y + o.height / 2
      ];
    }, t.prototype.cloneShallow = function(r) {
      r == null && (r = this.name);
      var n = new t(r, this.geometries, this._center);
      return n._rect = this._rect, n.transformTo = null, n;
    }, t;
  })(ey);
  (function(e) {
    ft(t, e);
    function t(r, n) {
      var i = e.call(this, r) || this;
      return i.type = "geoSVG", i._elOnlyForCalculate = n, i;
    }
    return t.prototype.calcCenter = function() {
      for (var r = this._elOnlyForCalculate, n = r.getBoundingRect(), i = [
        n.x + n.width / 2,
        n.y + n.height / 2
      ], a = No(eD), o = r; o && !o.isGeoSVGGraphicRoot; ) In(a, o.getLocalTransform(), a), o = o.parent;
      return Fo(a, a), Ye(i, i, a), i;
    }, t;
  })(ey);
  function iD(e) {
    if (!e.UTF8Encoding) return e;
    var t = e, r = t.UTF8Scale;
    r == null && (r = 1024);
    var n = t.features;
    return P(n, function(i) {
      var a = i.geometry, o = a.encodeOffsets, s = a.coordinates;
      if (o) switch (a.type) {
        case "LineString":
          a.coordinates = ry(s, o, r);
          break;
        case "Polygon":
          xu(s, o, r);
          break;
        case "MultiLineString":
          xu(s, o, r);
          break;
        case "MultiPolygon":
          P(s, function(u, l) {
            return xu(u, o[l], r);
          });
      }
    }), t.UTF8Encoding = false, t;
  }
  function xu(e, t, r) {
    for (var n = 0; n < e.length; n++) e[n] = ry(e[n], t[n], r);
  }
  function ry(e, t, r) {
    for (var n = [], i = t[0], a = t[1], o = 0; o < e.length; o += 2) {
      var s = e.charCodeAt(o) - 64, u = e.charCodeAt(o + 1) - 64;
      s = s >> 1 ^ -(s & 1), u = u >> 1 ^ -(u & 1), s += i, u += a, i = s, a = u, n.push([
        s / r,
        u / r
      ]);
    }
    return n;
  }
  function Qc(e, t) {
    return e = iD(e), F(yt(e.features, function(r) {
      return r.geometry && r.properties && r.geometry.coordinates.length > 0;
    }), function(r) {
      var n = r.properties, i = r.geometry, a = [];
      switch (i.type) {
        case "Polygon":
          var o = i.coordinates;
          a.push(new Kc(o[0], o.slice(1)));
          break;
        case "MultiPolygon":
          P(i.coordinates, function(u) {
            u[0] && a.push(new Kc(u[0], u.slice(1)));
          });
          break;
        case "LineString":
          a.push(new jc([
            i.coordinates
          ]));
          break;
        case "MultiLineString":
          a.push(new jc(i.coordinates));
      }
      var s = new nD(n[t || "name"], a, n.cp);
      return s.properties = n, s;
    });
  }
  const aD = Object.freeze(Object.defineProperty({
    __proto__: null,
    MAX_SAFE_INTEGER: e1,
    asc: _d,
    getPercentWithPrecision: Q_,
    getPixelPrecision: bd,
    getPrecision: Ae,
    getPrecisionSafe: Sd,
    isNumeric: Td,
    isRadianAroundZero: n1,
    linearMap: rl,
    nice: Zl,
    numericToNumber: Wi,
    parseDate: ie,
    quantile: a1,
    quantity: wd,
    quantityExponent: Go,
    reformIntervals: o1,
    remRadian: r1,
    round: bt
  }, Symbol.toStringTag, {
    value: "Module"
  })), oD = Object.freeze(Object.defineProperty({
    __proto__: null,
    format: ns,
    parse: ie
  }, Symbol.toStringTag, {
    value: "Module"
  })), sD = Object.freeze(Object.defineProperty({
    __proto__: null,
    Arc: oa,
    BezierCurve: Jo,
    BoundingRect: at,
    Circle: ia,
    CompoundPath: rf,
    Ellipse: Zo,
    Group: oe,
    Image: Se,
    IncrementalDisplayable: og,
    Line: en,
    LinearGradient: nf,
    Polygon: jo,
    Polyline: Qo,
    RadialGradient: ag,
    Rect: ne,
    Ring: Ko,
    Sector: aa,
    Text: Re,
    clipPointsByRect: cg,
    clipRectByRect: pg,
    createIcon: lf,
    extendPath: ug,
    extendShape: sg,
    getShapeClass: lg,
    getTransform: vg,
    initProps: Hn,
    makeImage: of,
    makePath: ts,
    mergePath: hg,
    registerShape: se,
    resizePath: sf,
    updateProps: rn
  }, Symbol.toStringTag, {
    value: "Module"
  })), uD = Object.freeze(Object.defineProperty({
    __proto__: null,
    addCommas: mf,
    capitalFirst: Zb,
    encodeHTML: Et,
    formatTime: $b,
    formatTpl: Ag,
    getTextRect: qb,
    getTooltipMarker: Eg,
    normalizeCssArray: Ig,
    toCamelCase: Xb,
    truncateText: L1
  }, Symbol.toStringTag, {
    value: "Module"
  })), lD = Object.freeze(Object.defineProperty({
    __proto__: null,
    bind: ut,
    clone: Z,
    curry: Vn,
    defaults: ht,
    each: P,
    extend: O,
    filter: yt,
    indexOf: vt,
    inherits: Fl,
    isArray: B,
    isFunction: Y,
    isObject: G,
    isString: V,
    map: F,
    merge: ct,
    reduce: Le
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  var Qi = Pt();
  function ny(e, t) {
    var r = F(t, function(n) {
      return e.scale.parse(n);
    });
    return e.type === "time" && r.length > 0 && (r.sort(), r.unshift(r[0]), r.push(r[r.length - 1])), r;
  }
  function fD(e) {
    var t = e.getLabelModel().get("customValues");
    if (t) {
      var r = Yn(e), n = e.scale.getExtent(), i = ny(e, t), a = yt(i, function(o) {
        return o >= n[0] && o <= n[1];
      });
      return {
        labels: F(a, function(o) {
          var s = {
            value: o
          };
          return {
            formattedLabel: r(s),
            rawLabel: e.scale.getLabel(s),
            tickValue: o
          };
        })
      };
    }
    return e.type === "category" ? vD(e) : pD(e);
  }
  function hD(e, t) {
    var r = e.getTickModel().get("customValues");
    if (r) {
      var n = e.scale.getExtent(), i = ny(e, r);
      return {
        ticks: yt(i, function(a) {
          return a >= n[0] && a <= n[1];
        })
      };
    }
    return e.type === "category" ? cD(e, t) : {
      ticks: F(e.scale.getTicks(), function(a) {
        return a.value;
      })
    };
  }
  function vD(e) {
    var t = e.getLabelModel(), r = iy(e, t);
    return !t.get("show") || e.scale.isBlank() ? {
      labels: [],
      labelCategoryInterval: r.labelCategoryInterval
    } : r;
  }
  function iy(e, t) {
    var r = ay(e, "labels"), n = Vf(t), i = oy(r, n);
    if (i) return i;
    var a, o;
    return Y(n) ? a = ly(e, n) : (o = n === "auto" ? dD(e) : n, a = uy(e, o)), sy(r, n, {
      labels: a,
      labelCategoryInterval: o
    });
  }
  function cD(e, t) {
    var r = ay(e, "ticks"), n = Vf(t), i = oy(r, n);
    if (i) return i;
    var a, o;
    if ((!t.get("show") || e.scale.isBlank()) && (a = []), Y(n)) a = ly(e, n, true);
    else if (n === "auto") {
      var s = iy(e, e.getLabelModel());
      o = s.labelCategoryInterval, a = F(s.labels, function(u) {
        return u.tickValue;
      });
    } else o = n, a = uy(e, o, true);
    return sy(r, n, {
      ticks: a,
      tickCategoryInterval: o
    });
  }
  function pD(e) {
    var t = e.scale.getTicks(), r = Yn(e);
    return {
      labels: F(t, function(n, i) {
        return {
          level: n.level,
          formattedLabel: r(n, i),
          rawLabel: e.scale.getLabel(n),
          tickValue: n.value
        };
      })
    };
  }
  function ay(e, t) {
    return Qi(e)[t] || (Qi(e)[t] = []);
  }
  function oy(e, t) {
    for (var r = 0; r < e.length; r++) if (e[r].key === t) return e[r].value;
  }
  function sy(e, t, r) {
    return e.push({
      key: t,
      value: r
    }), r;
  }
  function dD(e) {
    var t = Qi(e).autoInterval;
    return t ?? (Qi(e).autoInterval = e.calculateCategoryInterval());
  }
  function gD(e) {
    var t = yD(e), r = Yn(e), n = (t.axisRotate - t.labelRotate) / 180 * Math.PI, i = e.scale, a = i.getExtent(), o = i.count();
    if (a[1] - a[0] < 1) return 0;
    var s = 1;
    o > 40 && (s = Math.max(1, Math.floor(o / 40)));
    for (var u = a[0], l = e.dataToCoord(u + 1) - e.dataToCoord(u), f = Math.abs(l * Math.cos(n)), h = Math.abs(l * Math.sin(n)), c = 0, v = 0; u <= a[1]; u += s) {
      var p = 0, y = 0, g = vd(r({
        value: u
      }), t.font, "center", "top");
      p = g.width * 1.3, y = g.height * 1.3, c = Math.max(c, p, 7), v = Math.max(v, y, 7);
    }
    var d = c / f, m = v / h;
    isNaN(d) && (d = 1 / 0), isNaN(m) && (m = 1 / 0);
    var _ = Math.max(0, Math.floor(Math.min(d, m))), S = Qi(e.model), T = e.getExtent(), b = S.lastAutoInterval, w = S.lastTickCount;
    return b != null && w != null && Math.abs(b - _) <= 1 && Math.abs(w - o) <= 1 && b > _ && S.axisExtent0 === T[0] && S.axisExtent1 === T[1] ? _ = b : (S.lastTickCount = o, S.lastAutoInterval = _, S.axisExtent0 = T[0], S.axisExtent1 = T[1]), _;
  }
  function yD(e) {
    var t = e.getLabelModel();
    return {
      axisRotate: e.getRotate ? e.getRotate() : e.isHorizontal && !e.isHorizontal() ? 90 : 0,
      labelRotate: t.get("rotate") || 0,
      font: t.getFont()
    };
  }
  function uy(e, t, r) {
    var n = Yn(e), i = e.scale, a = i.getExtent(), o = e.getLabelModel(), s = [], u = Math.max((t || 0) + 1, 1), l = a[0], f = i.count();
    l !== 0 && u > 1 && f / u > 2 && (l = Math.round(Math.ceil(l / u) * u));
    var h = WC(e), c = o.get("showMinLabel") || h, v = o.get("showMaxLabel") || h;
    c && l !== a[0] && y(a[0]);
    for (var p = l; p <= a[1]; p += u) y(p);
    v && p - u !== a[1] && y(a[1]);
    function y(g) {
      var d = {
        value: g
      };
      s.push(r ? g : {
        formattedLabel: n(d),
        rawLabel: i.getLabel(d),
        tickValue: g
      });
    }
    return s;
  }
  function ly(e, t, r) {
    var n = e.scale, i = Yn(e), a = [];
    return P(n.getTicks(), function(o) {
      var s = n.getLabel(o), u = o.value;
      t(o.value, s) && a.push(r ? u : {
        formattedLabel: i(o),
        rawLabel: s,
        tickValue: u
      });
    }), a;
  }
  let Jc;
  Jc = [
    0,
    1
  ];
  fy = (function() {
    function e(t, r, n) {
      this.onBand = false, this.inverse = false, this.dim = t, this.scale = r, this._extent = n || [
        0,
        0
      ];
    }
    return e.prototype.contain = function(t) {
      var r = this._extent, n = Math.min(r[0], r[1]), i = Math.max(r[0], r[1]);
      return t >= n && t <= i;
    }, e.prototype.containData = function(t) {
      return this.scale.contain(t);
    }, e.prototype.getExtent = function() {
      return this._extent.slice();
    }, e.prototype.getPixelPrecision = function(t) {
      return bd(t || this.scale.getExtent(), this._extent);
    }, e.prototype.setExtent = function(t, r) {
      var n = this._extent;
      n[0] = t, n[1] = r;
    }, e.prototype.dataToCoord = function(t, r) {
      var n = this._extent, i = this.scale;
      return t = i.normalize(t), this.onBand && i.type === "ordinal" && (n = n.slice(), tp(n, i.count())), rl(t, Jc, n, r);
    }, e.prototype.coordToData = function(t, r) {
      var n = this._extent, i = this.scale;
      this.onBand && i.type === "ordinal" && (n = n.slice(), tp(n, i.count()));
      var a = rl(t, n, Jc, r);
      return this.scale.scale(a);
    }, e.prototype.pointToData = function(t, r) {
    }, e.prototype.getTicksCoords = function(t) {
      t = t || {};
      var r = t.tickModel || this.getTickModel(), n = hD(this, r), i = n.ticks, a = F(i, function(s) {
        return {
          coord: this.dataToCoord(this.scale.type === "ordinal" ? this.scale.getRawOrdinalNumber(s) : s),
          tickValue: s
        };
      }, this), o = r.get("alignWithLabel");
      return mD(this, a, o, t.clamp), a;
    }, e.prototype.getMinorTicksCoords = function() {
      if (this.scale.type === "ordinal") return [];
      var t = this.model.getModel("minorTick"), r = t.get("splitNumber");
      r > 0 && r < 100 || (r = 5);
      var n = this.scale.getMinorTicks(r), i = F(n, function(a) {
        return F(a, function(o) {
          return {
            coord: this.dataToCoord(o),
            tickValue: o
          };
        }, this);
      }, this);
      return i;
    }, e.prototype.getViewLabels = function() {
      return fD(this).labels;
    }, e.prototype.getLabelModel = function() {
      return this.model.getModel("axisLabel");
    }, e.prototype.getTickModel = function() {
      return this.model.getModel("axisTick");
    }, e.prototype.getBandWidth = function() {
      var t = this._extent, r = this.scale.getExtent(), n = r[1] - r[0] + (this.onBand ? 1 : 0);
      n === 0 && (n = 1);
      var i = Math.abs(t[1] - t[0]);
      return Math.abs(i) / n;
    }, e.prototype.calculateCategoryInterval = function() {
      return gD(this);
    }, e;
  })();
  function tp(e, t) {
    var r = e[1] - e[0], n = t, i = r / n / 2;
    e[0] += i, e[1] -= i;
  }
  function mD(e, t, r, n) {
    var i = t.length;
    if (!e.onBand || r || !i) return;
    var a = e.getExtent(), o, s;
    if (i === 1) t[0].coord = a[0], o = t[1] = {
      coord: a[1],
      tickValue: t[0].tickValue
    };
    else {
      var u = t[i - 1].tickValue - t[0].tickValue, l = (t[i - 1].coord - t[0].coord) / u;
      P(t, function(v) {
        v.coord -= l / 2;
      });
      var f = e.scale.getExtent();
      s = 1 + f[1] - t[i - 1].tickValue, o = {
        coord: t[i - 1].coord + l * s,
        tickValue: f[1] + 1
      }, t.push(o);
    }
    var h = a[0] > a[1];
    c(t[0].coord, a[0]) && (n ? t[0].coord = a[0] : t.shift()), n && c(a[0], t[0].coord) && t.unshift({
      coord: a[0]
    }), c(a[1], o.coord) && (n ? o.coord = a[1] : t.pop()), n && c(o.coord, a[1]) && t.push({
      coord: a[1]
    });
    function c(v, p) {
      return v = bt(v), p = bt(p), h ? v > p : v < p;
    }
  }
  function _D(e) {
    var t = nt.extend(e);
    return nt.registerClass(t), t;
  }
  function SD(e) {
    var t = Xe.extend(e);
    return Xe.registerClass(t), t;
  }
  function bD(e) {
    var t = _e.extend(e);
    return _e.registerClass(t), t;
  }
  function wD(e) {
    var t = Xt.extend(e);
    return Xt.registerClass(t), t;
  }
  sx = Object.freeze(Object.defineProperty({
    __proto__: null,
    Axis: fy,
    ChartView: Xt,
    ComponentModel: nt,
    ComponentView: Xe,
    List: Ff,
    Model: wt,
    PRIORITY: D0,
    SeriesModel: _e,
    color: d_,
    connect: LM,
    dataTool: zM,
    dependencies: pM,
    disConnect: RM,
    disconnect: O0,
    dispose: OM,
    env: j,
    extendChartView: wD,
    extendComponentModel: _D,
    extendComponentView: SD,
    extendSeriesModel: bD,
    format: uD,
    getCoordinateSystemDimensions: NM,
    getInstanceByDom: Ef,
    getInstanceById: kM,
    getMap: BM,
    graphic: sD,
    helper: QC,
    init: EM,
    innerDrawElementOnCanvas: y0,
    matrix: Um,
    number: aD,
    parseGeoJSON: Qc,
    parseGeoJson: Qc,
    registerAction: on,
    registerCoordinateSystem: F0,
    registerLayout: B0,
    registerLoading: Nf,
    registerLocale: pf,
    registerMap: z0,
    registerPostInit: k0,
    registerPostUpdate: N0,
    registerPreprocessor: Rf,
    registerProcessor: Of,
    registerTheme: Lf,
    registerTransform: V0,
    registerUpdateLifecycle: vs,
    registerVisual: mr,
    setCanvasCreator: FM,
    setPlatformAPI: Ep,
    throttle: Df,
    time: oD,
    use: ty,
    util: lD,
    vector: xm,
    version: cM,
    zrUtil: gm,
    zrender: K_
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  var TD = (function(e) {
    ft(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.type = t.type, r.hasSymbolVisual = true, r;
    }
    return t.prototype.getInitialData = function(r) {
      return Z0(null, this, {
        useEncodeDefaulter: true
      });
    }, t.prototype.getLegendIcon = function(r) {
      var n = new oe(), i = Fn("line", 0, r.itemHeight / 2, r.itemWidth, 0, r.lineStyle.stroke, false);
      n.add(i), i.setStyle(r.lineStyle);
      var a = this.getData().getVisual("symbol"), o = this.getData().getVisual("symbolRotate"), s = a === "none" ? "circle" : a, u = r.itemHeight * 0.8, l = Fn(s, (r.itemWidth - u) / 2, (r.itemHeight - u) / 2, u, u, r.itemStyle.fill);
      n.add(l), l.setStyle(r.itemStyle);
      var f = r.iconRotate === "inherit" ? o : r.iconRotate || 0;
      return l.rotation = f * Math.PI / 180, l.setOrigin([
        r.itemWidth / 2,
        r.itemHeight / 2
      ]), s.indexOf("empty") > -1 && (l.style.stroke = l.style.fill, l.style.fill = "#fff", l.style.lineWidth = 2), n;
    }, t.type = "series.line", t.dependencies = [
      "grid",
      "polar"
    ], t.defaultOption = {
      z: 3,
      coordinateSystem: "cartesian2d",
      legendHoverLink: true,
      clip: true,
      label: {
        position: "top"
      },
      endLabel: {
        show: false,
        valueAnimation: true,
        distance: 8
      },
      lineStyle: {
        width: 2,
        type: "solid"
      },
      emphasis: {
        scale: true
      },
      step: false,
      smooth: false,
      smoothMonotone: null,
      symbol: "emptyCircle",
      symbolSize: 4,
      symbolRotate: null,
      showSymbol: true,
      showAllSymbol: "auto",
      connectNulls: false,
      sampling: "none",
      animationEasing: "linear",
      progressive: 0,
      hoverLayerThreshold: 1 / 0,
      universalTransition: {
        divideShape: "clone"
      },
      triggerLineEvent: false
    }, t;
  })(_e);
  function hy(e, t) {
    var r = e.mapDimensionsAll("defaultedLabel"), n = r.length;
    if (n === 1) {
      var i = Nn(e, t, r[0]);
      return i != null ? i + "" : null;
    } else if (n) {
      for (var a = [], o = 0; o < r.length; o++) a.push(Nn(e, t, r[o]));
      return a.join(" ");
    }
  }
  function MD(e, t) {
    var r = e.mapDimensionsAll("defaultedLabel");
    if (!B(t)) return t + "";
    for (var n = [], i = 0; i < r.length; i++) {
      var a = e.getDimensionIndex(r[i]);
      a >= 0 && n.push(t[a]);
    }
    return n.join(" ");
  }
  var Gf = (function(e) {
    ft(t, e);
    function t(r, n, i, a) {
      var o = e.call(this) || this;
      return o.updateData(r, n, i, a), o;
    }
    return t.prototype._createSymbol = function(r, n, i, a, o) {
      this.removeAll();
      var s = Fn(r, -1, -1, 2, 2, null, o);
      s.attr({
        z2: 100,
        culling: true,
        scaleX: a[0] / 2,
        scaleY: a[1] / 2
      }), s.drift = CD, this._symbolType = r, this.add(s);
    }, t.prototype.stopSymbolAnimation = function(r) {
      this.childAt(0).stopAnimation(null, r);
    }, t.prototype.getSymbolType = function() {
      return this._symbolType;
    }, t.prototype.getSymbolPath = function() {
      return this.childAt(0);
    }, t.prototype.highlight = function() {
      po(this.childAt(0));
    }, t.prototype.downplay = function() {
      go(this.childAt(0));
    }, t.prototype.setZ = function(r, n) {
      var i = this.childAt(0);
      i.zlevel = r, i.z = n;
    }, t.prototype.setDraggable = function(r, n) {
      var i = this.childAt(0);
      i.draggable = r, i.cursor = !n && r ? "move" : i.cursor;
    }, t.prototype.updateData = function(r, n, i, a) {
      this.silent = false;
      var o = r.getItemVisual(n, "symbol") || "circle", s = r.hostModel, u = t.getSymbolSize(r, n), l = o !== this._symbolType, f = a && a.disableAnimation;
      if (l) {
        var h = r.getItemVisual(n, "symbolKeepAspect");
        this._createSymbol(o, r, n, u, h);
      } else {
        var c = this.childAt(0);
        c.silent = false;
        var v = {
          scaleX: u[0] / 2,
          scaleY: u[1] / 2
        };
        f ? c.attr(v) : rn(c, v, s, n), vb(c);
      }
      if (this._updateCommon(r, n, u, i, a), l) {
        var c = this.childAt(0);
        if (!f) {
          var v = {
            scaleX: this._sizeX,
            scaleY: this._sizeY,
            style: {
              opacity: c.style.opacity
            }
          };
          c.scaleX = c.scaleY = 0, c.style.opacity = 0, Hn(c, v, s, n);
        }
      }
      f && this.childAt(0).stopAnimation("leave");
    }, t.prototype._updateCommon = function(r, n, i, a, o) {
      var s = this.childAt(0), u = r.hostModel, l, f, h, c, v, p, y, g, d;
      if (a && (l = a.emphasisItemStyle, f = a.blurItemStyle, h = a.selectItemStyle, c = a.focus, v = a.blurScope, y = a.labelStatesModels, g = a.hoverScale, d = a.cursorStyle, p = a.emphasisDisabled), !a || r.hasItemOption) {
        var m = a && a.itemModel ? a.itemModel : r.getItemModel(n), _ = m.getModel("emphasis");
        l = _.getModel("itemStyle").getItemStyle(), h = m.getModel([
          "select",
          "itemStyle"
        ]).getItemStyle(), f = m.getModel([
          "blur",
          "itemStyle"
        ]).getItemStyle(), c = _.get("focus"), v = _.get("blurScope"), p = _.get("disabled"), y = hf(m), g = _.getShallow("scale"), d = m.getShallow("cursor");
      }
      var S = r.getItemVisual(n, "symbolRotate");
      s.attr("rotation", (S || 0) * Math.PI / 180 || 0);
      var T = p0(r.getItemVisual(n, "symbolOffset"), i);
      T && (s.x = T[0], s.y = T[1]), d && s.attr("cursor", d);
      var b = r.getItemVisual(n, "style"), w = b.fill;
      if (s instanceof Se) {
        var D = s.style;
        s.useStyle(O({
          image: D.image,
          x: D.x,
          y: D.y,
          width: D.width,
          height: D.height
        }, b));
      } else s.__isEmptyBrush ? s.useStyle(O({}, b)) : s.useStyle(b), s.style.decal = null, s.setColor(w, o && o.symbolInnerColor), s.style.strokeNoScale = true;
      var C = r.getItemVisual(n, "liftZ"), M = this._z2;
      C != null ? M == null && (this._z2 = s.z2, s.z2 += C) : M != null && (s.z2 = M, this._z2 = null);
      var x = o && o.useNameLabel;
      gg(s, y, {
        labelFetcher: u,
        labelDataIndex: n,
        defaultText: I,
        inheritColor: w,
        defaultOpacity: b.opacity
      });
      function I(R) {
        return x ? r.getName(R) : hy(r, R);
      }
      this._sizeX = i[0] / 2, this._sizeY = i[1] / 2;
      var A = s.ensureState("emphasis");
      A.style = l, s.ensureState("select").style = h, s.ensureState("blur").style = f;
      var E = g == null || g === true ? Math.max(1.1, 3 / this._sizeY) : isFinite(g) && g > 0 ? +g : 1;
      A.scaleX = this._sizeX * E, A.scaleY = this._sizeY * E, this.setSymbolScale(1), ul(this, c, v, p);
    }, t.prototype.setSymbolScale = function(r) {
      this.scaleX = this.scaleY = r;
    }, t.prototype.fadeOut = function(r, n, i) {
      var a = this.childAt(0), o = mt(this).dataIndex, s = i && i.animation;
      if (this.silent = a.silent = true, i && i.fadeLabel) {
        var u = a.getTextContent();
        u && yo(u, {
          style: {
            opacity: 0
          }
        }, n, {
          dataIndex: o,
          removeOpt: s,
          cb: function() {
            a.removeTextContent();
          }
        });
      } else a.removeTextContent();
      yo(a, {
        style: {
          opacity: 0
        },
        scaleX: 0,
        scaleY: 0
      }, n, {
        dataIndex: o,
        cb: r,
        removeOpt: s
      });
    }, t.getSymbolSize = function(r, n) {
      return c0(r.getItemVisual(n, "symbolSize"));
    }, t;
  })(oe);
  function CD(e, t) {
    this.parent.drift(e, t);
  }
  function Pu(e, t, r, n) {
    return t && !isNaN(t[0]) && !isNaN(t[1]) && !(n.isIgnore && n.isIgnore(r)) && !(n.clipShape && !n.clipShape.contain(t[0], t[1])) && e.getItemVisual(r, "symbol") !== "none";
  }
  function ep(e) {
    return e != null && !G(e) && (e = {
      isIgnore: e
    }), e || {};
  }
  function rp(e) {
    var t = e.hostModel, r = t.getModel("emphasis");
    return {
      emphasisItemStyle: r.getModel("itemStyle").getItemStyle(),
      blurItemStyle: t.getModel([
        "blur",
        "itemStyle"
      ]).getItemStyle(),
      selectItemStyle: t.getModel([
        "select",
        "itemStyle"
      ]).getItemStyle(),
      focus: r.get("focus"),
      blurScope: r.get("blurScope"),
      emphasisDisabled: r.get("disabled"),
      hoverScale: r.get("scale"),
      labelStatesModels: hf(t),
      cursorStyle: t.get("cursor")
    };
  }
  var DD = (function() {
    function e(t) {
      this.group = new oe(), this._SymbolCtor = t || Gf;
    }
    return e.prototype.updateData = function(t, r) {
      this._progressiveEls = null, r = ep(r);
      var n = this.group, i = t.hostModel, a = this._data, o = this._SymbolCtor, s = r.disableAnimation, u = rp(t), l = {
        disableAnimation: s
      }, f = r.getSymbolPoint || function(h) {
        return t.getItemLayout(h);
      };
      a || n.removeAll(), t.diff(a).add(function(h) {
        var c = f(h);
        if (Pu(t, c, h, r)) {
          var v = new o(t, h, u, l);
          v.setPosition(c), t.setItemGraphicEl(h, v), n.add(v);
        }
      }).update(function(h, c) {
        var v = a.getItemGraphicEl(c), p = f(h);
        if (!Pu(t, p, h, r)) {
          n.remove(v);
          return;
        }
        var y = t.getItemVisual(h, "symbol") || "circle", g = v && v.getSymbolType && v.getSymbolType();
        if (!v || g && g !== y) n.remove(v), v = new o(t, h, u, l), v.setPosition(p);
        else {
          v.updateData(t, h, u, l);
          var d = {
            x: p[0],
            y: p[1]
          };
          s ? v.attr(d) : rn(v, d, i);
        }
        n.add(v), t.setItemGraphicEl(h, v);
      }).remove(function(h) {
        var c = a.getItemGraphicEl(h);
        c && c.fadeOut(function() {
          n.remove(c);
        }, i);
      }).execute(), this._getSymbolPoint = f, this._data = t;
    }, e.prototype.updateLayout = function() {
      var t = this, r = this._data;
      r && r.eachItemGraphicEl(function(n, i) {
        var a = t._getSymbolPoint(i);
        n.setPosition(a), n.markRedraw();
      });
    }, e.prototype.incrementalPrepareUpdate = function(t) {
      this._seriesScope = rp(t), this._data = null, this.group.removeAll();
    }, e.prototype.incrementalUpdate = function(t, r, n) {
      this._progressiveEls = [], n = ep(n);
      function i(u) {
        u.isGroup || (u.incremental = true, u.ensureState("emphasis").hoverLayer = true);
      }
      for (var a = t.start; a < t.end; a++) {
        var o = r.getItemLayout(a);
        if (Pu(r, o, a, n)) {
          var s = new this._SymbolCtor(r, a, this._seriesScope);
          s.traverse(i), s.setPosition(o), this.group.add(s), r.setItemGraphicEl(a, s), this._progressiveEls.push(s);
        }
      }
    }, e.prototype.eachRendered = function(t) {
      ff(this._progressiveEls || this.group, t);
    }, e.prototype.remove = function(t) {
      var r = this.group, n = this._data;
      n && t ? n.eachItemGraphicEl(function(i) {
        i.fadeOut(function() {
          r.remove(i);
        }, n.hostModel);
      }) : r.removeAll();
    }, e;
  })();
  function vy(e, t, r) {
    var n = e.getBaseAxis(), i = e.getOtherAxis(n), a = xD(i, r), o = n.dim, s = i.dim, u = t.mapDimension(s), l = t.mapDimension(o), f = s === "x" || s === "radius" ? 1 : 0, h = F(e.dimensions, function(p) {
      return t.mapDimension(p);
    }), c = false, v = t.getCalculationInfo("stackResultDimension");
    return Bn(t, h[0]) && (c = true, h[0] = v), Bn(t, h[1]) && (c = true, h[1] = v), {
      dataDimsForPoint: h,
      valueStart: a,
      valueAxisDim: s,
      baseAxisDim: o,
      stacked: !!c,
      valueDim: u,
      baseDim: l,
      baseDataOffset: f,
      stackedOverDimension: t.getCalculationInfo("stackedOverDimension")
    };
  }
  function xD(e, t) {
    var r = 0, n = e.scale.getExtent();
    return t === "start" ? r = n[0] : t === "end" ? r = n[1] : lt(t) && !isNaN(t) ? r = t : n[0] > 0 ? r = n[0] : n[1] < 0 && (r = n[1]), r;
  }
  function cy(e, t, r, n) {
    var i = NaN;
    e.stacked && (i = r.get(r.getCalculationInfo("stackedOverDimension"), n)), isNaN(i) && (i = e.valueStart);
    var a = e.baseDataOffset, o = [];
    return o[a] = r.get(e.baseDim, n), o[1 - a] = i, t.dataToPoint(o);
  }
  function PD(e, t) {
    var r = [];
    return t.diff(e).add(function(n) {
      r.push({
        cmd: "+",
        idx: n
      });
    }).update(function(n, i) {
      r.push({
        cmd: "=",
        idx: i,
        idx1: n
      });
    }).remove(function(n) {
      r.push({
        cmd: "-",
        idx: n
      });
    }).execute(), r;
  }
  function ID(e, t, r, n, i, a, o, s) {
    for (var u = PD(e, t), l = [], f = [], h = [], c = [], v = [], p = [], y = [], g = vy(i, t, o), d = e.getLayout("points") || [], m = t.getLayout("points") || [], _ = 0; _ < u.length; _++) {
      var S = u[_], T = true, b = void 0, w = void 0;
      switch (S.cmd) {
        case "=":
          b = S.idx * 2, w = S.idx1 * 2;
          var D = d[b], C = d[b + 1], M = m[w], x = m[w + 1];
          (isNaN(D) || isNaN(C)) && (D = M, C = x), l.push(D, C), f.push(M, x), h.push(r[b], r[b + 1]), c.push(n[w], n[w + 1]), y.push(t.getRawIndex(S.idx1));
          break;
        case "+":
          var I = S.idx, A = g.dataDimsForPoint, E = i.dataToPoint([
            t.get(A[0], I),
            t.get(A[1], I)
          ]);
          w = I * 2, l.push(E[0], E[1]), f.push(m[w], m[w + 1]);
          var R = cy(g, i, t, I);
          h.push(R[0], R[1]), c.push(n[w], n[w + 1]), y.push(t.getRawIndex(I));
          break;
        case "-":
          T = false;
      }
      T && (v.push(S), p.push(p.length));
    }
    p.sort(function(st, Gt) {
      return y[st] - y[Gt];
    });
    for (var L = l.length, z = xn(L), k = xn(L), N = xn(L), U = xn(L), J = [], _ = 0; _ < p.length; _++) {
      var $ = p[_], rt = _ * 2, tt = $ * 2;
      z[rt] = l[tt], z[rt + 1] = l[tt + 1], k[rt] = f[tt], k[rt + 1] = f[tt + 1], N[rt] = h[tt], N[rt + 1] = h[tt + 1], U[rt] = c[tt], U[rt + 1] = c[tt + 1], J[_] = v[$];
    }
    return {
      current: z,
      next: k,
      stackedOnCurrent: N,
      stackedOnNext: U,
      status: J
    };
  }
  var rr = Math.min, nr = Math.max;
  function Jr(e, t) {
    return isNaN(e) || isNaN(t);
  }
  function xl(e, t, r, n, i, a, o, s, u) {
    for (var l, f, h, c, v, p, y = r, g = 0; g < n; g++) {
      var d = t[y * 2], m = t[y * 2 + 1];
      if (y >= i || y < 0) break;
      if (Jr(d, m)) {
        if (u) {
          y += a;
          continue;
        }
        break;
      }
      if (y === r) e[a > 0 ? "moveTo" : "lineTo"](d, m), h = d, c = m;
      else {
        var _ = d - l, S = m - f;
        if (_ * _ + S * S < 0.5) {
          y += a;
          continue;
        }
        if (o > 0) {
          for (var T = y + a, b = t[T * 2], w = t[T * 2 + 1]; b === d && w === m && g < n; ) g++, T += a, y += a, b = t[T * 2], w = t[T * 2 + 1], d = t[y * 2], m = t[y * 2 + 1], _ = d - l, S = m - f;
          var D = g + 1;
          if (u) for (; Jr(b, w) && D < n; ) D++, T += a, b = t[T * 2], w = t[T * 2 + 1];
          var C = 0.5, M = 0, x = 0, I = void 0, A = void 0;
          if (D >= n || Jr(b, w)) v = d, p = m;
          else {
            M = b - l, x = w - f;
            var E = d - l, R = b - d, L = m - f, z = w - m, k = void 0, N = void 0;
            if (s === "x") {
              k = Math.abs(E), N = Math.abs(R);
              var U = M > 0 ? 1 : -1;
              v = d - U * k * o, p = m, I = d + U * N * o, A = m;
            } else if (s === "y") {
              k = Math.abs(L), N = Math.abs(z);
              var J = x > 0 ? 1 : -1;
              v = d, p = m - J * k * o, I = d, A = m + J * N * o;
            } else k = Math.sqrt(E * E + L * L), N = Math.sqrt(R * R + z * z), C = N / (N + k), v = d - M * o * (1 - C), p = m - x * o * (1 - C), I = d + M * o * C, A = m + x * o * C, I = rr(I, nr(b, d)), A = rr(A, nr(w, m)), I = nr(I, rr(b, d)), A = nr(A, rr(w, m)), M = I - d, x = A - m, v = d - M * k / N, p = m - x * k / N, v = rr(v, nr(l, d)), p = rr(p, nr(f, m)), v = nr(v, rr(l, d)), p = nr(p, rr(f, m)), M = d - v, x = m - p, I = d + M * N / k, A = m + x * N / k;
          }
          e.bezierCurveTo(h, c, v, p, d, m), h = I, c = A;
        } else e.lineTo(d, m);
      }
      l = d, f = m, y += a;
    }
    return g;
  }
  var py = /* @__PURE__ */ (function() {
    function e() {
      this.smooth = 0, this.smoothConstraint = true;
    }
    return e;
  })(), AD = (function(e) {
    ft(t, e);
    function t(r) {
      var n = e.call(this, r) || this;
      return n.type = "ec-polyline", n;
    }
    return t.prototype.getDefaultStyle = function() {
      return {
        stroke: "#000",
        fill: null
      };
    }, t.prototype.getDefaultShape = function() {
      return new py();
    }, t.prototype.buildPath = function(r, n) {
      var i = n.points, a = 0, o = i.length / 2;
      if (n.connectNulls) {
        for (; o > 0 && Jr(i[o * 2 - 2], i[o * 2 - 1]); o--) ;
        for (; a < o && Jr(i[a * 2], i[a * 2 + 1]); a++) ;
      }
      for (; a < o; ) a += xl(r, i, a, o, o, 1, n.smooth, n.smoothMonotone, n.connectNulls) + 1;
    }, t.prototype.getPointOn = function(r, n) {
      this.path || (this.createPathProxy(), this.buildPath(this.path, this.shape));
      for (var i = this.path, a = i.data, o = yr.CMD, s, u, l = n === "x", f = [], h = 0; h < a.length; ) {
        var c = a[h++], v = void 0, p = void 0, y = void 0, g = void 0, d = void 0, m = void 0, _ = void 0;
        switch (c) {
          case o.M:
            s = a[h++], u = a[h++];
            break;
          case o.L:
            if (v = a[h++], p = a[h++], _ = l ? (r - s) / (v - s) : (r - u) / (p - u), _ <= 1 && _ >= 0) {
              var S = l ? (p - u) * _ + u : (v - s) * _ + s;
              return l ? [
                r,
                S
              ] : [
                S,
                r
              ];
            }
            s = v, u = p;
            break;
          case o.C:
            v = a[h++], p = a[h++], y = a[h++], g = a[h++], d = a[h++], m = a[h++];
            var T = l ? uo(s, v, y, d, r, f) : uo(u, p, g, m, r, f);
            if (T > 0) for (var b = 0; b < T; b++) {
              var w = f[b];
              if (w <= 1 && w >= 0) {
                var S = l ? Tt(u, p, g, m, w) : Tt(s, v, y, d, w);
                return l ? [
                  r,
                  S
                ] : [
                  S,
                  r
                ];
              }
            }
            s = d, u = m;
            break;
        }
      }
    }, t;
  })(et), ED = (function(e) {
    ft(t, e);
    function t() {
      return e !== null && e.apply(this, arguments) || this;
    }
    return t;
  })(py), LD = (function(e) {
    ft(t, e);
    function t(r) {
      var n = e.call(this, r) || this;
      return n.type = "ec-polygon", n;
    }
    return t.prototype.getDefaultShape = function() {
      return new ED();
    }, t.prototype.buildPath = function(r, n) {
      var i = n.points, a = n.stackedOnPoints, o = 0, s = i.length / 2, u = n.smoothMonotone;
      if (n.connectNulls) {
        for (; s > 0 && Jr(i[s * 2 - 2], i[s * 2 - 1]); s--) ;
        for (; o < s && Jr(i[o * 2], i[o * 2 + 1]); o++) ;
      }
      for (; o < s; ) {
        var l = xl(r, i, o, s, s, 1, n.smooth, u, n.connectNulls);
        xl(r, a, o + l - 1, l, s, -1, n.stackedOnSmooth, u, n.connectNulls), o += l + 1, r.closePath();
      }
    }, t;
  })(et);
  function RD(e, t, r, n, i) {
    var a = e.getArea(), o = a.x, s = a.y, u = a.width, l = a.height, f = r.get([
      "lineStyle",
      "width"
    ]) || 0;
    o -= f / 2, s -= f / 2, u += f, l += f, u = Math.ceil(u), o !== Math.floor(o) && (o = Math.floor(o), u++);
    var h = new ne({
      shape: {
        x: o,
        y: s,
        width: u,
        height: l
      }
    });
    if (t) {
      var c = e.getBaseAxis(), v = c.isHorizontal(), p = c.inverse;
      v ? (p && (h.shape.x += u), h.shape.width = 0) : (p || (h.shape.y += l), h.shape.height = 0);
      var y = Y(i) ? function(g) {
        i(g, h);
      } : null;
      Hn(h, {
        shape: {
          width: u,
          height: l,
          x: o,
          y: s
        }
      }, r, null, n, y);
    }
    return h;
  }
  function OD(e, t, r) {
    var n = e.getArea(), i = bt(n.r0, 1), a = bt(n.r, 1), o = new aa({
      shape: {
        cx: bt(e.cx, 1),
        cy: bt(e.cy, 1),
        r0: i,
        r: a,
        startAngle: n.startAngle,
        endAngle: n.endAngle,
        clockwise: n.clockwise
      }
    });
    if (t) {
      var s = e.getBaseAxis().dim === "angle";
      s ? o.shape.endAngle = n.startAngle : o.shape.r = i, Hn(o, {
        shape: {
          endAngle: n.endAngle,
          r: a
        }
      }, r);
    }
    return o;
  }
  function kD(e, t) {
    return e.type === t;
  }
  function np(e, t) {
    if (e.length === t.length) {
      for (var r = 0; r < e.length; r++) if (e[r] !== t[r]) return;
      return true;
    }
  }
  function ip(e) {
    for (var t = 1 / 0, r = 1 / 0, n = -1 / 0, i = -1 / 0, a = 0; a < e.length; ) {
      var o = e[a++], s = e[a++];
      isNaN(o) || (t = Math.min(o, t), n = Math.max(o, n)), isNaN(s) || (r = Math.min(s, r), i = Math.max(s, i));
    }
    return [
      [
        t,
        r
      ],
      [
        n,
        i
      ]
    ];
  }
  function ap(e, t) {
    var r = ip(e), n = r[0], i = r[1], a = ip(t), o = a[0], s = a[1];
    return Math.max(Math.abs(n[0] - o[0]), Math.abs(n[1] - o[1]), Math.abs(i[0] - s[0]), Math.abs(i[1] - s[1]));
  }
  function op(e) {
    return lt(e) ? e : e ? 0.5 : 0;
  }
  function ND(e, t, r) {
    if (!r.valueDim) return [];
    for (var n = t.count(), i = xn(n * 2), a = 0; a < n; a++) {
      var o = cy(r, e, t, a);
      i[a * 2] = o[0], i[a * 2 + 1] = o[1];
    }
    return i;
  }
  function ir(e, t, r, n, i) {
    var a = r.getBaseAxis(), o = a.dim === "x" || a.dim === "radius" ? 0 : 1, s = [], u = 0, l = [], f = [], h = [], c = [];
    if (i) {
      for (u = 0; u < e.length; u += 2) {
        var v = t || e;
        !isNaN(v[u]) && !isNaN(v[u + 1]) && c.push(e[u], e[u + 1]);
      }
      e = c;
    }
    for (u = 0; u < e.length - 2; u += 2) switch (h[0] = e[u + 2], h[1] = e[u + 3], f[0] = e[u], f[1] = e[u + 1], s.push(f[0], f[1]), n) {
      case "end":
        l[o] = h[o], l[1 - o] = f[1 - o], s.push(l[0], l[1]);
        break;
      case "middle":
        var p = (f[o] + h[o]) / 2, y = [];
        l[o] = y[o] = p, l[1 - o] = f[1 - o], y[1 - o] = h[1 - o], s.push(l[0], l[1]), s.push(y[0], y[1]);
        break;
      default:
        l[o] = f[o], l[1 - o] = h[1 - o], s.push(l[0], l[1]);
    }
    return s.push(e[u++], e[u++]), s;
  }
  function FD(e, t) {
    var r = [], n = e.length, i, a;
    function o(f, h, c) {
      var v = f.coord, p = (c - v) / (h.coord - v), y = Yl(p, [
        f.color,
        h.color
      ]);
      return {
        coord: c,
        color: y
      };
    }
    for (var s = 0; s < n; s++) {
      var u = e[s], l = u.coord;
      if (l < 0) i = u;
      else if (l > t) {
        a ? r.push(o(a, u, t)) : i && r.push(o(i, u, 0), o(i, u, t));
        break;
      } else i && (r.push(o(i, u, 0)), i = null), r.push(u), a = u;
    }
    return r;
  }
  function BD(e, t, r) {
    var n = e.getVisual("visualMeta");
    if (!(!n || !n.length || !e.count()) && t.type === "cartesian2d") {
      for (var i, a, o = n.length - 1; o >= 0; o--) {
        var s = e.getDimensionInfo(n[o].dimension);
        if (i = s && s.coordDim, i === "x" || i === "y") {
          a = n[o];
          break;
        }
      }
      if (a) {
        var u = t.getAxis(i), l = F(a.stops, function(_) {
          return {
            coord: u.toGlobalCoord(u.dataToCoord(_.value)),
            color: _.color
          };
        }), f = l.length, h = a.outerColors.slice();
        f && l[0].coord > l[f - 1].coord && (l.reverse(), h.reverse());
        var c = FD(l, i === "x" ? r.getWidth() : r.getHeight()), v = c.length;
        if (!v && f) return l[0].coord < 0 ? h[1] ? h[1] : l[f - 1].color : h[0] ? h[0] : l[0].color;
        var p = 10, y = c[0].coord - p, g = c[v - 1].coord + p, d = g - y;
        if (d < 1e-3) return "transparent";
        P(c, function(_) {
          _.offset = (_.coord - y) / d;
        }), c.push({
          offset: v ? c[v - 1].offset : 0.5,
          color: h[1] || "transparent"
        }), c.unshift({
          offset: v ? c[0].offset : 0.5,
          color: h[0] || "transparent"
        });
        var m = new nf(0, 0, 0, 0, c, true);
        return m[i] = y, m[i + "2"] = g, m;
      }
    }
  }
  function zD(e, t, r) {
    var n = e.get("showAllSymbol"), i = n === "auto";
    if (!(n && !i)) {
      var a = r.getAxesByScale("ordinal")[0];
      if (a && !(i && VD(a, t))) {
        var o = t.mapDimension(a.dim), s = {};
        return P(a.getViewLabels(), function(u) {
          var l = a.scale.getRawOrdinalNumber(u.tickValue);
          s[l] = 1;
        }), function(u) {
          return !s.hasOwnProperty(t.get(o, u));
        };
      }
    }
  }
  function VD(e, t) {
    var r = e.getExtent(), n = Math.abs(r[1] - r[0]) / e.scale.count();
    isNaN(n) && (n = 0);
    for (var i = t.count(), a = Math.max(1, Math.round(i / 5)), o = 0; o < i; o += a) if (Gf.getSymbolSize(t, o)[e.isHorizontal() ? 1 : 0] * 1.5 > n) return false;
    return true;
  }
  function GD(e, t) {
    return isNaN(e) || isNaN(t);
  }
  function HD(e) {
    for (var t = e.length / 2; t > 0 && GD(e[t * 2 - 2], e[t * 2 - 1]); t--) ;
    return t - 1;
  }
  function sp(e, t) {
    return [
      e[t * 2],
      e[t * 2 + 1]
    ];
  }
  function UD(e, t, r) {
    for (var n = e.length / 2, i = r === "x" ? 0 : 1, a, o, s = 0, u = -1, l = 0; l < n; l++) if (o = e[l * 2 + i], !(isNaN(o) || isNaN(e[l * 2 + 1 - i]))) {
      if (l === 0) {
        a = o;
        continue;
      }
      if (a <= t && o >= t || a >= t && o <= t) {
        u = l;
        break;
      }
      s = l, a = o;
    }
    return {
      range: [
        s,
        u
      ],
      t: (t - a) / (o - a)
    };
  }
  function dy(e) {
    if (e.get([
      "endLabel",
      "show"
    ])) return true;
    for (var t = 0; t < Oe.length; t++) if (e.get([
      Oe[t],
      "endLabel",
      "show"
    ])) return true;
    return false;
  }
  function Iu(e, t, r, n) {
    if (kD(t, "cartesian2d")) {
      var i = n.getModel("endLabel"), a = i.get("valueAnimation"), o = n.getData(), s = {
        lastFrameIndex: 0
      }, u = dy(n) ? function(v, p) {
        e._endLabelOnDuring(v, p, o, s, a, i, t);
      } : null, l = t.getBaseAxis().isHorizontal(), f = RD(t, r, n, function() {
        var v = e._endLabel;
        v && r && s.originalX != null && v.attr({
          x: s.originalX,
          y: s.originalY
        });
      }, u);
      if (!n.get("clip", true)) {
        var h = f.shape, c = Math.max(h.width, h.height);
        l ? (h.y -= c, h.height += c * 2) : (h.x -= c, h.width += c * 2);
      }
      return u && u(1, f), f;
    } else return OD(t, r, n);
  }
  function WD(e, t) {
    var r = t.getBaseAxis(), n = r.isHorizontal(), i = r.inverse, a = n ? i ? "right" : "left" : "center", o = n ? "middle" : i ? "top" : "bottom";
    return {
      normal: {
        align: e.get("align") || a,
        verticalAlign: e.get("verticalAlign") || o
      }
    };
  }
  var YD = (function(e) {
    ft(t, e);
    function t() {
      return e !== null && e.apply(this, arguments) || this;
    }
    return t.prototype.init = function() {
      var r = new oe(), n = new DD();
      this.group.add(n.group), this._symbolDraw = n, this._lineGroup = r, this._changePolyState = ut(this._changePolyState, this);
    }, t.prototype.render = function(r, n, i) {
      var a = r.coordinateSystem, o = this.group, s = r.getData(), u = r.getModel("lineStyle"), l = r.getModel("areaStyle"), f = s.getLayout("points") || [], h = a.type === "polar", c = this._coordSys, v = this._symbolDraw, p = this._polyline, y = this._polygon, g = this._lineGroup, d = !n.ssr && r.get("animation"), m = !l.isEmpty(), _ = l.get("origin"), S = vy(a, s, _), T = m && ND(a, s, S), b = r.get("showSymbol"), w = r.get("connectNulls"), D = b && !h && zD(r, s, a), C = this._data;
      C && C.eachItemGraphicEl(function(st, Gt) {
        st.__temp && (o.remove(st), C.setItemGraphicEl(Gt, null));
      }), b || v.remove(), o.add(g);
      var M = h ? false : r.get("step"), x;
      a && a.getArea && r.get("clip", true) && (x = a.getArea(), x.width != null ? (x.x -= 0.1, x.y -= 0.1, x.width += 0.2, x.height += 0.2) : x.r0 && (x.r0 -= 0.5, x.r += 0.5)), this._clipShapeForSymbol = x;
      var I = BD(s, a, i) || s.getVisual("style")[s.getVisual("drawType")];
      if (!(p && c.type === a.type && M === this._step)) b && v.updateData(s, {
        isIgnore: D,
        clipShape: x,
        disableAnimation: true,
        getSymbolPoint: function(st) {
          return [
            f[st * 2],
            f[st * 2 + 1]
          ];
        }
      }), d && this._initSymbolLabelAnimation(s, a, x), M && (T && (T = ir(T, f, a, M, w)), f = ir(f, null, a, M, w)), p = this._newPolyline(f), m ? y = this._newPolygon(f, T) : y && (g.remove(y), y = this._polygon = null), h || this._initOrUpdateEndLabel(r, a, pl(I)), g.setClipPath(Iu(this, a, true, r));
      else {
        m && !y ? y = this._newPolygon(f, T) : y && !m && (g.remove(y), y = this._polygon = null), h || this._initOrUpdateEndLabel(r, a, pl(I));
        var A = g.getClipPath();
        if (A) {
          var E = Iu(this, a, false, r);
          Hn(A, {
            shape: E.shape
          }, r);
        } else g.setClipPath(Iu(this, a, true, r));
        b && v.updateData(s, {
          isIgnore: D,
          clipShape: x,
          disableAnimation: true,
          getSymbolPoint: function(st) {
            return [
              f[st * 2],
              f[st * 2 + 1]
            ];
          }
        }), (!np(this._stackedOnPoints, T) || !np(this._points, f)) && (d ? this._doUpdateAnimation(s, T, a, i, M, _, w) : (M && (T && (T = ir(T, f, a, M, w)), f = ir(f, null, a, M, w)), p.setShape({
          points: f
        }), y && y.setShape({
          points: f,
          stackedOnPoints: T
        })));
      }
      var R = r.getModel("emphasis"), L = R.get("focus"), z = R.get("blurScope"), k = R.get("disabled");
      if (p.useStyle(ht(u.getLineStyle(), {
        fill: "none",
        stroke: I,
        lineJoin: "bevel"
      })), dv(p, r, "lineStyle"), p.style.lineWidth > 0 && r.get([
        "emphasis",
        "lineStyle",
        "width"
      ]) === "bolder") {
        var N = p.getState("emphasis").style;
        N.lineWidth = +p.style.lineWidth + 1;
      }
      mt(p).seriesIndex = r.seriesIndex, ul(p, L, z, k);
      var U = op(r.get("smooth")), J = r.get("smoothMonotone");
      if (p.setShape({
        smooth: U,
        smoothMonotone: J,
        connectNulls: w
      }), y) {
        var $ = s.getCalculationInfo("stackedOnSeries"), rt = 0;
        y.useStyle(ht(l.getAreaStyle(), {
          fill: I,
          opacity: 0.7,
          lineJoin: "bevel",
          decal: s.getVisual("style").decal
        })), $ && (rt = op($.get("smooth"))), y.setShape({
          smooth: U,
          stackedOnSmooth: rt,
          smoothMonotone: J,
          connectNulls: w
        }), dv(y, r, "areaStyle"), mt(y).seriesIndex = r.seriesIndex, ul(y, L, z, k);
      }
      var tt = this._changePolyState;
      s.eachItemGraphicEl(function(st) {
        st && (st.onHoverStateChange = tt);
      }), this._polyline.onHoverStateChange = tt, this._data = s, this._coordSys = a, this._stackedOnPoints = T, this._points = f, this._step = M, this._valueOrigin = _, r.get("triggerLineEvent") && (this.packEventData(r, p), y && this.packEventData(r, y));
    }, t.prototype.packEventData = function(r, n) {
      mt(n).eventData = {
        componentType: "series",
        componentSubType: "line",
        componentIndex: r.componentIndex,
        seriesIndex: r.seriesIndex,
        seriesName: r.name,
        seriesType: "line"
      };
    }, t.prototype.highlight = function(r, n, i, a) {
      var o = r.getData(), s = kn(o, a);
      if (this._changePolyState("emphasis"), !(s instanceof Array) && s != null && s >= 0) {
        var u = o.getLayout("points"), l = o.getItemGraphicEl(s);
        if (!l) {
          var f = u[s * 2], h = u[s * 2 + 1];
          if (isNaN(f) || isNaN(h) || this._clipShapeForSymbol && !this._clipShapeForSymbol.contain(f, h)) return;
          var c = r.get("zlevel") || 0, v = r.get("z") || 0;
          l = new Gf(o, s), l.x = f, l.y = h, l.setZ(c, v);
          var p = l.getSymbolPath().getTextContent();
          p && (p.zlevel = c, p.z = v, p.z2 = this._polyline.z2 + 1), l.__temp = true, o.setItemGraphicEl(s, l), l.stopSymbolAnimation(true), this.group.add(l);
        }
        l.highlight();
      } else Xt.prototype.highlight.call(this, r, n, i, a);
    }, t.prototype.downplay = function(r, n, i, a) {
      var o = r.getData(), s = kn(o, a);
      if (this._changePolyState("normal"), s != null && s >= 0) {
        var u = o.getItemGraphicEl(s);
        u && (u.__temp ? (o.setItemGraphicEl(s, null), this.group.remove(u)) : u.downplay());
      } else Xt.prototype.downplay.call(this, r, n, i, a);
    }, t.prototype._changePolyState = function(r) {
      var n = this._polygon;
      fv(this._polyline, r), n && fv(n, r);
    }, t.prototype._newPolyline = function(r) {
      var n = this._polyline;
      return n && this._lineGroup.remove(n), n = new AD({
        shape: {
          points: r
        },
        segmentIgnoreThreshold: 2,
        z2: 10
      }), this._lineGroup.add(n), this._polyline = n, n;
    }, t.prototype._newPolygon = function(r, n) {
      var i = this._polygon;
      return i && this._lineGroup.remove(i), i = new LD({
        shape: {
          points: r,
          stackedOnPoints: n
        },
        segmentIgnoreThreshold: 2
      }), this._lineGroup.add(i), this._polygon = i, i;
    }, t.prototype._initSymbolLabelAnimation = function(r, n, i) {
      var a, o, s = n.getBaseAxis(), u = s.inverse;
      n.type === "cartesian2d" ? (a = s.isHorizontal(), o = false) : n.type === "polar" && (a = s.dim === "angle", o = true);
      var l = r.hostModel, f = l.get("animationDuration");
      Y(f) && (f = f(null));
      var h = l.get("animationDelay") || 0, c = Y(h) ? h(null) : h;
      r.eachItemGraphicEl(function(v, p) {
        var y = v;
        if (y) {
          var g = [
            v.x,
            v.y
          ], d = void 0, m = void 0, _ = void 0;
          if (i) if (o) {
            var S = i, T = n.pointToCoord(g);
            a ? (d = S.startAngle, m = S.endAngle, _ = -T[1] / 180 * Math.PI) : (d = S.r0, m = S.r, _ = T[0]);
          } else {
            var b = i;
            a ? (d = b.x, m = b.x + b.width, _ = v.x) : (d = b.y + b.height, m = b.y, _ = v.y);
          }
          var w = m === d ? 0 : (_ - d) / (m - d);
          u && (w = 1 - w);
          var D = Y(h) ? h(p) : f * w + c, C = y.getSymbolPath(), M = C.getTextContent();
          y.attr({
            scaleX: 0,
            scaleY: 0
          }), y.animateTo({
            scaleX: 1,
            scaleY: 1
          }, {
            duration: 200,
            setToFinal: true,
            delay: D
          }), M && M.animateFrom({
            style: {
              opacity: 0
            }
          }, {
            duration: 300,
            delay: D
          }), C.disableLabelAnimation = true;
        }
      });
    }, t.prototype._initOrUpdateEndLabel = function(r, n, i) {
      var a = r.getModel("endLabel");
      if (dy(r)) {
        var o = r.getData(), s = this._polyline, u = o.getLayout("points");
        if (!u) {
          s.removeTextContent(), this._endLabel = null;
          return;
        }
        var l = this._endLabel;
        l || (l = this._endLabel = new Re({
          z2: 200
        }), l.ignoreClip = true, s.setTextContent(this._endLabel), s.disableLabelAnimation = true);
        var f = HD(u);
        f >= 0 && (gg(s, hf(r, "endLabel"), {
          inheritColor: i,
          labelFetcher: r,
          labelDataIndex: f,
          defaultText: function(h, c, v) {
            return v != null ? MD(o, v) : hy(o, h);
          },
          enableTextSetter: true
        }, WD(a, n)), s.textConfig.position = null);
      } else this._endLabel && (this._polyline.removeTextContent(), this._endLabel = null);
    }, t.prototype._endLabelOnDuring = function(r, n, i, a, o, s, u) {
      var l = this._endLabel, f = this._polyline;
      if (l) {
        r < 1 && a.originalX == null && (a.originalX = l.x, a.originalY = l.y);
        var h = i.getLayout("points"), c = i.hostModel, v = c.get("connectNulls"), p = s.get("precision"), y = s.get("distance") || 0, g = u.getBaseAxis(), d = g.isHorizontal(), m = g.inverse, _ = n.shape, S = m ? d ? _.x : _.y + _.height : d ? _.x + _.width : _.y, T = (d ? y : 0) * (m ? -1 : 1), b = (d ? 0 : -y) * (m ? -1 : 1), w = d ? "x" : "y", D = UD(h, S, w), C = D.range, M = C[1] - C[0], x = void 0;
        if (M >= 1) {
          if (M > 1 && !v) {
            var I = sp(h, C[0]);
            l.attr({
              x: I[0] + T,
              y: I[1] + b
            }), o && (x = c.getRawValue(C[0]));
          } else {
            var I = f.getPointOn(S, w);
            I && l.attr({
              x: I[0] + T,
              y: I[1] + b
            });
            var A = c.getRawValue(C[0]), E = c.getRawValue(C[1]);
            o && (x = _1(i, p, A, E, D.t));
          }
          a.lastFrameIndex = C[0];
        } else {
          var R = r === 1 || a.lastFrameIndex > 0 ? C[0] : 0, I = sp(h, R);
          o && (x = c.getRawValue(R)), l.attr({
            x: I[0] + T,
            y: I[1] + b
          });
        }
        if (o) {
          var L = yg(l);
          typeof L.setLabelText == "function" && L.setLabelText(x);
        }
      }
    }, t.prototype._doUpdateAnimation = function(r, n, i, a, o, s, u) {
      var l = this._polyline, f = this._polygon, h = r.hostModel, c = ID(this._data, r, this._stackedOnPoints, n, this._coordSys, i, this._valueOrigin), v = c.current, p = c.stackedOnCurrent, y = c.next, g = c.stackedOnNext;
      if (o && (p = ir(c.stackedOnCurrent, c.current, i, o, u), v = ir(c.current, null, i, o, u), g = ir(c.stackedOnNext, c.next, i, o, u), y = ir(c.next, null, i, o, u)), ap(v, y) > 3e3 || f && ap(p, g) > 3e3) {
        l.stopAnimation(), l.setShape({
          points: y
        }), f && (f.stopAnimation(), f.setShape({
          points: y,
          stackedOnPoints: g
        }));
        return;
      }
      l.shape.__points = c.current, l.shape.points = v;
      var d = {
        shape: {
          points: y
        }
      };
      c.current !== v && (d.shape.__points = c.next), l.stopAnimation(), rn(l, d, h), f && (f.setShape({
        points: v,
        stackedOnPoints: p
      }), f.stopAnimation(), rn(f, {
        shape: {
          stackedOnPoints: g
        }
      }, h), l.shape.points !== f.shape.points && (f.shape.points = l.shape.points));
      for (var m = [], _ = c.status, S = 0; S < _.length; S++) {
        var T = _[S].cmd;
        if (T === "=") {
          var b = r.getItemGraphicEl(_[S].idx1);
          b && m.push({
            el: b,
            ptIdx: S
          });
        }
      }
      l.animators && l.animators.length && l.animators[0].during(function() {
        f && f.dirtyShape();
        for (var w = l.shape.__points, D = 0; D < m.length; D++) {
          var C = m[D].el, M = m[D].ptIdx * 2;
          C.x = w[M], C.y = w[M + 1], C.markRedraw();
        }
      });
    }, t.prototype.remove = function(r) {
      var n = this.group, i = this._data;
      this._lineGroup.removeAll(), this._symbolDraw.remove(true), i && i.eachItemGraphicEl(function(a, o) {
        a.__temp && (n.remove(a), i.setItemGraphicEl(o, null));
      }), this._polyline = this._polygon = this._coordSys = this._points = this._stackedOnPoints = this._endLabel = this._data = null;
    }, t.type = "line", t;
  })(Xt);
  function qD(e, t) {
    return {
      seriesType: e,
      plan: i0(),
      reset: function(r) {
        var n = r.getData(), i = r.coordinateSystem;
        if (r.pipelineContext, !!i) {
          var a = F(i.dimensions, function(h) {
            return n.mapDimension(h);
          }).slice(0, 2), o = a.length, s = n.getCalculationInfo("stackResultDimension");
          Bn(n, a[0]) && (a[0] = s), Bn(n, a[1]) && (a[1] = s);
          var u = n.getStore(), l = n.getDimensionIndex(a[0]), f = n.getDimensionIndex(a[1]);
          return o && {
            progress: function(h, c) {
              for (var v = h.end - h.start, p = xn(v * o), y = [], g = [], d = h.start, m = 0; d < h.end; d++) {
                var _ = void 0;
                if (o === 1) {
                  var S = u.get(l, d);
                  _ = i.dataToPoint(S, null, g);
                } else y[0] = u.get(l, d), y[1] = u.get(f, d), _ = i.dataToPoint(y, null, g);
                p[m++] = _[0], p[m++] = _[1];
              }
              c.setLayout("points", p);
            }
          };
        }
      }
    };
  }
  var XD = {
    average: function(e) {
      for (var t = 0, r = 0, n = 0; n < e.length; n++) isNaN(e[n]) || (t += e[n], r++);
      return r === 0 ? NaN : t / r;
    },
    sum: function(e) {
      for (var t = 0, r = 0; r < e.length; r++) t += e[r] || 0;
      return t;
    },
    max: function(e) {
      for (var t = -1 / 0, r = 0; r < e.length; r++) e[r] > t && (t = e[r]);
      return isFinite(t) ? t : NaN;
    },
    min: function(e) {
      for (var t = 1 / 0, r = 0; r < e.length; r++) e[r] < t && (t = e[r]);
      return isFinite(t) ? t : NaN;
    },
    nearest: function(e) {
      return e[0];
    }
  }, $D = function(e) {
    return Math.round(e.length / 2);
  };
  function ZD(e) {
    return {
      seriesType: e,
      reset: function(t, r, n) {
        var i = t.getData(), a = t.get("sampling"), o = t.coordinateSystem, s = i.count();
        if (s > 10 && o.type === "cartesian2d" && a) {
          var u = o.getBaseAxis(), l = o.getOtherAxis(u), f = u.getExtent(), h = n.getDevicePixelRatio(), c = Math.abs(f[1] - f[0]) * (h || 1), v = Math.round(s / c);
          if (isFinite(v) && v > 1) {
            a === "lttb" ? t.setData(i.lttbDownSample(i.mapDimension(l.dim), 1 / v)) : a === "minmax" && t.setData(i.minmaxDownSample(i.mapDimension(l.dim), 1 / v));
            var p = void 0;
            V(a) ? p = XD[a] : Y(a) && (p = a), p && t.setData(i.downSample(i.mapDimension(l.dim), 1 / v, p, $D));
          }
        }
      }
    };
  }
  ux = function(e) {
    e.registerChartView(YD), e.registerSeriesModel(TD), e.registerLayout(qD("line")), e.registerVisual({
      seriesType: "line",
      reset: function(t) {
        var r = t.getData(), n = t.getModel("lineStyle").getLineStyle();
        n && !n.stroke && (n.stroke = r.getVisual("style").fill), r.setVisual("legendLineStyle", n);
      }
    }), e.registerProcessor(e.PRIORITY.PROCESSOR.STATISTIC, ZD("line"));
  };
  var up = (function(e) {
    ft(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.type = t.type, r.layoutMode = "box", r;
    }
    return t.prototype.init = function(r, n, i) {
      this.mergeDefaultAndTheme(r, i), this._initData();
    }, t.prototype.mergeOption = function(r) {
      e.prototype.mergeOption.apply(this, arguments), this._initData();
    }, t.prototype.setCurrentIndex = function(r) {
      r == null && (r = this.option.currentIndex);
      var n = this._data.count();
      this.option.loop ? r = (r % n + n) % n : (r >= n && (r = n - 1), r < 0 && (r = 0)), this.option.currentIndex = r;
    }, t.prototype.getCurrentIndex = function() {
      return this.option.currentIndex;
    }, t.prototype.isIndexMax = function() {
      return this.getCurrentIndex() >= this._data.count() - 1;
    }, t.prototype.setPlayState = function(r) {
      this.option.autoPlay = !!r;
    }, t.prototype.getPlayState = function() {
      return !!this.option.autoPlay;
    }, t.prototype._initData = function() {
      var r = this.option, n = r.data || [], i = r.axisType, a = this._names = [], o;
      i === "category" ? (o = [], P(n, function(l, f) {
        var h = me(Gn(l), ""), c;
        G(l) ? (c = Z(l), c.value = f) : c = f, o.push(c), a.push(h);
      })) : o = n;
      var s = {
        category: "ordinal",
        time: "time",
        value: "number"
      }[i] || "number", u = this._data = new Ff([
        {
          name: "value",
          type: s
        }
      ], this);
      u.initData(o, a);
    }, t.prototype.getData = function() {
      return this._data;
    }, t.prototype.getCategories = function() {
      if (this.get("axisType") === "category") return this._names.slice();
    }, t.type = "timeline", t.defaultOption = {
      z: 4,
      show: true,
      axisType: "time",
      realtime: true,
      left: "20%",
      top: null,
      right: "20%",
      bottom: 0,
      width: null,
      height: 40,
      padding: 5,
      controlPosition: "left",
      autoPlay: false,
      rewind: false,
      loop: true,
      playInterval: 2e3,
      currentIndex: 0,
      itemStyle: {},
      label: {
        color: "#000"
      },
      data: []
    }, t;
  })(nt), gy = (function(e) {
    ft(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.type = t.type, r;
    }
    return t.type = "timeline.slider", t.defaultOption = Nb(up.defaultOption, {
      backgroundColor: "rgba(0,0,0,0)",
      borderColor: "#ccc",
      borderWidth: 0,
      orient: "horizontal",
      inverse: false,
      tooltip: {
        trigger: "item"
      },
      symbol: "circle",
      symbolSize: 12,
      lineStyle: {
        show: true,
        width: 2,
        color: "#DAE1F5"
      },
      label: {
        position: "auto",
        show: true,
        interval: "auto",
        rotate: 0,
        color: "#A4B1D7"
      },
      itemStyle: {
        color: "#A4B1D7",
        borderWidth: 1
      },
      checkpointStyle: {
        symbol: "circle",
        symbolSize: 15,
        color: "#316bf3",
        borderColor: "#fff",
        borderWidth: 2,
        shadowBlur: 2,
        shadowOffsetX: 1,
        shadowOffsetY: 1,
        shadowColor: "rgba(0, 0, 0, 0.3)",
        animation: true,
        animationDuration: 300,
        animationEasing: "quinticInOut"
      },
      controlStyle: {
        show: true,
        showPlayBtn: true,
        showPrevBtn: true,
        showNextBtn: true,
        itemSize: 24,
        itemGap: 12,
        position: "left",
        playIcon: "path://M31.6,53C17.5,53,6,41.5,6,27.4S17.5,1.8,31.6,1.8C45.7,1.8,57.2,13.3,57.2,27.4S45.7,53,31.6,53z M31.6,3.3 C18.4,3.3,7.5,14.1,7.5,27.4c0,13.3,10.8,24.1,24.1,24.1C44.9,51.5,55.7,40.7,55.7,27.4C55.7,14.1,44.9,3.3,31.6,3.3z M24.9,21.3 c0-2.2,1.6-3.1,3.5-2l10.5,6.1c1.899,1.1,1.899,2.9,0,4l-10.5,6.1c-1.9,1.1-3.5,0.2-3.5-2V21.3z",
        stopIcon: "path://M30.9,53.2C16.8,53.2,5.3,41.7,5.3,27.6S16.8,2,30.9,2C45,2,56.4,13.5,56.4,27.6S45,53.2,30.9,53.2z M30.9,3.5C17.6,3.5,6.8,14.4,6.8,27.6c0,13.3,10.8,24.1,24.101,24.1C44.2,51.7,55,40.9,55,27.6C54.9,14.4,44.1,3.5,30.9,3.5z M36.9,35.8c0,0.601-0.4,1-0.9,1h-1.3c-0.5,0-0.9-0.399-0.9-1V19.5c0-0.6,0.4-1,0.9-1H36c0.5,0,0.9,0.4,0.9,1V35.8z M27.8,35.8 c0,0.601-0.4,1-0.9,1h-1.3c-0.5,0-0.9-0.399-0.9-1V19.5c0-0.6,0.4-1,0.9-1H27c0.5,0,0.9,0.4,0.9,1L27.8,35.8L27.8,35.8z",
        nextIcon: "M2,18.5A1.52,1.52,0,0,1,.92,18a1.49,1.49,0,0,1,0-2.12L7.81,9.36,1,3.11A1.5,1.5,0,1,1,3,.89l8,7.34a1.48,1.48,0,0,1,.49,1.09,1.51,1.51,0,0,1-.46,1.1L3,18.08A1.5,1.5,0,0,1,2,18.5Z",
        prevIcon: "M10,.5A1.52,1.52,0,0,1,11.08,1a1.49,1.49,0,0,1,0,2.12L4.19,9.64,11,15.89a1.5,1.5,0,1,1-2,2.22L1,10.77A1.48,1.48,0,0,1,.5,9.68,1.51,1.51,0,0,1,1,8.58L9,.92A1.5,1.5,0,0,1,10,.5Z",
        prevBtnSize: 18,
        nextBtnSize: 18,
        color: "#A4B1D7",
        borderColor: "#A4B1D7",
        borderWidth: 1
      },
      emphasis: {
        label: {
          show: true,
          color: "#6f778d"
        },
        itemStyle: {
          color: "#316BF3"
        },
        controlStyle: {
          color: "#316BF3",
          borderColor: "#316BF3",
          borderWidth: 2
        }
      },
      progress: {
        lineStyle: {
          color: "#316BF3"
        },
        itemStyle: {
          color: "#316BF3"
        },
        label: {
          color: "#6f778d"
        }
      },
      data: []
    }), t;
  })(up);
  ae(gy, Zg.prototype);
  var KD = (function(e) {
    ft(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.type = t.type, r;
    }
    return t.type = "timeline", t;
  })(Xe), jD = (function(e) {
    ft(t, e);
    function t(r, n, i, a) {
      var o = e.call(this, r, n, i) || this;
      return o.type = a || "value", o;
    }
    return t.prototype.getLabelModel = function() {
      return this.model.getModel("label");
    }, t.prototype.isHorizontal = function() {
      return this.model.get("orient") === "horizontal";
    }, t;
  })(fy), Au = Math.PI, lp = Pt(), QD = (function(e) {
    ft(t, e);
    function t() {
      var r = e !== null && e.apply(this, arguments) || this;
      return r.type = t.type, r;
    }
    return t.prototype.init = function(r, n) {
      this.api = n;
    }, t.prototype.render = function(r, n, i) {
      if (this.model = r, this.api = i, this.ecModel = n, this.group.removeAll(), r.get("show", true)) {
        var a = this._layout(r, i), o = this._createGroup("_mainGroup"), s = this._createGroup("_labelGroup"), u = this._axis = this._createAxis(a, r);
        r.formatTooltip = function(l) {
          var f = u.scale.getLabel({
            value: l
          });
          return To("nameValue", {
            noName: true,
            value: f
          });
        }, P([
          "AxisLine",
          "AxisTick",
          "Control",
          "CurrentPointer"
        ], function(l) {
          this["_render" + l](a, o, u, r);
        }, this), this._renderAxisLabel(a, s, u, r), this._position(a, r);
      }
      this._doPlayStop(), this._updateTicksStatus();
    }, t.prototype.remove = function() {
      this._clearTimer(), this.group.removeAll();
    }, t.prototype.dispose = function() {
      this._clearTimer();
    }, t.prototype._layout = function(r, n) {
      var i = r.get([
        "label",
        "position"
      ]), a = r.get("orient"), o = t2(r, n), s;
      i == null || i === "auto" ? s = a === "horizontal" ? o.y + o.height / 2 < n.getHeight() / 2 ? "-" : "+" : o.x + o.width / 2 < n.getWidth() / 2 ? "+" : "-" : V(i) ? s = {
        horizontal: {
          top: "-",
          bottom: "+"
        },
        vertical: {
          left: "-",
          right: "+"
        }
      }[a][i] : s = i;
      var u = {
        horizontal: "center",
        vertical: s >= 0 || s === "+" ? "left" : "right"
      }, l = {
        horizontal: s >= 0 || s === "+" ? "top" : "bottom",
        vertical: "middle"
      }, f = {
        horizontal: 0,
        vertical: Au / 2
      }, h = a === "vertical" ? o.height : o.width, c = r.getModel("controlStyle"), v = c.get("show", true), p = v ? c.get("itemSize") : 0, y = v ? c.get("itemGap") : 0, g = p + y, d = r.get([
        "label",
        "rotate"
      ]) || 0;
      d = d * Au / 180;
      var m, _, S, T = c.get("position", true), b = v && c.get("showPlayBtn", true), w = v && c.get("showPrevBtn", true), D = v && c.get("showNextBtn", true), C = 0, M = h;
      T === "left" || T === "bottom" ? (b && (m = [
        0,
        0
      ], C += g), w && (_ = [
        C,
        0
      ], C += g), D && (S = [
        M - p,
        0
      ], M -= g)) : (b && (m = [
        M - p,
        0
      ], M -= g), w && (_ = [
        0,
        0
      ], C += g), D && (S = [
        M - p,
        0
      ], M -= g));
      var x = [
        C,
        M
      ];
      return r.get("inverse") && x.reverse(), {
        viewRect: o,
        mainLength: h,
        orient: a,
        rotation: f[a],
        labelRotation: d,
        labelPosOpt: s,
        labelAlign: r.get([
          "label",
          "align"
        ]) || u[a],
        labelBaseline: r.get([
          "label",
          "verticalAlign"
        ]) || r.get([
          "label",
          "baseline"
        ]) || l[a],
        playPosition: m,
        prevBtnPosition: _,
        nextBtnPosition: S,
        axisExtent: x,
        controlSize: p,
        controlGap: y
      };
    }, t.prototype._position = function(r, n) {
      var i = this._mainGroup, a = this._labelGroup, o = r.viewRect;
      if (r.orient === "vertical") {
        var s = hr(), u = o.x, l = o.y + o.height;
        zi(s, s, [
          -u,
          -l
        ]), Ul(s, s, -Au / 2), zi(s, s, [
          u,
          l
        ]), o = o.clone(), o.applyTransform(s);
      }
      var f = m(o), h = m(i.getBoundingRect()), c = m(a.getBoundingRect()), v = [
        i.x,
        i.y
      ], p = [
        a.x,
        a.y
      ];
      p[0] = v[0] = f[0][0];
      var y = r.labelPosOpt;
      if (y == null || V(y)) {
        var g = y === "+" ? 0 : 1;
        _(v, h, f, 1, g), _(p, c, f, 1, 1 - g);
      } else {
        var g = y >= 0 ? 0 : 1;
        _(v, h, f, 1, g), p[1] = v[1] + y;
      }
      i.setPosition(v), a.setPosition(p), i.rotation = a.rotation = r.rotation, d(i), d(a);
      function d(S) {
        S.originX = f[0][0] - S.x, S.originY = f[1][0] - S.y;
      }
      function m(S) {
        return [
          [
            S.x,
            S.x + S.width
          ],
          [
            S.y,
            S.y + S.height
          ]
        ];
      }
      function _(S, T, b, w, D) {
        S[w] += b[w][D] - T[w][D];
      }
    }, t.prototype._createAxis = function(r, n) {
      var i = n.getData(), a = n.get("axisType"), o = JD(n, a);
      o.getTicks = function() {
        return i.mapArray([
          "value"
        ], function(l) {
          return {
            value: l
          };
        });
      };
      var s = i.getDataExtent("value");
      o.setExtent(s[0], s[1]), o.calcNiceTicks();
      var u = new jD("value", o, r.axisExtent, a);
      return u.model = n, u;
    }, t.prototype._createGroup = function(r) {
      var n = this[r] = new oe();
      return this.group.add(n), n;
    }, t.prototype._renderAxisLine = function(r, n, i, a) {
      var o = i.getExtent();
      if (a.get([
        "lineStyle",
        "show"
      ])) {
        var s = new en({
          shape: {
            x1: o[0],
            y1: 0,
            x2: o[1],
            y2: 0
          },
          style: O({
            lineCap: "round"
          }, a.getModel("lineStyle").getLineStyle()),
          silent: true,
          z2: 1
        });
        n.add(s);
        var u = this._progressLine = new en({
          shape: {
            x1: o[0],
            x2: this._currentPointer ? this._currentPointer.x : o[0],
            y1: 0,
            y2: 0
          },
          style: ht({
            lineCap: "round",
            lineWidth: s.style.lineWidth
          }, a.getModel([
            "progress",
            "lineStyle"
          ]).getLineStyle()),
          silent: true,
          z2: 1
        });
        n.add(u);
      }
    }, t.prototype._renderAxisTick = function(r, n, i, a) {
      var o = this, s = a.getData(), u = i.scale.getTicks();
      this._tickSymbols = [], P(u, function(l) {
        var f = i.dataToCoord(l.value), h = s.getItemModel(l.value), c = h.getModel("itemStyle"), v = h.getModel([
          "emphasis",
          "itemStyle"
        ]), p = h.getModel([
          "progress",
          "itemStyle"
        ]), y = {
          x: f,
          y: 0,
          onclick: ut(o._changeTimeline, o, l.value)
        }, g = fp(h, c, n, y);
        g.ensureState("emphasis").style = v.getItemStyle(), g.ensureState("progress").style = p.getItemStyle(), Ei(g);
        var d = mt(g);
        h.get("tooltip") ? (d.dataIndex = l.value, d.dataModel = a) : d.dataIndex = d.dataModel = null, o._tickSymbols.push(g);
      });
    }, t.prototype._renderAxisLabel = function(r, n, i, a) {
      var o = this, s = i.getLabelModel();
      if (s.get("show")) {
        var u = a.getData(), l = i.getViewLabels();
        this._tickLabels = [], P(l, function(f) {
          var h = f.tickValue, c = u.getItemModel(h), v = c.getModel("label"), p = c.getModel([
            "emphasis",
            "label"
          ]), y = c.getModel([
            "progress",
            "label"
          ]), g = i.dataToCoord(f.tickValue), d = new Re({
            x: g,
            y: 0,
            rotation: r.labelRotation - r.rotation,
            onclick: ut(o._changeTimeline, o, h),
            silent: false,
            style: En(v, {
              text: f.formattedLabel,
              align: r.labelAlign,
              verticalAlign: r.labelBaseline
            })
          });
          d.ensureState("emphasis").style = En(p), d.ensureState("progress").style = En(y), n.add(d), Ei(d), lp(d).dataIndex = h, o._tickLabels.push(d);
        });
      }
    }, t.prototype._renderControl = function(r, n, i, a) {
      var o = r.controlSize, s = r.rotation, u = a.getModel("controlStyle").getItemStyle(), l = a.getModel([
        "emphasis",
        "controlStyle"
      ]).getItemStyle(), f = a.getPlayState(), h = a.get("inverse", true);
      c(r.nextBtnPosition, "next", ut(this._changeTimeline, this, h ? "-" : "+")), c(r.prevBtnPosition, "prev", ut(this._changeTimeline, this, h ? "+" : "-")), c(r.playPosition, f ? "stop" : "play", ut(this._handlePlayClick, this, !f), true);
      function c(v, p, y, g) {
        if (v) {
          var d = gr(W(a.get([
            "controlStyle",
            p + "BtnSize"
          ]), o), o), m = [
            0,
            -d / 2,
            d,
            d
          ], _ = e2(a, p + "Icon", m, {
            x: v[0],
            y: v[1],
            originX: o / 2,
            originY: 0,
            rotation: g ? -s : 0,
            rectHover: true,
            style: u,
            onclick: y
          });
          _.ensureState("emphasis").style = l, n.add(_), Ei(_);
        }
      }
    }, t.prototype._renderCurrentPointer = function(r, n, i, a) {
      var o = a.getData(), s = a.getCurrentIndex(), u = o.getItemModel(s).getModel("checkpointStyle"), l = this, f = {
        onCreate: function(h) {
          h.draggable = true, h.drift = ut(l._handlePointerDrag, l), h.ondragend = ut(l._handlePointerDragend, l), hp(h, l._progressLine, s, i, a, true);
        },
        onUpdate: function(h) {
          hp(h, l._progressLine, s, i, a);
        }
      };
      this._currentPointer = fp(u, u, this._mainGroup, {}, this._currentPointer, f);
    }, t.prototype._handlePlayClick = function(r) {
      this._clearTimer(), this.api.dispatchAction({
        type: "timelinePlayChange",
        playState: r,
        from: this.uid
      });
    }, t.prototype._handlePointerDrag = function(r, n, i) {
      this._clearTimer(), this._pointerChangeTimeline([
        i.offsetX,
        i.offsetY
      ]);
    }, t.prototype._handlePointerDragend = function(r) {
      this._pointerChangeTimeline([
        r.offsetX,
        r.offsetY
      ], true);
    }, t.prototype._pointerChangeTimeline = function(r, n) {
      var i = this._toAxisCoord(r)[0], a = this._axis, o = _d(a.getExtent().slice());
      i > o[1] && (i = o[1]), i < o[0] && (i = o[0]), this._currentPointer.x = i, this._currentPointer.markRedraw();
      var s = this._progressLine;
      s && (s.shape.x2 = i, s.dirty());
      var u = this._findNearestTick(i), l = this.model;
      (n || u !== l.getCurrentIndex() && l.get("realtime")) && this._changeTimeline(u);
    }, t.prototype._doPlayStop = function() {
      var r = this;
      this._clearTimer(), this.model.getPlayState() && (this._timer = setTimeout(function() {
        var n = r.model;
        r._changeTimeline(n.getCurrentIndex() + (n.get("rewind", true) ? -1 : 1));
      }, this.model.get("playInterval")));
    }, t.prototype._toAxisCoord = function(r) {
      var n = this._mainGroup.getLocalTransform();
      return uf(r, n, true);
    }, t.prototype._findNearestTick = function(r) {
      var n = this.model.getData(), i = 1 / 0, a, o = this._axis;
      return n.each([
        "value"
      ], function(s, u) {
        var l = o.dataToCoord(s), f = Math.abs(l - r);
        f < i && (i = f, a = u);
      }), a;
    }, t.prototype._clearTimer = function() {
      this._timer && (clearTimeout(this._timer), this._timer = null);
    }, t.prototype._changeTimeline = function(r) {
      var n = this.model.getCurrentIndex();
      r === "+" ? r = n + 1 : r === "-" && (r = n - 1), this.api.dispatchAction({
        type: "timelineChange",
        currentIndex: r,
        from: this.uid
      });
    }, t.prototype._updateTicksStatus = function() {
      var r = this.model.getCurrentIndex(), n = this._tickSymbols, i = this._tickLabels;
      if (n) for (var a = 0; a < n.length; a++) n && n[a] && n[a].toggleState("progress", a < r);
      if (i) for (var a = 0; a < i.length; a++) i && i[a] && i[a].toggleState("progress", lp(i[a]).dataIndex <= r);
    }, t.type = "timeline.slider", t;
  })(KD);
  function JD(e, t) {
    if (t = t || e.get("type"), t) switch (t) {
      case "category":
        return new gs({
          ordinalMeta: e.getCategories(),
          extent: [
            1 / 0,
            -1 / 0
          ]
        });
      case "time":
        return new Bf({
          locale: e.ecModel.getLocaleModel(),
          useUTC: e.ecModel.get("useUTC")
        });
      default:
        return new Wn();
    }
  }
  function t2(e, t) {
    return Sf(e.getBoxLayoutParams(), {
      width: t.getWidth(),
      height: t.getHeight()
    }, e.get("padding"));
  }
  function e2(e, t, r, n) {
    var i = n.style, a = lf(e.get([
      "controlStyle",
      t
    ]), n || {}, new at(r[0], r[1], r[2], r[3]));
    return i && a.setStyle(i), a;
  }
  function fp(e, t, r, n, i, a) {
    var o = t.get("color");
    if (i) i.setColor(o), r.add(i), a && a.onUpdate(i);
    else {
      var s = e.get("symbol");
      i = Fn(s, -1, -1, 2, 2, o), i.setStyle("strokeNoScale", true), r.add(i), a && a.onCreate(i);
    }
    var u = t.getItemStyle([
      "color"
    ]);
    i.setStyle(u), n = ct({
      rectHover: true,
      z2: 100
    }, n, true);
    var l = c0(e.get("symbolSize"));
    n.scaleX = l[0] / 2, n.scaleY = l[1] / 2;
    var f = p0(e.get("symbolOffset"), l);
    f && (n.x = (n.x || 0) + f[0], n.y = (n.y || 0) + f[1]);
    var h = e.get("symbolRotate");
    return n.rotation = (h || 0) * Math.PI / 180 || 0, i.attr(n), i.updateTransform(), i;
  }
  function hp(e, t, r, n, i, a) {
    if (!e.dragging) {
      var o = i.getModel("checkpointStyle"), s = n.dataToCoord(i.getData().get("value", r));
      if (a || !o.get("animation", true)) e.attr({
        x: s,
        y: 0
      }), t && t.attr({
        shape: {
          x2: s
        }
      });
      else {
        var u = {
          duration: o.get("animationDuration", true),
          easing: o.get("animationEasing", true)
        };
        e.stopAnimation(null, true), e.animateTo({
          x: s,
          y: 0
        }, u), t && t.animateTo({
          shape: {
            x2: s
          }
        }, u);
      }
    }
  }
  function r2(e) {
    e.registerAction({
      type: "timelineChange",
      event: "timelineChanged",
      update: "prepareAndUpdate"
    }, function(t, r, n) {
      var i = r.getComponent("timeline");
      return i && t.currentIndex != null && (i.setCurrentIndex(t.currentIndex), !i.get("loop", true) && i.isIndexMax() && i.getPlayState() && (i.setPlayState(false), n.dispatchAction({
        type: "timelinePlayChange",
        playState: false,
        from: t.from
      }))), r.resetOption("timeline", {
        replaceMerge: i.get("replaceMerge", true)
      }), ht({
        currentIndex: i.option.currentIndex
      }, t);
    }), e.registerAction({
      type: "timelinePlayChange",
      event: "timelinePlayChanged",
      update: "update"
    }, function(t, r) {
      var n = r.getComponent("timeline");
      n && t.playState != null && n.setPlayState(t.playState);
    });
  }
  function n2(e) {
    var t = e && e.timeline;
    B(t) || (t = t ? [
      t
    ] : []), P(t, function(r) {
      r && i2(r);
    });
  }
  function i2(e) {
    var t = e.type, r = {
      number: "value",
      time: "time"
    };
    if (r[t] && (e.axisType = r[t], delete e.type), vp(e), Hr(e, "controlPosition")) {
      var n = e.controlStyle || (e.controlStyle = {});
      Hr(n, "position") || (n.position = e.controlPosition), n.position === "none" && !Hr(n, "show") && (n.show = false, delete n.position), delete e.controlPosition;
    }
    P(e.data || [], function(i) {
      G(i) && !B(i) && (!Hr(i, "value") && Hr(i, "name") && (i.value = i.name), vp(i));
    });
  }
  function vp(e) {
    var t = e.itemStyle || (e.itemStyle = {}), r = t.emphasis || (t.emphasis = {}), n = e.label || e.label || {}, i = n.normal || (n.normal = {}), a = {
      normal: 1,
      emphasis: 1
    };
    P(n, function(o, s) {
      !a[s] && !Hr(i, s) && (i[s] = o);
    }), r.label && !Hr(n, "emphasis") && (n.emphasis = r.label, delete r.label);
  }
  function Hr(e, t) {
    return e.hasOwnProperty(t);
  }
  lx = function(e) {
    e.registerComponentModel(gy), e.registerComponentView(QD), e.registerSubTypeDefaulter("timeline", function() {
      return "slider";
    }), r2(e), e.registerPreprocessor(n2);
  };
  var Eu = Math.sin, Lu = Math.cos, yy = Math.PI, Vr = Math.PI * 2, a2 = 180 / yy, my = (function() {
    function e() {
    }
    return e.prototype.reset = function(t) {
      this._start = true, this._d = [], this._str = "", this._p = Math.pow(10, t || 4);
    }, e.prototype.moveTo = function(t, r) {
      this._add("M", t, r);
    }, e.prototype.lineTo = function(t, r) {
      this._add("L", t, r);
    }, e.prototype.bezierCurveTo = function(t, r, n, i, a, o) {
      this._add("C", t, r, n, i, a, o);
    }, e.prototype.quadraticCurveTo = function(t, r, n, i) {
      this._add("Q", t, r, n, i);
    }, e.prototype.arc = function(t, r, n, i, a, o) {
      this.ellipse(t, r, n, n, 0, i, a, o);
    }, e.prototype.ellipse = function(t, r, n, i, a, o, s, u) {
      var l = s - o, f = !u, h = Math.abs(l), c = fr(h - Vr) || (f ? l >= Vr : -l >= Vr), v = l > 0 ? l % Vr : l % Vr + Vr, p = false;
      c ? p = true : fr(h) ? p = false : p = v >= yy == !!f;
      var y = t + n * Lu(o), g = r + i * Eu(o);
      this._start && this._add("M", y, g);
      var d = Math.round(a * a2);
      if (c) {
        var m = 1 / this._p, _ = (f ? 1 : -1) * (Vr - m);
        this._add("A", n, i, d, 1, +f, t + n * Lu(o + _), r + i * Eu(o + _)), m > 0.01 && this._add("A", n, i, d, 0, +f, y, g);
      } else {
        var S = t + n * Lu(s), T = r + i * Eu(s);
        this._add("A", n, i, d, +p, +f, S, T);
      }
    }, e.prototype.rect = function(t, r, n, i) {
      this._add("M", t, r), this._add("l", n, 0), this._add("l", 0, i), this._add("l", -n, 0), this._add("Z");
    }, e.prototype.closePath = function() {
      this._d.length > 0 && this._add("Z");
    }, e.prototype._add = function(t, r, n, i, a, o, s, u, l) {
      for (var f = [], h = this._p, c = 1; c < arguments.length; c++) {
        var v = arguments[c];
        if (isNaN(v)) {
          this._invalid = true;
          return;
        }
        f.push(Math.round(v * h) / h);
      }
      this._d.push(t + f.join(" ")), this._start = t === "Z";
    }, e.prototype.generateStr = function() {
      this._str = this._invalid ? "" : this._d.join(""), this._d = [];
    }, e.prototype.getStr = function() {
      return this._str;
    }, e;
  })(), Hf = "none", o2 = Math.round;
  function s2(e) {
    var t = e.fill;
    return t != null && t !== Hf;
  }
  function u2(e) {
    var t = e.stroke;
    return t != null && t !== Hf;
  }
  var Pl = [
    "lineCap",
    "miterLimit",
    "lineJoin"
  ], l2 = F(Pl, function(e) {
    return "stroke-" + e.toLowerCase();
  });
  function f2(e, t, r, n) {
    var i = t.opacity == null ? 1 : t.opacity;
    if (r instanceof Se) {
      e("opacity", i);
      return;
    }
    if (s2(t)) {
      var a = Hi(t.fill);
      e("fill", a.color);
      var o = t.fillOpacity != null ? t.fillOpacity * a.opacity * i : a.opacity * i;
      o < 1 && e("fill-opacity", o);
    } else e("fill", Hf);
    if (u2(t)) {
      var s = Hi(t.stroke);
      e("stroke", s.color);
      var u = t.strokeNoScale ? r.getLineScale() : 1, l = u ? (t.lineWidth || 0) / u : 0, f = t.strokeOpacity != null ? t.strokeOpacity * s.opacity * i : s.opacity * i, h = t.strokeFirst;
      if (l !== 1 && e("stroke-width", l), h && e("paint-order", h ? "stroke" : "fill"), f < 1 && e("stroke-opacity", f), t.lineDash) {
        var c = xf(r), v = c[0], p = c[1];
        v && (p = o2(p || 0), e("stroke-dasharray", v.join(",")), (p || n) && e("stroke-dashoffset", p));
      }
      for (var y = 0; y < Pl.length; y++) {
        var g = Pl[y];
        if (t[g] !== co[g]) {
          var d = t[g] || co[g];
          d && e(l2[y], d);
        }
      }
    }
  }
  var _y = "http://www.w3.org/2000/svg", Sy = "http://www.w3.org/1999/xlink", h2 = "http://www.w3.org/2000/xmlns/", v2 = "http://www.w3.org/XML/1998/namespace", cp = "ecmeta_";
  function by(e) {
    return document.createElementNS(_y, e);
  }
  function _t(e, t, r, n, i) {
    return {
      tag: e,
      attrs: r || {},
      children: n,
      text: i,
      key: t
    };
  }
  function c2(e, t) {
    var r = [];
    if (t) for (var n in t) {
      var i = t[n], a = n;
      i !== false && (i !== true && i != null && (a += '="' + i + '"'), r.push(a));
    }
    return "<" + e + " " + r.join(" ") + ">";
  }
  function p2(e) {
    return "</" + e + ">";
  }
  function Uf(e, t) {
    t = t || {};
    var r = t.newline ? `
` : "";
    function n(i) {
      var a = i.children, o = i.tag, s = i.attrs, u = i.text;
      return c2(o, s) + (o !== "style" ? Et(u) : u || "") + (a ? "" + r + F(a, function(l) {
        return n(l);
      }).join(r) + r : "") + p2(o);
    }
    return n(e);
  }
  function d2(e, t, r) {
    r = r || {};
    var n = r.newline ? `
` : "", i = " {" + n, a = n + "}", o = F(K(e), function(u) {
      return u + i + F(K(e[u]), function(l) {
        return l + ":" + e[u][l] + ";";
      }).join(n) + a;
    }).join(n), s = F(K(t), function(u) {
      return "@keyframes " + u + i + F(K(t[u]), function(l) {
        return l + i + F(K(t[u][l]), function(f) {
          var h = t[u][l][f];
          return f === "d" && (h = 'path("' + h + '")'), f + ":" + h + ";";
        }).join(n) + a;
      }).join(n) + a;
    }).join(n);
    return !o && !s ? "" : [
      "<![CDATA[",
      o,
      s,
      "]]>"
    ].join(n);
  }
  function Il(e) {
    return {
      zrId: e,
      shadowCache: {},
      patternCache: {},
      gradientCache: {},
      clipPathCache: {},
      defs: {},
      cssNodes: {},
      cssAnims: {},
      cssStyleCache: {},
      cssAnimIdx: 0,
      shadowIdx: 0,
      gradientIdx: 0,
      patternIdx: 0,
      clipPathIdx: 0
    };
  }
  function pp(e, t, r, n) {
    return _t("svg", "root", {
      width: e,
      height: t,
      xmlns: _y,
      "xmlns:xlink": Sy,
      version: "1.1",
      baseProfile: "full",
      viewBox: n ? "0 0 " + e + " " + t : false
    }, r);
  }
  var g2 = 0;
  function wy() {
    return g2++;
  }
  var dp = {
    cubicIn: "0.32,0,0.67,0",
    cubicOut: "0.33,1,0.68,1",
    cubicInOut: "0.65,0,0.35,1",
    quadraticIn: "0.11,0,0.5,0",
    quadraticOut: "0.5,1,0.89,1",
    quadraticInOut: "0.45,0,0.55,1",
    quarticIn: "0.5,0,0.75,0",
    quarticOut: "0.25,1,0.5,1",
    quarticInOut: "0.76,0,0.24,1",
    quinticIn: "0.64,0,0.78,0",
    quinticOut: "0.22,1,0.36,1",
    quinticInOut: "0.83,0,0.17,1",
    sinusoidalIn: "0.12,0,0.39,0",
    sinusoidalOut: "0.61,1,0.88,1",
    sinusoidalInOut: "0.37,0,0.63,1",
    exponentialIn: "0.7,0,0.84,0",
    exponentialOut: "0.16,1,0.3,1",
    exponentialInOut: "0.87,0,0.13,1",
    circularIn: "0.55,0,1,0.45",
    circularOut: "0,0.55,0.45,1",
    circularInOut: "0.85,0,0.15,1"
  }, Gr = "transform-origin";
  function y2(e, t, r) {
    var n = O({}, e.shape);
    O(n, t), e.buildPath(r, n);
    var i = new my();
    return i.reset(od(e)), r.rebuildPath(i, 1), i.generateStr(), i.getStr();
  }
  function m2(e, t) {
    var r = t.originX, n = t.originY;
    (r || n) && (e[Gr] = r + "px " + n + "px");
  }
  var _2 = {
    fill: "fill",
    opacity: "opacity",
    lineWidth: "stroke-width",
    lineDashOffset: "stroke-dashoffset"
  };
  function Ty(e, t) {
    var r = t.zrId + "-ani-" + t.cssAnimIdx++;
    return t.cssAnims[r] = e, r;
  }
  function S2(e, t, r) {
    var n = e.shape.paths, i = {}, a, o;
    if (P(n, function(u) {
      var l = Il(r.zrId);
      l.animation = true, ys(u, {}, l, true);
      var f = l.cssAnims, h = l.cssNodes, c = K(f), v = c.length;
      if (v) {
        o = c[v - 1];
        var p = f[o];
        for (var y in p) {
          var g = p[y];
          i[y] = i[y] || {
            d: ""
          }, i[y].d += g.d || "";
        }
        for (var d in h) {
          var m = h[d].animation;
          m.indexOf(o) >= 0 && (a = m);
        }
      }
    }), !!a) {
      t.d = false;
      var s = Ty(i, r);
      return a.replace(o, s);
    }
  }
  function gp(e) {
    return V(e) ? dp[e] ? "cubic-bezier(" + dp[e] + ")" : Wl(e) ? e : "" : "";
  }
  function ys(e, t, r, n) {
    var i = e.animators, a = i.length, o = [];
    if (e instanceof rf) {
      var s = S2(e, t, r);
      if (s) o.push(s);
      else if (!a) return;
    } else if (!a) return;
    for (var u = {}, l = 0; l < a; l++) {
      var f = i[l], h = [
        f.getMaxTime() / 1e3 + "s"
      ], c = gp(f.getClip().easing), v = f.getDelay();
      c ? h.push(c) : h.push("linear"), v && h.push(v / 1e3 + "s"), f.getLoop() && h.push("infinite");
      var p = h.join(" ");
      u[p] = u[p] || [
        p,
        []
      ], u[p][1].push(f);
    }
    function y(m) {
      var _ = m[1], S = _.length, T = {}, b = {}, w = {}, D = "animation-timing-function";
      function C(le, St, dt) {
        for (var H = le.getTracks(), X = le.getMaxTime(), fe = 0; fe < H.length; fe++) {
          var gt = H[fe];
          if (gt.needsAnimate()) {
            var qn = gt.keyframes, _r = gt.propName;
            if (dt && (_r = dt(_r)), _r) for (var ms = 0; ms < qn.length; ms++) {
              var sa = qn[ms], ua = Math.round(sa.time / X * 100) + "%", $f = gp(sa.easing), Zf = sa.rawValue;
              (V(Zf) || lt(Zf)) && (St[ua] = St[ua] || {}, St[ua][_r] = sa.rawValue, $f && (St[ua][D] = $f));
            }
          }
        }
      }
      for (var M = 0; M < S; M++) {
        var x = _[M], I = x.targetName;
        I ? I === "shape" && C(x, b) : !n && C(x, T);
      }
      for (var A in T) {
        var E = {};
        hd(E, e), O(E, T[A]);
        var R = sd(E), L = T[A][D];
        w[A] = R ? {
          transform: R
        } : {}, m2(w[A], E), L && (w[A][D] = L);
      }
      var z, k = true;
      for (var A in b) {
        w[A] = w[A] || {};
        var N = !z, L = b[A][D];
        N && (z = new yr());
        var U = z.len();
        z.reset(), w[A].d = y2(e, b[A], z);
        var J = z.len();
        if (!N && U !== J) {
          k = false;
          break;
        }
        L && (w[A][D] = L);
      }
      if (!k) for (var A in w) delete w[A].d;
      if (!n) for (var M = 0; M < S; M++) {
        var x = _[M], I = x.targetName;
        I === "style" && C(x, w, function(H) {
          return _2[H];
        });
      }
      for (var $ = K(w), rt = true, tt, M = 1; M < $.length; M++) {
        var st = $[M - 1], Gt = $[M];
        if (w[st][Gr] !== w[Gt][Gr]) {
          rt = false;
          break;
        }
        tt = w[st][Gr];
      }
      if (rt && tt) {
        for (var A in w) w[A][Gr] && delete w[A][Gr];
        t[Gr] = tt;
      }
      if (yt($, function(le) {
        return K(w[le]).length > 0;
      }).length) {
        var Fe = Ty(w, r);
        return Fe + " " + m[0] + " both";
      }
    }
    for (var g in u) {
      var s = y(u[g]);
      s && o.push(s);
    }
    if (o.length) {
      var d = r.zrId + "-cls-" + wy();
      r.cssNodes["." + d] = {
        animation: o.join(",")
      }, t.class = d;
    }
  }
  function b2(e, t, r) {
    if (!e.ignore) if (e.isSilent()) {
      var n = {
        "pointer-events": "none"
      };
      yp(n, t, r);
    } else {
      var i = e.states.emphasis && e.states.emphasis.style ? e.states.emphasis.style : {}, a = i.fill;
      if (!a) {
        var o = e.style && e.style.fill, s = e.states.select && e.states.select.style && e.states.select.style.fill, u = e.currentStates.indexOf("select") >= 0 && s || o;
        u && (a = ho(u));
      }
      var l = i.lineWidth;
      if (l) {
        var f = !i.strokeNoScale && e.transform ? e.transform[0] : 1;
        l = l / f;
      }
      var n = {
        cursor: "pointer"
      };
      a && (n.fill = a), i.stroke && (n.stroke = i.stroke), l && (n["stroke-width"] = l), yp(n, t, r);
    }
  }
  function yp(e, t, r, n) {
    var i = JSON.stringify(e), a = r.cssStyleCache[i];
    a || (a = r.zrId + "-cls-" + wy(), r.cssStyleCache[i] = a, r.cssNodes["." + a + ":hover"] = e), t.class = t.class ? t.class + " " + a : a;
  }
  var Ji = Math.round;
  function My(e) {
    return e && V(e.src);
  }
  function Cy(e) {
    return e && Y(e.toDataURL);
  }
  function Wf(e, t, r, n) {
    f2(function(i, a) {
      var o = i === "fill" || i === "stroke";
      o && ad(a) ? xy(t, e, i, n) : o && ql(a) ? Py(r, e, i, n) : e[i] = a, o && n.ssr && a === "none" && (e["pointer-events"] = "visible");
    }, t, r, false), P2(r, e, n);
  }
  function Yf(e, t) {
    var r = gd(t);
    r && (r.each(function(n, i) {
      n != null && (e[(cp + i).toLowerCase()] = n + "");
    }), t.isSilent() && (e[cp + "silent"] = "true"));
  }
  function mp(e) {
    return fr(e[0] - 1) && fr(e[1]) && fr(e[2]) && fr(e[3] - 1);
  }
  function w2(e) {
    return fr(e[4]) && fr(e[5]);
  }
  function qf(e, t, r) {
    if (t && !(w2(t) && mp(t))) {
      var n = 1e4;
      e.transform = mp(t) ? "translate(" + Ji(t[4] * n) / n + " " + Ji(t[5] * n) / n + ")" : g_(t);
    }
  }
  function _p(e, t, r) {
    for (var n = e.points, i = [], a = 0; a < n.length; a++) i.push(Ji(n[a][0] * r) / r), i.push(Ji(n[a][1] * r) / r);
    t.points = i.join(" ");
  }
  function Sp(e) {
    return !e.smooth;
  }
  function T2(e) {
    var t = F(e, function(r) {
      return typeof r == "string" ? [
        r,
        r
      ] : r;
    });
    return function(r, n, i) {
      for (var a = 0; a < t.length; a++) {
        var o = t[a], s = r[o[0]];
        s != null && (n[o[1]] = Ji(s * i) / i);
      }
    };
  }
  var M2 = {
    circle: [
      T2([
        "cx",
        "cy",
        "r"
      ])
    ],
    polyline: [
      _p,
      Sp
    ],
    polygon: [
      _p,
      Sp
    ]
  };
  function C2(e) {
    for (var t = e.animators, r = 0; r < t.length; r++) if (t[r].targetName === "shape") return true;
    return false;
  }
  function Dy(e, t) {
    var r = e.style, n = e.shape, i = M2[e.type], a = {}, o = t.animation, s = "path", u = e.style.strokePercent, l = t.compress && od(e) || 4;
    if (i && !t.willUpdate && !(i[1] && !i[1](n)) && !(o && C2(e)) && !(u < 1)) {
      s = e.type;
      var f = Math.pow(10, l);
      i[0](n, a, f);
    } else {
      var h = !e.path || e.shapeChanged();
      e.path || e.createPathProxy();
      var c = e.path;
      h && (c.beginPath(), e.buildPath(c, e.shape), e.pathUpdated());
      var v = c.getVersion(), p = e, y = p.__svgPathBuilder;
      (p.__svgPathVersion !== v || !y || u !== p.__svgPathStrokePercent) && (y || (y = p.__svgPathBuilder = new my()), y.reset(l), c.rebuildPath(y, u), y.generateStr(), p.__svgPathVersion = v, p.__svgPathStrokePercent = u), a.d = y.getStr();
    }
    return qf(a, e.transform), Wf(a, r, e, t), Yf(a, e), t.animation && ys(e, a, t), t.emphasis && b2(e, a, t), _t(s, e.id + "", a);
  }
  function D2(e, t) {
    var r = e.style, n = r.image;
    if (n && !V(n) && (My(n) ? n = n.src : Cy(n) && (n = n.toDataURL())), !!n) {
      var i = r.x || 0, a = r.y || 0, o = r.width, s = r.height, u = {
        href: n,
        width: o,
        height: s
      };
      return i && (u.x = i), a && (u.y = a), qf(u, e.transform), Wf(u, r, e, t), Yf(u, e), t.animation && ys(e, u, t), _t("image", e.id + "", u);
    }
  }
  function x2(e, t) {
    var r = e.style, n = r.text;
    if (n != null && (n += ""), !(!n || isNaN(r.x) || isNaN(r.y))) {
      var i = r.font || pr, a = r.x || 0, o = m_(r.y || 0, zo(i), r.textBaseline), s = y_[r.textAlign] || r.textAlign, u = {
        "dominant-baseline": "central",
        "text-anchor": s
      };
      if (Hd(r)) {
        var l = "", f = r.fontStyle, h = Gd(r.fontSize);
        if (!parseFloat(h)) return;
        var c = r.fontFamily || Ap, v = r.fontWeight;
        l += "font-size:" + h + ";font-family:" + c + ";", f && f !== "normal" && (l += "font-style:" + f + ";"), v && v !== "normal" && (l += "font-weight:" + v + ";"), u.style = l;
      } else u.style = "font: " + i;
      return n.match(/\s/) && (u["xml:space"] = "preserve"), a && (u.x = a), o && (u.y = o), qf(u, e.transform), Wf(u, r, e, t), Yf(u, e), t.animation && ys(e, u, t), _t("text", e.id + "", u, void 0, n);
    }
  }
  function bp(e, t) {
    if (e instanceof et) return Dy(e, t);
    if (e instanceof Se) return D2(e, t);
    if (e instanceof Xi) return x2(e, t);
  }
  function P2(e, t, r) {
    var n = e.style;
    if (__(n)) {
      var i = S_(e), a = r.shadowCache, o = a[i];
      if (!o) {
        var s = e.getGlobalScale(), u = s[0], l = s[1];
        if (!u || !l) return;
        var f = n.shadowOffsetX || 0, h = n.shadowOffsetY || 0, c = n.shadowBlur, v = Hi(n.shadowColor), p = v.opacity, y = v.color, g = c / 2 / u, d = c / 2 / l, m = g + " " + d;
        o = r.zrId + "-s" + r.shadowIdx++, r.defs[o] = _t("filter", o, {
          id: o,
          x: "-100%",
          y: "-100%",
          width: "300%",
          height: "300%"
        }, [
          _t("feDropShadow", "", {
            dx: f / u,
            dy: h / l,
            stdDeviation: m,
            "flood-color": y,
            "flood-opacity": p
          })
        ]), a[i] = o;
      }
      t.filter = Bo(o);
    }
  }
  function xy(e, t, r, n) {
    var i = e[r], a, o = {
      gradientUnits: i.global ? "userSpaceOnUse" : "objectBoundingBox"
    };
    if (nd(i)) a = "linearGradient", o.x1 = i.x, o.y1 = i.y, o.x2 = i.x2, o.y2 = i.y2;
    else if (id(i)) a = "radialGradient", o.cx = W(i.x, 0.5), o.cy = W(i.y, 0.5), o.r = W(i.r, 0.5);
    else return;
    for (var s = i.colorStops, u = [], l = 0, f = s.length; l < f; ++l) {
      var h = Yu(s[l].offset) * 100 + "%", c = s[l].color, v = Hi(c), p = v.color, y = v.opacity, g = {
        offset: h
      };
      g["stop-color"] = p, y < 1 && (g["stop-opacity"] = y), u.push(_t("stop", l + "", g));
    }
    var d = _t(a, "", o, u), m = Uf(d), _ = n.gradientCache, S = _[m];
    S || (S = n.zrId + "-g" + n.gradientIdx++, _[m] = S, o.id = S, n.defs[S] = _t(a, S, o, u)), t[r] = Bo(S);
  }
  function Py(e, t, r, n) {
    var i = e.style[r], a = e.getBoundingRect(), o = {}, s = i.repeat, u = s === "no-repeat", l = s === "repeat-x", f = s === "repeat-y", h;
    if (rd(i)) {
      var c = i.imageWidth, v = i.imageHeight, p = void 0, y = i.image;
      if (V(y) ? p = y : My(y) ? p = y.src : Cy(y) && (p = y.toDataURL()), typeof Image > "u") {
        var g = "Image width/height must been given explictly in svg-ssr renderer.";
        $t(c, g), $t(v, g);
      } else if (c == null || v == null) {
        var d = function(M, x) {
          if (M) {
            var I = M.elm, A = c || x.width, E = v || x.height;
            M.tag === "pattern" && (l ? (E = 1, A /= a.width) : f && (A = 1, E /= a.height)), M.attrs.width = A, M.attrs.height = E, I && (I.setAttribute("width", A), I.setAttribute("height", E));
          }
        }, m = jl(p, null, e, function(M) {
          u || d(b, M), d(h, M);
        });
        m && m.width && m.height && (c = c || m.width, v = v || m.height);
      }
      h = _t("image", "img", {
        href: p,
        width: c,
        height: v
      }), o.width = c, o.height = v;
    } else i.svgElement && (h = Z(i.svgElement), o.width = i.svgWidth, o.height = i.svgHeight);
    if (h) {
      var _, S;
      u ? _ = S = 1 : l ? (S = 1, _ = o.width / a.width) : f ? (_ = 1, S = o.height / a.height) : o.patternUnits = "userSpaceOnUse", _ != null && !isNaN(_) && (o.width = _), S != null && !isNaN(S) && (o.height = S);
      var T = sd(i);
      T && (o.patternTransform = T);
      var b = _t("pattern", "", o, [
        h
      ]), w = Uf(b), D = n.patternCache, C = D[w];
      C || (C = n.zrId + "-p" + n.patternIdx++, D[w] = C, o.id = C, b = n.defs[C] = _t("pattern", C, o, [
        h
      ])), t[r] = Bo(C);
    }
  }
  function I2(e, t, r) {
    var n = r.clipPathCache, i = r.defs, a = n[e.id];
    if (!a) {
      a = r.zrId + "-c" + r.clipPathIdx++;
      var o = {
        id: a
      };
      n[e.id] = a, i[a] = _t("clipPath", a, o, [
        Dy(e, r)
      ]);
    }
    t["clip-path"] = Bo(a);
  }
  function wp(e) {
    return document.createTextNode(e);
  }
  function Ur(e, t, r) {
    e.insertBefore(t, r);
  }
  function Tp(e, t) {
    e.removeChild(t);
  }
  function Mp(e, t) {
    e.appendChild(t);
  }
  function Iy(e) {
    return e.parentNode;
  }
  function Ay(e) {
    return e.nextSibling;
  }
  function Ru(e, t) {
    e.textContent = t;
  }
  var Cp = 58, A2 = 120, E2 = _t("", "");
  function Al(e) {
    return e === void 0;
  }
  function De(e) {
    return e !== void 0;
  }
  function L2(e, t, r) {
    for (var n = {}, i = t; i <= r; ++i) {
      var a = e[i].key;
      a !== void 0 && (n[a] = i);
    }
    return n;
  }
  function Mi(e, t) {
    var r = e.key === t.key, n = e.tag === t.tag;
    return n && r;
  }
  function ta(e) {
    var t, r = e.children, n = e.tag;
    if (De(n)) {
      var i = e.elm = by(n);
      if (Xf(E2, e), B(r)) for (t = 0; t < r.length; ++t) {
        var a = r[t];
        a != null && Mp(i, ta(a));
      }
      else De(e.text) && !G(e.text) && Mp(i, wp(e.text));
    } else e.elm = wp(e.text);
    return e.elm;
  }
  function Ey(e, t, r, n, i) {
    for (; n <= i; ++n) {
      var a = r[n];
      a != null && Ur(e, ta(a), t);
    }
  }
  function Lo(e, t, r, n) {
    for (; r <= n; ++r) {
      var i = t[r];
      if (i != null) if (De(i.tag)) {
        var a = Iy(i.elm);
        Tp(a, i.elm);
      } else Tp(e, i.elm);
    }
  }
  function Xf(e, t) {
    var r, n = t.elm, i = e && e.attrs || {}, a = t.attrs || {};
    if (i !== a) {
      for (r in a) {
        var o = a[r], s = i[r];
        s !== o && (o === true ? n.setAttribute(r, "") : o === false ? n.removeAttribute(r) : r === "style" ? n.style.cssText = o : r.charCodeAt(0) !== A2 ? n.setAttribute(r, o) : r === "xmlns:xlink" || r === "xmlns" ? n.setAttributeNS(h2, r, o) : r.charCodeAt(3) === Cp ? n.setAttributeNS(v2, r, o) : r.charCodeAt(5) === Cp ? n.setAttributeNS(Sy, r, o) : n.setAttribute(r, o));
      }
      for (r in i) r in a || n.removeAttribute(r);
    }
  }
  function R2(e, t, r) {
    for (var n = 0, i = 0, a = t.length - 1, o = t[0], s = t[a], u = r.length - 1, l = r[0], f = r[u], h, c, v, p; n <= a && i <= u; ) o == null ? o = t[++n] : s == null ? s = t[--a] : l == null ? l = r[++i] : f == null ? f = r[--u] : Mi(o, l) ? (Mn(o, l), o = t[++n], l = r[++i]) : Mi(s, f) ? (Mn(s, f), s = t[--a], f = r[--u]) : Mi(o, f) ? (Mn(o, f), Ur(e, o.elm, Ay(s.elm)), o = t[++n], f = r[--u]) : Mi(s, l) ? (Mn(s, l), Ur(e, s.elm, o.elm), s = t[--a], l = r[++i]) : (Al(h) && (h = L2(t, n, a)), c = h[l.key], Al(c) ? Ur(e, ta(l), o.elm) : (v = t[c], v.tag !== l.tag ? Ur(e, ta(l), o.elm) : (Mn(v, l), t[c] = void 0, Ur(e, v.elm, o.elm))), l = r[++i]);
    (n <= a || i <= u) && (n > a ? (p = r[u + 1] == null ? null : r[u + 1].elm, Ey(e, p, r, i, u)) : Lo(e, t, n, a));
  }
  function Mn(e, t) {
    var r = t.elm = e.elm, n = e.children, i = t.children;
    e !== t && (Xf(e, t), Al(t.text) ? De(n) && De(i) ? n !== i && R2(r, n, i) : De(i) ? (De(e.text) && Ru(r, ""), Ey(r, null, i, 0, i.length - 1)) : De(n) ? Lo(r, n, 0, n.length - 1) : De(e.text) && Ru(r, "") : e.text !== t.text && (De(n) && Lo(r, n, 0, n.length - 1), Ru(r, t.text)));
  }
  function O2(e, t) {
    if (Mi(e, t)) Mn(e, t);
    else {
      var r = e.elm, n = Iy(r);
      ta(t), n !== null && (Ur(n, t.elm, Ay(r)), Lo(n, [
        e
      ], 0, 0));
    }
    return t;
  }
  var k2 = 0, N2 = (function() {
    function e(t, r, n) {
      if (this.type = "svg", this.refreshHover = Dp(), this.configLayer = Dp(), this.storage = r, this._opts = n = O({}, n), this.root = t, this._id = "zr" + k2++, this._oldVNode = pp(n.width, n.height), t && !n.ssr) {
        var i = this._viewport = document.createElement("div");
        i.style.cssText = "position:relative;overflow:hidden";
        var a = this._svgDom = this._oldVNode.elm = by("svg");
        Xf(null, this._oldVNode), i.appendChild(a), t.appendChild(i);
      }
      this.resize(n.width, n.height);
    }
    return e.prototype.getType = function() {
      return this.type;
    }, e.prototype.getViewportRoot = function() {
      return this._viewport;
    }, e.prototype.getViewportRootOffset = function() {
      var t = this.getViewportRoot();
      if (t) return {
        offsetLeft: t.offsetLeft || 0,
        offsetTop: t.offsetTop || 0
      };
    }, e.prototype.getSvgDom = function() {
      return this._svgDom;
    }, e.prototype.refresh = function() {
      if (this.root) {
        var t = this.renderToVNode({
          willUpdate: true
        });
        t.attrs.style = "position:absolute;left:0;top:0;user-select:none", O2(this._oldVNode, t), this._oldVNode = t;
      }
    }, e.prototype.renderOneToVNode = function(t) {
      return bp(t, Il(this._id));
    }, e.prototype.renderToVNode = function(t) {
      t = t || {};
      var r = this.storage.getDisplayList(true), n = this._width, i = this._height, a = Il(this._id);
      a.animation = t.animation, a.willUpdate = t.willUpdate, a.compress = t.compress, a.emphasis = t.emphasis, a.ssr = this._opts.ssr;
      var o = [], s = this._bgVNode = F2(n, i, this._backgroundColor, a);
      s && o.push(s);
      var u = t.compress ? null : this._mainVNode = _t("g", "main", {}, []);
      this._paintList(r, a, u ? u.children : o), u && o.push(u);
      var l = F(K(a.defs), function(c) {
        return a.defs[c];
      });
      if (l.length && o.push(_t("defs", "defs", {}, l)), t.animation) {
        var f = d2(a.cssNodes, a.cssAnims, {
          newline: true
        });
        if (f) {
          var h = _t("style", "stl", {}, [], f);
          o.push(h);
        }
      }
      return pp(n, i, o, t.useViewBox);
    }, e.prototype.renderToString = function(t) {
      return t = t || {}, Uf(this.renderToVNode({
        animation: W(t.cssAnimation, true),
        emphasis: W(t.cssEmphasis, true),
        willUpdate: false,
        compress: true,
        useViewBox: W(t.useViewBox, true)
      }), {
        newline: true
      });
    }, e.prototype.setBackgroundColor = function(t) {
      this._backgroundColor = t;
    }, e.prototype.getSvgRoot = function() {
      return this._mainVNode && this._mainVNode.elm;
    }, e.prototype._paintList = function(t, r, n) {
      for (var i = t.length, a = [], o = 0, s, u, l = 0, f = 0; f < i; f++) {
        var h = t[f];
        if (!h.invisible) {
          var c = h.__clipPaths, v = c && c.length || 0, p = u && u.length || 0, y = void 0;
          for (y = Math.max(v - 1, p - 1); y >= 0 && !(c && u && c[y] === u[y]); y--) ;
          for (var g = p - 1; g > y; g--) o--, s = a[o - 1];
          for (var d = y + 1; d < v; d++) {
            var m = {};
            I2(c[d], m, r);
            var _ = _t("g", "clip-g-" + l++, m, []);
            (s ? s.children : n).push(_), a[o++] = _, s = _;
          }
          u = c;
          var S = bp(h, r);
          S && (s ? s.children : n).push(S);
        }
      }
    }, e.prototype.resize = function(t, r) {
      var n = this._opts, i = this.root, a = this._viewport;
      if (t != null && (n.width = t), r != null && (n.height = r), i && a && (a.style.display = "none", t = gc(i, 0, n), r = gc(i, 1, n), a.style.display = ""), this._width !== t || this._height !== r) {
        if (this._width = t, this._height = r, a) {
          var o = a.style;
          o.width = t + "px", o.height = r + "px";
        }
        if (ql(this._backgroundColor)) this.refresh();
        else {
          var s = this._svgDom;
          s && (s.setAttribute("width", t), s.setAttribute("height", r));
          var u = this._bgVNode && this._bgVNode.elm;
          u && (u.setAttribute("width", t), u.setAttribute("height", r));
        }
      }
    }, e.prototype.getWidth = function() {
      return this._width;
    }, e.prototype.getHeight = function() {
      return this._height;
    }, e.prototype.dispose = function() {
      this.root && (this.root.innerHTML = ""), this._svgDom = this._viewport = this.storage = this._oldVNode = this._bgVNode = this._mainVNode = null;
    }, e.prototype.clear = function() {
      this._svgDom && (this._svgDom.innerHTML = null), this._oldVNode = null;
    }, e.prototype.toDataURL = function(t) {
      var r = this.renderToString(), n = "data:image/svg+xml;";
      return t ? (r = w_(r), r && n + "base64," + r) : n + "charset=UTF-8," + encodeURIComponent(r);
    }, e;
  })();
  function Dp(e) {
    return function() {
    };
  }
  function F2(e, t, r, n) {
    var i;
    if (r && r !== "none") if (i = _t("rect", "bg", {
      width: e,
      height: t,
      x: "0",
      y: "0"
    }), ad(r)) xy({
      fill: r
    }, i.attrs, "fill", n);
    else if (ql(r)) Py({
      style: {
        fill: r
      },
      dirty: zt,
      getBoundingRect: function() {
        return {
          width: e,
          height: t
        };
      }
    }, i.attrs, "fill", n);
    else {
      var a = Hi(r), o = a.color, s = a.opacity;
      i.attrs.fill = o, s < 1 && (i.attrs["fill-opacity"] = s);
    }
    return i;
  }
  fx = function(e) {
    e.registerPainter("svg", N2);
  };
});
export {
  Sc as $,
  tn as A,
  Lg as B,
  nt as C,
  Nb as D,
  wo as E,
  lf as F,
  oe as G,
  ut as H,
  Z as I,
  W as J,
  rn as K,
  ty as L,
  wt as M,
  ot as N,
  G as O,
  dm as P,
  at as Q,
  ne as R,
  xe as S,
  $e as T,
  Oh as U,
  dr as V,
  Oo as W,
  dc as X,
  fm as Y,
  Re as Z,
  ft as _,
  __tla,
  V as a,
  bd as a$,
  Tl as a0,
  y0 as a1,
  Gu as a2,
  j as a3,
  Nl as a4,
  gc as a5,
  V2 as a6,
  sx as a7,
  lx as a8,
  ux as a9,
  No as aA,
  Ul as aB,
  In as aC,
  n1 as aD,
  Pt as aE,
  _b as aF,
  on as aG,
  zt as aH,
  VM as aI,
  jo as aJ,
  Qo as aK,
  yb as aL,
  vg as aM,
  cg as aN,
  Y2 as aO,
  zm as aP,
  tx as aQ,
  ex as aR,
  HC as aS,
  zi as aT,
  uf as aU,
  Ig as aV,
  vd as aW,
  hr as aX,
  kn as aY,
  U2 as aZ,
  rl as a_,
  sb as aa,
  Yr as ab,
  ae as ac,
  qC as ad,
  bo as ae,
  Hc as af,
  Fo as ag,
  Ye as ah,
  fy as ai,
  vm as aj,
  Wn as ak,
  BC as al,
  nx as am,
  bt as an,
  ax as ao,
  GC as ap,
  YC as aq,
  K as ar,
  rx as as,
  VC as at,
  ix as au,
  en as av,
  pb as aw,
  p0 as ax,
  r1 as ay,
  WC as az,
  Id as b,
  ox as b0,
  FC as b1,
  _d as b2,
  $2 as b3,
  rs as b4,
  po as b5,
  go as b6,
  Db as b7,
  io as b8,
  Fm as b9,
  Us as ba,
  Z2 as bb,
  H2 as bc,
  Xb as bd,
  pe as be,
  G2 as bf,
  pl as bg,
  Q2 as bh,
  Wt as bi,
  W2 as bj,
  ka as bk,
  To as bl,
  Ie as bm,
  J2 as bn,
  K2 as bo,
  j2 as bp,
  Et as bq,
  ns as br,
  Ag as bs,
  Ut as bt,
  Ad as bu,
  Ho as bv,
  q2 as bw,
  fx as bx,
  q as c,
  F as d,
  P as e,
  lt as f,
  yt as g,
  vt as h,
  B as i,
  Sf as j,
  ht as k,
  mt as l,
  ct as m,
  O as n,
  gg as o,
  Yt as p,
  Ei as q,
  Y as r,
  an as s,
  En as t,
  wb as u,
  X2 as v,
  Xe as w,
  Vn as x,
  Ac as y,
  Fn as z
};
