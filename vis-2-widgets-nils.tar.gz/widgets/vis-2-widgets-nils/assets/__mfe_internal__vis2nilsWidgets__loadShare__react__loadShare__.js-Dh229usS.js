let J, E, c, T, v, R, H, k, M, I, h, U, Y, w, q, W, B, x, p, P, L, d, $;
let __tla = (async () => {
  function i(e, n) {
    for (var r = 0; r < n.length; r++) {
      const _ = n[r];
      if (typeof _ != "string" && !Array.isArray(_)) {
        for (const t in _) if (t !== "default" && !(t in e)) {
          const a = Object.getOwnPropertyDescriptor(_, t);
          a && Object.defineProperty(e, t, a.get ? a : {
            enumerable: true,
            get: () => _[t]
          });
        }
      }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
      value: "Module"
    }));
  }
  const f = "__mf_init____mf__virtual/__mfe_internal__vis2nilsWidgets__mf_v__runtimeInit__mf_v__.js__";
  let o = globalThis[f];
  if (!o) {
    let e, n;
    const r = new Promise((_, t) => {
      e = _, n = t;
    });
    o = globalThis[f] = {
      initPromise: r,
      initResolve: e,
      initReject: n
    }, typeof window > "u" && e({
      loadRemote: function() {
        return Promise.resolve(void 0);
      },
      loadShare: function() {
        return Promise.resolve(void 0);
      }
    });
  }
  let m, u, s, l, S, g, b, y, C, O, D, V, j, N, F, A, z, G, K;
  m = o.initPromise;
  u = m.then((e) => e.loadShare("react", {
    customShareInfo: {
      shareConfig: {
        singleton: true,
        strictVersion: false,
        requiredVersion: "*"
      }
    }
  }));
  s = await u.then((e) => typeof e == "function" ? e() : e);
  l = s;
  c = s.__esModule ? s.default : s.default ?? s;
  ({ Children: d, Component: E, Fragment: R, Profiler: S, PureComponent: p, StrictMode: g, Suspense: b, __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: y, act: C, cloneElement: P, createContext: I, createElement: v, createFactory: O, createRef: T, forwardRef: h, isValidElement: x, lazy: D, memo: L, startTransition: V, unstable_act: j, useCallback: w, useContext: M, useDebugValue: N, useDeferredValue: F, useEffect: k, useId: A, useImperativeHandle: U, useInsertionEffect: z, useLayoutEffect: W, useMemo: q, useReducer: B, useRef: H, useState: Y, useSyncExternalStore: G, useTransition: K, version: $ } = s);
  J = i({
    __proto__: null,
    Children: d,
    Component: E,
    Fragment: R,
    Profiler: S,
    PureComponent: p,
    StrictMode: g,
    Suspense: b,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: y,
    act: C,
    cloneElement: P,
    createContext: I,
    createElement: v,
    createFactory: O,
    createRef: T,
    default: c,
    forwardRef: h,
    isValidElement: x,
    lazy: D,
    memo: L,
    startTransition: V,
    unstable_act: j,
    useCallback: w,
    useContext: M,
    useDebugValue: N,
    useDeferredValue: F,
    useEffect: k,
    useId: A,
    useImperativeHandle: U,
    useInsertionEffect: z,
    useLayoutEffect: W,
    useMemo: q,
    useReducer: B,
    useRef: H,
    useState: Y,
    useSyncExternalStore: G,
    useTransition: K,
    version: $
  }, [
    l
  ]);
})();
export {
  J as R,
  E as _,
  __tla,
  c as a,
  T as b,
  v as c,
  R as d,
  H as e,
  k as f,
  M as g,
  I as h,
  h as i,
  U as j,
  Y as k,
  w as l,
  q as m,
  W as n,
  B as o,
  x as p,
  p as q,
  P as r,
  L as s,
  d as t,
  $ as u
};
