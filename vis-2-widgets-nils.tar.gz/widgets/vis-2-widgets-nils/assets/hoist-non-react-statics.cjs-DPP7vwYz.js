function I(e2) {
  return e2 && e2.__esModule && Object.prototype.hasOwnProperty.call(e2, "default") ? e2.default : e2;
}
var A = { exports: {} }, e = {};
/** @license React v16.13.1
* react-is.production.min.js
*
* Copyright (c) Facebook, Inc. and its affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var t = typeof Symbol == "function" && Symbol.for, P = t ? Symbol.for("react.element") : 60103, T = t ? Symbol.for("react.portal") : 60106, u = t ? Symbol.for("react.fragment") : 60107, s = t ? Symbol.for("react.strict_mode") : 60108, a = t ? Symbol.for("react.profiler") : 60114, p = t ? Symbol.for("react.provider") : 60109, y = t ? Symbol.for("react.context") : 60110, g = t ? Symbol.for("react.async_mode") : 60111, i = t ? Symbol.for("react.concurrent_mode") : 60111, l = t ? Symbol.for("react.forward_ref") : 60112, m = t ? Symbol.for("react.suspense") : 60113, D = t ? Symbol.for("react.suspense_list") : 60120, S = t ? Symbol.for("react.memo") : 60115, d = t ? Symbol.for("react.lazy") : 60116, C = t ? Symbol.for("react.block") : 60121, z = t ? Symbol.for("react.fundamental") : 60117, L = t ? Symbol.for("react.responder") : 60118, W = t ? Symbol.for("react.scope") : 60119;
function o(r) {
  if (typeof r == "object" && r !== null) {
    var n = r.$$typeof;
    switch (n) {
      case P:
        switch (r = r.type, r) {
          case g:
          case i:
          case u:
          case a:
          case s:
          case m:
            return r;
          default:
            switch (r = r && r.$$typeof, r) {
              case y:
              case l:
              case d:
              case S:
              case p:
                return r;
              default:
                return n;
            }
        }
      case T:
        return n;
    }
  }
}
function E(r) {
  return o(r) === i;
}
e.AsyncMode = g;
e.ConcurrentMode = i;
e.ContextConsumer = y;
e.ContextProvider = p;
e.Element = P;
e.ForwardRef = l;
e.Fragment = u;
e.Lazy = d;
e.Memo = S;
e.Portal = T;
e.Profiler = a;
e.StrictMode = s;
e.Suspense = m;
e.isAsyncMode = function(r) {
  return E(r) || o(r) === g;
};
e.isConcurrentMode = E;
e.isContextConsumer = function(r) {
  return o(r) === y;
};
e.isContextProvider = function(r) {
  return o(r) === p;
};
e.isElement = function(r) {
  return typeof r == "object" && r !== null && r.$$typeof === P;
};
e.isForwardRef = function(r) {
  return o(r) === l;
};
e.isFragment = function(r) {
  return o(r) === u;
};
e.isLazy = function(r) {
  return o(r) === d;
};
e.isMemo = function(r) {
  return o(r) === S;
};
e.isPortal = function(r) {
  return o(r) === T;
};
e.isProfiler = function(r) {
  return o(r) === a;
};
e.isStrictMode = function(r) {
  return o(r) === s;
};
e.isSuspense = function(r) {
  return o(r) === m;
};
e.isValidElementType = function(r) {
  return typeof r == "string" || typeof r == "function" || r === u || r === i || r === a || r === s || r === m || r === D || typeof r == "object" && r !== null && (r.$$typeof === d || r.$$typeof === S || r.$$typeof === p || r.$$typeof === y || r.$$typeof === l || r.$$typeof === z || r.$$typeof === L || r.$$typeof === W || r.$$typeof === C);
};
e.typeOf = o;
A.exports = e;
var q = A.exports, O = q, K = { childContextTypes: true, contextType: true, contextTypes: true, defaultProps: true, displayName: true, getDefaultProps: true, getDerivedStateFromError: true, getDerivedStateFromProps: true, mixins: true, propTypes: true, type: true }, V = { name: true, length: true, prototype: true, caller: true, callee: true, arguments: true, arity: true }, Y = { $$typeof: true, render: true, defaultProps: true, displayName: true, propTypes: true }, F = { $$typeof: true, compare: true, defaultProps: true, displayName: true, propTypes: true, type: true }, x = {};
x[O.ForwardRef] = Y;
x[O.Memo] = F;
function j(r) {
  return O.isMemo(r) ? F : x[r.$$typeof] || K;
}
var B = Object.defineProperty, G = Object.getOwnPropertyNames, M = Object.getOwnPropertySymbols, H = Object.getOwnPropertyDescriptor, J = Object.getPrototypeOf, h = Object.prototype;
function N(r, n, b) {
  if (typeof n != "string") {
    if (h) {
      var $ = J(n);
      $ && $ !== h && N(r, $, b);
    }
    var f = G(n);
    M && (f = f.concat(M(n)));
    for (var w = j(r), _ = j(n), v = 0; v < f.length; ++v) {
      var c = f[v];
      if (!V[c] && !(b && b[c]) && !(_ && _[c]) && !(w && w[c])) {
        var R = H(n, c);
        try {
          B(r, c, R);
        } catch {
        }
      }
    }
  }
  return r;
}
var Q = N;
const Z = I(Q);
export {
  Z as h
};
