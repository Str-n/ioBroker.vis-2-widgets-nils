import { r as e, t, __tla as __tla_0 } from "./assets/dist-BgxWXJ5y.js";
import { t as n } from "./assets/vite-preload-helper-HclGiUj8.js";
let k, O;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  var _a, _b;
  ({
    ...e.global
  });
  var r = e.share;
  e.utils, typeof __VUE_HMR_RUNTIME__ > `u` && (globalThis.__VUE_HMR_RUNTIME__ = {
    createRecord() {
    },
    rerender() {
    },
    reload() {
    }
  });
  var i = `__mf_init__virtual:mf:__mfe_internal__vis2nilsForkWidgets__mf_owner__1__mf_v__runtimeInit__mf_v__.js__`, a = globalThis[i];
  if (!a) {
    let e2, t2, n2 = new Promise((n3, r2) => {
      e2 = n3, t2 = r2;
    });
    a = globalThis[i] = {
      initPromise: n2,
      initResolve: e2,
      initReject: t2
    };
  }
  var o = a.initResolve, s = `__mf_module_cache__`;
  globalThis[s] || (globalThis[s] = {
    share: {},
    remote: {}
  }), (_a = globalThis[s]).share || (_a.share = {}), (_b = globalThis[s]).remote || (_b.remote = {});
  var c = globalThis[s];
  for (let e2 of Object.keys(c.share)) if (e2.startsWith(`default:`)) {
    let t2 = e2.slice(8);
    c.share[t2] === void 0 && (c.share[t2] = c.share[e2]);
  } else if (!e2.includes(`:`)) {
    let t2 = `default:` + e2;
    c.share[t2] === void 0 && (c.share[t2] = c.share[e2]);
  }
  var l = {}, u = Array.isArray(`default`) ? `default` : [
    `default`
  ], d = `default`, f = `vis2nilsForkWidgets`, p = [
    [
      `react`,
      `moment`
    ],
    [
      `react/jsx-dev-runtime`,
      `react/jsx-runtime`,
      `react-dom`,
      `@emotion/react`,
      `@mui/private-theming`
    ],
    [
      `react-dom/client`,
      `@mui/system`
    ],
    [
      `@mui/material`
    ],
    [
      `@iobroker/gui-components`
    ]
  ], m, h, g;
  async function _(e2) {
    for (let t2 = 0; ; t2++) try {
      return await e2();
    } catch (e3) {
      throw e3;
    }
  }
  var v = /* @__PURE__ */ Symbol(`mf.originalSharedProvider`), y = {
    emit: (e2) => e2
  }, b = (e2, t2) => {
    if (t2 !== `version-first`) return e2;
    let n2 = {};
    for (let [t3, r2] of Object.entries(e2)) n2[t3] = Object.assign({}, r2, {
      [v]: r2
    });
    return n2;
  }, x = (e2, t2) => {
    if (!t2) return;
    let n2 = Object.entries(e2 || {}), r2 = n2.find(([, e3]) => e3 === t2);
    if (r2) return {
      version: r2[0],
      provider: t2,
      registered: true
    };
    if (typeof t2.version == `string` && t2.version) return {
      version: t2.version,
      provider: t2,
      registered: false
    };
    let i2 = n2.filter(([, e3]) => e3 === t2 || !!(t2.from && (e3 == null ? void 0 : e3.from) === t2.from));
    if (i2.length === 1) return {
      version: i2[0][0],
      provider: t2,
      registered: false
    };
  }, S = (e2, t2, n2, i2) => {
    var _a2;
    if (!e2 || !n2) return;
    let a2 = Array.isArray(n2.scope) ? n2.scope : [
      n2.scope || `default`
    ], o2 = b(e2, i2), s2 = {};
    for (let e3 of a2) s2[e3 || `default`] = {
      [t2]: o2
    };
    let c2 = (_a2 = r.getRegisteredShare(s2, t2, {
      ...n2,
      scope: a2,
      strategy: i2
    }, y)) == null ? void 0 : _a2.shared;
    return (c2 == null ? void 0 : c2[v]) || c2;
  }, C = (e2, t2, n2, r2) => {
    var _a2;
    let i2 = (e3) => w(e3, n2), a2 = Object.fromEntries(Object.entries(e2 || {}).filter(([, e3]) => {
      var _a3;
      return !i2(e3) && ((_a3 = e3 == null ? void 0 : e3.shareConfig) == null ? void 0 : _a3.import) !== false;
    }));
    (n2 == null ? void 0 : n2.version) && ((_a2 = n2.shareConfig) == null ? void 0 : _a2.import) !== false && (a2[n2.version] || (a2[n2.version] = n2));
    let o2 = S(a2, t2, n2, r2);
    return i2(o2) ? void 0 : o2;
  }, w = (e2, t2) => e2 === t2 || !!((t2 == null ? void 0 : t2.from) && (e2 == null ? void 0 : e2.from) === t2.from), T = (e2, t2, n2, r2, i2, a2, o2, s2, c2) => {
    var _a2, _b2, _c;
    if (c2 !== `version-first` || !s2) return;
    let l2 = (_b2 = (_a2 = t2 == null ? void 0 : t2.options) == null ? void 0 : _a2.shared) == null ? void 0 : _b2[i2], u2 = Array.isArray(l2) ? l2.find((e3) => (e3 == null ? void 0 : e3.version) === a2) : void 0, d2 = ((s2 == null ? void 0 : s2.from) === ((_c = t2 == null ? void 0 : t2.options) == null ? void 0 : _c.name) ? s2 : void 0) || (w(u2, s2) ? u2 : t2 ? void 0 : s2);
    if (d2) return e2.some((e3) => {
      var _a3, _b3;
      return e3 !== t2 && ((_a3 = e3 == null ? void 0 : e3.options) == null ? void 0 : _a3.name) === (o2 == null ? void 0 : o2.from) && ((_b3 = e3 == null ? void 0 : e3.shareScopeMap) == null ? void 0 : _b3[r2]) === n2;
    }) ? d2 : void 0;
  }, ee = (e2, t2, n2, r2, i2, a2, o2, s2, c2) => {
    let l2 = a2.registered ? T(e2, t2, n2, r2, i2, a2.version, a2.provider, s2, c2) : void 0, u2 = l2 || o2;
    if (u2 && (!a2.registered || w(u2, s2))) return {
      provider: u2,
      scopeRootProvider: l2
    };
  };
  async function E() {
    return m || (m = _(() => n(() => import("./assets/_virtual_mf-localSharedImportMap___mfe_internal__vis2nilsForkWidgets__mf_owner__1-DJF1wT9s.js").then(async (m2) => {
      await m2.__tla;
      return m2;
    }), [], import.meta.url)).catch((e2) => {
      throw m = void 0, e2;
    })), m;
  }
  async function D() {
    return h || (h = _(() => n(() => import("./assets/virtualExposes-5Z3xpAMt.js").then(async (m2) => {
      await m2.__tla;
      return m2;
    }), [], import.meta.url)).then((e2) => e2.default ?? e2).catch((e2) => {
      throw h = void 0, e2;
    })), h;
  }
  O = async function(e2 = {}, n2 = []) {
    var _a2, _b2, _c, _d, _e2;
    let r2 = (e3, t2, n3, r3) => {
      let i3 = (Array.isArray(r3) ? r3[0] : r3) || `default`, a3 = t2 || !n3 ? e3 : e3 + `@` + n3, o2 = {
        canonical: i3 + `:` + a3
      };
      return i3 === "default" && (o2.aliases = [
        a3
      ]), o2;
    }, i2 = (e3, t2) => {
      let n3 = e3[t2.canonical];
      if (n3 !== void 0) return n3;
      let r3 = t2.aliases || [];
      for (let n4 of r3) {
        if (!Object.prototype.hasOwnProperty.call(e3, n4)) continue;
        let r4 = e3[n4];
        if (r4 !== void 0) return e3[t2.canonical] = r4, r4;
      }
    }, a2 = /* @__PURE__ */ Symbol.for(`module-federation.shared-cache-listeners`), s2 = /* @__PURE__ */ Symbol.for(`module-federation.shared-cache-owners`), m2 = (e3) => {
      let t2 = e3[s2];
      return t2 === void 0 && (t2 = /* @__PURE__ */ Object.create(null), Object.defineProperty(e3, s2, {
        value: t2,
        enumerable: false,
        configurable: false,
        writable: false
      })), t2;
    }, h2 = (e3, t2) => {
      var _a3;
      return (_a3 = e3[s2]) == null ? void 0 : _a3[t2.canonical];
    }, v2 = (e3, t2, n3, r3) => {
      var _a3;
      e3[t2.canonical] = n3;
      let i3 = t2.aliases || [];
      for (let t3 of i3) Object.defineProperty(e3, t3, {
        value: n3,
        enumerable: true,
        configurable: true,
        writable: true
      });
      let o2 = e3[s2];
      r3 === void 0 ? o2 && delete o2[t2.canonical] : m2(e3)[t2.canonical] = r3;
      let c2 = (_a3 = e3[a2]) == null ? void 0 : _a3[t2.canonical];
      if (c2) for (let e4 of c2) e4(n3);
      return n3;
    }, y2 = /* @__PURE__ */ Symbol.for(`module-federation.tree-shaking-shared-cache`), b2 = (e3) => {
      let t2 = e3[y2];
      return t2 === void 0 && (t2 = /* @__PURE__ */ Object.create(null), Object.defineProperty(e3, y2, {
        value: t2,
        enumerable: false,
        configurable: false,
        writable: false
      })), t2;
    }, T2 = (e3, t2, n3, r3) => {
      var _a3;
      if (!Array.isArray(n3)) return r3;
      let i3 = [
        ...new Set(n3)
      ].sort(), a3 = b2(e3), o2 = a3[_a3 = t2.canonical] || (a3[_a3] = []), s3 = o2.find((e4) => e4.providedExports.length === i3.length && e4.providedExports.every((e5, t3) => e5 === i3[t3]));
      return s3 ? s3.value = r3 : o2.push({
        providedExports: i3,
        value: r3
      }), r3;
    }, D2 = /* @__PURE__ */ Symbol.for(`module-federation.tree-shaking-shared-selection-cache`), O2 = (e3) => {
      let t2 = e3[D2];
      return t2 === void 0 && (t2 = /* @__PURE__ */ Object.create(null), Object.defineProperty(e3, D2, {
        value: t2,
        enumerable: false,
        configurable: false,
        writable: false
      })), t2;
    }, k2 = (e3, t2, n3) => {
      var _a3, _b3;
      let r3 = i2(e3, t2);
      return r3 === void 0 ? (_b3 = (_a3 = e3[D2]) == null ? void 0 : _a3[t2.canonical]) == null ? void 0 : _b3[n3] : r3;
    }, A = (e3, t2, n3, r3) => {
      var _a3;
      let i3 = O2(e3), a3 = i3[_a3 = t2.canonical] || (i3[_a3] = /* @__PURE__ */ Object.create(null));
      return a3[n3] = r3, r3;
    }, j = ((_a2 = globalThis.__FEDERATION__) == null ? void 0 : _a2.__INSTANCES__) || [], M = (_b2 = n2.find((e3) => e3 == null ? void 0 : e3.from)) == null ? void 0 : _b2.from, N = j.find((t2) => {
      var _a3, _b3;
      return ((_a3 = t2 == null ? void 0 : t2.options) == null ? void 0 : _a3.name) === M && ((_b3 = t2 == null ? void 0 : t2.shareScopeMap) == null ? void 0 : _b3.default) === e2;
    }) || j.find((t2) => {
      var _a3, _b3;
      return ((_a3 = t2 == null ? void 0 : t2.options) == null ? void 0 : _a3.name) !== f && ((_b3 = t2 == null ? void 0 : t2.shareScopeMap) == null ? void 0 : _b3.default) === e2;
    }), P = /* @__PURE__ */ Object.create(null), F = (e3) => {
      let t2 = /* @__PURE__ */ Object.create(null);
      for (let [n3, r3] of Object.entries(e3 || {})) t2[n3] = Object.assign(/* @__PURE__ */ Object.create(null), r3);
      return t2;
    }, te = (e3, t2) => {
      let n3 = !N && Object.values(t2 || {}).some((e4) => Object.values(e4 || {}).some(z)), r3 = n3 ? F(t2) : t2;
      return P[e3] = {
        host: t2,
        runtime: r3,
        isWebpackScope: n3
      }, r3;
    }, I = () => {
      let e3 = Object.values(P).filter(({ isWebpackScope: e4 }) => e4);
      if (e3.length !== 0) for (let { host: t2, runtime: n3 } of e3) for (let [e4, r3] of Object.entries(t2 || {})) {
        let t3 = n3[e4] || (n3[e4] = /* @__PURE__ */ Object.create(null));
        for (let [e5, n4] of Object.entries(r3 || {})) t3[e5] = n4;
      }
    }, L = /* @__PURE__ */ Object.create(null);
    for (let [t2, n3] of Object.entries(e2)) {
      let e3 = L[t2] = /* @__PURE__ */ Object.create(null);
      for (let [t3, r3] of Object.entries(n3)) e3[t3] = Object.assign({}, r3);
    }
    let { usedShared: R, usedRemotes: ne } = await E();
    function z(e3) {
      if (typeof (e3 == null ? void 0 : e3.get) != `function`) return false;
      let t2 = Function.prototype.toString.call(e3.get);
      return t2.includes(`__webpack_require__`) || /\.\s*e\s*\([^)]*\)\s*\.then\s*\(/.test(t2);
    }
    let re = Object.values(L).some((e3) => Object.values(e3 || {}).some(z)), ie = (e3) => {
      let t2 = e3.split(`/`);
      return e3.startsWith(`@`) ? t2.slice(0, 2).join(`/`) : t2[0];
    }, B = (t2, n3, r3) => {
      if (typeof C != `function`) return;
      let i3 = ie(t2), a3 = i3 === t2 ? [
        [
          t2,
          n3
        ]
      ] : [
        [
          t2,
          n3
        ],
        [
          i3,
          R[i3]
        ]
      ];
      for (let [n4, i4] of a3) {
        if (!i4) continue;
        let a4 = C(r3 ? n4 === t2 ? r3 : L[n4] : e2[n4], n4, i4, `version-first`);
        if (a4 && z(a4) && !a4.lib && !a4.loaded) return a4;
      }
    };
    var V = l[d];
    if (V || (V = l[d] = {
      from: f
    }), n2.indexOf(V) >= 0) return;
    n2.push(V);
    let H = (e3) => {
      let t2 = e3;
      for (let e4 = 0; e4 < 5; e4++) {
        let e5 = t2 == null ? void 0 : t2.default;
        if (!e5 || typeof e5 != `object` || Object.keys(e5).length === 0) break;
        let n3 = Object.keys(t2).filter((e6) => e6 !== "default").map((e6) => t2[e6]);
        if (n3.length > 0 && n3.some((e6) => e6 !== void 0)) break;
        t2 = e5;
      }
      return t2;
    }, ae = [], oe = globalThis.window === void 0 ? await Promise.all([]) : [], U = `__mf_vite_runtime_share_load_id__`, se = 0, W = /* @__PURE__ */ new Map(), G = /* @__PURE__ */ new Map(), K = t({
      name: f,
      remotes: ne,
      shared: R,
      plugins: [
        ce(),
        le(),
        ...ae,
        ...oe
      ],
      shareStrategy: `version-first`
    });
    K.initShareScopeMap(`default`, te(`default`, e2));
    function ce() {
      return {
        name: `vite-share-pin-lifecycle-plugin`,
        resolveShare(e3) {
          var _a3;
          let t2 = (_a3 = e3.shareInfo) == null ? void 0 : _a3[U], n3 = t2 === void 0 ? void 0 : G.get(t2);
          if (!n3) return e3;
          let r3 = e3.resolver;
          return e3.resolver = (...e4) => (n3.pinned.reapply(), r3(...e4)), n3.pinned.reveal(), e3;
        }
      };
    }
    function le() {
      return {
        name: `vite-real-name-snapshot-plugin`,
        afterLoadSnapshot(e3) {
          let t2 = e3 && e3.remoteSnapshot, n3 = t2 && t2.globalName, r3 = t2 && t2.version;
          if (!n3 || !r3 || !t2.remoteEntry) return e3;
          let i3 = globalThis.__FEDERATION__ && globalThis.__FEDERATION__.moduleInfo, a3 = n3 + `:` + r3;
          return i3 && !i3[a3] && (i3[a3] = t2), e3;
        }
      };
    }
    let ue = K.sharedHandler.hooks.lifecycle.resolveShare, q = /* @__PURE__ */ new WeakMap();
    ue.on((e3) => {
      var _a3;
      let t2 = (_a3 = e3.shareInfo) == null ? void 0 : _a3[U], n3 = e3.resolver;
      return typeof n3 == `function` && (e3.resolver = (...e4) => {
        let r3 = n3(...e4), i3 = r3 == null ? void 0 : r3.shared;
        return i3 && (typeof i3 == `object` || typeof i3 == `function`) && !q.has(i3) && q.set(i3, {
          from: i3.from
        }), t2 !== void 0 && i3 && W.set(t2, i3), r3;
      }), e3;
    });
    let de = (e3, t2, n3, r3) => {
      if (!e3 || e3[t2] !== n3) return;
      let i3 = Object.assign({}, r3, {
        version: r3.version ?? t2,
        scope: r3.scope ?? (n3 == null ? void 0 : n3.scope) ?? [
          `default`
        ],
        strategy: `loaded-first`
      }), a3 = r3.from;
      e3[t2] = i3;
      let o2 = () => n3 === void 0 ? e3[t2] === void 0 : e3[t2] === n3;
      return {
        provider: i3,
        reveal() {
          return e3[t2] === i3 && (n3 === void 0 ? delete e3[t2] : e3[t2] = n3, true);
        },
        reapply() {
          return o2() ? (e3[t2] = i3, true) : false;
        },
        release(s3, c2 = true) {
          return r3.from = a3, e3[t2] === i3 ? c2 ? s3 ? (i3.from = a3, s3 && i3.lib && (i3.loaded = true), r3.strategy === void 0 ? delete i3.strategy : i3.strategy = r3.strategy, true) : (n3 === void 0 ? delete e3[t2] : e3[t2] = n3, false) : (n3 === void 0 ? delete e3[t2] : e3[t2] = n3, true) : !c2 && o2();
        }
      };
    }, fe = (e3) => Object.entries(e3 || {}).map(([e4, t2]) => ({
      provider: t2,
      version: e4,
      from: t2.from,
      registered: true
    })), pe = (e3, t2) => {
      if (t2 === void 0) return;
      let n3;
      for (let r3 of e3) {
        let e4 = r3.provider, i3 = e4.treeShaking || e4;
        if (r3.loadedFactory === t2 || e4.lib === t2 || i3.lib === t2) {
          if (n3) return;
          n3 = r3;
        }
      }
      return n3;
    }, me = async (e3, t2, n3) => {
      let r3 = ++se;
      G.set(r3, {
        pinned: n3
      });
      try {
        let n4 = await K.loadShare(e3, {
          customShareInfo: {
            shareConfig: t2,
            [U]: r3
          }
        });
        return {
          factory: n4 === false ? void 0 : n4,
          selectedProvider: W.get(r3)
        };
      } finally {
        W.delete(r3), G.delete(r3);
      }
    }, J = async (e3, t2, n3, r3, i3, a3, o2 = true) => {
      let s3 = a3.from, c2 = de(n3, r3, i3, a3);
      if (!c2) return;
      let l2;
      try {
        l2 = await me(e3, t2, c2);
      } catch (e4) {
        throw c2.release(false), e4;
      }
      let u2 = l2 == null ? void 0 : l2.factory;
      if (u2 === void 0) {
        c2.release(false);
        return;
      }
      let d2 = fe(n3), f2 = c2.provider.treeShaking || c2.provider, p2 = c2.provider.lib === u2 || f2.lib === u2;
      if (!o2 && p2) {
        let e4 = d2.findIndex((e5) => e5.provider === c2.provider);
        e4 !== -1 && d2.splice(e4, 1);
      }
      !o2 && !d2.some((e4) => e4.provider === a3) && d2.push({
        provider: a3,
        version: r3,
        from: s3,
        registered: false,
        loadedFactory: p2 ? u2 : void 0
      });
      let m3 = !o2 && l2.selectedProvider === c2.provider && p2 ? a3 : l2.selectedProvider;
      if (m3 && !d2.some((e4) => e4.provider === m3)) {
        let e4 = q.get(m3), t3 = typeof m3.version == `string` && m3.version ? m3.version : r3;
        d2.push({
          provider: m3,
          version: t3,
          from: e4 ? e4.from : m3.from,
          registered: (n3 == null ? void 0 : n3[t3]) === m3,
          loadedFactory: u2
        });
      }
      let h3 = d2.find((e4) => e4.provider === m3) ?? pe(d2, u2);
      if (!c2.release(true, (h3 == null ? void 0 : h3.provider) === c2.provider) || !h3) return;
      let g2 = q.get(h3.provider);
      h3.from = h3.provider === a3 ? s3 : g2 ? g2.from : h3.provider.from, g2 && (h3.provider.from = g2.from);
      let _2 = typeof u2 == `function` ? u2() : u2, v3 = await Promise.resolve(_2);
      if (!(h3.registered && (n3 == null ? void 0 : n3[h3.version]) !== h3.provider)) return {
        provider: h3.provider,
        selection: h3,
        resolved: v3
      };
    }, Y = /* @__PURE__ */ new Set(), X = /* @__PURE__ */ new Map(), he = async (t2, n3, a3) => {
      var _a3;
      let o2 = !!((_a3 = n3.shareConfig) == null ? void 0 : _a3.singleton);
      if (!o2 && n3.canLiveRebind !== false) try {
        let s3 = C(a3, t2, n3, `version-first`), l2 = x(a3, s3);
        if (!l2) return;
        let { version: u2 } = l2;
        if (!o2 && u2 !== n3.version || !s3.lib && !s3.loading && !(s3.loaded && typeof s3.get == `function`)) return;
        let d2 = r2(t2, o2, n3.version, n3.scope);
        if (i2(c.share, d2) !== void 0) return;
        let f2 = e2[t2], p2 = f2 == null ? void 0 : f2[u2];
        if (l2.registered && !w(p2, s3)) return;
        let m3, h3 = s3.lib;
        if (!h3 && z(s3) || (!h3 && s3.loading && (h3 = await s3.loading), !h3 && s3.loaded && typeof s3.get == `function` && (h3 = await s3.get()), !h3)) return;
        let g2 = typeof h3 == `function` ? h3() : h3, _2 = await Promise.resolve(g2), y3 = l2.registered ? p2 : s3;
        m3 = {
          provider: y3,
          selection: {
            provider: y3,
            version: u2,
            from: s3.from,
            registered: l2.registered
          },
          resolved: _2
        };
        let b3 = m3 == null ? void 0 : m3.provider, S2 = m3 == null ? void 0 : m3.selection;
        if (!S2) return;
        let T3 = m3 == null ? void 0 : m3.resolved;
        if (T3 === void 0 || i2(c.share, d2) !== void 0 || S2.registered && (f2 == null ? void 0 : f2[S2.version]) !== b3) return;
        v2(c.share, d2, H(T3), S2.from), Y.add(b3);
      } catch (e3) {
        console.error(`[Module Federation] Failed to bridge materialized shared module "` + t2 + `"`, e3);
      }
    }, Z = async (t2, n3, a3, o2, s3) => {
      var _a3, _b3;
      try {
        let l2 = r2(t2, (_a3 = n3.shareConfig) == null ? void 0 : _a3.singleton, n3.version, n3.scope), u2 = i2(c.share, l2), d2 = h2(c.share, l2), p2 = C(a3, t2, n3, `version-first`), m3 = p2 || S(a3, t2, n3, `version-first`) || n3, g2 = x(a3, m3);
        if (!g2) return;
        let _2 = w(m3, n3), { version: y3 } = g2;
        if (!((_b3 = n3.shareConfig) == null ? void 0 : _b3.singleton) && y3 !== n3.version) return;
        let b3 = o2 == null ? void 0 : o2[y3], T3 = ee(j, N, e2, `default`, t2, g2, p2, b3, `version-first`);
        if (!T3 && !_2) return;
        let { provider: E2, scopeRootProvider: D3 } = T3 || {
          provider: m3,
          scopeRootProvider: void 0
        };
        if (n3.canLiveRebind === false || u2 !== void 0 && d2 !== f) return;
        let O3 = e2[t2], k3 = O3 == null ? void 0 : O3[y3];
        if (g2.registered && !D3 && !w(k3, E2)) return;
        let A2 = await J(t2, n3.shareConfig, O3, y3, k3, E2, g2.registered && !_2), M2 = A2 == null ? void 0 : A2.provider, P2 = A2 == null ? void 0 : A2.selection;
        if (!P2 || w(M2, n3) || s3 && (s3.version !== P2.version || !w({
          from: P2.from
        }, s3.provider)) || Y.has(M2)) return;
        let F2 = A2 == null ? void 0 : A2.resolved;
        if (F2 === void 0) return;
        let te2 = i2(c.share, l2), I2 = h2(c.share, l2);
        if (te2 !== void 0 && I2 !== f || P2.registered && (O3 == null ? void 0 : O3[P2.version]) !== M2) return;
        s3 || X.set(t2, {
          version: P2.version,
          provider: {
            from: P2.from
          }
        }), Y.add(M2);
        let L2 = H(F2);
        v2(c.share, l2, L2, P2.from);
      } catch (e3) {
        console.error(`[Module Federation] Failed to bridge external shared module "` + t2 + `"`, e3);
      }
    };
    for (let e3 of p) await Promise.all(e3.map(async (e4) => {
      let t2 = R[e4];
      t2 && t2.materialize !== false && !t2.treeShaking && await he(e4, t2, L[e4]);
    }));
    for (let [e3, t2] of Object.entries(R)) {
      if (t2.treeShaking) continue;
      let n3 = r2(e3, (_c = t2.shareConfig) == null ? void 0 : _c.singleton, t2.version, t2.scope);
      if (i2(c.share, n3) !== void 0) continue;
      let a3 = r2(e3, true, t2.version, t2.scope), o2 = i2(c.share, a3);
      o2 !== void 0 && v2(c.share, n3, o2, h2(c.share, a3));
    }
    let ge = [
      `react`,
      `moment`,
      `react/jsx-dev-runtime`,
      `react/jsx-runtime`,
      `react-dom`,
      `@emotion/react`,
      `@mui/private-theming`,
      `react-dom/client`,
      `@mui/system`,
      `@mui/material`,
      `@iobroker/gui-components`
    ], _e = [
      [
        `react`,
        `moment`
      ],
      [
        `react/jsx-dev-runtime`,
        `react/jsx-runtime`,
        `react-dom`,
        `@emotion/react`,
        `@mui/private-theming`
      ],
      [
        `react-dom/client`,
        `@mui/system`
      ],
      [
        `@mui/material`
      ],
      [
        `@iobroker/gui-components`
      ]
    ], Q = ge.filter((e3) => {
      var _a3;
      return R[e3] && (R[e3].materialize !== false || ((_a3 = R[e3].shareConfig) == null ? void 0 : _a3.import) === false);
    });
    c.providerInit || (c.providerInit = /* @__PURE__ */ new Map());
    let ve = (e3, t2) => {
      let n3 = c.providerInit.get(e3);
      if (n3) return n3;
      let r3 = Promise.resolve().then(t2);
      return c.providerInit.set(e3, r3), r3.catch(() => c.providerInit.delete(e3)), r3;
    };
    var ye = async (e3) => {
      let t2 = new Set(e3);
      for (let e4 of _e) await Promise.all(e4.filter((e5) => t2.has(e5)).map(async (e5) => {
        var _a3, _b3;
        let t3 = R[e5], n3 = r2(e5, (_a3 = t3.shareConfig) == null ? void 0 : _a3.singleton, t3.version, t3.scope);
        if (((_b3 = t3.shareConfig) == null ? void 0 : _b3.import) === false || t3.treeShaking || i2(c.share, n3) !== void 0) return;
        let a3 = r2(e5, true, t3.version, t3.scope), o2 = i2(c.share, a3);
        if (o2 !== void 0) {
          v2(c.share, n3, o2, h2(c.share, a3));
          return;
        }
        let s3 = typeof B == `function` ? B(e5, t3) : void 0;
        if (s3 && !s3.lib && !s3.loaded) return;
        let l2 = n3.canonical, u2 = await ve(l2, async () => {
          let e6 = await t3.get(), n4 = typeof e6 == `function` ? e6() : e6;
          return Promise.resolve(n4);
        }), d2 = ((e6) => {
          let t4 = e6;
          for (let e7 = 0; e7 < 5; e7++) {
            let e8 = t4 == null ? void 0 : t4.default;
            if (!e8 || typeof e8 != `object` || Object.keys(e8).length === 0) break;
            let n4 = Object.keys(t4).filter((e9) => e9 !== "default").map((e9) => t4[e9]);
            if (n4.length > 0 && n4.some((e9) => e9 !== void 0)) break;
            t4 = e8;
          }
          return t4;
        })(u2), p2 = d2 === u2 ? {
          ...u2
        } : d2;
        p2.__esModule !== true && Object.defineProperty(p2, "__esModule", {
          value: true,
          enumerable: false
        }), v2(c.share, n3, p2, f);
      }));
    };
    let be = (e3) => {
      var _a3, _b3;
      let t2 = R[e3];
      if (!t2.treeShaking && ((_a3 = t2.shareConfig) == null ? void 0 : _a3.import) !== false) return false;
      let n3 = r2(e3, (_b3 = t2.shareConfig) == null ? void 0 : _b3.singleton, t2.version, t2.scope);
      return t2.treeShaking ? k2(c.share, n3, f) === void 0 && i2(c.share, n3) === void 0 : i2(c.share, n3) === void 0;
    }, $ = Q.findIndex((e3) => {
      var _a3, _b3;
      let t2 = R[e3], n3 = r2(e3, (_a3 = t2.shareConfig) == null ? void 0 : _a3.singleton, t2.version, t2.scope);
      return (t2.treeShaking ? k2(c.share, n3, f) ?? i2(c.share, n3) : i2(c.share, n3)) === void 0 ? t2.treeShaking || ((_b3 = t2.shareConfig) == null ? void 0 : _b3.import) === false ? true : typeof C == `function` && !!C(L[e3], e3, t2, `version-first`) : false;
    }), xe = $ === -1 ? Q : Q.slice(0, $);
    var Se = $ === -1 ? [] : Q.slice($);
    await ye(xe);
    try {
      await _(async () => {
        await Promise.all(await K.initializeSharing(`default`, {
          strategy: `version-first`,
          from: `build`,
          initScope: n2
        }));
      });
    } catch (e3) {
      console.error(`[Module Federation]`, e3);
    }
    I();
    let Ce = async () => {
      for (let t2 of p) await Promise.all(t2.map(async (t3) => {
        let n3 = R[t3];
        n3 && n3.materialize !== false && !n3.treeShaking && await Z(t3, n3, e2[t3], L[t3], void 0);
      }));
    };
    await Ce(), re && (g = Ce);
    try {
      let e3 = (_d = globalThis.__FEDERATION__) == null ? void 0 : _d.__SHARE__, t2 = /* @__PURE__ */ Object.create(null);
      if (e3) for (let [, n3] of Object.entries(e3)) for (let e4 of u) {
        let r3 = n3 == null ? void 0 : n3[e4];
        if (r3) for (let [e5, n4] of Object.entries(r3)) {
          let r4 = R == null ? void 0 : R[e5], i3 = L[e5], a3 = X.get(e5);
          if (!r4 || !i3 || !a3 || r4.treeShaking) continue;
          let o2 = t2[e5] || (t2[e5] = /* @__PURE__ */ Object.create(null));
          for (let [e6, t3] of Object.entries(n4)) {
            if (!t3.lib || a3.version !== e6 || !w(t3, a3.provider)) continue;
            let n5 = i3[e6];
            (t3 === n5 || (n5 == null ? void 0 : n5.from) && t3.from === n5.from) && (t3 === r4 || r4.from && t3.from === r4.from || o2[e6] === void 0 && (o2[e6] = t3));
          }
        }
      }
      for (let e4 of p) await Promise.all(e4.map(async (e5) => {
        let n3 = t2[e5];
        n3 && await Z(e5, R[e5], n3, L[e5], X.get(e5));
      }));
    } catch (e3) {
      console.error(`[Module Federation] Failed to bridge external shared modules`, e3);
    }
    let we = async () => {
    }, Te = async (t2, n3) => {
      var _a3, _b3;
      let a3 = r2(t2, (_a3 = n3.shareConfig) == null ? void 0 : _a3.singleton, n3.version, n3.scope), o2 = n3.treeShaking ? k2(c.share, a3, f) : i2(c.share, a3);
      if (((_b3 = n3.shareConfig) == null ? void 0 : _b3.import) !== false || o2 !== void 0 || B(t2, n3, L[t2])) return;
      let s3 = (e3) => {
        let t3 = e3;
        for (let e4 = 0; e4 < 5; e4++) {
          let e5 = t3 == null ? void 0 : t3.default;
          if (!e5 || typeof e5 != `object` || Object.keys(e5).length === 0) break;
          let n4 = Object.keys(t3).filter((e6) => e6 !== "default").map((e6) => t3[e6]);
          if (n4.length > 0 && n4.some((e6) => e6 !== void 0)) break;
          t3 = e5;
        }
        return t3;
      }, l2 = e2 == null ? void 0 : e2[t2], u2 = S(l2, t2, n3, `version-first`) || n3, d2 = x(l2, u2);
      if (!d2) return;
      let { version: p2 } = d2, m3 = l2 == null ? void 0 : l2[p2], h3 = await J(t2, n3.shareConfig, l2, p2, m3, u2, d2.registered && !w(u2, n3)), g2 = h3 == null ? void 0 : h3.selection, _2 = h3 == null ? void 0 : h3.provider, y3 = h3 == null ? void 0 : h3.resolved;
      if (!g2 || w(_2, n3) || y3 === void 0 || (n3.treeShaking ? k2(c.share, a3, f) : i2(c.share, a3)) !== void 0 || g2.registered && (l2 == null ? void 0 : l2[g2.version]) !== _2) return;
      let b3 = s3(y3);
      if (n3.treeShaking) {
        let e3 = n3.treeShaking.providedExports ?? n3.treeShaking.usedExports ?? [];
        T2(c.share, a3, e3, b3), A(c.share, a3, f, b3);
      } else v2(c.share, a3, b3, g2.from);
    }, Ee = [];
    for (let e3 of Se) {
      let t2 = R[e3];
      if (be(e3)) try {
        t2.treeShaking ? await we(e3, t2) : ((_e2 = t2.shareConfig) == null ? void 0 : _e2.import) === false && await Te(e3, t2);
      } catch (t3) {
        console.error(`[Module Federation] Failed to resolve runtime-only shared module "${e3}"`, t3);
        break;
      }
      if (be(e3)) break;
      Ee.push(e3);
    }
    return await ye(Ee), o(K), K;
  };
  k = async function(e2) {
    let t2 = await D();
    if (!(e2 in t2)) throw Error(`[Module Federation] Module ${e2} does not exist in container.`);
    return g && await g(), c.pendingShareLoads && await Promise.all(c.pendingShareLoads), t2[e2]().then((e3) => () => e3);
  };
  if (typeof document !== "undefined" && document.head) {
    try {
      for (const __mfWarmupPath of [
        "assets/virtualExposes-5Z3xpAMt.js",
        "assets/_virtual_mf-localSharedImportMap___mfe_internal__vis2nilsForkWidgets__mf_owner__1-DJF1wT9s.js",
        "assets/vite-preload-helper-HclGiUj8.js",
        "assets/dist-BgxWXJ5y.js"
      ]) {
        const __mfWarmupLink = document.createElement("link");
        __mfWarmupLink.rel = "modulepreload";
        __mfWarmupLink.crossOrigin = "";
        __mfWarmupLink.href = new URL(__mfWarmupPath, import.meta.url).href;
        document.head.appendChild(__mfWarmupLink);
      }
    } catch (__mfWarmupError) {
    }
  }
});
export {
  __tla,
  k as get,
  O as init
};
