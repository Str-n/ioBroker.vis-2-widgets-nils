import { B as e } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as t, ft as n, i as r, r as i } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as a } from "./Generic-BOiMPpxz.js";
e();
var o = class e2 extends a {
  static getWidgetInfo() {
    return { id: `tplNils2ThemeSwitcher`, visSet: `vis-2-widgets-nils-fork`, visName: `Theme switcher`, visWidgetLabel: `theme_switcher`, visAttrs: [{ name: `common`, fields: [{ label: `theme_type`, type: `select`, options: [{ value: `system`, label: `Browser` }, { value: `static`, label: `Static` }, { value: `variable`, label: `Variable` }], default: `system`, name: `themeType` }, { name: `themeName`, type: `select`, noTranslation: true, options: [{ value: `dark`, label: `dark` }, { value: `light`, label: `light` }], default: `light`, label: `theme_name`, hidden: (e3) => e3.themeType === `system` }, { name: `variant`, type: `select`, options: [{ value: `contained`, label: `Contained` }, { value: `text`, label: `Text` }, { value: `outlined`, label: `Outlined` }], default: `outlined`, label: `variant`, hidden: (e3) => e3.themeType !== `variable` }] }], visDefaultStyle: { width: 48, height: 48, position: `absolute` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_theme_switcher.png` };
  }
  componentDidMount() {
    super.componentDidMount();
    let e3;
    e3 = window.matchMedia && window.matchMedia(`(prefers-color-scheme: dark)`).matches ? `dark` : `light`, this.state.rxData.themeType === `system` ? (window.matchMedia(`(prefers-color-scheme: dark)`).addEventListener(`change`, this.onThemeChanged), this.setState({ themeName: e3 }, () => this.setViewTheme(e3))) : this.state.rxData.themeType === `static` ? e3 = this.state.rxData.themeName : this.state.rxData.themeType === `variable` && (e3 = window.localStorage.getItem(`App.themeName`) || (window.matchMedia && window.matchMedia(`(prefers-color-scheme: dark)`).matches ? `dark` : `light`)), this.setState({ themeName: e3 }, () => this.setViewTheme(e3));
  }
  setViewTheme(e3) {
    var _a, _b;
    let t2 = e3 || this.state.rxData.themeName || `light`;
    (_b = (_a = this.props.context) == null ? void 0 : _a.toggleTheme) == null ? void 0 : _b.call(_a, t2);
  }
  onThemeChanged = (e3) => this.setState({ themeName: e3.matches ? `dark` : `light` });
  componentWillUnmount() {
    this.state.rxData.themeType === `system` && window.matchMedia(`(prefers-color-scheme: dark)`).removeEventListener(`change`, this.onThemeChanged);
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  renderWidgetBody(e3) {
    return super.renderWidgetBody(e3), this.state.rxData.themeType === `system` || this.state.rxData.themeType === `static` ? this.props.editMode ? n(`div`, { style: { display: `flex`, alignItems: `center`, width: `100%`, height: `100%` }, children: n(r, { style: { width: `100%`, textAlign: `center` }, themeName: this.state.themeName, toggleTheme: () => {
    }, t: i.t }) }) : null : this.state.rxData.themeType === `variable` ? n(t, { variant: this.state.rxData.variant, style: { width: `100%`, height: `100%` }, onClick: (e4) => {
      e4.stopPropagation();
      let t2 = this.state.themeName === `dark` ? `light` : `dark`;
      window.localStorage.setItem(`App.themeName`, t2), this.setState({ themeName: t2 }, () => this.setViewTheme(t2));
    }, children: n(r, { themeName: this.state.themeName, toggleTheme: () => {
    }, t: i.t }) }) : null;
  }
};
export {
  o as default
};
