var re = {}, W = {}, B = {};
Object.defineProperty(B, "__esModule", { value: true });
B.StateType = B.Types = void 0;
var Y;
(function(i) {
  i.unknown = "unknown", i.airCondition = "airCondition", i.blind = "blind", i.blindButtons = "blindButtons", i.button = "button", i.buttonSensor = "buttonSensor", i.camera = "camera", i.chart = "chart", i.cie = "cie", i.ct = "ct", i.dimmer = "dimmer", i.door = "door", i.fireAlarm = "fireAlarm", i.floodAlarm = "floodAlarm", i.gate = "gate", i.hue = "hue", i.humidity = "humidity", i.illuminance = "illuminance", i.image = "image", i.info = "info", i.instance = "instance", i.light = "light", i.location = "location", i.locationOne = "locationOne", i.lock = "lock", i.media = "media", i.motion = "motion", i.rgb = "rgb", i.rgbSingle = "rgbSingle", i.rgbwSingle = "rgbwSingle", i.slider = "slider", i.socket = "socket", i.temperature = "temperature", i.thermostat = "thermostat", i.vacuumCleaner = "vacuumCleaner", i.volume = "volume", i.volumeGroup = "volumeGroup", i.warning = "warning", i.weatherCurrent = "weatherCurrent", i.weatherForecast = "weatherForecast", i.window = "window", i.windowTilt = "windowTilt";
})(Y || (B.Types = Y = {}));
var x;
(function(i) {
  i.Number = "number", i.String = "string", i.Boolean = "boolean";
})(x || (B.StateType = x = {}));
var R = {};
Object.defineProperty(R, "__esModule", { value: true });
R.checkEnum = V;
R.roleOrEnum = L;
R.roleOrEnumLight = ae;
R.roleOrEnumBlind = le;
R.roleOrEnumGate = ie;
R.roleOrEnumWindow = ne;
R.roleOrEnumDoor = oe;
R.getEnums = ue;
R.getAllStatesInChannel = se;
R.getAllStatesInDevice = de;
R.getObjectsBelowId = te;
R.getFunctionEnums = fe;
R.getParentId = ce;
function V(i, r) {
  let a = false;
  return i && i.forEach((l) => {
    const o = l.lastIndexOf(".");
    o !== -1 && (l = l.substring(o + 1));
    for (const u in r) if (Object.prototype.hasOwnProperty.call(r, u) && r[u].find((n) => n.test(l))) return a = true, false;
  }), a;
}
function L(i, r, a, l) {
  return i.common.role && (a == null ? void 0 : a.includes(i.common.role)) ? true : V(r, l);
}
const K = { en: [/lights?/i, /lamps?/i, /ceilings?/i], de: [/licht(er)?/i, /lampen?/i, /beleuchtung(en)?/i], ru: [/свет/i, /ламп[аы]/i, /торшеры?/, /подсветк[аи]/i, /лампочк[аи]/i, /светильники?/i] }, j = ["switch.light", "dimmer", "value.dimmer", "level.dimmer", "sensor.light", "state.light"];
function ae(i, r) {
  return L(i, r, j, K);
}
const k = { en: [/blinds?/i, /windows?/i, /shutters?/i], de: [/rollladen?/i, /fenstern?/i, /beschattung(en)?/i, /jalousien?/i], ru: [/ставни/i, /рольставни/i, /окна|окно/, /жалюзи/i] }, J = ["blind", "level.blind", "value.blind", "action.stop", "button.stop", "button.stop.blind", "button.open.blind", "button.close.blind", "level.tilt", "value.tilt", "button.tilt.open", "button.tilt.close", "button.tilt.stop"];
function le(i, r) {
  return L(i, r, J, k);
}
const X = { en: [/gates?/i], de: [/^toren$/i, /^tor$/i], ru: [/ворота/i] }, z = ["gate", "value.gate", "switch.gate", "action.stop", "button.stop"];
function ie(i, r) {
  return L(i, r, z, X);
}
const Q = ["window", "state.window", "sensor.window", "value.window"];
function ne(i, r) {
  return L(i, r, Q, k);
}
const Z = { en: [/doors?/i, /gates?/i, /wickets?/i, /entry|entries/i], de: [/^türe?/i, /^tuere?/i, /^tore?$/i, /einfahrt(en)?/i, /pforten?/i], ru: [/двери|дверь/i, /ворота/i, /калитка|калитки/, /въезды?/i, /входы?/i] }, ee = ["door", "state.door", "sensor.door"];
function oe(i, r) {
  return L(i, r, ee, Z);
}
function ue() {
  return { door: { roles: ee, words: Z }, window: { roles: Q, words: k }, blind: { roles: J, words: k }, gate: { roles: z, words: X }, light: { roles: j, words: K } };
}
function se(i, r) {
  const a = [], l = new RegExp(`^${r.replace(/([$^.)([\]{}])/g, "\\$1")}\\.[^.]+$`);
  return i.forEach((o) => l.test(o) && a.push(o)), a;
}
function de(i, r) {
  const a = [], l = new RegExp(`^${r.replace(/([$^.)([\]{}])/g, "\\$1")}\\.[^.]+\\.[^.]+$`);
  return i.forEach((o) => l.test(o) && a.push(o)), a;
}
function te(i, r) {
  const a = [];
  r += ".";
  let l = 0, o = i.length - 1, u = -1;
  for (; l <= o; ) {
    const n = Math.floor((l + o) / 2);
    i[n] < r ? l = n + 1 : (u = n, o = n - 1);
  }
  if (u === -1 || u >= i.length) return a;
  for (let n = u; n < i.length; n++) {
    const s = i[n];
    if (s === r || s.startsWith(r)) a.push(s);
    else break;
  }
  return a;
}
function fe(i, r) {
  var a, l, o;
  const u = [], n = /^enum\.functions\./, s = te(r, "enum");
  for (const d of s) Object.prototype.hasOwnProperty.call(i, d) && n.test(d) && ((a = i[d]) === null || a === void 0 ? void 0 : a.type) === "enum" && (!((o = (l = i[d].common) === null || l === void 0 ? void 0 : l.members) === null || o === void 0) && o.length) && u.push(d);
  return u;
}
function ce(i) {
  const r = i.lastIndexOf(".");
  return r !== -1 ? i.substring(0, r) : i;
}
var H = {};
Object.defineProperty(H, "__esModule", { value: true });
H.patterns = void 0;
const e = B, m = R, p = /^[^.]+\.setting\./, t = { working: { role: /^indicator\.working$/, indicator: true, notSingle: true, name: "WORKING", required: false, defaultRole: "indicator.working", defaultType: e.StateType.Boolean }, unreach: { role: /^indicator(\.maintenance)?\.unreach$/, indicator: true, type: e.StateType.Boolean, notSingle: true, name: "UNREACH", required: false, defaultRole: "indicator.maintenance.unreach" }, lowbat: { role: /^indicator(\.maintenance)?\.(lowbat|battery)$/, indicator: true, type: e.StateType.Boolean, notSingle: true, name: "LOWBAT", required: false, defaultRole: "indicator.maintenance.lowbat" }, maintain: { role: /^indicator\.maintenance$/, indicator: true, type: e.StateType.Boolean, notSingle: true, name: "MAINTAIN", required: false, defaultRole: "indicator.maintenance" }, error: { role: /^indicator\.error$/, indicator: true, notSingle: true, name: "ERROR", required: false, defaultRole: "indicator.error", defaultType: e.StateType.String }, direction: { role: /^indicator\.direction$/, indicator: true, type: e.StateType.Boolean, notSingle: true, name: "DIRECTION", required: false, defaultRole: "indicator.direction" }, direction_enum: { role: /^(indicator|value)\.direction$/, type: e.StateType.Number, notSingle: true, name: "DIRECTION", required: false, defaultStates: { 0: "None", 1: "Up/Open", 2: "Down/Close", 3: "Unknown" }, defaultRole: "value.direction" }, reachable: { role: /^indicator\.reachable$/, indicator: true, type: e.StateType.Boolean, notSingle: true, name: "CONNECTED", required: false, defaultRole: "indicator.reachable", inverted: true }, battery: { role: /^value\.battery$/, indicator: false, type: e.StateType.Number, write: false, name: "BATTERY", required: false, defaultRole: "value.battery", defaultUnit: "%" } }, O = { power: { role: /^value\.power$/, indicator: false, type: e.StateType.Number, write: false, name: "ELECTRIC_POWER", required: false, defaultRole: "value.power", defaultUnit: "W" }, current: { role: /^value\.current$/, indicator: false, type: e.StateType.Number, write: false, name: "CURRENT", required: false, defaultRole: "value.current", defaultUnit: "mA" }, voltage: { role: /^value\.voltage$/, indicator: false, type: e.StateType.Number, write: false, name: "VOLTAGE", required: false, defaultRole: "value.voltage", defaultUnit: "V" }, consumption: { role: /^value\.power\.consumption$/, indicator: false, type: e.StateType.Number, write: false, name: "CONSUMPTION", required: false, defaultRole: "value.power.consumption", defaultUnit: "Wh" }, frequency: { role: /^value\.frequency$/, indicator: false, type: e.StateType.Number, write: false, name: "FREQUENCY", required: false, defaultRole: "value.frequency", defaultUnit: "Hz" } };
H.patterns = { chart: { states: [{ objectType: "chart", name: "CHART" }], type: e.Types.chart }, mediaPlayer: { states: [{ role: /^media\.state(\..*)?$/, indicator: false, type: [e.StateType.Boolean, e.StateType.Number], name: "STATE", required: true, defaultRole: "media.state" }, { role: /^(button|action)\.play(\..*)?$/, indicator: false, write: true, type: e.StateType.Boolean, name: "PLAY", required: false, noSubscribe: true, defaultRole: "button.play" }, { role: /^(button|action)\.pause(\..*)?$/, indicator: false, write: true, type: e.StateType.Boolean, name: "PAUSE", required: false, noSubscribe: true, defaultRole: "button.pause" }, { role: /^(button|action)\.stop(\..*)?$/, indicator: false, write: true, type: e.StateType.Boolean, name: "STOP", required: false, noSubscribe: true, defaultRole: "button.stop" }, { role: /^(button|action)\.next(\..*)?$/, indicator: false, write: true, type: e.StateType.Boolean, name: "NEXT", required: false, noSubscribe: true, defaultRole: "button.next" }, { role: /^(button|action)\.prev(\..*)?$/, indicator: false, write: true, type: e.StateType.Boolean, name: "PREV", required: false, noSubscribe: true, defaultRole: "button.prev" }, { role: /^media\.mode\.shuffle(\..*)?$/, indicator: false, write: true, type: e.StateType.Boolean, name: "SHUFFLE", required: false, noSubscribe: true, defaultRole: "media.mode.shuffle" }, { role: /^media\.mode\.repeat(\..*)?$/, indicator: false, write: true, type: e.StateType.Number, name: "REPEAT", required: false, noSubscribe: true, defaultRole: "media.mode.repeat" }, { role: /^media\.artist(\..*)?$/, indicator: false, write: false, type: e.StateType.String, name: "ARTIST", required: false, defaultRole: "media.artist" }, { role: /^media\.album(\..*)?$/, indicator: false, write: false, type: e.StateType.String, name: "ALBUM", required: false, defaultRole: "media.album" }, { role: /^media\.title(\..*)?$/, indicator: false, write: false, type: e.StateType.String, name: "TITLE", required: false, defaultRole: "media.title" }, { role: /^media\.cover(\.big)?$/, indicator: false, write: false, type: e.StateType.String, name: "COVER", required: false, notSingle: true, defaultRole: "media.cover" }, { role: /^media\.cover(\..*)$/, indicator: false, write: false, type: e.StateType.String, name: "COVER", required: false, notSingle: true }, { role: /^media\.duration(\..*)?$/, indicator: false, write: false, type: e.StateType.Number, name: "DURATION", required: false, noSubscribe: true, defaultRole: "media.duration", defaultUnit: "sec" }, { role: /^media\.elapsed(\..*)?$/, indicator: false, type: e.StateType.Number, name: "ELAPSED", required: false, noSubscribe: true, defaultRole: "media.elapsed", defaultUnit: "sec" }, { role: /^media\.seek(\..*)?$/, indicator: false, write: true, type: e.StateType.Number, name: "SEEK", required: false, noSubscribe: true, defaultRole: "media.seek" }, { role: /^media\.track(\..*)?$/, indicator: false, type: e.StateType.String, name: "TRACK", required: false, noSubscribe: true, defaultRole: "media.track" }, { role: /^media\.episode(\..*)?$/, indicator: false, type: e.StateType.String, name: "EPISODE", required: false, noSubscribe: true, defaultRole: "media.episode" }, { role: /^media\.season(\..*)?$/, indicator: false, type: e.StateType.String, name: "SEASON", required: false, noSubscribe: true, defaultRole: "media.season" }, { role: /^level(\.volume)?$/, indicator: false, type: e.StateType.Number, min: e.StateType.Number, max: e.StateType.Number, write: true, name: "VOLUME", required: false, notSingle: true, noSubscribe: true, defaultRole: "level.volume", defaultUnit: "%" }, { role: /^value(\.volume)?$/, indicator: false, type: e.StateType.Number, min: e.StateType.Number, max: e.StateType.Number, write: false, name: "VOLUME_ACTUAL", required: false, notSingle: true, noSubscribe: true, defaultRole: "value.volume", defaultUnit: "%" }, { role: /^media(\.mute)?$/, indicator: false, type: e.StateType.Boolean, write: true, name: "MUTE", required: false, notSingle: true, noSubscribe: true, defaultRole: "media.mute" }, { stateName: /\.(paused|playerState)$/, indicator: false, name: "IGNORE", required: false, multiple: true, noSubscribe: true }, t.reachable, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.media }, weatherForecast: { states: [{ role: /^weather\.icon(\.forecast\.0)?$/, indicator: false, type: e.StateType.String, name: "ICON", required: true, defaultRole: "weather.icon.forecast.0" }, { role: /^value\.temperature\.min\.forecast\.0$/, indicator: false, type: e.StateType.Number, name: "TEMP_MIN", required: true, defaultRole: "value.temperature.min.forecast.0" }, { role: /^value\.temperature\.max\.forecast\.0$/, indicator: false, type: e.StateType.Number, name: "TEMP_MAX", required: true, defaultRole: "value.temperature.max.forecast.0" }, { role: /^value\.precipitation(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "PRECIPITATION_CHANCE", unit: "%", required: false, defaultRole: "value.precipitation.forecast.0" }, { role: /^value\.precipitation(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "PRECIPITATION", unit: "mm", required: false, defaultRole: "value.precipitation.forecast.0" }, { role: /^date(\.forecast\.0)?$/, indicator: false, type: e.StateType.String, name: "DATE", required: false, defaultRole: "date.forecast.0" }, { role: /^dayofweek(\.forecast\.0)?$/, indicator: false, type: e.StateType.String, name: "DOW", required: false, defaultRole: "dayofweek.forecast.0" }, { role: /^weather\.state(\.forecast\.0)?$/, indicator: false, type: e.StateType.String, name: "STATE", required: false, defaultRole: "weather.state.forecast.0" }, { role: /^value\.temperature(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "TEMP", required: false, defaultRole: "value.temperature.forecast.0" }, { role: /^value\.pressure(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "PRESSURE", required: false, defaultRole: "value.pressure.forecast.0" }, { role: /^value\.humidity(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "HUMIDITY", required: false, defaultRole: "value.humidity.forecast.0" }, { role: /^(?:date|time)\.sunrise(?:\.forecast\.0)?$/, indicator: false, type: e.StateType.String, name: "TIME_SUNRISE", required: false, defaultRole: "date.sunrise" }, { role: /^(?:date|time)\.sunset(?:\.forecast\.0)?$/, indicator: false, type: e.StateType.String, name: "TIME_SUNSET", required: false, defaultRole: "date.sunset" }, { role: /^value\.temperature\.windchill(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "WIND_CHILL", required: false, defaultRole: "value.temperature.windchill.forecast.0" }, { role: /^value\.temperature\.feelslike(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "FEELS_LIKE", required: false, defaultRole: "value.temperature.feelslike.forecast.0" }, { role: /^value\.speed\.wind(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "WIND_SPEED", required: false, defaultRole: "value.speed.wind.forecast.0" }, { role: /^value\.direction\.wind(\.forecast\.0)?$/, indicator: false, type: e.StateType.Number, name: "WIND_DIRECTION", required: false, defaultRole: "value.direction.wind.forecast.0" }, { role: /^weather\.direction\.wind(\.forecast\.0)?$/, indicator: false, type: e.StateType.String, name: "WIND_DIRECTION_STR", required: false, defaultRole: "weather.direction.wind.forecast.0" }, { role: /^weather\.icon\.wind(\.forecast\.0)?$/, indicator: false, type: e.StateType.String, name: "WIND_ICON", required: false, defaultRole: "weather.icon.wind.forecast.0" }, { role: /^weather\.chart\.url$/, indicator: false, type: e.StateType.String, name: "HISTORY_CHART", required: false, noSubscribe: true, defaultRole: "weather.chart.url" }, { role: /^weather\.chart\.url\.forecast$/, indicator: false, type: e.StateType.String, name: "FORECAST_CHART", required: false, noSubscribe: true, defaultRole: "weather.chart.url.forecast" }, { role: /^location$/, indicator: false, type: e.StateType.String, name: "LOCATION", required: false, defaultRole: "location" }, { role: /^weather\.icon\.forecast.(\d+)$/, indicator: false, type: e.StateType.String, name: "ICON%d", required: false, searchInParent: true, multiple: true, noSubscribe: true, notSingle: true }, { role: /^value\.temperature\.min\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, name: "TEMP_MIN%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^value\.temperature\.max\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, name: "TEMP_MAX%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^date\.forecast\.(\d+)$/, indicator: false, type: e.StateType.String, name: "DATE%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^dayofweek\.forecast\.(\d+)$/, indicator: false, type: e.StateType.String, name: "DOW%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^weather\.state\.forecast\.(\d+)$/, indicator: false, type: e.StateType.String, name: "STATE%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^value\.temperature\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, name: "TEMP%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^value\.humidity\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, name: "HUMIDITY%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^value\.humidity\.max\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, name: "HUMIDITY_MAX%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^value\.precipitation\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, unit: "%", name: "PRECIPITATION_CHANCE%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^value\.precipitation\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, unit: "mm", name: "PRECIPITATION%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^value\.speed\.wind\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, name: "WIND_SPEED%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^value\.direction\.wind\.forecast\.(\d+)$/, indicator: false, type: e.StateType.Number, name: "WIND_DIRECTION%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^weather\.direction\.wind\.forecast\.(\d+)$/, indicator: false, type: e.StateType.String, name: "WIND_DIRECTION_STR%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }, { role: /^weather\.icon\.wind\.forecast\.(\d+)$/, indicator: false, type: e.StateType.String, name: "WIND_ICON%d", required: false, searchInParent: true, multiple: true, noSubscribe: true }], type: e.Types.weatherForecast }, rgb: { states: [{ role: /^level\.color\.red$/, indicator: false, type: e.StateType.Number, write: true, name: "RED", required: true, defaultRole: "level.color.red" }, { role: /^level\.color\.green$/, indicator: false, type: e.StateType.Number, write: true, name: "GREEN", required: true, defaultRole: "level.color.green" }, { role: /^level\.color\.blue$/, indicator: false, type: e.StateType.Number, write: true, name: "BLUE", required: true, defaultRole: "level.color.blue" }, { role: /^level\.color\.white$/, indicator: false, type: e.StateType.Number, write: true, name: "WHITE", required: false, defaultRole: "level.color.white" }, { role: /^level\.dimmer$/, indicator: false, type: e.StateType.Number, write: true, name: "DIMMER", required: false, defaultRole: "level.dimmer", defaultUnit: "%" }, { role: /^level\.brightness$/, indicator: false, type: e.StateType.Number, write: true, name: "BRIGHTNESS", required: false }, { role: /^level\.color\.temperature$/, indicator: false, type: e.StateType.Number, write: true, name: "TEMPERATURE", required: false, defaultRole: "level.color.temperature", defaultUnit: "\xB0K" }, { role: /^switch(\.light)?$|^state$/, indicator: false, type: e.StateType.Boolean, write: true, name: "ON", required: false, defaultRole: "switch.light" }, { role: /^(state|switch|sensor)\.light|switch$/, indicator: false, type: e.StateType.Boolean, write: false, name: "ON_ACTUAL", required: false, defaultRole: "sensor.light", ignoreRole: p }, { role: /^time\.(span|interval)$/, indicator: false, type: e.StateType.Number, write: true, name: "TRANSITION_TIME", required: false, defaultRole: "time.span", defaultUnit: "ms" }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.rgb }, rgbwSingle: { states: [{ role: /^level\.color\.rgbw$/, indicator: false, type: e.StateType.String, write: true, name: "RGBW", required: true, defaultRole: "level.color.rgbw" }, { role: /^level\.dimmer$/, indicator: false, type: e.StateType.Number, write: true, name: "DIMMER", required: false, defaultRole: "level.dimmer", defaultUnit: "%" }, { role: /^level\.brightness$/, indicator: false, type: e.StateType.Number, write: true, name: "BRIGHTNESS", required: false, defaultUnit: "%" }, { role: /^level\.color\.temperature$/, indicator: false, type: e.StateType.Number, write: true, name: "TEMPERATURE", required: false, defaultRole: "level.color.temperature", defaultUnit: "\xB0K" }, { role: /^switch(\.light)?$/, indicator: false, type: e.StateType.Boolean, write: true, name: "ON", required: false, defaultRole: "switch.light" }, { role: /^(state|switch|sensor)\.light|switch$/, indicator: false, type: e.StateType.Boolean, write: false, name: "ON_ACTUAL", required: false, defaultRole: "sensor.light", ignoreRole: p }, { role: /^time\.(span|interval)$/, indicator: false, type: e.StateType.Number, write: true, name: "TRANSITION_TIME", required: false, defaultRole: "time.span", defaultUnit: "ms" }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.rgbwSingle }, rgbSingle: { states: [{ role: /^level\.color\.rgb$/, indicator: false, type: e.StateType.String, write: true, name: "RGB", required: true, defaultRole: "level.color.rgb" }, { role: /^level\.dimmer$/, indicator: false, type: e.StateType.Number, write: true, name: "DIMMER", required: false, defaultRole: "level.dimmer", defaultUnit: "%" }, { role: /^level\.brightness$/, indicator: false, type: e.StateType.Number, write: true, name: "BRIGHTNESS", required: false, defaultUnit: "%" }, { role: /^level\.color\.temperature$/, indicator: false, type: e.StateType.Number, write: true, name: "TEMPERATURE", required: false, defaultRole: "level.color.temperature", defaultUnit: "\xB0K" }, { role: /^switch(\.light)?$/, indicator: false, type: e.StateType.Boolean, write: true, name: "ON", required: false, defaultRole: "switch.light" }, { role: /^(state|switch|sensor)\.light|switch$/, indicator: false, type: e.StateType.Boolean, write: false, name: "ON_ACTUAL", required: false, defaultRole: "sensor.light", ignoreRole: p }, { role: /^time\.(span|interval)$/, indicator: false, type: e.StateType.Number, write: true, name: "TRANSITION_TIME", required: false, defaultRole: "time.span", defaultUnit: "ms" }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.rgbSingle }, cie: { states: [{ role: /^level\.color\.cie$/, indicator: false, type: e.StateType.String, write: true, name: "CIE", required: true, defaultRole: "level.color.cie" }, { role: /^level\.dimmer$/, indicator: false, type: e.StateType.Number, write: true, name: "DIMMER", required: false, defaultRole: "level.dimmer", defaultUnit: "%" }, { role: /^level\.brightness$/, indicator: false, type: e.StateType.Number, write: true, name: "BRIGHTNESS", required: false, defaultUnit: "%" }, { role: /^level\.color\.temperature$/, indicator: false, type: e.StateType.Number, write: true, name: "TEMPERATURE", required: false, defaultRole: "level.color.temperature", defaultUnit: "\xB0K" }, { role: /^switch(\.light)?$/, indicator: false, type: e.StateType.Boolean, write: true, name: "ON", required: false, defaultRole: "switch.light" }, { role: /^(state|switch|sensor)\.light|switch$/, indicator: false, type: e.StateType.Boolean, write: false, name: "ON_ACTUAL", required: false, defaultRole: "sensor.light", ignoreRole: p }, { role: /^time\.(span|interval)$/, indicator: false, type: e.StateType.Number, write: true, name: "TRANSITION_TIME", required: false, defaultRole: "time.span", defaultUnit: "ms" }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.cie }, hue: { states: [{ role: /^level\.color\.hue$/, indicator: false, type: e.StateType.Number, write: true, name: "HUE", required: true, defaultRole: "level.color.hue", defaultUnit: "\xB0" }, { role: /^level\.dimmer$/, indicator: false, type: e.StateType.Number, write: true, name: "DIMMER", required: false, searchInParent: true, defaultRole: "level.dimmer", defaultUnit: "%" }, { role: /^level\.brightness$/, indicator: false, type: e.StateType.Number, write: true, name: "BRIGHTNESS", required: false }, { role: /^level\.color\.saturation$/, indicator: false, type: e.StateType.Number, write: true, name: "SATURATION", required: false, defaultRole: "level.color.saturation", defaultUnit: "%" }, { role: /^level\.color\.temperature$/, indicator: false, type: e.StateType.Number, write: true, name: "TEMPERATURE", required: false, defaultRole: "level.color.temperature", defaultUnit: "\xB0K" }, { role: /^switch(\.light)?$/, indicator: false, type: e.StateType.Boolean, write: true, name: "ON", required: false, defaultRole: "switch.light" }, { role: /^(state|switch|sensor)\.light|switch$/, indicator: false, type: e.StateType.Boolean, write: false, name: "ON_ACTUAL", required: false, defaultRole: "sensor.light", ignoreRole: p }, { role: /^time\.(span|interval)$/, indicator: false, type: e.StateType.Number, write: true, name: "TRANSITION_TIME", required: false, defaultRole: "time.span", defaultUnit: "ms" }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.hue }, ct: { states: [{ role: /^level\.color\.temperature$/, indicator: false, type: e.StateType.Number, write: true, name: "TEMPERATURE", required: true, defaultRole: "level.color.temperature", defaultUnit: "\xB0K" }, { role: /^level\.dimmer$/, indicator: false, type: e.StateType.Number, write: true, name: "DIMMER", required: false, defaultRole: "level.dimmer", defaultUnit: "%" }, { role: /^level\.brightness$/, indicator: false, type: e.StateType.Number, write: true, name: "BRIGHTNESS", required: false }, { role: /^switch(\.light)?$/, indicator: false, type: e.StateType.Boolean, write: true, name: "ON", required: false, defaultRole: "switch.light" }, { role: /^(state|switch|sensor)\.light|switch$/, indicator: false, type: e.StateType.Boolean, write: false, name: "ON_ACTUAL", required: false, defaultRole: "sensor.light", ignoreRole: p }, { role: /^time\.(span|interval)$/, indicator: false, type: e.StateType.Number, write: true, name: "TRANSITION_TIME", required: false, defaultRole: "time.span", defaultUnit: "ms" }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.ct }, warning: { states: [{ role: /^value\.warning$/, indicator: false, name: "LEVEL", required: true, defaultRole: "value.warning" }, { role: /^weather\.title\.short$/, indicator: false, type: e.StateType.String, name: "TITLE", required: false, defaultRole: "weather.title.short" }, { role: /^weather\.title$/, indicator: false, type: e.StateType.String, name: "INFO", required: false, defaultRole: "weather.title" }, { role: /^date\.start$/, indicator: false, type: e.StateType.String, name: "START", required: false, defaultRole: "date.start" }, { role: /^date\.end$/, indicator: false, type: e.StateType.String, name: "END", required: false, defaultRole: "date.end" }, { role: /^date$/, indicator: false, type: e.StateType.String, name: "START", required: false }, { role: /^weather\.chart\.url/, indicator: false, type: e.StateType.String, name: "ICON", required: false, defaultRole: "weather.chart.url" }, { role: /^weather\.state$/, indicator: false, type: e.StateType.String, name: "DESC", required: false, noSubscribe: true, defaultRole: "weather.state" }], type: e.Types.warning }, airCondition: { states: [{ role: /temperature(\..*)?$/, indicator: false, write: true, type: e.StateType.Number, name: "SET", required: true, defaultRole: "level.temperature", defaultUnit: "\xB0C", ignoreRole: p }, { role: /(level\.mode\.)?airconditioner$/, indicator: false, write: true, type: e.StateType.Number, searchInParent: true, name: "MODE", required: true, defaultRole: "level.mode.airconditioner", defaultStates: { 0: "AUTO", 3: "COOL", 4: "DRY", 5: "ECO", 6: "FAN_ONLY", 7: "HEAT", 8: "OFF" }, ignoreRole: p }, { role: /(speed|mode)\.fan$/, indicator: false, write: true, type: e.StateType.Number, name: "SPEED", required: false, defaultRole: "level.mode.fan", defaultStates: { 0: "AUTO", 1: "HIGH", 2: "LOW", 3: "MEDIUM", 4: "QUIET", 5: "TURBO" }, ignoreRole: p }, { role: /^switch(\.power)?$/, indicator: false, write: true, type: [e.StateType.Boolean, e.StateType.Number], searchInParent: true, name: "POWER", required: false, defaultRole: "switch.power" }, { role: /temperature(\..*)?$/, indicator: false, write: false, type: e.StateType.Number, searchInParent: true, name: "ACTUAL", required: false, defaultRole: "value.temperature", defaultUnit: "\xB0C", ignoreRole: p }, { role: /humidity(\..*)?$/, indicator: false, write: false, type: e.StateType.Number, searchInParent: true, name: "HUMIDITY", required: false, defaultRole: "value.humidity", defaultUnit: "%", ignoreRole: p }, { role: /^switch\.boost(\..*)?$/, indicator: false, write: true, type: [e.StateType.Boolean, e.StateType.Number], searchInParent: true, name: "BOOST", required: false, defaultRole: "switch.boost" }, { role: /swing$/, indicator: false, write: true, type: e.StateType.Number, searchInParent: true, name: "SWING", required: false, defaultRole: "level.mode.swing", defaultStates: { 0: "AUTO", 1: "HORIZONTAL", 2: "STATIONARY", 3: "VERTICAL" }, ignoreRole: p }, { role: /swing$/, indicator: false, write: true, type: e.StateType.Boolean, searchInParent: true, name: "SWING", required: false, defaultRole: "switch.mode.swing", ignoreRole: p }, ...Object.values(O), t.unreach, t.maintain, t.error], type: e.Types.airCondition }, thermostat: { states: [{ role: /temperature(\..*)?$/, indicator: false, write: true, type: e.StateType.Number, name: "SET", required: true, defaultRole: "level.temperature", defaultUnit: "\xB0C", ignoreRole: p }, { role: /temperature(\..*)?$/, indicator: false, write: false, type: e.StateType.Number, searchInParent: true, name: "ACTUAL", required: false, defaultRole: "value.temperature", defaultUnit: "\xB0C", ignoreRole: p }, { role: /humidity(\..*)?$/, indicator: false, write: false, type: e.StateType.Number, searchInParent: true, name: "HUMIDITY", required: false, defaultRole: "value.humidity", defaultUnit: "%", ignoreRole: p }, { role: /^switch(\.mode)?\.boost(\..*)?$/, indicator: false, write: true, type: [e.StateType.Boolean, e.StateType.Number], searchInParent: true, name: "BOOST", required: false, defaultRole: "switch.mode.boost" }, { role: /^switch(\.power)?$/, indicator: false, write: true, type: [e.StateType.Boolean, e.StateType.Number], searchInParent: true, name: "POWER", required: false, defaultRole: "switch.power" }, { role: /^switch(\.mode)?\.party$/, indicator: false, write: true, type: [e.StateType.Boolean, e.StateType.Number], searchInParent: true, name: "PARTY", required: false, defaultRole: "switch.mode.party" }, { role: /^level(\.mode)?\.thermostat$/, indicator: false, write: true, type: e.StateType.Number, searchInParent: true, name: "MODE", required: false, defaultRole: "level.mode.thermostat", defaultStates: { 0: "AUTO", 1: "MANUAL" } }, t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.thermostat }, vacuumCleaner: { states: [{ role: /^switch\.power$/, indicator: false, write: true, type: [e.StateType.Boolean, e.StateType.Number], searchInParent: true, name: "POWER", required: true, defaultRole: "switch.power" }, { role: /mode\.cleanup$/, indicator: false, write: true, type: e.StateType.Number, searchInParent: true, name: "MODE", required: true, defaultRole: "level.mode.cleanup", defaultStates: { 0: "AUTO", 1: "NORMAL", 2: "QUIET", 3: "ECO", 4: "EXPRESS" }, ignoreRole: p }, { role: /vacuum\.map\.base64$/, indicator: false, write: false, type: e.StateType.String, searchInParent: true, name: "MAP_BASE64", required: false, defaultRole: "vacuum.map.base64", ignoreRole: p }, { role: /vacuum\.map\.url$/, indicator: false, write: false, type: e.StateType.String, searchInParent: true, name: "MAP_URL", required: false, ignoreRole: p }, { role: /mode\.work$/, indicator: false, write: true, type: e.StateType.Number, searchInParent: true, name: "WORK_MODE", required: false, defaultRole: "level.mode.work", defaultStates: { 0: "AUTO", 1: "FAST", 2: "MEDIUM", 3: "SLOW", 4: "TURBO" }, ignoreRole: p }, { role: /^value\.water$/, indicator: false, write: false, type: e.StateType.Number, searchInParent: true, unit: "%", name: "WATER", required: false, defaultRole: "value.water", defaultUnit: "%" }, { role: /^value\.waste$/, indicator: false, write: false, type: e.StateType.Number, searchInParent: true, unit: "%", name: "WASTE", required: false, defaultRole: "value.waste", defaultUnit: "%" }, { role: /^value\.battery$/, indicator: false, write: false, type: e.StateType.Number, searchInParent: true, unit: "%", name: "BATTERY", required: false, defaultRole: "value.battery", defaultUnit: "%" }, { role: /^value\.state$/, indicator: false, write: false, type: [e.StateType.Number, e.StateType.String], searchInParent: true, name: "STATE", required: false, defaultRole: "value.state" }, { role: /^switch\.pause$/, indicator: false, write: true, type: e.StateType.Boolean, searchInParent: true, name: "PAUSE", required: false, defaultRole: "switch.pause" }, { role: /^indicator(\.maintenance)?\.waste$|^indicator(\.alarm)?\.waste/, indicator: true, type: e.StateType.Boolean, searchInParent: true, name: "WASTE_ALARM", required: false, defaultRole: "indicator.maintenance.waste" }, { role: /^indicator(\.maintenance)?\.water$|^indicator(\.alarm)?\.water/, indicator: true, type: e.StateType.Boolean, searchInParent: true, name: "WATER_ALARM", required: false, defaultRole: "indicator.maintenance.water" }, { role: /^value(\.usage)?\.filter/, indicator: true, type: e.StateType.Number, searchInParent: true, name: "FILTER", required: false, defaultRole: "value.usage.filter", defaultUnit: "%" }, { role: /^value(\.usage)?\.brush/, indicator: true, type: e.StateType.Number, searchInParent: true, name: "BRUSH", required: false, defaultRole: "value.usage.brush", defaultUnit: "%" }, { role: /^value(\.usage)?\.sensors/, indicator: true, type: e.StateType.Number, searchInParent: true, name: "SENSORS", required: false, defaultRole: "value.usage.sensors", defaultUnit: "%" }, { role: /^value(\.usage)?\.brush\.side/, indicator: true, type: e.StateType.Number, searchInParent: true, name: "SIDE_BRUSH", required: false, defaultRole: "value.usage.brush.side", defaultUnit: "%" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.vacuumCleaner }, blinds: { states: [{ role: /^level(\.blind)?$/, indicator: false, type: e.StateType.Number, write: true, enums: m.roleOrEnumBlind, name: "SET", required: true, defaultRole: "level.blind", defaultUnit: "%" }, { role: /^value(\.blind)?$/, indicator: false, type: e.StateType.Number, enums: m.roleOrEnumBlind, name: "ACTUAL", required: false, defaultRole: "value.blind", defaultUnit: "%" }, { role: /^(button|action)\.stop(\.blind)?$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "STOP", required: false, noSubscribe: true, defaultRole: "button.stop.blind" }, { role: /^(button|action)\.open(\.blind)?$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "OPEN", required: false, noSubscribe: true, defaultRole: "button.open.blind" }, { role: /^(button|action)\.close(\.blind)?$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "CLOSE", required: false, noSubscribe: true, defaultRole: "button.close.blind" }, { role: /^level(\.open)?\.tilt$/, indicator: false, type: e.StateType.Number, write: true, enums: m.roleOrEnumBlind, name: "TILT_SET", required: false, defaultRole: "level.tilt" }, { role: /^value(\.open)?\.tilt$/, indicator: false, type: e.StateType.Number, enums: m.roleOrEnumBlind, name: "TILT_ACTUAL", required: false, defaultRole: "value.tilt" }, { role: /^(button|action)\.stop\.tilt$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "TILT_STOP", required: false, noSubscribe: true, defaultRole: "button.stop.tilt" }, { role: /^(button|action)\.open\.tilt$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "TILT_OPEN", required: false, noSubscribe: true, defaultRole: "button.open.tilt" }, { role: /^(button|action)\.close\.tilt$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "TILT_CLOSE", required: false, noSubscribe: true, defaultRole: "button.close.tilt" }, t.direction, t.direction_enum, t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.blind }, blindButtons: { states: [{ role: /^(button|action)\.stop(\.blind)?$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "STOP", required: true, noSubscribe: true, defaultRole: "button.stop.blind" }, { role: /^(button|action)\.open(\.blind)?$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "OPEN", required: true, noSubscribe: true, defaultRole: "button.open.blind" }, { role: /^(button|action)\.close(\.blind)?$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "CLOSE", required: true, noSubscribe: true, defaultRole: "button.close.blind" }, { role: /^level\.tilt$/, indicator: false, type: e.StateType.Number, write: true, enums: m.roleOrEnumBlind, name: "TILT_SET", required: false, defaultRole: "level.tilt" }, { role: /^value\.tilt$/, indicator: false, type: e.StateType.Number, enums: m.roleOrEnumBlind, name: "TILT_ACTUAL", required: false, defaultRole: "value.tilt" }, { role: /^(button|action)\.stop\.tilt$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "TILT_STOP", required: false, noSubscribe: true, defaultRole: "button.stop.tilt" }, { role: /^(button|action)\.open\.tilt$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "TILT_OPEN", required: false, noSubscribe: true, defaultRole: "button.open.tilt" }, { role: /^(button|action)\.close\.tilt$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumBlind, name: "TILT_CLOSE", required: false, noSubscribe: true, defaultRole: "button.close.tilt" }, t.direction, t.direction_enum, t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.blindButtons }, gate: { states: [{ role: /^switch(\.gate)?$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumGate, name: "SET", required: true, defaultRole: "switch.gate" }, { role: /^value(\.(position|gate))?$/, indicator: false, type: e.StateType.Number, enums: m.roleOrEnumGate, name: "ACTUAL", required: false, defaultRole: "value.blind", defaultUnit: "%", ignoreRole: p }, { role: /^(button|action)\.stop$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumGate, name: "STOP", required: false, noSubscribe: true, defaultRole: "button.stop" }, t.direction, t.direction_enum, t.working, t.unreach, t.maintain, t.error], type: e.Types.gate }, weatherCurrent: { states: [{ role: /^value(\.temperature)?$/, indicator: false, type: e.StateType.Number, name: "ACTUAL", required: true, defaultRole: "value.temperature", defaultUnit: "\xB0C" }, { role: /^weather\.icon$/, indicator: false, name: "ICON", required: true, defaultRole: "weather.icon" }, { role: /^value\.precipitation\.chance$/, indicator: false, type: e.StateType.Number, name: "PRECIPITATION_CHANCE", defaultRole: "value.precipitation.chance", defaultUnit: "%" }, { role: /^value\.precipitation\.type$/, indicator: false, type: e.StateType.Number, name: "PRECIPITATION_TYPE", defaultRole: "value.precipitation.type", defaultStates: { 0: "NO", 1: "RAIN", 2: "SNOW", 3: "HAIL" } }, { role: /^value\.pressure$/, indicator: false, type: e.StateType.Number, name: "PRESSURE", defaultRole: "value.pressure", defaultUnit: "mbar" }, { role: /^value\.pressure\.tendency$/, indicator: false, type: e.StateType.String, name: "PRESSURE_TENDENCY", defaultRole: "value.pressure.tendency" }, { role: /^value\.temperature\.windchill$/, indicator: false, type: e.StateType.Number, name: "REAL_FEEL_TEMPERATURE", defaultRole: "value.temperature.windchill", defaultUnit: "\xB0C" }, { role: /^value\.humidity$/, indicator: false, type: e.StateType.Number, name: "HUMIDITY", defaultRole: "value.humidity", defaultUnit: "%" }, { role: /^value\.uv$/, indicator: false, type: e.StateType.Number, name: "UV", defaultRole: "value.uv" }, { role: /^weather\.state$/, indicator: false, type: e.StateType.String, name: "WEATHER", defaultRole: "weather.state" }, { role: /^value\.direction\.wind$/, indicator: false, type: e.StateType.String, name: "WIND_DIRECTION", defaultRole: "value.direction.wind", defaultUnit: "\xB0" }, { role: /^value\.speed\.wind\.gust$/, indicator: false, type: e.StateType.Number, name: "WIND_GUST", defaultRole: "value.speed.wind.gust", defaultUnit: "km/h" }, { role: /^value\.speed\.wind$/, indicator: false, type: e.StateType.Number, name: "WIND_SPEED", defaultRole: "value.speed.wind$", defaultUnit: "km/h" }, t.lowbat, t.unreach, t.maintain, t.error, t.battery], type: e.Types.weatherCurrent }, camera: { states: [{ role: /^link\.camera(\.\w+)?$/, indicator: false, type: e.StateType.String, name: "URL", required: true, defaultRole: "link.camera" }, { role: /^switch(\.camera)?\.autofocus$/, indicator: false, type: e.StateType.Boolean, write: true, name: "AUTOFOCUS", required: false, defaultRole: "switch.camera.autofocus" }, { role: /^switch(\.camera)?\.autowhitebalance$/, indicator: false, type: e.StateType.Boolean, write: true, name: "AUTOWHITEBALANCE", required: false, defaultRole: "switch.camera.autowhitebalance" }, { role: /^switch(\.camera)?\.brightness$/, indicator: false, type: e.StateType.Boolean, write: true, name: "BRIGHTNESS", required: false, defaultRole: "switch.camera.brightness" }, { role: /^switch(\.camera)?\.nightmode$/, indicator: false, type: e.StateType.Boolean, write: true, name: "NIGHTMODE", required: false, defaultRole: "switch.camera.nightmode" }, { role: /^level(\.camera)?\.position$|^level(\.camera)?(\.ptz)$/, indicator: false, type: e.StateType.Number, write: true, name: "PTZ", required: false, defaultRole: "level.camera.position" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.camera, enumRequired: false }, lock: { states: [{ role: /^switch\.lock$/, indicator: false, type: e.StateType.Boolean, write: true, name: "SET", required: true, defaultRole: "switch.lock" }, { role: /^state$/, indicator: false, type: e.StateType.Boolean, write: false, name: "ACTUAL", required: false, defaultRole: "state" }, { indicator: false, type: e.StateType.Boolean, write: true, read: false, name: "OPEN", required: false, noSubscribe: true, defaultRole: "button", ignoreRole: p }, { role: /^(state|sensor)(\.door)?$/, indicator: false, type: e.StateType.Boolean, write: false, name: "DOOR_STATE", required: false, defaultRole: "sensor.door", ignoreRole: p }, t.direction, t.direction_enum, t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.lock }, motion: { states: [{ role: /^(state\.)?motion$|^sensor\.motion$/, indicator: false, type: e.StateType.Boolean, name: "ACTUAL", required: true, defaultRole: "sensor.motion", ignoreRole: p }, { role: /brightness$/, indicator: false, type: e.StateType.Number, name: "SECOND", required: false, defaultRole: "value.brightness", defaultUnit: "lux", ignoreRole: p }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.motion }, window: { states: [{ role: /^(state|sensor)(\.window)?/, indicator: false, type: e.StateType.Boolean, enums: m.roleOrEnumWindow, write: false, name: "ACTUAL", required: true, defaultRole: "sensor.window", ignoreRole: p }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.window }, windowTilt: { states: [{ role: /^state$|^value(\.window)?$/, indicator: false, type: e.StateType.Number, write: false, enums: m.roleOrEnumWindow, name: "ACTUAL", required: true, defaultRole: "value.window" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.windowTilt }, fireAlarm: { states: [{ role: /^(state|sensor|indicator)(\.alarm)?\.fire$/, indicator: false, type: e.StateType.Boolean, name: "ACTUAL", required: true, defaultRole: "sensor.alarm.fire", defaultChannelRole: "sensor.alarm.fire" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.fireAlarm, enumRequired: false }, floodAlarm: { states: [{ role: /^(state|sensor|indicator)(\.alarm)?\.flood$/, indicator: false, type: e.StateType.Boolean, name: "ACTUAL", required: true, defaultRole: "sensor.alarm.flood", defaultChannelRole: "sensor.alarm.flood" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.floodAlarm }, door: { states: [{ role: /^(state|sensor)(\.door)?/, indicator: false, type: e.StateType.Boolean, write: false, enums: m.roleOrEnumDoor, name: "ACTUAL", required: true, defaultRole: "sensor.door" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.door }, dimmer: { states: [{ role: /^level(\.dimmer)?$|^level\.brightness$/, indicator: false, type: e.StateType.Number, write: true, enums: m.roleOrEnumLight, name: "SET", required: true, defaultRole: "level.dimmer", ignoreRole: /^level\.dimspeed$/, defaultUnit: "%" }, { role: /^value(\.dimmer)?$/, indicator: false, type: e.StateType.Number, write: false, enums: m.roleOrEnumLight, name: "ACTUAL", required: false, defaultRole: "value.dimmer", defaultUnit: "%" }, { role: /^switch(\.light)?$|^state$/, indicator: false, type: e.StateType.Boolean, write: true, enums: m.roleOrEnumLight, name: "ON_SET", required: false, defaultRole: "switch.light" }, { role: /^(state|switch|sensor)\.light|switch$/, indicator: false, type: e.StateType.Boolean, write: false, enums: m.roleOrEnumLight, name: "ON_ACTUAL", required: false, defaultRole: "sensor.light", ignoreRole: p }, { role: /^time\.(span|interval)$/, indicator: false, type: e.StateType.Number, write: true, enums: m.roleOrEnumLight, name: "TRANSITION_TIME", required: false, defaultRole: "time.span", defaultUnit: "ms" }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.dimmer }, light: { states: [{ role: /^switch(\.light)?$|^state$/, enums: m.roleOrEnumLight, indicator: false, type: e.StateType.Boolean, write: true, name: "SET", required: true, defaultRole: "switch.light" }, { role: /^(state|switch|sensor)\.light|switch$/, indicator: false, type: e.StateType.Boolean, write: false, enums: m.roleOrEnumLight, name: "ON_ACTUAL", required: false, defaultRole: "sensor.light", ignoreRole: p }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.light }, volume: { states: [{ role: /^level\.volume$/, indicator: false, type: e.StateType.Number, min: e.StateType.Number, max: e.StateType.Number, write: true, name: "SET", required: true, defaultRole: "level.volume", defaultUnit: "%" }, { role: /^value\.volume$/, indicator: false, type: e.StateType.Number, min: e.StateType.Number, max: e.StateType.Number, write: false, name: "ACTUAL", required: false, defaultRole: "value.volume", defaultUnit: "%" }, { role: /^media\.mute$/, indicator: false, type: e.StateType.Boolean, write: true, name: "MUTE", required: false, defaultRole: "media.mute" }, t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.volume }, locationOne: { states: [{ role: /^value\.gps$/, indicator: false, type: e.StateType.String, write: false, name: "GPS", required: true, defaultRole: "value.gps" }, { role: /^value\.gps\.elevation$/, indicator: false, type: e.StateType.Number, write: false, name: "ELEVATION", required: false, defaultRole: "value.gps.elevation" }, { role: /^value(\.gps)?\.radius$/, indicator: false, type: e.StateType.Number, write: false, name: "RADIUS", required: false, defaultRole: "value.gps.radius" }, { role: /^value(\.gps)?\.accuracy$/, indicator: false, type: e.StateType.Number, write: false, name: "ACCURACY", required: false, defaultRole: "value.gps.accuracy" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.locationOne }, location: { states: [{ role: /^value(\.gps)?\.longitude$/, indicator: false, type: e.StateType.Number, write: false, name: "LONGITUDE", required: true, defaultRole: "value.gps.longitude", defaultUnit: "\xB0" }, { role: /^value(\.gps)?\.latitude$/, indicator: false, type: e.StateType.Number, write: false, name: "LATITUDE", required: true, defaultRole: "value.gps.latitude", defaultUnit: "\xB0" }, { role: /^value(\.gps)?\.elevation$/, indicator: false, type: e.StateType.Number, write: false, name: "ELEVATION", required: false, defaultRole: "value.gps.elevation" }, { role: /^value(\.gps)?\.radius$/, indicator: false, type: e.StateType.Number, write: false, name: "RADIUS", required: false, defaultRole: "value.gps.radius" }, { role: /^value(\.gps)?\.accuracy$/, indicator: false, type: e.StateType.Number, write: false, name: "ACCURACY", required: false, defaultRole: "value.gps.accuracy" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.location }, volumeGroup: { states: [{ role: /^level\.volume\.group?$/, indicator: false, type: e.StateType.Number, min: e.StateType.Number, max: e.StateType.Number, write: true, name: "SET", required: true, defaultRole: "level.volume.group", defaultUnit: "%" }, { role: /^value\.volume\.group$/, indicator: false, type: e.StateType.Number, min: e.StateType.Number, max: e.StateType.Number, write: false, name: "ACTUAL", required: false, defaultRole: "value.volume.group", defaultUnit: "%" }, { role: /^media\.mute\.group$/, indicator: false, type: e.StateType.Boolean, write: true, name: "MUTE", required: false, defaultRole: "media.mute.group" }, t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.volumeGroup }, levelSlider: { states: [{ role: /^level(\..*)?$/, indicator: false, type: e.StateType.Number, min: e.StateType.Number, max: e.StateType.Number, write: true, name: "SET", required: true, defaultRole: "level", defaultUnit: "%", ignoreRole: p }, { role: /^value(\..*)?$/, indicator: false, type: e.StateType.Number, min: e.StateType.Number, max: e.StateType.Number, write: false, name: "ACTUAL", required: false, defaultRole: "value", defaultUnit: "%", ignoreRole: p }, t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.slider }, socket: { states: [{ role: /^switch(\.active)?$|^state$/, indicator: false, type: e.StateType.Boolean, write: true, name: "SET", required: true, defaultRole: "switch" }, { role: /^state(\.active)?$/, indicator: false, type: e.StateType.Boolean, write: false, name: "ACTUAL", required: false, defaultRole: "sensor.switch" }, ...Object.values(O), t.working, t.unreach, t.lowbat, t.maintain, t.error], type: e.Types.socket }, button: { states: [{ role: /^(button|action)(\.[.\w]+)?$/, indicator: false, type: e.StateType.Boolean, read: false, write: true, name: "SET", required: true, noSubscribe: true, defaultRole: "button" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.button }, buttonSensor: { states: [{ role: /^button(\.[.\w]+)?$/, indicator: false, type: e.StateType.Boolean, read: true, write: false, name: "PRESS", required: true, defaultRole: "button.press" }, { role: /^button\.long/, indicator: false, type: e.StateType.Boolean, read: true, write: false, name: "PRESS_LONG", required: false, defaultRole: "button.long" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.buttonSensor }, temperature: { states: [{ role: /\.temperature$/, indicator: false, write: false, type: e.StateType.Number, name: "ACTUAL", required: true, defaultRole: "value.temperature", defaultUnit: "\xB0C" }, { role: /\.humidity$/, indicator: false, write: false, type: e.StateType.Number, name: "SECOND", required: false, defaultRole: "value.humidity", defaultUnit: "%" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.temperature }, humidity: { states: [{ role: /\.humidity$/, indicator: false, write: false, type: e.StateType.Number, name: "ACTUAL", required: true, defaultRole: "value.humidity", defaultUnit: "%" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.humidity }, illuminance: { states: [{ role: /\.brightness$/, indicator: false, write: false, type: e.StateType.Number, name: "ACTUAL", required: true, defaultRole: "value.brightness", defaultUnit: "lux" }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.illuminance }, image: { states: [{ role: /\.icon$|^icon$|^icon\.|\.icon\.|\.chart\.url\.|\.chart\.url$|^url.icon$/, indicator: false, write: false, type: e.StateType.String, name: "URL", defaultRole: "icon", required: true, ignoreRole: p }, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.image }, info: { states: [{ indicator: false, name: "ACTUAL", required: true, multiple: true, noDeviceDetection: true, ignoreRole: /\.inhibit$/, defaultRole: "state" }, t.working, t.unreach, t.lowbat, t.maintain, t.error, t.battery], type: e.Types.info } };
Object.defineProperty(W, "__esModule", { value: true });
W.ChannelDetector = void 0;
const A = B, U = R, _ = H;
class N {
  constructor() {
    this.enums = null, this.cache = {};
  }
  _applyPattern(r, a, l, o, u) {
    var n, s;
    if (!((n = r[a]) === null || n === void 0) && n.common) {
      let d = null;
      if (l.role && (d = l.role.test(r[a].common.role || ""), d && l.channelRole)) {
        const S = (0, U.getParentId)(a), w = ((s = r[S]) === null || s === void 0 ? void 0 : s.common.role) || "";
        w && (r[S].type === "channel" || r[S].type === "device") ? d = l.channelRole.test(w) : d = false;
      }
      if (d === false) return false;
      if (l.type) {
        if (typeof l.type == "string") {
          if (l.type !== r[a].common.type) return false;
        } else if (Array.isArray(l.type)) {
          let S = false;
          for (let w = 0; w < l.type.length; w++) if (l.type[w] === r[a].common.type) {
            S = true;
            break;
          }
          if (!S) return false;
        }
      }
      if (l.objectType && r[a].type !== l.objectType || l.stateName && !l.stateName.test(a) || l.unit && l.unit !== r[a].common.unit) return false;
      if (l.ignoreRole) {
        const S = r[a].common.role || "";
        if (S && l.ignoreRole.test(S)) return false;
      }
      if (l.indicator === false && (r[a].common.role || "").match(/^indicator(\.[.\w]+)?$/)) return false;
      if (l.state) {
        const S = a.split(".").pop() || "";
        if (S && !l.state.test(S)) return false;
      }
      const v = l.defaultRole && r[a].common.role === l.defaultRole, T = l.defaultUnit ? r[a].common.unit === l.defaultUnit : false;
      if (l.min === A.StateType.Number && typeof r[a].common.min !== A.StateType.Number && (!T || r[a].common.unit !== "%") || l.max === A.StateType.Number && typeof r[a].common.max !== A.StateType.Number && (!T || r[a].common.unit !== "%")) return false;
      if (!v) {
        if (l.write !== void 0 && l.write !== !!r[a].common.write || l.read !== void 0 && l.read !== (r[a].common.read === void 0 ? true : r[a].common.read)) return false;
        if (typeof l.enums == "function") {
          const S = this._getEnumsForId(r, a, u);
          if (!o && !l.enums(r[a], S || [])) return false;
        }
      }
      return true;
    }
    return false;
  }
  _getEnumsForId(r, a, l) {
    var o;
    this.enums || (this.enums = (0, U.getFunctionEnums)(r, l));
    const u = [];
    if (this.enums.forEach((n) => {
      r[n].common.members.includes(a) && u.push(n);
    }), !u.length && ((o = r[a]) === null || o === void 0 ? void 0 : o.type) === "state") {
      const n = (0, U.getParentId)(a);
      r[n] && (r[n].type === "channel" || r[n].type === "device") && this.enums.forEach((s) => {
        r[s].common.members.includes(n) && u.push(s);
      });
    }
    return u.length ? u : null;
  }
  static copyState(r, a) {
    const l = a || JSON.parse(JSON.stringify(r));
    return l.original = r.original || r, "enums" in r && r.enums && (l.enums = r.enums), "role" in r && r.role && (l.role = r.role), "channelRole" in r && r.channelRole && (l.channelRole = r.channelRole), l;
  }
  _testOneState(r) {
    var a, l, o, u, n, s;
    const d = r.objects, v = r.pattern, T = r.state, S = r.channelStates, w = r.usedIds, g = r.usedInCurrentDevice, I = r.ignoreIndicators, C = r.ignoreEnums, D = r.sortedKeys;
    let c = r.result, $ = false;
    for (const y of S) if (!(T.name === "COVER" && (c == null ? void 0 : c.states.find((b) => b.id && b.name === "COVER")))) {
      if (T.indicator && I) {
        const f = y.split(".").pop() || "";
        if (f && I.includes(f)) continue;
      }
      if (!T.indicator) {
        if (g.includes(y)) continue;
        if (!T.notSingle) {
          if (!r.detectAllPossibleDevices) {
            if (w.includes(y)) continue;
          }
        }
      }
      if (this._applyPattern(d, y, T, C, D)) {
        if (c || (c = JSON.parse(JSON.stringify(_.patterns[v])), r.result = c, c == null ? void 0 : c.states.forEach((b, f) => N.copyState(_.patterns[v].states[f], b))), c.states.find(({ id: b }) => b === y)) $ = true;
        else for (const b of c.states) if (b.name === T.name) {
          if (b.id) {
            let f;
            r.favorId && (y === r.favorId ? f = true : b.id === r.favorId && (f = false));
            const P = (o = (l = (a = d[b.id]) === null || a === void 0 ? void 0 : a.common) === null || l === void 0 ? void 0 : l.role) !== null && o !== void 0 ? o : "", h = (s = (n = (u = d[y]) === null || u === void 0 ? void 0 : u.common) === null || n === void 0 ? void 0 : n.role) !== null && s !== void 0 ? s : "", E = b.defaultRole;
            if (E && f === void 0 && (h === E ? f = true : P === E && (f = false)), f === void 0) {
              const q = h.split("."), M = q.length, G = P.split("."), F = G.length;
              h === "" || q[0] === "state" && G[0] !== "state" ? f = false : q[0] !== "state" && G[0] === "state" || M > F ? f = true : M < F ? f = false : f = q[0] !== "state";
            }
            if (!f) break;
          }
          b.id = y, $ = true;
          break;
        }
        if ($ && (T.indicator || g.push(y), T.multiple && S.length > 1)) {
          for (const b of S) if (b !== y && (T.indicator || !g.includes(b) && (T.notSingle || !w.includes(b))) && this._applyPattern(d, b, T, C, D)) if (T.indicator || g.push(b), Array.isArray(T)) {
            const f = N.copyState(T[0]);
            f.id = b, c.states.push(f);
          } else {
            const f = N.copyState(T);
            f.id = b, c.states.push(f);
          }
        }
      }
    }
    return $;
  }
  static findParentChannelOrDevice(r, a, l) {
    if (!r[a]) return;
    const o = a.split("."), u = a;
    if (r[a].type === "state" && (o.pop(), a = o.join(".")), o.length <= 2) return a;
    const n = r[a];
    if ((n == null ? void 0 : n.type) === "device" || l && (n == null ? void 0 : n.type) === "channel") return a;
    if (l) return;
    o.pop();
    const s = o.join("."), d = r[s];
    if (!d) return n ? a : u;
    if (d.type === "device" || o.length <= 2) return s;
    if ((n == null ? void 0 : n.type) === "channel") return a;
    o.pop();
    const v = o.join("."), T = r[v];
    return !T || T.type !== "device" && T.type !== "channel" ? s : v;
  }
  static getChannelOrDeviceStates(r, a, l, o = false, u = false) {
    var n;
    const s = (n = r[a]) === null || n === void 0 ? void 0 : n.type;
    switch (s) {
      case void 0:
        return [...(0, U.getObjectsBelowId)(l, a)];
      case "state":
      case "channel":
      case "device":
      case "folder":
        if (o && s !== "device") {
          const d = N.findParentChannelOrDevice(r, a);
          return d && d !== a ? [...(0, U.getObjectsBelowId)(l, d)] : [a];
        }
        if (s !== "state") return [...(0, U.getObjectsBelowId)(l, a)];
        if (u) {
          const d = N.findParentChannelOrDevice(r, a, true);
          return d && d !== a ? [...(0, U.getObjectsBelowId)(l, d)] : [a];
        }
        return [a];
      default:
        return [a];
    }
  }
  static patternIsAllowed(r, a, l) {
    if (!r) return false;
    if (Array.isArray(r.type)) {
      for (let o = 0; o < r.type.length; o++) if (a && !a.includes(r.type[o]) || l && l.includes(r.type[o])) return false;
      return true;
    }
    return a && !a.includes(r.type) ? false : !l || !l.includes(r.type);
  }
  static allRequiredStatesFound(r) {
    if (!r.result) return false;
    const a = r.result.states;
    for (let l = 0; l < a.length; l++) if (a[l].required && !a[l].id) return false;
    return true;
  }
  static cleanState(r, a) {
    var l, o;
    const u = ((o = (l = a[r.id]) === null || l === void 0 ? void 0 : l.common) === null || o === void 0 ? void 0 : o.role) || "";
    if (r.name.includes("%d") && r.role && r.id && u) {
      const n = r.role.exec(u);
      n && (r.name = r.name.replace("%d", n[1]));
    }
    r.role && delete r.role, r.enums && delete r.enums, r.original && delete r.original;
  }
  sortTypes(r, a) {
    return a.forEach(([l, o]) => {
      const u = r.indexOf(l), n = r.indexOf(o);
      if (u === -1 || n === -1) return;
      const s = r.splice(u, 1);
      r.splice(n, 0, ...s);
    }), r;
  }
  _detectNext(r) {
    var a, l, o, u;
    const { objects: n, id: s, _usedIdsOptional: d = [], ignoreIndicators: v, prioritizedTypes: T, detectParent: S, detectOnlyChannel: w, allowedTypes: g, excludedTypes: I, _keysOptional: C, detectAllPossibleDevices: D } = r;
    let { _patternList: c } = r;
    r._usedIdsOptional = d;
    const $ = N.getChannelOrDeviceStates(n, s, C || [], S, w);
    if (!(!((a = n[s]) === null || a === void 0) && a.common) && !$.length) return null;
    if ((l = r._checkedPatterns) !== null && l !== void 0 || (r._checkedPatterns = []), !c) {
      const f = Object.keys(_.patterns).filter((P) => N.patternIsAllowed(_.patterns[P], g, I));
      c = T ? this.sortTypes(f, T) : f, r._patternList = c;
    }
    const y = { objects: n, channelStates: $, usedIds: d, ignoreIndicators: v || [], pattern: "unknown", usedInCurrentDevice: [], state: {}, ignoreEnums: !!r.ignoreEnums, sortedKeys: C, favorId: r.detectParent ? void 0 : s, detectAllPossibleDevices: D }, b = (o = n[s]) === null || o === void 0 ? void 0 : o.type;
    for (const f of c) {
      if (r._checkedPatterns.includes(f)) continue;
      r._checkedPatterns.push(f), delete y.result, y.pattern = f, y.usedInCurrentDevice = [];
      for (const h of _.patterns[f].states) {
        let E = false;
        if (y.state = h, this._testOneState(y) && (E = true), h.required && !E) {
          delete y.result;
          break;
        }
      }
      if (!N.allRequiredStatesFound(y)) continue;
      y.usedInCurrentDevice.forEach((h) => d.push(h));
      let P;
      if (b !== "device") {
        const h = (u = N.findParentChannelOrDevice(n, s)) !== null && u !== void 0 ? u : s;
        if (n[h] && (n[h].type === "channel" || n[h].type === "device")) {
          P = (0, U.getObjectsBelowId)(C, h);
          for (const E of P) y.result.states.forEach((q, M) => {
            !q.id && (q.indicator || q.searchInParent) && !q.noDeviceDetection && this._applyPattern(n, E, q.original, !!r.ignoreEnums, y.sortedKeys) && y.result && (y.result.states[M].id = E);
          });
        }
      }
      if (y.result.states.forEach((h) => N.cleanState(h, y.objects)), r.limitTypesToOneOf) {
        for (const h of r.limitTypesToOneOf) if (h.includes(f)) for (const E of h) E === f || r._checkedPatterns.includes(E) || r._checkedPatterns.push(E);
      }
      return y.result;
    }
    return null;
  }
  detect(r) {
    var a;
    const { objects: l, id: o, ignoreCache: u, detectAllPossibleDevices: n } = r;
    let { _keysOptional: s, _usedIdsOptional: d } = r;
    if (!u && this.cache[o]) {
      const { allowedTypes: S = [], excludedTypes: w = [] } = r;
      if (!S.length && !w.length) return this.cache[o];
      const g = this.cache[o].filter(({ type: I }) => S.includes(I) && !w.includes(I));
      if (g.length) return g;
    }
    s ? r._keysOptionalSorted || s.sort() : (s = Object.keys(l), s.sort(), r._keysOptional = s), d && !r.detectParent && (d = [], r._usedIdsOptional = d), r.ignoreEnums === void 0 && ((a = r.allowedTypes) === null || a === void 0 ? void 0 : a.length) === 1 && (r.ignoreEnums = true), n && (r.excludedTypes || (r.excludedTypes = []), r.excludedTypes.includes(A.Types.info) || r.excludedTypes.push(A.Types.info)), r._checkedPatterns = [];
    const v = [];
    let T;
    for (; T = this._detectNext(r); ) v.push(T), r.detectAllPossibleDevices && (r._usedIdsOptional = []);
    return v.sort((S, w) => {
      if (S.type === A.Types.info && w.type !== A.Types.info) return 1;
      if (w.type === A.Types.info && S.type !== A.Types.info) return -1;
      const g = S.states.find((c) => c.id === o && c.required) ? 1 : 0, I = w.states.find((c) => c.id === o && c.required) ? 1 : 0;
      if (g !== I) return I - g;
      if (!g) {
        const c = S.states.find((y) => y.id === o) ? 1 : 0, $ = w.states.find((y) => y.id === o) ? 1 : 0;
        if (c !== $) return $ - c;
      }
      const C = S.states.filter((c) => c.id).length;
      return w.states.filter((c) => c.id).length - C;
    }), this.cache[o] = v.length ? v : null, this.cache[o];
  }
  static getPatterns() {
    const r = {};
    return Object.keys(_.patterns).forEach((a) => {
      const l = JSON.parse(JSON.stringify(_.patterns[a]));
      l.states.forEach((o, u) => {
        const n = _.patterns[a].states[u];
        n.role && (l.states[u].role = n.role.toString()), n.enums && (l.states[u].enums = true);
      }), r[a] = l;
    }), r;
  }
}
W.ChannelDetector = N;
N.getEnums = U.getEnums;
(function(i) {
  Object.defineProperty(i, "__esModule", { value: true }), i.StateType = i.Types = void 0;
  const r = W;
  i.default = r.ChannelDetector;
  var a = B;
  Object.defineProperty(i, "Types", { enumerable: true, get: function() {
    return a.Types;
  } }), Object.defineProperty(i, "StateType", { enumerable: true, get: function() {
    return a.StateType;
  } });
})(re);
export {
  re as t
};
