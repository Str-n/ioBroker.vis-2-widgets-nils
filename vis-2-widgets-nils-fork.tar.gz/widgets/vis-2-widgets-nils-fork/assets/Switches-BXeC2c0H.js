import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { B as t, g as n } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { B as r, C as i, D as a, E as o, F as s, H as c, I as l, J as u, L as d, M as f, O as ee, P as p, Q as m, T as h, U as g, W as _, Y as v, Z as te, a as ne, d as y, dt as b, f as re, ft as x, g as S, k as ie, n as C, p as w, pt as T, st as ae, u as oe } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as se } from "./Backspace-CRhYnPpV.js";
import { n as ce, t as le } from "./ElectricBolt-jdviczbv.js";
import { n as ue, r as de, t as fe } from "./WindowClosed-Di23zk5M.js";
import { t as E } from "./Lightbulb-BbGK3Qf2.js";
import { t as D } from "./LightbulbOutlined-_xkblzYe.js";
import { a as O, i as k, n as pe, r as me, t as he } from "./LockIcon-BaqJjXJa.js";
import { t as A } from "./PowerSettingsNew-BNxDRF4G.js";
import { t as j } from "./Thermostat-XvI2VZ3I.js";
import { Vn as M, i as N, n as P, o as F, r as I, t as L } from "./installSVGRenderer-DpsPSOBw.js";
import { t as R } from "./Generic-BOiMPpxz.js";
import { RGB_NAMES as z, RGB_ROLES as B, a as V, c as ge, colorTemperatureToRGB as H, d as _e, f as ve, i as ye, l as be, n as xe, o as Se, p as U, r as Ce, s as W, t as we, u as Te } from "./RGBLight-B5teopid.js";
import { t as Ee } from "./dist-nezUW2fm.js";
import { FanIcon as De, VACUUM_CHARGING_STATES as G, VACUUM_CLEANING_STATES as Oe, VACUUM_ID_ROLES as K, VACUUM_PAUSE_STATES as ke, a as Ae, i as je, n as Me, o as Ne, r as q, t as J, vacuumGetStatusColor as Y } from "./Vacuum-Bge0udXM.js";
var X = ae(x(`path`, { d: `M2 17h20v2H2zm11.84-9.21c.1-.24.16-.51.16-.79 0-1.1-.9-2-2-2s-2 .9-2 2c0 .28.06.55.16.79C6.25 8.6 3.27 11.93 3 16h18c-.27-4.07-3.25-7.4-7.16-8.21` }), `RoomService`);
t();
var Pe = e(M(), 1);
function Fe() {
  return T(`svg`, { viewBox: `0 0 24 24`, xmlns: `http://www.w3.org/2000/svg`, children: [x(`path`, { strokeWidth: `1`, fill: `none`, strokeLinejoin: `round`, strokeLinecap: `round`, stroke: `currentColor`, d: `M21 12a9 9 0 1 1 -18 0a9 9 0 0 1 18 0z` }), x(`path`, { strokeWidth: `1`, fill: `none`, strokeLinejoin: `round`, strokeLinecap: `round`, stroke: `currentColor`, d: `M14 9a2 2 0 1 1 -4 0a2 2 0 0 1 4 0z` }), x(`path`, { strokeWidth: `2`, fill: `none`, strokeLinejoin: `round`, strokeLinecap: `round`, stroke: `currentColor`, d: `M12 16h.01` })] });
}
var Ie = [`influxdb`, `sql`, `history`];
F([P, I, L]);
async function Z(e3, t2, n2, r2, i2) {
  var _a;
  if (t2[e3.name] && ((_a = await r2.getObject(t2[e3.name])) == null ? void 0 : _a.common)) {
    let a2 = t2[e3.name].split(`.`);
    a2.pop();
    let o2 = await r2.getObjectViewSystem(`state`, `${a2.join(`.`)}.`, `${a2.join(`.`)}.\u9999`);
    if (o2) {
      let r3 = false;
      Object.values(o2).forEach((n3) => {
        var _a2;
        let a3 = (_a2 = n3.common) == null ? void 0 : _a2.role;
        if (a3 && B[a3] && (!t2[a3] || t2[a3] === `nothing_selected`) && e3.name !== a3 && (r3 = true, B[a3] === `rgb` ? t2[`oid${i2}`] = n3._id : t2[B[a3] + i2] = n3._id, B[a3] === `color_temperature`)) {
          let e4 = n3.common;
          !t2[`ct_min${i2}`] && e4.min && (t2[`ct_min${i2}`] = e4.min), !t2[`ct_max${i2}`] && e4.max && (t2[`ct_max${i2}`] = e4.max);
        }
      }), r3 && n2(t2);
    }
  }
}
var Q = async (e3, t2, n2, r2, i2) => {
  if (t2[e3.name]) {
    let a2 = await r2.getObject(t2[e3.name]);
    if (a2 == null ? void 0 : a2.common) {
      let o2 = a2._id.split(`.`);
      o2.pop();
      let s2 = await r2.getObject(o2.join(`.`));
      if (!s2) return;
      (s2.type === `channel` || s2.type === `folder`) && (o2.pop(), s2 = await r2.getObject(o2.join(`.`))), (!s2 || s2.type !== `device`) && (o2 = a2._id.split(`.`), o2.pop());
      let c2 = await r2.getObjectViewSystem(`state`, `${o2.join(`.`)}.`, `${o2.join(`.`)}.\u9999`);
      if (c2) {
        let r3 = false;
        t2[`type${i2}`] !== `vacuum` && t2[e3.name].startsWith(`mihome-vacuum.`) && (r3 = true, t2[`type${i2}`] = `vacuum`), Object.keys(K).forEach((e4) => {
          t2[`vacuum-${e4}-oid${i2}`] || Object.values(c2).forEach((n3) => {
            var _a;
            if (n3._id.split(`.`).includes(`rooms`)) {
              t2[`vacuum-use-rooms${i2}`] || (r3 = true, t2[`vacuum-use-rooms${i2}`] = true);
              return;
            }
            let a3 = (_a = n3.common) == null ? void 0 : _a.role, o3 = K[e4].role;
            if (o3 && !(a3 == null ? void 0 : a3.includes(o3))) return;
            let s3 = K[e4].name;
            (!s3 || n3._id.split(`.`).pop().toLowerCase().includes(s3)) && (r3 = true, t2[`vacuum-${e4}-oid${i2}`] = n3._id);
          });
        }), r3 && n2(t2);
      }
    }
  }
}, $ = { intermediate: { opacity: 0.2 }, text: { textTransform: `none` }, button: { display: `block`, width: `100%`, overflow: `hidden`, textOverflow: `ellipsis` }, buttonInactive: { opacity: 0.6 }, iconButton: { width: `100%`, height: 40, display: `block`, alignItems: `center`, flexDirection: `column`, justifyContent: `center` }, iconSwitch: { width: 40, height: 40, display: `inline-flex`, alignItems: `center`, justifyContent: `center` }, cardsHolder: { display: `flex`, justifyContent: `space-between`, width: `100%`, alignItems: `center`, gap: 16, position: `relative` }, allButtonsTitle: { display: `flex`, justifyContent: `space-between`, flexWrap: `wrap`, width: `100%`, alignItems: `center` }, buttonDiv: { display: `inline-block`, width: 120, height: 80, textAlign: `center`, position: `relative` }, iconCustom: { maxWidth: 40, maxHeight: 40 }, controlElement: { maxWidth: `50%` }, selectLabel: { top: 12, left: -13 }, widgetContainer: { width: `100%`, height: `100%`, display: `flex`, alignItems: `center`, position: `relative` }, buttonsContainer: { width: `100%`, display: `flex`, justifyContent: `center`, alignItems: `center` }, infoData: { textAlign: `center`, minWidth: 58 }, value: { display: `flex`, justifyContent: `center`, alignItems: `center` }, secondaryValueDiv: { marginLeft: 4, fontSize: `smaller`, opacity: 0.6, whiteSpace: `nowrap` }, secondaryValue: { marginLeft: 4, whiteSpace: `nowrap` }, rgbSliderContainer: { display: `flex`, alignItems: `center`, gap: 12, width: `100%` }, rgbDialogContainer: { display: `flex`, flexDirection: `column`, gap: 12, maxWidth: 400 }, rgbWheel: { display: `flex`, justifyContent: `center` }, rgbDialog: { maxWidth: 400 }, thermostatCircleDiv: { width: `100%`, display: `flex`, flexDirection: `column`, justifyContent: `flex-end`, "& svg circle": { cursor: `pointer` }, "&>div": { margin: `auto`, "&>div": { top: `35% !important` } } }, thermostatButtonsDiv: { textAlign: `center`, display: `flex`, justifyContent: `center`, width: `100%`, position: `absolute`, bottom: 8, left: 0 }, thermostatNewValueLight: { animation: `vis-2-widgets-nils-fork-newValueAnimationLight 2s ease-in-out` }, thermostatNewValueDark: { animation: `vis-2-widgets-nils-fork-newValueAnimationDark 2s ease-in-out` }, thermostatDesiredTemp: { fontWeight: `bold`, display: `flex`, alignItems: `center`, width: `100%`, left: 0, transform: `none` }, lockPinGrid: { display: `grid`, gridTemplateColumns: `1fr 1fr 1fr`, gridGap: `10px` }, lockPinInput: { padding: `10px 0px` }, lockWorkingIcon: { position: `absolute`, top: 10, left: 10 }, lockSvgIcon: {}, vacuumBattery: { display: `flex`, alignItems: `center`, gap: 4 }, vacuumSensorsContainer: { overflow: `auto` }, vacuumSensors: { display: `flex`, justifyContent: `space-between`, alignItems: `center`, gap: 4, minWidth: `min-content` }, vacuumButtons: { display: `flex`, alignItems: `center`, gap: 4 }, vacuumContent: { width: `100%`, height: `100%`, overflow: `auto` }, vacuumMapContainer: { flex: 1 }, vacuumTopPanel: { display: `flex`, alignItems: `center`, justifyContent: `space-between` }, vacuumBottomPanel: { display: `flex`, justifyContent: `space-between`, alignItems: `center` }, vacuumSensorCard: { boxShadow: `none`, backgroundColor: `transparent`, backgroundImage: `none` }, vacuumSensorCardContent: { display: `flex`, flexDirection: `column`, alignItems: `center`, textAlign: `center`, padding: 2, paddingBottom: 2 }, vacuumSensorBigText: { fontSize: 20 }, vacuumSensorSmallText: { fontSize: 12 }, vacuumImage: { width: `100%`, height: `100%`, objectFit: `contain`, color: `grey` }, vacuumSpeedContainer: { gap: 4, display: `flex`, alignItems: `center` }, tooltip: { pointerEvents: `none` }, disabledOverlay: { position: `absolute`, top: 0, left: 0, right: 0, bottom: 0, userSelect: `none`, pointerEvents: `none`, zIndex: 100 }, ...de }, Le = class e2 extends ue {
  timeouts = {};
  history = [];
  _refs = [];
  widgetRef = {};
  lastRxData = ``;
  doNotWantIncludeWidgets;
  updateDialogChartInterval = null;
  updateChartInterval = null;
  customStyle;
  updateTimeout = null;
  constructor(e3) {
    super(e3), this.state = { ...this.state, showControlDialog: null, inputValue: ``, showSetButton: [], inputValues: [], objects: [], historyData: {}, chartWidth: {}, chartHeight: {}, sketch: {}, secondaryObjects: [], dialogPin: null, invalidPin: false, lockPinInput: ``, showRoomsMenu: null, controlValue: null }, this.doNotWantIncludeWidgets = this.state.rxData.doNotWantIncludeWidgets;
  }
  static getWidgetInfo() {
    return { id: `tplNils2Switches`, visSet: `vis-2-widgets-nils-fork`, visName: `Switches`, visWidgetLabel: `switches_or_buttons`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox`, noBinding: false }, { name: `widgetTitle`, label: `name`, hidden: `data.noCard === true` }, { name: `count`, type: `number`, default: 2, label: `count` }, { name: `type`, type: `select`, label: `type`, options: [{ value: `lines`, label: `lines` }, { value: `buttons`, label: `buttons` }], default: `lines` }, { name: `allSwitch`, type: `checkbox`, default: true, label: `show_all_switch`, hidden: `data.type !== "lines"`, noBinding: false }, { name: `orientation`, type: `select`, options: [{ value: `h`, label: `horizontal` }, { value: `v`, label: `vertical` }, { value: `f`, label: `flexible` }], default: `horizontal`, label: `orientation`, hidden: `data.type !== "buttons"` }, { label: `buttons_width`, name: `buttonsWidth`, hidden: `data.type !== "buttons"`, type: `slider`, default: 120, min: 40, max: 300 }, { label: `doNotWantIncludeWidgets`, name: `doNotWantIncludeWidgets`, type: `checkbox`, default: false }] }, { name: `switch`, label: `group_switch`, indexFrom: 1, indexTo: `count`, fields: [{ name: `oid`, type: `id`, label: `oid`, hidden: `data["widget" + index]`, onChange: async (e3, t2, n2, r2, i2) => {
      var _a;
      if (t2[e3.name]) {
        if (t2[e3.name].startsWith(`mihome-vacuum.`)) {
          await Q(e3, t2, n2, r2, i2);
          return;
        }
        let a2 = await r2.getObject(t2[e3.name]);
        if (((_a = a2 == null ? void 0 : a2.common) == null ? void 0 : _a.role) && (a2.common.role.includes(`level.temperature`) || a2.common.role.includes(`rgb`) || a2.common.role.includes(`lock`))) {
          let o2 = t2[e3.name].split(`.`);
          o2.pop();
          let s2 = await r2.getObjectViewSystem(`state`, `${o2.join(`.`)}.`, `${o2.join(`.`)}.\u9999`);
          if (s2) {
            let r3 = false;
            t2[`type${i2}`] !== `thermostat` && a2.common.role.includes(`level.temperature`) && (r3 = true, t2[`type${i2}`] = `thermostat`), t2[`type${i2}`] !== `rgb` && a2.common.role.includes(`rgb`) && (r3 = true, t2[`type${i2}`] = `rgb`), t2[`type${i2}`] !== `lock` && a2.common.role.includes(`lock`) && (r3 = true, t2[`type${i2}`] = `lock`), a2.common.role.includes(`level.temperature`) ? Object.values(s2).forEach((e4) => {
              var _a2;
              let n3 = (_a2 = e4.common) == null ? void 0 : _a2.role;
              (n3 == null ? void 0 : n3.includes(`value.temperature`)) ? (t2[`actual${i2}`] = e4._id, r3 = true) : (n3 == null ? void 0 : n3.includes(`power`)) ? (t2[`switch${i2}`] = e4._id, r3 = true) : (n3 == null ? void 0 : n3.includes(`boost`)) ? (t2[`boost${i2}`] = e4._id, r3 = true) : (n3 == null ? void 0 : n3.includes(`party`)) && (t2[`party${i2}`] = e4._id, r3 = true);
            }) : a2.common.role.includes(`rgb`) ? (t2[`rgbType${i2}`] !== `rgb` && a2.common.role.includes(`rgbw`) ? (r3 = true, t2[`rgbType${i2}`] = `rgbw`) : t2[`rgbType${i2}`] !== `rgb` && (r3 = true, t2[`rgbType${i2}`] = `rgb`), Object.values(s2).forEach((n3) => {
              var _a2;
              let a3 = (_a2 = n3.common) == null ? void 0 : _a2.role;
              a3 && B[a3] && (!t2[a3] || t2[a3] === `nothing_selected`) && e3.name !== a3 && (r3 = true, B[a3] === `rgb` ? t2[`oid${i2}`] = n3._id : t2[B[a3] + i2] = n3._id);
            })) : a2.common.role.includes(`lock`) && Object.values(s2).forEach((e4) => {
              var _a2;
              let n3 = (_a2 = e4.common) == null ? void 0 : _a2.role;
              (n3 == null ? void 0 : n3.includes(`button`)) ? (t2[`open${i2}`] = e4._id, r3 = true) : (n3 == null ? void 0 : n3.includes(`working`)) && (t2[`working${i2}`] = e4._id, r3 = true);
            }), r3 && n2(t2);
          }
        }
      }
    } }, { name: `type`, type: `select`, label: `type`, options: [{ value: `auto`, label: `auto` }, { value: `switch`, label: `switch` }, { value: `button`, label: `button` }, { value: `info`, label: `info` }, { value: `input`, label: `input` }, { value: `slider`, label: `slider` }, { value: `select`, label: `select` }, { value: `blinds`, label: `blinds` }, { value: `thermostat`, label: `thermostat` }, { value: `rgb`, label: `rgb` }, { value: `lock`, label: `lock` }, { value: `vacuum`, label: `vacuum` }], hidden: `!data["oid" + index]`, default: `auto` }, { name: `noIcon`, type: `checkbox`, label: `no_icon`, hidden: `data.type === "buttons" && !!data["widget" + index]`, noBinding: false }, { name: `icon`, type: `image`, label: `icon`, hidden: `!!data["iconSmall" + index] || data["type" + index] === "blinds" || data["noIcon" + index] === true || (data.type === "buttons" && !!data["widget" + index])` }, { name: `iconSmall`, type: `icon64`, label: `small_icon`, hidden: `!!data["icon" + index] || data["type" + index] === "blinds" || data["noIcon" + index] === true || (data.type === "buttons" && !!data["widget" + index])` }, { name: `iconEnabled`, type: `image`, label: `icon_active`, hidden: `!data["oid" + index] || !!data["iconEnabledSmall" + index] || data["type" + index] === "blinds" || data["noIcon" + index] === true || (data.type === "buttons" && !!data["widget" + index])` }, { name: `iconEnabledSmall`, type: `icon64`, label: `small_icon_active`, hidden: `!data["oid" + index] || !!data["iconEnabled" + index] || data["type" + index] === "blinds" || data["noIcon" + index] === true || (data.type === "buttons" && !!data["widget" + index])` }, { name: `color`, type: `color`, label: `color`, hidden: `!data["oid" + index] || data["type" + index] === "blinds" || data["widget" + index]` }, { name: `colorEnabled`, type: `color`, label: `color_active`, hidden: `data["type" + index] === "blinds" || data["widget" + index]` }, { label: `invert_position`, type: `checkbox`, hidden: `!data["oid" + index] || data["type" + index] !== "blinds"`, name: `slideInvert`, noBinding: false }, { name: `title`, type: `text`, label: `title`, hidden: `data.type === "buttons" && !!data["widget" + index]` }, { name: `unit`, type: `text`, noButton: true, label: `unit`, hidden: `data["type" + index] === "button" || data["type" + index] === "switch" || data["widget" + index]` }, { name: `step`, label: `values_step`, hidden: `!data["oid" + index] || (data["type" + index] !== "select" && data["type" + index] !== "thermostat")` }, { name: `hideChart`, type: `checkbox`, label: `hide_chart`, noBinding: false, hidden: `!data["oid" + index] || data["type" + index] !== "info"` }, { name: `chartPeriod`, type: `select`, options: [{ value: `10`, label: `10_minutes` }, { value: `30`, label: `30_minutes` }, { value: `60`, label: `1_hour` }, { value: `120`, label: `2_hours` }, { value: `180`, label: `3_hours` }, { value: `360`, label: `6_hours` }, { value: `720`, label: `12_hours` }, { value: `1440`, label: `1_day` }, { value: `2880`, label: `2_days` }, { value: `10080`, label: `1_week` }], default: `60`, label: `chart_period`, hidden: `!data["oid" + index] || data["type" + index] !== "info" || data["hideChart" + index] === true` }, { name: `buttonText`, type: `text`, noButton: true, label: `button_text`, hidden: `data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonIcon" + index] || !!data["buttonImage" + index]` }, { name: `buttonIcon`, type: `icon64`, label: `button_icon`, hidden: `data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonText" + index] || !!data["buttonImage" + index]` }, { name: `buttonImage`, type: `image`, label: `button_image`, hidden: `data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonText" + index] || !!data["buttonIcon" + index]` }, { name: `buttonIconActive`, type: `icon64`, label: `button_icon`, hidden: `data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonText" + index] || !!data["buttonImageActive" + index]` }, { name: `buttonImageActive`, type: `image`, label: `button_image`, hidden: `data.type !== "lines" || !data["oid" + index] || data["type" + index] !== "button" || !!data["buttonText" + index] || !!data["buttonIconActive" + index]` }, { name: `infoInactiveText`, type: `text`, noButton: true, label: `info_inactive_text`, hidden: `!data["oid" + index] || data["type" + index] !== "info" || !!data["infoInactiveIcon" + index] || !!data["infoInactiveImage" + index]` }, { name: `infoActiveText`, type: `text`, noButton: true, label: `info_active_text`, hidden: `!data["oid" + index] || data["type" + index] !== "info" || !!data["infoActiveIcon" + index] || !!data["infoActiveImage" + index]` }, { name: `infoInactiveIcon`, type: `icon64`, label: `info_inactive_icon`, hidden: `!data["oid" + index] || data["type" + index] !== "info" || !!data["infoInactiveText" + index] || !!data["infoInactiveImage" + index]` }, { name: `infoActiveIcon`, type: `icon64`, label: `info_active_icon`, hidden: `!data["oid" + index] || data["type" + index] !== "info" || !!data["infoActiveText" + index] || !!data["infoActiveImage" + index]` }, { name: `infoInactiveImage`, type: `image`, label: `info_inactive_image`, hidden: `!data["oid" + index] || data["type" + index] !== "info" || !!data["infoInactiveIcon" + index] || !!data["infoInactiveText" + index]` }, { name: `infoActiveImage`, type: `image`, label: `info_active_image`, hidden: `!data["oid" + index] || data["type" + index] !== "info" || !!data["infoActiveIcon" + index] || !!data["infoActiveText" + index]` }, { name: `infoInactiveColor`, type: `color`, label: `info_inactive_color`, hidden: `!data["oid" + index] || data["type" + index] !== "info"` }, { name: `infoActiveColor`, type: `color`, label: `info_active_color`, hidden: `!data["oid" + index] || data["type" + index] !== "info"` }, { name: `widget`, type: `widget`, label: `widget_id`, hidden: `!!data["oid" + index]`, noBinding: true, checkUsage: true }, { name: `height`, type: `slider`, min: 40, max: 500, label: `height`, hidden: `!data["widget" + index]` }, { name: `position`, type: `slider`, min: 0, max: 500, label: `position`, hidden: `!data["widget" + index] || data.type !== "lines"` }, { name: `hide`, type: `checkbox`, label: `hide`, tooltip: `hide_tooltip`, noBinding: false }, { name: `actual`, type: `id`, label: `actual_oid`, hidden: `!!data["widget" + index] || data["type" + index] !== "thermostat"` }, { name: `boost`, type: `id`, label: `mode_boost`, hidden: `!!data["widget" + index] || data["type" + index] !== "thermostat"` }, { name: `party`, type: `id`, label: `mode_party`, hidden: `!!data["widget" + index] || data["type" + index] !== "thermostat"` }, { name: `switch`, type: `id`, label: `switch`, onChange: Z, hidden: `!!data["widget" + index] || (data["type" + index] !== "rgb" || data["type" + index] !== "thermostat")` }, { name: `brightness`, type: `id`, label: `brightness`, onChange: Z, hidden: `!!data["widget" + index] || data["type" + index] !== "rgb"` }, { name: `rgbType`, label: `rgbType`, type: `select`, noTranslation: true, options: [`rgb`, `rgbw`, `r/g/b`, `r/g/b/w`, `hue/sat/lum`, `ct`], onChange: Z, hidden: `!!data["widget" + index] || data["type" + index] !== "rgb"` }, { name: `red`, type: `id`, label: `red`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `r/g/b` && e3[`rgbType${t2}`] !== `r/g/b/w`, onChange: Z }, { name: `green`, type: `id`, label: `green`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `r/g/b` && e3[`rgbType${t2}`] !== `r/g/b/w`, onChange: Z }, { name: `blue`, type: `id`, label: `blue`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `r/g/b` && e3[`rgbType${t2}`] !== `r/g/b/w`, onChange: Z }, { name: `white`, type: `id`, label: `white`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `r/g/b/w` && e3[`rgbType${t2}`] !== `rgbw`, onChange: Z }, { name: `color_temperature`, type: `id`, label: `color_temperature`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `ct`, onChange: Z }, { name: `ct_min`, type: `number`, min: 500, max: 1e4, label: `color_temperature_min`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `ct` || !e3[`color_temperature${t2}`] }, { name: `ct_max`, type: `number`, min: 500, max: 1e4, label: `color_temperature_max`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `ct` || !e3[`color_temperature${t2}`] }, { name: `hue`, type: `id`, label: `hue`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `hue/sat/lum`, onChange: Z }, { name: `saturation`, type: `id`, label: `saturation`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `hue/sat/lum`, onChange: Z }, { name: `luminance`, type: `id`, label: `luminance`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `hue/sat/lum`, onChange: Z }, { name: `hideBrightness`, type: `checkbox`, label: `hideBrightness`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `rgb` && e3[`rgbType${t2}`] !== `rgbw` && e3[`rgbType${t2}`] !== `r/g/b` && e3[`rgbType${t2}`] !== `r/g/b/w`, onChange: Z, noBinding: false }, { name: `whiteMode`, type: `checkbox`, label: `whiteMode`, tooltip: `whiteModeTooltip`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `rgbw` && e3[`rgbType${t2}`] !== `r/g/b/w`, onChange: Z }, { name: `noRgbPalette`, type: `checkbox`, label: `noRgbPalette`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `rgb` || e3[`rgbType${t2}`] !== `rgb` && e3[`rgbType${t2}`] !== `rgbw` && e3[`rgbType${t2}`] !== `r/g/b` && e3[`rgbType${t2}`] !== `r/g/b/w`, onChange: Z }, { name: `open`, type: `id`, label: `doorOpen-oid`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` }, { name: `working`, type: `id`, label: `lockWorking-oid`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` }, { name: `sensor`, type: `id`, label: `doorSensor-oid`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` }, { name: `pincode`, label: `pincode`, onChange: (e3, t2, n2, r2, i2) => (t2[`pincode${i2}`] && t2[`pincode${i2}`].match(/[^0-9]/g) && (t2[`pincode${i2}`] = t2[`pincode${i2}`].replace(/[^0-9]/g, ``), n2(t2)), Promise.resolve()), hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` || !!e3[`oid-pincode${t2}`] }, { name: `oid-pincode`, type: `id`, label: `pincode_oid`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` || !!e3[`pincode${t2}`] }, { name: `doNotConfirm`, type: `checkbox`, label: `doNotConfirm`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` || !!e3[`oid-pincode${t2}`] && !!e3[`pincode${t2}`] }, { name: `noLockAnimation`, label: `noLockAnimation`, type: `checkbox`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` || !e3[`oid${t2}`] }, { name: `lockColor`, label: `Lock color`, type: `color`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` || !e3[`oid${t2}`] || !!e3[`noLockAnimation${t2}`] }, { name: `pincodeReturnButton`, type: `select`, options: [`submit`, `backspace`], default: `submit`, label: `pincode_return_button`, hidden: (e3, t2) => !!e3[`widget${t2}`] || e3[`type${t2}`] !== `lock` || !!e3[`oid-pincode${t2}`] && !!e3[`pincode${t2}`] }, { name: `timeout`, label: `controlTimeout`, tooltip: `timeout_tooltip`, type: `slider`, min: 0, max: 2e3, default: 500, hidden: `!!data["widget" + index] || (data["type" + index] !== "rgb" && data["type" + index] !== "slider" && data["type" + index] !== "thermostat")` }, { label: `status`, name: `vacuum-status-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `battery`, name: `vacuum-battery-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `is_charging`, name: `vacuum-is-charging-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `fan_speed`, name: `vacuum-fan-speed-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `sensors_left`, name: `vacuum-sensors-left-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `filter_left`, name: `vacuum-filter-left-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `main_brush_left`, name: `vacuum-main-brush-left-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `side_brush_left`, name: `vacuum-side-brush-left-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `cleaning_count`, name: `vacuum-cleaning-count-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `rooms`, name: `vacuum-use-rooms`, type: `checkbox`, tooltip: `rooms_tooltip`, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `map64`, name: `vacuum-map64-oid`, type: `id`, onChange: Q, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `useDefaultPicture`, name: `vacuum-use-default-picture`, type: `checkbox`, default: true, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum" || !!data["vacuum-map64-oid"]` }, { label: `ownImage`, name: `vacuum-own-image`, type: `image`, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum" || !!data["vacuum-map64-oid"] || !data["vacuum-use-default-picture"]` }, { label: `start`, name: `vacuum-start-oid`, type: `id`, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `home`, name: `vacuum-home-oid`, type: `id`, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { label: `pause`, name: `vacuum-pause-oid`, type: `id`, hidden: `!!data["widget" + index] || data["type" + index] !== "vacuum"` }, { type: `delimiter`, name: `delimiter` }, { label: `visibility-oid`, name: `visibility-oid`, type: `id` }, { label: `visibility-cond`, name: `visibility-cond`, type: `select`, options: [`==`, `!=`, `<=`, `>=`, `<`, `>`, `consist`, `not consist`, `exist`, `not exist`], noTranslation: true, default: `==`, hidden: `!data["visibility-oid" + index]` }, { label: `visibility-val`, name: `visibility-val`, type: `text`, default: `1`, hidden: `!data["visibility-oid" + index]` }, { label: `visibility-no-hide`, name: `visibility-no-hide`, type: `checkbox`, hidden: `!data["visibility-oid" + index]`, noBinding: false }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_switches.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  onStateUpdated(e3) {
    var _a;
    ((_a = this.state.controlValue) == null ? void 0 : _a.id) === e3 && this.setState({ controlValue: { id: e3, value: this.state.controlValue.value, changed: true } });
  }
  async propertiesUpdate() {
    var _a, _b, _c, _d, _e2, _f, _g, _h, _i;
    let e3 = JSON.stringify(this.state.rxData);
    if (this.lastRxData === e3) return;
    this.lastRxData = e3;
    let t2 = [], r2 = [], i2 = [];
    for (let e4 = 1; e4 <= this.state.rxData.count; e4++) this.state.rxData[`type${e4}`] === `rgb` ? this.rgbObjectIDs(e4, i2) : this.state.rxData[`type${e4}`] === `thermostat` ? this.thermostatObjectIDs(e4, i2) : this.state.rxData[`type${e4}`] === `vacuum` ? this.vacuumObjectIDs(e4, i2) : this.state.rxData[`oid${e4}`] && this.state.rxData[`oid${e4}`] !== `nothing_selected` && i2.push(this.state.rxData[`oid${e4}`]);
    let a2 = i2.length ? await this.props.context.socket.getObjectsById(i2) : {};
    for (let e4 = 1; e4 <= this.state.rxData.count; e4++) if (this.state.rxData[`type${e4}`] === `rgb`) this.rgbReadObjects(e4, a2, t2, r2);
    else if (this.state.rxData[`type${e4}`] === `thermostat`) this.thermostatReadObjects(e4, a2, t2, r2);
    else if (this.state.rxData[`type${e4}`] === `vacuum`) await this.vacuumReadObjects(e4, a2, t2, r2);
    else if (this.state.rxData[`oid${e4}`] && this.state.rxData[`oid${e4}`] !== `nothing_selected`) {
      let n2 = a2[this.state.rxData[`oid${e4}`]];
      if (!n2) {
        t2[e4] = { common: {} };
        continue;
      }
      n2.common || (n2.common = {});
      let r3 = this.state.rxData[`type${e4}`];
      if (r3 === `auto` && (r3 = n2.common.write === false ? `info` : n2.common.states && n2.common.write !== false ? `select` : n2.common.type === `number` && n2.common.max !== void 0 ? `slider` : n2.common.type === `boolean` && n2.common.write !== false ? `switch` : n2.common.type === `boolean` && n2.common.read === false ? `button` : `input`), n2.common.type === `number` && ((_a = n2.common).max ?? (_a.max = 100), (_b = n2.common).min ?? (_b.min = 0)), Array.isArray(n2.common.states)) {
        let e5 = {};
        n2.common.states.forEach((t3) => e5[t3] = t3), n2.common.states = e5;
      }
      if ((_c = n2.common).unit || (_c.unit = this.state.rxData[`unit${e4}`]), this.state.rxData[`noIcon${e4}`] === true || this.state.rxData[`noIcon${e4}`] === `true`) n2.common.icon = void 0;
      else if (!this.state.rxData[`icon${e4}`] && !this.state.rxData[`iconSmall${e4}`] && !n2.common.icon && (n2.type === `state` || n2.type === `channel`)) {
        let t3 = this.state.rxData[`oid${e4}`].split(`.`), r4 = await this.props.context.socket.getObject(t3.slice(0, -1).join(`.`));
        if (!((_d = r4 == null ? void 0 : r4.common) == null ? void 0 : _d.icon) && (n2.type === `state` || n2.type === `channel`)) {
          let e5 = await this.props.context.socket.getObject(t3.slice(0, -2).join(`.`));
          ((_e2 = e5 == null ? void 0 : e5.common) == null ? void 0 : _e2.icon) && (n2.common.icon = R.getObjectIcon(e5, e5._id) || void 0);
        } else ((_f = r4 == null ? void 0 : r4.common) == null ? void 0 : _f.icon) && (n2.common.icon = R.getObjectIcon(r4, r4._id) || void 0);
      }
      r3 === `blinds` && (n2.common.unit = `%`), t2[e4] = { common: n2.common, _id: n2._id, widgetType: r3 }, this.widgetRef[e4] && delete this.widgetRef[e4];
    } else this.state.rxData[`widget${e4}`] ? (t2[e4] = this.state.rxData[`widget${e4}`], (_g = this.widgetRef)[e4] || (_g[e4] = n.createRef())) : this.widgetRef[e4] && (delete this.widgetRef[e4], t2[e4] = null);
    this.doNotWantIncludeWidgets !== !!this.state.rxData.doNotWantIncludeWidgets && (this.doNotWantIncludeWidgets = !!this.state.rxData.doNotWantIncludeWidgets, (_i = (_h = this.props).askView) == null ? void 0 : _i.call(_h, `update`, { id: this.props.id, uuid: this.uuid, doNotWantIncludeWidgets: !!this.state.rxData.doNotWantIncludeWidgets })), (JSON.stringify(t2) !== JSON.stringify(this.state.objects) || JSON.stringify(r2) !== JSON.stringify(this.state.secondaryObjects)) && this.setState({ objects: t2, secondaryObjects: r2 });
  }
  async componentDidMount() {
    super.componentDidMount(), await this.propertiesUpdate(), this.doNotWantIncludeWidgets = !!this.state.rxData.doNotWantIncludeWidgets, this.props.askView && this.props.askView(`update`, { id: this.props.id, uuid: this.uuid, canHaveWidgets: true, doNotWantIncludeWidgets: !!this.state.rxData.doNotWantIncludeWidgets });
  }
  onCommand(e3, t2) {
    let n2 = super.onCommand(e3, t2);
    if (n2 === false && e3 === `include`) {
      let e4 = false;
      for (let t3 = 1; t3 <= this.state.rxData.count; t3++) if (!this.state.rxData[`oid${t3}`] && !this.state.rxData[`widget${t3}`] && !this.state.rxData[`title${t3}`]) {
        e4 = t3;
        break;
      }
      let n3 = JSON.parse(JSON.stringify(this.props.context.views)), r2 = n3[this.props.view].widgets[this.props.id];
      return e4 || (e4 = (r2.data.count++, r2.data.count)), r2.data[`widget${e4}`] = t2, this.props.context.changeProject(n3), true;
    }
    return n2;
  }
  componentWillUnmount() {
    this.updateDialogChartInterval && (this.updateDialogChartInterval = (clearInterval(this.updateDialogChartInterval), null)), this.updateChartInterval && (this.updateChartInterval = (clearInterval(this.updateChartInterval), null)), this.rgbDestroy();
  }
  async onRxDataChanged() {
    await this.propertiesUpdate();
  }
  isOn(e3, t2) {
    let n2 = this.state.objects[e3];
    if (!n2 || typeof n2 == `string`) return false;
    let r2 = n2;
    return t2 || (t2 = this.state.values), r2.widgetType === `rgb` || r2.widgetType === `thermostat` || r2.widgetType === `vacuum` ? t2[`${this.state.rxData[`switch${e3}`]}.val`] : r2.common.type === `number` ? t2[`${r2._id}.val`] !== r2.common.min : !!t2[`${r2._id}.val`];
  }
  getStateIcon(e3) {
    var _a;
    let t2 = this.state.objects[e3], n2, r2;
    if (this.state.rxData[`noIcon${e3}`] === true || this.state.rxData[`noIcon${e3}`] === `true`) return;
    this.isOn(e3) && (n2 = this.state.rxData[`iconEnabled${e3}`] || this.state.rxData[`iconEnabledSmall${e3}`]), n2 || (n2 = this.state.rxData[`icon${e3}`] || this.state.rxData[`iconSmall${e3}`]), n2 || (n2 = typeof t2 == `object` ? (_a = t2 == null ? void 0 : t2.common) == null ? void 0 : _a.icon : void 0);
    let i2 = this.isOn(e3), a2 = this.getColor(e3, i2);
    return r2 = n2 ? x(C, { src: n2, style: { ...$.iconCustom, width: 40, height: 40, color: a2 } }) : typeof t2 == `object` && (t2 == null ? void 0 : t2.widgetType) === `blinds` ? x(fe, { style: { color: a2 } }) : typeof t2 == `object` && (t2 == null ? void 0 : t2.widgetType) === `vacuum` ? x(Fe, {}) : typeof t2 == `object` && (t2 == null ? void 0 : t2.widgetType) === `thermostat` ? this.state.rxData[`switch${e3}`] && this.state.values[`${this.state.rxData[`switch${e3}`]}.val`] ? x(j, { color: `primary`, style: { color: a2 } }) : x(j, {}) : typeof t2 == `object` && (t2 == null ? void 0 : t2.widgetType) === `lock` ? i2 ? x(k, { color: `primary`, style: { color: a2 } }) : x(O, { style: { color: a2 } }) : typeof t2 == `object` && (t2 == null ? void 0 : t2.widgetType) === `rgb` ? this.state.rxData[`switch${e3}`] ? this.state.values[`${this.state.rxData[`switch${e3}`]}.val`] ? x(E, { color: `primary`, style: { color: a2 } }) : x(D, { style: { color: a2 } }) : this.state.rxData[`brightness${e3}`] ? this.state.values[`${this.state.rxData[`brightness${e3}`]}.val`] ? x(E, { color: `primary`, style: { color: a2 } }) : x(D, { style: { color: a2 } }) : x(E, { color: `primary`, style: { color: a2 } }) : i2 ? x(E, { color: `primary`, style: { color: a2 } }) : x(D, { style: { color: a2 } }), r2;
  }
  getColor(e3, t2) {
    var _a, _b;
    let n2 = this.state.objects[e3];
    if (typeof n2 != `string`) return t2 === void 0 && (t2 = this.isOn(e3)), t2 ? this.state.rxData[`colorEnabled${e3}`] || this.state.rxData[`color${e3}`] || ((_a = n2 == null ? void 0 : n2.common) == null ? void 0 : _a.color) : this.state.rxData[`color${e3}`] || ((_b = n2 == null ? void 0 : n2.common) == null ? void 0 : _b.color);
  }
  changeSwitch = (e3) => {
    if (!this.state.objects[e3] || typeof this.state.objects[e3] == `string`) return;
    let t2 = this.state.objects[e3];
    if (t2.widgetType === `rgb` || t2.widgetType === `lock` || t2.widgetType === `vacuum` || t2.widgetType === `thermostat`) this.setState({ showControlDialog: e3 });
    else if (t2.widgetType === `slider` || t2.widgetType === `input` || t2.widgetType === `select` || t2.widgetType === `info`) t2.widgetType === `info` && (this.updateDialogChartInterval || (this.updateDialogChartInterval = setInterval(() => this.updateCharts(), 6e4)), this.updateCharts(e3)), this.setState({ showControlDialog: e3, inputValue: this.state.values[`${t2._id}.val`] });
    else if (t2.widgetType === `button`) t2.common.max === void 0 ? this.props.context.setValue(this.state.rxData[`oid${e3}`], true) : this.props.context.setValue(this.state.rxData[`oid${e3}`], t2.common.max);
    else {
      let n2 = JSON.parse(JSON.stringify(this.state.values)), r2 = `${t2._id}.val`;
      n2[r2] = t2.common.type === `number` ? n2[r2] === t2.common.max ? t2.common.min : t2.common.max : !n2[r2], this.setState({ values: n2 }), this.props.context.setValue(this.state.rxData[`oid${e3}`], n2[r2]);
    }
  };
  buttonPressed(e3, t2) {
    this.props.context.setValue(this.state.rxData[`oid${e3}`], t2);
  }
  setOnOff(e3, t2) {
    if (!this.state.objects[e3] || typeof this.state.objects[e3] == `string`) return;
    let n2 = this.state.objects[e3], r2 = JSON.parse(JSON.stringify(this.state.values)), i2 = `${n2._id}.val`;
    r2[i2] = t2 ? n2.common.max : n2.common.min, this.setState({ values: r2 }), this.props.context.setValue(this.state.rxData[`oid${e3}`], r2[i2]);
  }
  controlSpecificState(e3, t2) {
    if (!this.state.objects[e3] || typeof this.state.objects[e3] == `string`) return;
    let n2 = this.state.objects[e3], r2 = JSON.parse(JSON.stringify(this.state.values)), i2 = `${n2._id}.val`;
    n2.common.type === `number` ? t2 = parseFloat(t2) : n2.common.type === `boolean` && (t2 = t2 === `true` || t2 === true), r2[i2] = t2, this.setState({ values: r2, showControlDialog: null }), this.props.context.setValue(this.state.rxData[`oid${e3}`], r2[i2]);
  }
  finishChanging() {
    if (this.state.controlValue) {
      let e3 = { controlValue: null };
      if (!this.state.controlValue.changed) {
        let t2 = JSON.parse(JSON.stringify(this.state.values));
        t2[`${this.state.controlValue.id}.val`] = this.state.controlValue.value, e3.values = t2;
      }
      this.setState(e3);
    }
  }
  renderControlDialog() {
    var _a, _b;
    let e3 = this.state.showControlDialog;
    if (e3 !== null) {
      if (!this.state.objects[e3] || typeof this.state.objects[e3] == `string`) return;
      let t2 = this.state.objects[e3], n2 = this.state.values[`${t2._id}.val`], r2;
      if (t2.widgetType === `select`) {
        let i2;
        if (t2.common.states) i2 = Object.keys(t2.common.states).map((r3, i3) => x(a, { style: { ...n2 === r3 ? void 0 : $.buttonInactive, ...this.customStyle }, variant: `contained`, color: n2 === r3 ? `primary` : `grey`, onClick: () => this.controlSpecificState(e3, r3), children: t2.common.states[r3] }, `${r3}_${i3}`));
        else if (t2.common.type === `number`) {
          i2 = [];
          let r3 = t2.common.min === void 0 ? 0 : t2.common.min, o2 = t2.common.max === void 0 ? 100 : t2.common.max, s2 = parseInt(this.state.rxData[`step${e3}`], 10) || (t2.common.step === void 0 ? (o2 - r3) / 10 : t2.common.step);
          i2 = [];
          for (let c2 = r3; c2 <= o2; c2 += s2) i2.push(x(a, { style: { ...n2 === c2 ? void 0 : $.buttonInactive, ...this.customStyle }, variant: `contained`, color: n2 === c2 ? `primary` : `grey`, onClick: () => this.controlSpecificState(e3, c2), children: c2 + (t2.common.unit || ``) }, c2));
        }
        r2 = x(`div`, { style: { width: `100%`, textAlign: `center`, display: `flex`, flexWrap: `wrap`, gap: 4, alignItems: `center`, justifyContent: `center` }, children: i2 });
      } else t2.widgetType === `slider` ? r2 = T(b, { children: [T(`div`, { style: { width: `100%`, marginBottom: 20 }, children: [T(a, { style: { ...n2 === t2.common.min ? void 0 : $.buttonInactive, width: `50%`, ...this.customStyle }, color: `grey`, onClick: () => {
        this.setOnOff(e3, false), this.setState({ showControlDialog: null });
      }, children: [x(D, {}), R.t(`OFF`).replace(`vis_2_widgets_nils_`, ``)] }), T(a, { style: { ...n2 === t2.common.max ? void 0 : $.buttonInactive, width: `50%`, ...this.customStyle }, color: `primary`, onClick: () => {
        this.setOnOff(e3, true), this.setState({ showControlDialog: null });
      }, children: [x(E, {}), R.t(`ON`).replace(`vis_2_widgets_nils_`, ``)] })] }), x(`div`, { style: { width: `100%` }, children: x(m, { size: `small`, value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === t2._id ? this.state.controlValue.value : n2, step: parseFloat(this.state.rxData[`step${e3}`]) || void 0, valueLabelDisplay: `auto`, min: t2.common.min, max: t2.common.max, onChangeCommitted: () => this.finishChanging(), onChange: (e4, n3) => {
        var _a2;
        return this.setState({ controlValue: { id: t2._id, value: n3, changed: !!((_a2 = this.state.controlValue) == null ? void 0 : _a2.changed) } }, () => this.props.context.setValue(t2._id, n3));
      } }) })] }) : t2.widgetType === `rgb` ? r2 = this.rgbRenderDialog(e3) : t2.widgetType === `thermostat` ? r2 = this.thermostatRenderDialog(e3) : t2.widgetType === `lock` || (t2.widgetType === `vacuum` ? r2 = this.vacuumRenderDialog(e3) : t2.widgetType === `info` ? this._refs[e3] ? (setTimeout(() => this.checkChartWidth(), 50), r2 = x(`div`, { style: { width: `100%`, minWidth: 500, height: `100%`, minHeight: 300 }, ref: this._refs[e3], children: this.drawChart(e3, { width: this.state.chartWidth[e3], height: this.state.chartHeight[e3], position: `relative`, top: void 0, right: void 0, maxWidth: void 0, userSelect: void 0, pointerEvents: void 0 }) })) : r2 = x(f, {}) : r2 = T(`div`, { style: { display: `flex`, gap: 16 }, children: [x(i, { fullWidth: true, variant: `standard`, value: this.state.inputValue === void 0 || this.state.inputValue === null ? `` : this.state.inputValue, slotProps: { input: { endAdornment: t2.common.unit ? x(g, { position: `end`, children: t2.common.unit }) : void 0 } }, onKeyUp: (n3) => {
        if (n3.key === `Enter`) {
          let n4 = JSON.parse(JSON.stringify(this.state.values)), r3 = `${t2._id}.val`;
          n4[r3] = this.state.inputValue, this.setState({ values: n4, showControlDialog: null }), t2.common.type === `number` ? this.props.context.setValue(this.state.rxData[`oid${e3}`], parseFloat(n4[r3])) : t2.common.type === `boolean` ? this.props.context.setValue(this.state.rxData[`oid${e3}`], n4[r3] === `true` || n4[r3] === true || n4[r3] === 1 || n4[r3] === `1` || n4[r3] === `on` || n4[r3] === `ON` || n4[r3] === `On` || n4[r3] === `ein` || n4[r3] === `EIN` || n4[r3] === `Ein` || n4[r3] === `an` || n4[r3] === `AN` || n4[r3] === `An`) : this.props.context.setValue(this.state.rxData[`oid${e3}`], n4[r3]);
        }
      }, onChange: (e4) => this.setState({ inputValue: e4.target.value }) }), x(a, { variant: `contained`, color: `primary`, title: R.t(`Set`), style: this.customStyle, onClick: () => {
        let n3 = JSON.parse(JSON.stringify(this.state.values)), r3 = `${t2._id}.val`;
        n3[r3] = this.state.inputValue, this.setState({ values: n3, showControlDialog: null }), t2.common.type === `number` ? this.props.context.setValue(this.state.rxData[`oid${e3}`], parseFloat(n3[r3])) : t2.common.type === `boolean` ? this.props.context.setValue(this.state.rxData[`oid${e3}`], n3[r3] === `true` || n3[r3] === true || n3[r3] === 1 || n3[r3] === `1` || n3[r3] === `on` || n3[r3] === `ON` || n3[r3] === `On` || n3[r3] === `ein` || n3[r3] === `EIN` || n3[r3] === `Ein` || n3[r3] === `an` || n3[r3] === `AN` || n3[r3] === `An`) : this.props.context.setValue(this.state.rxData[`oid${e3}`], n3[r3]);
      }, children: x(y, {}) })] }));
      return T(p, { fullWidth: true, maxWidth: `sm`, sx: { "& .MuiDialog-paper": $.rgbDialog }, open: true, onClose: () => {
        this.updateDialogChartInterval && (this.updateDialogChartInterval = (clearInterval(this.updateDialogChartInterval), null)), this.setState({ showControlDialog: null });
      }, children: [T(d, { children: [(this.state.rxData[`title${e3}`] || R.getText((_b = t2.common) == null ? void 0 : _b.name) || ``).trim(), x(c, { style: { float: `right` }, onClick: () => this.setState({ showControlDialog: null }), children: x(oe, {}) })] }), x(l, { children: r2 })] });
    }
    return null;
  }
  renderWidgetInWidget(e3, t2, n2) {
    var _a, _b, _c, _d, _e2, _f, _g;
    let r2 = this.state.rxData[`widget${e3}`], i2 = (_b = (_a = this.props.context.views[this.props.view]) == null ? void 0 : _a.widgets) == null ? void 0 : _b[r2];
    if (i2 && r2 !== this.props.id) {
      this.widgetRef[e3].current || setTimeout(() => this.forceUpdate(), 50);
      let a2 = t2 ? { justifyContent: `center` } : { margin: 8, justifyContent: `right` };
      return t2 ? (!this.state.rxData.orientation || this.state.rxData.orientation === `h` ? a2.width = this.state.rxData[`width${e3}`] || this.state.rxData.buttonsWidth || ((_c = i2.style) == null ? void 0 : _c.width) || 120 : this.state.rxData.orientation === `v` ? a2.height = this.state.rxData[`height${e3}`] || this.state.rxData.buttonsHeight || ((_d = i2.style) == null ? void 0 : _d.height) || 80 : this.state.rxData.orientation === `f` && (a2.width = this.state.rxData[`width${e3}`] || this.state.rxData.buttonsWidth || ((_e2 = i2.style) == null ? void 0 : _e2.width) || 120, a2.height = this.state.rxData[`height${e3}`] || this.state.rxData.buttonsHeight || ((_f = i2.style) == null ? void 0 : _f.height) || 80), this.state.selectedOne && (a2.border = `1px dashed gray`, a2.boxSizing = `border-box`)) : (a2.height = this.state.rxData[`height${e3}`] || ((_g = i2.style) == null ? void 0 : _g.height) || 80, a2.marginRight = this.state.rxData[`position${e3}`]), (!n2 || n2 === `disabled`) && (a2.opacity = 0.3), T(`div`, { ref: this.widgetRef[e3], style: { ...$.widgetContainer, ...a2, ...n2 === `disabled` ? { pointerEvents: `none` } : void 0 }, children: [this.widgetRef[e3].current ? this.getWidgetInWidget(this.props.view, r2, { refParent: this.widgetRef[e3] }) : null, n2 === `disabled` ? x(`div`, { style: $.disabledOverlay }) : null] }, e3);
    }
    return null;
  }
  renderLine(e3) {
    var _a, _b, _c, _d;
    if (typeof this.state.objects[e3] == `string`) return this.renderWidgetInWidget(e3, false, true);
    if (!this.state.objects[e3]) return null;
    let t2 = this.state.objects[e3], n2 = this.state.values[`${t2._id}.val`];
    if (t2.widgetType === `rgb`) {
      let t3 = null;
      this.state.secondaryObjects[e3].switch && (t3 = this.getPropertyValue(`switch${e3}`));
      let n3;
      n3 = t3 ? this.state.rxData[`colorEnabled${e3}`] || `#4DABF5` : this.state.rxData[`color${e3}`] || (this.props.context.themeType === `dark` ? `#111` : `#eee`);
      let r2 = this.state.rxData[`icon${e3}`], i2, a2 = { color: this.rgbGetColor(e3) };
      return t3 === false && (a2.opacity = 0.7), r2 === void 0 ? i2 = x(U, { style: a2 }) : r2 ? i2 = x(C, { src: r2, style: a2 }) : (a2.borderRadius = `50%`, i2 = x(`div`, { style: a2 })), x(c, { style: { backgroundColor: n3, width: 36, height: 36 }, onClick: () => this.setState({ showControlDialog: e3 }), children: i2 });
    }
    if (t2.widgetType === `vacuum`) return this.vacuumRenderButtons(e3, true);
    if (t2.widgetType === `lock`) return this.lockRenderLine(e3);
    if (t2.widgetType === `button`) {
      let t3 = this.state.rxData[`buttonText${e3}`], r2 = this.state.rxData[`buttonIcon${e3}`] || this.state.rxData[`buttonImage${e3}`], i2 = this.state.rxData[`buttonIconActive${e3}`] || this.state.rxData[`buttonImageActive${e3}`];
      return i2 && (n2 === `1` || n2 === 1 || n2 === true || n2 === `true`) && (r2 = i2), x(a, { onKeyDown: () => this.buttonPressed(e3, true), onKeyUp: () => this.buttonPressed(e3, false), onMouseDown: () => this.buttonPressed(e3, true), onMouseUp: () => this.buttonPressed(e3, false), style: this.customStyle, children: t3 || (r2 ? x(C, { src: r2, style: { width: 24, height: 24 } }) : x(X, {})) });
    }
    if (t2.widgetType === `switch`) return x(S, { checked: this.isOn(e3), onChange: () => this.changeSwitch(e3) });
    if (t2.widgetType === `slider`) {
      let r2 = t2.common.min === void 0 ? 0 : t2.common.min, i2 = t2.common.max === void 0 ? 100 : t2.common.max;
      return [x(m, { style: $.controlElement, size: `small`, valueLabelDisplay: `auto`, step: parseFloat(this.state.rxData[`step${e3}`]) || void 0, value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === t2._id ? this.state.controlValue.value : n2 ?? r2, onChange: (n3, r3) => {
        var _a2;
        this.setState({ controlValue: { id: t2._id, value: r3, changed: !!((_a2 = this.state.controlValue) == null ? void 0 : _a2.changed) } }, () => {
          var _a3;
          let n4 = this.state.rxData[`timeout${e3}`];
          (n4 == null || n4 === ``) && (n4 = 500), n4 ? ((_a3 = this.timeouts)[e3] || (_a3[e3] = {}), this.timeouts[e3][t2._id] && clearTimeout(this.timeouts[e3][t2._id]), this.timeouts[e3][t2._id] = setTimeout((n5) => {
            this.timeouts[e3][t2._id] = null, this.props.context.setValue(t2._id, n5);
          }, parseInt(n4, 10), r3)) : this.props.context.setValue(t2._id, r3);
        });
      }, onChangeCommitted: () => this.finishChanging(), min: r2, max: i2 }, `slider`), x(`div`, { style: { width: 45 }, children: n2 + (t2.common.unit ? ` ${t2.common.unit}` : ``) }, `value`)];
    }
    if (t2.widgetType === `thermostat`) {
      let r2 = t2.common.min === void 0 ? 12 : t2.common.min, i2 = t2.common.max === void 0 ? 30 : t2.common.max, a2;
      if (this.state.rxData[`actual${e3}`] && (a2 = this.state.values[`${this.state.rxData[`actual${e3}`]}.val`], (a2 || a2 === `0`) && (a2 = a2.toString(), a2.includes(`.`)))) {
        let e4 = Math.round((parseFloat(a2) || 0) * 10) / 10;
        a2 = this.props.context.systemConfig.common.isFloatComma ? e4.toString().replace(`.`, `,`) : e4.toString();
      }
      return [x(m, { style: $.controlElement, size: `small`, step: parseFloat(this.state.rxData[`step${e3}`]) || void 0, valueLabelDisplay: `auto`, value: ((_b = this.state.controlValue) == null ? void 0 : _b.id) === t2._id ? this.state.controlValue.value : n2 ?? r2, onChange: (n3, r3) => {
        var _a2;
        this.setState({ controlValue: { id: t2._id, value: r3, changed: !!((_a2 = this.state.controlValue) == null ? void 0 : _a2.changed) } }, () => {
          var _a3;
          let n4 = this.state.rxData[`timeout${e3}`];
          (n4 == null || n4 === ``) && (n4 = 500), n4 ? ((_a3 = this.timeouts)[e3] || (_a3[e3] = {}), this.timeouts[e3][t2._id] && clearTimeout(this.timeouts[e3][t2._id]), this.timeouts[e3][t2._id] = setTimeout((n5) => {
            this.timeouts[e3][t2._id] = null, this.props.context.setValue(t2._id, n5);
          }, parseInt(n4, 10), r3)) : this.props.context.setValue(t2._id, r3);
        });
      }, onChangeCommitted: () => this.finishChanging(), min: r2, max: i2 }, `slider`), T(`div`, { onClick: () => this.setState({ showControlDialog: e3 }), style: { width: 45, display: `flex`, flexDirection: `column`, alignItems: `center`, cursor: `pointer` }, children: [x(`div`, { style: { whiteSpace: `nowrap` }, children: n2 + (t2.common.unit ? ` ${t2.common.unit}` : ``) }), a2 ? x(`div`, { style: { fontSize: `smaller`, opacity: 0.7, whiteSpace: `nowrap` }, children: a2 + (t2.common.unit ? ` ${t2.common.unit}` : ``) }) : null] }, `value`)];
    }
    if (t2.widgetType === `input`) return [x(i, { fullWidth: true, onFocus: () => {
      let t3 = [...this.state.showSetButton];
      t3[e3] = true;
      let r2 = [];
      r2[e3] = n2 ?? ``, this.setState({ showSetButton: t3, inputValues: r2 });
    }, onKeyUp: (n3) => {
      if (n3.key === `Enter`) {
        let n4 = JSON.parse(JSON.stringify(this.state.values)), r2 = `${t2._id}.val`;
        n4[r2] = this.state.inputValues[e3], this.setState({ values: n4 }), t2.common.type === `number` ? this.props.context.setValue(this.state.rxData[`oid${e3}`], parseFloat(n4[r2])) : t2.common.type === `boolean` ? this.props.context.setValue(this.state.rxData[`oid${e3}`], n4[r2] === `true` || n4[r2] === true || n4[r2] === 1 || n4[r2] === `1` || n4[r2] === `on` || n4[r2] === `ON` || n4[r2] === `On` || n4[r2] === `ein` || n4[r2] === `EIN` || n4[r2] === `Ein` || n4[r2] === `an` || n4[r2] === `AN` || n4[r2] === `An`) : this.props.context.setValue(this.state.rxData[`oid${e3}`], n4[r2]);
      }
    }, onBlur: () => {
      setTimeout(() => {
        let t3 = [...this.state.showSetButton];
        t3[e3] = false, this.setState({ showSetButton: t3 });
      }, 100);
    }, variant: `standard`, label: this.state.rxData[`title${e3}`] || R.getText((_c = t2 == null ? void 0 : t2.common) == null ? void 0 : _c.name) || ``, value: this.state.showSetButton[e3] ? this.state.inputValues[e3] : n2 ?? ``, slotProps: { input: { endAdornment: t2.common.unit ? x(g, { position: `end`, children: t2.common.unit }) : void 0 } }, onChange: (t3) => {
      let n3 = [];
      n3[e3] = t3.target.value, this.setState({ inputValues: n3 });
    } }, `input`), this.state.showSetButton[e3] ? x(a, { variant: `contained`, style: this.customStyle, onClick: () => {
      let n3 = JSON.parse(JSON.stringify(this.state.values)), r2 = `${t2._id}.val`;
      n3[r2] = this.state.inputValues[e3];
      let i2 = [...this.state.showSetButton];
      i2[e3] = false, this.setState({ values: n3, showSetButton: i2 }), t2.common.type === `number` ? this.props.context.setValue(this.state.rxData[`oid${e3}`], parseFloat(n3[r2].replace(`,`, `.`))) : t2.common.type === `boolean` ? this.props.context.setValue(this.state.rxData[`oid${e3}`], n3[r2] === `true` || n3[r2] === true || n3[r2] === 1 || n3[r2] === `1` || n3[r2] === `on` || n3[r2] === `ON` || n3[r2] === `On` || n3[r2] === `ein` || n3[r2] === `EIN` || n3[r2] === `Ein` || n3[r2] === `an` || n3[r2] === `AN` || n3[r2] === `An`) : this.props.context.setValue(this.state.rxData[`oid${e3}`], n3[r2]);
    }, children: x(y, {}) }, `button`) : null];
    if (t2.widgetType === `select`) {
      let i2;
      if (t2.common.states) i2 = Object.keys(t2.common.states).map((e4) => ({ label: t2.common.states[e4], value: e4 }));
      else if (t2.common.type === `boolean`) i2 = [{ label: R.t(`ON`), value: true }, { label: R.t(`OFF`), value: false }];
      else if (t2.common.type === `number`) {
        let r2 = t2.common.min === void 0 ? 0 : t2.common.min, a2 = t2.common.max === void 0 ? 100 : t2.common.max, o3 = parseInt(this.state.rxData[`step${e3}`], 10) || (t2.common.step === void 0 ? (a2 - r2) / 10 : t2.common.step);
        i2 = [];
        for (let e4 = r2; e4 <= a2; e4 += o3) i2.push({ label: e4 + (t2.common.unit || ``), value: e4 }), n2 > e4 && n2 < e4 + o3 && i2.push({ label: n2 + (t2.common.unit || ``), value: n2 });
      } else i2 = [];
      return T(r, { fullWidth: true, children: [x(_, { style: i2.find((e4) => e4.value === n2) ? $.selectLabel : void 0, children: this.state.rxData[`title${e3}`] || R.getText((_d = t2 == null ? void 0 : t2.common) == null ? void 0 : _d.name) || `` }), x(te, { variant: `standard`, value: n2 === void 0 ? `` : n2, onChange: (n3) => {
        let r2 = JSON.parse(JSON.stringify(this.state.values)), i3 = `${t2._id}.val`;
        r2[i3] = n3.target.value, this.setState({ values: r2 }), this.props.context.setValue(this.state.rxData[`oid${e3}`], r2[i3]);
      }, children: i2.map((e4) => x(v, { value: e4.value, children: e4.label }, e4.value)) })] });
    }
    if (t2.common.type === `number`) {
      if (t2.widgetType === `blinds`) {
        let t3 = this.getMinMaxPosition(1, e3);
        n2 = parseFloat(n2), n2 = (n2 - t3.min) / (t3.max - t3.min) * 100, t3.invert && (n2 = 100 - n2);
      }
      n2 = this.formatValue(n2);
    }
    this.checkHistory(e3).catch((e4) => window.alert(`Cannot check history: ${e4}`)), n2 ?? (n2 = `--`);
    let o2, s2, l2, u2 = false;
    if (t2.common.type === `boolean` || t2.common.type === `number` || n2 === 0 || n2 === 1 || n2 === `0` || n2 === `1` || n2 === true || n2 === `true` || n2 === false || n2 === `false`) {
      (n2 === true || n2 === `true` || n2 === 1 || n2 === `1` || n2 === `on` || n2 === `ON` || n2 === `On` || n2 === `ein` || n2 === `EIN` || n2 === `Ein` || n2 === `an` || n2 === `AN` || n2 === `An`) && (u2 = true);
      let t3 = this.state.rxData[`infoInactiveColor${e3}`] || this.state.rxData[`color${e3}`];
      if (u2) {
        let n3 = this.state.rxData[`infoActiveColor${e3}`] || this.state.rxData[`colorEnabled${e3}`], r2 = n3 && t3 && n3 !== t3;
        o2 = this.state.rxData[`infoActiveIcon${e3}`] || this.state.rxData[`infoActiveImage${e3}`], !o2 && r2 && (o2 = this.state.rxData[`infoInactiveIcon${e3}`] || this.state.rxData[`infoInactiveImage${e3}`]), s2 = this.state.rxData[`infoActiveText${e3}`], !s2 && r2 && (s2 = this.state.rxData[`infoInactiveText${e3}`]), l2 = n3 || t3;
      } else o2 = this.state.rxData[`infoInactiveIcon${e3}`] || this.state.rxData[`infoInactiveImage${e3}`], s2 = this.state.rxData[`infoInactiveText${e3}`], l2 = t3;
    }
    if (t2.widgetType === `blinds`) {
      let t3 = 40;
      t3 -= 4.8, s2 = T(`div`, { style: { display: `flex`, alignItems: `center`, gap: 8, cursor: `pointer` }, children: [T(`span`, { children: [n2, `%`] }), this.renderWindows({ height: t3, width: 40 }, e3)] });
    }
    let d2;
    return d2 = s2 ? x(`span`, { style: { color: l2 }, children: s2 }) : o2 ? x(C, { src: o2, style: { width: 24, height: 24, color: l2 } }) : x(`span`, { style: { color: l2 }, children: n2 + (t2.common.unit ? ` ${t2.common.unit}` : ``) }), this._refs[e3] && t2.common.type === `number` ? (setTimeout(() => this.checkChartWidth(), 50), T(`div`, { style: { flexGrow: 1, textAlign: `right`, cursor: `pointer` }, ref: this._refs[e3], onClick: () => this.setState({ showControlDialog: e3 }), children: [this.drawChart(e3), d2] })) : x(`div`, { style: $.infoData, children: d2 });
  }
  checkChartWidth() {
    for (let e3 = 0; e3 < this._refs.length; ++e3) {
      let t2 = this._refs[e3];
      if (t2 == null ? void 0 : t2.current) {
        let n2 = t2.current.offsetWidth, r2 = t2.current.offsetHeight;
        if (n2 !== this.state.chartWidth[e3] || r2 !== this.state.chartHeight[e3]) {
          let t3 = { ...this.state.chartWidth }, i2 = { ...this.state.chartHeight };
          t3[e3] = n2, i2[e3] = r2, this.setState({ chartWidth: t3, chartHeight: i2 });
        }
      }
    }
  }
  drawChart(e3, t2) {
    if (this.state.historyData[e3] && this.state.chartWidth[e3]) {
      let n2 = { height: 37, width: this.state.chartWidth[e3], position: `absolute`, right: 0, top: 0, maxWidth: 200, userSelect: `none`, pointerEvents: `none`, ...t2 };
      return x(Pe.default, { style: { ...$.chart, ...n2 }, echarts: N, option: this.state.historyData[e3], notMerge: true, lazyUpdate: true, theme: this.props.context.themeType === `dark` ? `dark` : ``, opts: { renderer: `svg` } });
    }
    return null;
  }
  async checkHistory(e3, t2) {
    var _a, _b;
    if (!this.state.objects[e3] || typeof this.state.objects[e3] == `string`) return;
    let r2 = this.state.objects[e3], i2 = r2.common.custom;
    if (!i2 || this.state.rxData[`hideChart${e3}`] === true || this.state.rxData[`hideChart${e3}`] === `true`) {
      r2.common.history = false, this._refs[e3] && (this._refs[e3] = null), this.history[e3] && (this.history[e3] = null);
      let t3 = 0;
      for (let e4 = 0; e4 < this.history.length; e4++) this.history[e4] && t3++;
      t3 || (this.updateChartInterval && (this.updateChartInterval = (clearInterval(this.updateChartInterval), null)), this.updateDialogChartInterval && (this.updateDialogChartInterval = (clearInterval(this.updateDialogChartInterval), null)), this.history = []), this.state.historyData[e3] && setTimeout(() => {
        let t4 = { ...this.state.historyData };
        delete t4[e3], this.setState({ historyData: t4 });
      }, 100);
      return;
    }
    if (r2.common.history) return;
    r2.common.history = true;
    let a2;
    if (i2[this.props.context.systemConfig.common.defaultHistory] && ((_a = await this.props.context.socket.getState(`system.adapter.${this.props.context.systemConfig.common.defaultHistory}.alive`)) == null ? void 0 : _a.val) && (a2 = this.props.context.systemConfig.common.defaultHistory), !a2) {
      let e4 = Object.keys(i2);
      for (let t3 = 0; t3 < e4.length; t3++) {
        if (e4[t3] === this.props.context.systemConfig.common.defaultHistory) continue;
        let n2 = e4[t3].split(`.`)[0];
        if (Ie.includes(n2) && ((_b = await this.props.context.socket.getState(`system.adapter.${e4[t3]}.alive`)) == null ? void 0 : _b.val)) {
          a2 = e4[t3];
          break;
        }
      }
    }
    a2 && (this._refs[e3] = this._refs[e3] || n.createRef(), this.history[e3] = a2, t2 || (this.updateChartInterval || (this.updateChartInterval = setInterval(() => this.updateCharts(), 6e4)), this.updateCharts(e3)));
  }
  updateCharts(e3) {
    let t2;
    if (e3 !== void 0) t2 = [e3];
    else {
      t2 = [];
      for (let e4 = 0; e4 < this.history.length; e4++) this.history[e4] && t2.push(e4);
    }
    for (let e4 = 0; e4 < t2.length; e4++) ((e5) => {
      if (!this.state.objects[e5] || typeof this.state.objects[e5] == `string` || !this.state.objects[e5]._id) return;
      let t3 = this.state.objects[e5];
      this.props.context.socket.getHistory(t3._id, { instance: this.history[e5], start: Date.now() - (parseInt(this.state.rxData[`chartPeriod${e5}`], 10) || 60) * 6e4, aggregate: `minmax`, step: 6e4 }).then((n2) => {
        var _a, _b, _c, _d;
        if (n2) {
          let r2 = { ...this.state.historyData }, i2 = [], a2 = ((_a = n2[0]) == null ? void 0 : _a.val) || 0, o2 = ((_b = n2[0]) == null ? void 0 : _b.val) || 0;
          for (let e6 = 0; e6 < n2.length; e6++) {
            let t4 = n2[e6];
            t4.val !== null && a2 > t4.val && (a2 = t4.val), t4.val !== null && o2 < t4.val && (o2 = t4.val), i2.push([t4.ts, t4.val]);
          }
          let s2 = this.state.rxData.type !== `lines`, c2 = { type: `line`, showSymbol: false, data: i2, lineStyle: { color: this.props.context.theme.palette.primary.main, opacity: 0.3 }, areaStyle: { opacity: 0.1 } }, l2 = { type: `value`, show: s2, boundaryGap: [0, `100%`], splitLine: { show: s2 }, min: a2, max: o2 }, u2;
          if (s2) {
            if (l2.axisTick = { alignWithLabel: true }, l2.axisLabel = { formatter: (e6) => {
              let n3;
              return n3 = this.props.context.systemConfig.common.isFloatComma ? e6.toString().replace(`,`, `.`) + (t3.common.unit || ``) : e6 + (t3.common.unit || ``), n3;
            }, showMaxLabel: true, showMinLabel: true }, delete l2.min, delete l2.max, t3.common.type === `boolean`) c2.step = `end`, l2.axisLabel.showMaxLabel = false, l2.axisLabel.formatter = (e6) => e6 === 1 ? `TRUE` : `FALSE`, l2.max = 1.5, l2.interval = 1;
            else if (t3.common.type === `number` && t3.common.states) {
              c2.step = `end`, l2.axisLabel.showMaxLabel = false, l2.axisLabel.formatter = (e7) => t3.common.states[e7] ?? e7;
              let e6 = Object.keys(t3.common.states);
              e6.sort(), l2.max = parseFloat(e6[e6.length - 1]) + 0.5, l2.interval = 1;
            } else t3.common.type === `number` && (t3.common.min !== void 0 && t3.common.max !== void 0 ? (l2.max = t3.common.max, l2.min = t3.common.min) : t3.common.unit === `%` && (l2.max = 100, l2.min = 0));
            u2 = { trigger: `axis`, formatter: (e6) => {
              let n3 = e6[0], r3 = new Date(n3.value[0]), i3 = n3.value[1];
              return i3 !== null && this.props.context.systemConfig.common.isFloatComma && (i3 = i3.toString().replace(`.`, `,`)), `${n3.exact === false ? `i` : ``}${r3.toLocaleString()}.${r3.getMilliseconds().toString().padStart(3, `0`)}: ${i3}${t3.common.unit || ``}`;
            }, axisPointer: { animation: true } };
          }
          r2[e5] = { backgroundColor: `transparent`, grid: s2 ? { top: 10, right: 0 } : { left: 2, right: 2, top: 2, bottom: 2 }, animation: false, xAxis: { type: `time`, show: s2 }, yAxis: l2, series: [c2], tooltip: u2 };
          let d2 = { historyData: r2 };
          ((_d = (_c = this._refs[e5]) == null ? void 0 : _c.current) == null ? void 0 : _d.offsetWidth) && (this.state.chartWidth[e5] !== this._refs[e5].current.offsetWidth || this.state.chartHeight[e5] !== this._refs[e5].current.offsetHeight) && (d2.chartWidth = { ...this.state.chartWidth }, d2.chartHeight = { ...this.state.chartHeight }, d2.chartWidth[e5] = this._refs[e5].current.offsetWidth, d2.chartHeight[e5] = this._refs[e5].current.offsetHeight), this.setState(d2);
        }
      });
    })(t2[e4]);
  }
  renderButton(e3, t2) {
    var _a, _b, _c, _d, _e2, _f, _g;
    let n2 = this.checkLineVisibility(e3);
    if (!n2 && !this.props.editMode || !this.state.objects[e3]) return null;
    if (typeof this.state.objects[e3] == `string`) return this.renderWidgetInWidget(e3, true, n2);
    let r2 = this.state.objects[e3], i2, o2 = null, s2 = {};
    if (r2.widgetType !== `rgb` && (i2 = this.state.values[`${r2._id}.val`], ((_a = r2.common) == null ? void 0 : _a.type) === `number` || ((_b = r2.common) == null ? void 0 : _b.states))) {
      if (r2.common.states && r2.common.states[i2] !== void 0) i2 = r2.common.states[i2];
      else {
        if (r2.widgetType === `blinds`) {
          let t3 = this.getMinMaxPosition(1, e3);
          i2 = parseFloat(i2), i2 = (i2 - t3.min) / (t3.max - t3.min) * 100, t3.invert && (i2 = 100 - i2);
        }
        i2 = this.formatValue(i2);
      }
    }
    if (r2.widgetType === `info`) this.checkHistory(e3).catch((e4) => console.error(`Cannot read history: ${e4}`));
    else if (r2.widgetType === `blinds`) {
      let n3 = 40;
      n3 -= 4.8, t2 = this.renderWindows({ height: n3, width: 40 }, e3);
    } else if (r2.widgetType === `rgb`) {
      let n3 = null;
      this.state.secondaryObjects[e3].switch && (n3 = this.getPropertyValue(`switch${e3}`)), s2.backgroundColor = n3 === null || n3 ? this.rgbGetColor(e3) : this.props.context.themeType === `dark` ? `#111` : `#eee`, s2.color = ne.getInvertedColor(s2.backgroundColor, this.props.context.themeType), t2 = x(U, { style: { color: n3 === null || n3 ? void 0 : this.rgbGetColor(e3) } });
    } else if (r2.widgetType === `thermostat`) {
      let t3 = (_c = this.state.secondaryObjects[e3]) == null ? void 0 : _c.actual;
      if (t3) {
        let n3 = this.state.values[`${t3._id}.val`];
        (n3 || n3 === 0) && (o2 = T(`div`, { style: $.secondaryValueDiv, children: [`/`, T(`span`, { style: $.secondaryValue, children: [this.formatValue(n3, 1), this.state.rxData[`unit${e3}`] || ((_d = t3.common) == null ? void 0 : _d.unit) || ``] })] }));
      }
    } else if (r2.widgetType === `vacuum`) {
      let n3 = this.vacuumGetValue(e3, `status`), r3 = Y(n3);
      t2 = x(J, { style: { color: r3, width: `100%`, height: `100%` } }), i2 = x(`span`, { style: { color: r3 }, children: R.t(n3).replace(`vis_2_widgets_nils_`, ``) });
    }
    let c2 = 120, l2 = 80;
    if (!this.state.rxData.orientation || this.state.rxData.orientation === `h` ? c2 = parseInt(this.state.rxData[`width${e3}`], 10) || this.state.rxData.buttonsWidth || 120 : this.state.rxData.orientation === `v` ? l2 = this.state.rxData[`height${e3}`] || this.state.rxData.buttonsHeight || 80 : this.state.rxData.orientation === `f` && (c2 = parseInt(this.state.rxData[`width${e3}`], 10) || this.state.rxData.buttonsWidth || 120, l2 = this.state.rxData[`height${e3}`] || this.state.rxData.buttonsHeight || 80), r2.widgetType === `lock`) return this.lockRenderLine(e3, c2, l2);
    if (r2.widgetType === `button`) {
      let t3 = this.state.rxData[`title${e3}`], r3 = this.state.rxData[`icon${e3}`] || this.state.rxData[`iconSmall${e3}`], o3 = this.state.rxData[`iconEnabled${e3}`] || this.state.rxData[`iconEnabledSmall${e3}`], s3 = i2 === `1` || i2 === 1 || i2 === true || i2 === `true`;
      return o3 && s3 && (r3 = o3), x(a, { onKeyDown: () => this.buttonPressed(e3, true), onKeyUp: () => this.buttonPressed(e3, false), onMouseDown: () => this.buttonPressed(e3, true), onMouseUp: () => this.buttonPressed(e3, false), style: { ...$.buttonDiv, width: c2 || void 0, height: l2 || void 0, border: this.state.selectedOne ? `1px dashed gray` : `none`, boxSizing: `border-box`, opacity: n2 && n2 !== `disabled` ? void 0 : 0.3, ...n2 === `disabled` ? { pointerEvents: `none` } : void 0, ...this.customStyle, color: s3 ? this.state.rxData[`colorEnabled${e3}`] : this.state.rxData[`color${e3}`] }, startIcon: t3 && r3 ? x(C, { src: r3, style: { width: 24, height: 24 } }) : null, children: t3 || (r3 ? x(C, { src: r3, style: { width: 24, height: 24 } }) : x(X, {})) });
    }
    return T(`div`, { className: `test`, style: { ...$.buttonDiv, width: c2 || void 0, height: l2 || void 0, border: this.state.selectedOne ? `1px dashed gray` : `none`, boxSizing: `border-box`, opacity: n2 && n2 !== `disabled` ? void 0 : 0.3, ...n2 === `disabled` ? { pointerEvents: `none` } : void 0 }, children: [T(a, { onClick: () => this.changeSwitch(e3), color: !((_e2 = r2.common) == null ? void 0 : _e2.states) && this.isOn(e3) ? `primary` : `grey`, style: { ...$.button, ...this.isOn(e3) ? void 0 : $.buttonInactive, ...s2 }, disabled: r2.widgetType === `info` && (!this.history[e3] || this.state.rxData[`hideChart${e3}`] === true || this.state.rxData[`hideChart${e3}`] === `true`), children: [t2 ? x(`div`, { style: $.iconButton, children: t2 }) : null, x(`div`, { style: { ...$.text, ...this.customStyle }, children: this.state.rxData[`title${e3}`] || R.getText((_f = r2.common) == null ? void 0 : _f.name) || `` }), i2 != null || o2 ? T(`div`, { style: $.value, children: [x(`div`, { children: i2 }), this.state.rxData[`unit${e3}`] || ((_g = r2.common) == null ? void 0 : _g.unit) || ``, o2] }) : null] }), n2 === `disabled` ? x(`div`, { style: $.disabledOverlay }) : null] }, e3);
  }
  lockRenderUnlockDialog() {
    if (this.state.dialogPin === null) return null;
    let e3 = this.state.dialogPin.index, t2 = this.lockGetPinCode(e3), n2 = this.state.rxData[`pincodeReturnButton${e3}`] === `backspace` ? `backspace` : `submit`;
    return T(p, { open: true, onClose: () => this.setState({ dialogPin: null }), children: [x(d, { children: R.t(`enter_pin`) }), T(l, { children: [x(`div`, { style: $.lockPinInput, children: x(i, { variant: `outlined`, fullWidth: true, type: this.state.invalidPin ? `text` : `password`, slotProps: { input: { readOnly: true, style: { textAlign: `center`, color: this.state.invalidPin ? `#ff3e3e` : `inherit` } } }, value: this.state.invalidPin ? R.t(`invalid_pin`) : this.state.lockPinInput }) }), x(`div`, { style: $.lockPinGrid, children: [1, 2, 3, 4, 5, 6, 7, 8, 9, `R`, 0, n2].map((r2) => {
      let i2 = r2;
      return r2 === `backspace` ? i2 = x(se, {}) : r2 === `submit` && (i2 = x(y, {})), x(a, { variant: `outlined`, title: r2 === `R` ? this.state.lockPinInput ? R.t(`reset`) : R.t(`close`) : r2 === n2 ? `enter` : ``, onClick: () => {
        if (r2 === `submit`) this.state.lockPinInput === t2 ? (this.state.dialogPin.oid === `open` ? this.props.context.setValue(this.state.rxData[`open${e3}`], true) : this.props.context.setValue(this.state.rxData[`oid${e3}`], true), this.setState({ dialogPin: null })) : (this.setState({ lockPinInput: ``, invalidPin: true }), setTimeout(() => this.setState({ invalidPin: false }), 500));
        else if (r2 === `backspace`) this.setState({ lockPinInput: this.state.lockPinInput.slice(0, -1) });
        else if (r2 === `R`) this.state.lockPinInput ? this.setState({ lockPinInput: `` }) : this.setState({ dialogPin: null });
        else {
          let i3 = this.state.lockPinInput + r2;
          this.setState({ lockPinInput: i3 }), n2 === `backspace` && i3 === t2 && (this.state.dialogPin.oid === `open` ? this.props.context.setValue(this.state.rxData[`open${e3}`], true) : this.props.context.setValue(this.state.rxData[`oid${e3}`], true), this.setState({ dialogPin: null }));
        }
      }, children: i2 === `R` ? this.state.lockPinInput ? `R` : `x` : i2 }, r2);
    }) })] })] });
  }
  lockGetPinCode(e3) {
    return this.state.rxData[`oid-pincode${e3}`] ? this.getPropertyValue(`oid-pincode${e3}`) : this.state.rxData[`pincode${e3}`];
  }
  lockRenderConfirmDialog() {
    if (!this.state.lockConfirmDialog) return null;
    let e3 = this.state.lockConfirmDialog.index;
    return T(p, { open: true, onClose: () => this.setState({ lockConfirmDialog: null }), children: [x(l, { children: R.t(`please_confirm`) }), T(s, { children: [x(a, { variant: `contained`, color: `primary`, onClick: () => {
      this.setState({ lockConfirmDialog: null }), this.state.lockConfirmDialog.oid === `open` ? this.props.context.setValue(this.state.rxData[`open${e3}`], true) : this.props.context.setValue(this.state.rxData[`oid${e3}`], true);
    }, startIcon: this.state.lockConfirmDialog.oid === `open` ? x(me, {}) : x(k, {}), children: R.t(`Open`) }), x(a, { variant: `contained`, color: `grey`, autoFocus: true, onClick: () => this.setState({ lockConfirmDialog: null }), startIcon: x(re, {}), children: R.t(`Cancel`) })] })] });
  }
  lockRenderLine(e3, t2, n2) {
    if (!this.state.objects[e3] || typeof this.state.objects[e3] == `string`) return null;
    let r2 = this.state.objects[e3], i2 = 30;
    t2 && (i2 = Math.min((t2 - 32) / 2, n2 - 16));
    let a2 = this.state.rxData[`sensor${e3}`] && this.getPropertyValue(`sensor${e3}`), o2 = this.getPropertyValue(`oid${e3}`), s2 = this.state.rxData[`working${e3}`] && this.getPropertyValue(`working${e3}`), l2 = T(`div`, { style: { display: `flex` }, children: [this.state.rxData[`sensor${e3}`] || this.state.rxData[`open${e3}`] ? x(c, { disabled: !this.state.rxData[`open${e3}`], title: this.state.rxData[`open${e3}`] ? R.t(`open_door`) : void 0, onClick: () => {
      this.lockGetPinCode(e3) ? this.setState({ dialogPin: { oid: `open`, index: e3 }, lockPinInput: `` }) : this.state.rxData[`doNotConfirm${e3}`] ? this.props.context.setValue(this.state.rxData[`open${e3}`], true) : this.setState({ lockConfirmDialog: { oid: `open`, index: e3 } });
    }, children: x(pe, { open: a2, size: i2 }) }, `door`) : null, this.state.rxData[`oid${e3}`] ? T(c, { title: o2 ? R.t(`close_lock`) : R.t(`open_lock`), onClick: () => {
      !o2 && this.lockGetPinCode(e3) ? this.setState({ dialogPin: { oid: `oid`, index: e3 }, lockPinInput: `` }) : o2 || this.state.rxData[`doNotConfirm${e3}`] ? this.props.context.setValue(this.state.rxData[`oid${e3}`], !this.getPropertyValue(`oid${e3}`)) : this.setState({ lockConfirmDialog: { oid: `oid`, index: e3 } });
    }, children: [s2 ? x(f, { style: $.workingIcon, size: i2 }) : null, x(`style`, { children: `
.iob-lock {
    transition: transform 0.5s ease;
    transform-origin: 15px 60px;
}
.iob-lock-opened {
    transform: rotate(-30deg);
}
.iob-lock-closed {
    transform: rotate(0deg);
}
` }), this.state.rxData[`noLockAnimation${e3}`] ? o2 ? x(k, { style: { ...$.lockSvgIcon, width: i2, height: i2 }, sx: (e4) => ({ color: e4.palette.primary.main }) }) : x(O, { style: { ...$.lockSvgIcon, width: i2, height: i2 } }) : x(he, { className: o2 ? `iob-lock iob-lock-opened` : `iob-lock iob-lock-closed`, opened: o2, style: { color: this.state.rxData[`lockColor${e3}`], height: i2, width: `auto` } })] }, `lock`) : null] });
    if (!t2) return l2;
    let u2 = this.state.rxData[`title${e3}`] || R.getText(r2.common.name) || ``;
    return u2 ? T(`div`, { style: { ...$.buttonDiv, display: `flex`, flexDirection: `column`, alignItems: `center`, width: t2 || void 0, height: n2 || void 0, border: this.state.selectedOne ? `1px dashed gray` : `none`, boxSizing: `border-box` }, children: [l2, x(`div`, { children: u2 })] }, e3) : l2;
  }
  thermostatObjectIDs(e3, t2) {
    [`oid`, `actual`, `boost`, `party`].forEach((n2) => {
      let r2 = `${n2}${e3}`;
      this.state.rxData[r2] && this.state.rxData[r2] !== `nothing_selected` && t2.push(this.state.rxData[r2]);
    });
  }
  thermostatReadObjects(e3, t2, n2, r2) {
    var _a, _b;
    let i2 = this.state.rxData[`oid${e3}`];
    if (t2[i2]) {
      let r3 = t2[i2];
      n2[e3] = { widgetType: `thermostat`, common: r3.common, _id: i2 }, n2[e3].common.min = ((_a = r3 == null ? void 0 : r3.common) == null ? void 0 : _a.min) === void 0 ? 12 : r3.common.min, n2[e3].common.max = ((_b = r3 == null ? void 0 : r3.common) == null ? void 0 : _b.max) === void 0 ? 30 : r3.common.max;
    } else n2[e3] = { widgetType: `thermostat`, common: {}, _id: i2 };
    i2 = this.state.rxData[`actual${e3}`], r2[e3] = {}, t2[i2] ? r2[e3].actual = { common: t2[i2].common, _id: i2, type: `state`, native: {} } : r2[e3] = null;
  }
  thermIsWithPowerButton(e3) {
    return !!this.state.rxData[`switch${e3}`] && this.state.rxData[`switch${e3}`] !== `nothing_selected`;
  }
  thermIsWithModeButtons(e3) {
    return !(!this.state.rxData[`party${e3}`] && !this.state.rxData[`boost${e3}`] || this.state.rxData[`switch${e3}`] && !this.state.values[`${this.state.rxData[`switch${e3}`]}.val`]);
  }
  thermostatRenderDialog(e3) {
    var _a, _b, _c, _d, _e2, _f, _g, _h, _i;
    if (!this.state.objects[e3] || typeof this.state.objects[e3] == `string`) return null;
    let t2 = this.state.objects[e3], n2 = null;
    t2._id && (n2 = this.state.values[`${t2._id}.val`], n2 === void 0 && (n2 = null), n2 !== null && t2.common.min !== void 0 && n2 < t2.common.min ? n2 = t2.common.min : n2 !== null && t2.common.max !== void 0 && n2 > t2.common.max && (n2 = t2.common.max), n2 === null && t2.common.min !== void 0 && t2.common.max !== void 0 && (n2 = (t2.common.max - t2.common.min) / 2 + t2.common.min));
    let r2 = (_a = this.state.secondaryObjects[e3]) == null ? void 0 : _a.actual, i2 = null;
    r2 && (i2 = this.state.values[`${r2._id}.val`], i2 === void 0 && (i2 = null));
    let s2 = window.innerWidth > window.innerHeight ? window.innerHeight : window.innerWidth;
    s2 > 200 && (s2 = 200);
    let l2 = Math.round(s2 / 25);
    l2 < 8 && (l2 = 8), i2 = i2 === null ? null : this.formatValue(i2, 1);
    let u2 = ((_f = (_e2 = (_d = (_c = (_b = this.props.customSettings) == null ? void 0 : _b.viewStyle) == null ? void 0 : _c.overrides) == null ? void 0 : _d.palette) == null ? void 0 : _e2.primary) == null ? void 0 : _f.main) || ((_g = this.props.context.theme) == null ? void 0 : _g.palette.primary.main) || `#448aff`, d2 = [];
    if (this.thermIsWithModeButtons(e3)) {
      if (this.state.rxData[`party${e3}`]) {
        let t3 = this.state.values[`${this.state.rxData[`party${e3}`]}.val`];
        t3 = t3 == null ? false : t3 === `1` || t3 === `true` || t3 === true, d2.push(x(a, { color: t3 ? `primary` : `grey`, onClick: () => {
          let t4 = this.state.values[`${this.state.rxData[`party${e3}`]}.val`];
          t4 = t4 == null ? false : t4 === `1` || t4 === `true` || t4 === true;
          let n3 = JSON.parse(JSON.stringify(this.state.values));
          n3[`${this.state.rxData[`party${e3}`]}.val`] = !t4, this.setState(n3), this.props.context.setValue(this.state.rxData[`party${e3}`], !t4);
        }, startIcon: x(ce, {}), children: R.t(`Party`) }, `party`));
      }
      if (this.state.rxData[`boost${e3}`]) {
        let t3 = this.state.values[`${this.state.rxData[`boost${e3}`]}.val`];
        t3 = t3 == null ? false : t3 === `1` || t3 === `true` || t3 === true, d2.push(x(a, { color: t3 ? `primary` : `grey`, onClick: () => {
          let t4 = this.state.values[`${this.state.rxData[`boost${e3}`]}.val`];
          t4 = t4 == null ? false : t4 === `1` || t4 === `true` || t4 === true;
          let n3 = JSON.parse(JSON.stringify(this.state.values));
          n3[`${this.state.rxData[`boost${e3}`]}.val`] = !t4, this.setState(n3), this.props.context.setValue(this.state.rxData[`boost${e3}`], !t4);
        }, startIcon: x(le, {}), children: R.t(`Boost`) }, `boost`));
      }
    }
    return this.thermIsWithPowerButton(e3) && d2.push(x(h, { title: R.t(`power`).replace(`vis_2_widgets_nils_`, ``), slotProps: { popper: { sx: $.tooltip } }, children: x(c, { color: this.state.values[`${this.state.rxData[`switch${e3}`]}.val`] ? `primary` : `grey`, onClick: () => {
      let t3 = JSON.parse(JSON.stringify(this.state.values)), n3 = `${this.state.rxData[`switch${e3}`]}.val`;
      t3[n3] = !t3[n3], this.setState(t3), this.props.context.setValue(this.state.rxData[`switch${e3}`], t3[n3]);
    }, children: x(A, {}) }) }, `power`)), T(o, { component: `div`, sx: $.thermostatCircleDiv, style: { height: `100%` }, children: [s2 && t2 ? T(Ee, { minValue: t2.common.min, maxValue: t2.common.max, size: s2, arcColor: u2, arcBackgroundColor: this.props.context.themeType === `dark` ? `#DDD` : `#222`, startAngle: 40, handleSize: l2, endAngle: 320, handle1: { value: n2 || 0, onChange: (n3) => {
      let r3 = JSON.parse(JSON.stringify(this.state.values));
      this.state.rxData[`step${e3}`] === `0.5` ? r3[`${t2._id}.val`] = Math.round(n3 * 2) / 2 : r3[`${t2._id}.val`] = Math.round(n3), this.setState({ values: r3 });
    } }, onControlFinished: () => this.props.context.setValue(t2._id, this.state.values[`${t2._id}.val`]), children: [n2 === null ? null : x(h, { title: R.t(`desired_temperature`), slotProps: { popper: { sx: $.tooltip } }, children: T(`div`, { style: { ...$.thermostatDesiredTemp, fontSize: Math.round(s2 / 6), ...this.customStyle }, children: [x(j, { style: { width: s2 / 8, height: s2 / 8 } }), T(`div`, { style: { display: `flex`, alignItems: `top`, ...this.customStyle }, children: [this.formatValue(n2), x(`span`, { style: { fontSize: Math.round(s2 / 12), fontWeight: `normal` }, children: this.state.rxData[`unit${e3}`] || ((_h = t2.common) == null ? void 0 : _h.unit) })] })] }) }), i2 === null ? null : x(`style`, { children: `
@keyframes vis-2-widgets-nils-fork-newValueAnimationLight {
    0% {
        color: #00bd00;
    },
    80% {
        color: #008000;
    },
    100% {
        color: #000;
    }
}

@keyframes vis-2-widgets-nils-fork-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: #ffffff;
    }
}                          
                            ` }), i2 === null ? null : x(h, { title: R.t(`actual_temperature`), slotProps: { popper: { sx: $.tooltip } }, children: T(`div`, { style: { ...this.props.context.themeType === `dark` ? $.thermostatNewValueDark : $.thermostatNewValueLight, fontSize: Math.round(s2 * 0.6 / 6), opacity: 0.7, ...this.customStyle }, children: [i2, this.state.rxData[`unit${e3}`] || ((_i = r2 == null ? void 0 : r2.common) == null ? void 0 : _i.unit)] }, `${i2}valText`) })] }) : null, x(`div`, { style: { ...$.thermostatButtonsDiv, bottom: 8 }, children: d2 })] });
  }
  rgbGetIdMin = (e3, t2) => {
    var _a, _b, _c, _d;
    return t2 === `color_temperature` ? parseInt(this.state.rxData[`ct_min${e3}`], 10) || ((_b = (_a = this.state.secondaryObjects[e3][t2]) == null ? void 0 : _a.common) == null ? void 0 : _b.min) || 0 : ((_d = (_c = this.state.secondaryObjects[e3][t2]) == null ? void 0 : _c.common) == null ? void 0 : _d.min) || 0;
  };
  rgbGetIdMax = (e3, t2) => {
    var _a, _b, _c, _d;
    return t2 === `color_temperature` ? parseInt(this.state.rxData[`ct_max${e3}`] || ((_b = (_a = this.state.secondaryObjects[e3][t2]) == null ? void 0 : _a.common) == null ? void 0 : _b.max), 10) || 0 : ((_d = (_c = this.state.secondaryObjects[e3][t2]) == null ? void 0 : _c.common) == null ? void 0 : _d.min) || 0;
  };
  rgbSetId = (e3, t2, n2, r2) => {
    var _a, _b;
    if (this.state.secondaryObjects[e3][t2]) {
      this.timeouts || (this.timeouts = {}), (_a = this.timeouts)[e3] || (_a[e3] = {});
      let i2 = this.state.rxData[t2 + e3];
      if (this.timeouts[e3][t2] && clearTimeout(this.timeouts[e3][t2]), r2) this.setState({ controlValue: { id: i2, value: n2, changed: !!((_b = this.state.controlValue) == null ? void 0 : _b.changed) } }, () => {
        this.timeouts[e3][t2] = setTimeout(() => {
          this.timeouts[e3][t2] = null, this.props.context.setValue(i2, n2);
        }, parseInt(this.state.rxData[`timeout${e3}`], 10) || 200);
      });
      else if (t2 === `switch` || t2 === `white_mode`) {
        let t3 = { ...this.state.values, [`switch${e3}.val`]: n2 };
        this.setState({ values: t3 }, () => {
          this.props.context.setValue(this.state.rxData[`switch${e3}`], n2);
        });
      } else {
        let r3 = { ...this.state.values, [`${i2}.val`]: n2 };
        this.setState({ values: r3 }, () => {
          this.timeouts[e3][t2] = setTimeout(() => {
            this.timeouts[e3][t2] = null, this.props.context.setValue(i2, n2);
          }, parseInt(this.state.rxData[`timeout${e3}`], 10) || 200);
        });
      }
    }
  };
  rgbObjectIDs(e3, t2) {
    z.forEach((n2) => {
      let r2 = `${n2}${e3}`;
      this.state.rxData[r2] && this.state.rxData[r2] !== `nothing_selected` && t2.push(this.state.rxData[r2]);
    }), t2.push(this.state.rxData[`oid${e3}`]);
  }
  rgbReadObjects(e3, t2, n2, r2) {
    var _a, _b, _c, _d, _e2;
    let i2 = {};
    if (z.forEach((n3) => {
      let r3 = `${n3}${e3}`, a2 = this.state.rxData[r3];
      if (a2) {
        let e4 = t2[a2];
        e4 && (i2[n3] = e4);
      }
    }), i2.oid = t2[this.state.rxData[`oid${e3}`]], r2[e3] = i2, i2.color_temperature) {
      let t3 = [], n3 = parseInt(this.state.rxData[`ct_min${e3}`] || ((_b = (_a = i2.color_temperature) == null ? void 0 : _a.common) == null ? void 0 : _b.min) || `0`, 10) || 2700, r3 = parseInt(this.state.rxData[`ct_max${e3}`] || ((_d = (_c = i2.color_temperature) == null ? void 0 : _c.common) == null ? void 0 : _d.max) || `0`, 10) || 6e3, a2 = (r3 - n3) / 20;
      for (let e4 = n3; e4 <= r3; e4 += a2) t3.push(H(e4));
      i2.color_temperature.colors = t3;
    }
    n2[e3] = { widgetType: `rgb`, common: (_e2 = i2.oid) == null ? void 0 : _e2.common, _id: this.state.rxData[`oid${e3}`] };
  }
  rgbDestroy() {
    if (this.timeouts) for (let e3 in this.timeouts) for (let t2 in this.timeouts[e3]) this.timeouts[e3][t2] && (clearTimeout(this.timeouts[e3][t2]), this.timeouts[e3][t2] = null);
  }
  rgbIsOnlyHue = (e3) => this.state.rxData[`rgbType${e3}`] === `hue/sat/lum` && (!this.state.secondaryObjects[e3].saturation || !this.state.secondaryObjects[e3].luminance);
  rgbGetWheelColor = (e3) => {
    let t2 = { h: 0, s: 0, v: 0, a: 1 };
    if (this.state.rxData[`rgbType${e3}`] === `hue/sat/lum`) t2 = Se({ h: this.getPropertyValue(`hue${e3}`), s: this.rgbIsOnlyHue(e3) ? 100 : this.getPropertyValue(`saturation${e3}`), l: this.rgbIsOnlyHue(e3) ? 50 : this.getPropertyValue(`luminance${e3}`), a: 1 });
    else if (this.state.rxData[`rgbType${e3}`] === `r/g/b` || this.state.rxData[`rgbType${e3}`] === `r/g/b/w`) t2 = _e({ r: this.getPropertyValue(`red${e3}`), g: this.getPropertyValue(`green${e3}`), b: this.getPropertyValue(`blue${e3}`), a: 1 });
    else if (this.state.rxData[`rgbType${e3}`] === `rgb`) try {
      let n2 = this.getPropertyValue(`oid${e3}`) || ``;
      t2 = n2 && n2.length >= 4 ? V(n2) : V(`#000000`);
    } catch (e4) {
      console.error(e4);
    }
    else if (this.state.rxData[`rgbType${e3}`] === `rgbw`) try {
      let n2 = this.getPropertyValue(`oid${e3}`) || ``;
      t2 = n2 && n2.length >= 4 ? V(n2) : V(`#000000`);
    } catch (e4) {
      console.error(e4);
    }
    return (this.state.rxData[`hideBrightness${e3}`] === true || this.state.rxData[`hideBrightness${e3}`] === `true`) && (t2.v = 100), t2;
  };
  rgbSetWheelColor = (e3, t2) => {
    if (this.state.rxData[`rgbType${e3}`] === `hue/sat/lum`) {
      let n2 = ge(t2);
      this.rgbSetId(e3, `hue`, n2.h), this.rgbIsOnlyHue(e3) || (this.rgbSetId(e3, `saturation`, n2.s), this.rgbSetId(e3, `luminance`, n2.l));
    } else if (this.state.rxData[`rgbType${e3}`] === `r/g/b` || this.state.rxData[`rgbType${e3}`] === `r/g/b/w`) {
      let n2 = be(t2);
      this.rgbSetId(e3, `red`, n2.r), this.rgbSetId(e3, `green`, n2.g), this.rgbSetId(e3, `blue`, n2.b);
    } else if (this.state.rxData[`rgbType${e3}`] === `rgb`) this.rgbSetId(e3, `oid`, W(t2));
    else if (this.state.rxData[`rgbType${e3}`] === `rgbw`) {
      if (this.state.secondaryObjects[e3].white) this.rgbSetId(e3, `oid`, W(t2));
      else {
        let n2 = this.getPropertyValue(`oid${e3}`) || `#00000000`;
        n2 = W(t2) + n2.substring(7), this.rgbSetId(e3, `oid`, n2);
      }
    }
  };
  rgbGetWhite = (e3) => {
    var _a;
    if (this.state.rxData[`rgbType${e3}`] === `r/g/b/w`) return this.getPropertyValue(`white${e3}`);
    if (this.state.rxData[`rgbType${e3}`] === `rgbw`) {
      if (this.state.secondaryObjects[e3].white) return this.getPropertyValue(`white${e3}`);
      let t2 = (_a = this.getPropertyValue(`oid${e3}`)) == null ? void 0 : _a.substring(7);
      return parseInt(t2, 16);
    }
    return 0;
  };
  rgbGetWhiteId = (e3) => this.state.rxData[`rgbType${e3}`] === `r/g/b/w` ? this.state.rxData[`white${e3}`] : this.state.rxData[`rgbType${e3}`] === `rgbw` ? this.state.secondaryObjects[e3].white ? this.state.rxData[`white${e3}`] : this.state.rxData[`oid${e3}`] : ``;
  rgbSetWhite = (e3, t2) => {
    if (this.state.rxData[`rgbType${e3}`] === `r/g/b/w`) this.rgbSetId(e3, `white`, t2, true);
    else if (this.state.rxData[`rgbType${e3}`] === `rgbw`) {
      if (this.state.secondaryObjects[e3].white) this.rgbSetId(e3, `white`, t2, true);
      else {
        let n2 = this.getPropertyValue(`oid${e3}`) || `#00000000`;
        n2 = n2.substring(0, 7) + t2.toString(16).padStart(2, `0`), this.rgbSetId(e3, `oid`, n2, true);
      }
    }
  };
  rgbSetWhiteMode = (e3, t2) => {
    this.state.rxData[`white_mode${e3}`] || this.rgbSetId(e3, `white_mode`, !!t2);
  };
  rgbGetWhiteMode = (e3) => this.state.rxData[`white_mode${e3}`] ? this.getPropertyValue(`white_mode${e3}`) : null;
  rgbIsRgb = (e3) => (this.state.rxData[`rgbType${e3}`] === `rgb` || this.state.rxData[`rgbType${e3}`] === `rgbw`) && this.state.rxData[`oid${e3}`] ? true : (this.state.rxData[`rgbType${e3}`] === `r/g/b` || this.state.rxData[`rgbType${e3}`] === `r/g/b/w`) && !!this.state.secondaryObjects[e3].red && !!this.state.secondaryObjects[e3].green && !!this.state.secondaryObjects[e3].blue;
  rgbIsWhite = (e3) => this.state.rxData[`rgbType${e3}`] === `rgbw` && !!this.state.rxData[`oid${e3}`] || this.state.rxData[`rgbType${e3}`] === `r/g/b/w` && !!this.state.secondaryObjects[e3].white;
  rgbIsHSL = (e3) => this.state.rxData[`rgbType${e3}`] === `hue/sat/lum` && !!this.state.secondaryObjects[e3].hue;
  rgbRenderSwitch(e3) {
    return this.state.secondaryObjects[e3].switch && T(`div`, { style: { ...$.rgbSliderContainer, justifyContent: `center` }, children: [R.t(`Off`), x(S, { checked: this.getPropertyValue(`switch${e3}`) || false, onChange: (t2) => this.rgbSetId(e3, `switch`, t2.target.checked) }), R.t(`On`)] });
  }
  rgbRenderBrightness(e3) {
    var _a;
    return this.state.secondaryObjects[e3].brightness && T(`div`, { style: $.rgbSliderContainer, children: [x(h, { title: R.t(`Brightness`), slotProps: { popper: { sx: $.tooltip } }, children: x(w, {}) }), x(m, { min: this.rgbGetIdMin(e3, `brightness`) || 0, max: this.rgbGetIdMax(e3, `brightness`) || 100, valueLabelDisplay: `auto`, value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === this.state.rxData[`brightness${e3}`] ? this.state.controlValue.value : this.getPropertyValue(`brightness${e3}`) || 0, onChange: (t2, n2) => this.rgbSetId(e3, `brightness`, n2, true), onChangeCommitted: () => this.finishChanging() })] });
  }
  rgbRenderSketch(e3) {
    return x(`div`, { className: `dark`, style: $.rgbWheel, children: x(Ce, { color: this.rgbGetWheelColor(e3), disableAlpha: true, onChange: (t2) => this.rgbSetWheelColor(e3, t2.hsva) }) });
  }
  rgbRenderWheelTypeSwitch(e3, t2, n2, r2) {
    return !t2 || r2 === null && this.state.rxData[`noRgbPalette${e3}`] ? null : !this.rgbIsOnlyHue(e3) && T(`div`, { style: { textAlign: n2 ? `right` : void 0 }, children: [r2 === null ? null : x(h, { title: R.t(`Switch white mode`), slotProps: { popper: { sx: $.tooltip } }, children: x(c, { onClick: () => this.rgbSetWhiteMode(e3, !r2), color: r2 ? `primary` : `default`, children: x(ve, {}) }) }), !this.state.rxData[`noRgbPalette${e3}`] && r2 !== true ? x(h, { title: R.t(`Switch color picker`), slotProps: { popper: { sx: $.tooltip } }, children: x(c, { onClick: () => {
      let t3 = JSON.parse(JSON.stringify(this.state.sketch));
      t3[e3] = !t3[e3], this.setState({ sketch: t3 });
    }, children: x(U, {}) }) }) : null] });
  }
  rgbRenderBrightnessSlider(e3, t2, n2) {
    return !t2 || this.state.sketch[e3] || n2 || this.state.rxData[`hideBrightness${e3}`] === true || this.state.rxData[`hideBrightness${e3}`] === `true` ? null : !this.rgbIsOnlyHue(e3) && x(ye, { hsva: this.rgbGetWheelColor(e3), onChange: (t3) => this.rgbSetWheelColor(e3, { ...this.rgbGetWheelColor(e3), ...t3 }) });
  }
  rgbRenderWheel(e3, t2, n2) {
    return !t2 || n2 === true ? null : this.state.sketch[e3] ? this.rgbRenderSketch(e3) : x(`div`, { style: $.rgbWheel, children: x(xe, { color: this.rgbGetWheelColor(e3), onChange: (t3) => {
      t3 = JSON.parse(JSON.stringify(t3)), this.rgbSetWheelColor(e3, t3.hsva);
    } }) });
  }
  rgbRenderWhite(e3) {
    var _a;
    if (!this.rgbIsWhite(e3)) return null;
    let t2, n2;
    this.state.secondaryObjects[e3].white ? (t2 = this.rgbGetIdMin(e3, `white`) || 0, n2 = this.rgbGetIdMax(e3, `white`) || 100) : (t2 = 0, n2 = 255);
    let r2 = this.rgbGetWhiteId(e3);
    return T(`div`, { style: $.rgbSliderContainer, children: [x(we, { style: { width: 24, height: 24 } }), x(m, { min: t2, max: n2, valueLabelDisplay: `auto`, value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === r2 ? this.state.controlValue.value : this.rgbGetWhite(e3) || 0, onChange: (t3, n3) => this.rgbSetWhite(e3, n3), onChangeCommitted: () => this.finishChanging() })] });
  }
  rgbRenderColorTemperature(e3, t2) {
    var _a;
    if (this.state.rxData[`rgbType${e3}`] !== `ct` || t2) return null;
    let n2 = this.state.rxData[`color_temperature${e3}`];
    return T(`div`, { style: $.rgbSliderContainer, children: [x(h, { title: R.t(`Color temperature`), slotProps: { popper: { sx: $.tooltip } }, children: x(j, {}) }), x(`div`, { style: { ...$.rgbSliderContainer, background: `linear-gradient(to right, ${this.state.secondaryObjects[e3].color_temperature.colors.map((e4) => `rgb(${e4.red}, ${e4.green}, ${e4.blue})`).join(`, `)})`, flex: `1`, borderRadius: 4 }, children: x(m, { valueLabelDisplay: `auto`, min: this.rgbGetIdMin(e3, `color_temperature`) || 2700, max: this.rgbGetIdMax(e3, `color_temperature`) || 6e3, value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === n2 ? this.state.controlValue.value : this.state.values[`${n2}.val`] || 0, onChange: (t3, n3) => this.rgbSetId(e3, `color_temperature`, n3, true), onChangeCommitted: () => this.finishChanging() }) })] });
  }
  rgbRenderDialog(e3) {
    let t2 = this.rgbIsRgb(e3) || this.rgbIsHSL(e3), n2 = !!this.rgbGetWhiteMode(e3);
    return T(`div`, { style: $.rgbDialogContainer, children: [this.rgbRenderSwitch(e3), this.rgbRenderBrightness(e3), this.rgbRenderWhite(e3), this.rgbRenderWheelTypeSwitch(e3, t2, false, n2), this.rgbRenderWheel(e3, t2, n2), this.rgbRenderBrightnessSlider(e3, t2, n2), this.rgbRenderColorTemperature(e3, n2)] });
  }
  rgbGetColor = (e3) => {
    if (this.state.rxData[`rgbType${e3}`] === `ct`) {
      let t2 = H(this.getPropertyValue(`color_temperature${e3}`));
      return Te({ r: t2.red, g: t2.green, b: t2.blue, a: 1 });
    }
    return W(this.rgbGetWheelColor(e3));
  };
  vacuumObjectIDs(e3, t2) {
    let n2 = Object.keys(K);
    for (let r2 = 0; r2 < n2.length; r2++) {
      let i2 = this.state.rxData[`vacuum-${n2[r2]}-oid${e3}`];
      i2 && t2.push(i2);
    }
  }
  async vacuumReadObjects(e3, t2, n2, r2) {
    r2[e3] = {}, n2[e3] = { widgetType: `vacuum`, common: { name: R.t(`vacuum`) }, _id: `` };
    let i2 = Object.keys(K);
    Object.values(t2).forEach((t3) => {
      let n3 = i2.find((n4) => this.state.rxData[`vacuum-${n4}-oid${e3}`] === t3._id);
      n3 && (r2[e3][n3] = t3);
    }), r2[e3].rooms = await this.vacuumLoadRooms(e3);
  }
  async vacuumLoadRooms(e3) {
    if (this.state.rxData[`vacuum-use-rooms${e3}`] && this.state.rxData[`vacuum-status-oid${e3}`]) {
      let t2 = this.state.rxData[`vacuum-status-oid${e3}`].split(`.`);
      if (t2.length === 4) {
        t2.pop(), t2.pop(), t2.push(`rooms`);
        let e4 = await this.props.context.socket.getObjectViewSystem(`channel`, `${t2.join(`.`)}.room`, `${t2.join(`.`)}.room\u9999`), n2 = [];
        return Object.keys(e4).forEach((t3) => {
          var _a;
          return n2.push({ value: `${t3}.roomClean`, label: R.getText(((_a = e4[t3].common) == null ? void 0 : _a.name) || t3.split(`.`).pop() || ``) });
        }), n2.sort((e5, t3) => e5.label.localeCompare(t3.label)), n2;
      }
    }
    return null;
  }
  vacuumGetValue(e3, t2, n2) {
    var _a;
    let r2 = this.vacuumGetObj(e3, t2);
    if (!r2) return null;
    let i2 = this.state.values[`${r2._id}.val`];
    return !n2 && ((_a = r2.common) == null ? void 0 : _a.states) && r2.common.states !== void 0 && r2.common.states[i2] !== null ? r2.common.states[i2] : i2;
  }
  vacuumGetObj(e3, t2) {
    if (this.state.secondaryObjects[e3]) return this.state.secondaryObjects[e3][t2];
  }
  vacuumRenderBattery(e3) {
    var _a;
    return this.vacuumGetObj(e3, `battery`) ? T(`div`, { style: $.vacuumBattery, children: [this.vacuumGetObj(e3, `is-charging`) && this.vacuumGetValue(e3, `is-charging`) ? x(Ne, {}) : x(Ae, {}), this.vacuumGetValue(e3, `battery`) || 0, ` `, (_a = this.vacuumGetObj(e3, `battery`).common) == null ? void 0 : _a.unit] }) : null;
  }
  vacuumRenderSpeed(e3) {
    let t2 = this.vacuumGetObj(e3, `fan-speed`);
    if (!t2) return null;
    let n2 = {};
    if (Array.isArray(t2.common.states)) {
      let e4 = {};
      t2.common.states.forEach((t3) => e4[t3] = t3), n2 = e4;
    } else n2 = t2.common.states || {};
    let r2 = this.vacuumGetValue(e3, `fan-speed`, true);
    return r2 ?? (r2 = ``), r2 = r2.toString(), [x(a, { style: $.vacuumSpeedContainer, endIcon: x(De, {}), onClick: (e4) => {
      e4.stopPropagation(), this.setState({ showSpeedMenu: e4.currentTarget });
    }, children: n2[r2] !== void 0 && n2[r2] !== null ? R.t(n2[r2]).replace(`vis_2_widgets_nils_`, ``) : r2 }, `speed`), this.state.showSpeedMenu ? x(u, { open: true, anchorEl: this.state.showSpeedMenu, onClose: () => this.setState({ showSpeedMenu: null }), children: Object.keys(n2).map((t3) => x(v, { selected: r2 === t3, onClick: () => {
      let n3 = t3;
      this.setState({ showSpeedMenu: null }, () => this.props.context.setValue(this.state.rxData[`vacuum-fan-speed-oid${e3}`], n3));
    }, children: R.t(n2[t3]).replace(`vis_2_widgets_nils_`, ``) }, t3)) }, `speedMenu`) : null];
  }
  vacuumRenderRooms(e3) {
    var _a;
    let t2 = (_a = this.state.secondaryObjects[e3]) == null ? void 0 : _a.rooms;
    return (t2 == null ? void 0 : t2.length) ? [x(a, { variant: `outlined`, color: `grey`, onClick: (e4) => this.setState({ showRoomsMenu: e4.currentTarget }), children: R.t(`Room`) }, `rooms`), this.state.showRoomsMenu ? x(u, { onClose: () => this.setState({ showRoomsMenu: null }), open: true, anchorEl: this.state.showRoomsMenu, children: t2.map((e4) => x(v, { value: e4.value, onClick: () => {
      let t3 = e4.value;
      this.setState({ showRoomsMenu: null }, () => this.props.context.setValue(t3, true));
    }, children: e4.label }, e4.value)) }, `roomsMenu`) : null] : null;
  }
  vacuumRenderSensors(e3) {
    let t2 = [`filter-left`, `side-brush-left`, `main-brush-left`, `sensors-left`, `cleaning-count`].filter((t3) => this.vacuumGetObj(e3, t3));
    return t2.length ? x(`div`, { style: $.vacuumSensorsContainer, children: x(`div`, { style: $.vacuumSensors, children: t2.map((t3) => {
      let n2 = this.vacuumGetObj(e3, t3);
      return x(ee, { style: $.vacuumSensorCard, children: T(ie, { style: { ...$.vacuumSensorCardContent, paddingBottom: 2 }, children: [T(`div`, { children: [x(`span`, { style: $.vacuumSensorBigText, children: this.vacuumGetValue(e3, t3) || 0 }), ` `, x(`span`, { style: $.vacuumSensorSmallText, children: n2.common.unit })] }), x(`div`, { children: x(`span`, { style: $.vacuumSensorSmallText, children: R.t(t3.replaceAll(`-`, `_`)) }) })] }) }, t3);
    }) }) }) : null;
  }
  vacuumRenderButtons(e3, t2) {
    let n2, r2 = this.vacuumGetObj(e3, `status`), i2, a2;
    return r2 && (i2 = this.vacuumGetValue(e3, `status`), n2 = Y(i2), typeof i2 == `boolean` ? (a2 = i2 ? `cleaning` : `pause`, i2 = i2 ? `Cleaning` : `Pause`) : (i2 ?? (i2 = ``), i2 = i2.toString(), a2 = i2.toLowerCase())), T(`div`, { style: { ...$.vacuumButtons, cursor: t2 ? `pointer` : void 0 }, onClick: t2 ? (t3) => {
      t3.stopPropagation(), t3.preventDefault(), this.setState({ showControlDialog: e3 });
    } : void 0, children: [this.vacuumGetObj(e3, `start`) && (!a2 || !Oe.includes(a2)) && x(h, { title: R.t(`Start`), slotProps: { popper: { sx: $.tooltip } }, children: x(c, { onClick: t2 ? void 0 : () => this.props.context.setValue(this.state.rxData[`vacuum-start-oid${e3}`], true), children: x(Me, {}) }) }), this.vacuumGetObj(e3, `pause`) && (!a2 || !ke.includes(a2)) && (!a2 || !G.includes(a2)) && x(h, { title: R.t(`Pause`), slotProps: { popper: { sx: $.tooltip } }, children: x(c, { onClick: t2 ? void 0 : () => this.props.context.setValue(this.state.rxData[`vacuum-pause-oid${e3}`], true), children: x(q, {}) }) }), this.vacuumGetObj(e3, `home`) && (!a2 || !G.includes(a2)) && x(h, { title: R.t(`Home`), slotProps: { popper: { sx: $.tooltip } }, children: x(c, { onClick: t2 ? void 0 : () => this.props.context.setValue(this.state.rxData[`vacuum-home-oid${e3}`], true), children: x(je, {}) }) }), r2 && x(h, { title: R.t(`Status`), slotProps: { popper: { sx: $.tooltip } }, children: x(`div`, { style: { color: n2 }, children: R.t((i2 || ``).toString()).replace(`vis_2_widgets_nils_`, ``) }) })] });
  }
  vacuumRenderMap(e3) {
    let t2 = this.vacuumGetObj(e3, `map64`);
    return t2 ? x(`img`, { src: this.state.values[`${t2._id}.val`], alt: `vacuum`, style: $.vacuumImage }) : this.state.rxData[`vacuum-use-default-picture${e3}`] ? x(J, { style: $.vacuumImage }) : this.state.rxData[`vacuum-own-image${e3}`] ? x(C, { src: this.state.rxData[`vacuum-own-image${e3}`], style: $.vacuumImage }) : null;
  }
  vacuumRenderDialog(e3) {
    let t2 = this.vacuumRenderRooms(e3), n2 = this.vacuumRenderBattery(e3), r2 = 0;
    t2 ? r2 += 36 : n2 && (r2 += 24);
    let i2 = this.vacuumRenderSensors(e3);
    i2 && (r2 += 46);
    let a2 = this.vacuumRenderButtons(e3), o2 = this.vacuumRenderSpeed(e3);
    (a2 || t2) && (r2 += 40);
    let s2 = this.vacuumRenderMap(e3);
    return T(`div`, { style: $.vacuumContent, children: [n2 || t2 ? T(`div`, { style: $.vacuumTopPanel, children: [t2, n2] }) : null, s2 ? x(`div`, { style: { ...$.vacuumMapContainer, height: `calc(100% - ${r2}px)`, width: `100%` }, children: s2 }) : null, i2, a2 || o2 ? T(`div`, { style: $.vacuumBottomPanel, children: [a2, o2] }) : null] });
  }
  checkLineVisibility(e3) {
    let t2 = this.state.rxData[`visibility-oid${e3}`];
    if (!t2) return true;
    let n2 = this.state.rxData[`visibility-cond${e3}`] || `==`, r2 = this.state.values[`${t2}.val`];
    if (r2 == null) return n2 === `not exist`;
    let i2 = this.state.rxData[`visibility-val${e3}`], a2 = this.state.rxData[`visibility-no-hide${e3}`] === true || this.state.rxData[`visibility-no-hide${e3}`] === `true` ? `disabled` : false;
    if (i2 == null) return n2 === `not exist`;
    if (r2 === `null` && n2 !== `exist` && n2 !== `not exist`) return false;
    let o2 = typeof r2;
    switch (o2 === `boolean` || r2 === `false` || r2 === `true` ? i2 = i2 === `true` || i2 === true || i2 === 1 || i2 === `1` : o2 === `number` ? i2 = parseFloat(i2) : o2 === `object` && (r2 = JSON.stringify(r2)), n2) {
      case `==`:
        return i2 = i2.toString(), r2 = r2.toString(), r2 === `1` && (r2 = `true`), i2 === `1` && (i2 = `true`), r2 === `0` && (r2 = `false`), i2 === `0` && (i2 = `false`), i2 !== r2 || a2;
      case `!=`:
        return i2 = i2.toString(), r2 = r2.toString(), r2 === `1` && (r2 = `true`), i2 === `1` && (i2 = `true`), r2 === `0` && (r2 = `false`), i2 === `0` && (i2 = `false`), i2 === r2 || a2;
      case `>=`:
        return r2 < i2 || a2;
      case `<=`:
        return r2 > i2 || a2;
      case `>`:
        return r2 <= i2 || a2;
      case `<`:
        return r2 >= i2 || a2;
      case `consist`:
        return i2 = i2.toString(), r2 = r2.toString(), !r2.toString().includes(i2) || a2;
      case `not consist`:
        return i2 = i2.toString(), r2 = r2.toString(), r2.toString().includes(i2) ? true : a2;
      case `exist`:
        return r2 === `null`;
      case `not exist`:
        return r2 !== `null` || a2;
      default:
        return console.log(`[${this.props.id} / Line ${e3}] Unknown visibility condition: ${n2}`), false;
    }
  }
  renderWidgetBody(e3) {
    super.renderWidgetBody(e3), this.customStyle = {}, this.state.rxStyle && (this.state.rxStyle[`font-weight`] && (this.customStyle.fontWeight = this.state.rxStyle[`font-weight`]), this.state.rxStyle[`font-size`] && (this.customStyle.fontSize = this.state.rxStyle[`font-size`]), this.state.rxStyle[`font-family`] && (this.customStyle.fontFamily = this.state.rxStyle[`font-family`]), this.state.rxStyle[`font-style`] && (this.customStyle.fontStyle = this.state.rxStyle[`font-style`]), this.state.rxStyle[`word-spacing`] && (this.customStyle.wordSpacing = this.state.rxStyle[`word-spacing`]), this.state.rxStyle[`letter-spacing`] && (this.customStyle.letterSpacing = this.state.rxStyle[`letter-spacing`]));
    let t2 = JSON.stringify(this.state.rxData);
    this.lastRxData !== t2 && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
      this.updateTimeout = null, await this.propertiesUpdate();
    }, 50)));
    let n2 = null, r2, i2 = [];
    for (let e4 = 0; e4 < this.state.objects.length; e4++) this.state.objects[e4] && this.state.rxData[`hide${e4}`] !== true && this.state.rxData[`hide${e4}`] !== `true` && i2.push(e4);
    this.state.rxData.type === `lines` && i2.filter((e4) => typeof this.state.objects[e4] != `string`).find((e4) => this.state.objects[e4].widgetType === `switch`) && (n2 = i2.filter((e4) => this.state.objects[e4].widgetType === `switch`).every((e4) => this.isOn(e4)), r2 = !!i2.filter((e4) => this.state.objects[e4].widgetType === `switch`).find((e4) => this.isOn(e4) !== n2));
    let a2 = i2.map((e4) => this.getStateIcon(e4)), o2 = !!a2.find((e4) => e4), s2 = T(b, { children: [this.lockRenderUnlockDialog(), this.lockRenderConfirmDialog(), this.renderControlDialog(), this.renderBlindsDialog(), this.state.rxData.type === `lines` ? i2.map((e4, t3) => {
      var _a;
      let n3 = this.checkLineVisibility(e4);
      if (!this.props.editMode && !n3) return null;
      let r3 = {};
      return this.state.rxData[`widget${e4}`] && this.state.rxData[`height${e4}`] && (r3.height = this.state.rxData[`widget${e4}`]), (!n3 || n3 === `disabled`) && (r3.opacity = 0.3), T(`div`, { style: { ...$.cardsHolder, ...r3, ...n3 === `disabled` ? { pointerEvents: `none` } : void 0 }, children: [T(`span`, { style: { display: `inline-flex`, alignItems: `center` }, children: [o2 ? x(`span`, { style: $.iconSwitch, children: a2[t3] }) : null, this.state.objects[e4].widgetType !== `input` && this.state.objects[e4].widgetType !== `select` ? x(`span`, { style: { color: this.getColor(e4), paddingLeft: 16 }, children: this.state.rxData[`title${e4}`] || R.getText((_a = this.state.objects[e4].common) == null ? void 0 : _a.name) || `` }) : null] }), this.renderLine(e4), n3 === `disabled` ? x(`div`, { style: $.disabledOverlay }) : null] }, e4);
    }) : x(`div`, { style: { ...$.buttonsContainer, flexWrap: this.state.rxData.orientation && this.state.rxData.orientation !== `h` ? `wrap` : `nowrap` }, children: i2.map((e4, t3) => this.renderButton(e4, o2 ? a2[t3] : void 0)) })] }), c2 = (this.state.rxData.allSwitch === true || this.state.rxData.allSwitch === `true`) && i2.length > 1 && n2 !== null ? x(S, { checked: n2, style: r2 ? $.intermediate : void 0, onChange: () => {
      let e4 = JSON.parse(JSON.stringify(this.state.values));
      for (let t3 = 0; t3 <= i2.length; t3++) {
        let r3 = this.state.objects[i2[t3]];
        if (r3 && typeof r3 == `object` && r3._id && r3.widgetType === `switch`) {
          let t4 = `${r3._id}.val`;
          r3.common.type === `boolean` ? (e4[t4] = !n2, this.props.context.setValue(r3._id, e4[t4])) : r3.common.type === `number` ? (e4[t4] = n2 ? r3.common.min : r3.common.max, this.props.context.setValue(r3._id, e4[t4])) : (e4[t4] = !n2, this.props.context.setValue(r3._id, e4[t4] ? `true` : `false`));
        }
      }
      this.setState({ values: e4 });
    } }) : null;
    return this.state.rxData.noCard === true || this.state.rxData.noCard === `true` || e3.widget.usedInWidget ? s2 : (!this.state.rxData.widgetTitle && c2 && (c2 = x(`div`, { style: { textAlign: `right`, width: `100%` }, children: c2 })), this.wrapContent(s2, c2));
  }
};
export {
  Le as default
};
