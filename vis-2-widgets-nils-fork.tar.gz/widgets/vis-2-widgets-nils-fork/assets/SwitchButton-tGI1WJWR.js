import { j as l, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { c as y, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { d as s, G as f, H as O, I as _, p as g, q as m, J as b, K as h, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CgDCyMuJ.js";
import { _ as k, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-Buo0KxVv.js";
import { G as D } from "./Generic-DDdmRdK-.js";
import { __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
let p;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  const c = {
    flashon: b,
    flash_off: h,
    "flash-off": h,
    flashonoutlined: b,
    bulb: m,
    lightbulb: m,
    "lightbulb-outlined": g,
    lightbulboutlined: g,
    power: s,
    power_settings_new: s,
    "power-settings-new": s,
    power_settings_new_rounded: _,
    "power-settings-new-rounded": _,
    toggleon: O,
    toggle_off: f,
    "toggle-off": f,
    toggleoff: f
  };
  function I(i) {
    return (i || "").trim().toLowerCase().replace(/\s+/g, "-").replace(/_+/g, "-").replace(/-+/g, "-");
  }
  function v(i) {
    if (!i) return s;
    const t = I(i), e = c[t];
    if (e) return e;
    const o = t.replace(/^mdi:/, "").replace(/^material-icons:/, "");
    return o && c[o] ? c[o] : null;
  }
  p = class extends D {
    static getWidgetInfo() {
      return {
        id: "tplNils2SwitchButton",
        visSet: "vis-2-widgets-nils-fork",
        visName: "Switch button",
        visWidgetLabel: "switch_button",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "oid",
                type: "id",
                label: "switch_button_oid"
              },
              {
                name: "color",
                type: "color",
                label: "switch_button_color",
                default: "#9e9e9e"
              },
              {
                name: "colorOn",
                type: "color",
                label: "switch_button_color_on",
                default: "#4caf50"
              },
              {
                name: "colorOff",
                type: "color",
                label: "switch_button_color_off",
                default: "#9e9e9e"
              },
              {
                name: "background",
                type: "color",
                label: "switch_button_background",
                default: "#00000000"
              },
              {
                name: "backgroundOn",
                type: "color",
                label: "switch_button_background_on",
                default: "#4caf5033"
              },
              {
                name: "backgroundOff",
                type: "color",
                label: "switch_button_background_off",
                default: "#9e9e9e33"
              },
              {
                name: "readOnly",
                type: "checkbox",
                label: "read_only",
                noBinding: false
              },
              {
                name: "icon-on",
                type: "icon64",
                label: "switch_button_on_icon"
              },
              {
                name: "icon-off",
                type: "icon64",
                label: "switch_button_off_icon"
              }
            ]
          }
        ],
        visDefaultStyle: {
          position: "absolute",
          width: 40,
          height: 40,
          display: "inline-block"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_switch_button.png"
      };
    }
    getWidgetInfo() {
      return p.getWidgetInfo();
    }
    isOn(t) {
      if (t === true || t === "true") return true;
      if (t === false || t === "false") return false;
      if (typeof t == "number") return t !== 0;
      if (typeof t == "string") {
        const e = t.trim().toLowerCase();
        if (e === "0" || e === "false") return false;
        if (e === "1" || e === "true") return true;
      }
      return !!t;
    }
    getNextValue(t) {
      const e = this.isOn(t);
      if (typeof t == "number") return e ? 0 : 1;
      if (typeof t == "string") {
        const o = t.trim().toLowerCase();
        if (o === "0" || o === "1") return e ? 0 : 1;
      }
      return !e;
    }
    getIconElement(t, e) {
      const o = v(t);
      if (o) {
        const a = o;
        return l.jsx(a, {
          style: {
            width: "70%",
            height: "70%",
            color: e
          }
        });
      }
      const n = t || "power";
      return l.jsx(k, {
        src: n,
        style: {
          width: "70%",
          height: "70%",
          color: e
        }
      });
    }
    renderWidgetBody(t) {
      super.renderWidgetBody(t), t.style.overflow = "visible", t.style.overflowX = "visible", t.style.overflowY = "visible";
      const e = this.state.rxData.oid;
      if (!e) return null;
      const o = this.state.values[`${e}.val`], n = this.isOn(o), a = n ? this.state.rxData["icon-on"] : this.state.rxData["icon-off"], d = this.state.rxData.color || "#9e9e9e", r = n ? this.state.rxData.colorOn || d : this.state.rxData.colorOff || d, w = n ? this.state.rxData.backgroundOn || this.state.rxData.background || "#4caf5033" : this.state.rxData.backgroundOff || this.state.rxData.background || "#9e9e9e33", u = this.state.rxData.readOnly === true || this.state.rxData.readOnly === "true";
      return l.jsx(y, {
        size: "small",
        color: "primary",
        disabled: u,
        onClick: (x) => {
          x.stopPropagation(), u || this.props.context.setValue(e, this.getNextValue(o));
        },
        style: {
          width: "100%",
          height: "100%",
          minWidth: 0,
          minHeight: 0,
          borderRadius: "50%",
          background: w,
          color: r,
          boxShadow: n ? `2px 4px 10px color-mix(in srgb, ${r} 35%, transparent)` : `2px 4px 10px color-mix(in srgb, ${r} 35%, transparent)`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 0,
          transition: "all 0.2s ease"
        },
        "aria-label": n ? "on" : "off",
        children: this.getIconElement(a, r)
      });
    }
  };
});
export {
  __tla,
  p as default
};
