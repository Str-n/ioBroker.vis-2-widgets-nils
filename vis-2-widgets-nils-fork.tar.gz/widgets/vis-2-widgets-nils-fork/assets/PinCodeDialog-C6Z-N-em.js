import { j as i, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { k as f, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { a as _, b as m, d as c, p, _ as u, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { G as r } from "./Generic-DDdmRdK-.js";
import { F as x, r as C, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CpkBFb5h.js";
let y;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })()
]).then(async () => {
  y = function(s) {
    const [n, t] = f(""), [a, o] = f(false);
    return i.jsxs(_, {
      open: true,
      onClose: () => s.onClose(),
      children: [
        i.jsx(m, {
          children: r.t("enter_pin")
        }),
        i.jsxs(c, {
          children: [
            i.jsx("div", {
              style: {
                padding: "10px 0px"
              },
              children: i.jsx(p, {
                variant: "outlined",
                fullWidth: true,
                type: a ? "text" : "password",
                slotProps: {
                  input: {
                    readOnly: true,
                    style: {
                      textAlign: "center",
                      color: a ? "#ff3e3e" : "inherit"
                    }
                  }
                },
                value: a ? r.t("invalid_pin") : n
              })
            }),
            i.jsx("div", {
              style: {
                display: "grid",
                gridTemplateColumns: "1fr 1fr 1fr",
                gridGap: "10px"
              },
              children: [
                1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                "R",
                0,
                s.pinCodeReturnButton
              ].map((e) => {
                let l = e;
                return e === "backspace" ? l = i.jsx(x, {}) : e === "submit" && (l = i.jsx(C, {})), i.jsx(u, {
                  variant: "outlined",
                  title: e === "R" ? n ? r.t("reset") : r.t("close") : e === s.pinCodeReturnButton ? "enter" : "",
                  onClick: () => {
                    if (e === "submit") n === s.pinCode ? s.onClose(true) : (o(true), t(""), setTimeout(() => o(false), 500));
                    else if (e === "backspace") t(n.slice(0, -1));
                    else if (e === "R") n ? t("") : s.onClose();
                    else {
                      const d = n + e;
                      t(d), s.pinCodeReturnButton === "backspace" && d === n && s.onClose(true);
                    }
                  },
                  children: l === "R" ? n ? "R" : "x" : l
                }, e);
              })
            })
          ]
        })
      ]
    });
  };
});
export {
  y as P,
  __tla
};
