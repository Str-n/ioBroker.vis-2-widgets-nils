import { j as h, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { a as c, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { B as u, __tla as __tla_2 } from "./BlindsBase-R_xxlO0J.js";
import { __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
import "./Generic-DDdmRdK-.js";
import { __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_system__loadShare__.js-BtyZ_WHy.js";
import { __tla as __tla_6 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CgDCyMuJ.js";
import { __tla as __tla_7 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-Buo0KxVv.js";
let p;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })()
]).then(async () => {
  const m = {
    cardContent: {
      flex: 1,
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      width: "100%",
      overflow: "hidden",
      height: "100%"
    }
  };
  p = class extends u {
    refCardContent = c.createRef();
    lastRxData;
    updateTimeout;
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        objects: []
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2Blinds",
        visSet: "vis-2-widgets-nils-fork",
        visName: "Blinds",
        visWidgetLabel: "blinds",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                hidden: "!!data.externalDialog"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "sashCount",
                type: "number",
                default: 1,
                label: "sash_count"
              },
              {
                name: "ratio",
                type: "slider",
                min: 0.1,
                max: 3,
                step: 0.1,
                label: "window_ratio",
                default: 1
              },
              {
                name: "borderWidth",
                type: "slider",
                min: 0,
                max: 100,
                step: 0.1,
                label: "border_width",
                default: 3
              },
              {
                name: "oid",
                type: "id",
                default: "",
                label: "blinds_position_oid",
                noInit: true,
                onChange: async (t, i, a, o) => {
                  if (i[t.name]) {
                    const n = await o.getObject(i[t.name]);
                    if (n == null ? void 0 : n.common) {
                      let d = false;
                      const e = n._id.split(".");
                      e.pop();
                      const s = await o.getObjectViewSystem("state", `${e.join(".")}.`, `${e.join(".")}.\u9999`);
                      s && Object.values(s).forEach((l) => {
                        var _a, _b;
                        ((_b = (_a = l == null ? void 0 : l.common) == null ? void 0 : _a.role) == null ? void 0 : _b.includes("stop")) && (i.blinds_stop_oid = l._id, d = true);
                      }), d && a(i);
                    }
                  }
                }
              },
              {
                name: "oid_stop",
                type: "id",
                default: "",
                label: "blinds_stop_oid",
                noInit: true,
                hidden: (t) => !t.oid
              },
              {
                label: "show_value",
                type: "checkbox",
                name: "showValue",
                hidden: (t) => !t.oid,
                default: true
              },
              {
                label: "min_position",
                type: "number",
                hidden: (t) => !t.oid,
                name: "min"
              },
              {
                label: "max_position",
                type: "number",
                hidden: (t) => !t.oid,
                name: "max"
              },
              {
                label: "invert_position",
                type: "checkbox",
                hidden: (t) => !t.oid,
                name: "invert"
              },
              {
                name: "externalDialog",
                label: "use_as_dialog",
                type: "checkbox",
                tooltip: "use_as_dialog_tooltip"
              }
            ]
          },
          {
            name: "sashes",
            label: "sash",
            indexFrom: 1,
            indexTo: "sashCount",
            fields: [
              {
                name: "slideSensor_oid",
                type: "id",
                label: "slide_sensor_oid",
                noInit: true
              },
              {
                name: "slideHandle_oid",
                type: "id",
                label: "handle_sensor_oid",
                noInit: true
              },
              {
                name: "slideType",
                type: "select",
                label: "sash_type",
                options: [
                  {
                    value: "",
                    label: "sash_none"
                  },
                  {
                    value: "left",
                    label: "left"
                  },
                  {
                    value: "right",
                    label: "right"
                  },
                  {
                    value: "top",
                    label: "top"
                  },
                  {
                    value: "bottom",
                    label: "bottom"
                  }
                ]
              },
              {
                name: "slideRatio",
                type: "slider",
                label: "slide_ratio",
                default: 1,
                min: 0.1,
                max: 4,
                step: 0.1,
                hidden: (t) => t.sashCount < 2
              },
              {
                name: "slidePos_oid",
                type: "id",
                default: "",
                label: "blinds_position_oid",
                hidden: (t) => !!t.oid,
                noInit: true,
                onChange: async (t, i, a, o) => {
                  if (i[t.name]) {
                    const n = await o.getObject(i[t.name]), d = t.name.match(/(\d+)$/)[1];
                    if (n == null ? void 0 : n.common) {
                      let e = false;
                      const s = n._id.split(".");
                      s.pop();
                      const l = await o.getObjectViewSystem("state", `${s.join(".")}.`, `${s.join(".")}.\u9999`);
                      l && Object.values(l).forEach((r) => {
                        var _a, _b;
                        ((_b = (_a = r == null ? void 0 : r.common) == null ? void 0 : _a.role) == null ? void 0 : _b.includes("stop")) && (i[`slideStop_oid${d}`] = r._id, e = true);
                      }), e && a(i);
                    }
                  }
                }
              },
              {
                name: "slideStop_oid",
                type: "id",
                default: "",
                label: "blinds_stop_oid",
                noInit: true,
                hidden: (t, i) => !!t.oid || !t[`slidePos_oid${i}`]
              },
              {
                label: "min_position",
                type: "number",
                hidden: (t, i) => !!t.oid || !t[`slidePos_oid${i}`],
                name: "slideMin"
              },
              {
                label: "max_position",
                type: "number",
                hidden: (t, i) => !!t.oid || !t[`slidePos_oid${i}`],
                name: "slideMax"
              },
              {
                label: "invert_position",
                type: "checkbox",
                hidden: (t, i) => !!t.oid || !t[`slidePos_oid${i}`],
                name: "slideInvert"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_blinds.png"
      };
    }
    getWidgetInfo() {
      return p.getWidgetInfo();
    }
    async propertiesUpdate() {
      var _a;
      const t = JSON.stringify(this.state.rxData);
      if (this.lastRxData === t) return;
      this.lastRxData = t;
      const i = [], a = [];
      for (let e = 1; e <= this.state.rxData.sashCount; e++) this.state.rxData[`slidePos_oid${e}`] && this.state.rxData[`slidePos_oid${e}`] !== "nothing_selected" && a.push(this.state.rxData[`slidePos_oid${e}`]);
      this.state.rxData.oid && this.state.rxData.oid !== "nothing_selected" && a.push(this.state.rxData.oid);
      const o = a.length ? await this.props.context.socket.getObjectsById(a) : {}, d = ((_a = o[this.state.rxData.oid] || null) == null ? void 0 : _a.common) || {};
      for (let e = 1; e <= this.state.rxData.sashCount; e++) if (this.state.rxData[`slidePos_oid${e}`] && this.state.rxData[`slidePos_oid${e}`] !== "nothing_selected") {
        const s = o[this.state.rxData[`slidePos_oid${e}`]];
        i[e] = {
          common: (s == null ? void 0 : s.common) || {},
          _id: this.state.rxData[`slidePos_oid${e}`],
          widgetType: "blinds"
        };
      }
      (JSON.stringify(i) !== JSON.stringify(this.state.objects) || JSON.stringify(d) !== JSON.stringify(this.state.main)) && this.setState({
        objects: i,
        main: d
      });
    }
    async componentDidMount() {
      super.componentDidMount(), await this.propertiesUpdate();
    }
    async onRxDataChanged() {
      await this.propertiesUpdate();
    }
    onCommand(t) {
      const i = super.onCommand(t);
      if (i === false) {
        if (t === "openDialog") return this.setState({
          showBlindsDialog: true
        }), true;
        if (t === "closeDialog") return this.setState({
          showBlindsDialog: false
        }), true;
      }
      return i;
    }
    renderWidgetBody(t) {
      super.renderWidgetBody(t);
      const i = JSON.stringify(this.state.rxData);
      this.lastRxData !== i && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
        this.updateTimeout = void 0, await this.propertiesUpdate();
      }, 50)));
      let a, o;
      if (!this.refCardContent.current) setTimeout(() => this.forceUpdate(), 50);
      else {
        a = this.refCardContent.current.offsetHeight;
        let e = 0;
        for (let s = 1; s <= this.state.rxData.sashCount; s++) (this.state.rxData[`slideSensor_oid${s}`] || this.state.rxData[`slideHandle_oid${s}`]) && e < this.state.rxData[`slideRatio${s}`] && (e = this.state.rxData[`slideRatio${s}`]);
        if (o = this.refCardContent.current.offsetWidth, e) {
          const s = o / this.state.rxData.sashCount * e;
          a -= 0.12 * s;
        }
      }
      const n = this.getMinMaxPosition(0);
      a -= 8;
      const d = h.jsxs("div", {
        ref: this.refCardContent,
        style: {
          ...m.cardContent,
          cursor: n.hasControl ? "pointer" : void 0
        },
        onClick: n.hasControl ? (e) => {
          e.stopPropagation(), e.preventDefault(), (!this.lastClick || Date.now() - this.lastClick > 300) && this.setState({
            showBlindsDialog: true
          });
        } : void 0,
        children: [
          a ? this.renderBlindsDialog() : null,
          a ? this.renderWindows({
            height: a,
            width: o
          }) : null
        ]
      });
      return this.state.rxData.externalDialog && !this.props.editMode ? this.renderBlindsDialog() : this.state.rxData.noCard || t.widget.usedInWidget ? d : this.wrapContent(d, this.state.rxData.showValue && n.hasControl ? h.jsxs("span", {
        children: [
          n.shutterPos,
          "%"
        ]
      }) : null);
    }
  };
});
export {
  __tla,
  p as default
};
