import { r as l, __tla as __tla_0 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react_mf_2_dom__loadShare__.js_commonjs-proxy-Bur19Dhn.js";
let d;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function s(o, c) {
    for (var a = 0; a < c.length; a++) {
      const e = c[a];
      if (typeof e != "string" && !Array.isArray(e)) {
        for (const t in e) if (t !== "default" && !(t in o)) {
          const n = Object.getOwnPropertyDescriptor(e, t);
          n && Object.defineProperty(o, t, n.get ? n : {
            enumerable: true,
            get: () => e[t]
          });
        }
      }
    }
    return Object.freeze(Object.defineProperty(o, Symbol.toStringTag, {
      value: "Module"
    }));
  }
  var r = {}, f, u, i = l;
  u = r.createRoot = i.createRoot, f = r.hydrateRoot = i.hydrateRoot;
  d = s({
    __proto__: null,
    get createRoot() {
      return u;
    },
    default: r,
    get hydrateRoot() {
      return f;
    }
  }, [
    r
  ]);
});
export {
  __tla,
  d as c
};
