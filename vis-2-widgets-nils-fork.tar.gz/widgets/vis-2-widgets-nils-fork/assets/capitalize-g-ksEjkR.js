import { p as C, __tla as __tla_0 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
let h, Y, $, a;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  $ = function(r, ...e) {
    const f = new URL(`https://mui.com/production-error/?code=${r}`);
    return e.forEach((i) => f.searchParams.append("args[]", i)), `Minified MUI error #${r}; visit ${f} for the full message.`;
  };
  var d = {
    exports: {}
  }, t = {};
  var R = Symbol.for("react.transitional.element"), P = Symbol.for("react.portal"), s = Symbol.for("react.fragment"), l = Symbol.for("react.strict_mode"), c = Symbol.for("react.profiler"), u = Symbol.for("react.consumer"), E = Symbol.for("react.context"), T = Symbol.for("react.forward_ref"), _ = Symbol.for("react.suspense"), p = Symbol.for("react.suspense_list"), m = Symbol.for("react.memo"), S = Symbol.for("react.lazy"), y = Symbol.for("react.view_transition"), M = Symbol.for("react.client.reference");
  function o(r) {
    if (typeof r == "object" && r !== null) {
      var e = r.$$typeof;
      switch (e) {
        case R:
          switch (r = r.type, r) {
            case s:
            case c:
            case l:
            case _:
            case p:
            case y:
              return r;
            default:
              switch (r = r && r.$$typeof, r) {
                case E:
                case T:
                case S:
                case m:
                  return r;
                case u:
                  return r;
                default:
                  return e;
              }
          }
        case P:
          return e;
      }
    }
  }
  t.ContextConsumer = u;
  t.ContextProvider = E;
  t.Element = R;
  t.ForwardRef = T;
  t.Fragment = s;
  t.Lazy = S;
  t.Memo = m;
  t.Portal = P;
  t.Profiler = c;
  t.StrictMode = l;
  t.Suspense = _;
  t.SuspenseList = p;
  t.isContextConsumer = function(r) {
    return o(r) === u;
  };
  t.isContextProvider = function(r) {
    return o(r) === E;
  };
  t.isElement = function(r) {
    return typeof r == "object" && r !== null && r.$$typeof === R;
  };
  t.isForwardRef = function(r) {
    return o(r) === T;
  };
  t.isFragment = function(r) {
    return o(r) === s;
  };
  t.isLazy = function(r) {
    return o(r) === S;
  };
  t.isMemo = function(r) {
    return o(r) === m;
  };
  t.isPortal = function(r) {
    return o(r) === P;
  };
  t.isProfiler = function(r) {
    return o(r) === c;
  };
  t.isStrictMode = function(r) {
    return o(r) === l;
  };
  t.isSuspense = function(r) {
    return o(r) === _;
  };
  t.isSuspenseList = function(r) {
    return o(r) === p;
  };
  t.isValidElementType = function(r) {
    return typeof r == "string" || typeof r == "function" || r === s || r === c || r === l || r === _ || r === p || typeof r == "object" && r !== null && (r.$$typeof === S || r.$$typeof === m || r.$$typeof === E || r.$$typeof === u || r.$$typeof === T || r.$$typeof === M || r.getModuleId !== void 0);
  };
  t.typeOf = o;
  d.exports = t;
  var A = d.exports;
  a = function(r) {
    if (typeof r != "object" || r === null) return false;
    const e = Object.getPrototypeOf(r);
    return (e === null || e === Object.prototype || Object.getPrototypeOf(e) === null) && !(Symbol.toStringTag in r) && !(Symbol.iterator in r);
  };
  function O(r) {
    if (C(r) || A.isValidElementType(r) || !a(r)) return r;
    const e = {};
    return Object.keys(r).forEach((f) => {
      e[f] = O(r[f]);
    }), e;
  }
  Y = function(r, e, f = {
    clone: true
  }) {
    const i = f.clone ? {
      ...r
    } : r;
    return a(r) && a(e) && Object.keys(e).forEach((n) => {
      C(e[n]) || A.isValidElementType(e[n]) ? i[n] = e[n] : a(e[n]) && Object.prototype.hasOwnProperty.call(r, n) && a(r[n]) ? i[n] = Y(r[n], e[n], f) : f.clone ? i[n] = a(e[n]) ? O(e[n]) : e[n] : i[n] = e[n];
    }), i;
  };
  h = function(r) {
    if (typeof r != "string") throw new Error($(7));
    return r.charAt(0).toUpperCase() + r.slice(1);
  };
});
export {
  __tla,
  h as c,
  Y as d,
  $ as f,
  a as i
};
