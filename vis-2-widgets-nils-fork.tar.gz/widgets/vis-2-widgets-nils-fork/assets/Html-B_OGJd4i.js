import { B as e, g as t } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { ft as n } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as r } from "./Generic-BOiMPpxz.js";
e();
var i = class e2 extends r {
  widgetRef = t.createRef();
  doNotWantIncludeWidgets;
  wakeUpInstalled;
  viewChangeInstalled;
  lastRefreshInterval;
  refreshInterval;
  lastWidget;
  constructor(e3) {
    super(e3), this.state = { ...this.state, q: Date.now() };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Static`, visSet: `vis-2-widgets-nils-fork`, visName: `Html template`, visWidgetLabel: `html`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard` }, { name: `html`, type: `html`, default: `Admin Memory: <span style="color: #73b9ff">{system.adapter.admin.0.memHeapTotal.val}MB</span>`, label: `html_template`, hidden: (e3) => !!e3.iframe || !!e3.image || !!e3.image_oid || !!e3.iframe_oid || !!e3.widget }, { name: `iframe`, type: `url`, label: `iframe_url`, hidden: (e3) => !!e3.html || !!e3.image || !!e3.image_oid || !!e3.iframe_oid || !!e3.widget }, { name: `iframe_oid`, type: `id`, label: `iframe_oid`, hidden: (e3) => !!e3.html || !!e3.image || !!e3.image_oid || !!e3.iframe || !!e3.widget }, { name: `image`, type: `url`, label: `image_url`, hidden: (e3) => !!e3.iframe || !!e3.html || !!e3.image_oid || !!e3.iframe_oid || !!e3.widget }, { name: `image_oid`, type: `id`, label: `image_oid`, hidden: (e3) => !!e3.iframe || !!e3.html || !!e3.image || !!e3.iframe_oid || !!e3.widget }, { name: `objectFit`, type: `select`, noTranslation: true, options: [{ value: `fill`, label: `fill` }, { value: `contain`, label: `contain` }, { value: `cover`, label: `cover` }, { value: `none`, label: `none` }, { value: `scale-down`, label: `scale-down` }], default: `fill`, label: `object_fit`, hidden: (e3) => !e3.image && !e3.image_oid }, { name: `refreshInterval`, type: `slider`, min: 0, max: 18e4, step: 100, label: `refresh_interval`, hidden: (e3) => !!e3.html || !!e3.widget }, { name: `refreshOnWakeUp`, type: `checkbox`, label: `refresh_on_wake_up`, hidden: (e3) => !!e3.html || !!e3.widget }, { name: `refreshOnViewChange`, type: `checkbox`, label: `refresh_on_view_change`, hidden: (e3) => !!e3.html || !!e3.widget }, { name: `scrollX`, type: `checkbox`, label: `scroll_x`, hidden: (e3) => !e3.iframe && !e3.iframe_oid }, { name: `scrollY`, type: `checkbox`, label: `scroll_y`, hidden: (e3) => !e3.iframe && !e3.iframe_oid }, { name: `seamless`, type: `checkbox`, label: `seamless`, default: true, hidden: (e3) => !e3.iframe && !e3.iframe_oid }, { name: `noSandbox`, type: `checkbox`, label: `no_sandbox`, default: true, hidden: (e3) => !e3.iframe && !e3.iframe_oid }, { name: `allowUserInteractions`, type: `checkbox`, label: `allow_user_interactions`, default: true, hidden: (e3) => !e3.image && !e3.image_oid }, { name: `refreshWithNoQuery`, type: `checkbox`, label: `refresh_with_no_query`, default: true, hidden: (e3) => !e3.image && !e3.image_oid && !e3.iframe && !e3.iframe_oid }, { name: `widget`, type: `widget`, label: `widget_id`, hidden: (e3) => !!e3.image || !!e3.image_oid || !!e3.iframe || !!e3.iframe_oid || !!e3.html }, { label: `doNotWantIncludeWidgets`, name: `doNotWantIncludeWidgets`, type: `checkbox`, default: false }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_html.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  componentDidMount() {
    var _a, _b;
    super.componentDidMount(), this.reinitInterval(), this.doNotWantIncludeWidgets = !!this.state.rxData.doNotWantIncludeWidgets, (_b = (_a = this.props).askView) == null ? void 0 : _b.call(_a, `update`, { id: this.props.id, uuid: this.uuid, canHaveWidgets: true, doNotWantIncludeWidgets: !!this.state.rxData.doNotWantIncludeWidgets }), this.state.rxData.refreshOnWakeUp && !this.state.rxData.widget && (this.wakeUpInstalled = true, window.vis.onWakeUp(() => this.refresh(), this.props.id)), this.state.rxData.refreshOnViewChange && !this.state.rxData.widget && (this.viewChangeInstalled = true, window.vis.navChangeCallbacks.push({ cb: (e3) => e3 === this.props.view && this.refresh(), id: this.props.id }));
  }
  onCommand(e3, t2) {
    let n2 = super.onCommand(e3, t2);
    if (n2 === false && e3 === `include`) {
      let e4 = JSON.parse(JSON.stringify(this.props.context.views)), n3 = e4[this.props.view].widgets[this.props.id];
      return n3.data.widget = t2, this.props.context.changeProject(e4), true;
    }
    return n2;
  }
  reinitInterval() {
    let e3 = parseInt(this.state.rxData.refreshInterval, 10);
    (e3 !== this.lastRefreshInterval || this.state.rxData.widget !== this.lastWidget) && (this.refreshInterval && clearInterval(this.refreshInterval), this.refreshInterval = void 0, this.lastWidget = this.state.rxData.widget, this.lastRefreshInterval = e3, e3 && !this.lastWidget && (this.refreshInterval = setInterval(() => this.refresh(), e3)));
  }
  componentWillUnmount() {
    super.componentWillUnmount(), this.refreshInterval && clearInterval(this.refreshInterval), this.refreshInterval = void 0, this.wakeUpInstalled && (this.wakeUpInstalled = false, window.vis.onWakeUp(null, this.props.id)), this.viewChangeInstalled && (this.viewChangeInstalled = false, window.vis.navChangeCallbacks = window.vis.navChangeCallbacks.filter((e3) => e3.id !== this.props.id));
  }
  refresh() {
    this.setState({ q: Date.now() });
  }
  getUrl() {
    let e3 = this.state.rxData.image || this.state.rxData.iframe;
    return this.state.rxData.iframe_oid && (e3 = this.state.values[`${this.state.rxData.iframe_oid}.val`]), this.state.rxData.image_oid && (e3 = this.state.values[`${this.state.rxData.image_oid}.val`]), this.state.rxData.refreshWithNoQuery || (e3.includes(`?`) ? e3 += `&_=${this.state.q}` : e3 += `?_=${this.state.q}`), e3;
  }
  renderWidgetBody(e3) {
    var _a, _b;
    super.renderWidgetBody(e3);
    let t2 = this.state.rxData.noCard || e3.widget.usedInWidget;
    typeof this.doNotWantIncludeWidgets == `boolean` && this.doNotWantIncludeWidgets !== !!this.state.rxData.doNotWantIncludeWidgets && (this.doNotWantIncludeWidgets = !!this.state.rxData.doNotWantIncludeWidgets, setTimeout(() => this.props.askView && this.props.askView(`update`, { id: this.props.id, uuid: this.uuid, doNotWantIncludeWidgets: !!this.state.rxData.doNotWantIncludeWidgets }), 100));
    let r2 = { width: `100%`, height: !t2 && this.state.rxData.widgetTitle ? `calc(100% - 36px)` : `100%`, border: `0` };
    Object.keys(this.state.rxStyle).forEach((e4) => {
      if (e4 !== `position` && e4 !== `top` && e4 !== `left` && e4 !== `width` && e4 !== `height` && this.state.rxStyle[e4] !== void 0 && this.state.rxStyle[e4] !== null) {
        if (e4.includes(`-`)) {
          let t3 = this.state.rxStyle[e4];
          e4 = e4.replace(/-./g, (e5) => e5[1].toUpperCase()), r2[e4] = t3;
        } else r2[e4] = this.state.rxStyle[e4];
      }
    });
    let i2;
    if (this.state.rxData.html && (i2 = n(`div`, { dangerouslySetInnerHTML: { __html: this.state.rxData.html }, style: r2 })), this.state.rxData.iframe_oid || this.state.rxData.iframe) {
      let e4 = this.state.rxData.refreshWithNoQuery ? this.state.q : `element`;
      this.reinitInterval(), r2.overflowX = this.state.rxData.scrollX ? `scroll` : `hidden`, r2.overflowY = this.state.rxData.scrollY ? `scroll` : `hidden`, i2 = n(`iframe`, { title: this.props.id, seamless: this.state.rxData.seamless, src: this.getUrl(), style: r2, sandbox: this.state.rxData.noSandbox ? void 0 : `allow-scripts allow-same-origin allow-modals allow-forms allow-pointer-lock allow-popups` }, e4);
    }
    if (this.state.rxData.image || this.state.rxData.image_oid) {
      let e4 = this.state.rxData.refreshWithNoQuery ? this.state.q : `element`;
      this.reinitInterval(), this.state.rxData.allowUserInteractions && (r2.touchAction = `none`, r2.userSelect = `none`, r2.pointerEvents = `none`), r2.objectFit = this.state.rxData.objectFit, i2 = n(`img`, { src: this.getUrl(), style: r2, alt: this.props.id }, e4);
    }
    if (this.state.rxData.widget) {
      this.reinitInterval();
      let e4 = this.state.rxData.widget;
      ((_b = (_a = this.props.context.views[this.props.view]) == null ? void 0 : _a.widgets) == null ? void 0 : _b[e4]) && this.getWidgetInWidget && e4 !== this.props.id && (this.widgetRef.current || setTimeout(() => this.forceUpdate(), 50), r2.justifyContent = `center`, r2.display = `flex`, r2.alignItems = `center`, i2 = n(`div`, { ref: this.widgetRef, style: r2, children: this.widgetRef.current ? this.getWidgetInWidget(this.props.view, e4, { refParent: this.widgetRef }) : null }));
    }
    return i2 || (i2 = n(`div`, { style: r2, children: `---` })), t2 ? i2 : this.wrapContent(i2);
  }
};
export {
  i as default
};
