import { B as e, T as t, g as n } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as r, H as i, I as a, L as o, P as s, ct as c, ft as l, pt as u, r as d, st as f, u as p, z as m } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as h } from "./Lightbulb-BbGK3Qf2.js";
import { t as g } from "./Generic-BOiMPpxz.js";
var _ = f([l(`path`, { d: `M18 6.41 16.59 5 12 9.58 7.41 5 6 6.41l6 6z` }, `0`), l(`path`, { d: `m18 13-1.41-1.41L12 16.17l-4.59-4.58L6 13l6 6z` }, `1`)], `KeyboardDoubleArrowDown`), v = f([l(`path`, { d: `M6 17.59 7.41 19 12 14.42 16.59 19 18 17.59l-6-6z` }, `0`), l(`path`, { d: `m6 11 1.41 1.41L12 7.83l4.59 4.58L18 11l-6-6z` }, `1`)], `KeyboardDoubleArrowUp`), y = f(l(`path`, { d: `M6 6h12v12H6z` }), `Stop`);
e();
var b = `widgets/vis-2-widgets-nils-fork/img`, x = { dialog: { maxWidth: `1000px`, width: `calc(100vw - 32px)` }, dialogContent: { padding: 0, background: `#b8d2dd`, overflow: `hidden` }, dialogTitle: { textAlign: `center` }, wrapperSliderBlock: { display: `flex`, flexDirection: `column`, alignItems: `center`, width: `100%`, position: `relative`, zIndex: 2 }, sceneStack: { display: `flex`, flexDirection: `column`, alignItems: `center`, gap: `0.75em`, width: `100%` }, buttonStopStyle: { float: `left` }, sliderText: { display: `inline-block` }, sliderStyle: { marginTop: `1em`, marginBottom: `1em`, position: `relative`, zIndex: 11, width: `10em`, borderRadius: `2em`, overflow: `hidden`, background: `transparent`, cursor: `pointer`, boxShadow: `none`, height: `20em`, boxSizing: `border-box` }, scene: { position: `relative`, width: `100%`, maxWidth: `620px`, aspectRatio: `1024 / 1536`, backgroundColor: `#dfeaf2`, backgroundImage: `linear-gradient(180deg, rgba(13,20,31,0.12), rgba(13,20,31,0.12)), url("${b}/person-at-window.png")`, backgroundRepeat: `no-repeat`, backgroundPosition: `center center`, backgroundSize: `100% 100%`, display: `flex`, alignItems: `center`, justifyContent: `center`, margin: `0 auto` }, sceneWindow: { position: `absolute`, inset: 0, backgroundImage: `url("${b}/personatemptywindow.png")`, backgroundRepeat: `no-repeat`, backgroundPosition: `center center`, backgroundSize: `100% 100%`, pointerEvents: `none`, zIndex: 2 }, blindWindow: { position: `absolute`, left: `10%`, right: `10%`, top: `0%`, bottom: `23%`, zIndex: 1, display: `flex`, alignItems: `center`, justifyContent: `center`, background: `transparent`, overflow: `hidden` } }, S = `#c7c70e`, C = class e2 extends t {
  static types = { value: 0, dimmer: 1, blinds: 2 };
  static mouseDown = false;
  button = { time: 0, name: ``, timer: null, timeUp: 0 };
  refSlider = n.createRef();
  type;
  top = void 0;
  height = void 0;
  controlTimer = null;
  constructor(t2) {
    super(t2), this.state = { value: this.props.startValue || 0, toggleValue: this.props.startToggleValue || false, lastControl: 0 }, this.type = this.props.type || e2.types.dimmer;
  }
  static getDerivedStateFromProps(t2, n2) {
    let r2 = null;
    return t2.startValue !== n2.value && !e2.mouseDown && Date.now() - n2.lastControl > 1e3 && (r2 = {}, r2.value = t2.startValue), t2.startToggleValue !== void 0 && t2.startToggleValue !== n2.toggleValue && (r2 || (r2 = {}), r2.toggleValue = t2.startToggleValue), r2 || null;
  }
  eventToValue(t2) {
    let n2 = t2.touches ? t2.touches[t2.touches.length - 1].clientY : t2.clientY, r2 = 100 - Math.round((n2 - this.top) / this.height * 100);
    r2 > 100 ? r2 = 100 : r2 < 0 && (r2 = 0), this.setState({ value: r2 }), Date.now() - this.state.lastControl > 200 && this.type !== e2.types.blinds && this.setState({ lastControl: Date.now() }, () => this.onValueChanged(r2));
  }
  onMouseMove = (t2) => {
    e2.mouseDown && (t2.preventDefault(), t2.stopPropagation(), this.eventToValue(t2));
  };
  onMouseDown = (t2) => {
    if (t2.preventDefault(), t2.stopPropagation(), !this.height) {
      if (this.refSlider.current) this.height = this.refSlider.current.offsetHeight, this.top = this.refSlider.current.getBoundingClientRect().top;
      else return;
    }
    e2.mouseDown = true, this.eventToValue(t2), window.document.addEventListener(`mousemove`, this.onMouseMove, { passive: false, capture: true }), window.document.addEventListener(`mouseup`, this.onMouseUp, { passive: false, capture: true }), window.document.addEventListener(`touchmove`, this.onMouseMove, { passive: false, capture: true }), window.document.addEventListener(`touchend`, this.onMouseUp, { passive: false, capture: true });
  };
  onValueChanged(e3) {
    var _a, _b;
    this.props.controlTimeout ? (this.controlTimer && (this.controlTimer = (clearTimeout(this.controlTimer), null)), this.controlTimer = setTimeout(() => {
      var _a2, _b2;
      (_b2 = (_a2 = this.props).onValueChange) == null ? void 0 : _b2.call(_a2, e3);
    }, this.props.controlTimeout)) : (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, e3);
  }
  onMouseUp = (t2) => {
    t2.preventDefault(), t2.stopPropagation(), e2.mouseDown && (e2.mouseDown = false, window.document.removeEventListener(`mousemove`, this.onMouseMove, { passive: false, capture: true }), window.document.removeEventListener(`mouseup`, this.onMouseUp, { passive: false, capture: true }), window.document.removeEventListener(`touchmove`, this.onMouseMove, { passive: false, capture: true }), window.document.removeEventListener(`touchend`, this.onMouseUp, { passive: false, capture: true })), this.setState({ lastControl: Date.now() }, () => {
      var _a, _b;
      (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, this.state.value, true);
    });
  };
  componentWillUnmount() {
    e2.mouseDown && (e2.mouseDown = false, window.document.removeEventListener(`mousemove`, this.onMouseMove, { passive: false, capture: true }), window.document.removeEventListener(`mouseup`, this.onMouseUp, { passive: false, capture: true }), window.document.removeEventListener(`touchmove`, this.onMouseMove, { passive: false, capture: true }), window.document.removeEventListener(`touchend`, this.onMouseUp, { passive: false, capture: true }));
  }
  getTopButtonName() {
    switch (this.props.type) {
      case e2.types.blinds:
        return l(v, { style: { width: 20, height: 20 } });
      case e2.types.dimmer:
        return l(h, { style: { color: S, width: 20, height: 20 } });
      default:
        return d.t(`ON`);
    }
  }
  getBottomButtonName() {
    switch (this.props.type) {
      case e2.types.blinds:
        return l(_, { style: { width: 20, height: 20 } });
      case e2.types.dimmer:
        return l(h, { style: { width: 20, height: 20 } });
      default:
        return d.t(`OFF`);
    }
  }
  onButtonDown(e3, t2) {
    e3 == null ? void 0 : e3.stopPropagation(), !(Date.now() - this.button.time < 50) && (this.button.timer && clearTimeout(this.button.timer), this.button.name = t2, this.button.time = Date.now(), this.button.timer = setTimeout(() => {
      this.button.timer = null;
      let e4;
      switch (this.button.name) {
        case `top`:
          e4 = 100;
          break;
        case `bottom`:
          e4 = 0;
      }
      e4 !== void 0 && this.setState({ value: e4 }, () => {
        var _a, _b;
        return (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, e4, true);
      });
    }, 400));
  }
  getSliderColor() {
    if (this.props.type !== e2.types.blinds) {
      if (this.props.type === e2.types.dimmer) {
        let e3 = this.state.value;
        return c(S, 1 - (e3 / 70 + 0.3));
      }
      return `#888`;
    }
  }
  getValueText() {
    let t2 = `%`;
    return this.props.type !== e2.types.blinds && this.props.type !== e2.types.dimmer && (t2 = this.props.unit || ``), this.state.value + t2;
  }
  getToggleButton() {
    return this.props.onToggle ? l(m, { onClick: this.props.onToggle, className: `dimmer-button`, style: x.buttonToggleStyle, children: l(h, {}) }) : null;
  }
  getStopButton() {
    return this.props.onStop ? l(m, { style: x.buttonStopStyle, size: `small`, onClick: this.props.onStop, color: `secondary`, children: l(y, {}) }) : null;
  }
  generateContent() {
    let t2 = { position: `absolute`, width: `100%`, left: 0, height: `${this.props.type === e2.types.blinds ? 100 - this.state.value : this.state.value}%`, background: this.props.background || this.getSliderColor(), transitionProperty: `height`, transitionDuration: `0.1s` }, n2 = { position: `absolute`, width: `2em`, height: `0.3em`, left: `calc(50% - 1em)`, background: `white`, borderRadius: `0.4em` };
    this.props.type === e2.types.blinds ? (t2.top = 0, n2.bottom = `0.4em`, t2.backgroundImage = `linear-gradient(0deg, #949494 4.55%, #c9c9c9 4.55%, #c9c9c9 50%, #949494 50%, #949494 54.55%, #c9c9c9 54.55%, #c9c9c9 100%)`, t2.backgroundSize = `100% 2.5em`, t2.backgroundPosition = `center bottom`) : (t2.bottom = 0, n2.top = `0.4em`);
    let i2 = { ...x.sliderStyle, width: `100%`, height: `85%`, minHeight: `250px`, margin: 0, background: `transparent`, boxShadow: `none`, borderRadius: 0, overflow: `hidden` };
    return u(`div`, { className: `vis-2-slider-wrapper`, style: x.sceneStack, children: [l(r, { variant: `outlined`, onClick: (e3) => this.onButtonDown(e3, `top`), children: this.getTopButtonName() }), u(`div`, { style: x.scene, children: [l(`div`, { style: x.sceneWindow }), l(`div`, { style: x.blindWindow, children: l(`div`, { className: `vis-2-slider-blind`, ref: this.refSlider, onMouseDown: this.onMouseDown, onTouchStart: this.onMouseDown, onClick: (e3) => e3.stopPropagation(), style: i2, children: l(`div`, { style: t2, className: `vis-2-slider-inside`, children: l(`div`, { style: n2, className: `vis-2-slider-handler` }) }) }) })] }), l(r, { variant: `outlined`, onClick: (e3) => this.onButtonDown(e3, `bottom`), children: this.getBottomButtonName() }), this.getToggleButton()] });
  }
  render() {
    return u(s, { open: true, onClose: () => this.props.onClose(), slotProps: { paper: { style: x.dialog } }, children: [u(o, { style: x.dialogTitle, children: [this.getStopButton(), l(`div`, { style: x.sliderText, children: this.getValueText() }), l(i, { onClick: () => this.props.onClose(), style: { float: `right` }, children: l(p, {}) })] }), l(a, { style: x.dialogContent, children: this.generateContent() })] });
  }
};
e();
var w = { blindHandle: { position: `absolute`, borderColor: `#a5aaad`, borderStyle: `solid`, background: `linear-gradient(to bottom, rgba(226, 226, 226, 1) 0%, rgba(219, 219, 219, 1) 50%, rgba(209, 209, 209, 1) 51%, rgba(254, 254, 254, 1) 100%)` }, blindBlind: { backgroundImage: `linear-gradient(0deg, #949494 4.55%, #c9c9c9 4.55%, #c9c9c9 50%, #949494 50%, #949494 54.55%, #c9c9c9 54.55%, #c9c9c9 100%)`, backgroundSize: `100% 20px`, backgroundPosition: `center bottom`, width: `100%`, position: `absolute`, transitionProperty: `height`, transitionDuration: `0.3s` }, blindBlind1: { height: `100%`, boxSizing: `border-box`, borderStyle: `solid`, background: `linear-gradient(45deg, rgba(173, 174, 178, 1) 0%, rgba(251, 251, 251, 1) 100%)` }, blindBlind2: { position: `relative`, width: `100%`, height: `100%`, boxSizing: `border-box`, borderStyle: `solid`, borderColor: `rgba(0, 0, 0, 0)` }, blindBlind3: { position: `relative`, width: `100%`, height: `100%`, boxSizing: `border-box`, background: `linear-gradient(to bottom, rgba(0, 0, 0, 0.8) 0%, rgba(0, 51, 135, 0.83) 100%)` }, blindBlind4: { position: `relative`, width: `100%`, height: `100%`, boxSizing: `border-box`, borderStyle: `solid`, background: `linear-gradient(45deg, rgba(221, 231, 243, 0.7) 0%, rgba(120, 132, 146, 0.7) 52%, rgba(166, 178, 190, 0.7) 68%, rgba(201, 206, 210, 0.7) 100%)`, transitionProperty: `transform`, transitionDuration: `0.3s`, transformOrigin: `0 100%` }, blindBlind4_left: { transformOrigin: `0 0` }, blindBlind4_right: { transformOrigin: `100% 0` }, blindBlind4_top: { transformOrigin: `0 100%` }, blindBlind4_bottom: { transformOrigin: `0 0` }, blindBlind4Opened_left: { transform: `skew(0deg, 10deg) scale(0.9, 1)` }, blindBlind4Opened_right: { transform: `skew(0deg, -10deg) scale(0.9, 1)` }, blindBlind4Opened_top: { transform: `skew(-10deg, 0deg) scale(1, 0.9)` }, blindBlind4Opened_bottom: { transform: `skew(10deg, 0deg) scale(1, 0.9)` }, blindBlind4_tilted: { transform: `skew(-10deg, 0deg) scale(1, 0.9)`, transformOrigin: `0 100%` }, blindHandleBG: {}, blindHandleTiltedBG: { background: `linear-gradient(to bottom, rgba(241, 231, 103, 1) 0%, rgba(254, 182, 69, 1) 100%)` } }, T = w, E = class extends g {
  constructor(e3) {
    super(e3), this.state = { ...this.state, showBlindsDialog: null };
  }
  getMinMaxPosition(e3, t2) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
    let n2 = e3 ? this.state.rxData[`slideStop_oid${e3}`] : this.state.rxData.oid_stop, r2 = e3 && !this.state.rxData.oid ? this.state.rxData[`slidePos_oid${e3}`] : this.state.rxData.oid, i2 = e3 && !this.state.rxData.oid ? this.state.rxData[`slideInvert${e3}`] === true || this.state.rxData[`slideInvert${e3}`] === `true` : this.state.rxData.invert === true || this.state.rxData.invert === `true`;
    t2 !== void 0 && (r2 = this.state.rxData[`slidePos_oid${e3}`] === `nothing_selected` ? `` : this.state.rxData[`slidePos_oid${e3}`], i2 = this.state.rxData[`slideInvert${t2}`] === true || this.state.rxData[`slideInvert${t2}`] === `true`), e3 && (r2 === `nothing_selected` || !r2) && (r2 = this.state.rxData.oid, i2 = this.state.rxData.invert === true || this.state.rxData.invert === `true`);
    let a2, o2;
    if (!e3) a2 = parseFloat(this.state.rxData.min), Number.isNaN(a2) && (a2 = ((_a = this.state.main) == null ? void 0 : _a.min) === void 0 || Number.isNaN((_b = this.state.main) == null ? void 0 : _b.min) ? 0 : this.state.main.min), o2 = parseFloat(this.state.rxData.max), Number.isNaN(o2) && (o2 = ((_c = this.state.main) == null ? void 0 : _c.max) === void 0 || Number.isNaN((_d = this.state.main) == null ? void 0 : _d.max) ? 100 : this.state.main.max);
    else if (t2 !== void 0) {
      let e4 = typeof this.state.objects[t2] == `object` ? parseFloat((_f = (_e = this.state.objects[t2]) == null ? void 0 : _e.common) == null ? void 0 : _f.min) : void 0;
      a2 = e4 === void 0 || Number.isNaN(e4) ? ((_g = this.state.main) == null ? void 0 : _g.min) === void 0 || Number.isNaN(parseFloat(this.state.main.min)) ? 0 : this.state.main.min : e4;
      let n3 = typeof this.state.objects[t2] == `object` ? parseFloat((_i = (_h = this.state.objects[t2]) == null ? void 0 : _h.common) == null ? void 0 : _i.max) : void 0;
      o2 = n3 === void 0 || Number.isNaN(n3) ? ((_j = this.state.main) == null ? void 0 : _j.max) === void 0 || Number.isNaN(this.state.main.max) ? 100 : this.state.main.max : n3;
    } else {
      if (a2 = parseFloat(this.state.rxData[`slideMin${e3}`]), Number.isNaN(a2)) {
        let t3 = typeof this.state.objects[e3] == `object` ? parseFloat((_l = (_k = this.state.objects[e3]) == null ? void 0 : _k.common) == null ? void 0 : _l.min) : void 0;
        t3 === void 0 || Number.isNaN(t3) ? (a2 = parseFloat(this.state.rxData.min), Number.isNaN(a2) && (a2 = parseFloat((_m = this.state.main) == null ? void 0 : _m.min), Number.isNaN(a2) && (a2 = 0))) : a2 = t3;
      }
      if (o2 = parseFloat(this.state.rxData[`slideMax${e3}`]), Number.isNaN(o2)) {
        let t3 = typeof this.state.objects[e3] == `object` ? parseFloat((_o = (_n = this.state.objects[e3]) == null ? void 0 : _n.common) == null ? void 0 : _o.max) : void 0;
        t3 === void 0 || Number.isNaN(t3) ? (o2 = parseFloat(this.state.rxData.max), Number.isNaN(o2) && (o2 = parseFloat((_p = this.state.main) == null ? void 0 : _p.max), Number.isNaN(o2) && (o2 = 100))) : o2 = t3;
      }
    }
    let s2 = this.state.values[`${r2}.val`];
    return s2 == null ? s2 = 0 : (s2 < a2 && (s2 = a2), s2 > o2 && (s2 = o2), s2 = Math.round(100 * (s2 - a2) / (o2 - a2))), i2 && (s2 = 100 - s2), { min: a2, max: o2, shutterPos: s2, invert: i2, stopOid: n2, positionOid: r2, customOid: r2 !== this.state.rxData.oid, hasControl: r2 !== `nothing_selected` && !!r2 };
  }
  renderBlindsDialog() {
    if (this.state.showBlindsDialog !== null) {
      let e3 = this.getMinMaxPosition(this.state.showBlindsDialog === true ? 0 : this.state.showBlindsDialog, this.state.showBlindsDialogIndexOfButton);
      return l(C, { onClose: () => {
        this.lastClick = Date.now(), this.setState({ showBlindsDialog: null });
      }, onStop: e3.stopOid && e3.stopOid !== `nothing_selected` ? () => this.props.context.setValue(e3.stopOid, true) : void 0, controlTimeout: parseInt(this.state.rxData.timeout, 10) || 0, onValueChange: (t2, n2) => {
        e3.invert && (t2 = 100 - t2), t2 = (e3.max - e3.min) / 100 * t2 + e3.min, n2 && this.props.context.setValue(e3.positionOid, t2);
      }, startValue: e3.shutterPos, type: C.types.blinds });
    }
    return null;
  }
  renderOneWindow(e3, t2) {
    let n2 = this.getMinMaxPosition(e3, t2.indexOfButton), r2 = null, i2 = null;
    t2.handleOid && (r2 = this.state.values[`${t2.handleOid}.val`], r2 === 2 || r2 === `2` ? r2 = 1 : (r2 === 1 || r2 === `1`) && (r2 = 2), r2 === `1` || r2 === true || r2 === `true` || r2 === `open` || r2 === `opened` ? r2 = 1 : (r2 === `2` || r2 === `tilt` || r2 === `tilted`) && (r2 = 2), i2 = r2), t2.slideOid && (i2 = this.state.values[`${t2.slideOid}.val`], (i2 === 2 || i2 === `2`) && (i2 = 2), i2 === `1` || i2 === true || i2 === `true` || i2 === `open` || i2 === `opened` ? i2 = 1 : (i2 === `2` || i2 === `tilt` || i2 === `tilted`) && (i2 = 2), t2.handleOid || (r2 = i2));
    let a2 = null;
    if (t2.type) {
      let e4 = Math.round(t2.borderWidth / 3);
      e4 < 1 && (e4 = 1);
      let n3 = { borderWidth: e4, transitionProperty: `transform`, transitionDuration: `0.3s` };
      if (t2.type === `left` || t2.type === `right` ? (n3.top = `50%`, n3.width = t2.borderWidth, n3.height = `10%`) : (t2.type === `top` || t2.type === `bottom`) && (n3.left = `50%`, n3.height = t2.borderWidth, n3.width = `10%`), t2.type === `left` ? n3.left = `calc(100% - ${e4 * 2 + t2.borderWidth}px)` : t2.type === `bottom` && (n3.top = `calc(100% - ${e4 * 2 + t2.borderWidth}px)`), r2) {
        if (t2.type === `right`) {
          let i3 = Math.round(e4 + t2.borderWidth / 2);
          n3.transformOrigin = `${i3}px ${i3}px`, n3.top = `calc(50% + ${i3}px)`, r2 === 1 ? n3.transform = `rotate(-90deg)` : r2 === 2 && (n3.transform = `rotate(180deg)`);
        } else if (t2.type === `bottom`) {
          let i3 = Math.round(e4 + t2.borderWidth / 2);
          n3.transformOrigin = `${i3}px ${i3}px`, r2 === 1 ? n3.transform = `rotate(-90deg)` : r2 === 2 && (n3.transform = `rotate(180deg)`);
        } else r2 === 1 ? n3.transform = `rotate(90deg)` : r2 === 2 && (n3.transform = `rotate(180deg)`);
      }
      a2 = l(`div`, { className: `vis-2-blinds-handle`, style: { ...w.blindHandle, ...r2 === 2 ? w.blindHandleTiltedBG : void 0, ...n3 } });
    }
    return l(`div`, { className: `vis-2-blinds-outside`, style: { ...w.blindBlind1, borderWidth: t2.borderWidth, borderColor: `#a9a7a8`, flex: t2.flex || 1 }, children: l(`div`, { className: `vis-2-blinds-inside`, style: { ...w.blindBlind2, borderWidth: t2.borderWidth }, onClick: n2.customOid ? (n3) => {
      n3.preventDefault(), n3.stopPropagation(), this.lastClick = Date.now(), this.setState({ showBlindsDialog: e3, showBlindsDialogIndexOfButton: t2.indexOfButton });
    } : void 0, children: u(`div`, { style: w.blindBlind3, className: `vis-2-blinds-inside-2`, children: [l(`div`, { style: { ...w.blindBlind, height: `${100 - n2.shutterPos}%` }, className: `vis-2-blinds-closed` }), l(`div`, { className: `vis-2-blinds-opened`, style: { ...w.blindBlind4, ...t2.type ? w[`blindBlind4_${t2.type}`] : void 0, ...i2 === 1 && t2.type ? w[`blindBlind4Opened_${t2.type}`] : void 0, ...i2 === 2 && t2.type ? w.blindBlind4_tilted : void 0, borderWidth: t2.borderWidth, borderColor: `#a5aaad` }, children: a2 })] }) }) }, e3);
  }
  renderWindows(e3, t2) {
    let n2, r2, i2 = parseFloat(this.state.rxData.ratio) || 1;
    r2 = e3.height, n2 = Math.round(r2 * i2), n2 > e3.width && (n2 = e3.width, r2 = Math.round(n2 / i2));
    let a2 = e3.width > e3.height ? e3.height : e3.width, o2 = parseFloat(this.state.rxData.borderWidth) || 2.5;
    o2 = Math.round(a2 * o2 / 10) / 10, o2 < 1 && (o2 = 1);
    let s2 = [], c2 = this.state.rxData.sashCount === void 0 ? 1 : this.state.rxData.sashCount;
    for (let n3 = 1; n3 <= c2; n3++) {
      let r3 = { slideOid: this.state.rxData[`slideSensor_oid${n3}`], handleOid: this.state.rxData[`slideHandle_oid${n3}`], type: this.state.rxData[`slideType${n3}`], flex: this.state.rxData[`slideRatio${n3}`], borderWidth: o2, size: e3, indexOfButton: t2 };
      s2.push(this.renderOneWindow(n3, r3));
    }
    let u2 = { paddingTop: o2, paddingBottom: o2 - 1, paddingRight: o2 + 1, paddingLeft: o2 + 1, width: n2, height: r2, display: `flex`, alignItems: `stretch`, margin: `auto` };
    return l(`div`, { style: u2, children: s2 });
  }
};
e();
function D(e3) {
  return u(`svg`, { width: 361, height: 361, viewBox: `0 0 361 361`, ...e3, children: [l(`path`, { d: `M267.826 263.303c0 3.91-3.156 7.082-7.05 7.082l-157.885.021c-3.894 0-7.05-3.171-7.05-7.083v-157.5c0-3.911 3.156-7.083 7.05-7.083l157.885-.021c3.894 0 7.05 3.172 7.05 7.083v157.501z`, fill: `none`, stroke: `currentColor`, strokeWidth: 10, strokeMiterlimit: 10 }), l(`path`, { d: `M258.5 185.584h6.639c2.726 0 5-2.274 5-5s-2.274-5-5-5H258.5c-2.726 0-5 2.274-5 5s2.274 5 5 5z`, fill: `currentColor` }), l(`path`, { d: `M267.826 103.208c0 2.485-2.711 4.5-6.053 4.5l-159.88.021c-3.342 0-6.052-2.015-6.052-4.5v-9c0-2.485 2.71-4.5 6.052-4.5l159.88-.021c3.342 0 6.053 2.015 6.053 4.5v9z`, fill: `none`, stroke: `currentColor`, strokeWidth: 10, strokeMiterlimit: 10 })] });
}
export {
  E as n,
  T as r,
  D as t
};
