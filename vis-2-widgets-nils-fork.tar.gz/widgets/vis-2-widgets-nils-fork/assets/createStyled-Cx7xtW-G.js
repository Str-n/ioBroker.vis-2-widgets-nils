import { R as Pe, n as rt, h as ye, i as nt, g as ie, c as H, d as Me, __tla as __tla_0 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__prop_mf_2_types__loadShare__.js-DP_PH0VJ.js";
import { j as at, __tla as __tla_2 } from "./jsx-runtime-DTPVEbuR.js";
import { _ as it } from "./extends-CF3RwP-h.js";
import { c as st, s as Ce, __tla as __tla_3 } from "./getColorSchemeSelector-S_MR5UAK.js";
import { i as ot, __tla as __tla_4 } from "./capitalize-g-ksEjkR.js";
let rr, _r, kr, lt, Je, Cr, Pr, Tr, wr, Sr, xr, ar, Qe, Ge, Mt, W, Qt, le, or, sr, pe, xe, Ar, Ze;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  function ct(e) {
    if (e.sheet) return e.sheet;
    for (var t = 0; t < document.styleSheets.length; t++) if (document.styleSheets[t].ownerNode === e) return document.styleSheets[t];
  }
  function ft(e) {
    var t = document.createElement("style");
    return t.setAttribute("data-emotion", e.key), e.nonce !== void 0 && t.setAttribute("nonce", e.nonce), t.appendChild(document.createTextNode("")), t.setAttribute("data-s", ""), t;
  }
  let P, ae, p, Ne, ge, ve, ut, De, dt, ht, se, mt;
  lt = (function() {
    function e(r) {
      var n = this;
      this._insertTag = function(a) {
        var i;
        n.tags.length === 0 ? n.insertionPoint ? i = n.insertionPoint.nextSibling : n.prepend ? i = n.container.firstChild : i = n.before : i = n.tags[n.tags.length - 1].nextSibling, n.container.insertBefore(a, i), n.tags.push(a);
      }, this.isSpeedy = r.speedy === void 0 ? true : r.speedy, this.tags = [], this.ctr = 0, this.nonce = r.nonce, this.key = r.key, this.container = r.container, this.prepend = r.prepend, this.insertionPoint = r.insertionPoint, this.before = null;
    }
    var t = e.prototype;
    return t.hydrate = function(n) {
      n.forEach(this._insertTag);
    }, t.insert = function(n) {
      this.ctr % (this.isSpeedy ? 65e3 : 1) === 0 && this._insertTag(ft(this));
      var a = this.tags[this.tags.length - 1];
      if (this.isSpeedy) {
        var i = ct(a);
        try {
          i.insertRule(n, i.cssRules.length);
        } catch {
        }
      } else a.appendChild(document.createTextNode(n));
      this.ctr++;
    }, t.flush = function() {
      this.tags.forEach(function(n) {
        var a;
        return (a = n.parentNode) == null ? void 0 : a.removeChild(n);
      }), this.tags = [], this.ctr = 0;
    }, e;
  })();
  P = "-ms-";
  ae = "-moz-";
  p = "-webkit-";
  Ne = "comm";
  ge = "rule";
  ve = "decl";
  ut = "@import";
  De = "@keyframes";
  dt = "@layer";
  ht = Math.abs;
  se = String.fromCharCode;
  mt = Object.assign;
  function pt(e, t) {
    return k(e, 0) ^ 45 ? (((t << 2 ^ k(e, 0)) << 2 ^ k(e, 1)) << 2 ^ k(e, 2)) << 2 ^ k(e, 3) : 0;
  }
  function Ve(e) {
    return e.trim();
  }
  function yt(e, t) {
    return (e = t.exec(e)) ? e[0] : e;
  }
  function y(e, t, r) {
    return e.replace(t, r);
  }
  function ue(e, t) {
    return e.indexOf(t);
  }
  function k(e, t) {
    return e.charCodeAt(t) | 0;
  }
  function B(e, t, r) {
    return e.slice(t, r);
  }
  function L(e) {
    return e.length;
  }
  function be(e) {
    return e.length;
  }
  function Q(e, t) {
    return t.push(e), e;
  }
  function gt(e, t) {
    return e.map(t).join("");
  }
  var oe = 1, U = 1, We = 0, _ = 0, x = 0, q = "";
  function ce(e, t, r, n, a, i, s) {
    return {
      value: e,
      root: t,
      parent: r,
      type: n,
      props: a,
      children: i,
      line: oe,
      column: U,
      length: s,
      return: ""
    };
  }
  function G(e, t) {
    return mt(ce("", null, null, "", null, null, 0), e, {
      length: -e.length
    }, t);
  }
  function vt() {
    return x;
  }
  function bt() {
    return x = _ > 0 ? k(q, --_) : 0, U--, x === 10 && (U = 1, oe--), x;
  }
  function O() {
    return x = _ < We ? k(q, _++) : 0, U++, x === 10 && (U = 1, oe++), x;
  }
  function N() {
    return k(q, _);
  }
  function ee() {
    return _;
  }
  function X(e, t) {
    return B(q, e, t);
  }
  function Y(e) {
    switch (e) {
      case 0:
      case 9:
      case 10:
      case 13:
      case 32:
        return 5;
      case 33:
      case 43:
      case 44:
      case 47:
      case 62:
      case 64:
      case 126:
      case 59:
      case 123:
      case 125:
        return 4;
      case 58:
        return 3;
      case 34:
      case 39:
      case 40:
      case 91:
        return 2;
      case 41:
      case 93:
        return 1;
    }
    return 0;
  }
  function je(e) {
    return oe = U = 1, We = L(q = e), _ = 0, [];
  }
  function He(e) {
    return q = "", e;
  }
  function te(e) {
    return Ve(X(_ - 1, de(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
  }
  function wt(e) {
    for (; (x = N()) && x < 33; ) O();
    return Y(e) > 2 || Y(x) > 3 ? "" : " ";
  }
  function xt(e, t) {
    for (; --t && O() && !(x < 48 || x > 102 || x > 57 && x < 65 || x > 70 && x < 97); ) ;
    return X(e, ee() + (t < 6 && N() == 32 && O() == 32));
  }
  function de(e) {
    for (; O(); ) switch (x) {
      case e:
        return _;
      case 34:
      case 39:
        e !== 34 && e !== 39 && de(x);
        break;
      case 40:
        e === 41 && de(e);
        break;
      case 92:
        O();
        break;
    }
    return _;
  }
  function St(e, t) {
    for (; O() && e + x !== 57; ) if (e + x === 84 && N() === 47) break;
    return "/*" + X(t, _ - 1) + "*" + se(e === 47 ? e : O());
  }
  function kt(e) {
    for (; !Y(N()); ) O();
    return X(e, _);
  }
  function Pt(e) {
    return He(re("", null, null, null, [
      ""
    ], e = je(e), 0, [
      0
    ], e));
  }
  function re(e, t, r, n, a, i, s, o, c) {
    for (var f = 0, u = 0, h = s, C = 0, A = 0, w = 0, d = 1, m = 1, g = 1, b = 0, S = "", R = a, T = i, v = n, l = S; m; ) switch (w = b, b = O()) {
      case 40:
        if (w != 108 && k(l, h - 1) == 58) {
          ue(l += y(te(b), "&", "&\f"), "&\f") != -1 && (g = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        l += te(b);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        l += wt(w);
        break;
      case 92:
        l += xt(ee() - 1, 7);
        continue;
      case 47:
        switch (N()) {
          case 42:
          case 47:
            Q(Ct(St(O(), ee()), t, r), c);
            break;
          default:
            l += "/";
        }
        break;
      case 123 * d:
        o[f++] = L(l) * g;
      case 125 * d:
      case 59:
      case 0:
        switch (b) {
          case 0:
          case 125:
            m = 0;
          case 59 + u:
            g == -1 && (l = y(l, /\f/g, "")), A > 0 && L(l) - h && Q(A > 32 ? Ae(l + ";", n, r, h - 1) : Ae(y(l, " ", "") + ";", n, r, h - 2), c);
            break;
          case 59:
            l += ";";
          default:
            if (Q(v = _e(l, t, r, f, u, a, o, S, R = [], T = [], h), i), b === 123) if (u === 0) re(l, t, v, v, R, i, h, o, T);
            else switch (C === 99 && k(l, 3) === 110 ? 100 : C) {
              case 100:
              case 108:
              case 109:
              case 115:
                re(e, v, v, n && Q(_e(e, v, v, 0, 0, a, o, S, a, R = [], h), T), a, T, h, o, n ? R : T);
                break;
              default:
                re(l, v, v, v, [
                  ""
                ], T, 0, o, T);
            }
        }
        f = u = A = 0, d = g = 1, S = l = "", h = s;
        break;
      case 58:
        h = 1 + L(l), A = w;
      default:
        if (d < 1) {
          if (b == 123) --d;
          else if (b == 125 && d++ == 0 && bt() == 125) continue;
        }
        switch (l += se(b), b * d) {
          case 38:
            g = u > 0 ? 1 : (l += "\f", -1);
            break;
          case 44:
            o[f++] = (L(l) - 1) * g, g = 1;
            break;
          case 64:
            N() === 45 && (l += te(O())), C = N(), u = h = L(S = l += kt(ee())), b++;
            break;
          case 45:
            w === 45 && L(l) == 2 && (d = 0);
        }
    }
    return i;
  }
  function _e(e, t, r, n, a, i, s, o, c, f, u) {
    for (var h = a - 1, C = a === 0 ? i : [
      ""
    ], A = be(C), w = 0, d = 0, m = 0; w < n; ++w) for (var g = 0, b = B(e, h + 1, h = ht(d = s[w])), S = e; g < A; ++g) (S = Ve(d > 0 ? C[g] + " " + b : y(b, /&\f/g, C[g]))) && (c[m++] = S);
    return ce(e, t, r, a === 0 ? ge : o, c, f, u);
  }
  function Ct(e, t, r) {
    return ce(e, t, r, Ne, se(vt()), B(e, 2, -2), 0);
  }
  function Ae(e, t, r, n) {
    return ce(e, t, r, ve, B(e, 0, n), B(e, n + 1, -1), n);
  }
  function z(e, t) {
    for (var r = "", n = be(e), a = 0; a < n; a++) r += t(e[a], a, e, t) || "";
    return r;
  }
  function _t(e, t, r, n) {
    switch (e.type) {
      case dt:
        if (e.children.length) break;
      case ut:
      case ve:
        return e.return = e.return || e.value;
      case Ne:
        return "";
      case De:
        return e.return = e.value + "{" + z(e.children, n) + "}";
      case ge:
        e.value = e.props.join(",");
    }
    return L(r = z(e.children, n)) ? e.return = e.value + "{" + r + "}" : "";
  }
  function At(e) {
    var t = be(e);
    return function(r, n, a, i) {
      for (var s = "", o = 0; o < t; o++) s += e[o](r, n, a, i) || "";
      return s;
    };
  }
  function Tt(e) {
    return function(t) {
      t.root || (t = t.return) && e(t);
    };
  }
  function ze(e) {
    var t = /* @__PURE__ */ Object.create(null);
    return function(r) {
      return t[r] === void 0 && (t[r] = e(r)), t[r];
    };
  }
  var Ot = function(t, r, n) {
    for (var a = 0, i = 0; a = i, i = N(), a === 38 && i === 12 && (r[n] = 1), !Y(i); ) O();
    return X(t, _);
  }, Rt = function(t, r) {
    var n = -1, a = 44;
    do
      switch (Y(a)) {
        case 0:
          a === 38 && N() === 12 && (r[n] = 1), t[n] += Ot(_ - 1, r, n);
          break;
        case 2:
          t[n] += te(a);
          break;
        case 4:
          if (a === 44) {
            t[++n] = N() === 58 ? "&\f" : "", r[n] = t[n].length;
            break;
          }
        default:
          t[n] += se(a);
      }
    while (a = O());
    return t;
  }, Et = function(t, r) {
    return He(Rt(je(t), r));
  }, Te = /* @__PURE__ */ new WeakMap(), $t = function(t) {
    if (!(t.type !== "rule" || !t.parent || t.length < 1)) {
      for (var r = t.value, n = t.parent, a = t.column === n.column && t.line === n.line; n.type !== "rule"; ) if (n = n.parent, !n) return;
      if (!(t.props.length === 1 && r.charCodeAt(0) !== 58 && !Te.get(n)) && !a) {
        Te.set(t, true);
        for (var i = [], s = Et(r, i), o = n.props, c = 0, f = 0; c < s.length; c++) for (var u = 0; u < o.length; u++, f++) t.props[f] = i[c] ? s[c].replace(/&\f/g, o[u]) : o[u] + " " + s[c];
      }
    }
  }, Ft = function(t) {
    if (t.type === "decl") {
      var r = t.value;
      r.charCodeAt(0) === 108 && r.charCodeAt(2) === 98 && (t.return = "", t.value = "");
    }
  };
  function Ue(e, t) {
    switch (pt(e, t)) {
      case 5103:
        return p + "print-" + e + e;
      case 5737:
      case 4201:
      case 3177:
      case 3433:
      case 1641:
      case 4457:
      case 2921:
      case 5572:
      case 6356:
      case 5844:
      case 3191:
      case 6645:
      case 3005:
      case 6391:
      case 5879:
      case 5623:
      case 6135:
      case 4599:
      case 4855:
      case 4215:
      case 6389:
      case 5109:
      case 5365:
      case 5621:
      case 3829:
        return p + e + e;
      case 5349:
      case 4246:
      case 4810:
      case 6968:
      case 2756:
        return p + e + ae + e + P + e + e;
      case 6828:
      case 4268:
        return p + e + P + e + e;
      case 6165:
        return p + e + P + "flex-" + e + e;
      case 5187:
        return p + e + y(e, /(\w+).+(:[^]+)/, p + "box-$1$2" + P + "flex-$1$2") + e;
      case 5443:
        return p + e + P + "flex-item-" + y(e, /flex-|-self/, "") + e;
      case 4675:
        return p + e + P + "flex-line-pack" + y(e, /align-content|flex-|-self/, "") + e;
      case 5548:
        return p + e + P + y(e, "shrink", "negative") + e;
      case 5292:
        return p + e + P + y(e, "basis", "preferred-size") + e;
      case 6060:
        return p + "box-" + y(e, "-grow", "") + p + e + P + y(e, "grow", "positive") + e;
      case 4554:
        return p + y(e, /([^-])(transform)/g, "$1" + p + "$2") + e;
      case 6187:
        return y(y(y(e, /(zoom-|grab)/, p + "$1"), /(image-set)/, p + "$1"), e, "") + e;
      case 5495:
      case 3959:
        return y(e, /(image-set\([^]*)/, p + "$1$`$1");
      case 4968:
        return y(y(e, /(.+:)(flex-)?(.*)/, p + "box-pack:$3" + P + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + p + e + e;
      case 4095:
      case 3583:
      case 4068:
      case 2532:
        return y(e, /(.+)-inline(.+)/, p + "$1$2") + e;
      case 8116:
      case 7059:
      case 5753:
      case 5535:
      case 5445:
      case 5701:
      case 4933:
      case 4677:
      case 5533:
      case 5789:
      case 5021:
      case 4765:
        if (L(e) - 1 - t > 6) switch (k(e, t + 1)) {
          case 109:
            if (k(e, t + 4) !== 45) break;
          case 102:
            return y(e, /(.+:)(.+)-([^]+)/, "$1" + p + "$2-$3$1" + ae + (k(e, t + 3) == 108 ? "$3" : "$2-$3")) + e;
          case 115:
            return ~ue(e, "stretch") ? Ue(y(e, "stretch", "fill-available"), t) + e : e;
        }
        break;
      case 4949:
        if (k(e, t + 1) !== 115) break;
      case 6444:
        switch (k(e, L(e) - 3 - (~ue(e, "!important") && 10))) {
          case 107:
            return y(e, ":", ":" + p) + e;
          case 101:
            return y(e, /(.+:)([^;!]+)(;|!.+)?/, "$1" + p + (k(e, 14) === 45 ? "inline-" : "") + "box$3$1" + p + "$2$3$1" + P + "$2box$3") + e;
        }
        break;
      case 5936:
        switch (k(e, t + 11)) {
          case 114:
            return p + e + P + y(e, /[svh]\w+-[tblr]{2}/, "tb") + e;
          case 108:
            return p + e + P + y(e, /[svh]\w+-[tblr]{2}/, "tb-rl") + e;
          case 45:
            return p + e + P + y(e, /[svh]\w+-[tblr]{2}/, "lr") + e;
        }
        return p + e + P + e + e;
    }
    return e;
  }
  let It, Lt, Nt;
  It = function(t, r, n, a) {
    if (t.length > -1 && !t.return) switch (t.type) {
      case ve:
        t.return = Ue(t.value, t.length);
        break;
      case De:
        return z([
          G(t, {
            value: y(t.value, "@", "@" + p)
          })
        ], a);
      case ge:
        if (t.length) return gt(t.props, function(i) {
          switch (yt(i, /(::plac\w+|:read-\w+)/)) {
            case ":read-only":
            case ":read-write":
              return z([
                G(t, {
                  props: [
                    y(i, /:(read-\w+)/, ":" + ae + "$1")
                  ]
                })
              ], a);
            case "::placeholder":
              return z([
                G(t, {
                  props: [
                    y(i, /:(plac\w+)/, ":" + p + "input-$1")
                  ]
                }),
                G(t, {
                  props: [
                    y(i, /:(plac\w+)/, ":" + ae + "$1")
                  ]
                }),
                G(t, {
                  props: [
                    y(i, /:(plac\w+)/, P + "input-$1")
                  ]
                })
              ], a);
          }
          return "";
        });
    }
  };
  Lt = [
    It
  ];
  Mt = function(t) {
    var r = t.key;
    if (r === "css") {
      var n = document.querySelectorAll("style[data-emotion]:not([data-s])");
      Array.prototype.forEach.call(n, function(d) {
        var m = d.getAttribute("data-emotion");
        m.indexOf(" ") !== -1 && (document.head.appendChild(d), d.setAttribute("data-s", ""));
      });
    }
    var a = t.stylisPlugins || Lt, i = {}, s, o = [];
    s = t.container || document.head, Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="' + r + ' "]'), function(d) {
      for (var m = d.getAttribute("data-emotion").split(" "), g = 1; g < m.length; g++) i[m[g]] = true;
      o.push(d);
    });
    var c, f = [
      $t,
      Ft
    ];
    {
      var u, h = [
        _t,
        Tt(function(d) {
          u.insert(d);
        })
      ], C = At(f.concat(a, h)), A = function(m) {
        return z(Pt(m), C);
      };
      c = function(m, g, b, S) {
        u = b, A(m ? m + "{" + g.styles + "}" : g.styles), S && (w.inserted[g.name] = true);
      };
    }
    var w = {
      key: r,
      sheet: new lt({
        key: r,
        container: s,
        nonce: t.nonce,
        speedy: t.speedy,
        prepend: t.prepend,
        insertionPoint: t.insertionPoint
      }),
      nonce: t.nonce,
      inserted: i,
      registered: {},
      insert: c
    };
    return w.sheet.hydrate(o), w;
  };
  Nt = true;
  function qe(e, t, r) {
    var n = "";
    return r.split(" ").forEach(function(a) {
      e[a] !== void 0 ? t.push(e[a] + ";") : a && (n += a + " ");
    }), n;
  }
  let we;
  we = function(t, r, n) {
    var a = t.key + "-" + r.name;
    (n === false || Nt === false) && t.registered[a] === void 0 && (t.registered[a] = r.styles);
  };
  Ge = function(t, r, n) {
    we(t, r, n);
    var a = t.key + "-" + r.name;
    if (t.inserted[r.name] === void 0) {
      var i = r;
      do
        t.insert(r === i ? "." + a : "", i, t.sheet, true), i = i.next;
      while (i !== void 0);
    }
  };
  function Dt(e) {
    for (var t = 0, r, n = 0, a = e.length; a >= 4; ++n, a -= 4) r = e.charCodeAt(n) & 255 | (e.charCodeAt(++n) & 255) << 8 | (e.charCodeAt(++n) & 255) << 16 | (e.charCodeAt(++n) & 255) << 24, r = (r & 65535) * 1540483477 + ((r >>> 16) * 59797 << 16), r ^= r >>> 24, t = (r & 65535) * 1540483477 + ((r >>> 16) * 59797 << 16) ^ (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
    switch (a) {
      case 3:
        t ^= (e.charCodeAt(n + 2) & 255) << 16;
      case 2:
        t ^= (e.charCodeAt(n + 1) & 255) << 8;
      case 1:
        t ^= e.charCodeAt(n) & 255, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
    }
    return t ^= t >>> 13, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36);
  }
  var Vt = {
    animationIterationCount: 1,
    aspectRatio: 1,
    borderImageOutset: 1,
    borderImageSlice: 1,
    borderImageWidth: 1,
    boxFlex: 1,
    boxFlexGroup: 1,
    boxOrdinalGroup: 1,
    columnCount: 1,
    columns: 1,
    flex: 1,
    flexGrow: 1,
    flexPositive: 1,
    flexShrink: 1,
    flexNegative: 1,
    flexOrder: 1,
    gridRow: 1,
    gridRowEnd: 1,
    gridRowSpan: 1,
    gridRowStart: 1,
    gridColumn: 1,
    gridColumnEnd: 1,
    gridColumnSpan: 1,
    gridColumnStart: 1,
    msGridRow: 1,
    msGridRowSpan: 1,
    msGridColumn: 1,
    msGridColumnSpan: 1,
    fontWeight: 1,
    lineHeight: 1,
    opacity: 1,
    order: 1,
    orphans: 1,
    scale: 1,
    tabSize: 1,
    widows: 1,
    zIndex: 1,
    zoom: 1,
    WebkitLineClamp: 1,
    fillOpacity: 1,
    floodOpacity: 1,
    stopOpacity: 1,
    strokeDasharray: 1,
    strokeDashoffset: 1,
    strokeMiterlimit: 1,
    strokeOpacity: 1,
    strokeWidth: 1
  }, Wt = /[A-Z]|^ms/g, jt = /_EMO_([^_]+?)_([^]*?)_EMO_/g, Be = function(t) {
    return t.charCodeAt(1) === 45;
  }, Oe = function(t) {
    return t != null && typeof t != "boolean";
  }, fe = ze(function(e) {
    return Be(e) ? e : e.replace(Wt, "-$&").toLowerCase();
  }), Re = function(t, r) {
    switch (t) {
      case "animation":
      case "animationName":
        if (typeof r == "string") return r.replace(jt, function(n, a, i) {
          return M = {
            name: a,
            styles: i,
            next: M
          }, a;
        });
    }
    return Vt[t] !== 1 && !Be(t) && typeof r == "number" && r !== 0 ? r + "px" : r;
  };
  function K(e, t, r) {
    if (r == null) return "";
    var n = r;
    if (n.__emotion_styles !== void 0) return n;
    switch (typeof r) {
      case "boolean":
        return "";
      case "object": {
        var a = r;
        if (a.anim === 1) return M = {
          name: a.name,
          styles: a.styles,
          next: M
        }, a.name;
        var i = r;
        if (i.styles !== void 0) {
          var s = i.next;
          if (s !== void 0) for (; s !== void 0; ) M = {
            name: s.name,
            styles: s.styles,
            next: M
          }, s = s.next;
          var o = i.styles + ";";
          return o;
        }
        return Ht(e, t, r);
      }
      case "function": {
        if (e !== void 0) {
          var c = M, f = r(e);
          return M = c, K(e, t, f);
        }
        break;
      }
    }
    var u = r;
    if (t == null) return u;
    var h = t[u];
    return h !== void 0 ? h : u;
  }
  function Ht(e, t, r) {
    var n = "";
    if (Array.isArray(r)) for (var a = 0; a < r.length; a++) n += K(e, t, r[a]) + ";";
    else for (var i in r) {
      var s = r[i];
      if (typeof s != "object") {
        var o = s;
        t != null && t[o] !== void 0 ? n += i + "{" + t[o] + "}" : Oe(o) && (n += fe(i) + ":" + Re(i, o) + ";");
      } else if (Array.isArray(s) && typeof s[0] == "string" && (t == null || t[s[0]] === void 0)) for (var c = 0; c < s.length; c++) Oe(s[c]) && (n += fe(i) + ":" + Re(i, s[c]) + ";");
      else {
        var f = K(e, t, s);
        switch (i) {
          case "animation":
          case "animationName": {
            n += fe(i) + ":" + f + ";";
            break;
          }
          default:
            n += i + "{" + f + "}";
        }
      }
    }
    return n;
  }
  var Ee = /label:\s*([^\s;{]+)\s*(;|$)/g, M;
  xe = function(e, t, r) {
    if (e.length === 1 && typeof e[0] == "object" && e[0] !== null && e[0].styles !== void 0) return e[0];
    var n = true, a = "";
    M = void 0;
    var i = e[0];
    if (i == null || i.raw === void 0) n = false, a += K(r, t, i);
    else {
      var s = i;
      a += s[0];
    }
    for (var o = 1; o < e.length; o++) if (a += K(r, t, e[o]), n) {
      var c = i;
      a += c[o];
    }
    Ee.lastIndex = 0;
    for (var f = "", u; (u = Ee.exec(a)) !== null; ) f += "-" + u[1];
    var h = Dt(a) + f;
    return {
      name: h,
      styles: a,
      next: M
    };
  };
  let zt, Ye, Ke, Xe, he, Ut, qt, Gt, Bt, Yt, Kt, $e, Fe, Xt, Zt, Jt, me;
  zt = function(t) {
    return t();
  };
  Ye = Pe.useInsertionEffect ? Pe.useInsertionEffect : false;
  Ke = Ye || zt;
  wr = Ye || rt;
  Xe = ye(typeof HTMLElement < "u" ? Mt({
    key: "css"
  }) : null);
  xr = Xe.Provider;
  Ze = function(t) {
    return nt(function(r, n) {
      var a = ie(Xe);
      return t(r, a, n);
    });
  };
  Je = ye({});
  Qe = {}.hasOwnProperty;
  he = "__EMOTION_TYPE_PLEASE_DO_NOT_USE__";
  Sr = function(t, r) {
    var n = {};
    for (var a in r) Qe.call(r, a) && (n[a] = r[a]);
    return n[he] = t, n;
  };
  Ut = function(t) {
    var r = t.cache, n = t.serialized, a = t.isStringTag;
    return we(r, n, a), Ke(function() {
      return Ge(r, n, a);
    }), null;
  };
  qt = Ze(function(e, t, r) {
    var n = e.css;
    typeof n == "string" && t.registered[n] !== void 0 && (n = t.registered[n]);
    var a = e[he], i = [
      n
    ], s = "";
    typeof e.className == "string" ? s = qe(t.registered, i, e.className) : e.className != null && (s = e.className + " ");
    var o = xe(i, void 0, ie(Je));
    s += t.key + "-" + o.name;
    var c = {};
    for (var f in e) Qe.call(e, f) && f !== "css" && f !== he && (c[f] = e[f]);
    return c.className = s, r && (c.ref = r), H(Me, null, H(Ut, {
      cache: t,
      serialized: o,
      isStringTag: typeof a == "string"
    }), H(a, c));
  });
  kr = qt;
  Gt = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|disableRemotePlayback|download|draggable|encType|enterKeyHint|fetchpriority|fetchPriority|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|popover|popoverTarget|popoverTargetAction|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/;
  Bt = ze(function(e) {
    return Gt.test(e) || e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) < 91;
  });
  Yt = Bt;
  Kt = function(t) {
    return t !== "theme";
  };
  $e = function(t) {
    return typeof t == "string" && t.charCodeAt(0) > 96 ? Yt : Kt;
  };
  Fe = function(t, r, n) {
    var a;
    if (r) {
      var i = r.shouldForwardProp;
      a = t.__emotion_forwardProp && i ? function(s) {
        return t.__emotion_forwardProp(s) && i(s);
      } : i;
    }
    return typeof a != "function" && n && (a = t.__emotion_forwardProp), a;
  };
  Xt = function(t) {
    var r = t.cache, n = t.serialized, a = t.isStringTag;
    return we(r, n, a), Ke(function() {
      return Ge(r, n, a);
    }), null;
  };
  Zt = function e(t, r) {
    var n = t.__emotion_real === t, a = n && t.__emotion_base || t, i, s;
    r !== void 0 && (i = r.label, s = r.target);
    var o = Fe(t, r, n), c = o || $e(a), f = !c("as");
    return function() {
      var u = arguments, h = n && t.__emotion_styles !== void 0 ? t.__emotion_styles.slice(0) : [];
      if (i !== void 0 && h.push("label:" + i + ";"), u[0] == null || u[0].raw === void 0) h.push.apply(h, u);
      else {
        var C = u[0];
        h.push(C[0]);
        for (var A = u.length, w = 1; w < A; w++) h.push(u[w], C[w]);
      }
      var d = Ze(function(m, g, b) {
        var S = f && m.as || a, R = "", T = [], v = m;
        if (m.theme == null) {
          v = {};
          for (var l in m) v[l] = m[l];
          v.theme = ie(Je);
        }
        typeof m.className == "string" ? R = qe(g.registered, T, m.className) : m.className != null && (R = m.className + " ");
        var F = xe(h.concat(T), g.registered, v);
        R += g.key + "-" + F.name, s !== void 0 && (R += " " + s);
        var E = f && o === void 0 ? $e(S) : c, j = {};
        for (var D in m) f && D === "as" || E(D) && (j[D] = m[D]);
        return j.className = R, b && (j.ref = b), H(Me, null, H(Xt, {
          cache: g,
          serialized: F,
          isStringTag: typeof S == "string"
        }), H(S, j));
      });
      return d.displayName = i !== void 0 ? i : "Styled(" + (typeof a == "string" ? a : a.displayName || a.name || "Component") + ")", d.defaultProps = t.defaultProps, d.__emotion_real = d, d.__emotion_base = a, d.__emotion_styles = h, d.__emotion_forwardProp = o, Object.defineProperty(d, "toString", {
        value: function() {
          return "." + s;
        }
      }), d.withComponent = function(m, g) {
        var b = e(m, it({}, r, g, {
          shouldForwardProp: Fe(d, g, true)
        }));
        return b.apply(void 0, h);
      }, d;
    };
  };
  Jt = [
    "a",
    "abbr",
    "address",
    "area",
    "article",
    "aside",
    "audio",
    "b",
    "base",
    "bdi",
    "bdo",
    "big",
    "blockquote",
    "body",
    "br",
    "button",
    "canvas",
    "caption",
    "cite",
    "code",
    "col",
    "colgroup",
    "data",
    "datalist",
    "dd",
    "del",
    "details",
    "dfn",
    "dialog",
    "div",
    "dl",
    "dt",
    "em",
    "embed",
    "fieldset",
    "figcaption",
    "figure",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "head",
    "header",
    "hgroup",
    "hr",
    "html",
    "i",
    "iframe",
    "img",
    "input",
    "ins",
    "kbd",
    "keygen",
    "label",
    "legend",
    "li",
    "link",
    "main",
    "map",
    "mark",
    "marquee",
    "menu",
    "menuitem",
    "meta",
    "meter",
    "nav",
    "noscript",
    "object",
    "ol",
    "optgroup",
    "option",
    "output",
    "p",
    "param",
    "picture",
    "pre",
    "progress",
    "q",
    "rp",
    "rt",
    "ruby",
    "s",
    "samp",
    "script",
    "section",
    "select",
    "small",
    "source",
    "span",
    "strong",
    "style",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "time",
    "title",
    "tr",
    "track",
    "u",
    "ul",
    "var",
    "video",
    "wbr",
    "circle",
    "clipPath",
    "defs",
    "ellipse",
    "foreignObject",
    "g",
    "image",
    "line",
    "linearGradient",
    "mask",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "radialGradient",
    "rect",
    "stop",
    "svg",
    "text",
    "tspan"
  ];
  me = Zt.bind(null);
  Jt.forEach(function(e) {
    me[e] = me(e);
  });
  Qt = function(e, t) {
    return me(e, t);
  };
  function er(e, t) {
    Array.isArray(e.__emotion_styles) && (e.__emotion_styles = t(e.__emotion_styles));
  }
  const Ie = [];
  W = function(e) {
    return Ie[0] = e, xe(Ie);
  };
  pe = function(e, t) {
    const r = {
      ...t
    };
    for (const n in e) if (Object.prototype.hasOwnProperty.call(e, n)) {
      const a = n;
      if (a === "components" || a === "slots") r[a] = {
        ...e[a],
        ...r[a]
      };
      else if (a === "componentsProps" || a === "slotProps") {
        const i = e[a], s = t[a];
        if (!s) r[a] = i || {};
        else if (!i) r[a] = s;
        else {
          r[a] = {
            ...s
          };
          for (const o in i) if (Object.prototype.hasOwnProperty.call(i, o)) {
            const c = o;
            r[a][c] = pe(i[c], s[c]);
          }
        }
      } else r[a] === void 0 && (r[a] = e[a]);
    }
    return r;
  };
  Pr = function(e, t, r = void 0) {
    const n = {};
    for (const a in e) {
      const i = e[a];
      let s = "", o = true;
      for (let c = 0; c < i.length; c += 1) {
        const f = i[c];
        f && (s += (o === true ? "" : " ") + t(f), o = false, r && r[f] && (s += " " + r[f]));
      }
      n[a] = s;
    }
    return n;
  };
  let Le, tr, nr;
  Le = (e) => e;
  tr = () => {
    let e = Le;
    return {
      configure(t) {
        e = t;
      },
      generate(t) {
        return e(t);
      },
      reset() {
        e = Le;
      }
    };
  };
  rr = tr();
  nr = {
    active: "active",
    checked: "checked",
    completed: "completed",
    disabled: "disabled",
    error: "error",
    expanded: "expanded",
    focused: "focused",
    focusVisible: "focusVisible",
    open: "open",
    readOnly: "readOnly",
    required: "required",
    selected: "selected"
  };
  ar = function(e, t, r = "Mui") {
    const n = nr[t];
    return n ? `${r}-${n}` : `${rr.generate(e)}-${t}`;
  };
  Cr = function(e, t, r = "Mui") {
    const n = {};
    return t.forEach((a) => {
      n[a] = ar(e, a, r);
    }), n;
  };
  const et = ye(void 0);
  _r = function({ value: e, children: t }) {
    return at.jsx(et.Provider, {
      value: e,
      children: t
    });
  };
  function ir(e) {
    const { theme: t, name: r, props: n } = e;
    if (!t || !t.components || !t.components[r]) return n;
    const a = t.components[r];
    return a.defaultProps ? pe(a.defaultProps, n) : !a.styleOverrides && !a.variants ? pe(a, n) : n;
  }
  Ar = function({ props: e, name: t }) {
    const r = ie(et);
    return ir({
      props: e,
      name: t,
      theme: {
        components: r
      }
    });
  };
  sr = function(e) {
    const { variants: t, ...r } = e, n = {
      variants: t,
      style: W(r),
      isProcessed: true
    };
    return n.style === r || t && t.forEach((a) => {
      typeof a.style != "function" && (a.style = W(a.style));
    }), n;
  };
  or = st();
  le = function(e) {
    return e !== "ownerState" && e !== "theme" && e !== "sx" && e !== "as";
  };
  function V(e, t) {
    return t && e && typeof e == "object" && e.styles && !e.styles.startsWith("@layer") && (e.styles = `@layer ${t}{${String(e.styles)}}`), e;
  }
  function cr(e) {
    return e ? (t, r) => r[e] : null;
  }
  function fr(e, t, r) {
    e.theme = ur(e.theme) ? r : e.theme[t] || e.theme;
  }
  function ne(e, t, r) {
    const n = typeof t == "function" ? t(e) : t;
    if (Array.isArray(n)) return n.flatMap((a) => ne(e, a, r));
    if (Array.isArray(n == null ? void 0 : n.variants)) {
      let a;
      if (n.isProcessed) a = r ? V(n.style, r) : n.style;
      else {
        const { variants: i, ...s } = n;
        a = r ? V(W(s), r) : s;
      }
      return tt(e, n.variants, [
        a
      ], r);
    }
    return (n == null ? void 0 : n.isProcessed) ? r ? V(W(n.style), r) : n.style : r ? V(W(n), r) : n;
  }
  function tt(e, t, r = [], n = void 0) {
    var _a;
    let a;
    e: for (let i = 0; i < t.length; i += 1) {
      const s = t[i];
      if (typeof s.props == "function") {
        if (a ?? (a = {
          ...e,
          ...e.ownerState,
          ownerState: e.ownerState
        }), !s.props(a)) continue;
      } else for (const o in s.props) if (e[o] !== s.props[o] && ((_a = e.ownerState) == null ? void 0 : _a[o]) !== s.props[o]) continue e;
      typeof s.style == "function" ? (a ?? (a = {
        ...e,
        ...e.ownerState,
        ownerState: e.ownerState
      }), r.push(n ? V(W(s.style(a)), n) : s.style(a))) : r.push(n ? V(W(s.style), n) : s.style);
    }
    return r;
  }
  Tr = function(e = {}) {
    const { themeId: t, defaultTheme: r = or, rootShouldForwardProp: n = le, slotShouldForwardProp: a = le } = e;
    function i(o) {
      fr(o, t, r);
    }
    return (o, c = {}) => {
      er(o, (v) => v.filter((l) => l !== Ce));
      const { name: f, slot: u, skipVariantsResolver: h, skipSx: C, overridesResolver: A = cr(hr(u)), ...w } = c, d = f && f.startsWith("Mui") || u ? "components" : "custom", m = h !== void 0 ? h : u && u !== "Root" && u !== "root" || false, g = C || false;
      let b = le;
      u === "Root" || u === "root" ? b = n : u ? b = a : dr(o) && (b = void 0);
      const S = Qt(o, {
        shouldForwardProp: b,
        label: lr(),
        ...w
      }), R = (v) => {
        if (v.__emotion_real === v) return v;
        if (typeof v == "function") return function(F) {
          return ne(F, v, F.theme.modularCssLayers ? d : void 0);
        };
        if (ot(v)) {
          const l = sr(v);
          return function(E) {
            return l.variants ? ne(E, l, E.theme.modularCssLayers ? d : void 0) : E.theme.modularCssLayers ? V(l.style, d) : l.style;
          };
        }
        return v;
      }, T = (...v) => {
        const l = [], F = v.map(R), E = [];
        if (l.push(i), f && A && E.push(function($) {
          var _a, _b;
          const I = (_b = (_a = $.theme.components) == null ? void 0 : _a[f]) == null ? void 0 : _b.styleOverrides;
          if (!I) return null;
          const Se = {};
          for (const ke in I) Se[ke] = ne($, I[ke], $.theme.modularCssLayers ? "theme" : void 0);
          return A($, Se);
        }), f && !m && E.push(function($) {
          var _a, _b, _c;
          const I = (_c = (_b = (_a = $.theme) == null ? void 0 : _a.components) == null ? void 0 : _b[f]) == null ? void 0 : _c.variants;
          return I ? tt($, I, [], $.theme.modularCssLayers ? "theme" : void 0) : null;
        }), g || E.push(Ce), Array.isArray(F[0])) {
          const Z = F.shift(), $ = new Array(l.length).fill(""), J = new Array(E.length).fill("");
          let I;
          I = [
            ...$,
            ...Z,
            ...J
          ], I.raw = [
            ...$,
            ...Z.raw,
            ...J
          ], l.unshift(I);
        }
        const j = [
          ...l,
          ...F,
          ...E
        ], D = S(...j);
        return o.muiName && (D.muiName = o.muiName), D;
      };
      return S.withConfig && (T.withConfig = S.withConfig), T;
    };
  };
  function lr(e, t) {
    return void 0;
  }
  function ur(e) {
    for (const t in e) return false;
    return true;
  }
  function dr(e) {
    return typeof e == "string" && e.charCodeAt(0) > 96;
  }
  function hr(e) {
    return e && e.charAt(0).toLowerCase() + e.slice(1);
  }
});
export {
  rr as C,
  _r as D,
  kr as E,
  lt as S,
  Je as T,
  __tla,
  Cr as a,
  Pr as b,
  Tr as c,
  wr as d,
  Sr as e,
  xr as f,
  ar as g,
  Qe as h,
  Ge as i,
  Mt as j,
  W as k,
  Qt as l,
  le as m,
  or as n,
  sr as p,
  pe as r,
  xe as s,
  Ar as u,
  Ze as w
};
