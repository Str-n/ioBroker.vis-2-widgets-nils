import { _ as o } from "./preload-helper-PPVm8Dsz.js";
let s, a;
let __tla = (async () => {
  let n;
  n = {
    "@iobroker/adapter-react-v5": async () => await o(() => import("./index-dIInXSfA.js").then(async (m) => {
      await m.__tla;
      return m;
    }), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/de.json": async () => await o(() => import("./de-BPzxvzzY.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/en.json": async () => await o(() => import("./en-CMo9rP3g.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/es.json": async () => await o(() => import("./es-D8pfYodp.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/fr.json": async () => await o(() => import("./fr-B1rF6-oi.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/it.json": async () => await o(() => import("./it-DWDd2OKF.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/nl.json": async () => await o(() => import("./nl-DfHb-A22.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/pl.json": async () => await o(() => import("./pl-C6ge55Tz.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/pt.json": async () => await o(() => import("./pt-BTiykKza.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/ru.json": async () => await o(() => import("./ru-EXvpxdB6.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/uk.json": async () => await o(() => import("./uk-BHlw2rhy.js"), [], import.meta.url),
    "@iobroker/adapter-react-v5/i18n/zh-cn.json": async () => await o(() => import("./zh-cn-_smjnCgp.js"), [], import.meta.url),
    "@mui/icons-material": async () => await o(() => import("./index-Dj4e_O3c.js").then(async (m) => {
      await m.__tla;
      return m;
    }), [], import.meta.url),
    "@mui/material": async () => await o(() => import("./index-C3nKUUlT.js").then(async (m) => {
      await m.__tla;
      return m;
    }), [], import.meta.url),
    "@mui/styles": async () => await o(() => import("./index-CXIQ-I_O.js").then(async (m) => {
      await m.__tla;
      return m;
    }), [], import.meta.url),
    "@mui/system": async () => await o(() => import("./index-CC98rz1z.js").then(async (m) => {
      await m.__tla;
      return m;
    }), [], import.meta.url),
    "prop-types": async () => await o(() => import("./index-DAR0pbjD.js").then((t) => t.i), [], import.meta.url),
    react: async () => await o(() => import("./index-CuxuYCF9.js").then((t) => t.i), [], import.meta.url),
    "react-dom": async () => await o(() => import("./index-z56DYxy0.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((t) => t.i), [], import.meta.url),
    "react-dom/client": async () => await o(() => import("./client-DwRO8cfl.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((t) => t.c), [], import.meta.url)
  };
  a = {
    "@iobroker/adapter-react-v5": {
      name: "@iobroker/adapter-react-v5",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5"].loaded = true;
        const { "@iobroker/adapter-react-v5": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/de.json": {
      name: "@iobroker/adapter-react-v5/i18n/de.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/de.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/de.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/en.json": {
      name: "@iobroker/adapter-react-v5/i18n/en.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/en.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/en.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/es.json": {
      name: "@iobroker/adapter-react-v5/i18n/es.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/es.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/es.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/fr.json": {
      name: "@iobroker/adapter-react-v5/i18n/fr.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/fr.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/fr.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/it.json": {
      name: "@iobroker/adapter-react-v5/i18n/it.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/it.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/it.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/nl.json": {
      name: "@iobroker/adapter-react-v5/i18n/nl.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/nl.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/nl.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/pl.json": {
      name: "@iobroker/adapter-react-v5/i18n/pl.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/pl.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/pl.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/pt.json": {
      name: "@iobroker/adapter-react-v5/i18n/pt.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/pt.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/pt.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/ru.json": {
      name: "@iobroker/adapter-react-v5/i18n/ru.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/ru.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/ru.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/uk.json": {
      name: "@iobroker/adapter-react-v5/i18n/uk.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/uk.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/uk.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@iobroker/adapter-react-v5/i18n/zh-cn.json": {
      name: "@iobroker/adapter-react-v5/i18n/zh-cn.json",
      version: "7.7.5",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@iobroker/adapter-react-v5/i18n/zh-cn.json"].loaded = true;
        const { "@iobroker/adapter-react-v5/i18n/zh-cn.json": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@mui/icons-material": {
      name: "@mui/icons-material",
      version: "6.5.0",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@mui/icons-material"].loaded = true;
        const { "@mui/icons-material": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@mui/material": {
      name: "@mui/material",
      version: "6.5.0",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@mui/material"].loaded = true;
        const { "@mui/material": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@mui/styles": {
      name: "@mui/styles",
      version: "6.5.0",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@mui/styles"].loaded = true;
        const { "@mui/styles": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "@mui/system": {
      name: "@mui/system",
      version: "6.5.0",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["@mui/system"].loaded = true;
        const { "@mui/system": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "prop-types": {
      name: "prop-types",
      version: "15.8.1",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["prop-types"].loaded = true;
        const { "prop-types": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    react: {
      name: "react",
      version: "18.3.1",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a.react.loaded = true;
        const { react: e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "react-dom": {
      name: "react-dom",
      version: "18.3.1",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["react-dom"].loaded = true;
        const { "react-dom": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    },
    "react-dom/client": {
      name: "react-dom/client",
      version: "18.3.1",
      scope: [
        "default"
      ],
      loaded: false,
      from: "__mfe_internal__vis2nilsForkWidgets",
      async get() {
        a["react-dom/client"].loaded = true;
        const { "react-dom/client": e } = n, r = {
          ...await e()
        };
        return Object.defineProperty(r, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: "*"
      }
    }
  };
  s = [];
})();
export {
  __tla,
  s as usedRemotes,
  a as usedShared
};
