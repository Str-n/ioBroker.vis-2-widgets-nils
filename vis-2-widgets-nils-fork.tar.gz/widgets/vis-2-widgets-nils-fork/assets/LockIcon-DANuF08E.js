import { j as jsxRuntimeExports, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { f as __mf_24, k as __mf_32, e as __mf_31, a as React, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
let DoorAnimation, LockIcon;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  function getDefaultExportFromCjs(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
  }
  var lottie$2 = {
    exports: {}
  }, lottie = lottie$2.exports;
  (function(module, exports$1) {
    typeof document < "u" && typeof navigator < "u" && (function(t, e) {
      module.exports = e();
    })(lottie, (function() {
      var svgNS = "http://www.w3.org/2000/svg", locationHref = "", _useWebWorker = false, initialDefaultFrame = -999999, setWebWorker = function(e) {
        _useWebWorker = !!e;
      }, getWebWorker = function() {
        return _useWebWorker;
      }, setLocationHref = function(e) {
        locationHref = e;
      }, getLocationHref = function() {
        return locationHref;
      };
      function createTag(t) {
        return document.createElement(t);
      }
      function extendPrototype(t, e) {
        var r, i = t.length, s;
        for (r = 0; r < i; r += 1) {
          s = t[r].prototype;
          for (var a in s) Object.prototype.hasOwnProperty.call(s, a) && (e.prototype[a] = s[a]);
        }
      }
      function getDescriptor(t, e) {
        return Object.getOwnPropertyDescriptor(t, e);
      }
      function createProxyFunction(t) {
        function e() {
        }
        return e.prototype = t, e;
      }
      var audioControllerFactory = (function() {
        function t(e) {
          this.audios = [], this.audioFactory = e, this._volume = 1, this._isMuted = false;
        }
        return t.prototype = {
          addAudio: function(r) {
            this.audios.push(r);
          },
          pause: function() {
            var r, i = this.audios.length;
            for (r = 0; r < i; r += 1) this.audios[r].pause();
          },
          resume: function() {
            var r, i = this.audios.length;
            for (r = 0; r < i; r += 1) this.audios[r].resume();
          },
          setRate: function(r) {
            var i, s = this.audios.length;
            for (i = 0; i < s; i += 1) this.audios[i].setRate(r);
          },
          createAudio: function(r) {
            return this.audioFactory ? this.audioFactory(r) : window.Howl ? new window.Howl({
              src: [
                r
              ]
            }) : {
              isPlaying: false,
              play: function() {
                this.isPlaying = true;
              },
              seek: function() {
                this.isPlaying = false;
              },
              playing: function() {
              },
              rate: function() {
              },
              setVolume: function() {
              }
            };
          },
          setAudioFactory: function(r) {
            this.audioFactory = r;
          },
          setVolume: function(r) {
            this._volume = r, this._updateVolume();
          },
          mute: function() {
            this._isMuted = true, this._updateVolume();
          },
          unmute: function() {
            this._isMuted = false, this._updateVolume();
          },
          getVolume: function() {
            return this._volume;
          },
          _updateVolume: function() {
            var r, i = this.audios.length;
            for (r = 0; r < i; r += 1) this.audios[r].volume(this._volume * (this._isMuted ? 0 : 1));
          }
        }, function() {
          return new t();
        };
      })(), createTypedArray = /* @__PURE__ */ (function() {
        function t(r, i) {
          var s = 0, a = [], n;
          switch (r) {
            case "int16":
            case "uint8c":
              n = 1;
              break;
            default:
              n = 1.1;
              break;
          }
          for (s = 0; s < i; s += 1) a.push(n);
          return a;
        }
        function e(r, i) {
          return r === "float32" ? new Float32Array(i) : r === "int16" ? new Int16Array(i) : r === "uint8c" ? new Uint8ClampedArray(i) : t(r, i);
        }
        return typeof Uint8ClampedArray == "function" && typeof Float32Array == "function" ? e : t;
      })();
      function createSizedArray(t) {
        return Array.apply(null, {
          length: t
        });
      }
      function _typeof$6(t) {
        "@babel/helpers - typeof";
        return _typeof$6 = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
          return typeof e;
        } : function(e) {
          return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, _typeof$6(t);
      }
      var subframeEnabled = true, expressionsPlugin = null, expressionsInterfaces = null, idPrefix$1 = "", isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent), bmPow = Math.pow, bmSqrt = Math.sqrt, bmFloor = Math.floor, bmMax = Math.max, bmMin = Math.min, BMMath = {};
      (function() {
        var t = [
          "abs",
          "acos",
          "acosh",
          "asin",
          "asinh",
          "atan",
          "atanh",
          "atan2",
          "ceil",
          "cbrt",
          "expm1",
          "clz32",
          "cos",
          "cosh",
          "exp",
          "floor",
          "fround",
          "hypot",
          "imul",
          "log",
          "log1p",
          "log2",
          "log10",
          "max",
          "min",
          "pow",
          "random",
          "round",
          "sign",
          "sin",
          "sinh",
          "sqrt",
          "tan",
          "tanh",
          "trunc",
          "E",
          "LN10",
          "LN2",
          "LOG10E",
          "LOG2E",
          "PI",
          "SQRT1_2",
          "SQRT2"
        ], e, r = t.length;
        for (e = 0; e < r; e += 1) BMMath[t[e]] = Math[t[e]];
      })(), BMMath.random = Math.random, BMMath.abs = function(t) {
        var e = _typeof$6(t);
        if (e === "object" && t.length) {
          var r = createSizedArray(t.length), i, s = t.length;
          for (i = 0; i < s; i += 1) r[i] = Math.abs(t[i]);
          return r;
        }
        return Math.abs(t);
      };
      var defaultCurveSegments = 150, degToRads = Math.PI / 180, roundCorner = 0.5519;
      function styleDiv(t) {
        t.style.position = "absolute", t.style.top = 0, t.style.left = 0, t.style.display = "block", t.style.transformOrigin = "0 0", t.style.webkitTransformOrigin = "0 0", t.style.backfaceVisibility = "visible", t.style.webkitBackfaceVisibility = "visible", t.style.transformStyle = "preserve-3d", t.style.webkitTransformStyle = "preserve-3d", t.style.mozTransformStyle = "preserve-3d";
      }
      function BMEnterFrameEvent(t, e, r, i) {
        this.type = t, this.currentTime = e, this.totalTime = r, this.direction = i < 0 ? -1 : 1;
      }
      function BMCompleteEvent(t, e) {
        this.type = t, this.direction = e < 0 ? -1 : 1;
      }
      function BMCompleteLoopEvent(t, e, r, i) {
        this.type = t, this.currentLoop = r, this.totalLoops = e, this.direction = i < 0 ? -1 : 1;
      }
      function BMSegmentStartEvent(t, e, r) {
        this.type = t, this.firstFrame = e, this.totalFrames = r;
      }
      function BMDestroyEvent(t, e) {
        this.type = t, this.target = e;
      }
      function BMRenderFrameErrorEvent(t, e) {
        this.type = "renderFrameError", this.nativeError = t, this.currentTime = e;
      }
      function BMConfigErrorEvent(t) {
        this.type = "configError", this.nativeError = t;
      }
      var createElementID = /* @__PURE__ */ (function() {
        var t = 0;
        return function() {
          return t += 1, idPrefix$1 + "__lottie_element_" + t;
        };
      })();
      function HSVtoRGB(t, e, r) {
        var i, s, a, n, l, o, p, y;
        switch (n = Math.floor(t * 6), l = t * 6 - n, o = r * (1 - e), p = r * (1 - l * e), y = r * (1 - (1 - l) * e), n % 6) {
          case 0:
            i = r, s = y, a = o;
            break;
          case 1:
            i = p, s = r, a = o;
            break;
          case 2:
            i = o, s = r, a = y;
            break;
          case 3:
            i = o, s = p, a = r;
            break;
          case 4:
            i = y, s = o, a = r;
            break;
          case 5:
            i = r, s = o, a = p;
            break;
        }
        return [
          i,
          s,
          a
        ];
      }
      function RGBtoHSV(t, e, r) {
        var i = Math.max(t, e, r), s = Math.min(t, e, r), a = i - s, n, l = i === 0 ? 0 : a / i, o = i / 255;
        switch (i) {
          case s:
            n = 0;
            break;
          case t:
            n = e - r + a * (e < r ? 6 : 0), n /= 6 * a;
            break;
          case e:
            n = r - t + a * 2, n /= 6 * a;
            break;
          case r:
            n = t - e + a * 4, n /= 6 * a;
            break;
        }
        return [
          n,
          l,
          o
        ];
      }
      function addSaturationToRGB(t, e) {
        var r = RGBtoHSV(t[0] * 255, t[1] * 255, t[2] * 255);
        return r[1] += e, r[1] > 1 ? r[1] = 1 : r[1] <= 0 && (r[1] = 0), HSVtoRGB(r[0], r[1], r[2]);
      }
      function addBrightnessToRGB(t, e) {
        var r = RGBtoHSV(t[0] * 255, t[1] * 255, t[2] * 255);
        return r[2] += e, r[2] > 1 ? r[2] = 1 : r[2] < 0 && (r[2] = 0), HSVtoRGB(r[0], r[1], r[2]);
      }
      function addHueToRGB(t, e) {
        var r = RGBtoHSV(t[0] * 255, t[1] * 255, t[2] * 255);
        return r[0] += e / 360, r[0] > 1 ? r[0] -= 1 : r[0] < 0 && (r[0] += 1), HSVtoRGB(r[0], r[1], r[2]);
      }
      var rgbToHex = (function() {
        var t = [], e, r;
        for (e = 0; e < 256; e += 1) r = e.toString(16), t[e] = r.length === 1 ? "0" + r : r;
        return function(i, s, a) {
          return i < 0 && (i = 0), s < 0 && (s = 0), a < 0 && (a = 0), "#" + t[i] + t[s] + t[a];
        };
      })(), setSubframeEnabled = function(e) {
        subframeEnabled = !!e;
      }, getSubframeEnabled = function() {
        return subframeEnabled;
      }, setExpressionsPlugin = function(e) {
        expressionsPlugin = e;
      }, getExpressionsPlugin = function() {
        return expressionsPlugin;
      }, setExpressionInterfaces = function(e) {
        expressionsInterfaces = e;
      }, getExpressionInterfaces = function() {
        return expressionsInterfaces;
      }, setDefaultCurveSegments = function(e) {
        defaultCurveSegments = e;
      }, getDefaultCurveSegments = function() {
        return defaultCurveSegments;
      }, setIdPrefix = function(e) {
        idPrefix$1 = e;
      };
      function createNS(t) {
        return document.createElementNS(svgNS, t);
      }
      function _typeof$5(t) {
        "@babel/helpers - typeof";
        return _typeof$5 = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
          return typeof e;
        } : function(e) {
          return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, _typeof$5(t);
      }
      var dataManager = /* @__PURE__ */ (function() {
        var t = 1, e = [], r, i, s = {
          onmessage: function() {
          },
          postMessage: function(x) {
            r({
              data: x
            });
          }
        }, a = {
          postMessage: function(x) {
            s.onmessage({
              data: x
            });
          }
        };
        function n(u) {
          if (window.Worker && window.Blob && getWebWorker()) {
            var x = new Blob([
              "var _workerSelf = self; self.onmessage = ",
              u.toString()
            ], {
              type: "text/javascript"
            }), g = URL.createObjectURL(x);
            return new Worker(g);
          }
          return r = u, s;
        }
        function l() {
          i || (i = n(function(x) {
            function g() {
              function A(R, k) {
                var M, S, P = R.length, V, F, B, G;
                for (S = 0; S < P; S += 1) if (M = R[S], "ks" in M && !M.completed) {
                  if (M.completed = true, M.hasMask) {
                    var z = M.masksProperties;
                    for (F = z.length, V = 0; V < F; V += 1) if (z[V].pt.k.i) C(z[V].pt.k);
                    else for (G = z[V].pt.k.length, B = 0; B < G; B += 1) z[V].pt.k[B].s && C(z[V].pt.k[B].s[0]), z[V].pt.k[B].e && C(z[V].pt.k[B].e[0]);
                  }
                  M.ty === 0 ? (M.layers = f(M.refId, k), A(M.layers, k)) : M.ty === 4 ? b(M.shapes) : M.ty === 5 && N(M);
                }
              }
              function c(R, k) {
                if (R) {
                  var M = 0, S = R.length;
                  for (M = 0; M < S; M += 1) R[M].t === 1 && (R[M].data.layers = f(R[M].data.refId, k), A(R[M].data.layers, k));
                }
              }
              function m(R, k) {
                for (var M = 0, S = k.length; M < S; ) {
                  if (k[M].id === R) return k[M];
                  M += 1;
                }
                return null;
              }
              function f(R, k) {
                var M = m(R, k);
                return M ? M.layers.__used ? JSON.parse(JSON.stringify(M.layers)) : (M.layers.__used = true, M.layers) : null;
              }
              function b(R) {
                var k, M = R.length, S, P;
                for (k = M - 1; k >= 0; k -= 1) if (R[k].ty === "sh") if (R[k].ks.k.i) C(R[k].ks.k);
                else for (P = R[k].ks.k.length, S = 0; S < P; S += 1) R[k].ks.k[S].s && C(R[k].ks.k[S].s[0]), R[k].ks.k[S].e && C(R[k].ks.k[S].e[0]);
                else R[k].ty === "gr" && b(R[k].it);
              }
              function C(R) {
                var k, M = R.i.length;
                for (k = 0; k < M; k += 1) R.i[k][0] += R.v[k][0], R.i[k][1] += R.v[k][1], R.o[k][0] += R.v[k][0], R.o[k][1] += R.v[k][1];
              }
              function _(R, k) {
                var M = k ? k.split(".") : [
                  100,
                  100,
                  100
                ];
                return R[0] > M[0] ? true : M[0] > R[0] ? false : R[1] > M[1] ? true : M[1] > R[1] ? false : R[2] > M[2] ? true : M[2] > R[2] ? false : null;
              }
              var T = /* @__PURE__ */ (function() {
                var R = [
                  4,
                  4,
                  14
                ];
                function k(S) {
                  var P = S.t.d;
                  S.t.d = {
                    k: [
                      {
                        s: P,
                        t: 0
                      }
                    ]
                  };
                }
                function M(S) {
                  var P, V = S.length;
                  for (P = 0; P < V; P += 1) S[P].ty === 5 && k(S[P]);
                }
                return function(S) {
                  if (_(R, S.v) && (M(S.layers), S.assets)) {
                    var P, V = S.assets.length;
                    for (P = 0; P < V; P += 1) S.assets[P].layers && M(S.assets[P].layers);
                  }
                };
              })(), I = /* @__PURE__ */ (function() {
                var R = [
                  4,
                  7,
                  99
                ];
                return function(k) {
                  if (k.chars && !_(R, k.v)) {
                    var M, S = k.chars.length;
                    for (M = 0; M < S; M += 1) {
                      var P = k.chars[M];
                      P.data && P.data.shapes && (b(P.data.shapes), P.data.ip = 0, P.data.op = 99999, P.data.st = 0, P.data.sr = 1, P.data.ks = {
                        p: {
                          k: [
                            0,
                            0
                          ],
                          a: 0
                        },
                        s: {
                          k: [
                            100,
                            100
                          ],
                          a: 0
                        },
                        a: {
                          k: [
                            0,
                            0
                          ],
                          a: 0
                        },
                        r: {
                          k: 0,
                          a: 0
                        },
                        o: {
                          k: 100,
                          a: 0
                        }
                      }, k.chars[M].t || (P.data.shapes.push({
                        ty: "no"
                      }), P.data.shapes[0].it.push({
                        p: {
                          k: [
                            0,
                            0
                          ],
                          a: 0
                        },
                        s: {
                          k: [
                            100,
                            100
                          ],
                          a: 0
                        },
                        a: {
                          k: [
                            0,
                            0
                          ],
                          a: 0
                        },
                        r: {
                          k: 0,
                          a: 0
                        },
                        o: {
                          k: 100,
                          a: 0
                        },
                        sk: {
                          k: 0,
                          a: 0
                        },
                        sa: {
                          k: 0,
                          a: 0
                        },
                        ty: "tr"
                      })));
                    }
                  }
                };
              })(), L = /* @__PURE__ */ (function() {
                var R = [
                  5,
                  7,
                  15
                ];
                function k(S) {
                  var P = S.t.p;
                  typeof P.a == "number" && (P.a = {
                    a: 0,
                    k: P.a
                  }), typeof P.p == "number" && (P.p = {
                    a: 0,
                    k: P.p
                  }), typeof P.r == "number" && (P.r = {
                    a: 0,
                    k: P.r
                  });
                }
                function M(S) {
                  var P, V = S.length;
                  for (P = 0; P < V; P += 1) S[P].ty === 5 && k(S[P]);
                }
                return function(S) {
                  if (_(R, S.v) && (M(S.layers), S.assets)) {
                    var P, V = S.assets.length;
                    for (P = 0; P < V; P += 1) S.assets[P].layers && M(S.assets[P].layers);
                  }
                };
              })(), j = /* @__PURE__ */ (function() {
                var R = [
                  4,
                  1,
                  9
                ];
                function k(S) {
                  var P, V = S.length, F, B;
                  for (P = 0; P < V; P += 1) if (S[P].ty === "gr") k(S[P].it);
                  else if (S[P].ty === "fl" || S[P].ty === "st") if (S[P].c.k && S[P].c.k[0].i) for (B = S[P].c.k.length, F = 0; F < B; F += 1) S[P].c.k[F].s && (S[P].c.k[F].s[0] /= 255, S[P].c.k[F].s[1] /= 255, S[P].c.k[F].s[2] /= 255, S[P].c.k[F].s[3] /= 255), S[P].c.k[F].e && (S[P].c.k[F].e[0] /= 255, S[P].c.k[F].e[1] /= 255, S[P].c.k[F].e[2] /= 255, S[P].c.k[F].e[3] /= 255);
                  else S[P].c.k[0] /= 255, S[P].c.k[1] /= 255, S[P].c.k[2] /= 255, S[P].c.k[3] /= 255;
                }
                function M(S) {
                  var P, V = S.length;
                  for (P = 0; P < V; P += 1) S[P].ty === 4 && k(S[P].shapes);
                }
                return function(S) {
                  if (_(R, S.v) && (M(S.layers), S.assets)) {
                    var P, V = S.assets.length;
                    for (P = 0; P < V; P += 1) S.assets[P].layers && M(S.assets[P].layers);
                  }
                };
              })(), O = /* @__PURE__ */ (function() {
                var R = [
                  4,
                  4,
                  18
                ];
                function k(S) {
                  var P, V = S.length, F, B;
                  for (P = V - 1; P >= 0; P -= 1) if (S[P].ty === "sh") if (S[P].ks.k.i) S[P].ks.k.c = S[P].closed;
                  else for (B = S[P].ks.k.length, F = 0; F < B; F += 1) S[P].ks.k[F].s && (S[P].ks.k[F].s[0].c = S[P].closed), S[P].ks.k[F].e && (S[P].ks.k[F].e[0].c = S[P].closed);
                  else S[P].ty === "gr" && k(S[P].it);
                }
                function M(S) {
                  var P, V, F = S.length, B, G, z, q;
                  for (V = 0; V < F; V += 1) {
                    if (P = S[V], P.hasMask) {
                      var $ = P.masksProperties;
                      for (G = $.length, B = 0; B < G; B += 1) if ($[B].pt.k.i) $[B].pt.k.c = $[B].cl;
                      else for (q = $[B].pt.k.length, z = 0; z < q; z += 1) $[B].pt.k[z].s && ($[B].pt.k[z].s[0].c = $[B].cl), $[B].pt.k[z].e && ($[B].pt.k[z].e[0].c = $[B].cl);
                    }
                    P.ty === 4 && k(P.shapes);
                  }
                }
                return function(S) {
                  if (_(R, S.v) && (M(S.layers), S.assets)) {
                    var P, V = S.assets.length;
                    for (P = 0; P < V; P += 1) S.assets[P].layers && M(S.assets[P].layers);
                  }
                };
              })();
              function D(R) {
                R.__complete || (j(R), T(R), I(R), L(R), O(R), A(R.layers, R.assets), c(R.chars, R.assets), R.__complete = true);
              }
              function N(R) {
                R.t.a.length === 0 && "m" in R.t.p;
              }
              var H = {};
              return H.completeData = D, H.checkColors = j, H.checkChars = I, H.checkPathProperties = L, H.checkShapes = O, H.completeLayers = A, H;
            }
            if (a.dataManager || (a.dataManager = g()), a.assetLoader || (a.assetLoader = /* @__PURE__ */ (function() {
              function A(m) {
                var f = m.getResponseHeader("content-type");
                return f && m.responseType === "json" && f.indexOf("json") !== -1 || m.response && _typeof$5(m.response) === "object" ? m.response : m.response && typeof m.response == "string" ? JSON.parse(m.response) : m.responseText ? JSON.parse(m.responseText) : null;
              }
              function c(m, f, b, C) {
                var _, T = new XMLHttpRequest();
                try {
                  T.responseType = "json";
                } catch {
                }
                T.onreadystatechange = function() {
                  if (T.readyState === 4) if (T.status === 200) _ = A(T), b(_);
                  else try {
                    _ = A(T), b(_);
                  } catch (I) {
                    C && C(I);
                  }
                };
                try {
                  T.open([
                    "G",
                    "E",
                    "T"
                  ].join(""), m, true);
                } catch {
                  T.open([
                    "G",
                    "E",
                    "T"
                  ].join(""), f + "/" + m, true);
                }
                T.send();
              }
              return {
                load: c
              };
            })()), x.data.type === "loadAnimation") a.assetLoader.load(x.data.path, x.data.fullPath, function(A) {
              a.dataManager.completeData(A), a.postMessage({
                id: x.data.id,
                payload: A,
                status: "success"
              });
            }, function() {
              a.postMessage({
                id: x.data.id,
                status: "error"
              });
            });
            else if (x.data.type === "complete") {
              var d = x.data.animation;
              a.dataManager.completeData(d), a.postMessage({
                id: x.data.id,
                payload: d,
                status: "success"
              });
            } else x.data.type === "loadData" && a.assetLoader.load(x.data.path, x.data.fullPath, function(A) {
              a.postMessage({
                id: x.data.id,
                payload: A,
                status: "success"
              });
            }, function() {
              a.postMessage({
                id: x.data.id,
                status: "error"
              });
            });
          }), i.onmessage = function(u) {
            var x = u.data, g = x.id, d = e[g];
            e[g] = null, x.status === "success" ? d.onComplete(x.payload) : d.onError && d.onError();
          });
        }
        function o(u, x) {
          t += 1;
          var g = "processId_" + t;
          return e[g] = {
            onComplete: u,
            onError: x
          }, g;
        }
        function p(u, x, g) {
          l();
          var d = o(x, g);
          i.postMessage({
            type: "loadAnimation",
            path: u,
            fullPath: window.location.origin + window.location.pathname,
            id: d
          });
        }
        function y(u, x, g) {
          l();
          var d = o(x, g);
          i.postMessage({
            type: "loadData",
            path: u,
            fullPath: window.location.origin + window.location.pathname,
            id: d
          });
        }
        function E(u, x, g) {
          l();
          var d = o(x, g);
          i.postMessage({
            type: "complete",
            animation: u,
            id: d
          });
        }
        return {
          loadAnimation: p,
          loadData: y,
          completeAnimation: E
        };
      })(), ImagePreloader = (function() {
        var t = (function() {
          var c = createTag("canvas");
          c.width = 1, c.height = 1;
          var m = c.getContext("2d");
          return m.fillStyle = "rgba(0,0,0,0)", m.fillRect(0, 0, 1, 1), c;
        })();
        function e() {
          this.loadedAssets += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null);
        }
        function r() {
          this.loadedFootagesCount += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null);
        }
        function i(c, m, f) {
          var b = "";
          if (c.e) b = c.p;
          else if (m) {
            var C = c.p;
            C.indexOf("images/") !== -1 && (C = C.split("/")[1]), b = m + C;
          } else b = f, b += c.u ? c.u : "", b += c.p;
          return b;
        }
        function s(c) {
          var m = 0, f = setInterval(function() {
            var b = c.getBBox();
            (b.width || m > 500) && (this._imageLoaded(), clearInterval(f)), m += 1;
          }.bind(this), 50);
        }
        function a(c) {
          var m = i(c, this.assetsPath, this.path), f = createNS("image");
          isSafari ? this.testImageLoaded(f) : f.addEventListener("load", this._imageLoaded, false), f.addEventListener("error", function() {
            b.img = t, this._imageLoaded();
          }.bind(this), false), f.setAttributeNS("http://www.w3.org/1999/xlink", "href", m), this._elementHelper.append ? this._elementHelper.append(f) : this._elementHelper.appendChild(f);
          var b = {
            img: f,
            assetData: c
          };
          return b;
        }
        function n(c) {
          var m = i(c, this.assetsPath, this.path), f = createTag("img");
          f.crossOrigin = "anonymous", f.addEventListener("load", this._imageLoaded, false), f.addEventListener("error", function() {
            b.img = t, this._imageLoaded();
          }.bind(this), false), f.src = m;
          var b = {
            img: f,
            assetData: c
          };
          return b;
        }
        function l(c) {
          var m = {
            assetData: c
          }, f = i(c, this.assetsPath, this.path);
          return dataManager.loadData(f, function(b) {
            m.img = b, this._footageLoaded();
          }.bind(this), function() {
            m.img = {}, this._footageLoaded();
          }.bind(this)), m;
        }
        function o(c, m) {
          this.imagesLoadedCb = m;
          var f, b = c.length;
          for (f = 0; f < b; f += 1) c[f].layers || (!c[f].t || c[f].t === "seq" ? (this.totalImages += 1, this.images.push(this._createImageData(c[f]))) : c[f].t === 3 && (this.totalFootages += 1, this.images.push(this.createFootageData(c[f]))));
        }
        function p(c) {
          this.path = c || "";
        }
        function y(c) {
          this.assetsPath = c || "";
        }
        function E(c) {
          for (var m = 0, f = this.images.length; m < f; ) {
            if (this.images[m].assetData === c) return this.images[m].img;
            m += 1;
          }
          return null;
        }
        function u() {
          this.imagesLoadedCb = null, this.images.length = 0;
        }
        function x() {
          return this.totalImages === this.loadedAssets;
        }
        function g() {
          return this.totalFootages === this.loadedFootagesCount;
        }
        function d(c, m) {
          c === "svg" ? (this._elementHelper = m, this._createImageData = this.createImageData.bind(this)) : this._createImageData = this.createImgData.bind(this);
        }
        function A() {
          this._imageLoaded = e.bind(this), this._footageLoaded = r.bind(this), this.testImageLoaded = s.bind(this), this.createFootageData = l.bind(this), this.assetsPath = "", this.path = "", this.totalImages = 0, this.totalFootages = 0, this.loadedAssets = 0, this.loadedFootagesCount = 0, this.imagesLoadedCb = null, this.images = [];
        }
        return A.prototype = {
          loadAssets: o,
          setAssetsPath: y,
          setPath: p,
          loadedImages: x,
          loadedFootages: g,
          destroy: u,
          getAsset: E,
          createImgData: n,
          createImageData: a,
          imageLoaded: e,
          footageLoaded: r,
          setCacheType: d
        }, A;
      })();
      function BaseEvent() {
      }
      BaseEvent.prototype = {
        triggerEvent: function(e, r) {
          if (this._cbs[e]) for (var i = this._cbs[e], s = 0; s < i.length; s += 1) i[s](r);
        },
        addEventListener: function(e, r) {
          return this._cbs[e] || (this._cbs[e] = []), this._cbs[e].push(r), function() {
            this.removeEventListener(e, r);
          }.bind(this);
        },
        removeEventListener: function(e, r) {
          if (!r) this._cbs[e] = null;
          else if (this._cbs[e]) {
            for (var i = 0, s = this._cbs[e].length; i < s; ) this._cbs[e][i] === r && (this._cbs[e].splice(i, 1), i -= 1, s -= 1), i += 1;
            this._cbs[e].length || (this._cbs[e] = null);
          }
        }
      };
      var markerParser = /* @__PURE__ */ (function() {
        function t(e) {
          for (var r = e.split(`\r
`), i = {}, s, a = 0, n = 0; n < r.length; n += 1) s = r[n].split(":"), s.length === 2 && (i[s[0]] = s[1].trim(), a += 1);
          if (a === 0) throw new Error();
          return i;
        }
        return function(e) {
          for (var r = [], i = 0; i < e.length; i += 1) {
            var s = e[i], a = {
              time: s.tm,
              duration: s.dr
            };
            try {
              a.payload = JSON.parse(e[i].cm);
            } catch {
              try {
                a.payload = t(e[i].cm);
              } catch {
                a.payload = {
                  name: e[i].cm
                };
              }
            }
            r.push(a);
          }
          return r;
        };
      })(), ProjectInterface = /* @__PURE__ */ (function() {
        function t(e) {
          this.compositions.push(e);
        }
        return function() {
          function e(r) {
            for (var i = 0, s = this.compositions.length; i < s; ) {
              if (this.compositions[i].data && this.compositions[i].data.nm === r) return this.compositions[i].prepareFrame && this.compositions[i].data.xt && this.compositions[i].prepareFrame(this.currentFrame), this.compositions[i].compInterface;
              i += 1;
            }
            return null;
          }
          return e.compositions = [], e.currentFrame = 0, e.registerComposition = t, e;
        };
      })(), renderers = {}, registerRenderer = function(e, r) {
        renderers[e] = r;
      };
      function getRenderer(t) {
        return renderers[t];
      }
      function getRegisteredRenderer() {
        if (renderers.canvas) return "canvas";
        for (var t in renderers) if (renderers[t]) return t;
        return "";
      }
      function _typeof$4(t) {
        "@babel/helpers - typeof";
        return _typeof$4 = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
          return typeof e;
        } : function(e) {
          return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, _typeof$4(t);
      }
      var AnimationItem = function() {
        this._cbs = [], this.name = "", this.path = "", this.isLoaded = false, this.currentFrame = 0, this.currentRawFrame = 0, this.firstFrame = 0, this.totalFrames = 0, this.frameRate = 0, this.frameMult = 0, this.playSpeed = 1, this.playDirection = 1, this.playCount = 0, this.animationData = {}, this.assets = [], this.isPaused = true, this.autoplay = false, this.loop = true, this.renderer = null, this.animationID = createElementID(), this.assetsPath = "", this.timeCompleted = 0, this.segmentPos = 0, this.isSubframeEnabled = getSubframeEnabled(), this.segments = [], this._idle = true, this._completedLoop = false, this.projectInterface = ProjectInterface(), this.imagePreloader = new ImagePreloader(), this.audioController = audioControllerFactory(), this.markers = [], this.configAnimation = this.configAnimation.bind(this), this.onSetupError = this.onSetupError.bind(this), this.onSegmentComplete = this.onSegmentComplete.bind(this), this.drawnFrameEvent = new BMEnterFrameEvent("drawnFrame", 0, 0, 0), this.expressionsPlugin = getExpressionsPlugin();
      };
      extendPrototype([
        BaseEvent
      ], AnimationItem), AnimationItem.prototype.setParams = function(t) {
        (t.wrapper || t.container) && (this.wrapper = t.wrapper || t.container);
        var e = "svg";
        t.animType ? e = t.animType : t.renderer && (e = t.renderer);
        var r = getRenderer(e);
        this.renderer = new r(this, t.rendererSettings), this.imagePreloader.setCacheType(e, this.renderer.globalData.defs), this.renderer.setProjectInterface(this.projectInterface), this.animType = e, t.loop === "" || t.loop === null || t.loop === void 0 || t.loop === true ? this.loop = true : t.loop === false ? this.loop = false : this.loop = parseInt(t.loop, 10), this.autoplay = "autoplay" in t ? t.autoplay : true, this.name = t.name ? t.name : "", this.autoloadSegments = Object.prototype.hasOwnProperty.call(t, "autoloadSegments") ? t.autoloadSegments : true, this.assetsPath = t.assetsPath, this.initialSegment = t.initialSegment, t.audioFactory && this.audioController.setAudioFactory(t.audioFactory), t.animationData ? this.setupAnimation(t.animationData) : t.path && (t.path.lastIndexOf("\\") !== -1 ? this.path = t.path.substr(0, t.path.lastIndexOf("\\") + 1) : this.path = t.path.substr(0, t.path.lastIndexOf("/") + 1), this.fileName = t.path.substr(t.path.lastIndexOf("/") + 1), this.fileName = this.fileName.substr(0, this.fileName.lastIndexOf(".json")), dataManager.loadAnimation(t.path, this.configAnimation, this.onSetupError));
      }, AnimationItem.prototype.onSetupError = function() {
        this.trigger("data_failed");
      }, AnimationItem.prototype.setupAnimation = function(t) {
        dataManager.completeAnimation(t, this.configAnimation);
      }, AnimationItem.prototype.setData = function(t, e) {
        e && _typeof$4(e) !== "object" && (e = JSON.parse(e));
        var r = {
          wrapper: t,
          animationData: e
        }, i = t.attributes;
        r.path = i.getNamedItem("data-animation-path") ? i.getNamedItem("data-animation-path").value : i.getNamedItem("data-bm-path") ? i.getNamedItem("data-bm-path").value : i.getNamedItem("bm-path") ? i.getNamedItem("bm-path").value : "", r.animType = i.getNamedItem("data-anim-type") ? i.getNamedItem("data-anim-type").value : i.getNamedItem("data-bm-type") ? i.getNamedItem("data-bm-type").value : i.getNamedItem("bm-type") ? i.getNamedItem("bm-type").value : i.getNamedItem("data-bm-renderer") ? i.getNamedItem("data-bm-renderer").value : i.getNamedItem("bm-renderer") ? i.getNamedItem("bm-renderer").value : getRegisteredRenderer() || "canvas";
        var s = i.getNamedItem("data-anim-loop") ? i.getNamedItem("data-anim-loop").value : i.getNamedItem("data-bm-loop") ? i.getNamedItem("data-bm-loop").value : i.getNamedItem("bm-loop") ? i.getNamedItem("bm-loop").value : "";
        s === "false" ? r.loop = false : s === "true" ? r.loop = true : s !== "" && (r.loop = parseInt(s, 10));
        var a = i.getNamedItem("data-anim-autoplay") ? i.getNamedItem("data-anim-autoplay").value : i.getNamedItem("data-bm-autoplay") ? i.getNamedItem("data-bm-autoplay").value : i.getNamedItem("bm-autoplay") ? i.getNamedItem("bm-autoplay").value : true;
        r.autoplay = a !== "false", r.name = i.getNamedItem("data-name") ? i.getNamedItem("data-name").value : i.getNamedItem("data-bm-name") ? i.getNamedItem("data-bm-name").value : i.getNamedItem("bm-name") ? i.getNamedItem("bm-name").value : "";
        var n = i.getNamedItem("data-anim-prerender") ? i.getNamedItem("data-anim-prerender").value : i.getNamedItem("data-bm-prerender") ? i.getNamedItem("data-bm-prerender").value : i.getNamedItem("bm-prerender") ? i.getNamedItem("bm-prerender").value : "";
        n === "false" && (r.prerender = false), r.path ? this.setParams(r) : this.trigger("destroy");
      }, AnimationItem.prototype.includeLayers = function(t) {
        t.op > this.animationData.op && (this.animationData.op = t.op, this.totalFrames = Math.floor(t.op - this.animationData.ip));
        var e = this.animationData.layers, r, i = e.length, s = t.layers, a, n = s.length;
        for (a = 0; a < n; a += 1) for (r = 0; r < i; ) {
          if (e[r].id === s[a].id) {
            e[r] = s[a];
            break;
          }
          r += 1;
        }
        if ((t.chars || t.fonts) && (this.renderer.globalData.fontManager.addChars(t.chars), this.renderer.globalData.fontManager.addFonts(t.fonts, this.renderer.globalData.defs)), t.assets) for (i = t.assets.length, r = 0; r < i; r += 1) this.animationData.assets.push(t.assets[r]);
        this.animationData.__complete = false, dataManager.completeAnimation(this.animationData, this.onSegmentComplete);
      }, AnimationItem.prototype.onSegmentComplete = function(t) {
        this.animationData = t;
        var e = getExpressionsPlugin();
        e && e.initExpressions(this), this.loadNextSegment();
      }, AnimationItem.prototype.loadNextSegment = function() {
        var t = this.animationData.segments;
        if (!t || t.length === 0 || !this.autoloadSegments) {
          this.trigger("data_ready"), this.timeCompleted = this.totalFrames;
          return;
        }
        var e = t.shift();
        this.timeCompleted = e.time * this.frameRate;
        var r = this.path + this.fileName + "_" + this.segmentPos + ".json";
        this.segmentPos += 1, dataManager.loadData(r, this.includeLayers.bind(this), function() {
          this.trigger("data_failed");
        }.bind(this));
      }, AnimationItem.prototype.loadSegments = function() {
        var t = this.animationData.segments;
        t || (this.timeCompleted = this.totalFrames), this.loadNextSegment();
      }, AnimationItem.prototype.imagesLoaded = function() {
        this.trigger("loaded_images"), this.checkLoaded();
      }, AnimationItem.prototype.preloadImages = function() {
        this.imagePreloader.setAssetsPath(this.assetsPath), this.imagePreloader.setPath(this.path), this.imagePreloader.loadAssets(this.animationData.assets, this.imagesLoaded.bind(this));
      }, AnimationItem.prototype.configAnimation = function(t) {
        if (this.renderer) try {
          this.animationData = t, this.initialSegment ? (this.totalFrames = Math.floor(this.initialSegment[1] - this.initialSegment[0]), this.firstFrame = Math.round(this.initialSegment[0])) : (this.totalFrames = Math.floor(this.animationData.op - this.animationData.ip), this.firstFrame = Math.round(this.animationData.ip)), this.renderer.configAnimation(t), t.assets || (t.assets = []), this.assets = this.animationData.assets, this.frameRate = this.animationData.fr, this.frameMult = this.animationData.fr / 1e3, this.renderer.searchExtraCompositions(t.assets), this.markers = markerParser(t.markers || []), this.trigger("config_ready"), this.preloadImages(), this.loadSegments(), this.updaFrameModifier(), this.waitForFontsLoaded(), this.isPaused && this.audioController.pause();
        } catch (e) {
          this.triggerConfigError(e);
        }
      }, AnimationItem.prototype.waitForFontsLoaded = function() {
        this.renderer && (this.renderer.globalData.fontManager.isLoaded ? this.checkLoaded() : setTimeout(this.waitForFontsLoaded.bind(this), 20));
      }, AnimationItem.prototype.checkLoaded = function() {
        if (!this.isLoaded && this.renderer.globalData.fontManager.isLoaded && (this.imagePreloader.loadedImages() || this.renderer.rendererType !== "canvas") && this.imagePreloader.loadedFootages()) {
          this.isLoaded = true;
          var t = getExpressionsPlugin();
          t && t.initExpressions(this), this.renderer.initItems(), setTimeout(function() {
            this.trigger("DOMLoaded");
          }.bind(this), 0), this.gotoFrame(), this.autoplay && this.play();
        }
      }, AnimationItem.prototype.resize = function(t, e) {
        var r = typeof t == "number" ? t : void 0, i = typeof e == "number" ? e : void 0;
        this.renderer.updateContainerSize(r, i);
      }, AnimationItem.prototype.setSubframe = function(t) {
        this.isSubframeEnabled = !!t;
      }, AnimationItem.prototype.gotoFrame = function() {
        this.currentFrame = this.isSubframeEnabled ? this.currentRawFrame : ~~this.currentRawFrame, this.timeCompleted !== this.totalFrames && this.currentFrame > this.timeCompleted && (this.currentFrame = this.timeCompleted), this.trigger("enterFrame"), this.renderFrame(), this.trigger("drawnFrame");
      }, AnimationItem.prototype.renderFrame = function() {
        if (!(this.isLoaded === false || !this.renderer)) try {
          this.expressionsPlugin && this.expressionsPlugin.resetFrame(), this.renderer.renderFrame(this.currentFrame + this.firstFrame);
        } catch (t) {
          this.triggerRenderFrameError(t);
        }
      }, AnimationItem.prototype.play = function(t) {
        t && this.name !== t || this.isPaused === true && (this.isPaused = false, this.trigger("_play"), this.audioController.resume(), this._idle && (this._idle = false, this.trigger("_active")));
      }, AnimationItem.prototype.pause = function(t) {
        t && this.name !== t || this.isPaused === false && (this.isPaused = true, this.trigger("_pause"), this._idle = true, this.trigger("_idle"), this.audioController.pause());
      }, AnimationItem.prototype.togglePause = function(t) {
        t && this.name !== t || (this.isPaused === true ? this.play() : this.pause());
      }, AnimationItem.prototype.stop = function(t) {
        t && this.name !== t || (this.pause(), this.playCount = 0, this._completedLoop = false, this.setCurrentRawFrameValue(0));
      }, AnimationItem.prototype.getMarkerData = function(t) {
        for (var e, r = 0; r < this.markers.length; r += 1) if (e = this.markers[r], e.payload && e.payload.name === t) return e;
        return null;
      }, AnimationItem.prototype.goToAndStop = function(t, e, r) {
        if (!(r && this.name !== r)) {
          var i = Number(t);
          if (isNaN(i)) {
            var s = this.getMarkerData(t);
            s && this.goToAndStop(s.time, true);
          } else e ? this.setCurrentRawFrameValue(t) : this.setCurrentRawFrameValue(t * this.frameModifier);
          this.pause();
        }
      }, AnimationItem.prototype.goToAndPlay = function(t, e, r) {
        if (!(r && this.name !== r)) {
          var i = Number(t);
          if (isNaN(i)) {
            var s = this.getMarkerData(t);
            s && (s.duration ? this.playSegments([
              s.time,
              s.time + s.duration
            ], true) : this.goToAndStop(s.time, true));
          } else this.goToAndStop(i, e, r);
          this.play();
        }
      }, AnimationItem.prototype.advanceTime = function(t) {
        if (!(this.isPaused === true || this.isLoaded === false)) {
          var e = this.currentRawFrame + t * this.frameModifier, r = false;
          e >= this.totalFrames - 1 && this.frameModifier > 0 ? !this.loop || this.playCount === this.loop ? this.checkSegments(e > this.totalFrames ? e % this.totalFrames : 0) || (r = true, e = this.totalFrames - 1) : e >= this.totalFrames ? (this.playCount += 1, this.checkSegments(e % this.totalFrames) || (this.setCurrentRawFrameValue(e % this.totalFrames), this._completedLoop = true, this.trigger("loopComplete"))) : this.setCurrentRawFrameValue(e) : e < 0 ? this.checkSegments(e % this.totalFrames) || (this.loop && !(this.playCount-- <= 0 && this.loop !== true) ? (this.setCurrentRawFrameValue(this.totalFrames + e % this.totalFrames), this._completedLoop ? this.trigger("loopComplete") : this._completedLoop = true) : (r = true, e = 0)) : this.setCurrentRawFrameValue(e), r && (this.setCurrentRawFrameValue(e), this.pause(), this.trigger("complete"));
        }
      }, AnimationItem.prototype.adjustSegment = function(t, e) {
        this.playCount = 0, t[1] < t[0] ? (this.frameModifier > 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(-1)), this.totalFrames = t[0] - t[1], this.timeCompleted = this.totalFrames, this.firstFrame = t[1], this.setCurrentRawFrameValue(this.totalFrames - 1e-3 - e)) : t[1] > t[0] && (this.frameModifier < 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(1)), this.totalFrames = t[1] - t[0], this.timeCompleted = this.totalFrames, this.firstFrame = t[0], this.setCurrentRawFrameValue(1e-3 + e)), this.trigger("segmentStart");
      }, AnimationItem.prototype.setSegment = function(t, e) {
        var r = -1;
        this.isPaused && (this.currentRawFrame + this.firstFrame < t ? r = t : this.currentRawFrame + this.firstFrame > e && (r = e - t)), this.firstFrame = t, this.totalFrames = e - t, this.timeCompleted = this.totalFrames, r !== -1 && this.goToAndStop(r, true);
      }, AnimationItem.prototype.playSegments = function(t, e) {
        if (e && (this.segments.length = 0), _typeof$4(t[0]) === "object") {
          var r, i = t.length;
          for (r = 0; r < i; r += 1) this.segments.push(t[r]);
        } else this.segments.push(t);
        this.segments.length && e && this.adjustSegment(this.segments.shift(), 0), this.isPaused && this.play();
      }, AnimationItem.prototype.resetSegments = function(t) {
        this.segments.length = 0, this.segments.push([
          this.animationData.ip,
          this.animationData.op
        ]), t && this.checkSegments(0);
      }, AnimationItem.prototype.checkSegments = function(t) {
        return this.segments.length ? (this.adjustSegment(this.segments.shift(), t), true) : false;
      }, AnimationItem.prototype.destroy = function(t) {
        t && this.name !== t || !this.renderer || (this.renderer.destroy(), this.imagePreloader.destroy(), this.trigger("destroy"), this._cbs = null, this.onEnterFrame = null, this.onLoopComplete = null, this.onComplete = null, this.onSegmentStart = null, this.onDestroy = null, this.renderer = null, this.expressionsPlugin = null, this.imagePreloader = null, this.projectInterface = null);
      }, AnimationItem.prototype.setCurrentRawFrameValue = function(t) {
        this.currentRawFrame = t, this.gotoFrame();
      }, AnimationItem.prototype.setSpeed = function(t) {
        this.playSpeed = t, this.updaFrameModifier();
      }, AnimationItem.prototype.setDirection = function(t) {
        this.playDirection = t < 0 ? -1 : 1, this.updaFrameModifier();
      }, AnimationItem.prototype.setLoop = function(t) {
        this.loop = t;
      }, AnimationItem.prototype.setVolume = function(t, e) {
        e && this.name !== e || this.audioController.setVolume(t);
      }, AnimationItem.prototype.getVolume = function() {
        return this.audioController.getVolume();
      }, AnimationItem.prototype.mute = function(t) {
        t && this.name !== t || this.audioController.mute();
      }, AnimationItem.prototype.unmute = function(t) {
        t && this.name !== t || this.audioController.unmute();
      }, AnimationItem.prototype.updaFrameModifier = function() {
        this.frameModifier = this.frameMult * this.playSpeed * this.playDirection, this.audioController.setRate(this.playSpeed * this.playDirection);
      }, AnimationItem.prototype.getPath = function() {
        return this.path;
      }, AnimationItem.prototype.getAssetsPath = function(t) {
        var e = "";
        if (t.e) e = t.p;
        else if (this.assetsPath) {
          var r = t.p;
          r.indexOf("images/") !== -1 && (r = r.split("/")[1]), e = this.assetsPath + r;
        } else e = this.path, e += t.u ? t.u : "", e += t.p;
        return e;
      }, AnimationItem.prototype.getAssetData = function(t) {
        for (var e = 0, r = this.assets.length; e < r; ) {
          if (t === this.assets[e].id) return this.assets[e];
          e += 1;
        }
        return null;
      }, AnimationItem.prototype.hide = function() {
        this.renderer.hide();
      }, AnimationItem.prototype.show = function() {
        this.renderer.show();
      }, AnimationItem.prototype.getDuration = function(t) {
        return t ? this.totalFrames : this.totalFrames / this.frameRate;
      }, AnimationItem.prototype.updateDocumentData = function(t, e, r) {
        try {
          var i = this.renderer.getElementByPath(t);
          i.updateDocumentData(e, r);
        } catch {
        }
      }, AnimationItem.prototype.trigger = function(t) {
        if (this._cbs && this._cbs[t]) switch (t) {
          case "enterFrame":
            this.triggerEvent(t, new BMEnterFrameEvent(t, this.currentFrame, this.totalFrames, this.frameModifier));
            break;
          case "drawnFrame":
            this.drawnFrameEvent.currentTime = this.currentFrame, this.drawnFrameEvent.totalTime = this.totalFrames, this.drawnFrameEvent.direction = this.frameModifier, this.triggerEvent(t, this.drawnFrameEvent);
            break;
          case "loopComplete":
            this.triggerEvent(t, new BMCompleteLoopEvent(t, this.loop, this.playCount, this.frameMult));
            break;
          case "complete":
            this.triggerEvent(t, new BMCompleteEvent(t, this.frameMult));
            break;
          case "segmentStart":
            this.triggerEvent(t, new BMSegmentStartEvent(t, this.firstFrame, this.totalFrames));
            break;
          case "destroy":
            this.triggerEvent(t, new BMDestroyEvent(t, this));
            break;
          default:
            this.triggerEvent(t);
        }
        t === "enterFrame" && this.onEnterFrame && this.onEnterFrame.call(this, new BMEnterFrameEvent(t, this.currentFrame, this.totalFrames, this.frameMult)), t === "loopComplete" && this.onLoopComplete && this.onLoopComplete.call(this, new BMCompleteLoopEvent(t, this.loop, this.playCount, this.frameMult)), t === "complete" && this.onComplete && this.onComplete.call(this, new BMCompleteEvent(t, this.frameMult)), t === "segmentStart" && this.onSegmentStart && this.onSegmentStart.call(this, new BMSegmentStartEvent(t, this.firstFrame, this.totalFrames)), t === "destroy" && this.onDestroy && this.onDestroy.call(this, new BMDestroyEvent(t, this));
      }, AnimationItem.prototype.triggerRenderFrameError = function(t) {
        var e = new BMRenderFrameErrorEvent(t, this.currentFrame);
        this.triggerEvent("error", e), this.onError && this.onError.call(this, e);
      }, AnimationItem.prototype.triggerConfigError = function(t) {
        var e = new BMConfigErrorEvent(t, this.currentFrame);
        this.triggerEvent("error", e), this.onError && this.onError.call(this, e);
      };
      var animationManager = (function() {
        var t = {}, e = [], r = 0, i = 0, s = 0, a = true, n = false;
        function l(k) {
          for (var M = 0, S = k.target; M < i; ) e[M].animation === S && (e.splice(M, 1), M -= 1, i -= 1, S.isPaused || E()), M += 1;
        }
        function o(k, M) {
          if (!k) return null;
          for (var S = 0; S < i; ) {
            if (e[S].elem === k && e[S].elem !== null) return e[S].animation;
            S += 1;
          }
          var P = new AnimationItem();
          return u(P, k), P.setData(k, M), P;
        }
        function p() {
          var k, M = e.length, S = [];
          for (k = 0; k < M; k += 1) S.push(e[k].animation);
          return S;
        }
        function y() {
          s += 1, j();
        }
        function E() {
          s -= 1;
        }
        function u(k, M) {
          k.addEventListener("destroy", l), k.addEventListener("_active", y), k.addEventListener("_idle", E), e.push({
            elem: M,
            animation: k
          }), i += 1;
        }
        function x(k) {
          var M = new AnimationItem();
          return u(M, null), M.setParams(k), M;
        }
        function g(k, M) {
          var S;
          for (S = 0; S < i; S += 1) e[S].animation.setSpeed(k, M);
        }
        function d(k, M) {
          var S;
          for (S = 0; S < i; S += 1) e[S].animation.setDirection(k, M);
        }
        function A(k) {
          var M;
          for (M = 0; M < i; M += 1) e[M].animation.play(k);
        }
        function c(k) {
          var M = k - r, S;
          for (S = 0; S < i; S += 1) e[S].animation.advanceTime(M);
          r = k, s && !n ? window.requestAnimationFrame(c) : a = true;
        }
        function m(k) {
          r = k, window.requestAnimationFrame(c);
        }
        function f(k) {
          var M;
          for (M = 0; M < i; M += 1) e[M].animation.pause(k);
        }
        function b(k, M, S) {
          var P;
          for (P = 0; P < i; P += 1) e[P].animation.goToAndStop(k, M, S);
        }
        function C(k) {
          var M;
          for (M = 0; M < i; M += 1) e[M].animation.stop(k);
        }
        function _(k) {
          var M;
          for (M = 0; M < i; M += 1) e[M].animation.togglePause(k);
        }
        function T(k) {
          var M;
          for (M = i - 1; M >= 0; M -= 1) e[M].animation.destroy(k);
        }
        function I(k, M, S) {
          var P = [].concat([].slice.call(document.getElementsByClassName("lottie")), [].slice.call(document.getElementsByClassName("bodymovin"))), V, F = P.length;
          for (V = 0; V < F; V += 1) S && P[V].setAttribute("data-bm-type", S), o(P[V], k);
          if (M && F === 0) {
            S || (S = "svg");
            var B = document.getElementsByTagName("body")[0];
            B.innerText = "";
            var G = createTag("div");
            G.style.width = "100%", G.style.height = "100%", G.setAttribute("data-bm-type", S), B.appendChild(G), o(G, k);
          }
        }
        function L() {
          var k;
          for (k = 0; k < i; k += 1) e[k].animation.resize();
        }
        function j() {
          !n && s && a && (window.requestAnimationFrame(m), a = false);
        }
        function O() {
          n = true;
        }
        function D() {
          n = false, j();
        }
        function N(k, M) {
          var S;
          for (S = 0; S < i; S += 1) e[S].animation.setVolume(k, M);
        }
        function H(k) {
          var M;
          for (M = 0; M < i; M += 1) e[M].animation.mute(k);
        }
        function R(k) {
          var M;
          for (M = 0; M < i; M += 1) e[M].animation.unmute(k);
        }
        return t.registerAnimation = o, t.loadAnimation = x, t.setSpeed = g, t.setDirection = d, t.play = A, t.pause = f, t.stop = C, t.togglePause = _, t.searchAnimations = I, t.resize = L, t.goToAndStop = b, t.destroy = T, t.freeze = O, t.unfreeze = D, t.setVolume = N, t.mute = H, t.unmute = R, t.getRegisteredAnimations = p, t;
      })(), BezierFactory = (function() {
        var t = {};
        t.getBezierEasing = r;
        var e = {};
        function r(m, f, b, C, _) {
          var T = _ || ("bez_" + m + "_" + f + "_" + b + "_" + C).replace(/\./g, "p");
          if (e[T]) return e[T];
          var I = new c([
            m,
            f,
            b,
            C
          ]);
          return e[T] = I, I;
        }
        var i = 4, s = 1e-3, a = 1e-7, n = 10, l = 11, o = 1 / (l - 1), p = typeof Float32Array == "function";
        function y(m, f) {
          return 1 - 3 * f + 3 * m;
        }
        function E(m, f) {
          return 3 * f - 6 * m;
        }
        function u(m) {
          return 3 * m;
        }
        function x(m, f, b) {
          return ((y(f, b) * m + E(f, b)) * m + u(f)) * m;
        }
        function g(m, f, b) {
          return 3 * y(f, b) * m * m + 2 * E(f, b) * m + u(f);
        }
        function d(m, f, b, C, _) {
          var T, I, L = 0;
          do
            I = f + (b - f) / 2, T = x(I, C, _) - m, T > 0 ? b = I : f = I;
          while (Math.abs(T) > a && ++L < n);
          return I;
        }
        function A(m, f, b, C) {
          for (var _ = 0; _ < i; ++_) {
            var T = g(f, b, C);
            if (T === 0) return f;
            var I = x(f, b, C) - m;
            f -= I / T;
          }
          return f;
        }
        function c(m) {
          this._p = m, this._mSampleValues = p ? new Float32Array(l) : new Array(l), this._precomputed = false, this.get = this.get.bind(this);
        }
        return c.prototype = {
          get: function(f) {
            var b = this._p[0], C = this._p[1], _ = this._p[2], T = this._p[3];
            return this._precomputed || this._precompute(), b === C && _ === T ? f : f === 0 ? 0 : f === 1 ? 1 : x(this._getTForX(f), C, T);
          },
          _precompute: function() {
            var f = this._p[0], b = this._p[1], C = this._p[2], _ = this._p[3];
            this._precomputed = true, (f !== b || C !== _) && this._calcSampleValues();
          },
          _calcSampleValues: function() {
            for (var f = this._p[0], b = this._p[2], C = 0; C < l; ++C) this._mSampleValues[C] = x(C * o, f, b);
          },
          _getTForX: function(f) {
            for (var b = this._p[0], C = this._p[2], _ = this._mSampleValues, T = 0, I = 1, L = l - 1; I !== L && _[I] <= f; ++I) T += o;
            --I;
            var j = (f - _[I]) / (_[I + 1] - _[I]), O = T + j * o, D = g(O, b, C);
            return D >= s ? A(f, O, b, C) : D === 0 ? O : d(f, T, T + o, b, C);
          }
        }, t;
      })(), pooling = /* @__PURE__ */ (function() {
        function t(e) {
          return e.concat(createSizedArray(e.length));
        }
        return {
          double: t
        };
      })(), poolFactory = /* @__PURE__ */ (function() {
        return function(t, e, r) {
          var i = 0, s = t, a = createSizedArray(s), n = {
            newElement: l,
            release: o
          };
          function l() {
            var p;
            return i ? (i -= 1, p = a[i]) : p = e(), p;
          }
          function o(p) {
            i === s && (a = pooling.double(a), s *= 2), r && r(p), a[i] = p, i += 1;
          }
          return n;
        };
      })(), bezierLengthPool = (function() {
        function t() {
          return {
            addedLength: 0,
            percents: createTypedArray("float32", getDefaultCurveSegments()),
            lengths: createTypedArray("float32", getDefaultCurveSegments())
          };
        }
        return poolFactory(8, t);
      })(), segmentsLengthPool = (function() {
        function t() {
          return {
            lengths: [],
            totalLength: 0
          };
        }
        function e(r) {
          var i, s = r.lengths.length;
          for (i = 0; i < s; i += 1) bezierLengthPool.release(r.lengths[i]);
          r.lengths.length = 0;
        }
        return poolFactory(8, t, e);
      })();
      function bezFunction() {
        var t = Math;
        function e(u, x, g, d, A, c) {
          var m = u * d + x * A + g * c - A * d - c * u - g * x;
          return m > -1e-3 && m < 1e-3;
        }
        function r(u, x, g, d, A, c, m, f, b) {
          if (g === 0 && c === 0 && b === 0) return e(u, x, d, A, m, f);
          var C = t.sqrt(t.pow(d - u, 2) + t.pow(A - x, 2) + t.pow(c - g, 2)), _ = t.sqrt(t.pow(m - u, 2) + t.pow(f - x, 2) + t.pow(b - g, 2)), T = t.sqrt(t.pow(m - d, 2) + t.pow(f - A, 2) + t.pow(b - c, 2)), I;
          return C > _ ? C > T ? I = C - _ - T : I = T - _ - C : T > _ ? I = T - _ - C : I = _ - C - T, I > -1e-4 && I < 1e-4;
        }
        var i = /* @__PURE__ */ (function() {
          return function(u, x, g, d) {
            var A = getDefaultCurveSegments(), c, m, f, b, C, _ = 0, T, I = [], L = [], j = bezierLengthPool.newElement();
            for (f = g.length, c = 0; c < A; c += 1) {
              for (C = c / (A - 1), T = 0, m = 0; m < f; m += 1) b = bmPow(1 - C, 3) * u[m] + 3 * bmPow(1 - C, 2) * C * g[m] + 3 * (1 - C) * bmPow(C, 2) * d[m] + bmPow(C, 3) * x[m], I[m] = b, L[m] !== null && (T += bmPow(I[m] - L[m], 2)), L[m] = I[m];
              T && (T = bmSqrt(T), _ += T), j.percents[c] = C, j.lengths[c] = _;
            }
            return j.addedLength = _, j;
          };
        })();
        function s(u) {
          var x = segmentsLengthPool.newElement(), g = u.c, d = u.v, A = u.o, c = u.i, m, f = u._length, b = x.lengths, C = 0;
          for (m = 0; m < f - 1; m += 1) b[m] = i(d[m], d[m + 1], A[m], c[m + 1]), C += b[m].addedLength;
          return g && f && (b[m] = i(d[m], d[0], A[m], c[0]), C += b[m].addedLength), x.totalLength = C, x;
        }
        function a(u) {
          this.segmentLength = 0, this.points = new Array(u);
        }
        function n(u, x) {
          this.partialLength = u, this.point = x;
        }
        var l = /* @__PURE__ */ (function() {
          var u = {};
          return function(x, g, d, A) {
            var c = (x[0] + "_" + x[1] + "_" + g[0] + "_" + g[1] + "_" + d[0] + "_" + d[1] + "_" + A[0] + "_" + A[1]).replace(/\./g, "p");
            if (!u[c]) {
              var m = getDefaultCurveSegments(), f, b, C, _, T, I = 0, L, j, O = null;
              x.length === 2 && (x[0] !== g[0] || x[1] !== g[1]) && e(x[0], x[1], g[0], g[1], x[0] + d[0], x[1] + d[1]) && e(x[0], x[1], g[0], g[1], g[0] + A[0], g[1] + A[1]) && (m = 2);
              var D = new a(m);
              for (C = d.length, f = 0; f < m; f += 1) {
                for (j = createSizedArray(C), T = f / (m - 1), L = 0, b = 0; b < C; b += 1) _ = bmPow(1 - T, 3) * x[b] + 3 * bmPow(1 - T, 2) * T * (x[b] + d[b]) + 3 * (1 - T) * bmPow(T, 2) * (g[b] + A[b]) + bmPow(T, 3) * g[b], j[b] = _, O !== null && (L += bmPow(j[b] - O[b], 2));
                L = bmSqrt(L), I += L, D.points[f] = new n(L, j), O = j;
              }
              D.segmentLength = I, u[c] = D;
            }
            return u[c];
          };
        })();
        function o(u, x) {
          var g = x.percents, d = x.lengths, A = g.length, c = bmFloor((A - 1) * u), m = u * x.addedLength, f = 0;
          if (c === A - 1 || c === 0 || m === d[c]) return g[c];
          for (var b = d[c] > m ? -1 : 1, C = true; C; ) if (d[c] <= m && d[c + 1] > m ? (f = (m - d[c]) / (d[c + 1] - d[c]), C = false) : c += b, c < 0 || c >= A - 1) {
            if (c === A - 1) return g[c];
            C = false;
          }
          return g[c] + (g[c + 1] - g[c]) * f;
        }
        function p(u, x, g, d, A, c) {
          var m = o(A, c), f = 1 - m, b = t.round((f * f * f * u[0] + (m * f * f + f * m * f + f * f * m) * g[0] + (m * m * f + f * m * m + m * f * m) * d[0] + m * m * m * x[0]) * 1e3) / 1e3, C = t.round((f * f * f * u[1] + (m * f * f + f * m * f + f * f * m) * g[1] + (m * m * f + f * m * m + m * f * m) * d[1] + m * m * m * x[1]) * 1e3) / 1e3;
          return [
            b,
            C
          ];
        }
        var y = createTypedArray("float32", 8);
        function E(u, x, g, d, A, c, m) {
          A < 0 ? A = 0 : A > 1 && (A = 1);
          var f = o(A, m);
          c = c > 1 ? 1 : c;
          var b = o(c, m), C, _ = u.length, T = 1 - f, I = 1 - b, L = T * T * T, j = f * T * T * 3, O = f * f * T * 3, D = f * f * f, N = T * T * I, H = f * T * I + T * f * I + T * T * b, R = f * f * I + T * f * b + f * T * b, k = f * f * b, M = T * I * I, S = f * I * I + T * b * I + T * I * b, P = f * b * I + T * b * b + f * I * b, V = f * b * b, F = I * I * I, B = b * I * I + I * b * I + I * I * b, G = b * b * I + I * b * b + b * I * b, z = b * b * b;
          for (C = 0; C < _; C += 1) y[C * 4] = t.round((L * u[C] + j * g[C] + O * d[C] + D * x[C]) * 1e3) / 1e3, y[C * 4 + 1] = t.round((N * u[C] + H * g[C] + R * d[C] + k * x[C]) * 1e3) / 1e3, y[C * 4 + 2] = t.round((M * u[C] + S * g[C] + P * d[C] + V * x[C]) * 1e3) / 1e3, y[C * 4 + 3] = t.round((F * u[C] + B * g[C] + G * d[C] + z * x[C]) * 1e3) / 1e3;
          return y;
        }
        return {
          getSegmentsLength: s,
          getNewSegment: E,
          getPointInSegment: p,
          buildBezierData: l,
          pointOnLine2D: e,
          pointOnLine3D: r
        };
      }
      var bez = bezFunction(), initFrame = initialDefaultFrame, mathAbs = Math.abs;
      function interpolateValue(t, e) {
        var r = this.offsetTime, i;
        this.propType === "multidimensional" && (i = createTypedArray("float32", this.pv.length));
        for (var s = e.lastIndex, a = s, n = this.keyframes.length - 1, l = true, o, p, y; l; ) {
          if (o = this.keyframes[a], p = this.keyframes[a + 1], a === n - 1 && t >= p.t - r) {
            o.h && (o = p), s = 0;
            break;
          }
          if (p.t - r > t) {
            s = a;
            break;
          }
          a < n - 1 ? a += 1 : (s = 0, l = false);
        }
        y = this.keyframesMetadata[a] || {};
        var E, u, x, g, d, A, c = p.t - r, m = o.t - r, f;
        if (o.to) {
          y.bezierData || (y.bezierData = bez.buildBezierData(o.s, p.s || o.e, o.to, o.ti));
          var b = y.bezierData;
          if (t >= c || t < m) {
            var C = t >= c ? b.points.length - 1 : 0;
            for (u = b.points[C].point.length, E = 0; E < u; E += 1) i[E] = b.points[C].point[E];
          } else {
            y.__fnct ? A = y.__fnct : (A = BezierFactory.getBezierEasing(o.o.x, o.o.y, o.i.x, o.i.y, o.n).get, y.__fnct = A), x = A((t - m) / (c - m));
            var _ = b.segmentLength * x, T, I = e.lastFrame < t && e._lastKeyframeIndex === a ? e._lastAddedLength : 0;
            for (d = e.lastFrame < t && e._lastKeyframeIndex === a ? e._lastPoint : 0, l = true, g = b.points.length; l; ) {
              if (I += b.points[d].partialLength, _ === 0 || x === 0 || d === b.points.length - 1) {
                for (u = b.points[d].point.length, E = 0; E < u; E += 1) i[E] = b.points[d].point[E];
                break;
              } else if (_ >= I && _ < I + b.points[d + 1].partialLength) {
                for (T = (_ - I) / b.points[d + 1].partialLength, u = b.points[d].point.length, E = 0; E < u; E += 1) i[E] = b.points[d].point[E] + (b.points[d + 1].point[E] - b.points[d].point[E]) * T;
                break;
              }
              d < g - 1 ? d += 1 : l = false;
            }
            e._lastPoint = d, e._lastAddedLength = I - b.points[d].partialLength, e._lastKeyframeIndex = a;
          }
        } else {
          var L, j, O, D, N;
          if (n = o.s.length, f = p.s || o.e, this.sh && o.h !== 1) if (t >= c) i[0] = f[0], i[1] = f[1], i[2] = f[2];
          else if (t <= m) i[0] = o.s[0], i[1] = o.s[1], i[2] = o.s[2];
          else {
            var H = createQuaternion(o.s), R = createQuaternion(f), k = (t - m) / (c - m);
            quaternionToEuler(i, slerp(H, R, k));
          }
          else for (a = 0; a < n; a += 1) o.h !== 1 && (t >= c ? x = 1 : t < m ? x = 0 : (o.o.x.constructor === Array ? (y.__fnct || (y.__fnct = []), y.__fnct[a] ? A = y.__fnct[a] : (L = o.o.x[a] === void 0 ? o.o.x[0] : o.o.x[a], j = o.o.y[a] === void 0 ? o.o.y[0] : o.o.y[a], O = o.i.x[a] === void 0 ? o.i.x[0] : o.i.x[a], D = o.i.y[a] === void 0 ? o.i.y[0] : o.i.y[a], A = BezierFactory.getBezierEasing(L, j, O, D).get, y.__fnct[a] = A)) : y.__fnct ? A = y.__fnct : (L = o.o.x, j = o.o.y, O = o.i.x, D = o.i.y, A = BezierFactory.getBezierEasing(L, j, O, D).get, o.keyframeMetadata = A), x = A((t - m) / (c - m)))), f = p.s || o.e, N = o.h === 1 ? o.s[a] : o.s[a] + (f[a] - o.s[a]) * x, this.propType === "multidimensional" ? i[a] = N : i = N;
        }
        return e.lastIndex = s, i;
      }
      function slerp(t, e, r) {
        var i = [], s = t[0], a = t[1], n = t[2], l = t[3], o = e[0], p = e[1], y = e[2], E = e[3], u, x, g, d, A;
        return x = s * o + a * p + n * y + l * E, x < 0 && (x = -x, o = -o, p = -p, y = -y, E = -E), 1 - x > 1e-6 ? (u = Math.acos(x), g = Math.sin(u), d = Math.sin((1 - r) * u) / g, A = Math.sin(r * u) / g) : (d = 1 - r, A = r), i[0] = d * s + A * o, i[1] = d * a + A * p, i[2] = d * n + A * y, i[3] = d * l + A * E, i;
      }
      function quaternionToEuler(t, e) {
        var r = e[0], i = e[1], s = e[2], a = e[3], n = Math.atan2(2 * i * a - 2 * r * s, 1 - 2 * i * i - 2 * s * s), l = Math.asin(2 * r * i + 2 * s * a), o = Math.atan2(2 * r * a - 2 * i * s, 1 - 2 * r * r - 2 * s * s);
        t[0] = n / degToRads, t[1] = l / degToRads, t[2] = o / degToRads;
      }
      function createQuaternion(t) {
        var e = t[0] * degToRads, r = t[1] * degToRads, i = t[2] * degToRads, s = Math.cos(e / 2), a = Math.cos(r / 2), n = Math.cos(i / 2), l = Math.sin(e / 2), o = Math.sin(r / 2), p = Math.sin(i / 2), y = s * a * n - l * o * p, E = l * o * n + s * a * p, u = l * a * n + s * o * p, x = s * o * n - l * a * p;
        return [
          E,
          u,
          x,
          y
        ];
      }
      function getValueAtCurrentTime() {
        var t = this.comp.renderedFrame - this.offsetTime, e = this.keyframes[0].t - this.offsetTime, r = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
        if (!(t === this._caching.lastFrame || this._caching.lastFrame !== initFrame && (this._caching.lastFrame >= r && t >= r || this._caching.lastFrame < e && t < e))) {
          this._caching.lastFrame >= t && (this._caching._lastKeyframeIndex = -1, this._caching.lastIndex = 0);
          var i = this.interpolateValue(t, this._caching);
          this.pv = i;
        }
        return this._caching.lastFrame = t, this.pv;
      }
      function setVValue(t) {
        var e;
        if (this.propType === "unidimensional") e = t * this.mult, mathAbs(this.v - e) > 1e-5 && (this.v = e, this._mdf = true);
        else for (var r = 0, i = this.v.length; r < i; ) e = t[r] * this.mult, mathAbs(this.v[r] - e) > 1e-5 && (this.v[r] = e, this._mdf = true), r += 1;
      }
      function processEffectsSequence() {
        if (!(this.elem.globalData.frameId === this.frameId || !this.effectsSequence.length)) {
          if (this.lock) {
            this.setVValue(this.pv);
            return;
          }
          this.lock = true, this._mdf = this._isFirstFrame;
          var t, e = this.effectsSequence.length, r = this.kf ? this.pv : this.data.k;
          for (t = 0; t < e; t += 1) r = this.effectsSequence[t](r);
          this.setVValue(r), this._isFirstFrame = false, this.lock = false, this.frameId = this.elem.globalData.frameId;
        }
      }
      function addEffect(t) {
        this.effectsSequence.push(t), this.container.addDynamicProperty(this);
      }
      function ValueProperty(t, e, r, i) {
        this.propType = "unidimensional", this.mult = r || 1, this.data = e, this.v = r ? e.k * r : e.k, this.pv = e.k, this._mdf = false, this.elem = t, this.container = i, this.comp = t.comp, this.k = false, this.kf = false, this.vel = 0, this.effectsSequence = [], this._isFirstFrame = true, this.getValue = processEffectsSequence, this.setVValue = setVValue, this.addEffect = addEffect;
      }
      function MultiDimensionalProperty(t, e, r, i) {
        this.propType = "multidimensional", this.mult = r || 1, this.data = e, this._mdf = false, this.elem = t, this.container = i, this.comp = t.comp, this.k = false, this.kf = false, this.frameId = -1;
        var s, a = e.k.length;
        for (this.v = createTypedArray("float32", a), this.pv = createTypedArray("float32", a), this.vel = createTypedArray("float32", a), s = 0; s < a; s += 1) this.v[s] = e.k[s] * this.mult, this.pv[s] = e.k[s];
        this._isFirstFrame = true, this.effectsSequence = [], this.getValue = processEffectsSequence, this.setVValue = setVValue, this.addEffect = addEffect;
      }
      function KeyframedValueProperty(t, e, r, i) {
        this.propType = "unidimensional", this.keyframes = e.k, this.keyframesMetadata = [], this.offsetTime = t.data.st, this.frameId = -1, this._caching = {
          lastFrame: initFrame,
          lastIndex: 0,
          value: 0,
          _lastKeyframeIndex: -1
        }, this.k = true, this.kf = true, this.data = e, this.mult = r || 1, this.elem = t, this.container = i, this.comp = t.comp, this.v = initFrame, this.pv = initFrame, this._isFirstFrame = true, this.getValue = processEffectsSequence, this.setVValue = setVValue, this.interpolateValue = interpolateValue, this.effectsSequence = [
          getValueAtCurrentTime.bind(this)
        ], this.addEffect = addEffect;
      }
      function KeyframedMultidimensionalProperty(t, e, r, i) {
        this.propType = "multidimensional";
        var s, a = e.k.length, n, l, o, p;
        for (s = 0; s < a - 1; s += 1) e.k[s].to && e.k[s].s && e.k[s + 1] && e.k[s + 1].s && (n = e.k[s].s, l = e.k[s + 1].s, o = e.k[s].to, p = e.k[s].ti, (n.length === 2 && !(n[0] === l[0] && n[1] === l[1]) && bez.pointOnLine2D(n[0], n[1], l[0], l[1], n[0] + o[0], n[1] + o[1]) && bez.pointOnLine2D(n[0], n[1], l[0], l[1], l[0] + p[0], l[1] + p[1]) || n.length === 3 && !(n[0] === l[0] && n[1] === l[1] && n[2] === l[2]) && bez.pointOnLine3D(n[0], n[1], n[2], l[0], l[1], l[2], n[0] + o[0], n[1] + o[1], n[2] + o[2]) && bez.pointOnLine3D(n[0], n[1], n[2], l[0], l[1], l[2], l[0] + p[0], l[1] + p[1], l[2] + p[2])) && (e.k[s].to = null, e.k[s].ti = null), n[0] === l[0] && n[1] === l[1] && o[0] === 0 && o[1] === 0 && p[0] === 0 && p[1] === 0 && (n.length === 2 || n[2] === l[2] && o[2] === 0 && p[2] === 0) && (e.k[s].to = null, e.k[s].ti = null));
        this.effectsSequence = [
          getValueAtCurrentTime.bind(this)
        ], this.data = e, this.keyframes = e.k, this.keyframesMetadata = [], this.offsetTime = t.data.st, this.k = true, this.kf = true, this._isFirstFrame = true, this.mult = r || 1, this.elem = t, this.container = i, this.comp = t.comp, this.getValue = processEffectsSequence, this.setVValue = setVValue, this.interpolateValue = interpolateValue, this.frameId = -1;
        var y = e.k[0].s.length;
        for (this.v = createTypedArray("float32", y), this.pv = createTypedArray("float32", y), s = 0; s < y; s += 1) this.v[s] = initFrame, this.pv[s] = initFrame;
        this._caching = {
          lastFrame: initFrame,
          lastIndex: 0,
          value: createTypedArray("float32", y)
        }, this.addEffect = addEffect;
      }
      var PropertyFactory = /* @__PURE__ */ (function() {
        function t(r, i, s, a, n) {
          i.sid && (i = r.globalData.slotManager.getProp(i));
          var l;
          if (!i.k.length) l = new ValueProperty(r, i, a, n);
          else if (typeof i.k[0] == "number") l = new MultiDimensionalProperty(r, i, a, n);
          else switch (s) {
            case 0:
              l = new KeyframedValueProperty(r, i, a, n);
              break;
            case 1:
              l = new KeyframedMultidimensionalProperty(r, i, a, n);
              break;
          }
          return l.effectsSequence.length && n.addDynamicProperty(l), l;
        }
        var e = {
          getProp: t
        };
        return e;
      })();
      function DynamicPropertyContainer() {
      }
      DynamicPropertyContainer.prototype = {
        addDynamicProperty: function(e) {
          this.dynamicProperties.indexOf(e) === -1 && (this.dynamicProperties.push(e), this.container.addDynamicProperty(this), this._isAnimated = true);
        },
        iterateDynamicProperties: function() {
          this._mdf = false;
          var e, r = this.dynamicProperties.length;
          for (e = 0; e < r; e += 1) this.dynamicProperties[e].getValue(), this.dynamicProperties[e]._mdf && (this._mdf = true);
        },
        initDynamicPropertyContainer: function(e) {
          this.container = e, this.dynamicProperties = [], this._mdf = false, this._isAnimated = false;
        }
      };
      var pointPool = (function() {
        function t() {
          return createTypedArray("float32", 2);
        }
        return poolFactory(8, t);
      })();
      function ShapePath() {
        this.c = false, this._length = 0, this._maxLength = 8, this.v = createSizedArray(this._maxLength), this.o = createSizedArray(this._maxLength), this.i = createSizedArray(this._maxLength);
      }
      ShapePath.prototype.setPathData = function(t, e) {
        this.c = t, this.setLength(e);
        for (var r = 0; r < e; ) this.v[r] = pointPool.newElement(), this.o[r] = pointPool.newElement(), this.i[r] = pointPool.newElement(), r += 1;
      }, ShapePath.prototype.setLength = function(t) {
        for (; this._maxLength < t; ) this.doubleArrayLength();
        this._length = t;
      }, ShapePath.prototype.doubleArrayLength = function() {
        this.v = this.v.concat(createSizedArray(this._maxLength)), this.i = this.i.concat(createSizedArray(this._maxLength)), this.o = this.o.concat(createSizedArray(this._maxLength)), this._maxLength *= 2;
      }, ShapePath.prototype.setXYAt = function(t, e, r, i, s) {
        var a;
        switch (this._length = Math.max(this._length, i + 1), this._length >= this._maxLength && this.doubleArrayLength(), r) {
          case "v":
            a = this.v;
            break;
          case "i":
            a = this.i;
            break;
          case "o":
            a = this.o;
            break;
          default:
            a = [];
            break;
        }
        (!a[i] || a[i] && !s) && (a[i] = pointPool.newElement()), a[i][0] = t, a[i][1] = e;
      }, ShapePath.prototype.setTripleAt = function(t, e, r, i, s, a, n, l) {
        this.setXYAt(t, e, "v", n, l), this.setXYAt(r, i, "o", n, l), this.setXYAt(s, a, "i", n, l);
      }, ShapePath.prototype.reverse = function() {
        var t = new ShapePath();
        t.setPathData(this.c, this._length);
        var e = this.v, r = this.o, i = this.i, s = 0;
        this.c && (t.setTripleAt(e[0][0], e[0][1], i[0][0], i[0][1], r[0][0], r[0][1], 0, false), s = 1);
        var a = this._length - 1, n = this._length, l;
        for (l = s; l < n; l += 1) t.setTripleAt(e[a][0], e[a][1], i[a][0], i[a][1], r[a][0], r[a][1], l, false), a -= 1;
        return t;
      }, ShapePath.prototype.length = function() {
        return this._length;
      };
      var shapePool = (function() {
        function t() {
          return new ShapePath();
        }
        function e(s) {
          var a = s._length, n;
          for (n = 0; n < a; n += 1) pointPool.release(s.v[n]), pointPool.release(s.i[n]), pointPool.release(s.o[n]), s.v[n] = null, s.i[n] = null, s.o[n] = null;
          s._length = 0, s.c = false;
        }
        function r(s) {
          var a = i.newElement(), n, l = s._length === void 0 ? s.v.length : s._length;
          for (a.setLength(l), a.c = s.c, n = 0; n < l; n += 1) a.setTripleAt(s.v[n][0], s.v[n][1], s.o[n][0], s.o[n][1], s.i[n][0], s.i[n][1], n);
          return a;
        }
        var i = poolFactory(4, t, e);
        return i.clone = r, i;
      })();
      function ShapeCollection() {
        this._length = 0, this._maxLength = 4, this.shapes = createSizedArray(this._maxLength);
      }
      ShapeCollection.prototype.addShape = function(t) {
        this._length === this._maxLength && (this.shapes = this.shapes.concat(createSizedArray(this._maxLength)), this._maxLength *= 2), this.shapes[this._length] = t, this._length += 1;
      }, ShapeCollection.prototype.releaseShapes = function() {
        var t;
        for (t = 0; t < this._length; t += 1) shapePool.release(this.shapes[t]);
        this._length = 0;
      };
      var shapeCollectionPool = (function() {
        var t = {
          newShapeCollection: s,
          release: a
        }, e = 0, r = 4, i = createSizedArray(r);
        function s() {
          var n;
          return e ? (e -= 1, n = i[e]) : n = new ShapeCollection(), n;
        }
        function a(n) {
          var l, o = n._length;
          for (l = 0; l < o; l += 1) shapePool.release(n.shapes[l]);
          n._length = 0, e === r && (i = pooling.double(i), r *= 2), i[e] = n, e += 1;
        }
        return t;
      })(), ShapePropertyFactory = (function() {
        var t = -999999;
        function e(c, m, f) {
          var b = f.lastIndex, C, _, T, I, L, j, O, D, N, H = this.keyframes;
          if (c < H[0].t - this.offsetTime) C = H[0].s[0], T = true, b = 0;
          else if (c >= H[H.length - 1].t - this.offsetTime) C = H[H.length - 1].s ? H[H.length - 1].s[0] : H[H.length - 2].e[0], T = true;
          else {
            for (var R = b, k = H.length - 1, M = true, S, P, V; M && (S = H[R], P = H[R + 1], !(P.t - this.offsetTime > c)); ) R < k - 1 ? R += 1 : M = false;
            if (V = this.keyframesMetadata[R] || {}, T = S.h === 1, b = R, !T) {
              if (c >= P.t - this.offsetTime) D = 1;
              else if (c < S.t - this.offsetTime) D = 0;
              else {
                var F;
                V.__fnct ? F = V.__fnct : (F = BezierFactory.getBezierEasing(S.o.x, S.o.y, S.i.x, S.i.y).get, V.__fnct = F), D = F((c - (S.t - this.offsetTime)) / (P.t - this.offsetTime - (S.t - this.offsetTime)));
              }
              _ = P.s ? P.s[0] : S.e[0];
            }
            C = S.s[0];
          }
          for (j = m._length, O = C.i[0].length, f.lastIndex = b, I = 0; I < j; I += 1) for (L = 0; L < O; L += 1) N = T ? C.i[I][L] : C.i[I][L] + (_.i[I][L] - C.i[I][L]) * D, m.i[I][L] = N, N = T ? C.o[I][L] : C.o[I][L] + (_.o[I][L] - C.o[I][L]) * D, m.o[I][L] = N, N = T ? C.v[I][L] : C.v[I][L] + (_.v[I][L] - C.v[I][L]) * D, m.v[I][L] = N;
        }
        function r() {
          var c = this.comp.renderedFrame - this.offsetTime, m = this.keyframes[0].t - this.offsetTime, f = this.keyframes[this.keyframes.length - 1].t - this.offsetTime, b = this._caching.lastFrame;
          return b !== t && (b < m && c < m || b > f && c > f) || (this._caching.lastIndex = b < c ? this._caching.lastIndex : 0, this.interpolateShape(c, this.pv, this._caching)), this._caching.lastFrame = c, this.pv;
        }
        function i() {
          this.paths = this.localShapeCollection;
        }
        function s(c, m) {
          if (c._length !== m._length || c.c !== m.c) return false;
          var f, b = c._length;
          for (f = 0; f < b; f += 1) if (c.v[f][0] !== m.v[f][0] || c.v[f][1] !== m.v[f][1] || c.o[f][0] !== m.o[f][0] || c.o[f][1] !== m.o[f][1] || c.i[f][0] !== m.i[f][0] || c.i[f][1] !== m.i[f][1]) return false;
          return true;
        }
        function a(c) {
          s(this.v, c) || (this.v = shapePool.clone(c), this.localShapeCollection.releaseShapes(), this.localShapeCollection.addShape(this.v), this._mdf = true, this.paths = this.localShapeCollection);
        }
        function n() {
          if (this.elem.globalData.frameId !== this.frameId) {
            if (!this.effectsSequence.length) {
              this._mdf = false;
              return;
            }
            if (this.lock) {
              this.setVValue(this.pv);
              return;
            }
            this.lock = true, this._mdf = false;
            var c;
            this.kf ? c = this.pv : this.data.ks ? c = this.data.ks.k : c = this.data.pt.k;
            var m, f = this.effectsSequence.length;
            for (m = 0; m < f; m += 1) c = this.effectsSequence[m](c);
            this.setVValue(c), this.lock = false, this.frameId = this.elem.globalData.frameId;
          }
        }
        function l(c, m, f) {
          this.propType = "shape", this.comp = c.comp, this.container = c, this.elem = c, this.data = m, this.k = false, this.kf = false, this._mdf = false;
          var b = f === 3 ? m.pt.k : m.ks.k;
          this.v = shapePool.clone(b), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.reset = i, this.effectsSequence = [];
        }
        function o(c) {
          this.effectsSequence.push(c), this.container.addDynamicProperty(this);
        }
        l.prototype.interpolateShape = e, l.prototype.getValue = n, l.prototype.setVValue = a, l.prototype.addEffect = o;
        function p(c, m, f) {
          this.propType = "shape", this.comp = c.comp, this.elem = c, this.container = c, this.offsetTime = c.data.st, this.keyframes = f === 3 ? m.pt.k : m.ks.k, this.keyframesMetadata = [], this.k = true, this.kf = true;
          var b = this.keyframes[0].s[0].i.length;
          this.v = shapePool.newElement(), this.v.setPathData(this.keyframes[0].s[0].c, b), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.lastFrame = t, this.reset = i, this._caching = {
            lastFrame: t,
            lastIndex: 0
          }, this.effectsSequence = [
            r.bind(this)
          ];
        }
        p.prototype.getValue = n, p.prototype.interpolateShape = e, p.prototype.setVValue = a, p.prototype.addEffect = o;
        var y = (function() {
          var c = roundCorner;
          function m(f, b) {
            this.v = shapePool.newElement(), this.v.setPathData(true, 4), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.localShapeCollection.addShape(this.v), this.d = b.d, this.elem = f, this.comp = f.comp, this.frameId = -1, this.initDynamicPropertyContainer(f), this.p = PropertyFactory.getProp(f, b.p, 1, 0, this), this.s = PropertyFactory.getProp(f, b.s, 1, 0, this), this.dynamicProperties.length ? this.k = true : (this.k = false, this.convertEllToPath());
          }
          return m.prototype = {
            reset: i,
            getValue: function() {
              this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertEllToPath());
            },
            convertEllToPath: function() {
              var b = this.p.v[0], C = this.p.v[1], _ = this.s.v[0] / 2, T = this.s.v[1] / 2, I = this.d !== 3, L = this.v;
              L.v[0][0] = b, L.v[0][1] = C - T, L.v[1][0] = I ? b + _ : b - _, L.v[1][1] = C, L.v[2][0] = b, L.v[2][1] = C + T, L.v[3][0] = I ? b - _ : b + _, L.v[3][1] = C, L.i[0][0] = I ? b - _ * c : b + _ * c, L.i[0][1] = C - T, L.i[1][0] = I ? b + _ : b - _, L.i[1][1] = C - T * c, L.i[2][0] = I ? b + _ * c : b - _ * c, L.i[2][1] = C + T, L.i[3][0] = I ? b - _ : b + _, L.i[3][1] = C + T * c, L.o[0][0] = I ? b + _ * c : b - _ * c, L.o[0][1] = C - T, L.o[1][0] = I ? b + _ : b - _, L.o[1][1] = C + T * c, L.o[2][0] = I ? b - _ * c : b + _ * c, L.o[2][1] = C + T, L.o[3][0] = I ? b - _ : b + _, L.o[3][1] = C - T * c;
            }
          }, extendPrototype([
            DynamicPropertyContainer
          ], m), m;
        })(), E = (function() {
          function c(m, f) {
            this.v = shapePool.newElement(), this.v.setPathData(true, 0), this.elem = m, this.comp = m.comp, this.data = f, this.frameId = -1, this.d = f.d, this.initDynamicPropertyContainer(m), f.sy === 1 ? (this.ir = PropertyFactory.getProp(m, f.ir, 0, 0, this), this.is = PropertyFactory.getProp(m, f.is, 0, 0.01, this), this.convertToPath = this.convertStarToPath) : this.convertToPath = this.convertPolygonToPath, this.pt = PropertyFactory.getProp(m, f.pt, 0, 0, this), this.p = PropertyFactory.getProp(m, f.p, 1, 0, this), this.r = PropertyFactory.getProp(m, f.r, 0, degToRads, this), this.or = PropertyFactory.getProp(m, f.or, 0, 0, this), this.os = PropertyFactory.getProp(m, f.os, 0, 0.01, this), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.dynamicProperties.length ? this.k = true : (this.k = false, this.convertToPath());
          }
          return c.prototype = {
            reset: i,
            getValue: function() {
              this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertToPath());
            },
            convertStarToPath: function() {
              var f = Math.floor(this.pt.v) * 2, b = Math.PI * 2 / f, C = true, _ = this.or.v, T = this.ir.v, I = this.os.v, L = this.is.v, j = 2 * Math.PI * _ / (f * 2), O = 2 * Math.PI * T / (f * 2), D, N, H, R, k = -Math.PI / 2;
              k += this.r.v;
              var M = this.data.d === 3 ? -1 : 1;
              for (this.v._length = 0, D = 0; D < f; D += 1) {
                N = C ? _ : T, H = C ? I : L, R = C ? j : O;
                var S = N * Math.cos(k), P = N * Math.sin(k), V = S === 0 && P === 0 ? 0 : P / Math.sqrt(S * S + P * P), F = S === 0 && P === 0 ? 0 : -S / Math.sqrt(S * S + P * P);
                S += +this.p.v[0], P += +this.p.v[1], this.v.setTripleAt(S, P, S - V * R * H * M, P - F * R * H * M, S + V * R * H * M, P + F * R * H * M, D, true), C = !C, k += b * M;
              }
            },
            convertPolygonToPath: function() {
              var f = Math.floor(this.pt.v), b = Math.PI * 2 / f, C = this.or.v, _ = this.os.v, T = 2 * Math.PI * C / (f * 4), I, L = -Math.PI * 0.5, j = this.data.d === 3 ? -1 : 1;
              for (L += this.r.v, this.v._length = 0, I = 0; I < f; I += 1) {
                var O = C * Math.cos(L), D = C * Math.sin(L), N = O === 0 && D === 0 ? 0 : D / Math.sqrt(O * O + D * D), H = O === 0 && D === 0 ? 0 : -O / Math.sqrt(O * O + D * D);
                O += +this.p.v[0], D += +this.p.v[1], this.v.setTripleAt(O, D, O - N * T * _ * j, D - H * T * _ * j, O + N * T * _ * j, D + H * T * _ * j, I, true), L += b * j;
              }
              this.paths.length = 0, this.paths[0] = this.v;
            }
          }, extendPrototype([
            DynamicPropertyContainer
          ], c), c;
        })(), u = (function() {
          function c(m, f) {
            this.v = shapePool.newElement(), this.v.c = true, this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.elem = m, this.comp = m.comp, this.frameId = -1, this.d = f.d, this.initDynamicPropertyContainer(m), this.p = PropertyFactory.getProp(m, f.p, 1, 0, this), this.s = PropertyFactory.getProp(m, f.s, 1, 0, this), this.r = PropertyFactory.getProp(m, f.r, 0, 0, this), this.dynamicProperties.length ? this.k = true : (this.k = false, this.convertRectToPath());
          }
          return c.prototype = {
            convertRectToPath: function() {
              var f = this.p.v[0], b = this.p.v[1], C = this.s.v[0] / 2, _ = this.s.v[1] / 2, T = bmMin(C, _, this.r.v), I = T * (1 - roundCorner);
              this.v._length = 0, this.d === 2 || this.d === 1 ? (this.v.setTripleAt(f + C, b - _ + T, f + C, b - _ + T, f + C, b - _ + I, 0, true), this.v.setTripleAt(f + C, b + _ - T, f + C, b + _ - I, f + C, b + _ - T, 1, true), T !== 0 ? (this.v.setTripleAt(f + C - T, b + _, f + C - T, b + _, f + C - I, b + _, 2, true), this.v.setTripleAt(f - C + T, b + _, f - C + I, b + _, f - C + T, b + _, 3, true), this.v.setTripleAt(f - C, b + _ - T, f - C, b + _ - T, f - C, b + _ - I, 4, true), this.v.setTripleAt(f - C, b - _ + T, f - C, b - _ + I, f - C, b - _ + T, 5, true), this.v.setTripleAt(f - C + T, b - _, f - C + T, b - _, f - C + I, b - _, 6, true), this.v.setTripleAt(f + C - T, b - _, f + C - I, b - _, f + C - T, b - _, 7, true)) : (this.v.setTripleAt(f - C, b + _, f - C + I, b + _, f - C, b + _, 2), this.v.setTripleAt(f - C, b - _, f - C, b - _ + I, f - C, b - _, 3))) : (this.v.setTripleAt(f + C, b - _ + T, f + C, b - _ + I, f + C, b - _ + T, 0, true), T !== 0 ? (this.v.setTripleAt(f + C - T, b - _, f + C - T, b - _, f + C - I, b - _, 1, true), this.v.setTripleAt(f - C + T, b - _, f - C + I, b - _, f - C + T, b - _, 2, true), this.v.setTripleAt(f - C, b - _ + T, f - C, b - _ + T, f - C, b - _ + I, 3, true), this.v.setTripleAt(f - C, b + _ - T, f - C, b + _ - I, f - C, b + _ - T, 4, true), this.v.setTripleAt(f - C + T, b + _, f - C + T, b + _, f - C + I, b + _, 5, true), this.v.setTripleAt(f + C - T, b + _, f + C - I, b + _, f + C - T, b + _, 6, true), this.v.setTripleAt(f + C, b + _ - T, f + C, b + _ - T, f + C, b + _ - I, 7, true)) : (this.v.setTripleAt(f - C, b - _, f - C + I, b - _, f - C, b - _, 1, true), this.v.setTripleAt(f - C, b + _, f - C, b + _ - I, f - C, b + _, 2, true), this.v.setTripleAt(f + C, b + _, f + C - I, b + _, f + C, b + _, 3, true)));
            },
            getValue: function() {
              this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertRectToPath());
            },
            reset: i
          }, extendPrototype([
            DynamicPropertyContainer
          ], c), c;
        })();
        function x(c, m, f) {
          var b;
          if (f === 3 || f === 4) {
            var C = f === 3 ? m.pt : m.ks, _ = C.k;
            _.length ? b = new p(c, m, f) : b = new l(c, m, f);
          } else f === 5 ? b = new u(c, m) : f === 6 ? b = new y(c, m) : f === 7 && (b = new E(c, m));
          return b.k && c.addDynamicProperty(b), b;
        }
        function g() {
          return l;
        }
        function d() {
          return p;
        }
        var A = {};
        return A.getShapeProp = x, A.getConstructorFunction = g, A.getKeyframedConstructorFunction = d, A;
      })();
      var Matrix = /* @__PURE__ */ (function() {
        var t = Math.cos, e = Math.sin, r = Math.tan, i = Math.round;
        function s() {
          return this.props[0] = 1, this.props[1] = 0, this.props[2] = 0, this.props[3] = 0, this.props[4] = 0, this.props[5] = 1, this.props[6] = 0, this.props[7] = 0, this.props[8] = 0, this.props[9] = 0, this.props[10] = 1, this.props[11] = 0, this.props[12] = 0, this.props[13] = 0, this.props[14] = 0, this.props[15] = 1, this;
        }
        function a(S) {
          if (S === 0) return this;
          var P = t(S), V = e(S);
          return this._t(P, -V, 0, 0, V, P, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
        }
        function n(S) {
          if (S === 0) return this;
          var P = t(S), V = e(S);
          return this._t(1, 0, 0, 0, 0, P, -V, 0, 0, V, P, 0, 0, 0, 0, 1);
        }
        function l(S) {
          if (S === 0) return this;
          var P = t(S), V = e(S);
          return this._t(P, 0, V, 0, 0, 1, 0, 0, -V, 0, P, 0, 0, 0, 0, 1);
        }
        function o(S) {
          if (S === 0) return this;
          var P = t(S), V = e(S);
          return this._t(P, -V, 0, 0, V, P, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
        }
        function p(S, P) {
          return this._t(1, P, S, 1, 0, 0);
        }
        function y(S, P) {
          return this.shear(r(S), r(P));
        }
        function E(S, P) {
          var V = t(P), F = e(P);
          return this._t(V, F, 0, 0, -F, V, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(1, 0, 0, 0, r(S), 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(V, -F, 0, 0, F, V, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
        }
        function u(S, P, V) {
          return !V && V !== 0 && (V = 1), S === 1 && P === 1 && V === 1 ? this : this._t(S, 0, 0, 0, 0, P, 0, 0, 0, 0, V, 0, 0, 0, 0, 1);
        }
        function x(S, P, V, F, B, G, z, q, $, X, Z, rt, J, K, Q, Y) {
          return this.props[0] = S, this.props[1] = P, this.props[2] = V, this.props[3] = F, this.props[4] = B, this.props[5] = G, this.props[6] = z, this.props[7] = q, this.props[8] = $, this.props[9] = X, this.props[10] = Z, this.props[11] = rt, this.props[12] = J, this.props[13] = K, this.props[14] = Q, this.props[15] = Y, this;
        }
        function g(S, P, V) {
          return V = V || 0, S !== 0 || P !== 0 || V !== 0 ? this._t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, S, P, V, 1) : this;
        }
        function d(S, P, V, F, B, G, z, q, $, X, Z, rt, J, K, Q, Y) {
          var W = this.props;
          if (S === 1 && P === 0 && V === 0 && F === 0 && B === 0 && G === 1 && z === 0 && q === 0 && $ === 0 && X === 0 && Z === 1 && rt === 0) return W[12] = W[12] * S + W[15] * J, W[13] = W[13] * G + W[15] * K, W[14] = W[14] * Z + W[15] * Q, W[15] *= Y, this._identityCalculated = false, this;
          var st = W[0], ht = W[1], at = W[2], it = W[3], nt = W[4], ot = W[5], U = W[6], lt = W[7], ft = W[8], tt = W[9], pt = W[10], et = W[11], ct = W[12], ut = W[13], mt = W[14], dt = W[15];
          return W[0] = st * S + ht * B + at * $ + it * J, W[1] = st * P + ht * G + at * X + it * K, W[2] = st * V + ht * z + at * Z + it * Q, W[3] = st * F + ht * q + at * rt + it * Y, W[4] = nt * S + ot * B + U * $ + lt * J, W[5] = nt * P + ot * G + U * X + lt * K, W[6] = nt * V + ot * z + U * Z + lt * Q, W[7] = nt * F + ot * q + U * rt + lt * Y, W[8] = ft * S + tt * B + pt * $ + et * J, W[9] = ft * P + tt * G + pt * X + et * K, W[10] = ft * V + tt * z + pt * Z + et * Q, W[11] = ft * F + tt * q + pt * rt + et * Y, W[12] = ct * S + ut * B + mt * $ + dt * J, W[13] = ct * P + ut * G + mt * X + dt * K, W[14] = ct * V + ut * z + mt * Z + dt * Q, W[15] = ct * F + ut * q + mt * rt + dt * Y, this._identityCalculated = false, this;
        }
        function A(S) {
          var P = S.props;
          return this.transform(P[0], P[1], P[2], P[3], P[4], P[5], P[6], P[7], P[8], P[9], P[10], P[11], P[12], P[13], P[14], P[15]);
        }
        function c() {
          return this._identityCalculated || (this._identity = !(this.props[0] !== 1 || this.props[1] !== 0 || this.props[2] !== 0 || this.props[3] !== 0 || this.props[4] !== 0 || this.props[5] !== 1 || this.props[6] !== 0 || this.props[7] !== 0 || this.props[8] !== 0 || this.props[9] !== 0 || this.props[10] !== 1 || this.props[11] !== 0 || this.props[12] !== 0 || this.props[13] !== 0 || this.props[14] !== 0 || this.props[15] !== 1), this._identityCalculated = true), this._identity;
        }
        function m(S) {
          for (var P = 0; P < 16; ) {
            if (S.props[P] !== this.props[P]) return false;
            P += 1;
          }
          return true;
        }
        function f(S) {
          var P;
          for (P = 0; P < 16; P += 1) S.props[P] = this.props[P];
          return S;
        }
        function b(S) {
          var P;
          for (P = 0; P < 16; P += 1) this.props[P] = S[P];
        }
        function C(S, P, V) {
          return {
            x: S * this.props[0] + P * this.props[4] + V * this.props[8] + this.props[12],
            y: S * this.props[1] + P * this.props[5] + V * this.props[9] + this.props[13],
            z: S * this.props[2] + P * this.props[6] + V * this.props[10] + this.props[14]
          };
        }
        function _(S, P, V) {
          return S * this.props[0] + P * this.props[4] + V * this.props[8] + this.props[12];
        }
        function T(S, P, V) {
          return S * this.props[1] + P * this.props[5] + V * this.props[9] + this.props[13];
        }
        function I(S, P, V) {
          return S * this.props[2] + P * this.props[6] + V * this.props[10] + this.props[14];
        }
        function L() {
          var S = this.props[0] * this.props[5] - this.props[1] * this.props[4], P = this.props[5] / S, V = -this.props[1] / S, F = -this.props[4] / S, B = this.props[0] / S, G = (this.props[4] * this.props[13] - this.props[5] * this.props[12]) / S, z = -(this.props[0] * this.props[13] - this.props[1] * this.props[12]) / S, q = new Matrix();
          return q.props[0] = P, q.props[1] = V, q.props[4] = F, q.props[5] = B, q.props[12] = G, q.props[13] = z, q;
        }
        function j(S) {
          var P = this.getInverseMatrix();
          return P.applyToPointArray(S[0], S[1], S[2] || 0);
        }
        function O(S) {
          var P, V = S.length, F = [];
          for (P = 0; P < V; P += 1) F[P] = j(S[P]);
          return F;
        }
        function D(S, P, V) {
          var F = createTypedArray("float32", 6);
          if (this.isIdentity()) F[0] = S[0], F[1] = S[1], F[2] = P[0], F[3] = P[1], F[4] = V[0], F[5] = V[1];
          else {
            var B = this.props[0], G = this.props[1], z = this.props[4], q = this.props[5], $ = this.props[12], X = this.props[13];
            F[0] = S[0] * B + S[1] * z + $, F[1] = S[0] * G + S[1] * q + X, F[2] = P[0] * B + P[1] * z + $, F[3] = P[0] * G + P[1] * q + X, F[4] = V[0] * B + V[1] * z + $, F[5] = V[0] * G + V[1] * q + X;
          }
          return F;
        }
        function N(S, P, V) {
          var F;
          return this.isIdentity() ? F = [
            S,
            P,
            V
          ] : F = [
            S * this.props[0] + P * this.props[4] + V * this.props[8] + this.props[12],
            S * this.props[1] + P * this.props[5] + V * this.props[9] + this.props[13],
            S * this.props[2] + P * this.props[6] + V * this.props[10] + this.props[14]
          ], F;
        }
        function H(S, P) {
          if (this.isIdentity()) return S + "," + P;
          var V = this.props;
          return Math.round((S * V[0] + P * V[4] + V[12]) * 100) / 100 + "," + Math.round((S * V[1] + P * V[5] + V[13]) * 100) / 100;
        }
        function R() {
          for (var S = 0, P = this.props, V = "matrix3d(", F = 1e4; S < 16; ) V += i(P[S] * F) / F, V += S === 15 ? ")" : ",", S += 1;
          return V;
        }
        function k(S) {
          var P = 1e4;
          return S < 1e-6 && S > 0 || S > -1e-6 && S < 0 ? i(S * P) / P : S;
        }
        function M() {
          var S = this.props, P = k(S[0]), V = k(S[1]), F = k(S[4]), B = k(S[5]), G = k(S[12]), z = k(S[13]);
          return "matrix(" + P + "," + V + "," + F + "," + B + "," + G + "," + z + ")";
        }
        return function() {
          this.reset = s, this.rotate = a, this.rotateX = n, this.rotateY = l, this.rotateZ = o, this.skew = y, this.skewFromAxis = E, this.shear = p, this.scale = u, this.setTransform = x, this.translate = g, this.transform = d, this.multiply = A, this.applyToPoint = C, this.applyToX = _, this.applyToY = T, this.applyToZ = I, this.applyToPointArray = N, this.applyToTriplePoints = D, this.applyToPointStringified = H, this.toCSS = R, this.to2dCSS = M, this.clone = f, this.cloneFromProps = b, this.equals = m, this.inversePoints = O, this.inversePoint = j, this.getInverseMatrix = L, this._t = this.transform, this.isIdentity = c, this._identity = true, this._identityCalculated = false, this.props = createTypedArray("float32", 16), this.reset();
        };
      })();
      function _typeof$3(t) {
        "@babel/helpers - typeof";
        return _typeof$3 = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
          return typeof e;
        } : function(e) {
          return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, _typeof$3(t);
      }
      var lottie = {};
      function setLocation(t) {
        setLocationHref(t);
      }
      function searchAnimations() {
        animationManager.searchAnimations();
      }
      function setSubframeRendering(t) {
        setSubframeEnabled(t);
      }
      function setPrefix(t) {
        setIdPrefix(t);
      }
      function loadAnimation(t) {
        return animationManager.loadAnimation(t);
      }
      function setQuality(t) {
        if (typeof t == "string") switch (t) {
          case "high":
            setDefaultCurveSegments(200);
            break;
          default:
          case "medium":
            setDefaultCurveSegments(50);
            break;
          case "low":
            setDefaultCurveSegments(10);
            break;
        }
        else !isNaN(t) && t > 1 && setDefaultCurveSegments(t);
      }
      function inBrowser() {
        return typeof navigator < "u";
      }
      function installPlugin(t, e) {
        t === "expressions" && setExpressionsPlugin(e);
      }
      function getFactory(t) {
        switch (t) {
          case "propertyFactory":
            return PropertyFactory;
          case "shapePropertyFactory":
            return ShapePropertyFactory;
          case "matrix":
            return Matrix;
          default:
            return null;
        }
      }
      lottie.play = animationManager.play, lottie.pause = animationManager.pause, lottie.setLocationHref = setLocation, lottie.togglePause = animationManager.togglePause, lottie.setSpeed = animationManager.setSpeed, lottie.setDirection = animationManager.setDirection, lottie.stop = animationManager.stop, lottie.searchAnimations = searchAnimations, lottie.registerAnimation = animationManager.registerAnimation, lottie.loadAnimation = loadAnimation, lottie.setSubframeRendering = setSubframeRendering, lottie.resize = animationManager.resize, lottie.goToAndStop = animationManager.goToAndStop, lottie.destroy = animationManager.destroy, lottie.setQuality = setQuality, lottie.inBrowser = inBrowser, lottie.installPlugin = installPlugin, lottie.freeze = animationManager.freeze, lottie.unfreeze = animationManager.unfreeze, lottie.setVolume = animationManager.setVolume, lottie.mute = animationManager.mute, lottie.unmute = animationManager.unmute, lottie.getRegisteredAnimations = animationManager.getRegisteredAnimations, lottie.useWebWorker = setWebWorker, lottie.setIDPrefix = setPrefix, lottie.__getFactory = getFactory, lottie.version = "5.13.0";
      function checkReady() {
        document.readyState === "complete" && (clearInterval(readyStateCheckInterval), searchAnimations());
      }
      function getQueryVariable(t) {
        for (var e = queryString.split("&"), r = 0; r < e.length; r += 1) {
          var i = e[r].split("=");
          if (decodeURIComponent(i[0]) == t) return decodeURIComponent(i[1]);
        }
        return null;
      }
      var queryString = "";
      {
        var scripts = document.getElementsByTagName("script"), index = scripts.length - 1, myScript = scripts[index] || {
          src: ""
        };
        queryString = myScript.src ? myScript.src.replace(/^[^\?]+\??/, "") : "", getQueryVariable("renderer");
      }
      var readyStateCheckInterval = setInterval(checkReady, 100);
      try {
        _typeof$3(exports$1) !== "object" && (window.bodymovin = lottie);
      } catch (t) {
      }
      var ShapeModifiers = (function() {
        var t = {}, e = {};
        t.registerModifier = r, t.getModifier = i;
        function r(s, a) {
          e[s] || (e[s] = a);
        }
        function i(s, a, n) {
          return new e[s](a, n);
        }
        return t;
      })();
      function ShapeModifier() {
      }
      ShapeModifier.prototype.initModifierProperties = function() {
      }, ShapeModifier.prototype.addShapeToModifier = function() {
      }, ShapeModifier.prototype.addShape = function(t) {
        if (!this.closed) {
          t.sh.container.addDynamicProperty(t.sh);
          var e = {
            shape: t.sh,
            data: t,
            localShapeCollection: shapeCollectionPool.newShapeCollection()
          };
          this.shapes.push(e), this.addShapeToModifier(e), this._isAnimated && t.setAsAnimated();
        }
      }, ShapeModifier.prototype.init = function(t, e) {
        this.shapes = [], this.elem = t, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e), this.frameId = initialDefaultFrame, this.closed = false, this.k = false, this.dynamicProperties.length ? this.k = true : this.getValue(true);
      }, ShapeModifier.prototype.processKeys = function() {
        this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties());
      }, extendPrototype([
        DynamicPropertyContainer
      ], ShapeModifier);
      function TrimModifier() {
      }
      extendPrototype([
        ShapeModifier
      ], TrimModifier), TrimModifier.prototype.initModifierProperties = function(t, e) {
        this.s = PropertyFactory.getProp(t, e.s, 0, 0.01, this), this.e = PropertyFactory.getProp(t, e.e, 0, 0.01, this), this.o = PropertyFactory.getProp(t, e.o, 0, 0, this), this.sValue = 0, this.eValue = 0, this.getValue = this.processKeys, this.m = e.m, this._isAnimated = !!this.s.effectsSequence.length || !!this.e.effectsSequence.length || !!this.o.effectsSequence.length;
      }, TrimModifier.prototype.addShapeToModifier = function(t) {
        t.pathsData = [];
      }, TrimModifier.prototype.calculateShapeEdges = function(t, e, r, i, s) {
        var a = [];
        e <= 1 ? a.push({
          s: t,
          e
        }) : t >= 1 ? a.push({
          s: t - 1,
          e: e - 1
        }) : (a.push({
          s: t,
          e: 1
        }), a.push({
          s: 0,
          e: e - 1
        }));
        var n = [], l, o = a.length, p;
        for (l = 0; l < o; l += 1) if (p = a[l], !(p.e * s < i || p.s * s > i + r)) {
          var y, E;
          p.s * s <= i ? y = 0 : y = (p.s * s - i) / r, p.e * s >= i + r ? E = 1 : E = (p.e * s - i) / r, n.push([
            y,
            E
          ]);
        }
        return n.length || n.push([
          0,
          0
        ]), n;
      }, TrimModifier.prototype.releasePathsData = function(t) {
        var e, r = t.length;
        for (e = 0; e < r; e += 1) segmentsLengthPool.release(t[e]);
        return t.length = 0, t;
      }, TrimModifier.prototype.processShapes = function(t) {
        var e, r;
        if (this._mdf || t) {
          var i = this.o.v % 360 / 360;
          if (i < 0 && (i += 1), this.s.v > 1 ? e = 1 + i : this.s.v < 0 ? e = 0 + i : e = this.s.v + i, this.e.v > 1 ? r = 1 + i : this.e.v < 0 ? r = 0 + i : r = this.e.v + i, e > r) {
            var s = e;
            e = r, r = s;
          }
          e = Math.round(e * 1e4) * 1e-4, r = Math.round(r * 1e4) * 1e-4, this.sValue = e, this.eValue = r;
        } else e = this.sValue, r = this.eValue;
        var a, n, l = this.shapes.length, o, p, y, E, u, x = 0;
        if (r === e) for (n = 0; n < l; n += 1) this.shapes[n].localShapeCollection.releaseShapes(), this.shapes[n].shape._mdf = true, this.shapes[n].shape.paths = this.shapes[n].localShapeCollection, this._mdf && (this.shapes[n].pathsData.length = 0);
        else if (r === 1 && e === 0 || r === 0 && e === 1) {
          if (this._mdf) for (n = 0; n < l; n += 1) this.shapes[n].pathsData.length = 0, this.shapes[n].shape._mdf = true;
        } else {
          var g = [], d, A;
          for (n = 0; n < l; n += 1) if (d = this.shapes[n], !d.shape._mdf && !this._mdf && !t && this.m !== 2) d.shape.paths = d.localShapeCollection;
          else {
            if (a = d.shape.paths, p = a._length, u = 0, !d.shape._mdf && d.pathsData.length) u = d.totalShapeLength;
            else {
              for (y = this.releasePathsData(d.pathsData), o = 0; o < p; o += 1) E = bez.getSegmentsLength(a.shapes[o]), y.push(E), u += E.totalLength;
              d.totalShapeLength = u, d.pathsData = y;
            }
            x += u, d.shape._mdf = true;
          }
          var c = e, m = r, f = 0, b;
          for (n = l - 1; n >= 0; n -= 1) if (d = this.shapes[n], d.shape._mdf) {
            for (A = d.localShapeCollection, A.releaseShapes(), this.m === 2 && l > 1 ? (b = this.calculateShapeEdges(e, r, d.totalShapeLength, f, x), f += d.totalShapeLength) : b = [
              [
                c,
                m
              ]
            ], p = b.length, o = 0; o < p; o += 1) {
              c = b[o][0], m = b[o][1], g.length = 0, m <= 1 ? g.push({
                s: d.totalShapeLength * c,
                e: d.totalShapeLength * m
              }) : c >= 1 ? g.push({
                s: d.totalShapeLength * (c - 1),
                e: d.totalShapeLength * (m - 1)
              }) : (g.push({
                s: d.totalShapeLength * c,
                e: d.totalShapeLength
              }), g.push({
                s: 0,
                e: d.totalShapeLength * (m - 1)
              }));
              var C = this.addShapes(d, g[0]);
              if (g[0].s !== g[0].e) {
                if (g.length > 1) {
                  var _ = d.shape.paths.shapes[d.shape.paths._length - 1];
                  if (_.c) {
                    var T = C.pop();
                    this.addPaths(C, A), C = this.addShapes(d, g[1], T);
                  } else this.addPaths(C, A), C = this.addShapes(d, g[1]);
                }
                this.addPaths(C, A);
              }
            }
            d.shape.paths = A;
          }
        }
      }, TrimModifier.prototype.addPaths = function(t, e) {
        var r, i = t.length;
        for (r = 0; r < i; r += 1) e.addShape(t[r]);
      }, TrimModifier.prototype.addSegment = function(t, e, r, i, s, a, n) {
        s.setXYAt(e[0], e[1], "o", a), s.setXYAt(r[0], r[1], "i", a + 1), n && s.setXYAt(t[0], t[1], "v", a), s.setXYAt(i[0], i[1], "v", a + 1);
      }, TrimModifier.prototype.addSegmentFromArray = function(t, e, r, i) {
        e.setXYAt(t[1], t[5], "o", r), e.setXYAt(t[2], t[6], "i", r + 1), i && e.setXYAt(t[0], t[4], "v", r), e.setXYAt(t[3], t[7], "v", r + 1);
      }, TrimModifier.prototype.addShapes = function(t, e, r) {
        var i = t.pathsData, s = t.shape.paths.shapes, a, n = t.shape.paths._length, l, o, p = 0, y, E, u, x, g = [], d, A = true;
        for (r ? (E = r._length, d = r._length) : (r = shapePool.newElement(), E = 0, d = 0), g.push(r), a = 0; a < n; a += 1) {
          for (u = i[a].lengths, r.c = s[a].c, o = s[a].c ? u.length : u.length + 1, l = 1; l < o; l += 1) if (y = u[l - 1], p + y.addedLength < e.s) p += y.addedLength, r.c = false;
          else if (p > e.e) {
            r.c = false;
            break;
          } else e.s <= p && e.e >= p + y.addedLength ? (this.addSegment(s[a].v[l - 1], s[a].o[l - 1], s[a].i[l], s[a].v[l], r, E, A), A = false) : (x = bez.getNewSegment(s[a].v[l - 1], s[a].v[l], s[a].o[l - 1], s[a].i[l], (e.s - p) / y.addedLength, (e.e - p) / y.addedLength, u[l - 1]), this.addSegmentFromArray(x, r, E, A), A = false, r.c = false), p += y.addedLength, E += 1;
          if (s[a].c && u.length) {
            if (y = u[l - 1], p <= e.e) {
              var c = u[l - 1].addedLength;
              e.s <= p && e.e >= p + c ? (this.addSegment(s[a].v[l - 1], s[a].o[l - 1], s[a].i[0], s[a].v[0], r, E, A), A = false) : (x = bez.getNewSegment(s[a].v[l - 1], s[a].v[0], s[a].o[l - 1], s[a].i[0], (e.s - p) / c, (e.e - p) / c, u[l - 1]), this.addSegmentFromArray(x, r, E, A), A = false, r.c = false);
            } else r.c = false;
            p += y.addedLength, E += 1;
          }
          if (r._length && (r.setXYAt(r.v[d][0], r.v[d][1], "i", d), r.setXYAt(r.v[r._length - 1][0], r.v[r._length - 1][1], "o", r._length - 1)), p > e.e) break;
          a < n - 1 && (r = shapePool.newElement(), A = true, g.push(r), E = 0);
        }
        return g;
      };
      function PuckerAndBloatModifier() {
      }
      extendPrototype([
        ShapeModifier
      ], PuckerAndBloatModifier), PuckerAndBloatModifier.prototype.initModifierProperties = function(t, e) {
        this.getValue = this.processKeys, this.amount = PropertyFactory.getProp(t, e.a, 0, null, this), this._isAnimated = !!this.amount.effectsSequence.length;
      }, PuckerAndBloatModifier.prototype.processPath = function(t, e) {
        var r = e / 100, i = [
          0,
          0
        ], s = t._length, a = 0;
        for (a = 0; a < s; a += 1) i[0] += t.v[a][0], i[1] += t.v[a][1];
        i[0] /= s, i[1] /= s;
        var n = shapePool.newElement();
        n.c = t.c;
        var l, o, p, y, E, u;
        for (a = 0; a < s; a += 1) l = t.v[a][0] + (i[0] - t.v[a][0]) * r, o = t.v[a][1] + (i[1] - t.v[a][1]) * r, p = t.o[a][0] + (i[0] - t.o[a][0]) * -r, y = t.o[a][1] + (i[1] - t.o[a][1]) * -r, E = t.i[a][0] + (i[0] - t.i[a][0]) * -r, u = t.i[a][1] + (i[1] - t.i[a][1]) * -r, n.setTripleAt(l, o, p, y, E, u, a);
        return n;
      }, PuckerAndBloatModifier.prototype.processShapes = function(t) {
        var e, r, i = this.shapes.length, s, a, n = this.amount.v;
        if (n !== 0) {
          var l, o;
          for (r = 0; r < i; r += 1) {
            if (l = this.shapes[r], o = l.localShapeCollection, !(!l.shape._mdf && !this._mdf && !t)) for (o.releaseShapes(), l.shape._mdf = true, e = l.shape.paths.shapes, a = l.shape.paths._length, s = 0; s < a; s += 1) o.addShape(this.processPath(e[s], n));
            l.shape.paths = l.localShapeCollection;
          }
        }
        this.dynamicProperties.length || (this._mdf = false);
      };
      var TransformPropertyFactory = (function() {
        var t = [
          0,
          0
        ];
        function e(o) {
          var p = this._mdf;
          this.iterateDynamicProperties(), this._mdf = this._mdf || p, this.a && o.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.s && o.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && o.skewFromAxis(-this.sk.v, this.sa.v), this.r ? o.rotate(-this.r.v) : o.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.data.p.s ? this.data.p.z ? o.translate(this.px.v, this.py.v, -this.pz.v) : o.translate(this.px.v, this.py.v, 0) : o.translate(this.p.v[0], this.p.v[1], -this.p.v[2]);
        }
        function r(o) {
          if (this.elem.globalData.frameId !== this.frameId) {
            if (this._isDirty && (this.precalculateMatrix(), this._isDirty = false), this.iterateDynamicProperties(), this._mdf || o) {
              var p;
              if (this.v.cloneFromProps(this.pre.props), this.appliedTransformations < 1 && this.v.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations < 2 && this.v.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && this.appliedTransformations < 3 && this.v.skewFromAxis(-this.sk.v, this.sa.v), this.r && this.appliedTransformations < 4 ? this.v.rotate(-this.r.v) : !this.r && this.appliedTransformations < 4 && this.v.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.autoOriented) {
                var y, E;
                if (p = this.elem.globalData.frameRate, this.p && this.p.keyframes && this.p.getValueAtTime) this.p._caching.lastFrame + this.p.offsetTime <= this.p.keyframes[0].t ? (y = this.p.getValueAtTime((this.p.keyframes[0].t + 0.01) / p, 0), E = this.p.getValueAtTime(this.p.keyframes[0].t / p, 0)) : this.p._caching.lastFrame + this.p.offsetTime >= this.p.keyframes[this.p.keyframes.length - 1].t ? (y = this.p.getValueAtTime(this.p.keyframes[this.p.keyframes.length - 1].t / p, 0), E = this.p.getValueAtTime((this.p.keyframes[this.p.keyframes.length - 1].t - 0.05) / p, 0)) : (y = this.p.pv, E = this.p.getValueAtTime((this.p._caching.lastFrame + this.p.offsetTime - 0.01) / p, this.p.offsetTime));
                else if (this.px && this.px.keyframes && this.py.keyframes && this.px.getValueAtTime && this.py.getValueAtTime) {
                  y = [], E = [];
                  var u = this.px, x = this.py;
                  u._caching.lastFrame + u.offsetTime <= u.keyframes[0].t ? (y[0] = u.getValueAtTime((u.keyframes[0].t + 0.01) / p, 0), y[1] = x.getValueAtTime((x.keyframes[0].t + 0.01) / p, 0), E[0] = u.getValueAtTime(u.keyframes[0].t / p, 0), E[1] = x.getValueAtTime(x.keyframes[0].t / p, 0)) : u._caching.lastFrame + u.offsetTime >= u.keyframes[u.keyframes.length - 1].t ? (y[0] = u.getValueAtTime(u.keyframes[u.keyframes.length - 1].t / p, 0), y[1] = x.getValueAtTime(x.keyframes[x.keyframes.length - 1].t / p, 0), E[0] = u.getValueAtTime((u.keyframes[u.keyframes.length - 1].t - 0.01) / p, 0), E[1] = x.getValueAtTime((x.keyframes[x.keyframes.length - 1].t - 0.01) / p, 0)) : (y = [
                    u.pv,
                    x.pv
                  ], E[0] = u.getValueAtTime((u._caching.lastFrame + u.offsetTime - 0.01) / p, u.offsetTime), E[1] = x.getValueAtTime((x._caching.lastFrame + x.offsetTime - 0.01) / p, x.offsetTime));
                } else E = t, y = E;
                this.v.rotate(-Math.atan2(y[1] - E[1], y[0] - E[0]));
              }
              this.data.p && this.data.p.s ? this.data.p.z ? this.v.translate(this.px.v, this.py.v, -this.pz.v) : this.v.translate(this.px.v, this.py.v, 0) : this.v.translate(this.p.v[0], this.p.v[1], -this.p.v[2]);
            }
            this.frameId = this.elem.globalData.frameId;
          }
        }
        function i() {
          if (this.appliedTransformations = 0, this.pre.reset(), !this.a.effectsSequence.length) this.pre.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations = 1;
          else return;
          if (!this.s.effectsSequence.length) this.pre.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.appliedTransformations = 2;
          else return;
          if (this.sk) if (!this.sk.effectsSequence.length && !this.sa.effectsSequence.length) this.pre.skewFromAxis(-this.sk.v, this.sa.v), this.appliedTransformations = 3;
          else return;
          this.r ? this.r.effectsSequence.length || (this.pre.rotate(-this.r.v), this.appliedTransformations = 4) : !this.rz.effectsSequence.length && !this.ry.effectsSequence.length && !this.rx.effectsSequence.length && !this.or.effectsSequence.length && (this.pre.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.appliedTransformations = 4);
        }
        function s() {
        }
        function a(o) {
          this._addDynamicProperty(o), this.elem.addDynamicProperty(o), this._isDirty = true;
        }
        function n(o, p, y) {
          if (this.elem = o, this.frameId = -1, this.propType = "transform", this.data = p, this.v = new Matrix(), this.pre = new Matrix(), this.appliedTransformations = 0, this.initDynamicPropertyContainer(y || o), p.p && p.p.s ? (this.px = PropertyFactory.getProp(o, p.p.x, 0, 0, this), this.py = PropertyFactory.getProp(o, p.p.y, 0, 0, this), p.p.z && (this.pz = PropertyFactory.getProp(o, p.p.z, 0, 0, this))) : this.p = PropertyFactory.getProp(o, p.p || {
            k: [
              0,
              0,
              0
            ]
          }, 1, 0, this), p.rx) {
            if (this.rx = PropertyFactory.getProp(o, p.rx, 0, degToRads, this), this.ry = PropertyFactory.getProp(o, p.ry, 0, degToRads, this), this.rz = PropertyFactory.getProp(o, p.rz, 0, degToRads, this), p.or.k[0].ti) {
              var E, u = p.or.k.length;
              for (E = 0; E < u; E += 1) p.or.k[E].to = null, p.or.k[E].ti = null;
            }
            this.or = PropertyFactory.getProp(o, p.or, 1, degToRads, this), this.or.sh = true;
          } else this.r = PropertyFactory.getProp(o, p.r || {
            k: 0
          }, 0, degToRads, this);
          p.sk && (this.sk = PropertyFactory.getProp(o, p.sk, 0, degToRads, this), this.sa = PropertyFactory.getProp(o, p.sa, 0, degToRads, this)), this.a = PropertyFactory.getProp(o, p.a || {
            k: [
              0,
              0,
              0
            ]
          }, 1, 0, this), this.s = PropertyFactory.getProp(o, p.s || {
            k: [
              100,
              100,
              100
            ]
          }, 1, 0.01, this), p.o ? this.o = PropertyFactory.getProp(o, p.o, 0, 0.01, o) : this.o = {
            _mdf: false,
            v: 1
          }, this._isDirty = true, this.dynamicProperties.length || this.getValue(true);
        }
        n.prototype = {
          applyToMatrix: e,
          getValue: r,
          precalculateMatrix: i,
          autoOrient: s
        }, extendPrototype([
          DynamicPropertyContainer
        ], n), n.prototype.addDynamicProperty = a, n.prototype._addDynamicProperty = DynamicPropertyContainer.prototype.addDynamicProperty;
        function l(o, p, y) {
          return new n(o, p, y);
        }
        return {
          getTransformProperty: l
        };
      })();
      function RepeaterModifier() {
      }
      extendPrototype([
        ShapeModifier
      ], RepeaterModifier), RepeaterModifier.prototype.initModifierProperties = function(t, e) {
        this.getValue = this.processKeys, this.c = PropertyFactory.getProp(t, e.c, 0, null, this), this.o = PropertyFactory.getProp(t, e.o, 0, null, this), this.tr = TransformPropertyFactory.getTransformProperty(t, e.tr, this), this.so = PropertyFactory.getProp(t, e.tr.so, 0, 0.01, this), this.eo = PropertyFactory.getProp(t, e.tr.eo, 0, 0.01, this), this.data = e, this.dynamicProperties.length || this.getValue(true), this._isAnimated = !!this.dynamicProperties.length, this.pMatrix = new Matrix(), this.rMatrix = new Matrix(), this.sMatrix = new Matrix(), this.tMatrix = new Matrix(), this.matrix = new Matrix();
      }, RepeaterModifier.prototype.applyTransforms = function(t, e, r, i, s, a) {
        var n = a ? -1 : 1, l = i.s.v[0] + (1 - i.s.v[0]) * (1 - s), o = i.s.v[1] + (1 - i.s.v[1]) * (1 - s);
        t.translate(i.p.v[0] * n * s, i.p.v[1] * n * s, i.p.v[2]), e.translate(-i.a.v[0], -i.a.v[1], i.a.v[2]), e.rotate(-i.r.v * n * s), e.translate(i.a.v[0], i.a.v[1], i.a.v[2]), r.translate(-i.a.v[0], -i.a.v[1], i.a.v[2]), r.scale(a ? 1 / l : l, a ? 1 / o : o), r.translate(i.a.v[0], i.a.v[1], i.a.v[2]);
      }, RepeaterModifier.prototype.init = function(t, e, r, i) {
        for (this.elem = t, this.arr = e, this.pos = r, this.elemsData = i, this._currentCopies = 0, this._elements = [], this._groups = [], this.frameId = -1, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e[r]); r > 0; ) r -= 1, this._elements.unshift(e[r]);
        this.dynamicProperties.length ? this.k = true : this.getValue(true);
      }, RepeaterModifier.prototype.resetElements = function(t) {
        var e, r = t.length;
        for (e = 0; e < r; e += 1) t[e]._processed = false, t[e].ty === "gr" && this.resetElements(t[e].it);
      }, RepeaterModifier.prototype.cloneElements = function(t) {
        var e = JSON.parse(JSON.stringify(t));
        return this.resetElements(e), e;
      }, RepeaterModifier.prototype.changeGroupRender = function(t, e) {
        var r, i = t.length;
        for (r = 0; r < i; r += 1) t[r]._render = e, t[r].ty === "gr" && this.changeGroupRender(t[r].it, e);
      }, RepeaterModifier.prototype.processShapes = function(t) {
        var e, r, i, s, a, n = false;
        if (this._mdf || t) {
          var l = Math.ceil(this.c.v);
          if (this._groups.length < l) {
            for (; this._groups.length < l; ) {
              var o = {
                it: this.cloneElements(this._elements),
                ty: "gr"
              };
              o.it.push({
                a: {
                  a: 0,
                  ix: 1,
                  k: [
                    0,
                    0
                  ]
                },
                nm: "Transform",
                o: {
                  a: 0,
                  ix: 7,
                  k: 100
                },
                p: {
                  a: 0,
                  ix: 2,
                  k: [
                    0,
                    0
                  ]
                },
                r: {
                  a: 1,
                  ix: 6,
                  k: [
                    {
                      s: 0,
                      e: 0,
                      t: 0
                    },
                    {
                      s: 0,
                      e: 0,
                      t: 1
                    }
                  ]
                },
                s: {
                  a: 0,
                  ix: 3,
                  k: [
                    100,
                    100
                  ]
                },
                sa: {
                  a: 0,
                  ix: 5,
                  k: 0
                },
                sk: {
                  a: 0,
                  ix: 4,
                  k: 0
                },
                ty: "tr"
              }), this.arr.splice(0, 0, o), this._groups.splice(0, 0, o), this._currentCopies += 1;
            }
            this.elem.reloadShapes(), n = true;
          }
          a = 0;
          var p;
          for (i = 0; i <= this._groups.length - 1; i += 1) {
            if (p = a < l, this._groups[i]._render = p, this.changeGroupRender(this._groups[i].it, p), !p) {
              var y = this.elemsData[i].it, E = y[y.length - 1];
              E.transform.op.v !== 0 ? (E.transform.op._mdf = true, E.transform.op.v = 0) : E.transform.op._mdf = false;
            }
            a += 1;
          }
          this._currentCopies = l;
          var u = this.o.v, x = u % 1, g = u > 0 ? Math.floor(u) : Math.ceil(u), d = this.pMatrix.props, A = this.rMatrix.props, c = this.sMatrix.props;
          this.pMatrix.reset(), this.rMatrix.reset(), this.sMatrix.reset(), this.tMatrix.reset(), this.matrix.reset();
          var m = 0;
          if (u > 0) {
            for (; m < g; ) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, false), m += 1;
            x && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, x, false), m += x);
          } else if (u < 0) {
            for (; m > g; ) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, true), m -= 1;
            x && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, -x, true), m -= x);
          }
          i = this.data.m === 1 ? 0 : this._currentCopies - 1, s = this.data.m === 1 ? 1 : -1, a = this._currentCopies;
          for (var f, b; a; ) {
            if (e = this.elemsData[i].it, r = e[e.length - 1].transform.mProps.v.props, b = r.length, e[e.length - 1].transform.mProps._mdf = true, e[e.length - 1].transform.op._mdf = true, e[e.length - 1].transform.op.v = this._currentCopies === 1 ? this.so.v : this.so.v + (this.eo.v - this.so.v) * (i / (this._currentCopies - 1)), m !== 0) {
              for ((i !== 0 && s === 1 || i !== this._currentCopies - 1 && s === -1) && this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, false), this.matrix.transform(A[0], A[1], A[2], A[3], A[4], A[5], A[6], A[7], A[8], A[9], A[10], A[11], A[12], A[13], A[14], A[15]), this.matrix.transform(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7], c[8], c[9], c[10], c[11], c[12], c[13], c[14], c[15]), this.matrix.transform(d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7], d[8], d[9], d[10], d[11], d[12], d[13], d[14], d[15]), f = 0; f < b; f += 1) r[f] = this.matrix.props[f];
              this.matrix.reset();
            } else for (this.matrix.reset(), f = 0; f < b; f += 1) r[f] = this.matrix.props[f];
            m += 1, a -= 1, i += s;
          }
        } else for (a = this._currentCopies, i = 0, s = 1; a; ) e = this.elemsData[i].it, r = e[e.length - 1].transform.mProps.v.props, e[e.length - 1].transform.mProps._mdf = false, e[e.length - 1].transform.op._mdf = false, a -= 1, i += s;
        return n;
      }, RepeaterModifier.prototype.addShape = function() {
      };
      function RoundCornersModifier() {
      }
      extendPrototype([
        ShapeModifier
      ], RoundCornersModifier), RoundCornersModifier.prototype.initModifierProperties = function(t, e) {
        this.getValue = this.processKeys, this.rd = PropertyFactory.getProp(t, e.r, 0, null, this), this._isAnimated = !!this.rd.effectsSequence.length;
      }, RoundCornersModifier.prototype.processPath = function(t, e) {
        var r = shapePool.newElement();
        r.c = t.c;
        var i, s = t._length, a, n, l, o, p, y, E = 0, u, x, g, d, A, c;
        for (i = 0; i < s; i += 1) a = t.v[i], l = t.o[i], n = t.i[i], a[0] === l[0] && a[1] === l[1] && a[0] === n[0] && a[1] === n[1] ? (i === 0 || i === s - 1) && !t.c ? (r.setTripleAt(a[0], a[1], l[0], l[1], n[0], n[1], E), E += 1) : (i === 0 ? o = t.v[s - 1] : o = t.v[i - 1], p = Math.sqrt(Math.pow(a[0] - o[0], 2) + Math.pow(a[1] - o[1], 2)), y = p ? Math.min(p / 2, e) / p : 0, A = a[0] + (o[0] - a[0]) * y, u = A, c = a[1] - (a[1] - o[1]) * y, x = c, g = u - (u - a[0]) * roundCorner, d = x - (x - a[1]) * roundCorner, r.setTripleAt(u, x, g, d, A, c, E), E += 1, i === s - 1 ? o = t.v[0] : o = t.v[i + 1], p = Math.sqrt(Math.pow(a[0] - o[0], 2) + Math.pow(a[1] - o[1], 2)), y = p ? Math.min(p / 2, e) / p : 0, g = a[0] + (o[0] - a[0]) * y, u = g, d = a[1] + (o[1] - a[1]) * y, x = d, A = u - (u - a[0]) * roundCorner, c = x - (x - a[1]) * roundCorner, r.setTripleAt(u, x, g, d, A, c, E), E += 1) : (r.setTripleAt(t.v[i][0], t.v[i][1], t.o[i][0], t.o[i][1], t.i[i][0], t.i[i][1], E), E += 1);
        return r;
      }, RoundCornersModifier.prototype.processShapes = function(t) {
        var e, r, i = this.shapes.length, s, a, n = this.rd.v;
        if (n !== 0) {
          var l, o;
          for (r = 0; r < i; r += 1) {
            if (l = this.shapes[r], o = l.localShapeCollection, !(!l.shape._mdf && !this._mdf && !t)) for (o.releaseShapes(), l.shape._mdf = true, e = l.shape.paths.shapes, a = l.shape.paths._length, s = 0; s < a; s += 1) o.addShape(this.processPath(e[s], n));
            l.shape.paths = l.localShapeCollection;
          }
        }
        this.dynamicProperties.length || (this._mdf = false);
      };
      function floatEqual(t, e) {
        return Math.abs(t - e) * 1e5 <= Math.min(Math.abs(t), Math.abs(e));
      }
      function floatZero(t) {
        return Math.abs(t) <= 1e-5;
      }
      function lerp(t, e, r) {
        return t * (1 - r) + e * r;
      }
      function lerpPoint(t, e, r) {
        return [
          lerp(t[0], e[0], r),
          lerp(t[1], e[1], r)
        ];
      }
      function quadRoots(t, e, r) {
        if (t === 0) return [];
        var i = e * e - 4 * t * r;
        if (i < 0) return [];
        var s = -e / (2 * t);
        if (i === 0) return [
          s
        ];
        var a = Math.sqrt(i) / (2 * t);
        return [
          s - a,
          s + a
        ];
      }
      function polynomialCoefficients(t, e, r, i) {
        return [
          -t + 3 * e - 3 * r + i,
          3 * t - 6 * e + 3 * r,
          -3 * t + 3 * e,
          t
        ];
      }
      function singlePoint(t) {
        return new PolynomialBezier(t, t, t, t, false);
      }
      function PolynomialBezier(t, e, r, i, s) {
        s && pointEqual(t, e) && (e = lerpPoint(t, i, 1 / 3)), s && pointEqual(r, i) && (r = lerpPoint(t, i, 2 / 3));
        var a = polynomialCoefficients(t[0], e[0], r[0], i[0]), n = polynomialCoefficients(t[1], e[1], r[1], i[1]);
        this.a = [
          a[0],
          n[0]
        ], this.b = [
          a[1],
          n[1]
        ], this.c = [
          a[2],
          n[2]
        ], this.d = [
          a[3],
          n[3]
        ], this.points = [
          t,
          e,
          r,
          i
        ];
      }
      PolynomialBezier.prototype.point = function(t) {
        return [
          ((this.a[0] * t + this.b[0]) * t + this.c[0]) * t + this.d[0],
          ((this.a[1] * t + this.b[1]) * t + this.c[1]) * t + this.d[1]
        ];
      }, PolynomialBezier.prototype.derivative = function(t) {
        return [
          (3 * t * this.a[0] + 2 * this.b[0]) * t + this.c[0],
          (3 * t * this.a[1] + 2 * this.b[1]) * t + this.c[1]
        ];
      }, PolynomialBezier.prototype.tangentAngle = function(t) {
        var e = this.derivative(t);
        return Math.atan2(e[1], e[0]);
      }, PolynomialBezier.prototype.normalAngle = function(t) {
        var e = this.derivative(t);
        return Math.atan2(e[0], e[1]);
      }, PolynomialBezier.prototype.inflectionPoints = function() {
        var t = this.a[1] * this.b[0] - this.a[0] * this.b[1];
        if (floatZero(t)) return [];
        var e = -0.5 * (this.a[1] * this.c[0] - this.a[0] * this.c[1]) / t, r = e * e - 1 / 3 * (this.b[1] * this.c[0] - this.b[0] * this.c[1]) / t;
        if (r < 0) return [];
        var i = Math.sqrt(r);
        return floatZero(i) ? i > 0 && i < 1 ? [
          e
        ] : [] : [
          e - i,
          e + i
        ].filter(function(s) {
          return s > 0 && s < 1;
        });
      }, PolynomialBezier.prototype.split = function(t) {
        if (t <= 0) return [
          singlePoint(this.points[0]),
          this
        ];
        if (t >= 1) return [
          this,
          singlePoint(this.points[this.points.length - 1])
        ];
        var e = lerpPoint(this.points[0], this.points[1], t), r = lerpPoint(this.points[1], this.points[2], t), i = lerpPoint(this.points[2], this.points[3], t), s = lerpPoint(e, r, t), a = lerpPoint(r, i, t), n = lerpPoint(s, a, t);
        return [
          new PolynomialBezier(this.points[0], e, s, n, true),
          new PolynomialBezier(n, a, i, this.points[3], true)
        ];
      };
      function extrema(t, e) {
        var r = t.points[0][e], i = t.points[t.points.length - 1][e];
        if (r > i) {
          var s = i;
          i = r, r = s;
        }
        for (var a = quadRoots(3 * t.a[e], 2 * t.b[e], t.c[e]), n = 0; n < a.length; n += 1) if (a[n] > 0 && a[n] < 1) {
          var l = t.point(a[n])[e];
          l < r ? r = l : l > i && (i = l);
        }
        return {
          min: r,
          max: i
        };
      }
      PolynomialBezier.prototype.bounds = function() {
        return {
          x: extrema(this, 0),
          y: extrema(this, 1)
        };
      }, PolynomialBezier.prototype.boundingBox = function() {
        var t = this.bounds();
        return {
          left: t.x.min,
          right: t.x.max,
          top: t.y.min,
          bottom: t.y.max,
          width: t.x.max - t.x.min,
          height: t.y.max - t.y.min,
          cx: (t.x.max + t.x.min) / 2,
          cy: (t.y.max + t.y.min) / 2
        };
      };
      function intersectData(t, e, r) {
        var i = t.boundingBox();
        return {
          cx: i.cx,
          cy: i.cy,
          width: i.width,
          height: i.height,
          bez: t,
          t: (e + r) / 2,
          t1: e,
          t2: r
        };
      }
      function splitData(t) {
        var e = t.bez.split(0.5);
        return [
          intersectData(e[0], t.t1, t.t),
          intersectData(e[1], t.t, t.t2)
        ];
      }
      function boxIntersect(t, e) {
        return Math.abs(t.cx - e.cx) * 2 < t.width + e.width && Math.abs(t.cy - e.cy) * 2 < t.height + e.height;
      }
      function intersectsImpl(t, e, r, i, s, a) {
        if (boxIntersect(t, e)) {
          if (r >= a || t.width <= i && t.height <= i && e.width <= i && e.height <= i) {
            s.push([
              t.t,
              e.t
            ]);
            return;
          }
          var n = splitData(t), l = splitData(e);
          intersectsImpl(n[0], l[0], r + 1, i, s, a), intersectsImpl(n[0], l[1], r + 1, i, s, a), intersectsImpl(n[1], l[0], r + 1, i, s, a), intersectsImpl(n[1], l[1], r + 1, i, s, a);
        }
      }
      PolynomialBezier.prototype.intersections = function(t, e, r) {
        e === void 0 && (e = 2), r === void 0 && (r = 7);
        var i = [];
        return intersectsImpl(intersectData(this, 0, 1), intersectData(t, 0, 1), 0, e, i, r), i;
      }, PolynomialBezier.shapeSegment = function(t, e) {
        var r = (e + 1) % t.length();
        return new PolynomialBezier(t.v[e], t.o[e], t.i[r], t.v[r], true);
      }, PolynomialBezier.shapeSegmentInverted = function(t, e) {
        var r = (e + 1) % t.length();
        return new PolynomialBezier(t.v[r], t.i[r], t.o[e], t.v[e], true);
      };
      function crossProduct(t, e) {
        return [
          t[1] * e[2] - t[2] * e[1],
          t[2] * e[0] - t[0] * e[2],
          t[0] * e[1] - t[1] * e[0]
        ];
      }
      function lineIntersection(t, e, r, i) {
        var s = [
          t[0],
          t[1],
          1
        ], a = [
          e[0],
          e[1],
          1
        ], n = [
          r[0],
          r[1],
          1
        ], l = [
          i[0],
          i[1],
          1
        ], o = crossProduct(crossProduct(s, a), crossProduct(n, l));
        return floatZero(o[2]) ? null : [
          o[0] / o[2],
          o[1] / o[2]
        ];
      }
      function polarOffset(t, e, r) {
        return [
          t[0] + Math.cos(e) * r,
          t[1] - Math.sin(e) * r
        ];
      }
      function pointDistance(t, e) {
        return Math.hypot(t[0] - e[0], t[1] - e[1]);
      }
      function pointEqual(t, e) {
        return floatEqual(t[0], e[0]) && floatEqual(t[1], e[1]);
      }
      function ZigZagModifier() {
      }
      extendPrototype([
        ShapeModifier
      ], ZigZagModifier), ZigZagModifier.prototype.initModifierProperties = function(t, e) {
        this.getValue = this.processKeys, this.amplitude = PropertyFactory.getProp(t, e.s, 0, null, this), this.frequency = PropertyFactory.getProp(t, e.r, 0, null, this), this.pointsType = PropertyFactory.getProp(t, e.pt, 0, null, this), this._isAnimated = this.amplitude.effectsSequence.length !== 0 || this.frequency.effectsSequence.length !== 0 || this.pointsType.effectsSequence.length !== 0;
      };
      function setPoint(t, e, r, i, s, a, n) {
        var l = r - Math.PI / 2, o = r + Math.PI / 2, p = e[0] + Math.cos(r) * i * s, y = e[1] - Math.sin(r) * i * s;
        t.setTripleAt(p, y, p + Math.cos(l) * a, y - Math.sin(l) * a, p + Math.cos(o) * n, y - Math.sin(o) * n, t.length());
      }
      function getPerpendicularVector(t, e) {
        var r = [
          e[0] - t[0],
          e[1] - t[1]
        ], i = -Math.PI * 0.5, s = [
          Math.cos(i) * r[0] - Math.sin(i) * r[1],
          Math.sin(i) * r[0] + Math.cos(i) * r[1]
        ];
        return s;
      }
      function getProjectingAngle(t, e) {
        var r = e === 0 ? t.length() - 1 : e - 1, i = (e + 1) % t.length(), s = t.v[r], a = t.v[i], n = getPerpendicularVector(s, a);
        return Math.atan2(0, 1) - Math.atan2(n[1], n[0]);
      }
      function zigZagCorner(t, e, r, i, s, a, n) {
        var l = getProjectingAngle(e, r), o = e.v[r % e._length], p = e.v[r === 0 ? e._length - 1 : r - 1], y = e.v[(r + 1) % e._length], E = a === 2 ? Math.sqrt(Math.pow(o[0] - p[0], 2) + Math.pow(o[1] - p[1], 2)) : 0, u = a === 2 ? Math.sqrt(Math.pow(o[0] - y[0], 2) + Math.pow(o[1] - y[1], 2)) : 0;
        setPoint(t, e.v[r % e._length], l, n, i, u / ((s + 1) * 2), E / ((s + 1) * 2));
      }
      function zigZagSegment(t, e, r, i, s, a) {
        for (var n = 0; n < i; n += 1) {
          var l = (n + 1) / (i + 1), o = s === 2 ? Math.sqrt(Math.pow(e.points[3][0] - e.points[0][0], 2) + Math.pow(e.points[3][1] - e.points[0][1], 2)) : 0, p = e.normalAngle(l), y = e.point(l);
          setPoint(t, y, p, a, r, o / ((i + 1) * 2), o / ((i + 1) * 2)), a = -a;
        }
        return a;
      }
      ZigZagModifier.prototype.processPath = function(t, e, r, i) {
        var s = t._length, a = shapePool.newElement();
        if (a.c = t.c, t.c || (s -= 1), s === 0) return a;
        var n = -1, l = PolynomialBezier.shapeSegment(t, 0);
        zigZagCorner(a, t, 0, e, r, i, n);
        for (var o = 0; o < s; o += 1) n = zigZagSegment(a, l, e, r, i, -n), o === s - 1 && !t.c ? l = null : l = PolynomialBezier.shapeSegment(t, (o + 1) % s), zigZagCorner(a, t, o + 1, e, r, i, n);
        return a;
      }, ZigZagModifier.prototype.processShapes = function(t) {
        var e, r, i = this.shapes.length, s, a, n = this.amplitude.v, l = Math.max(0, Math.round(this.frequency.v)), o = this.pointsType.v;
        if (n !== 0) {
          var p, y;
          for (r = 0; r < i; r += 1) {
            if (p = this.shapes[r], y = p.localShapeCollection, !(!p.shape._mdf && !this._mdf && !t)) for (y.releaseShapes(), p.shape._mdf = true, e = p.shape.paths.shapes, a = p.shape.paths._length, s = 0; s < a; s += 1) y.addShape(this.processPath(e[s], n, l, o));
            p.shape.paths = p.localShapeCollection;
          }
        }
        this.dynamicProperties.length || (this._mdf = false);
      };
      function linearOffset(t, e, r) {
        var i = Math.atan2(e[0] - t[0], e[1] - t[1]);
        return [
          polarOffset(t, i, r),
          polarOffset(e, i, r)
        ];
      }
      function offsetSegment(t, e) {
        var r, i, s, a, n, l, o;
        o = linearOffset(t.points[0], t.points[1], e), r = o[0], i = o[1], o = linearOffset(t.points[1], t.points[2], e), s = o[0], a = o[1], o = linearOffset(t.points[2], t.points[3], e), n = o[0], l = o[1];
        var p = lineIntersection(r, i, s, a);
        p === null && (p = i);
        var y = lineIntersection(n, l, s, a);
        return y === null && (y = n), new PolynomialBezier(r, p, y, l);
      }
      function joinLines(t, e, r, i, s) {
        var a = e.points[3], n = r.points[0];
        if (i === 3 || pointEqual(a, n)) return a;
        if (i === 2) {
          var l = -e.tangentAngle(1), o = -r.tangentAngle(0) + Math.PI, p = lineIntersection(a, polarOffset(a, l + Math.PI / 2, 100), n, polarOffset(n, l + Math.PI / 2, 100)), y = p ? pointDistance(p, a) : pointDistance(a, n) / 2, E = polarOffset(a, l, 2 * y * roundCorner);
          return t.setXYAt(E[0], E[1], "o", t.length() - 1), E = polarOffset(n, o, 2 * y * roundCorner), t.setTripleAt(n[0], n[1], n[0], n[1], E[0], E[1], t.length()), n;
        }
        var u = pointEqual(a, e.points[2]) ? e.points[0] : e.points[2], x = pointEqual(n, r.points[1]) ? r.points[3] : r.points[1], g = lineIntersection(u, a, n, x);
        return g && pointDistance(g, a) < s ? (t.setTripleAt(g[0], g[1], g[0], g[1], g[0], g[1], t.length()), g) : a;
      }
      function getIntersection(t, e) {
        var r = t.intersections(e);
        return r.length && floatEqual(r[0][0], 1) && r.shift(), r.length ? r[0] : null;
      }
      function pruneSegmentIntersection(t, e) {
        var r = t.slice(), i = e.slice(), s = getIntersection(t[t.length - 1], e[0]);
        return s && (r[t.length - 1] = t[t.length - 1].split(s[0])[0], i[0] = e[0].split(s[1])[1]), t.length > 1 && e.length > 1 && (s = getIntersection(t[0], e[e.length - 1]), s) ? [
          [
            t[0].split(s[0])[0]
          ],
          [
            e[e.length - 1].split(s[1])[1]
          ]
        ] : [
          r,
          i
        ];
      }
      function pruneIntersections(t) {
        for (var e, r = 1; r < t.length; r += 1) e = pruneSegmentIntersection(t[r - 1], t[r]), t[r - 1] = e[0], t[r] = e[1];
        return t.length > 1 && (e = pruneSegmentIntersection(t[t.length - 1], t[0]), t[t.length - 1] = e[0], t[0] = e[1]), t;
      }
      function offsetSegmentSplit(t, e) {
        var r = t.inflectionPoints(), i, s, a, n;
        if (r.length === 0) return [
          offsetSegment(t, e)
        ];
        if (r.length === 1 || floatEqual(r[1], 1)) return a = t.split(r[0]), i = a[0], s = a[1], [
          offsetSegment(i, e),
          offsetSegment(s, e)
        ];
        a = t.split(r[0]), i = a[0];
        var l = (r[1] - r[0]) / (1 - r[0]);
        return a = a[1].split(l), n = a[0], s = a[1], [
          offsetSegment(i, e),
          offsetSegment(n, e),
          offsetSegment(s, e)
        ];
      }
      function OffsetPathModifier() {
      }
      extendPrototype([
        ShapeModifier
      ], OffsetPathModifier), OffsetPathModifier.prototype.initModifierProperties = function(t, e) {
        this.getValue = this.processKeys, this.amount = PropertyFactory.getProp(t, e.a, 0, null, this), this.miterLimit = PropertyFactory.getProp(t, e.ml, 0, null, this), this.lineJoin = e.lj, this._isAnimated = this.amount.effectsSequence.length !== 0;
      }, OffsetPathModifier.prototype.processPath = function(t, e, r, i) {
        var s = shapePool.newElement();
        s.c = t.c;
        var a = t.length();
        t.c || (a -= 1);
        var n, l, o, p = [];
        for (n = 0; n < a; n += 1) o = PolynomialBezier.shapeSegment(t, n), p.push(offsetSegmentSplit(o, e));
        if (!t.c) for (n = a - 1; n >= 0; n -= 1) o = PolynomialBezier.shapeSegmentInverted(t, n), p.push(offsetSegmentSplit(o, e));
        p = pruneIntersections(p);
        var y = null, E = null;
        for (n = 0; n < p.length; n += 1) {
          var u = p[n];
          for (E && (y = joinLines(s, E, u[0], r, i)), E = u[u.length - 1], l = 0; l < u.length; l += 1) o = u[l], y && pointEqual(o.points[0], y) ? s.setXYAt(o.points[1][0], o.points[1][1], "o", s.length() - 1) : s.setTripleAt(o.points[0][0], o.points[0][1], o.points[1][0], o.points[1][1], o.points[0][0], o.points[0][1], s.length()), s.setTripleAt(o.points[3][0], o.points[3][1], o.points[3][0], o.points[3][1], o.points[2][0], o.points[2][1], s.length()), y = o.points[3];
        }
        return p.length && joinLines(s, E, p[0][0], r, i), s;
      }, OffsetPathModifier.prototype.processShapes = function(t) {
        var e, r, i = this.shapes.length, s, a, n = this.amount.v, l = this.miterLimit.v, o = this.lineJoin;
        if (n !== 0) {
          var p, y;
          for (r = 0; r < i; r += 1) {
            if (p = this.shapes[r], y = p.localShapeCollection, !(!p.shape._mdf && !this._mdf && !t)) for (y.releaseShapes(), p.shape._mdf = true, e = p.shape.paths.shapes, a = p.shape.paths._length, s = 0; s < a; s += 1) y.addShape(this.processPath(e[s], n, o, l));
            p.shape.paths = p.localShapeCollection;
          }
        }
        this.dynamicProperties.length || (this._mdf = false);
      };
      function getFontProperties(t) {
        for (var e = t.fStyle ? t.fStyle.split(" ") : [], r = "normal", i = "normal", s = e.length, a, n = 0; n < s; n += 1) switch (a = e[n].toLowerCase(), a) {
          case "italic":
            i = "italic";
            break;
          case "bold":
            r = "700";
            break;
          case "black":
            r = "900";
            break;
          case "medium":
            r = "500";
            break;
          case "regular":
          case "normal":
            r = "400";
            break;
          case "light":
          case "thin":
            r = "200";
            break;
        }
        return {
          style: i,
          weight: t.fWeight || r
        };
      }
      var FontManager = (function() {
        var t = 5e3, e = {
          w: 0,
          size: 0,
          shapes: [],
          data: {
            shapes: []
          }
        }, r = [];
        r = r.concat([
          2304,
          2305,
          2306,
          2307,
          2362,
          2363,
          2364,
          2364,
          2366,
          2367,
          2368,
          2369,
          2370,
          2371,
          2372,
          2373,
          2374,
          2375,
          2376,
          2377,
          2378,
          2379,
          2380,
          2381,
          2382,
          2383,
          2387,
          2388,
          2389,
          2390,
          2391,
          2402,
          2403
        ]);
        var i = 127988, s = 917631, a = 917601, n = 917626, l = 65039, o = 8205, p = 127462, y = 127487, E = [
          "d83cdffb",
          "d83cdffc",
          "d83cdffd",
          "d83cdffe",
          "d83cdfff"
        ];
        function u(k) {
          var M = k.split(","), S, P = M.length, V = [];
          for (S = 0; S < P; S += 1) M[S] !== "sans-serif" && M[S] !== "monospace" && V.push(M[S]);
          return V.join(",");
        }
        function x(k, M) {
          var S = createTag("span");
          S.setAttribute("aria-hidden", true), S.style.fontFamily = M;
          var P = createTag("span");
          P.innerText = "giItT1WQy@!-/#", S.style.position = "absolute", S.style.left = "-10000px", S.style.top = "-10000px", S.style.fontSize = "300px", S.style.fontVariant = "normal", S.style.fontStyle = "normal", S.style.fontWeight = "normal", S.style.letterSpacing = "0", S.appendChild(P), document.body.appendChild(S);
          var V = P.offsetWidth;
          return P.style.fontFamily = u(k) + ", " + M, {
            node: P,
            w: V,
            parent: S
          };
        }
        function g() {
          var k, M = this.fonts.length, S, P, V = M;
          for (k = 0; k < M; k += 1) this.fonts[k].loaded ? V -= 1 : this.fonts[k].fOrigin === "n" || this.fonts[k].origin === 0 ? this.fonts[k].loaded = true : (S = this.fonts[k].monoCase.node, P = this.fonts[k].monoCase.w, S.offsetWidth !== P ? (V -= 1, this.fonts[k].loaded = true) : (S = this.fonts[k].sansCase.node, P = this.fonts[k].sansCase.w, S.offsetWidth !== P && (V -= 1, this.fonts[k].loaded = true)), this.fonts[k].loaded && (this.fonts[k].sansCase.parent.parentNode.removeChild(this.fonts[k].sansCase.parent), this.fonts[k].monoCase.parent.parentNode.removeChild(this.fonts[k].monoCase.parent)));
          V !== 0 && Date.now() - this.initTime < t ? setTimeout(this.checkLoadedFontsBinded, 20) : setTimeout(this.setIsLoadedBinded, 10);
        }
        function d(k, M) {
          var S = document.body && M ? "svg" : "canvas", P, V = getFontProperties(k);
          if (S === "svg") {
            var F = createNS("text");
            F.style.fontSize = "100px", F.setAttribute("font-family", k.fFamily), F.setAttribute("font-style", V.style), F.setAttribute("font-weight", V.weight), F.textContent = "1", k.fClass ? (F.style.fontFamily = "inherit", F.setAttribute("class", k.fClass)) : F.style.fontFamily = k.fFamily, M.appendChild(F), P = F;
          } else {
            var B = new OffscreenCanvas(500, 500).getContext("2d");
            B.font = V.style + " " + V.weight + " 100px " + k.fFamily, P = B;
          }
          function G(z) {
            return S === "svg" ? (P.textContent = z, P.getComputedTextLength()) : P.measureText(z).width;
          }
          return {
            measureText: G
          };
        }
        function A(k, M) {
          if (!k) {
            this.isLoaded = true;
            return;
          }
          if (this.chars) {
            this.isLoaded = true, this.fonts = k.list;
            return;
          }
          if (!document.body) {
            this.isLoaded = true, k.list.forEach(function(Z) {
              Z.helper = d(Z), Z.cache = {};
            }), this.fonts = k.list;
            return;
          }
          var S = k.list, P, V = S.length, F = V;
          for (P = 0; P < V; P += 1) {
            var B = true, G, z;
            if (S[P].loaded = false, S[P].monoCase = x(S[P].fFamily, "monospace"), S[P].sansCase = x(S[P].fFamily, "sans-serif"), !S[P].fPath) S[P].loaded = true, F -= 1;
            else if (S[P].fOrigin === "p" || S[P].origin === 3) {
              if (G = document.querySelectorAll('style[f-forigin="p"][f-family="' + S[P].fFamily + '"], style[f-origin="3"][f-family="' + S[P].fFamily + '"]'), G.length > 0 && (B = false), B) {
                var q = createTag("style");
                q.setAttribute("f-forigin", S[P].fOrigin), q.setAttribute("f-origin", S[P].origin), q.setAttribute("f-family", S[P].fFamily), q.type = "text/css", q.innerText = "@font-face {font-family: " + S[P].fFamily + "; font-style: normal; src: url('" + S[P].fPath + "');}", M.appendChild(q);
              }
            } else if (S[P].fOrigin === "g" || S[P].origin === 1) {
              for (G = document.querySelectorAll('link[f-forigin="g"], link[f-origin="1"]'), z = 0; z < G.length; z += 1) G[z].href.indexOf(S[P].fPath) !== -1 && (B = false);
              if (B) {
                var $ = createTag("link");
                $.setAttribute("f-forigin", S[P].fOrigin), $.setAttribute("f-origin", S[P].origin), $.type = "text/css", $.rel = "stylesheet", $.href = S[P].fPath, document.body.appendChild($);
              }
            } else if (S[P].fOrigin === "t" || S[P].origin === 2) {
              for (G = document.querySelectorAll('script[f-forigin="t"], script[f-origin="2"]'), z = 0; z < G.length; z += 1) S[P].fPath === G[z].src && (B = false);
              if (B) {
                var X = createTag("link");
                X.setAttribute("f-forigin", S[P].fOrigin), X.setAttribute("f-origin", S[P].origin), X.setAttribute("rel", "stylesheet"), X.setAttribute("href", S[P].fPath), M.appendChild(X);
              }
            }
            S[P].helper = d(S[P], M), S[P].cache = {}, this.fonts.push(S[P]);
          }
          F === 0 ? this.isLoaded = true : setTimeout(this.checkLoadedFonts.bind(this), 100);
        }
        function c(k) {
          if (k) {
            this.chars || (this.chars = []);
            var M, S = k.length, P, V = this.chars.length, F;
            for (M = 0; M < S; M += 1) {
              for (P = 0, F = false; P < V; ) this.chars[P].style === k[M].style && this.chars[P].fFamily === k[M].fFamily && this.chars[P].ch === k[M].ch && (F = true), P += 1;
              F || (this.chars.push(k[M]), V += 1);
            }
          }
        }
        function m(k, M, S) {
          for (var P = 0, V = this.chars.length; P < V; ) {
            if (this.chars[P].ch === k && this.chars[P].style === M && this.chars[P].fFamily === S) return this.chars[P];
            P += 1;
          }
          return (typeof k == "string" && k.charCodeAt(0) !== 13 || !k) && console && console.warn && !this._warned && (this._warned = true, console.warn("Missing character from exported characters list: ", k, M, S)), e;
        }
        function f(k, M, S) {
          var P = this.getFontByName(M), V = k;
          if (!P.cache[V]) {
            var F = P.helper;
            if (k === " ") {
              var B = F.measureText("|" + k + "|"), G = F.measureText("||");
              P.cache[V] = (B - G) / 100;
            } else P.cache[V] = F.measureText(k) / 100;
          }
          return P.cache[V] * S;
        }
        function b(k) {
          for (var M = 0, S = this.fonts.length; M < S; ) {
            if (this.fonts[M].fName === k) return this.fonts[M];
            M += 1;
          }
          return this.fonts[0];
        }
        function C(k) {
          var M = 0, S = k.charCodeAt(0);
          if (S >= 55296 && S <= 56319) {
            var P = k.charCodeAt(1);
            P >= 56320 && P <= 57343 && (M = (S - 55296) * 1024 + P - 56320 + 65536);
          }
          return M;
        }
        function _(k, M) {
          var S = k.toString(16) + M.toString(16);
          return E.indexOf(S) !== -1;
        }
        function T(k) {
          return k === o;
        }
        function I(k) {
          return k === l;
        }
        function L(k) {
          var M = C(k);
          return M >= p && M <= y;
        }
        function j(k) {
          return L(k.substr(0, 2)) && L(k.substr(2, 2));
        }
        function O(k) {
          return r.indexOf(k) !== -1;
        }
        function D(k, M) {
          var S = C(k.substr(M, 2));
          if (S !== i) return false;
          var P = 0;
          for (M += 2; P < 5; ) {
            if (S = C(k.substr(M, 2)), S < a || S > n) return false;
            P += 1, M += 2;
          }
          return C(k.substr(M, 2)) === s;
        }
        function N() {
          this.isLoaded = true;
        }
        var H = function() {
          this.fonts = [], this.chars = null, this.typekitLoaded = 0, this.isLoaded = false, this._warned = false, this.initTime = Date.now(), this.setIsLoadedBinded = this.setIsLoaded.bind(this), this.checkLoadedFontsBinded = this.checkLoadedFonts.bind(this);
        };
        H.isModifier = _, H.isZeroWidthJoiner = T, H.isFlagEmoji = j, H.isRegionalCode = L, H.isCombinedCharacter = O, H.isRegionalFlag = D, H.isVariationSelector = I, H.BLACK_FLAG_CODE_POINT = i;
        var R = {
          addChars: c,
          addFonts: A,
          getCharData: m,
          getFontByName: b,
          measureText: f,
          checkLoadedFonts: g,
          setIsLoaded: N
        };
        return H.prototype = R, H;
      })();
      function SlotManager(t) {
        this.animationData = t;
      }
      SlotManager.prototype.getProp = function(t) {
        return this.animationData.slots && this.animationData.slots[t.sid] ? Object.assign(t, this.animationData.slots[t.sid].p) : t;
      };
      function slotFactory(t) {
        return new SlotManager(t);
      }
      function RenderableElement() {
      }
      RenderableElement.prototype = {
        initRenderable: function() {
          this.isInRange = false, this.hidden = false, this.isTransparent = false, this.renderableComponents = [];
        },
        addRenderableComponent: function(e) {
          this.renderableComponents.indexOf(e) === -1 && this.renderableComponents.push(e);
        },
        removeRenderableComponent: function(e) {
          this.renderableComponents.indexOf(e) !== -1 && this.renderableComponents.splice(this.renderableComponents.indexOf(e), 1);
        },
        prepareRenderableFrame: function(e) {
          this.checkLayerLimits(e);
        },
        checkTransparency: function() {
          this.finalTransform.mProp.o.v <= 0 ? !this.isTransparent && this.globalData.renderConfig.hideOnTransparent && (this.isTransparent = true, this.hide()) : this.isTransparent && (this.isTransparent = false, this.show());
        },
        checkLayerLimits: function(e) {
          this.data.ip - this.data.st <= e && this.data.op - this.data.st > e ? this.isInRange !== true && (this.globalData._mdf = true, this._mdf = true, this.isInRange = true, this.show()) : this.isInRange !== false && (this.globalData._mdf = true, this.isInRange = false, this.hide());
        },
        renderRenderable: function() {
          var e, r = this.renderableComponents.length;
          for (e = 0; e < r; e += 1) this.renderableComponents[e].renderFrame(this._isFirstFrame);
        },
        sourceRectAtTime: function() {
          return {
            top: 0,
            left: 0,
            width: 100,
            height: 100
          };
        },
        getLayerSize: function() {
          return this.data.ty === 5 ? {
            w: this.data.textData.width,
            h: this.data.textData.height
          } : {
            w: this.data.width,
            h: this.data.height
          };
        }
      };
      var getBlendMode = /* @__PURE__ */ (function() {
        var t = {
          0: "source-over",
          1: "multiply",
          2: "screen",
          3: "overlay",
          4: "darken",
          5: "lighten",
          6: "color-dodge",
          7: "color-burn",
          8: "hard-light",
          9: "soft-light",
          10: "difference",
          11: "exclusion",
          12: "hue",
          13: "saturation",
          14: "color",
          15: "luminosity"
        };
        return function(e) {
          return t[e] || "";
        };
      })();
      function SliderEffect(t, e, r) {
        this.p = PropertyFactory.getProp(e, t.v, 0, 0, r);
      }
      function AngleEffect(t, e, r) {
        this.p = PropertyFactory.getProp(e, t.v, 0, 0, r);
      }
      function ColorEffect(t, e, r) {
        this.p = PropertyFactory.getProp(e, t.v, 1, 0, r);
      }
      function PointEffect(t, e, r) {
        this.p = PropertyFactory.getProp(e, t.v, 1, 0, r);
      }
      function LayerIndexEffect(t, e, r) {
        this.p = PropertyFactory.getProp(e, t.v, 0, 0, r);
      }
      function MaskIndexEffect(t, e, r) {
        this.p = PropertyFactory.getProp(e, t.v, 0, 0, r);
      }
      function CheckboxEffect(t, e, r) {
        this.p = PropertyFactory.getProp(e, t.v, 0, 0, r);
      }
      function NoValueEffect() {
        this.p = {};
      }
      function EffectsManager(t, e) {
        var r = t.ef || [];
        this.effectElements = [];
        var i, s = r.length, a;
        for (i = 0; i < s; i += 1) a = new GroupEffect(r[i], e), this.effectElements.push(a);
      }
      function GroupEffect(t, e) {
        this.init(t, e);
      }
      extendPrototype([
        DynamicPropertyContainer
      ], GroupEffect), GroupEffect.prototype.getValue = GroupEffect.prototype.iterateDynamicProperties, GroupEffect.prototype.init = function(t, e) {
        this.data = t, this.effectElements = [], this.initDynamicPropertyContainer(e);
        var r, i = this.data.ef.length, s, a = this.data.ef;
        for (r = 0; r < i; r += 1) {
          switch (s = null, a[r].ty) {
            case 0:
              s = new SliderEffect(a[r], e, this);
              break;
            case 1:
              s = new AngleEffect(a[r], e, this);
              break;
            case 2:
              s = new ColorEffect(a[r], e, this);
              break;
            case 3:
              s = new PointEffect(a[r], e, this);
              break;
            case 4:
            case 7:
              s = new CheckboxEffect(a[r], e, this);
              break;
            case 10:
              s = new LayerIndexEffect(a[r], e, this);
              break;
            case 11:
              s = new MaskIndexEffect(a[r], e, this);
              break;
            case 5:
              s = new EffectsManager(a[r], e);
              break;
            default:
              s = new NoValueEffect(a[r]);
              break;
          }
          s && this.effectElements.push(s);
        }
      };
      function BaseElement() {
      }
      BaseElement.prototype = {
        checkMasks: function() {
          if (!this.data.hasMask) return false;
          for (var e = 0, r = this.data.masksProperties.length; e < r; ) {
            if (this.data.masksProperties[e].mode !== "n" && this.data.masksProperties[e].cl !== false) return true;
            e += 1;
          }
          return false;
        },
        initExpressions: function() {
          var e = getExpressionInterfaces();
          if (e) {
            var r = e("layer"), i = e("effects"), s = e("shape"), a = e("text"), n = e("comp");
            this.layerInterface = r(this), this.data.hasMask && this.maskManager && this.layerInterface.registerMaskInterface(this.maskManager);
            var l = i.createEffectsInterface(this, this.layerInterface);
            this.layerInterface.registerEffectsInterface(l), this.data.ty === 0 || this.data.xt ? this.compInterface = n(this) : this.data.ty === 4 ? (this.layerInterface.shapeInterface = s(this.shapesData, this.itemsData, this.layerInterface), this.layerInterface.content = this.layerInterface.shapeInterface) : this.data.ty === 5 && (this.layerInterface.textInterface = a(this), this.layerInterface.text = this.layerInterface.textInterface);
          }
        },
        setBlendMode: function() {
          var e = getBlendMode(this.data.bm), r = this.baseElement || this.layerElement;
          r.style["mix-blend-mode"] = e;
        },
        initBaseData: function(e, r, i) {
          this.globalData = r, this.comp = i, this.data = e, this.layerId = createElementID(), this.data.sr || (this.data.sr = 1), this.effectsManager = new EffectsManager(this.data, this, this.dynamicProperties);
        },
        getType: function() {
          return this.type;
        },
        sourceRectAtTime: function() {
        }
      };
      function FrameElement() {
      }
      FrameElement.prototype = {
        initFrame: function() {
          this._isFirstFrame = false, this.dynamicProperties = [], this._mdf = false;
        },
        prepareProperties: function(e, r) {
          var i, s = this.dynamicProperties.length;
          for (i = 0; i < s; i += 1) (r || this._isParent && this.dynamicProperties[i].propType === "transform") && (this.dynamicProperties[i].getValue(), this.dynamicProperties[i]._mdf && (this.globalData._mdf = true, this._mdf = true));
        },
        addDynamicProperty: function(e) {
          this.dynamicProperties.indexOf(e) === -1 && this.dynamicProperties.push(e);
        }
      };
      function FootageElement(t, e, r) {
        this.initFrame(), this.initRenderable(), this.assetData = e.getAssetData(t.refId), this.footageData = e.imageLoader.getAsset(this.assetData), this.initBaseData(t, e, r);
      }
      FootageElement.prototype.prepareFrame = function() {
      }, extendPrototype([
        RenderableElement,
        BaseElement,
        FrameElement
      ], FootageElement), FootageElement.prototype.getBaseElement = function() {
        return null;
      }, FootageElement.prototype.renderFrame = function() {
      }, FootageElement.prototype.destroy = function() {
      }, FootageElement.prototype.initExpressions = function() {
        var t = getExpressionInterfaces();
        if (t) {
          var e = t("footage");
          this.layerInterface = e(this);
        }
      }, FootageElement.prototype.getFootageData = function() {
        return this.footageData;
      };
      function AudioElement(t, e, r) {
        this.initFrame(), this.initRenderable(), this.assetData = e.getAssetData(t.refId), this.initBaseData(t, e, r), this._isPlaying = false, this._canPlay = false;
        var i = this.globalData.getAssetsPath(this.assetData);
        this.audio = this.globalData.audioController.createAudio(i), this._currentTime = 0, this.globalData.audioController.addAudio(this), this._volumeMultiplier = 1, this._volume = 1, this._previousVolume = null, this.tm = t.tm ? PropertyFactory.getProp(this, t.tm, 0, e.frameRate, this) : {
          _placeholder: true
        }, this.lv = PropertyFactory.getProp(this, t.au && t.au.lv ? t.au.lv : {
          k: [
            100
          ]
        }, 1, 0.01, this);
      }
      AudioElement.prototype.prepareFrame = function(t) {
        if (this.prepareRenderableFrame(t, true), this.prepareProperties(t, true), this.tm._placeholder) this._currentTime = t / this.data.sr;
        else {
          var e = this.tm.v;
          this._currentTime = e;
        }
        this._volume = this.lv.v[0];
        var r = this._volume * this._volumeMultiplier;
        this._previousVolume !== r && (this._previousVolume = r, this.audio.volume(r));
      }, extendPrototype([
        RenderableElement,
        BaseElement,
        FrameElement
      ], AudioElement), AudioElement.prototype.renderFrame = function() {
        this.isInRange && this._canPlay && (this._isPlaying ? (!this.audio.playing() || Math.abs(this._currentTime / this.globalData.frameRate - this.audio.seek()) > 0.1) && this.audio.seek(this._currentTime / this.globalData.frameRate) : (this.audio.play(), this.audio.seek(this._currentTime / this.globalData.frameRate), this._isPlaying = true));
      }, AudioElement.prototype.show = function() {
      }, AudioElement.prototype.hide = function() {
        this.audio.pause(), this._isPlaying = false;
      }, AudioElement.prototype.pause = function() {
        this.audio.pause(), this._isPlaying = false, this._canPlay = false;
      }, AudioElement.prototype.resume = function() {
        this._canPlay = true;
      }, AudioElement.prototype.setRate = function(t) {
        this.audio.rate(t);
      }, AudioElement.prototype.volume = function(t) {
        this._volumeMultiplier = t, this._previousVolume = t * this._volume, this.audio.volume(this._previousVolume);
      }, AudioElement.prototype.getBaseElement = function() {
        return null;
      }, AudioElement.prototype.destroy = function() {
      }, AudioElement.prototype.sourceRectAtTime = function() {
      }, AudioElement.prototype.initExpressions = function() {
      };
      function BaseRenderer() {
      }
      BaseRenderer.prototype.checkLayers = function(t) {
        var e, r = this.layers.length, i;
        for (this.completeLayers = true, e = r - 1; e >= 0; e -= 1) this.elements[e] || (i = this.layers[e], i.ip - i.st <= t - this.layers[e].st && i.op - i.st > t - this.layers[e].st && this.buildItem(e)), this.completeLayers = this.elements[e] ? this.completeLayers : false;
        this.checkPendingElements();
      }, BaseRenderer.prototype.createItem = function(t) {
        switch (t.ty) {
          case 2:
            return this.createImage(t);
          case 0:
            return this.createComp(t);
          case 1:
            return this.createSolid(t);
          case 3:
            return this.createNull(t);
          case 4:
            return this.createShape(t);
          case 5:
            return this.createText(t);
          case 6:
            return this.createAudio(t);
          case 13:
            return this.createCamera(t);
          case 15:
            return this.createFootage(t);
          default:
            return this.createNull(t);
        }
      }, BaseRenderer.prototype.createCamera = function() {
        throw new Error("You're using a 3d camera. Try the html renderer.");
      }, BaseRenderer.prototype.createAudio = function(t) {
        return new AudioElement(t, this.globalData, this);
      }, BaseRenderer.prototype.createFootage = function(t) {
        return new FootageElement(t, this.globalData, this);
      }, BaseRenderer.prototype.buildAllItems = function() {
        var t, e = this.layers.length;
        for (t = 0; t < e; t += 1) this.buildItem(t);
        this.checkPendingElements();
      }, BaseRenderer.prototype.includeLayers = function(t) {
        this.completeLayers = false;
        var e, r = t.length, i, s = this.layers.length;
        for (e = 0; e < r; e += 1) for (i = 0; i < s; ) {
          if (this.layers[i].id === t[e].id) {
            this.layers[i] = t[e];
            break;
          }
          i += 1;
        }
      }, BaseRenderer.prototype.setProjectInterface = function(t) {
        this.globalData.projectInterface = t;
      }, BaseRenderer.prototype.initItems = function() {
        this.globalData.progressiveLoad || this.buildAllItems();
      }, BaseRenderer.prototype.buildElementParenting = function(t, e, r) {
        for (var i = this.elements, s = this.layers, a = 0, n = s.length; a < n; ) s[a].ind == e && (!i[a] || i[a] === true ? (this.buildItem(a), this.addPendingElement(t)) : (r.push(i[a]), i[a].setAsParent(), s[a].parent !== void 0 ? this.buildElementParenting(t, s[a].parent, r) : t.setHierarchy(r))), a += 1;
      }, BaseRenderer.prototype.addPendingElement = function(t) {
        this.pendingElements.push(t);
      }, BaseRenderer.prototype.searchExtraCompositions = function(t) {
        var e, r = t.length;
        for (e = 0; e < r; e += 1) if (t[e].xt) {
          var i = this.createComp(t[e]);
          i.initExpressions(), this.globalData.projectInterface.registerComposition(i);
        }
      }, BaseRenderer.prototype.getElementById = function(t) {
        var e, r = this.elements.length;
        for (e = 0; e < r; e += 1) if (this.elements[e].data.ind === t) return this.elements[e];
        return null;
      }, BaseRenderer.prototype.getElementByPath = function(t) {
        var e = t.shift(), r;
        if (typeof e == "number") r = this.elements[e];
        else {
          var i, s = this.elements.length;
          for (i = 0; i < s; i += 1) if (this.elements[i].data.nm === e) {
            r = this.elements[i];
            break;
          }
        }
        return t.length === 0 ? r : r.getElementByPath(t);
      }, BaseRenderer.prototype.setupGlobalData = function(t, e) {
        this.globalData.fontManager = new FontManager(), this.globalData.slotManager = slotFactory(t), this.globalData.fontManager.addChars(t.chars), this.globalData.fontManager.addFonts(t.fonts, e), this.globalData.getAssetData = this.animationItem.getAssetData.bind(this.animationItem), this.globalData.getAssetsPath = this.animationItem.getAssetsPath.bind(this.animationItem), this.globalData.imageLoader = this.animationItem.imagePreloader, this.globalData.audioController = this.animationItem.audioController, this.globalData.frameId = 0, this.globalData.frameRate = t.fr, this.globalData.nm = t.nm, this.globalData.compSize = {
          w: t.w,
          h: t.h
        };
      };
      var effectTypes = {
        TRANSFORM_EFFECT: "transformEFfect"
      };
      function TransformElement() {
      }
      TransformElement.prototype = {
        initTransform: function() {
          var e = new Matrix();
          this.finalTransform = {
            mProp: this.data.ks ? TransformPropertyFactory.getTransformProperty(this, this.data.ks, this) : {
              o: 0
            },
            _matMdf: false,
            _localMatMdf: false,
            _opMdf: false,
            mat: e,
            localMat: e,
            localOpacity: 1
          }, this.data.ao && (this.finalTransform.mProp.autoOriented = true), this.data.ty;
        },
        renderTransform: function() {
          if (this.finalTransform._opMdf = this.finalTransform.mProp.o._mdf || this._isFirstFrame, this.finalTransform._matMdf = this.finalTransform.mProp._mdf || this._isFirstFrame, this.hierarchy) {
            var e, r = this.finalTransform.mat, i = 0, s = this.hierarchy.length;
            if (!this.finalTransform._matMdf) for (; i < s; ) {
              if (this.hierarchy[i].finalTransform.mProp._mdf) {
                this.finalTransform._matMdf = true;
                break;
              }
              i += 1;
            }
            if (this.finalTransform._matMdf) for (e = this.finalTransform.mProp.v.props, r.cloneFromProps(e), i = 0; i < s; i += 1) r.multiply(this.hierarchy[i].finalTransform.mProp.v);
          }
          (!this.localTransforms || this.finalTransform._matMdf) && (this.finalTransform._localMatMdf = this.finalTransform._matMdf), this.finalTransform._opMdf && (this.finalTransform.localOpacity = this.finalTransform.mProp.o.v);
        },
        renderLocalTransform: function() {
          if (this.localTransforms) {
            var e = 0, r = this.localTransforms.length;
            if (this.finalTransform._localMatMdf = this.finalTransform._matMdf, !this.finalTransform._localMatMdf || !this.finalTransform._opMdf) for (; e < r; ) this.localTransforms[e]._mdf && (this.finalTransform._localMatMdf = true), this.localTransforms[e]._opMdf && !this.finalTransform._opMdf && (this.finalTransform.localOpacity = this.finalTransform.mProp.o.v, this.finalTransform._opMdf = true), e += 1;
            if (this.finalTransform._localMatMdf) {
              var i = this.finalTransform.localMat;
              for (this.localTransforms[0].matrix.clone(i), e = 1; e < r; e += 1) {
                var s = this.localTransforms[e].matrix;
                i.multiply(s);
              }
              i.multiply(this.finalTransform.mat);
            }
            if (this.finalTransform._opMdf) {
              var a = this.finalTransform.localOpacity;
              for (e = 0; e < r; e += 1) a *= this.localTransforms[e].opacity * 0.01;
              this.finalTransform.localOpacity = a;
            }
          }
        },
        searchEffectTransforms: function() {
          if (this.renderableEffectsManager) {
            var e = this.renderableEffectsManager.getEffects(effectTypes.TRANSFORM_EFFECT);
            if (e.length) {
              this.localTransforms = [], this.finalTransform.localMat = new Matrix();
              var r = 0, i = e.length;
              for (r = 0; r < i; r += 1) this.localTransforms.push(e[r]);
            }
          }
        },
        globalToLocal: function(e) {
          var r = [];
          r.push(this.finalTransform);
          for (var i = true, s = this.comp; i; ) s.finalTransform ? (s.data.hasMask && r.splice(0, 0, s.finalTransform), s = s.comp) : i = false;
          var a, n = r.length, l;
          for (a = 0; a < n; a += 1) l = r[a].mat.applyToPointArray(0, 0, 0), e = [
            e[0] - l[0],
            e[1] - l[1],
            0
          ];
          return e;
        },
        mHelper: new Matrix()
      };
      function MaskElement(t, e, r) {
        this.data = t, this.element = e, this.globalData = r, this.storedData = [], this.masksProperties = this.data.masksProperties || [], this.maskElement = null;
        var i = this.globalData.defs, s, a = this.masksProperties ? this.masksProperties.length : 0;
        this.viewData = createSizedArray(a), this.solidPath = "";
        var n, l = this.masksProperties, o = 0, p = [], y, E, u = createElementID(), x, g, d, A, c = "clipPath", m = "clip-path";
        for (s = 0; s < a; s += 1) if ((l[s].mode !== "a" && l[s].mode !== "n" || l[s].inv || l[s].o.k !== 100 || l[s].o.x) && (c = "mask", m = "mask"), (l[s].mode === "s" || l[s].mode === "i") && o === 0 ? (x = createNS("rect"), x.setAttribute("fill", "#ffffff"), x.setAttribute("width", this.element.comp.data.w || 0), x.setAttribute("height", this.element.comp.data.h || 0), p.push(x)) : x = null, n = createNS("path"), l[s].mode === "n") this.viewData[s] = {
          op: PropertyFactory.getProp(this.element, l[s].o, 0, 0.01, this.element),
          prop: ShapePropertyFactory.getShapeProp(this.element, l[s], 3),
          elem: n,
          lastPath: ""
        }, i.appendChild(n);
        else {
          o += 1, n.setAttribute("fill", l[s].mode === "s" ? "#000000" : "#ffffff"), n.setAttribute("clip-rule", "nonzero");
          var f;
          if (l[s].x.k !== 0 ? (c = "mask", m = "mask", A = PropertyFactory.getProp(this.element, l[s].x, 0, null, this.element), f = createElementID(), g = createNS("filter"), g.setAttribute("id", f), d = createNS("feMorphology"), d.setAttribute("operator", "erode"), d.setAttribute("in", "SourceGraphic"), d.setAttribute("radius", "0"), g.appendChild(d), i.appendChild(g), n.setAttribute("stroke", l[s].mode === "s" ? "#000000" : "#ffffff")) : (d = null, A = null), this.storedData[s] = {
            elem: n,
            x: A,
            expan: d,
            lastPath: "",
            lastOperator: "",
            filterId: f,
            lastRadius: 0
          }, l[s].mode === "i") {
            E = p.length;
            var b = createNS("g");
            for (y = 0; y < E; y += 1) b.appendChild(p[y]);
            var C = createNS("mask");
            C.setAttribute("mask-type", "alpha"), C.setAttribute("id", u + "_" + o), C.appendChild(n), i.appendChild(C), b.setAttribute("mask", "url(" + getLocationHref() + "#" + u + "_" + o + ")"), p.length = 0, p.push(b);
          } else p.push(n);
          l[s].inv && !this.solidPath && (this.solidPath = this.createLayerSolidPath()), this.viewData[s] = {
            elem: n,
            lastPath: "",
            op: PropertyFactory.getProp(this.element, l[s].o, 0, 0.01, this.element),
            prop: ShapePropertyFactory.getShapeProp(this.element, l[s], 3),
            invRect: x
          }, this.viewData[s].prop.k || this.drawPath(l[s], this.viewData[s].prop.v, this.viewData[s]);
        }
        for (this.maskElement = createNS(c), a = p.length, s = 0; s < a; s += 1) this.maskElement.appendChild(p[s]);
        o > 0 && (this.maskElement.setAttribute("id", u), this.element.maskedElement.setAttribute(m, "url(" + getLocationHref() + "#" + u + ")"), i.appendChild(this.maskElement)), this.viewData.length && this.element.addRenderableComponent(this);
      }
      MaskElement.prototype.getMaskProperty = function(t) {
        return this.viewData[t].prop;
      }, MaskElement.prototype.renderFrame = function(t) {
        var e = this.element.finalTransform.mat, r, i = this.masksProperties.length;
        for (r = 0; r < i; r += 1) if ((this.viewData[r].prop._mdf || t) && this.drawPath(this.masksProperties[r], this.viewData[r].prop.v, this.viewData[r]), (this.viewData[r].op._mdf || t) && this.viewData[r].elem.setAttribute("fill-opacity", this.viewData[r].op.v), this.masksProperties[r].mode !== "n" && (this.viewData[r].invRect && (this.element.finalTransform.mProp._mdf || t) && this.viewData[r].invRect.setAttribute("transform", e.getInverseMatrix().to2dCSS()), this.storedData[r].x && (this.storedData[r].x._mdf || t))) {
          var s = this.storedData[r].expan;
          this.storedData[r].x.v < 0 ? (this.storedData[r].lastOperator !== "erode" && (this.storedData[r].lastOperator = "erode", this.storedData[r].elem.setAttribute("filter", "url(" + getLocationHref() + "#" + this.storedData[r].filterId + ")")), s.setAttribute("radius", -this.storedData[r].x.v)) : (this.storedData[r].lastOperator !== "dilate" && (this.storedData[r].lastOperator = "dilate", this.storedData[r].elem.setAttribute("filter", null)), this.storedData[r].elem.setAttribute("stroke-width", this.storedData[r].x.v * 2));
        }
      }, MaskElement.prototype.getMaskelement = function() {
        return this.maskElement;
      }, MaskElement.prototype.createLayerSolidPath = function() {
        var t = "M0,0 ";
        return t += " h" + this.globalData.compSize.w, t += " v" + this.globalData.compSize.h, t += " h-" + this.globalData.compSize.w, t += " v-" + this.globalData.compSize.h + " ", t;
      }, MaskElement.prototype.drawPath = function(t, e, r) {
        var i = " M" + e.v[0][0] + "," + e.v[0][1], s, a;
        for (a = e._length, s = 1; s < a; s += 1) i += " C" + e.o[s - 1][0] + "," + e.o[s - 1][1] + " " + e.i[s][0] + "," + e.i[s][1] + " " + e.v[s][0] + "," + e.v[s][1];
        if (e.c && a > 1 && (i += " C" + e.o[s - 1][0] + "," + e.o[s - 1][1] + " " + e.i[0][0] + "," + e.i[0][1] + " " + e.v[0][0] + "," + e.v[0][1]), r.lastPath !== i) {
          var n = "";
          r.elem && (e.c && (n = t.inv ? this.solidPath + i : i), r.elem.setAttribute("d", n)), r.lastPath = i;
        }
      }, MaskElement.prototype.destroy = function() {
        this.element = null, this.globalData = null, this.maskElement = null, this.data = null, this.masksProperties = null;
      };
      var filtersFactory = (function() {
        var t = {};
        t.createFilter = e, t.createAlphaToLuminanceFilter = r;
        function e(i, s) {
          var a = createNS("filter");
          return a.setAttribute("id", i), s !== true && (a.setAttribute("filterUnits", "objectBoundingBox"), a.setAttribute("x", "0%"), a.setAttribute("y", "0%"), a.setAttribute("width", "100%"), a.setAttribute("height", "100%")), a;
        }
        function r() {
          var i = createNS("feColorMatrix");
          return i.setAttribute("type", "matrix"), i.setAttribute("color-interpolation-filters", "sRGB"), i.setAttribute("values", "0 0 0 1 0  0 0 0 1 0  0 0 0 1 0  0 0 0 1 1"), i;
        }
        return t;
      })(), featureSupport = (function() {
        var t = {
          maskType: true,
          svgLumaHidden: true,
          offscreenCanvas: typeof OffscreenCanvas < "u"
        };
        return (/MSIE 10/i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge\/\d./i.test(navigator.userAgent)) && (t.maskType = false), /firefox/i.test(navigator.userAgent) && (t.svgLumaHidden = false), t;
      })(), registeredEffects$1 = {}, idPrefix = "filter_result_";
      function SVGEffects(t) {
        var e, r = "SourceGraphic", i = t.data.ef ? t.data.ef.length : 0, s = createElementID(), a = filtersFactory.createFilter(s, true), n = 0;
        this.filters = [];
        var l;
        for (e = 0; e < i; e += 1) {
          l = null;
          var o = t.data.ef[e].ty;
          if (registeredEffects$1[o]) {
            var p = registeredEffects$1[o].effect;
            l = new p(a, t.effectsManager.effectElements[e], t, idPrefix + n, r), r = idPrefix + n, registeredEffects$1[o].countsAsEffect && (n += 1);
          }
          l && this.filters.push(l);
        }
        n && (t.globalData.defs.appendChild(a), t.layerElement.setAttribute("filter", "url(" + getLocationHref() + "#" + s + ")")), this.filters.length && t.addRenderableComponent(this);
      }
      SVGEffects.prototype.renderFrame = function(t) {
        var e, r = this.filters.length;
        for (e = 0; e < r; e += 1) this.filters[e].renderFrame(t);
      }, SVGEffects.prototype.getEffects = function(t) {
        var e, r = this.filters.length, i = [];
        for (e = 0; e < r; e += 1) this.filters[e].type === t && i.push(this.filters[e]);
        return i;
      };
      function registerEffect$1(t, e, r) {
        registeredEffects$1[t] = {
          effect: e,
          countsAsEffect: r
        };
      }
      function SVGBaseElement() {
      }
      SVGBaseElement.prototype = {
        initRendererElement: function() {
          this.layerElement = createNS("g");
        },
        createContainerElements: function() {
          this.matteElement = createNS("g"), this.transformedElement = this.layerElement, this.maskedElement = this.layerElement, this._sizeChanged = false;
          var e = null;
          if (this.data.td) {
            this.matteMasks = {};
            var r = createNS("g");
            r.setAttribute("id", this.layerId), r.appendChild(this.layerElement), e = r, this.globalData.defs.appendChild(r);
          } else this.data.tt ? (this.matteElement.appendChild(this.layerElement), e = this.matteElement, this.baseElement = this.matteElement) : this.baseElement = this.layerElement;
          if (this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), this.data.ty === 0 && !this.data.hd) {
            var i = createNS("clipPath"), s = createNS("path");
            s.setAttribute("d", "M0,0 L" + this.data.w + ",0 L" + this.data.w + "," + this.data.h + " L0," + this.data.h + "z");
            var a = createElementID();
            if (i.setAttribute("id", a), i.appendChild(s), this.globalData.defs.appendChild(i), this.checkMasks()) {
              var n = createNS("g");
              n.setAttribute("clip-path", "url(" + getLocationHref() + "#" + a + ")"), n.appendChild(this.layerElement), this.transformedElement = n, e ? e.appendChild(this.transformedElement) : this.baseElement = this.transformedElement;
            } else this.layerElement.setAttribute("clip-path", "url(" + getLocationHref() + "#" + a + ")");
          }
          this.data.bm !== 0 && this.setBlendMode();
        },
        renderElement: function() {
          this.finalTransform._localMatMdf && this.transformedElement.setAttribute("transform", this.finalTransform.localMat.to2dCSS()), this.finalTransform._opMdf && this.transformedElement.setAttribute("opacity", this.finalTransform.localOpacity);
        },
        destroyBaseElement: function() {
          this.layerElement = null, this.matteElement = null, this.maskManager.destroy();
        },
        getBaseElement: function() {
          return this.data.hd ? null : this.baseElement;
        },
        createRenderableComponents: function() {
          this.maskManager = new MaskElement(this.data, this, this.globalData), this.renderableEffectsManager = new SVGEffects(this), this.searchEffectTransforms();
        },
        getMatte: function(e) {
          if (this.matteMasks || (this.matteMasks = {}), !this.matteMasks[e]) {
            var r = this.layerId + "_" + e, i, s, a, n;
            if (e === 1 || e === 3) {
              var l = createNS("mask");
              l.setAttribute("id", r), l.setAttribute("mask-type", e === 3 ? "luminance" : "alpha"), a = createNS("use"), a.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#" + this.layerId), l.appendChild(a), this.globalData.defs.appendChild(l), !featureSupport.maskType && e === 1 && (l.setAttribute("mask-type", "luminance"), i = createElementID(), s = filtersFactory.createFilter(i), this.globalData.defs.appendChild(s), s.appendChild(filtersFactory.createAlphaToLuminanceFilter()), n = createNS("g"), n.appendChild(a), l.appendChild(n), n.setAttribute("filter", "url(" + getLocationHref() + "#" + i + ")"));
            } else if (e === 2) {
              var o = createNS("mask");
              o.setAttribute("id", r), o.setAttribute("mask-type", "alpha");
              var p = createNS("g");
              o.appendChild(p), i = createElementID(), s = filtersFactory.createFilter(i);
              var y = createNS("feComponentTransfer");
              y.setAttribute("in", "SourceGraphic"), s.appendChild(y);
              var E = createNS("feFuncA");
              E.setAttribute("type", "table"), E.setAttribute("tableValues", "1.0 0.0"), y.appendChild(E), this.globalData.defs.appendChild(s);
              var u = createNS("rect");
              u.setAttribute("width", this.comp.data.w), u.setAttribute("height", this.comp.data.h), u.setAttribute("x", "0"), u.setAttribute("y", "0"), u.setAttribute("fill", "#ffffff"), u.setAttribute("opacity", "0"), p.setAttribute("filter", "url(" + getLocationHref() + "#" + i + ")"), p.appendChild(u), a = createNS("use"), a.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#" + this.layerId), p.appendChild(a), featureSupport.maskType || (o.setAttribute("mask-type", "luminance"), s.appendChild(filtersFactory.createAlphaToLuminanceFilter()), n = createNS("g"), p.appendChild(u), n.appendChild(this.layerElement), p.appendChild(n)), this.globalData.defs.appendChild(o);
            }
            this.matteMasks[e] = r;
          }
          return this.matteMasks[e];
        },
        setMatte: function(e) {
          this.matteElement && this.matteElement.setAttribute("mask", "url(" + getLocationHref() + "#" + e + ")");
        }
      };
      function HierarchyElement() {
      }
      HierarchyElement.prototype = {
        initHierarchy: function() {
          this.hierarchy = [], this._isParent = false, this.checkParenting();
        },
        setHierarchy: function(e) {
          this.hierarchy = e;
        },
        setAsParent: function() {
          this._isParent = true;
        },
        checkParenting: function() {
          this.data.parent !== void 0 && this.comp.buildElementParenting(this, this.data.parent, []);
        }
      };
      function RenderableDOMElement() {
      }
      (function() {
        var t = {
          initElement: function(r, i, s) {
            this.initFrame(), this.initBaseData(r, i, s), this.initTransform(r, i, s), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide();
          },
          hide: function() {
            if (!this.hidden && (!this.isInRange || this.isTransparent)) {
              var r = this.baseElement || this.layerElement;
              r.style.display = "none", this.hidden = true;
            }
          },
          show: function() {
            if (this.isInRange && !this.isTransparent) {
              if (!this.data.hd) {
                var r = this.baseElement || this.layerElement;
                r.style.display = "block";
              }
              this.hidden = false, this._isFirstFrame = true;
            }
          },
          renderFrame: function() {
            this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderLocalTransform(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = false));
          },
          renderInnerContent: function() {
          },
          prepareFrame: function(r) {
            this._mdf = false, this.prepareRenderableFrame(r), this.prepareProperties(r, this.isInRange), this.checkTransparency();
          },
          destroy: function() {
            this.innerElem = null, this.destroyBaseElement();
          }
        };
        extendPrototype([
          RenderableElement,
          createProxyFunction(t)
        ], RenderableDOMElement);
      })();
      function IImageElement(t, e, r) {
        this.assetData = e.getAssetData(t.refId), this.assetData && this.assetData.sid && (this.assetData = e.slotManager.getProp(this.assetData)), this.initElement(t, e, r), this.sourceRect = {
          top: 0,
          left: 0,
          width: this.assetData.w,
          height: this.assetData.h
        };
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        SVGBaseElement,
        HierarchyElement,
        FrameElement,
        RenderableDOMElement
      ], IImageElement), IImageElement.prototype.createContent = function() {
        var t = this.globalData.getAssetsPath(this.assetData);
        this.innerElem = createNS("image"), this.innerElem.setAttribute("width", this.assetData.w + "px"), this.innerElem.setAttribute("height", this.assetData.h + "px"), this.innerElem.setAttribute("preserveAspectRatio", this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio), this.innerElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", t), this.layerElement.appendChild(this.innerElem);
      }, IImageElement.prototype.sourceRectAtTime = function() {
        return this.sourceRect;
      };
      function ProcessedElement(t, e) {
        this.elem = t, this.pos = e;
      }
      function IShapeElement() {
      }
      IShapeElement.prototype = {
        addShapeToModifiers: function(e) {
          var r, i = this.shapeModifiers.length;
          for (r = 0; r < i; r += 1) this.shapeModifiers[r].addShape(e);
        },
        isShapeInAnimatedModifiers: function(e) {
          for (var r = 0, i = this.shapeModifiers.length; r < i; ) if (this.shapeModifiers[r].isAnimatedWithShape(e)) return true;
          return false;
        },
        renderModifiers: function() {
          if (this.shapeModifiers.length) {
            var e, r = this.shapes.length;
            for (e = 0; e < r; e += 1) this.shapes[e].sh.reset();
            r = this.shapeModifiers.length;
            var i;
            for (e = r - 1; e >= 0 && (i = this.shapeModifiers[e].processShapes(this._isFirstFrame), !i); e -= 1) ;
          }
        },
        searchProcessedElement: function(e) {
          for (var r = this.processedElements, i = 0, s = r.length; i < s; ) {
            if (r[i].elem === e) return r[i].pos;
            i += 1;
          }
          return 0;
        },
        addProcessedElement: function(e, r) {
          for (var i = this.processedElements, s = i.length; s; ) if (s -= 1, i[s].elem === e) {
            i[s].pos = r;
            return;
          }
          i.push(new ProcessedElement(e, r));
        },
        prepareFrame: function(e) {
          this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange);
        }
      };
      var lineCapEnum = {
        1: "butt",
        2: "round",
        3: "square"
      }, lineJoinEnum = {
        1: "miter",
        2: "round",
        3: "bevel"
      };
      function SVGShapeData(t, e, r) {
        this.caches = [], this.styles = [], this.transformers = t, this.lStr = "", this.sh = r, this.lvl = e, this._isAnimated = !!r.k;
        for (var i = 0, s = t.length; i < s; ) {
          if (t[i].mProps.dynamicProperties.length) {
            this._isAnimated = true;
            break;
          }
          i += 1;
        }
      }
      SVGShapeData.prototype.setAsAnimated = function() {
        this._isAnimated = true;
      };
      function SVGStyleData(t, e) {
        this.data = t, this.type = t.ty, this.d = "", this.lvl = e, this._mdf = false, this.closed = t.hd === true, this.pElem = createNS("path"), this.msElem = null;
      }
      SVGStyleData.prototype.reset = function() {
        this.d = "", this._mdf = false;
      };
      function DashProperty(t, e, r, i) {
        this.elem = t, this.frameId = -1, this.dataProps = createSizedArray(e.length), this.renderer = r, this.k = false, this.dashStr = "", this.dashArray = createTypedArray("float32", e.length ? e.length - 1 : 0), this.dashoffset = createTypedArray("float32", 1), this.initDynamicPropertyContainer(i);
        var s, a = e.length || 0, n;
        for (s = 0; s < a; s += 1) n = PropertyFactory.getProp(t, e[s].v, 0, 0, this), this.k = n.k || this.k, this.dataProps[s] = {
          n: e[s].n,
          p: n
        };
        this.k || this.getValue(true), this._isAnimated = this.k;
      }
      DashProperty.prototype.getValue = function(t) {
        if (!(this.elem.globalData.frameId === this.frameId && !t) && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf = this._mdf || t, this._mdf)) {
          var e = 0, r = this.dataProps.length;
          for (this.renderer === "svg" && (this.dashStr = ""), e = 0; e < r; e += 1) this.dataProps[e].n !== "o" ? this.renderer === "svg" ? this.dashStr += " " + this.dataProps[e].p.v : this.dashArray[e] = this.dataProps[e].p.v : this.dashoffset[0] = this.dataProps[e].p.v;
        }
      }, extendPrototype([
        DynamicPropertyContainer
      ], DashProperty);
      function SVGStrokeStyleData(t, e, r) {
        this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(t, e.o, 0, 0.01, this), this.w = PropertyFactory.getProp(t, e.w, 0, null, this), this.d = new DashProperty(t, e.d || {}, "svg", this), this.c = PropertyFactory.getProp(t, e.c, 1, 255, this), this.style = r, this._isAnimated = !!this._isAnimated;
      }
      extendPrototype([
        DynamicPropertyContainer
      ], SVGStrokeStyleData);
      function SVGFillStyleData(t, e, r) {
        this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(t, e.o, 0, 0.01, this), this.c = PropertyFactory.getProp(t, e.c, 1, 255, this), this.style = r;
      }
      extendPrototype([
        DynamicPropertyContainer
      ], SVGFillStyleData);
      function SVGNoStyleData(t, e, r) {
        this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.style = r;
      }
      extendPrototype([
        DynamicPropertyContainer
      ], SVGNoStyleData);
      function GradientProperty(t, e, r) {
        this.data = e, this.c = createTypedArray("uint8c", e.p * 4);
        var i = e.k.k[0].s ? e.k.k[0].s.length - e.p * 4 : e.k.k.length - e.p * 4;
        this.o = createTypedArray("float32", i), this._cmdf = false, this._omdf = false, this._collapsable = this.checkCollapsable(), this._hasOpacity = i, this.initDynamicPropertyContainer(r), this.prop = PropertyFactory.getProp(t, e.k, 1, null, this), this.k = this.prop.k, this.getValue(true);
      }
      GradientProperty.prototype.comparePoints = function(t, e) {
        for (var r = 0, i = this.o.length / 2, s; r < i; ) {
          if (s = Math.abs(t[r * 4] - t[e * 4 + r * 2]), s > 0.01) return false;
          r += 1;
        }
        return true;
      }, GradientProperty.prototype.checkCollapsable = function() {
        if (this.o.length / 2 !== this.c.length / 4) return false;
        if (this.data.k.k[0].s) for (var t = 0, e = this.data.k.k.length; t < e; ) {
          if (!this.comparePoints(this.data.k.k[t].s, this.data.p)) return false;
          t += 1;
        }
        else if (!this.comparePoints(this.data.k.k, this.data.p)) return false;
        return true;
      }, GradientProperty.prototype.getValue = function(t) {
        if (this.prop.getValue(), this._mdf = false, this._cmdf = false, this._omdf = false, this.prop._mdf || t) {
          var e, r = this.data.p * 4, i, s;
          for (e = 0; e < r; e += 1) i = e % 4 === 0 ? 100 : 255, s = Math.round(this.prop.v[e] * i), this.c[e] !== s && (this.c[e] = s, this._cmdf = !t);
          if (this.o.length) for (r = this.prop.v.length, e = this.data.p * 4; e < r; e += 1) i = e % 2 === 0 ? 100 : 1, s = e % 2 === 0 ? Math.round(this.prop.v[e] * 100) : this.prop.v[e], this.o[e - this.data.p * 4] !== s && (this.o[e - this.data.p * 4] = s, this._omdf = !t);
          this._mdf = !t;
        }
      }, extendPrototype([
        DynamicPropertyContainer
      ], GradientProperty);
      function SVGGradientFillStyleData(t, e, r) {
        this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.initGradientData(t, e, r);
      }
      SVGGradientFillStyleData.prototype.initGradientData = function(t, e, r) {
        this.o = PropertyFactory.getProp(t, e.o, 0, 0.01, this), this.s = PropertyFactory.getProp(t, e.s, 1, null, this), this.e = PropertyFactory.getProp(t, e.e, 1, null, this), this.h = PropertyFactory.getProp(t, e.h || {
          k: 0
        }, 0, 0.01, this), this.a = PropertyFactory.getProp(t, e.a || {
          k: 0
        }, 0, degToRads, this), this.g = new GradientProperty(t, e.g, this), this.style = r, this.stops = [], this.setGradientData(r.pElem, e), this.setGradientOpacity(e, r), this._isAnimated = !!this._isAnimated;
      }, SVGGradientFillStyleData.prototype.setGradientData = function(t, e) {
        var r = createElementID(), i = createNS(e.t === 1 ? "linearGradient" : "radialGradient");
        i.setAttribute("id", r), i.setAttribute("spreadMethod", "pad"), i.setAttribute("gradientUnits", "userSpaceOnUse");
        var s = [], a, n, l;
        for (l = e.g.p * 4, n = 0; n < l; n += 4) a = createNS("stop"), i.appendChild(a), s.push(a);
        t.setAttribute(e.ty === "gf" ? "fill" : "stroke", "url(" + getLocationHref() + "#" + r + ")"), this.gf = i, this.cst = s;
      }, SVGGradientFillStyleData.prototype.setGradientOpacity = function(t, e) {
        if (this.g._hasOpacity && !this.g._collapsable) {
          var r, i, s, a = createNS("mask"), n = createNS("path");
          a.appendChild(n);
          var l = createElementID(), o = createElementID();
          a.setAttribute("id", o);
          var p = createNS(t.t === 1 ? "linearGradient" : "radialGradient");
          p.setAttribute("id", l), p.setAttribute("spreadMethod", "pad"), p.setAttribute("gradientUnits", "userSpaceOnUse"), s = t.g.k.k[0].s ? t.g.k.k[0].s.length : t.g.k.k.length;
          var y = this.stops;
          for (i = t.g.p * 4; i < s; i += 2) r = createNS("stop"), r.setAttribute("stop-color", "rgb(255,255,255)"), p.appendChild(r), y.push(r);
          n.setAttribute(t.ty === "gf" ? "fill" : "stroke", "url(" + getLocationHref() + "#" + l + ")"), t.ty === "gs" && (n.setAttribute("stroke-linecap", lineCapEnum[t.lc || 2]), n.setAttribute("stroke-linejoin", lineJoinEnum[t.lj || 2]), t.lj === 1 && n.setAttribute("stroke-miterlimit", t.ml)), this.of = p, this.ms = a, this.ost = y, this.maskId = o, e.msElem = n;
        }
      }, extendPrototype([
        DynamicPropertyContainer
      ], SVGGradientFillStyleData);
      function SVGGradientStrokeStyleData(t, e, r) {
        this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.w = PropertyFactory.getProp(t, e.w, 0, null, this), this.d = new DashProperty(t, e.d || {}, "svg", this), this.initGradientData(t, e, r), this._isAnimated = !!this._isAnimated;
      }
      extendPrototype([
        SVGGradientFillStyleData,
        DynamicPropertyContainer
      ], SVGGradientStrokeStyleData);
      function ShapeGroupData() {
        this.it = [], this.prevViewData = [], this.gr = createNS("g");
      }
      function SVGTransformData(t, e, r) {
        this.transform = {
          mProps: t,
          op: e,
          container: r
        }, this.elements = [], this._isAnimated = this.transform.mProps.dynamicProperties.length || this.transform.op.effectsSequence.length;
      }
      var buildShapeString = function(e, r, i, s) {
        if (r === 0) return "";
        var a = e.o, n = e.i, l = e.v, o, p = " M" + s.applyToPointStringified(l[0][0], l[0][1]);
        for (o = 1; o < r; o += 1) p += " C" + s.applyToPointStringified(a[o - 1][0], a[o - 1][1]) + " " + s.applyToPointStringified(n[o][0], n[o][1]) + " " + s.applyToPointStringified(l[o][0], l[o][1]);
        return i && r && (p += " C" + s.applyToPointStringified(a[o - 1][0], a[o - 1][1]) + " " + s.applyToPointStringified(n[0][0], n[0][1]) + " " + s.applyToPointStringified(l[0][0], l[0][1]), p += "z"), p;
      }, SVGElementsRenderer = (function() {
        var t = new Matrix(), e = new Matrix(), r = {
          createRenderFunction: i
        };
        function i(E) {
          switch (E.ty) {
            case "fl":
              return l;
            case "gf":
              return p;
            case "gs":
              return o;
            case "st":
              return y;
            case "sh":
            case "el":
            case "rc":
            case "sr":
              return n;
            case "tr":
              return s;
            case "no":
              return a;
            default:
              return null;
          }
        }
        function s(E, u, x) {
          (x || u.transform.op._mdf) && u.transform.container.setAttribute("opacity", u.transform.op.v), (x || u.transform.mProps._mdf) && u.transform.container.setAttribute("transform", u.transform.mProps.v.to2dCSS());
        }
        function a() {
        }
        function n(E, u, x) {
          var g, d, A, c, m, f, b = u.styles.length, C = u.lvl, _, T, I, L;
          for (f = 0; f < b; f += 1) {
            if (c = u.sh._mdf || x, u.styles[f].lvl < C) {
              for (T = e.reset(), I = C - u.styles[f].lvl, L = u.transformers.length - 1; !c && I > 0; ) c = u.transformers[L].mProps._mdf || c, I -= 1, L -= 1;
              if (c) for (I = C - u.styles[f].lvl, L = u.transformers.length - 1; I > 0; ) T.multiply(u.transformers[L].mProps.v), I -= 1, L -= 1;
            } else T = t;
            if (_ = u.sh.paths, d = _._length, c) {
              for (A = "", g = 0; g < d; g += 1) m = _.shapes[g], m && m._length && (A += buildShapeString(m, m._length, m.c, T));
              u.caches[f] = A;
            } else A = u.caches[f];
            u.styles[f].d += E.hd === true ? "" : A, u.styles[f]._mdf = c || u.styles[f]._mdf;
          }
        }
        function l(E, u, x) {
          var g = u.style;
          (u.c._mdf || x) && g.pElem.setAttribute("fill", "rgb(" + bmFloor(u.c.v[0]) + "," + bmFloor(u.c.v[1]) + "," + bmFloor(u.c.v[2]) + ")"), (u.o._mdf || x) && g.pElem.setAttribute("fill-opacity", u.o.v);
        }
        function o(E, u, x) {
          p(E, u, x), y(E, u, x);
        }
        function p(E, u, x) {
          var g = u.gf, d = u.g._hasOpacity, A = u.s.v, c = u.e.v;
          if (u.o._mdf || x) {
            var m = E.ty === "gf" ? "fill-opacity" : "stroke-opacity";
            u.style.pElem.setAttribute(m, u.o.v);
          }
          if (u.s._mdf || x) {
            var f = E.t === 1 ? "x1" : "cx", b = f === "x1" ? "y1" : "cy";
            g.setAttribute(f, A[0]), g.setAttribute(b, A[1]), d && !u.g._collapsable && (u.of.setAttribute(f, A[0]), u.of.setAttribute(b, A[1]));
          }
          var C, _, T, I;
          if (u.g._cmdf || x) {
            C = u.cst;
            var L = u.g.c;
            for (T = C.length, _ = 0; _ < T; _ += 1) I = C[_], I.setAttribute("offset", L[_ * 4] + "%"), I.setAttribute("stop-color", "rgb(" + L[_ * 4 + 1] + "," + L[_ * 4 + 2] + "," + L[_ * 4 + 3] + ")");
          }
          if (d && (u.g._omdf || x)) {
            var j = u.g.o;
            for (u.g._collapsable ? C = u.cst : C = u.ost, T = C.length, _ = 0; _ < T; _ += 1) I = C[_], u.g._collapsable || I.setAttribute("offset", j[_ * 2] + "%"), I.setAttribute("stop-opacity", j[_ * 2 + 1]);
          }
          if (E.t === 1) (u.e._mdf || x) && (g.setAttribute("x2", c[0]), g.setAttribute("y2", c[1]), d && !u.g._collapsable && (u.of.setAttribute("x2", c[0]), u.of.setAttribute("y2", c[1])));
          else {
            var O;
            if ((u.s._mdf || u.e._mdf || x) && (O = Math.sqrt(Math.pow(A[0] - c[0], 2) + Math.pow(A[1] - c[1], 2)), g.setAttribute("r", O), d && !u.g._collapsable && u.of.setAttribute("r", O)), u.s._mdf || u.e._mdf || u.h._mdf || u.a._mdf || x) {
              O || (O = Math.sqrt(Math.pow(A[0] - c[0], 2) + Math.pow(A[1] - c[1], 2)));
              var D = Math.atan2(c[1] - A[1], c[0] - A[0]), N = u.h.v;
              N >= 1 ? N = 0.99 : N <= -1 && (N = -0.99);
              var H = O * N, R = Math.cos(D + u.a.v) * H + A[0], k = Math.sin(D + u.a.v) * H + A[1];
              g.setAttribute("fx", R), g.setAttribute("fy", k), d && !u.g._collapsable && (u.of.setAttribute("fx", R), u.of.setAttribute("fy", k));
            }
          }
        }
        function y(E, u, x) {
          var g = u.style, d = u.d;
          d && (d._mdf || x) && d.dashStr && (g.pElem.setAttribute("stroke-dasharray", d.dashStr), g.pElem.setAttribute("stroke-dashoffset", d.dashoffset[0])), u.c && (u.c._mdf || x) && g.pElem.setAttribute("stroke", "rgb(" + bmFloor(u.c.v[0]) + "," + bmFloor(u.c.v[1]) + "," + bmFloor(u.c.v[2]) + ")"), (u.o._mdf || x) && g.pElem.setAttribute("stroke-opacity", u.o.v), (u.w._mdf || x) && (g.pElem.setAttribute("stroke-width", u.w.v), g.msElem && g.msElem.setAttribute("stroke-width", u.w.v));
        }
        return r;
      })();
      function SVGShapeElement(t, e, r) {
        this.shapes = [], this.shapesData = t.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.initElement(t, e, r), this.prevViewData = [];
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        SVGBaseElement,
        IShapeElement,
        HierarchyElement,
        FrameElement,
        RenderableDOMElement
      ], SVGShapeElement), SVGShapeElement.prototype.initSecondaryElement = function() {
      }, SVGShapeElement.prototype.identityMatrix = new Matrix(), SVGShapeElement.prototype.buildExpressionInterface = function() {
      }, SVGShapeElement.prototype.createContent = function() {
        this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], true), this.filterUniqueShapes();
      }, SVGShapeElement.prototype.filterUniqueShapes = function() {
        var t, e = this.shapes.length, r, i, s = this.stylesList.length, a, n = [], l = false;
        for (i = 0; i < s; i += 1) {
          for (a = this.stylesList[i], l = false, n.length = 0, t = 0; t < e; t += 1) r = this.shapes[t], r.styles.indexOf(a) !== -1 && (n.push(r), l = r._isAnimated || l);
          n.length > 1 && l && this.setShapesAsAnimated(n);
        }
      }, SVGShapeElement.prototype.setShapesAsAnimated = function(t) {
        var e, r = t.length;
        for (e = 0; e < r; e += 1) t[e].setAsAnimated();
      }, SVGShapeElement.prototype.createStyleElement = function(t, e) {
        var r, i = new SVGStyleData(t, e), s = i.pElem;
        if (t.ty === "st") r = new SVGStrokeStyleData(this, t, i);
        else if (t.ty === "fl") r = new SVGFillStyleData(this, t, i);
        else if (t.ty === "gf" || t.ty === "gs") {
          var a = t.ty === "gf" ? SVGGradientFillStyleData : SVGGradientStrokeStyleData;
          r = new a(this, t, i), this.globalData.defs.appendChild(r.gf), r.maskId && (this.globalData.defs.appendChild(r.ms), this.globalData.defs.appendChild(r.of), s.setAttribute("mask", "url(" + getLocationHref() + "#" + r.maskId + ")"));
        } else t.ty === "no" && (r = new SVGNoStyleData(this, t, i));
        return (t.ty === "st" || t.ty === "gs") && (s.setAttribute("stroke-linecap", lineCapEnum[t.lc || 2]), s.setAttribute("stroke-linejoin", lineJoinEnum[t.lj || 2]), s.setAttribute("fill-opacity", "0"), t.lj === 1 && s.setAttribute("stroke-miterlimit", t.ml)), t.r === 2 && s.setAttribute("fill-rule", "evenodd"), t.ln && s.setAttribute("id", t.ln), t.cl && s.setAttribute("class", t.cl), t.bm && (s.style["mix-blend-mode"] = getBlendMode(t.bm)), this.stylesList.push(i), this.addToAnimatedContents(t, r), r;
      }, SVGShapeElement.prototype.createGroupElement = function(t) {
        var e = new ShapeGroupData();
        return t.ln && e.gr.setAttribute("id", t.ln), t.cl && e.gr.setAttribute("class", t.cl), t.bm && (e.gr.style["mix-blend-mode"] = getBlendMode(t.bm)), e;
      }, SVGShapeElement.prototype.createTransformElement = function(t, e) {
        var r = TransformPropertyFactory.getTransformProperty(this, t, this), i = new SVGTransformData(r, r.o, e);
        return this.addToAnimatedContents(t, i), i;
      }, SVGShapeElement.prototype.createShapeElement = function(t, e, r) {
        var i = 4;
        t.ty === "rc" ? i = 5 : t.ty === "el" ? i = 6 : t.ty === "sr" && (i = 7);
        var s = ShapePropertyFactory.getShapeProp(this, t, i, this), a = new SVGShapeData(e, r, s);
        return this.shapes.push(a), this.addShapeToModifiers(a), this.addToAnimatedContents(t, a), a;
      }, SVGShapeElement.prototype.addToAnimatedContents = function(t, e) {
        for (var r = 0, i = this.animatedContents.length; r < i; ) {
          if (this.animatedContents[r].element === e) return;
          r += 1;
        }
        this.animatedContents.push({
          fn: SVGElementsRenderer.createRenderFunction(t),
          element: e,
          data: t
        });
      }, SVGShapeElement.prototype.setElementStyles = function(t) {
        var e = t.styles, r, i = this.stylesList.length;
        for (r = 0; r < i; r += 1) e.indexOf(this.stylesList[r]) === -1 && !this.stylesList[r].closed && e.push(this.stylesList[r]);
      }, SVGShapeElement.prototype.reloadShapes = function() {
        this._isFirstFrame = true;
        var t, e = this.itemsData.length;
        for (t = 0; t < e; t += 1) this.prevViewData[t] = this.itemsData[t];
        for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], true), this.filterUniqueShapes(), e = this.dynamicProperties.length, t = 0; t < e; t += 1) this.dynamicProperties[t].getValue();
        this.renderModifiers();
      }, SVGShapeElement.prototype.searchShapes = function(t, e, r, i, s, a, n) {
        var l = [].concat(a), o, p = t.length - 1, y, E, u = [], x = [], g, d, A;
        for (o = p; o >= 0; o -= 1) {
          if (A = this.searchProcessedElement(t[o]), A ? e[o] = r[A - 1] : t[o]._render = n, t[o].ty === "fl" || t[o].ty === "st" || t[o].ty === "gf" || t[o].ty === "gs" || t[o].ty === "no") A ? e[o].style.closed = t[o].hd : e[o] = this.createStyleElement(t[o], s), t[o]._render && e[o].style.pElem.parentNode !== i && i.appendChild(e[o].style.pElem), u.push(e[o].style);
          else if (t[o].ty === "gr") {
            if (!A) e[o] = this.createGroupElement(t[o]);
            else for (E = e[o].it.length, y = 0; y < E; y += 1) e[o].prevViewData[y] = e[o].it[y];
            this.searchShapes(t[o].it, e[o].it, e[o].prevViewData, e[o].gr, s + 1, l, n), t[o]._render && e[o].gr.parentNode !== i && i.appendChild(e[o].gr);
          } else t[o].ty === "tr" ? (A || (e[o] = this.createTransformElement(t[o], i)), g = e[o].transform, l.push(g)) : t[o].ty === "sh" || t[o].ty === "rc" || t[o].ty === "el" || t[o].ty === "sr" ? (A || (e[o] = this.createShapeElement(t[o], l, s)), this.setElementStyles(e[o])) : t[o].ty === "tm" || t[o].ty === "rd" || t[o].ty === "ms" || t[o].ty === "pb" || t[o].ty === "zz" || t[o].ty === "op" ? (A ? (d = e[o], d.closed = false) : (d = ShapeModifiers.getModifier(t[o].ty), d.init(this, t[o]), e[o] = d, this.shapeModifiers.push(d)), x.push(d)) : t[o].ty === "rp" && (A ? (d = e[o], d.closed = true) : (d = ShapeModifiers.getModifier(t[o].ty), e[o] = d, d.init(this, t, o, e), this.shapeModifiers.push(d), n = false), x.push(d));
          this.addProcessedElement(t[o], o + 1);
        }
        for (p = u.length, o = 0; o < p; o += 1) u[o].closed = true;
        for (p = x.length, o = 0; o < p; o += 1) x[o].closed = true;
      }, SVGShapeElement.prototype.renderInnerContent = function() {
        this.renderModifiers();
        var t, e = this.stylesList.length;
        for (t = 0; t < e; t += 1) this.stylesList[t].reset();
        for (this.renderShape(), t = 0; t < e; t += 1) (this.stylesList[t]._mdf || this._isFirstFrame) && (this.stylesList[t].msElem && (this.stylesList[t].msElem.setAttribute("d", this.stylesList[t].d), this.stylesList[t].d = "M0 0" + this.stylesList[t].d), this.stylesList[t].pElem.setAttribute("d", this.stylesList[t].d || "M0 0"));
      }, SVGShapeElement.prototype.renderShape = function() {
        var t, e = this.animatedContents.length, r;
        for (t = 0; t < e; t += 1) r = this.animatedContents[t], (this._isFirstFrame || r.element._isAnimated) && r.data !== true && r.fn(r.data, r.element, this._isFirstFrame);
      }, SVGShapeElement.prototype.destroy = function() {
        this.destroyBaseElement(), this.shapesData = null, this.itemsData = null;
      };
      function LetterProps(t, e, r, i, s, a) {
        this.o = t, this.sw = e, this.sc = r, this.fc = i, this.m = s, this.p = a, this._mdf = {
          o: true,
          sw: !!e,
          sc: !!r,
          fc: !!i,
          m: true,
          p: true
        };
      }
      LetterProps.prototype.update = function(t, e, r, i, s, a) {
        this._mdf.o = false, this._mdf.sw = false, this._mdf.sc = false, this._mdf.fc = false, this._mdf.m = false, this._mdf.p = false;
        var n = false;
        return this.o !== t && (this.o = t, this._mdf.o = true, n = true), this.sw !== e && (this.sw = e, this._mdf.sw = true, n = true), this.sc !== r && (this.sc = r, this._mdf.sc = true, n = true), this.fc !== i && (this.fc = i, this._mdf.fc = true, n = true), this.m !== s && (this.m = s, this._mdf.m = true, n = true), a.length && (this.p[0] !== a[0] || this.p[1] !== a[1] || this.p[4] !== a[4] || this.p[5] !== a[5] || this.p[12] !== a[12] || this.p[13] !== a[13]) && (this.p = a, this._mdf.p = true, n = true), n;
      };
      function TextProperty(t, e) {
        this._frameId = initialDefaultFrame, this.pv = "", this.v = "", this.kf = false, this._isFirstFrame = true, this._mdf = false, e.d && e.d.sid && (e.d = t.globalData.slotManager.getProp(e.d)), this.data = e, this.elem = t, this.comp = this.elem.comp, this.keysIndex = 0, this.canResize = false, this.minimumFontSize = 1, this.effectsSequence = [], this.currentData = {
          ascent: 0,
          boxWidth: this.defaultBoxWidth,
          f: "",
          fStyle: "",
          fWeight: "",
          fc: "",
          j: "",
          justifyOffset: "",
          l: [],
          lh: 0,
          lineWidths: [],
          ls: "",
          of: "",
          s: "",
          sc: "",
          sw: 0,
          t: 0,
          tr: 0,
          sz: 0,
          ps: null,
          fillColorAnim: false,
          strokeColorAnim: false,
          strokeWidthAnim: false,
          yOffset: 0,
          finalSize: 0,
          finalText: [],
          finalLineHeight: 0,
          __complete: false
        }, this.copyData(this.currentData, this.data.d.k[0].s), this.searchProperty() || this.completeTextData(this.currentData);
      }
      TextProperty.prototype.defaultBoxWidth = [
        0,
        0
      ], TextProperty.prototype.copyData = function(t, e) {
        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
        return t;
      }, TextProperty.prototype.setCurrentData = function(t) {
        t.__complete || this.completeTextData(t), this.currentData = t, this.currentData.boxWidth = this.currentData.boxWidth || this.defaultBoxWidth, this._mdf = true;
      }, TextProperty.prototype.searchProperty = function() {
        return this.searchKeyframes();
      }, TextProperty.prototype.searchKeyframes = function() {
        return this.kf = this.data.d.k.length > 1, this.kf && this.addEffect(this.getKeyframeValue.bind(this)), this.kf;
      }, TextProperty.prototype.addEffect = function(t) {
        this.effectsSequence.push(t), this.elem.addDynamicProperty(this);
      }, TextProperty.prototype.getValue = function(t) {
        if (!((this.elem.globalData.frameId === this.frameId || !this.effectsSequence.length) && !t)) {
          this.currentData.t = this.data.d.k[this.keysIndex].s.t;
          var e = this.currentData, r = this.keysIndex;
          if (this.lock) {
            this.setCurrentData(this.currentData);
            return;
          }
          this.lock = true, this._mdf = false;
          var i, s = this.effectsSequence.length, a = t || this.data.d.k[this.keysIndex].s;
          for (i = 0; i < s; i += 1) r !== this.keysIndex ? a = this.effectsSequence[i](a, a.t) : a = this.effectsSequence[i](this.currentData, a.t);
          e !== a && this.setCurrentData(a), this.v = this.currentData, this.pv = this.v, this.lock = false, this.frameId = this.elem.globalData.frameId;
        }
      }, TextProperty.prototype.getKeyframeValue = function() {
        for (var t = this.data.d.k, e = this.elem.comp.renderedFrame, r = 0, i = t.length; r <= i - 1 && !(r === i - 1 || t[r + 1].t > e); ) r += 1;
        return this.keysIndex !== r && (this.keysIndex = r), this.data.d.k[this.keysIndex].s;
      }, TextProperty.prototype.buildFinalText = function(t) {
        for (var e = [], r = 0, i = t.length, s, a, n = false, l = false, o = ""; r < i; ) n = l, l = false, s = t.charCodeAt(r), o = t.charAt(r), FontManager.isCombinedCharacter(s) ? n = true : s >= 55296 && s <= 56319 ? FontManager.isRegionalFlag(t, r) ? o = t.substr(r, 14) : (a = t.charCodeAt(r + 1), a >= 56320 && a <= 57343 && (FontManager.isModifier(s, a) ? (o = t.substr(r, 2), n = true) : FontManager.isFlagEmoji(t.substr(r, 4)) ? o = t.substr(r, 4) : o = t.substr(r, 2))) : s > 56319 ? (a = t.charCodeAt(r + 1), FontManager.isVariationSelector(s) && (n = true)) : FontManager.isZeroWidthJoiner(s) && (n = true, l = true), n ? (e[e.length - 1] += o, n = false) : e.push(o), r += o.length;
        return e;
      }, TextProperty.prototype.completeTextData = function(t) {
        t.__complete = true;
        var e = this.elem.globalData.fontManager, r = this.data, i = [], s, a, n, l = 0, o, p = r.m.g, y = 0, E = 0, u = 0, x = [], g = 0, d = 0, A, c, m = e.getFontByName(t.f), f, b = 0, C = getFontProperties(m);
        t.fWeight = C.weight, t.fStyle = C.style, t.finalSize = t.s, t.finalText = this.buildFinalText(t.t), a = t.finalText.length, t.finalLineHeight = t.lh;
        var _ = t.tr / 1e3 * t.finalSize, T;
        if (t.sz) for (var I = true, L = t.sz[0], j = t.sz[1], O, D; I; ) {
          D = this.buildFinalText(t.t), O = 0, g = 0, a = D.length, _ = t.tr / 1e3 * t.finalSize;
          var N = -1;
          for (s = 0; s < a; s += 1) T = D[s].charCodeAt(0), n = false, D[s] === " " ? N = s : (T === 13 || T === 3) && (g = 0, n = true, O += t.finalLineHeight || t.finalSize * 1.2), e.chars ? (f = e.getCharData(D[s], m.fStyle, m.fFamily), b = n ? 0 : f.w * t.finalSize / 100) : b = e.measureText(D[s], t.f, t.finalSize), g + b > L && D[s] !== " " ? (N === -1 ? a += 1 : s = N, O += t.finalLineHeight || t.finalSize * 1.2, D.splice(s, N === s ? 1 : 0, "\r"), N = -1, g = 0) : (g += b, g += _);
          O += m.ascent * t.finalSize / 100, this.canResize && t.finalSize > this.minimumFontSize && j < O ? (t.finalSize -= 1, t.finalLineHeight = t.finalSize * t.lh / t.s) : (t.finalText = D, a = t.finalText.length, I = false);
        }
        g = -_, b = 0;
        var H = 0, R;
        for (s = 0; s < a; s += 1) if (n = false, R = t.finalText[s], T = R.charCodeAt(0), T === 13 || T === 3 ? (H = 0, x.push(g), d = g > d ? g : d, g = -2 * _, o = "", n = true, u += 1) : o = R, e.chars ? (f = e.getCharData(R, m.fStyle, e.getFontByName(t.f).fFamily), b = n ? 0 : f.w * t.finalSize / 100) : b = e.measureText(o, t.f, t.finalSize), R === " " ? H += b + _ : (g += b + _ + H, H = 0), i.push({
          l: b,
          an: b,
          add: y,
          n,
          anIndexes: [],
          val: o,
          line: u,
          animatorJustifyOffset: 0
        }), p == 2) {
          if (y += b, o === "" || o === " " || s === a - 1) {
            for ((o === "" || o === " ") && (y -= b); E <= s; ) i[E].an = y, i[E].ind = l, i[E].extra = b, E += 1;
            l += 1, y = 0;
          }
        } else if (p == 3) {
          if (y += b, o === "" || s === a - 1) {
            for (o === "" && (y -= b); E <= s; ) i[E].an = y, i[E].ind = l, i[E].extra = b, E += 1;
            y = 0, l += 1;
          }
        } else i[l].ind = l, i[l].extra = 0, l += 1;
        if (t.l = i, d = g > d ? g : d, x.push(g), t.sz) t.boxWidth = t.sz[0], t.justifyOffset = 0;
        else switch (t.boxWidth = d, t.j) {
          case 1:
            t.justifyOffset = -t.boxWidth;
            break;
          case 2:
            t.justifyOffset = -t.boxWidth / 2;
            break;
          default:
            t.justifyOffset = 0;
        }
        t.lineWidths = x;
        var k = r.a, M, S;
        c = k.length;
        var P, V, F = [];
        for (A = 0; A < c; A += 1) {
          for (M = k[A], M.a.sc && (t.strokeColorAnim = true), M.a.sw && (t.strokeWidthAnim = true), (M.a.fc || M.a.fh || M.a.fs || M.a.fb) && (t.fillColorAnim = true), V = 0, P = M.s.b, s = 0; s < a; s += 1) S = i[s], S.anIndexes[A] = V, (P == 1 && S.val !== "" || P == 2 && S.val !== "" && S.val !== " " || P == 3 && (S.n || S.val == " " || s == a - 1) || P == 4 && (S.n || s == a - 1)) && (M.s.rn === 1 && F.push(V), V += 1);
          r.a[A].s.totalChars = V;
          var B = -1, G;
          if (M.s.rn === 1) for (s = 0; s < a; s += 1) S = i[s], B != S.anIndexes[A] && (B = S.anIndexes[A], G = F.splice(Math.floor(Math.random() * F.length), 1)[0]), S.anIndexes[A] = G;
        }
        t.yOffset = t.finalLineHeight || t.finalSize * 1.2, t.ls = t.ls || 0, t.ascent = m.ascent * t.finalSize / 100;
      }, TextProperty.prototype.updateDocumentData = function(t, e) {
        e = e === void 0 ? this.keysIndex : e;
        var r = this.copyData({}, this.data.d.k[e].s);
        r = this.copyData(r, t), this.data.d.k[e].s = r, this.recalculate(e), this.setCurrentData(r), this.elem.addDynamicProperty(this);
      }, TextProperty.prototype.recalculate = function(t) {
        var e = this.data.d.k[t].s;
        e.__complete = false, this.keysIndex = 0, this._isFirstFrame = true, this.getValue(e);
      }, TextProperty.prototype.canResizeFont = function(t) {
        this.canResize = t, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this);
      }, TextProperty.prototype.setMinimumFontSize = function(t) {
        this.minimumFontSize = Math.floor(t) || 1, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this);
      };
      var TextSelectorProp = (function() {
        var t = Math.max, e = Math.min, r = Math.floor;
        function i(a, n) {
          this._currentTextLength = -1, this.k = false, this.data = n, this.elem = a, this.comp = a.comp, this.finalS = 0, this.finalE = 0, this.initDynamicPropertyContainer(a), this.s = PropertyFactory.getProp(a, n.s || {
            k: 0
          }, 0, 0, this), "e" in n ? this.e = PropertyFactory.getProp(a, n.e, 0, 0, this) : this.e = {
            v: 100
          }, this.o = PropertyFactory.getProp(a, n.o || {
            k: 0
          }, 0, 0, this), this.xe = PropertyFactory.getProp(a, n.xe || {
            k: 0
          }, 0, 0, this), this.ne = PropertyFactory.getProp(a, n.ne || {
            k: 0
          }, 0, 0, this), this.sm = PropertyFactory.getProp(a, n.sm || {
            k: 100
          }, 0, 0, this), this.a = PropertyFactory.getProp(a, n.a, 0, 0.01, this), this.dynamicProperties.length || this.getValue();
        }
        i.prototype = {
          getMult: function(n) {
            this._currentTextLength !== this.elem.textProperty.currentData.l.length && this.getValue();
            var l = 0, o = 0, p = 1, y = 1;
            this.ne.v > 0 ? l = this.ne.v / 100 : o = -this.ne.v / 100, this.xe.v > 0 ? p = 1 - this.xe.v / 100 : y = 1 + this.xe.v / 100;
            var E = BezierFactory.getBezierEasing(l, o, p, y).get, u = 0, x = this.finalS, g = this.finalE, d = this.data.sh;
            if (d === 2) g === x ? u = n >= g ? 1 : 0 : u = t(0, e(0.5 / (g - x) + (n - x) / (g - x), 1)), u = E(u);
            else if (d === 3) g === x ? u = n >= g ? 0 : 1 : u = 1 - t(0, e(0.5 / (g - x) + (n - x) / (g - x), 1)), u = E(u);
            else if (d === 4) g === x ? u = 0 : (u = t(0, e(0.5 / (g - x) + (n - x) / (g - x), 1)), u < 0.5 ? u *= 2 : u = 1 - 2 * (u - 0.5)), u = E(u);
            else if (d === 5) {
              if (g === x) u = 0;
              else {
                var A = g - x;
                n = e(t(0, n + 0.5 - x), g - x);
                var c = -A / 2 + n, m = A / 2;
                u = Math.sqrt(1 - c * c / (m * m));
              }
              u = E(u);
            } else d === 6 ? (g === x ? u = 0 : (n = e(t(0, n + 0.5 - x), g - x), u = (1 + Math.cos(Math.PI + Math.PI * 2 * n / (g - x))) / 2), u = E(u)) : (n >= r(x) && (n - x < 0 ? u = t(0, e(e(g, 1) - (x - n), 1)) : u = t(0, e(g - n, 1))), u = E(u));
            if (this.sm.v !== 100) {
              var f = this.sm.v * 0.01;
              f === 0 && (f = 1e-8);
              var b = 0.5 - f * 0.5;
              u < b ? u = 0 : (u = (u - b) / f, u > 1 && (u = 1));
            }
            return u * this.a.v;
          },
          getValue: function(n) {
            this.iterateDynamicProperties(), this._mdf = n || this._mdf, this._currentTextLength = this.elem.textProperty.currentData.l.length || 0, n && this.data.r === 2 && (this.e.v = this._currentTextLength);
            var l = this.data.r === 2 ? 1 : 100 / this.data.totalChars, o = this.o.v / l, p = this.s.v / l + o, y = this.e.v / l + o;
            if (p > y) {
              var E = p;
              p = y, y = E;
            }
            this.finalS = p, this.finalE = y;
          }
        }, extendPrototype([
          DynamicPropertyContainer
        ], i);
        function s(a, n, l) {
          return new i(a, n);
        }
        return {
          getTextSelectorProp: s
        };
      })();
      function TextAnimatorDataProperty(t, e, r) {
        var i = {
          propType: false
        }, s = PropertyFactory.getProp, a = e.a;
        this.a = {
          r: a.r ? s(t, a.r, 0, degToRads, r) : i,
          rx: a.rx ? s(t, a.rx, 0, degToRads, r) : i,
          ry: a.ry ? s(t, a.ry, 0, degToRads, r) : i,
          sk: a.sk ? s(t, a.sk, 0, degToRads, r) : i,
          sa: a.sa ? s(t, a.sa, 0, degToRads, r) : i,
          s: a.s ? s(t, a.s, 1, 0.01, r) : i,
          a: a.a ? s(t, a.a, 1, 0, r) : i,
          o: a.o ? s(t, a.o, 0, 0.01, r) : i,
          p: a.p ? s(t, a.p, 1, 0, r) : i,
          sw: a.sw ? s(t, a.sw, 0, 0, r) : i,
          sc: a.sc ? s(t, a.sc, 1, 0, r) : i,
          fc: a.fc ? s(t, a.fc, 1, 0, r) : i,
          fh: a.fh ? s(t, a.fh, 0, 0, r) : i,
          fs: a.fs ? s(t, a.fs, 0, 0.01, r) : i,
          fb: a.fb ? s(t, a.fb, 0, 0.01, r) : i,
          t: a.t ? s(t, a.t, 0, 0, r) : i
        }, this.s = TextSelectorProp.getTextSelectorProp(t, e.s, r), this.s.t = e.s.t;
      }
      function TextAnimatorProperty(t, e, r) {
        this._isFirstFrame = true, this._hasMaskedPath = false, this._frameId = -1, this._textData = t, this._renderType = e, this._elem = r, this._animatorsData = createSizedArray(this._textData.a.length), this._pathData = {}, this._moreOptions = {
          alignment: {}
        }, this.renderedLetters = [], this.lettersChangedFlag = false, this.initDynamicPropertyContainer(r);
      }
      TextAnimatorProperty.prototype.searchProperties = function() {
        var t, e = this._textData.a.length, r, i = PropertyFactory.getProp;
        for (t = 0; t < e; t += 1) r = this._textData.a[t], this._animatorsData[t] = new TextAnimatorDataProperty(this._elem, r, this);
        this._textData.p && "m" in this._textData.p ? (this._pathData = {
          a: i(this._elem, this._textData.p.a, 0, 0, this),
          f: i(this._elem, this._textData.p.f, 0, 0, this),
          l: i(this._elem, this._textData.p.l, 0, 0, this),
          r: i(this._elem, this._textData.p.r, 0, 0, this),
          p: i(this._elem, this._textData.p.p, 0, 0, this),
          m: this._elem.maskManager.getMaskProperty(this._textData.p.m)
        }, this._hasMaskedPath = true) : this._hasMaskedPath = false, this._moreOptions.alignment = i(this._elem, this._textData.m.a, 1, 0, this);
      }, TextAnimatorProperty.prototype.getMeasures = function(t, e) {
        if (this.lettersChangedFlag = e, !(!this._mdf && !this._isFirstFrame && !e && (!this._hasMaskedPath || !this._pathData.m._mdf))) {
          this._isFirstFrame = false;
          var r = this._moreOptions.alignment.v, i = this._animatorsData, s = this._textData, a = this.mHelper, n = this._renderType, l = this.renderedLetters.length, o, p, y, E, u = t.l, x, g, d, A, c, m, f, b, C, _, T, I, L, j, O;
          if (this._hasMaskedPath) {
            if (O = this._pathData.m, !this._pathData.n || this._pathData._mdf) {
              var D = O.v;
              this._pathData.r.v && (D = D.reverse()), x = {
                tLength: 0,
                segments: []
              }, E = D._length - 1;
              var N;
              for (I = 0, y = 0; y < E; y += 1) N = bez.buildBezierData(D.v[y], D.v[y + 1], [
                D.o[y][0] - D.v[y][0],
                D.o[y][1] - D.v[y][1]
              ], [
                D.i[y + 1][0] - D.v[y + 1][0],
                D.i[y + 1][1] - D.v[y + 1][1]
              ]), x.tLength += N.segmentLength, x.segments.push(N), I += N.segmentLength;
              y = E, O.v.c && (N = bez.buildBezierData(D.v[y], D.v[0], [
                D.o[y][0] - D.v[y][0],
                D.o[y][1] - D.v[y][1]
              ], [
                D.i[0][0] - D.v[0][0],
                D.i[0][1] - D.v[0][1]
              ]), x.tLength += N.segmentLength, x.segments.push(N), I += N.segmentLength), this._pathData.pi = x;
            }
            if (x = this._pathData.pi, g = this._pathData.f.v, f = 0, m = 1, A = 0, c = true, _ = x.segments, g < 0 && O.v.c) for (x.tLength < Math.abs(g) && (g = -Math.abs(g) % x.tLength), f = _.length - 1, C = _[f].points, m = C.length - 1; g < 0; ) g += C[m].partialLength, m -= 1, m < 0 && (f -= 1, C = _[f].points, m = C.length - 1);
            C = _[f].points, b = C[m - 1], d = C[m], T = d.partialLength;
          }
          E = u.length, o = 0, p = 0;
          var H = t.finalSize * 1.2 * 0.714, R = true, k, M, S, P, V;
          P = i.length;
          var F, B = -1, G, z, q, $ = g, X = f, Z = m, rt = -1, J, K, Q, Y, W, st, ht, at, it = "", nt = this.defaultPropsArray, ot;
          if (t.j === 2 || t.j === 1) {
            var U = 0, lt = 0, ft = t.j === 2 ? -0.5 : -1, tt = 0, pt = true;
            for (y = 0; y < E; y += 1) if (u[y].n) {
              for (U && (U += lt); tt < y; ) u[tt].animatorJustifyOffset = U, tt += 1;
              U = 0, pt = true;
            } else {
              for (S = 0; S < P; S += 1) k = i[S].a, k.t.propType && (pt && t.j === 2 && (lt += k.t.v * ft), M = i[S].s, F = M.getMult(u[y].anIndexes[S], s.a[S].s.totalChars), F.length ? U += k.t.v * F[0] * ft : U += k.t.v * F * ft);
              pt = false;
            }
            for (U && (U += lt); tt < y; ) u[tt].animatorJustifyOffset = U, tt += 1;
          }
          for (y = 0; y < E; y += 1) {
            if (a.reset(), J = 1, u[y].n) o = 0, p += t.yOffset, p += R ? 1 : 0, g = $, R = false, this._hasMaskedPath && (f = X, m = Z, C = _[f].points, b = C[m - 1], d = C[m], T = d.partialLength, A = 0), it = "", at = "", st = "", ot = "", nt = this.defaultPropsArray;
            else {
              if (this._hasMaskedPath) {
                if (rt !== u[y].line) {
                  switch (t.j) {
                    case 1:
                      g += I - t.lineWidths[u[y].line];
                      break;
                    case 2:
                      g += (I - t.lineWidths[u[y].line]) / 2;
                      break;
                  }
                  rt = u[y].line;
                }
                B !== u[y].ind && (u[B] && (g += u[B].extra), g += u[y].an / 2, B = u[y].ind), g += r[0] * u[y].an * 5e-3;
                var et = 0;
                for (S = 0; S < P; S += 1) k = i[S].a, k.p.propType && (M = i[S].s, F = M.getMult(u[y].anIndexes[S], s.a[S].s.totalChars), F.length ? et += k.p.v[0] * F[0] : et += k.p.v[0] * F), k.a.propType && (M = i[S].s, F = M.getMult(u[y].anIndexes[S], s.a[S].s.totalChars), F.length ? et += k.a.v[0] * F[0] : et += k.a.v[0] * F);
                for (c = true, this._pathData.a.v && (g = u[0].an * 0.5 + (I - this._pathData.f.v - u[0].an * 0.5 - u[u.length - 1].an * 0.5) * B / (E - 1), g += this._pathData.f.v); c; ) A + T >= g + et || !C ? (L = (g + et - A) / d.partialLength, z = b.point[0] + (d.point[0] - b.point[0]) * L, q = b.point[1] + (d.point[1] - b.point[1]) * L, a.translate(-r[0] * u[y].an * 5e-3, -(r[1] * H) * 0.01), c = false) : C && (A += d.partialLength, m += 1, m >= C.length && (m = 0, f += 1, _[f] ? C = _[f].points : O.v.c ? (m = 0, f = 0, C = _[f].points) : (A -= d.partialLength, C = null)), C && (b = d, d = C[m], T = d.partialLength));
                G = u[y].an / 2 - u[y].add, a.translate(-G, 0, 0);
              } else G = u[y].an / 2 - u[y].add, a.translate(-G, 0, 0), a.translate(-r[0] * u[y].an * 5e-3, -r[1] * H * 0.01, 0);
              for (S = 0; S < P; S += 1) k = i[S].a, k.t.propType && (M = i[S].s, F = M.getMult(u[y].anIndexes[S], s.a[S].s.totalChars), (o !== 0 || t.j !== 0) && (this._hasMaskedPath ? F.length ? g += k.t.v * F[0] : g += k.t.v * F : F.length ? o += k.t.v * F[0] : o += k.t.v * F));
              for (t.strokeWidthAnim && (Q = t.sw || 0), t.strokeColorAnim && (t.sc ? K = [
                t.sc[0],
                t.sc[1],
                t.sc[2]
              ] : K = [
                0,
                0,
                0
              ]), t.fillColorAnim && t.fc && (Y = [
                t.fc[0],
                t.fc[1],
                t.fc[2]
              ]), S = 0; S < P; S += 1) k = i[S].a, k.a.propType && (M = i[S].s, F = M.getMult(u[y].anIndexes[S], s.a[S].s.totalChars), F.length ? a.translate(-k.a.v[0] * F[0], -k.a.v[1] * F[1], k.a.v[2] * F[2]) : a.translate(-k.a.v[0] * F, -k.a.v[1] * F, k.a.v[2] * F));
              for (S = 0; S < P; S += 1) k = i[S].a, k.s.propType && (M = i[S].s, F = M.getMult(u[y].anIndexes[S], s.a[S].s.totalChars), F.length ? a.scale(1 + (k.s.v[0] - 1) * F[0], 1 + (k.s.v[1] - 1) * F[1], 1) : a.scale(1 + (k.s.v[0] - 1) * F, 1 + (k.s.v[1] - 1) * F, 1));
              for (S = 0; S < P; S += 1) {
                if (k = i[S].a, M = i[S].s, F = M.getMult(u[y].anIndexes[S], s.a[S].s.totalChars), k.sk.propType && (F.length ? a.skewFromAxis(-k.sk.v * F[0], k.sa.v * F[1]) : a.skewFromAxis(-k.sk.v * F, k.sa.v * F)), k.r.propType && (F.length ? a.rotateZ(-k.r.v * F[2]) : a.rotateZ(-k.r.v * F)), k.ry.propType && (F.length ? a.rotateY(k.ry.v * F[1]) : a.rotateY(k.ry.v * F)), k.rx.propType && (F.length ? a.rotateX(k.rx.v * F[0]) : a.rotateX(k.rx.v * F)), k.o.propType && (F.length ? J += (k.o.v * F[0] - J) * F[0] : J += (k.o.v * F - J) * F), t.strokeWidthAnim && k.sw.propType && (F.length ? Q += k.sw.v * F[0] : Q += k.sw.v * F), t.strokeColorAnim && k.sc.propType) for (W = 0; W < 3; W += 1) F.length ? K[W] += (k.sc.v[W] - K[W]) * F[0] : K[W] += (k.sc.v[W] - K[W]) * F;
                if (t.fillColorAnim && t.fc) {
                  if (k.fc.propType) for (W = 0; W < 3; W += 1) F.length ? Y[W] += (k.fc.v[W] - Y[W]) * F[0] : Y[W] += (k.fc.v[W] - Y[W]) * F;
                  k.fh.propType && (F.length ? Y = addHueToRGB(Y, k.fh.v * F[0]) : Y = addHueToRGB(Y, k.fh.v * F)), k.fs.propType && (F.length ? Y = addSaturationToRGB(Y, k.fs.v * F[0]) : Y = addSaturationToRGB(Y, k.fs.v * F)), k.fb.propType && (F.length ? Y = addBrightnessToRGB(Y, k.fb.v * F[0]) : Y = addBrightnessToRGB(Y, k.fb.v * F));
                }
              }
              for (S = 0; S < P; S += 1) k = i[S].a, k.p.propType && (M = i[S].s, F = M.getMult(u[y].anIndexes[S], s.a[S].s.totalChars), this._hasMaskedPath ? F.length ? a.translate(0, k.p.v[1] * F[0], -k.p.v[2] * F[1]) : a.translate(0, k.p.v[1] * F, -k.p.v[2] * F) : F.length ? a.translate(k.p.v[0] * F[0], k.p.v[1] * F[1], -k.p.v[2] * F[2]) : a.translate(k.p.v[0] * F, k.p.v[1] * F, -k.p.v[2] * F));
              if (t.strokeWidthAnim && (st = Q < 0 ? 0 : Q), t.strokeColorAnim && (ht = "rgb(" + Math.round(K[0] * 255) + "," + Math.round(K[1] * 255) + "," + Math.round(K[2] * 255) + ")"), t.fillColorAnim && t.fc && (at = "rgb(" + Math.round(Y[0] * 255) + "," + Math.round(Y[1] * 255) + "," + Math.round(Y[2] * 255) + ")"), this._hasMaskedPath) {
                if (a.translate(0, -t.ls), a.translate(0, r[1] * H * 0.01 + p, 0), this._pathData.p.v) {
                  j = (d.point[1] - b.point[1]) / (d.point[0] - b.point[0]);
                  var ct = Math.atan(j) * 180 / Math.PI;
                  d.point[0] < b.point[0] && (ct += 180), a.rotate(-ct * Math.PI / 180);
                }
                a.translate(z, q, 0), g -= r[0] * u[y].an * 5e-3, u[y + 1] && B !== u[y + 1].ind && (g += u[y].an / 2, g += t.tr * 1e-3 * t.finalSize);
              } else {
                switch (a.translate(o, p, 0), t.ps && a.translate(t.ps[0], t.ps[1] + t.ascent, 0), t.j) {
                  case 1:
                    a.translate(u[y].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[u[y].line]), 0, 0);
                    break;
                  case 2:
                    a.translate(u[y].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[u[y].line]) / 2, 0, 0);
                    break;
                }
                a.translate(0, -t.ls), a.translate(G, 0, 0), a.translate(r[0] * u[y].an * 5e-3, r[1] * H * 0.01, 0), o += u[y].l + t.tr * 1e-3 * t.finalSize;
              }
              n === "html" ? it = a.toCSS() : n === "svg" ? it = a.to2dCSS() : nt = [
                a.props[0],
                a.props[1],
                a.props[2],
                a.props[3],
                a.props[4],
                a.props[5],
                a.props[6],
                a.props[7],
                a.props[8],
                a.props[9],
                a.props[10],
                a.props[11],
                a.props[12],
                a.props[13],
                a.props[14],
                a.props[15]
              ], ot = J;
            }
            l <= y ? (V = new LetterProps(ot, st, ht, at, it, nt), this.renderedLetters.push(V), l += 1, this.lettersChangedFlag = true) : (V = this.renderedLetters[y], this.lettersChangedFlag = V.update(ot, st, ht, at, it, nt) || this.lettersChangedFlag);
          }
        }
      }, TextAnimatorProperty.prototype.getValue = function() {
        this._elem.globalData.frameId !== this._frameId && (this._frameId = this._elem.globalData.frameId, this.iterateDynamicProperties());
      }, TextAnimatorProperty.prototype.mHelper = new Matrix(), TextAnimatorProperty.prototype.defaultPropsArray = [], extendPrototype([
        DynamicPropertyContainer
      ], TextAnimatorProperty);
      function ITextElement() {
      }
      ITextElement.prototype.initElement = function(t, e, r) {
        this.lettersChangedFlag = true, this.initFrame(), this.initBaseData(t, e, r), this.textProperty = new TextProperty(this, t.t, this.dynamicProperties), this.textAnimator = new TextAnimatorProperty(t.t, this.renderType, this), this.initTransform(t, e, r), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide(), this.textAnimator.searchProperties(this.dynamicProperties);
      }, ITextElement.prototype.prepareFrame = function(t) {
        this._mdf = false, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange);
      }, ITextElement.prototype.createPathShape = function(t, e) {
        var r, i = e.length, s, a = "";
        for (r = 0; r < i; r += 1) e[r].ty === "sh" && (s = e[r].ks.k, a += buildShapeString(s, s.i.length, true, t));
        return a;
      }, ITextElement.prototype.updateDocumentData = function(t, e) {
        this.textProperty.updateDocumentData(t, e);
      }, ITextElement.prototype.canResizeFont = function(t) {
        this.textProperty.canResizeFont(t);
      }, ITextElement.prototype.setMinimumFontSize = function(t) {
        this.textProperty.setMinimumFontSize(t);
      }, ITextElement.prototype.applyTextPropertiesToMatrix = function(t, e, r, i, s) {
        switch (t.ps && e.translate(t.ps[0], t.ps[1] + t.ascent, 0), e.translate(0, -t.ls, 0), t.j) {
          case 1:
            e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[r]), 0, 0);
            break;
          case 2:
            e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[r]) / 2, 0, 0);
            break;
        }
        e.translate(i, s, 0);
      }, ITextElement.prototype.buildColor = function(t) {
        return "rgb(" + Math.round(t[0] * 255) + "," + Math.round(t[1] * 255) + "," + Math.round(t[2] * 255) + ")";
      }, ITextElement.prototype.emptyProp = new LetterProps(), ITextElement.prototype.destroy = function() {
      }, ITextElement.prototype.validateText = function() {
        (this.textProperty._mdf || this.textProperty._isFirstFrame) && (this.buildNewText(), this.textProperty._isFirstFrame = false, this.textProperty._mdf = false);
      };
      var emptyShapeData = {
        shapes: []
      };
      function SVGTextLottieElement(t, e, r) {
        this.textSpans = [], this.renderType = "svg", this.initElement(t, e, r);
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        SVGBaseElement,
        HierarchyElement,
        FrameElement,
        RenderableDOMElement,
        ITextElement
      ], SVGTextLottieElement), SVGTextLottieElement.prototype.createContent = function() {
        this.data.singleShape && !this.globalData.fontManager.chars && (this.textContainer = createNS("text"));
      }, SVGTextLottieElement.prototype.buildTextContents = function(t) {
        for (var e = 0, r = t.length, i = [], s = ""; e < r; ) t[e] === "\r" || t[e] === "" ? (i.push(s), s = "") : s += t[e], e += 1;
        return i.push(s), i;
      }, SVGTextLottieElement.prototype.buildShapeData = function(t, e) {
        if (t.shapes && t.shapes.length) {
          var r = t.shapes[0];
          if (r.it) {
            var i = r.it[r.it.length - 1];
            i.s && (i.s.k[0] = e, i.s.k[1] = e);
          }
        }
        return t;
      }, SVGTextLottieElement.prototype.buildNewText = function() {
        this.addDynamicProperty(this);
        var t, e, r = this.textProperty.currentData;
        this.renderedLetters = createSizedArray(r ? r.l.length : 0), r.fc ? this.layerElement.setAttribute("fill", this.buildColor(r.fc)) : this.layerElement.setAttribute("fill", "rgba(0,0,0,0)"), r.sc && (this.layerElement.setAttribute("stroke", this.buildColor(r.sc)), this.layerElement.setAttribute("stroke-width", r.sw)), this.layerElement.setAttribute("font-size", r.finalSize);
        var i = this.globalData.fontManager.getFontByName(r.f);
        if (i.fClass) this.layerElement.setAttribute("class", i.fClass);
        else {
          this.layerElement.setAttribute("font-family", i.fFamily);
          var s = r.fWeight, a = r.fStyle;
          this.layerElement.setAttribute("font-style", a), this.layerElement.setAttribute("font-weight", s);
        }
        this.layerElement.setAttribute("aria-label", r.t);
        var n = r.l || [], l = !!this.globalData.fontManager.chars;
        e = n.length;
        var o, p = this.mHelper, y = "", E = this.data.singleShape, u = 0, x = 0, g = true, d = r.tr * 1e-3 * r.finalSize;
        if (E && !l && !r.sz) {
          var A = this.textContainer, c = "start";
          switch (r.j) {
            case 1:
              c = "end";
              break;
            case 2:
              c = "middle";
              break;
            default:
              c = "start";
              break;
          }
          A.setAttribute("text-anchor", c), A.setAttribute("letter-spacing", d);
          var m = this.buildTextContents(r.finalText);
          for (e = m.length, x = r.ps ? r.ps[1] + r.ascent : 0, t = 0; t < e; t += 1) o = this.textSpans[t].span || createNS("tspan"), o.textContent = m[t], o.setAttribute("x", 0), o.setAttribute("y", x), o.style.display = "inherit", A.appendChild(o), this.textSpans[t] || (this.textSpans[t] = {
            span: null,
            glyph: null
          }), this.textSpans[t].span = o, x += r.finalLineHeight;
          this.layerElement.appendChild(A);
        } else {
          var f = this.textSpans.length, b;
          for (t = 0; t < e; t += 1) {
            if (this.textSpans[t] || (this.textSpans[t] = {
              span: null,
              childSpan: null,
              glyph: null
            }), !l || !E || t === 0) {
              if (o = f > t ? this.textSpans[t].span : createNS(l ? "g" : "text"), f <= t) {
                if (o.setAttribute("stroke-linecap", "butt"), o.setAttribute("stroke-linejoin", "round"), o.setAttribute("stroke-miterlimit", "4"), this.textSpans[t].span = o, l) {
                  var C = createNS("g");
                  o.appendChild(C), this.textSpans[t].childSpan = C;
                }
                this.textSpans[t].span = o, this.layerElement.appendChild(o);
              }
              o.style.display = "inherit";
            }
            if (p.reset(), E && (n[t].n && (u = -d, x += r.yOffset, x += g ? 1 : 0, g = false), this.applyTextPropertiesToMatrix(r, p, n[t].line, u, x), u += n[t].l || 0, u += d), l) {
              b = this.globalData.fontManager.getCharData(r.finalText[t], i.fStyle, this.globalData.fontManager.getFontByName(r.f).fFamily);
              var _;
              if (b.t === 1) _ = new SVGCompElement(b.data, this.globalData, this);
              else {
                var T = emptyShapeData;
                b.data && b.data.shapes && (T = this.buildShapeData(b.data, r.finalSize)), _ = new SVGShapeElement(T, this.globalData, this);
              }
              if (this.textSpans[t].glyph) {
                var I = this.textSpans[t].glyph;
                this.textSpans[t].childSpan.removeChild(I.layerElement), I.destroy();
              }
              this.textSpans[t].glyph = _, _._debug = true, _.prepareFrame(0), _.renderFrame(), this.textSpans[t].childSpan.appendChild(_.layerElement), b.t === 1 && this.textSpans[t].childSpan.setAttribute("transform", "scale(" + r.finalSize / 100 + "," + r.finalSize / 100 + ")");
            } else E && o.setAttribute("transform", "translate(" + p.props[12] + "," + p.props[13] + ")"), o.textContent = n[t].val, o.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
          }
          E && o && o.setAttribute("d", y);
        }
        for (; t < this.textSpans.length; ) this.textSpans[t].span.style.display = "none", t += 1;
        this._sizeChanged = true;
      }, SVGTextLottieElement.prototype.sourceRectAtTime = function() {
        if (this.prepareFrame(this.comp.renderedFrame - this.data.st), this.renderInnerContent(), this._sizeChanged) {
          this._sizeChanged = false;
          var t = this.layerElement.getBBox();
          this.bbox = {
            top: t.y,
            left: t.x,
            width: t.width,
            height: t.height
          };
        }
        return this.bbox;
      }, SVGTextLottieElement.prototype.getValue = function() {
        var t, e = this.textSpans.length, r;
        for (this.renderedFrame = this.comp.renderedFrame, t = 0; t < e; t += 1) r = this.textSpans[t].glyph, r && (r.prepareFrame(this.comp.renderedFrame - this.data.st), r._mdf && (this._mdf = true));
      }, SVGTextLottieElement.prototype.renderInnerContent = function() {
        if (this.validateText(), (!this.data.singleShape || this._mdf) && (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag)) {
          this._sizeChanged = true;
          var t, e, r = this.textAnimator.renderedLetters, i = this.textProperty.currentData.l;
          e = i.length;
          var s, a, n;
          for (t = 0; t < e; t += 1) i[t].n || (s = r[t], a = this.textSpans[t].span, n = this.textSpans[t].glyph, n && n.renderFrame(), s._mdf.m && a.setAttribute("transform", s.m), s._mdf.o && a.setAttribute("opacity", s.o), s._mdf.sw && a.setAttribute("stroke-width", s.sw), s._mdf.sc && a.setAttribute("stroke", s.sc), s._mdf.fc && a.setAttribute("fill", s.fc));
        }
      };
      function ISolidElement(t, e, r) {
        this.initElement(t, e, r);
      }
      extendPrototype([
        IImageElement
      ], ISolidElement), ISolidElement.prototype.createContent = function() {
        var t = createNS("rect");
        t.setAttribute("width", this.data.sw), t.setAttribute("height", this.data.sh), t.setAttribute("fill", this.data.sc), this.layerElement.appendChild(t);
      };
      function NullElement(t, e, r) {
        this.initFrame(), this.initBaseData(t, e, r), this.initFrame(), this.initTransform(t, e, r), this.initHierarchy();
      }
      NullElement.prototype.prepareFrame = function(t) {
        this.prepareProperties(t, true);
      }, NullElement.prototype.renderFrame = function() {
      }, NullElement.prototype.getBaseElement = function() {
        return null;
      }, NullElement.prototype.destroy = function() {
      }, NullElement.prototype.sourceRectAtTime = function() {
      }, NullElement.prototype.hide = function() {
      }, extendPrototype([
        BaseElement,
        TransformElement,
        HierarchyElement,
        FrameElement
      ], NullElement);
      function SVGRendererBase() {
      }
      extendPrototype([
        BaseRenderer
      ], SVGRendererBase), SVGRendererBase.prototype.createNull = function(t) {
        return new NullElement(t, this.globalData, this);
      }, SVGRendererBase.prototype.createShape = function(t) {
        return new SVGShapeElement(t, this.globalData, this);
      }, SVGRendererBase.prototype.createText = function(t) {
        return new SVGTextLottieElement(t, this.globalData, this);
      }, SVGRendererBase.prototype.createImage = function(t) {
        return new IImageElement(t, this.globalData, this);
      }, SVGRendererBase.prototype.createSolid = function(t) {
        return new ISolidElement(t, this.globalData, this);
      }, SVGRendererBase.prototype.configAnimation = function(t) {
        this.svgElement.setAttribute("xmlns", "http://www.w3.org/2000/svg"), this.svgElement.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink"), this.renderConfig.viewBoxSize ? this.svgElement.setAttribute("viewBox", this.renderConfig.viewBoxSize) : this.svgElement.setAttribute("viewBox", "0 0 " + t.w + " " + t.h), this.renderConfig.viewBoxOnly || (this.svgElement.setAttribute("width", t.w), this.svgElement.setAttribute("height", t.h), this.svgElement.style.width = "100%", this.svgElement.style.height = "100%", this.svgElement.style.transform = "translate3d(0,0,0)", this.svgElement.style.contentVisibility = this.renderConfig.contentVisibility), this.renderConfig.width && this.svgElement.setAttribute("width", this.renderConfig.width), this.renderConfig.height && this.svgElement.setAttribute("height", this.renderConfig.height), this.renderConfig.className && this.svgElement.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.svgElement.setAttribute("id", this.renderConfig.id), this.renderConfig.focusable !== void 0 && this.svgElement.setAttribute("focusable", this.renderConfig.focusable), this.svgElement.setAttribute("preserveAspectRatio", this.renderConfig.preserveAspectRatio), this.animationItem.wrapper.appendChild(this.svgElement);
        var e = this.globalData.defs;
        this.setupGlobalData(t, e), this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.data = t;
        var r = createNS("clipPath"), i = createNS("rect");
        i.setAttribute("width", t.w), i.setAttribute("height", t.h), i.setAttribute("x", 0), i.setAttribute("y", 0);
        var s = createElementID();
        r.setAttribute("id", s), r.appendChild(i), this.layerElement.setAttribute("clip-path", "url(" + getLocationHref() + "#" + s + ")"), e.appendChild(r), this.layers = t.layers, this.elements = createSizedArray(t.layers.length);
      }, SVGRendererBase.prototype.destroy = function() {
        this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.layerElement = null, this.globalData.defs = null;
        var t, e = this.layers ? this.layers.length : 0;
        for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy && this.elements[t].destroy();
        this.elements.length = 0, this.destroyed = true, this.animationItem = null;
      }, SVGRendererBase.prototype.updateContainerSize = function() {
      }, SVGRendererBase.prototype.findIndexByInd = function(t) {
        var e = 0, r = this.layers.length;
        for (e = 0; e < r; e += 1) if (this.layers[e].ind === t) return e;
        return -1;
      }, SVGRendererBase.prototype.buildItem = function(t) {
        var e = this.elements;
        if (!(e[t] || this.layers[t].ty === 99)) {
          e[t] = true;
          var r = this.createItem(this.layers[t]);
          if (e[t] = r, getExpressionsPlugin() && (this.layers[t].ty === 0 && this.globalData.projectInterface.registerComposition(r), r.initExpressions()), this.appendElementInPos(r, t), this.layers[t].tt) {
            var i = "tp" in this.layers[t] ? this.findIndexByInd(this.layers[t].tp) : t - 1;
            if (i === -1) return;
            if (!this.elements[i] || this.elements[i] === true) this.buildItem(i), this.addPendingElement(r);
            else {
              var s = e[i], a = s.getMatte(this.layers[t].tt);
              r.setMatte(a);
            }
          }
        }
      }, SVGRendererBase.prototype.checkPendingElements = function() {
        for (; this.pendingElements.length; ) {
          var t = this.pendingElements.pop();
          if (t.checkParenting(), t.data.tt) for (var e = 0, r = this.elements.length; e < r; ) {
            if (this.elements[e] === t) {
              var i = "tp" in t.data ? this.findIndexByInd(t.data.tp) : e - 1, s = this.elements[i], a = s.getMatte(this.layers[e].tt);
              t.setMatte(a);
              break;
            }
            e += 1;
          }
        }
      }, SVGRendererBase.prototype.renderFrame = function(t) {
        if (!(this.renderedFrame === t || this.destroyed)) {
          t === null ? t = this.renderedFrame : this.renderedFrame = t, this.globalData.frameNum = t, this.globalData.frameId += 1, this.globalData.projectInterface.currentFrame = t, this.globalData._mdf = false;
          var e, r = this.layers.length;
          for (this.completeLayers || this.checkLayers(t), e = r - 1; e >= 0; e -= 1) (this.completeLayers || this.elements[e]) && this.elements[e].prepareFrame(t - this.layers[e].st);
          if (this.globalData._mdf) for (e = 0; e < r; e += 1) (this.completeLayers || this.elements[e]) && this.elements[e].renderFrame();
        }
      }, SVGRendererBase.prototype.appendElementInPos = function(t, e) {
        var r = t.getBaseElement();
        if (r) {
          for (var i = 0, s; i < e; ) this.elements[i] && this.elements[i] !== true && this.elements[i].getBaseElement() && (s = this.elements[i].getBaseElement()), i += 1;
          s ? this.layerElement.insertBefore(r, s) : this.layerElement.appendChild(r);
        }
      }, SVGRendererBase.prototype.hide = function() {
        this.layerElement.style.display = "none";
      }, SVGRendererBase.prototype.show = function() {
        this.layerElement.style.display = "block";
      };
      function ICompElement() {
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        HierarchyElement,
        FrameElement,
        RenderableDOMElement
      ], ICompElement), ICompElement.prototype.initElement = function(t, e, r) {
        this.initFrame(), this.initBaseData(t, e, r), this.initTransform(t, e, r), this.initRenderable(), this.initHierarchy(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), (this.data.xt || !e.progressiveLoad) && this.buildAllItems(), this.hide();
      }, ICompElement.prototype.prepareFrame = function(t) {
        if (this._mdf = false, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), !(!this.isInRange && !this.data.xt)) {
          if (this.tm._placeholder) this.renderedFrame = t / this.data.sr;
          else {
            var e = this.tm.v;
            e === this.data.op && (e = this.data.op - 1), this.renderedFrame = e;
          }
          var r, i = this.elements.length;
          for (this.completeLayers || this.checkLayers(this.renderedFrame), r = i - 1; r >= 0; r -= 1) (this.completeLayers || this.elements[r]) && (this.elements[r].prepareFrame(this.renderedFrame - this.layers[r].st), this.elements[r]._mdf && (this._mdf = true));
        }
      }, ICompElement.prototype.renderInnerContent = function() {
        var t, e = this.layers.length;
        for (t = 0; t < e; t += 1) (this.completeLayers || this.elements[t]) && this.elements[t].renderFrame();
      }, ICompElement.prototype.setElements = function(t) {
        this.elements = t;
      }, ICompElement.prototype.getElements = function() {
        return this.elements;
      }, ICompElement.prototype.destroyElements = function() {
        var t, e = this.layers.length;
        for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy();
      }, ICompElement.prototype.destroy = function() {
        this.destroyElements(), this.destroyBaseElement();
      };
      function SVGCompElement(t, e, r) {
        this.layers = t.layers, this.supports3d = true, this.completeLayers = false, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(t, e, r), this.tm = t.tm ? PropertyFactory.getProp(this, t.tm, 0, e.frameRate, this) : {
          _placeholder: true
        };
      }
      extendPrototype([
        SVGRendererBase,
        ICompElement,
        SVGBaseElement
      ], SVGCompElement), SVGCompElement.prototype.createComp = function(t) {
        return new SVGCompElement(t, this.globalData, this);
      };
      function SVGRenderer(t, e) {
        this.animationItem = t, this.layers = null, this.renderedFrame = -1, this.svgElement = createNS("svg");
        var r = "";
        if (e && e.title) {
          var i = createNS("title"), s = createElementID();
          i.setAttribute("id", s), i.textContent = e.title, this.svgElement.appendChild(i), r += s;
        }
        if (e && e.description) {
          var a = createNS("desc"), n = createElementID();
          a.setAttribute("id", n), a.textContent = e.description, this.svgElement.appendChild(a), r += " " + n;
        }
        r && this.svgElement.setAttribute("aria-labelledby", r);
        var l = createNS("defs");
        this.svgElement.appendChild(l);
        var o = createNS("g");
        this.svgElement.appendChild(o), this.layerElement = o, this.renderConfig = {
          preserveAspectRatio: e && e.preserveAspectRatio || "xMidYMid meet",
          imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
          contentVisibility: e && e.contentVisibility || "visible",
          progressiveLoad: e && e.progressiveLoad || false,
          hideOnTransparent: !(e && e.hideOnTransparent === false),
          viewBoxOnly: e && e.viewBoxOnly || false,
          viewBoxSize: e && e.viewBoxSize || false,
          className: e && e.className || "",
          id: e && e.id || "",
          focusable: e && e.focusable,
          filterSize: {
            width: e && e.filterSize && e.filterSize.width || "100%",
            height: e && e.filterSize && e.filterSize.height || "100%",
            x: e && e.filterSize && e.filterSize.x || "0%",
            y: e && e.filterSize && e.filterSize.y || "0%"
          },
          width: e && e.width,
          height: e && e.height,
          runExpressions: !e || e.runExpressions === void 0 || e.runExpressions
        }, this.globalData = {
          _mdf: false,
          frameNum: -1,
          defs: l,
          renderConfig: this.renderConfig
        }, this.elements = [], this.pendingElements = [], this.destroyed = false, this.rendererType = "svg";
      }
      extendPrototype([
        SVGRendererBase
      ], SVGRenderer), SVGRenderer.prototype.createComp = function(t) {
        return new SVGCompElement(t, this.globalData, this);
      };
      function ShapeTransformManager() {
        this.sequences = {}, this.sequenceList = [], this.transform_key_count = 0;
      }
      ShapeTransformManager.prototype = {
        addTransformSequence: function(e) {
          var r, i = e.length, s = "_";
          for (r = 0; r < i; r += 1) s += e[r].transform.key + "_";
          var a = this.sequences[s];
          return a || (a = {
            transforms: [].concat(e),
            finalTransform: new Matrix(),
            _mdf: false
          }, this.sequences[s] = a, this.sequenceList.push(a)), a;
        },
        processSequence: function(e, r) {
          for (var i = 0, s = e.transforms.length, a = r; i < s && !r; ) {
            if (e.transforms[i].transform.mProps._mdf) {
              a = true;
              break;
            }
            i += 1;
          }
          if (a) for (e.finalTransform.reset(), i = s - 1; i >= 0; i -= 1) e.finalTransform.multiply(e.transforms[i].transform.mProps.v);
          e._mdf = a;
        },
        processSequences: function(e) {
          var r, i = this.sequenceList.length;
          for (r = 0; r < i; r += 1) this.processSequence(this.sequenceList[r], e);
        },
        getNewKey: function() {
          return this.transform_key_count += 1, "_" + this.transform_key_count;
        }
      };
      var lumaLoader = function() {
        var e = "__lottie_element_luma_buffer", r = null, i = null, s = null;
        function a() {
          var o = createNS("svg"), p = createNS("filter"), y = createNS("feColorMatrix");
          return p.setAttribute("id", e), y.setAttribute("type", "matrix"), y.setAttribute("color-interpolation-filters", "sRGB"), y.setAttribute("values", "0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0"), p.appendChild(y), o.appendChild(p), o.setAttribute("id", e + "_svg"), featureSupport.svgLumaHidden && (o.style.display = "none"), o;
        }
        function n() {
          r || (s = a(), document.body.appendChild(s), r = createTag("canvas"), i = r.getContext("2d"), i.filter = "url(#" + e + ")", i.fillStyle = "rgba(0,0,0,0)", i.fillRect(0, 0, 1, 1));
        }
        function l(o) {
          return r || n(), r.width = o.width, r.height = o.height, i.filter = "url(#" + e + ")", r;
        }
        return {
          load: n,
          get: l
        };
      };
      function createCanvas(t, e) {
        if (featureSupport.offscreenCanvas) return new OffscreenCanvas(t, e);
        var r = createTag("canvas");
        return r.width = t, r.height = e, r;
      }
      var assetLoader = (function() {
        return {
          loadLumaCanvas: lumaLoader.load,
          getLumaCanvas: lumaLoader.get,
          createCanvas
        };
      })(), registeredEffects = {};
      function CVEffects(t) {
        var e, r = t.data.ef ? t.data.ef.length : 0;
        this.filters = [];
        var i;
        for (e = 0; e < r; e += 1) {
          i = null;
          var s = t.data.ef[e].ty;
          if (registeredEffects[s]) {
            var a = registeredEffects[s].effect;
            i = new a(t.effectsManager.effectElements[e], t);
          }
          i && this.filters.push(i);
        }
        this.filters.length && t.addRenderableComponent(this);
      }
      CVEffects.prototype.renderFrame = function(t) {
        var e, r = this.filters.length;
        for (e = 0; e < r; e += 1) this.filters[e].renderFrame(t);
      }, CVEffects.prototype.getEffects = function(t) {
        var e, r = this.filters.length, i = [];
        for (e = 0; e < r; e += 1) this.filters[e].type === t && i.push(this.filters[e]);
        return i;
      };
      function registerEffect(t, e) {
        registeredEffects[t] = {
          effect: e
        };
      }
      function CVMaskElement(t, e) {
        this.data = t, this.element = e, this.masksProperties = this.data.masksProperties || [], this.viewData = createSizedArray(this.masksProperties.length);
        var r, i = this.masksProperties.length, s = false;
        for (r = 0; r < i; r += 1) this.masksProperties[r].mode !== "n" && (s = true), this.viewData[r] = ShapePropertyFactory.getShapeProp(this.element, this.masksProperties[r], 3);
        this.hasMasks = s, s && this.element.addRenderableComponent(this);
      }
      CVMaskElement.prototype.renderFrame = function() {
        if (this.hasMasks) {
          var t = this.element.finalTransform.mat, e = this.element.canvasContext, r, i = this.masksProperties.length, s, a, n;
          for (e.beginPath(), r = 0; r < i; r += 1) if (this.masksProperties[r].mode !== "n") {
            this.masksProperties[r].inv && (e.moveTo(0, 0), e.lineTo(this.element.globalData.compSize.w, 0), e.lineTo(this.element.globalData.compSize.w, this.element.globalData.compSize.h), e.lineTo(0, this.element.globalData.compSize.h), e.lineTo(0, 0)), n = this.viewData[r].v, s = t.applyToPointArray(n.v[0][0], n.v[0][1], 0), e.moveTo(s[0], s[1]);
            var l, o = n._length;
            for (l = 1; l < o; l += 1) a = t.applyToTriplePoints(n.o[l - 1], n.i[l], n.v[l]), e.bezierCurveTo(a[0], a[1], a[2], a[3], a[4], a[5]);
            a = t.applyToTriplePoints(n.o[l - 1], n.i[0], n.v[0]), e.bezierCurveTo(a[0], a[1], a[2], a[3], a[4], a[5]);
          }
          this.element.globalData.renderer.save(true), e.clip();
        }
      }, CVMaskElement.prototype.getMaskProperty = MaskElement.prototype.getMaskProperty, CVMaskElement.prototype.destroy = function() {
        this.element = null;
      };
      function CVBaseElement() {
      }
      var operationsMap = {
        1: "source-in",
        2: "source-out",
        3: "source-in",
        4: "source-out"
      };
      CVBaseElement.prototype = {
        createElements: function() {
        },
        initRendererElement: function() {
        },
        createContainerElements: function() {
          if (this.data.tt >= 1) {
            this.buffers = [];
            var e = this.globalData.canvasContext, r = assetLoader.createCanvas(e.canvas.width, e.canvas.height);
            this.buffers.push(r);
            var i = assetLoader.createCanvas(e.canvas.width, e.canvas.height);
            this.buffers.push(i), this.data.tt >= 3 && !document._isProxy && assetLoader.loadLumaCanvas();
          }
          this.canvasContext = this.globalData.canvasContext, this.transformCanvas = this.globalData.transformCanvas, this.renderableEffectsManager = new CVEffects(this), this.searchEffectTransforms();
        },
        createContent: function() {
        },
        setBlendMode: function() {
          var e = this.globalData;
          if (e.blendMode !== this.data.bm) {
            e.blendMode = this.data.bm;
            var r = getBlendMode(this.data.bm);
            e.canvasContext.globalCompositeOperation = r;
          }
        },
        createRenderableComponents: function() {
          this.maskManager = new CVMaskElement(this.data, this), this.transformEffects = this.renderableEffectsManager.getEffects(effectTypes.TRANSFORM_EFFECT);
        },
        hideElement: function() {
          !this.hidden && (!this.isInRange || this.isTransparent) && (this.hidden = true);
        },
        showElement: function() {
          this.isInRange && !this.isTransparent && (this.hidden = false, this._isFirstFrame = true, this.maskManager._isFirstFrame = true);
        },
        clearCanvas: function(e) {
          e.clearRect(this.transformCanvas.tx, this.transformCanvas.ty, this.transformCanvas.w * this.transformCanvas.sx, this.transformCanvas.h * this.transformCanvas.sy);
        },
        prepareLayer: function() {
          if (this.data.tt >= 1) {
            var e = this.buffers[0], r = e.getContext("2d");
            this.clearCanvas(r), r.drawImage(this.canvasContext.canvas, 0, 0), this.currentTransform = this.canvasContext.getTransform(), this.canvasContext.setTransform(1, 0, 0, 1, 0, 0), this.clearCanvas(this.canvasContext), this.canvasContext.setTransform(this.currentTransform);
          }
        },
        exitLayer: function() {
          if (this.data.tt >= 1) {
            var e = this.buffers[1], r = e.getContext("2d");
            this.clearCanvas(r), r.drawImage(this.canvasContext.canvas, 0, 0), this.canvasContext.setTransform(1, 0, 0, 1, 0, 0), this.clearCanvas(this.canvasContext), this.canvasContext.setTransform(this.currentTransform);
            var i = this.comp.getElementById("tp" in this.data ? this.data.tp : this.data.ind - 1);
            if (i.renderFrame(true), this.canvasContext.setTransform(1, 0, 0, 1, 0, 0), this.data.tt >= 3 && !document._isProxy) {
              var s = assetLoader.getLumaCanvas(this.canvasContext.canvas), a = s.getContext("2d");
              a.drawImage(this.canvasContext.canvas, 0, 0), this.clearCanvas(this.canvasContext), this.canvasContext.drawImage(s, 0, 0);
            }
            this.canvasContext.globalCompositeOperation = operationsMap[this.data.tt], this.canvasContext.drawImage(e, 0, 0), this.canvasContext.globalCompositeOperation = "destination-over", this.canvasContext.drawImage(this.buffers[0], 0, 0), this.canvasContext.setTransform(this.currentTransform), this.canvasContext.globalCompositeOperation = "source-over";
          }
        },
        renderFrame: function(e) {
          if (!(this.hidden || this.data.hd) && !(this.data.td === 1 && !e)) {
            this.renderTransform(), this.renderRenderable(), this.renderLocalTransform(), this.setBlendMode();
            var r = this.data.ty === 0;
            this.prepareLayer(), this.globalData.renderer.save(r), this.globalData.renderer.ctxTransform(this.finalTransform.localMat.props), this.globalData.renderer.ctxOpacity(this.finalTransform.localOpacity), this.renderInnerContent(), this.globalData.renderer.restore(r), this.exitLayer(), this.maskManager.hasMasks && this.globalData.renderer.restore(true), this._isFirstFrame && (this._isFirstFrame = false);
          }
        },
        destroy: function() {
          this.canvasContext = null, this.data = null, this.globalData = null, this.maskManager.destroy();
        },
        mHelper: new Matrix()
      }, CVBaseElement.prototype.hide = CVBaseElement.prototype.hideElement, CVBaseElement.prototype.show = CVBaseElement.prototype.showElement;
      function CVShapeData(t, e, r, i) {
        this.styledShapes = [], this.tr = [
          0,
          0,
          0,
          0,
          0,
          0
        ];
        var s = 4;
        e.ty === "rc" ? s = 5 : e.ty === "el" ? s = 6 : e.ty === "sr" && (s = 7), this.sh = ShapePropertyFactory.getShapeProp(t, e, s, t);
        var a, n = r.length, l;
        for (a = 0; a < n; a += 1) r[a].closed || (l = {
          transforms: i.addTransformSequence(r[a].transforms),
          trNodes: []
        }, this.styledShapes.push(l), r[a].elements.push(l));
      }
      CVShapeData.prototype.setAsAnimated = SVGShapeData.prototype.setAsAnimated;
      function CVShapeElement(t, e, r) {
        this.shapes = [], this.shapesData = t.shapes, this.stylesList = [], this.itemsData = [], this.prevViewData = [], this.shapeModifiers = [], this.processedElements = [], this.transformsManager = new ShapeTransformManager(), this.initElement(t, e, r);
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        CVBaseElement,
        IShapeElement,
        HierarchyElement,
        FrameElement,
        RenderableElement
      ], CVShapeElement), CVShapeElement.prototype.initElement = RenderableDOMElement.prototype.initElement, CVShapeElement.prototype.transformHelper = {
        opacity: 1,
        _opMdf: false
      }, CVShapeElement.prototype.dashResetter = [], CVShapeElement.prototype.createContent = function() {
        this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, true, []);
      }, CVShapeElement.prototype.createStyleElement = function(t, e) {
        var r = {
          data: t,
          type: t.ty,
          preTransforms: this.transformsManager.addTransformSequence(e),
          transforms: [],
          elements: [],
          closed: t.hd === true
        }, i = {};
        if (t.ty === "fl" || t.ty === "st" ? (i.c = PropertyFactory.getProp(this, t.c, 1, 255, this), i.c.k || (r.co = "rgb(" + bmFloor(i.c.v[0]) + "," + bmFloor(i.c.v[1]) + "," + bmFloor(i.c.v[2]) + ")")) : (t.ty === "gf" || t.ty === "gs") && (i.s = PropertyFactory.getProp(this, t.s, 1, null, this), i.e = PropertyFactory.getProp(this, t.e, 1, null, this), i.h = PropertyFactory.getProp(this, t.h || {
          k: 0
        }, 0, 0.01, this), i.a = PropertyFactory.getProp(this, t.a || {
          k: 0
        }, 0, degToRads, this), i.g = new GradientProperty(this, t.g, this)), i.o = PropertyFactory.getProp(this, t.o, 0, 0.01, this), t.ty === "st" || t.ty === "gs") {
          if (r.lc = lineCapEnum[t.lc || 2], r.lj = lineJoinEnum[t.lj || 2], t.lj == 1 && (r.ml = t.ml), i.w = PropertyFactory.getProp(this, t.w, 0, null, this), i.w.k || (r.wi = i.w.v), t.d) {
            var s = new DashProperty(this, t.d, "canvas", this);
            i.d = s, i.d.k || (r.da = i.d.dashArray, r.do = i.d.dashoffset[0]);
          }
        } else r.r = t.r === 2 ? "evenodd" : "nonzero";
        return this.stylesList.push(r), i.style = r, i;
      }, CVShapeElement.prototype.createGroupElement = function() {
        var t = {
          it: [],
          prevViewData: []
        };
        return t;
      }, CVShapeElement.prototype.createTransformElement = function(t) {
        var e = {
          transform: {
            opacity: 1,
            _opMdf: false,
            key: this.transformsManager.getNewKey(),
            op: PropertyFactory.getProp(this, t.o, 0, 0.01, this),
            mProps: TransformPropertyFactory.getTransformProperty(this, t, this)
          }
        };
        return e;
      }, CVShapeElement.prototype.createShapeElement = function(t) {
        var e = new CVShapeData(this, t, this.stylesList, this.transformsManager);
        return this.shapes.push(e), this.addShapeToModifiers(e), e;
      }, CVShapeElement.prototype.reloadShapes = function() {
        this._isFirstFrame = true;
        var t, e = this.itemsData.length;
        for (t = 0; t < e; t += 1) this.prevViewData[t] = this.itemsData[t];
        for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, true, []), e = this.dynamicProperties.length, t = 0; t < e; t += 1) this.dynamicProperties[t].getValue();
        this.renderModifiers(), this.transformsManager.processSequences(this._isFirstFrame);
      }, CVShapeElement.prototype.addTransformToStyleList = function(t) {
        var e, r = this.stylesList.length;
        for (e = 0; e < r; e += 1) this.stylesList[e].closed || this.stylesList[e].transforms.push(t);
      }, CVShapeElement.prototype.removeTransformFromStyleList = function() {
        var t, e = this.stylesList.length;
        for (t = 0; t < e; t += 1) this.stylesList[t].closed || this.stylesList[t].transforms.pop();
      }, CVShapeElement.prototype.closeStyles = function(t) {
        var e, r = t.length;
        for (e = 0; e < r; e += 1) t[e].closed = true;
      }, CVShapeElement.prototype.searchShapes = function(t, e, r, i, s) {
        var a, n = t.length - 1, l, o, p = [], y = [], E, u, x, g = [].concat(s);
        for (a = n; a >= 0; a -= 1) {
          if (E = this.searchProcessedElement(t[a]), E ? e[a] = r[E - 1] : t[a]._shouldRender = i, t[a].ty === "fl" || t[a].ty === "st" || t[a].ty === "gf" || t[a].ty === "gs") E ? e[a].style.closed = false : e[a] = this.createStyleElement(t[a], g), p.push(e[a].style);
          else if (t[a].ty === "gr") {
            if (!E) e[a] = this.createGroupElement(t[a]);
            else for (o = e[a].it.length, l = 0; l < o; l += 1) e[a].prevViewData[l] = e[a].it[l];
            this.searchShapes(t[a].it, e[a].it, e[a].prevViewData, i, g);
          } else t[a].ty === "tr" ? (E || (x = this.createTransformElement(t[a]), e[a] = x), g.push(e[a]), this.addTransformToStyleList(e[a])) : t[a].ty === "sh" || t[a].ty === "rc" || t[a].ty === "el" || t[a].ty === "sr" ? E || (e[a] = this.createShapeElement(t[a])) : t[a].ty === "tm" || t[a].ty === "rd" || t[a].ty === "pb" || t[a].ty === "zz" || t[a].ty === "op" ? (E ? (u = e[a], u.closed = false) : (u = ShapeModifiers.getModifier(t[a].ty), u.init(this, t[a]), e[a] = u, this.shapeModifiers.push(u)), y.push(u)) : t[a].ty === "rp" && (E ? (u = e[a], u.closed = true) : (u = ShapeModifiers.getModifier(t[a].ty), e[a] = u, u.init(this, t, a, e), this.shapeModifiers.push(u), i = false), y.push(u));
          this.addProcessedElement(t[a], a + 1);
        }
        for (this.removeTransformFromStyleList(), this.closeStyles(p), n = y.length, a = 0; a < n; a += 1) y[a].closed = true;
      }, CVShapeElement.prototype.renderInnerContent = function() {
        this.transformHelper.opacity = 1, this.transformHelper._opMdf = false, this.renderModifiers(), this.transformsManager.processSequences(this._isFirstFrame), this.renderShape(this.transformHelper, this.shapesData, this.itemsData, true);
      }, CVShapeElement.prototype.renderShapeTransform = function(t, e) {
        (t._opMdf || e.op._mdf || this._isFirstFrame) && (e.opacity = t.opacity, e.opacity *= e.op.v, e._opMdf = true);
      }, CVShapeElement.prototype.drawLayer = function() {
        var t, e = this.stylesList.length, r, i, s, a, n, l, o = this.globalData.renderer, p = this.globalData.canvasContext, y, E;
        for (t = 0; t < e; t += 1) if (E = this.stylesList[t], y = E.type, !((y === "st" || y === "gs") && E.wi === 0 || !E.data._shouldRender || E.coOp === 0 || this.globalData.currentGlobalAlpha === 0)) {
          for (o.save(), n = E.elements, y === "st" || y === "gs" ? (o.ctxStrokeStyle(y === "st" ? E.co : E.grd), o.ctxLineWidth(E.wi), o.ctxLineCap(E.lc), o.ctxLineJoin(E.lj), o.ctxMiterLimit(E.ml || 0)) : o.ctxFillStyle(y === "fl" ? E.co : E.grd), o.ctxOpacity(E.coOp), y !== "st" && y !== "gs" && p.beginPath(), o.ctxTransform(E.preTransforms.finalTransform.props), i = n.length, r = 0; r < i; r += 1) {
            for ((y === "st" || y === "gs") && (p.beginPath(), E.da && (p.setLineDash(E.da), p.lineDashOffset = E.do)), l = n[r].trNodes, a = l.length, s = 0; s < a; s += 1) l[s].t === "m" ? p.moveTo(l[s].p[0], l[s].p[1]) : l[s].t === "c" ? p.bezierCurveTo(l[s].pts[0], l[s].pts[1], l[s].pts[2], l[s].pts[3], l[s].pts[4], l[s].pts[5]) : p.closePath();
            (y === "st" || y === "gs") && (o.ctxStroke(), E.da && p.setLineDash(this.dashResetter));
          }
          y !== "st" && y !== "gs" && this.globalData.renderer.ctxFill(E.r), o.restore();
        }
      }, CVShapeElement.prototype.renderShape = function(t, e, r, i) {
        var s, a = e.length - 1, n;
        for (n = t, s = a; s >= 0; s -= 1) e[s].ty === "tr" ? (n = r[s].transform, this.renderShapeTransform(t, n)) : e[s].ty === "sh" || e[s].ty === "el" || e[s].ty === "rc" || e[s].ty === "sr" ? this.renderPath(e[s], r[s]) : e[s].ty === "fl" ? this.renderFill(e[s], r[s], n) : e[s].ty === "st" ? this.renderStroke(e[s], r[s], n) : e[s].ty === "gf" || e[s].ty === "gs" ? this.renderGradientFill(e[s], r[s], n) : e[s].ty === "gr" ? this.renderShape(n, e[s].it, r[s].it) : e[s].ty;
        i && this.drawLayer();
      }, CVShapeElement.prototype.renderStyledShape = function(t, e) {
        if (this._isFirstFrame || e._mdf || t.transforms._mdf) {
          var r = t.trNodes, i = e.paths, s, a, n, l = i._length;
          r.length = 0;
          var o = t.transforms.finalTransform;
          for (n = 0; n < l; n += 1) {
            var p = i.shapes[n];
            if (p && p.v) {
              for (a = p._length, s = 1; s < a; s += 1) s === 1 && r.push({
                t: "m",
                p: o.applyToPointArray(p.v[0][0], p.v[0][1], 0)
              }), r.push({
                t: "c",
                pts: o.applyToTriplePoints(p.o[s - 1], p.i[s], p.v[s])
              });
              a === 1 && r.push({
                t: "m",
                p: o.applyToPointArray(p.v[0][0], p.v[0][1], 0)
              }), p.c && a && (r.push({
                t: "c",
                pts: o.applyToTriplePoints(p.o[s - 1], p.i[0], p.v[0])
              }), r.push({
                t: "z"
              }));
            }
          }
          t.trNodes = r;
        }
      }, CVShapeElement.prototype.renderPath = function(t, e) {
        if (t.hd !== true && t._shouldRender) {
          var r, i = e.styledShapes.length;
          for (r = 0; r < i; r += 1) this.renderStyledShape(e.styledShapes[r], e.sh);
        }
      }, CVShapeElement.prototype.renderFill = function(t, e, r) {
        var i = e.style;
        (e.c._mdf || this._isFirstFrame) && (i.co = "rgb(" + bmFloor(e.c.v[0]) + "," + bmFloor(e.c.v[1]) + "," + bmFloor(e.c.v[2]) + ")"), (e.o._mdf || r._opMdf || this._isFirstFrame) && (i.coOp = e.o.v * r.opacity);
      }, CVShapeElement.prototype.renderGradientFill = function(t, e, r) {
        var i = e.style, s;
        if (!i.grd || e.g._mdf || e.s._mdf || e.e._mdf || t.t !== 1 && (e.h._mdf || e.a._mdf)) {
          var a = this.globalData.canvasContext, n = e.s.v, l = e.e.v;
          if (t.t === 1) s = a.createLinearGradient(n[0], n[1], l[0], l[1]);
          else {
            var o = Math.sqrt(Math.pow(n[0] - l[0], 2) + Math.pow(n[1] - l[1], 2)), p = Math.atan2(l[1] - n[1], l[0] - n[0]), y = e.h.v;
            y >= 1 ? y = 0.99 : y <= -1 && (y = -0.99);
            var E = o * y, u = Math.cos(p + e.a.v) * E + n[0], x = Math.sin(p + e.a.v) * E + n[1];
            s = a.createRadialGradient(u, x, 0, n[0], n[1], o);
          }
          var g, d = t.g.p, A = e.g.c, c = 1;
          for (g = 0; g < d; g += 1) e.g._hasOpacity && e.g._collapsable && (c = e.g.o[g * 2 + 1]), s.addColorStop(A[g * 4] / 100, "rgba(" + A[g * 4 + 1] + "," + A[g * 4 + 2] + "," + A[g * 4 + 3] + "," + c + ")");
          i.grd = s;
        }
        i.coOp = e.o.v * r.opacity;
      }, CVShapeElement.prototype.renderStroke = function(t, e, r) {
        var i = e.style, s = e.d;
        s && (s._mdf || this._isFirstFrame) && (i.da = s.dashArray, i.do = s.dashoffset[0]), (e.c._mdf || this._isFirstFrame) && (i.co = "rgb(" + bmFloor(e.c.v[0]) + "," + bmFloor(e.c.v[1]) + "," + bmFloor(e.c.v[2]) + ")"), (e.o._mdf || r._opMdf || this._isFirstFrame) && (i.coOp = e.o.v * r.opacity), (e.w._mdf || this._isFirstFrame) && (i.wi = e.w.v);
      }, CVShapeElement.prototype.destroy = function() {
        this.shapesData = null, this.globalData = null, this.canvasContext = null, this.stylesList.length = 0, this.itemsData.length = 0;
      };
      function CVTextElement(t, e, r) {
        this.textSpans = [], this.yOffset = 0, this.fillColorAnim = false, this.strokeColorAnim = false, this.strokeWidthAnim = false, this.stroke = false, this.fill = false, this.justifyOffset = 0, this.currentRender = null, this.renderType = "canvas", this.values = {
          fill: "rgba(0,0,0,0)",
          stroke: "rgba(0,0,0,0)",
          sWidth: 0,
          fValue: ""
        }, this.initElement(t, e, r);
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        CVBaseElement,
        HierarchyElement,
        FrameElement,
        RenderableElement,
        ITextElement
      ], CVTextElement), CVTextElement.prototype.tHelper = createTag("canvas").getContext("2d"), CVTextElement.prototype.buildNewText = function() {
        var t = this.textProperty.currentData;
        this.renderedLetters = createSizedArray(t.l ? t.l.length : 0);
        var e = false;
        t.fc ? (e = true, this.values.fill = this.buildColor(t.fc)) : this.values.fill = "rgba(0,0,0,0)", this.fill = e;
        var r = false;
        t.sc && (r = true, this.values.stroke = this.buildColor(t.sc), this.values.sWidth = t.sw);
        var i = this.globalData.fontManager.getFontByName(t.f), s, a, n = t.l, l = this.mHelper;
        this.stroke = r, this.values.fValue = t.finalSize + "px " + this.globalData.fontManager.getFontByName(t.f).fFamily, a = t.finalText.length;
        var o, p, y, E, u, x, g, d, A, c, m = this.data.singleShape, f = t.tr * 1e-3 * t.finalSize, b = 0, C = 0, _ = true, T = 0;
        for (s = 0; s < a; s += 1) {
          o = this.globalData.fontManager.getCharData(t.finalText[s], i.fStyle, this.globalData.fontManager.getFontByName(t.f).fFamily), p = o && o.data || {}, l.reset(), m && n[s].n && (b = -f, C += t.yOffset, C += _ ? 1 : 0, _ = false), u = p.shapes ? p.shapes[0].it : [], g = u.length, l.scale(t.finalSize / 100, t.finalSize / 100), m && this.applyTextPropertiesToMatrix(t, l, n[s].line, b, C), A = createSizedArray(g - 1);
          var I = 0;
          for (x = 0; x < g; x += 1) if (u[x].ty === "sh") {
            for (E = u[x].ks.k.i.length, d = u[x].ks.k, c = [], y = 1; y < E; y += 1) y === 1 && c.push(l.applyToX(d.v[0][0], d.v[0][1], 0), l.applyToY(d.v[0][0], d.v[0][1], 0)), c.push(l.applyToX(d.o[y - 1][0], d.o[y - 1][1], 0), l.applyToY(d.o[y - 1][0], d.o[y - 1][1], 0), l.applyToX(d.i[y][0], d.i[y][1], 0), l.applyToY(d.i[y][0], d.i[y][1], 0), l.applyToX(d.v[y][0], d.v[y][1], 0), l.applyToY(d.v[y][0], d.v[y][1], 0));
            c.push(l.applyToX(d.o[y - 1][0], d.o[y - 1][1], 0), l.applyToY(d.o[y - 1][0], d.o[y - 1][1], 0), l.applyToX(d.i[0][0], d.i[0][1], 0), l.applyToY(d.i[0][0], d.i[0][1], 0), l.applyToX(d.v[0][0], d.v[0][1], 0), l.applyToY(d.v[0][0], d.v[0][1], 0)), A[I] = c, I += 1;
          }
          m && (b += n[s].l, b += f), this.textSpans[T] ? this.textSpans[T].elem = A : this.textSpans[T] = {
            elem: A
          }, T += 1;
        }
      }, CVTextElement.prototype.renderInnerContent = function() {
        this.validateText();
        var t = this.canvasContext;
        t.font = this.values.fValue, this.globalData.renderer.ctxLineCap("butt"), this.globalData.renderer.ctxLineJoin("miter"), this.globalData.renderer.ctxMiterLimit(4), this.data.singleShape || this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag);
        var e, r, i, s, a, n, l = this.textAnimator.renderedLetters, o = this.textProperty.currentData.l;
        r = o.length;
        var p, y = null, E = null, u = null, x, g, d = this.globalData.renderer;
        for (e = 0; e < r; e += 1) if (!o[e].n) {
          if (p = l[e], p && (d.save(), d.ctxTransform(p.p), d.ctxOpacity(p.o)), this.fill) {
            for (p && p.fc ? y !== p.fc && (d.ctxFillStyle(p.fc), y = p.fc) : y !== this.values.fill && (y = this.values.fill, d.ctxFillStyle(this.values.fill)), x = this.textSpans[e].elem, s = x.length, this.globalData.canvasContext.beginPath(), i = 0; i < s; i += 1) for (g = x[i], n = g.length, this.globalData.canvasContext.moveTo(g[0], g[1]), a = 2; a < n; a += 6) this.globalData.canvasContext.bezierCurveTo(g[a], g[a + 1], g[a + 2], g[a + 3], g[a + 4], g[a + 5]);
            this.globalData.canvasContext.closePath(), d.ctxFill();
          }
          if (this.stroke) {
            for (p && p.sw ? u !== p.sw && (u = p.sw, d.ctxLineWidth(p.sw)) : u !== this.values.sWidth && (u = this.values.sWidth, d.ctxLineWidth(this.values.sWidth)), p && p.sc ? E !== p.sc && (E = p.sc, d.ctxStrokeStyle(p.sc)) : E !== this.values.stroke && (E = this.values.stroke, d.ctxStrokeStyle(this.values.stroke)), x = this.textSpans[e].elem, s = x.length, this.globalData.canvasContext.beginPath(), i = 0; i < s; i += 1) for (g = x[i], n = g.length, this.globalData.canvasContext.moveTo(g[0], g[1]), a = 2; a < n; a += 6) this.globalData.canvasContext.bezierCurveTo(g[a], g[a + 1], g[a + 2], g[a + 3], g[a + 4], g[a + 5]);
            this.globalData.canvasContext.closePath(), d.ctxStroke();
          }
          p && this.globalData.renderer.restore();
        }
      };
      function CVImageElement(t, e, r) {
        this.assetData = e.getAssetData(t.refId), this.img = e.imageLoader.getAsset(this.assetData), this.initElement(t, e, r);
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        CVBaseElement,
        HierarchyElement,
        FrameElement,
        RenderableElement
      ], CVImageElement), CVImageElement.prototype.initElement = SVGShapeElement.prototype.initElement, CVImageElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame, CVImageElement.prototype.createContent = function() {
        if (this.img.width && (this.assetData.w !== this.img.width || this.assetData.h !== this.img.height)) {
          var t = createTag("canvas");
          t.width = this.assetData.w, t.height = this.assetData.h;
          var e = t.getContext("2d"), r = this.img.width, i = this.img.height, s = r / i, a = this.assetData.w / this.assetData.h, n, l, o = this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio;
          s > a && o === "xMidYMid slice" || s < a && o !== "xMidYMid slice" ? (l = i, n = l * a) : (n = r, l = n / a), e.drawImage(this.img, (r - n) / 2, (i - l) / 2, n, l, 0, 0, this.assetData.w, this.assetData.h), this.img = t;
        }
      }, CVImageElement.prototype.renderInnerContent = function() {
        this.canvasContext.drawImage(this.img, 0, 0);
      }, CVImageElement.prototype.destroy = function() {
        this.img = null;
      };
      function CVSolidElement(t, e, r) {
        this.initElement(t, e, r);
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        CVBaseElement,
        HierarchyElement,
        FrameElement,
        RenderableElement
      ], CVSolidElement), CVSolidElement.prototype.initElement = SVGShapeElement.prototype.initElement, CVSolidElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame, CVSolidElement.prototype.renderInnerContent = function() {
        this.globalData.renderer.ctxFillStyle(this.data.sc), this.globalData.renderer.ctxFillRect(0, 0, this.data.sw, this.data.sh);
      };
      function CanvasRendererBase() {
      }
      extendPrototype([
        BaseRenderer
      ], CanvasRendererBase), CanvasRendererBase.prototype.createShape = function(t) {
        return new CVShapeElement(t, this.globalData, this);
      }, CanvasRendererBase.prototype.createText = function(t) {
        return new CVTextElement(t, this.globalData, this);
      }, CanvasRendererBase.prototype.createImage = function(t) {
        return new CVImageElement(t, this.globalData, this);
      }, CanvasRendererBase.prototype.createSolid = function(t) {
        return new CVSolidElement(t, this.globalData, this);
      }, CanvasRendererBase.prototype.createNull = SVGRenderer.prototype.createNull, CanvasRendererBase.prototype.ctxTransform = function(t) {
        t[0] === 1 && t[1] === 0 && t[4] === 0 && t[5] === 1 && t[12] === 0 && t[13] === 0 || this.canvasContext.transform(t[0], t[1], t[4], t[5], t[12], t[13]);
      }, CanvasRendererBase.prototype.ctxOpacity = function(t) {
        this.canvasContext.globalAlpha *= t < 0 ? 0 : t;
      }, CanvasRendererBase.prototype.ctxFillStyle = function(t) {
        this.canvasContext.fillStyle = t;
      }, CanvasRendererBase.prototype.ctxStrokeStyle = function(t) {
        this.canvasContext.strokeStyle = t;
      }, CanvasRendererBase.prototype.ctxLineWidth = function(t) {
        this.canvasContext.lineWidth = t;
      }, CanvasRendererBase.prototype.ctxLineCap = function(t) {
        this.canvasContext.lineCap = t;
      }, CanvasRendererBase.prototype.ctxLineJoin = function(t) {
        this.canvasContext.lineJoin = t;
      }, CanvasRendererBase.prototype.ctxMiterLimit = function(t) {
        this.canvasContext.miterLimit = t;
      }, CanvasRendererBase.prototype.ctxFill = function(t) {
        this.canvasContext.fill(t);
      }, CanvasRendererBase.prototype.ctxFillRect = function(t, e, r, i) {
        this.canvasContext.fillRect(t, e, r, i);
      }, CanvasRendererBase.prototype.ctxStroke = function() {
        this.canvasContext.stroke();
      }, CanvasRendererBase.prototype.reset = function() {
        if (!this.renderConfig.clearCanvas) {
          this.canvasContext.restore();
          return;
        }
        this.contextData.reset();
      }, CanvasRendererBase.prototype.save = function() {
        this.canvasContext.save();
      }, CanvasRendererBase.prototype.restore = function(t) {
        if (!this.renderConfig.clearCanvas) {
          this.canvasContext.restore();
          return;
        }
        t && (this.globalData.blendMode = "source-over"), this.contextData.restore(t);
      }, CanvasRendererBase.prototype.configAnimation = function(t) {
        if (this.animationItem.wrapper) {
          this.animationItem.container = createTag("canvas");
          var e = this.animationItem.container.style;
          e.width = "100%", e.height = "100%";
          var r = "0px 0px 0px";
          e.transformOrigin = r, e.mozTransformOrigin = r, e.webkitTransformOrigin = r, e["-webkit-transform"] = r, e.contentVisibility = this.renderConfig.contentVisibility, this.animationItem.wrapper.appendChild(this.animationItem.container), this.canvasContext = this.animationItem.container.getContext("2d"), this.renderConfig.className && this.animationItem.container.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.animationItem.container.setAttribute("id", this.renderConfig.id);
        } else this.canvasContext = this.renderConfig.context;
        this.contextData.setContext(this.canvasContext), this.data = t, this.layers = t.layers, this.transformCanvas = {
          w: t.w,
          h: t.h,
          sx: 0,
          sy: 0,
          tx: 0,
          ty: 0
        }, this.setupGlobalData(t, document.body), this.globalData.canvasContext = this.canvasContext, this.globalData.renderer = this, this.globalData.isDashed = false, this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.globalData.transformCanvas = this.transformCanvas, this.elements = createSizedArray(t.layers.length), this.updateContainerSize();
      }, CanvasRendererBase.prototype.updateContainerSize = function(t, e) {
        this.reset();
        var r, i;
        t ? (r = t, i = e, this.canvasContext.canvas.width = r, this.canvasContext.canvas.height = i) : (this.animationItem.wrapper && this.animationItem.container ? (r = this.animationItem.wrapper.offsetWidth, i = this.animationItem.wrapper.offsetHeight) : (r = this.canvasContext.canvas.width, i = this.canvasContext.canvas.height), this.canvasContext.canvas.width = r * this.renderConfig.dpr, this.canvasContext.canvas.height = i * this.renderConfig.dpr);
        var s, a;
        if (this.renderConfig.preserveAspectRatio.indexOf("meet") !== -1 || this.renderConfig.preserveAspectRatio.indexOf("slice") !== -1) {
          var n = this.renderConfig.preserveAspectRatio.split(" "), l = n[1] || "meet", o = n[0] || "xMidYMid", p = o.substr(0, 4), y = o.substr(4);
          s = r / i, a = this.transformCanvas.w / this.transformCanvas.h, a > s && l === "meet" || a < s && l === "slice" ? (this.transformCanvas.sx = r / (this.transformCanvas.w / this.renderConfig.dpr), this.transformCanvas.sy = r / (this.transformCanvas.w / this.renderConfig.dpr)) : (this.transformCanvas.sx = i / (this.transformCanvas.h / this.renderConfig.dpr), this.transformCanvas.sy = i / (this.transformCanvas.h / this.renderConfig.dpr)), p === "xMid" && (a < s && l === "meet" || a > s && l === "slice") ? this.transformCanvas.tx = (r - this.transformCanvas.w * (i / this.transformCanvas.h)) / 2 * this.renderConfig.dpr : p === "xMax" && (a < s && l === "meet" || a > s && l === "slice") ? this.transformCanvas.tx = (r - this.transformCanvas.w * (i / this.transformCanvas.h)) * this.renderConfig.dpr : this.transformCanvas.tx = 0, y === "YMid" && (a > s && l === "meet" || a < s && l === "slice") ? this.transformCanvas.ty = (i - this.transformCanvas.h * (r / this.transformCanvas.w)) / 2 * this.renderConfig.dpr : y === "YMax" && (a > s && l === "meet" || a < s && l === "slice") ? this.transformCanvas.ty = (i - this.transformCanvas.h * (r / this.transformCanvas.w)) * this.renderConfig.dpr : this.transformCanvas.ty = 0;
        } else this.renderConfig.preserveAspectRatio === "none" ? (this.transformCanvas.sx = r / (this.transformCanvas.w / this.renderConfig.dpr), this.transformCanvas.sy = i / (this.transformCanvas.h / this.renderConfig.dpr), this.transformCanvas.tx = 0, this.transformCanvas.ty = 0) : (this.transformCanvas.sx = this.renderConfig.dpr, this.transformCanvas.sy = this.renderConfig.dpr, this.transformCanvas.tx = 0, this.transformCanvas.ty = 0);
        this.transformCanvas.props = [
          this.transformCanvas.sx,
          0,
          0,
          0,
          0,
          this.transformCanvas.sy,
          0,
          0,
          0,
          0,
          1,
          0,
          this.transformCanvas.tx,
          this.transformCanvas.ty,
          0,
          1
        ], this.ctxTransform(this.transformCanvas.props), this.canvasContext.beginPath(), this.canvasContext.rect(0, 0, this.transformCanvas.w, this.transformCanvas.h), this.canvasContext.closePath(), this.canvasContext.clip(), this.renderFrame(this.renderedFrame, true);
      }, CanvasRendererBase.prototype.destroy = function() {
        this.renderConfig.clearCanvas && this.animationItem.wrapper && (this.animationItem.wrapper.innerText = "");
        var t, e = this.layers ? this.layers.length : 0;
        for (t = e - 1; t >= 0; t -= 1) this.elements[t] && this.elements[t].destroy && this.elements[t].destroy();
        this.elements.length = 0, this.globalData.canvasContext = null, this.animationItem.container = null, this.destroyed = true;
      }, CanvasRendererBase.prototype.renderFrame = function(t, e) {
        if (!(this.renderedFrame === t && this.renderConfig.clearCanvas === true && !e || this.destroyed || t === -1)) {
          this.renderedFrame = t, this.globalData.frameNum = t - this.animationItem._isFirstFrame, this.globalData.frameId += 1, this.globalData._mdf = !this.renderConfig.clearCanvas || e, this.globalData.projectInterface.currentFrame = t;
          var r, i = this.layers.length;
          for (this.completeLayers || this.checkLayers(t), r = i - 1; r >= 0; r -= 1) (this.completeLayers || this.elements[r]) && this.elements[r].prepareFrame(t - this.layers[r].st);
          if (this.globalData._mdf) {
            for (this.renderConfig.clearCanvas === true ? this.canvasContext.clearRect(0, 0, this.transformCanvas.w, this.transformCanvas.h) : this.save(), r = i - 1; r >= 0; r -= 1) (this.completeLayers || this.elements[r]) && this.elements[r].renderFrame();
            this.renderConfig.clearCanvas !== true && this.restore();
          }
        }
      }, CanvasRendererBase.prototype.buildItem = function(t) {
        var e = this.elements;
        if (!(e[t] || this.layers[t].ty === 99)) {
          var r = this.createItem(this.layers[t], this, this.globalData);
          e[t] = r, r.initExpressions();
        }
      }, CanvasRendererBase.prototype.checkPendingElements = function() {
        for (; this.pendingElements.length; ) {
          var t = this.pendingElements.pop();
          t.checkParenting();
        }
      }, CanvasRendererBase.prototype.hide = function() {
        this.animationItem.container.style.display = "none";
      }, CanvasRendererBase.prototype.show = function() {
        this.animationItem.container.style.display = "block";
      };
      function CanvasContext() {
        this.opacity = -1, this.transform = createTypedArray("float32", 16), this.fillStyle = "", this.strokeStyle = "", this.lineWidth = "", this.lineCap = "", this.lineJoin = "", this.miterLimit = "", this.id = Math.random();
      }
      function CVContextData() {
        this.stack = [], this.cArrPos = 0, this.cTr = new Matrix();
        var t, e = 15;
        for (t = 0; t < e; t += 1) {
          var r = new CanvasContext();
          this.stack[t] = r;
        }
        this._length = e, this.nativeContext = null, this.transformMat = new Matrix(), this.currentOpacity = 1, this.currentFillStyle = "", this.appliedFillStyle = "", this.currentStrokeStyle = "", this.appliedStrokeStyle = "", this.currentLineWidth = "", this.appliedLineWidth = "", this.currentLineCap = "", this.appliedLineCap = "", this.currentLineJoin = "", this.appliedLineJoin = "", this.appliedMiterLimit = "", this.currentMiterLimit = "";
      }
      CVContextData.prototype.duplicate = function() {
        var t = this._length * 2, e = 0;
        for (e = this._length; e < t; e += 1) this.stack[e] = new CanvasContext();
        this._length = t;
      }, CVContextData.prototype.reset = function() {
        this.cArrPos = 0, this.cTr.reset(), this.stack[this.cArrPos].opacity = 1;
      }, CVContextData.prototype.restore = function(t) {
        this.cArrPos -= 1;
        var e = this.stack[this.cArrPos], r = e.transform, i, s = this.cTr.props;
        for (i = 0; i < 16; i += 1) s[i] = r[i];
        if (t) {
          this.nativeContext.restore();
          var a = this.stack[this.cArrPos + 1];
          this.appliedFillStyle = a.fillStyle, this.appliedStrokeStyle = a.strokeStyle, this.appliedLineWidth = a.lineWidth, this.appliedLineCap = a.lineCap, this.appliedLineJoin = a.lineJoin, this.appliedMiterLimit = a.miterLimit;
        }
        this.nativeContext.setTransform(r[0], r[1], r[4], r[5], r[12], r[13]), (t || e.opacity !== -1 && this.currentOpacity !== e.opacity) && (this.nativeContext.globalAlpha = e.opacity, this.currentOpacity = e.opacity), this.currentFillStyle = e.fillStyle, this.currentStrokeStyle = e.strokeStyle, this.currentLineWidth = e.lineWidth, this.currentLineCap = e.lineCap, this.currentLineJoin = e.lineJoin, this.currentMiterLimit = e.miterLimit;
      }, CVContextData.prototype.save = function(t) {
        t && this.nativeContext.save();
        var e = this.cTr.props;
        this._length <= this.cArrPos && this.duplicate();
        var r = this.stack[this.cArrPos], i;
        for (i = 0; i < 16; i += 1) r.transform[i] = e[i];
        this.cArrPos += 1;
        var s = this.stack[this.cArrPos];
        s.opacity = r.opacity, s.fillStyle = r.fillStyle, s.strokeStyle = r.strokeStyle, s.lineWidth = r.lineWidth, s.lineCap = r.lineCap, s.lineJoin = r.lineJoin, s.miterLimit = r.miterLimit;
      }, CVContextData.prototype.setOpacity = function(t) {
        this.stack[this.cArrPos].opacity = t;
      }, CVContextData.prototype.setContext = function(t) {
        this.nativeContext = t;
      }, CVContextData.prototype.fillStyle = function(t) {
        this.stack[this.cArrPos].fillStyle !== t && (this.currentFillStyle = t, this.stack[this.cArrPos].fillStyle = t);
      }, CVContextData.prototype.strokeStyle = function(t) {
        this.stack[this.cArrPos].strokeStyle !== t && (this.currentStrokeStyle = t, this.stack[this.cArrPos].strokeStyle = t);
      }, CVContextData.prototype.lineWidth = function(t) {
        this.stack[this.cArrPos].lineWidth !== t && (this.currentLineWidth = t, this.stack[this.cArrPos].lineWidth = t);
      }, CVContextData.prototype.lineCap = function(t) {
        this.stack[this.cArrPos].lineCap !== t && (this.currentLineCap = t, this.stack[this.cArrPos].lineCap = t);
      }, CVContextData.prototype.lineJoin = function(t) {
        this.stack[this.cArrPos].lineJoin !== t && (this.currentLineJoin = t, this.stack[this.cArrPos].lineJoin = t);
      }, CVContextData.prototype.miterLimit = function(t) {
        this.stack[this.cArrPos].miterLimit !== t && (this.currentMiterLimit = t, this.stack[this.cArrPos].miterLimit = t);
      }, CVContextData.prototype.transform = function(t) {
        this.transformMat.cloneFromProps(t);
        var e = this.cTr;
        this.transformMat.multiply(e), e.cloneFromProps(this.transformMat.props);
        var r = e.props;
        this.nativeContext.setTransform(r[0], r[1], r[4], r[5], r[12], r[13]);
      }, CVContextData.prototype.opacity = function(t) {
        var e = this.stack[this.cArrPos].opacity;
        e *= t < 0 ? 0 : t, this.stack[this.cArrPos].opacity !== e && (this.currentOpacity !== t && (this.nativeContext.globalAlpha = t, this.currentOpacity = t), this.stack[this.cArrPos].opacity = e);
      }, CVContextData.prototype.fill = function(t) {
        this.appliedFillStyle !== this.currentFillStyle && (this.appliedFillStyle = this.currentFillStyle, this.nativeContext.fillStyle = this.appliedFillStyle), this.nativeContext.fill(t);
      }, CVContextData.prototype.fillRect = function(t, e, r, i) {
        this.appliedFillStyle !== this.currentFillStyle && (this.appliedFillStyle = this.currentFillStyle, this.nativeContext.fillStyle = this.appliedFillStyle), this.nativeContext.fillRect(t, e, r, i);
      }, CVContextData.prototype.stroke = function() {
        this.appliedStrokeStyle !== this.currentStrokeStyle && (this.appliedStrokeStyle = this.currentStrokeStyle, this.nativeContext.strokeStyle = this.appliedStrokeStyle), this.appliedLineWidth !== this.currentLineWidth && (this.appliedLineWidth = this.currentLineWidth, this.nativeContext.lineWidth = this.appliedLineWidth), this.appliedLineCap !== this.currentLineCap && (this.appliedLineCap = this.currentLineCap, this.nativeContext.lineCap = this.appliedLineCap), this.appliedLineJoin !== this.currentLineJoin && (this.appliedLineJoin = this.currentLineJoin, this.nativeContext.lineJoin = this.appliedLineJoin), this.appliedMiterLimit !== this.currentMiterLimit && (this.appliedMiterLimit = this.currentMiterLimit, this.nativeContext.miterLimit = this.appliedMiterLimit), this.nativeContext.stroke();
      };
      function CVCompElement(t, e, r) {
        this.completeLayers = false, this.layers = t.layers, this.pendingElements = [], this.elements = createSizedArray(this.layers.length), this.initElement(t, e, r), this.tm = t.tm ? PropertyFactory.getProp(this, t.tm, 0, e.frameRate, this) : {
          _placeholder: true
        };
      }
      extendPrototype([
        CanvasRendererBase,
        ICompElement,
        CVBaseElement
      ], CVCompElement), CVCompElement.prototype.renderInnerContent = function() {
        var t = this.canvasContext;
        t.beginPath(), t.moveTo(0, 0), t.lineTo(this.data.w, 0), t.lineTo(this.data.w, this.data.h), t.lineTo(0, this.data.h), t.lineTo(0, 0), t.clip();
        var e, r = this.layers.length;
        for (e = r - 1; e >= 0; e -= 1) (this.completeLayers || this.elements[e]) && this.elements[e].renderFrame();
      }, CVCompElement.prototype.destroy = function() {
        var t, e = this.layers.length;
        for (t = e - 1; t >= 0; t -= 1) this.elements[t] && this.elements[t].destroy();
        this.layers = null, this.elements = null;
      }, CVCompElement.prototype.createComp = function(t) {
        return new CVCompElement(t, this.globalData, this);
      };
      function CanvasRenderer(t, e) {
        this.animationItem = t, this.renderConfig = {
          clearCanvas: e && e.clearCanvas !== void 0 ? e.clearCanvas : true,
          context: e && e.context || null,
          progressiveLoad: e && e.progressiveLoad || false,
          preserveAspectRatio: e && e.preserveAspectRatio || "xMidYMid meet",
          imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
          contentVisibility: e && e.contentVisibility || "visible",
          className: e && e.className || "",
          id: e && e.id || "",
          runExpressions: !e || e.runExpressions === void 0 || e.runExpressions
        }, this.renderConfig.dpr = e && e.dpr || 1, this.animationItem.wrapper && (this.renderConfig.dpr = e && e.dpr || window.devicePixelRatio || 1), this.renderedFrame = -1, this.globalData = {
          frameNum: -1,
          _mdf: false,
          renderConfig: this.renderConfig,
          currentGlobalAlpha: -1
        }, this.contextData = new CVContextData(), this.elements = [], this.pendingElements = [], this.transformMat = new Matrix(), this.completeLayers = false, this.rendererType = "canvas", this.renderConfig.clearCanvas && (this.ctxTransform = this.contextData.transform.bind(this.contextData), this.ctxOpacity = this.contextData.opacity.bind(this.contextData), this.ctxFillStyle = this.contextData.fillStyle.bind(this.contextData), this.ctxStrokeStyle = this.contextData.strokeStyle.bind(this.contextData), this.ctxLineWidth = this.contextData.lineWidth.bind(this.contextData), this.ctxLineCap = this.contextData.lineCap.bind(this.contextData), this.ctxLineJoin = this.contextData.lineJoin.bind(this.contextData), this.ctxMiterLimit = this.contextData.miterLimit.bind(this.contextData), this.ctxFill = this.contextData.fill.bind(this.contextData), this.ctxFillRect = this.contextData.fillRect.bind(this.contextData), this.ctxStroke = this.contextData.stroke.bind(this.contextData), this.save = this.contextData.save.bind(this.contextData));
      }
      extendPrototype([
        CanvasRendererBase
      ], CanvasRenderer), CanvasRenderer.prototype.createComp = function(t) {
        return new CVCompElement(t, this.globalData, this);
      };
      function HBaseElement() {
      }
      HBaseElement.prototype = {
        checkBlendMode: function() {
        },
        initRendererElement: function() {
          this.baseElement = createTag(this.data.tg || "div"), this.data.hasMask ? (this.svgElement = createNS("svg"), this.layerElement = createNS("g"), this.maskedElement = this.layerElement, this.svgElement.appendChild(this.layerElement), this.baseElement.appendChild(this.svgElement)) : this.layerElement = this.baseElement, styleDiv(this.baseElement);
        },
        createContainerElements: function() {
          this.renderableEffectsManager = new CVEffects(this), this.transformedElement = this.baseElement, this.maskedElement = this.layerElement, this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), this.data.bm !== 0 && this.setBlendMode();
        },
        renderElement: function() {
          var e = this.transformedElement ? this.transformedElement.style : {};
          if (this.finalTransform._matMdf) {
            var r = this.finalTransform.mat.toCSS();
            e.transform = r, e.webkitTransform = r;
          }
          this.finalTransform._opMdf && (e.opacity = this.finalTransform.mProp.o.v);
        },
        renderFrame: function() {
          this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = false));
        },
        destroy: function() {
          this.layerElement = null, this.transformedElement = null, this.matteElement && (this.matteElement = null), this.maskManager && (this.maskManager.destroy(), this.maskManager = null);
        },
        createRenderableComponents: function() {
          this.maskManager = new MaskElement(this.data, this, this.globalData);
        },
        addEffects: function() {
        },
        setMatte: function() {
        }
      }, HBaseElement.prototype.getBaseElement = SVGBaseElement.prototype.getBaseElement, HBaseElement.prototype.destroyBaseElement = HBaseElement.prototype.destroy, HBaseElement.prototype.buildElementParenting = BaseRenderer.prototype.buildElementParenting;
      function HSolidElement(t, e, r) {
        this.initElement(t, e, r);
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        HBaseElement,
        HierarchyElement,
        FrameElement,
        RenderableDOMElement
      ], HSolidElement), HSolidElement.prototype.createContent = function() {
        var t;
        this.data.hasMask ? (t = createNS("rect"), t.setAttribute("width", this.data.sw), t.setAttribute("height", this.data.sh), t.setAttribute("fill", this.data.sc), this.svgElement.setAttribute("width", this.data.sw), this.svgElement.setAttribute("height", this.data.sh)) : (t = createTag("div"), t.style.width = this.data.sw + "px", t.style.height = this.data.sh + "px", t.style.backgroundColor = this.data.sc), this.layerElement.appendChild(t);
      };
      function HShapeElement(t, e, r) {
        this.shapes = [], this.shapesData = t.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.shapesContainer = createNS("g"), this.initElement(t, e, r), this.prevViewData = [], this.currentBBox = {
          x: 999999,
          y: -999999,
          h: 0,
          w: 0
        };
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        HSolidElement,
        SVGShapeElement,
        HBaseElement,
        HierarchyElement,
        FrameElement,
        RenderableElement
      ], HShapeElement), HShapeElement.prototype._renderShapeFrame = HShapeElement.prototype.renderInnerContent, HShapeElement.prototype.createContent = function() {
        var t;
        if (this.baseElement.style.fontSize = 0, this.data.hasMask) this.layerElement.appendChild(this.shapesContainer), t = this.svgElement;
        else {
          t = createNS("svg");
          var e = this.comp.data ? this.comp.data : this.globalData.compSize;
          t.setAttribute("width", e.w), t.setAttribute("height", e.h), t.appendChild(this.shapesContainer), this.layerElement.appendChild(t);
        }
        this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.shapesContainer, 0, [], true), this.filterUniqueShapes(), this.shapeCont = t;
      }, HShapeElement.prototype.getTransformedPoint = function(t, e) {
        var r, i = t.length;
        for (r = 0; r < i; r += 1) e = t[r].mProps.v.applyToPointArray(e[0], e[1], 0);
        return e;
      }, HShapeElement.prototype.calculateShapeBoundingBox = function(t, e) {
        var r = t.sh.v, i = t.transformers, s, a = r._length, n, l, o, p;
        if (!(a <= 1)) {
          for (s = 0; s < a - 1; s += 1) n = this.getTransformedPoint(i, r.v[s]), l = this.getTransformedPoint(i, r.o[s]), o = this.getTransformedPoint(i, r.i[s + 1]), p = this.getTransformedPoint(i, r.v[s + 1]), this.checkBounds(n, l, o, p, e);
          r.c && (n = this.getTransformedPoint(i, r.v[s]), l = this.getTransformedPoint(i, r.o[s]), o = this.getTransformedPoint(i, r.i[0]), p = this.getTransformedPoint(i, r.v[0]), this.checkBounds(n, l, o, p, e));
        }
      }, HShapeElement.prototype.checkBounds = function(t, e, r, i, s) {
        this.getBoundsOfCurve(t, e, r, i);
        var a = this.shapeBoundingBox;
        s.x = bmMin(a.left, s.x), s.xMax = bmMax(a.right, s.xMax), s.y = bmMin(a.top, s.y), s.yMax = bmMax(a.bottom, s.yMax);
      }, HShapeElement.prototype.shapeBoundingBox = {
        left: 0,
        right: 0,
        top: 0,
        bottom: 0
      }, HShapeElement.prototype.tempBoundingBox = {
        x: 0,
        xMax: 0,
        y: 0,
        yMax: 0,
        width: 0,
        height: 0
      }, HShapeElement.prototype.getBoundsOfCurve = function(t, e, r, i) {
        for (var s = [
          [
            t[0],
            i[0]
          ],
          [
            t[1],
            i[1]
          ]
        ], a, n, l, o, p, y, E, u = 0; u < 2; ++u) n = 6 * t[u] - 12 * e[u] + 6 * r[u], a = -3 * t[u] + 9 * e[u] - 9 * r[u] + 3 * i[u], l = 3 * e[u] - 3 * t[u], n |= 0, a |= 0, l |= 0, a === 0 && n === 0 || (a === 0 ? (o = -l / n, o > 0 && o < 1 && s[u].push(this.calculateF(o, t, e, r, i, u))) : (p = n * n - 4 * l * a, p >= 0 && (y = (-n + bmSqrt(p)) / (2 * a), y > 0 && y < 1 && s[u].push(this.calculateF(y, t, e, r, i, u)), E = (-n - bmSqrt(p)) / (2 * a), E > 0 && E < 1 && s[u].push(this.calculateF(E, t, e, r, i, u)))));
        this.shapeBoundingBox.left = bmMin.apply(null, s[0]), this.shapeBoundingBox.top = bmMin.apply(null, s[1]), this.shapeBoundingBox.right = bmMax.apply(null, s[0]), this.shapeBoundingBox.bottom = bmMax.apply(null, s[1]);
      }, HShapeElement.prototype.calculateF = function(t, e, r, i, s, a) {
        return bmPow(1 - t, 3) * e[a] + 3 * bmPow(1 - t, 2) * t * r[a] + 3 * (1 - t) * bmPow(t, 2) * i[a] + bmPow(t, 3) * s[a];
      }, HShapeElement.prototype.calculateBoundingBox = function(t, e) {
        var r, i = t.length;
        for (r = 0; r < i; r += 1) t[r] && t[r].sh ? this.calculateShapeBoundingBox(t[r], e) : t[r] && t[r].it ? this.calculateBoundingBox(t[r].it, e) : t[r] && t[r].style && t[r].w && this.expandStrokeBoundingBox(t[r].w, e);
      }, HShapeElement.prototype.expandStrokeBoundingBox = function(t, e) {
        var r = 0;
        if (t.keyframes) {
          for (var i = 0; i < t.keyframes.length; i += 1) {
            var s = t.keyframes[i].s;
            s > r && (r = s);
          }
          r *= t.mult;
        } else r = t.v * t.mult;
        e.x -= r, e.xMax += r, e.y -= r, e.yMax += r;
      }, HShapeElement.prototype.currentBoxContains = function(t) {
        return this.currentBBox.x <= t.x && this.currentBBox.y <= t.y && this.currentBBox.width + this.currentBBox.x >= t.x + t.width && this.currentBBox.height + this.currentBBox.y >= t.y + t.height;
      }, HShapeElement.prototype.renderInnerContent = function() {
        if (this._renderShapeFrame(), !this.hidden && (this._isFirstFrame || this._mdf)) {
          var t = this.tempBoundingBox, e = 999999;
          if (t.x = e, t.xMax = -e, t.y = e, t.yMax = -e, this.calculateBoundingBox(this.itemsData, t), t.width = t.xMax < t.x ? 0 : t.xMax - t.x, t.height = t.yMax < t.y ? 0 : t.yMax - t.y, this.currentBoxContains(t)) return;
          var r = false;
          if (this.currentBBox.w !== t.width && (this.currentBBox.w = t.width, this.shapeCont.setAttribute("width", t.width), r = true), this.currentBBox.h !== t.height && (this.currentBBox.h = t.height, this.shapeCont.setAttribute("height", t.height), r = true), r || this.currentBBox.x !== t.x || this.currentBBox.y !== t.y) {
            this.currentBBox.w = t.width, this.currentBBox.h = t.height, this.currentBBox.x = t.x, this.currentBBox.y = t.y, this.shapeCont.setAttribute("viewBox", this.currentBBox.x + " " + this.currentBBox.y + " " + this.currentBBox.w + " " + this.currentBBox.h);
            var i = this.shapeCont.style, s = "translate(" + this.currentBBox.x + "px," + this.currentBBox.y + "px)";
            i.transform = s, i.webkitTransform = s;
          }
        }
      };
      function HTextElement(t, e, r) {
        this.textSpans = [], this.textPaths = [], this.currentBBox = {
          x: 999999,
          y: -999999,
          h: 0,
          w: 0
        }, this.renderType = "svg", this.isMasked = false, this.initElement(t, e, r);
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        HBaseElement,
        HierarchyElement,
        FrameElement,
        RenderableDOMElement,
        ITextElement
      ], HTextElement), HTextElement.prototype.createContent = function() {
        if (this.isMasked = this.checkMasks(), this.isMasked) {
          this.renderType = "svg", this.compW = this.comp.data.w, this.compH = this.comp.data.h, this.svgElement.setAttribute("width", this.compW), this.svgElement.setAttribute("height", this.compH);
          var t = createNS("g");
          this.maskedElement.appendChild(t), this.innerElem = t;
        } else this.renderType = "html", this.innerElem = this.layerElement;
        this.checkParenting();
      }, HTextElement.prototype.buildNewText = function() {
        var t = this.textProperty.currentData;
        this.renderedLetters = createSizedArray(t.l ? t.l.length : 0);
        var e = this.innerElem.style, r = t.fc ? this.buildColor(t.fc) : "rgba(0,0,0,0)";
        e.fill = r, e.color = r, t.sc && (e.stroke = this.buildColor(t.sc), e.strokeWidth = t.sw + "px");
        var i = this.globalData.fontManager.getFontByName(t.f);
        if (!this.globalData.fontManager.chars) if (e.fontSize = t.finalSize + "px", e.lineHeight = t.finalSize + "px", i.fClass) this.innerElem.className = i.fClass;
        else {
          e.fontFamily = i.fFamily;
          var s = t.fWeight, a = t.fStyle;
          e.fontStyle = a, e.fontWeight = s;
        }
        var n, l, o = t.l;
        l = o.length;
        var p, y, E, u = this.mHelper, x, g = "", d = 0;
        for (n = 0; n < l; n += 1) {
          if (this.globalData.fontManager.chars ? (this.textPaths[d] ? p = this.textPaths[d] : (p = createNS("path"), p.setAttribute("stroke-linecap", lineCapEnum[1]), p.setAttribute("stroke-linejoin", lineJoinEnum[2]), p.setAttribute("stroke-miterlimit", "4")), this.isMasked || (this.textSpans[d] ? (y = this.textSpans[d], E = y.children[0]) : (y = createTag("div"), y.style.lineHeight = 0, E = createNS("svg"), E.appendChild(p), styleDiv(y)))) : this.isMasked ? p = this.textPaths[d] ? this.textPaths[d] : createNS("text") : this.textSpans[d] ? (y = this.textSpans[d], p = this.textPaths[d]) : (y = createTag("span"), styleDiv(y), p = createTag("span"), styleDiv(p), y.appendChild(p)), this.globalData.fontManager.chars) {
            var A = this.globalData.fontManager.getCharData(t.finalText[n], i.fStyle, this.globalData.fontManager.getFontByName(t.f).fFamily), c;
            if (A ? c = A.data : c = null, u.reset(), c && c.shapes && c.shapes.length && (x = c.shapes[0].it, u.scale(t.finalSize / 100, t.finalSize / 100), g = this.createPathShape(u, x), p.setAttribute("d", g)), this.isMasked) this.innerElem.appendChild(p);
            else {
              if (this.innerElem.appendChild(y), c && c.shapes) {
                document.body.appendChild(E);
                var m = E.getBBox();
                E.setAttribute("width", m.width + 2), E.setAttribute("height", m.height + 2), E.setAttribute("viewBox", m.x - 1 + " " + (m.y - 1) + " " + (m.width + 2) + " " + (m.height + 2));
                var f = E.style, b = "translate(" + (m.x - 1) + "px," + (m.y - 1) + "px)";
                f.transform = b, f.webkitTransform = b, o[n].yOffset = m.y - 1;
              } else E.setAttribute("width", 1), E.setAttribute("height", 1);
              y.appendChild(E);
            }
          } else if (p.textContent = o[n].val, p.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), this.isMasked) this.innerElem.appendChild(p);
          else {
            this.innerElem.appendChild(y);
            var C = p.style, _ = "translate3d(0," + -t.finalSize / 1.2 + "px,0)";
            C.transform = _, C.webkitTransform = _;
          }
          this.isMasked ? this.textSpans[d] = p : this.textSpans[d] = y, this.textSpans[d].style.display = "block", this.textPaths[d] = p, d += 1;
        }
        for (; d < this.textSpans.length; ) this.textSpans[d].style.display = "none", d += 1;
      }, HTextElement.prototype.renderInnerContent = function() {
        this.validateText();
        var t;
        if (this.data.singleShape) {
          if (!this._isFirstFrame && !this.lettersChangedFlag) return;
          if (this.isMasked && this.finalTransform._matMdf) {
            this.svgElement.setAttribute("viewBox", -this.finalTransform.mProp.p.v[0] + " " + -this.finalTransform.mProp.p.v[1] + " " + this.compW + " " + this.compH), t = this.svgElement.style;
            var e = "translate(" + -this.finalTransform.mProp.p.v[0] + "px," + -this.finalTransform.mProp.p.v[1] + "px)";
            t.transform = e, t.webkitTransform = e;
          }
        }
        if (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), !(!this.lettersChangedFlag && !this.textAnimator.lettersChangedFlag)) {
          var r, i, s = 0, a = this.textAnimator.renderedLetters, n = this.textProperty.currentData.l;
          i = n.length;
          var l, o, p;
          for (r = 0; r < i; r += 1) n[r].n ? s += 1 : (o = this.textSpans[r], p = this.textPaths[r], l = a[s], s += 1, l._mdf.m && (this.isMasked ? o.setAttribute("transform", l.m) : (o.style.webkitTransform = l.m, o.style.transform = l.m)), o.style.opacity = l.o, l.sw && l._mdf.sw && p.setAttribute("stroke-width", l.sw), l.sc && l._mdf.sc && p.setAttribute("stroke", l.sc), l.fc && l._mdf.fc && (p.setAttribute("fill", l.fc), p.style.color = l.fc));
          if (this.innerElem.getBBox && !this.hidden && (this._isFirstFrame || this._mdf)) {
            var y = this.innerElem.getBBox();
            this.currentBBox.w !== y.width && (this.currentBBox.w = y.width, this.svgElement.setAttribute("width", y.width)), this.currentBBox.h !== y.height && (this.currentBBox.h = y.height, this.svgElement.setAttribute("height", y.height));
            var E = 1;
            if (this.currentBBox.w !== y.width + E * 2 || this.currentBBox.h !== y.height + E * 2 || this.currentBBox.x !== y.x - E || this.currentBBox.y !== y.y - E) {
              this.currentBBox.w = y.width + E * 2, this.currentBBox.h = y.height + E * 2, this.currentBBox.x = y.x - E, this.currentBBox.y = y.y - E, this.svgElement.setAttribute("viewBox", this.currentBBox.x + " " + this.currentBBox.y + " " + this.currentBBox.w + " " + this.currentBBox.h), t = this.svgElement.style;
              var u = "translate(" + this.currentBBox.x + "px," + this.currentBBox.y + "px)";
              t.transform = u, t.webkitTransform = u;
            }
          }
        }
      };
      function HCameraElement(t, e, r) {
        this.initFrame(), this.initBaseData(t, e, r), this.initHierarchy();
        var i = PropertyFactory.getProp;
        if (this.pe = i(this, t.pe, 0, 0, this), t.ks.p.s ? (this.px = i(this, t.ks.p.x, 1, 0, this), this.py = i(this, t.ks.p.y, 1, 0, this), this.pz = i(this, t.ks.p.z, 1, 0, this)) : this.p = i(this, t.ks.p, 1, 0, this), t.ks.a && (this.a = i(this, t.ks.a, 1, 0, this)), t.ks.or.k.length && t.ks.or.k[0].to) {
          var s, a = t.ks.or.k.length;
          for (s = 0; s < a; s += 1) t.ks.or.k[s].to = null, t.ks.or.k[s].ti = null;
        }
        this.or = i(this, t.ks.or, 1, degToRads, this), this.or.sh = true, this.rx = i(this, t.ks.rx, 0, degToRads, this), this.ry = i(this, t.ks.ry, 0, degToRads, this), this.rz = i(this, t.ks.rz, 0, degToRads, this), this.mat = new Matrix(), this._prevMat = new Matrix(), this._isFirstFrame = true, this.finalTransform = {
          mProp: this
        };
      }
      extendPrototype([
        BaseElement,
        FrameElement,
        HierarchyElement
      ], HCameraElement), HCameraElement.prototype.setup = function() {
        var t, e = this.comp.threeDElements.length, r, i, s;
        for (t = 0; t < e; t += 1) if (r = this.comp.threeDElements[t], r.type === "3d") {
          i = r.perspectiveElem.style, s = r.container.style;
          var a = this.pe.v + "px", n = "0px 0px 0px", l = "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)";
          i.perspective = a, i.webkitPerspective = a, s.transformOrigin = n, s.mozTransformOrigin = n, s.webkitTransformOrigin = n, i.transform = l, i.webkitTransform = l;
        }
      }, HCameraElement.prototype.createElements = function() {
      }, HCameraElement.prototype.hide = function() {
      }, HCameraElement.prototype.renderFrame = function() {
        var t = this._isFirstFrame, e, r;
        if (this.hierarchy) for (r = this.hierarchy.length, e = 0; e < r; e += 1) t = this.hierarchy[e].finalTransform.mProp._mdf || t;
        if (t || this.pe._mdf || this.p && this.p._mdf || this.px && (this.px._mdf || this.py._mdf || this.pz._mdf) || this.rx._mdf || this.ry._mdf || this.rz._mdf || this.or._mdf || this.a && this.a._mdf) {
          if (this.mat.reset(), this.hierarchy) for (r = this.hierarchy.length - 1, e = r; e >= 0; e -= 1) {
            var i = this.hierarchy[e].finalTransform.mProp;
            this.mat.translate(-i.p.v[0], -i.p.v[1], i.p.v[2]), this.mat.rotateX(-i.or.v[0]).rotateY(-i.or.v[1]).rotateZ(i.or.v[2]), this.mat.rotateX(-i.rx.v).rotateY(-i.ry.v).rotateZ(i.rz.v), this.mat.scale(1 / i.s.v[0], 1 / i.s.v[1], 1 / i.s.v[2]), this.mat.translate(i.a.v[0], i.a.v[1], i.a.v[2]);
          }
          if (this.p ? this.mat.translate(-this.p.v[0], -this.p.v[1], this.p.v[2]) : this.mat.translate(-this.px.v, -this.py.v, this.pz.v), this.a) {
            var s;
            this.p ? s = [
              this.p.v[0] - this.a.v[0],
              this.p.v[1] - this.a.v[1],
              this.p.v[2] - this.a.v[2]
            ] : s = [
              this.px.v - this.a.v[0],
              this.py.v - this.a.v[1],
              this.pz.v - this.a.v[2]
            ];
            var a = Math.sqrt(Math.pow(s[0], 2) + Math.pow(s[1], 2) + Math.pow(s[2], 2)), n = [
              s[0] / a,
              s[1] / a,
              s[2] / a
            ], l = Math.sqrt(n[2] * n[2] + n[0] * n[0]), o = Math.atan2(n[1], l), p = Math.atan2(n[0], -n[2]);
            this.mat.rotateY(p).rotateX(-o);
          }
          this.mat.rotateX(-this.rx.v).rotateY(-this.ry.v).rotateZ(this.rz.v), this.mat.rotateX(-this.or.v[0]).rotateY(-this.or.v[1]).rotateZ(this.or.v[2]), this.mat.translate(this.globalData.compSize.w / 2, this.globalData.compSize.h / 2, 0), this.mat.translate(0, 0, this.pe.v);
          var y = !this._prevMat.equals(this.mat);
          if ((y || this.pe._mdf) && this.comp.threeDElements) {
            r = this.comp.threeDElements.length;
            var E, u, x;
            for (e = 0; e < r; e += 1) if (E = this.comp.threeDElements[e], E.type === "3d") {
              if (y) {
                var g = this.mat.toCSS();
                x = E.container.style, x.transform = g, x.webkitTransform = g;
              }
              this.pe._mdf && (u = E.perspectiveElem.style, u.perspective = this.pe.v + "px", u.webkitPerspective = this.pe.v + "px");
            }
            this.mat.clone(this._prevMat);
          }
        }
        this._isFirstFrame = false;
      }, HCameraElement.prototype.prepareFrame = function(t) {
        this.prepareProperties(t, true);
      }, HCameraElement.prototype.destroy = function() {
      }, HCameraElement.prototype.getBaseElement = function() {
        return null;
      };
      function HImageElement(t, e, r) {
        this.assetData = e.getAssetData(t.refId), this.initElement(t, e, r);
      }
      extendPrototype([
        BaseElement,
        TransformElement,
        HBaseElement,
        HSolidElement,
        HierarchyElement,
        FrameElement,
        RenderableElement
      ], HImageElement), HImageElement.prototype.createContent = function() {
        var t = this.globalData.getAssetsPath(this.assetData), e = new Image();
        this.data.hasMask ? (this.imageElem = createNS("image"), this.imageElem.setAttribute("width", this.assetData.w + "px"), this.imageElem.setAttribute("height", this.assetData.h + "px"), this.imageElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", t), this.layerElement.appendChild(this.imageElem), this.baseElement.setAttribute("width", this.assetData.w), this.baseElement.setAttribute("height", this.assetData.h)) : this.layerElement.appendChild(e), e.crossOrigin = "anonymous", e.src = t, this.data.ln && this.baseElement.setAttribute("id", this.data.ln);
      };
      function HybridRendererBase(t, e) {
        this.animationItem = t, this.layers = null, this.renderedFrame = -1, this.renderConfig = {
          className: e && e.className || "",
          imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
          hideOnTransparent: !(e && e.hideOnTransparent === false),
          filterSize: {
            width: e && e.filterSize && e.filterSize.width || "400%",
            height: e && e.filterSize && e.filterSize.height || "400%",
            x: e && e.filterSize && e.filterSize.x || "-100%",
            y: e && e.filterSize && e.filterSize.y || "-100%"
          }
        }, this.globalData = {
          _mdf: false,
          frameNum: -1,
          renderConfig: this.renderConfig
        }, this.pendingElements = [], this.elements = [], this.threeDElements = [], this.destroyed = false, this.camera = null, this.supports3d = true, this.rendererType = "html";
      }
      extendPrototype([
        BaseRenderer
      ], HybridRendererBase), HybridRendererBase.prototype.buildItem = SVGRenderer.prototype.buildItem, HybridRendererBase.prototype.checkPendingElements = function() {
        for (; this.pendingElements.length; ) {
          var t = this.pendingElements.pop();
          t.checkParenting();
        }
      }, HybridRendererBase.prototype.appendElementInPos = function(t, e) {
        var r = t.getBaseElement();
        if (r) {
          var i = this.layers[e];
          if (!i.ddd || !this.supports3d) if (this.threeDElements) this.addTo3dContainer(r, e);
          else {
            for (var s = 0, a, n, l; s < e; ) this.elements[s] && this.elements[s] !== true && this.elements[s].getBaseElement && (n = this.elements[s], l = this.layers[s].ddd ? this.getThreeDContainerByPos(s) : n.getBaseElement(), a = l || a), s += 1;
            a ? (!i.ddd || !this.supports3d) && this.layerElement.insertBefore(r, a) : (!i.ddd || !this.supports3d) && this.layerElement.appendChild(r);
          }
          else this.addTo3dContainer(r, e);
        }
      }, HybridRendererBase.prototype.createShape = function(t) {
        return this.supports3d ? new HShapeElement(t, this.globalData, this) : new SVGShapeElement(t, this.globalData, this);
      }, HybridRendererBase.prototype.createText = function(t) {
        return this.supports3d ? new HTextElement(t, this.globalData, this) : new SVGTextLottieElement(t, this.globalData, this);
      }, HybridRendererBase.prototype.createCamera = function(t) {
        return this.camera = new HCameraElement(t, this.globalData, this), this.camera;
      }, HybridRendererBase.prototype.createImage = function(t) {
        return this.supports3d ? new HImageElement(t, this.globalData, this) : new IImageElement(t, this.globalData, this);
      }, HybridRendererBase.prototype.createSolid = function(t) {
        return this.supports3d ? new HSolidElement(t, this.globalData, this) : new ISolidElement(t, this.globalData, this);
      }, HybridRendererBase.prototype.createNull = SVGRenderer.prototype.createNull, HybridRendererBase.prototype.getThreeDContainerByPos = function(t) {
        for (var e = 0, r = this.threeDElements.length; e < r; ) {
          if (this.threeDElements[e].startPos <= t && this.threeDElements[e].endPos >= t) return this.threeDElements[e].perspectiveElem;
          e += 1;
        }
        return null;
      }, HybridRendererBase.prototype.createThreeDContainer = function(t, e) {
        var r = createTag("div"), i, s;
        styleDiv(r);
        var a = createTag("div");
        if (styleDiv(a), e === "3d") {
          i = r.style, i.width = this.globalData.compSize.w + "px", i.height = this.globalData.compSize.h + "px";
          var n = "50% 50%";
          i.webkitTransformOrigin = n, i.mozTransformOrigin = n, i.transformOrigin = n, s = a.style;
          var l = "matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)";
          s.transform = l, s.webkitTransform = l;
        }
        r.appendChild(a);
        var o = {
          container: a,
          perspectiveElem: r,
          startPos: t,
          endPos: t,
          type: e
        };
        return this.threeDElements.push(o), o;
      }, HybridRendererBase.prototype.build3dContainers = function() {
        var t, e = this.layers.length, r, i = "";
        for (t = 0; t < e; t += 1) this.layers[t].ddd && this.layers[t].ty !== 3 ? (i !== "3d" && (i = "3d", r = this.createThreeDContainer(t, "3d")), r.endPos = Math.max(r.endPos, t)) : (i !== "2d" && (i = "2d", r = this.createThreeDContainer(t, "2d")), r.endPos = Math.max(r.endPos, t));
        for (e = this.threeDElements.length, t = e - 1; t >= 0; t -= 1) this.resizerElem.appendChild(this.threeDElements[t].perspectiveElem);
      }, HybridRendererBase.prototype.addTo3dContainer = function(t, e) {
        for (var r = 0, i = this.threeDElements.length; r < i; ) {
          if (e <= this.threeDElements[r].endPos) {
            for (var s = this.threeDElements[r].startPos, a; s < e; ) this.elements[s] && this.elements[s].getBaseElement && (a = this.elements[s].getBaseElement()), s += 1;
            a ? this.threeDElements[r].container.insertBefore(t, a) : this.threeDElements[r].container.appendChild(t);
            break;
          }
          r += 1;
        }
      }, HybridRendererBase.prototype.configAnimation = function(t) {
        var e = createTag("div"), r = this.animationItem.wrapper, i = e.style;
        i.width = t.w + "px", i.height = t.h + "px", this.resizerElem = e, styleDiv(e), i.transformStyle = "flat", i.mozTransformStyle = "flat", i.webkitTransformStyle = "flat", this.renderConfig.className && e.setAttribute("class", this.renderConfig.className), r.appendChild(e), i.overflow = "hidden";
        var s = createNS("svg");
        s.setAttribute("width", "1"), s.setAttribute("height", "1"), styleDiv(s), this.resizerElem.appendChild(s);
        var a = createNS("defs");
        s.appendChild(a), this.data = t, this.setupGlobalData(t, s), this.globalData.defs = a, this.layers = t.layers, this.layerElement = this.resizerElem, this.build3dContainers(), this.updateContainerSize();
      }, HybridRendererBase.prototype.destroy = function() {
        this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.animationItem.container = null, this.globalData.defs = null;
        var t, e = this.layers ? this.layers.length : 0;
        for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy && this.elements[t].destroy();
        this.elements.length = 0, this.destroyed = true, this.animationItem = null;
      }, HybridRendererBase.prototype.updateContainerSize = function() {
        var t = this.animationItem.wrapper.offsetWidth, e = this.animationItem.wrapper.offsetHeight, r = t / e, i = this.globalData.compSize.w / this.globalData.compSize.h, s, a, n, l;
        i > r ? (s = t / this.globalData.compSize.w, a = t / this.globalData.compSize.w, n = 0, l = (e - this.globalData.compSize.h * (t / this.globalData.compSize.w)) / 2) : (s = e / this.globalData.compSize.h, a = e / this.globalData.compSize.h, n = (t - this.globalData.compSize.w * (e / this.globalData.compSize.h)) / 2, l = 0);
        var o = this.resizerElem.style;
        o.webkitTransform = "matrix3d(" + s + ",0,0,0,0," + a + ",0,0,0,0,1,0," + n + "," + l + ",0,1)", o.transform = o.webkitTransform;
      }, HybridRendererBase.prototype.renderFrame = SVGRenderer.prototype.renderFrame, HybridRendererBase.prototype.hide = function() {
        this.resizerElem.style.display = "none";
      }, HybridRendererBase.prototype.show = function() {
        this.resizerElem.style.display = "block";
      }, HybridRendererBase.prototype.initItems = function() {
        if (this.buildAllItems(), this.camera) this.camera.setup();
        else {
          var t = this.globalData.compSize.w, e = this.globalData.compSize.h, r, i = this.threeDElements.length;
          for (r = 0; r < i; r += 1) {
            var s = this.threeDElements[r].perspectiveElem.style;
            s.webkitPerspective = Math.sqrt(Math.pow(t, 2) + Math.pow(e, 2)) + "px", s.perspective = s.webkitPerspective;
          }
        }
      }, HybridRendererBase.prototype.searchExtraCompositions = function(t) {
        var e, r = t.length, i = createTag("div");
        for (e = 0; e < r; e += 1) if (t[e].xt) {
          var s = this.createComp(t[e], i, this.globalData.comp, null);
          s.initExpressions(), this.globalData.projectInterface.registerComposition(s);
        }
      };
      function HCompElement(t, e, r) {
        this.layers = t.layers, this.supports3d = !t.hasMask, this.completeLayers = false, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(t, e, r), this.tm = t.tm ? PropertyFactory.getProp(this, t.tm, 0, e.frameRate, this) : {
          _placeholder: true
        };
      }
      extendPrototype([
        HybridRendererBase,
        ICompElement,
        HBaseElement
      ], HCompElement), HCompElement.prototype._createBaseContainerElements = HCompElement.prototype.createContainerElements, HCompElement.prototype.createContainerElements = function() {
        this._createBaseContainerElements(), this.data.hasMask ? (this.svgElement.setAttribute("width", this.data.w), this.svgElement.setAttribute("height", this.data.h), this.transformedElement = this.baseElement) : this.transformedElement = this.layerElement;
      }, HCompElement.prototype.addTo3dContainer = function(t, e) {
        for (var r = 0, i; r < e; ) this.elements[r] && this.elements[r].getBaseElement && (i = this.elements[r].getBaseElement()), r += 1;
        i ? this.layerElement.insertBefore(t, i) : this.layerElement.appendChild(t);
      }, HCompElement.prototype.createComp = function(t) {
        return this.supports3d ? new HCompElement(t, this.globalData, this) : new SVGCompElement(t, this.globalData, this);
      };
      function HybridRenderer(t, e) {
        this.animationItem = t, this.layers = null, this.renderedFrame = -1, this.renderConfig = {
          className: e && e.className || "",
          imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
          hideOnTransparent: !(e && e.hideOnTransparent === false),
          filterSize: {
            width: e && e.filterSize && e.filterSize.width || "400%",
            height: e && e.filterSize && e.filterSize.height || "400%",
            x: e && e.filterSize && e.filterSize.x || "-100%",
            y: e && e.filterSize && e.filterSize.y || "-100%"
          },
          runExpressions: !e || e.runExpressions === void 0 || e.runExpressions
        }, this.globalData = {
          _mdf: false,
          frameNum: -1,
          renderConfig: this.renderConfig
        }, this.pendingElements = [], this.elements = [], this.threeDElements = [], this.destroyed = false, this.camera = null, this.supports3d = true, this.rendererType = "html";
      }
      extendPrototype([
        HybridRendererBase
      ], HybridRenderer), HybridRenderer.prototype.createComp = function(t) {
        return this.supports3d ? new HCompElement(t, this.globalData, this) : new SVGCompElement(t, this.globalData, this);
      };
      var CompExpressionInterface = /* @__PURE__ */ (function() {
        return function(t) {
          function e(r) {
            for (var i = 0, s = t.layers.length; i < s; ) {
              if (t.layers[i].nm === r || t.layers[i].ind === r) return t.elements[i].layerInterface;
              i += 1;
            }
            return null;
          }
          return Object.defineProperty(e, "_name", {
            value: t.data.nm
          }), e.layer = e, e.pixelAspect = 1, e.height = t.data.h || t.globalData.compSize.h, e.width = t.data.w || t.globalData.compSize.w, e.pixelAspect = 1, e.frameDuration = 1 / t.globalData.frameRate, e.displayStartTime = 0, e.numLayers = t.layers.length, e;
        };
      })();
      function _typeof$2(t) {
        "@babel/helpers - typeof";
        return _typeof$2 = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
          return typeof e;
        } : function(e) {
          return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, _typeof$2(t);
      }
      function seedRandom(t, e) {
        var r = this, i = 256, s = 6, a = 52, n = "random", l = e.pow(i, s), o = e.pow(2, a), p = o * 2, y = i - 1, E;
        function u(f, b, C) {
          var _ = [];
          b = b === true ? {
            entropy: true
          } : b || {};
          var T = A(d(b.entropy ? [
            f,
            m(t)
          ] : f === null ? c() : f, 3), _), I = new x(_), L = function() {
            for (var O = I.g(s), D = l, N = 0; O < o; ) O = (O + N) * i, D *= i, N = I.g(1);
            for (; O >= p; ) O /= 2, D /= 2, N >>>= 1;
            return (O + N) / D;
          };
          return L.int32 = function() {
            return I.g(4) | 0;
          }, L.quick = function() {
            return I.g(4) / 4294967296;
          }, L.double = L, A(m(I.S), t), (b.pass || C || function(j, O, D, N) {
            return N && (N.S && g(N, I), j.state = function() {
              return g(I, {});
            }), D ? (e[n] = j, O) : j;
          })(L, T, "global" in b ? b.global : this == e, b.state);
        }
        e["seed" + n] = u;
        function x(f) {
          var b, C = f.length, _ = this, T = 0, I = _.i = _.j = 0, L = _.S = [];
          for (C || (f = [
            C++
          ]); T < i; ) L[T] = T++;
          for (T = 0; T < i; T++) L[T] = L[I = y & I + f[T % C] + (b = L[T])], L[I] = b;
          _.g = function(j) {
            for (var O, D = 0, N = _.i, H = _.j, R = _.S; j--; ) O = R[N = y & N + 1], D = D * i + R[y & (R[N] = R[H = y & H + O]) + (R[H] = O)];
            return _.i = N, _.j = H, D;
          };
        }
        function g(f, b) {
          return b.i = f.i, b.j = f.j, b.S = f.S.slice(), b;
        }
        function d(f, b) {
          var C = [], _ = _typeof$2(f), T;
          if (b && _ == "object") for (T in f) try {
            C.push(d(f[T], b - 1));
          } catch {
          }
          return C.length ? C : _ == "string" ? f : f + "\0";
        }
        function A(f, b) {
          for (var C = f + "", _, T = 0; T < C.length; ) b[y & T] = y & (_ ^= b[y & T] * 19) + C.charCodeAt(T++);
          return m(b);
        }
        function c() {
          try {
            var f = new Uint8Array(i);
            return (r.crypto || r.msCrypto).getRandomValues(f), m(f);
          } catch {
            var b = r.navigator, C = b && b.plugins;
            return [
              +/* @__PURE__ */ new Date(),
              r,
              C,
              r.screen,
              m(t)
            ];
          }
        }
        function m(f) {
          return String.fromCharCode.apply(0, f);
        }
        A(e.random(), t);
      }
      function initialize$2(t) {
        seedRandom([], t);
      }
      var propTypes = {
        SHAPE: "shape"
      };
      function _typeof$1(t) {
        "@babel/helpers - typeof";
        return _typeof$1 = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
          return typeof e;
        } : function(e) {
          return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, _typeof$1(t);
      }
      var ExpressionManager = (function() {
        var ob = {}, Math = BMMath, window = null, document = null, XMLHttpRequest = null, fetch = null, frames = null, _lottieGlobal = {};
        initialize$2(BMMath);
        function resetFrame() {
          _lottieGlobal = {};
        }
        function $bm_isInstanceOfArray(t) {
          return t.constructor === Array || t.constructor === Float32Array;
        }
        function isNumerable(t, e) {
          return t === "number" || e instanceof Number || t === "boolean" || t === "string";
        }
        function $bm_neg(t) {
          var e = _typeof$1(t);
          if (e === "number" || t instanceof Number || e === "boolean") return -t;
          if ($bm_isInstanceOfArray(t)) {
            var r, i = t.length, s = [];
            for (r = 0; r < i; r += 1) s[r] = -t[r];
            return s;
          }
          return t.propType ? t.v : -t;
        }
        var easeInBez = BezierFactory.getBezierEasing(0.333, 0, 0.833, 0.833, "easeIn").get, easeOutBez = BezierFactory.getBezierEasing(0.167, 0.167, 0.667, 1, "easeOut").get, easeInOutBez = BezierFactory.getBezierEasing(0.33, 0, 0.667, 1, "easeInOut").get;
        function sum(t, e) {
          var r = _typeof$1(t), i = _typeof$1(e);
          if (isNumerable(r, t) && isNumerable(i, e) || r === "string" || i === "string") return t + e;
          if ($bm_isInstanceOfArray(t) && isNumerable(i, e)) return t = t.slice(0), t[0] += e, t;
          if (isNumerable(r, t) && $bm_isInstanceOfArray(e)) return e = e.slice(0), e[0] = t + e[0], e;
          if ($bm_isInstanceOfArray(t) && $bm_isInstanceOfArray(e)) {
            for (var s = 0, a = t.length, n = e.length, l = []; s < a || s < n; ) (typeof t[s] == "number" || t[s] instanceof Number) && (typeof e[s] == "number" || e[s] instanceof Number) ? l[s] = t[s] + e[s] : l[s] = e[s] === void 0 ? t[s] : t[s] || e[s], s += 1;
            return l;
          }
          return 0;
        }
        var add = sum;
        function sub(t, e) {
          var r = _typeof$1(t), i = _typeof$1(e);
          if (isNumerable(r, t) && isNumerable(i, e)) return r === "string" && (t = parseInt(t, 10)), i === "string" && (e = parseInt(e, 10)), t - e;
          if ($bm_isInstanceOfArray(t) && isNumerable(i, e)) return t = t.slice(0), t[0] -= e, t;
          if (isNumerable(r, t) && $bm_isInstanceOfArray(e)) return e = e.slice(0), e[0] = t - e[0], e;
          if ($bm_isInstanceOfArray(t) && $bm_isInstanceOfArray(e)) {
            for (var s = 0, a = t.length, n = e.length, l = []; s < a || s < n; ) (typeof t[s] == "number" || t[s] instanceof Number) && (typeof e[s] == "number" || e[s] instanceof Number) ? l[s] = t[s] - e[s] : l[s] = e[s] === void 0 ? t[s] : t[s] || e[s], s += 1;
            return l;
          }
          return 0;
        }
        function mul(t, e) {
          var r = _typeof$1(t), i = _typeof$1(e), s;
          if (isNumerable(r, t) && isNumerable(i, e)) return t * e;
          var a, n;
          if ($bm_isInstanceOfArray(t) && isNumerable(i, e)) {
            for (n = t.length, s = createTypedArray("float32", n), a = 0; a < n; a += 1) s[a] = t[a] * e;
            return s;
          }
          if (isNumerable(r, t) && $bm_isInstanceOfArray(e)) {
            for (n = e.length, s = createTypedArray("float32", n), a = 0; a < n; a += 1) s[a] = t * e[a];
            return s;
          }
          return 0;
        }
        function div(t, e) {
          var r = _typeof$1(t), i = _typeof$1(e), s;
          if (isNumerable(r, t) && isNumerable(i, e)) return t / e;
          var a, n;
          if ($bm_isInstanceOfArray(t) && isNumerable(i, e)) {
            for (n = t.length, s = createTypedArray("float32", n), a = 0; a < n; a += 1) s[a] = t[a] / e;
            return s;
          }
          if (isNumerable(r, t) && $bm_isInstanceOfArray(e)) {
            for (n = e.length, s = createTypedArray("float32", n), a = 0; a < n; a += 1) s[a] = t / e[a];
            return s;
          }
          return 0;
        }
        function mod(t, e) {
          return typeof t == "string" && (t = parseInt(t, 10)), typeof e == "string" && (e = parseInt(e, 10)), t % e;
        }
        var $bm_sum = sum, $bm_sub = sub, $bm_mul = mul, $bm_div = div, $bm_mod = mod;
        function clamp(t, e, r) {
          if (e > r) {
            var i = r;
            r = e, e = i;
          }
          return Math.min(Math.max(t, e), r);
        }
        function radiansToDegrees(t) {
          return t / degToRads;
        }
        var radians_to_degrees = radiansToDegrees;
        function degreesToRadians(t) {
          return t * degToRads;
        }
        var degrees_to_radians = radiansToDegrees, helperLengthArray = [
          0,
          0,
          0,
          0,
          0,
          0
        ];
        function length(t, e) {
          if (typeof t == "number" || t instanceof Number) return e = e || 0, Math.abs(t - e);
          e || (e = helperLengthArray);
          var r, i = Math.min(t.length, e.length), s = 0;
          for (r = 0; r < i; r += 1) s += Math.pow(e[r] - t[r], 2);
          return Math.sqrt(s);
        }
        function normalize(t) {
          return div(t, length(t));
        }
        function rgbToHsl(t) {
          var e = t[0], r = t[1], i = t[2], s = Math.max(e, r, i), a = Math.min(e, r, i), n, l, o = (s + a) / 2;
          if (s === a) n = 0, l = 0;
          else {
            var p = s - a;
            switch (l = o > 0.5 ? p / (2 - s - a) : p / (s + a), s) {
              case e:
                n = (r - i) / p + (r < i ? 6 : 0);
                break;
              case r:
                n = (i - e) / p + 2;
                break;
              case i:
                n = (e - r) / p + 4;
                break;
            }
            n /= 6;
          }
          return [
            n,
            l,
            o,
            t[3]
          ];
        }
        function hue2rgb(t, e, r) {
          return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? t + (e - t) * 6 * r : r < 1 / 2 ? e : r < 2 / 3 ? t + (e - t) * (2 / 3 - r) * 6 : t;
        }
        function hslToRgb(t) {
          var e = t[0], r = t[1], i = t[2], s, a, n;
          if (r === 0) s = i, n = i, a = i;
          else {
            var l = i < 0.5 ? i * (1 + r) : i + r - i * r, o = 2 * i - l;
            s = hue2rgb(o, l, e + 1 / 3), a = hue2rgb(o, l, e), n = hue2rgb(o, l, e - 1 / 3);
          }
          return [
            s,
            a,
            n,
            t[3]
          ];
        }
        function linear(t, e, r, i, s) {
          if ((i === void 0 || s === void 0) && (i = e, s = r, e = 0, r = 1), r < e) {
            var a = r;
            r = e, e = a;
          }
          if (t <= e) return i;
          if (t >= r) return s;
          var n = r === e ? 0 : (t - e) / (r - e);
          if (!i.length) return i + (s - i) * n;
          var l, o = i.length, p = createTypedArray("float32", o);
          for (l = 0; l < o; l += 1) p[l] = i[l] + (s[l] - i[l]) * n;
          return p;
        }
        function random(t, e) {
          if (e === void 0 && (t === void 0 ? (t = 0, e = 1) : (e = t, t = void 0)), e.length) {
            var r, i = e.length;
            t || (t = createTypedArray("float32", i));
            var s = createTypedArray("float32", i), a = BMMath.random();
            for (r = 0; r < i; r += 1) s[r] = t[r] + a * (e[r] - t[r]);
            return s;
          }
          t === void 0 && (t = 0);
          var n = BMMath.random();
          return t + n * (e - t);
        }
        function createPath(t, e, r, i) {
          var s, a = t.length, n = shapePool.newElement();
          n.setPathData(!!i, a);
          var l = [
            0,
            0
          ], o, p;
          for (s = 0; s < a; s += 1) o = e && e[s] ? e[s] : l, p = r && r[s] ? r[s] : l, n.setTripleAt(t[s][0], t[s][1], p[0] + t[s][0], p[1] + t[s][1], o[0] + t[s][0], o[1] + t[s][1], s, true);
          return n;
        }
        function initiateExpression(elem, data, property) {
          function noOp(t) {
            return t;
          }
          if (!elem.globalData.renderConfig.runExpressions) return noOp;
          var val = data.x, needsVelocity = /velocity(?![\w\d])/.test(val), _needsRandom = val.indexOf("random") !== -1, elemType = elem.data.ty, transform, $bm_transform, content, effect, thisProperty = property;
          thisProperty._name = elem.data.nm, thisProperty.valueAtTime = thisProperty.getValueAtTime, Object.defineProperty(thisProperty, "value", {
            get: function() {
              return thisProperty.v;
            }
          }), elem.comp.frameDuration = 1 / elem.comp.globalData.frameRate, elem.comp.displayStartTime = 0;
          var inPoint = elem.data.ip / elem.comp.globalData.frameRate, outPoint = elem.data.op / elem.comp.globalData.frameRate, width = elem.data.sw ? elem.data.sw : 0, height = elem.data.sh ? elem.data.sh : 0, name = elem.data.nm, loopIn, loop_in, loopOut, loop_out, smooth, toWorld, fromWorld, fromComp, toComp, fromCompToSurface, position, rotation, anchorPoint, scale, thisLayer, thisComp, mask, valueAtTime, velocityAtTime, scoped_bm_rt, expression_function = eval("[function _expression_function(){" + val + ";scoped_bm_rt=$bm_rt}]")[0], numKeys = property.kf ? data.k.length : 0, active = !this.data || this.data.hd !== true, wiggle = function t(e, r) {
            var i, s, a = this.pv.length ? this.pv.length : 1, n = createTypedArray("float32", a);
            e = 5;
            var l = Math.floor(time * e);
            for (i = 0, s = 0; i < l; ) {
              for (s = 0; s < a; s += 1) n[s] += -r + r * 2 * BMMath.random();
              i += 1;
            }
            var o = time * e, p = o - Math.floor(o), y = createTypedArray("float32", a);
            if (a > 1) {
              for (s = 0; s < a; s += 1) y[s] = this.pv[s] + n[s] + (-r + r * 2 * BMMath.random()) * p;
              return y;
            }
            return this.pv + n[0] + (-r + r * 2 * BMMath.random()) * p;
          }.bind(this);
          thisProperty.loopIn && (loopIn = thisProperty.loopIn.bind(thisProperty), loop_in = loopIn), thisProperty.loopOut && (loopOut = thisProperty.loopOut.bind(thisProperty), loop_out = loopOut), thisProperty.smooth && (smooth = thisProperty.smooth.bind(thisProperty));
          function loopInDuration(t, e) {
            return loopIn(t, e, true);
          }
          function loopOutDuration(t, e) {
            return loopOut(t, e, true);
          }
          this.getValueAtTime && (valueAtTime = this.getValueAtTime.bind(this)), this.getVelocityAtTime && (velocityAtTime = this.getVelocityAtTime.bind(this));
          var comp = elem.comp.globalData.projectInterface.bind(elem.comp.globalData.projectInterface);
          function lookAt(t, e) {
            var r = [
              e[0] - t[0],
              e[1] - t[1],
              e[2] - t[2]
            ], i = Math.atan2(r[0], Math.sqrt(r[1] * r[1] + r[2] * r[2])) / degToRads, s = -Math.atan2(r[1], r[2]) / degToRads;
            return [
              s,
              i,
              0
            ];
          }
          function easeOut(t, e, r, i, s) {
            return applyEase(easeOutBez, t, e, r, i, s);
          }
          function easeIn(t, e, r, i, s) {
            return applyEase(easeInBez, t, e, r, i, s);
          }
          function ease(t, e, r, i, s) {
            return applyEase(easeInOutBez, t, e, r, i, s);
          }
          function applyEase(t, e, r, i, s, a) {
            s === void 0 ? (s = r, a = i) : e = (e - r) / (i - r), e > 1 ? e = 1 : e < 0 && (e = 0);
            var n = t(e);
            if ($bm_isInstanceOfArray(s)) {
              var l, o = s.length, p = createTypedArray("float32", o);
              for (l = 0; l < o; l += 1) p[l] = (a[l] - s[l]) * n + s[l];
              return p;
            }
            return (a - s) * n + s;
          }
          function nearestKey(t) {
            var e, r = data.k.length, i, s;
            if (!data.k.length || typeof data.k[0] == "number") i = 0, s = 0;
            else if (i = -1, t *= elem.comp.globalData.frameRate, t < data.k[0].t) i = 1, s = data.k[0].t;
            else {
              for (e = 0; e < r - 1; e += 1) if (t === data.k[e].t) {
                i = e + 1, s = data.k[e].t;
                break;
              } else if (t > data.k[e].t && t < data.k[e + 1].t) {
                t - data.k[e].t > data.k[e + 1].t - t ? (i = e + 2, s = data.k[e + 1].t) : (i = e + 1, s = data.k[e].t);
                break;
              }
              i === -1 && (i = e + 1, s = data.k[e].t);
            }
            var a = {};
            return a.index = i, a.time = s / elem.comp.globalData.frameRate, a;
          }
          function key(t) {
            var e, r, i;
            if (!data.k.length || typeof data.k[0] == "number") throw new Error("The property has no keyframe at index " + t);
            t -= 1, e = {
              time: data.k[t].t / elem.comp.globalData.frameRate,
              value: []
            };
            var s = Object.prototype.hasOwnProperty.call(data.k[t], "s") ? data.k[t].s : data.k[t - 1].e;
            for (i = s.length, r = 0; r < i; r += 1) e[r] = s[r], e.value[r] = s[r];
            return e;
          }
          function framesToTime(t, e) {
            return e || (e = elem.comp.globalData.frameRate), t / e;
          }
          function timeToFrames(t, e) {
            return !t && t !== 0 && (t = time), e || (e = elem.comp.globalData.frameRate), t * e;
          }
          function seedRandom(t) {
            BMMath.seedrandom(randSeed + t);
          }
          function sourceRectAtTime() {
            return elem.sourceRectAtTime();
          }
          function substring(t, e) {
            return typeof value == "string" ? e === void 0 ? value.substring(t) : value.substring(t, e) : "";
          }
          function substr(t, e) {
            return typeof value == "string" ? e === void 0 ? value.substr(t) : value.substr(t, e) : "";
          }
          function posterizeTime(t) {
            time = t === 0 ? 0 : Math.floor(time * t) / t, value = valueAtTime(time);
          }
          var time, velocity, value, text, textIndex, textTotal, selectorValue, index = elem.data.ind, hasParent = !!(elem.hierarchy && elem.hierarchy.length), parent, randSeed = Math.floor(Math.random() * 1e6), globalData = elem.globalData;
          function executeExpression(t) {
            return value = t, this.frameExpressionId === elem.globalData.frameId && this.propType !== "textSelector" ? value : (this.propType === "textSelector" && (textIndex = this.textIndex, textTotal = this.textTotal, selectorValue = this.selectorValue), thisLayer || (text = elem.layerInterface.text, thisLayer = elem.layerInterface, thisComp = elem.comp.compInterface, toWorld = thisLayer.toWorld.bind(thisLayer), fromWorld = thisLayer.fromWorld.bind(thisLayer), fromComp = thisLayer.fromComp.bind(thisLayer), toComp = thisLayer.toComp.bind(thisLayer), mask = thisLayer.mask ? thisLayer.mask.bind(thisLayer) : null, fromCompToSurface = fromComp), transform || (transform = elem.layerInterface("ADBE Transform Group"), $bm_transform = transform, transform && (anchorPoint = transform.anchorPoint)), elemType === 4 && !content && (content = thisLayer("ADBE Root Vectors Group")), effect || (effect = thisLayer(4)), hasParent = !!(elem.hierarchy && elem.hierarchy.length), hasParent && !parent && (parent = elem.hierarchy[0].layerInterface), time = this.comp.renderedFrame / this.comp.globalData.frameRate, _needsRandom && seedRandom(randSeed + time), needsVelocity && (velocity = velocityAtTime(time)), expression_function(), this.frameExpressionId = elem.globalData.frameId, scoped_bm_rt = scoped_bm_rt.propType === propTypes.SHAPE ? scoped_bm_rt.v : scoped_bm_rt, scoped_bm_rt);
          }
          return executeExpression.__preventDeadCodeRemoval = [
            $bm_transform,
            anchorPoint,
            time,
            velocity,
            inPoint,
            outPoint,
            width,
            height,
            name,
            loop_in,
            loop_out,
            smooth,
            toComp,
            fromCompToSurface,
            toWorld,
            fromWorld,
            mask,
            position,
            rotation,
            scale,
            thisComp,
            numKeys,
            active,
            wiggle,
            loopInDuration,
            loopOutDuration,
            comp,
            lookAt,
            easeOut,
            easeIn,
            ease,
            nearestKey,
            key,
            text,
            textIndex,
            textTotal,
            selectorValue,
            framesToTime,
            timeToFrames,
            sourceRectAtTime,
            substring,
            substr,
            posterizeTime,
            index,
            globalData
          ], executeExpression;
        }
        return ob.initiateExpression = initiateExpression, ob.__preventDeadCodeRemoval = [
          window,
          document,
          XMLHttpRequest,
          fetch,
          frames,
          $bm_neg,
          add,
          $bm_sum,
          $bm_sub,
          $bm_mul,
          $bm_div,
          $bm_mod,
          clamp,
          radians_to_degrees,
          degreesToRadians,
          degrees_to_radians,
          normalize,
          rgbToHsl,
          hslToRgb,
          linear,
          random,
          createPath,
          _lottieGlobal
        ], ob.resetFrame = resetFrame, ob;
      })(), Expressions = (function() {
        var t = {};
        t.initExpressions = e, t.resetFrame = ExpressionManager.resetFrame;
        function e(r) {
          var i = 0, s = [];
          function a() {
            i += 1;
          }
          function n() {
            i -= 1, i === 0 && o();
          }
          function l(p) {
            s.indexOf(p) === -1 && s.push(p);
          }
          function o() {
            var p, y = s.length;
            for (p = 0; p < y; p += 1) s[p].release();
            s.length = 0;
          }
          r.renderer.compInterface = CompExpressionInterface(r.renderer), r.renderer.globalData.projectInterface.registerComposition(r.renderer), r.renderer.globalData.pushExpression = a, r.renderer.globalData.popExpression = n, r.renderer.globalData.registerExpressionProperty = l;
        }
        return t;
      })(), MaskManagerInterface = (function() {
        function t(r, i) {
          this._mask = r, this._data = i;
        }
        Object.defineProperty(t.prototype, "maskPath", {
          get: function() {
            return this._mask.prop.k && this._mask.prop.getValue(), this._mask.prop;
          }
        }), Object.defineProperty(t.prototype, "maskOpacity", {
          get: function() {
            return this._mask.op.k && this._mask.op.getValue(), this._mask.op.v * 100;
          }
        });
        var e = function(i) {
          var s = createSizedArray(i.viewData.length), a, n = i.viewData.length;
          for (a = 0; a < n; a += 1) s[a] = new t(i.viewData[a], i.masksProperties[a]);
          var l = function(p) {
            for (a = 0; a < n; ) {
              if (i.masksProperties[a].nm === p) return s[a];
              a += 1;
            }
            return null;
          };
          return l;
        };
        return e;
      })(), ExpressionPropertyInterface = /* @__PURE__ */ (function() {
        var t = {
          pv: 0,
          v: 0,
          mult: 1
        }, e = {
          pv: [
            0,
            0,
            0
          ],
          v: [
            0,
            0,
            0
          ],
          mult: 1
        };
        function r(n, l, o) {
          Object.defineProperty(n, "velocity", {
            get: function() {
              return l.getVelocityAtTime(l.comp.currentFrame);
            }
          }), n.numKeys = l.keyframes ? l.keyframes.length : 0, n.key = function(p) {
            if (!n.numKeys) return 0;
            var y = "";
            "s" in l.keyframes[p - 1] ? y = l.keyframes[p - 1].s : "e" in l.keyframes[p - 2] ? y = l.keyframes[p - 2].e : y = l.keyframes[p - 2].s;
            var E = o === "unidimensional" ? new Number(y) : Object.assign({}, y);
            return E.time = l.keyframes[p - 1].t / l.elem.comp.globalData.frameRate, E.value = o === "unidimensional" ? y[0] : y, E;
          }, n.valueAtTime = l.getValueAtTime, n.speedAtTime = l.getSpeedAtTime, n.velocityAtTime = l.getVelocityAtTime, n.propertyGroup = l.propertyGroup;
        }
        function i(n) {
          (!n || !("pv" in n)) && (n = t);
          var l = 1 / n.mult, o = n.pv * l, p = new Number(o);
          return p.value = o, r(p, n, "unidimensional"), function() {
            return n.k && n.getValue(), o = n.v * l, p.value !== o && (p = new Number(o), p.value = o, p[0] = o, r(p, n, "unidimensional")), p;
          };
        }
        function s(n) {
          (!n || !("pv" in n)) && (n = e);
          var l = 1 / n.mult, o = n.data && n.data.l || n.pv.length, p = createTypedArray("float32", o), y = createTypedArray("float32", o);
          return p.value = y, r(p, n, "multidimensional"), function() {
            n.k && n.getValue();
            for (var E = 0; E < o; E += 1) y[E] = n.v[E] * l, p[E] = y[E];
            return p;
          };
        }
        function a() {
          return t;
        }
        return function(n) {
          return n ? n.propType === "unidimensional" ? i(n) : s(n) : a;
        };
      })(), TransformExpressionInterface = /* @__PURE__ */ (function() {
        return function(t) {
          function e(n) {
            switch (n) {
              case "scale":
              case "Scale":
              case "ADBE Scale":
              case 6:
                return e.scale;
              case "rotation":
              case "Rotation":
              case "ADBE Rotation":
              case "ADBE Rotate Z":
              case 10:
                return e.rotation;
              case "ADBE Rotate X":
                return e.xRotation;
              case "ADBE Rotate Y":
                return e.yRotation;
              case "position":
              case "Position":
              case "ADBE Position":
              case 2:
                return e.position;
              case "ADBE Position_0":
                return e.xPosition;
              case "ADBE Position_1":
                return e.yPosition;
              case "ADBE Position_2":
                return e.zPosition;
              case "anchorPoint":
              case "AnchorPoint":
              case "Anchor Point":
              case "ADBE AnchorPoint":
              case 1:
                return e.anchorPoint;
              case "opacity":
              case "Opacity":
              case 11:
                return e.opacity;
              default:
                return null;
            }
          }
          Object.defineProperty(e, "rotation", {
            get: ExpressionPropertyInterface(t.r || t.rz)
          }), Object.defineProperty(e, "zRotation", {
            get: ExpressionPropertyInterface(t.rz || t.r)
          }), Object.defineProperty(e, "xRotation", {
            get: ExpressionPropertyInterface(t.rx)
          }), Object.defineProperty(e, "yRotation", {
            get: ExpressionPropertyInterface(t.ry)
          }), Object.defineProperty(e, "scale", {
            get: ExpressionPropertyInterface(t.s)
          });
          var r, i, s, a;
          return t.p ? a = ExpressionPropertyInterface(t.p) : (r = ExpressionPropertyInterface(t.px), i = ExpressionPropertyInterface(t.py), t.pz && (s = ExpressionPropertyInterface(t.pz))), Object.defineProperty(e, "position", {
            get: function() {
              return t.p ? a() : [
                r(),
                i(),
                s ? s() : 0
              ];
            }
          }), Object.defineProperty(e, "xPosition", {
            get: ExpressionPropertyInterface(t.px)
          }), Object.defineProperty(e, "yPosition", {
            get: ExpressionPropertyInterface(t.py)
          }), Object.defineProperty(e, "zPosition", {
            get: ExpressionPropertyInterface(t.pz)
          }), Object.defineProperty(e, "anchorPoint", {
            get: ExpressionPropertyInterface(t.a)
          }), Object.defineProperty(e, "opacity", {
            get: ExpressionPropertyInterface(t.o)
          }), Object.defineProperty(e, "skew", {
            get: ExpressionPropertyInterface(t.sk)
          }), Object.defineProperty(e, "skewAxis", {
            get: ExpressionPropertyInterface(t.sa)
          }), Object.defineProperty(e, "orientation", {
            get: ExpressionPropertyInterface(t.or)
          }), e;
        };
      })(), LayerExpressionInterface = /* @__PURE__ */ (function() {
        function t(p) {
          var y = new Matrix();
          if (p !== void 0) {
            var E = this._elem.finalTransform.mProp.getValueAtTime(p);
            E.clone(y);
          } else {
            var u = this._elem.finalTransform.mProp;
            u.applyToMatrix(y);
          }
          return y;
        }
        function e(p, y) {
          var E = this.getMatrix(y);
          return E.props[12] = 0, E.props[13] = 0, E.props[14] = 0, this.applyPoint(E, p);
        }
        function r(p, y) {
          var E = this.getMatrix(y);
          return this.applyPoint(E, p);
        }
        function i(p, y) {
          var E = this.getMatrix(y);
          return E.props[12] = 0, E.props[13] = 0, E.props[14] = 0, this.invertPoint(E, p);
        }
        function s(p, y) {
          var E = this.getMatrix(y);
          return this.invertPoint(E, p);
        }
        function a(p, y) {
          if (this._elem.hierarchy && this._elem.hierarchy.length) {
            var E, u = this._elem.hierarchy.length;
            for (E = 0; E < u; E += 1) this._elem.hierarchy[E].finalTransform.mProp.applyToMatrix(p);
          }
          return p.applyToPointArray(y[0], y[1], y[2] || 0);
        }
        function n(p, y) {
          if (this._elem.hierarchy && this._elem.hierarchy.length) {
            var E, u = this._elem.hierarchy.length;
            for (E = 0; E < u; E += 1) this._elem.hierarchy[E].finalTransform.mProp.applyToMatrix(p);
          }
          return p.inversePoint(y);
        }
        function l(p) {
          var y = new Matrix();
          if (y.reset(), this._elem.finalTransform.mProp.applyToMatrix(y), this._elem.hierarchy && this._elem.hierarchy.length) {
            var E, u = this._elem.hierarchy.length;
            for (E = 0; E < u; E += 1) this._elem.hierarchy[E].finalTransform.mProp.applyToMatrix(y);
            return y.inversePoint(p);
          }
          return y.inversePoint(p);
        }
        function o() {
          return [
            1,
            1,
            1,
            1
          ];
        }
        return function(p) {
          var y;
          function E(d) {
            x.mask = new MaskManagerInterface(d, p);
          }
          function u(d) {
            x.effect = d;
          }
          function x(d) {
            switch (d) {
              case "ADBE Root Vectors Group":
              case "Contents":
              case 2:
                return x.shapeInterface;
              case 1:
              case 6:
              case "Transform":
              case "transform":
              case "ADBE Transform Group":
                return y;
              case 4:
              case "ADBE Effect Parade":
              case "effects":
              case "Effects":
                return x.effect;
              case "ADBE Text Properties":
                return x.textInterface;
              default:
                return null;
            }
          }
          x.getMatrix = t, x.invertPoint = n, x.applyPoint = a, x.toWorld = r, x.toWorldVec = e, x.fromWorld = s, x.fromWorldVec = i, x.toComp = r, x.fromComp = l, x.sampleImage = o, x.sourceRectAtTime = p.sourceRectAtTime.bind(p), x._elem = p, y = TransformExpressionInterface(p.finalTransform.mProp);
          var g = getDescriptor(y, "anchorPoint");
          return Object.defineProperties(x, {
            hasParent: {
              get: function() {
                return p.hierarchy.length;
              }
            },
            parent: {
              get: function() {
                return p.hierarchy[0].layerInterface;
              }
            },
            rotation: getDescriptor(y, "rotation"),
            scale: getDescriptor(y, "scale"),
            position: getDescriptor(y, "position"),
            opacity: getDescriptor(y, "opacity"),
            anchorPoint: g,
            anchor_point: g,
            transform: {
              get: function() {
                return y;
              }
            },
            active: {
              get: function() {
                return p.isInRange;
              }
            }
          }), x.startTime = p.data.st, x.index = p.data.ind, x.source = p.data.refId, x.height = p.data.ty === 0 ? p.data.h : 100, x.width = p.data.ty === 0 ? p.data.w : 100, x.inPoint = p.data.ip / p.comp.globalData.frameRate, x.outPoint = p.data.op / p.comp.globalData.frameRate, x._name = p.data.nm, x.registerMaskInterface = E, x.registerEffectsInterface = u, x;
        };
      })(), propertyGroupFactory = /* @__PURE__ */ (function() {
        return function(t, e) {
          return function(r) {
            return r = r === void 0 ? 1 : r, r <= 0 ? t : e(r - 1);
          };
        };
      })(), PropertyInterface = /* @__PURE__ */ (function() {
        return function(t, e) {
          var r = {
            _name: t
          };
          function i(s) {
            return s = s === void 0 ? 1 : s, s <= 0 ? r : e(s - 1);
          }
          return i;
        };
      })(), EffectsExpressionInterface = /* @__PURE__ */ (function() {
        var t = {
          createEffectsInterface: e
        };
        function e(s, a) {
          if (s.effectsManager) {
            var n = [], l = s.data.ef, o, p = s.effectsManager.effectElements.length;
            for (o = 0; o < p; o += 1) n.push(r(l[o], s.effectsManager.effectElements[o], a, s));
            var y = s.data.ef || [], E = function(x) {
              for (o = 0, p = y.length; o < p; ) {
                if (x === y[o].nm || x === y[o].mn || x === y[o].ix) return n[o];
                o += 1;
              }
              return null;
            };
            return Object.defineProperty(E, "numProperties", {
              get: function() {
                return y.length;
              }
            }), E;
          }
          return null;
        }
        function r(s, a, n, l) {
          function o(x) {
            for (var g = s.ef, d = 0, A = g.length; d < A; ) {
              if (x === g[d].nm || x === g[d].mn || x === g[d].ix) return g[d].ty === 5 ? y[d] : y[d]();
              d += 1;
            }
            throw new Error();
          }
          var p = propertyGroupFactory(o, n), y = [], E, u = s.ef.length;
          for (E = 0; E < u; E += 1) s.ef[E].ty === 5 ? y.push(r(s.ef[E], a.effectElements[E], a.effectElements[E].propertyGroup, l)) : y.push(i(a.effectElements[E], s.ef[E].ty, l, p));
          return s.mn === "ADBE Color Control" && Object.defineProperty(o, "color", {
            get: function() {
              return y[0]();
            }
          }), Object.defineProperties(o, {
            numProperties: {
              get: function() {
                return s.np;
              }
            },
            _name: {
              value: s.nm
            },
            propertyGroup: {
              value: p
            }
          }), o.enabled = s.en !== 0, o.active = o.enabled, o;
        }
        function i(s, a, n, l) {
          var o = ExpressionPropertyInterface(s.p);
          function p() {
            return a === 10 ? n.comp.compInterface(s.p.v) : o();
          }
          return s.p.setGroupProperty && s.p.setGroupProperty(PropertyInterface("", l)), p;
        }
        return t;
      })(), ShapePathInterface = /* @__PURE__ */ (function() {
        return function(e, r, i) {
          var s = r.sh;
          function a(l) {
            return l === "Shape" || l === "shape" || l === "Path" || l === "path" || l === "ADBE Vector Shape" || l === 2 ? a.path : null;
          }
          var n = propertyGroupFactory(a, i);
          return s.setGroupProperty(PropertyInterface("Path", n)), Object.defineProperties(a, {
            path: {
              get: function() {
                return s.k && s.getValue(), s;
              }
            },
            shape: {
              get: function() {
                return s.k && s.getValue(), s;
              }
            },
            _name: {
              value: e.nm
            },
            ix: {
              value: e.ix
            },
            propertyIndex: {
              value: e.ix
            },
            mn: {
              value: e.mn
            },
            propertyGroup: {
              value: i
            }
          }), a;
        };
      })(), ShapeExpressionInterface = /* @__PURE__ */ (function() {
        function t(g, d, A) {
          var c = [], m, f = g ? g.length : 0;
          for (m = 0; m < f; m += 1) g[m].ty === "gr" ? c.push(r(g[m], d[m], A)) : g[m].ty === "fl" ? c.push(i(g[m], d[m], A)) : g[m].ty === "st" ? c.push(n(g[m], d[m], A)) : g[m].ty === "tm" ? c.push(l(g[m], d[m], A)) : g[m].ty === "tr" || (g[m].ty === "el" ? c.push(p(g[m], d[m], A)) : g[m].ty === "sr" ? c.push(y(g[m], d[m], A)) : g[m].ty === "sh" ? c.push(ShapePathInterface(g[m], d[m], A)) : g[m].ty === "rc" ? c.push(E(g[m], d[m], A)) : g[m].ty === "rd" ? c.push(u(g[m], d[m], A)) : g[m].ty === "rp" ? c.push(x(g[m], d[m], A)) : g[m].ty === "gf" ? c.push(s(g[m], d[m], A)) : c.push(a(g[m], d[m])));
          return c;
        }
        function e(g, d, A) {
          var c, m = function(C) {
            for (var _ = 0, T = c.length; _ < T; ) {
              if (c[_]._name === C || c[_].mn === C || c[_].propertyIndex === C || c[_].ix === C || c[_].ind === C) return c[_];
              _ += 1;
            }
            return typeof C == "number" ? c[C - 1] : null;
          };
          m.propertyGroup = propertyGroupFactory(m, A), c = t(g.it, d.it, m.propertyGroup), m.numProperties = c.length;
          var f = o(g.it[g.it.length - 1], d.it[d.it.length - 1], m.propertyGroup);
          return m.transform = f, m.propertyIndex = g.cix, m._name = g.nm, m;
        }
        function r(g, d, A) {
          var c = function(C) {
            switch (C) {
              case "ADBE Vectors Group":
              case "Contents":
              case 2:
                return c.content;
              default:
                return c.transform;
            }
          };
          c.propertyGroup = propertyGroupFactory(c, A);
          var m = e(g, d, c.propertyGroup), f = o(g.it[g.it.length - 1], d.it[d.it.length - 1], c.propertyGroup);
          return c.content = m, c.transform = f, Object.defineProperty(c, "_name", {
            get: function() {
              return g.nm;
            }
          }), c.numProperties = g.np, c.propertyIndex = g.ix, c.nm = g.nm, c.mn = g.mn, c;
        }
        function i(g, d, A) {
          function c(m) {
            return m === "Color" || m === "color" ? c.color : m === "Opacity" || m === "opacity" ? c.opacity : null;
          }
          return Object.defineProperties(c, {
            color: {
              get: ExpressionPropertyInterface(d.c)
            },
            opacity: {
              get: ExpressionPropertyInterface(d.o)
            },
            _name: {
              value: g.nm
            },
            mn: {
              value: g.mn
            }
          }), d.c.setGroupProperty(PropertyInterface("Color", A)), d.o.setGroupProperty(PropertyInterface("Opacity", A)), c;
        }
        function s(g, d, A) {
          function c(m) {
            return m === "Start Point" || m === "start point" ? c.startPoint : m === "End Point" || m === "end point" ? c.endPoint : m === "Opacity" || m === "opacity" ? c.opacity : null;
          }
          return Object.defineProperties(c, {
            startPoint: {
              get: ExpressionPropertyInterface(d.s)
            },
            endPoint: {
              get: ExpressionPropertyInterface(d.e)
            },
            opacity: {
              get: ExpressionPropertyInterface(d.o)
            },
            type: {
              get: function() {
                return "a";
              }
            },
            _name: {
              value: g.nm
            },
            mn: {
              value: g.mn
            }
          }), d.s.setGroupProperty(PropertyInterface("Start Point", A)), d.e.setGroupProperty(PropertyInterface("End Point", A)), d.o.setGroupProperty(PropertyInterface("Opacity", A)), c;
        }
        function a() {
          function g() {
            return null;
          }
          return g;
        }
        function n(g, d, A) {
          var c = propertyGroupFactory(T, A), m = propertyGroupFactory(_, c);
          function f(I) {
            Object.defineProperty(_, g.d[I].nm, {
              get: ExpressionPropertyInterface(d.d.dataProps[I].p)
            });
          }
          var b, C = g.d ? g.d.length : 0, _ = {};
          for (b = 0; b < C; b += 1) f(b), d.d.dataProps[b].p.setGroupProperty(m);
          function T(I) {
            return I === "Color" || I === "color" ? T.color : I === "Opacity" || I === "opacity" ? T.opacity : I === "Stroke Width" || I === "stroke width" ? T.strokeWidth : null;
          }
          return Object.defineProperties(T, {
            color: {
              get: ExpressionPropertyInterface(d.c)
            },
            opacity: {
              get: ExpressionPropertyInterface(d.o)
            },
            strokeWidth: {
              get: ExpressionPropertyInterface(d.w)
            },
            dash: {
              get: function() {
                return _;
              }
            },
            _name: {
              value: g.nm
            },
            mn: {
              value: g.mn
            }
          }), d.c.setGroupProperty(PropertyInterface("Color", c)), d.o.setGroupProperty(PropertyInterface("Opacity", c)), d.w.setGroupProperty(PropertyInterface("Stroke Width", c)), T;
        }
        function l(g, d, A) {
          function c(f) {
            return f === g.e.ix || f === "End" || f === "end" ? c.end : f === g.s.ix ? c.start : f === g.o.ix ? c.offset : null;
          }
          var m = propertyGroupFactory(c, A);
          return c.propertyIndex = g.ix, d.s.setGroupProperty(PropertyInterface("Start", m)), d.e.setGroupProperty(PropertyInterface("End", m)), d.o.setGroupProperty(PropertyInterface("Offset", m)), c.propertyIndex = g.ix, c.propertyGroup = A, Object.defineProperties(c, {
            start: {
              get: ExpressionPropertyInterface(d.s)
            },
            end: {
              get: ExpressionPropertyInterface(d.e)
            },
            offset: {
              get: ExpressionPropertyInterface(d.o)
            },
            _name: {
              value: g.nm
            }
          }), c.mn = g.mn, c;
        }
        function o(g, d, A) {
          function c(f) {
            return g.a.ix === f || f === "Anchor Point" ? c.anchorPoint : g.o.ix === f || f === "Opacity" ? c.opacity : g.p.ix === f || f === "Position" ? c.position : g.r.ix === f || f === "Rotation" || f === "ADBE Vector Rotation" ? c.rotation : g.s.ix === f || f === "Scale" ? c.scale : g.sk && g.sk.ix === f || f === "Skew" ? c.skew : g.sa && g.sa.ix === f || f === "Skew Axis" ? c.skewAxis : null;
          }
          var m = propertyGroupFactory(c, A);
          return d.transform.mProps.o.setGroupProperty(PropertyInterface("Opacity", m)), d.transform.mProps.p.setGroupProperty(PropertyInterface("Position", m)), d.transform.mProps.a.setGroupProperty(PropertyInterface("Anchor Point", m)), d.transform.mProps.s.setGroupProperty(PropertyInterface("Scale", m)), d.transform.mProps.r.setGroupProperty(PropertyInterface("Rotation", m)), d.transform.mProps.sk && (d.transform.mProps.sk.setGroupProperty(PropertyInterface("Skew", m)), d.transform.mProps.sa.setGroupProperty(PropertyInterface("Skew Angle", m))), d.transform.op.setGroupProperty(PropertyInterface("Opacity", m)), Object.defineProperties(c, {
            opacity: {
              get: ExpressionPropertyInterface(d.transform.mProps.o)
            },
            position: {
              get: ExpressionPropertyInterface(d.transform.mProps.p)
            },
            anchorPoint: {
              get: ExpressionPropertyInterface(d.transform.mProps.a)
            },
            scale: {
              get: ExpressionPropertyInterface(d.transform.mProps.s)
            },
            rotation: {
              get: ExpressionPropertyInterface(d.transform.mProps.r)
            },
            skew: {
              get: ExpressionPropertyInterface(d.transform.mProps.sk)
            },
            skewAxis: {
              get: ExpressionPropertyInterface(d.transform.mProps.sa)
            },
            _name: {
              value: g.nm
            }
          }), c.ty = "tr", c.mn = g.mn, c.propertyGroup = A, c;
        }
        function p(g, d, A) {
          function c(b) {
            return g.p.ix === b ? c.position : g.s.ix === b ? c.size : null;
          }
          var m = propertyGroupFactory(c, A);
          c.propertyIndex = g.ix;
          var f = d.sh.ty === "tm" ? d.sh.prop : d.sh;
          return f.s.setGroupProperty(PropertyInterface("Size", m)), f.p.setGroupProperty(PropertyInterface("Position", m)), Object.defineProperties(c, {
            size: {
              get: ExpressionPropertyInterface(f.s)
            },
            position: {
              get: ExpressionPropertyInterface(f.p)
            },
            _name: {
              value: g.nm
            }
          }), c.mn = g.mn, c;
        }
        function y(g, d, A) {
          function c(b) {
            return g.p.ix === b ? c.position : g.r.ix === b ? c.rotation : g.pt.ix === b ? c.points : g.or.ix === b || b === "ADBE Vector Star Outer Radius" ? c.outerRadius : g.os.ix === b ? c.outerRoundness : g.ir && (g.ir.ix === b || b === "ADBE Vector Star Inner Radius") ? c.innerRadius : g.is && g.is.ix === b ? c.innerRoundness : null;
          }
          var m = propertyGroupFactory(c, A), f = d.sh.ty === "tm" ? d.sh.prop : d.sh;
          return c.propertyIndex = g.ix, f.or.setGroupProperty(PropertyInterface("Outer Radius", m)), f.os.setGroupProperty(PropertyInterface("Outer Roundness", m)), f.pt.setGroupProperty(PropertyInterface("Points", m)), f.p.setGroupProperty(PropertyInterface("Position", m)), f.r.setGroupProperty(PropertyInterface("Rotation", m)), g.ir && (f.ir.setGroupProperty(PropertyInterface("Inner Radius", m)), f.is.setGroupProperty(PropertyInterface("Inner Roundness", m))), Object.defineProperties(c, {
            position: {
              get: ExpressionPropertyInterface(f.p)
            },
            rotation: {
              get: ExpressionPropertyInterface(f.r)
            },
            points: {
              get: ExpressionPropertyInterface(f.pt)
            },
            outerRadius: {
              get: ExpressionPropertyInterface(f.or)
            },
            outerRoundness: {
              get: ExpressionPropertyInterface(f.os)
            },
            innerRadius: {
              get: ExpressionPropertyInterface(f.ir)
            },
            innerRoundness: {
              get: ExpressionPropertyInterface(f.is)
            },
            _name: {
              value: g.nm
            }
          }), c.mn = g.mn, c;
        }
        function E(g, d, A) {
          function c(b) {
            return g.p.ix === b ? c.position : g.r.ix === b ? c.roundness : g.s.ix === b || b === "Size" || b === "ADBE Vector Rect Size" ? c.size : null;
          }
          var m = propertyGroupFactory(c, A), f = d.sh.ty === "tm" ? d.sh.prop : d.sh;
          return c.propertyIndex = g.ix, f.p.setGroupProperty(PropertyInterface("Position", m)), f.s.setGroupProperty(PropertyInterface("Size", m)), f.r.setGroupProperty(PropertyInterface("Rotation", m)), Object.defineProperties(c, {
            position: {
              get: ExpressionPropertyInterface(f.p)
            },
            roundness: {
              get: ExpressionPropertyInterface(f.r)
            },
            size: {
              get: ExpressionPropertyInterface(f.s)
            },
            _name: {
              value: g.nm
            }
          }), c.mn = g.mn, c;
        }
        function u(g, d, A) {
          function c(b) {
            return g.r.ix === b || b === "Round Corners 1" ? c.radius : null;
          }
          var m = propertyGroupFactory(c, A), f = d;
          return c.propertyIndex = g.ix, f.rd.setGroupProperty(PropertyInterface("Radius", m)), Object.defineProperties(c, {
            radius: {
              get: ExpressionPropertyInterface(f.rd)
            },
            _name: {
              value: g.nm
            }
          }), c.mn = g.mn, c;
        }
        function x(g, d, A) {
          function c(b) {
            return g.c.ix === b || b === "Copies" ? c.copies : g.o.ix === b || b === "Offset" ? c.offset : null;
          }
          var m = propertyGroupFactory(c, A), f = d;
          return c.propertyIndex = g.ix, f.c.setGroupProperty(PropertyInterface("Copies", m)), f.o.setGroupProperty(PropertyInterface("Offset", m)), Object.defineProperties(c, {
            copies: {
              get: ExpressionPropertyInterface(f.c)
            },
            offset: {
              get: ExpressionPropertyInterface(f.o)
            },
            _name: {
              value: g.nm
            }
          }), c.mn = g.mn, c;
        }
        return function(g, d, A) {
          var c;
          function m(b) {
            if (typeof b == "number") return b = b === void 0 ? 1 : b, b === 0 ? A : c[b - 1];
            for (var C = 0, _ = c.length; C < _; ) {
              if (c[C]._name === b) return c[C];
              C += 1;
            }
            return null;
          }
          function f() {
            return A;
          }
          return m.propertyGroup = propertyGroupFactory(m, f), c = t(g, d, m.propertyGroup), m.numProperties = c.length, m._name = "Contents", m;
        };
      })(), TextExpressionInterface = /* @__PURE__ */ (function() {
        return function(t) {
          var e;
          function r(i) {
            switch (i) {
              case "ADBE Text Document":
                return r.sourceText;
              default:
                return null;
            }
          }
          return Object.defineProperty(r, "sourceText", {
            get: function() {
              t.textProperty.getValue();
              var s = t.textProperty.currentData.t;
              return (!e || s !== e.value) && (e = new String(s), e.value = s || new String(s), Object.defineProperty(e, "style", {
                get: function() {
                  return {
                    fillColor: t.textProperty.currentData.fc
                  };
                }
              })), e;
            }
          }), r;
        };
      })();
      function _typeof(t) {
        "@babel/helpers - typeof";
        return _typeof = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
          return typeof e;
        } : function(e) {
          return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
        }, _typeof(t);
      }
      var FootageInterface = /* @__PURE__ */ (function() {
        var t = function(i) {
          var s = "", a = i.getFootageData();
          function n() {
            return s = "", a = i.getFootageData(), l;
          }
          function l(o) {
            if (a[o]) return s = o, a = a[o], _typeof(a) === "object" ? l : a;
            var p = o.indexOf(s);
            if (p !== -1) {
              var y = parseInt(o.substr(p + s.length), 10);
              return a = a[y], _typeof(a) === "object" ? l : a;
            }
            return "";
          }
          return n;
        }, e = function(i) {
          function s(a) {
            return a === "Outline" ? s.outlineInterface() : null;
          }
          return s._name = "Outline", s.outlineInterface = t(i), s;
        };
        return function(r) {
          function i(s) {
            return s === "Data" ? i.dataInterface : null;
          }
          return i._name = "Data", i.dataInterface = e(r), i;
        };
      })(), interfaces = {
        layer: LayerExpressionInterface,
        effects: EffectsExpressionInterface,
        comp: CompExpressionInterface,
        shape: ShapeExpressionInterface,
        text: TextExpressionInterface,
        footage: FootageInterface
      };
      function getInterface(t) {
        return interfaces[t] || null;
      }
      var expressionHelpers = /* @__PURE__ */ (function() {
        function t(n, l, o) {
          l.x && (o.k = true, o.x = true, o.initiateExpression = ExpressionManager.initiateExpression, o.effectsSequence.push(o.initiateExpression(n, l, o).bind(o)));
        }
        function e(n) {
          return n *= this.elem.globalData.frameRate, n -= this.offsetTime, n !== this._cachingAtTime.lastFrame && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastFrame < n ? this._cachingAtTime.lastIndex : 0, this._cachingAtTime.value = this.interpolateValue(n, this._cachingAtTime), this._cachingAtTime.lastFrame = n), this._cachingAtTime.value;
        }
        function r(n) {
          var l = -0.01, o = this.getValueAtTime(n), p = this.getValueAtTime(n + l), y = 0;
          if (o.length) {
            var E;
            for (E = 0; E < o.length; E += 1) y += Math.pow(p[E] - o[E], 2);
            y = Math.sqrt(y) * 100;
          } else y = 0;
          return y;
        }
        function i(n) {
          if (this.vel !== void 0) return this.vel;
          var l = -1e-3, o = this.getValueAtTime(n), p = this.getValueAtTime(n + l), y;
          if (o.length) {
            y = createTypedArray("float32", o.length);
            var E;
            for (E = 0; E < o.length; E += 1) y[E] = (p[E] - o[E]) / l;
          } else y = (p - o) / l;
          return y;
        }
        function s() {
          return this.pv;
        }
        function a(n) {
          this.propertyGroup = n;
        }
        return {
          searchExpressions: t,
          getSpeedAtTime: r,
          getVelocityAtTime: i,
          getValueAtTime: e,
          getStaticValueAtTime: s,
          setGroupProperty: a
        };
      })();
      function addPropertyDecorator() {
        function t(u, x, g) {
          if (!this.k || !this.keyframes) return this.pv;
          u = u ? u.toLowerCase() : "";
          var d = this.comp.renderedFrame, A = this.keyframes, c = A[A.length - 1].t;
          if (d <= c) return this.pv;
          var m, f;
          g ? (x ? m = Math.abs(c - this.elem.comp.globalData.frameRate * x) : m = Math.max(0, c - this.elem.data.ip), f = c - m) : ((!x || x > A.length - 1) && (x = A.length - 1), f = A[A.length - 1 - x].t, m = c - f);
          var b, C, _;
          if (u === "pingpong") {
            var T = Math.floor((d - f) / m);
            if (T % 2 !== 0) return this.getValueAtTime((m - (d - f) % m + f) / this.comp.globalData.frameRate, 0);
          } else if (u === "offset") {
            var I = this.getValueAtTime(f / this.comp.globalData.frameRate, 0), L = this.getValueAtTime(c / this.comp.globalData.frameRate, 0), j = this.getValueAtTime(((d - f) % m + f) / this.comp.globalData.frameRate, 0), O = Math.floor((d - f) / m);
            if (this.pv.length) {
              for (_ = new Array(I.length), C = _.length, b = 0; b < C; b += 1) _[b] = (L[b] - I[b]) * O + j[b];
              return _;
            }
            return (L - I) * O + j;
          } else if (u === "continue") {
            var D = this.getValueAtTime(c / this.comp.globalData.frameRate, 0), N = this.getValueAtTime((c - 1e-3) / this.comp.globalData.frameRate, 0);
            if (this.pv.length) {
              for (_ = new Array(D.length), C = _.length, b = 0; b < C; b += 1) _[b] = D[b] + (D[b] - N[b]) * ((d - c) / this.comp.globalData.frameRate) / 5e-4;
              return _;
            }
            return D + (D - N) * ((d - c) / 1e-3);
          }
          return this.getValueAtTime(((d - f) % m + f) / this.comp.globalData.frameRate, 0);
        }
        function e(u, x, g) {
          if (!this.k) return this.pv;
          u = u ? u.toLowerCase() : "";
          var d = this.comp.renderedFrame, A = this.keyframes, c = A[0].t;
          if (d >= c) return this.pv;
          var m, f;
          g ? (x ? m = Math.abs(this.elem.comp.globalData.frameRate * x) : m = Math.max(0, this.elem.data.op - c), f = c + m) : ((!x || x > A.length - 1) && (x = A.length - 1), f = A[x].t, m = f - c);
          var b, C, _;
          if (u === "pingpong") {
            var T = Math.floor((c - d) / m);
            if (T % 2 === 0) return this.getValueAtTime(((c - d) % m + c) / this.comp.globalData.frameRate, 0);
          } else if (u === "offset") {
            var I = this.getValueAtTime(c / this.comp.globalData.frameRate, 0), L = this.getValueAtTime(f / this.comp.globalData.frameRate, 0), j = this.getValueAtTime((m - (c - d) % m + c) / this.comp.globalData.frameRate, 0), O = Math.floor((c - d) / m) + 1;
            if (this.pv.length) {
              for (_ = new Array(I.length), C = _.length, b = 0; b < C; b += 1) _[b] = j[b] - (L[b] - I[b]) * O;
              return _;
            }
            return j - (L - I) * O;
          } else if (u === "continue") {
            var D = this.getValueAtTime(c / this.comp.globalData.frameRate, 0), N = this.getValueAtTime((c + 1e-3) / this.comp.globalData.frameRate, 0);
            if (this.pv.length) {
              for (_ = new Array(D.length), C = _.length, b = 0; b < C; b += 1) _[b] = D[b] + (D[b] - N[b]) * (c - d) / 1e-3;
              return _;
            }
            return D + (D - N) * (c - d) / 1e-3;
          }
          return this.getValueAtTime((m - ((c - d) % m + c)) / this.comp.globalData.frameRate, 0);
        }
        function r(u, x) {
          if (!this.k) return this.pv;
          if (u = (u || 0.4) * 0.5, x = Math.floor(x || 5), x <= 1) return this.pv;
          var g = this.comp.renderedFrame / this.comp.globalData.frameRate, d = g - u, A = g + u, c = x > 1 ? (A - d) / (x - 1) : 1, m = 0, f = 0, b;
          this.pv.length ? b = createTypedArray("float32", this.pv.length) : b = 0;
          for (var C; m < x; ) {
            if (C = this.getValueAtTime(d + m * c), this.pv.length) for (f = 0; f < this.pv.length; f += 1) b[f] += C[f];
            else b += C;
            m += 1;
          }
          if (this.pv.length) for (f = 0; f < this.pv.length; f += 1) b[f] /= x;
          else b /= x;
          return b;
        }
        function i(u) {
          this._transformCachingAtTime || (this._transformCachingAtTime = {
            v: new Matrix()
          });
          var x = this._transformCachingAtTime.v;
          if (x.cloneFromProps(this.pre.props), this.appliedTransformations < 1) {
            var g = this.a.getValueAtTime(u);
            x.translate(-g[0] * this.a.mult, -g[1] * this.a.mult, g[2] * this.a.mult);
          }
          if (this.appliedTransformations < 2) {
            var d = this.s.getValueAtTime(u);
            x.scale(d[0] * this.s.mult, d[1] * this.s.mult, d[2] * this.s.mult);
          }
          if (this.sk && this.appliedTransformations < 3) {
            var A = this.sk.getValueAtTime(u), c = this.sa.getValueAtTime(u);
            x.skewFromAxis(-A * this.sk.mult, c * this.sa.mult);
          }
          if (this.r && this.appliedTransformations < 4) {
            var m = this.r.getValueAtTime(u);
            x.rotate(-m * this.r.mult);
          } else if (!this.r && this.appliedTransformations < 4) {
            var f = this.rz.getValueAtTime(u), b = this.ry.getValueAtTime(u), C = this.rx.getValueAtTime(u), _ = this.or.getValueAtTime(u);
            x.rotateZ(-f * this.rz.mult).rotateY(b * this.ry.mult).rotateX(C * this.rx.mult).rotateZ(-_[2] * this.or.mult).rotateY(_[1] * this.or.mult).rotateX(_[0] * this.or.mult);
          }
          if (this.data.p && this.data.p.s) {
            var T = this.px.getValueAtTime(u), I = this.py.getValueAtTime(u);
            if (this.data.p.z) {
              var L = this.pz.getValueAtTime(u);
              x.translate(T * this.px.mult, I * this.py.mult, -L * this.pz.mult);
            } else x.translate(T * this.px.mult, I * this.py.mult, 0);
          } else {
            var j = this.p.getValueAtTime(u);
            x.translate(j[0] * this.p.mult, j[1] * this.p.mult, -j[2] * this.p.mult);
          }
          return x;
        }
        function s() {
          return this.v.clone(new Matrix());
        }
        var a = TransformPropertyFactory.getTransformProperty;
        TransformPropertyFactory.getTransformProperty = function(u, x, g) {
          var d = a(u, x, g);
          return d.dynamicProperties.length ? d.getValueAtTime = i.bind(d) : d.getValueAtTime = s.bind(d), d.setGroupProperty = expressionHelpers.setGroupProperty, d;
        };
        var n = PropertyFactory.getProp;
        PropertyFactory.getProp = function(u, x, g, d, A) {
          var c = n(u, x, g, d, A);
          c.kf ? c.getValueAtTime = expressionHelpers.getValueAtTime.bind(c) : c.getValueAtTime = expressionHelpers.getStaticValueAtTime.bind(c), c.setGroupProperty = expressionHelpers.setGroupProperty, c.loopOut = t, c.loopIn = e, c.smooth = r, c.getVelocityAtTime = expressionHelpers.getVelocityAtTime.bind(c), c.getSpeedAtTime = expressionHelpers.getSpeedAtTime.bind(c), c.numKeys = x.a === 1 ? x.k.length : 0, c.propertyIndex = x.ix;
          var m = 0;
          return g !== 0 && (m = createTypedArray("float32", x.a === 1 ? x.k[0].s.length : x.k.length)), c._cachingAtTime = {
            lastFrame: initialDefaultFrame,
            lastIndex: 0,
            value: m
          }, expressionHelpers.searchExpressions(u, x, c), c.k && A.addDynamicProperty(c), c;
        };
        function l(u) {
          return this._cachingAtTime || (this._cachingAtTime = {
            shapeValue: shapePool.clone(this.pv),
            lastIndex: 0,
            lastTime: initialDefaultFrame
          }), u *= this.elem.globalData.frameRate, u -= this.offsetTime, u !== this._cachingAtTime.lastTime && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastTime < u ? this._caching.lastIndex : 0, this._cachingAtTime.lastTime = u, this.interpolateShape(u, this._cachingAtTime.shapeValue, this._cachingAtTime)), this._cachingAtTime.shapeValue;
        }
        var o = ShapePropertyFactory.getConstructorFunction(), p = ShapePropertyFactory.getKeyframedConstructorFunction();
        function y() {
        }
        y.prototype = {
          vertices: function(x, g) {
            this.k && this.getValue();
            var d = this.v;
            g !== void 0 && (d = this.getValueAtTime(g, 0));
            var A, c = d._length, m = d[x], f = d.v, b = createSizedArray(c);
            for (A = 0; A < c; A += 1) x === "i" || x === "o" ? b[A] = [
              m[A][0] - f[A][0],
              m[A][1] - f[A][1]
            ] : b[A] = [
              m[A][0],
              m[A][1]
            ];
            return b;
          },
          points: function(x) {
            return this.vertices("v", x);
          },
          inTangents: function(x) {
            return this.vertices("i", x);
          },
          outTangents: function(x) {
            return this.vertices("o", x);
          },
          isClosed: function() {
            return this.v.c;
          },
          pointOnPath: function(x, g) {
            var d = this.v;
            g !== void 0 && (d = this.getValueAtTime(g, 0)), this._segmentsLength || (this._segmentsLength = bez.getSegmentsLength(d));
            for (var A = this._segmentsLength, c = A.lengths, m = A.totalLength * x, f = 0, b = c.length, C = 0, _; f < b; ) {
              if (C + c[f].addedLength > m) {
                var T = f, I = d.c && f === b - 1 ? 0 : f + 1, L = (m - C) / c[f].addedLength;
                _ = bez.getPointInSegment(d.v[T], d.v[I], d.o[T], d.i[I], L, c[f]);
                break;
              } else C += c[f].addedLength;
              f += 1;
            }
            return _ || (_ = d.c ? [
              d.v[0][0],
              d.v[0][1]
            ] : [
              d.v[d._length - 1][0],
              d.v[d._length - 1][1]
            ]), _;
          },
          vectorOnPath: function(x, g, d) {
            x == 1 ? x = this.v.c : x == 0 && (x = 0.999);
            var A = this.pointOnPath(x, g), c = this.pointOnPath(x + 1e-3, g), m = c[0] - A[0], f = c[1] - A[1], b = Math.sqrt(Math.pow(m, 2) + Math.pow(f, 2));
            if (b === 0) return [
              0,
              0
            ];
            var C = d === "tangent" ? [
              m / b,
              f / b
            ] : [
              -f / b,
              m / b
            ];
            return C;
          },
          tangentOnPath: function(x, g) {
            return this.vectorOnPath(x, g, "tangent");
          },
          normalOnPath: function(x, g) {
            return this.vectorOnPath(x, g, "normal");
          },
          setGroupProperty: expressionHelpers.setGroupProperty,
          getValueAtTime: expressionHelpers.getStaticValueAtTime
        }, extendPrototype([
          y
        ], o), extendPrototype([
          y
        ], p), p.prototype.getValueAtTime = l, p.prototype.initiateExpression = ExpressionManager.initiateExpression;
        var E = ShapePropertyFactory.getShapeProp;
        ShapePropertyFactory.getShapeProp = function(u, x, g, d, A) {
          var c = E(u, x, g, d, A);
          return c.propertyIndex = x.ix, c.lock = false, g === 3 ? expressionHelpers.searchExpressions(u, x.pt, c) : g === 4 && expressionHelpers.searchExpressions(u, x.ks, c), c.k && u.addDynamicProperty(c), c;
        };
      }
      function initialize$1() {
        addPropertyDecorator();
      }
      function addDecorator() {
        function t() {
          return this.data.d.x ? (this.calculateExpression = ExpressionManager.initiateExpression.bind(this)(this.elem, this.data.d, this), this.addEffect(this.getExpressionValue.bind(this)), true) : null;
        }
        TextProperty.prototype.getExpressionValue = function(e, r) {
          var i = this.calculateExpression(r);
          if (e.t !== i) {
            var s = {};
            return this.copyData(s, e), s.t = i.toString(), s.__complete = false, s;
          }
          return e;
        }, TextProperty.prototype.searchProperty = function() {
          var e = this.searchKeyframes(), r = this.searchExpressions();
          return this.kf = e || r, this.kf;
        }, TextProperty.prototype.searchExpressions = t;
      }
      function initialize() {
        addDecorator();
      }
      function SVGComposableEffect() {
      }
      SVGComposableEffect.prototype = {
        createMergeNode: function t(e, r) {
          var i = createNS("feMerge");
          i.setAttribute("result", e);
          var s, a;
          for (a = 0; a < r.length; a += 1) s = createNS("feMergeNode"), s.setAttribute("in", r[a]), i.appendChild(s), i.appendChild(s);
          return i;
        }
      };
      var linearFilterValue = "0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0";
      function SVGTintFilter(t, e, r, i, s) {
        this.filterManager = e;
        var a = createNS("feColorMatrix");
        a.setAttribute("type", "matrix"), a.setAttribute("color-interpolation-filters", "linearRGB"), a.setAttribute("values", linearFilterValue + " 1 0"), this.linearFilter = a, a.setAttribute("result", i + "_tint_1"), t.appendChild(a), a = createNS("feColorMatrix"), a.setAttribute("type", "matrix"), a.setAttribute("color-interpolation-filters", "sRGB"), a.setAttribute("values", "1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"), a.setAttribute("result", i + "_tint_2"), t.appendChild(a), this.matrixFilter = a;
        var n = this.createMergeNode(i, [
          s,
          i + "_tint_1",
          i + "_tint_2"
        ]);
        t.appendChild(n);
      }
      extendPrototype([
        SVGComposableEffect
      ], SVGTintFilter), SVGTintFilter.prototype.renderFrame = function(t) {
        if (t || this.filterManager._mdf) {
          var e = this.filterManager.effectElements[0].p.v, r = this.filterManager.effectElements[1].p.v, i = this.filterManager.effectElements[2].p.v / 100;
          this.linearFilter.setAttribute("values", linearFilterValue + " " + i + " 0"), this.matrixFilter.setAttribute("values", r[0] - e[0] + " 0 0 0 " + e[0] + " " + (r[1] - e[1]) + " 0 0 0 " + e[1] + " " + (r[2] - e[2]) + " 0 0 0 " + e[2] + " 0 0 0 1 0");
        }
      };
      function SVGFillFilter(t, e, r, i) {
        this.filterManager = e;
        var s = createNS("feColorMatrix");
        s.setAttribute("type", "matrix"), s.setAttribute("color-interpolation-filters", "sRGB"), s.setAttribute("values", "1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"), s.setAttribute("result", i), t.appendChild(s), this.matrixFilter = s;
      }
      SVGFillFilter.prototype.renderFrame = function(t) {
        if (t || this.filterManager._mdf) {
          var e = this.filterManager.effectElements[2].p.v, r = this.filterManager.effectElements[6].p.v;
          this.matrixFilter.setAttribute("values", "0 0 0 0 " + e[0] + " 0 0 0 0 " + e[1] + " 0 0 0 0 " + e[2] + " 0 0 0 " + r + " 0");
        }
      };
      function SVGStrokeEffect(t, e, r) {
        this.initialized = false, this.filterManager = e, this.elem = r, this.paths = [];
      }
      SVGStrokeEffect.prototype.initialize = function() {
        var t = this.elem.layerElement.children || this.elem.layerElement.childNodes, e, r, i, s;
        for (this.filterManager.effectElements[1].p.v === 1 ? (s = this.elem.maskManager.masksProperties.length, i = 0) : (i = this.filterManager.effectElements[0].p.v - 1, s = i + 1), r = createNS("g"), r.setAttribute("fill", "none"), r.setAttribute("stroke-linecap", "round"), r.setAttribute("stroke-dashoffset", 1), i; i < s; i += 1) e = createNS("path"), r.appendChild(e), this.paths.push({
          p: e,
          m: i
        });
        if (this.filterManager.effectElements[10].p.v === 3) {
          var a = createNS("mask"), n = createElementID();
          a.setAttribute("id", n), a.setAttribute("mask-type", "alpha"), a.appendChild(r), this.elem.globalData.defs.appendChild(a);
          var l = createNS("g");
          for (l.setAttribute("mask", "url(" + getLocationHref() + "#" + n + ")"); t[0]; ) l.appendChild(t[0]);
          this.elem.layerElement.appendChild(l), this.masker = a, r.setAttribute("stroke", "#fff");
        } else if (this.filterManager.effectElements[10].p.v === 1 || this.filterManager.effectElements[10].p.v === 2) {
          if (this.filterManager.effectElements[10].p.v === 2) for (t = this.elem.layerElement.children || this.elem.layerElement.childNodes; t.length; ) this.elem.layerElement.removeChild(t[0]);
          this.elem.layerElement.appendChild(r), this.elem.layerElement.removeAttribute("mask"), r.setAttribute("stroke", "#fff");
        }
        this.initialized = true, this.pathMasker = r;
      }, SVGStrokeEffect.prototype.renderFrame = function(t) {
        this.initialized || this.initialize();
        var e, r = this.paths.length, i, s;
        for (e = 0; e < r; e += 1) if (this.paths[e].m !== -1 && (i = this.elem.maskManager.viewData[this.paths[e].m], s = this.paths[e].p, (t || this.filterManager._mdf || i.prop._mdf) && s.setAttribute("d", i.lastPath), t || this.filterManager.effectElements[9].p._mdf || this.filterManager.effectElements[4].p._mdf || this.filterManager.effectElements[7].p._mdf || this.filterManager.effectElements[8].p._mdf || i.prop._mdf)) {
          var a;
          if (this.filterManager.effectElements[7].p.v !== 0 || this.filterManager.effectElements[8].p.v !== 100) {
            var n = Math.min(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v) * 0.01, l = Math.max(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v) * 0.01, o = s.getTotalLength();
            a = "0 0 0 " + o * n + " ";
            var p = o * (l - n), y = 1 + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * 0.01, E = Math.floor(p / y), u;
            for (u = 0; u < E; u += 1) a += "1 " + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * 0.01 + " ";
            a += "0 " + o * 10 + " 0 0";
          } else a = "1 " + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * 0.01;
          s.setAttribute("stroke-dasharray", a);
        }
        if ((t || this.filterManager.effectElements[4].p._mdf) && this.pathMasker.setAttribute("stroke-width", this.filterManager.effectElements[4].p.v * 2), (t || this.filterManager.effectElements[6].p._mdf) && this.pathMasker.setAttribute("opacity", this.filterManager.effectElements[6].p.v), (this.filterManager.effectElements[10].p.v === 1 || this.filterManager.effectElements[10].p.v === 2) && (t || this.filterManager.effectElements[3].p._mdf)) {
          var x = this.filterManager.effectElements[3].p.v;
          this.pathMasker.setAttribute("stroke", "rgb(" + bmFloor(x[0] * 255) + "," + bmFloor(x[1] * 255) + "," + bmFloor(x[2] * 255) + ")");
        }
      };
      function SVGTritoneFilter(t, e, r, i) {
        this.filterManager = e;
        var s = createNS("feColorMatrix");
        s.setAttribute("type", "matrix"), s.setAttribute("color-interpolation-filters", "linearRGB"), s.setAttribute("values", "0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0"), t.appendChild(s);
        var a = createNS("feComponentTransfer");
        a.setAttribute("color-interpolation-filters", "sRGB"), a.setAttribute("result", i), this.matrixFilter = a;
        var n = createNS("feFuncR");
        n.setAttribute("type", "table"), a.appendChild(n), this.feFuncR = n;
        var l = createNS("feFuncG");
        l.setAttribute("type", "table"), a.appendChild(l), this.feFuncG = l;
        var o = createNS("feFuncB");
        o.setAttribute("type", "table"), a.appendChild(o), this.feFuncB = o, t.appendChild(a);
      }
      SVGTritoneFilter.prototype.renderFrame = function(t) {
        if (t || this.filterManager._mdf) {
          var e = this.filterManager.effectElements[0].p.v, r = this.filterManager.effectElements[1].p.v, i = this.filterManager.effectElements[2].p.v, s = i[0] + " " + r[0] + " " + e[0], a = i[1] + " " + r[1] + " " + e[1], n = i[2] + " " + r[2] + " " + e[2];
          this.feFuncR.setAttribute("tableValues", s), this.feFuncG.setAttribute("tableValues", a), this.feFuncB.setAttribute("tableValues", n);
        }
      };
      function SVGProLevelsFilter(t, e, r, i) {
        this.filterManager = e;
        var s = this.filterManager.effectElements, a = createNS("feComponentTransfer");
        (s[10].p.k || s[10].p.v !== 0 || s[11].p.k || s[11].p.v !== 1 || s[12].p.k || s[12].p.v !== 1 || s[13].p.k || s[13].p.v !== 0 || s[14].p.k || s[14].p.v !== 1) && (this.feFuncR = this.createFeFunc("feFuncR", a)), (s[17].p.k || s[17].p.v !== 0 || s[18].p.k || s[18].p.v !== 1 || s[19].p.k || s[19].p.v !== 1 || s[20].p.k || s[20].p.v !== 0 || s[21].p.k || s[21].p.v !== 1) && (this.feFuncG = this.createFeFunc("feFuncG", a)), (s[24].p.k || s[24].p.v !== 0 || s[25].p.k || s[25].p.v !== 1 || s[26].p.k || s[26].p.v !== 1 || s[27].p.k || s[27].p.v !== 0 || s[28].p.k || s[28].p.v !== 1) && (this.feFuncB = this.createFeFunc("feFuncB", a)), (s[31].p.k || s[31].p.v !== 0 || s[32].p.k || s[32].p.v !== 1 || s[33].p.k || s[33].p.v !== 1 || s[34].p.k || s[34].p.v !== 0 || s[35].p.k || s[35].p.v !== 1) && (this.feFuncA = this.createFeFunc("feFuncA", a)), (this.feFuncR || this.feFuncG || this.feFuncB || this.feFuncA) && (a.setAttribute("color-interpolation-filters", "sRGB"), t.appendChild(a)), (s[3].p.k || s[3].p.v !== 0 || s[4].p.k || s[4].p.v !== 1 || s[5].p.k || s[5].p.v !== 1 || s[6].p.k || s[6].p.v !== 0 || s[7].p.k || s[7].p.v !== 1) && (a = createNS("feComponentTransfer"), a.setAttribute("color-interpolation-filters", "sRGB"), a.setAttribute("result", i), t.appendChild(a), this.feFuncRComposed = this.createFeFunc("feFuncR", a), this.feFuncGComposed = this.createFeFunc("feFuncG", a), this.feFuncBComposed = this.createFeFunc("feFuncB", a));
      }
      SVGProLevelsFilter.prototype.createFeFunc = function(t, e) {
        var r = createNS(t);
        return r.setAttribute("type", "table"), e.appendChild(r), r;
      }, SVGProLevelsFilter.prototype.getTableValue = function(t, e, r, i, s) {
        for (var a = 0, n = 256, l, o = Math.min(t, e), p = Math.max(t, e), y = Array.call(null, {
          length: n
        }), E, u = 0, x = s - i, g = e - t; a <= 256; ) l = a / 256, l <= o ? E = g < 0 ? s : i : l >= p ? E = g < 0 ? i : s : E = i + x * Math.pow((l - t) / g, 1 / r), y[u] = E, u += 1, a += 256 / (n - 1);
        return y.join(" ");
      }, SVGProLevelsFilter.prototype.renderFrame = function(t) {
        if (t || this.filterManager._mdf) {
          var e, r = this.filterManager.effectElements;
          this.feFuncRComposed && (t || r[3].p._mdf || r[4].p._mdf || r[5].p._mdf || r[6].p._mdf || r[7].p._mdf) && (e = this.getTableValue(r[3].p.v, r[4].p.v, r[5].p.v, r[6].p.v, r[7].p.v), this.feFuncRComposed.setAttribute("tableValues", e), this.feFuncGComposed.setAttribute("tableValues", e), this.feFuncBComposed.setAttribute("tableValues", e)), this.feFuncR && (t || r[10].p._mdf || r[11].p._mdf || r[12].p._mdf || r[13].p._mdf || r[14].p._mdf) && (e = this.getTableValue(r[10].p.v, r[11].p.v, r[12].p.v, r[13].p.v, r[14].p.v), this.feFuncR.setAttribute("tableValues", e)), this.feFuncG && (t || r[17].p._mdf || r[18].p._mdf || r[19].p._mdf || r[20].p._mdf || r[21].p._mdf) && (e = this.getTableValue(r[17].p.v, r[18].p.v, r[19].p.v, r[20].p.v, r[21].p.v), this.feFuncG.setAttribute("tableValues", e)), this.feFuncB && (t || r[24].p._mdf || r[25].p._mdf || r[26].p._mdf || r[27].p._mdf || r[28].p._mdf) && (e = this.getTableValue(r[24].p.v, r[25].p.v, r[26].p.v, r[27].p.v, r[28].p.v), this.feFuncB.setAttribute("tableValues", e)), this.feFuncA && (t || r[31].p._mdf || r[32].p._mdf || r[33].p._mdf || r[34].p._mdf || r[35].p._mdf) && (e = this.getTableValue(r[31].p.v, r[32].p.v, r[33].p.v, r[34].p.v, r[35].p.v), this.feFuncA.setAttribute("tableValues", e));
        }
      };
      function SVGDropShadowEffect(t, e, r, i, s) {
        var a = e.container.globalData.renderConfig.filterSize, n = e.data.fs || a;
        t.setAttribute("x", n.x || a.x), t.setAttribute("y", n.y || a.y), t.setAttribute("width", n.width || a.width), t.setAttribute("height", n.height || a.height), this.filterManager = e;
        var l = createNS("feGaussianBlur");
        l.setAttribute("in", "SourceAlpha"), l.setAttribute("result", i + "_drop_shadow_1"), l.setAttribute("stdDeviation", "0"), this.feGaussianBlur = l, t.appendChild(l);
        var o = createNS("feOffset");
        o.setAttribute("dx", "25"), o.setAttribute("dy", "0"), o.setAttribute("in", i + "_drop_shadow_1"), o.setAttribute("result", i + "_drop_shadow_2"), this.feOffset = o, t.appendChild(o);
        var p = createNS("feFlood");
        p.setAttribute("flood-color", "#00ff00"), p.setAttribute("flood-opacity", "1"), p.setAttribute("result", i + "_drop_shadow_3"), this.feFlood = p, t.appendChild(p);
        var y = createNS("feComposite");
        y.setAttribute("in", i + "_drop_shadow_3"), y.setAttribute("in2", i + "_drop_shadow_2"), y.setAttribute("operator", "in"), y.setAttribute("result", i + "_drop_shadow_4"), t.appendChild(y);
        var E = this.createMergeNode(i, [
          i + "_drop_shadow_4",
          s
        ]);
        t.appendChild(E);
      }
      extendPrototype([
        SVGComposableEffect
      ], SVGDropShadowEffect), SVGDropShadowEffect.prototype.renderFrame = function(t) {
        if (t || this.filterManager._mdf) {
          if ((t || this.filterManager.effectElements[4].p._mdf) && this.feGaussianBlur.setAttribute("stdDeviation", this.filterManager.effectElements[4].p.v / 4), t || this.filterManager.effectElements[0].p._mdf) {
            var e = this.filterManager.effectElements[0].p.v;
            this.feFlood.setAttribute("flood-color", rgbToHex(Math.round(e[0] * 255), Math.round(e[1] * 255), Math.round(e[2] * 255)));
          }
          if ((t || this.filterManager.effectElements[1].p._mdf) && this.feFlood.setAttribute("flood-opacity", this.filterManager.effectElements[1].p.v / 255), t || this.filterManager.effectElements[2].p._mdf || this.filterManager.effectElements[3].p._mdf) {
            var r = this.filterManager.effectElements[3].p.v, i = (this.filterManager.effectElements[2].p.v - 90) * degToRads, s = r * Math.cos(i), a = r * Math.sin(i);
            this.feOffset.setAttribute("dx", s), this.feOffset.setAttribute("dy", a);
          }
        }
      };
      var _svgMatteSymbols = [];
      function SVGMatte3Effect(t, e, r) {
        this.initialized = false, this.filterManager = e, this.filterElem = t, this.elem = r, r.matteElement = createNS("g"), r.matteElement.appendChild(r.layerElement), r.matteElement.appendChild(r.transformedElement), r.baseElement = r.matteElement;
      }
      SVGMatte3Effect.prototype.findSymbol = function(t) {
        for (var e = 0, r = _svgMatteSymbols.length; e < r; ) {
          if (_svgMatteSymbols[e] === t) return _svgMatteSymbols[e];
          e += 1;
        }
        return null;
      }, SVGMatte3Effect.prototype.replaceInParent = function(t, e) {
        var r = t.layerElement.parentNode;
        if (r) {
          for (var i = r.children, s = 0, a = i.length; s < a && i[s] !== t.layerElement; ) s += 1;
          var n;
          s <= a - 2 && (n = i[s + 1]);
          var l = createNS("use");
          l.setAttribute("href", "#" + e), n ? r.insertBefore(l, n) : r.appendChild(l);
        }
      }, SVGMatte3Effect.prototype.setElementAsMask = function(t, e) {
        if (!this.findSymbol(e)) {
          var r = createElementID(), i = createNS("mask");
          i.setAttribute("id", e.layerId), i.setAttribute("mask-type", "alpha"), _svgMatteSymbols.push(e);
          var s = t.globalData.defs;
          s.appendChild(i);
          var a = createNS("symbol");
          a.setAttribute("id", r), this.replaceInParent(e, r), a.appendChild(e.layerElement), s.appendChild(a);
          var n = createNS("use");
          n.setAttribute("href", "#" + r), i.appendChild(n), e.data.hd = false, e.show();
        }
        t.setMatte(e.layerId);
      }, SVGMatte3Effect.prototype.initialize = function() {
        for (var t = this.filterManager.effectElements[0].p.v, e = this.elem.comp.elements, r = 0, i = e.length; r < i; ) e[r] && e[r].data.ind === t && this.setElementAsMask(this.elem, e[r]), r += 1;
        this.initialized = true;
      }, SVGMatte3Effect.prototype.renderFrame = function() {
        this.initialized || this.initialize();
      };
      function SVGGaussianBlurEffect(t, e, r, i) {
        t.setAttribute("x", "-100%"), t.setAttribute("y", "-100%"), t.setAttribute("width", "300%"), t.setAttribute("height", "300%"), this.filterManager = e;
        var s = createNS("feGaussianBlur");
        s.setAttribute("result", i), t.appendChild(s), this.feGaussianBlur = s;
      }
      SVGGaussianBlurEffect.prototype.renderFrame = function(t) {
        if (t || this.filterManager._mdf) {
          var e = 0.3, r = this.filterManager.effectElements[0].p.v * e, i = this.filterManager.effectElements[1].p.v, s = i == 3 ? 0 : r, a = i == 2 ? 0 : r;
          this.feGaussianBlur.setAttribute("stdDeviation", s + " " + a);
          var n = this.filterManager.effectElements[2].p.v == 1 ? "wrap" : "duplicate";
          this.feGaussianBlur.setAttribute("edgeMode", n);
        }
      };
      function TransformEffect() {
      }
      TransformEffect.prototype.init = function(t) {
        this.effectsManager = t, this.type = effectTypes.TRANSFORM_EFFECT, this.matrix = new Matrix(), this.opacity = -1, this._mdf = false, this._opMdf = false;
      }, TransformEffect.prototype.renderFrame = function(t) {
        if (this._opMdf = false, this._mdf = false, t || this.effectsManager._mdf) {
          var e = this.effectsManager.effectElements, r = e[0].p.v, i = e[1].p.v, s = e[2].p.v === 1, a = e[3].p.v, n = s ? a : e[4].p.v, l = e[5].p.v, o = e[6].p.v, p = e[7].p.v;
          this.matrix.reset(), this.matrix.translate(-r[0], -r[1], r[2]), this.matrix.scale(n * 0.01, a * 0.01, 1), this.matrix.rotate(-p * degToRads), this.matrix.skewFromAxis(-l * degToRads, (o + 90) * degToRads), this.matrix.translate(i[0], i[1], 0), this._mdf = true, this.opacity !== e[8].p.v && (this.opacity = e[8].p.v, this._opMdf = true);
        }
      };
      function SVGTransformEffect(t, e) {
        this.init(e);
      }
      extendPrototype([
        TransformEffect
      ], SVGTransformEffect);
      function CVTransformEffect(t) {
        this.init(t);
      }
      return extendPrototype([
        TransformEffect
      ], CVTransformEffect), registerRenderer("canvas", CanvasRenderer), registerRenderer("html", HybridRenderer), registerRenderer("svg", SVGRenderer), ShapeModifiers.registerModifier("tm", TrimModifier), ShapeModifiers.registerModifier("pb", PuckerAndBloatModifier), ShapeModifiers.registerModifier("rp", RepeaterModifier), ShapeModifiers.registerModifier("rd", RoundCornersModifier), ShapeModifiers.registerModifier("zz", ZigZagModifier), ShapeModifiers.registerModifier("op", OffsetPathModifier), setExpressionsPlugin(Expressions), setExpressionInterfaces(getInterface), initialize$1(), initialize(), registerEffect$1(20, SVGTintFilter, true), registerEffect$1(21, SVGFillFilter, true), registerEffect$1(22, SVGStrokeEffect, false), registerEffect$1(23, SVGTritoneFilter, true), registerEffect$1(24, SVGProLevelsFilter, true), registerEffect$1(25, SVGDropShadowEffect, true), registerEffect$1(28, SVGMatte3Effect, false), registerEffect$1(29, SVGGaussianBlurEffect, true), registerEffect$1(35, SVGTransformEffect, false), registerEffect(35, CVTransformEffect), lottie;
    }));
  })(lottie$2, lottie$2.exports);
  var lottieExports = lottie$2.exports;
  const lottie$1 = getDefaultExportFromCjs(lottieExports);
  function _arrayLikeToArray(t, e) {
    (e == null || e > t.length) && (e = t.length);
    for (var r = 0, i = Array(e); r < e; r++) i[r] = t[r];
    return i;
  }
  function _arrayWithHoles(t) {
    if (Array.isArray(t)) return t;
  }
  function _defineProperty(t, e, r) {
    return (e = _toPropertyKey(e)) in t ? Object.defineProperty(t, e, {
      value: r,
      enumerable: true,
      configurable: true,
      writable: true
    }) : t[e] = r, t;
  }
  function _iterableToArrayLimit(t, e) {
    var r = t == null ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
    if (r != null) {
      var i, s, a, n, l = [], o = true, p = false;
      try {
        if (a = (r = r.call(t)).next, e !== 0) for (; !(o = (i = a.call(r)).done) && (l.push(i.value), l.length !== e); o = true) ;
      } catch (y) {
        p = true, s = y;
      } finally {
        try {
          if (!o && r.return != null && (n = r.return(), Object(n) !== n)) return;
        } finally {
          if (p) throw s;
        }
      }
      return l;
    }
  }
  function _nonIterableRest() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  function ownKeys(t, e) {
    var r = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
      var i = Object.getOwnPropertySymbols(t);
      e && (i = i.filter(function(s) {
        return Object.getOwnPropertyDescriptor(t, s).enumerable;
      })), r.push.apply(r, i);
    }
    return r;
  }
  function _objectSpread2(t) {
    for (var e = 1; e < arguments.length; e++) {
      var r = arguments[e] != null ? arguments[e] : {};
      e % 2 ? ownKeys(Object(r), true).forEach(function(i) {
        _defineProperty(t, i, r[i]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : ownKeys(Object(r)).forEach(function(i) {
        Object.defineProperty(t, i, Object.getOwnPropertyDescriptor(r, i));
      });
    }
    return t;
  }
  function _objectWithoutProperties(t, e) {
    if (t == null) return {};
    var r, i, s = _objectWithoutPropertiesLoose(t, e);
    if (Object.getOwnPropertySymbols) {
      var a = Object.getOwnPropertySymbols(t);
      for (i = 0; i < a.length; i++) r = a[i], e.includes(r) || {}.propertyIsEnumerable.call(t, r) && (s[r] = t[r]);
    }
    return s;
  }
  function _objectWithoutPropertiesLoose(t, e) {
    if (t == null) return {};
    var r = {};
    for (var i in t) if ({}.hasOwnProperty.call(t, i)) {
      if (e.includes(i)) continue;
      r[i] = t[i];
    }
    return r;
  }
  function _slicedToArray(t, e) {
    return _arrayWithHoles(t) || _iterableToArrayLimit(t, e) || _unsupportedIterableToArray(t, e) || _nonIterableRest();
  }
  function _toPrimitive(t, e) {
    if (typeof t != "object" || !t) return t;
    var r = t[Symbol.toPrimitive];
    if (r !== void 0) {
      var i = r.call(t, e);
      if (typeof i != "object") return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (e === "string" ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var e = _toPrimitive(t, "string");
    return typeof e == "symbol" ? e : e + "";
  }
  function _unsupportedIterableToArray(t, e) {
    if (t) {
      if (typeof t == "string") return _arrayLikeToArray(t, e);
      var r = {}.toString.call(t).slice(8, -1);
      return r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set" ? Array.from(t) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? _arrayLikeToArray(t, e) : void 0;
    }
  }
  var _excluded$1 = [
    "animationData",
    "loop",
    "autoplay",
    "initialSegment",
    "onComplete",
    "onLoopComplete",
    "onEnterFrame",
    "onSegmentStart",
    "onConfigReady",
    "onDataReady",
    "onDataFailed",
    "onLoadedImages",
    "onDOMLoaded",
    "onDestroy",
    "lottieRef",
    "renderer",
    "name",
    "assetsPath",
    "rendererSettings"
  ], useLottie = function t(e, r) {
    var i = e.animationData, s = e.loop, a = e.autoplay, n = e.initialSegment, l = e.onComplete, o = e.onLoopComplete, p = e.onEnterFrame, y = e.onSegmentStart, E = e.onConfigReady, u = e.onDataReady, x = e.onDataFailed, g = e.onLoadedImages, d = e.onDOMLoaded, A = e.onDestroy;
    e.lottieRef, e.renderer, e.name, e.assetsPath, e.rendererSettings;
    var c = _objectWithoutProperties(e, _excluded$1), m = __mf_32(false), f = _slicedToArray(m, 2), b = f[0], C = f[1], _ = __mf_31(), T = __mf_31(null), I = function() {
      var B;
      (B = _.current) === null || B === void 0 || B.play();
    }, L = function() {
      var B;
      (B = _.current) === null || B === void 0 || B.stop();
    }, j = function() {
      var B;
      (B = _.current) === null || B === void 0 || B.pause();
    }, O = function(B) {
      var G;
      (G = _.current) === null || G === void 0 || G.setSpeed(B);
    }, D = function(B, G) {
      var z;
      (z = _.current) === null || z === void 0 || z.goToAndPlay(B, G);
    }, N = function(B, G) {
      var z;
      (z = _.current) === null || z === void 0 || z.goToAndStop(B, G);
    }, H = function(B) {
      var G;
      (G = _.current) === null || G === void 0 || G.setDirection(B);
    }, R = function(B, G) {
      var z;
      (z = _.current) === null || z === void 0 || z.playSegments(B, G);
    }, k = function(B) {
      var G;
      (G = _.current) === null || G === void 0 || G.setSubframe(B);
    }, M = function(B) {
      var G;
      return (G = _.current) === null || G === void 0 ? void 0 : G.getDuration(B);
    }, S = function() {
      var B;
      (B = _.current) === null || B === void 0 || B.destroy(), _.current = void 0;
    }, P = function() {
      var B = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, G;
      if (T.current) {
        (G = _.current) === null || G === void 0 || G.destroy();
        var z = _objectSpread2(_objectSpread2(_objectSpread2({}, e), B), {}, {
          container: T.current
        });
        return _.current = lottie$1.loadAnimation(z), C(!!_.current), function() {
          var q;
          (q = _.current) === null || q === void 0 || q.destroy(), _.current = void 0;
        };
      }
    };
    __mf_24(function() {
      var F = P();
      return function() {
        return F == null ? void 0 : F();
      };
    }, [
      i,
      s
    ]), __mf_24(function() {
      _.current && (_.current.autoplay = !!a);
    }, [
      a
    ]), __mf_24(function() {
      if (_.current) {
        if (!n) {
          _.current.resetSegments(true);
          return;
        }
        !Array.isArray(n) || !n.length || ((_.current.currentRawFrame < n[0] || _.current.currentRawFrame > n[1]) && (_.current.currentRawFrame = n[0]), _.current.setSegment(n[0], n[1]));
      }
    }, [
      n
    ]), __mf_24(function() {
      var F = [
        {
          name: "complete",
          handler: l
        },
        {
          name: "loopComplete",
          handler: o
        },
        {
          name: "enterFrame",
          handler: p
        },
        {
          name: "segmentStart",
          handler: y
        },
        {
          name: "config_ready",
          handler: E
        },
        {
          name: "data_ready",
          handler: u
        },
        {
          name: "data_failed",
          handler: x
        },
        {
          name: "loaded_images",
          handler: g
        },
        {
          name: "DOMLoaded",
          handler: d
        },
        {
          name: "destroy",
          handler: A
        }
      ], B = F.filter(function(z) {
        return z.handler != null;
      });
      if (B.length) {
        var G = B.map(function(z) {
          var q;
          return (q = _.current) === null || q === void 0 || q.addEventListener(z.name, z.handler), function() {
            var $;
            ($ = _.current) === null || $ === void 0 || $.removeEventListener(z.name, z.handler);
          };
        });
        return function() {
          G.forEach(function(z) {
            return z();
          });
        };
      }
    }, [
      l,
      o,
      p,
      y,
      E,
      u,
      x,
      g,
      d,
      A
    ]);
    var V = React.createElement("div", _objectSpread2({
      style: r,
      ref: T
    }, c));
    return {
      View: V,
      play: I,
      stop: L,
      pause: j,
      setSpeed: O,
      goToAndStop: N,
      goToAndPlay: D,
      setDirection: H,
      playSegments: R,
      setSubframe: k,
      getDuration: M,
      destroy: S,
      animationContainerRef: T,
      animationLoaded: b,
      animationItem: _.current
    };
  };
  function getContainerVisibility(t) {
    var e = t.getBoundingClientRect(), r = e.top, i = e.height, s = window.innerHeight - r, a = window.innerHeight + i;
    return s / a;
  }
  function getContainerCursorPosition(t, e, r) {
    var i = t.getBoundingClientRect(), s = i.top, a = i.left, n = i.width, l = i.height, o = (e - a) / n, p = (r - s) / l;
    return {
      x: o,
      y: p
    };
  }
  var useInitInteractivity = function t(e) {
    var r = e.wrapperRef, i = e.animationItem, s = e.mode, a = e.actions;
    __mf_24(function() {
      var n = r.current;
      if (!(!n || !i || !a.length)) {
        i.stop();
        var l = function() {
          var y = null, E = function() {
            var x = getContainerVisibility(n), g = a.find(function(A) {
              var c = A.visibility;
              return c && x >= c[0] && x <= c[1];
            });
            if (g) {
              if (g.type === "seek" && g.visibility && g.frames.length === 2) {
                var d = g.frames[0] + Math.ceil((x - g.visibility[0]) / (g.visibility[1] - g.visibility[0]) * g.frames[1]);
                i.goToAndStop(d - i.firstFrame - 1, true);
              }
              g.type === "loop" && (y === null || y !== g.frames || i.isPaused) && (i.playSegments(g.frames, true), y = g.frames), g.type === "play" && i.isPaused && (i.resetSegments(true), i.play()), g.type === "stop" && i.goToAndStop(g.frames[0] - i.firstFrame - 1, true);
            }
          };
          return document.addEventListener("scroll", E), function() {
            document.removeEventListener("scroll", E);
          };
        }, o = function() {
          var y = function(g, d) {
            var A = g, c = d;
            if (A !== -1 && c !== -1) {
              var m = getContainerCursorPosition(n, A, c);
              A = m.x, c = m.y;
            }
            var f = a.find(function(_) {
              var T = _.position;
              return T && Array.isArray(T.x) && Array.isArray(T.y) ? A >= T.x[0] && A <= T.x[1] && c >= T.y[0] && c <= T.y[1] : T && !Number.isNaN(T.x) && !Number.isNaN(T.y) ? A === T.x && c === T.y : false;
            });
            if (f) {
              if (f.type === "seek" && f.position && Array.isArray(f.position.x) && Array.isArray(f.position.y) && f.frames.length === 2) {
                var b = (A - f.position.x[0]) / (f.position.x[1] - f.position.x[0]), C = (c - f.position.y[0]) / (f.position.y[1] - f.position.y[0]);
                i.playSegments(f.frames, true), i.goToAndStop(Math.ceil((b + C) / 2 * (f.frames[1] - f.frames[0])), true);
              }
              f.type === "loop" && i.playSegments(f.frames, true), f.type === "play" && (i.isPaused && i.resetSegments(false), i.playSegments(f.frames)), f.type === "stop" && i.goToAndStop(f.frames[0], true);
            }
          }, E = function(g) {
            y(g.clientX, g.clientY);
          }, u = function() {
            y(-1, -1);
          };
          return n.addEventListener("mousemove", E), n.addEventListener("mouseout", u), function() {
            n.removeEventListener("mousemove", E), n.removeEventListener("mouseout", u);
          };
        };
        switch (s) {
          case "scroll":
            return l();
          case "cursor":
            return o();
        }
      }
    }, [
      s,
      i
    ]);
  }, useLottieInteractivity = function t(e) {
    var r = e.actions, i = e.mode, s = e.lottieObj, a = s.animationItem, n = s.View, l = s.animationContainerRef;
    return useInitInteractivity({
      actions: r,
      animationItem: a,
      mode: i,
      wrapperRef: l
    }), n;
  }, _excluded = [
    "style",
    "interactivity"
  ], Lottie = function t(e) {
    var r, i, s, a = e.style, n = e.interactivity, l = _objectWithoutProperties(e, _excluded), o = useLottie(l, a), p = o.View, y = o.play, E = o.stop, u = o.pause, x = o.setSpeed, g = o.goToAndStop, d = o.goToAndPlay, A = o.setDirection, c = o.playSegments, m = o.setSubframe, f = o.getDuration, b = o.destroy, C = o.animationContainerRef, _ = o.animationLoaded, T = o.animationItem;
    return __mf_24(function() {
      e.lottieRef && (e.lottieRef.current = {
        play: y,
        stop: E,
        pause: u,
        setSpeed: x,
        goToAndPlay: d,
        goToAndStop: g,
        setDirection: A,
        playSegments: c,
        setSubframe: m,
        getDuration: f,
        destroy: b,
        animationContainerRef: C,
        animationLoaded: _,
        animationItem: T
      });
    }, [
      (r = e.lottieRef) === null || r === void 0 ? void 0 : r.current
    ]), useLottieInteractivity({
      lottieObj: {
        View: p,
        play: y,
        stop: E,
        pause: u,
        setSpeed: x,
        goToAndStop: g,
        goToAndPlay: d,
        setDirection: A,
        playSegments: c,
        setSubframe: m,
        getDuration: f,
        destroy: b,
        animationContainerRef: C,
        animationLoaded: _,
        animationItem: T
      },
      actions: (i = n == null ? void 0 : n.actions) !== null && i !== void 0 ? i : [],
      mode: (s = n == null ? void 0 : n.mode) !== null && s !== void 0 ? s : "scroll"
    });
  };
  let v, fr, ip, op, w, h, nm, ddd, assets, layers, markers, animationDoor;
  v = "5.5.8";
  fr = 29.9700012207031;
  ip = 0;
  op = 47.0000019143492;
  w = 800;
  h = 800;
  nm = "Comp 1";
  ddd = 0;
  assets = [];
  layers = [
    {
      ddd: 0,
      ind: 1,
      ty: 4,
      nm: "Door Face 2",
      sr: 1,
      ks: {
        o: {
          a: 0,
          k: 100,
          ix: 11
        },
        r: {
          a: 0,
          k: 0,
          ix: 10
        },
        p: {
          a: 0,
          k: [
            237.844,
            395.617,
            0
          ],
          ix: 2
        },
        a: {
          a: 0,
          k: [
            -162.156,
            -4.383,
            0
          ],
          ix: 1
        },
        s: {
          a: 0,
          k: [
            100,
            100,
            100
          ],
          ix: 6
        }
      },
      ao: 0,
      shapes: [
        {
          ty: "gr",
          it: [
            {
              ty: "gr",
              it: [
                {
                  d: 1,
                  ty: "el",
                  s: {
                    a: 0,
                    k: [
                      31.414,
                      31.414
                    ],
                    ix: 2
                  },
                  p: {
                    a: 0,
                    k: [
                      0,
                      0
                    ],
                    ix: 3
                  },
                  nm: "Ellipse Path 1",
                  mn: "ADBE Vector Shape - Ellipse",
                  hd: false
                },
                {
                  ty: "st",
                  c: {
                    a: 0,
                    k: [
                      0.10196078431372549,
                      0.596078431372549,
                      0.8274509803921568,
                      1
                    ],
                    ix: 3
                  },
                  o: {
                    a: 0,
                    k: 100,
                    ix: 4
                  },
                  w: {
                    a: 0,
                    k: 6,
                    ix: 5
                  },
                  lc: 1,
                  lj: 1,
                  ml: 4,
                  bm: 0,
                  nm: "Stroke 1",
                  mn: "ADBE Vector Graphic - Stroke",
                  hd: false
                },
                {
                  ty: "tm",
                  s: {
                    a: 1,
                    k: [
                      {
                        i: {
                          x: [
                            0.833
                          ],
                          y: [
                            0.833
                          ]
                        },
                        o: {
                          x: [
                            0.167
                          ],
                          y: [
                            0.167
                          ]
                        },
                        t: 0,
                        s: [
                          100
                        ]
                      },
                      {
                        t: 10.0000004073083,
                        s: [
                          0
                        ]
                      }
                    ],
                    ix: 1
                  },
                  e: {
                    a: 0,
                    k: 100,
                    ix: 2
                  },
                  o: {
                    a: 0,
                    k: 0,
                    ix: 3
                  },
                  m: 1,
                  ix: 3,
                  nm: "Trim Paths 1",
                  mn: "ADBE Vector Filter - Trim",
                  hd: false
                },
                {
                  ty: "tr",
                  p: {
                    a: 0,
                    k: [
                      123.707,
                      -0.293
                    ],
                    ix: 2
                  },
                  a: {
                    a: 0,
                    k: [
                      0,
                      0
                    ],
                    ix: 1
                  },
                  s: {
                    a: 0,
                    k: [
                      100,
                      100
                    ],
                    ix: 3
                  },
                  r: {
                    a: 0,
                    k: 0,
                    ix: 6
                  },
                  o: {
                    a: 0,
                    k: 100,
                    ix: 7
                  },
                  sk: {
                    a: 0,
                    k: 0,
                    ix: 4
                  },
                  sa: {
                    a: 0,
                    k: 0,
                    ix: 5
                  },
                  nm: "Transform"
                }
              ],
              nm: "Ellipse 2",
              np: 3,
              cix: 2,
              bm: 0,
              ix: 1,
              mn: "ADBE Vector Group",
              hd: false
            },
            {
              ty: "gr",
              it: [
                {
                  d: 1,
                  ty: "el",
                  s: {
                    a: 0,
                    k: [
                      31.414,
                      31.414
                    ],
                    ix: 2
                  },
                  p: {
                    a: 0,
                    k: [
                      0,
                      0
                    ],
                    ix: 3
                  },
                  nm: "Ellipse Path 1",
                  mn: "ADBE Vector Shape - Ellipse",
                  hd: false
                },
                {
                  ty: "st",
                  c: {
                    a: 0,
                    k: [
                      0.753998160362,
                      0.753998160362,
                      0.753998160362,
                      1
                    ],
                    ix: 3
                  },
                  o: {
                    a: 0,
                    k: 100,
                    ix: 4
                  },
                  w: {
                    a: 0,
                    k: 6,
                    ix: 5
                  },
                  lc: 1,
                  lj: 1,
                  ml: 4,
                  bm: 0,
                  nm: "Stroke 1",
                  mn: "ADBE Vector Graphic - Stroke",
                  hd: false
                },
                {
                  ty: "fl",
                  c: {
                    a: 0,
                    k: [
                      0.866666674614,
                      0.866666674614,
                      0.866666674614,
                      1
                    ],
                    ix: 4
                  },
                  o: {
                    a: 0,
                    k: 100,
                    ix: 5
                  },
                  r: 1,
                  bm: 0,
                  nm: "Fill 1",
                  mn: "ADBE Vector Graphic - Fill",
                  hd: false
                },
                {
                  ty: "tr",
                  p: {
                    a: 0,
                    k: [
                      123.707,
                      -0.293
                    ],
                    ix: 2
                  },
                  a: {
                    a: 0,
                    k: [
                      0,
                      0
                    ],
                    ix: 1
                  },
                  s: {
                    a: 0,
                    k: [
                      100,
                      100
                    ],
                    ix: 3
                  },
                  r: {
                    a: 0,
                    k: 0,
                    ix: 6
                  },
                  o: {
                    a: 0,
                    k: 100,
                    ix: 7
                  },
                  sk: {
                    a: 0,
                    k: 0,
                    ix: 4
                  },
                  sa: {
                    a: 0,
                    k: 0,
                    ix: 5
                  },
                  nm: "Transform"
                }
              ],
              nm: "Ellipse 1",
              np: 3,
              cix: 2,
              bm: 0,
              ix: 2,
              mn: "ADBE Vector Group",
              hd: false
            },
            {
              ty: "tr",
              p: {
                a: 1,
                k: [
                  {
                    i: {
                      x: 0.833,
                      y: 0.833
                    },
                    o: {
                      x: 0.167,
                      y: 0.167
                    },
                    t: 10,
                    s: [
                      123.707,
                      -0.293
                    ],
                    to: [
                      -11.667,
                      0
                    ],
                    ti: [
                      11.667,
                      0
                    ]
                  },
                  {
                    t: 25.0000010182709,
                    s: [
                      53.707,
                      -0.293
                    ]
                  }
                ],
                ix: 2
              },
              a: {
                a: 0,
                k: [
                  123.707,
                  -0.293
                ],
                ix: 1
              },
              s: {
                a: 0,
                k: [
                  100,
                  100
                ],
                ix: 3
              },
              r: {
                a: 0,
                k: 0,
                ix: 6
              },
              o: {
                a: 0,
                k: 100,
                ix: 7
              },
              sk: {
                a: 0,
                k: 0,
                ix: 4
              },
              sa: {
                a: 0,
                k: 0,
                ix: 5
              },
              nm: "Transform"
            }
          ],
          nm: "Group 1",
          np: 2,
          cix: 2,
          bm: 0,
          ix: 1,
          mn: "ADBE Vector Group",
          hd: false
        },
        {
          ty: "gr",
          it: [
            {
              ind: 0,
              ty: "sh",
              ix: 1,
              ks: {
                a: 1,
                k: [
                  {
                    i: {
                      x: 0.833,
                      y: 0.833
                    },
                    o: {
                      x: 0.167,
                      y: 0.167
                    },
                    t: 10,
                    s: [
                      {
                        i: [
                          [
                            0,
                            -7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            -7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ]
                        ],
                        o: [
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            -7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            -7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            7.18,
                            0
                          ]
                        ],
                        v: [
                          [
                            159.367,
                            -271.094
                          ],
                          [
                            159.367,
                            271.094
                          ],
                          [
                            146.367,
                            284.094
                          ],
                          [
                            -146.367,
                            284.094
                          ],
                          [
                            -159.367,
                            271.094
                          ],
                          [
                            -159.367,
                            -271.094
                          ],
                          [
                            -146.367,
                            -284.094
                          ],
                          [
                            146.367,
                            -284.094
                          ]
                        ],
                        c: true
                      }
                    ]
                  },
                  {
                    t: 25.0000010182709,
                    s: [
                      {
                        i: [
                          [
                            0,
                            -7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            -7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ]
                        ],
                        o: [
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            -7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            -7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            7.18,
                            0
                          ]
                        ],
                        v: [
                          [
                            89.367,
                            -343.094
                          ],
                          [
                            87.367,
                            341.094
                          ],
                          [
                            74.367,
                            354.094
                          ],
                          [
                            -146.367,
                            284.094
                          ],
                          [
                            -159.367,
                            271.094
                          ],
                          [
                            -159.367,
                            -271.094
                          ],
                          [
                            -146.367,
                            -284.094
                          ],
                          [
                            76.367,
                            -356.094
                          ]
                        ],
                        c: true
                      }
                    ]
                  }
                ],
                ix: 2
              },
              nm: "Path 1",
              mn: "ADBE Vector Shape - Group",
              hd: false
            },
            {
              ty: "tm",
              s: {
                a: 1,
                k: [
                  {
                    i: {
                      x: [
                        0.833
                      ],
                      y: [
                        0.833
                      ]
                    },
                    o: {
                      x: [
                        0.167
                      ],
                      y: [
                        0.167
                      ]
                    },
                    t: 25,
                    s: [
                      100
                    ]
                  },
                  {
                    t: 35.0000014255792,
                    s: [
                      0
                    ]
                  }
                ],
                ix: 1
              },
              e: {
                a: 0,
                k: 100,
                ix: 2
              },
              o: {
                a: 0,
                k: 9,
                ix: 3
              },
              m: 1,
              ix: 2,
              nm: "Trim Paths 1",
              mn: "ADBE Vector Filter - Trim",
              hd: false
            },
            {
              ty: "st",
              c: {
                a: 0,
                k: [
                  0.10196078431372549,
                  0.596078431372549,
                  0.8274509803921568,
                  1
                ],
                ix: 3
              },
              o: {
                a: 0,
                k: 100,
                ix: 4
              },
              w: {
                a: 0,
                k: 11,
                ix: 5
              },
              lc: 2,
              lj: 2,
              bm: 0,
              nm: "Stroke 1",
              mn: "ADBE Vector Graphic - Stroke",
              hd: false
            },
            {
              ty: "fl",
              c: {
                a: 0,
                k: [
                  0.929411768913,
                  0.929411768913,
                  0.929411768913,
                  1
                ],
                ix: 4
              },
              o: {
                a: 0,
                k: 100,
                ix: 5
              },
              r: 1,
              bm: 0,
              nm: "Fill 1",
              mn: "ADBE Vector Graphic - Fill",
              hd: false
            },
            {
              ty: "tr",
              p: {
                a: 0,
                k: [
                  -2.789,
                  -4.383
                ],
                ix: 2
              },
              a: {
                a: 0,
                k: [
                  0,
                  0
                ],
                ix: 1
              },
              s: {
                a: 0,
                k: [
                  100,
                  100
                ],
                ix: 3
              },
              r: {
                a: 0,
                k: 0,
                ix: 6
              },
              o: {
                a: 0,
                k: 100,
                ix: 7
              },
              sk: {
                a: 0,
                k: 0,
                ix: 4
              },
              sa: {
                a: 0,
                k: 0,
                ix: 5
              },
              nm: "Transform"
            }
          ],
          nm: "Rectangle 2",
          np: 4,
          cix: 2,
          bm: 0,
          ix: 2,
          mn: "ADBE Vector Group",
          hd: false
        },
        {
          ty: "gr",
          it: [
            {
              ind: 0,
              ty: "sh",
              ix: 1,
              ks: {
                a: 1,
                k: [
                  {
                    i: {
                      x: 0.833,
                      y: 0.833
                    },
                    o: {
                      x: 0.167,
                      y: 0.167
                    },
                    t: 10,
                    s: [
                      {
                        i: [
                          [
                            0,
                            -7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            -7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ]
                        ],
                        o: [
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            -7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            -7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            7.18,
                            0
                          ]
                        ],
                        v: [
                          [
                            159.367,
                            -271.094
                          ],
                          [
                            159.367,
                            271.094
                          ],
                          [
                            146.367,
                            284.094
                          ],
                          [
                            -146.367,
                            284.094
                          ],
                          [
                            -159.367,
                            271.094
                          ],
                          [
                            -159.367,
                            -271.094
                          ],
                          [
                            -146.367,
                            -284.094
                          ],
                          [
                            146.367,
                            -284.094
                          ]
                        ],
                        c: true
                      }
                    ]
                  },
                  {
                    t: 25.0000010182709,
                    s: [
                      {
                        i: [
                          [
                            0,
                            -7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            -7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ]
                        ],
                        o: [
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            -7.18,
                            0
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            0,
                            -7.18
                          ],
                          [
                            0,
                            0
                          ],
                          [
                            7.18,
                            0
                          ]
                        ],
                        v: [
                          [
                            89.367,
                            -343.094
                          ],
                          [
                            87.367,
                            341.094
                          ],
                          [
                            74.367,
                            354.094
                          ],
                          [
                            -146.367,
                            284.094
                          ],
                          [
                            -159.367,
                            271.094
                          ],
                          [
                            -159.367,
                            -271.094
                          ],
                          [
                            -146.367,
                            -284.094
                          ],
                          [
                            76.367,
                            -356.094
                          ]
                        ],
                        c: true
                      }
                    ]
                  }
                ],
                ix: 2
              },
              nm: "Path 1",
              mn: "ADBE Vector Shape - Group",
              hd: false
            },
            {
              ty: "tm",
              s: {
                a: 0,
                k: 100,
                ix: 1
              },
              e: {
                a: 0,
                k: 0,
                ix: 2
              },
              o: {
                a: 0,
                k: 9,
                ix: 3
              },
              m: 1,
              ix: 2,
              nm: "Trim Paths 1",
              mn: "ADBE Vector Filter - Trim",
              hd: false
            },
            {
              ty: "st",
              c: {
                a: 0,
                k: [
                  0.85724568367,
                  0.85724568367,
                  0.85724568367,
                  1
                ],
                ix: 3
              },
              o: {
                a: 0,
                k: 100,
                ix: 4
              },
              w: {
                a: 0,
                k: 11,
                ix: 5
              },
              lc: 2,
              lj: 2,
              bm: 0,
              nm: "Stroke 1",
              mn: "ADBE Vector Graphic - Stroke",
              hd: false
            },
            {
              ty: "fl",
              c: {
                a: 0,
                k: [
                  0.929411768913,
                  0.929411768913,
                  0.929411768913,
                  1
                ],
                ix: 4
              },
              o: {
                a: 0,
                k: 100,
                ix: 5
              },
              r: 1,
              bm: 0,
              nm: "Fill 1",
              mn: "ADBE Vector Graphic - Fill",
              hd: false
            },
            {
              ty: "tr",
              p: {
                a: 0,
                k: [
                  -2.789,
                  -4.383
                ],
                ix: 2
              },
              a: {
                a: 0,
                k: [
                  0,
                  0
                ],
                ix: 1
              },
              s: {
                a: 0,
                k: [
                  100,
                  100
                ],
                ix: 3
              },
              r: {
                a: 0,
                k: 0,
                ix: 6
              },
              o: {
                a: 0,
                k: 100,
                ix: 7
              },
              sk: {
                a: 0,
                k: 0,
                ix: 4
              },
              sa: {
                a: 0,
                k: 0,
                ix: 5
              },
              nm: "Transform"
            }
          ],
          nm: "Rectangle 3",
          np: 4,
          cix: 2,
          bm: 0,
          ix: 3,
          mn: "ADBE Vector Group",
          hd: false
        }
      ],
      ip: 0,
      op: 180.00000733155,
      st: 0,
      bm: 0
    },
    {
      ddd: 0,
      ind: 2,
      ty: 4,
      nm: "Door Frame",
      sr: 1,
      ks: {
        o: {
          a: 0,
          k: 100,
          ix: 11
        },
        r: {
          a: 0,
          k: 0,
          ix: 10
        },
        p: {
          a: 0,
          k: [
            400,
            400,
            0
          ],
          ix: 2
        },
        a: {
          a: 0,
          k: [
            0,
            0,
            0
          ],
          ix: 1
        },
        s: {
          a: 0,
          k: [
            100,
            100,
            100
          ],
          ix: 6
        }
      },
      ao: 0,
      shapes: [
        {
          ty: "gr",
          it: [
            {
              ty: "rc",
              d: 1,
              s: {
                a: 0,
                k: [
                  318.734,
                  568.188
                ],
                ix: 2
              },
              p: {
                a: 0,
                k: [
                  0,
                  0
                ],
                ix: 3
              },
              r: {
                a: 0,
                k: 13,
                ix: 4
              },
              nm: "Rectangle Path 1",
              mn: "ADBE Vector Shape - Rect",
              hd: false
            },
            {
              ty: "tm",
              s: {
                a: 0,
                k: 0,
                ix: 1
              },
              e: {
                a: 1,
                k: [
                  {
                    i: {
                      x: [
                        0.833
                      ],
                      y: [
                        0.603
                      ]
                    },
                    o: {
                      x: [
                        0.167
                      ],
                      y: [
                        0.167
                      ]
                    },
                    t: 35,
                    s: [
                      0
                    ]
                  },
                  {
                    t: 45.0000018328876,
                    s: [
                      42
                    ]
                  }
                ],
                ix: 2
              },
              o: {
                a: 0,
                k: -16,
                ix: 3
              },
              m: 1,
              ix: 2,
              nm: "Trim Paths 1",
              mn: "ADBE Vector Filter - Trim",
              hd: false
            },
            {
              ty: "st",
              c: {
                a: 0,
                k: [
                  0.10196078431372549,
                  0.596078431372549,
                  0.8274509803921568,
                  1
                ],
                ix: 3
              },
              o: {
                a: 0,
                k: 100,
                ix: 4
              },
              w: {
                a: 0,
                k: 11,
                ix: 5
              },
              lc: 2,
              lj: 2,
              bm: 0,
              nm: "Stroke 1",
              mn: "ADBE Vector Graphic - Stroke",
              hd: false
            },
            {
              ty: "fl",
              c: {
                a: 0,
                k: [
                  0.929411768913,
                  0.929411768913,
                  0.929411768913,
                  1
                ],
                ix: 4
              },
              o: {
                a: 0,
                k: 100,
                ix: 5
              },
              r: 1,
              bm: 0,
              nm: "Fill 1",
              mn: "ADBE Vector Graphic - Fill",
              hd: false
            },
            {
              ty: "tr",
              p: {
                a: 0,
                k: [
                  -2.789,
                  -4.383
                ],
                ix: 2
              },
              a: {
                a: 0,
                k: [
                  0,
                  0
                ],
                ix: 1
              },
              s: {
                a: 0,
                k: [
                  100,
                  100
                ],
                ix: 3
              },
              r: {
                a: 0,
                k: 0,
                ix: 6
              },
              o: {
                a: 0,
                k: 100,
                ix: 7
              },
              sk: {
                a: 0,
                k: 0,
                ix: 4
              },
              sa: {
                a: 0,
                k: 0,
                ix: 5
              },
              nm: "Transform"
            }
          ],
          nm: "Rectangle 2",
          np: 4,
          cix: 2,
          bm: 0,
          ix: 1,
          mn: "ADBE Vector Group",
          hd: false
        },
        {
          ty: "gr",
          it: [
            {
              ty: "rc",
              d: 1,
              s: {
                a: 0,
                k: [
                  318.734,
                  568.188
                ],
                ix: 2
              },
              p: {
                a: 0,
                k: [
                  0,
                  0
                ],
                ix: 3
              },
              r: {
                a: 0,
                k: 13,
                ix: 4
              },
              nm: "Rectangle Path 1",
              mn: "ADBE Vector Shape - Rect",
              hd: false
            },
            {
              ty: "st",
              c: {
                a: 0,
                k: [
                  0.858823537827,
                  0.858823537827,
                  0.858823537827,
                  1
                ],
                ix: 3
              },
              o: {
                a: 0,
                k: 100,
                ix: 4
              },
              w: {
                a: 0,
                k: 11,
                ix: 5
              },
              lc: 2,
              lj: 2,
              bm: 0,
              nm: "Stroke 1",
              mn: "ADBE Vector Graphic - Stroke",
              hd: false
            },
            {
              ty: "fl",
              c: {
                a: 0,
                k: [
                  0.929411768913,
                  0.929411768913,
                  0.929411768913,
                  1
                ],
                ix: 4
              },
              o: {
                a: 0,
                k: 100,
                ix: 5
              },
              r: 1,
              bm: 0,
              nm: "Fill 1",
              mn: "ADBE Vector Graphic - Fill",
              hd: false
            },
            {
              ty: "tr",
              p: {
                a: 0,
                k: [
                  -2.789,
                  -4.383
                ],
                ix: 2
              },
              a: {
                a: 0,
                k: [
                  0,
                  0
                ],
                ix: 1
              },
              s: {
                a: 0,
                k: [
                  100,
                  100
                ],
                ix: 3
              },
              r: {
                a: 0,
                k: 0,
                ix: 6
              },
              o: {
                a: 0,
                k: 100,
                ix: 7
              },
              sk: {
                a: 0,
                k: 0,
                ix: 4
              },
              sa: {
                a: 0,
                k: 0,
                ix: 5
              },
              nm: "Transform"
            }
          ],
          nm: "Rectangle 1",
          np: 3,
          cix: 2,
          bm: 0,
          ix: 2,
          mn: "ADBE Vector Group",
          hd: false
        }
      ],
      ip: 0,
      op: 180.00000733155,
      st: 0,
      bm: 0
    }
  ];
  markers = [];
  animationDoor = {
    v,
    fr,
    ip,
    op,
    w,
    h,
    nm,
    ddd,
    assets,
    layers,
    markers
  };
  DoorAnimation = (t) => {
    const [e, r] = __mf_32(false), i = __mf_31(null);
    return __mf_24(() => {
      r(t.open), i.current && (t.open ? (i.current.setDirection(1), i.current.goToAndStop(0, true), i.current.playSegments([
        0,
        24
      ], true)) : (i.current.setDirection(-1), i.current.goToAndStop(24, true), i.current.playSegments([
        24,
        0
      ], true)));
    }, [
      t.open
    ]), jsxRuntimeExports.jsx(Lottie, {
      animationData: animationDoor,
      onClick: () => r(!e),
      lottieRef: i,
      autoPlay: false,
      loop: false,
      style: {
        height: t.size || 120
      }
    });
  };
  LockIcon = function(t) {
    return jsxRuntimeExports.jsxs("svg", {
      style: t.style,
      viewBox: "0 0 89 131",
      xmlns: "http://www.w3.org/2000/svg",
      children: [
        jsxRuntimeExports.jsx("path", {
          className: t.className,
          opacity: "0.7",
          fill: "currentColor",
          d: "m46.37384,13.39542c16.2147,0.19436 29.4056,13.28938 29.6233,29.59748l0.2069,15.4986c0.0331,2.4851 -1.9545,4.5265 -4.4396,4.5597l0,0c-2.485,0.0332 -4.5265,-1.9545 -4.5596,-4.4395l-0.2069,-15.4987c-0.1548,-11.5969 -9.6815,-20.8726 -21.2784,-20.71781l-2.9998,0.04004c-11.5969,0.15479 -20.8726,9.68147 -20.71781,21.27837l0.20687,15.4987c0.03317,2.485 -1.95448,4.5264 -4.43954,4.5596l0,0c-2.48506,0.0332 -4.52649,-1.9545 -4.55966,-4.4395l-0.20687,-15.4986c-0.21767,-16.3082 12.61901,-29.7506 28.82271,-30.37767l0.7742,-0.0201l2.9998,-0.04004l0.7744,-0.00057z"
        }),
        jsxRuntimeExports.jsx("path", {
          fill: "currentColor",
          d: "m79,60c5.5228,0 10,4.47715 10,10l0,45.2002c-0.0001,8.8365 -7.1635,16 -16,16l-57,0c-8.83649,0 -15.99989,-7.1635 -16,-16l0,-45.2002c0,-5.52285 4.47715,-10 10,-10l69,0zm-34.5,22.25c-4.9152,0.0002 -8.9004,3.9852 -8.9004,8.9004c0.0002,3.2933 1.7911,6.166 4.4502,7.7051l0,11.4297c0.0001,2.7031 2.1915,4.8941 4.8945,4.8945c2.7034,0 4.8955,-2.1912 4.8955,-4.8945l0,-12.0157c2.1613,-1.6237 3.5595,-4.2078 3.5596,-7.1191c0,-4.9152 -3.9842,-8.9002 -8.8994,-8.9004z"
        })
      ]
    });
  };
});
export {
  DoorAnimation as D,
  LockIcon as L,
  __tla
};
