import { j, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { a as O, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { _ as m, a as Q, b as Z, d as k, r as x, y as f, z as A, A as p, B as U, C as h, p as v, h as J, s as H, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { V as E, W as G, q as _, X as P, a as R, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CpkBFb5h.js";
import { _ as r, __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CxgaxSjv.js";
import { G as o } from "./Generic-DDdmRdK-.js";
import { b as a } from "./index-EX5SENus.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
let sM;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  const d = {
    motion: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0xMy41IDUuNWMxLjEgMCAyLS45IDItMnMtLjktMi0yLTJzLTIgLjktMiAycy45IDIgMiAyek05LjggOC45TDcgMjNoMi4xbDEuOC04bDIuMSAydjZoMnYtNy41bC0yLjEtMmwuNi0zQzE0LjggMTIgMTYuOCAxMyAxOSAxM3YtMmMtMS45IDAtMy41LTEtNC4zLTIuNGwtMS0xLjZjLS40LS42LTEtMS0xLjctMWMtLjMgMC0uNS4xLS44LjFMNiA4LjNWMTNoMlY5LjZsMS44LS43Ii8+PC9zdmc+",
    noMotion: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0xMiA3LjVjLjk3IDAgMS43NS0uNzggMS43NS0xLjc1UzEyLjk3IDQgMTIgNHMtMS43NS43OC0xLjc1IDEuNzVTMTEuMDMgNy41IDEyIDcuNXpNMTQgMjB2LTVoMXYtNC41YzAtMS4xLS45LTItMi0yaC0yYy0xLjEgMC0yIC45LTIgMlYxNWgxdjVoNHoiLz48L3N2Zz4=",
    fire: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0xMy41LjY3cy43NCAyLjY1Ljc0IDQuOGMwIDIuMDYtMS4zNSAzLjczLTMuNDEgMy43M2MtMi4wNyAwLTMuNjMtMS42Ny0zLjYzLTMuNzNsLjAzLS4zNkM1LjIxIDcuNTEgNCAxMC42MiA0IDE0YzAgNC40MiAzLjU4IDggOCA4czgtMy41OCA4LThDMjAgOC42MSAxNy40MSAzLjggMTMuNS42N3pNMTEuNzEgMTljLTEuNzggMC0zLjIyLTEuNC0zLjIyLTMuMTRjMC0xLjYyIDEuMDUtMi43NiAyLjgxLTMuMTJjMS43Ny0uMzYgMy42LTEuMjEgNC42Mi0yLjU4Yy4zOSAxLjI5LjU5IDIuNjUuNTkgNC4wNGMwIDIuNjUtMi4xNSA0LjgtNC44IDQuOHoiLz48L3N2Zz4=",
    flood: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0yMS45OCAxNEgyMmgtLjAyek01LjM1IDEzYzEuMTkgMCAxLjQyIDEgMy4zMyAxYzEuOTUgMCAyLjA5LTEgMy4zMy0xYzEuMTkgMCAxLjQyIDEgMy4zMyAxYzEuOTUgMCAyLjA5LTEgMy4zMy0xYzEuMTkgMCAxLjQuOTggMy4zMSAxdi0yYy0xLjE5IDAtMS40Mi0xLTMuMzMtMWMtMS45NSAwLTIuMDkgMS0zLjMzIDFjLTEuMTkgMC0xLjQyLTEtMy4zMy0xYy0xLjk1IDAtMi4wOSAxLTMuMzMgMWMtMS4xOSAwLTEuNDItMS0zLjMzLTFjLTEuOTUgMC0yLjA5IDEtMy4zMyAxdjJjMS45IDAgMi4xNy0xIDMuMzUtMXptMTMuMzIgMmMtMS45NSAwLTIuMDkgMS0zLjMzIDFjLTEuMTkgMC0xLjQyLTEtMy4zMy0xYy0xLjk1IDAtMi4xIDEtMy4zNCAxYy0xLjI0IDAtMS4zOC0xLTMuMzMtMWMtMS45NSAwLTIuMSAxLTMuMzQgMXYyYzEuOTUgMCAyLjExLTEgMy4zNC0xYzEuMjQgMCAxLjM4IDEgMy4zMyAxYzEuOTUgMCAyLjEtMSAzLjM0LTFjMS4xOSAwIDEuNDIgMSAzLjMzIDFjMS45NCAwIDIuMDktMSAzLjMzLTFjMS4xOSAwIDEuNDIgMSAzLjMzIDF2LTJjLTEuMjQgMC0xLjM4LTEtMy4zMy0xek01LjM1IDljMS4xOSAwIDEuNDIgMSAzLjMzIDFjMS45NSAwIDIuMDktMSAzLjMzLTFjMS4xOSAwIDEuNDIgMSAzLjMzIDFjMS45NSAwIDIuMDktMSAzLjMzLTFjMS4xOSAwIDEuNC45OCAzLjMxIDFWOGMtMS4xOSAwLTEuNDItMS0zLjMzLTFjLTEuOTUgMC0yLjA5IDEtMy4zMyAxYy0xLjE5IDAtMS40Mi0xLTMuMzMtMWMtMS45NSAwLTIuMDkgMS0zLjMzIDFjLTEuMTkgMC0xLjQyLTEtMy4zMy0xQzMuMzggNyAzLjI0IDggMiA4djJjMS45IDAgMi4xNy0xIDMuMzUtMXoiLz48L3N2Zz4=",
    windowOpened: "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8c3ZnIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMzYxcHgiCgkgaGVpZ2h0PSIzNjFweCIgdmlld0JveD0iMCAwIDM2MSAzNjEiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDM2MSAzNjE7Ij4KPGc+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2Ny44MjYsMjYzLjMwM2MwLDMuOTEtMy4xNTYsNy4wODItNy4wNSw3LjA4MgoJCWwtMTU3Ljg4NSwwLjAyMWMtMy44OTQsMC03LjA1LTMuMTcxLTcuMDUtNy4wODN2LTE1Ny41YzAtMy45MTEsMy4xNTYtNy4wODMsNy4wNS03LjA4M2wxNTcuODg1LTAuMDIxCgkJYzMuODk0LDAsNy4wNSwzLjE3Miw3LjA1LDcuMDgzVjI2My4zMDN6Ii8+Cgk8Zz4KCQk8Zz4KCQkJPHBhdGggc3R5bGU9ImZpbGw6Y3VycmVudENvbG9yOyIgZD0iTTIyOC41LDIwNS41ODRjMi4yMTMsMCw0LjQyNiwwLDYuNjM5LDBjMi43MjYsMCw1LTIuMjc0LDUtNXMtMi4yNzQtNS01LTUKCQkJCWMtMi4yMTMsMC00LjQyNiwwLTYuNjM5LDBjLTIuNzI2LDAtNSwyLjI3NC01LDVTMjI1Ljc3NCwyMDUuNTg0LDIyOC41LDIwNS41ODRMMjI4LjUsMjA1LjU4NHoiLz4KCQk8L2c+Cgk8L2c+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2Ny44MjYsMTAzLjIwOGMwLDIuNDg1LTIuNzExLDQuNS02LjA1Myw0LjUKCQlsLTE1OS44OCwwLjAyMWMtMy4zNDIsMC02LjA1Mi0yLjAxNS02LjA1Mi00LjV2LTljMC0yLjQ4NSwyLjcxLTQuNSw2LjA1Mi00LjVsMTU5Ljg4LTAuMDIxYzMuMzQyLDAsNi4wNTMsMi4wMTUsNi4wNTMsNC41VjEwMy4yMDgKCQl6Ii8+Cgk8cGF0aCBzdHlsZT0iZGlzcGxheTpub25lO2ZpbGw6bm9uZTtzdHJva2U6Y3VycmVudENvbG9yO3N0cm9rZS13aWR0aDoxMDtzdHJva2UtbWl0ZXJsaW1pdDoxMDsiIGQ9Ik0yNjQuNzMyLDI2NS4xNzgKCQljMC41ODQsMi44ODctMS42MjksNS4yMjgtNC45NDIsNS4yMjhIMTAyLjQ1N2MtMy4zMTMsMC02LjQ3NC0yLjM0MS03LjA1OC01LjIyOEw3NC4yNCwxMzAuNjMzCgkJYy0wLjU4NC0yLjg4NywxLjYyOC01LjIyOCw0Ljk0Mi01LjIyOGgxNTcuMzMzYzMuMzEzLDAsNi40NzQsMi4zNCw3LjA1OCw1LjIyOEwyNjQuNzMyLDI2NS4xNzh6Ii8+Cgk8Zz4KCQk8Zz4KCQkJPHBhdGggc3R5bGU9ImZpbGw6Y3VycmVudENvbG9yOyIgZD0iTTIzMi44MjYsMjgwLjkwNWMtMC4zMzksMy4zNTYtMTguODEzLTAuNzgyLTIwLjkxOS0xLjA2Yy0xNS4wMjQtMS45OC0zMC4wNDktMy45Ni00NS4wNzMtNS45NAoJCQkJYy0xNS4wMjUtMS45OC0zMC4wNDktMy45Ni00NS4wNzQtNS45NGMtNC44MzUtMC42MzgtOS42NzEtMS4yNzUtMTQuNTA3LTEuOTEyYy0xLjQ1Ni0wLjE5Mi02LjIwMS0wLjA1NS02LjQxMi0yLjE0NwoJCQkJYy0wLjYyMS02LjE1NywwLTEyLjY5OSwwLTE4Ljg3OGMwLTE0LjUsMC0yOSwwLTQzLjVjMC0yNy4zNTksMC01NC43MTgsMC04Mi4wNzZjMC0xLjcxLDAtMy40MiwwLTUuMTMKCQkJCWMwLTIuNTUxLDUuMTg0LTEuMDE1LDYuNDEyLTAuODUzYzExLjgxMywxLjU1NywyMy42MjUsMy4xMTQsMzUuNDM4LDQuNjdjMjcuOTA4LDMuNjc4LDU1LjgxNiw3LjM1Niw4My43MjMsMTEuMDM1CgkJCQljMS40NTcsMC4xOTIsNi4yMDEsMC4wNTUsNi40MTIsMi4xNDdjMC4xNjksMS42NzMsMCwzLjQ1MSwwLDUuMTNjMCwxMS4yMTcsMCwyMi40MzQsMCwzMy42NTFjMCwzMC42NDIsMCw2MS4yODMsMCw5MS45MjUKCQkJCUMyMzIuODI2LDI2OC4zMiwyMzIuODI2LDI3NC42MTIsMjMyLjgyNiwyODAuOTA1YzAsNi40NDgsMTAsNi40NDgsMTAsMGMwLTQ4LjE1MSwwLTk2LjMwMywwLTE0NC40NTRjMC0xLjcxLDAtMy40MiwwLTUuMTMKCQkJCWMwLTcuNjE5LTYuMTM3LTEwLjc5My0xMi42NzMtMTEuNjU1Yy05LjUxMS0xLjI1My0xOS4wMjEtMi41MDctMjguNTMxLTMuNzZjLTI5LjQ3LTMuODg0LTU4Ljk0LTcuNzY4LTg4LjQxMS0xMS42NTIKCQkJCWMtMy4yOTktMC40MzUtNi41OTgtMC44Ny05Ljg5Ny0xLjMwNGMtNi41NTUtMC44NjQtMTIuNDczLDQuOS0xMi40NzMsMTEuMzhjMCw2LjUyMSwwLDEzLjA0MiwwLDE5LjU2MwoJCQkJYzAsMzAuNzA1LDAsNjEuNDEsMCw5Mi4xMTVjMCwxMS4wNTIsMCwyMi4xMDQsMCwzMy4xNTRjMCwyLjAyMy0wLjA3MSw0LjA0LDAuMTMyLDYuMDUzYzAuNzE3LDcuMTExLDYuNjA2LDkuNTYzLDEyLjc1OSwxMC4zNzQKCQkJCWMyNS42MDksMy4zNzUsNTEuMjE4LDYuNzUsNzYuODI3LDEwLjEyNWMxMy4yOTksMS43NTMsMjYuNTk4LDMuNTA2LDM5Ljg5Niw1LjI1OWMzLjIzMiwwLjQyNiw2LjQ2NSwwLjg1Miw5LjY5NywxLjI3OAoJCQkJYzcuMDYzLDAuOTMxLDEyLjAxMS00Ljc3OCwxMi42NzMtMTEuMzQ2QzI0My40NzMsMjc0LjQ5LDIzMy40NjcsMjc0LjU1MywyMzIuODI2LDI4MC45MDV6Ii8+CgkJPC9nPgoJPC9nPgo8L2c+Cjwvc3ZnPgo=",
    windowClosed: "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8c3ZnIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMzYxcHgiCgkgaGVpZ2h0PSIzNjFweCIgdmlld0JveD0iMCAwIDM2MSAzNjEiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDM2MSAzNjE7Ij4KPGc+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2Ny44MjYsMjYzLjMwM2MwLDMuOTEtMy4xNTYsNy4wODItNy4wNSw3LjA4MgoJCWwtMTU3Ljg4NSwwLjAyMWMtMy44OTQsMC03LjA1LTMuMTcxLTcuMDUtNy4wODN2LTE1Ny41YzAtMy45MTEsMy4xNTYtNy4wODMsNy4wNS03LjA4M2wxNTcuODg1LTAuMDIxCgkJYzMuODk0LDAsNy4wNSwzLjE3Miw3LjA1LDcuMDgzVjI2My4zMDN6Ii8+Cgk8Zz4KCQk8Zz4KCQkJPHBhdGggc3R5bGU9ImZpbGw6Y3VycmVudENvbG9yOyIgZD0iTTI1OC41LDE4NS41ODRjMi4yMTMsMCw0LjQyNiwwLDYuNjM5LDBjMi43MjYsMCw1LTIuMjc0LDUtNXMtMi4yNzQtNS01LTUKCQkJCWMtMi4yMTMsMC00LjQyNiwwLTYuNjM5LDBjLTIuNzI2LDAtNSwyLjI3NC01LDVTMjU1Ljc3NCwxODUuNTg0LDI1OC41LDE4NS41ODRMMjU4LjUsMTg1LjU4NHoiLz4KCQk8L2c+Cgk8L2c+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2Ny44MjYsMTAzLjIwOGMwLDIuNDg1LTIuNzExLDQuNS02LjA1Myw0LjUKCQlsLTE1OS44OCwwLjAyMWMtMy4zNDIsMC02LjA1Mi0yLjAxNS02LjA1Mi00LjV2LTljMC0yLjQ4NSwyLjcxLTQuNSw2LjA1Mi00LjVsMTU5Ljg4LTAuMDIxYzMuMzQyLDAsNi4wNTMsMi4wMTUsNi4wNTMsNC41VjEwMy4yMDgKCQl6Ii8+Cgk8cGF0aCBzdHlsZT0iZGlzcGxheTpub25lO2ZpbGw6bm9uZTtzdHJva2U6Y3VycmVudENvbG9yO3N0cm9rZS13aWR0aDoxMDtzdHJva2UtbWl0ZXJsaW1pdDoxMDsiIGQ9Ik0yNjQuNzMyLDI2NS4xNzgKCQljMC41ODQsMi44ODctMS42MjksNS4yMjgtNC45NDIsNS4yMjhIMTAyLjQ1N2MtMy4zMTMsMC02LjQ3NC0yLjM0MS03LjA1OC01LjIyOEw3NC4yNCwxMzAuNjMzCgkJYy0wLjU4NC0yLjg4NywxLjYyOC01LjIyOCw0Ljk0Mi01LjIyOGgxNTcuMzMzYzMuMzEzLDAsNi40NzQsMi4zNCw3LjA1OCw1LjIyOEwyNjQuNzMyLDI2NS4xNzh6Ii8+CjwvZz4KPC9zdmc+Cg==",
    windowTilted: "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8c3ZnIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMzYxcHgiCgkgaGVpZ2h0PSIzNjFweCIgdmlld0JveD0iMCAwIDM2MSAzNjEiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDM2MSAzNjE7Ij4KPGc+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2Ny44MjYsMjYzLjMwM2MwLDMuOTEtMy4xNTYsNy4wODItNy4wNSw3LjA4MgoJCWwtMTU3Ljg4NSwwLjAyMWMtMy44OTQsMC03LjA1LTMuMTcxLTcuMDUtNy4wODN2LTE1Ny41YzAtMy45MTEsMy4xNTYtNy4wODMsNy4wNS03LjA4M2wxNTcuODg1LTAuMDIxCgkJYzMuODk0LDAsNy4wNSwzLjE3Miw3LjA1LDcuMDgzVjI2My4zMDN6Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2Ny44MjYsMTAzLjIwOGMwLDIuNDg1LTIuNzExLDQuNS02LjA1Myw0LjUKCQlsLTE1OS44OCwwLjAyMWMtMy4zNDIsMC02LjA1Mi0yLjAxNS02LjA1Mi00LjV2LTljMC0yLjQ4NSwyLjcxLTQuNSw2LjA1Mi00LjVsMTU5Ljg4LTAuMDIxYzMuMzQyLDAsNi4wNTMsMi4wMTUsNi4wNTMsNC41VjEwMy4yMDgKCQl6Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2NS43MzIsMjY1LjE3OAoJCWMwLjU4NCwyLjg4Ny0xLjYyOSw1LjIyOC00Ljk0Miw1LjIyOEgxMDMuNDU3Yy0zLjMxMywwLTYuNDc0LTIuMzQxLTcuMDU4LTUuMjI4TDc1LjI0LDEzMC42MzMKCQljLTAuNTg0LTIuODg3LDEuNjI4LTUuMjI4LDQuOTQyLTUuMjI4aDE1Ny4zMzNjMy4zMTMsMCw2LjQ3NCwyLjM0LDcuMDU4LDUuMjI4TDI2NS43MzIsMjY1LjE3OHoiLz4KCTxnPgoJCTxnPgoJCQk8cGF0aCBzdHlsZT0iZmlsbDpjdXJyZW50Q29sb3I7IiBkPSJNMjQ3LjE5NCwxOTkuNjY3YzIuMjEzLDAsNC40MjYsMCw2LjYzOSwwYzIuNzI2LDAsNS0yLjI3NCw1LTVzLTIuMjc0LTUtNS01CgkJCQljLTIuMjEzLDAtNC40MjYsMC02LjYzOSwwYy0yLjcyNiwwLTUsMi4yNzQtNSw1UzI0NC40NjksMTk5LjY2NywyNDcuMTk0LDE5OS42NjdMMjQ3LjE5NCwxOTkuNjY3eiIvPgoJCTwvZz4KCTwvZz4KPC9nPgo8L3N2Zz4K",
    doorOpened: "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8c3ZnIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMzYxcHgiCgkgaGVpZ2h0PSIzNjFweCIgdmlld0JveD0iMCAwIDM2MSAzNjEiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDM2MSAzNjE7Ij4KPGc+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTIzOC42MDcsMjY1LjQ2YzAsMy4xNDctMi41MDYsNi4xNC01LjU5OCw2LjY4NQoJCWwtODUuODEzLDE1LjEzMWMtMy4wOTEsMC41NDUtNS41OTYtMS41NjMtNS41OTYtNC43MVY5Ny43MTNjMC0zLjE0NiwyLjUwNS02LjEzOSw1LjU5Ni02LjY4NGw4NS44MTMtMTUuMTMxCgkJYzMuMDkyLTAuNTQ1LDUuNTk4LDEuNTY0LDUuNTk4LDQuNzFWMjY1LjQ2eiIvPgoJPGc+CgkJPGc+CgkJCTxwYXRoIHN0eWxlPSJmaWxsOmN1cnJlbnRDb2xvcjsiIGQ9Ik0xNDQuNzc3LDE5NC40NTNjMy4wOC0wLjU0Myw2LjE1OS0xLjA4Nyw5LjIzOC0xLjYzYzIuNjg3LTAuNDc0LDQuMTYzLTMuNzEyLDMuNDkyLTYuMTUKCQkJCWMtMC43NzMtMi44MTEtMy40NjktMy45NjYtNi4xNS0zLjQ5MmMtMy4wOCwwLjU0My02LjE1OSwxLjA4Ny05LjIzOCwxLjYzYy0yLjY4NywwLjQ3NC00LjE2MywzLjcxMi0zLjQ5Miw2LjE1CgkJCQlDMTM5LjM5OSwxOTMuNzcxLDE0Mi4wOTYsMTk0LjkyNywxNDQuNzc3LDE5NC40NTNMMTQ0Ljc3NywxOTQuNDUzeiIvPgoJCTwvZz4KCTwvZz4KCTxwYXRoIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOmN1cnJlbnRDb2xvcjtzdHJva2Utd2lkdGg6MTA7c3Ryb2tlLW1pdGVybGltaXQ6MTA7IiBkPSJNMjM4LjYwNywyNjUuNjk4CgkJYzAsMy4xNDctMi45MzYsNS42OTgtNi41NTcsNS42OThIMTMxLjUyOGMtMy42MjEsMC02LjU1Ni0yLjU1MS02LjU1Ni01LjY5OFY4MC44NDZjMC0zLjE0NiwyLjkzNi01LjY5Nyw2LjU1Ni01LjY5N2gxMDAuNTIzCgkJYzMuNjIxLDAsNi41NTcsMi41NTEsNi41NTcsNS42OTdWMjY1LjY5OHoiLz4KPC9nPgo8L3N2Zz4K",
    doorClosed: "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8c3ZnIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB3aWR0aD0iMzYxcHgiCgkgaGVpZ2h0PSIzNjFweCIgdmlld0JveD0iMCAwIDM2MSAzNjEiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDM2MSAzNjE7Ij4KPGc+Cgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTIzMi44MzYsMjgwLjkxMgoJCWMwLDMuNDA2LTIuNzEzLDYuMTY4LTYuMDU5LDYuMTY4aC05Mi44OWMtMy4zNDYsMC02LjA1OC0yLjc2Mi02LjA1OC02LjE2OFY4MC44MTZjMC0zLjQwNiwyLjcxMi02LjE2Nyw2LjA1OC02LjE2N2g5Mi44OQoJCWMzLjM0NiwwLDYuMDU5LDIuNzYxLDYuMDU5LDYuMTY3VjI4MC45MTJ6Ii8+Cgk8Zz4KCQk8Zz4KCQkJPHBhdGggc3R5bGU9ImZpbGw6Y3VycmVudENvbG9yOyIgZD0iTTEyOS44MywxODUuNjY3YzMuMzMzLDAsNi42NjcsMCwxMCwwYzYuNDQ5LDAsNi40NDktMTAsMC0xMGMtMy4zMzMsMC02LjY2NywwLTEwLDAKCQkJCUMxMjMuMzgxLDE3NS42NjcsMTIzLjM4MSwxODUuNjY3LDEyOS44MywxODUuNjY3TDEyOS44MywxODUuNjY3eiIvPgoJCTwvZz4KCTwvZz4KCTxwYXRoIHN0eWxlPSJmaWxsOm5vbmU7c3Ryb2tlOmN1cnJlbnRDb2xvcjtzdHJva2Utd2lkdGg6MTA7c3Ryb2tlLW1pdGVybGltaXQ6MTA7IiBkPSJNMjMxLjE2MywyODBjMC0zLjMxMy0yLjY4Ny02LTYtNkgxMzMuODMKCQljLTMuMzEzLDAtNiwyLjY4Ny02LDZ2MC42NjdjMCwzLjMxMywyLjY4Nyw2LDYsNmg5MS4zMzNjMy4zMTMsMCw2LTIuNjg3LDYtNlYyODB6Ii8+CjwvZz4KPC9zdmc+Cg==",
    socket: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwczEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyek05IDEyYy0uNTUgMC0xLS40NS0xLTFWOGMwLS41NS40NS0xIDEtMXMxIC40NSAxIDF2M2MwIC41NS0uNDUgMS0xIDF6bTUgNmgtNHYtMmMwLTEuMS45LTIgMi0yczIgLjkgMiAydjJ6bTItN2MwIC41NS0uNDUgMS0xIDFzLTEtLjQ1LTEtMVY4YzAtLjU1LjQ1LTEgMS0xczEgLjQ1IDEgMXYzeiIvPjwvc3ZnPg==",
    volume: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0zIDl2Nmg0bDUgNVY0TDcgOUgzem0xMy41IDNBNC41IDQuNSAwIDAgMCAxNCA3Ljk3djguMDVjMS40OC0uNzMgMi41LTIuMjUgMi41LTQuMDJ6TTE0IDMuMjN2Mi4wNmMyLjg5Ljg2IDUgMy41NCA1IDYuNzFzLTIuMTEgNS44NS01IDYuNzF2Mi4wNmM0LjAxLS45MSA3LTQuNDkgNy04Ljc3cy0yLjk5LTcuODYtNy04Ljc3eiIvPjwvc3ZnPg=="
  }, l = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTIgMjJDNi40OSAyMiAyIDE3LjUxIDIgMTJTNi40OSAyIDEyIDJzMTAgNC4wNCAxMCA5YzAgMy4zMS0yLjY5IDYtNiA2aC0xLjc3Yy0uMjggMC0uNS4yMi0uNS41IDAgLjEyLjA1LjIzLjEzLjMzLjQxLjQ3LjY0IDEuMDYuNjQgMS42NyAwIDEuMzgtMS4xMiAyLjUtMi41IDIuNXptMC0xOGMtNC40MSAwLTggMy41OS04IDhzMy41OSA4IDggOGMuMjggMCAuNS0uMjIuNS0uNSAwLS4xNi0uMDgtLjI4LS4xNC0uMzUtLjQxLS40Ni0uNjMtMS4wNS0uNjMtMS42NSAwLTEuMzggMS4xMi0yLjUgMi41LTIuNUgxNmMyLjIxIDAgNC0xLjc5IDQtNCAwLTMuODYtMy41OS03LTgtN3oiLz4NCiAgICA8Y2lyY2xlIGZpbGw9ImN1cnJlbnRDb2xvciIgY3g9IjYuNSIgY3k9IjExLjUiIHI9IjEuNSIvPg0KICAgIDxjaXJjbGUgZmlsbD0iY3VycmVudENvbG9yIiBjeD0iOS41IiBjeT0iNy41IiByPSIxLjUiLz4NCiAgICA8Y2lyY2xlIGZpbGw9ImN1cnJlbnRDb2xvciIgY3g9IjE0LjUiIGN5PSI3LjUiIHI9IjEuNSIvPg0KICAgIDxjaXJjbGUgZmlsbD0iY3VycmVudENvbG9yIiBjeD0iMTcuNSIgY3k9IjExLjUiIHI9IjEuNSIvPg0KPC9zdmc+", z = {
    [a.Types.blind]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMjAsMTlWM0g0djE2SDJ2MmgyMHYtMkgyMHogTTE2LDloMnYyaC0yVjl6IE0xNCwxMUg2VjloOFYxMXogTTE4LDdoLTJWNWgyVjd6IE0xNCw1djJINlY1SDE0eiBNNiwxOXYtNmg4djEuODIgYy0wLjQ1LDAuMzItMC43NSwwLjg0LTAuNzUsMS40M2MwLDAuOTcsMC43OCwxLjc1LDEuNzUsMS43NXMxLjc1LTAuNzgsMS43NS0xLjc1YzAtMC41OS0wLjMtMS4xMi0wLjc1LTEuNDNWMTNoMnY2SDZ6IiAvPg0KPC9zdmc+",
    [a.Types.dimmer]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNNywyMGg0YzAsMS4xLTAuOSwyLTIsMlM3LDIxLjEsNywyMHogTTUsMTloOHYtMkg1VjE5eiBNMTYuNSw5LjVjMCwzLjgyLTIuNjYsNS44Ni0zLjc3LDYuNUg1LjI3IEM0LjE2LDE1LjM2LDEuNSwxMy4zMiwxLjUsOS41QzEuNSw1LjM2LDQuODYsMiw5LDJTMTYuNSw1LjM2LDE2LjUsOS41eiBNMTQuNSw5LjVDMTQuNSw2LjQ3LDEyLjAzLDQsOSw0UzMuNSw2LjQ3LDMuNSw5LjUgYzAsMi40NywxLjQ5LDMuODksMi4zNSw0LjVoNi4zQzEzLjAxLDEzLjM5LDE0LjUsMTEuOTcsMTQuNSw5LjV6IE0yMS4zNyw3LjM3TDIwLDhsMS4zNywwLjYzTDIyLDEwbDAuNjMtMS4zN0wyNCw4bC0xLjM3LTAuNjNMMjIsNiBMMjEuMzcsNy4zN3ogTTE5LDZsMC45NC0yLjA2TDIyLDNsLTIuMDYtMC45NEwxOSwwbC0wLjk0LDIuMDZMMTYsM2wyLjA2LDAuOTRMMTksNnoiLz4NCjwvc3ZnPg==",
    [a.Types.door]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPGc+DQogICAgICAgIDxyZWN0IGZpbGw9Im5vbmUiIGhlaWdodD0iMjQiIHdpZHRoPSIyNCIvPg0KICAgICAgICA8cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0xOCw0djE2SDZWNEgxOCBNMTgsMkg2QzQuOSwyLDQsMi45LDQsNHYxOGgxNlY0QzIwLDIuOSwxOS4xLDIsMTgsMkwxOCwyeiBNMTUuNSwxMC41Yy0wLjgzLDAtMS41LDAuNjctMS41LDEuNSBzMC42NywxLjUsMS41LDEuNWMwLjgzLDAsMS41LTAuNjcsMS41LTEuNVMxNi4zMywxMC41LDE1LjUsMTAuNXoiLz4NCiAgICA8L2c+DQo8L3N2Zz4=",
    [a.Types.fireAlarm]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTYsNmwtMC40NCwwLjU1Yy0wLjQyLDAuNTItMC45OCwwLjc1LTEuNTQsMC43NUMxMyw3LjMsMTIsNi41MiwxMiw1LjNWMmMwLDAtOCw0LTgsMTFjMCw0LjQyLDMuNTgsOCw4LDhzOC0zLjU4LDgtOCBDMjAsMTAuMDQsMTguMzksNy4zOCwxNiw2eiBNMTIsMTljLTEuMSwwLTItMC44Ny0yLTEuOTRjMC0wLjUxLDAuMi0wLjk5LDAuNTgtMS4zNmwxLjQyLTEuNGwxLjQzLDEuNCBDMTMuOCwxNi4wNywxNCwxNi41NSwxNCwxNy4wNkMxNCwxOC4xMywxMy4xLDE5LDEyLDE5eiBNMTUuOTYsMTcuNUwxNS45NiwxNy41YzAuMDQtMC4zNiwwLjIyLTEuODktMS4xMy0zLjIybDAsMEwxMiwxMS41IGwtMi44MywyLjc4bDAsMGMtMS4zNiwxLjM0LTEuMTcsMi44OC0xLjEzLDMuMjJDNi43OSwxNi40LDYsMTQuNzksNiwxM2MwLTMuMTYsMi4xMy01LjY1LDQuMDMtNy4yNWMwLjIzLDEuOTksMS45MywzLjU1LDMuOTksMy41NSBjMC43OCwwLDEuNTQtMC4yMywyLjE4LTAuNjZDMTcuMzQsOS43OCwxOCwxMS4zNSwxOCwxM0MxOCwxNC43OSwxNy4yMSwxNi40LDE1Ljk2LDE3LjV6IiAvPg0KPC9zdmc+",
    [a.Types.floodAlarm]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMjEuOTgsMTRIMjJIMjEuOTh6IE01LjM1LDEzYzEuMTksMCwxLjQyLDEsMy4zMywxYzEuOTUsMCwyLjA5LTEsMy4zMy0xYzEuMTksMCwxLjQyLDEsMy4zMywxYzEuOTUsMCwyLjA5LTEsMy4zMy0xIGMxLjE5LDAsMS40LDAuOTgsMy4zMSwxdi0yYy0xLjE5LDAtMS40Mi0xLTMuMzMtMWMtMS45NSwwLTIuMDksMS0zLjMzLDFjLTEuMTksMC0xLjQyLTEtMy4zMy0xYy0xLjk1LDAtMi4wOSwxLTMuMzMsMSBjLTEuMTksMC0xLjQyLTEtMy4zMy0xQzMuMzgsMTEsMy4yNCwxMiwyLDEydjJDMy45LDE0LDQuMTcsMTMsNS4zNSwxM3ogTTE4LjY3LDE1Yy0xLjk1LDAtMi4wOSwxLTMuMzMsMWMtMS4xOSwwLTEuNDItMS0zLjMzLTEgYy0xLjk1LDAtMi4xLDEtMy4zNCwxYy0xLjI0LDAtMS4zOC0xLTMuMzMtMWMtMS45NSwwLTIuMSwxLTMuMzQsMXYyYzEuOTUsMCwyLjExLTEsMy4zNC0xYzEuMjQsMCwxLjM4LDEsMy4zMywxIGMxLjk1LDAsMi4xLTEsMy4zNC0xYzEuMTksMCwxLjQyLDEsMy4zMywxYzEuOTQsMCwyLjA5LTEsMy4zMy0xYzEuMTksMCwxLjQyLDEsMy4zMywxdi0yQzIwLjc2LDE2LDIwLjYyLDE1LDE4LjY3LDE1eiBNNS4zNSw5IGMxLjE5LDAsMS40MiwxLDMuMzMsMWMxLjk1LDAsMi4wOS0xLDMuMzMtMWMxLjE5LDAsMS40MiwxLDMuMzMsMWMxLjk1LDAsMi4wOS0xLDMuMzMtMWMxLjE5LDAsMS40LDAuOTgsMy4zMSwxVjggYy0xLjE5LDAtMS40Mi0xLTMuMzMtMWMtMS45NSwwLTIuMDksMS0zLjMzLDFjLTEuMTksMC0xLjQyLTEtMy4zMy0xQzEwLjA0LDcsOS45LDgsOC42Niw4QzcuNDcsOCw3LjI0LDcsNS4zMyw3IEMzLjM4LDcsMy4yNCw4LDIsOHYyQzMuOSwxMCw0LjE3LDksNS4zNSw5eiIgLz4NCjwvc3ZnPg==",
    [a.Types.humidity]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTIsMmMtNS4zMyw0LjU1LTgsOC40OC04LDExLjhjMCw0Ljk4LDMuOCw4LjIsOCw4LjJzOC0zLjIyLDgtOC4yQzIwLDEwLjQ4LDE3LjMzLDYuNTUsMTIsMnogTTEyLDIwYy0zLjM1LDAtNi0yLjU3LTYtNi4yIGMwLTIuMzQsMS45NS01LjQ0LDYtOS4xNGM0LjA1LDMuNyw2LDYuNzksNiw5LjE0QzE4LDE3LjQzLDE1LjM1LDIwLDEyLDIweiBNNy44MywxNGMwLjM3LDAsMC42NywwLjI2LDAuNzQsMC42MiBjMC40MSwyLjIyLDIuMjgsMi45OCwzLjY0LDIuODdjMC40My0wLjAyLDAuNzksMC4zMiwwLjc5LDAuNzVjMCwwLjQtMC4zMiwwLjczLTAuNzIsMC43NWMtMi4xMywwLjEzLTQuNjItMS4wOS01LjE5LTQuMTIgQzcuMDEsMTQuNDIsNy4zNywxNCw3LjgzLDE0eiIgLz4NCjwvc3ZnPg==",
    [a.Types.slider]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMyAxN3YyaDZ2LTJIM3pNMyA1djJoMTBWNUgzem0xMCAxNnYtMmg4di0yaC04di0yaC0ydjZoMnpNNyA5djJIM3YyaDR2MmgyVjlIN3ptMTQgNHYtMkgxMXYyaDEwem0tNi00aDJWN2g0VjVoLTRWM2gtMnY2eiIgLz4NCjwvc3ZnPg==",
    [a.Types.light]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNOSAyMWMwIC41NS40NSAxIDEgMWg0Yy41NSAwIDEtLjQ1IDEtMXYtMUg5djF6bTMtMTlDOC4xNCAyIDUgNS4xNCA1IDljMCAyLjM4IDEuMTkgNC40NyAzIDUuNzRWMTdjMCAuNTUuNDUgMSAxIDFoNmMuNTUgMCAxLS40NSAxLTF2LTIuMjZjMS44MS0xLjI3IDMtMy4zNiAzLTUuNzQgMC0zLjg2LTMuMTQtNy03LTd6bTIuODUgMTEuMWwtLjg1LjZWMTZoLTR2LTIuM2wtLjg1LS42QzcuOCAxMi4xNiA3IDEwLjYzIDcgOWMwLTIuNzYgMi4yNC01IDUtNXM1IDIuMjQgNSA1YzAgMS42My0uOCAzLjE2LTIuMTUgNC4xeiIgLz4NCjwvc3ZnPg==",
    [a.Types.lock]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTggOGgtMVY2YzAtMi43Ni0yLjI0LTUtNS01UzcgMy4yNCA3IDZ2Mkg2Yy0xLjEgMC0yIC45LTIgMnYxMGMwIDEuMS45IDIgMiAyaDEyYzEuMSAwIDItLjkgMi0yVjEwYzAtMS4xLS45LTItMi0yek05IDZjMC0xLjY2IDEuMzQtMyAzLTNzMyAxLjM0IDMgM3YySDlWNnptOSAxNEg2VjEwaDEydjEwem0tNi0zYzEuMSAwIDItLjkgMi0ycy0uOS0yLTItMi0yIC45LTIgMiAuOSAyIDIgMnoiIC8+DQo8L3N2Zz4=",
    [a.Types.media]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTIsMkM2LjQ4LDIsMiw2LjQ4LDIsMTJzNC40OCwxMCwxMCwxMHMxMC00LjQ4LDEwLTEwUzE3LjUyLDIsMTIsMnogTTEyLDIwYy00LjQxLDAtOC0zLjU5LTgtOHMzLjU5LTgsOC04czgsMy41OSw4LDggUzE2LjQxLDIwLDEyLDIweiBNOS41LDE2LjVsNy00LjVsLTctNC41VjE2LjV6IiAvPg0KPC9zdmc+",
    [a.Types.motion]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgLTk2MCA5NjAgOTYwIiB3aWR0aD0iNDgiPg0KICAgIDxwYXRoIGZpbGw9ImN1cnJlbnRDb2xvciIgZD0iTTUzNS00MHYtMjM5bC0xMDgtOTktNDIgMTg4LTI2NS01NSAxMS01NiAxOTkgNDAgNzMtMzY5LTEwMCA0N3YxMzRoLTYwdi0xNzVsMTY0LTY5cTMyLTE0IDQ1LjUtMTcuNVQ0ODAtNzE0cTIwIDAgMzUuNSA4LjVUNTQyLTY4MGw0MiA2N3EyNiA0MiA3MSA3M3QxMDUgMzF2NjBxLTY3IDAtMTE5LjUtMzFUNTQzLTU3M2wtMzkgMTU4IDkxIDg0djI5MWgtNjBabTUtNzE0cS0zMCAwLTUxLjUtMjEuNVQ0NjctODI3cTAtMzAgMjEuNS01MS41VDU0MC05MDBxMzAgMCA1MS41IDIxLjVUNjEzLTgyN3EwIDMwLTIxLjUgNTEuNVQ1NDAtNzU0WiIgLz4NCjwvc3ZnPg==",
    [a.Types.rgb]: l,
    [a.Types.rgbSingle]: l,
    [a.Types.rgbwSingle]: l,
    [a.Types.hue]: l,
    [a.Types.ct]: l,
    [a.Types.socket]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTYgOXY0LjY2bC0zLjUgMy41MVYxOWgtMXYtMS44M0w4IDEzLjY1VjloOG0wLTZoLTJ2NGgtNFYzSDh2NGgtLjAxQzYuOSA2Ljk5IDYgNy44OSA2IDguOTh2NS41Mkw5LjUgMTh2M2g1di0zbDMuNS0zLjUxVjljMC0xLjEtLjktMi0yLTJWM3oiIC8+DQo8L3N2Zz4=",
    [a.Types.temperature]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTUgMTNWNWMwLTEuNjYtMS4zNC0zLTMtM1M5IDMuMzQgOSA1djhjLTEuMjEuOTEtMiAyLjM3LTIgNCAwIDIuNzYgMi4yNCA1IDUgNXM1LTIuMjQgNS01YzAtMS42My0uNzktMy4wOS0yLTR6bS00LThjMC0uNTUuNDUtMSAxLTFzMSAuNDUgMSAxaC0xdjFoMXYyaC0xdjFoMXYyaC0yVjV6IiAvPg0KPC9zdmc+",
    [a.Types.thermostat]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NS42NTkgNDUuNjU5Ij4NCgk8cGF0aCBmaWxsPSJjdXJyZW50Q29sb3IiIGQ9Ik0zMC42MTksMjcuMzA5VjcuNzgxQzMwLjYxOSwzLjQ5LDI3LjEyNCwwLDIyLjgzMywwYy00LjI5LDAtNy43ODUsMy40OTEtNy43ODUsNy43OHYxOS41MjgNCgkJYy0xLjkwMiwxLjk0OS0zLjA1LDQuNjA0LTMuMDUsNy41MjJjMCw1Ljk3Miw0Ljg1NywxMC44MjgsMTAuODI5LDEwLjgyOGM1Ljk3LDAsMTAuODM0LTQuODU2LDEwLjgzNC0xMC44MjgNCgkJQzMzLjY2MSwzMS45MTIsMzIuNTIsMjkuMjU4LDMwLjYxOSwyNy4zMDl6IE0yMi44MjUsNDIuNjZjLTQuMzE2LDAtNy44MjQtMy41MTItNy44MjQtNy44MjhjMC0yLjUyNywxLjE3NC00Ljc3OSwzLjA3Ny02LjIxMQ0KCQlWMTYuMjM3aDMuMzcyYzAuNTUyLDAsMS0wLjQ3LDEtMS4wMjJjMC0wLjU1My0wLjQ0OC0xLjAyMS0xLTEuMDIxaC0zLjM3MnYtMi40NjZoMy4zNzJjMC41NTIsMCwxLTAuNDM0LDEtMC45ODYNCgkJYzAtMC41NTItMC40NDgtMC45ODYtMS0wLjk4NmgtMy4zNzJWNy43OGMwLTIuNjM2LDIuMTE5LTQuNzgsNC43NTQtNC43OGMyLjYzNywwLDQuNzU2LDIuMTQ0LDQuNzU2LDQuNzgxdjIwLjg3MQ0KCQljMS45MDMsMS40MzQsMy4wNDcsMy42NzEsMy4wNDcsNi4xOEMzMC42MzUsMzkuMTQ4LDI3LjE0MSw0Mi42NiwyMi44MjUsNDIuNjZ6IiAvPg0KCTxwYXRoIGZpbGw9ImN1cnJlbnRDb2xvciIgZD0iTTI1LjMzNCwzMC40NjNWMTguNjMyaC01LjAwMnYxMS44MzFjLTEuNTQ5LDAuODc0LTIuNTM3LDIuNTAyLTIuNTM3LDQuMzY5YzAsMi43ODgsMi4yNTEsNS4wNDYsNS4wMzgsNS4wNDYNCgkJYzIuNzg4LDAsNS4wMzQtMi4yNTgsNS4wMzQtNS4wNDZDMjcuODY3LDMyLjk2NiwyNi44ODUsMzEuMzM3LDI1LjMzNCwzMC40NjN6IiAvPg0KPC9zdmc+DQo=",
    [a.Types.volume]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTYgNy45N3Y4LjA1YzEuNDgtLjczIDIuNS0yLjI1IDIuNS00LjAyIDAtMS43Ny0xLjAyLTMuMjktMi41LTQuMDN6TTUgOXY2aDRsNSA1VjRMOSA5SDV6bTctLjE3djYuMzRMOS44MyAxM0g3di0yaDIuODNMMTIgOC44M3oiIC8+DQo8L3N2Zz4=",
    [a.Types.volumeGroup]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggZmlsbD0iY3VycmVudENvbG9yIiBkPSJNMTYgNy45N3Y4LjA1YzEuNDgtLjczIDIuNS0yLjI1IDIuNS00LjAyIDAtMS43Ny0xLjAyLTMuMjktMi41LTQuMDN6TTUgOXY2aDRsNSA1VjRMOSA5SDV6bTctLjE3djYuMzRMOS44MyAxM0g3di0yaDIuODNMMTIgOC44M3oiIC8+DQo8L3N2Zz4=",
    [a.Types.window]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzNjEgMzYxIj4NCgk8cGF0aCBzdHlsZT0iZmlsbDpub25lOyBzdHJva2U6IGN1cnJlbnRDb2xvcjtzdHJva2Utd2lkdGg6MTA7c3Ryb2tlLW1pdGVybGltaXQ6MTA7IiBkPSJNMjY3LjgyNiwyNjMuMzAzYzAsMy45MS0zLjE1Niw3LjA4Mi03LjA1LDcuMDgyDQoJCWwtMTU3Ljg4NSwwLjAyMWMtMy44OTQsMC03LjA1LTMuMTcxLTcuMDUtNy4wODN2LTE1Ny41YzAtMy45MTEsMy4xNTYtNy4wODMsNy4wNS03LjA4M2wxNTcuODg1LTAuMDIxDQoJCWMzLjg5NCwwLDcuMDUsMy4xNzIsNy4wNSw3LjA4M1YyNjMuMzAzeiIvPg0KCTxwYXRoIHN0eWxlPSJmaWxsOiBjdXJyZW50Q29sb3I7IiBkPSJNMjU4LjUsMTg1LjU4NGMyLjIxMywwLDQuNDI2LDAsNi42MzksMGMyLjcyNiwwLDUtMi4yNzQsNS01cy0yLjI3NC01LTUtNQ0KCQljLTIuMjEzLDAtNC40MjYsMC02LjYzOSwwYy0yLjcyNiwwLTUsMi4yNzQtNSw1UzI1NS43NzQsMTg1LjU4NCwyNTguNSwxODUuNTg0TDI1OC41LDE4NS41ODR6Ii8+DQoJPHBhdGggc3R5bGU9ImZpbGw6bm9uZTsgc3Ryb2tlOiBjdXJyZW50Q29sb3I7IHN0cm9rZS13aWR0aDogMTA7IHN0cm9rZS1taXRlcmxpbWl0OiAxMDsiIGQ9Ik0yNjcuODI2LDEwMy4yMDhjMCwyLjQ4NS0yLjcxMSw0LjUtNi4wNTMsNC41DQoJCWwtMTU5Ljg4LDAuMDIxYy0zLjM0MiwwLTYuMDUyLTIuMDE1LTYuMDUyLTQuNXYtOWMwLTIuNDg1LDIuNzEtNC41LDYuMDUyLTQuNWwxNTkuODgtMC4wMjFjMy4zNDIsMCw2LjA1MywyLjAxNSw2LjA1Myw0LjVWMTAzLjIwOA0KCQl6IiAvPg0KPC9zdmc+DQo=",
    [a.Types.windowTilt]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzNjEgMzYxIj4NCgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2Ny44MjYsMjYzLjMwM2MwLDMuOTEtMy4xNTYsNy4wODItNy4wNSw3LjA4Mg0KCQlsLTE1Ny44ODUsMC4wMjFjLTMuODk0LDAtNy4wNS0zLjE3MS03LjA1LTcuMDgzdi0xNTcuNWMwLTMuOTExLDMuMTU2LTcuMDgzLDcuMDUtNy4wODNsMTU3Ljg4NS0wLjAyMQ0KCQljMy44OTQsMCw3LjA1LDMuMTcyLDcuMDUsNy4wODNWMjYzLjMwM3oiLz4NCgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2Ny44MjYsMTAzLjIwOGMwLDIuNDg1LTIuNzExLDQuNS02LjA1Myw0LjUNCgkJbC0xNTkuODgsMC4wMjFjLTMuMzQyLDAtNi4wNTItMi4wMTUtNi4wNTItNC41di05YzAtMi40ODUsMi43MS00LjUsNi4wNTItNC41bDE1OS44OC0wLjAyMWMzLjM0MiwwLDYuMDUzLDIuMDE1LDYuMDUzLDQuNVYxMDMuMjA4DQoJCXoiLz4NCgk8cGF0aCBzdHlsZT0iZmlsbDpub25lO3N0cm9rZTpjdXJyZW50Q29sb3I7c3Ryb2tlLXdpZHRoOjEwO3N0cm9rZS1taXRlcmxpbWl0OjEwOyIgZD0iTTI2NS43MzIsMjY1LjE3OA0KCQljMC41ODQsMi44ODctMS42MjksNS4yMjgtNC45NDIsNS4yMjhIMTAzLjQ1N2MtMy4zMTMsMC02LjQ3NC0yLjM0MS03LjA1OC01LjIyOEw3NS4yNCwxMzAuNjMzDQoJCWMtMC41ODQtMi44ODcsMS42MjgtNS4yMjgsNC45NDItNS4yMjhoMTU3LjMzM2MzLjMxMywwLDYuNDc0LDIuMzQsNy4wNTgsNS4yMjhMMjY1LjczMiwyNjUuMTc4eiIvPg0KCTxwYXRoIHN0eWxlPSJmaWxsOmN1cnJlbnRDb2xvcjsiIGQ9Ik0yNDcuMTk0LDE5OS42NjdjMi4yMTMsMCw0LjQyNiwwLDYuNjM5LDBjMi43MjYsMCw1LTIuMjc0LDUtNXMtMi4yNzQtNS01LTUNCgkJYy0yLjIxMywwLTQuNDI2LDAtNi42MzksMGMtMi43MjYsMC01LDIuMjc0LTUsNVMyNDQuNDY5LDE5OS42NjcsMjQ3LjE5NCwxOTkuNjY3TDI0Ny4xOTQsMTk5LjY2N3oiLz4NCjwvc3ZnPg0K",
    [a.Types.vacuumCleaner]: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+DQogICAgPHBhdGggc3Ryb2tlPSJjdXJyZW50Q29sb3IiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBkPSJNMjEgMTJhOSA5IDAgMSAxIC0xOCAwYTkgOSAwIDAgMSAxOCAweiIgLz4NCiAgICA8cGF0aCBzdHJva2U9ImN1cnJlbnRDb2xvciIgZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIGQ9Ik0xNCA5YTIgMiAwIDEgMSAtNCAwYTIgMiAwIDAgMSA0IDB6IiAvPg0KICAgIDxwYXRoIHN0cm9rZT0iY3VycmVudENvbG9yIiBmaWxsPSJub25lIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgZD0iTTEyIDE2aC4wMSIgLz4NCjwvc3ZnPg==",
    [a.Types.unknown]: "",
    [a.Types.airCondition]: "",
    [a.Types.blindButtons]: "",
    [a.Types.button]: "",
    [a.Types.buttonSensor]: "",
    [a.Types.camera]: "",
    [a.Types.chart]: "",
    [a.Types.cie]: "",
    [a.Types.gate]: "",
    [a.Types.percentage]: "",
    [a.Types.illuminance]: "",
    [a.Types.image]: "",
    [a.Types.instance]: "",
    [a.Types.info]: "",
    [a.Types.location]: "",
    [a.Types.locationOne]: "",
    [a.Types.warning]: "",
    [a.Types.weatherCurrent]: "",
    [a.Types.weatherForecast]: ""
  }, B = [
    "title",
    "artist",
    "cover",
    "state",
    "duration",
    "elapsed",
    "prev",
    "next",
    "volume",
    "mute",
    "repeat",
    "shuffle"
  ];
  function g(t, I, M, w) {
    const D = t.states.find((y) => y.common.role === I || y.name === I);
    return D ? ((w == null ? void 0 : w.standardIcons) && z[t.deviceType] && (w.icon = z[t.deviceType]), t.common.icon && (!(w == null ? void 0 : w.standardIcons) || !(w == null ? void 0 : w.icon)) && (w ? (delete w.iconSmall, delete w.iconEnabledSmall, w.icon = t.common.icon) : w = {
      icon: t.common.icon
    }), (w == null ? void 0 : w.standardIcons) && delete w.standardIcons, {
      tpl: "tplNils2SimpleState",
      widgetSet: "vis-2-widgets-nils-fork",
      data: {
        name: o.getText(t.common.name),
        widgetTitle: o.t(t.deviceType).replace("vis_2_widgets_nils_", ""),
        wizardId: t._id,
        values_count: 0,
        g_common: true,
        oid: D == null ? void 0 : D._id,
        circleSize: 0,
        withNumber: false,
        withStates: false,
        ...w || {}
      },
      style: M
    }) : null;
  }
  function b(t, I) {
    const M = {
      left: "0px",
      top: "0px",
      width: "100%",
      position: "relative"
    };
    if (t.deviceType === "thermostat") {
      const w = t.states.find((i) => i.name === "SET"), D = t.states.find((i) => i.name === "ACTUAL"), y = t.states.find((i) => i.name === "MODE"), N = t.states.find((i) => i.name === "POWER"), c = t.states.find((i) => i.name === "PARTY"), u = t.states.find((i) => i.name === "BOOST");
      M.height = 160;
      const L = {
        tpl: "tplNils2Thermostat",
        style: M,
        widgetSet: "vis-2-widgets-nils-fork",
        data: {
          name: o.getText(t.common.name),
          widgetTitle: o.t(t.deviceType).replace("vis_2_widgets_nils_", ""),
          wizardId: t._id,
          step: w.common.step === 0.5 ? "0.5" : "1",
          g_common: true,
          count: 5,
          "oid-temp-set": (w == null ? void 0 : w._id) || "",
          "oid-temp-actual": (D == null ? void 0 : D._id) || "",
          "oid-power": (N == null ? void 0 : N._id) || "",
          "oid-mode": (y == null ? void 0 : y._id) || "",
          "oid-boost": (u == null ? void 0 : u._id) || "",
          "oid-party": (c == null ? void 0 : c._id) || ""
        }
      }, s = y == null ? void 0 : y.common;
      if (s == null ? void 0 : s.states) {
        if (Array.isArray(s.states)) {
          const i = {};
          s.states.forEach((T) => i[T] = T), s.states = i;
        }
        L.data.count = Object.keys(s.states).length, Object.keys(s.states).forEach((i, T) => {
          L.data[`g_modes-${T}`] = true, L.data[`title${T}`] = s.states[i].toString().toUpperCase();
        });
      }
      return L;
    }
    if (t.deviceType === "light") return g(t, "SET", M, {
      standardIcons: I
    });
    if (t.deviceType === "dimmer") return g(t, "SET", M, {
      standardIcons: I
    });
    if (t.deviceType === "blind") {
      const w = t.states.find((D) => D.name === "SET");
      return M.height = 120, {
        tpl: "tplNils2Blinds",
        widgetSet: "vis-2-widgets-nils-fork",
        style: M,
        data: {
          name: o.getText(t.common.name),
          widgetTitle: o.t(t.deviceType).replace("vis_2_widgets_nils_", ""),
          wizardId: t._id,
          sashCount: 1,
          g_common: true,
          ratio: 1,
          borderWidth: 3,
          oid: w == null ? void 0 : w._id
        }
      };
    }
    if (t.deviceType === "temperature") {
      const w = t.states.find((y) => y.name === "ACTUAL"), D = t.states.find((y) => y.name === "SECOND");
      return {
        tpl: "tplNils2Actual",
        style: M,
        widgetSet: "vis-2-widgets-nils-fork",
        data: {
          name: o.getText(t.common.name),
          widgetTitle: o.t(t.deviceType).replace("vis_2_widgets_nils_", ""),
          wizardId: t._id,
          timeInterval: 12,
          updateInterval: 60,
          "oid-main": w == null ? void 0 : w._id,
          "oid-secondary": D == null ? void 0 : D._id
        }
      };
    }
    if (t.deviceType === "motion") return g(t, "ACTUAL", M, {
      colorEnabled: "rgba(52,170,68,1)",
      iconSmall: d.noMotion,
      iconEnabledSmall: d.motion,
      standardIcons: I
    });
    if (t.deviceType === "fireAlarm") return g(t, "ACTUAL", M, {
      colorEnabled: "#F00",
      iconSmall: d.fire,
      standardIcons: I
    });
    if (t.deviceType === "floodAlarm") return g(t, "ACTUAL", M, {
      colorEnabled: "#00F",
      iconSmall: d.flood,
      standardIcons: I
    });
    if (t.deviceType === "door") return g(t, "ACTUAL", M, {
      colorEnabled: "#F00",
      iconSmall: d.doorClosed,
      iconEnabledSmall: d.doorOpened,
      standardIcons: I
    });
    if (t.deviceType === "levelSlider") return g(t, "SET", M, {
      standardIcons: I
    });
    if (t.deviceType === "lock") {
      const w = t.states.find((N) => N.name === "SET"), D = t.states.find((N) => N.name === "OPEN"), y = t.states.find((N) => N.name === "WORKING");
      return {
        tpl: "tplNils2Lock",
        widgetSet: "vis-2-widgets-nils-fork",
        style: M,
        data: {
          name: o.getText(t.common.name),
          widgetTitle: o.t(t.deviceType).replace("vis_2_widgets_nils_", ""),
          wizardId: t._id,
          "lock-oid": w == null ? void 0 : w._id,
          "doorOpen-oid": D == null ? void 0 : D._id,
          "lockWorking-oid": y == null ? void 0 : y._id
        }
      };
    }
    if (t.deviceType === "socket") return g(t, "SET", M, {
      iconSmall: d.socket,
      standardIcons: I
    });
    if (t.deviceType === "media") {
      const w = [
        ...B
      ], D = {
        tpl: "tplNils2Player",
        style: M,
        widgetSet: "vis-2-widgets-nils-fork",
        data: {
          name: o.getText(t.common.name),
          wizardId: t._id,
          noCard: false,
          widgetTitle: o.getText(t.roomName || "")
        }
      };
      return t.states.forEach((y) => {
        var _a, _b, _c;
        const N = (_c = (_b = (_a = y == null ? void 0 : y.common) == null ? void 0 : _a.role) == null ? void 0 : _b.match(/^(media\.mode|media|button|level)\.(.*)$/)) == null ? void 0 : _c[2];
        N && w.includes(N) && (w.splice(w.indexOf(N), 1), D.data[N] = y._id);
      }), D;
    }
    return t.deviceType === "volume" ? g(t, "SET", M, {
      iconSmall: d.volume,
      standardIcons: I
    }) : t.deviceType === "volumeGroup" ? g(t, "SET", M, {
      iconSmall: d.volume,
      standardIcons: I
    }) : t.deviceType === "weatherForecast" ? {
      tpl: "tplOpenWeatherMapWeather",
      style: M,
      widgetSet: "vis-2-widgets-nils-fork",
      data: {
        name: o.getText(t.common.name),
        widgetTitle: o.t(t.deviceType).replace("vis_2_widgets_nils_", ""),
        wizardId: t._id,
        type: "all",
        g_common: true,
        days: "6",
        instance: "0"
      }
    } : t.deviceType === "window" ? g(t, "ACTUAL", M, {
      colorEnabled: "#F00",
      iconSmall: d.windowClosed,
      iconEnabledSmall: d.windowOpened,
      standardIcons: I
    }) : t.deviceType === "windowTilt" ? g(t, "ACTUAL", M, {
      colorEnabled: "#F00",
      iconSmall: d.windowClosed,
      iconEnabledSmall: d.windowTilted,
      standardIcons: I
    }) : null;
  }
  const V = (t, I, M, w, D) => {
    const y = (N, c) => {
      D && (N === "value.humidity" ? c.icon = z.humidity : z[t.deviceType] && (c.icon = z[t.deviceType])), !c.icon && t.common.icon && (c ? (delete c.iconSmall, c.icon = t.common.icon) : c = {
        icon: t.common.icon
      });
      const u = t.states.find((L) => L.common.role === N);
      if (u) {
        for (let L = 1; L <= M.data.count; L++) if (!u || M.data[`oid${L}`] === u._id) return false;
        M.data.count++, M.data[`oid${M.data.count}`] = u._id, N === "value.temperature" && c.type === a.Types.info ? M.data[`title${M.data.count}`] = o.t("Temperature") : N === "value.humidity" && c.type === a.Types.info ? M.data[`title${M.data.count}`] = o.t("Humidity") : M.data[`title${M.data.count}`] = o.getText(t.common.name), c && Object.keys(c).filter((L) => c[L] !== void 0).forEach((L) => M.data[`${L}${M.data.count}`] = c[L]);
      }
      return false;
    };
    if (t.deviceType === "thermostat") {
      const N = t.states.find((T) => T.name === "SET"), c = t.states.find((T) => T.name === "ACTUAL") || void 0, u = t.states.find((T) => T.name === "HUMIDITY") || void 0, L = t.states.find((T) => T.name === "POWER") || void 0, s = t.states.find((T) => T.name === "PARTY") || void 0, i = t.states.find((T) => T.name === "BOOST") || void 0;
      for (let T = 1; T <= M.data.count; T++) if (!N || M.data[`oid${T}`] === N._id) return false;
      return M.data.count++, M.data[`type${M.data.count}`] = "thermostat", M.data[`oid${M.data.count}`] = N._id, c && (M.data[`actual${M.data.count}`] = c._id), u && (M.data[`humidity${M.data.count}`] = u._id), L && (M.data[`switch${M.data.count}`] = L._id), s && (M.data[`party${M.data.count}`] = s._id), i && (M.data[`boost${M.data.count}`] = i._id), M.data[`title${M.data.count}`] = o.getText(t.common.name), true;
    }
    if (t.deviceType === a.Types.rgb) {
      const N = t.states.find((e) => e.name === "RED") || void 0, c = t.states.find((e) => e.name === "GREEN") || void 0, u = t.states.find((e) => e.name === "BLUE") || void 0, L = t.states.find((e) => e.name === "ON" && e.common.write !== false) || void 0, s = t.states.find((e) => e.name === "WHITE") || void 0, i = t.states.find((e) => e.name === "SATURATION") || void 0, T = t.states.find((e) => e.name === "DIMMER" || e.name === "BRIGHTNESS") || void 0, C = t.states.find((e) => e.name === "TEMPERATURE") || void 0;
      for (let e = 1; e <= M.data.count; e++) if (!N || M.data[`red${e}`] === N._id) return false;
      return M.data.count++, M.data[`type${M.data.count}`] = "rgb", M.data[`rgbType${M.data.count}`] = s ? "r/g/b/w" : "r/g/b", M.data[`red${M.data.count}`] = N._id, M.data[`green${M.data.count}`] = c._id, M.data[`blue${M.data.count}`] = u._id, s && (M.data[`white${M.data.count}`] = s._id), i && (M.data[`saturation${M.data.count}`] = i._id), C && (M.data[`color_temperature${M.data.count}`] = C._id), L && (M.data[`switch${M.data.count}`] = L._id), T && (M.data[`brightness${M.data.count}`] = T._id), M.data[`title${M.data.count}`] = o.getText(t.common.name), true;
    }
    if (t.deviceType === "rgbSingle") {
      const N = t.states.find((i) => i.name === "RGB"), c = t.states.find((i) => i.name === "ON" && i.common.write !== false) || void 0, u = t.states.find((i) => i.name === "DIMMER" || i.name === "BRIGHTNESS") || void 0, L = t.states.find((i) => i.name === "TEMPERATURE") || void 0, s = t.states.find((i) => i.name === "SATURATION") || void 0;
      for (let i = 1; i <= M.data.count; i++) if (!N || M.data[`oid${i}`] === N._id) return false;
      return M.data.count++, M.data[`type${M.data.count}`] = "rgb", M.data[`rgbType${M.data.count}`] = "rgb", M.data[`oid${M.data.count}`] = N._id, s && (M.data[`saturation${M.data.count}`] = s._id), L && (M.data[`color_temperature${M.data.count}`] = L._id), c && (M.data[`switch${M.data.count}`] = c._id), u && (M.data[`brightness${M.data.count}`] = u._id), M.data[`title${M.data.count}`] = o.getText(t.common.name), true;
    }
    if (t.deviceType === "rgbwSingle") {
      const N = t.states.find((i) => i.name === "RGBW"), c = t.states.find((i) => i.name === "ON" && i.common.write !== false) || void 0, u = t.states.find((i) => i.name === "DIMMER" || i.name === "BRIGHTNESS") || void 0, L = t.states.find((i) => i.name === "TEMPERATURE") || void 0, s = t.states.find((i) => i.name === "SATURATION") || void 0;
      for (let i = 1; i <= M.data.count; i++) if (!N || M.data[`oid${i}`] === N._id) return false;
      return M.data.count++, M.data[`type${M.data.count}`] = "rgb", M.data[`rgbType${M.data.count}`] = "rgbw", M.data[`oid${M.data.count}`] = N._id, s && (M.data[`saturation${M.data.count}`] = s._id), L && (M.data[`color_temperature${M.data.count}`] = L._id), c && (M.data[`switch${M.data.count}`] = c._id), u && (M.data[`brightness${M.data.count}`] = u._id), M.data[`title${M.data.count}`] = o.getText(t.common.name), true;
    }
    if (t.deviceType === "hue") {
      const N = t.states.find((i) => i.name === "HUE"), c = t.states.find((i) => i.name === "ON" && i.common.write !== false) || void 0, u = t.states.find((i) => i.name === "DIMMER" || i.name === "BRIGHTNESS") || void 0, L = t.states.find((i) => i.name === "TEMPERATURE") || void 0, s = t.states.find((i) => i.name === "SATURATION") || void 0;
      for (let i = 1; i <= M.data.count; i++) if (!N || M.data[`hue${i}`] === N._id) return false;
      return M.data.count++, M.data[`type${M.data.count}`] = "rgb", M.data[`rgbType${M.data.count}`] = "hue/sat/lum", M.data[`hue${M.data.count}`] = N._id, s && (M.data[`saturation${M.data.count}`] = s._id), L && (M.data[`color_temperature${M.data.count}`] = L._id), c && (M.data[`switch${M.data.count}`] = c._id), u && (M.data[`brightness${M.data.count}`] = u._id), M.data[`title${M.data.count}`] = o.getText(t.common.name), true;
    }
    if (t.deviceType === "ct") {
      const N = t.states.find((s) => s.name === "TEMPERATURE"), c = t.states.find((s) => s.name === "ON" && s.common.write !== false) || void 0, u = t.states.find((s) => s.name === "DIMMER" || s.name === "BRIGHTNESS") || void 0, L = t.states.find((s) => s.name === "SATURATION") || void 0;
      for (let s = 1; s <= M.data.count; s++) if (!N || M.data[`color_temperature${s}`] === N._id) return false;
      return M.data.count++, M.data[`type${M.data.count}`] = "rgb", M.data[`rgbType${M.data.count}`] = "ct", M.data[`color_temperature${M.data.count}`] = N._id, L && (M.data[`saturation${M.data.count}`] = L._id), c && (M.data[`switch${M.data.count}`] = c._id), u && (M.data[`brightness${M.data.count}`] = u._id), M.data[`title${M.data.count}`] = o.getText(t.common.name), true;
    }
    if (t.deviceType === "lock") {
      const N = t.states.find((L) => L.name === "SET"), c = t.states.find((L) => L.name === "OPEN") || void 0, u = t.states.find((L) => L.name === "WORKING") || void 0;
      for (let L = 1; L <= M.data.count; L++) if (!N || M.data[`oid${L}`] === N._id) return false;
      return M.data.count++, M.data[`type${M.data.count}`] = "lock", M.data[`oid${M.data.count}`] = N._id, c && (M.data[`open${M.data.count}`] = c._id), u && (M.data[`working${M.data.count}`] = u._id), M.data[`title${M.data.count}`] = o.getText(t.common.name), true;
    }
    return t.deviceType, t.deviceType === "media" || t.deviceType === "weatherForecast" ? Object.values(w.widgets).find((N) => N.data.wizardId === t._id) ? false : (w.widgets[I] = b(t, D), true) : t.deviceType === "light" ? y("switch.light", {
      type: "switch"
    }) : t.deviceType === "dimmer" ? y("level.dimmer", {
      type: "slider"
    }) : t.deviceType === "blind" ? y("level.blind", {
      type: "blinds"
    }) : t.deviceType === "temperature" ? (y("value.temperature", {
      type: "info"
    }), y("value.humidity", {
      type: "info"
    })) : t.deviceType === "motion" ? y("sensor.motion", {
      type: "info",
      colorEnabled: "rgba(52,170,68,1)",
      infoInactiveIcon: d.noMotion,
      infoActiveIcon: d.motion
    }) : t.deviceType === "fireAlarm" ? y("sensor.alarm.fire", {
      type: "info",
      colorEnabled: "#F00",
      infoInactiveIcon: d.fire
    }) : t.deviceType === "floodAlarm" ? y("sensor.alarm.flood", {
      type: "info",
      colorEnabled: "#00F",
      infoInactiveIcon: d.flood
    }) : t.deviceType === "door" ? y("sensor.door", {
      type: "info",
      colorEnabled: "#F00",
      infoInactiveIcon: d.doorClosed,
      infoActiveIcon: d.doorOpened
    }) : t.deviceType === "levelSlider" ? y("level", {
      type: "slider"
    }) : t.deviceType === "lock" ? y("switch.lock", {
      type: "switch"
    }) : t.deviceType === "socket" ? y("switch", {
      type: "switch",
      iconSmall: d.socket
    }) : t.deviceType === "volume" ? y("level.volume", {
      type: "slider",
      iconSmall: d.volume
    }) : t.deviceType === "volumeGroup" ? y("level.volume.group", {
      type: "slider",
      iconSmall: d.volume
    }) : t.deviceType === "window" ? y("sensor.window", {
      type: "info",
      infoInactiveIcon: d.windowClosed,
      infoActiveIcon: d.windowOpened,
      infoActiveColor: "#F00"
    }) : t.deviceType === "windowTilt" ? y("value.window", {
      type: "info",
      infoInactiveIcon: d.windowClosed,
      infoActiveIcon: d.windowTilted,
      infoActiveColor: "#F00"
    }) : (M.data.count++, M.data[`oid${M.data.count}`] = t._id, M.data[`type${M.data.count}`] = "auto", false);
  };
  class X extends O.Component {
    constructor(I) {
      super(I), this.state = {
        rooms: null,
        devicesChecked: {},
        roomsChecked: {},
        onePage: window.localStorage.getItem("AppWizard.onePage") !== "false",
        standardIcons: window.localStorage.getItem("AppWizard.standardIcons") === "true"
      };
    }
    componentDidMount() {
      (async () => {
        var _a;
        let I = await ((_a = this.props.helpers) == null ? void 0 : _a.detectDevices(this.props.socket)) || [];
        I.forEach((D) => {
          D.devices = D.devices.filter((y) => y.common.role !== "button");
        }), I = I.filter((D) => D.devices.length), I.forEach((D) => {
          D.devices.forEach((y) => {
            y.common.name = (o.getText(y.common.name) || "").replace(/\./g, " ").trim(), y.roomName && (y.common.name = y.common.name.replace(o.getText(y.roomName), "").trim());
          });
        });
        const M = {}, w = {};
        I.forEach((D) => {
          w[D._id] = true, D.devices.forEach((y) => {
            M[y._id] = true;
          });
        }), this.setState({
          rooms: I,
          devicesChecked: M,
          roomsChecked: w
        });
      })();
    }
    handleSubmit = () => {
      var _a;
      const { rooms: I, roomsChecked: M, devicesChecked: w, onePage: D, standardIcons: y } = this.state, N = JSON.parse(JSON.stringify(this.props.project));
      let c = ((_a = this.props.helpers) == null ? void 0 : _a.getNewWidgetIdNumber(false, N)) || 1e3, u = false, L = "";
      I.forEach((s) => {
        var _a2;
        if (!M[s._id] || !s.devices.length || !s.devices.find((C) => w[C._id])) return;
        let i = o.getText(s.common.name), T;
        if (D) {
          if (T = Object.values(N[this.props.selectedView].widgets).find((e) => e.data.wizardId === s._id), T || (T = {
            tpl: "tplNils2Switches",
            widgetSet: "vis-2-widgets-nils-fork",
            data: {
              name: o.getText(s.common.name),
              widgetTitle: o.getText(s.common.name),
              count: 0,
              g_common: true,
              type: "lines",
              allSwitch: false,
              wizardId: s._id
            },
            style: {
              left: "0px",
              top: "0px",
              width: "100%",
              position: "relative"
            }
          }), i = this.props.selectedView, s.devices.forEach((e) => {
            if (!w[e._id]) return;
            const S = `w${c.toString().padStart(6, "0")}`;
            u = true, V(e, S, T, N[i], y) && c++;
          }), !Object.keys(N[this.props.selectedView].widgets).find((e) => T === N[this.props.selectedView].widgets[e])) {
            const e = `w${c.toString().padStart(6, "0")}`;
            N[this.props.selectedView].widgets[e] = T, c++;
          }
        } else {
          const C = Object.keys(N).find((e) => {
            var _a3;
            return ((_a3 = N[e].settings) == null ? void 0 : _a3.wizardId) === s._id;
          });
          C ? i = C : N[i] ? N[i].settings.wizardId = s._id : (N[i] = {
            name: o.getText(s.common.name),
            parentId: void 0,
            settings: {
              style: {},
              wizardId: s._id
            },
            rerender: false,
            filterList: [],
            widgets: {},
            activeWidgets: []
          }, ((_a2 = s.common.icon) == null ? void 0 : _a2.startsWith("data:image")) && (N[i].settings.navigationIcon = s.common.icon), s.common.color && (N[i].settings.navigationBackground = s.common.color), N.___settings.openedViews && !N.___settings.openedViews.includes(i) && N.___settings.openedViews.push(i)), L = L || i, s.devices.forEach((e) => {
            if (!w[e._id]) return;
            if (!Object.keys(N[i].widgets).find((n) => {
              var _a3, _b;
              return ((_b = (_a3 = N[i].widgets) == null ? void 0 : _a3[n].data) == null ? void 0 : _b.wizardId) === e._id;
            })) {
              u = true;
              const n = b(e, y);
              if (n) {
                const Y = `w${c.toString().padStart(6, "0")}`;
                N[i].widgets[Y] = n, c++;
              } else console.warn(`Cannot find widget for ${e._id} (${JSON.stringify(e.common.name)})`);
            }
          });
        }
      }), u && this.props.changeProject(N), u && L && setTimeout(() => {
        var _a2, _b;
        (_b = (_a2 = this.props).changeView) == null ? void 0 : _b.call(_a2, L);
      }, 100), this.props.onClose();
    };
    render() {
      const { rooms: I, roomsChecked: M, devicesChecked: w, onePage: D, standardIcons: y } = this.state, N = I == null ? void 0 : I.every((L) => M[L._id]), c = I == null ? void 0 : I.some((L) => M[L._id]), u = (I == null ? void 0 : I.map((L) => L.devices.reduce((s, i) => s + (w[i._id] ? 1 : 0), 0))) || [];
      return j.jsxs(Q, {
        open: true,
        onClose: this.props.onClose,
        fullWidth: true,
        sx: {
          "& .MuiDialog-paper": {
            maxHeight: "calc(100% - 80px)",
            height: "calc(100% - 80px)"
          }
        },
        children: [
          j.jsx(Z, {
            children: o.t("Wizard")
          }),
          j.jsx(k, {
            style: {
              height: "100%",
              overflowY: "hidden"
            },
            children: I ? j.jsxs("div", {
              style: {
                height: "100%",
                overflowY: "hidden"
              },
              children: [
                j.jsxs("div", {
                  children: [
                    o.t("Multiple views"),
                    j.jsx(x, {
                      checked: D,
                      onChange: (L) => {
                        window.localStorage.setItem("AppWizard.onePage", L.target.checked ? "true" : "false"), this.setState({
                          onePage: L.target.checked
                        });
                      }
                    }),
                    o.t("One view")
                  ]
                }),
                j.jsxs("div", {
                  children: [
                    o.t("Custom icons"),
                    j.jsx("img", {
                      src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAyCAMAAAAUcxnlAAADAFBMVEUCAgKGhoY/Pz/X19cfHx9jY2OoqKju7u4QEBDh4eF0dHQxMTG/v78ICAienp5JSUnf399ra2u3t7cXFxfp6el8fHw5OTkDAwNBQUHZ2dkpKSmurq7+/v4SEhLn5+d6eno3NzfBwcEKCgqmpqZycnJycnIeHh4AAACurq4cHBxOTk5FRUUAAAANDQ0cHBwAAABJSUlISEgUFBQAAAAyMjKCgoJGRkYhISGWlpY4ODhGRkYhISHV1dXCwsKpqamYmJhHR0eFhYVMTEwhISFCQkJeXl5UVFQhISElJSUqKioYGBgAAAAeHh4iIiIwMDACAgJMTExwcHB/f39FRUWDg4NTU1MeHh4AAABkZGRycnJoaGhFRUXj4+PKysqpqamYmJgdHR1fX19vb28AAAArKyvOzs5YWFhFRUUWFhZTU1Ofn59HR0cICAgNDQ0EBAQAAAC1tbWYmJhTU1NFRUUUFBQAAAAAAAAAAABYWFhwcHAlJSULCwsuLi6EhIQ/Pz8hISEnJydmZmYaGhoAAAAuLi7IyMg1NTUhISEiIiIoKChAQEAhISGVlZXLy8tXV1dJSUk4ODhUVFRRUVEhISG9vb3b29syMjIhISEaGhqlpaVgYGBFRUVbW1tRUVFjY2NUVFSnp6e/v7+0tLSnp6c7Ozuenp53d3djY2O8vLzAwMCGhoZ7e3sICAgXFxeFhYULCwsQEBAWFhZ3d3cAAAAAAAArKytBQUELCwsLCws1NTUqKiohISFra2uAgIBTU1MhISEAAAAfHx+YmJgiIiIaGhq4uLgPDw8AAAAlJSUlJSVcXFwlJSUkJCQuLi5lZWUXFxc2NjY/Pz8rKysAAAA8PDwzMzM4ODg5OTlcXFxaWlo7Ozs/Pz9ISEhNTU1LS0tFRUU4ODhDQ0NNTU1GRkZ9fX2ZmZl7e3t/f38+Pj5fX19AQEA5OTlJSUlCQkJAQEA6OjpOTk5HR0c1NTUlJSUpKSk7OzsnJyckJCQ7OzsxMTEfHx8kJCRKSkpJSUkLCwtFRUVwJku+AAAACXBIWXMAAFxGAABcRgEUlENBAAAAvklEQVR42u2Vyw6CMBBFrxDDiBmVRylCA4j+/zfKqqBOKS5M1HCn6erkJF3MLcxbwc/jpzjxjFKpxZss9OWCwOIa/qSFxVHUh9lcFaJuxGPfE3fI9yN+8+Hhgz3x4ecXO4jFECLJTi7zMZLsbIi0Zg2e3j1MkEt2LftLUzaynSW8c9od+Gpf7audXcvnslcEzU+Hh9UW7e7iEO1MQ1MI00Psmc91ZLugsCf2ahO3c6O2yGqLZ0s+mz/5tb8EvwNPZ9YpjSwIDgAAAABJRU5ErkJggg==",
                      style: {
                        width: 24,
                        height: 24,
                        marginLeft: 8
                      },
                      alt: "icon"
                    }),
                    j.jsx(x, {
                      checked: y,
                      onChange: (L) => {
                        window.localStorage.setItem("AppWizard.standardIcons", L.target.checked ? "true" : "false"), this.setState({
                          standardIcons: L.target.checked
                        });
                      }
                    }),
                    j.jsx("svg", {
                      xmlns: "http://www.w3.org/2000/svg",
                      height: "24px",
                      viewBox: "0 0 24 24",
                      width: "24px",
                      style: {
                        marginRight: 8
                      },
                      children: j.jsx("path", {
                        fill: "currentColor",
                        d: "M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7zm2.85 11.1l-.85.6V16h-4v-2.3l-.85-.6C7.8 12.16 7 10.63 7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 1.63-.8 3.16-2.15 4.1z"
                      })
                    }),
                    o.t("Standard icons")
                  ]
                }),
                j.jsx("div", {
                  style: {
                    marginLeft: 26
                  },
                  children: j.jsx(f, {
                    control: j.jsx(A, {
                      indeterminate: !N && c,
                      checked: N,
                      onChange: () => {
                        const L = JSON.parse(JSON.stringify(M));
                        I.forEach((s) => L[s._id] = !N), this.setState({
                          roomsChecked: L
                        });
                      }
                    }),
                    label: N ? o.t("Unselect all rooms") : o.t("Select all rooms")
                  })
                }),
                j.jsxs("div", {
                  style: {
                    height: "calc(100% - 120px)",
                    overflowY: "auto"
                  },
                  children: [
                    I.length ? null : j.jsx("div", {
                      children: o.t("Nothing detected")
                    }),
                    I.map((L, s) => {
                      var _a;
                      return j.jsx("div", {
                        children: j.jsxs(p, {
                          children: [
                            j.jsx(U, {
                              expandIcon: j.jsx(G, {}),
                              children: j.jsxs("div", {
                                style: {
                                  display: "flex",
                                  alignItems: "center",
                                  width: "100%"
                                },
                                children: [
                                  j.jsx(A, {
                                    checked: M[L._id],
                                    onChange: (i) => {
                                      const T = JSON.parse(JSON.stringify(M));
                                      T[L._id] = i.target.checked, this.setState({
                                        roomsChecked: T
                                      });
                                    },
                                    onClick: (i) => i.stopPropagation()
                                  }),
                                  L.common.icon ? L.common.icon === "?" ? j.jsx(E, {
                                    style: {
                                      width: 24,
                                      height: 24,
                                      marginRight: 8
                                    }
                                  }) : j.jsx(r, {
                                    src: L.common.icon,
                                    style: {
                                      width: 24,
                                      height: 24,
                                      marginRight: 8
                                    },
                                    alt: ""
                                  }) : null,
                                  j.jsx("div", {
                                    style: {
                                      flexGrow: 1
                                    },
                                    children: o.getText(L.common.name)
                                  }),
                                  j.jsx(A, {
                                    title: o.t("Select/Unselect all devices in room"),
                                    indeterminate: u[s] !== L.devices.length && !!u[s],
                                    checked: u[s] === L.devices.length,
                                    disabled: !M[L._id],
                                    onClick: (i) => {
                                      i.stopPropagation(), i.preventDefault();
                                      const T = JSON.parse(JSON.stringify(w));
                                      u[s] === L.devices.length ? L.devices.forEach((C) => {
                                        T[C._id] = false;
                                      }) : L.devices.forEach((C) => {
                                        T[C._id] = true;
                                      }), this.setState({
                                        devicesChecked: T
                                      });
                                    }
                                  }),
                                  j.jsx("div", {
                                    style: {
                                      fontSize: 12,
                                      opacity: 0.7,
                                      marginLeft: 20,
                                      minWidth: 200
                                    },
                                    children: o.t("%s of %s devices selected", ((_a = u[s]) == null ? void 0 : _a.toString()) || "0", L.devices.length.toString())
                                  })
                                ]
                              })
                            }),
                            j.jsx(h, {
                              style: {
                                backgroundColor: this.props.themeType === "dark" ? "#111" : "#eee"
                              },
                              children: L.devices.map((i, T) => {
                                var _a2;
                                return j.jsx("div", {
                                  style: {
                                    backgroundColor: "transparent"
                                  },
                                  children: j.jsxs("div", {
                                    style: {
                                      display: "flex",
                                      alignItems: "center",
                                      marginLeft: 20,
                                      marginBottom: 20,
                                      opacity: M[L._id] ? 1 : 0.5
                                    },
                                    children: [
                                      j.jsx(A, {
                                        checked: w[i._id],
                                        onChange: (C) => {
                                          const e = JSON.parse(JSON.stringify(w));
                                          e[i._id] = C.target.checked, this.setState({
                                            devicesChecked: e
                                          });
                                        },
                                        onClick: (C) => C.stopPropagation()
                                      }),
                                      j.jsx("span", {
                                        style: {
                                          marginRight: 8
                                        },
                                        children: !y && i.common.icon ? i.common.icon === "?" ? j.jsx(E, {
                                          style: {
                                            width: 24,
                                            height: 24
                                          }
                                        }) : j.jsx(r, {
                                          src: i.common.icon,
                                          style: {
                                            width: 24,
                                            height: 24
                                          },
                                          alt: ""
                                        }) : ((_a2 = this.props.helpers) == null ? void 0 : _a2.deviceIcons[i.deviceType]) || j.jsx(_, {})
                                      }),
                                      j.jsx(v, {
                                        variant: "standard",
                                        fullWidth: true,
                                        label: i._id,
                                        helperText: j.jsx("span", {
                                          style: {
                                            fontStyle: "italic"
                                          },
                                          children: `${o.t("Device type")}: ${o.t(i.deviceType).replace("vis_2_widgets_nils_", "")}`
                                        }),
                                        value: i.common.name,
                                        onChange: (C) => {
                                          const e = JSON.parse(JSON.stringify(I));
                                          e[s].devices[T].common.name = C.target.value, this.setState({
                                            rooms: e
                                          });
                                        }
                                      })
                                    ]
                                  })
                                }, i._id);
                              })
                            })
                          ]
                        })
                      }, L._id);
                    })
                  ]
                })
              ]
            }) : j.jsx(J, {})
          }),
          j.jsxs(H, {
            children: [
              j.jsx(m, {
                variant: "contained",
                disabled: !(I == null ? void 0 : I.length) || !Object.values(M).find((L) => L),
                onClick: this.handleSubmit,
                startIcon: j.jsx(P, {}),
                children: o.t("Add widgets")
              }),
              j.jsx(m, {
                variant: "contained",
                onClick: () => this.props.onClose(),
                startIcon: j.jsx(R, {}),
                color: "grey",
                children: o.t("Cancel")
              })
            ]
          })
        ]
      }, "materialWizardDialog");
    }
  }
  const F = () => j.jsx("svg", {
    stroke: "currentColor",
    fill: "none",
    strokeWidth: "0",
    viewBox: "0 0 15 15",
    height: "1em",
    width: "1em",
    xmlns: "http://www.w3.org/2000/svg",
    children: j.jsx("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M13.9 0.499976C13.9 0.279062 13.7209 0.0999756 13.5 0.0999756C13.2791 0.0999756 13.1 0.279062 13.1 0.499976V1.09998H12.5C12.2791 1.09998 12.1 1.27906 12.1 1.49998C12.1 1.72089 12.2791 1.89998 12.5 1.89998H13.1V2.49998C13.1 2.72089 13.2791 2.89998 13.5 2.89998C13.7209 2.89998 13.9 2.72089 13.9 2.49998V1.89998H14.5C14.7209 1.89998 14.9 1.72089 14.9 1.49998C14.9 1.27906 14.7209 1.09998 14.5 1.09998H13.9V0.499976ZM11.8536 3.14642C12.0488 3.34168 12.0488 3.65826 11.8536 3.85353L10.8536 4.85353C10.6583 5.04879 10.3417 5.04879 10.1465 4.85353C9.9512 4.65827 9.9512 4.34169 10.1465 4.14642L11.1464 3.14643C11.3417 2.95116 11.6583 2.95116 11.8536 3.14642ZM9.85357 5.14642C10.0488 5.34168 10.0488 5.65827 9.85357 5.85353L2.85355 12.8535C2.65829 13.0488 2.34171 13.0488 2.14645 12.8535C1.95118 12.6583 1.95118 12.3417 2.14645 12.1464L9.14646 5.14642C9.34172 4.95116 9.65831 4.95116 9.85357 5.14642ZM13.5 5.09998C13.7209 5.09998 13.9 5.27906 13.9 5.49998V6.09998H14.5C14.7209 6.09998 14.9 6.27906 14.9 6.49998C14.9 6.72089 14.7209 6.89998 14.5 6.89998H13.9V7.49998C13.9 7.72089 13.7209 7.89998 13.5 7.89998C13.2791 7.89998 13.1 7.72089 13.1 7.49998V6.89998H12.5C12.2791 6.89998 12.1 6.72089 12.1 6.49998C12.1 6.27906 12.2791 6.09998 12.5 6.09998H13.1V5.49998C13.1 5.27906 13.2791 5.09998 13.5 5.09998ZM8.90002 0.499976C8.90002 0.279062 8.72093 0.0999756 8.50002 0.0999756C8.2791 0.0999756 8.10002 0.279062 8.10002 0.499976V1.09998H7.50002C7.2791 1.09998 7.10002 1.27906 7.10002 1.49998C7.10002 1.72089 7.2791 1.89998 7.50002 1.89998H8.10002V2.49998C8.10002 2.72089 8.2791 2.89998 8.50002 2.89998C8.72093 2.89998 8.90002 2.72089 8.90002 2.49998V1.89998H9.50002C9.72093 1.89998 9.90002 1.72089 9.90002 1.49998C9.90002 1.27906 9.72093 1.09998 9.50002 1.09998H8.90002V0.499976Z",
      fill: "currentColor"
    })
  });
  class W extends O.Component {
    constructor(I) {
      super(I), this.state = {
        open: false
      };
    }
    render() {
      return [
        j.jsx(m, {
          onClick: () => this.setState({
            open: true
          }),
          variant: "contained",
          startIcon: j.jsx(F, {}),
          children: o.t("Wizard")
        }, "materialWizardButton"),
        this.state.open ? j.jsx(X, {
          onClose: () => this.setState({
            open: false
          }),
          ...this.props
        }, "materialWizardDialog") : null
      ];
    }
  }
  sM = class extends window.visRxWidget {
    static getWidgetInfo() {
      return {
        id: "tplNils2Wizard",
        visSet: "vis-2-widgets-nils-fork",
        visName: "Wizard",
        visWidgetLabel: "wizard",
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_wizard.png",
        visOrder: 100,
        visAttrs: [],
        customPalette: (I) => j.jsx(W, {
          ...I
        }, "wizard")
      };
    }
  };
});
export {
  __tla,
  sM as default
};
