import { i as e, t } from "./rolldown-runtime-C0FnF6B9.js";
import { B as n, g as r } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { dt as i, ft as a, pt as o } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as s } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare__moment__loadShare__.js-DmY8-Wzg.js";
import { t as c } from "./Generic-BOiMPpxz.js";
var l = t(((t2, n2) => {
  (function(e3, r2) {
    typeof t2 == `object` && n2 !== void 0 ? n2.exports = r2() : typeof define == `function` && define.amd ? define(r2) : e3.moment = r2();
  })(t2, (function() {
    var t3;
    function r2() {
      return t3.apply(null, arguments);
    }
    function i2(e3) {
      t3 = e3;
    }
    function a2(e3) {
      return e3 instanceof Array || Object.prototype.toString.call(e3) === `[object Array]`;
    }
    function o2(e3) {
      return e3 != null && Object.prototype.toString.call(e3) === `[object Object]`;
    }
    function s2(e3, t4) {
      return Object.prototype.hasOwnProperty.call(e3, t4);
    }
    function c2(e3) {
      if (Object.getOwnPropertyNames) return Object.getOwnPropertyNames(e3).length === 0;
      for (var t4 in e3) if (s2(e3, t4)) return false;
      return true;
    }
    function l2(e3) {
      return e3 === void 0;
    }
    function u2(e3) {
      return typeof e3 == `number` || Object.prototype.toString.call(e3) === `[object Number]`;
    }
    function d2(e3) {
      return e3 instanceof Date || Object.prototype.toString.call(e3) === `[object Date]`;
    }
    function f2(e3, t4) {
      var n3 = [], r3, i3 = e3.length;
      for (r3 = 0; r3 < i3; ++r3) n3.push(t4(e3[r3], r3));
      return n3;
    }
    function p2(e3, t4) {
      for (var n3 in t4) s2(t4, n3) && (e3[n3] = t4[n3]);
      return s2(t4, `toString`) && (e3.toString = t4.toString), s2(t4, `valueOf`) && (e3.valueOf = t4.valueOf), e3;
    }
    function m2(e3, t4, n3, r3) {
      return sr(e3, t4, n3, r3, true).utc();
    }
    function ee2() {
      return { empty: false, unusedTokens: [], unusedInput: [], overflow: -2, charsLeftOver: 0, nullInput: false, invalidEra: null, invalidMonth: null, invalidFormat: false, userInvalidated: false, iso: false, parsedDateParts: [], era: null, meridiem: null, rfc2822: false, weekdayMismatch: false };
    }
    function h2(e3) {
      return e3._pf ?? (e3._pf = ee2()), e3._pf;
    }
    var te2 = Array.prototype.some ? Array.prototype.some : function(e3) {
      for (var t4 = Object(this), n3 = t4.length >>> 0, r3 = 0; r3 < n3; r3++) if (r3 in t4 && e3.call(this, t4[r3], r3, t4)) return true;
      return false;
    };
    function ne2(e3) {
      var t4 = null, n3 = false, r3 = e3._d && !isNaN(e3._d.getTime());
      if (r3 && (t4 = h2(e3), n3 = te2.call(t4.parsedDateParts, function(e4) {
        return e4 != null;
      }), r3 = t4.overflow < 0 && !t4.empty && !t4.invalidEra && !t4.invalidMonth && !t4.invalidWeekday && !t4.weekdayMismatch && !t4.nullInput && !t4.invalidFormat && !t4.userInvalidated && (!t4.meridiem || t4.meridiem && n3), e3._strict && (r3 = r3 && t4.charsLeftOver === 0 && t4.unusedTokens.length === 0 && t4.bigHour === void 0)), Object.isFrozen == null || !Object.isFrozen(e3)) e3._isValid = r3;
      else return r3;
      return e3._isValid;
    }
    function re2(e3) {
      var t4 = m2(NaN);
      return e3 == null ? h2(t4).userInvalidated = true : p2(h2(t4), e3), t4;
    }
    var ie2 = r2.momentProperties = [], ae2 = false;
    function oe2(e3, t4) {
      var n3, r3, i3, a3 = ie2.length;
      if (l2(t4._isAMomentObject) || (e3._isAMomentObject = t4._isAMomentObject), l2(t4._i) || (e3._i = t4._i), l2(t4._f) || (e3._f = t4._f), l2(t4._l) || (e3._l = t4._l), l2(t4._strict) || (e3._strict = t4._strict), l2(t4._tzm) || (e3._tzm = t4._tzm), l2(t4._isUTC) || (e3._isUTC = t4._isUTC), l2(t4._offset) || (e3._offset = t4._offset), l2(t4._pf) || (e3._pf = h2(t4)), l2(t4._locale) || (e3._locale = t4._locale), a3 > 0) for (n3 = 0; n3 < a3; n3++) r3 = ie2[n3], i3 = t4[r3], l2(i3) || (e3[r3] = i3);
      return e3;
    }
    function g2(e3) {
      oe2(this, e3), this._d = new Date(e3._d == null ? NaN : e3._d.getTime()), this.isValid() || (this._d = /* @__PURE__ */ new Date(NaN)), ae2 === false && (ae2 = true, r2.updateOffset(this), ae2 = false);
    }
    function _2(e3) {
      return e3 instanceof g2 || e3 != null && e3._isAMomentObject != null;
    }
    function se(e3) {
      r2.suppressDeprecationWarnings === false && typeof console < `u` && console.warn && console.warn(`Deprecation warning: ` + e3);
    }
    function v(e3, t4) {
      var n3 = true;
      return p2(function() {
        if (r2.deprecationHandler != null && r2.deprecationHandler(null, e3), n3) {
          var i3 = [], a3, o3, c3, l3 = arguments.length;
          for (o3 = 0; o3 < l3; o3++) {
            if (a3 = ``, typeof arguments[o3] == `object`) {
              for (c3 in a3 += `
[` + o3 + `] `, arguments[0]) s2(arguments[0], c3) && (a3 += c3 + `: ` + arguments[0][c3] + `, `);
              a3 = a3.slice(0, -2);
            } else a3 = arguments[o3];
            i3.push(a3);
          }
          se(e3 + `
Arguments: ` + Array.prototype.slice.call(i3).join(``) + `
` + Error().stack), n3 = false;
        }
        return t4.apply(this, arguments);
      }, t4);
    }
    var ce = {};
    function le(e3, t4) {
      r2.deprecationHandler != null && r2.deprecationHandler(e3, t4), ce[e3] || (se(t4), ce[e3] = true);
    }
    r2.suppressDeprecationWarnings = false, r2.deprecationHandler = null;
    function y(e3) {
      return typeof Function < `u` && e3 instanceof Function || Object.prototype.toString.call(e3) === `[object Function]`;
    }
    function ue(e3) {
      var t4, n3;
      for (n3 in e3) s2(e3, n3) && (t4 = e3[n3], y(t4) ? this[n3] = t4 : this[`_` + n3] = t4);
      this._config = e3, this._dayOfMonthOrdinalParseLenient = RegExp((this._dayOfMonthOrdinalParse.source || this._ordinalParse.source) + `|\\d{1,2}`);
    }
    function de(e3, t4) {
      var n3 = p2({}, e3), r3;
      for (r3 in t4) s2(t4, r3) && (o2(e3[r3]) && o2(t4[r3]) ? (n3[r3] = {}, p2(n3[r3], e3[r3]), p2(n3[r3], t4[r3])) : t4[r3] == null ? delete n3[r3] : n3[r3] = t4[r3]);
      for (r3 in e3) s2(e3, r3) && !s2(t4, r3) && o2(e3[r3]) && (n3[r3] = p2({}, n3[r3]));
      return n3;
    }
    function fe(e3) {
      e3 != null && this.set(e3);
    }
    var pe = Object.keys ? Object.keys : function(e3) {
      var t4, n3 = [];
      for (t4 in e3) s2(e3, t4) && n3.push(t4);
      return n3;
    }, me = { sameDay: `[Today at] LT`, nextDay: `[Tomorrow at] LT`, nextWeek: `dddd [at] LT`, lastDay: `[Yesterday at] LT`, lastWeek: `[Last] dddd [at] LT`, sameElse: `L` };
    function he(e3, t4, n3) {
      var r3 = this._calendar[e3] || this._calendar.sameElse;
      return y(r3) ? r3.call(t4, n3) : r3;
    }
    function b(e3, t4, n3) {
      var r3 = `` + Math.abs(e3), i3 = t4 - r3.length;
      return (e3 >= 0 ? n3 ? `+` : `` : `-`) + (10 ** Math.max(0, i3)).toString().substr(1) + r3;
    }
    var ge = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|N{1,5}|YYYYYY|YYYYY|YYYY|YY|y{2,4}|yo?|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g, _e = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g, ve = {}, ye = {};
    function x(e3, t4, n3, r3) {
      var i3 = r3;
      typeof r3 == `string` && (i3 = function() {
        return this[r3]();
      }), e3 && (ye[e3] = i3), t4 && (ye[t4[0]] = function() {
        return b(i3.apply(this, arguments), t4[1], t4[2]);
      }), n3 && (ye[n3] = function() {
        return this.localeData().ordinal(i3.apply(this, arguments), e3);
      });
    }
    function be(e3) {
      return e3.match(/\[[\s\S]/) ? e3.replace(/^\[|\]$/g, ``) : e3.replace(/\\/g, ``);
    }
    function xe(e3) {
      for (var t4 = e3.match(ge), n3 = 0, r3 = t4.length; n3 < r3; n3++) ye[t4[n3]] ? t4[n3] = ye[t4[n3]] : t4[n3] = be(t4[n3]);
      return function(n4) {
        for (var i3 = ``, a3 = 0; a3 < r3; a3++) i3 += y(t4[a3]) ? t4[a3].call(n4, e3) : t4[a3];
        return i3;
      };
    }
    function Se(e3, t4) {
      return e3.isValid() ? (t4 = Ce(t4, e3.localeData()), ve[t4] = ve[t4] || xe(t4), ve[t4](e3)) : e3.localeData().invalidDate();
    }
    function Ce(e3, t4) {
      var n3 = 5;
      function r3(e4) {
        return t4.longDateFormat(e4) || e4;
      }
      for (_e.lastIndex = 0; n3 >= 0 && _e.test(e3); ) e3 = e3.replace(_e, r3), _e.lastIndex = 0, --n3;
      return e3;
    }
    var we = { LTS: `h:mm:ss A`, LT: `h:mm A`, L: `MM/DD/YYYY`, LL: `MMMM D, YYYY`, LLL: `MMMM D, YYYY h:mm A`, LLLL: `dddd, MMMM D, YYYY h:mm A` };
    function Te(e3) {
      var t4 = this._longDateFormat[e3], n3 = this._longDateFormat[e3.toUpperCase()];
      return t4 || !n3 ? t4 : (this._longDateFormat[e3] = n3.match(ge).map(function(e4) {
        return e4 === `MMMM` || e4 === `MM` || e4 === `DD` || e4 === `dddd` ? e4.slice(1) : e4;
      }).join(``), this._longDateFormat[e3]);
    }
    var Ee = `Invalid date`;
    function De() {
      return this._invalidDate;
    }
    var Oe = `%d`, ke = /\d{1,2}/;
    function Ae(e3) {
      return this._ordinal.replace(`%d`, e3);
    }
    var je = { future: `in %s`, past: `%s ago`, s: `a few seconds`, ss: `%d seconds`, m: `a minute`, mm: `%d minutes`, h: `an hour`, hh: `%d hours`, d: `a day`, dd: `%d days`, w: `a week`, ww: `%d weeks`, M: `a month`, MM: `%d months`, y: `a year`, yy: `%d years` };
    function Me(e3, t4, n3, r3) {
      var i3 = this._relativeTime[n3];
      return y(i3) ? i3(e3, t4, n3, r3) : i3.replace(/%d/i, e3);
    }
    function Ne(e3, t4) {
      var n3 = this._relativeTime[e3 > 0 ? `future` : `past`];
      return y(n3) ? n3(t4) : n3.replace(/%s/i, t4);
    }
    var Pe = { D: `date`, dates: `date`, date: `date`, d: `day`, days: `day`, day: `day`, e: `weekday`, weekdays: `weekday`, weekday: `weekday`, E: `isoWeekday`, isoweekdays: `isoWeekday`, isoweekday: `isoWeekday`, DDD: `dayOfYear`, dayofyears: `dayOfYear`, dayofyear: `dayOfYear`, h: `hour`, hours: `hour`, hour: `hour`, ms: `millisecond`, milliseconds: `millisecond`, millisecond: `millisecond`, m: `minute`, minutes: `minute`, minute: `minute`, M: `month`, months: `month`, month: `month`, Q: `quarter`, quarters: `quarter`, quarter: `quarter`, s: `second`, seconds: `second`, second: `second`, gg: `weekYear`, weekyears: `weekYear`, weekyear: `weekYear`, GG: `isoWeekYear`, isoweekyears: `isoWeekYear`, isoweekyear: `isoWeekYear`, w: `week`, weeks: `week`, week: `week`, W: `isoWeek`, isoweeks: `isoWeek`, isoweek: `isoWeek`, y: `year`, years: `year`, year: `year` };
    function S(e3) {
      return typeof e3 == `string` ? Pe[e3] || Pe[e3.toLowerCase()] : void 0;
    }
    function Fe(e3) {
      var t4 = {}, n3, r3;
      for (r3 in e3) s2(e3, r3) && (n3 = S(r3), n3 && (t4[n3] = e3[r3]));
      return t4;
    }
    var Ie = { date: 9, day: 11, weekday: 11, isoWeekday: 11, dayOfYear: 4, hour: 13, millisecond: 16, minute: 14, month: 8, quarter: 7, second: 15, weekYear: 1, isoWeekYear: 1, week: 5, isoWeek: 5, year: 1 };
    function Le(e3) {
      var t4 = [], n3;
      for (n3 in e3) s2(e3, n3) && t4.push({ unit: n3, priority: Ie[n3] });
      return t4.sort(function(e4, t5) {
        return e4.priority - t5.priority;
      }), t4;
    }
    var Re = /\d/, C = /\d\d/, ze = /\d{3}/, Be = /\d{4}/, Ve = /[+-]?\d{6}/, w = /\d\d?/, He = /\d\d\d\d?/, Ue = /\d\d\d\d\d\d?/, We = /\d{1,3}/, Ge = /\d{1,4}/, Ke = /[+-]?\d{1,6}/, qe = /\d+/, Je = /[+-]?\d+/, Ye = /Z|[+-]\d\d:?\d\d/gi, Xe = /Z|[+-]\d\d(?::?\d\d)?/gi, Ze = /[+-]?\d+(\.\d{1,3})?/, Qe = /[0-9]{0,256}['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFF07\uFF10-\uFFEF]{1,256}|[\u0600-\u06FF\/]{1,256}(\s*?[\u0600-\u06FF]{1,256}){1,2}/i, $e = /^[1-9]\d?/, et = /^([1-9]\d|\d)/, tt = {};
    function T(e3, t4, n3) {
      tt[e3] = y(t4) ? t4 : function(e4, r3) {
        return e4 && n3 ? n3 : t4;
      };
    }
    function nt(e3, t4) {
      return s2(tt, e3) ? tt[e3](t4._strict, t4._locale) : new RegExp(rt(e3));
    }
    function rt(e3) {
      return E(e3.replace(`\\`, ``).replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function(e4, t4, n3, r3, i3) {
        return t4 || n3 || r3 || i3;
      }));
    }
    function E(e3) {
      return e3.replace(/[-\/\\^$*+?.()|[\]{}]/g, `\\$&`);
    }
    function D(e3) {
      return e3 < 0 ? Math.ceil(e3) || 0 : Math.floor(e3);
    }
    function O(e3) {
      var t4 = +e3, n3 = 0;
      return t4 !== 0 && isFinite(t4) && (n3 = D(t4)), n3;
    }
    var it = {};
    function k(e3, t4) {
      var n3, r3 = t4, i3;
      for (typeof e3 == `string` && (e3 = [e3]), u2(t4) && (r3 = function(e4, n4) {
        n4[t4] = O(e4);
      }), i3 = e3.length, n3 = 0; n3 < i3; n3++) it[e3[n3]] = r3;
    }
    function at(e3, t4) {
      k(e3, function(e4, n3, r3, i3) {
        r3._w = r3._w || {}, t4(e4, r3._w, r3, i3);
      });
    }
    function ot(e3, t4, n3) {
      t4 != null && s2(it, e3) && it[e3](t4, n3._a, n3, e3);
    }
    function st(e3) {
      return e3 % 4 == 0 && e3 % 100 != 0 || e3 % 400 == 0;
    }
    var A = 0, j = 1, M = 2, N = 3, P = 4, F = 5, I = 6, ct = 7, lt = 8;
    x(`Y`, 0, 0, function() {
      var e3 = this.year();
      return e3 <= 9999 ? b(e3, 4) : `+` + e3;
    }), x(0, [`YY`, 2], 0, function() {
      return this.year() % 100;
    }), x(0, [`YYYY`, 4], 0, `year`), x(0, [`YYYYY`, 5], 0, `year`), x(0, [`YYYYYY`, 6, true], 0, `year`), T(`Y`, Je), T(`YY`, w, C), T(`YYYY`, Ge, Be), T(`YYYYY`, Ke, Ve), T(`YYYYYY`, Ke, Ve), k([`YYYYY`, `YYYYYY`], A), k(`YYYY`, function(e3, t4) {
      t4[A] = e3.length === 2 ? r2.parseTwoDigitYear(e3) : O(e3);
    }), k(`YY`, function(e3, t4) {
      t4[A] = r2.parseTwoDigitYear(e3);
    }), k(`Y`, function(e3, t4) {
      t4[A] = parseInt(e3, 10);
    });
    function ut(e3) {
      return st(e3) ? 366 : 365;
    }
    r2.parseTwoDigitYear = function(e3) {
      return O(e3) + (O(e3) > 68 ? 1900 : 2e3);
    };
    var dt = pt(`FullYear`, true);
    function ft() {
      return st(this.year());
    }
    function pt(e3, t4) {
      return function(n3) {
        return n3 == null ? mt(this, e3) : (ht(this, e3, n3), r2.updateOffset(this, t4), this);
      };
    }
    function mt(e3, t4) {
      if (!e3.isValid()) return NaN;
      var n3 = e3._d, r3 = e3._isUTC;
      switch (t4) {
        case `Milliseconds`:
          return r3 ? n3.getUTCMilliseconds() : n3.getMilliseconds();
        case `Seconds`:
          return r3 ? n3.getUTCSeconds() : n3.getSeconds();
        case `Minutes`:
          return r3 ? n3.getUTCMinutes() : n3.getMinutes();
        case `Hours`:
          return r3 ? n3.getUTCHours() : n3.getHours();
        case `Date`:
          return r3 ? n3.getUTCDate() : n3.getDate();
        case `Day`:
          return r3 ? n3.getUTCDay() : n3.getDay();
        case `Month`:
          return r3 ? n3.getUTCMonth() : n3.getMonth();
        case `FullYear`:
          return r3 ? n3.getUTCFullYear() : n3.getFullYear();
        default:
          return NaN;
      }
    }
    function ht(e3, t4, n3) {
      var r3, i3, a3, o3, s3;
      if (e3.isValid() && !isNaN(n3)) {
        switch (r3 = e3._d, i3 = e3._isUTC, t4) {
          case `Milliseconds`:
            i3 ? r3.setUTCMilliseconds(n3) : r3.setMilliseconds(n3);
            return;
          case `Seconds`:
            i3 ? r3.setUTCSeconds(n3) : r3.setSeconds(n3);
            return;
          case `Minutes`:
            i3 ? r3.setUTCMinutes(n3) : r3.setMinutes(n3);
            return;
          case `Hours`:
            i3 ? r3.setUTCHours(n3) : r3.setHours(n3);
            return;
          case `Date`:
            i3 ? r3.setUTCDate(n3) : r3.setDate(n3);
            return;
          case `FullYear`:
            break;
          default:
            return;
        }
        a3 = n3, o3 = e3.month(), s3 = e3.date(), s3 = s3 === 29 && o3 === 1 && !st(a3) ? 28 : s3, i3 ? r3.setUTCFullYear(a3, o3, s3) : r3.setFullYear(a3, o3, s3);
      }
    }
    function gt(e3) {
      return e3 = S(e3), y(this[e3]) ? this[e3]() : this;
    }
    function _t(e3, t4) {
      if (typeof e3 == `object`) {
        e3 = Fe(e3);
        var n3 = Le(e3), r3, i3 = n3.length;
        for (r3 = 0; r3 < i3; r3++) this[n3[r3].unit](e3[n3[r3].unit]);
      } else if (e3 = S(e3), y(this[e3])) return this[e3](t4);
      return this;
    }
    function vt(e3, t4) {
      return (e3 % t4 + t4) % t4;
    }
    var L = Array.prototype.indexOf ? Array.prototype.indexOf : function(e3) {
      for (var t4 = 0; t4 < this.length; ++t4) if (this[t4] === e3) return t4;
      return -1;
    };
    function yt(e3, t4) {
      if (isNaN(e3) || isNaN(t4)) return NaN;
      var n3 = vt(t4, 12);
      return e3 += (t4 - n3) / 12, n3 === 1 ? st(e3) ? 29 : 28 : 31 - n3 % 7 % 2;
    }
    x(`M`, [`MM`, 2], `Mo`, function() {
      return this.month() + 1;
    }), x(`MMM`, 0, 0, function(e3) {
      return this.localeData().monthsShort(this, e3);
    }), x(`MMMM`, 0, 0, function(e3) {
      return this.localeData().months(this, e3);
    }), T(`M`, w, $e), T(`MM`, w, C), T(`MMM`, function(e3, t4) {
      return t4.monthsShortRegex(e3);
    }), T(`MMMM`, function(e3, t4) {
      return t4.monthsRegex(e3);
    }), k([`M`, `MM`], function(e3, t4) {
      t4[j] = O(e3) - 1;
    }), k([`MMM`, `MMMM`], function(e3, t4, n3, r3) {
      var i3 = n3._locale.monthsParse(e3, r3, n3._strict);
      i3 == null ? h2(n3).invalidMonth = e3 : t4[j] = i3;
    });
    var bt = `January_February_March_April_May_June_July_August_September_October_November_December`.split(`_`), xt = `Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec`.split(`_`), St = /D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/, Ct = Qe, wt = Qe;
    function Tt(e3, t4) {
      return e3 ? a2(this._months) ? this._months[e3.month()] : this._months[(this._months.isFormat || St).test(t4) ? `format` : `standalone`][e3.month()] : a2(this._months) ? this._months : this._months.standalone;
    }
    function Et(e3, t4) {
      return e3 ? a2(this._monthsShort) ? this._monthsShort[e3.month()] : this._monthsShort[St.test(t4) ? `format` : `standalone`][e3.month()] : a2(this._monthsShort) ? this._monthsShort : this._monthsShort.standalone;
    }
    function Dt(e3, t4, n3) {
      var r3, i3, a3, o3 = e3.toLocaleLowerCase();
      if (!this._monthsParse) for (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = [], r3 = 0; r3 < 12; ++r3) a3 = m2([2e3, r3]), this._shortMonthsParse[r3] = this.monthsShort(a3, ``).toLocaleLowerCase(), this._longMonthsParse[r3] = this.months(a3, ``).toLocaleLowerCase();
      return n3 ? t4 === `MMM` ? (i3 = L.call(this._shortMonthsParse, o3), i3 === -1 ? null : i3) : (i3 = L.call(this._longMonthsParse, o3), i3 === -1 ? null : i3) : t4 === `MMM` ? (i3 = L.call(this._shortMonthsParse, o3), i3 === -1 ? (i3 = L.call(this._longMonthsParse, o3), i3 === -1 ? null : i3) : i3) : (i3 = L.call(this._longMonthsParse, o3), i3 === -1 ? (i3 = L.call(this._shortMonthsParse, o3), i3 === -1 ? null : i3) : i3);
    }
    function Ot(e3, t4, n3) {
      var r3, i3, a3;
      if (this._monthsParseExact) return Dt.call(this, e3, t4, n3);
      for (this._monthsParse || (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = []), r3 = 0; r3 < 12; r3++) if (i3 = m2([2e3, r3]), n3 && !this._longMonthsParse[r3] && (this._longMonthsParse[r3] = RegExp(`^` + this.months(i3, ``).replace(`.`, ``) + `$`, `i`), this._shortMonthsParse[r3] = RegExp(`^` + this.monthsShort(i3, ``).replace(`.`, ``) + `$`, `i`)), !n3 && !this._monthsParse[r3] && (a3 = `^` + this.months(i3, ``) + `|^` + this.monthsShort(i3, ``), this._monthsParse[r3] = new RegExp(a3.replace(`.`, ``), `i`)), n3 && t4 === `MMMM` && this._longMonthsParse[r3].test(e3) || n3 && t4 === `MMM` && this._shortMonthsParse[r3].test(e3) || !n3 && this._monthsParse[r3].test(e3)) return r3;
    }
    function kt(e3, t4) {
      if (!e3.isValid()) return e3;
      if (typeof t4 == `string`) {
        if (/^\d+$/.test(t4)) t4 = O(t4);
        else if (t4 = e3.localeData().monthsParse(t4), !u2(t4)) return e3;
      }
      var n3 = t4, r3 = e3.date();
      return r3 = r3 < 29 ? r3 : Math.min(r3, yt(e3.year(), n3)), e3._isUTC ? e3._d.setUTCMonth(n3, r3) : e3._d.setMonth(n3, r3), e3;
    }
    function At(e3) {
      return e3 == null ? mt(this, `Month`) : (kt(this, e3), r2.updateOffset(this, true), this);
    }
    function jt() {
      return yt(this.year(), this.month());
    }
    function Mt(e3) {
      return this._monthsParseExact ? (s2(this, `_monthsRegex`) || Pt.call(this), e3 ? this._monthsShortStrictRegex : this._monthsShortRegex) : (s2(this, `_monthsShortRegex`) || (this._monthsShortRegex = Ct), this._monthsShortStrictRegex && e3 ? this._monthsShortStrictRegex : this._monthsShortRegex);
    }
    function Nt(e3) {
      return this._monthsParseExact ? (s2(this, `_monthsRegex`) || Pt.call(this), e3 ? this._monthsStrictRegex : this._monthsRegex) : (s2(this, `_monthsRegex`) || (this._monthsRegex = wt), this._monthsStrictRegex && e3 ? this._monthsStrictRegex : this._monthsRegex);
    }
    function Pt() {
      function e3(e4, t5) {
        return t5.length - e4.length;
      }
      for (var t4 = [], n3 = [], r3 = [], i3 = 0, a3, o3, s3; i3 < 12; i3++) a3 = m2([2e3, i3]), o3 = E(this.monthsShort(a3, ``)), s3 = E(this.months(a3, ``)), t4.push(o3), n3.push(s3), r3.push(s3), r3.push(o3);
      t4.sort(e3), n3.sort(e3), r3.sort(e3), this._monthsRegex = RegExp(`^(` + r3.join(`|`) + `)`, `i`), this._monthsShortRegex = this._monthsRegex, this._monthsStrictRegex = RegExp(`^(` + n3.join(`|`) + `)`, `i`), this._monthsShortStrictRegex = RegExp(`^(` + t4.join(`|`) + `)`, `i`);
    }
    function Ft(e3, t4, n3, r3, i3, a3, o3) {
      var s3;
      return e3 < 100 && e3 >= 0 ? (s3 = new Date(e3 + 400, t4, n3, r3, i3, a3, o3), isFinite(s3.getFullYear()) && s3.setFullYear(e3)) : s3 = new Date(e3, t4, n3, r3, i3, a3, o3), s3;
    }
    function It(e3) {
      var t4, n3;
      return e3 < 100 && e3 >= 0 ? (n3 = Array.prototype.slice.call(arguments), n3[0] = e3 + 400, t4 = new Date(Date.UTC.apply(null, n3)), isFinite(t4.getUTCFullYear()) && t4.setUTCFullYear(e3)) : t4 = new Date(Date.UTC.apply(null, arguments)), t4;
    }
    function Lt(e3, t4, n3) {
      var r3 = 7 + t4 - n3;
      return -((7 + It(e3, 0, r3).getUTCDay() - t4) % 7) + r3 - 1;
    }
    function Rt(e3, t4, n3, r3, i3) {
      var a3 = (7 + n3 - r3) % 7, o3 = Lt(e3, r3, i3), s3 = 1 + 7 * (t4 - 1) + a3 + o3, c3, l3;
      return s3 <= 0 ? (c3 = e3 - 1, l3 = ut(c3) + s3) : s3 > ut(e3) ? (c3 = e3 + 1, l3 = s3 - ut(e3)) : (c3 = e3, l3 = s3), { year: c3, dayOfYear: l3 };
    }
    function zt(e3, t4, n3) {
      var r3 = Lt(e3.year(), t4, n3), i3 = Math.floor((e3.dayOfYear() - r3 - 1) / 7) + 1, a3, o3;
      return i3 < 1 ? (o3 = e3.year() - 1, a3 = i3 + R(o3, t4, n3)) : i3 > R(e3.year(), t4, n3) ? (a3 = i3 - R(e3.year(), t4, n3), o3 = e3.year() + 1) : (o3 = e3.year(), a3 = i3), { week: a3, year: o3 };
    }
    function R(e3, t4, n3) {
      var r3 = Lt(e3, t4, n3), i3 = Lt(e3 + 1, t4, n3);
      return (ut(e3) - r3 + i3) / 7;
    }
    x(`w`, [`ww`, 2], `wo`, `week`), x(`W`, [`WW`, 2], `Wo`, `isoWeek`), T(`w`, w, $e), T(`ww`, w, C), T(`W`, w, $e), T(`WW`, w, C), at([`w`, `ww`, `W`, `WW`], function(e3, t4, n3, r3) {
      t4[r3.substr(0, 1)] = O(e3);
    });
    function Bt(e3) {
      return zt(e3, this._week.dow, this._week.doy).week;
    }
    var Vt = { dow: 0, doy: 6 };
    function Ht() {
      return this._week.dow;
    }
    function Ut() {
      return this._week.doy;
    }
    function Wt(e3) {
      var t4 = this.localeData().week(this);
      return e3 == null ? t4 : this.add((e3 - t4) * 7, `d`);
    }
    function Gt(e3) {
      var t4 = zt(this, 1, 4).week;
      return e3 == null ? t4 : this.add((e3 - t4) * 7, `d`);
    }
    x(`d`, 0, `do`, `day`), x(`dd`, 0, 0, function(e3) {
      return this.localeData().weekdaysMin(this, e3);
    }), x(`ddd`, 0, 0, function(e3) {
      return this.localeData().weekdaysShort(this, e3);
    }), x(`dddd`, 0, 0, function(e3) {
      return this.localeData().weekdays(this, e3);
    }), x(`e`, 0, 0, `weekday`), x(`E`, 0, 0, `isoWeekday`), T(`d`, w), T(`e`, w), T(`E`, w), T(`dd`, function(e3, t4) {
      return t4.weekdaysMinRegex(e3);
    }), T(`ddd`, function(e3, t4) {
      return t4.weekdaysShortRegex(e3);
    }), T(`dddd`, function(e3, t4) {
      return t4.weekdaysRegex(e3);
    }), at([`dd`, `ddd`, `dddd`], function(e3, t4, n3, r3) {
      var i3 = n3._locale.weekdaysParse(e3, r3, n3._strict);
      i3 == null ? h2(n3).invalidWeekday = e3 : t4.d = i3;
    }), at([`d`, `e`, `E`], function(e3, t4, n3, r3) {
      t4[r3] = O(e3);
    });
    function Kt(e3, t4) {
      return typeof e3 == `string` ? isNaN(e3) ? (e3 = t4.weekdaysParse(e3), typeof e3 == `number` ? e3 : null) : parseInt(e3, 10) : e3;
    }
    function qt(e3, t4) {
      return typeof e3 == `string` ? t4.weekdaysParse(e3) % 7 || 7 : isNaN(e3) ? null : e3;
    }
    function Jt(e3, t4) {
      return e3.slice(t4, 7).concat(e3.slice(0, t4));
    }
    var Yt = `Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday`.split(`_`), Xt = `Sun_Mon_Tue_Wed_Thu_Fri_Sat`.split(`_`), Zt = `Su_Mo_Tu_We_Th_Fr_Sa`.split(`_`), Qt = Qe, $t = Qe, en = Qe;
    function tn(e3, t4) {
      var n3 = a2(this._weekdays) ? this._weekdays : this._weekdays[e3 && e3 !== true && this._weekdays.isFormat.test(t4) ? `format` : `standalone`];
      return e3 === true ? Jt(n3, this._week.dow) : e3 ? n3[e3.day()] : n3;
    }
    function nn(e3) {
      return e3 === true ? Jt(this._weekdaysShort, this._week.dow) : e3 ? this._weekdaysShort[e3.day()] : this._weekdaysShort;
    }
    function rn(e3) {
      return e3 === true ? Jt(this._weekdaysMin, this._week.dow) : e3 ? this._weekdaysMin[e3.day()] : this._weekdaysMin;
    }
    function an(e3, t4, n3) {
      var r3, i3, a3, o3 = e3.toLocaleLowerCase();
      if (!this._weekdaysParse) for (this._weekdaysParse = [], this._shortWeekdaysParse = [], this._minWeekdaysParse = [], r3 = 0; r3 < 7; ++r3) a3 = m2([2e3, 1]).day(r3), this._minWeekdaysParse[r3] = this.weekdaysMin(a3, ``).toLocaleLowerCase(), this._shortWeekdaysParse[r3] = this.weekdaysShort(a3, ``).toLocaleLowerCase(), this._weekdaysParse[r3] = this.weekdays(a3, ``).toLocaleLowerCase();
      return n3 ? t4 === `dddd` ? (i3 = L.call(this._weekdaysParse, o3), i3 === -1 ? null : i3) : t4 === `ddd` ? (i3 = L.call(this._shortWeekdaysParse, o3), i3 === -1 ? null : i3) : (i3 = L.call(this._minWeekdaysParse, o3), i3 === -1 ? null : i3) : t4 === `dddd` ? (i3 = L.call(this._weekdaysParse, o3), i3 !== -1 || (i3 = L.call(this._shortWeekdaysParse, o3), i3 !== -1) ? i3 : (i3 = L.call(this._minWeekdaysParse, o3), i3 === -1 ? null : i3)) : t4 === `ddd` ? (i3 = L.call(this._shortWeekdaysParse, o3), i3 !== -1 || (i3 = L.call(this._weekdaysParse, o3), i3 !== -1) ? i3 : (i3 = L.call(this._minWeekdaysParse, o3), i3 === -1 ? null : i3)) : (i3 = L.call(this._minWeekdaysParse, o3), i3 !== -1 || (i3 = L.call(this._weekdaysParse, o3), i3 !== -1) ? i3 : (i3 = L.call(this._shortWeekdaysParse, o3), i3 === -1 ? null : i3));
    }
    function on(e3, t4, n3) {
      var r3, i3, a3;
      if (this._weekdaysParseExact) return an.call(this, e3, t4, n3);
      for (this._weekdaysParse || (this._weekdaysParse = [], this._minWeekdaysParse = [], this._shortWeekdaysParse = [], this._fullWeekdaysParse = []), r3 = 0; r3 < 7; r3++) if (i3 = m2([2e3, 1]).day(r3), n3 && !this._fullWeekdaysParse[r3] && (this._fullWeekdaysParse[r3] = RegExp(`^` + this.weekdays(i3, ``).replace(`.`, `\\.?`) + `$`, `i`), this._shortWeekdaysParse[r3] = RegExp(`^` + this.weekdaysShort(i3, ``).replace(`.`, `\\.?`) + `$`, `i`), this._minWeekdaysParse[r3] = RegExp(`^` + this.weekdaysMin(i3, ``).replace(`.`, `\\.?`) + `$`, `i`)), this._weekdaysParse[r3] || (a3 = `^` + this.weekdays(i3, ``) + `|^` + this.weekdaysShort(i3, ``) + `|^` + this.weekdaysMin(i3, ``), this._weekdaysParse[r3] = new RegExp(a3.replace(`.`, ``), `i`)), n3 && t4 === `dddd` && this._fullWeekdaysParse[r3].test(e3) || n3 && t4 === `ddd` && this._shortWeekdaysParse[r3].test(e3) || n3 && t4 === `dd` && this._minWeekdaysParse[r3].test(e3) || !n3 && this._weekdaysParse[r3].test(e3)) return r3;
    }
    function sn(e3) {
      if (!this.isValid()) return e3 == null ? NaN : this;
      var t4 = mt(this, `Day`);
      return e3 == null ? t4 : (e3 = Kt(e3, this.localeData()), this.add(e3 - t4, `d`));
    }
    function cn(e3) {
      if (!this.isValid()) return e3 == null ? NaN : this;
      var t4 = (this.day() + 7 - this.localeData()._week.dow) % 7;
      return e3 == null ? t4 : this.add(e3 - t4, `d`);
    }
    function ln(e3) {
      if (!this.isValid()) return e3 == null ? NaN : this;
      if (e3 != null) {
        var t4 = qt(e3, this.localeData());
        return this.day(this.day() % 7 ? t4 : t4 - 7);
      }
      return this.day() || 7;
    }
    function un(e3) {
      return this._weekdaysParseExact ? (s2(this, `_weekdaysRegex`) || pn.call(this), e3 ? this._weekdaysStrictRegex : this._weekdaysRegex) : (s2(this, `_weekdaysRegex`) || (this._weekdaysRegex = Qt), this._weekdaysStrictRegex && e3 ? this._weekdaysStrictRegex : this._weekdaysRegex);
    }
    function dn(e3) {
      return this._weekdaysParseExact ? (s2(this, `_weekdaysRegex`) || pn.call(this), e3 ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex) : (s2(this, `_weekdaysShortRegex`) || (this._weekdaysShortRegex = $t), this._weekdaysShortStrictRegex && e3 ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex);
    }
    function fn(e3) {
      return this._weekdaysParseExact ? (s2(this, `_weekdaysRegex`) || pn.call(this), e3 ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex) : (s2(this, `_weekdaysMinRegex`) || (this._weekdaysMinRegex = en), this._weekdaysMinStrictRegex && e3 ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex);
    }
    function pn() {
      function e3(e4, t5) {
        return t5.length - e4.length;
      }
      for (var t4 = [], n3 = [], r3 = [], i3 = [], a3 = 0, o3, s3, c3, l3; a3 < 7; a3++) o3 = m2([2e3, 1]).day(a3), s3 = E(this.weekdaysMin(o3, ``)), c3 = E(this.weekdaysShort(o3, ``)), l3 = E(this.weekdays(o3, ``)), t4.push(s3), n3.push(c3), r3.push(l3), i3.push(s3), i3.push(c3), i3.push(l3);
      t4.sort(e3), n3.sort(e3), r3.sort(e3), i3.sort(e3), this._weekdaysRegex = RegExp(`^(` + i3.join(`|`) + `)`, `i`), this._weekdaysShortRegex = this._weekdaysRegex, this._weekdaysMinRegex = this._weekdaysRegex, this._weekdaysStrictRegex = RegExp(`^(` + r3.join(`|`) + `)`, `i`), this._weekdaysShortStrictRegex = RegExp(`^(` + n3.join(`|`) + `)`, `i`), this._weekdaysMinStrictRegex = RegExp(`^(` + t4.join(`|`) + `)`, `i`);
    }
    function mn() {
      return this.hours() % 12 || 12;
    }
    function hn() {
      return this.hours() || 24;
    }
    x(`H`, [`HH`, 2], 0, `hour`), x(`h`, [`hh`, 2], 0, mn), x(`k`, [`kk`, 2], 0, hn), x(`hmm`, 0, 0, function() {
      return `` + mn.apply(this) + b(this.minutes(), 2);
    }), x(`hmmss`, 0, 0, function() {
      return `` + mn.apply(this) + b(this.minutes(), 2) + b(this.seconds(), 2);
    }), x(`Hmm`, 0, 0, function() {
      return `` + this.hours() + b(this.minutes(), 2);
    }), x(`Hmmss`, 0, 0, function() {
      return `` + this.hours() + b(this.minutes(), 2) + b(this.seconds(), 2);
    });
    function gn(e3, t4) {
      x(e3, 0, 0, function() {
        return this.localeData().meridiem(this.hours(), this.minutes(), t4);
      });
    }
    gn(`a`, true), gn(`A`, false);
    function _n(e3, t4) {
      return t4._meridiemParse;
    }
    T(`a`, _n), T(`A`, _n), T(`H`, w, et), T(`h`, w, $e), T(`k`, w, $e), T(`HH`, w, C), T(`hh`, w, C), T(`kk`, w, C), T(`hmm`, He), T(`hmmss`, Ue), T(`Hmm`, He), T(`Hmmss`, Ue), k([`H`, `HH`], N), k([`k`, `kk`], function(e3, t4, n3) {
      var r3 = O(e3);
      t4[N] = r3 === 24 ? 0 : r3;
    }), k([`a`, `A`], function(e3, t4, n3) {
      n3._isPm = n3._locale.isPM(e3), n3._meridiem = e3;
    }), k([`h`, `hh`], function(e3, t4, n3) {
      t4[N] = O(e3), h2(n3).bigHour = true;
    }), k(`hmm`, function(e3, t4, n3) {
      var r3 = e3.length - 2;
      t4[N] = O(e3.substr(0, r3)), t4[P] = O(e3.substr(r3)), h2(n3).bigHour = true;
    }), k(`hmmss`, function(e3, t4, n3) {
      var r3 = e3.length - 4, i3 = e3.length - 2;
      t4[N] = O(e3.substr(0, r3)), t4[P] = O(e3.substr(r3, 2)), t4[F] = O(e3.substr(i3)), h2(n3).bigHour = true;
    }), k(`Hmm`, function(e3, t4, n3) {
      var r3 = e3.length - 2;
      t4[N] = O(e3.substr(0, r3)), t4[P] = O(e3.substr(r3));
    }), k(`Hmmss`, function(e3, t4, n3) {
      var r3 = e3.length - 4, i3 = e3.length - 2;
      t4[N] = O(e3.substr(0, r3)), t4[P] = O(e3.substr(r3, 2)), t4[F] = O(e3.substr(i3));
    });
    function vn(e3) {
      return (e3 + ``).toLowerCase().charAt(0) === `p`;
    }
    var yn = /[ap]\.?m?\.?/i, bn = pt(`Hours`, true);
    function xn(e3, t4, n3) {
      return e3 > 11 ? n3 ? `pm` : `PM` : n3 ? `am` : `AM`;
    }
    var Sn = { calendar: me, longDateFormat: we, invalidDate: Ee, ordinal: Oe, dayOfMonthOrdinalParse: ke, relativeTime: je, months: bt, monthsShort: xt, week: Vt, weekdays: Yt, weekdaysMin: Zt, weekdaysShort: Xt, meridiemParse: yn }, z = {}, Cn = {}, wn;
    function Tn(e3, t4) {
      var n3, r3 = Math.min(e3.length, t4.length);
      for (n3 = 0; n3 < r3; n3 += 1) if (e3[n3] !== t4[n3]) return n3;
      return r3;
    }
    function En(e3) {
      return e3 && e3.toLowerCase().replace(`_`, `-`);
    }
    function Dn(e3) {
      for (var t4 = 0, n3, r3, i3, a3; t4 < e3.length; ) {
        for (a3 = En(e3[t4]).split(`-`), n3 = a3.length, r3 = En(e3[t4 + 1]), r3 = r3 ? r3.split(`-`) : null; n3 > 0; ) {
          if (i3 = kn(a3.slice(0, n3).join(`-`)), i3) return i3;
          if (r3 && r3.length >= n3 && Tn(a3, r3) >= n3 - 1) break;
          n3--;
        }
        t4++;
      }
      return wn;
    }
    function On(e3) {
      return !!(e3 && e3.match(`^[^/\\\\]*$`));
    }
    function kn(t4) {
      var r3 = null, i3;
      if (z[t4] === void 0 && n2 !== void 0 && n2 && n2.exports && On(t4)) try {
        r3 = wn._abbr, i3 = e, i3(`./locale/` + t4), B(r3);
      } catch {
        z[t4] = null;
      }
      return z[t4];
    }
    function B(e3, t4) {
      var n3;
      return e3 && (n3 = l2(t4) ? V(e3) : An(e3, t4), n3 ? wn = n3 : typeof console < `u` && console.warn && console.warn(`Locale ` + e3 + ` not found. Did you forget to load it?`)), wn._abbr;
    }
    function An(e3, t4) {
      if (t4 !== null) {
        var n3, r3 = Sn;
        if (t4.abbr = e3, z[e3] != null) le(`defineLocaleOverride`, `use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info.`), r3 = z[e3]._config;
        else if (t4.parentLocale != null) {
          if (z[t4.parentLocale] != null) r3 = z[t4.parentLocale]._config;
          else if (n3 = kn(t4.parentLocale), n3 != null) r3 = n3._config;
          else return Cn[t4.parentLocale] || (Cn[t4.parentLocale] = []), Cn[t4.parentLocale].push({ name: e3, config: t4 }), null;
        }
        return z[e3] = new fe(de(r3, t4)), Cn[e3] && Cn[e3].forEach(function(e4) {
          An(e4.name, e4.config);
        }), B(e3), z[e3];
      }
      return delete z[e3], null;
    }
    function jn(e3, t4) {
      if (t4 != null) {
        var n3, r3, i3 = Sn;
        z[e3] != null && z[e3].parentLocale != null ? z[e3].set(de(z[e3]._config, t4)) : (r3 = kn(e3), r3 != null && (i3 = r3._config), t4 = de(i3, t4), r3 ?? (t4.abbr = e3), n3 = new fe(t4), n3.parentLocale = z[e3], z[e3] = n3), B(e3);
      } else z[e3] != null && (z[e3].parentLocale == null ? z[e3] != null && delete z[e3] : (z[e3] = z[e3].parentLocale, e3 === B() && B(e3)));
      return z[e3];
    }
    function V(e3) {
      var t4;
      if (e3 && e3._locale && e3._locale._abbr && (e3 = e3._locale._abbr), !e3) return wn;
      if (!a2(e3)) {
        if (t4 = kn(e3), t4) return t4;
        e3 = [e3];
      }
      return Dn(e3);
    }
    function Mn() {
      return pe(z);
    }
    function Nn(e3) {
      var t4, n3 = e3._a;
      return n3 && h2(e3).overflow === -2 && (t4 = n3[j] < 0 || n3[j] > 11 ? j : n3[M] < 1 || n3[M] > yt(n3[A], n3[j]) ? M : n3[N] < 0 || n3[N] > 24 || n3[N] === 24 && (n3[P] !== 0 || n3[F] !== 0 || n3[I] !== 0) ? N : n3[P] < 0 || n3[P] > 59 ? P : n3[F] < 0 || n3[F] > 59 ? F : n3[I] < 0 || n3[I] > 999 ? I : -1, h2(e3)._overflowDayOfYear && (t4 < A || t4 > M) && (t4 = M), h2(e3)._overflowWeeks && t4 === -1 && (t4 = ct), h2(e3)._overflowWeekday && t4 === -1 && (t4 = lt), h2(e3).overflow = t4), e3;
    }
    var Pn = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/, Fn = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d|))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/, In = /Z|[+-]\d\d(?::?\d\d)?/, Ln = [[`YYYYYY-MM-DD`, /[+-]\d{6}-\d\d-\d\d/], [`YYYY-MM-DD`, /\d{4}-\d\d-\d\d/], [`GGGG-[W]WW-E`, /\d{4}-W\d\d-\d/], [`GGGG-[W]WW`, /\d{4}-W\d\d/, false], [`YYYY-DDD`, /\d{4}-\d{3}/], [`YYYY-MM`, /\d{4}-\d\d/, false], [`YYYYYYMMDD`, /[+-]\d{10}/], [`YYYYMMDD`, /\d{8}/], [`GGGG[W]WWE`, /\d{4}W\d{3}/], [`GGGG[W]WW`, /\d{4}W\d{2}/, false], [`YYYYDDD`, /\d{7}/], [`YYYYMM`, /\d{6}/, false], [`YYYY`, /\d{4}/, false]], Rn = [[`HH:mm:ss.SSSS`, /\d\d:\d\d:\d\d\.\d+/], [`HH:mm:ss,SSSS`, /\d\d:\d\d:\d\d,\d+/], [`HH:mm:ss`, /\d\d:\d\d:\d\d/], [`HH:mm`, /\d\d:\d\d/], [`HHmmss.SSSS`, /\d\d\d\d\d\d\.\d+/], [`HHmmss,SSSS`, /\d\d\d\d\d\d,\d+/], [`HHmmss`, /\d\d\d\d\d\d/], [`HHmm`, /\d\d\d\d/], [`HH`, /\d\d/]], zn = /^\/?Date\((-?\d+)/i, Bn = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|([+-]\d{4}))$/, Vn = { UT: 0, GMT: 0, EDT: -240, EST: -300, CDT: -300, CST: -360, MDT: -360, MST: -420, PDT: -420, PST: -480 };
    function Hn(e3) {
      var t4, n3, r3 = e3._i, i3 = Pn.exec(r3) || Fn.exec(r3), a3, o3, s3, c3, l3 = Ln.length, u3 = Rn.length;
      if (i3) {
        for (h2(e3).iso = true, t4 = 0, n3 = l3; t4 < n3; t4++) if (Ln[t4][1].exec(i3[1])) {
          o3 = Ln[t4][0], a3 = Ln[t4][2] !== false;
          break;
        }
        if (o3 == null) {
          e3._isValid = false;
          return;
        }
        if (i3[3]) {
          for (t4 = 0, n3 = u3; t4 < n3; t4++) if (Rn[t4][1].exec(i3[3])) {
            s3 = (i3[2] || ` `) + Rn[t4][0];
            break;
          }
          if (s3 == null) {
            e3._isValid = false;
            return;
          }
        }
        if (!a3 && s3 != null) {
          e3._isValid = false;
          return;
        }
        if (i3[4]) {
          if (In.exec(i3[4])) c3 = `Z`;
          else {
            e3._isValid = false;
            return;
          }
        }
        e3._f = o3 + (s3 || ``) + (c3 || ``), er(e3);
      } else e3._isValid = false;
    }
    function Un(e3, t4, n3, r3, i3, a3) {
      var o3 = [Wn(e3), xt.indexOf(t4), parseInt(n3, 10), parseInt(r3, 10), parseInt(i3, 10)];
      return a3 && o3.push(parseInt(a3, 10)), o3;
    }
    function Wn(e3) {
      var t4 = parseInt(e3, 10);
      return t4 <= 49 ? 2e3 + t4 : t4 <= 999 ? 1900 + t4 : t4;
    }
    function Gn(e3) {
      return e3.replace(/\([^()]*\)|[\n\t]/g, ` `).replace(/(\s\s+)/g, ` `).replace(/^\s\s*/, ``).replace(/\s\s*$/, ``);
    }
    function Kn(e3, t4, n3) {
      return e3 && Xt.indexOf(e3) !== new Date(t4[0], t4[1], t4[2]).getDay() ? (h2(n3).weekdayMismatch = true, n3._isValid = false, false) : true;
    }
    function qn(e3, t4, n3) {
      if (e3) return Vn[e3];
      if (t4) return 0;
      var r3 = parseInt(n3, 10), i3 = r3 % 100;
      return (r3 - i3) / 100 * 60 + i3;
    }
    function Jn(e3) {
      var t4 = Bn.exec(Gn(e3._i)), n3;
      if (t4) {
        if (n3 = Un(t4[4], t4[3], t4[2], t4[5], t4[6], t4[7]), !Kn(t4[1], n3, e3)) return;
        e3._a = n3, e3._tzm = qn(t4[8], t4[9], t4[10]), e3._d = It.apply(null, e3._a), e3._d.setUTCMinutes(e3._d.getUTCMinutes() - e3._tzm), h2(e3).rfc2822 = true;
      } else e3._isValid = false;
    }
    function Yn(e3) {
      var t4 = zn.exec(e3._i);
      if (t4 !== null) {
        e3._d = /* @__PURE__ */ new Date(+t4[1]);
        return;
      }
      if (Hn(e3), e3._isValid === false) delete e3._isValid;
      else return;
      if (Jn(e3), e3._isValid === false) delete e3._isValid;
      else return;
      e3._strict ? e3._isValid = false : r2.createFromInputFallback(e3);
    }
    r2.createFromInputFallback = v(`value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.`, function(e3) {
      e3._d = /* @__PURE__ */ new Date(e3._i + (e3._useUTC ? ` UTC` : ``));
    });
    function Xn(e3, t4, n3) {
      return e3 ?? t4 ?? n3;
    }
    function Zn(e3) {
      var t4 = new Date(r2.now());
      return e3._useUTC ? [t4.getUTCFullYear(), t4.getUTCMonth(), t4.getUTCDate()] : [t4.getFullYear(), t4.getMonth(), t4.getDate()];
    }
    function Qn(e3) {
      var t4, n3, r3 = [], i3, a3, o3;
      if (!e3._d) {
        for (i3 = Zn(e3), e3._w && e3._a[M] == null && e3._a[j] == null && $n(e3), e3._dayOfYear != null && (o3 = Xn(e3._a[A], i3[A]), (e3._dayOfYear > ut(o3) || e3._dayOfYear === 0) && (h2(e3)._overflowDayOfYear = true), n3 = It(o3, 0, e3._dayOfYear), e3._a[j] = n3.getUTCMonth(), e3._a[M] = n3.getUTCDate()), t4 = 0; t4 < 3 && e3._a[t4] == null; ++t4) e3._a[t4] = r3[t4] = i3[t4];
        for (; t4 < 7; t4++) e3._a[t4] = r3[t4] = e3._a[t4] == null ? +(t4 === 2) : e3._a[t4];
        e3._a[N] === 24 && e3._a[P] === 0 && e3._a[F] === 0 && e3._a[I] === 0 && (e3._nextDay = true, e3._a[N] = 0), e3._d = (e3._useUTC ? It : Ft).apply(null, r3), a3 = e3._useUTC ? e3._d.getUTCDay() : e3._d.getDay(), e3._tzm != null && e3._d.setUTCMinutes(e3._d.getUTCMinutes() - e3._tzm), e3._nextDay && (e3._a[N] = 24), e3._w && e3._w.d !== void 0 && e3._w.d !== a3 && (h2(e3).weekdayMismatch = true);
      }
    }
    function $n(e3) {
      var t4 = e3._w, n3, r3, i3, a3, o3, s3, c3, l3;
      t4.GG != null || t4.W != null || t4.E != null ? (a3 = 1, o3 = 4, n3 = Xn(t4.GG, e3._a[A], zt(H(), 1, 4).year), r3 = Xn(t4.W, 1), i3 = Xn(t4.E, 1), (i3 < 1 || i3 > 7) && (c3 = true)) : (a3 = e3._locale._week.dow, o3 = e3._locale._week.doy, l3 = zt(H(), a3, o3), n3 = Xn(t4.gg, e3._a[A], l3.year), r3 = Xn(t4.w, l3.week), t4.d == null ? t4.e == null ? i3 = a3 : (i3 = t4.e + a3, (t4.e < 0 || t4.e > 6) && (c3 = true)) : (i3 = t4.d, (i3 < 0 || i3 > 6) && (c3 = true))), r3 < 1 || r3 > R(n3, a3, o3) ? h2(e3)._overflowWeeks = true : c3 == null ? (s3 = Rt(n3, r3, i3, a3, o3), e3._a[A] = s3.year, e3._dayOfYear = s3.dayOfYear) : h2(e3)._overflowWeekday = true;
    }
    r2.ISO_8601 = function() {
    }, r2.RFC_2822 = function() {
    };
    function er(e3) {
      if (e3._f === r2.ISO_8601) {
        Hn(e3);
        return;
      }
      if (e3._f === r2.RFC_2822) {
        Jn(e3);
        return;
      }
      e3._a = [], h2(e3).empty = true;
      var t4 = `` + e3._i, n3, i3, a3, o3, s3, c3 = t4.length, l3 = 0, u3, d3;
      for (a3 = Ce(e3._f, e3._locale).match(ge) || [], d3 = a3.length, n3 = 0; n3 < d3; n3++) o3 = a3[n3], i3 = (t4.match(nt(o3, e3)) || [])[0], i3 && (s3 = t4.substr(0, t4.indexOf(i3)), s3.length > 0 && h2(e3).unusedInput.push(s3), t4 = t4.slice(t4.indexOf(i3) + i3.length), l3 += i3.length), ye[o3] ? (i3 ? h2(e3).empty = false : h2(e3).unusedTokens.push(o3), ot(o3, i3, e3)) : e3._strict && !i3 && h2(e3).unusedTokens.push(o3);
      h2(e3).charsLeftOver = c3 - l3, t4.length > 0 && h2(e3).unusedInput.push(t4), e3._a[N] <= 12 && h2(e3).bigHour === true && e3._a[N] > 0 && (h2(e3).bigHour = void 0), h2(e3).parsedDateParts = e3._a.slice(0), h2(e3).meridiem = e3._meridiem, e3._a[N] = tr(e3._locale, e3._a[N], e3._meridiem), u3 = h2(e3).era, u3 !== null && (e3._a[A] = e3._locale.erasConvertYear(u3, e3._a[A])), Qn(e3), Nn(e3);
    }
    function tr(e3, t4, n3) {
      var r3;
      return n3 == null ? t4 : e3.meridiemHour == null ? e3.isPM == null ? t4 : (r3 = e3.isPM(n3), r3 && t4 < 12 && (t4 += 12), !r3 && t4 === 12 && (t4 = 0), t4) : e3.meridiemHour(t4, n3);
    }
    function nr(e3) {
      var t4, n3, r3, i3, a3, o3, s3 = false, c3 = e3._f.length;
      if (c3 === 0) {
        h2(e3).invalidFormat = true, e3._d = /* @__PURE__ */ new Date(NaN);
        return;
      }
      for (i3 = 0; i3 < c3; i3++) a3 = 0, o3 = false, t4 = oe2({}, e3), e3._useUTC != null && (t4._useUTC = e3._useUTC), t4._f = e3._f[i3], er(t4), ne2(t4) && (o3 = true), a3 += h2(t4).charsLeftOver, a3 += h2(t4).unusedTokens.length * 10, h2(t4).score = a3, s3 ? a3 < r3 && (r3 = a3, n3 = t4) : (r3 == null || a3 < r3 || o3) && (r3 = a3, n3 = t4, o3 && (s3 = true));
      p2(e3, n3 || t4);
    }
    function rr(e3) {
      if (!e3._d) {
        var t4 = Fe(e3._i), n3 = t4.day === void 0 ? t4.date : t4.day;
        e3._a = f2([t4.year, t4.month, n3, t4.hour, t4.minute, t4.second, t4.millisecond], function(e4) {
          return e4 && parseInt(e4, 10);
        }), Qn(e3);
      }
    }
    function ir(e3) {
      var t4 = new g2(Nn(ar(e3)));
      return t4._nextDay && (t4._nextDay = (t4.add(1, `d`), void 0)), t4;
    }
    function ar(e3) {
      var t4 = e3._i, n3 = e3._f;
      return e3._locale = e3._locale || V(e3._l), t4 === null || n3 === void 0 && t4 === `` ? re2({ nullInput: true }) : (typeof t4 == `string` && (e3._i = t4 = e3._locale.preparse(t4)), _2(t4) ? new g2(Nn(t4)) : (d2(t4) ? e3._d = t4 : a2(n3) ? nr(e3) : n3 ? er(e3) : or(e3), ne2(e3) || (e3._d = null), e3));
    }
    function or(e3) {
      var t4 = e3._i;
      l2(t4) ? e3._d = new Date(r2.now()) : d2(t4) ? e3._d = new Date(t4.valueOf()) : typeof t4 == `string` ? Yn(e3) : a2(t4) ? (e3._a = f2(t4.slice(0), function(e4) {
        return parseInt(e4, 10);
      }), Qn(e3)) : o2(t4) ? rr(e3) : u2(t4) ? e3._d = new Date(t4) : r2.createFromInputFallback(e3);
    }
    function sr(e3, t4, n3, r3, i3) {
      var s3 = {};
      return (t4 === true || t4 === false) && (r3 = t4, t4 = void 0), (n3 === true || n3 === false) && (r3 = n3, n3 = void 0), (o2(e3) && c2(e3) || a2(e3) && e3.length === 0) && (e3 = void 0), s3._isAMomentObject = true, s3._useUTC = s3._isUTC = i3, s3._l = n3, s3._i = e3, s3._f = t4, s3._strict = r3, ir(s3);
    }
    function H(e3, t4, n3, r3) {
      return sr(e3, t4, n3, r3, false);
    }
    var cr = v(`moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/`, function() {
      var e3 = H.apply(null, arguments);
      return this.isValid() && e3.isValid() ? e3 < this ? this : e3 : re2();
    }), lr = v(`moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/`, function() {
      var e3 = H.apply(null, arguments);
      return this.isValid() && e3.isValid() ? e3 > this ? this : e3 : re2();
    });
    function ur(e3, t4) {
      var n3, r3;
      if (t4.length === 1 && a2(t4[0]) && (t4 = t4[0]), !t4.length) return H();
      for (n3 = t4[0], r3 = 1; r3 < t4.length; ++r3) (!t4[r3].isValid() || t4[r3][e3](n3)) && (n3 = t4[r3]);
      return n3;
    }
    function dr() {
      return ur(`isBefore`, [].slice.call(arguments, 0));
    }
    function fr() {
      return ur(`isAfter`, [].slice.call(arguments, 0));
    }
    var pr = function() {
      return Date.now ? Date.now() : +/* @__PURE__ */ new Date();
    }, mr = [`year`, `quarter`, `month`, `week`, `day`, `hour`, `minute`, `second`, `millisecond`];
    function hr(e3) {
      var t4, n3 = false, r3, i3 = mr.length;
      for (t4 in e3) if (s2(e3, t4) && (L.call(mr, t4) === -1 || e3[t4] != null && isNaN(e3[t4]))) return false;
      for (r3 = 0; r3 < i3; ++r3) if (e3[mr[r3]]) {
        if (n3) return false;
        parseFloat(e3[mr[r3]]) !== O(e3[mr[r3]]) && (n3 = true);
      }
      return true;
    }
    function gr() {
      return this._isValid;
    }
    function _r() {
      return U(NaN);
    }
    function vr(e3) {
      var t4 = Fe(e3), n3 = t4.year || 0, r3 = t4.quarter || 0, i3 = t4.month || 0, a3 = t4.week || t4.isoWeek || 0, o3 = t4.day || 0, s3 = t4.hour || 0, c3 = t4.minute || 0, l3 = t4.second || 0, u3 = t4.millisecond || 0;
      this._isValid = hr(t4), this._milliseconds = +u3 + l3 * 1e3 + c3 * 6e4 + s3 * 1e3 * 60 * 60, this._days = +o3 + a3 * 7, this._months = +i3 + r3 * 3 + n3 * 12, this._data = {}, this._locale = V(), this._bubble();
    }
    function yr(e3) {
      return e3 instanceof vr;
    }
    function br(e3) {
      return e3 < 0 ? Math.round(-1 * e3) * -1 : Math.round(e3);
    }
    function xr(e3, t4, n3) {
      for (var r3 = Math.min(e3.length, t4.length), i3 = Math.abs(e3.length - t4.length), a3 = 0, o3 = 0; o3 < r3; o3++) (n3 && e3[o3] !== t4[o3] || !n3 && O(e3[o3]) !== O(t4[o3])) && a3++;
      return a3 + i3;
    }
    function Sr(e3, t4) {
      x(e3, 0, 0, function() {
        var e4 = this.utcOffset(), n3 = `+`;
        return e4 < 0 && (e4 = -e4, n3 = `-`), n3 + b(~~(e4 / 60), 2) + t4 + b(~~e4 % 60, 2);
      });
    }
    Sr(`Z`, `:`), Sr(`ZZ`, ``), T(`Z`, Xe), T(`ZZ`, Xe), k([`Z`, `ZZ`], function(e3, t4, n3) {
      n3._useUTC = true, n3._tzm = wr(Xe, e3);
    });
    var Cr = /([\+\-]|\d\d)/gi;
    function wr(e3, t4) {
      var n3 = (t4 || ``).match(e3), r3, i3, a3;
      return n3 === null ? null : (r3 = n3[n3.length - 1] || [], i3 = (r3 + ``).match(Cr) || [`-`, 0, 0], a3 = +(i3[1] * 60) + O(i3[2]), a3 === 0 ? 0 : i3[0] === `+` ? a3 : -a3);
    }
    function Tr(e3, t4) {
      var n3, i3;
      return t4._isUTC ? (n3 = t4.clone(), i3 = (_2(e3) || d2(e3) ? e3.valueOf() : H(e3).valueOf()) - n3.valueOf(), n3._d.setTime(n3._d.valueOf() + i3), r2.updateOffset(n3, false), n3) : H(e3).local();
    }
    function Er(e3) {
      return -Math.round(e3._d.getTimezoneOffset());
    }
    r2.updateOffset = function() {
    };
    function Dr(e3, t4, n3) {
      var i3 = this._offset || 0, a3;
      if (!this.isValid()) return e3 == null ? NaN : this;
      if (e3 != null) {
        if (typeof e3 == `string`) {
          if (e3 = wr(Xe, e3), e3 === null) return this;
        } else Math.abs(e3) < 16 && !n3 && (e3 *= 60);
        return !this._isUTC && t4 && (a3 = Er(this)), this._offset = e3, this._isUTC = true, a3 != null && this.add(a3, `m`), i3 !== e3 && (!t4 || this._changeInProgress ? Ur(this, U(e3 - i3, `m`), 1, false) : this._changeInProgress || (this._changeInProgress = (this._changeInProgress = true, r2.updateOffset(this, true), null))), this;
      }
      return this._isUTC ? i3 : Er(this);
    }
    function Or(e3, t4) {
      return e3 == null ? -this.utcOffset() : (typeof e3 != `string` && (e3 = -e3), this.utcOffset(e3, t4), this);
    }
    function kr(e3) {
      return this.utcOffset(0, e3);
    }
    function Ar(e3) {
      return this._isUTC && (this.utcOffset(0, e3), this._isUTC = false, e3 && this.subtract(Er(this), `m`)), this;
    }
    function jr() {
      if (this._tzm != null) this.utcOffset(this._tzm, false, true);
      else if (typeof this._i == `string`) {
        var e3 = wr(Ye, this._i);
        e3 == null ? this.utcOffset(0, true) : this.utcOffset(e3);
      }
      return this;
    }
    function Mr(e3) {
      return this.isValid() ? (e3 = e3 ? H(e3).utcOffset() : 0, (this.utcOffset() - e3) % 60 == 0) : false;
    }
    function Nr() {
      return this.utcOffset() > this.clone().month(0).utcOffset() || this.utcOffset() > this.clone().month(5).utcOffset();
    }
    function Pr() {
      if (!l2(this._isDSTShifted)) return this._isDSTShifted;
      var e3 = {}, t4;
      return oe2(e3, this), e3 = ar(e3), e3._a ? (t4 = e3._isUTC ? m2(e3._a) : H(e3._a), this._isDSTShifted = this.isValid() && xr(e3._a, t4.toArray()) > 0) : this._isDSTShifted = false, this._isDSTShifted;
    }
    function Fr() {
      return this.isValid() ? !this._isUTC : false;
    }
    function Ir() {
      return this.isValid() ? this._isUTC : false;
    }
    function Lr() {
      return this.isValid() ? this._isUTC && this._offset === 0 : false;
    }
    var Rr = /^(-|\+)?(?:(\d*)[. ])?(\d+):(\d+)(?::(\d+)(\.\d*)?)?$/, zr = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;
    function U(e3, t4) {
      var n3 = e3, r3 = null, i3, a3, o3;
      return yr(e3) ? n3 = { ms: e3._milliseconds, d: e3._days, M: e3._months } : u2(e3) || !isNaN(+e3) ? (n3 = {}, t4 ? n3[t4] = +e3 : n3.milliseconds = +e3) : (r3 = Rr.exec(e3)) ? (i3 = r3[1] === `-` ? -1 : 1, n3 = { y: 0, d: O(r3[M]) * i3, h: O(r3[N]) * i3, m: O(r3[P]) * i3, s: O(r3[F]) * i3, ms: O(br(r3[I] * 1e3)) * i3 }) : (r3 = zr.exec(e3)) ? (i3 = r3[1] === `-` ? -1 : 1, n3 = { y: W(r3[2], i3), M: W(r3[3], i3), w: W(r3[4], i3), d: W(r3[5], i3), h: W(r3[6], i3), m: W(r3[7], i3), s: W(r3[8], i3) }) : n3 == null ? n3 = {} : typeof n3 == `object` && (`from` in n3 || `to` in n3) && (o3 = Vr(H(n3.from), H(n3.to)), n3 = {}, n3.ms = o3.milliseconds, n3.M = o3.months), a3 = new vr(n3), yr(e3) && s2(e3, `_locale`) && (a3._locale = e3._locale), yr(e3) && s2(e3, `_isValid`) && (a3._isValid = e3._isValid), a3;
    }
    U.fn = vr.prototype, U.invalid = _r;
    function W(e3, t4) {
      var n3 = e3 && parseFloat(e3.replace(`,`, `.`));
      return (isNaN(n3) ? 0 : n3) * t4;
    }
    function Br(e3, t4) {
      var n3 = {};
      return n3.months = t4.month() - e3.month() + (t4.year() - e3.year()) * 12, e3.clone().add(n3.months, `M`).isAfter(t4) && --n3.months, n3.milliseconds = +t4 - e3.clone().add(n3.months, `M`), n3;
    }
    function Vr(e3, t4) {
      var n3;
      return e3.isValid() && t4.isValid() ? (t4 = Tr(t4, e3), e3.isBefore(t4) ? n3 = Br(e3, t4) : (n3 = Br(t4, e3), n3.milliseconds = -n3.milliseconds, n3.months = -n3.months), n3) : { milliseconds: 0, months: 0 };
    }
    function Hr(e3, t4) {
      return function(n3, r3) {
        var i3, a3;
        return r3 !== null && !isNaN(+r3) && (le(t4, `moment().` + t4 + `(period, number) is deprecated. Please use moment().` + t4 + `(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info.`), a3 = n3, n3 = r3, r3 = a3), i3 = U(n3, r3), Ur(this, i3, e3), this;
      };
    }
    function Ur(e3, t4, n3, i3) {
      var a3 = t4._milliseconds, o3 = br(t4._days), s3 = br(t4._months);
      e3.isValid() && (i3 ?? (i3 = true), s3 && kt(e3, mt(e3, `Month`) + s3 * n3), o3 && ht(e3, `Date`, mt(e3, `Date`) + o3 * n3), a3 && e3._d.setTime(e3._d.valueOf() + a3 * n3), i3 && r2.updateOffset(e3, o3 || s3));
    }
    var Wr = Hr(1, `add`), Gr = Hr(-1, `subtract`);
    function Kr(e3) {
      return typeof e3 == `string` || e3 instanceof String;
    }
    function qr(e3) {
      return _2(e3) || d2(e3) || Kr(e3) || u2(e3) || Yr(e3) || Jr(e3) || e3 == null;
    }
    function Jr(e3) {
      var t4 = o2(e3) && !c2(e3), n3 = false, r3 = [`years`, `year`, `y`, `months`, `month`, `M`, `days`, `day`, `d`, `dates`, `date`, `D`, `hours`, `hour`, `h`, `minutes`, `minute`, `m`, `seconds`, `second`, `s`, `milliseconds`, `millisecond`, `ms`], i3, a3, l3 = r3.length;
      for (i3 = 0; i3 < l3; i3 += 1) a3 = r3[i3], n3 || (n3 = s2(e3, a3));
      return t4 && n3;
    }
    function Yr(e3) {
      var t4 = a2(e3), n3 = false;
      return t4 && (n3 = e3.filter(function(t5) {
        return !u2(t5) && Kr(e3);
      }).length === 0), t4 && n3;
    }
    function Xr(e3) {
      for (var t4 = o2(e3) && !c2(e3), n3 = false, r3 = [`sameDay`, `nextDay`, `lastDay`, `nextWeek`, `lastWeek`, `sameElse`], i3 = 0, a3; i3 < r3.length; i3 += 1) a3 = r3[i3], n3 || (n3 = s2(e3, a3));
      return t4 && n3;
    }
    function Zr(e3, t4) {
      var n3 = e3.diff(t4, `days`, true);
      return n3 < -6 ? `sameElse` : n3 < -1 ? `lastWeek` : n3 < 0 ? `lastDay` : n3 < 1 ? `sameDay` : n3 < 2 ? `nextDay` : n3 < 7 ? `nextWeek` : `sameElse`;
    }
    function Qr(e3, t4) {
      arguments.length === 1 && (arguments[0] ? qr(arguments[0]) ? (e3 = arguments[0], t4 = void 0) : Xr(arguments[0]) && (t4 = arguments[0], e3 = void 0) : (e3 = void 0, t4 = void 0));
      var n3 = e3 || H(), i3 = Tr(n3, this).startOf(`day`), a3 = r2.calendarFormat(this, i3) || `sameElse`, o3 = t4 && (y(t4[a3]) ? t4[a3].call(this, n3) : t4[a3]);
      return this.format(o3 || this.localeData().calendar(a3, this, H(n3)));
    }
    function $r() {
      return new g2(this);
    }
    function ei(e3, t4) {
      var n3 = _2(e3) ? e3 : H(e3);
      return this.isValid() && n3.isValid() ? (t4 = S(t4) || `millisecond`, t4 === `millisecond` ? this.valueOf() > n3.valueOf() : n3.valueOf() < this.clone().startOf(t4).valueOf()) : false;
    }
    function ti(e3, t4) {
      var n3 = _2(e3) ? e3 : H(e3);
      return this.isValid() && n3.isValid() ? (t4 = S(t4) || `millisecond`, t4 === `millisecond` ? this.valueOf() < n3.valueOf() : this.clone().endOf(t4).valueOf() < n3.valueOf()) : false;
    }
    function ni(e3, t4, n3, r3) {
      var i3 = _2(e3) ? e3 : H(e3), a3 = _2(t4) ? t4 : H(t4);
      return this.isValid() && i3.isValid() && a3.isValid() ? (r3 || (r3 = `()`), (r3[0] === `(` ? this.isAfter(i3, n3) : !this.isBefore(i3, n3)) && (r3[1] === `)` ? this.isBefore(a3, n3) : !this.isAfter(a3, n3))) : false;
    }
    function ri(e3, t4) {
      var n3 = _2(e3) ? e3 : H(e3), r3;
      return this.isValid() && n3.isValid() ? (t4 = S(t4) || `millisecond`, t4 === `millisecond` ? this.valueOf() === n3.valueOf() : (r3 = n3.valueOf(), this.clone().startOf(t4).valueOf() <= r3 && r3 <= this.clone().endOf(t4).valueOf())) : false;
    }
    function ii(e3, t4) {
      return this.isSame(e3, t4) || this.isAfter(e3, t4);
    }
    function ai(e3, t4) {
      return this.isSame(e3, t4) || this.isBefore(e3, t4);
    }
    function oi(e3, t4, n3) {
      var r3, i3, a3;
      if (!this.isValid() || (r3 = Tr(e3, this), !r3.isValid())) return NaN;
      switch (i3 = (r3.utcOffset() - this.utcOffset()) * 6e4, t4 = S(t4), t4) {
        case `year`:
          a3 = si(this, r3) / 12;
          break;
        case `month`:
          a3 = si(this, r3);
          break;
        case `quarter`:
          a3 = si(this, r3) / 3;
          break;
        case `second`:
          a3 = (this - r3) / 1e3;
          break;
        case `minute`:
          a3 = (this - r3) / 6e4;
          break;
        case `hour`:
          a3 = (this - r3) / 36e5;
          break;
        case `day`:
          a3 = (this - r3 - i3) / 864e5;
          break;
        case `week`:
          a3 = (this - r3 - i3) / 6048e5;
          break;
        default:
          a3 = this - r3;
      }
      return n3 ? a3 : D(a3);
    }
    function si(e3, t4) {
      if (e3.date() < t4.date()) return -si(t4, e3);
      var n3 = (t4.year() - e3.year()) * 12 + (t4.month() - e3.month()), r3 = e3.clone().add(n3, `months`), i3, a3;
      return t4 - r3 < 0 ? (i3 = e3.clone().add(n3 - 1, `months`), a3 = (t4 - r3) / (r3 - i3)) : (i3 = e3.clone().add(n3 + 1, `months`), a3 = (t4 - r3) / (i3 - r3)), -(n3 + a3) || 0;
    }
    r2.defaultFormat = `YYYY-MM-DDTHH:mm:ssZ`, r2.defaultFormatUtc = `YYYY-MM-DDTHH:mm:ss[Z]`;
    function ci() {
      return this.clone().locale(`en`).format(`ddd MMM DD YYYY HH:mm:ss [GMT]ZZ`);
    }
    function li(e3) {
      if (!this.isValid()) return null;
      var t4 = e3 !== true, n3 = t4 ? this.clone().utc() : this;
      return n3.year() < 0 || n3.year() > 9999 ? Se(n3, t4 ? `YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]` : `YYYYYY-MM-DD[T]HH:mm:ss.SSSZ`) : y(Date.prototype.toISOString) ? t4 ? this.toDate().toISOString() : new Date(this.valueOf() + this.utcOffset() * 60 * 1e3).toISOString().replace(`Z`, Se(n3, `Z`)) : Se(n3, t4 ? `YYYY-MM-DD[T]HH:mm:ss.SSS[Z]` : `YYYY-MM-DD[T]HH:mm:ss.SSSZ`);
    }
    function ui() {
      if (!this.isValid()) return `moment.invalid(/* ` + this._i + ` */)`;
      var e3 = `moment`, t4 = ``, n3, r3, i3, a3;
      return this.isLocal() || (e3 = this.utcOffset() === 0 ? `moment.utc` : `moment.parseZone`, t4 = `Z`), n3 = `[` + e3 + `("]`, r3 = 0 <= this.year() && this.year() <= 9999 ? `YYYY` : `YYYYYY`, i3 = `-MM-DD[T]HH:mm:ss.SSS`, a3 = t4 + `[")]`, this.format(n3 + r3 + i3 + a3);
    }
    function di(e3) {
      e3 || (e3 = this.isUtc() ? r2.defaultFormatUtc : r2.defaultFormat);
      var t4 = Se(this, e3);
      return this.localeData().postformat(t4);
    }
    function fi(e3, t4) {
      return this.isValid() && (_2(e3) && e3.isValid() || H(e3).isValid()) ? U({ to: this, from: e3 }).locale(this.locale()).humanize(!t4) : this.localeData().invalidDate();
    }
    function pi(e3) {
      return this.from(H(), e3);
    }
    function mi(e3, t4) {
      return this.isValid() && (_2(e3) && e3.isValid() || H(e3).isValid()) ? U({ from: this, to: e3 }).locale(this.locale()).humanize(!t4) : this.localeData().invalidDate();
    }
    function hi(e3) {
      return this.to(H(), e3);
    }
    function gi(e3) {
      var t4;
      return e3 === void 0 ? this._locale._abbr : (t4 = V(e3), t4 != null && (this._locale = t4), this);
    }
    var _i = v(`moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.`, function(e3) {
      return e3 === void 0 ? this.localeData() : this.locale(e3);
    });
    function vi() {
      return this._locale;
    }
    var yi = 1e3, bi = 60 * yi, xi = 60 * bi, Si = 3506328 * xi;
    function Ci(e3, t4) {
      return (e3 % t4 + t4) % t4;
    }
    function wi(e3, t4, n3) {
      return e3 < 100 && e3 >= 0 ? new Date(e3 + 400, t4, n3) - Si : new Date(e3, t4, n3).valueOf();
    }
    function Ti(e3, t4, n3) {
      return e3 < 100 && e3 >= 0 ? Date.UTC(e3 + 400, t4, n3) - Si : Date.UTC(e3, t4, n3);
    }
    function Ei(e3) {
      var t4, n3;
      if (e3 = S(e3), e3 === void 0 || e3 === `millisecond` || !this.isValid()) return this;
      switch (n3 = this._isUTC ? Ti : wi, e3) {
        case `year`:
          t4 = n3(this.year(), 0, 1);
          break;
        case `quarter`:
          t4 = n3(this.year(), this.month() - this.month() % 3, 1);
          break;
        case `month`:
          t4 = n3(this.year(), this.month(), 1);
          break;
        case `week`:
          t4 = n3(this.year(), this.month(), this.date() - this.weekday());
          break;
        case `isoWeek`:
          t4 = n3(this.year(), this.month(), this.date() - (this.isoWeekday() - 1));
          break;
        case `day`:
        case `date`:
          t4 = n3(this.year(), this.month(), this.date());
          break;
        case `hour`:
          t4 = this._d.valueOf(), t4 -= Ci(t4 + (this._isUTC ? 0 : this.utcOffset() * bi), xi);
          break;
        case `minute`:
          t4 = this._d.valueOf(), t4 -= Ci(t4, bi);
          break;
        case `second`:
          t4 = this._d.valueOf(), t4 -= Ci(t4, yi);
      }
      return this._d.setTime(t4), r2.updateOffset(this, true), this;
    }
    function Di(e3) {
      var t4, n3;
      if (e3 = S(e3), e3 === void 0 || e3 === `millisecond` || !this.isValid()) return this;
      switch (n3 = this._isUTC ? Ti : wi, e3) {
        case `year`:
          t4 = n3(this.year() + 1, 0, 1) - 1;
          break;
        case `quarter`:
          t4 = n3(this.year(), this.month() - this.month() % 3 + 3, 1) - 1;
          break;
        case `month`:
          t4 = n3(this.year(), this.month() + 1, 1) - 1;
          break;
        case `week`:
          t4 = n3(this.year(), this.month(), this.date() - this.weekday() + 7) - 1;
          break;
        case `isoWeek`:
          t4 = n3(this.year(), this.month(), this.date() - (this.isoWeekday() - 1) + 7) - 1;
          break;
        case `day`:
        case `date`:
          t4 = n3(this.year(), this.month(), this.date() + 1) - 1;
          break;
        case `hour`:
          t4 = this._d.valueOf(), t4 += xi - Ci(t4 + (this._isUTC ? 0 : this.utcOffset() * bi), xi) - 1;
          break;
        case `minute`:
          t4 = this._d.valueOf(), t4 += bi - Ci(t4, bi) - 1;
          break;
        case `second`:
          t4 = this._d.valueOf(), t4 += yi - Ci(t4, yi) - 1;
      }
      return this._d.setTime(t4), r2.updateOffset(this, true), this;
    }
    function Oi() {
      return this._d.valueOf() - (this._offset || 0) * 6e4;
    }
    function ki() {
      return Math.floor(this.valueOf() / 1e3);
    }
    function Ai() {
      return new Date(this.valueOf());
    }
    function ji() {
      var e3 = this;
      return [e3.year(), e3.month(), e3.date(), e3.hour(), e3.minute(), e3.second(), e3.millisecond()];
    }
    function Mi() {
      var e3 = this;
      return { years: e3.year(), months: e3.month(), date: e3.date(), hours: e3.hours(), minutes: e3.minutes(), seconds: e3.seconds(), milliseconds: e3.milliseconds() };
    }
    function Ni() {
      return this.isValid() ? this.toISOString() : null;
    }
    function Pi() {
      return ne2(this);
    }
    function Fi() {
      return p2({}, h2(this));
    }
    function Ii() {
      return h2(this).overflow;
    }
    function Li() {
      return { input: this._i, format: this._f, locale: this._locale, isUTC: this._isUTC, strict: this._strict };
    }
    x(`N`, 0, 0, `eraAbbr`), x(`NN`, 0, 0, `eraAbbr`), x(`NNN`, 0, 0, `eraAbbr`), x(`NNNN`, 0, 0, `eraName`), x(`NNNNN`, 0, 0, `eraNarrow`), x(`y`, [`y`, 1], `yo`, `eraYear`), x(`y`, [`yy`, 2], 0, `eraYear`), x(`y`, [`yyy`, 3], 0, `eraYear`), x(`y`, [`yyyy`, 4], 0, `eraYear`), T(`N`, Ji), T(`NN`, Ji), T(`NNN`, Ji), T(`NNNN`, Yi), T(`NNNNN`, Xi), k([`N`, `NN`, `NNN`, `NNNN`, `NNNNN`], function(e3, t4, n3, r3) {
      var i3 = n3._locale.erasParse(e3, r3, n3._strict);
      i3 ? h2(n3).era = i3 : h2(n3).invalidEra = e3;
    }), T(`y`, qe), T(`yy`, qe), T(`yyy`, qe), T(`yyyy`, qe), T(`yo`, Zi), k([`y`, `yy`, `yyy`, `yyyy`], A), k([`yo`], function(e3, t4, n3, r3) {
      var i3;
      n3._locale._eraYearOrdinalRegex && (i3 = e3.match(n3._locale._eraYearOrdinalRegex)), t4[A] = n3._locale.eraYearOrdinalParse ? n3._locale.eraYearOrdinalParse(e3, i3) : parseInt(e3, 10);
    });
    function Ri(e3, t4) {
      var n3, i3, a3, o3 = this._eras || V(`en`)._eras;
      for (n3 = 0, i3 = o3.length; n3 < i3; ++n3) switch (typeof o3[n3].since == `string` && (a3 = r2(o3[n3].since).startOf(`day`), o3[n3].since = a3.valueOf()), typeof o3[n3].until) {
        case `undefined`:
          o3[n3].until = 1 / 0;
          break;
        case `string`:
          a3 = r2(o3[n3].until).startOf(`day`).valueOf(), o3[n3].until = a3.valueOf();
      }
      return o3;
    }
    function zi(e3, t4, n3) {
      var r3, i3, a3 = this.eras(), o3, s3, c3;
      for (e3 = e3.toUpperCase(), r3 = 0, i3 = a3.length; r3 < i3; ++r3) if (o3 = a3[r3].name.toUpperCase(), s3 = a3[r3].abbr.toUpperCase(), c3 = a3[r3].narrow.toUpperCase(), n3) switch (t4) {
        case `N`:
        case `NN`:
        case `NNN`:
          if (s3 === e3) return a3[r3];
          break;
        case `NNNN`:
          if (o3 === e3) return a3[r3];
          break;
        case `NNNNN`:
          if (c3 === e3) return a3[r3];
      }
      else if ([o3, s3, c3].indexOf(e3) >= 0) return a3[r3];
    }
    function Bi(e3, t4) {
      var n3 = e3.since <= e3.until ? 1 : -1;
      return t4 === void 0 ? r2(e3.since).year() : r2(e3.since).year() + (t4 - e3.offset) * n3;
    }
    function Vi() {
      var e3, t4, n3, r3 = this.localeData().eras();
      for (e3 = 0, t4 = r3.length; e3 < t4; ++e3) if (n3 = this.clone().startOf(`day`).valueOf(), r3[e3].since <= n3 && n3 <= r3[e3].until || r3[e3].until <= n3 && n3 <= r3[e3].since) return r3[e3].name;
      return ``;
    }
    function Hi() {
      var e3, t4, n3, r3 = this.localeData().eras();
      for (e3 = 0, t4 = r3.length; e3 < t4; ++e3) if (n3 = this.clone().startOf(`day`).valueOf(), r3[e3].since <= n3 && n3 <= r3[e3].until || r3[e3].until <= n3 && n3 <= r3[e3].since) return r3[e3].narrow;
      return ``;
    }
    function Ui() {
      var e3, t4, n3, r3 = this.localeData().eras();
      for (e3 = 0, t4 = r3.length; e3 < t4; ++e3) if (n3 = this.clone().startOf(`day`).valueOf(), r3[e3].since <= n3 && n3 <= r3[e3].until || r3[e3].until <= n3 && n3 <= r3[e3].since) return r3[e3].abbr;
      return ``;
    }
    function Wi() {
      var e3, t4, n3, i3, a3 = this.localeData().eras();
      for (e3 = 0, t4 = a3.length; e3 < t4; ++e3) if (n3 = a3[e3].since <= a3[e3].until ? 1 : -1, i3 = this.clone().startOf(`day`).valueOf(), a3[e3].since <= i3 && i3 <= a3[e3].until || a3[e3].until <= i3 && i3 <= a3[e3].since) return (this.year() - r2(a3[e3].since).year()) * n3 + a3[e3].offset;
      return this.year();
    }
    function Gi(e3) {
      return s2(this, `_erasNameRegex`) || Qi.call(this), e3 ? this._erasNameRegex : this._erasRegex;
    }
    function Ki(e3) {
      return s2(this, `_erasAbbrRegex`) || Qi.call(this), e3 ? this._erasAbbrRegex : this._erasRegex;
    }
    function qi(e3) {
      return s2(this, `_erasNarrowRegex`) || Qi.call(this), e3 ? this._erasNarrowRegex : this._erasRegex;
    }
    function Ji(e3, t4) {
      return t4.erasAbbrRegex(e3);
    }
    function Yi(e3, t4) {
      return t4.erasNameRegex(e3);
    }
    function Xi(e3, t4) {
      return t4.erasNarrowRegex(e3);
    }
    function Zi(e3, t4) {
      return t4._eraYearOrdinalRegex || qe;
    }
    function Qi() {
      var e3 = [], t4 = [], n3 = [], r3 = [], i3, a3, o3, s3, c3, l3 = this.eras();
      for (i3 = 0, a3 = l3.length; i3 < a3; ++i3) o3 = E(l3[i3].name), s3 = E(l3[i3].abbr), c3 = E(l3[i3].narrow), t4.push(o3), e3.push(s3), n3.push(c3), r3.push(o3), r3.push(s3), r3.push(c3);
      this._erasRegex = RegExp(`^(` + r3.join(`|`) + `)`, `i`), this._erasNameRegex = RegExp(`^(` + t4.join(`|`) + `)`, `i`), this._erasAbbrRegex = RegExp(`^(` + e3.join(`|`) + `)`, `i`), this._erasNarrowRegex = RegExp(`^(` + n3.join(`|`) + `)`, `i`);
    }
    x(0, [`gg`, 2], 0, function() {
      return this.weekYear() % 100;
    }), x(0, [`GG`, 2], 0, function() {
      return this.isoWeekYear() % 100;
    });
    function $i(e3, t4) {
      x(0, [e3, e3.length], 0, t4);
    }
    $i(`gggg`, `weekYear`), $i(`ggggg`, `weekYear`), $i(`GGGG`, `isoWeekYear`), $i(`GGGGG`, `isoWeekYear`), T(`G`, Je), T(`g`, Je), T(`GG`, w, C), T(`gg`, w, C), T(`GGGG`, Ge, Be), T(`gggg`, Ge, Be), T(`GGGGG`, Ke, Ve), T(`ggggg`, Ke, Ve), at([`gggg`, `ggggg`, `GGGG`, `GGGGG`], function(e3, t4, n3, r3) {
      t4[r3.substr(0, 2)] = O(e3);
    }), at([`gg`, `GG`], function(e3, t4, n3, i3) {
      t4[i3] = r2.parseTwoDigitYear(e3);
    });
    function ea(e3) {
      return oa.call(this, e3, this.week(), this.weekday() + this.localeData()._week.dow, this.localeData()._week.dow, this.localeData()._week.doy);
    }
    function ta(e3) {
      return oa.call(this, e3, this.isoWeek(), this.isoWeekday(), 1, 4);
    }
    function na() {
      return R(this.year(), 1, 4);
    }
    function ra() {
      return R(this.isoWeekYear(), 1, 4);
    }
    function ia() {
      var e3 = this.localeData()._week;
      return R(this.year(), e3.dow, e3.doy);
    }
    function aa() {
      var e3 = this.localeData()._week;
      return R(this.weekYear(), e3.dow, e3.doy);
    }
    function oa(e3, t4, n3, r3, i3) {
      var a3;
      return e3 == null ? zt(this, r3, i3).year : (a3 = R(e3, r3, i3), t4 > a3 && (t4 = a3), sa.call(this, e3, t4, n3, r3, i3));
    }
    function sa(e3, t4, n3, r3, i3) {
      var a3 = Rt(e3, t4, n3, r3, i3), o3 = It(a3.year, 0, a3.dayOfYear);
      return this.year(o3.getUTCFullYear()), this.month(o3.getUTCMonth()), this.date(o3.getUTCDate()), this;
    }
    x(`Q`, 0, `Qo`, `quarter`), T(`Q`, Re), k(`Q`, function(e3, t4) {
      t4[j] = (O(e3) - 1) * 3;
    });
    function ca(e3) {
      return e3 == null ? Math.ceil((this.month() + 1) / 3) : this.month((e3 - 1) * 3 + this.month() % 3);
    }
    x(`D`, [`DD`, 2], `Do`, `date`), T(`D`, w, $e), T(`DD`, w, C), T(`Do`, function(e3, t4) {
      return e3 ? t4._dayOfMonthOrdinalParse || t4._ordinalParse : t4._dayOfMonthOrdinalParseLenient;
    }), k([`D`, `DD`], M), k(`Do`, function(e3, t4) {
      t4[M] = O(e3.match(w)[0]);
    });
    var la = pt(`Date`, true);
    x(`DDD`, [`DDDD`, 3], `DDDo`, `dayOfYear`), T(`DDD`, We), T(`DDDD`, ze), k([`DDD`, `DDDD`], function(e3, t4, n3) {
      n3._dayOfYear = O(e3);
    });
    function ua(e3) {
      var t4 = Math.round((this.clone().startOf(`day`) - this.clone().startOf(`year`)) / 864e5) + 1;
      return e3 == null ? t4 : this.add(e3 - t4, `d`);
    }
    x(`m`, [`mm`, 2], 0, `minute`), T(`m`, w, et), T(`mm`, w, C), k([`m`, `mm`], P);
    var da = pt(`Minutes`, false);
    x(`s`, [`ss`, 2], 0, `second`), T(`s`, w, et), T(`ss`, w, C), k([`s`, `ss`], F);
    var fa = pt(`Seconds`, false);
    x(`S`, 0, 0, function() {
      return ~~(this.millisecond() / 100);
    }), x(0, [`SS`, 2], 0, function() {
      return ~~(this.millisecond() / 10);
    }), x(0, [`SSS`, 3], 0, `millisecond`), x(0, [`SSSS`, 4], 0, function() {
      return this.millisecond() * 10;
    }), x(0, [`SSSSS`, 5], 0, function() {
      return this.millisecond() * 100;
    }), x(0, [`SSSSSS`, 6], 0, function() {
      return this.millisecond() * 1e3;
    }), x(0, [`SSSSSSS`, 7], 0, function() {
      return this.millisecond() * 1e4;
    }), x(0, [`SSSSSSSS`, 8], 0, function() {
      return this.millisecond() * 1e5;
    }), x(0, [`SSSSSSSSS`, 9], 0, function() {
      return this.millisecond() * 1e6;
    }), T(`S`, We, Re), T(`SS`, We, C), T(`SSS`, We, ze);
    for (var G = `SSSS`, pa; G.length <= 9; G += `S`) T(G, qe);
    function ma(e3, t4) {
      t4[I] = O((`0.` + e3) * 1e3);
    }
    for (G = `S`; G.length <= 9; G += `S`) k(G, ma);
    pa = pt(`Milliseconds`, false), x(`z`, 0, 0, `zoneAbbr`), x(`zz`, 0, 0, `zoneName`);
    function ha() {
      return this._isUTC ? `UTC` : ``;
    }
    function ga() {
      return this._isUTC ? `Coordinated Universal Time` : ``;
    }
    var K = g2.prototype;
    K.add = Wr, K.calendar = Qr, K.clone = $r, K.diff = oi, K.endOf = Di, K.format = di, K.from = fi, K.fromNow = pi, K.to = mi, K.toNow = hi, K.get = gt, K.invalidAt = Ii, K.isAfter = ei, K.isBefore = ti, K.isBetween = ni, K.isSame = ri, K.isSameOrAfter = ii, K.isSameOrBefore = ai, K.isValid = Pi, K.lang = _i, K.locale = gi, K.localeData = vi, K.max = lr, K.min = cr, K.parsingFlags = Fi, K.set = _t, K.startOf = Ei, K.subtract = Gr, K.toArray = ji, K.toObject = Mi, K.toDate = Ai, K.toISOString = li, K.inspect = ui, typeof Symbol < `u` && Symbol.for != null && (K[/* @__PURE__ */ Symbol.for(`nodejs.util.inspect.custom`)] = function() {
      return `Moment<` + this.format() + `>`;
    }), K.toJSON = Ni, K.toString = ci, K.unix = ki, K.valueOf = Oi, K.creationData = Li, K.eraName = Vi, K.eraNarrow = Hi, K.eraAbbr = Ui, K.eraYear = Wi, K.year = dt, K.isLeapYear = ft, K.weekYear = ea, K.isoWeekYear = ta, K.quarter = K.quarters = ca, K.month = At, K.daysInMonth = jt, K.week = K.weeks = Wt, K.isoWeek = K.isoWeeks = Gt, K.weeksInYear = ia, K.weeksInWeekYear = aa, K.isoWeeksInYear = na, K.isoWeeksInISOWeekYear = ra, K.date = la, K.day = K.days = sn, K.weekday = cn, K.isoWeekday = ln, K.dayOfYear = ua, K.hour = K.hours = bn, K.minute = K.minutes = da, K.second = K.seconds = fa, K.millisecond = K.milliseconds = pa, K.utcOffset = Dr, K.utc = kr, K.local = Ar, K.parseZone = jr, K.hasAlignedHourOffset = Mr, K.isDST = Nr, K.isLocal = Fr, K.isUtcOffset = Ir, K.isUtc = Lr, K.isUTC = Lr, K.zoneAbbr = ha, K.zoneName = ga, K.dates = v(`dates accessor is deprecated. Use date instead.`, la), K.months = v(`months accessor is deprecated. Use month instead`, At), K.years = v(`years accessor is deprecated. Use year instead`, dt), K.zone = v(`moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/`, Or), K.isDSTShifted = v(`isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information`, Pr);
    function _a(e3) {
      return H(e3 * 1e3);
    }
    function va() {
      return H.apply(null, arguments).parseZone();
    }
    function ya(e3) {
      return e3;
    }
    var q = fe.prototype;
    q.calendar = he, q.longDateFormat = Te, q.invalidDate = De, q.ordinal = Ae, q.preparse = ya, q.postformat = ya, q.relativeTime = Me, q.pastFuture = Ne, q.set = ue, q.eras = Ri, q.erasParse = zi, q.erasConvertYear = Bi, q.erasAbbrRegex = Ki, q.erasNameRegex = Gi, q.erasNarrowRegex = qi, q.months = Tt, q.monthsShort = Et, q.monthsParse = Ot, q.monthsRegex = Nt, q.monthsShortRegex = Mt, q.week = Bt, q.firstDayOfYear = Ut, q.firstDayOfWeek = Ht, q.weekdays = tn, q.weekdaysMin = rn, q.weekdaysShort = nn, q.weekdaysParse = on, q.weekdaysRegex = un, q.weekdaysShortRegex = dn, q.weekdaysMinRegex = fn, q.isPM = vn, q.meridiem = xn;
    function ba(e3, t4, n3, r3) {
      var i3 = V(), a3 = m2().set(r3, t4);
      return i3[n3](a3, e3);
    }
    function xa(e3, t4, n3) {
      if (u2(e3) && (t4 = e3, e3 = void 0), e3 || (e3 = ``), t4 != null) return ba(e3, t4, n3, `month`);
      var r3, i3 = [];
      for (r3 = 0; r3 < 12; r3++) i3[r3] = ba(e3, r3, n3, `month`);
      return i3;
    }
    function Sa(e3, t4, n3, r3) {
      typeof e3 == `boolean` ? (u2(t4) && (n3 = t4, t4 = void 0), t4 || (t4 = ``)) : (t4 = e3, n3 = t4, e3 = false, u2(t4) && (n3 = t4, t4 = void 0), t4 || (t4 = ``));
      var i3 = V(), a3 = e3 ? i3._week.dow : 0, o3, s3 = [];
      if (n3 != null) return ba(t4, (n3 + a3) % 7, r3, `day`);
      for (o3 = 0; o3 < 7; o3++) s3[o3] = ba(t4, (o3 + a3) % 7, r3, `day`);
      return s3;
    }
    function Ca(e3, t4) {
      return xa(e3, t4, `months`);
    }
    function wa(e3, t4) {
      return xa(e3, t4, `monthsShort`);
    }
    function Ta(e3, t4, n3) {
      return Sa(e3, t4, n3, `weekdays`);
    }
    function Ea(e3, t4, n3) {
      return Sa(e3, t4, n3, `weekdaysShort`);
    }
    function Da(e3, t4, n3) {
      return Sa(e3, t4, n3, `weekdaysMin`);
    }
    B(`en`, { eras: [{ since: `0001-01-01`, until: 1 / 0, offset: 1, name: `Anno Domini`, narrow: `AD`, abbr: `AD` }, { since: `0000-12-31`, until: -1 / 0, offset: 1, name: `Before Christ`, narrow: `BC`, abbr: `BC` }], dayOfMonthOrdinalParse: /\d{1,2}(th|st|nd|rd)/, ordinal: function(e3) {
      var t4 = e3 % 10;
      return e3 + (O(e3 % 100 / 10) === 1 ? `th` : t4 === 1 ? `st` : t4 === 2 ? `nd` : t4 === 3 ? `rd` : `th`);
    } }), r2.lang = v(`moment.lang is deprecated. Use moment.locale instead.`, B), r2.langData = v(`moment.langData is deprecated. Use moment.localeData instead.`, V);
    var J = Math.abs;
    function Oa() {
      var e3 = this._data;
      return this._milliseconds = J(this._milliseconds), this._days = J(this._days), this._months = J(this._months), e3.milliseconds = J(e3.milliseconds), e3.seconds = J(e3.seconds), e3.minutes = J(e3.minutes), e3.hours = J(e3.hours), e3.months = J(e3.months), e3.years = J(e3.years), this;
    }
    function ka(e3, t4, n3, r3) {
      var i3 = U(t4, n3);
      return e3._milliseconds += r3 * i3._milliseconds, e3._days += r3 * i3._days, e3._months += r3 * i3._months, e3._bubble();
    }
    function Aa(e3, t4) {
      return ka(this, e3, t4, 1);
    }
    function ja(e3, t4) {
      return ka(this, e3, t4, -1);
    }
    function Ma(e3) {
      return e3 < 0 ? Math.floor(e3) : Math.ceil(e3);
    }
    function Na() {
      var e3 = this._milliseconds, t4 = this._days, n3 = this._months, r3 = this._data, i3, a3, o3, s3, c3;
      return e3 >= 0 && t4 >= 0 && n3 >= 0 || e3 <= 0 && t4 <= 0 && n3 <= 0 || (e3 += Ma(Fa(n3) + t4) * 864e5, t4 = 0, n3 = 0), r3.milliseconds = e3 % 1e3, i3 = D(e3 / 1e3), r3.seconds = i3 % 60, a3 = D(i3 / 60), r3.minutes = a3 % 60, o3 = D(a3 / 60), r3.hours = o3 % 24, t4 += D(o3 / 24), c3 = D(Pa(t4)), n3 += c3, t4 -= Ma(Fa(c3)), s3 = D(n3 / 12), n3 %= 12, r3.days = t4, r3.months = n3, r3.years = s3, this;
    }
    function Pa(e3) {
      return e3 * 4800 / 146097;
    }
    function Fa(e3) {
      return e3 * 146097 / 4800;
    }
    function Ia(e3) {
      if (!this.isValid()) return NaN;
      var t4, n3, r3 = this._milliseconds;
      if (e3 = S(e3), e3 === `month` || e3 === `quarter` || e3 === `year`) switch (t4 = this._days + r3 / 864e5, n3 = this._months + Pa(t4), e3) {
        case `month`:
          return n3;
        case `quarter`:
          return n3 / 3;
        case `year`:
          return n3 / 12;
      }
      else switch (t4 = this._days + Math.round(Fa(this._months)), e3) {
        case `week`:
          return t4 / 7 + r3 / 6048e5;
        case `day`:
          return t4 + r3 / 864e5;
        case `hour`:
          return t4 * 24 + r3 / 36e5;
        case `minute`:
          return t4 * 1440 + r3 / 6e4;
        case `second`:
          return t4 * 86400 + r3 / 1e3;
        case `millisecond`:
          return Math.floor(t4 * 864e5) + r3;
        default:
          throw Error(`Unknown unit ` + e3);
      }
    }
    function Y(e3) {
      return function() {
        return this.as(e3);
      };
    }
    var La = Y(`ms`), Ra = Y(`s`), za = Y(`m`), Ba = Y(`h`), Va = Y(`d`), Ha = Y(`w`), Ua = Y(`M`), Wa = Y(`Q`), Ga = Y(`y`), Ka = La;
    function qa() {
      return U(this);
    }
    function Ja(e3) {
      return e3 = S(e3), this.isValid() ? this[e3 + `s`]() : NaN;
    }
    function X(e3) {
      return function() {
        return this.isValid() ? this._data[e3] : NaN;
      };
    }
    var Ya = X(`milliseconds`), Xa = X(`seconds`), Za = X(`minutes`), Qa = X(`hours`), $a = X(`days`), eo = X(`months`), to = X(`years`);
    function no() {
      return D(this.days() / 7);
    }
    var Z = Math.round, Q = { ss: 44, s: 45, m: 45, h: 22, d: 26, w: null, M: 11 };
    function ro(e3, t4, n3, r3, i3) {
      return i3.relativeTime(t4 || 1, !!n3, e3, r3);
    }
    function io(e3, t4, n3, r3) {
      var i3 = U(e3).abs(), a3 = Z(i3.as(`s`)), o3 = Z(i3.as(`m`)), s3 = Z(i3.as(`h`)), c3 = Z(i3.as(`d`)), l3 = Z(i3.as(`M`)), u3 = Z(i3.as(`w`)), d3 = Z(i3.as(`y`)), f3 = a3 <= n3.ss && [`s`, a3] || a3 < n3.s && [`ss`, a3] || o3 <= 1 && [`m`] || o3 < n3.m && [`mm`, o3] || s3 <= 1 && [`h`] || s3 < n3.h && [`hh`, s3] || c3 <= 1 && [`d`] || c3 < n3.d && [`dd`, c3];
      return n3.w != null && (f3 = f3 || u3 <= 1 && [`w`] || u3 < n3.w && [`ww`, u3]), f3 = f3 || l3 <= 1 && [`M`] || l3 < n3.M && [`MM`, l3] || d3 <= 1 && [`y`] || [`yy`, d3], f3[2] = t4, f3[3] = +e3 > 0, f3[4] = r3, ro.apply(null, f3);
    }
    function ao(e3) {
      return e3 === void 0 ? Z : typeof e3 == `function` && (Z = e3, true);
    }
    function oo(e3, t4) {
      return Q[e3] === void 0 ? false : t4 === void 0 ? Q[e3] : (Q[e3] = t4, e3 === `s` && (Q.ss = t4 - 1), true);
    }
    function so(e3, t4) {
      if (!this.isValid()) return this.localeData().invalidDate();
      var n3 = false, r3 = Q, i3, a3;
      return typeof e3 == `object` && (t4 = e3, e3 = false), typeof e3 == `boolean` && (n3 = e3), typeof t4 == `object` && (r3 = Object.assign({}, Q, t4), t4.s != null && t4.ss == null && (r3.ss = t4.s - 1)), i3 = this.localeData(), a3 = io(this, !n3, r3, i3), n3 && (a3 = i3.pastFuture(+this, a3)), i3.postformat(a3);
    }
    var co = Math.abs;
    function lo(e3) {
      return (e3 > 0) - (e3 < 0) || +e3;
    }
    function uo() {
      if (!this.isValid()) return this.localeData().invalidDate();
      var e3 = co(this._milliseconds) / 1e3, t4 = co(this._days), n3 = co(this._months), r3, i3, a3, o3, s3 = this.asSeconds(), c3, l3, u3, d3;
      return s3 ? (r3 = D(e3 / 60), i3 = D(r3 / 60), e3 %= 60, r3 %= 60, a3 = D(n3 / 12), n3 %= 12, o3 = e3 ? e3.toFixed(3).replace(/\.?0+$/, ``) : ``, c3 = s3 < 0 ? `-` : ``, l3 = lo(this._months) === lo(s3) ? `` : `-`, u3 = lo(this._days) === lo(s3) ? `` : `-`, d3 = lo(this._milliseconds) === lo(s3) ? `` : `-`, c3 + `P` + (a3 ? l3 + a3 + `Y` : ``) + (n3 ? l3 + n3 + `M` : ``) + (t4 ? u3 + t4 + `D` : ``) + (i3 || r3 || e3 ? `T` : ``) + (i3 ? d3 + i3 + `H` : ``) + (r3 ? d3 + r3 + `M` : ``) + (e3 ? d3 + o3 + `S` : ``)) : `P0D`;
    }
    var $ = vr.prototype;
    return $.isValid = gr, $.abs = Oa, $.add = Aa, $.subtract = ja, $.as = Ia, $.asMilliseconds = La, $.asSeconds = Ra, $.asMinutes = za, $.asHours = Ba, $.asDays = Va, $.asWeeks = Ha, $.asMonths = Ua, $.asQuarters = Wa, $.asYears = Ga, $.valueOf = Ka, $._bubble = Na, $.clone = qa, $.get = Ja, $.milliseconds = Ya, $.seconds = Xa, $.minutes = Za, $.hours = Qa, $.days = $a, $.weeks = no, $.months = eo, $.years = to, $.humanize = so, $.toISOString = uo, $.toString = uo, $.toJSON = uo, $.locale = gi, $.localeData = vi, $.toIsoString = v(`toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)`, uo), $.lang = _i, x(`X`, 0, 0, `unix`), x(`x`, 0, 0, `valueOf`), T(`x`, Je), T(`X`, Ze), k(`X`, function(e3, t4, n3) {
      n3._d = new Date(parseFloat(e3) * 1e3);
    }), k(`x`, function(e3, t4, n3) {
      n3._d = new Date(O(e3));
    }), r2.version = `2.30.1`, i2(H), r2.fn = K, r2.min = dr, r2.max = fr, r2.now = pr, r2.utc = m2, r2.unix = _a, r2.months = Ca, r2.isDate = d2, r2.locale = B, r2.invalid = re2, r2.duration = U, r2.isMoment = _2, r2.weekdays = Ta, r2.parseZone = va, r2.localeData = V, r2.isDuration = yr, r2.monthsShort = wa, r2.weekdaysMin = Da, r2.defineLocale = An, r2.updateLocale = jn, r2.locales = Mn, r2.weekdaysShort = Ea, r2.normalizeUnits = S, r2.relativeTimeRounding = ao, r2.relativeTimeThreshold = oo, r2.calendarFormat = Zr, r2.prototype = K, r2.HTML5_FMT = { DATETIME_LOCAL: `YYYY-MM-DDTHH:mm`, DATETIME_LOCAL_SECONDS: `YYYY-MM-DDTHH:mm:ss`, DATETIME_LOCAL_MS: `YYYY-MM-DDTHH:mm:ss.SSS`, DATE: `YYYY-MM-DD`, TIME: `HH:mm`, TIME_SECONDS: `HH:mm:ss`, TIME_MS: `HH:mm:ss.SSS`, WEEK: `GGGG-[W]WW`, MONTH: `YYYY-MM` }, r2;
  }));
})), u = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    function t3(e4, t4, n3, r2) {
      var i2 = { m: [`eine Minute`, `einer Minute`], h: [`eine Stunde`, `einer Stunde`], d: [`ein Tag`, `einem Tag`], dd: [e4 + ` Tage`, e4 + ` Tagen`], w: [`eine Woche`, `einer Woche`], M: [`ein Monat`, `einem Monat`], MM: [e4 + ` Monate`, e4 + ` Monaten`], y: [`ein Jahr`, `einem Jahr`], yy: [e4 + ` Jahre`, e4 + ` Jahren`] };
      return t4 ? i2[n3][0] : i2[n3][1];
    }
    return e3.defineLocale(`de`, { months: `Januar_Februar_M\xE4rz_April_Mai_Juni_Juli_August_September_Oktober_November_Dezember`.split(`_`), monthsShort: `Jan._Feb._M\xE4rz_Apr._Mai_Juni_Juli_Aug._Sep._Okt._Nov._Dez.`.split(`_`), monthsParseExact: true, weekdays: `Sonntag_Montag_Dienstag_Mittwoch_Donnerstag_Freitag_Samstag`.split(`_`), weekdaysShort: `So._Mo._Di._Mi._Do._Fr._Sa.`.split(`_`), weekdaysMin: `So_Mo_Di_Mi_Do_Fr_Sa`.split(`_`), weekdaysParseExact: true, longDateFormat: { LT: `HH:mm`, LTS: `HH:mm:ss`, L: `DD.MM.YYYY`, LL: `D. MMMM YYYY`, LLL: `D. MMMM YYYY HH:mm`, LLLL: `dddd, D. MMMM YYYY HH:mm` }, calendar: { sameDay: `[heute um] LT [Uhr]`, sameElse: `L`, nextDay: `[morgen um] LT [Uhr]`, nextWeek: `dddd [um] LT [Uhr]`, lastDay: `[gestern um] LT [Uhr]`, lastWeek: `[letzten] dddd [um] LT [Uhr]` }, relativeTime: { future: `in %s`, past: `vor %s`, s: `ein paar Sekunden`, ss: `%d Sekunden`, m: t3, mm: `%d Minuten`, h: t3, hh: `%d Stunden`, d: t3, dd: t3, w: t3, ww: `%d Wochen`, M: t3, MM: t3, y: t3, yy: t3 }, dayOfMonthOrdinalParse: /\d{1,2}\./, ordinal: `%d.`, week: { dow: 1, doy: 4 } });
  }));
})), d = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    var t3 = `ene._feb._mar._abr._may._jun._jul._ago._sep._oct._nov._dic.`.split(`_`), n3 = `ene_feb_mar_abr_may_jun_jul_ago_sep_oct_nov_dic`.split(`_`), r2 = [/^ene/i, /^feb/i, /^mar/i, /^abr/i, /^may/i, /^jun/i, /^jul/i, /^ago/i, /^sep/i, /^oct/i, /^nov/i, /^dic/i], i2 = /^(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|ene\.?|feb\.?|mar\.?|abr\.?|may\.?|jun\.?|jul\.?|ago\.?|sep\.?|oct\.?|nov\.?|dic\.?)/i;
    return e3.defineLocale(`es`, { months: `enero_febrero_marzo_abril_mayo_junio_julio_agosto_septiembre_octubre_noviembre_diciembre`.split(`_`), monthsShort: function(e4, r3) {
      return e4 ? /-MMM-/.test(r3) ? n3[e4.month()] : t3[e4.month()] : t3;
    }, monthsRegex: i2, monthsShortRegex: i2, monthsStrictRegex: /^(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)/i, monthsShortStrictRegex: /^(ene\.?|feb\.?|mar\.?|abr\.?|may\.?|jun\.?|jul\.?|ago\.?|sep\.?|oct\.?|nov\.?|dic\.?)/i, monthsParse: r2, longMonthsParse: r2, shortMonthsParse: r2, weekdays: `domingo_lunes_martes_mi\xE9rcoles_jueves_viernes_s\xE1bado`.split(`_`), weekdaysShort: `dom._lun._mar._mi\xE9._jue._vie._s\xE1b.`.split(`_`), weekdaysMin: `do_lu_ma_mi_ju_vi_s\xE1`.split(`_`), weekdaysParseExact: true, longDateFormat: { LT: `H:mm`, LTS: `H:mm:ss`, L: `DD/MM/YYYY`, LL: `D [de] MMMM [de] YYYY`, LLL: `D [de] MMMM [de] YYYY H:mm`, LLLL: `dddd, D [de] MMMM [de] YYYY H:mm` }, calendar: { sameDay: function() {
      return `[hoy a la` + (this.hours() === 1 ? `` : `s`) + `] LT`;
    }, nextDay: function() {
      return `[ma\xF1ana a la` + (this.hours() === 1 ? `` : `s`) + `] LT`;
    }, nextWeek: function() {
      return `dddd [a la` + (this.hours() === 1 ? `` : `s`) + `] LT`;
    }, lastDay: function() {
      return `[ayer a la` + (this.hours() === 1 ? `` : `s`) + `] LT`;
    }, lastWeek: function() {
      return `[el] dddd [pasado a la` + (this.hours() === 1 ? `` : `s`) + `] LT`;
    }, sameElse: `L` }, relativeTime: { future: `en %s`, past: `hace %s`, s: `unos segundos`, ss: `%d segundos`, m: `un minuto`, mm: `%d minutos`, h: `una hora`, hh: `%d horas`, d: `un d\xEDa`, dd: `%d d\xEDas`, w: `una semana`, ww: `%d semanas`, M: `un mes`, MM: `%d meses`, y: `un a\xF1o`, yy: `%d a\xF1os` }, dayOfMonthOrdinalParse: /\d{1,2}º/, ordinal: `%d\xBA`, week: { dow: 1, doy: 4 }, invalidDate: `Fecha inv\xE1lida` });
  }));
})), f = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    var t3 = /^(janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre)/i, n3 = /(janv\.?|févr\.?|mars|avr\.?|mai|juin|juil\.?|août|sept\.?|oct\.?|nov\.?|déc\.?)/i, r2 = /(janv\.?|févr\.?|mars|avr\.?|mai|juin|juil\.?|août|sept\.?|oct\.?|nov\.?|déc\.?|janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre)/i, i2 = [/^janv/i, /^févr/i, /^mars/i, /^avr/i, /^mai/i, /^juin/i, /^juil/i, /^août/i, /^sept/i, /^oct/i, /^nov/i, /^déc/i];
    return e3.defineLocale(`fr`, { months: `janvier_f\xE9vrier_mars_avril_mai_juin_juillet_ao\xFBt_septembre_octobre_novembre_d\xE9cembre`.split(`_`), monthsShort: `janv._f\xE9vr._mars_avr._mai_juin_juil._ao\xFBt_sept._oct._nov._d\xE9c.`.split(`_`), monthsRegex: r2, monthsShortRegex: r2, monthsStrictRegex: t3, monthsShortStrictRegex: n3, monthsParse: i2, longMonthsParse: i2, shortMonthsParse: i2, weekdays: `dimanche_lundi_mardi_mercredi_jeudi_vendredi_samedi`.split(`_`), weekdaysShort: `dim._lun._mar._mer._jeu._ven._sam.`.split(`_`), weekdaysMin: `di_lu_ma_me_je_ve_sa`.split(`_`), weekdaysParseExact: true, longDateFormat: { LT: `HH:mm`, LTS: `HH:mm:ss`, L: `DD/MM/YYYY`, LL: `D MMMM YYYY`, LLL: `D MMMM YYYY HH:mm`, LLLL: `dddd D MMMM YYYY HH:mm` }, calendar: { sameDay: `[Aujourd\u2019hui \xE0] LT`, nextDay: `[Demain \xE0] LT`, nextWeek: `dddd [\xE0] LT`, lastDay: `[Hier \xE0] LT`, lastWeek: `dddd [dernier \xE0] LT`, sameElse: `L` }, relativeTime: { future: `dans %s`, past: `il y a %s`, s: `quelques secondes`, ss: `%d secondes`, m: `une minute`, mm: `%d minutes`, h: `une heure`, hh: `%d heures`, d: `un jour`, dd: `%d jours`, w: `une semaine`, ww: `%d semaines`, M: `un mois`, MM: `%d mois`, y: `un an`, yy: `%d ans` }, dayOfMonthOrdinalParse: /\d{1,2}(er|)/, ordinal: function(e4, t4) {
      switch (t4) {
        case `D`:
          return e4 + (e4 === 1 ? `er` : ``);
        default:
        case `M`:
        case `Q`:
        case `DDD`:
        case `d`:
          return e4 + (e4 === 1 ? `er` : `e`);
        case `w`:
        case `W`:
          return e4 + (e4 === 1 ? `re` : `e`);
      }
    }, week: { dow: 1, doy: 4 } });
  }));
})), p = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    return e3.defineLocale(`it`, { months: `gennaio_febbraio_marzo_aprile_maggio_giugno_luglio_agosto_settembre_ottobre_novembre_dicembre`.split(`_`), monthsShort: `gen_feb_mar_apr_mag_giu_lug_ago_set_ott_nov_dic`.split(`_`), weekdays: `domenica_luned\xEC_marted\xEC_mercoled\xEC_gioved\xEC_venerd\xEC_sabato`.split(`_`), weekdaysShort: `dom_lun_mar_mer_gio_ven_sab`.split(`_`), weekdaysMin: `do_lu_ma_me_gi_ve_sa`.split(`_`), longDateFormat: { LT: `HH:mm`, LTS: `HH:mm:ss`, L: `DD/MM/YYYY`, LL: `D MMMM YYYY`, LLL: `D MMMM YYYY HH:mm`, LLLL: `dddd D MMMM YYYY HH:mm` }, calendar: { sameDay: function() {
      return `[Oggi a` + (this.hours() > 1 ? `lle ` : this.hours() === 0 ? ` ` : `ll'`) + `]LT`;
    }, nextDay: function() {
      return `[Domani a` + (this.hours() > 1 ? `lle ` : this.hours() === 0 ? ` ` : `ll'`) + `]LT`;
    }, nextWeek: function() {
      return `dddd [a` + (this.hours() > 1 ? `lle ` : this.hours() === 0 ? ` ` : `ll'`) + `]LT`;
    }, lastDay: function() {
      return `[Ieri a` + (this.hours() > 1 ? `lle ` : this.hours() === 0 ? ` ` : `ll'`) + `]LT`;
    }, lastWeek: function() {
      switch (this.day()) {
        case 0:
          return `[La scorsa] dddd [a` + (this.hours() > 1 ? `lle ` : this.hours() === 0 ? ` ` : `ll'`) + `]LT`;
        default:
          return `[Lo scorso] dddd [a` + (this.hours() > 1 ? `lle ` : this.hours() === 0 ? ` ` : `ll'`) + `]LT`;
      }
    }, sameElse: `L` }, relativeTime: { future: `tra %s`, past: `%s fa`, s: `alcuni secondi`, ss: `%d secondi`, m: `un minuto`, mm: `%d minuti`, h: `un'ora`, hh: `%d ore`, d: `un giorno`, dd: `%d giorni`, w: `una settimana`, ww: `%d settimane`, M: `un mese`, MM: `%d mesi`, y: `un anno`, yy: `%d anni` }, dayOfMonthOrdinalParse: /\d{1,2}º/, ordinal: `%d\xBA`, week: { dow: 1, doy: 4 } });
  }));
})), m = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    var t3 = `jan._feb._mrt._apr._mei_jun._jul._aug._sep._okt._nov._dec.`.split(`_`), n3 = `jan_feb_mrt_apr_mei_jun_jul_aug_sep_okt_nov_dec`.split(`_`), r2 = [/^jan/i, /^feb/i, /^(maart|mrt\.?)$/i, /^apr/i, /^mei$/i, /^jun[i.]?$/i, /^jul[i.]?$/i, /^aug/i, /^sep/i, /^okt/i, /^nov/i, /^dec/i], i2 = /^(januari|februari|maart|april|mei|ju[nl]i|augustus|september|oktober|november|december|jan\.?|feb\.?|mrt\.?|apr\.?|ju[nl]\.?|aug\.?|sep\.?|okt\.?|nov\.?|dec\.?)/i;
    return e3.defineLocale(`nl`, { months: `januari_februari_maart_april_mei_juni_juli_augustus_september_oktober_november_december`.split(`_`), monthsShort: function(e4, r3) {
      return e4 ? /-MMM-/.test(r3) ? n3[e4.month()] : t3[e4.month()] : t3;
    }, monthsRegex: i2, monthsShortRegex: i2, monthsStrictRegex: /^(januari|februari|maart|april|mei|ju[nl]i|augustus|september|oktober|november|december)/i, monthsShortStrictRegex: /^(jan\.?|feb\.?|mrt\.?|apr\.?|mei|ju[nl]\.?|aug\.?|sep\.?|okt\.?|nov\.?|dec\.?)/i, monthsParse: r2, longMonthsParse: r2, shortMonthsParse: r2, weekdays: `zondag_maandag_dinsdag_woensdag_donderdag_vrijdag_zaterdag`.split(`_`), weekdaysShort: `zo._ma._di._wo._do._vr._za.`.split(`_`), weekdaysMin: `zo_ma_di_wo_do_vr_za`.split(`_`), weekdaysParseExact: true, longDateFormat: { LT: `HH:mm`, LTS: `HH:mm:ss`, L: `DD-MM-YYYY`, LL: `D MMMM YYYY`, LLL: `D MMMM YYYY HH:mm`, LLLL: `dddd D MMMM YYYY HH:mm` }, calendar: { sameDay: `[vandaag om] LT`, nextDay: `[morgen om] LT`, nextWeek: `dddd [om] LT`, lastDay: `[gisteren om] LT`, lastWeek: `[afgelopen] dddd [om] LT`, sameElse: `L` }, relativeTime: { future: `over %s`, past: `%s geleden`, s: `een paar seconden`, ss: `%d seconden`, m: `\xE9\xE9n minuut`, mm: `%d minuten`, h: `\xE9\xE9n uur`, hh: `%d uur`, d: `\xE9\xE9n dag`, dd: `%d dagen`, w: `\xE9\xE9n week`, ww: `%d weken`, M: `\xE9\xE9n maand`, MM: `%d maanden`, y: `\xE9\xE9n jaar`, yy: `%d jaar` }, dayOfMonthOrdinalParse: /\d{1,2}(ste|de)/, ordinal: function(e4) {
      return e4 + (e4 === 1 || e4 === 8 || e4 >= 20 ? `ste` : `de`);
    }, week: { dow: 1, doy: 4 } });
  }));
})), ee = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    var t3 = `stycze\u0144_luty_marzec_kwiecie\u0144_maj_czerwiec_lipiec_sierpie\u0144_wrzesie\u0144_pa\u017Adziernik_listopad_grudzie\u0144`.split(`_`), n3 = `stycznia_lutego_marca_kwietnia_maja_czerwca_lipca_sierpnia_wrze\u015Bnia_pa\u017Adziernika_listopada_grudnia`.split(`_`), r2 = [/^sty/i, /^lut/i, /^mar/i, /^kwi/i, /^maj/i, /^cze/i, /^lip/i, /^sie/i, /^wrz/i, /^paź/i, /^lis/i, /^gru/i];
    function i2(e4) {
      return e4 % 10 < 5 && e4 % 10 > 1 && ~~(e4 / 10) % 10 != 1;
    }
    function a2(e4, t4, n4) {
      var r3 = e4 + ` `;
      switch (n4) {
        case `ss`:
          return r3 + (i2(e4) ? `sekundy` : `sekund`);
        case `m`:
          return t4 ? `minuta` : `minut\u0119`;
        case `mm`:
          return r3 + (i2(e4) ? `minuty` : `minut`);
        case `h`:
          return t4 ? `godzina` : `godzin\u0119`;
        case `hh`:
          return r3 + (i2(e4) ? `godziny` : `godzin`);
        case `ww`:
          return r3 + (i2(e4) ? `tygodnie` : `tygodni`);
        case `MM`:
          return r3 + (i2(e4) ? `miesi\u0105ce` : `miesi\u0119cy`);
        case `yy`:
          return r3 + (i2(e4) ? `lata` : `lat`);
      }
    }
    return e3.defineLocale(`pl`, { months: function(e4, r3) {
      return e4 ? /D MMMM/.test(r3) ? n3[e4.month()] : t3[e4.month()] : t3;
    }, monthsShort: `sty_lut_mar_kwi_maj_cze_lip_sie_wrz_pa\u017A_lis_gru`.split(`_`), monthsParse: r2, longMonthsParse: r2, shortMonthsParse: r2, weekdays: `niedziela_poniedzia\u0142ek_wtorek_\u015Broda_czwartek_pi\u0105tek_sobota`.split(`_`), weekdaysShort: `ndz_pon_wt_\u015Br_czw_pt_sob`.split(`_`), weekdaysMin: `Nd_Pn_Wt_\u015Ar_Cz_Pt_So`.split(`_`), longDateFormat: { LT: `HH:mm`, LTS: `HH:mm:ss`, L: `DD.MM.YYYY`, LL: `D MMMM YYYY`, LLL: `D MMMM YYYY HH:mm`, LLLL: `dddd, D MMMM YYYY HH:mm` }, calendar: { sameDay: `[Dzi\u015B o] LT`, nextDay: `[Jutro o] LT`, nextWeek: function() {
      switch (this.day()) {
        case 0:
          return `[W niedziel\u0119 o] LT`;
        case 2:
          return `[We wtorek o] LT`;
        case 3:
          return `[W \u015Brod\u0119 o] LT`;
        case 6:
          return `[W sobot\u0119 o] LT`;
        default:
          return `[W] dddd [o] LT`;
      }
    }, lastDay: `[Wczoraj o] LT`, lastWeek: function() {
      switch (this.day()) {
        case 0:
          return `[W zesz\u0142\u0105 niedziel\u0119 o] LT`;
        case 3:
          return `[W zesz\u0142\u0105 \u015Brod\u0119 o] LT`;
        case 6:
          return `[W zesz\u0142\u0105 sobot\u0119 o] LT`;
        default:
          return `[W zesz\u0142y] dddd [o] LT`;
      }
    }, sameElse: `L` }, relativeTime: { future: `za %s`, past: `%s temu`, s: `kilka sekund`, ss: a2, m: a2, mm: a2, h: a2, hh: a2, d: `1 dzie\u0144`, dd: `%d dni`, w: `tydzie\u0144`, ww: a2, M: `miesi\u0105c`, MM: a2, y: `rok`, yy: a2 }, dayOfMonthOrdinalParse: /\d{1,2}\./, ordinal: `%d.`, week: { dow: 1, doy: 4 } });
  }));
})), h = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    return e3.defineLocale(`pt`, { months: `janeiro_fevereiro_mar\xE7o_abril_maio_junho_julho_agosto_setembro_outubro_novembro_dezembro`.split(`_`), monthsShort: `jan_fev_mar_abr_mai_jun_jul_ago_set_out_nov_dez`.split(`_`), weekdays: `Domingo_Segunda-feira_Ter\xE7a-feira_Quarta-feira_Quinta-feira_Sexta-feira_S\xE1bado`.split(`_`), weekdaysShort: `Dom_Seg_Ter_Qua_Qui_Sex_S\xE1b`.split(`_`), weekdaysMin: `Do_2\xAA_3\xAA_4\xAA_5\xAA_6\xAA_S\xE1`.split(`_`), weekdaysParseExact: true, longDateFormat: { LT: `HH:mm`, LTS: `HH:mm:ss`, L: `DD/MM/YYYY`, LL: `D [de] MMMM [de] YYYY`, LLL: `D [de] MMMM [de] YYYY HH:mm`, LLLL: `dddd, D [de] MMMM [de] YYYY HH:mm` }, calendar: { sameDay: `[Hoje \xE0s] LT`, nextDay: `[Amanh\xE3 \xE0s] LT`, nextWeek: `dddd [\xE0s] LT`, lastDay: `[Ontem \xE0s] LT`, lastWeek: function() {
      return this.day() === 0 || this.day() === 6 ? `[\xDAltimo] dddd [\xE0s] LT` : `[\xDAltima] dddd [\xE0s] LT`;
    }, sameElse: `L` }, relativeTime: { future: `em %s`, past: `h\xE1 %s`, s: `segundos`, ss: `%d segundos`, m: `um minuto`, mm: `%d minutos`, h: `uma hora`, hh: `%d horas`, d: `um dia`, dd: `%d dias`, w: `uma semana`, ww: `%d semanas`, M: `um m\xEAs`, MM: `%d meses`, y: `um ano`, yy: `%d anos` }, dayOfMonthOrdinalParse: /\d{1,2}º/, ordinal: `%d\xBA`, week: { dow: 1, doy: 4 } });
  }));
})), te = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    function t3(e4, t4) {
      var n4 = e4.split(`_`);
      return t4 % 10 == 1 && t4 % 100 != 11 ? n4[0] : t4 % 10 >= 2 && t4 % 10 <= 4 && (t4 % 100 < 10 || t4 % 100 >= 20) ? n4[1] : n4[2];
    }
    function n3(e4, n4, r3) {
      var i2 = { ss: n4 ? `\u0441\u0435\u043A\u0443\u043D\u0434\u0430_\u0441\u0435\u043A\u0443\u043D\u0434\u044B_\u0441\u0435\u043A\u0443\u043D\u0434` : `\u0441\u0435\u043A\u0443\u043D\u0434\u0443_\u0441\u0435\u043A\u0443\u043D\u0434\u044B_\u0441\u0435\u043A\u0443\u043D\u0434`, mm: n4 ? `\u043C\u0438\u043D\u0443\u0442\u0430_\u043C\u0438\u043D\u0443\u0442\u044B_\u043C\u0438\u043D\u0443\u0442` : `\u043C\u0438\u043D\u0443\u0442\u0443_\u043C\u0438\u043D\u0443\u0442\u044B_\u043C\u0438\u043D\u0443\u0442`, hh: `\u0447\u0430\u0441_\u0447\u0430\u0441\u0430_\u0447\u0430\u0441\u043E\u0432`, dd: `\u0434\u0435\u043D\u044C_\u0434\u043D\u044F_\u0434\u043D\u0435\u0439`, ww: `\u043D\u0435\u0434\u0435\u043B\u044F_\u043D\u0435\u0434\u0435\u043B\u0438_\u043D\u0435\u0434\u0435\u043B\u044C`, MM: `\u043C\u0435\u0441\u044F\u0446_\u043C\u0435\u0441\u044F\u0446\u0430_\u043C\u0435\u0441\u044F\u0446\u0435\u0432`, yy: `\u0433\u043E\u0434_\u0433\u043E\u0434\u0430_\u043B\u0435\u0442` };
      return r3 === `m` ? n4 ? `\u043C\u0438\u043D\u0443\u0442\u0430` : `\u043C\u0438\u043D\u0443\u0442\u0443` : e4 + ` ` + t3(i2[r3], +e4);
    }
    var r2 = [/^янв/i, /^фев/i, /^мар/i, /^апр/i, /^ма[йя]/i, /^июн/i, /^июл/i, /^авг/i, /^сен/i, /^окт/i, /^ноя/i, /^дек/i];
    return e3.defineLocale(`ru`, { months: { format: `\u044F\u043D\u0432\u0430\u0440\u044F_\u0444\u0435\u0432\u0440\u0430\u043B\u044F_\u043C\u0430\u0440\u0442\u0430_\u0430\u043F\u0440\u0435\u043B\u044F_\u043C\u0430\u044F_\u0438\u044E\u043D\u044F_\u0438\u044E\u043B\u044F_\u0430\u0432\u0433\u0443\u0441\u0442\u0430_\u0441\u0435\u043D\u0442\u044F\u0431\u0440\u044F_\u043E\u043A\u0442\u044F\u0431\u0440\u044F_\u043D\u043E\u044F\u0431\u0440\u044F_\u0434\u0435\u043A\u0430\u0431\u0440\u044F`.split(`_`), standalone: `\u044F\u043D\u0432\u0430\u0440\u044C_\u0444\u0435\u0432\u0440\u0430\u043B\u044C_\u043C\u0430\u0440\u0442_\u0430\u043F\u0440\u0435\u043B\u044C_\u043C\u0430\u0439_\u0438\u044E\u043D\u044C_\u0438\u044E\u043B\u044C_\u0430\u0432\u0433\u0443\u0441\u0442_\u0441\u0435\u043D\u0442\u044F\u0431\u0440\u044C_\u043E\u043A\u0442\u044F\u0431\u0440\u044C_\u043D\u043E\u044F\u0431\u0440\u044C_\u0434\u0435\u043A\u0430\u0431\u0440\u044C`.split(`_`) }, monthsShort: { format: `\u044F\u043D\u0432._\u0444\u0435\u0432\u0440._\u043C\u0430\u0440._\u0430\u043F\u0440._\u043C\u0430\u044F_\u0438\u044E\u043D\u044F_\u0438\u044E\u043B\u044F_\u0430\u0432\u0433._\u0441\u0435\u043D\u0442._\u043E\u043A\u0442._\u043D\u043E\u044F\u0431._\u0434\u0435\u043A.`.split(`_`), standalone: `\u044F\u043D\u0432._\u0444\u0435\u0432\u0440._\u043C\u0430\u0440\u0442_\u0430\u043F\u0440._\u043C\u0430\u0439_\u0438\u044E\u043D\u044C_\u0438\u044E\u043B\u044C_\u0430\u0432\u0433._\u0441\u0435\u043D\u0442._\u043E\u043A\u0442._\u043D\u043E\u044F\u0431._\u0434\u0435\u043A.`.split(`_`) }, weekdays: { standalone: `\u0432\u043E\u0441\u043A\u0440\u0435\u0441\u0435\u043D\u044C\u0435_\u043F\u043E\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u0438\u043A_\u0432\u0442\u043E\u0440\u043D\u0438\u043A_\u0441\u0440\u0435\u0434\u0430_\u0447\u0435\u0442\u0432\u0435\u0440\u0433_\u043F\u044F\u0442\u043D\u0438\u0446\u0430_\u0441\u0443\u0431\u0431\u043E\u0442\u0430`.split(`_`), format: `\u0432\u043E\u0441\u043A\u0440\u0435\u0441\u0435\u043D\u044C\u0435_\u043F\u043E\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u0438\u043A_\u0432\u0442\u043E\u0440\u043D\u0438\u043A_\u0441\u0440\u0435\u0434\u0443_\u0447\u0435\u0442\u0432\u0435\u0440\u0433_\u043F\u044F\u0442\u043D\u0438\u0446\u0443_\u0441\u0443\u0431\u0431\u043E\u0442\u0443`.split(`_`), isFormat: /\[ ?[Вв] ?(?:прошлую|следующую|эту)? ?] ?dddd/ }, weekdaysShort: `\u0432\u0441_\u043F\u043D_\u0432\u0442_\u0441\u0440_\u0447\u0442_\u043F\u0442_\u0441\u0431`.split(`_`), weekdaysMin: `\u0432\u0441_\u043F\u043D_\u0432\u0442_\u0441\u0440_\u0447\u0442_\u043F\u0442_\u0441\u0431`.split(`_`), monthsParse: r2, longMonthsParse: r2, shortMonthsParse: r2, monthsRegex: /^(январ[ья]|янв\.?|феврал[ья]|февр?\.?|марта?|мар\.?|апрел[ья]|апр\.?|ма[йя]|июн[ья]|июн\.?|июл[ья]|июл\.?|августа?|авг\.?|сентябр[ья]|сент?\.?|октябр[ья]|окт\.?|ноябр[ья]|нояб?\.?|декабр[ья]|дек\.?)/i, monthsShortRegex: /^(январ[ья]|янв\.?|феврал[ья]|февр?\.?|марта?|мар\.?|апрел[ья]|апр\.?|ма[йя]|июн[ья]|июн\.?|июл[ья]|июл\.?|августа?|авг\.?|сентябр[ья]|сент?\.?|октябр[ья]|окт\.?|ноябр[ья]|нояб?\.?|декабр[ья]|дек\.?)/i, monthsStrictRegex: /^(январ[яь]|феврал[яь]|марта?|апрел[яь]|ма[яй]|июн[яь]|июл[яь]|августа?|сентябр[яь]|октябр[яь]|ноябр[яь]|декабр[яь])/i, monthsShortStrictRegex: /^(янв\.|февр?\.|мар[т.]|апр\.|ма[яй]|июн[ья.]|июл[ья.]|авг\.|сент?\.|окт\.|нояб?\.|дек\.)/i, longDateFormat: { LT: `H:mm`, LTS: `H:mm:ss`, L: `DD.MM.YYYY`, LL: `D MMMM YYYY \u0433.`, LLL: `D MMMM YYYY \u0433., H:mm`, LLLL: `dddd, D MMMM YYYY \u0433., H:mm` }, calendar: { sameDay: `[\u0421\u0435\u0433\u043E\u0434\u043D\u044F, \u0432] LT`, nextDay: `[\u0417\u0430\u0432\u0442\u0440\u0430, \u0432] LT`, lastDay: `[\u0412\u0447\u0435\u0440\u0430, \u0432] LT`, nextWeek: function(e4) {
      if (e4.week() !== this.week()) switch (this.day()) {
        case 0:
          return `[\u0412 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0435] dddd, [\u0432] LT`;
        case 1:
        case 2:
        case 4:
          return `[\u0412 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439] dddd, [\u0432] LT`;
        case 3:
        case 5:
        case 6:
          return `[\u0412 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0443\u044E] dddd, [\u0432] LT`;
      }
      else if (this.day() === 2) return `[\u0412\u043E] dddd, [\u0432] LT`;
      else return `[\u0412] dddd, [\u0432] LT`;
    }, lastWeek: function(e4) {
      if (e4.week() !== this.week()) switch (this.day()) {
        case 0:
          return `[\u0412 \u043F\u0440\u043E\u0448\u043B\u043E\u0435] dddd, [\u0432] LT`;
        case 1:
        case 2:
        case 4:
          return `[\u0412 \u043F\u0440\u043E\u0448\u043B\u044B\u0439] dddd, [\u0432] LT`;
        case 3:
        case 5:
        case 6:
          return `[\u0412 \u043F\u0440\u043E\u0448\u043B\u0443\u044E] dddd, [\u0432] LT`;
      }
      else if (this.day() === 2) return `[\u0412\u043E] dddd, [\u0432] LT`;
      else return `[\u0412] dddd, [\u0432] LT`;
    }, sameElse: `L` }, relativeTime: { future: `\u0447\u0435\u0440\u0435\u0437 %s`, past: `%s \u043D\u0430\u0437\u0430\u0434`, s: `\u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u0435\u043A\u0443\u043D\u0434`, ss: n3, m: n3, mm: n3, h: `\u0447\u0430\u0441`, hh: n3, d: `\u0434\u0435\u043D\u044C`, dd: n3, w: `\u043D\u0435\u0434\u0435\u043B\u044F`, ww: n3, M: `\u043C\u0435\u0441\u044F\u0446`, MM: n3, y: `\u0433\u043E\u0434`, yy: n3 }, meridiemParse: /ночи|утра|дня|вечера/i, isPM: function(e4) {
      return /^(дня|вечера)$/.test(e4);
    }, meridiem: function(e4, t4, n4) {
      return e4 < 4 ? `\u043D\u043E\u0447\u0438` : e4 < 12 ? `\u0443\u0442\u0440\u0430` : e4 < 17 ? `\u0434\u043D\u044F` : `\u0432\u0435\u0447\u0435\u0440\u0430`;
    }, dayOfMonthOrdinalParse: /\d{1,2}-(й|го|я)/, ordinal: function(e4, t4) {
      switch (t4) {
        case `M`:
        case `d`:
        case `DDD`:
          return e4 + `-\u0439`;
        case `D`:
          return e4 + `-\u0433\u043E`;
        case `w`:
        case `W`:
          return e4 + `-\u044F`;
        default:
          return e4;
      }
    }, week: { dow: 1, doy: 4 } });
  }));
})), ne = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    function t3(e4, t4) {
      var n4 = e4.split(`_`);
      return t4 % 10 == 1 && t4 % 100 != 11 ? n4[0] : t4 % 10 >= 2 && t4 % 10 <= 4 && (t4 % 100 < 10 || t4 % 100 >= 20) ? n4[1] : n4[2];
    }
    function n3(e4, n4, r3) {
      var i3 = { ss: n4 ? `\u0441\u0435\u043A\u0443\u043D\u0434\u0430_\u0441\u0435\u043A\u0443\u043D\u0434\u0438_\u0441\u0435\u043A\u0443\u043D\u0434` : `\u0441\u0435\u043A\u0443\u043D\u0434\u0443_\u0441\u0435\u043A\u0443\u043D\u0434\u0438_\u0441\u0435\u043A\u0443\u043D\u0434`, mm: n4 ? `\u0445\u0432\u0438\u043B\u0438\u043D\u0430_\u0445\u0432\u0438\u043B\u0438\u043D\u0438_\u0445\u0432\u0438\u043B\u0438\u043D` : `\u0445\u0432\u0438\u043B\u0438\u043D\u0443_\u0445\u0432\u0438\u043B\u0438\u043D\u0438_\u0445\u0432\u0438\u043B\u0438\u043D`, hh: n4 ? `\u0433\u043E\u0434\u0438\u043D\u0430_\u0433\u043E\u0434\u0438\u043D\u0438_\u0433\u043E\u0434\u0438\u043D` : `\u0433\u043E\u0434\u0438\u043D\u0443_\u0433\u043E\u0434\u0438\u043D\u0438_\u0433\u043E\u0434\u0438\u043D`, dd: `\u0434\u0435\u043D\u044C_\u0434\u043D\u0456_\u0434\u043D\u0456\u0432`, MM: `\u043C\u0456\u0441\u044F\u0446\u044C_\u043C\u0456\u0441\u044F\u0446\u0456_\u043C\u0456\u0441\u044F\u0446\u0456\u0432`, yy: `\u0440\u0456\u043A_\u0440\u043E\u043A\u0438_\u0440\u043E\u043A\u0456\u0432` };
      return r3 === `m` ? n4 ? `\u0445\u0432\u0438\u043B\u0438\u043D\u0430` : `\u0445\u0432\u0438\u043B\u0438\u043D\u0443` : r3 === `h` ? n4 ? `\u0433\u043E\u0434\u0438\u043D\u0430` : `\u0433\u043E\u0434\u0438\u043D\u0443` : e4 + ` ` + t3(i3[r3], +e4);
    }
    function r2(e4, t4) {
      var n4 = { nominative: `\u043D\u0435\u0434\u0456\u043B\u044F_\u043F\u043E\u043D\u0435\u0434\u0456\u043B\u043E\u043A_\u0432\u0456\u0432\u0442\u043E\u0440\u043E\u043A_\u0441\u0435\u0440\u0435\u0434\u0430_\u0447\u0435\u0442\u0432\u0435\u0440_\u043F\u2019\u044F\u0442\u043D\u0438\u0446\u044F_\u0441\u0443\u0431\u043E\u0442\u0430`.split(`_`), accusative: `\u043D\u0435\u0434\u0456\u043B\u044E_\u043F\u043E\u043D\u0435\u0434\u0456\u043B\u043E\u043A_\u0432\u0456\u0432\u0442\u043E\u0440\u043E\u043A_\u0441\u0435\u0440\u0435\u0434\u0443_\u0447\u0435\u0442\u0432\u0435\u0440_\u043F\u2019\u044F\u0442\u043D\u0438\u0446\u044E_\u0441\u0443\u0431\u043E\u0442\u0443`.split(`_`), genitive: `\u043D\u0435\u0434\u0456\u043B\u0456_\u043F\u043E\u043D\u0435\u0434\u0456\u043B\u043A\u0430_\u0432\u0456\u0432\u0442\u043E\u0440\u043A\u0430_\u0441\u0435\u0440\u0435\u0434\u0438_\u0447\u0435\u0442\u0432\u0435\u0440\u0433\u0430_\u043F\u2019\u044F\u0442\u043D\u0438\u0446\u0456_\u0441\u0443\u0431\u043E\u0442\u0438`.split(`_`) }, r3;
      return e4 === true ? n4.nominative.slice(1, 7).concat(n4.nominative.slice(0, 1)) : e4 ? (r3 = /(\[[ВвУу]\]) ?dddd/.test(t4) ? `accusative` : /\[?(?:минулої|наступної)? ?\] ?dddd/.test(t4) ? `genitive` : `nominative`, n4[r3][e4.day()]) : n4.nominative;
    }
    function i2(e4) {
      return function() {
        return e4 + `\u043E` + (this.hours() === 11 ? `\u0431` : ``) + `] LT`;
      };
    }
    return e3.defineLocale(`uk`, { months: { format: `\u0441\u0456\u0447\u043D\u044F_\u043B\u044E\u0442\u043E\u0433\u043E_\u0431\u0435\u0440\u0435\u0437\u043D\u044F_\u043A\u0432\u0456\u0442\u043D\u044F_\u0442\u0440\u0430\u0432\u043D\u044F_\u0447\u0435\u0440\u0432\u043D\u044F_\u043B\u0438\u043F\u043D\u044F_\u0441\u0435\u0440\u043F\u043D\u044F_\u0432\u0435\u0440\u0435\u0441\u043D\u044F_\u0436\u043E\u0432\u0442\u043D\u044F_\u043B\u0438\u0441\u0442\u043E\u043F\u0430\u0434\u0430_\u0433\u0440\u0443\u0434\u043D\u044F`.split(`_`), standalone: `\u0441\u0456\u0447\u0435\u043D\u044C_\u043B\u044E\u0442\u0438\u0439_\u0431\u0435\u0440\u0435\u0437\u0435\u043D\u044C_\u043A\u0432\u0456\u0442\u0435\u043D\u044C_\u0442\u0440\u0430\u0432\u0435\u043D\u044C_\u0447\u0435\u0440\u0432\u0435\u043D\u044C_\u043B\u0438\u043F\u0435\u043D\u044C_\u0441\u0435\u0440\u043F\u0435\u043D\u044C_\u0432\u0435\u0440\u0435\u0441\u0435\u043D\u044C_\u0436\u043E\u0432\u0442\u0435\u043D\u044C_\u043B\u0438\u0441\u0442\u043E\u043F\u0430\u0434_\u0433\u0440\u0443\u0434\u0435\u043D\u044C`.split(`_`) }, monthsShort: `\u0441\u0456\u0447_\u043B\u044E\u0442_\u0431\u0435\u0440_\u043A\u0432\u0456\u0442_\u0442\u0440\u0430\u0432_\u0447\u0435\u0440\u0432_\u043B\u0438\u043F_\u0441\u0435\u0440\u043F_\u0432\u0435\u0440_\u0436\u043E\u0432\u0442_\u043B\u0438\u0441\u0442_\u0433\u0440\u0443\u0434`.split(`_`), weekdays: r2, weekdaysShort: `\u043D\u0434_\u043F\u043D_\u0432\u0442_\u0441\u0440_\u0447\u0442_\u043F\u0442_\u0441\u0431`.split(`_`), weekdaysMin: `\u043D\u0434_\u043F\u043D_\u0432\u0442_\u0441\u0440_\u0447\u0442_\u043F\u0442_\u0441\u0431`.split(`_`), longDateFormat: { LT: `HH:mm`, LTS: `HH:mm:ss`, L: `DD.MM.YYYY`, LL: `D MMMM YYYY \u0440.`, LLL: `D MMMM YYYY \u0440., HH:mm`, LLLL: `dddd, D MMMM YYYY \u0440., HH:mm` }, calendar: { sameDay: i2(`[\u0421\u044C\u043E\u0433\u043E\u0434\u043D\u0456 `), nextDay: i2(`[\u0417\u0430\u0432\u0442\u0440\u0430 `), lastDay: i2(`[\u0412\u0447\u043E\u0440\u0430 `), nextWeek: i2(`[\u0423] dddd [`), lastWeek: function() {
      switch (this.day()) {
        case 0:
        case 3:
        case 5:
        case 6:
          return i2(`[\u041C\u0438\u043D\u0443\u043B\u043E\u0457] dddd [`).call(this);
        case 1:
        case 2:
        case 4:
          return i2(`[\u041C\u0438\u043D\u0443\u043B\u043E\u0433\u043E] dddd [`).call(this);
      }
    }, sameElse: `L` }, relativeTime: { future: `\u0437\u0430 %s`, past: `%s \u0442\u043E\u043C\u0443`, s: `\u0434\u0435\u043A\u0456\u043B\u044C\u043A\u0430 \u0441\u0435\u043A\u0443\u043D\u0434`, ss: n3, m: n3, mm: n3, h: `\u0433\u043E\u0434\u0438\u043D\u0443`, hh: n3, d: `\u0434\u0435\u043D\u044C`, dd: n3, M: `\u043C\u0456\u0441\u044F\u0446\u044C`, MM: n3, y: `\u0440\u0456\u043A`, yy: n3 }, meridiemParse: /ночі|ранку|дня|вечора/, isPM: function(e4) {
      return /^(дня|вечора)$/.test(e4);
    }, meridiem: function(e4, t4, n4) {
      return e4 < 4 ? `\u043D\u043E\u0447\u0456` : e4 < 12 ? `\u0440\u0430\u043D\u043A\u0443` : e4 < 17 ? `\u0434\u043D\u044F` : `\u0432\u0435\u0447\u043E\u0440\u0430`;
    }, dayOfMonthOrdinalParse: /\d{1,2}-(й|го)/, ordinal: function(e4, t4) {
      switch (t4) {
        case `M`:
        case `d`:
        case `DDD`:
        case `w`:
        case `W`:
          return e4 + `-\u0439`;
        case `D`:
          return e4 + `-\u0433\u043E`;
        default:
          return e4;
      }
    }, week: { dow: 1, doy: 7 } });
  }));
})), re = t(((t2, n2) => {
  (function(r2, i2) {
    typeof t2 == `object` && n2 !== void 0 && typeof e == `function` ? i2(l()) : typeof define == `function` && define.amd ? define([`../moment`], i2) : i2(r2.moment);
  })(t2, (function(e3) {
    return e3.defineLocale(`zh-cn`, { months: `\u4E00\u6708_\u4E8C\u6708_\u4E09\u6708_\u56DB\u6708_\u4E94\u6708_\u516D\u6708_\u4E03\u6708_\u516B\u6708_\u4E5D\u6708_\u5341\u6708_\u5341\u4E00\u6708_\u5341\u4E8C\u6708`.split(`_`), monthsShort: `1\u6708_2\u6708_3\u6708_4\u6708_5\u6708_6\u6708_7\u6708_8\u6708_9\u6708_10\u6708_11\u6708_12\u6708`.split(`_`), weekdays: `\u661F\u671F\u65E5_\u661F\u671F\u4E00_\u661F\u671F\u4E8C_\u661F\u671F\u4E09_\u661F\u671F\u56DB_\u661F\u671F\u4E94_\u661F\u671F\u516D`.split(`_`), weekdaysShort: `\u5468\u65E5_\u5468\u4E00_\u5468\u4E8C_\u5468\u4E09_\u5468\u56DB_\u5468\u4E94_\u5468\u516D`.split(`_`), weekdaysMin: `\u65E5_\u4E00_\u4E8C_\u4E09_\u56DB_\u4E94_\u516D`.split(`_`), longDateFormat: { LT: `HH:mm`, LTS: `HH:mm:ss`, L: `YYYY/MM/DD`, LL: `YYYY\u5E74M\u6708D\u65E5`, LLL: `YYYY\u5E74M\u6708D\u65E5Ah\u70B9mm\u5206`, LLLL: `YYYY\u5E74M\u6708D\u65E5ddddAh\u70B9mm\u5206`, l: `YYYY/M/D`, ll: `YYYY\u5E74M\u6708D\u65E5`, lll: `YYYY\u5E74M\u6708D\u65E5 HH:mm`, llll: `YYYY\u5E74M\u6708D\u65E5dddd HH:mm` }, meridiemParse: /凌晨|早上|上午|中午|下午|晚上/, meridiemHour: function(e4, t3) {
      return e4 === 12 && (e4 = 0), t3 === `\u51CC\u6668` || t3 === `\u65E9\u4E0A` || t3 === `\u4E0A\u5348` ? e4 : t3 === `\u4E0B\u5348` || t3 === `\u665A\u4E0A` ? e4 + 12 : e4 >= 11 ? e4 : e4 + 12;
    }, meridiem: function(e4, t3, n3) {
      var r2 = e4 * 100 + t3;
      return r2 < 600 ? `\u51CC\u6668` : r2 < 900 ? `\u65E9\u4E0A` : r2 < 1130 ? `\u4E0A\u5348` : r2 < 1230 ? `\u4E2D\u5348` : r2 < 1800 ? `\u4E0B\u5348` : `\u665A\u4E0A`;
    }, calendar: { sameDay: `[\u4ECA\u5929]LT`, nextDay: `[\u660E\u5929]LT`, nextWeek: function(e4) {
      return e4.week() === this.week() ? `[\u672C]dddLT` : `[\u4E0B]dddLT`;
    }, lastDay: `[\u6628\u5929]LT`, lastWeek: function(e4) {
      return this.week() === e4.week() ? `[\u672C]dddLT` : `[\u4E0A]dddLT`;
    }, sameElse: `L` }, dayOfMonthOrdinalParse: /\d{1,2}(日|月|周)/, ordinal: function(e4, t3) {
      switch (t3) {
        case `d`:
        case `D`:
        case `DDD`:
          return e4 + `\u65E5`;
        case `M`:
          return e4 + `\u6708`;
        case `w`:
        case `W`:
          return e4 + `\u5468`;
        default:
          return e4;
      }
    }, relativeTime: { future: `%s\u540E`, past: `%s\u524D`, s: `\u51E0\u79D2`, ss: `%d \u79D2`, m: `1 \u5206\u949F`, mm: `%d \u5206\u949F`, h: `1 \u5C0F\u65F6`, hh: `%d \u5C0F\u65F6`, d: `1 \u5929`, dd: `%d \u5929`, w: `1 \u5468`, ww: `%d \u5468`, M: `1 \u4E2A\u6708`, MM: `%d \u4E2A\u6708`, y: `1 \u5E74`, yy: `%d \u5E74` }, week: { dow: 1, doy: 4 } });
  }));
}));
n(), u(), d(), f(), p(), m(), ee(), h(), te(), ne(), re();
function ie(e3, t2, n2, r2) {
  let i2 = (r2 - 90) * (Math.PI / 180);
  return { x: e3 + n2 * Math.cos(i2), y: t2 + n2 * Math.sin(i2) };
}
function ae(e3, t2, n2, r2, i2) {
  let a2 = ie(e3, t2, n2, r2), o2 = ie(e3, t2, n2, i2), s2 = i2 - r2 <= 180 ? `0` : `1`;
  return [`M`, a2.x, a2.y, `A`, n2, n2, 0, s2, 1, o2.x, o2.y].join(` `);
}
function oe(e3) {
  return o(`svg`, { style: e3.style, viewBox: `0 0 44 35`, children: [a(`rect`, { fill: `#A1C8EC`, height: `35`, width: `44`, y: `0.00283`, x: `-0.01558` }), a(`line`, { stroke: `#7FABDA`, strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeWidth: `2`, fill: `none`, y2: `14.71955`, x2: `43.84278`, y1: `14.71955`, x1: `-0.01558` }), a(`path`, { fill: `#7FABDA`, d: `m9.98442,15.00283l-6,0l0,-5c0,-1.657 1.343,-3 3,-3l0,0c1.657,0 3,1.343 3,3l0,5z` }), a(`line`, { strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeLinecap: `round`, strokeWidth: `2`, stroke: `#7FABDA`, fill: `none`, y2: `3.00283`, x2: `8.98442`, y1: `3.00283`, x1: `4.98442` }), a(`line`, { strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeLinecap: `round`, strokeWidth: `2`, stroke: `#7FABDA`, fill: `none`, y2: `7.00283`, x2: `6.98442`, y1: `3.00283`, x1: `6.98442` }), a(`path`, { fill: `#7FABDA`, d: `m19.98442,15.00283l-6,0l0,-5c0,-1.657 1.343,-3 3,-3l0,0c1.657,0 3,1.343 3,3l0,5z` }), a(`line`, { strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeLinecap: `round`, strokeWidth: `2`, stroke: `#7FABDA`, fill: `none`, y2: `3.00283`, x2: `18.98442`, y1: `3.00283`, x1: `14.98442` }), a(`line`, { strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeLinecap: `round`, strokeWidth: `2`, stroke: `#7FABDA`, fill: `none`, y2: `7.00283`, x2: `16.98442`, y1: `3.00283`, x1: `16.98442` }), a(`path`, { fill: `#7FABDA`, d: `m29.98442,15.00283l-6,0l0,-5c0,-1.657 1.343,-3 3,-3l0,0c1.657,0 3,1.343 3,3l0,5z` }), a(`line`, { strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeLinecap: `round`, strokeWidth: `2`, stroke: `#7FABDA`, fill: `none`, y2: `3.00283`, x2: `28.98442`, y1: `3.00283`, x1: `24.98442` }), a(`line`, { strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeLinecap: `round`, strokeWidth: `2`, stroke: `#7FABDA`, fill: `none`, y2: `7.00283`, x2: `26.98442`, y1: `3.00283`, x1: `26.98442` }), a(`path`, { fill: `#7FABDA`, d: `m39.98442,15.00283l-6,0l0,-5c0,-1.657 1.343,-3 3,-3l0,0c1.657,0 3,1.343 3,3l0,5z` }), a(`line`, { strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeLinecap: `round`, strokeWidth: `2`, stroke: `#7FABDA`, fill: `none`, y2: `3.00283`, x2: `38.98442`, y1: `3.00283`, x1: `34.98442` }), a(`line`, { strokeMiterlimit: `10`, strokeLinejoin: `round`, strokeLinecap: `round`, strokeWidth: `2`, stroke: `#7FABDA`, fill: `none`, y2: `7.00283`, x2: `36.98442`, y1: `3.00283`, x1: `36.98442` }), a(`path`, { fill: `#6F98BC`, d: `m16.98442,31.00283c0,-6.627 -5.373,-12 -12,-12c-1.787,0 -3.476,0.401 -5,1.102l0,14.898l16.283,0c0.448,-1.253 0.717,-2.592 0.717,-4z` }), a(`path`, { fill: `#7FABDA`, d: `m12.98442,31.00283c0,-4.418 -3.582,-8 -8,-8c-1.893,0 -3.63,0.661 -5,1.76l0,10.24l11.918,0c0.685,-1.177 1.082,-2.54 1.082,-4z` }), a(`path`, { fill: `#568BB2`, d: `m13.98442,19.00283c-1.586,0 -3.087,0.33 -4.471,0.891c4.381,1.788 7.471,6.085 7.471,11.109c0,1.408 -0.269,2.747 -0.717,4l9,0c0.448,-1.253 0.717,-2.592 0.717,-4c0,-6.627 -5.373,-12 -12,-12z` }), a(`path`, { fill: `#7FABDA`, d: `m13.98442,23.00283c-0.024,0 -0.047,0.003 -0.071,0.003c1.904,2.124 3.071,4.921 3.071,7.997c0,1.408 -0.269,2.747 -0.717,4l4.636,0c0.685,-1.177 1.082,-2.54 1.082,-4c-0.001,-4.418 -3.583,-8 -8.001,-8z` }), a(`path`, { fill: `#6F98BC`, d: `m22.98442,19.00283c-1.586,0 -3.087,0.33 -4.471,0.891c4.381,1.788 7.471,6.085 7.471,11.109c0,1.408 -0.269,2.747 -0.717,4l9,0c0.448,-1.253 0.717,-2.592 0.717,-4c0,-6.627 -5.373,-12 -12,-12z` }), a(`path`, { fill: `#7FABDA`, d: `m22.98442,23.00283c-0.024,0 -0.047,0.003 -0.071,0.003c1.904,2.124 3.071,4.921 3.071,7.997c0,1.408 -0.269,2.747 -0.717,4l4.636,0c0.685,-1.177 1.082,-2.54 1.082,-4c-0.001,-4.418 -3.583,-8 -8.001,-8z` }), a(`path`, { fill: `#568BB2`, d: `m31.98442,19.00283c-1.586,0 -3.087,0.33 -4.471,0.891c4.381,1.788 7.471,6.085 7.471,11.109c0,1.408 -0.269,2.747 -0.717,4l9,0c0.448,-1.253 0.717,-2.592 0.717,-4c0,-6.627 -5.373,-12 -12,-12z` }), a(`path`, { fill: `#7FABDA`, d: `m31.98442,23.00283c-0.024,0 -0.047,0.003 -0.071,0.003c1.904,2.124 3.071,4.921 3.071,7.997c0,1.408 -0.269,2.747 -0.717,4l4.636,0c0.685,-1.177 1.082,-2.54 1.082,-4c-0.001,-4.418 -3.583,-8 -8.001,-8z` })] });
}
var g = { rotatedItem: { animation: `vis-2-widgets-nils-fork-rotation 10000ms infinite` }, body: { width: `100%`, display: `flex`, alignItems: `center`, justifyContent: `center` }, header: { width: `100%`, height: `15%`, display: `flex`, justifyContent: `right`, alignItems: `center` }, grayLed: { borderRadius: `50%`, backgroundColor: `#999`, marginRight: `3%`, marginTop: `4%` }, divider: { width: `95%`, height: `1%`, borderBottom: `1px solid grey` }, mainPart: { width: `90%`, height: `69%`, display: `flex`, alignItems: `center`, justifyContent: `center` }, centerText: { position: `absolute`, height: `100%`, width: `100%`, display: `flex`, alignItems: `center`, justifyContent: `center`, zIndex: 2, textAlign: `center` }, centerCircle: { position: `absolute`, height: `100%`, width: `100%`, borderRadius: `50%`, zIndex: 0, boxSizing: `border-box` }, footer: { width: `100%`, height: `14%`, display: `flex`, alignItems: `center`, justifyContent: `center`, overflow: `hidden`, textOverflow: `ellipsis` } }, _ = class e2 extends c {
  refDiv = r.createRef();
  statusOID;
  _updateInterval = null;
  constructor(e3) {
    super(e3), this.state = { ...this.state, object: { common: {} } }, s.locale(e3.context.lang);
  }
  static getWidgetInfo() {
    return { id: `tplNils2WasherDryer`, visSet: `vis-2-widgets-nils-fork`, visName: `WasherDryer`, visWidgetLabel: `washer_dryer`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard` }, { name: `brand`, label: `brand_name` }, { name: `brandColor`, type: `color`, label: `brand_color` }, { name: `type`, type: `select`, label: `type`, options: [{ value: `washer`, label: `washer` }, { value: `dryer`, label: `dryer` }, { value: `both`, label: `washer_and_dryer` }, { value: `dish`, label: `dishwasher` }] }, { name: `status-oid`, type: `id`, label: `status_id`, onChange: async () => {
    } }, { name: `start-time-oid`, type: `id`, label: `start_time_id` }, { name: `end-time-oid`, type: `id`, label: `end_time_id` }, { name: `dry-oid`, type: `id`, label: `wash_or_dry_id`, tooltip: `wash_or_dry_tooltip`, hidden: `data.type !== "both"` }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_washer_dryer.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  async propertiesUpdate() {
    if (this.statusOID === this.state.rxData[`status-oid`]) return;
    if (this.statusOID = this.state.rxData[`status-oid`], !this.statusOID || this.statusOID === `nothing_selected`) {
      this.setState({ object: { common: {} } });
      return;
    }
    let e3 = await this.props.context.socket.getObject(this.statusOID), t2 = { common: (e3 == null ? void 0 : e3.common) || {}, _id: (e3 == null ? void 0 : e3._id) || this.statusOID, native: {}, type: `state` };
    if (t2.common.states && Array.isArray(t2.common.states)) {
      let e4 = {};
      t2.common.states.forEach((t3) => e4[t3] = t3), t2.common.states = e4;
    }
    JSON.stringify(this.state.object) !== JSON.stringify(t2) && this.setState({ object: t2 });
  }
  componentWillUnmount() {
    super.componentWillUnmount(), this._updateInterval && clearInterval(this._updateInterval), this._updateInterval = null;
  }
  async componentDidMount() {
    super.componentDidMount(), await this.propertiesUpdate();
  }
  async onRxDataChanged() {
    await this.propertiesUpdate();
  }
  renderWasher(e3) {
    let t2;
    return e3.circle === `full` ? t2 = o(`div`, { style: { position: `absolute`, height: `100%`, width: `100%`, display: `flex`, alignItems: `center`, justifyContent: `center`, zIndex: 2 }, children: [a(`svg`, { viewBox: `-83 -83 166 166`, style: { position: `absolute`, top: 0, left: 0, width: `100%`, height: `100%` }, children: a(`path`, { d: ae(0, 0, 75, 0, e3.value), fill: `none`, style: { stroke: e3.color, strokeWidth: 15 } }) }), a(`svg`, { viewBox: `-83 -83 166 166`, style: { position: `absolute`, top: 0, left: 0, width: `100%`, height: `100%` }, children: a(`path`, { d: ae(0, 0, 75, e3.value, 359.999), fill: `none`, style: { stroke: e3.backgroundColor, strokeWidth: `15px` } }) })] }) : e3.circle === `short` && (t2 = o(i, { children: [a(`div`, { style: { ...g.centerCircle, border: `${e3.wSize / 20}px solid ${e3.backgroundColor}` } }), a(`div`, { style: { ...g.centerCircle, ...g.rotatedItem, zIndex: 1, borderTop: `${e3.wSize / 25}px solid ${e3.color}`, borderBottom: `${e3.wSize / 25}px solid ${e3.color}`, borderLeft: `${e3.wSize / 25}px solid ${e3.color}`, borderRight: `${e3.wSize / 25}px solid transparent` } })] })), o(`div`, { style: e3.style, children: [o(`div`, { style: g.header, children: [a(`div`, { style: { width: `30%`, height: `70%`, marginTop: `3%`, borderRadius: `8%`, border: `1px solid grey`, marginLeft: `3%`, overflow: `hidden`, display: `flex`, alignItems: `center`, justifyContent: `center`, color: this.state.rxData.brandColor || void 0, fontSize: (e3.brandLen || 0) <= 3 ? Math.round(e3.wSize / 10) : Math.round(e3.wSize / (e3.brandLen * 2.5)) }, children: this.state.rxData.brand }), a(`div`, { style: { flexGrow: 1 } }), a(`div`, { style: { ...g.grayLed, width: e3.wSize / 10, height: e3.wSize / 10 } }), a(`div`, { style: { ...g.grayLed, width: e3.wSize / 10, height: e3.wSize / 10 } }), a(`div`, { style: { width: e3.wSize / 10, height: e3.wSize / 10, borderRadius: `50%`, backgroundColor: e3.statusColor, marginRight: `10%`, marginTop: `4%` } })] }), a(`div`, { style: g.divider }), a(`div`, { style: g.mainPart, children: o(`div`, { style: { width: e3.wSize / 1.8, height: e3.wSize / 1.8, border: `${e3.wSize / 15}px solid grey`, borderRadius: `50%`, position: `relative` }, children: [t2, a(`div`, { style: { ...g.centerText, fontSize: e3.fontSize }, children: e3.timeText || `` })] }) }), a(`div`, { style: g.divider }), a(`div`, { style: { ...g.footer, color: e3.statusColor }, children: c.t(e3.status.toLowerCase()).replace(`vis_2_widgets_nils_`, ``) })] });
  }
  renderDishWasher(e3) {
    return o(`div`, { style: e3.style, children: [o(`div`, { style: g.header, children: [a(`div`, { style: { width: e3.wSize / 10, height: e3.wSize / 10, borderRadius: `50%`, backgroundColor: e3.statusColor, marginLeft: `3%`, marginTop: `4%` } }), a(`div`, { style: { flexGrow: 1 } }), a(`div`, { style: { width: `33%`, height: `70%`, marginTop: `3%`, borderRadius: `8%`, border: `1px solid grey`, overflow: `hidden`, display: `flex`, alignItems: `center`, justifyContent: `center`, color: this.state.rxData.brandColor || void 0, fontSize: e3.brandLen <= 3 ? Math.round(e3.wSize / 10) : Math.round(e3.wSize / (e3.brandLen * 2.5)) }, children: this.state.rxData.brand }), a(`div`, { style: { width: `33%` } })] }), a(`div`, { style: g.divider }), o(`div`, { style: g.mainPart, children: [a(oe, { style: { width: `100%`, height: `100%`, opacity: 0.5, filter: e3.running ? `` : `grayscale(1)` } }), a(`div`, { style: { ...g.centerText, fontSize: e3.fontSize }, children: e3.timeText || `` })] }), a(`div`, { style: g.divider }), a(`div`, { style: { ...g.footer, color: e3.statusColor }, children: c.t(e3.status.toLowerCase()).replace(`vis_2_widgets_nils_`, ``) })] });
  }
  renderWidgetBody(e3) {
    var _a, _b, _c, _d, _e;
    super.renderWidgetBody(e3);
    let t2 = { circle: `short`, wSize: 0, status: `inactive`, value: 0, brandLen: 50 }, n2 = ((_a = this.refDiv.current) == null ? void 0 : _a.clientWidth) || 0, r2 = ((_b = this.refDiv.current) == null ? void 0 : _b.clientHeight) || 0, i2 = 1.3;
    n2 && (t2.wSize = n2 * i2 < r2 ? n2 : r2 / 1.3), t2.style = { width: t2.wSize, height: t2.wSize * i2, display: `flex`, alignItems: `center`, flexDirection: `column`, margin: `auto`, fontSize: Math.round(t2.wSize / 10), borderRadius: Math.round(t2.wSize / 30), boxShadow: `1px 1px 5px 1px rgba(0,0,0,0.79)` }, t2.brandLen = ((_c = this.state.rxData.brand) == null ? void 0 : _c.length) || 0, t2.status = `stop`;
    let c2 = this.state.values[`${this.state.rxData[`status-oid`]}.val`];
    if (c2 === true || c2 === `true` ? (t2.running = true, t2.status = `run`) : c2 === `false` || c2 === false ? (t2.running = false, t2.status = `inactive`) : ((_e = (_d = this.state.object) == null ? void 0 : _d.common) == null ? void 0 : _e.states) ? (t2.status = (this.state.object.common.states[c2] || c2 || ``).toString().toLowerCase(), t2.running = t2.status.includes(`run`) || t2.status.includes(`active`) && !t2.status.includes(`inactive`)) : (t2.status = c2 || `stop`, t2.running = t2.status.includes(`run`) || t2.status.includes(`active`) && !t2.status.includes(`inactive`)), t2.backgroundColor = `#264d72`, t2.color = `#3679be`, t2.running ? (t2.statusColor = `#289f3c`, (this.state.rxData.type === `dryer` || this.state.rxData.type === `both` && this.state.values[`${this.state.rxData[`dry-oid`]}.val`]) && (t2.backgroundColor = `#9f883f`, t2.color = `#945521`, t2.statusColor = `#b24a00`)) : (t2.backgroundColor = `#565656`, t2.color = `#a2a2a2`, t2.statusColor = `#a2a2a2`), t2.running) {
      if (this.state.rxData[`start-time-oid`] && this.state.rxData[`end-time-oid`] && this.state.values[`${this.state.rxData[`end-time-oid`]}.val`] && this.state.values[`${this.state.rxData[`start-time-oid`]}.val`]) {
        let e4 = new Date(this.state.values[`${this.state.rxData[`end-time-oid`]}.val`]), n3 = new Date(this.state.values[`${this.state.rxData[`start-time-oid`]}.val`]), r3 = e4.getTime() - n3.getTime(), i3 = e4.getTime() - Date.now();
        if (r3 > 0 && e4.getTime() > Date.now()) {
          t2.value = Math.round((r3 - i3) / r3 * 360);
          let e5 = Math.floor(i3 / 1e3 / 60 / 60);
          t2.timeText = `${e5}:${Math.floor((i3 - e5 * 1e3 * 60 * 60) / 1e3 / 60).toString().padStart(2, `0`)}`, t2.circle = `full`;
        } else if (e4.getTime() > Date.now()) {
          let n4 = e4.getTime() - Date.now(), r4 = Math.floor(n4 / 1e3 / 60 / 60);
          t2.timeText = `${r4}:${Math.floor((n4 - r4 * 1e3 * 60 * 60) / 1e3 / 60).toString().padStart(2, `0`)}`;
        }
      } else if (this.state.rxData[`end-time-oid`]) {
        let e4 = new Date(this.state.values[`${this.state.rxData[`end-time-oid`]}.val`]).getTime() - Date.now();
        if (e4 > 0) {
          let n3 = Math.floor(e4 / 1e3 / 60 / 60);
          t2.timeText = `${n3}:${Math.floor((e4 - n3 * 1e3 * 60 * 60) / 1e3 / 60).toString().padStart(2, `0`)}`;
        }
      }
      t2.circle || (t2.circle = `short`), t2.fontSize = Math.round(t2.wSize / 5);
    } else if (this.state.rxData[`end-time-oid`] && this.state.values[`${this.state.rxData[`end-time-oid`]}.val`]) {
      let e4 = new Date(this.state.values[`${this.state.rxData[`end-time-oid`]}.val`]);
      Date.now() - e4.getTime() > 0 && Date.now() - e4.getTime() < 72e5 && (t2.timeText = s(e4).fromNow()), t2.fontSize = Math.round(t2.wSize / 10);
    }
    t2.timeText && !this._updateInterval ? this._updateInterval = setInterval(() => this.forceUpdate(), 3e4) : !t2.timeText && this._updateInterval && (clearInterval(this._updateInterval), this._updateInterval = null);
    let l2 = o(`div`, { style: { ...g.body, height: this.state.rxData.widgetTitle && !this.state.rxData.noCard && !e3.widget.usedInWidget ? `calc(100% - 36px)` : `100%` }, ref: this.refDiv, children: [a(`style`, { children: `
@keyframes vis-2-widgets-nils-fork-rotation {
    100% {
        transform: rotate(360deg);
    }
}
` }), t2.wSize ? this.state.rxData.type === `dish` ? this.renderDishWasher(t2) : this.renderWasher(t2) : null] });
    return this.state.rxData.noCard || e3.widget.usedInWidget ? l2 : this.wrapContent(l2);
  }
};
export {
  _ as default
};
