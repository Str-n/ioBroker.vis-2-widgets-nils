import { B as e, I as t } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { C as n, D as r, I as i, L as a, P as o, d as s, ft as c, pt as l } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as u } from "./Backspace-CRhYnPpV.js";
import { t as d } from "./Generic-BOiMPpxz.js";
e();
function f(e2) {
  let [f2, p] = t(``), [m, h] = t(false);
  return l(o, { open: true, onClose: () => e2.onClose(), children: [c(a, { children: d.t(`enter_pin`) }), l(i, { children: [c(`div`, { style: { padding: `10px 0px` }, children: c(n, { variant: `outlined`, fullWidth: true, type: m ? `text` : `password`, slotProps: { input: { readOnly: true, style: { textAlign: `center`, color: m ? `#ff3e3e` : `inherit` } } }, value: m ? d.t(`invalid_pin`) : f2 }) }), c(`div`, { style: { display: `grid`, gridTemplateColumns: `1fr 1fr 1fr`, gridGap: `10px` }, children: [1, 2, 3, 4, 5, 6, 7, 8, 9, `R`, 0, e2.pinCodeReturnButton].map((t2) => {
    let n2 = t2;
    return t2 === `backspace` ? n2 = c(u, {}) : t2 === `submit` && (n2 = c(s, {})), c(r, { variant: `outlined`, title: t2 === `R` ? f2 ? d.t(`reset`) : d.t(`close`) : t2 === e2.pinCodeReturnButton ? `enter` : ``, onClick: () => {
      if (t2 === `submit`) f2 === e2.pinCode ? e2.onClose(true) : (h(true), p(``), setTimeout(() => h(false), 500));
      else if (t2 === `backspace`) p(f2.slice(0, -1));
      else if (t2 === `R`) f2 ? p(``) : e2.onClose();
      else {
        let n3 = f2 + t2;
        p(n3), e2.pinCodeReturnButton === `backspace` && n3 === f2 && e2.onClose(true);
      }
    }, children: n2 === `R` ? f2 ? `R` : `x` : n2 }, t2);
  }) })] })] });
}
export {
  f as t
};
