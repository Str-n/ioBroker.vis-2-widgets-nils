import { B as e } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { ft as t, n, st as r, z as i } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as a } from "./Lightbulb-BbGK3Qf2.js";
import { t as o } from "./LightbulbOutlined-_xkblzYe.js";
import { t as s } from "./PowerSettingsNew-BNxDRF4G.js";
import { t as c } from "./Generic-BOiMPpxz.js";
var l = r(t(`path`, { d: `M3.27 3 2 4.27l5 5V13h3v9l3.58-6.14L17.73 20 19 18.73zM17 10h-4l4-8H7v2.18l8.46 8.46z` }), `FlashOff`), u = r(t(`path`, { d: `M7 2v11h3v9l7-12h-4l4-8z` }), `FlashOn`), d = r(t(`path`, { d: `M12 3c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1s1-.45 1-1V4c0-.55-.45-1-1-1m5.14 2.86c-.39.39-.38 1-.01 1.39 1.13 1.2 1.83 2.8 1.87 4.57.09 3.83-3.08 7.13-6.91 7.17C8.18 19.05 5 15.9 5 12c0-1.84.71-3.51 1.87-4.76.37-.39.37-1-.01-1.38-.4-.4-1.05-.39-1.43.02C3.98 7.42 3.07 9.47 3 11.74c-.14 4.88 3.83 9.1 8.71 9.25 5.1.16 9.29-3.93 9.29-9 0-2.37-.92-4.51-2.42-6.11-.38-.41-1.04-.42-1.44-.02` }), `PowerSettingsNewRounded`), f = r(t(`path`, { d: `M17 7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h10c2.76 0 5-2.24 5-5s-2.24-5-5-5M7 15c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3` }), `ToggleOff`), p = r(t(`path`, { d: `M17 7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h10c2.76 0 5-2.24 5-5s-2.24-5-5-5m0 8c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3` }), `ToggleOn`);
e();
var m = { flashon: u, flash_off: l, "flash-off": l, flashonoutlined: u, bulb: a, lightbulb: a, "lightbulb-outlined": o, lightbulboutlined: o, power: s, power_settings_new: s, "power-settings-new": s, power_settings_new_rounded: d, "power-settings-new-rounded": d, toggleon: p, toggle_off: f, "toggle-off": f, toggleoff: f };
function h(e3) {
  return (e3 || ``).trim().toLowerCase().replace(/\s+/g, `-`).replace(/_+/g, `-`).replace(/-+/g, `-`);
}
function g(e3) {
  if (!e3) return s;
  let t2 = h(e3), n2 = m[t2];
  if (n2) return n2;
  let r2 = t2.replace(/^mdi:/, ``).replace(/^material-icons:/, ``);
  return r2 && m[r2] ? m[r2] : null;
}
var _ = class e2 extends c {
  static getWidgetInfo() {
    return { id: `tplNils2SwitchButton`, visSet: `vis-2-widgets-nils-fork`, visName: `Switch button`, visWidgetLabel: `switch_button`, visAttrs: [{ name: `common`, fields: [{ name: `oid`, type: `id`, label: `switch_button_oid` }, { name: `color`, type: `color`, label: `switch_button_color` }, { name: `colorOn`, type: `color`, label: `switch_button_color_on` }, { name: `colorOff`, type: `color`, label: `switch_button_color_off` }, { name: `background`, type: `color`, label: `switch_button_background` }, { name: `backgroundOn`, type: `color`, label: `switch_button_background_on` }, { name: `backgroundOff`, type: `color`, label: `switch_button_background_off` }, { name: `readOnly`, type: `checkbox`, label: `read_only`, noBinding: false }, { name: `icon-on`, type: `icon64`, label: `switch_button_on_icon` }, { name: `icon-off`, type: `icon64`, label: `switch_button_off_icon` }] }], visDefaultStyle: { position: `absolute`, width: 40, height: 40, display: `inline-block` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_switch_button.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  isOn(e3) {
    if (e3 === true || e3 === `true`) return true;
    if (e3 === false || e3 === `false`) return false;
    if (typeof e3 == `number`) return e3 !== 0;
    if (typeof e3 == `string`) {
      let t2 = e3.trim().toLowerCase();
      if (t2 === `0` || t2 === `false`) return false;
      if (t2 === `1` || t2 === `true`) return true;
    }
    return !!e3;
  }
  getNextValue(e3) {
    let t2 = this.isOn(e3);
    if (typeof e3 == `number`) return +!t2;
    if (typeof e3 == `string`) {
      let n2 = e3.trim().toLowerCase();
      if (n2 === `0` || n2 === `1`) return +!t2;
    }
    return !t2;
  }
  getIconElement(e3) {
    let r2 = g(e3);
    return r2 ? t(r2, { style: { width: `70%`, height: `70%` } }) : t(n, { src: e3 || `power`, style: { width: `70%`, height: `70%`, color: `currentColor` } });
  }
  renderWidgetBody(e3) {
    super.renderWidgetBody(e3), e3.style.overflow = `visible`, e3.style.overflowX = `visible`, e3.style.overflowY = `visible`;
    let n2 = this.state.rxData.oid;
    if (!n2) return null;
    let r2 = this.state.values[`${n2}.val`], a2 = this.isOn(r2), o2 = a2 ? this.state.rxData[`icon-on`] : this.state.rxData[`icon-off`], s2 = (a2 ? this.state.rxData.colorOn : this.state.rxData.colorOff) || this.state.rxData.color, c2 = (a2 ? this.state.rxData.backgroundOn : this.state.rxData.backgroundOff) || this.state.rxData.background, l2 = this.state.rxData.readOnly === true || this.state.rxData.readOnly === `true`;
    return t(i, { size: `small`, color: a2 ? `primary` : `default`, disabled: l2, onClick: (e4) => {
      e4.stopPropagation(), l2 || this.props.context.setValue(n2, this.getNextValue(r2));
    }, sx: { width: `100%`, height: `100%`, minWidth: 0, minHeight: 0, ...c2 ? { backgroundColor: c2 } : {}, ...c2 ? { "&:hover": { backgroundColor: c2 } } : {}, ...s2 ? { color: s2 } : {}, padding: 0 }, "aria-label": a2 ? `on` : `off`, children: this.getIconElement(o2) });
  }
};
export {
  _ as default
};
