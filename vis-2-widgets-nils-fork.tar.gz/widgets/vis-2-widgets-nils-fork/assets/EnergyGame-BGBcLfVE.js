import { B as e, g as t } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { dt as n, ft as r, pt as i } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as a } from "./Generic-BOiMPpxz.js";
e();
var o = { POINT: 1400, COMBO: 2400, NEW_RECORD: 3600 }, s = { POINT: 1, COMBO: 2, NEW_RECORD: 3 }, c = { POINT: 6, COMBO: 12, NEW_RECORD: 16 };
function l(e3) {
  if (e3 == null || typeof e3 == `boolean`) return null;
  let t2 = typeof e3 == `number` ? e3 : typeof e3 == `string` ? Number(e3.trim().replace(`,`, `.`)) : NaN;
  return Number.isFinite(t2) ? t2 : null;
}
function u(e3) {
  let t2 = l(e3);
  return t2 === null ? null : Math.round(t2);
}
function d(e3) {
  let t2 = l(e3);
  return t2 === null || t2 < 0 ? null : Math.floor(t2);
}
function f(e3) {
  let t2 = l(e3);
  if (t2 === null) return null;
  let n2 = Math.round(t2);
  return n2 >= 1 ? n2 : null;
}
function p(e3) {
  return e3 === true || e3 === 1 || typeof e3 == `string` && [`true`, `1`, `on`, `yes`].includes(e3.trim().toLowerCase());
}
var m = (e3) => {
  let t2 = typeof e3 == `string` || typeof e3 == `number` ? String(e3).trim() : ``;
  return t2 ? t2.length > 24 ? `${t2.slice(0, 23)}\u2026` : t2 : ``;
};
function h(e3) {
  try {
    if (Array.isArray(e3)) return e3.map(m).filter(Boolean).slice(0, 50);
    if (e3 && typeof e3 == `object`) return h(e3.lightNames);
    if (typeof e3 != `string`) return [];
    let t2 = e3.trim();
    if (!t2 || t2 === `[]` || t2 === `null`) return [];
    if (t2.startsWith(`[`) || t2.startsWith(`{`)) try {
      let e4 = JSON.parse(t2);
      if (Array.isArray(e4) || e4 && typeof e4 == `object`) return h(e4);
    } catch {
    }
    return t2.replace(/^[[{]|[\]}]$/g, ``).split(/[,;•|]/).map((e4) => m(e4.replace(/^["']|["']$/g, ``))).filter(Boolean).slice(0, 50);
  } catch {
    return [];
  }
}
function g(e3, t2 = 3, n2 = ` \u2022 `) {
  return (e3 == null ? void 0 : e3.length) ? e3.length <= t2 ? e3.join(n2) : `${e3.slice(0, t2).join(n2)} +${e3.length - t2}` : ``;
}
function _(e3, t2) {
  if (typeof e3 == `string`) {
    let t3 = e3.trim().toUpperCase();
    if (t3 === `POINT` || t3 === `COMBO` || t3 === `NEW_RECORD`) return t3;
  }
  return t2 !== null && t2 > 1 ? `COMBO` : `POINT`;
}
function v(e3) {
  try {
    let t2 = typeof e3 == `string` ? JSON.parse(e3) : e3;
    if (!t2 || typeof t2 != `object`) return null;
    let n2 = t2, r2 = d(n2.sequence);
    return r2 === null ? null : { sequence: r2, delta: f(n2.delta), kind: n2.kind, lightCount: f(n2.lightCount), lightNames: h(n2.lightNames) };
  } catch {
    return null;
  }
}
function y(e3, t2) {
  if (e3 === null) return `\u2014`;
  try {
    return new Intl.NumberFormat(t2 || void 0).format(e3);
  } catch {
    return String(e3);
  }
}
var b = class {
  baseline = null;
  rebaselinePending = false;
  requestRebaseline() {
    this.rebaselinePending = true;
  }
  reset() {
    this.baseline = null, this.rebaselinePending = false;
  }
  observe(e3) {
    return e3 === null ? { animate: false, sequence: null, reason: `NO_VALUE` } : this.baseline === null ? (this.baseline = e3, this.rebaselinePending = false, { animate: false, sequence: e3, reason: `BASELINE` }) : this.rebaselinePending ? (this.baseline = e3, this.rebaselinePending = false, { animate: false, sequence: e3, reason: `REBASELINE` }) : e3 === this.baseline ? { animate: false, sequence: e3, reason: `UNCHANGED` } : e3 < this.baseline ? (this.baseline = e3, { animate: false, sequence: e3, reason: `REGRESSION` }) : (this.baseline = e3, { animate: true, sequence: e3, reason: `NEW_EVENT` });
  }
};
function x(e3, t2, n2) {
  return !e3 || s[n2.kind] >= s[e3.kind] ? { active: n2, pending: null, restarted: true } : { active: e3, pending: t2 && s[t2.kind] > s[n2.kind] ? t2 : n2, restarted: false };
}
function S(e3) {
  let t2 = e3 >>> 0;
  return () => {
    t2 = t2 + 1831565813 >>> 0;
    let e4 = t2;
    return e4 = Math.imul(e4 ^ e4 >>> 15, e4 | 1), e4 ^= e4 + Math.imul(e4 ^ e4 >>> 7, e4 | 61), ((e4 ^ e4 >>> 14) >>> 0) / 4294967296;
  };
}
function C(e3, t2, n2) {
  let r2 = Math.max(0, Math.min(24, Math.floor(e3))), i2 = S(t2 || 1);
  return Array.from({ length: r2 }, (e4, t3) => {
    let a2 = t3 / r2 * Math.PI * 2 + (i2() - 0.5) * 0.6, o2 = n2 * (0.55 + i2() * 0.45);
    return { dx: Math.round(Math.cos(a2) * o2), dy: Math.round(Math.sin(a2) * o2), delayMs: Math.round(i2() * 180), size: 3 + Math.round(i2() * 3), durationMs: 700 + Math.round(i2() * 400) };
  });
}
function w() {
  try {
    return typeof window < `u` && typeof window.matchMedia == `function` && window.matchMedia(`(prefers-reduced-motion: reduce)`).matches;
  } catch {
    return false;
  }
}
var T = `nils-energy-game-styles`, E = `
.nils-eg{position:relative;width:100%;height:100%;display:flex;flex-direction:column;justify-content:space-between;overflow:hidden;box-sizing:border-box;user-select:none}
.nils-eg *{box-sizing:border-box}.nils-eg-num{font-variant-numeric:tabular-nums;line-height:1;white-space:nowrap}.nils-eg-label{text-transform:uppercase;letter-spacing:.16em;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nils-eg-overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;text-align:center;pointer-events:none}.nils-eg-centre{position:absolute;left:50%;top:50%;pointer-events:none}
@keyframes nils-eg-rise{0%{opacity:0;transform:translate3d(0,14px,0) scale(.8)}18%{opacity:1;transform:translate3d(0,-2px,0) scale(1.12)}72%{opacity:1;transform:translate3d(0,-10px,0) scale(1)}100%{opacity:0;transform:translate3d(0,-24px,0) scale(.96)}}
@keyframes nils-eg-fade{0%{opacity:0}14%{opacity:1}82%{opacity:1}100%{opacity:0}}@keyframes nils-eg-ring{0%{opacity:.8;transform:translate(-50%,-50%) scale(.5)}100%{opacity:0;transform:translate(-50%,-50%) scale(1.8)}}
@keyframes nils-eg-spark{0%{opacity:0;transform:translate3d(0,0,0) scale(.3)}15%{opacity:1}100%{opacity:0;transform:translate3d(var(--dx),var(--dy),0) scale(1)}}@keyframes nils-eg-pop{30%{transform:scale(1.14)}100%{transform:scale(1)}}
@keyframes nils-eg-badge{0%{opacity:0;transform:translateY(-12px) scale(.7)}16%{opacity:1;transform:translateY(0) scale(1.08)}28%{transform:scale(1)}86%{opacity:1}100%{opacity:0}}@keyframes nils-eg-shine{0%{transform:translateX(-180%) skewX(-20deg)}100%{transform:translateX(280%) skewX(-20deg)}}
@keyframes nils-eg-breathe{0%,100%{opacity:.3}50%{opacity:.8}}@keyframes nils-eg-twinkle{0%,100%{opacity:0;transform:scale(.4) rotate(0)}50%{opacity:.9;transform:scale(1) rotate(45deg)}}
.nils-eg-rise{animation:nils-eg-rise var(--dur) cubic-bezier(.2,.8,.2,1) both}.nils-eg-fade{animation:nils-eg-fade var(--dur) ease-in-out both}.nils-eg-ring{animation:nils-eg-ring .9s ease-out both}.nils-eg-spark{animation:nils-eg-spark var(--sdur) ease-out both}.nils-eg-pop{animation:nils-eg-pop .6s ease-out both}.nils-eg-badge{animation:nils-eg-badge var(--dur) cubic-bezier(.2,.8,.2,1) both}.nils-eg-shine{animation:nils-eg-shine 1.4s ease-in-out .3s both}.nils-eg-breathe{animation:nils-eg-breathe 4s ease-in-out infinite}.nils-eg-twinkle{animation:nils-eg-twinkle var(--tdur) ease-in-out var(--tdelay) infinite}
@media(prefers-reduced-motion:reduce){.nils-eg-motion{animation:none!important;opacity:0!important}.nils-eg-breathe,.nils-eg-twinkle{animation:none!important}}
`;
function D() {
  if (typeof document > `u` || document.getElementById(T)) return;
  let e3 = document.createElement(`style`);
  e3.id = T, e3.textContent = E, document.head.appendChild(e3);
}
var O = (e3, t2, n2) => Math.max(t2, Math.min(n2, e3)), k = ({ size: e3, color: t2 }) => r(`svg`, { width: e3, height: e3, viewBox: `0 0 24 24`, "aria-hidden": `true`, children: r(`path`, { d: `M13 2 3 14h7l-1 8 10-12h-7l1-8z`, fill: t2 }) }), A = ({ size: e3, color: t2 }) => r(`svg`, { width: e3, height: e3, viewBox: `0 0 24 24`, "aria-hidden": `true`, children: r(`path`, { d: `M7 3h10v2h3v3a5 5 0 0 1-4.2 4.94A5 5 0 0 1 13 15.9V18h3v2H8v-2h3v-2.1A5 5 0 0 1 8.2 13 5 5 0 0 1 4 8V5h3V3zM6 7v1a3 3 0 0 0 1.6 2.65A7 7 0 0 1 7 8.5V7H6zm12 0h-1v1.5c0 .77-.2 1.5-.6 2.15A3 3 0 0 0 18 8V7z`, fill: t2 }) }), j = ({ size: e3, color: t2 }) => r(`svg`, { width: e3, height: e3, viewBox: `0 0 24 24`, "aria-hidden": `true`, children: r(`path`, { d: `M12 0l2.5 9.5L24 12l-9.5 2.5L12 24l-2.5-9.5L0 12l9.5-2.5z`, fill: t2 }) });
function M({ color: e3, reducedMotion: t2 }) {
  return i(n, { children: [r(`span`, { className: t2 ? void 0 : `nils-eg-breathe`, "aria-hidden": `true`, style: { position: `absolute`, inset: -2, borderRadius: 12, boxShadow: `0 0 0 1px ${e3}66,0 0 14px ${e3}55`, opacity: t2 ? 0.5 : void 0 } }), !t2 && [[`4%`, `8%`, `7s`, `0s`], [`88%`, `4%`, `9s`, `2.5s`], [`92%`, `70%`, `8s`, `5s`], [`8%`, `74%`, `7.5s`, `1.3s`]].map(([t3, n2, i2, a2], o2) => r(`span`, { className: `nils-eg-twinkle`, "aria-hidden": `true`, style: { position: `absolute`, left: t3, top: n2, "--tdur": i2, "--tdelay": a2 }, children: r(j, { size: 7, color: e3 }) }, o2))] });
}
function N({ event: e3, dailyText: t2, props: a2, base: s2 }) {
  let l2 = `${o[e3.kind]}ms`, u2 = e3.kind === `NEW_RECORD`, d2 = e3.kind === `COMBO`, f2 = u2 ? a2.palette.gold : a2.palette.accent, p2 = O(s2 * (u2 ? 0.16 : d2 ? 0.19 : 0.15), 26, 84), m2 = O(s2 * 0.04, 10, 16), h2 = e3.delta === null ? `` : `+${e3.delta}`, _2 = a2.showLightNames && !a2.compact ? g(e3.lightNames) : ``, v2 = a2.reducedMotion ? [] : C(c[e3.kind], e3.sequence, s2 * 0.42), y2 = u2 ? a2.t(`eg_new_record`) : d2 ? a2.t(`eg_energy_combo`) : a2.t(`eg_energy_saved`), b2 = u2 ? h2 ? `${h2} ${a2.t(`eg_energy`)}` : `` : d2 ? _2 || (e3.lightCount || e3.delta ? a2.t(`eg_lights_saved`, e3.lightCount || e3.delta || 0) : ``) : _2;
  return i(`div`, { className: `nils-eg-overlay`, "aria-hidden": `true`, style: { "--dur": l2 }, children: [u2 && r(`span`, { className: `nils-eg-fade`, style: { position: `absolute`, inset: 0, background: a2.palette.mode === `dark` ? `rgba(0,0,0,.55)` : `rgba(255,255,255,.72)` } }), !a2.reducedMotion && i(n, { children: [r(`span`, { className: `nils-eg-centre nils-eg-ring nils-eg-motion`, style: { width: s2 * 0.5, height: s2 * 0.5, borderRadius: `50%`, border: `2px solid ${f2}` } }), (d2 || u2) && r(`span`, { className: `nils-eg-centre nils-eg-ring nils-eg-motion`, style: { width: s2 * 0.5, height: s2 * 0.5, borderRadius: `50%`, border: `1px solid ${f2}`, animationDelay: `.18s` } }), v2.map((e4, t3) => r(`span`, { className: `nils-eg-centre nils-eg-spark nils-eg-motion`, style: { width: e4.size, height: e4.size, margin: -e4.size / 2, borderRadius: `50%`, background: f2, boxShadow: `0 0 6px ${f2}`, "--dx": `${e4.dx}px`, "--dy": `${e4.dy}px`, "--sdur": `${e4.durationMs}ms`, animationDelay: `${e4.delayMs}ms` } }, t3)), u2 && [[`10%`, `12%`], [`86%`, `10%`], [`12%`, `82%`], [`84%`, `80%`]].map(([e4, t3], n2) => r(`span`, { style: { position: `absolute`, left: e4, top: t3 }, children: r(j, { size: O(s2 * 0.05, 10, 22), color: a2.palette.gold }) }, n2))] }), r(`div`, { className: u2 ? `nils-eg-badge` : a2.reducedMotion ? `nils-eg-fade` : `nils-eg-rise`, style: { position: `relative` }, children: u2 ? i(n, { children: [r(`div`, { className: `nils-eg-label`, style: { fontSize: O(s2 * 0.045, 11, 18), fontWeight: 800, color: a2.palette.gold, padding: `4px 14px`, border: `1px solid ${a2.palette.gold}`, borderRadius: 999, display: `inline-block`, marginBottom: 8 }, children: y2 }), i(`div`, { style: { position: `relative`, display: `flex`, alignItems: `center`, justifyContent: `center`, gap: 10, overflow: `hidden`, borderRadius: 12 }, children: [r(A, { size: p2 * 0.9, color: a2.palette.gold }), r(`span`, { className: `nils-eg-num`, style: { fontSize: p2, fontWeight: 800, color: a2.palette.text, textShadow: `0 0 ${Math.round(s2 * 0.05)}px ${f2}99` }, children: t2 }), !a2.reducedMotion && r(`span`, { className: `nils-eg-shine nils-eg-motion`, style: { position: `absolute`, inset: `0 auto 0 0`, width: `35%`, background: `linear-gradient(90deg,transparent,${a2.palette.gold}55,transparent)` } })] }), b2 && r(`div`, { className: `nils-eg-label`, style: { fontSize: m2, fontWeight: 700, color: a2.palette.gold, marginTop: 6 }, children: b2 })] }) : i(n, { children: [i(`div`, { style: { display: `flex`, alignItems: `center`, justifyContent: `center`, gap: 6 }, children: [r(k, { size: p2 * 0.55, color: f2 }), r(`span`, { className: `nils-eg-num`, style: { fontSize: p2, fontWeight: 800, color: f2, textShadow: `0 0 ${Math.round(s2 * 0.05)}px ${f2}99` }, children: h2 || `\u26A1` })] }), r(`div`, { className: `nils-eg-label`, style: { fontSize: m2, fontWeight: 700, color: a2.palette.text, marginTop: 4 }, children: y2 }), b2 && r(`div`, { style: { fontSize: m2, color: a2.palette.textSecondary, marginTop: 2, maxWidth: `90%`, overflow: `hidden`, textOverflow: `ellipsis`, whiteSpace: `nowrap` }, children: b2 })] }) })] });
}
function P(e3) {
  let t2 = Math.max(120, e3.width || 400), n2 = Math.max(80, e3.height || 260), a2 = e3.compact || t2 < 300 || n2 < 190, o2 = Math.max(150, Math.min(t2, n2 * 1.45)), s2 = O(o2 * (a2 ? 0.17 : 0.2), 30, 96), c2 = O(o2 * 0.075, 14, 32), l2 = O(o2 * 0.03, 9, 13), u2 = a2 ? 8 : O(o2 * 0.035, 10, 20), d2 = y(e3.daily, e3.lang), f2 = e3.animationsEnabled ? e3.activeEvent : null, p2 = e3.recordBrokenAt ? new Date(e3.recordBrokenAt).toLocaleTimeString(e3.lang || void 0) : void 0;
  return i(`div`, { className: `nils-eg`, style: { padding: u2, color: e3.palette.text }, children: [e3.showTitle && !a2 && r(`div`, { className: `nils-eg-label`, style: { fontSize: l2, fontWeight: 700, color: e3.palette.textSecondary, textAlign: `center` }, children: e3.labels.title }), i(`div`, { style: { flex: 1, display: `flex`, flexDirection: `column`, alignItems: `center`, justifyContent: `center`, minHeight: 0 }, children: [!a2 && r(k, { size: O(o2 * 0.06, 14, 26), color: e3.palette.accent }), r(`div`, { className: `nils-eg-num${f2 && !e3.reducedMotion ? ` nils-eg-pop` : ``}`, role: `status`, "aria-live": `polite`, "aria-label": `${e3.labels.daily}: ${e3.daily === null ? e3.t(`eg_score_unavailable`) : d2}`, style: { fontSize: s2, fontWeight: 800, minWidth: `${Math.max(2, d2.length) * 0.62}em`, textAlign: `center`, textShadow: `0 0 ${Math.round(s2 * 0.25)}px ${e3.palette.accent}66`, marginTop: a2 ? 0 : 4 }, children: d2 }, (f2 == null ? void 0 : f2.sequence) || `idle`), r(`div`, { className: `nils-eg-label`, style: { fontSize: l2, fontWeight: 700, color: e3.palette.accent, marginTop: 6 }, children: e3.labels.daily })] }), i(`div`, { style: { display: `flex`, justifyContent: `space-between`, alignItems: `flex-end`, gap: 12 }, children: [i(`div`, { style: { minWidth: 0, flex: 1 }, children: [r(`div`, { className: `nils-eg-num`, style: { fontSize: c2, fontWeight: 700 }, "aria-label": `${e3.labels.overall}: ${y(e3.overall, e3.lang)}`, children: y(e3.overall, e3.lang) }), r(`div`, { className: `nils-eg-label`, style: { fontSize: l2, color: e3.palette.textSecondary, marginTop: 3 }, children: e3.labels.overall })] }), i(`div`, { title: p2, style: { position: `relative`, minWidth: 0, flex: 1, display: `flex`, flexDirection: `column`, alignItems: `flex-end`, padding: `6px 10px`, borderRadius: 12 }, children: [e3.highScoreToday && e3.recordSparkles && r(M, { color: e3.palette.gold, reducedMotion: e3.reducedMotion }), i(`div`, { style: { display: `flex`, alignItems: `center`, gap: 6 }, children: [r(A, { size: c2 * 0.95, color: e3.highScoreToday ? e3.palette.gold : e3.palette.textSecondary }), r(`span`, { className: `nils-eg-num`, style: { fontSize: c2, fontWeight: 700, color: e3.highScoreToday ? e3.palette.gold : e3.palette.text }, "aria-label": `${e3.labels.record}: ${y(e3.highScore, e3.lang)}`, children: y(e3.highScore, e3.lang) })] }), i(`div`, { style: { display: `flex`, alignItems: `center`, gap: 6, marginTop: 3 }, children: [e3.highScoreToday && r(`span`, { className: `nils-eg-label`, style: { fontSize: Math.max(8, l2 - 2), fontWeight: 800, color: e3.palette.gold, border: `1px solid ${e3.palette.gold}88`, borderRadius: 999, padding: `1px 6px` }, children: e3.t(`eg_new_record`) }), r(`span`, { className: `nils-eg-label`, style: { fontSize: l2, color: e3.palette.textSecondary }, children: e3.labels.record })] })] })] }), f2 && r(N, { event: f2, dailyText: d2, props: e3, base: o2 }, f2.sequence)] });
}
e();
var F = `0_userdata.0.energyGame`;
function I(e3, ...t2) {
  return a.t(e3, ...t2.map(String));
}
var L = class e2 extends a {
  tracker = new b();
  snapshotTimer = null;
  eventTimer = null;
  resizeObserver = null;
  motionQuery = null;
  rootRef = t.createRef();
  unmounted = false;
  wasConnected = null;
  constructor(e3) {
    super(e3), this.state = { ...this.state, activeEvent: null, pendingEvent: null, reducedMotion: w(), size: { width: 0, height: 0 } };
  }
  static getWidgetInfo() {
    return { id: `tplNils2EnergyGame`, visSet: `vis-2-widgets-nils-fork`, visName: `EnergyGame`, visWidgetLabel: `energy_game`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `widgetTitle`, label: `name`, hidden: `data.noCard`, default: `Energy Saver` }] }, { name: `eg_scores`, label: `group_eg_scores`, fields: [{ name: `oid_daily`, type: `id`, label: `eg_oid_daily`, default: `${F}.score.daily` }, { name: `oid_overall`, type: `id`, label: `eg_oid_overall`, default: `${F}.score.overall` }, { name: `oid_high_score`, type: `id`, label: `eg_oid_high_score`, default: `${F}.score.highScore` }, { name: `oid_high_score_today`, type: `id`, label: `eg_oid_high_score_today`, default: `${F}.day.highScoreToday` }, { name: `oid_record_broken_at`, type: `id`, label: `eg_oid_record_broken_at`, default: `${F}.day.recordBrokenAt` }] }, { name: `eg_event`, label: `group_eg_event`, fields: [{ name: `oid_seq`, type: `id`, label: `eg_oid_seq`, default: `${F}.event.sequence` }, { name: `oid_delta`, type: `id`, label: `eg_oid_delta`, default: `${F}.event.delta` }, { name: `oid_kind`, type: `id`, label: `eg_oid_kind`, default: `${F}.event.kind` }, { name: `oid_light_count`, type: `id`, label: `eg_oid_light_count`, default: `${F}.event.lightCount` }, { name: `oid_light_names`, type: `id`, label: `eg_oid_light_names`, default: `${F}.event.lightNames` }, { name: `oid_event_timestamp`, type: `id`, label: `eg_oid_event_timestamp`, default: `${F}.event.timestamp` }, { name: `oid_event_json`, type: `id`, label: `eg_oid_event_json`, default: `${F}.event.json` }] }, { name: `eg_labels`, label: `group_eg_labels`, fields: [{ name: `label_daily`, type: `text`, label: `eg_label_daily` }, { name: `label_overall`, type: `text`, label: `eg_label_overall` }, { name: `label_record`, type: `text`, label: `eg_label_record` }, { name: `label_unit`, type: `text`, label: `eg_label_unit` }] }, { name: `eg_behavior`, label: `group_eg_behavior`, fields: [{ name: `animations`, type: `checkbox`, label: `eg_animations`, default: true }, { name: `show_light_names`, type: `checkbox`, label: `eg_show_light_names`, default: true }, { name: `record_sparkles`, type: `checkbox`, label: `eg_record_sparkles`, default: true }, { name: `compact`, type: `checkbox`, label: `eg_compact`, default: false }] }, { name: `eg_appearance`, label: `group_eg_appearance`, fields: [{ name: `accent_color`, type: `color`, label: `eg_accent_color` }] }], visDefaultStyle: { width: 400, height: 260, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_energy_game.svg` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  componentDidMount() {
    super.componentDidMount(), D();
    let e3 = this.rootRef.current;
    if (e3 && (this.applySize(e3.clientWidth, e3.clientHeight), typeof ResizeObserver < `u` && (this.resizeObserver = new ResizeObserver((e4) => {
      var _a;
      let t3 = (_a = e4[0]) == null ? void 0 : _a.contentRect;
      t3 && this.applySize(t3.width, t3.height);
    }), this.resizeObserver.observe(e3))), typeof window < `u` && typeof window.matchMedia == `function`) {
      this.motionQuery = window.matchMedia(`(prefers-reduced-motion: reduce)`);
      let e4 = this.onMotionChange;
      typeof this.motionQuery.addEventListener == `function` ? this.motionQuery.addEventListener(`change`, e4) : typeof this.motionQuery.addListener == `function` && this.motionQuery.addListener(e4);
    }
    typeof document < `u` && document.addEventListener(`visibilitychange`, this.onVisibilityChange);
    let t2 = this.getSocket();
    (t2 == null ? void 0 : t2.registerConnectionHandler) && t2.registerConnectionHandler(this.onConnectionChange), this.checkSequence();
  }
  componentDidUpdate(e3, t2) {
    var _a, _b;
    super.componentDidUpdate(e3, t2), ((_a = t2.rxData) == null ? void 0 : _a.oid_seq) !== ((_b = this.state.rxData) == null ? void 0 : _b.oid_seq) && (this.tracker.reset(), this.cancelTransient()), this.checkSequence();
  }
  componentWillUnmount() {
    var _a;
    this.unmounted = true, this.cancelTransient(), (_a = this.resizeObserver) == null ? void 0 : _a.disconnect(), this.resizeObserver = null, this.motionQuery && (typeof this.motionQuery.removeEventListener == `function` ? this.motionQuery.removeEventListener(`change`, this.onMotionChange) : typeof this.motionQuery.removeListener == `function` && this.motionQuery.removeListener(this.onMotionChange)), this.motionQuery = null, typeof document < `u` && document.removeEventListener(`visibilitychange`, this.onVisibilityChange);
    let e3 = this.getSocket();
    (e3 == null ? void 0 : e3.unregisterConnectionHandler) && e3.unregisterConnectionHandler(this.onConnectionChange), super.componentWillUnmount();
  }
  getSocket() {
    var _a;
    return ((_a = this.props.context) == null ? void 0 : _a.socket) || this.props.socket || null;
  }
  applySize(e3, t2) {
    if (this.unmounted) return;
    let n2 = { width: Math.round(e3), height: Math.round(t2) };
    (Math.abs(n2.width - this.state.size.width) > 2 || Math.abs(n2.height - this.state.size.height) > 2) && this.setState({ size: n2 });
  }
  readValue(e3) {
    var _a;
    let t2 = (_a = this.state.rxData) == null ? void 0 : _a[e3];
    return typeof t2 == `string` && t2 ? this.getPropertyValue(e3) : void 0;
  }
  cancelTransient() {
    this.snapshotTimer && (this.snapshotTimer = (clearTimeout(this.snapshotTimer), null)), this.eventTimer && (this.eventTimer = (clearTimeout(this.eventTimer), null)), !this.unmounted && (this.state.activeEvent || this.state.pendingEvent) && this.setState({ activeEvent: null, pendingEvent: null });
  }
  onMotionChange = () => {
    this.unmounted || this.setState({ reducedMotion: w() });
  };
  onVisibilityChange = () => {
    typeof document < `u` && document.visibilityState === `visible` && (this.tracker.requestRebaseline(), this.cancelTransient());
  };
  onConnectionChange = (e3) => {
    e3 && this.wasConnected === false && (this.tracker.requestRebaseline(), this.cancelTransient()), this.wasConnected = e3;
  };
  checkSequence() {
    var _a;
    let e3 = this.tracker.observe(d(this.readValue(`oid_seq`)));
    e3.animate && e3.sequence !== null && ((_a = this.state.rxData) == null ? void 0 : _a.animations) !== false && !this.props.editMode && this.scheduleSnapshot(e3.sequence);
  }
  scheduleSnapshot(e3) {
    this.snapshotTimer && clearTimeout(this.snapshotTimer), this.snapshotTimer = setTimeout(() => {
      this.snapshotTimer = null, this.unmounted || this.captureEvent(e3);
    }, 80);
  }
  captureEvent(e3) {
    let t2 = f(this.readValue(`oid_delta`)), n2 = this.readValue(`oid_kind`), r2 = f(this.readValue(`oid_light_count`)), i2 = h(this.readValue(`oid_light_names`)), a2 = v(this.readValue(`oid_event_json`));
    (a2 == null ? void 0 : a2.sequence) === e3 && (t2 = a2.delta ?? t2, n2 = a2.kind ?? n2, r2 = a2.lightCount ?? r2, i2 = a2.lightNames.length ? a2.lightNames : i2), this.enqueueEvent({ sequence: e3, kind: _(n2, t2), delta: t2, lightCount: r2, lightNames: i2, receivedAt: Date.now() });
  }
  enqueueEvent(e3) {
    let t2 = x(this.state.activeEvent, this.state.pendingEvent, e3);
    this.setState({ activeEvent: t2.active, pendingEvent: t2.pending }), t2.restarted && this.startEventTimer(t2.active);
  }
  startEventTimer(e3) {
    this.eventTimer && clearTimeout(this.eventTimer), this.eventTimer = setTimeout(() => {
      if (this.eventTimer = null, this.unmounted) return;
      let e4 = this.state.pendingEvent;
      e4 ? (this.setState({ activeEvent: e4, pendingEvent: null }), this.startEventTimer(e4)) : this.setState({ activeEvent: null });
    }, o[e3.kind]);
  }
  buildPalette() {
    var _a, _b, _c, _d, _e, _f, _g;
    let e3 = (_a = this.props.context) == null ? void 0 : _a.theme, t2 = ((_b = e3 == null ? void 0 : e3.palette) == null ? void 0 : _b.mode) || (this.props.themeType === `dark` ? `dark` : `light`), n2 = t2 === `dark`, r2 = (_c = this.state.rxData) == null ? void 0 : _c.accent_color;
    return { mode: t2, text: ((_e = (_d = e3 == null ? void 0 : e3.palette) == null ? void 0 : _d.text) == null ? void 0 : _e.primary) || (n2 ? `#f5f7fa` : `#111827`), textSecondary: ((_g = (_f = e3 == null ? void 0 : e3.palette) == null ? void 0 : _f.text) == null ? void 0 : _g.secondary) || (n2 ? `rgba(245,247,250,.65)` : `rgba(17,24,39,.6)`), accent: typeof r2 == `string` && r2.trim() ? r2 : n2 ? `#4fd6ff` : `#0369a1`, gold: n2 ? `#ffc857` : `#b7791f` };
  }
  renderWidgetBody(e3) {
    var _a;
    super.renderWidgetBody(e3);
    let t2 = this.state.rxData, n2 = !!this.props.editMode, i2 = r(`div`, { ref: this.rootRef, style: { width: `100%`, height: `100%`, position: `relative` }, children: r(P, { daily: u(this.readValue(`oid_daily`)), overall: u(this.readValue(`oid_overall`)), highScore: u(this.readValue(`oid_high_score`)), highScoreToday: p(this.readValue(`oid_high_score_today`)), recordBrokenAt: f(this.readValue(`oid_record_broken_at`)), activeEvent: n2 ? null : this.state.activeEvent, labels: { title: t2.widgetTitle || I(`eg_energy_saver`), daily: t2.label_daily || I(`eg_today`), overall: t2.label_overall || I(`eg_all_time`), record: t2.label_record || I(`eg_record`), unit: t2.label_unit || I(`eg_energy`) }, showTitle: !!t2.noCard && !!t2.widgetTitle, animationsEnabled: t2.animations !== false, reducedMotion: this.state.reducedMotion, showLightNames: t2.show_light_names !== false, recordSparkles: t2.record_sparkles !== false, compact: !!t2.compact, palette: this.buildPalette(), lang: String(((_a = this.props.context) == null ? void 0 : _a.lang) || a.getLanguage() || `en`), width: this.state.size.width, height: this.state.size.height, t: I }) });
    return this.wrapContent(i2, null, { padding: 0, height: `100%`, boxSizing: `border-box` });
  }
};
export {
  L as default
};
