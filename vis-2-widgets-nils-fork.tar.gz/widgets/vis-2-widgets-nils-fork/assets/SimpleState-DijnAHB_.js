import { B as e, g as t } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as n, E as r, H as i, I as a, L as o, P as s, Q as c, dt as l, ft as u, n as d, pt as f, u as p } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as m } from "./Lightbulb-BbGK3Qf2.js";
import { t as h } from "./LightbulbOutlined-_xkblzYe.js";
import { t as g } from "./Generic-BOiMPpxz.js";
import { t as _ } from "./dist-nezUW2fm.js";
e();
var v = { intermediate: { opacity: 0.2 }, text: { textTransform: `none` }, button: { display: `block`, width: `100%`, height: `100%`, overflow: `hidden`, textOverflow: `ellipsis`, padding: 0 }, buttonInactive: { opacity: 0.6 }, topButton: { display: `flex`, alignItems: `center` }, iconButton: { width: `50%`, height: 40, display: `flex`, textAlign: `left`, alignItems: `center` }, iconButtonCenter: { width: `100%`, height: 40, display: `flex`, textAlign: `center`, justifyContent: `center` }, rightButton: (e3) => ({ width: `50%`, textAlign: `right`, position: `relative`, mt: `-20px`, mb: `-20px`, left: `20px`, display: `flex`, justifyContent: `right`, color: e3.palette.mode === `light` ? `#000` : `#fff`, "&>div": { margin: `auto`, "&>div": { transform: `translate(-50%, -50%) !important`, top: `50% !important` } } }), iconSwitch: { width: 40, height: 40, display: `inline-flex`, alignItems: `center`, justifyContent: `center` }, cardsHolder: { display: `flex`, justifyContent: `space-between`, width: `100%`, alignItems: `center` }, allButtonsTitle: { display: `flex`, justifyContent: `space-between`, flexWrap: `wrap`, width: `100%`, alignItems: `center` }, buttonDiv: { display: `inline-block`, width: 120, height: 80, textAlign: `center` }, iconCustom: { maxWidth: 40, maxHeight: 40 }, newValueLight: { animation: `vis-2-widgets-nils-fork-newValueAnimationLight 2s ease-in-out` }, newValueDark: { animation: `vis-2-widgets-nils-fork-newValueAnimationDark 2s ease-in-out` } }, y = class e2 extends g {
  refDiv = t.createRef();
  updateTimeout = null;
  updateTimer1 = null;
  lastRxData = null;
  controlTimer = null;
  constructor(e3) {
    super(e3), this.state = { ...this.state, showDimmerDialog: null, object: { common: {}, _id: ``, type: `` }, controlValue: null };
  }
  static getWidgetInfo() {
    return { id: `tplNils2SimpleState`, visSet: `vis-2-widgets-nils-fork`, visName: `SimpleState`, visWidgetLabel: `simple_state`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox`, noBinding: false }, { name: `widgetTitle`, label: `name`, hidden: `data.noCard === true` }, { name: `values_count`, type: `number`, hidden: `!data.withStates`, default: 2, label: `values_count` }, { name: `oid`, type: `id`, label: `oid`, onChange: async (e3, t2, n2, r2) => {
      if (t2.oid) {
        let e4 = await r2.getObject(t2.oid);
        if ((e4 == null ? void 0 : e4.type) === `state` && e4.common.states && typeof e4.common.states != `string`) {
          let r3 = e4.common.states;
          Array.isArray(r3) && (r3 = Object.fromEntries(r3.map((e5) => [e5, e5])), e4.common.states = r3), t2.values_count = Object.keys(r3).length, t2.withStates = true, t2.withNumber = false, Object.keys(r3).forEach((e5, n3) => t2[`value${n3 + 1}`] = r3[e5]), n2(t2);
        } else (e4 == null ? void 0 : e4.type) === `state` && (t2.withNumber = e4.common.type === `number`, t2.withStates = false, t2.values_count = 0, n2(t2));
      }
    } }, { name: `noIcon`, type: `checkbox`, label: `no_icon`, noBinding: false }, { name: `icon`, type: `image`, hidden: `data.noIcon === true || !!data.iconSmall`, label: `icon` }, { name: `iconSmall`, type: `icon64`, label: `small_icon`, hidden: `data.noIcon === true || !!data.icon` }, { name: `iconEnabled`, hidden: `data.noIcon === true || !!data.iconEnabledSmall`, type: `image`, label: `icon_active` }, { name: `iconEnabledSmall`, type: `icon64`, label: `small_icon_active`, hidden: `data.noIcon === true || !!data.iconEnabled` }, { name: `iconSize`, label: `icon_size`, type: `slider`, tooltip: `icon_size_tooltip`, min: 0, max: 300, hidden: `data.noIcon === true || (!data.icon && !data.iconSmall && !data.iconEnabled && !data.iconEnabledSmall)` }, { name: `color`, type: `color`, label: `color` }, { name: `colorEnabled`, type: `color`, label: `color_active` }, { name: `title`, label: `title` }, { name: `circleSize`, label: `circle_size`, type: `slider`, min: 0, max: 200, default: 0, hidden: `!data.withNumber` }, { name: `readOnly`, type: `checkbox`, label: `read_only`, noBinding: false }, { name: `unit`, label: `unit` }, { name: `timeout`, label: `controlTimeout`, tooltip: `In milliseconds`, type: `number`, min: 0, max: 2e3, hidden: `data.readOnly === true` }, { name: `step`, label: `step`, type: `number`, tooltip: `only_for_slider`, hidden: `data.readOnly === true` }] }, { name: `values`, indexFrom: 1, indexTo: `values_count`, label: `values`, fields: [{ name: `value`, label: `value` }, { name: `icon`, type: `image`, label: `icon`, hidden: (e3, t2) => !!e3[`iconSmall${t2}`] }, { name: `iconSmall`, type: `icon64`, label: `small_icon`, hidden: (e3, t2) => !!e3[`icon${t2}`] }, { name: `color`, type: `color`, label: `color` }, { name: `title`, label: `title` }, { name: `iconSize`, label: `icon_size`, type: `slider`, min: 0, max: 300, hidden: (e3, t2) => !e3[`icon${t2}`] }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_simple_state.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  async propertiesUpdate() {
    var _a, _b, _c;
    let e3 = JSON.stringify(this.state.rxData);
    if (this.lastRxData === e3) return;
    if (this.lastRxData = e3, !this.state.rxData.oid || this.state.rxData.oid === `nothing_selected`) {
      this.setState({ object: { common: {}, _id: ``, type: `` } });
      return;
    }
    let t2 = await this.props.context.socket.getObject(this.state.rxData.oid), n2;
    if (n2 = t2 ? { common: t2.common, _id: t2._id, type: t2.type } : { common: {}, _id: ``, type: `` }, n2.common || (n2.common = {}), n2.common.type === `number` && (n2.common.max === void 0 && (n2.common.max = 100), n2.common.min === void 0 && (n2.common.min = 0)), n2.common.states && Array.isArray(n2.common.states)) {
      let e4 = {};
      n2.common.states.forEach((t3) => e4[t3] = t3), n2.common.states = e4;
    }
    if (!n2.common.icon && (n2.type === `state` || n2.type === `channel`)) {
      let e4 = this.state.rxData.oid.split(`.`), t3 = await this.props.context.socket.getObject(e4.slice(0, -1).join(`.`));
      if (!((_a = t3 == null ? void 0 : t3.common) == null ? void 0 : _a.icon) && (n2.type === `state` || n2.type === `channel`)) {
        let t4 = await this.props.context.socket.getObject(e4.slice(0, -2).join(`.`));
        ((_b = t4 == null ? void 0 : t4.common) == null ? void 0 : _b.icon) && (n2.common.icon = t4.common.icon, (t4.type === `instance` || t4.type === `adapter`) && (n2.common.icon = `../${t4.common.name}.admin/${n2.common.icon}`));
      } else ((_c = t3 == null ? void 0 : t3.common) == null ? void 0 : _c.icon) && (n2.common.icon = t3.common.icon, (t3.type === `instance` || t3.type === `adapter`) && (n2.common.icon = `../${t3.common.name}.admin/${n2.common.icon}`));
    }
    n2.common.name && typeof n2.common.name == `object` && (n2.common.name = n2.common.name[g.getLanguage()] || n2.common.name.en), JSON.stringify(this.state.object) !== JSON.stringify(n2) && this.setState({ object: n2 });
  }
  async componentDidMount() {
    super.componentDidMount(), await this.propertiesUpdate();
  }
  async onRxDataChanged() {
    await this.propertiesUpdate();
  }
  getValueData() {
    var _a;
    let e3 = this.state.values[`${this.state.rxData.oid}.val`], t2 = ((_a = this.state.object.common) == null ? void 0 : _a.states)[e3];
    for (let e4 = 1; e4 <= this.state.rxData.values_count; e4++) if (this.state.rxData[`value${e4}`] === t2) return { color: this.state.rxData[`color${e4}`], icon: this.state.rxData[`icon${e4}`] || this.state.rxData[`iconSmall${e4}`], title: this.state.rxData[`title${e4}`] };
    return null;
  }
  isOn(e3) {
    return e3 || (e3 = this.state.values), this.state.object.common.type === `number` ? e3[`${this.state.object._id}.val`] !== this.state.object.common.min : !!e3[`${this.state.object._id}.val`];
  }
  getStateIcon(e3) {
    var _a;
    let t2 = ``;
    if (this.state.rxData.noIcon) return null;
    this.state.object.common.states && (t2 = (_a = this.getValueData()) == null ? void 0 : _a.icon), t2 || this.isOn() && (t2 = this.state.rxData.iconEnabled || this.state.rxData.iconEnabledSmall), t2 || (t2 = this.state.rxData.icon || this.state.rxData.iconSmall), t2 || (t2 = this.state.object.common.icon), e3 ?? (e3 = this.isOn());
    let n2 = this.getColor(e3);
    if (t2) {
      let e4 = 40, r2 = v.iconCustom;
      return this.state.rxData.iconSize && (e4 = parseFloat(this.state.rxData.iconSize), r2 = void 0), u(d, { src: t2, style: { ...r2, width: e4, height: e4, color: n2 } });
    }
    return e3 ? u(m, { color: `primary`, style: { color: n2 } }) : u(h, { style: { color: n2 } });
  }
  getColor(e3) {
    var _a;
    return this.state.object.common.states ? (_a = this.getValueData()) == null ? void 0 : _a.color : (e3 = e3 === void 0 ? this.isOn() : e3, e3 ? this.state.rxData.colorEnabled || this.state.object.common.color : this.state.rxData.color || this.state.object.common.color);
  }
  changeSwitch = () => {
    if (this.state.object.common.type === `number` || this.state.object.common.states) this.setState({ showDimmerDialog: true });
    else {
      let e3 = JSON.parse(JSON.stringify(this.state.values)), t2 = `${this.state.object._id}.val`;
      e3[t2] = this.state.object.common.type === `number` ? e3[t2] === this.state.object.common.max ? this.state.object.common.min : this.state.object.common.max : !e3[t2], this.setState({ values: e3 }), this.props.context.setValue(this.state.rxData.oid, e3[t2]);
    }
  };
  setOnOff(e3) {
    let t2 = JSON.parse(JSON.stringify(this.state.values)), n2 = `${this.state.object._id}.val`;
    t2[n2] = e3 ? this.state.object.common.max : this.state.object.common.min, this.setState({ values: t2 }), this.props.context.setValue(this.state.rxData.oid, t2[n2]);
  }
  controlSpecificState(e3) {
    let t2 = JSON.parse(JSON.stringify(this.state.values)), n2 = `${this.state.object._id}.val`;
    t2[n2] = e3, this.setState({ values: t2 }), this.props.context.setValue(this.state.rxData.oid, t2[n2]);
  }
  onStateUpdated(e3) {
    this.state.controlValue && this.state.rxData.oid === e3 && this.setState({ controlValue: { value: this.state.controlValue.value, changed: true } });
  }
  finishChanging() {
    if (this.state.controlValue) {
      let e3 = { controlValue: null };
      if (!this.state.controlValue.changed) {
        let t2 = JSON.parse(JSON.stringify(this.state.values));
        t2[`${this.state.rxData.oid}.val`] = this.state.controlValue.value, e3.values = t2;
      }
      this.setState(e3);
    }
  }
  renderDimmerDialog() {
    if (this.state.showDimmerDialog) {
      let e3 = this.state.object.common.min === 0 && (this.state.object.common.max === 100 || this.state.object.common.max === 1);
      return f(s, { fullWidth: true, maxWidth: `sm`, open: true, onClose: () => this.setState({ showDimmerDialog: null }), children: [f(o, { children: [this.state.rxData.title || g.getText(this.state.object.common.name), u(i, { style: { float: `right` }, onClick: () => this.setState({ showDimmerDialog: null }), children: u(p, {}) })] }), u(a, { children: this.state.object.common.states ? u(`div`, { style: { width: `100%`, textAlign: `center` }, children: Object.keys(this.state.object.common.states).map((e4, t2) => u(n, { style: this.state.values[`${this.state.object._id}.val`] === e4 ? void 0 : v.buttonInactive, color: this.state.values[`${this.state.object._id}.val`] === e4 ? `primary` : `grey`, onClick: () => this.controlSpecificState(e4), children: this.state.object.common.states[e4] }, `${e4}_${t2}`)) }) : f(l, { children: [f(`div`, { style: { width: `100%`, marginBottom: 20 }, children: [u(n, { style: { ...this.state.values[`${this.state.object._id}.val`] === this.state.object.common.min ? void 0 : v.buttonInactive, width: `50%` }, color: `grey`, onClick: () => this.setOnOff(false), startIcon: e3 ? u(h, {}) : null, children: e3 ? g.t(`OFF`).replace(`vis_2_widgets_nils_`, ``) : this.state.object.common.min + (this.state.rxData.unit || this.state.object.common.unit || ``) }), u(n, { style: { width: `50%`, ...this.state.values[`${this.state.object._id}.val`] === this.state.object.common.max ? void 0 : v.buttonInactive }, color: `primary`, onClick: () => this.setOnOff(true), startIcon: e3 ? u(m, { color: `primary` }) : null, children: e3 ? g.t(`ON`).replace(`vis_2_widgets_nils_`, ``) : this.state.object.common.max + (this.state.rxData.unit || this.state.object.common.unit || ``) })] }), u(`div`, { style: { width: `100%` }, children: u(c, { size: `small`, value: this.state.controlValue ? this.state.controlValue.value : this.state.values[`${this.state.object._id}.val`], valueLabelFormat: (e4) => {
        var _a, _b;
        return ((_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.isFloatComma) ? e4.toString().replace(`.`, `,`) : e4.toString();
      }, step: parseFloat(this.state.rxData.step) || 1, valueLabelDisplay: `auto`, min: this.state.object.common.min, max: this.state.object.common.max, onChangeCommitted: () => this.finishChanging(), onChange: (e4, t2) => {
        var _a;
        this.setState({ controlValue: { value: t2, changed: !!((_a = this.state.controlValue) == null ? void 0 : _a.changed) } }, () => {
          this.controlTimer && (this.controlTimer = (clearTimeout(this.controlTimer), null)), this.state.rxData.timeout ? this.controlTimer = setTimeout((e5) => {
            this.controlTimer = null, this.props.context.setValue(this.state.rxData.oid, e5);
          }, parseInt(this.state.rxData.timeout, 10) || 0, t2) : this.props.context.setValue(this.state.rxData.oid, t2);
        });
      } }) })] }) })] });
    }
    return null;
  }
  renderCircular() {
    var _a, _b, _c, _d, _e;
    let e3 = this.state.values[`${this.state.object._id}.val`], t2 = this.state.object;
    if (e3 == null) return null;
    if (t2.common.min !== void 0 && e3 < t2.common.min || t2.common.max !== void 0 && e3 > t2.common.max) return e3 + (this.state.rxData.unit || ((_a = this.state.object.common) == null ? void 0 : _a.unit) || ``);
    let n2 = this.state.rxData.circleSize;
    return n2 || (n2 = ((_b = this.refDiv.current) == null ? void 0 : _b.offsetHeight) || 0, n2 > (((_c = this.refDiv.current) == null ? void 0 : _c.offsetWidth) || 0) && (n2 = ((_d = this.refDiv.current) == null ? void 0 : _d.offsetWidth) || 0)), n2 || (n2 = 80), n2 < 60 ? null : (this.refDiv.current || (this.updateTimer1 || (this.updateTimer1 = setTimeout(() => {
      this.updateTimer1 = null, this.forceUpdate();
    }, 50))), u(_, { minValue: t2.common.min, maxValue: t2.common.max, size: n2 * 1.1, arcColor: this.props.context.theme.palette.primary.main, arcBackgroundColor: this.props.context.themeType === `dark` ? `#DDD` : `#222`, startAngle: 0, endAngle: 360, handle1: { value: e3 }, children: u(`div`, { style: { ...this.props.context.themeType === `dark` ? v.newValueDark : v.newValueLight, fontSize: Math.round(n2 / 8), fontWeight: `bold` }, children: e3 + (this.state.rxData.unit || ((_e = this.state.object.common) == null ? void 0 : _e.unit) || ``) }, `_${e3}`) }));
  }
  renderWidgetBody(e3) {
    var _a;
    super.renderWidgetBody(e3);
    let t2 = JSON.stringify(this.state.rxData);
    this.lastRxData !== t2 && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
      this.updateTimeout = null, await this.propertiesUpdate();
    }, 50)));
    let i2 = this.isOn(), a2 = this.getStateIcon(i2), o2 = this.getColor(i2), s2 = this.state.object.common.states && ((_a = this.getValueData()) == null ? void 0 : _a.title), c2;
    this.state.object._id && (this.state.object.common.type === `number` || this.state.object.common.states) && (c2 = this.state.values[`${this.state.object._id}.val`], c2 = this.state.object.common.states && this.state.object.common.states[c2] !== void 0 ? this.state.object.common.states[c2] : this.formatValue(c2));
    let d2 = this.state.rxData.noCard !== true && this.state.rxData.noCard !== `true` && !e3.widget.usedInWidget && this.state.rxData.widgetTitle ? `calc(100% - 36px)` : `100%`;
    e3.className = !this.state.object.common.states && this.isOn() ? `${e3.className} vis-on`.trim() : `${e3.className} vis-off`.trim();
    let p2 = f(l, { children: [u(`style`, { children: `
@keyframes vis-2-widgets-nils-fork-newValueAnimationLight {
    0% {
        color: #00bd00;
    }
    80% {
        color: #008000;
    }
    100% {
        color: #000;
    }
}
@keyframes vis-2-widgets-nils-fork-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: #ffffff;
    }
}            
` }), this.renderDimmerDialog(), u(`div`, { style: { width: `100%`, height: d2 }, ref: this.refDiv, children: u(`div`, { style: { ...v.buttonDiv, width: `100%`, height: `100%` }, children: f(n, { onClick: () => this.changeSwitch(), disabled: this.state.rxData.readOnly === true || this.state.rxData.readOnly === `true`, color: !this.state.object.common.states && this.isOn() ? `primary` : `grey`, style: { ...v.button, ...this.isOn() ? void 0 : v.buttonInactive }, children: [f(`div`, { style: v.topButton, children: [a2 ? u(`div`, { style: { ...!this.state.object.common.states && c2 != null ? v.iconButton : v.iconButtonCenter, height: this.state.rxData.iconSize ? `unset` : void 0 }, children: a2 }) : null, !this.state.object.common.states && c2 != null ? u(r, { component: `div`, sx: v.rightButton, style: a2 ? {} : { width: `100%`, left: 0, justifyContent: `center` }, children: this.renderCircular() }) : null] }), u(`div`, { style: { ...v.text, color: o2 }, children: this.state.rxData.title || g.getText(this.state.object.common.name) }), this.state.object.common.states && c2 != null ? u(`div`, { style: { ...v.value, ...o2 ? void 0 : this.props.context.themeType === `dark` ? v.newValueDark : v.newValueLight, color: o2 }, children: s2 || c2 }, `${s2 || c2}`) : null] }) }) })] });
    return this.state.rxData.noCard === true || this.state.rxData.noCard === `true` || e3.widget.usedInWidget ? p2 : this.wrapContent(p2, null);
  }
};
export {
  y as default
};
