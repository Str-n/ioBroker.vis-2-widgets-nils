import { j as e, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { C as M, __tla as __tla_1 } from "./index-DBUuV2Mq.js";
import { a as $, b as C, c as j, d as T, e as _, _ as w, f as A, g as J, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { a as I, b as H, c as L, d as R, e as W, _ as k, f as N, g as P, h as F, i as E, j as V, k as U, l as G, m as Y, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CpkBFb5h.js";
import { _ as q, __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CxgaxSjv.js";
import { O as K, __tla as __tla_5 } from "./ObjectChart-DL9VOeto.js";
import { G as f } from "./Generic-DDdmRdK-.js";
import { __tla as __tla_6 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
import { __tla as __tla_7 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { __tla as __tla_8 } from "./installSVGRenderer-It2PVbYG.js";
import "./tslib.es6-BuLyYyFn.js";
let z;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })()
]).then(async () => {
  const S = {
    AUTO: e.jsx(Y, {
      style: {
        width: 24,
        height: 24
      }
    }),
    MANUAL: e.jsx(G, {
      style: {
        width: 24,
        height: 24
      }
    }),
    VACATION: e.jsx(U, {
      style: {
        width: 24,
        height: 24
      }
    }),
    COOL: e.jsx(V, {
      style: {
        width: 24,
        height: 24
      }
    }),
    COOLING: e.jsx(V, {
      style: {
        width: 24,
        height: 24
      }
    }),
    DRY: e.jsx(E, {
      style: {
        width: 24,
        height: 24
      }
    }),
    ECO: e.jsx(F, {
      style: {
        width: 24,
        height: 24
      }
    }),
    FAN_ONLY: e.jsx(P, {
      style: {
        width: 24,
        height: 24
      }
    }),
    HEAT: e.jsx(N, {
      style: {
        width: 24,
        height: 24
      }
    }),
    HEATING: e.jsx(N, {
      style: {
        width: 24,
        height: 24
      }
    }),
    OFF: e.jsx(W, {
      style: {
        width: 24,
        height: 24
      }
    })
  }, x = {
    thermostatCircleDiv: {
      width: "100%",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-end",
      "& svg circle": {
        cursor: "pointer"
      },
      "&>div": {
        margin: "auto",
        "&>div": {
          top: "35% !important"
        }
      }
    },
    moreButton: {
      position: "absolute",
      top: 4,
      right: 4
    },
    thermostatButtonsDiv: {
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
      position: "absolute",
      bottom: 8,
      left: 0
    },
    thermostatNewValueLight: {
      animation: "vis-2-widgets-nils-fork-newValueAnimationLight 2s ease-in-out"
    },
    thermostatNewValueDark: {
      animation: "vis-2-widgets-nils-fork-newValueAnimationDark 2s ease-in-out"
    },
    thermostatDesiredTemp: {
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      width: "100%",
      left: 0,
      transform: "none"
    },
    tooltip: {
      pointerEvents: "none"
    }
  };
  function O(B) {
    var _a;
    let i = (_a = B == null ? void 0 : B.common) == null ? void 0 : _a.states;
    if (Array.isArray(i)) {
      const h = {};
      i.forEach((d) => h[d] = d), i = h;
    }
    const t = [];
    return i && Object.keys(i).forEach((h) => {
      const d = {
        value: h,
        label: i[h]
      };
      d.icon = S[(i[h] || "").toUpperCase()], t.push(d);
    }), t.length ? t : null;
  }
  z = class extends f {
    lastRxData = "";
    customStyle = {};
    updateTimeout = null;
    constructor(i) {
      super(i), this.state = {
        ...this.state,
        showDialog: false,
        dialogTab: 0,
        size: 0,
        horizontal: false
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2Thermostat",
        visSet: "vis-2-widgets-nils-fork",
        visWidgetLabel: "thermostat",
        visName: "Thermostat",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                hidden: "!!data.externalDialog"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard || !!data.externalDialog"
              },
              {
                name: "oid-temp-set",
                type: "id",
                label: "temperature_oid",
                onChange: async (i, t, h, d) => {
                  var _a;
                  if (t[i.name] && ((_a = await d.getObject(t[i.name])) == null ? void 0 : _a.common)) {
                    const c = t[i.name].split(".");
                    c.pop();
                    const u = await d.getObjectViewSystem("state", `${c.join(".")}.`, `${c.join(".")}.\u9999`);
                    if (u) {
                      let a = false;
                      const g = Object.values(u);
                      for (const D of g) {
                        const l = D.common.role;
                        if (l && l.includes("value.temperature")) t["oid-temp-actual"] = D._id, a = true;
                        else if (l == null ? void 0 : l.includes("power")) t["oid-power"] = D._id, a = true;
                        else if (l == null ? void 0 : l.includes("boost")) t["oid-boost"] = D._id, a = true;
                        else if (l == null ? void 0 : l.includes("party")) t["oid-party"] = D._id, a = true;
                        else if (l == null ? void 0 : l.includes("mode")) {
                          const n = O(D);
                          if (n) {
                            for (let p = 0; p < n.length; p++) {
                              const s = n[p];
                              (!t[`title${p + 1}`] || p + 1 > t.count) && (a = true, t[`title${p + 1}`] = s.label), (!t[`value${p + 1}`] || p + 1 > t.count) && (t[`value${p + 1}`] = s.value, a = true);
                            }
                            t.count !== n.length && (a = true, t.count = n.length);
                          }
                          t["oid-mode"] = D._id, a = true;
                        }
                      }
                      a && h(t);
                    }
                  }
                }
              },
              {
                name: "oid-temp-actual",
                type: "id",
                label: "actual_oid"
              },
              {
                name: "unit",
                label: "unit"
              },
              {
                name: "oid-power",
                type: "id",
                label: "power_oid"
              },
              {
                name: "oid-mode",
                type: "id",
                label: "mode_oid",
                onChange: async (i, t, h, d) => {
                  if (t[i.name]) {
                    const r = await d.getObject(t[i.name]), c = r ? O(r) : null;
                    if (c) {
                      let u = false;
                      c.forEach((a, g) => {
                        (!t[`title${g + 1}`] || g + 1 > t.count) && (u = true, t[`title${g + 1}`] = a.label), (!t[`value${g + 1}`] || g + 1 > t.count) && (t[`value${g + 1}`] = a.value, u = true);
                      }), t.count !== c.length && (u = true, t.count = c.length), u && h(t);
                    }
                  }
                }
              },
              {
                name: "oid-boost",
                type: "id",
                label: "mode_boost"
              },
              {
                name: "oid-party",
                type: "id",
                label: "mode_party"
              },
              {
                name: "step",
                type: "select",
                disabled: '!data["oid-temp-set"]',
                label: "step",
                noTranslation: true,
                options: [
                  "0.5",
                  "1"
                ],
                default: "1"
              },
              {
                name: "timeout",
                label: "controlTimeout",
                tooltip: "timeout_tooltip",
                type: "slider",
                min: 0,
                max: 2e3,
                default: 500
              },
              {
                name: "externalDialog",
                label: "use_as_dialog",
                type: "checkbox",
                tooltip: "use_as_dialog_tooltip"
              },
              {
                name: "count",
                type: "slider",
                min: 1,
                max: 9,
                label: "modes_count",
                default: 2,
                hidden: '!data["oid-mode"]'
              }
            ]
          },
          {
            name: "modes",
            label: "group_modes",
            indexFrom: 1,
            indexTo: "count",
            hidden: '!data["oid-mode"]',
            fields: [
              {
                name: "hide",
                type: "checkbox",
                label: "hide",
                noBinding: false
              },
              {
                name: "title",
                label: "title",
                hidden: 'data["hide" + index] === true'
              },
              {
                name: "tooltip",
                label: "tooltip",
                hidden: 'data["hide" + index] === true || !!data["title" + index]'
              },
              {
                name: "icon",
                type: "image",
                label: "icon",
                hidden: 'data["hide" + index] === true || !!data["iconSmall" + index]'
              },
              {
                name: "iconSmall",
                type: "icon64",
                label: "small_icon",
                hidden: 'data["hide" + index] === true || !!data["icon" + index]'
              },
              {
                name: "color",
                type: "color",
                label: "color",
                hidden: 'data["hide" + index] === true'
              },
              {
                name: "noText",
                type: "checkbox",
                label: "no_text",
                noBinding: false,
                hidden: 'data["hide" + index] === true || data["noIcon" + index] === true'
              },
              {
                name: "noIcon",
                type: "checkbox",
                label: "no_icon",
                noBinding: false,
                hidden: 'data["hide" + index] === true || data["noText" + index] === true || !data["title" + index]'
              },
              {
                name: "value",
                type: "text",
                label: "value",
                hidden: 'data["hide" + index] === true'
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_thermostat.png"
      };
    }
    async thermostatReadObjects() {
      var _a, _b, _c, _d;
      const i = JSON.stringify(this.state.rxData);
      if (this.lastRxData === i) return;
      const t = {};
      this.lastRxData = i;
      const h = [];
      this.state.rxData["oid-mode"] && this.state.rxData["oid-mode"] !== "nothing_selected" && h.push(this.state.rxData["oid-mode"]), this.state.rxData["oid-temp-set"] && this.state.rxData["oid-temp-set"] !== "nothing_selected" && h.push(this.state.rxData["oid-temp-set"]), this.state.rxData["oid-temp-actual"] && this.state.rxData["oid-temp-actual"] !== "nothing_selected" && h.push(this.state.rxData["oid-temp-actual"]);
      const d = h.length ? await this.props.context.socket.getObjectsById(h) : {};
      if (this.state.rxData["oid-mode"] && this.state.rxData["oid-mode"] !== "nothing_selected") {
        const a = d[this.state.rxData["oid-mode"]];
        if (a) {
          t.modeObject = {
            common: a.common,
            _id: a._id
          };
          const g = O(a);
          t.modes = [];
          const D = parseInt(this.state.rxData.count, 10) || 10;
          g == null ? void 0 : g.forEach((l, n) => {
            if (this.state.rxData[`hide${n + 1}`] === true || this.state.rxData[`hide${n + 1}`] === "true" || n >= D) return;
            const p = this.state.rxData[`noIcon${n + 1}`] !== true && this.state.rxData[`noIcon${n + 1}`] !== "true" ? this.state.rxData[`icon${n + 1}`] || this.state.rxData[`iconSmall${n + 1}`] || !!S[(l.label || "").toUpperCase()] : void 0, s = {
              value: this.state.rxData[`value${n + 1}`] || l.value,
              tooltip: this.state.rxData[`tooltip${n + 1}`] || l.label,
              icon: p,
              original: l.label,
              label: p && (this.state.rxData[`noText${n + 1}`] === true || this.state.rxData[`noText${n + 1}`] === "true") ? null : this.state.rxData[`title${n + 1}`] || l.label,
              color: this.state.rxData[`color${n + 1}`]
            };
            s.label && !(this.state.rxData[`noText${n + 1}`] === true || this.state.rxData[`noText${n + 1}`] === "true") && s.icon === true && !this.state.rxData[`title${n + 1}`] && (s.label = null), t.modes.push(s);
          });
          for (let l = (g == null ? void 0 : g.length) || 0; l < D; l++) {
            if (this.state.rxData[`hide${l + 1}`] === true || this.state.rxData[`hide${l + 1}`] === "true") continue;
            const n = this.state.rxData[`noIcon${l + 1}`] !== true && this.state.rxData[`noIcon${l + 1}`] !== "true" ? this.state.rxData[`icon${l + 1}`] || this.state.rxData[`iconSmall${l + 1}`] || !!S[(this.state.rxData[`title${l + 1}`] || "").toUpperCase()] : void 0;
            t.modes.push({
              tooltip: this.state.rxData[`tooltip${l + 1}`],
              icon: n,
              original: this.state.rxData[`title${l + 1}`],
              label: n && (this.state.rxData[`noText${l + 1}`] === true || this.state.rxData[`noText${l + 1}`] === "true") ? null : this.state.rxData[`title${l + 1}`],
              value: this.state.rxData[`value${l + 1}`],
              color: this.state.rxData[`color${l + 1}`]
            });
          }
        } else t.modes = null;
      } else t.modes = null;
      if (this.state.rxData["oid-temp-set"] && this.state.rxData["oid-temp-set"] !== "nothing_selected") {
        const a = d[this.state.rxData["oid-temp-set"]];
        t.min = ((_a = a == null ? void 0 : a.common) == null ? void 0 : _a.min) === void 0 ? 12 : a.common.min, t.max = ((_b = a == null ? void 0 : a.common) == null ? void 0 : _b.max) === void 0 ? 30 : a.common.max, t.tempObject = {
          common: a.common,
          _id: a._id
        };
      } else t.tempObject = null, t.max = null, t.min = null;
      if (this.state.rxData["oid-temp-actual"] && this.state.rxData["oid-temp-actual"] !== "nothing_selected") {
        const a = d[this.state.rxData["oid-temp-actual"]];
        t.tempStateObject = {
          common: a.common,
          _id: a._id
        };
      } else t.tempStateObject = null;
      const r = (_d = (_c = this.props.context.systemConfig) == null ? void 0 : _c.common) == null ? void 0 : _d.defaultHistory, c = f.getHistoryInstance(t.tempObject, r), u = f.getHistoryInstance(t.tempStateObject, r);
      t.isChart = !!c || !!u, Object.keys(t).find((a) => JSON.stringify(this.state[a]) !== JSON.stringify(t[a])) && this.setState(t);
    }
    async componentDidMount() {
      super.componentDidMount(), await this.thermostatReadObjects();
    }
    async onRxDataChanged() {
      await this.thermostatReadObjects();
    }
    getWidgetInfo() {
      return z.getWidgetInfo();
    }
    formatValue(i, t) {
      var _a;
      return typeof i == "number" && (t === 0 ? i = Math.round(i) : i = Math.round(i * 100) / 100, ((_a = this.props.context.systemConfig) == null ? void 0 : _a.common) && this.props.context.systemConfig.common.isFloatComma && (i = i.toString().replace(".", ","))), i == null ? "" : i.toString();
    }
    renderChartDialog() {
      var _a, _b, _c, _d;
      return this.state.showDialog ? e.jsxs($, {
        sx: {
          "& .MuiDialog-paper": {
            height: "100%"
          }
        },
        maxWidth: "lg",
        fullWidth: true,
        open: true,
        onClose: () => this.setState({
          showDialog: false
        }),
        children: [
          e.jsxs(C, {
            children: [
              this.state.rxData.widgetTitle,
              e.jsx(j, {
                style: {
                  float: "right"
                },
                onClick: () => this.setState({
                  showDialog: false
                }),
                children: e.jsx(I, {})
              })
            ]
          }),
          e.jsx(T, {
            children: this.state.dialogTab === 1 && e.jsx("div", {
              style: {
                height: "100%"
              },
              children: e.jsx(K, {
                t: (i) => f.t(i),
                lang: f.getLanguage(),
                socket: this.props.context.socket,
                obj: this.state.tempStateObject || this.state.tempObject,
                obj2: this.state.tempStateObject ? this.state.tempObject : null,
                objLineType: this.state.tempStateObject ? "line" : "step",
                obj2LineType: "step",
                themeType: this.props.context.themeType,
                historyInstance: f.getHistoryInstance(this.state.tempStateObject || this.state.tempObject, ((_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory) || "history.0"),
                historyInstance2: f.getHistoryInstance(this.state.tempStateObject, ((_d = (_c = this.props.context.systemConfig) == null ? void 0 : _c.common) == null ? void 0 : _d.defaultHistory) || "history.0"),
                noToolbar: false,
                systemConfig: this.props.context.systemConfig,
                dateFormat: this.props.context.systemConfig.common.dateFormat
              })
            })
          })
        ]
      }) : null;
    }
    componentDidUpdate(i, t) {
      var _a;
      if (super.componentDidUpdate(i, t), (_a = this.refService) == null ? void 0 : _a.current) {
        let h = this.refService.current.clientWidth, d = this.refService.current.clientHeight, r = h;
        const c = this.props.context.views[this.props.view].widgets[this.props.id];
        !this.state.rxData.noCard && !c.usedInWidget && (d -= 32, h -= 32);
        const u = this.state.rxData.widgetTitle && !this.state.rxData.noCard && !c.usedInWidget, a = this.thermIsWithModeButtons() || this.thermIsWithPowerButton();
        u && a ? d -= 64 : u ? d -= 36 : a && (d -= 28), d < 0 && (d = 0), h > d ? r = d : r = h, r < 80 && (r = 0), r !== this.state.size && this.setState({
          size: r
        });
      }
    }
    thermIsWithPowerButton() {
      return !!this.state.rxData["oid-power"] && this.state.rxData["oid-power"] !== "nothing_selected";
    }
    thermIsWithModeButtons() {
      var _a;
      return (((_a = this.state.modes) == null ? void 0 : _a.length) || this.state.rxData["oid-party"] || this.state.rxData["oid-boost"]) && (!this.state.rxData["oid-power"] || this.state.values[`${this.state.rxData["oid-power"]}.val`]);
    }
    onCommand(i) {
      const t = super.onCommand(i);
      if (t === false) {
        if (i === "openDialog") return this.setState({
          dialog: true
        }), true;
        if (i === "closeDialog") return this.setState({
          dialog: false
        }), true;
      }
      return t;
    }
    renderWidgetBody(i) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o;
      super.renderWidgetBody(i), this.customStyle = {}, this.state.rxStyle && (this.state.rxStyle["font-weight"] && (this.customStyle.fontWeight = this.state.rxStyle["font-weight"]), this.state.rxStyle["font-size"] && (this.customStyle.fontSize = this.state.rxStyle["font-size"]), this.state.rxStyle["font-family"] && (this.customStyle.fontFamily = this.state.rxStyle["font-family"]), this.state.rxStyle["font-style"] && (this.customStyle.fontStyle = this.state.rxStyle["font-style"]), this.state.rxStyle["word-spacing"] && (this.customStyle.wordSpacing = this.state.rxStyle["word-spacing"]), this.state.rxStyle["letter-spacing"] && (this.customStyle.letterSpacing = this.state.rxStyle["letter-spacing"]));
      const t = !this.state.rxData.noCard && !i.widget.usedInWidget, h = this.state.rxData.widgetTitle && t, d = JSON.stringify(this.state.rxData);
      this.lastRxData !== d && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
        this.updateTimeout = null, await this.thermostatReadObjects();
      }, 50)));
      let r = this.state.values[`${this.state.rxData["oid-temp-set"]}.val`];
      r === void 0 && (r = null), r !== null && (this.state.min === null || this.state.min === void 0 || r < this.state.min) ? r = this.state.min : r !== null && (this.state.max === null || this.state.max === void 0 || r > this.state.max) && (r = this.state.max), r === null && this.state.min !== null && this.state.min !== void 0 && this.state.max !== null && this.state.max !== void 0 && (r = (this.state.max - this.state.min) / 2 + this.state.min);
      let c = this.state.values[`${this.state.rxData["oid-temp-actual"]}.val`];
      c === void 0 && (c = null);
      let u = Math.round(this.state.size / 25);
      u < 8 && (u = 8);
      const a = this.state.isChart ? e.jsx(j, {
        style: {
          ...h ? void 0 : x.moreButton,
          right: this.state.rxData.externalDialog || h ? void 0 : 4,
          left: this.state.rxData.externalDialog ? 16 : void 0,
          top: this.state.rxData.externalDialog ? 16 : h ? void 0 : 4,
          zIndex: 2
        },
        onClick: () => this.setState({
          showDialog: true
        }),
        children: e.jsx(H, {})
      }) : null;
      c = c !== null ? this.formatValue(c) : null;
      const g = this.thermIsWithModeButtons(), D = this.thermIsWithPowerButton(), l = ((_e = (_d = (_c = (_b = (_a = this.props.customSettings) == null ? void 0 : _a.viewStyle) == null ? void 0 : _b.overrides) == null ? void 0 : _c.palette) == null ? void 0 : _d.primary) == null ? void 0 : _e.main) || ((_f = this.props.context.theme) == null ? void 0 : _f.palette.primary.main) || "#448aff";
      let n = [];
      if (g) {
        if (((_g = this.state.modes) == null ? void 0 : _g.length) && (n = this.state.modes.map((s, o) => {
          const y = s.icon === true ? S[(s.original || "").toUpperCase()] : s.icon ? e.jsx(q, {
            src: s.icon,
            style: {
              width: 24,
              height: 24
            }
          }) : null;
          let v = this.state.values[`${this.state.rxData["oid-mode"]}.val`];
          return v == null ? v = "null" : v = v.toString(), y && !s.label ? e.jsx(_, {
            title: s.tooltip,
            slotProps: {
              popper: {
                sx: x.tooltip
              }
            },
            children: e.jsx(j, {
              color: v === s.value ? "primary" : "inherit",
              style: v === s.value || !s.color ? void 0 : {
                color: s.color
              },
              onClick: () => {
                var _a2, _b2, _c2, _d2;
                let m = s.value;
                ((_b2 = (_a2 = this.state.modeObject) == null ? void 0 : _a2.common) == null ? void 0 : _b2.type) === "number" ? m = parseFloat(m) : ((_d2 = (_c2 = this.state.modeObject) == null ? void 0 : _c2.common) == null ? void 0 : _d2.type) === "boolean" && (m = m === "true" || m === true || m === "1" || m === 1);
                const b = JSON.parse(JSON.stringify(this.state.values));
                b[`${this.state.rxData["oid-mode"]}.val`] = m, this.setState({
                  values: b
                }), this.props.context.setValue(this.state.rxData["oid-mode"], m);
              },
              children: y
            })
          }, `${o}_${s.value}`) : e.jsx(w, {
            color: v === s.value ? "primary" : "inherit",
            onClick: () => {
              var _a2, _b2, _c2, _d2;
              let m = s.value;
              ((_b2 = (_a2 = this.state.modeObject) == null ? void 0 : _a2.common) == null ? void 0 : _b2.type) === "number" ? m = parseFloat(m) : ((_d2 = (_c2 = this.state.modeObject) == null ? void 0 : _c2.common) == null ? void 0 : _d2.type) === "boolean" && (m = m === "true" || m === true || m === "1" || m === 1);
              const b = JSON.parse(JSON.stringify(this.state.values));
              b[`${this.state.rxData["oid-mode"]}.val`] = m, this.setState({
                values: b
              }), this.props.context.setValue(this.state.rxData["oid-mode"], m);
            },
            startIcon: y,
            children: s.label
          }, `${o}_${s.value}`);
        })), this.state.rxData["oid-party"]) {
          let s = this.state.values[`${this.state.rxData["oid-party"]}.val`];
          s == null ? s = false : s = s === "1" || s === "true" || s === true, n.push(e.jsx(w, {
            color: s ? "primary" : "inherit",
            onClick: () => {
              let o = this.state.values[`${this.state.rxData["oid-party"]}.val`];
              o == null ? o = false : o = o === "1" || o === "true" || o === true;
              const y = JSON.parse(JSON.stringify(this.state.values));
              y[`${this.state.rxData["oid-party"]}.val`] = !o, this.setState({
                values: y
              }), this.props.context.setValue(this.state.rxData["oid-party"], !o);
            },
            startIcon: e.jsx(L, {}),
            children: f.t("Party")
          }, "party"));
        }
        if (this.state.rxData["oid-boost"]) {
          let s = this.state.values[`${this.state.rxData["oid-boost"]}.val`];
          s == null ? s = false : s = s === "1" || s === "true" || s === true, n.push(e.jsx(w, {
            color: s ? "primary" : "inherit",
            onClick: () => {
              let o = this.state.values[`${this.state.rxData["oid-boost"]}.val`];
              o == null ? o = false : o = o === "1" || o === "true" || o === true;
              const y = JSON.parse(JSON.stringify(this.state.values));
              y[`${this.state.rxData["oid-boost"]}.val`] = !o, this.setState({
                values: y
              }), this.props.context.setValue(this.state.rxData["oid-boost"], !o);
            },
            startIcon: e.jsx(R, {}),
            children: f.t("Boost")
          }, "boost"));
        }
      }
      D && n.push(e.jsx(_, {
        title: f.t("power").replace("vis_2_widgets_nils_", ""),
        slotProps: {
          popper: {
            sx: x.tooltip
          }
        },
        children: e.jsx(j, {
          color: this.state.values[`${this.state.rxData["oid-power"]}.val`] ? "primary" : "inherit",
          onClick: () => {
            const s = JSON.parse(JSON.stringify(this.state.values)), o = `${this.state.rxData["oid-power"]}.val`;
            s[o] = !s[o], this.setState({
              values: s
            }), this.props.context.setValue(this.state.rxData["oid-power"], s[o]);
          },
          children: e.jsx(W, {})
        })
      }, "power"));
      const p = e.jsxs(A, {
        component: "div",
        sx: x.thermostatCircleDiv,
        style: {
          height: h ? "calc(100% - 36px)" : "100%"
        },
        children: [
          e.jsx("style", {
            children: `
@keyframes vis-2-widgets-nils-fork-newValueAnimationLight {
    0% {
        color: #00bd00;
    },
    80% {
        color: #008000;
    },
    100% {
        color: #000;
    }
}

@keyframes vis-2-widgets-nils-fork-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: #ffffff;
    }
}                          
                            `
          }),
          h ? null : a,
          this.state.size && this.state.tempObject ? e.jsxs(M, {
            minValue: this.state.min === null || this.state.min === void 0 ? 12 : this.state.min,
            maxValue: this.state.max === null || this.state.max === void 0 ? 30 : this.state.max,
            size: this.state.size,
            arcColor: l,
            arcBackgroundColor: this.props.context.themeType === "dark" ? "#DDD" : "#222",
            startAngle: 40,
            handleSize: u,
            endAngle: 320,
            handle1: {
              value: r,
              onChange: (s) => {
                const o = JSON.parse(JSON.stringify(this.state.values));
                this.state.rxData.step === "0.5" ? o[`${this.state.rxData["oid-temp-set"]}.val`] = Math.round(s * 2) / 2 : o[`${this.state.rxData["oid-temp-set"]}.val`] = Math.round(s), this.setState({
                  values: o
                });
              }
            },
            onControlFinished: () => this.props.context.setValue(this.state.rxData["oid-temp-set"], this.state.values[`${this.state.rxData["oid-temp-set"]}.val`]),
            children: [
              r !== null ? e.jsx(_, {
                title: f.t("desired_temperature"),
                slotProps: {
                  popper: {
                    sx: x.tooltip
                  }
                },
                children: e.jsxs("div", {
                  style: {
                    ...x.thermostatDesiredTemp,
                    fontSize: Math.round(this.state.size / 6),
                    ...this.customStyle
                  },
                  children: [
                    e.jsx(k, {
                      style: {
                        width: this.state.size / 8,
                        height: this.state.size / 8
                      }
                    }),
                    e.jsxs("div", {
                      style: {
                        display: "flex",
                        alignItems: "top",
                        ...this.customStyle
                      },
                      children: [
                        this.formatValue(r),
                        e.jsx("span", {
                          style: {
                            fontSize: Math.round(this.state.size / 12),
                            fontWeight: "normal"
                          },
                          children: this.state.rxData.unit || ((_i = (_h = this.state.tempObject) == null ? void 0 : _h.common) == null ? void 0 : _i.unit)
                        })
                      ]
                    })
                  ]
                })
              }) : null,
              c !== null ? e.jsx(_, {
                title: f.t("actual_temperature"),
                slotProps: {
                  popper: {
                    sx: x.tooltip
                  }
                },
                children: e.jsxs("div", {
                  style: {
                    ...this.props.context.themeType === "dark" ? x.thermostatNewValueDark : x.thermostatNewValueLight,
                    fontSize: Math.round(this.state.size * 0.6 / 6),
                    opacity: 0.7,
                    ...this.customStyle
                  },
                  children: [
                    c,
                    this.state.rxData.unit || ((_k = (_j = this.state.tempStateObject) == null ? void 0 : _j.common) == null ? void 0 : _k.unit)
                  ]
                }, `${c}valText`)
              }) : null
            ]
          }) : this.state.tempObject ? e.jsxs("div", {
            style: {
              width: "100%"
            },
            children: [
              e.jsx(J, {
                style: {
                  width: "calc(100% - 50px)",
                  display: "inline-block"
                },
                min: this.state.min === null || this.state.min === void 0 ? 12 : this.state.min,
                max: this.state.max === null || this.state.max === void 0 ? 30 : this.state.max,
                step: this.state.step || 0.5,
                value: r,
                valueLabelDisplay: "auto",
                onChange: (s, o) => {
                  const y = JSON.parse(JSON.stringify(this.state.values));
                  this.state.rxData.step === "0.5" ? y[`${this.state.rxData["oid-temp-set"]}.val`] = Math.round(o * 2) / 2 : y[`${this.state.rxData["oid-temp-set"]}.val`] = Math.round(o), this.setState({
                    values: y
                  });
                },
                onChangeCommitted: () => this.props.context.setValue(this.state.rxData["oid-temp-set"], this.state.values[`${this.state.rxData["oid-temp-set"]}.val`])
              }),
              e.jsxs("div", {
                style: {
                  textAlign: "center",
                  display: "inline-block",
                  flexDirection: "column",
                  width: 50
                },
                children: [
                  r !== null ? e.jsx(_, {
                    title: f.t("desired_temperature"),
                    slotProps: {
                      popper: {
                        sx: x.tooltip
                      }
                    },
                    children: e.jsxs("div", {
                      style: {
                        ...x.thermostatDesiredTemp,
                        fontSize: 12,
                        ...this.customStyle
                      },
                      children: [
                        e.jsx(k, {
                          style: {
                            width: 24,
                            height: 24
                          }
                        }),
                        e.jsxs("div", {
                          style: {
                            display: "flex",
                            alignItems: "top",
                            ...this.customStyle
                          },
                          children: [
                            this.formatValue(r),
                            e.jsx("span", {
                              style: {
                                fontSize: 10,
                                fontWeight: "normal"
                              },
                              children: this.state.rxData.unit || ((_m = (_l = this.state.tempObject) == null ? void 0 : _l.common) == null ? void 0 : _m.unit)
                            })
                          ]
                        })
                      ]
                    })
                  }) : null,
                  c !== null ? e.jsx(_, {
                    title: f.t("actual_temperature"),
                    slotProps: {
                      popper: {
                        sx: x.tooltip
                      }
                    },
                    children: e.jsxs("div", {
                      style: {
                        ...this.props.context.themeType === "dark" ? x.thermostatNewValueDark : x.thermostatNewValueLight,
                        fontSize: Math.round(10),
                        opacity: 0.7,
                        ...this.customStyle
                      },
                      children: [
                        c,
                        this.state.rxData.unit || ((_o = (_n = this.state.tempStateObject) == null ? void 0 : _n.common) == null ? void 0 : _o.unit)
                      ]
                    }, `${c}valText`)
                  }) : null
                ]
              })
            ]
          }) : null,
          e.jsx("div", {
            style: {
              ...x.thermostatButtonsDiv,
              bottom: 8
            },
            children: n
          }),
          this.renderChartDialog()
        ]
      });
      return this.state.rxData.externalDialog && !this.props.editMode ? this.state.dialog ? e.jsxs($, {
        open: true,
        onClose: () => this.setState({
          dialog: false
        }),
        children: [
          e.jsxs(C, {
            children: [
              this.state.rxData.widgetTitle,
              e.jsx(j, {
                style: {
                  float: "right",
                  zIndex: 2
                },
                onClick: () => this.setState({
                  dialog: false
                }),
                children: e.jsx(I, {})
              })
            ]
          }),
          e.jsx(T, {
            style: {
              minWidth: 150,
              minHeight: 150
            },
            children: p
          })
        ]
      }) : null : t ? this.wrapContent(p, h ? a : null, {
        textAlign: "center"
      }) : p;
    }
  };
});
export {
  __tla,
  z as default
};
