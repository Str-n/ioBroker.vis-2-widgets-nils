import { __tla as __tla_0 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { d as m, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_system__loadShare__.js-BtyZ_WHy.js";
import { d as t, T as o, __tla as __tla_2 } from "./defaultTheme-B6tAfZzr.js";
let f;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  f = function() {
    const e = m(t);
    return e[o] || e;
  };
});
export {
  __tla,
  f as u
};
