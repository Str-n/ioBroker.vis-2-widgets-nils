import { a as e, o as t, t as n } from "./rolldown-runtime-C0FnF6B9.js";
import { B as r, z as i } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { it as a, rt as o } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
var s = n(((e2) => {
  function t2(e3, t3) {
    var n3 = e3.length;
    e3.push(t3);
    a: for (; 0 < n3; ) {
      var r3 = n3 - 1 >>> 1, a3 = e3[r3];
      if (0 < i2(a3, t3)) e3[r3] = t3, e3[n3] = a3, n3 = r3;
      else break a;
    }
  }
  function n2(e3) {
    return e3.length === 0 ? null : e3[0];
  }
  function r2(e3) {
    if (e3.length === 0) return null;
    var t3 = e3[0], n3 = e3.pop();
    if (n3 !== t3) {
      e3[0] = n3;
      a: for (var r3 = 0, a3 = e3.length, o3 = a3 >>> 1; r3 < o3; ) {
        var s3 = 2 * (r3 + 1) - 1, c3 = e3[s3], l3 = s3 + 1, u3 = e3[l3];
        if (0 > i2(c3, n3)) l3 < a3 && 0 > i2(u3, c3) ? (e3[r3] = u3, e3[l3] = n3, r3 = l3) : (e3[r3] = c3, e3[s3] = n3, r3 = s3);
        else if (l3 < a3 && 0 > i2(u3, n3)) e3[r3] = u3, e3[l3] = n3, r3 = l3;
        else break a;
      }
    }
    return t3;
  }
  function i2(e3, t3) {
    var n3 = e3.sortIndex - t3.sortIndex;
    return n3 === 0 ? e3.id - t3.id : n3;
  }
  if (e2.unstable_now = void 0, typeof performance == `object` && typeof performance.now == `function`) {
    var a2 = performance;
    e2.unstable_now = function() {
      return a2.now();
    };
  } else {
    var o2 = Date, s2 = o2.now();
    e2.unstable_now = function() {
      return o2.now() - s2;
    };
  }
  var c2 = [], l2 = [], u2 = 1, d2 = null, f2 = 3, p2 = false, m2 = false, h2 = false, g = false, _ = typeof setTimeout == `function` ? setTimeout : null, v = typeof clearTimeout == `function` ? clearTimeout : null, y = typeof setImmediate < `u` ? setImmediate : null;
  function b(e3) {
    for (var i3 = n2(l2); i3 !== null; ) {
      if (i3.callback === null) r2(l2);
      else if (i3.startTime <= e3) r2(l2), i3.sortIndex = i3.expirationTime, t2(c2, i3);
      else break;
      i3 = n2(l2);
    }
  }
  function x(e3) {
    if (h2 = false, b(e3), !m2) {
      if (n2(c2) !== null) m2 = true, ee || (ee = true, oe());
      else {
        var t3 = n2(l2);
        t3 !== null && le(x, t3.startTime - e3);
      }
    }
  }
  var ee = false, te = -1, ne = 5, re = -1;
  function ie() {
    return g ? true : !(e2.unstable_now() - re < ne);
  }
  function ae() {
    if (g = false, ee) {
      var t3 = e2.unstable_now();
      re = t3;
      var i3 = true;
      try {
        a: {
          m2 = false, h2 && (h2 = false, v(te), te = -1), p2 = true;
          var a3 = f2;
          try {
            b: {
              for (b(t3), d2 = n2(c2); d2 !== null && !(d2.expirationTime > t3 && ie()); ) {
                var o3 = d2.callback;
                if (typeof o3 == `function`) {
                  d2.callback = null, f2 = d2.priorityLevel;
                  var s3 = o3(d2.expirationTime <= t3);
                  if (t3 = e2.unstable_now(), typeof s3 == `function`) {
                    d2.callback = s3, b(t3), i3 = true;
                    break b;
                  }
                  d2 === n2(c2) && r2(c2), b(t3);
                } else r2(c2);
                d2 = n2(c2);
              }
              if (d2 !== null) i3 = true;
              else {
                var u3 = n2(l2);
                u3 !== null && le(x, u3.startTime - t3), i3 = false;
              }
            }
            break a;
          } finally {
            d2 = null, f2 = a3, p2 = false;
          }
          i3 = void 0;
        }
      } finally {
        i3 ? oe() : ee = false;
      }
    }
  }
  var oe;
  if (typeof y == `function`) oe = function() {
    y(ae);
  };
  else if (typeof MessageChannel < `u`) {
    var se = new MessageChannel(), ce = se.port2;
    se.port1.onmessage = ae, oe = function() {
      ce.postMessage(null);
    };
  } else oe = function() {
    _(ae, 0);
  };
  function le(t3, n3) {
    te = _(function() {
      t3(e2.unstable_now());
    }, n3);
  }
  e2.unstable_IdlePriority = 5, e2.unstable_ImmediatePriority = 1, e2.unstable_LowPriority = 4, e2.unstable_NormalPriority = 3, e2.unstable_Profiling = null, e2.unstable_UserBlockingPriority = 2, e2.unstable_cancelCallback = function(e3) {
    e3.callback = null;
  }, e2.unstable_forceFrameRate = function(e3) {
    0 > e3 || 125 < e3 ? console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`) : ne = 0 < e3 ? Math.floor(1e3 / e3) : 5;
  }, e2.unstable_getCurrentPriorityLevel = function() {
    return f2;
  }, e2.unstable_next = function(e3) {
    switch (f2) {
      case 1:
      case 2:
      case 3:
        var t3 = 3;
        break;
      default:
        t3 = f2;
    }
    var n3 = f2;
    f2 = t3;
    try {
      return e3();
    } finally {
      f2 = n3;
    }
  }, e2.unstable_requestPaint = function() {
    g = true;
  }, e2.unstable_runWithPriority = function(e3, t3) {
    switch (e3) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        e3 = 3;
    }
    var n3 = f2;
    f2 = e3;
    try {
      return t3();
    } finally {
      f2 = n3;
    }
  }, e2.unstable_scheduleCallback = function(r3, i3, a3) {
    var o3 = e2.unstable_now();
    switch (typeof a3 == `object` && a3 ? (a3 = a3.delay, a3 = typeof a3 == `number` && 0 < a3 ? o3 + a3 : o3) : a3 = o3, r3) {
      case 1:
        var s3 = -1;
        break;
      case 2:
        s3 = 250;
        break;
      case 5:
        s3 = 1073741823;
        break;
      case 4:
        s3 = 1e4;
        break;
      default:
        s3 = 5e3;
    }
    return s3 = a3 + s3, r3 = { id: u2++, callback: i3, priorityLevel: r3, startTime: a3, expirationTime: s3, sortIndex: -1 }, a3 > o3 ? (r3.sortIndex = a3, t2(l2, r3), n2(c2) === null && r3 === n2(l2) && (h2 ? (v(te), te = -1) : h2 = true, le(x, a3 - o3))) : (r3.sortIndex = s3, t2(c2, r3), m2 || p2 || (m2 = true, ee || (ee = true, oe()))), r3;
  }, e2.unstable_shouldYield = ie, e2.unstable_wrapCallback = function(e3) {
    var t3 = f2;
    return function() {
      var n3 = f2;
      f2 = t3;
      try {
        return e3.apply(this, arguments);
      } finally {
        f2 = n3;
      }
    };
  };
})), c = n(((e2, t2) => {
  t2.exports = s();
})), l = n(((t2) => {
  var n2 = c(), s2 = (r(), e(i)), l2 = (a(), e(o));
  function u2(e2) {
    var t3 = `https://react.dev/errors/` + e2;
    if (1 < arguments.length) {
      t3 += `?args[]=` + encodeURIComponent(arguments[1]);
      for (var n3 = 2; n3 < arguments.length; n3++) t3 += `&args[]=` + encodeURIComponent(arguments[n3]);
    }
    return `Minified React error #` + e2 + `; visit ` + t3 + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`;
  }
  function d2(e2) {
    return !(!e2 || e2.nodeType !== 1 && e2.nodeType !== 9 && e2.nodeType !== 11);
  }
  function f2(e2) {
    var t3 = e2, n3 = e2;
    if (e2.alternate) for (; t3.return; ) t3 = t3.return;
    else {
      e2 = t3;
      do
        t3 = e2, t3.flags & 4098 && (n3 = t3.return), e2 = t3.return;
      while (e2);
    }
    return t3.tag === 3 ? n3 : null;
  }
  function p2(e2) {
    if (e2.tag === 13) {
      var t3 = e2.memoizedState;
      if (t3 === null && (e2 = e2.alternate, e2 !== null && (t3 = e2.memoizedState)), t3 !== null) return t3.dehydrated;
    }
    return null;
  }
  function m2(e2) {
    if (e2.tag === 31) {
      var t3 = e2.memoizedState;
      if (t3 === null && (e2 = e2.alternate, e2 !== null && (t3 = e2.memoizedState)), t3 !== null) return t3.dehydrated;
    }
    return null;
  }
  function h2(e2) {
    if (f2(e2) !== e2) throw Error(u2(188));
  }
  function g(e2) {
    var t3 = e2.alternate;
    if (!t3) {
      if (t3 = f2(e2), t3 === null) throw Error(u2(188));
      return t3 === e2 ? e2 : null;
    }
    for (var n3 = e2, r2 = t3; ; ) {
      var i2 = n3.return;
      if (i2 === null) break;
      var a2 = i2.alternate;
      if (a2 === null) {
        if (r2 = i2.return, r2 !== null) {
          n3 = r2;
          continue;
        }
        break;
      }
      if (i2.child === a2.child) {
        for (a2 = i2.child; a2; ) {
          if (a2 === n3) return h2(i2), e2;
          if (a2 === r2) return h2(i2), t3;
          a2 = a2.sibling;
        }
        throw Error(u2(188));
      }
      if (n3.return !== r2.return) n3 = i2, r2 = a2;
      else {
        for (var o2 = false, s3 = i2.child; s3; ) {
          if (s3 === n3) {
            o2 = true, n3 = i2, r2 = a2;
            break;
          }
          if (s3 === r2) {
            o2 = true, r2 = i2, n3 = a2;
            break;
          }
          s3 = s3.sibling;
        }
        if (!o2) {
          for (s3 = a2.child; s3; ) {
            if (s3 === n3) {
              o2 = true, n3 = a2, r2 = i2;
              break;
            }
            if (s3 === r2) {
              o2 = true, r2 = a2, n3 = i2;
              break;
            }
            s3 = s3.sibling;
          }
          if (!o2) throw Error(u2(189));
        }
      }
      if (n3.alternate !== r2) throw Error(u2(190));
    }
    if (n3.tag !== 3) throw Error(u2(188));
    return n3.stateNode.current === n3 ? e2 : t3;
  }
  function _(e2) {
    var t3 = e2.tag;
    if (t3 === 5 || t3 === 26 || t3 === 27 || t3 === 6) return e2;
    for (e2 = e2.child; e2 !== null; ) {
      if (t3 = _(e2), t3 !== null) return t3;
      e2 = e2.sibling;
    }
    return null;
  }
  var v = Object.assign, y = /* @__PURE__ */ Symbol.for(`react.element`), b = /* @__PURE__ */ Symbol.for(`react.transitional.element`), x = /* @__PURE__ */ Symbol.for(`react.portal`), ee = /* @__PURE__ */ Symbol.for(`react.fragment`), te = /* @__PURE__ */ Symbol.for(`react.strict_mode`), ne = /* @__PURE__ */ Symbol.for(`react.profiler`), re = /* @__PURE__ */ Symbol.for(`react.consumer`), ie = /* @__PURE__ */ Symbol.for(`react.context`), ae = /* @__PURE__ */ Symbol.for(`react.forward_ref`), oe = /* @__PURE__ */ Symbol.for(`react.suspense`), se = /* @__PURE__ */ Symbol.for(`react.suspense_list`), ce = /* @__PURE__ */ Symbol.for(`react.memo`), le = /* @__PURE__ */ Symbol.for(`react.lazy`), ue = /* @__PURE__ */ Symbol.for(`react.activity`), de = /* @__PURE__ */ Symbol.for(`react.memo_cache_sentinel`), fe = Symbol.iterator;
  function pe(e2) {
    return typeof e2 != `object` || !e2 ? null : (e2 = fe && e2[fe] || e2[`@@iterator`], typeof e2 == `function` ? e2 : null);
  }
  var me = /* @__PURE__ */ Symbol.for(`react.client.reference`);
  function he(e2) {
    if (e2 == null) return null;
    if (typeof e2 == `function`) return e2.$$typeof === me ? null : e2.displayName || e2.name || null;
    if (typeof e2 == `string`) return e2;
    switch (e2) {
      case ee:
        return `Fragment`;
      case ne:
        return `Profiler`;
      case te:
        return `StrictMode`;
      case oe:
        return `Suspense`;
      case se:
        return `SuspenseList`;
      case ue:
        return `Activity`;
    }
    if (typeof e2 == `object`) switch (e2.$$typeof) {
      case x:
        return `Portal`;
      case ie:
        return e2.displayName || `Context`;
      case re:
        return (e2._context.displayName || `Context`) + `.Consumer`;
      case ae:
        var t3 = e2.render;
        return e2 = e2.displayName, e2 || (e2 = (e2 = t3.displayName || t3.name || ``, e2 === `` ? `ForwardRef` : `ForwardRef(` + e2 + `)`)), e2;
      case ce:
        return t3 = e2.displayName || null, t3 === null ? he(e2.type) || `Memo` : t3;
      case le:
        t3 = e2._payload, e2 = e2._init;
        try {
          return he(e2(t3));
        } catch {
        }
    }
    return null;
  }
  var ge = Array.isArray, S = s2.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, C = l2.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, _e = { pending: false, data: null, method: null, action: null }, ve = [], ye = -1;
  function be(e2) {
    return { current: e2 };
  }
  function w(e2) {
    0 > ye || (e2.current = ve[ye], ve[ye] = null, ye--);
  }
  function T(e2, t3) {
    ye++, ve[ye] = e2.current, e2.current = t3;
  }
  var xe = be(null), Se = be(null), Ce = be(null), we = be(null);
  function Te(e2, t3) {
    switch (T(Ce, t3), T(Se, e2), T(xe, null), t3.nodeType) {
      case 9:
      case 11:
        e2 = (e2 = t3.documentElement) && (e2 = e2.namespaceURI) ? Wd(e2) : 0;
        break;
      default:
        if (e2 = t3.tagName, t3 = t3.namespaceURI) t3 = Wd(t3), e2 = Gd(t3, e2);
        else switch (e2) {
          case `svg`:
            e2 = 1;
            break;
          case `math`:
            e2 = 2;
            break;
          default:
            e2 = 0;
        }
    }
    w(xe), T(xe, e2);
  }
  function Ee() {
    w(xe), w(Se), w(Ce);
  }
  function De(e2) {
    e2.memoizedState !== null && T(we, e2);
    var t3 = xe.current, n3 = Gd(t3, e2.type);
    t3 !== n3 && (T(Se, e2), T(xe, n3));
  }
  function Oe(e2) {
    Se.current === e2 && (w(xe), w(Se)), we.current === e2 && (w(we), tp._currentValue = _e);
  }
  var ke, Ae;
  function je(e2) {
    if (ke === void 0) try {
      throw Error();
    } catch (e3) {
      var t3 = e3.stack.trim().match(/\n( *(at )?)/);
      ke = t3 && t3[1] || ``, Ae = -1 < e3.stack.indexOf(`
    at`) ? ` (<anonymous>)` : -1 < e3.stack.indexOf(`@`) ? `@unknown:0:0` : ``;
    }
    return `
` + ke + e2 + Ae;
  }
  var Me = false;
  function Ne(e2, t3) {
    if (!e2 || Me) return ``;
    Me = true;
    var n3 = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var r2 = { DetermineComponentFrameRoot: function() {
        try {
          if (t3) {
            var n4 = function() {
              throw Error();
            };
            if (Object.defineProperty(n4.prototype, "props", { set: function() {
              throw Error();
            } }), typeof Reflect == `object` && Reflect.construct) {
              try {
                Reflect.construct(n4, []);
              } catch (e3) {
                var r3 = e3;
              }
              Reflect.construct(e2, [], n4);
            } else {
              try {
                n4.call();
              } catch (e3) {
                r3 = e3;
              }
              e2.call(n4.prototype);
            }
          } else {
            try {
              throw Error();
            } catch (e3) {
              r3 = e3;
            }
            (n4 = e2()) && typeof n4.catch == `function` && n4.catch(function() {
            });
          }
        } catch (e3) {
          if (e3 && r3 && typeof e3.stack == `string`) return [e3.stack, r3.stack];
        }
        return [null, null];
      } };
      r2.DetermineComponentFrameRoot.displayName = `DetermineComponentFrameRoot`;
      var i2 = Object.getOwnPropertyDescriptor(r2.DetermineComponentFrameRoot, `name`);
      i2 && i2.configurable && Object.defineProperty(r2.DetermineComponentFrameRoot, "name", { value: `DetermineComponentFrameRoot` });
      var a2 = r2.DetermineComponentFrameRoot(), o2 = a2[0], s3 = a2[1];
      if (o2 && s3) {
        var c2 = o2.split(`
`), l3 = s3.split(`
`);
        for (i2 = r2 = 0; r2 < c2.length && !c2[r2].includes(`DetermineComponentFrameRoot`); ) r2++;
        for (; i2 < l3.length && !l3[i2].includes(`DetermineComponentFrameRoot`); ) i2++;
        if (r2 === c2.length || i2 === l3.length) for (r2 = c2.length - 1, i2 = l3.length - 1; 1 <= r2 && 0 <= i2 && c2[r2] !== l3[i2]; ) i2--;
        for (; 1 <= r2 && 0 <= i2; r2--, i2--) if (c2[r2] !== l3[i2]) {
          if (r2 !== 1 || i2 !== 1) do
            if (r2--, i2--, 0 > i2 || c2[r2] !== l3[i2]) {
              var u3 = `
` + c2[r2].replace(` at new `, ` at `);
              return e2.displayName && u3.includes(`<anonymous>`) && (u3 = u3.replace(`<anonymous>`, e2.displayName)), u3;
            }
          while (1 <= r2 && 0 <= i2);
          break;
        }
      }
    } finally {
      Me = false, Error.prepareStackTrace = n3;
    }
    return (n3 = e2 ? e2.displayName || e2.name : ``) ? je(n3) : ``;
  }
  function Pe(e2, t3) {
    switch (e2.tag) {
      case 26:
      case 27:
      case 5:
        return je(e2.type);
      case 16:
        return je(`Lazy`);
      case 13:
        return e2.child !== t3 && t3 !== null ? je(`Suspense Fallback`) : je(`Suspense`);
      case 19:
        return je(`SuspenseList`);
      case 0:
      case 15:
        return Ne(e2.type, false);
      case 11:
        return Ne(e2.type.render, false);
      case 1:
        return Ne(e2.type, true);
      case 31:
        return je(`Activity`);
      default:
        return ``;
    }
  }
  function Fe(e2) {
    try {
      var t3 = ``, n3 = null;
      do
        t3 += Pe(e2, n3), n3 = e2, e2 = e2.return;
      while (e2);
      return t3;
    } catch (e3) {
      return `
Error generating stack: ` + e3.message + `
` + e3.stack;
    }
  }
  var Ie = Object.prototype.hasOwnProperty, Le = n2.unstable_scheduleCallback, Re = n2.unstable_cancelCallback, ze = n2.unstable_shouldYield, Be = n2.unstable_requestPaint, Ve = n2.unstable_now, He = n2.unstable_getCurrentPriorityLevel, Ue = n2.unstable_ImmediatePriority, We = n2.unstable_UserBlockingPriority, Ge = n2.unstable_NormalPriority, Ke = n2.unstable_LowPriority, qe = n2.unstable_IdlePriority, Je = n2.log, Ye = n2.unstable_setDisableYieldValue, Xe = null, Ze = null;
  function Qe(e2) {
    if (typeof Je == `function` && Ye(e2), Ze && typeof Ze.setStrictMode == `function`) try {
      Ze.setStrictMode(Xe, e2);
    } catch {
    }
  }
  var $e = Math.clz32 ? Math.clz32 : nt, et = Math.log, tt = Math.LN2;
  function nt(e2) {
    return e2 >>>= 0, e2 === 0 ? 32 : 31 - (et(e2) / tt | 0) | 0;
  }
  var rt = 256, it = 262144, at = 4194304;
  function ot(e2) {
    var t3 = e2 & 42;
    if (t3 !== 0) return t3;
    switch (e2 & -e2) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
        return e2 & 261888;
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e2 & 3932160;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return e2 & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return e2;
    }
  }
  function st(e2, t3, n3) {
    var r2 = e2.pendingLanes;
    if (r2 === 0) return 0;
    var i2 = 0, a2 = e2.suspendedLanes, o2 = e2.pingedLanes;
    e2 = e2.warmLanes;
    var s3 = r2 & 134217727;
    return s3 === 0 ? (s3 = r2 & ~a2, s3 === 0 ? o2 === 0 ? n3 || (n3 = r2 & ~e2, n3 !== 0 && (i2 = ot(n3))) : i2 = ot(o2) : i2 = ot(s3)) : (r2 = s3 & ~a2, r2 === 0 ? (o2 &= s3, o2 === 0 ? n3 || (n3 = s3 & ~e2, n3 !== 0 && (i2 = ot(n3))) : i2 = ot(o2)) : i2 = ot(r2)), i2 === 0 ? 0 : t3 !== 0 && t3 !== i2 && (t3 & a2) === 0 && (a2 = i2 & -i2, n3 = t3 & -t3, a2 >= n3 || a2 === 32 && n3 & 4194048) ? t3 : i2;
  }
  function ct(e2, t3) {
    return (e2.pendingLanes & ~(e2.suspendedLanes & ~e2.pingedLanes) & t3) === 0;
  }
  function lt(e2, t3) {
    switch (e2) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t3 + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t3 + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function ut() {
    var e2 = at;
    return at <<= 1, !(at & 62914560) && (at = 4194304), e2;
  }
  function dt(e2) {
    for (var t3 = [], n3 = 0; 31 > n3; n3++) t3.push(e2);
    return t3;
  }
  function ft(e2, t3) {
    e2.pendingLanes |= t3, t3 !== 268435456 && (e2.suspendedLanes = 0, e2.pingedLanes = 0, e2.warmLanes = 0);
  }
  function pt(e2, t3, n3, r2, i2, a2) {
    var o2 = e2.pendingLanes;
    e2.pendingLanes = n3, e2.suspendedLanes = 0, e2.pingedLanes = 0, e2.warmLanes = 0, e2.expiredLanes &= n3, e2.entangledLanes &= n3, e2.errorRecoveryDisabledLanes &= n3, e2.shellSuspendCounter = 0;
    var s3 = e2.entanglements, c2 = e2.expirationTimes, l3 = e2.hiddenUpdates;
    for (n3 = o2 & ~n3; 0 < n3; ) {
      var u3 = 31 - $e(n3), d3 = 1 << u3;
      s3[u3] = 0, c2[u3] = -1;
      var f3 = l3[u3];
      if (f3 !== null) for (l3[u3] = null, u3 = 0; u3 < f3.length; u3++) {
        var p3 = f3[u3];
        p3 !== null && (p3.lane &= -536870913);
      }
      n3 &= ~d3;
    }
    r2 !== 0 && mt(e2, r2, 0), a2 !== 0 && i2 === 0 && e2.tag !== 0 && (e2.suspendedLanes |= a2 & ~(o2 & ~t3));
  }
  function mt(e2, t3, n3) {
    e2.pendingLanes |= t3, e2.suspendedLanes &= ~t3;
    var r2 = 31 - $e(t3);
    e2.entangledLanes |= t3, e2.entanglements[r2] = e2.entanglements[r2] | 1073741824 | n3 & 261930;
  }
  function ht(e2, t3) {
    var n3 = e2.entangledLanes |= t3;
    for (e2 = e2.entanglements; n3; ) {
      var r2 = 31 - $e(n3), i2 = 1 << r2;
      i2 & t3 | e2[r2] & t3 && (e2[r2] |= t3), n3 &= ~i2;
    }
  }
  function gt(e2, t3) {
    var n3 = t3 & -t3;
    return n3 = n3 & 42 ? 1 : _t(n3), (n3 & (e2.suspendedLanes | t3)) === 0 ? n3 : 0;
  }
  function _t(e2) {
    switch (e2) {
      case 2:
        e2 = 1;
        break;
      case 8:
        e2 = 4;
        break;
      case 32:
        e2 = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        e2 = 128;
        break;
      case 268435456:
        e2 = 134217728;
        break;
      default:
        e2 = 0;
    }
    return e2;
  }
  function vt(e2) {
    return e2 &= -e2, 2 < e2 ? 8 < e2 ? e2 & 134217727 ? 32 : 268435456 : 8 : 2;
  }
  function yt() {
    var e2 = C.p;
    return e2 === 0 ? (e2 = window.event, e2 === void 0 ? 32 : _p(e2.type)) : e2;
  }
  function bt(e2, t3) {
    var n3 = C.p;
    try {
      return C.p = e2, t3();
    } finally {
      C.p = n3;
    }
  }
  var xt = Math.random().toString(36).slice(2), St = `__reactFiber$` + xt, Ct = `__reactProps$` + xt, wt = `__reactContainer$` + xt, Tt = `__reactEvents$` + xt, Et = `__reactListeners$` + xt, Dt = `__reactHandles$` + xt, Ot = `__reactResources$` + xt, kt = `__reactMarker$` + xt;
  function At(e2) {
    delete e2[St], delete e2[Ct], delete e2[Tt], delete e2[Et], delete e2[Dt];
  }
  function jt(e2) {
    var t3 = e2[St];
    if (t3) return t3;
    for (var n3 = e2.parentNode; n3; ) {
      if (t3 = n3[wt] || n3[St]) {
        if (n3 = t3.alternate, t3.child !== null || n3 !== null && n3.child !== null) for (e2 = mf(e2); e2 !== null; ) {
          if (n3 = e2[St]) return n3;
          e2 = mf(e2);
        }
        return t3;
      }
      e2 = n3, n3 = e2.parentNode;
    }
    return null;
  }
  function Mt(e2) {
    if (e2 = e2[St] || e2[wt]) {
      var t3 = e2.tag;
      if (t3 === 5 || t3 === 6 || t3 === 13 || t3 === 31 || t3 === 26 || t3 === 27 || t3 === 3) return e2;
    }
    return null;
  }
  function Nt(e2) {
    var t3 = e2.tag;
    if (t3 === 5 || t3 === 26 || t3 === 27 || t3 === 6) return e2.stateNode;
    throw Error(u2(33));
  }
  function Pt(e2) {
    var t3 = e2[Ot];
    return t3 || (t3 = e2[Ot] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }), t3;
  }
  function E(e2) {
    e2[kt] = true;
  }
  var Ft = /* @__PURE__ */ new Set(), It = {};
  function Lt(e2, t3) {
    Rt(e2, t3), Rt(e2 + `Capture`, t3);
  }
  function Rt(e2, t3) {
    for (It[e2] = t3, e2 = 0; e2 < t3.length; e2++) Ft.add(t3[e2]);
  }
  var zt = RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`), Bt = {}, Vt = {};
  function Ht(e2) {
    return Ie.call(Vt, e2) ? true : Ie.call(Bt, e2) ? false : zt.test(e2) ? Vt[e2] = true : (Bt[e2] = true, false);
  }
  function Ut(e2, t3, n3) {
    if (Ht(t3)) {
      if (n3 === null) e2.removeAttribute(t3);
      else {
        switch (typeof n3) {
          case `undefined`:
          case `function`:
          case `symbol`:
            e2.removeAttribute(t3);
            return;
          case `boolean`:
            var r2 = t3.toLowerCase().slice(0, 5);
            if (r2 !== `data-` && r2 !== `aria-`) {
              e2.removeAttribute(t3);
              return;
            }
        }
        e2.setAttribute(t3, `` + n3);
      }
    }
  }
  function Wt(e2, t3, n3) {
    if (n3 === null) e2.removeAttribute(t3);
    else {
      switch (typeof n3) {
        case `undefined`:
        case `function`:
        case `symbol`:
        case `boolean`:
          e2.removeAttribute(t3);
          return;
      }
      e2.setAttribute(t3, `` + n3);
    }
  }
  function Gt(e2, t3, n3, r2) {
    if (r2 === null) e2.removeAttribute(n3);
    else {
      switch (typeof r2) {
        case `undefined`:
        case `function`:
        case `symbol`:
        case `boolean`:
          e2.removeAttribute(n3);
          return;
      }
      e2.setAttributeNS(t3, n3, `` + r2);
    }
  }
  function Kt(e2) {
    switch (typeof e2) {
      case `bigint`:
      case `boolean`:
      case `number`:
      case `string`:
      case `undefined`:
        return e2;
      case `object`:
        return e2;
      default:
        return ``;
    }
  }
  function qt(e2) {
    var t3 = e2.type;
    return (e2 = e2.nodeName) && e2.toLowerCase() === `input` && (t3 === `checkbox` || t3 === `radio`);
  }
  function Jt(e2, t3, n3) {
    var r2 = Object.getOwnPropertyDescriptor(e2.constructor.prototype, t3);
    if (!e2.hasOwnProperty(t3) && r2 !== void 0 && typeof r2.get == `function` && typeof r2.set == `function`) {
      var i2 = r2.get, a2 = r2.set;
      return Object.defineProperty(e2, t3, { configurable: true, get: function() {
        return i2.call(this);
      }, set: function(e3) {
        n3 = `` + e3, a2.call(this, e3);
      } }), Object.defineProperty(e2, t3, { enumerable: r2.enumerable }), { getValue: function() {
        return n3;
      }, setValue: function(e3) {
        n3 = `` + e3;
      }, stopTracking: function() {
        e2._valueTracker = null, delete e2[t3];
      } };
    }
  }
  function Yt(e2) {
    if (!e2._valueTracker) {
      var t3 = qt(e2) ? `checked` : `value`;
      e2._valueTracker = Jt(e2, t3, `` + e2[t3]);
    }
  }
  function Xt(e2) {
    if (!e2) return false;
    var t3 = e2._valueTracker;
    if (!t3) return true;
    var n3 = t3.getValue(), r2 = ``;
    return e2 && (r2 = qt(e2) ? e2.checked ? `true` : `false` : e2.value), e2 = r2, e2 !== n3 && (t3.setValue(e2), true);
  }
  function Zt(e2) {
    if (e2 || (e2 = typeof document < `u` ? document : void 0), e2 === void 0) return null;
    try {
      return e2.activeElement || e2.body;
    } catch {
      return e2.body;
    }
  }
  var Qt = /[\n"\\]/g;
  function $t(e2) {
    return e2.replace(Qt, function(e3) {
      return `\\` + e3.charCodeAt(0).toString(16) + ` `;
    });
  }
  function en(e2, t3, n3, r2, i2, a2, o2, s3) {
    e2.name = ``, o2 != null && typeof o2 != `function` && typeof o2 != `symbol` && typeof o2 != `boolean` ? e2.type = o2 : e2.removeAttribute(`type`), t3 == null ? o2 !== `submit` && o2 !== `reset` || e2.removeAttribute(`value`) : o2 === `number` ? (t3 === 0 && e2.value === `` || e2.value != t3) && (e2.value = `` + Kt(t3)) : e2.value !== `` + Kt(t3) && (e2.value = `` + Kt(t3)), t3 == null ? n3 == null ? r2 != null && e2.removeAttribute(`value`) : nn(e2, o2, Kt(n3)) : nn(e2, o2, Kt(t3)), i2 == null && a2 != null && (e2.defaultChecked = !!a2), i2 != null && (e2.checked = i2 && typeof i2 != `function` && typeof i2 != `symbol`), s3 != null && typeof s3 != `function` && typeof s3 != `symbol` && typeof s3 != `boolean` ? e2.name = `` + Kt(s3) : e2.removeAttribute(`name`);
  }
  function tn(e2, t3, n3, r2, i2, a2, o2, s3) {
    if (a2 != null && typeof a2 != `function` && typeof a2 != `symbol` && typeof a2 != `boolean` && (e2.type = a2), t3 != null || n3 != null) {
      if (!(a2 !== `submit` && a2 !== `reset` || t3 != null)) {
        Yt(e2);
        return;
      }
      n3 = n3 == null ? `` : `` + Kt(n3), t3 = t3 == null ? n3 : `` + Kt(t3), s3 || t3 === e2.value || (e2.value = t3), e2.defaultValue = t3;
    }
    r2 ?? (r2 = i2), r2 = typeof r2 != `function` && typeof r2 != `symbol` && !!r2, e2.checked = s3 ? e2.checked : !!r2, e2.defaultChecked = !!r2, o2 != null && typeof o2 != `function` && typeof o2 != `symbol` && typeof o2 != `boolean` && (e2.name = o2), Yt(e2);
  }
  function nn(e2, t3, n3) {
    t3 === `number` && Zt(e2.ownerDocument) === e2 || e2.defaultValue === `` + n3 || (e2.defaultValue = `` + n3);
  }
  function rn(e2, t3, n3, r2) {
    if (e2 = e2.options, t3) {
      t3 = {};
      for (var i2 = 0; i2 < n3.length; i2++) t3[`$` + n3[i2]] = true;
      for (n3 = 0; n3 < e2.length; n3++) i2 = t3.hasOwnProperty(`$` + e2[n3].value), e2[n3].selected !== i2 && (e2[n3].selected = i2), i2 && r2 && (e2[n3].defaultSelected = true);
    } else {
      for (n3 = `` + Kt(n3), t3 = null, i2 = 0; i2 < e2.length; i2++) {
        if (e2[i2].value === n3) {
          e2[i2].selected = true, r2 && (e2[i2].defaultSelected = true);
          return;
        }
        t3 !== null || e2[i2].disabled || (t3 = e2[i2]);
      }
      t3 !== null && (t3.selected = true);
    }
  }
  function an(e2, t3, n3) {
    if (t3 != null && (t3 = `` + Kt(t3), t3 !== e2.value && (e2.value = t3), n3 == null)) {
      e2.defaultValue !== t3 && (e2.defaultValue = t3);
      return;
    }
    e2.defaultValue = n3 == null ? `` : `` + Kt(n3);
  }
  function on(e2, t3, n3, r2) {
    if (t3 == null) {
      if (r2 != null) {
        if (n3 != null) throw Error(u2(92));
        if (ge(r2)) {
          if (1 < r2.length) throw Error(u2(93));
          r2 = r2[0];
        }
        n3 = r2;
      }
      n3 ?? (n3 = ``), t3 = n3;
    }
    n3 = Kt(t3), e2.defaultValue = n3, r2 = e2.textContent, r2 === n3 && r2 !== `` && r2 !== null && (e2.value = r2), Yt(e2);
  }
  function sn(e2, t3) {
    if (t3) {
      var n3 = e2.firstChild;
      if (n3 && n3 === e2.lastChild && n3.nodeType === 3) {
        n3.nodeValue = t3;
        return;
      }
    }
    e2.textContent = t3;
  }
  var cn = new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));
  function ln(e2, t3, n3) {
    var r2 = t3.indexOf(`--`) === 0;
    n3 == null || typeof n3 == `boolean` || n3 === `` ? r2 ? e2.setProperty(t3, ``) : t3 === `float` ? e2.cssFloat = `` : e2[t3] = `` : r2 ? e2.setProperty(t3, n3) : typeof n3 != `number` || n3 === 0 || cn.has(t3) ? t3 === `float` ? e2.cssFloat = n3 : e2[t3] = (`` + n3).trim() : e2[t3] = n3 + `px`;
  }
  function un(e2, t3, n3) {
    if (t3 != null && typeof t3 != `object`) throw Error(u2(62));
    if (e2 = e2.style, n3 != null) {
      for (var r2 in n3) !n3.hasOwnProperty(r2) || t3 != null && t3.hasOwnProperty(r2) || (r2.indexOf(`--`) === 0 ? e2.setProperty(r2, ``) : r2 === `float` ? e2.cssFloat = `` : e2[r2] = ``);
      for (var i2 in t3) r2 = t3[i2], t3.hasOwnProperty(i2) && n3[i2] !== r2 && ln(e2, i2, r2);
    } else for (var a2 in t3) t3.hasOwnProperty(a2) && ln(e2, a2, t3[a2]);
  }
  function dn(e2) {
    if (e2.indexOf(`-`) === -1) return false;
    switch (e2) {
      case `annotation-xml`:
      case `color-profile`:
      case `font-face`:
      case `font-face-src`:
      case `font-face-uri`:
      case `font-face-format`:
      case `font-face-name`:
      case `missing-glyph`:
        return false;
      default:
        return true;
    }
  }
  var fn = /* @__PURE__ */ new Map([[`acceptCharset`, `accept-charset`], [`htmlFor`, `for`], [`httpEquiv`, `http-equiv`], [`crossOrigin`, `crossorigin`], [`accentHeight`, `accent-height`], [`alignmentBaseline`, `alignment-baseline`], [`arabicForm`, `arabic-form`], [`baselineShift`, `baseline-shift`], [`capHeight`, `cap-height`], [`clipPath`, `clip-path`], [`clipRule`, `clip-rule`], [`colorInterpolation`, `color-interpolation`], [`colorInterpolationFilters`, `color-interpolation-filters`], [`colorProfile`, `color-profile`], [`colorRendering`, `color-rendering`], [`dominantBaseline`, `dominant-baseline`], [`enableBackground`, `enable-background`], [`fillOpacity`, `fill-opacity`], [`fillRule`, `fill-rule`], [`floodColor`, `flood-color`], [`floodOpacity`, `flood-opacity`], [`fontFamily`, `font-family`], [`fontSize`, `font-size`], [`fontSizeAdjust`, `font-size-adjust`], [`fontStretch`, `font-stretch`], [`fontStyle`, `font-style`], [`fontVariant`, `font-variant`], [`fontWeight`, `font-weight`], [`glyphName`, `glyph-name`], [`glyphOrientationHorizontal`, `glyph-orientation-horizontal`], [`glyphOrientationVertical`, `glyph-orientation-vertical`], [`horizAdvX`, `horiz-adv-x`], [`horizOriginX`, `horiz-origin-x`], [`imageRendering`, `image-rendering`], [`letterSpacing`, `letter-spacing`], [`lightingColor`, `lighting-color`], [`markerEnd`, `marker-end`], [`markerMid`, `marker-mid`], [`markerStart`, `marker-start`], [`overlinePosition`, `overline-position`], [`overlineThickness`, `overline-thickness`], [`paintOrder`, `paint-order`], [`panose-1`, `panose-1`], [`pointerEvents`, `pointer-events`], [`renderingIntent`, `rendering-intent`], [`shapeRendering`, `shape-rendering`], [`stopColor`, `stop-color`], [`stopOpacity`, `stop-opacity`], [`strikethroughPosition`, `strikethrough-position`], [`strikethroughThickness`, `strikethrough-thickness`], [`strokeDasharray`, `stroke-dasharray`], [`strokeDashoffset`, `stroke-dashoffset`], [`strokeLinecap`, `stroke-linecap`], [`strokeLinejoin`, `stroke-linejoin`], [`strokeMiterlimit`, `stroke-miterlimit`], [`strokeOpacity`, `stroke-opacity`], [`strokeWidth`, `stroke-width`], [`textAnchor`, `text-anchor`], [`textDecoration`, `text-decoration`], [`textRendering`, `text-rendering`], [`transformOrigin`, `transform-origin`], [`underlinePosition`, `underline-position`], [`underlineThickness`, `underline-thickness`], [`unicodeBidi`, `unicode-bidi`], [`unicodeRange`, `unicode-range`], [`unitsPerEm`, `units-per-em`], [`vAlphabetic`, `v-alphabetic`], [`vHanging`, `v-hanging`], [`vIdeographic`, `v-ideographic`], [`vMathematical`, `v-mathematical`], [`vectorEffect`, `vector-effect`], [`vertAdvY`, `vert-adv-y`], [`vertOriginX`, `vert-origin-x`], [`vertOriginY`, `vert-origin-y`], [`wordSpacing`, `word-spacing`], [`writingMode`, `writing-mode`], [`xmlnsXlink`, `xmlns:xlink`], [`xHeight`, `x-height`]]), pn = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function mn(e2) {
    return pn.test(`` + e2) ? `javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')` : e2;
  }
  function hn() {
  }
  var gn = null;
  function _n(e2) {
    return e2 = e2.target || e2.srcElement || window, e2.correspondingUseElement && (e2 = e2.correspondingUseElement), e2.nodeType === 3 ? e2.parentNode : e2;
  }
  var vn = null, yn = null;
  function bn(e2) {
    var t3 = Mt(e2);
    if (t3 && (e2 = t3.stateNode)) {
      var n3 = e2[Ct] || null;
      a: switch (e2 = t3.stateNode, t3.type) {
        case `input`:
          if (en(e2, n3.value, n3.defaultValue, n3.defaultValue, n3.checked, n3.defaultChecked, n3.type, n3.name), t3 = n3.name, n3.type === `radio` && t3 != null) {
            for (n3 = e2; n3.parentNode; ) n3 = n3.parentNode;
            for (n3 = n3.querySelectorAll(`input[name="` + $t(`` + t3) + `"][type="radio"]`), t3 = 0; t3 < n3.length; t3++) {
              var r2 = n3[t3];
              if (r2 !== e2 && r2.form === e2.form) {
                var i2 = r2[Ct] || null;
                if (!i2) throw Error(u2(90));
                en(r2, i2.value, i2.defaultValue, i2.defaultValue, i2.checked, i2.defaultChecked, i2.type, i2.name);
              }
            }
            for (t3 = 0; t3 < n3.length; t3++) r2 = n3[t3], r2.form === e2.form && Xt(r2);
          }
          break a;
        case `textarea`:
          an(e2, n3.value, n3.defaultValue);
          break a;
        case `select`:
          t3 = n3.value, t3 != null && rn(e2, !!n3.multiple, t3, false);
      }
    }
  }
  var xn = false;
  function Sn(e2, t3, n3) {
    if (xn) return e2(t3, n3);
    xn = true;
    try {
      return e2(t3);
    } finally {
      if (xn = false, (vn !== null || yn !== null) && (wu(), vn && (t3 = vn, e2 = yn, yn = vn = null, bn(t3), e2))) for (t3 = 0; t3 < e2.length; t3++) bn(e2[t3]);
    }
  }
  function Cn(e2, t3) {
    var n3 = e2.stateNode;
    if (n3 === null) return null;
    var r2 = n3[Ct] || null;
    if (r2 === null) return null;
    n3 = r2[t3];
    a: switch (t3) {
      case `onClick`:
      case `onClickCapture`:
      case `onDoubleClick`:
      case `onDoubleClickCapture`:
      case `onMouseDown`:
      case `onMouseDownCapture`:
      case `onMouseMove`:
      case `onMouseMoveCapture`:
      case `onMouseUp`:
      case `onMouseUpCapture`:
      case `onMouseEnter`:
        (r2 = !r2.disabled) || (e2 = e2.type, r2 = e2 !== `button` && e2 !== `input` && e2 !== `select` && e2 !== `textarea`), e2 = !r2;
        break a;
      default:
        e2 = false;
    }
    if (e2) return null;
    if (n3 && typeof n3 != `function`) throw Error(u2(231, t3, typeof n3));
    return n3;
  }
  var wn = !(typeof window > `u` || window.document === void 0 || window.document.createElement === void 0), Tn = false;
  if (wn) try {
    var En = {};
    Object.defineProperty(En, "passive", { get: function() {
      Tn = true;
    } }), window.addEventListener(`test`, En, En), window.removeEventListener(`test`, En, En);
  } catch {
    Tn = false;
  }
  var Dn = null, On = null, kn = null;
  function An() {
    if (kn) return kn;
    var e2, t3 = On, n3 = t3.length, r2, i2 = `value` in Dn ? Dn.value : Dn.textContent, a2 = i2.length;
    for (e2 = 0; e2 < n3 && t3[e2] === i2[e2]; e2++) ;
    var o2 = n3 - e2;
    for (r2 = 1; r2 <= o2 && t3[n3 - r2] === i2[a2 - r2]; r2++) ;
    return kn = i2.slice(e2, 1 < r2 ? 1 - r2 : void 0);
  }
  function jn(e2) {
    var t3 = e2.keyCode;
    return `charCode` in e2 ? (e2 = e2.charCode, e2 === 0 && t3 === 13 && (e2 = 13)) : e2 = t3, e2 === 10 && (e2 = 13), 32 <= e2 || e2 === 13 ? e2 : 0;
  }
  function Mn() {
    return true;
  }
  function Nn() {
    return false;
  }
  function Pn(e2) {
    function t3(t4, n3, r2, i2, a2) {
      for (var o2 in this._reactName = t4, this._targetInst = r2, this.type = n3, this.nativeEvent = i2, this.target = a2, this.currentTarget = null, e2) e2.hasOwnProperty(o2) && (t4 = e2[o2], this[o2] = t4 ? t4(i2) : i2[o2]);
      return this.isDefaultPrevented = (i2.defaultPrevented == null ? false === i2.returnValue : i2.defaultPrevented) ? Mn : Nn, this.isPropagationStopped = Nn, this;
    }
    return v(t3.prototype, { preventDefault: function() {
      this.defaultPrevented = true;
      var e3 = this.nativeEvent;
      e3 && (e3.preventDefault ? e3.preventDefault() : typeof e3.returnValue != `unknown` && (e3.returnValue = false), this.isDefaultPrevented = Mn);
    }, stopPropagation: function() {
      var e3 = this.nativeEvent;
      e3 && (e3.stopPropagation ? e3.stopPropagation() : typeof e3.cancelBubble != `unknown` && (e3.cancelBubble = true), this.isPropagationStopped = Mn);
    }, persist: function() {
    }, isPersistent: Mn }), t3;
  }
  var Fn = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(e2) {
    return e2.timeStamp || Date.now();
  }, defaultPrevented: 0, isTrusted: 0 }, In = Pn(Fn), Ln = v({}, Fn, { view: 0, detail: 0 }), Rn = Pn(Ln), zn, Bn, Vn, Hn = v({}, Ln, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: $n, button: 0, buttons: 0, relatedTarget: function(e2) {
    return e2.relatedTarget === void 0 ? e2.fromElement === e2.srcElement ? e2.toElement : e2.fromElement : e2.relatedTarget;
  }, movementX: function(e2) {
    return `movementX` in e2 ? e2.movementX : (e2 !== Vn && (Vn && e2.type === `mousemove` ? (zn = e2.screenX - Vn.screenX, Bn = e2.screenY - Vn.screenY) : Bn = zn = 0, Vn = e2), zn);
  }, movementY: function(e2) {
    return `movementY` in e2 ? e2.movementY : Bn;
  } }), Un = Pn(Hn), Wn = Pn(v({}, Hn, { dataTransfer: 0 })), Gn = Pn(v({}, Ln, { relatedTarget: 0 })), Kn = Pn(v({}, Fn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 })), qn = Pn(v({}, Fn, { clipboardData: function(e2) {
    return `clipboardData` in e2 ? e2.clipboardData : window.clipboardData;
  } })), Jn = Pn(v({}, Fn, { data: 0 })), Yn = { Esc: `Escape`, Spacebar: ` `, Left: `ArrowLeft`, Up: `ArrowUp`, Right: `ArrowRight`, Down: `ArrowDown`, Del: `Delete`, Win: `OS`, Menu: `ContextMenu`, Apps: `ContextMenu`, Scroll: `ScrollLock`, MozPrintableKey: `Unidentified` }, Xn = { 8: `Backspace`, 9: `Tab`, 12: `Clear`, 13: `Enter`, 16: `Shift`, 17: `Control`, 18: `Alt`, 19: `Pause`, 20: `CapsLock`, 27: `Escape`, 32: ` `, 33: `PageUp`, 34: `PageDown`, 35: `End`, 36: `Home`, 37: `ArrowLeft`, 38: `ArrowUp`, 39: `ArrowRight`, 40: `ArrowDown`, 45: `Insert`, 46: `Delete`, 112: `F1`, 113: `F2`, 114: `F3`, 115: `F4`, 116: `F5`, 117: `F6`, 118: `F7`, 119: `F8`, 120: `F9`, 121: `F10`, 122: `F11`, 123: `F12`, 144: `NumLock`, 145: `ScrollLock`, 224: `Meta` }, Zn = { Alt: `altKey`, Control: `ctrlKey`, Meta: `metaKey`, Shift: `shiftKey` };
  function Qn(e2) {
    var t3 = this.nativeEvent;
    return t3.getModifierState ? t3.getModifierState(e2) : (e2 = Zn[e2]) ? !!t3[e2] : false;
  }
  function $n() {
    return Qn;
  }
  var er = Pn(v({}, Ln, { key: function(e2) {
    if (e2.key) {
      var t3 = Yn[e2.key] || e2.key;
      if (t3 !== `Unidentified`) return t3;
    }
    return e2.type === `keypress` ? (e2 = jn(e2), e2 === 13 ? `Enter` : String.fromCharCode(e2)) : e2.type === `keydown` || e2.type === `keyup` ? Xn[e2.keyCode] || `Unidentified` : ``;
  }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: $n, charCode: function(e2) {
    return e2.type === `keypress` ? jn(e2) : 0;
  }, keyCode: function(e2) {
    return e2.type === `keydown` || e2.type === `keyup` ? e2.keyCode : 0;
  }, which: function(e2) {
    return e2.type === `keypress` ? jn(e2) : e2.type === `keydown` || e2.type === `keyup` ? e2.keyCode : 0;
  } })), tr = Pn(v({}, Hn, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 })), nr = Pn(v({}, Ln, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: $n })), rr = Pn(v({}, Fn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 })), ir = Pn(v({}, Hn, { deltaX: function(e2) {
    return `deltaX` in e2 ? e2.deltaX : `wheelDeltaX` in e2 ? -e2.wheelDeltaX : 0;
  }, deltaY: function(e2) {
    return `deltaY` in e2 ? e2.deltaY : `wheelDeltaY` in e2 ? -e2.wheelDeltaY : `wheelDelta` in e2 ? -e2.wheelDelta : 0;
  }, deltaZ: 0, deltaMode: 0 })), ar = Pn(v({}, Fn, { newState: 0, oldState: 0 })), or = [9, 13, 27, 32], sr = wn && `CompositionEvent` in window, cr = null;
  wn && `documentMode` in document && (cr = document.documentMode);
  var lr = wn && `TextEvent` in window && !cr, ur = wn && (!sr || cr && 8 < cr && 11 >= cr), dr = ` `, fr = false;
  function pr(e2, t3) {
    switch (e2) {
      case `keyup`:
        return or.indexOf(t3.keyCode) !== -1;
      case `keydown`:
        return t3.keyCode !== 229;
      case `keypress`:
      case `mousedown`:
      case `focusout`:
        return true;
      default:
        return false;
    }
  }
  function mr(e2) {
    return e2 = e2.detail, typeof e2 == `object` && `data` in e2 ? e2.data : null;
  }
  var hr = false;
  function gr(e2, t3) {
    switch (e2) {
      case `compositionend`:
        return mr(t3);
      case `keypress`:
        return t3.which === 32 ? (fr = true, dr) : null;
      case `textInput`:
        return e2 = t3.data, e2 === dr && fr ? null : e2;
      default:
        return null;
    }
  }
  function _r(e2, t3) {
    if (hr) return e2 === `compositionend` || !sr && pr(e2, t3) ? (e2 = An(), kn = On = Dn = null, hr = false, e2) : null;
    switch (e2) {
      case `paste`:
        return null;
      case `keypress`:
        if (!(t3.ctrlKey || t3.altKey || t3.metaKey) || t3.ctrlKey && t3.altKey) {
          if (t3.char && 1 < t3.char.length) return t3.char;
          if (t3.which) return String.fromCharCode(t3.which);
        }
        return null;
      case `compositionend`:
        return ur && t3.locale !== `ko` ? null : t3.data;
      default:
        return null;
    }
  }
  var vr = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
  function yr(e2) {
    var t3 = e2 && e2.nodeName && e2.nodeName.toLowerCase();
    return t3 === `input` ? !!vr[e2.type] : t3 === `textarea`;
  }
  function br(e2, t3, n3, r2) {
    vn ? yn ? yn.push(r2) : yn = [r2] : vn = r2, t3 = Ad(t3, `onChange`), 0 < t3.length && (n3 = new In(`onChange`, `change`, null, n3, r2), e2.push({ event: n3, listeners: t3 }));
  }
  var xr = null, Sr = null;
  function Cr(e2) {
    Cd(e2, 0);
  }
  function wr(e2) {
    if (Xt(Nt(e2))) return e2;
  }
  function Tr(e2, t3) {
    if (e2 === `change`) return t3;
  }
  var Er = false;
  if (wn) {
    var Dr;
    if (wn) {
      var Or = `oninput` in document;
      if (!Or) {
        var kr = document.createElement(`div`);
        kr.setAttribute(`oninput`, `return;`), Or = typeof kr.oninput == `function`;
      }
      Dr = Or;
    } else Dr = false;
    Er = Dr && (!document.documentMode || 9 < document.documentMode);
  }
  function Ar() {
    xr && (xr.detachEvent(`onpropertychange`, jr), Sr = xr = null);
  }
  function jr(e2) {
    if (e2.propertyName === `value` && wr(Sr)) {
      var t3 = [];
      br(t3, Sr, e2, _n(e2)), Sn(Cr, t3);
    }
  }
  function Mr(e2, t3, n3) {
    e2 === `focusin` ? (Ar(), xr = t3, Sr = n3, xr.attachEvent(`onpropertychange`, jr)) : e2 === `focusout` && Ar();
  }
  function Nr(e2) {
    if (e2 === `selectionchange` || e2 === `keyup` || e2 === `keydown`) return wr(Sr);
  }
  function Pr(e2, t3) {
    if (e2 === `click`) return wr(t3);
  }
  function Fr(e2, t3) {
    if (e2 === `input` || e2 === `change`) return wr(t3);
  }
  function Ir(e2, t3) {
    return e2 === t3 && (e2 !== 0 || 1 / e2 == 1 / t3) || e2 !== e2 && t3 !== t3;
  }
  var Lr = typeof Object.is == `function` ? Object.is : Ir;
  function Rr(e2, t3) {
    if (Lr(e2, t3)) return true;
    if (typeof e2 != `object` || !e2 || typeof t3 != `object` || !t3) return false;
    var n3 = Object.keys(e2), r2 = Object.keys(t3);
    if (n3.length !== r2.length) return false;
    for (r2 = 0; r2 < n3.length; r2++) {
      var i2 = n3[r2];
      if (!Ie.call(t3, i2) || !Lr(e2[i2], t3[i2])) return false;
    }
    return true;
  }
  function zr(e2) {
    for (; e2 && e2.firstChild; ) e2 = e2.firstChild;
    return e2;
  }
  function Br(e2, t3) {
    var n3 = zr(e2);
    e2 = 0;
    for (var r2; n3; ) {
      if (n3.nodeType === 3) {
        if (r2 = e2 + n3.textContent.length, e2 <= t3 && r2 >= t3) return { node: n3, offset: t3 - e2 };
        e2 = r2;
      }
      a: {
        for (; n3; ) {
          if (n3.nextSibling) {
            n3 = n3.nextSibling;
            break a;
          }
          n3 = n3.parentNode;
        }
        n3 = void 0;
      }
      n3 = zr(n3);
    }
  }
  function Vr(e2, t3) {
    return e2 && t3 ? e2 === t3 ? true : e2 && e2.nodeType === 3 ? false : t3 && t3.nodeType === 3 ? Vr(e2, t3.parentNode) : `contains` in e2 ? e2.contains(t3) : e2.compareDocumentPosition ? !!(e2.compareDocumentPosition(t3) & 16) : false : false;
  }
  function Hr(e2) {
    e2 = e2 != null && e2.ownerDocument != null && e2.ownerDocument.defaultView != null ? e2.ownerDocument.defaultView : window;
    for (var t3 = Zt(e2.document); t3 instanceof e2.HTMLIFrameElement; ) {
      try {
        var n3 = typeof t3.contentWindow.location.href == `string`;
      } catch {
        n3 = false;
      }
      if (n3) e2 = t3.contentWindow;
      else break;
      t3 = Zt(e2.document);
    }
    return t3;
  }
  function Ur(e2) {
    var t3 = e2 && e2.nodeName && e2.nodeName.toLowerCase();
    return t3 && (t3 === `input` && (e2.type === `text` || e2.type === `search` || e2.type === `tel` || e2.type === `url` || e2.type === `password`) || t3 === `textarea` || e2.contentEditable === `true`);
  }
  var Wr = wn && `documentMode` in document && 11 >= document.documentMode, Gr = null, Kr = null, qr = null, Jr = false;
  function Yr(e2, t3, n3) {
    var r2 = n3.window === n3 ? n3.document : n3.nodeType === 9 ? n3 : n3.ownerDocument;
    Jr || Gr == null || Gr !== Zt(r2) || (r2 = Gr, `selectionStart` in r2 && Ur(r2) ? r2 = { start: r2.selectionStart, end: r2.selectionEnd } : (r2 = (r2.ownerDocument && r2.ownerDocument.defaultView || window).getSelection(), r2 = { anchorNode: r2.anchorNode, anchorOffset: r2.anchorOffset, focusNode: r2.focusNode, focusOffset: r2.focusOffset }), qr && Rr(qr, r2) || (qr = r2, r2 = Ad(Kr, `onSelect`), 0 < r2.length && (t3 = new In(`onSelect`, `select`, null, t3, n3), e2.push({ event: t3, listeners: r2 }), t3.target = Gr)));
  }
  function Xr(e2, t3) {
    var n3 = {};
    return n3[e2.toLowerCase()] = t3.toLowerCase(), n3[`Webkit` + e2] = `webkit` + t3, n3[`Moz` + e2] = `moz` + t3, n3;
  }
  var Zr = { animationend: Xr(`Animation`, `AnimationEnd`), animationiteration: Xr(`Animation`, `AnimationIteration`), animationstart: Xr(`Animation`, `AnimationStart`), transitionrun: Xr(`Transition`, `TransitionRun`), transitionstart: Xr(`Transition`, `TransitionStart`), transitioncancel: Xr(`Transition`, `TransitionCancel`), transitionend: Xr(`Transition`, `TransitionEnd`) }, Qr = {}, $r = {};
  wn && ($r = document.createElement(`div`).style, `AnimationEvent` in window || (delete Zr.animationend.animation, delete Zr.animationiteration.animation, delete Zr.animationstart.animation), `TransitionEvent` in window || delete Zr.transitionend.transition);
  function ei(e2) {
    if (Qr[e2]) return Qr[e2];
    if (!Zr[e2]) return e2;
    var t3 = Zr[e2], n3;
    for (n3 in t3) if (t3.hasOwnProperty(n3) && n3 in $r) return Qr[e2] = t3[n3];
    return e2;
  }
  var ti = ei(`animationend`), ni = ei(`animationiteration`), ri = ei(`animationstart`), ii = ei(`transitionrun`), ai = ei(`transitionstart`), oi = ei(`transitioncancel`), si = ei(`transitionend`), ci = /* @__PURE__ */ new Map(), li = `abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);
  li.push(`scrollEnd`);
  function ui(e2, t3) {
    ci.set(e2, t3), Lt(t3, [e2]);
  }
  var di = typeof reportError == `function` ? reportError : function(e2) {
    if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
      var t3 = new window.ErrorEvent(`error`, { bubbles: true, cancelable: true, message: typeof e2 == `object` && e2 && typeof e2.message == `string` ? String(e2.message) : String(e2), error: e2 });
      if (!window.dispatchEvent(t3)) return;
    } else if (typeof process == `object` && typeof process.emit == `function`) {
      process.emit(`uncaughtException`, e2);
      return;
    }
    console.error(e2);
  }, fi = [], pi = 0, mi = 0;
  function hi() {
    for (var e2 = pi, t3 = mi = pi = 0; t3 < e2; ) {
      var n3 = fi[t3];
      fi[t3++] = null;
      var r2 = fi[t3];
      fi[t3++] = null;
      var i2 = fi[t3];
      fi[t3++] = null;
      var a2 = fi[t3];
      if (fi[t3++] = null, r2 !== null && i2 !== null) {
        var o2 = r2.pending;
        o2 === null ? i2.next = i2 : (i2.next = o2.next, o2.next = i2), r2.pending = i2;
      }
      a2 !== 0 && yi(n3, i2, a2);
    }
  }
  function gi(e2, t3, n3, r2) {
    fi[pi++] = e2, fi[pi++] = t3, fi[pi++] = n3, fi[pi++] = r2, mi |= r2, e2.lanes |= r2, e2 = e2.alternate, e2 !== null && (e2.lanes |= r2);
  }
  function _i(e2, t3, n3, r2) {
    return gi(e2, t3, n3, r2), bi(e2);
  }
  function vi(e2, t3) {
    return gi(e2, null, null, t3), bi(e2);
  }
  function yi(e2, t3, n3) {
    e2.lanes |= n3;
    var r2 = e2.alternate;
    r2 !== null && (r2.lanes |= n3);
    for (var i2 = false, a2 = e2.return; a2 !== null; ) a2.childLanes |= n3, r2 = a2.alternate, r2 !== null && (r2.childLanes |= n3), a2.tag === 22 && (e2 = a2.stateNode, e2 === null || e2._visibility & 1 || (i2 = true)), e2 = a2, a2 = a2.return;
    return e2.tag === 3 ? (a2 = e2.stateNode, i2 && t3 !== null && (i2 = 31 - $e(n3), e2 = a2.hiddenUpdates, r2 = e2[i2], r2 === null ? e2[i2] = [t3] : r2.push(t3), t3.lane = n3 | 536870912), a2) : null;
  }
  function bi(e2) {
    if (50 < hu) throw hu = 0, gu = null, Error(u2(185));
    for (var t3 = e2.return; t3 !== null; ) e2 = t3, t3 = e2.return;
    return e2.tag === 3 ? e2.stateNode : null;
  }
  var xi = {};
  function Si(e2, t3, n3, r2) {
    this.tag = e2, this.key = n3, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t3, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r2, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function Ci(e2, t3, n3, r2) {
    return new Si(e2, t3, n3, r2);
  }
  function wi(e2) {
    return e2 = e2.prototype, !(!e2 || !e2.isReactComponent);
  }
  function Ti(e2, t3) {
    var n3 = e2.alternate;
    return n3 === null ? (n3 = Ci(e2.tag, t3, e2.key, e2.mode), n3.elementType = e2.elementType, n3.type = e2.type, n3.stateNode = e2.stateNode, n3.alternate = e2, e2.alternate = n3) : (n3.pendingProps = t3, n3.type = e2.type, n3.flags = 0, n3.subtreeFlags = 0, n3.deletions = null), n3.flags = e2.flags & 65011712, n3.childLanes = e2.childLanes, n3.lanes = e2.lanes, n3.child = e2.child, n3.memoizedProps = e2.memoizedProps, n3.memoizedState = e2.memoizedState, n3.updateQueue = e2.updateQueue, t3 = e2.dependencies, n3.dependencies = t3 === null ? null : { lanes: t3.lanes, firstContext: t3.firstContext }, n3.sibling = e2.sibling, n3.index = e2.index, n3.ref = e2.ref, n3.refCleanup = e2.refCleanup, n3;
  }
  function Ei(e2, t3) {
    e2.flags &= 65011714;
    var n3 = e2.alternate;
    return n3 === null ? (e2.childLanes = 0, e2.lanes = t3, e2.child = null, e2.subtreeFlags = 0, e2.memoizedProps = null, e2.memoizedState = null, e2.updateQueue = null, e2.dependencies = null, e2.stateNode = null) : (e2.childLanes = n3.childLanes, e2.lanes = n3.lanes, e2.child = n3.child, e2.subtreeFlags = 0, e2.deletions = null, e2.memoizedProps = n3.memoizedProps, e2.memoizedState = n3.memoizedState, e2.updateQueue = n3.updateQueue, e2.type = n3.type, t3 = n3.dependencies, e2.dependencies = t3 === null ? null : { lanes: t3.lanes, firstContext: t3.firstContext }), e2;
  }
  function Di(e2, t3, n3, r2, i2, a2) {
    var o2 = 0;
    if (r2 = e2, typeof e2 == `function`) wi(e2) && (o2 = 1);
    else if (typeof e2 == `string`) o2 = Kf(e2, n3, xe.current) ? 26 : e2 === `html` || e2 === `head` || e2 === `body` ? 27 : 5;
    else a: switch (e2) {
      case ue:
        return e2 = Ci(31, n3, t3, i2), e2.elementType = ue, e2.lanes = a2, e2;
      case ee:
        return Oi(n3.children, i2, a2, t3);
      case te:
        o2 = 8, i2 |= 24;
        break;
      case ne:
        return e2 = Ci(12, n3, t3, i2 | 2), e2.elementType = ne, e2.lanes = a2, e2;
      case oe:
        return e2 = Ci(13, n3, t3, i2), e2.elementType = oe, e2.lanes = a2, e2;
      case se:
        return e2 = Ci(19, n3, t3, i2), e2.elementType = se, e2.lanes = a2, e2;
      default:
        if (typeof e2 == `object` && e2) switch (e2.$$typeof) {
          case ie:
            o2 = 10;
            break a;
          case re:
            o2 = 9;
            break a;
          case ae:
            o2 = 11;
            break a;
          case ce:
            o2 = 14;
            break a;
          case le:
            o2 = 16, r2 = null;
            break a;
        }
        o2 = 29, n3 = Error(u2(130, e2 === null ? `null` : typeof e2, ``)), r2 = null;
    }
    return t3 = Ci(o2, n3, t3, i2), t3.elementType = e2, t3.type = r2, t3.lanes = a2, t3;
  }
  function Oi(e2, t3, n3, r2) {
    return e2 = Ci(7, e2, r2, t3), e2.lanes = n3, e2;
  }
  function ki(e2, t3, n3) {
    return e2 = Ci(6, e2, null, t3), e2.lanes = n3, e2;
  }
  function Ai(e2) {
    var t3 = Ci(18, null, null, 0);
    return t3.stateNode = e2, t3;
  }
  function ji(e2, t3, n3) {
    return t3 = Ci(4, e2.children === null ? [] : e2.children, e2.key, t3), t3.lanes = n3, t3.stateNode = { containerInfo: e2.containerInfo, pendingChildren: null, implementation: e2.implementation }, t3;
  }
  var Mi = /* @__PURE__ */ new WeakMap();
  function Ni(e2, t3) {
    if (typeof e2 == `object` && e2) {
      var n3 = Mi.get(e2);
      return n3 === void 0 ? (t3 = { value: e2, source: t3, stack: Fe(t3) }, Mi.set(e2, t3), t3) : n3;
    }
    return { value: e2, source: t3, stack: Fe(t3) };
  }
  var Pi = [], Fi = 0, Ii = null, Li = 0, Ri = [], zi = 0, Bi = null, Vi = 1, Hi = ``;
  function Ui(e2, t3) {
    Pi[Fi++] = Li, Pi[Fi++] = Ii, Ii = e2, Li = t3;
  }
  function Wi(e2, t3, n3) {
    Ri[zi++] = Vi, Ri[zi++] = Hi, Ri[zi++] = Bi, Bi = e2;
    var r2 = Vi;
    e2 = Hi;
    var i2 = 32 - $e(r2) - 1;
    r2 &= ~(1 << i2), n3 += 1;
    var a2 = 32 - $e(t3) + i2;
    if (30 < a2) {
      var o2 = i2 - i2 % 5;
      a2 = (r2 & (1 << o2) - 1).toString(32), r2 >>= o2, i2 -= o2, Vi = 1 << 32 - $e(t3) + i2 | n3 << i2 | r2, Hi = a2 + e2;
    } else Vi = 1 << a2 | n3 << i2 | r2, Hi = e2;
  }
  function Gi(e2) {
    e2.return !== null && (Ui(e2, 1), Wi(e2, 1, 0));
  }
  function Ki(e2) {
    for (; e2 === Ii; ) Ii = Pi[--Fi], Pi[Fi] = null, Li = Pi[--Fi], Pi[Fi] = null;
    for (; e2 === Bi; ) Bi = Ri[--zi], Ri[zi] = null, Hi = Ri[--zi], Ri[zi] = null, Vi = Ri[--zi], Ri[zi] = null;
  }
  function qi(e2, t3) {
    Ri[zi++] = Vi, Ri[zi++] = Hi, Ri[zi++] = Bi, Vi = t3.id, Hi = t3.overflow, Bi = e2;
  }
  var D = null, O = null, k = false, Ji = null, Yi = false, Xi = Error(u2(519));
  function Zi(e2) {
    throw ra(Ni(Error(u2(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? `text` : `HTML`, ``)), e2)), Xi;
  }
  function Qi(e2) {
    var t3 = e2.stateNode, n3 = e2.type, r2 = e2.memoizedProps;
    switch (t3[St] = e2, t3[Ct] = r2, n3) {
      case `dialog`:
        Z(`cancel`, t3), Z(`close`, t3);
        break;
      case `iframe`:
      case `object`:
      case `embed`:
        Z(`load`, t3);
        break;
      case `video`:
      case `audio`:
        for (n3 = 0; n3 < xd.length; n3++) Z(xd[n3], t3);
        break;
      case `source`:
        Z(`error`, t3);
        break;
      case `img`:
      case `image`:
      case `link`:
        Z(`error`, t3), Z(`load`, t3);
        break;
      case `details`:
        Z(`toggle`, t3);
        break;
      case `input`:
        Z(`invalid`, t3), tn(t3, r2.value, r2.defaultValue, r2.checked, r2.defaultChecked, r2.type, r2.name, true);
        break;
      case `select`:
        Z(`invalid`, t3);
        break;
      case `textarea`:
        Z(`invalid`, t3), on(t3, r2.value, r2.defaultValue, r2.children);
    }
    n3 = r2.children, typeof n3 != `string` && typeof n3 != `number` && typeof n3 != `bigint` || t3.textContent === `` + n3 || true === r2.suppressHydrationWarning || Id(t3.textContent, n3) ? (r2.popover != null && (Z(`beforetoggle`, t3), Z(`toggle`, t3)), r2.onScroll != null && Z(`scroll`, t3), r2.onScrollEnd != null && Z(`scrollend`, t3), r2.onClick != null && (t3.onclick = hn), t3 = true) : t3 = false, t3 || Zi(e2, true);
  }
  function $i(e2) {
    for (D = e2.return; D; ) switch (D.tag) {
      case 5:
      case 31:
      case 13:
        Yi = false;
        return;
      case 27:
      case 3:
        Yi = true;
        return;
      default:
        D = D.return;
    }
  }
  function ea(e2) {
    if (e2 !== D) return false;
    if (!k) return $i(e2), k = true, false;
    var t3 = e2.tag, n3;
    if ((n3 = t3 !== 3 && t3 !== 27) && ((n3 = t3 === 5) && (n3 = e2.type, n3 = n3 === `form` || n3 === `button` || Kd(e2.type, e2.memoizedProps)), n3 = !n3), n3 && O && Zi(e2), $i(e2), t3 === 13) {
      if (e2 = e2.memoizedState, e2 = e2 === null ? null : e2.dehydrated, !e2) throw Error(u2(317));
      O = pf(e2);
    } else if (t3 === 31) {
      if (e2 = e2.memoizedState, e2 = e2 === null ? null : e2.dehydrated, !e2) throw Error(u2(317));
      O = pf(e2);
    } else t3 === 27 ? (t3 = O, ef(e2.type) ? (e2 = ff, ff = null, O = e2) : O = t3) : O = D ? df(e2.stateNode.nextSibling) : null;
    return true;
  }
  function ta() {
    O = D = null, k = false;
  }
  function na() {
    var e2 = Ji;
    return e2 !== null && (nu === null ? nu = e2 : nu.push.apply(nu, e2), Ji = null), e2;
  }
  function ra(e2) {
    Ji === null ? Ji = [e2] : Ji.push(e2);
  }
  var ia = be(null), aa = null, oa = null;
  function sa(e2, t3, n3) {
    T(ia, t3._currentValue), t3._currentValue = n3;
  }
  function ca(e2) {
    e2._currentValue = ia.current, w(ia);
  }
  function la(e2, t3, n3) {
    for (; e2 !== null; ) {
      var r2 = e2.alternate;
      if ((e2.childLanes & t3) === t3 ? r2 !== null && (r2.childLanes & t3) !== t3 && (r2.childLanes |= t3) : (e2.childLanes |= t3, r2 !== null && (r2.childLanes |= t3)), e2 === n3) break;
      e2 = e2.return;
    }
  }
  function ua(e2, t3, n3, r2) {
    var i2 = e2.child;
    for (i2 !== null && (i2.return = e2); i2 !== null; ) {
      var a2 = i2.dependencies;
      if (a2 !== null) {
        var o2 = i2.child;
        a2 = a2.firstContext;
        a: for (; a2 !== null; ) {
          var s3 = a2;
          a2 = i2;
          for (var c2 = 0; c2 < t3.length; c2++) if (s3.context === t3[c2]) {
            a2.lanes |= n3, s3 = a2.alternate, s3 !== null && (s3.lanes |= n3), la(a2.return, n3, e2), r2 || (o2 = null);
            break a;
          }
          a2 = s3.next;
        }
      } else if (i2.tag === 18) {
        if (o2 = i2.return, o2 === null) throw Error(u2(341));
        o2.lanes |= n3, a2 = o2.alternate, a2 !== null && (a2.lanes |= n3), la(o2, n3, e2), o2 = null;
      } else o2 = i2.child;
      if (o2 !== null) o2.return = i2;
      else for (o2 = i2; o2 !== null; ) {
        if (o2 === e2) {
          o2 = null;
          break;
        }
        if (i2 = o2.sibling, i2 !== null) {
          i2.return = o2.return, o2 = i2;
          break;
        }
        o2 = o2.return;
      }
      i2 = o2;
    }
  }
  function da(e2, t3, n3, r2) {
    e2 = null;
    for (var i2 = t3, a2 = false; i2 !== null; ) {
      if (!a2) {
        if (i2.flags & 524288) a2 = true;
        else if (i2.flags & 262144) break;
      }
      if (i2.tag === 10) {
        var o2 = i2.alternate;
        if (o2 === null) throw Error(u2(387));
        if (o2 = o2.memoizedProps, o2 !== null) {
          var s3 = i2.type;
          Lr(i2.pendingProps.value, o2.value) || (e2 === null ? e2 = [s3] : e2.push(s3));
        }
      } else if (i2 === we.current) {
        if (o2 = i2.alternate, o2 === null) throw Error(u2(387));
        o2.memoizedState.memoizedState !== i2.memoizedState.memoizedState && (e2 === null ? e2 = [tp] : e2.push(tp));
      }
      i2 = i2.return;
    }
    e2 !== null && ua(t3, e2, n3, r2), t3.flags |= 262144;
  }
  function fa(e2) {
    for (e2 = e2.firstContext; e2 !== null; ) {
      if (!Lr(e2.context._currentValue, e2.memoizedValue)) return true;
      e2 = e2.next;
    }
    return false;
  }
  function pa(e2) {
    aa = e2, oa = null, e2 = e2.dependencies, e2 !== null && (e2.firstContext = null);
  }
  function A(e2) {
    return ha(aa, e2);
  }
  function ma(e2, t3) {
    return aa === null && pa(e2), ha(e2, t3);
  }
  function ha(e2, t3) {
    var n3 = t3._currentValue;
    if (t3 = { context: t3, memoizedValue: n3, next: null }, oa === null) {
      if (e2 === null) throw Error(u2(308));
      oa = t3, e2.dependencies = { lanes: 0, firstContext: t3 }, e2.flags |= 524288;
    } else oa = oa.next = t3;
    return n3;
  }
  var ga = typeof AbortController < `u` ? AbortController : function() {
    var e2 = [], t3 = this.signal = { aborted: false, addEventListener: function(t4, n3) {
      e2.push(n3);
    } };
    this.abort = function() {
      t3.aborted = true, e2.forEach(function(e3) {
        return e3();
      });
    };
  }, _a = n2.unstable_scheduleCallback, va = n2.unstable_NormalPriority, j = { $$typeof: ie, Consumer: null, Provider: null, _currentValue: null, _currentValue2: null, _threadCount: 0 };
  function ya() {
    return { controller: new ga(), data: /* @__PURE__ */ new Map(), refCount: 0 };
  }
  function ba(e2) {
    e2.refCount--, e2.refCount === 0 && _a(va, function() {
      e2.controller.abort();
    });
  }
  var xa = null, Sa = 0, Ca = 0, wa = null;
  function Ta(e2, t3) {
    if (xa === null) {
      var n3 = xa = [];
      Sa = 0, Ca = hd(), wa = { status: `pending`, value: void 0, then: function(e3) {
        n3.push(e3);
      } };
    }
    return Sa++, t3.then(Ea, Ea), t3;
  }
  function Ea() {
    if (--Sa === 0 && xa !== null) {
      wa !== null && (wa.status = `fulfilled`);
      var e2 = xa;
      xa = null, Ca = 0, wa = null;
      for (var t3 = 0; t3 < e2.length; t3++) (0, e2[t3])();
    }
  }
  function Da(e2, t3) {
    var n3 = [], r2 = { status: `pending`, value: null, reason: null, then: function(e3) {
      n3.push(e3);
    } };
    return e2.then(function() {
      r2.status = `fulfilled`, r2.value = t3;
      for (var e3 = 0; e3 < n3.length; e3++) (0, n3[e3])(t3);
    }, function(e3) {
      for (r2.status = `rejected`, r2.reason = e3, e3 = 0; e3 < n3.length; e3++) (0, n3[e3])(void 0);
    }), r2;
  }
  var Oa = S.S;
  S.S = function(e2, t3) {
    au = Ve(), typeof t3 == `object` && t3 && typeof t3.then == `function` && Ta(e2, t3), Oa !== null && Oa(e2, t3);
  };
  var ka = be(null);
  function Aa() {
    var e2 = ka.current;
    return e2 === null ? W.pooledCache : e2;
  }
  function ja(e2, t3) {
    t3 === null ? T(ka, ka.current) : T(ka, t3.pool);
  }
  function Ma() {
    var e2 = Aa();
    return e2 === null ? null : { parent: j._currentValue, pool: e2 };
  }
  var Na = Error(u2(460)), Pa = Error(u2(474)), Fa = Error(u2(542)), Ia = { then: function() {
  } };
  function La(e2) {
    return e2 = e2.status, e2 === `fulfilled` || e2 === `rejected`;
  }
  function Ra(e2, t3, n3) {
    switch (n3 = e2[n3], n3 === void 0 ? e2.push(t3) : n3 !== t3 && (t3.then(hn, hn), t3 = n3), t3.status) {
      case `fulfilled`:
        return t3.value;
      case `rejected`:
        throw e2 = t3.reason, Ha(e2), e2;
      default:
        if (typeof t3.status == `string`) t3.then(hn, hn);
        else {
          if (e2 = W, e2 !== null && 100 < e2.shellSuspendCounter) throw Error(u2(482));
          e2 = t3, e2.status = `pending`, e2.then(function(e3) {
            if (t3.status === `pending`) {
              var n4 = t3;
              n4.status = `fulfilled`, n4.value = e3;
            }
          }, function(e3) {
            if (t3.status === `pending`) {
              var n4 = t3;
              n4.status = `rejected`, n4.reason = e3;
            }
          });
        }
        switch (t3.status) {
          case `fulfilled`:
            return t3.value;
          case `rejected`:
            throw e2 = t3.reason, Ha(e2), e2;
        }
        throw Ba = t3, Na;
    }
  }
  function za(e2) {
    try {
      var t3 = e2._init;
      return t3(e2._payload);
    } catch (e3) {
      throw typeof e3 == `object` && e3 && typeof e3.then == `function` ? (Ba = e3, Na) : e3;
    }
  }
  var Ba = null;
  function Va() {
    if (Ba === null) throw Error(u2(459));
    var e2 = Ba;
    return Ba = null, e2;
  }
  function Ha(e2) {
    if (e2 === Na || e2 === Fa) throw Error(u2(483));
  }
  var Ua = null, Wa = 0;
  function Ga(e2) {
    var t3 = Wa;
    return Wa += 1, Ua === null && (Ua = []), Ra(Ua, e2, t3);
  }
  function Ka(e2, t3) {
    t3 = t3.props.ref, e2.ref = t3 === void 0 ? null : t3;
  }
  function qa(e2, t3) {
    throw t3.$$typeof === y ? Error(u2(525)) : (e2 = Object.prototype.toString.call(t3), Error(u2(31, e2 === `[object Object]` ? `object with keys {` + Object.keys(t3).join(`, `) + `}` : e2)));
  }
  function Ja(e2) {
    function t3(t4, n4) {
      if (e2) {
        var r3 = t4.deletions;
        r3 === null ? (t4.deletions = [n4], t4.flags |= 16) : r3.push(n4);
      }
    }
    function n3(n4, r3) {
      if (!e2) return null;
      for (; r3 !== null; ) t3(n4, r3), r3 = r3.sibling;
      return null;
    }
    function r2(e3) {
      for (var t4 = /* @__PURE__ */ new Map(); e3 !== null; ) e3.key === null ? t4.set(e3.index, e3) : t4.set(e3.key, e3), e3 = e3.sibling;
      return t4;
    }
    function i2(e3, t4) {
      return e3 = Ti(e3, t4), e3.index = 0, e3.sibling = null, e3;
    }
    function a2(t4, n4, r3) {
      return t4.index = r3, e2 ? (r3 = t4.alternate, r3 === null ? (t4.flags |= 67108866, n4) : (r3 = r3.index, r3 < n4 ? (t4.flags |= 67108866, n4) : r3)) : (t4.flags |= 1048576, n4);
    }
    function o2(t4) {
      return e2 && t4.alternate === null && (t4.flags |= 67108866), t4;
    }
    function s3(e3, t4, n4, r3) {
      return t4 === null || t4.tag !== 6 ? (t4 = ki(n4, e3.mode, r3), t4.return = e3, t4) : (t4 = i2(t4, n4), t4.return = e3, t4);
    }
    function c2(e3, t4, n4, r3) {
      var a3 = n4.type;
      return a3 === ee ? d3(e3, t4, n4.props.children, r3, n4.key) : t4 !== null && (t4.elementType === a3 || typeof a3 == `object` && a3 && a3.$$typeof === le && za(a3) === t4.type) ? (t4 = i2(t4, n4.props), Ka(t4, n4), t4.return = e3, t4) : (t4 = Di(n4.type, n4.key, n4.props, null, e3.mode, r3), Ka(t4, n4), t4.return = e3, t4);
    }
    function l3(e3, t4, n4, r3) {
      return t4 === null || t4.tag !== 4 || t4.stateNode.containerInfo !== n4.containerInfo || t4.stateNode.implementation !== n4.implementation ? (t4 = ji(n4, e3.mode, r3), t4.return = e3, t4) : (t4 = i2(t4, n4.children || []), t4.return = e3, t4);
    }
    function d3(e3, t4, n4, r3, a3) {
      return t4 === null || t4.tag !== 7 ? (t4 = Oi(n4, e3.mode, r3, a3), t4.return = e3, t4) : (t4 = i2(t4, n4), t4.return = e3, t4);
    }
    function f3(e3, t4, n4) {
      if (typeof t4 == `string` && t4 !== `` || typeof t4 == `number` || typeof t4 == `bigint`) return t4 = ki(`` + t4, e3.mode, n4), t4.return = e3, t4;
      if (typeof t4 == `object` && t4) {
        switch (t4.$$typeof) {
          case b:
            return n4 = Di(t4.type, t4.key, t4.props, null, e3.mode, n4), Ka(n4, t4), n4.return = e3, n4;
          case x:
            return t4 = ji(t4, e3.mode, n4), t4.return = e3, t4;
          case le:
            return t4 = za(t4), f3(e3, t4, n4);
        }
        if (ge(t4) || pe(t4)) return t4 = Oi(t4, e3.mode, n4, null), t4.return = e3, t4;
        if (typeof t4.then == `function`) return f3(e3, Ga(t4), n4);
        if (t4.$$typeof === ie) return f3(e3, ma(e3, t4), n4);
        qa(e3, t4);
      }
      return null;
    }
    function p3(e3, t4, n4, r3) {
      var i3 = t4 === null ? null : t4.key;
      if (typeof n4 == `string` && n4 !== `` || typeof n4 == `number` || typeof n4 == `bigint`) return i3 === null ? s3(e3, t4, `` + n4, r3) : null;
      if (typeof n4 == `object` && n4) {
        switch (n4.$$typeof) {
          case b:
            return n4.key === i3 ? c2(e3, t4, n4, r3) : null;
          case x:
            return n4.key === i3 ? l3(e3, t4, n4, r3) : null;
          case le:
            return n4 = za(n4), p3(e3, t4, n4, r3);
        }
        if (ge(n4) || pe(n4)) return i3 === null ? d3(e3, t4, n4, r3, null) : null;
        if (typeof n4.then == `function`) return p3(e3, t4, Ga(n4), r3);
        if (n4.$$typeof === ie) return p3(e3, t4, ma(e3, n4), r3);
        qa(e3, n4);
      }
      return null;
    }
    function m3(e3, t4, n4, r3, i3) {
      if (typeof r3 == `string` && r3 !== `` || typeof r3 == `number` || typeof r3 == `bigint`) return e3 = e3.get(n4) || null, s3(t4, e3, `` + r3, i3);
      if (typeof r3 == `object` && r3) {
        switch (r3.$$typeof) {
          case b:
            return e3 = e3.get(r3.key === null ? n4 : r3.key) || null, c2(t4, e3, r3, i3);
          case x:
            return e3 = e3.get(r3.key === null ? n4 : r3.key) || null, l3(t4, e3, r3, i3);
          case le:
            return r3 = za(r3), m3(e3, t4, n4, r3, i3);
        }
        if (ge(r3) || pe(r3)) return e3 = e3.get(n4) || null, d3(t4, e3, r3, i3, null);
        if (typeof r3.then == `function`) return m3(e3, t4, n4, Ga(r3), i3);
        if (r3.$$typeof === ie) return m3(e3, t4, n4, ma(t4, r3), i3);
        qa(t4, r3);
      }
      return null;
    }
    function h3(i3, o3, s4, c3) {
      for (var l4 = null, u3 = null, d4 = o3, h4 = o3 = 0, g3 = null; d4 !== null && h4 < s4.length; h4++) {
        d4.index > h4 ? (g3 = d4, d4 = null) : g3 = d4.sibling;
        var _3 = p3(i3, d4, s4[h4], c3);
        if (_3 === null) {
          d4 === null && (d4 = g3);
          break;
        }
        e2 && d4 && _3.alternate === null && t3(i3, d4), o3 = a2(_3, o3, h4), u3 === null ? l4 = _3 : u3.sibling = _3, u3 = _3, d4 = g3;
      }
      if (h4 === s4.length) return n3(i3, d4), k && Ui(i3, h4), l4;
      if (d4 === null) {
        for (; h4 < s4.length; h4++) d4 = f3(i3, s4[h4], c3), d4 !== null && (o3 = a2(d4, o3, h4), u3 === null ? l4 = d4 : u3.sibling = d4, u3 = d4);
        return k && Ui(i3, h4), l4;
      }
      for (d4 = r2(d4); h4 < s4.length; h4++) g3 = m3(d4, i3, h4, s4[h4], c3), g3 !== null && (e2 && g3.alternate !== null && d4.delete(g3.key === null ? h4 : g3.key), o3 = a2(g3, o3, h4), u3 === null ? l4 = g3 : u3.sibling = g3, u3 = g3);
      return e2 && d4.forEach(function(e3) {
        return t3(i3, e3);
      }), k && Ui(i3, h4), l4;
    }
    function g2(i3, o3, s4, c3) {
      if (s4 == null) throw Error(u2(151));
      for (var l4 = null, d4 = null, h4 = o3, g3 = o3 = 0, _3 = null, v2 = s4.next(); h4 !== null && !v2.done; g3++, v2 = s4.next()) {
        h4.index > g3 ? (_3 = h4, h4 = null) : _3 = h4.sibling;
        var y2 = p3(i3, h4, v2.value, c3);
        if (y2 === null) {
          h4 === null && (h4 = _3);
          break;
        }
        e2 && h4 && y2.alternate === null && t3(i3, h4), o3 = a2(y2, o3, g3), d4 === null ? l4 = y2 : d4.sibling = y2, d4 = y2, h4 = _3;
      }
      if (v2.done) return n3(i3, h4), k && Ui(i3, g3), l4;
      if (h4 === null) {
        for (; !v2.done; g3++, v2 = s4.next()) v2 = f3(i3, v2.value, c3), v2 !== null && (o3 = a2(v2, o3, g3), d4 === null ? l4 = v2 : d4.sibling = v2, d4 = v2);
        return k && Ui(i3, g3), l4;
      }
      for (h4 = r2(h4); !v2.done; g3++, v2 = s4.next()) v2 = m3(h4, i3, g3, v2.value, c3), v2 !== null && (e2 && v2.alternate !== null && h4.delete(v2.key === null ? g3 : v2.key), o3 = a2(v2, o3, g3), d4 === null ? l4 = v2 : d4.sibling = v2, d4 = v2);
      return e2 && h4.forEach(function(e3) {
        return t3(i3, e3);
      }), k && Ui(i3, g3), l4;
    }
    function _2(e3, r3, a3, s4) {
      if (typeof a3 == `object` && a3 && a3.type === ee && a3.key === null && (a3 = a3.props.children), typeof a3 == `object` && a3) {
        switch (a3.$$typeof) {
          case b:
            a: {
              for (var c3 = a3.key; r3 !== null; ) {
                if (r3.key === c3) {
                  if (c3 = a3.type, c3 === ee) {
                    if (r3.tag === 7) {
                      n3(e3, r3.sibling), s4 = i2(r3, a3.props.children), s4.return = e3, e3 = s4;
                      break a;
                    }
                  } else if (r3.elementType === c3 || typeof c3 == `object` && c3 && c3.$$typeof === le && za(c3) === r3.type) {
                    n3(e3, r3.sibling), s4 = i2(r3, a3.props), Ka(s4, a3), s4.return = e3, e3 = s4;
                    break a;
                  }
                  n3(e3, r3);
                  break;
                }
                t3(e3, r3), r3 = r3.sibling;
              }
              a3.type === ee ? (s4 = Oi(a3.props.children, e3.mode, s4, a3.key), s4.return = e3, e3 = s4) : (s4 = Di(a3.type, a3.key, a3.props, null, e3.mode, s4), Ka(s4, a3), s4.return = e3, e3 = s4);
            }
            return o2(e3);
          case x:
            a: {
              for (c3 = a3.key; r3 !== null; ) {
                if (r3.key === c3) {
                  if (r3.tag === 4 && r3.stateNode.containerInfo === a3.containerInfo && r3.stateNode.implementation === a3.implementation) {
                    n3(e3, r3.sibling), s4 = i2(r3, a3.children || []), s4.return = e3, e3 = s4;
                    break a;
                  }
                  n3(e3, r3);
                  break;
                }
                t3(e3, r3), r3 = r3.sibling;
              }
              s4 = ji(a3, e3.mode, s4), s4.return = e3, e3 = s4;
            }
            return o2(e3);
          case le:
            return a3 = za(a3), _2(e3, r3, a3, s4);
        }
        if (ge(a3)) return h3(e3, r3, a3, s4);
        if (pe(a3)) {
          if (c3 = pe(a3), typeof c3 != `function`) throw Error(u2(150));
          return a3 = c3.call(a3), g2(e3, r3, a3, s4);
        }
        if (typeof a3.then == `function`) return _2(e3, r3, Ga(a3), s4);
        if (a3.$$typeof === ie) return _2(e3, r3, ma(e3, a3), s4);
        qa(e3, a3);
      }
      return typeof a3 == `string` && a3 !== `` || typeof a3 == `number` || typeof a3 == `bigint` ? (a3 = `` + a3, r3 !== null && r3.tag === 6 ? (n3(e3, r3.sibling), s4 = i2(r3, a3), s4.return = e3, e3 = s4) : (n3(e3, r3), s4 = ki(a3, e3.mode, s4), s4.return = e3, e3 = s4), o2(e3)) : n3(e3, r3);
    }
    return function(e3, t4, n4, r3) {
      try {
        Wa = 0;
        var i3 = _2(e3, t4, n4, r3);
        return Ua = null, i3;
      } catch (t5) {
        if (t5 === Na || t5 === Fa) throw t5;
        var a3 = Ci(29, t5, null, e3.mode);
        return a3.lanes = r3, a3.return = e3, a3;
      }
    };
  }
  var Ya = Ja(true), Xa = Ja(false), Za = false;
  function Qa(e2) {
    e2.updateQueue = { baseState: e2.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, lanes: 0, hiddenCallbacks: null }, callbacks: null };
  }
  function $a(e2, t3) {
    e2 = e2.updateQueue, t3.updateQueue === e2 && (t3.updateQueue = { baseState: e2.baseState, firstBaseUpdate: e2.firstBaseUpdate, lastBaseUpdate: e2.lastBaseUpdate, shared: e2.shared, callbacks: null });
  }
  function eo(e2) {
    return { lane: e2, tag: 0, payload: null, callback: null, next: null };
  }
  function to(e2, t3, n3) {
    var r2 = e2.updateQueue;
    if (r2 === null) return null;
    if (r2 = r2.shared, U & 2) {
      var i2 = r2.pending;
      return i2 === null ? t3.next = t3 : (t3.next = i2.next, i2.next = t3), r2.pending = t3, t3 = bi(e2), yi(e2, null, n3), t3;
    }
    return gi(e2, r2, t3, n3), bi(e2);
  }
  function no(e2, t3, n3) {
    if (t3 = t3.updateQueue, t3 !== null && (t3 = t3.shared, n3 & 4194048)) {
      var r2 = t3.lanes;
      r2 &= e2.pendingLanes, n3 |= r2, t3.lanes = n3, ht(e2, n3);
    }
  }
  function ro(e2, t3) {
    var n3 = e2.updateQueue, r2 = e2.alternate;
    if (r2 !== null && (r2 = r2.updateQueue, n3 === r2)) {
      var i2 = null, a2 = null;
      if (n3 = n3.firstBaseUpdate, n3 !== null) {
        do {
          var o2 = { lane: n3.lane, tag: n3.tag, payload: n3.payload, callback: null, next: null };
          a2 === null ? i2 = a2 = o2 : a2 = a2.next = o2, n3 = n3.next;
        } while (n3 !== null);
        a2 === null ? i2 = a2 = t3 : a2 = a2.next = t3;
      } else i2 = a2 = t3;
      n3 = { baseState: r2.baseState, firstBaseUpdate: i2, lastBaseUpdate: a2, shared: r2.shared, callbacks: r2.callbacks }, e2.updateQueue = n3;
      return;
    }
    e2 = n3.lastBaseUpdate, e2 === null ? n3.firstBaseUpdate = t3 : e2.next = t3, n3.lastBaseUpdate = t3;
  }
  var io = false;
  function ao() {
    if (io) {
      var e2 = wa;
      if (e2 !== null) throw e2;
    }
  }
  function oo(e2, t3, n3, r2) {
    io = false;
    var i2 = e2.updateQueue;
    Za = false;
    var a2 = i2.firstBaseUpdate, o2 = i2.lastBaseUpdate, s3 = i2.shared.pending;
    if (s3 !== null) {
      i2.shared.pending = null;
      var c2 = s3, l3 = c2.next;
      c2.next = null, o2 === null ? a2 = l3 : o2.next = l3, o2 = c2;
      var u3 = e2.alternate;
      u3 !== null && (u3 = u3.updateQueue, s3 = u3.lastBaseUpdate, s3 !== o2 && (s3 === null ? u3.firstBaseUpdate = l3 : s3.next = l3, u3.lastBaseUpdate = c2));
    }
    if (a2 !== null) {
      var d3 = i2.baseState;
      o2 = 0, u3 = l3 = c2 = null, s3 = a2;
      do {
        var f3 = s3.lane & -536870913, p3 = f3 !== s3.lane;
        if (p3 ? (K & f3) === f3 : (r2 & f3) === f3) {
          f3 !== 0 && f3 === Ca && (io = true), u3 !== null && (u3 = u3.next = { lane: 0, tag: s3.tag, payload: s3.payload, callback: null, next: null });
          a: {
            var m3 = e2, h3 = s3;
            f3 = t3;
            var g2 = n3;
            switch (h3.tag) {
              case 1:
                if (m3 = h3.payload, typeof m3 == `function`) {
                  d3 = m3.call(g2, d3, f3);
                  break a;
                }
                d3 = m3;
                break a;
              case 3:
                m3.flags = m3.flags & -65537 | 128;
              case 0:
                if (m3 = h3.payload, f3 = typeof m3 == `function` ? m3.call(g2, d3, f3) : m3, f3 == null) break a;
                d3 = v({}, d3, f3);
                break a;
              case 2:
                Za = true;
            }
          }
          f3 = s3.callback, f3 !== null && (e2.flags |= 64, p3 && (e2.flags |= 8192), p3 = i2.callbacks, p3 === null ? i2.callbacks = [f3] : p3.push(f3));
        } else p3 = { lane: f3, tag: s3.tag, payload: s3.payload, callback: s3.callback, next: null }, u3 === null ? (l3 = u3 = p3, c2 = d3) : u3 = u3.next = p3, o2 |= f3;
        if (s3 = s3.next, s3 === null) {
          if (s3 = i2.shared.pending, s3 === null) break;
          p3 = s3, s3 = p3.next, p3.next = null, i2.lastBaseUpdate = p3, i2.shared.pending = null;
        }
      } while (1);
      u3 === null && (c2 = d3), i2.baseState = c2, i2.firstBaseUpdate = l3, i2.lastBaseUpdate = u3, a2 === null && (i2.shared.lanes = 0), Xl |= o2, e2.lanes = o2, e2.memoizedState = d3;
    }
  }
  function so(e2, t3) {
    if (typeof e2 != `function`) throw Error(u2(191, e2));
    e2.call(t3);
  }
  function co(e2, t3) {
    var n3 = e2.callbacks;
    if (n3 !== null) for (e2.callbacks = null, e2 = 0; e2 < n3.length; e2++) so(n3[e2], t3);
  }
  var lo = be(null), uo = be(0);
  function fo(e2, t3) {
    e2 = Yl, T(uo, e2), T(lo, t3), Yl = e2 | t3.baseLanes;
  }
  function po() {
    T(uo, Yl), T(lo, lo.current);
  }
  function mo() {
    Yl = uo.current, w(lo), w(uo);
  }
  var ho = be(null), go = null;
  function _o(e2) {
    var t3 = e2.alternate;
    T(M, M.current & 1), T(ho, e2), go === null && (t3 === null || lo.current !== null || t3.memoizedState !== null) && (go = e2);
  }
  function vo(e2) {
    T(M, M.current), T(ho, e2), go === null && (go = e2);
  }
  function yo(e2) {
    e2.tag === 22 ? (T(M, M.current), T(ho, e2), go === null && (go = e2)) : bo(e2);
  }
  function bo() {
    T(M, M.current), T(ho, ho.current);
  }
  function xo(e2) {
    w(ho), go === e2 && (go = null), w(M);
  }
  var M = be(0);
  function So(e2) {
    for (var t3 = e2; t3 !== null; ) {
      if (t3.tag === 13) {
        var n3 = t3.memoizedState;
        if (n3 !== null && (n3 = n3.dehydrated, n3 === null || cf(n3) || lf(n3))) return t3;
      } else if (t3.tag === 19 && (t3.memoizedProps.revealOrder === `forwards` || t3.memoizedProps.revealOrder === `backwards` || t3.memoizedProps.revealOrder === `unstable_legacy-backwards` || t3.memoizedProps.revealOrder === `together`)) {
        if (t3.flags & 128) return t3;
      } else if (t3.child !== null) {
        t3.child.return = t3, t3 = t3.child;
        continue;
      }
      if (t3 === e2) break;
      for (; t3.sibling === null; ) {
        if (t3.return === null || t3.return === e2) return null;
        t3 = t3.return;
      }
      t3.sibling.return = t3.return, t3 = t3.sibling;
    }
    return null;
  }
  var Co = 0, N = null, P = null, F = null, wo = false, To = false, Eo = false, Do = 0, Oo = 0, ko = null, Ao = 0;
  function I() {
    throw Error(u2(321));
  }
  function jo(e2, t3) {
    if (t3 === null) return false;
    for (var n3 = 0; n3 < t3.length && n3 < e2.length; n3++) if (!Lr(e2[n3], t3[n3])) return false;
    return true;
  }
  function Mo(e2, t3, n3, r2, i2, a2) {
    return Co = a2, N = t3, t3.memoizedState = null, t3.updateQueue = null, t3.lanes = 0, S.H = e2 === null || e2.memoizedState === null ? Js : Ys, Eo = false, a2 = n3(r2, i2), Eo = false, To && (a2 = Po(t3, n3, r2, i2)), No(e2), a2;
  }
  function No(e2) {
    S.H = qs;
    var t3 = P !== null && P.next !== null;
    if (Co = 0, F = P = N = null, wo = false, Oo = 0, ko = null, t3) throw Error(u2(300));
    e2 === null || R || (e2 = e2.dependencies, e2 !== null && fa(e2) && (R = true));
  }
  function Po(e2, t3, n3, r2) {
    N = e2;
    var i2 = 0;
    do {
      if (To && (ko = null), Oo = 0, To = false, 25 <= i2) throw Error(u2(301));
      if (i2 += 1, F = P = null, e2.updateQueue != null) {
        var a2 = e2.updateQueue;
        a2.lastEffect = null, a2.events = null, a2.stores = null, a2.memoCache != null && (a2.memoCache.index = 0);
      }
      S.H = Xs, a2 = t3(n3, r2);
    } while (To);
    return a2;
  }
  function Fo() {
    var e2 = S.H, t3 = e2.useState()[0];
    return t3 = typeof t3.then == `function` ? Vo(t3) : t3, e2 = e2.useState()[0], (P === null ? null : P.memoizedState) !== e2 && (N.flags |= 1024), t3;
  }
  function Io() {
    var e2 = Do !== 0;
    return Do = 0, e2;
  }
  function Lo(e2, t3, n3) {
    t3.updateQueue = e2.updateQueue, t3.flags &= -2053, e2.lanes &= ~n3;
  }
  function Ro(e2) {
    if (wo) {
      for (e2 = e2.memoizedState; e2 !== null; ) {
        var t3 = e2.queue;
        t3 !== null && (t3.pending = null), e2 = e2.next;
      }
      wo = false;
    }
    Co = 0, F = P = N = null, To = false, Oo = Do = 0, ko = null;
  }
  function zo() {
    var e2 = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
    return F === null ? N.memoizedState = F = e2 : F = F.next = e2, F;
  }
  function L() {
    if (P === null) {
      var e2 = N.alternate;
      e2 = e2 === null ? null : e2.memoizedState;
    } else e2 = P.next;
    var t3 = F === null ? N.memoizedState : F.next;
    if (t3 !== null) F = t3, P = e2;
    else {
      if (e2 === null) throw N.alternate === null ? Error(u2(467)) : Error(u2(310));
      P = e2, e2 = { memoizedState: P.memoizedState, baseState: P.baseState, baseQueue: P.baseQueue, queue: P.queue, next: null }, F === null ? N.memoizedState = F = e2 : F = F.next = e2;
    }
    return F;
  }
  function Bo() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function Vo(e2) {
    var t3 = Oo;
    return Oo += 1, ko === null && (ko = []), e2 = Ra(ko, e2, t3), t3 = N, (F === null ? t3.memoizedState : F.next) === null && (t3 = t3.alternate, S.H = t3 === null || t3.memoizedState === null ? Js : Ys), e2;
  }
  function Ho(e2) {
    if (typeof e2 == `object` && e2) {
      if (typeof e2.then == `function`) return Vo(e2);
      if (e2.$$typeof === ie) return A(e2);
    }
    throw Error(u2(438, String(e2)));
  }
  function Uo(e2) {
    var t3 = null, n3 = N.updateQueue;
    if (n3 !== null && (t3 = n3.memoCache), t3 == null) {
      var r2 = N.alternate;
      r2 !== null && (r2 = r2.updateQueue, r2 !== null && (r2 = r2.memoCache, r2 != null && (t3 = { data: r2.data.map(function(e3) {
        return e3.slice();
      }), index: 0 })));
    }
    if (t3 ?? (t3 = { data: [], index: 0 }), n3 === null && (n3 = Bo(), N.updateQueue = n3), n3.memoCache = t3, n3 = t3.data[t3.index], n3 === void 0) for (n3 = t3.data[t3.index] = Array(e2), r2 = 0; r2 < e2; r2++) n3[r2] = de;
    return t3.index++, n3;
  }
  function Wo(e2, t3) {
    return typeof t3 == `function` ? t3(e2) : t3;
  }
  function Go(e2) {
    return Ko(L(), P, e2);
  }
  function Ko(e2, t3, n3) {
    var r2 = e2.queue;
    if (r2 === null) throw Error(u2(311));
    r2.lastRenderedReducer = n3;
    var i2 = e2.baseQueue, a2 = r2.pending;
    if (a2 !== null) {
      if (i2 !== null) {
        var o2 = i2.next;
        i2.next = a2.next, a2.next = o2;
      }
      t3.baseQueue = i2 = a2, r2.pending = null;
    }
    if (a2 = e2.baseState, i2 === null) e2.memoizedState = a2;
    else {
      t3 = i2.next;
      var s3 = o2 = null, c2 = null, l3 = t3, d3 = false;
      do {
        var f3 = l3.lane & -536870913;
        if (f3 === l3.lane ? (Co & f3) === f3 : (K & f3) === f3) {
          var p3 = l3.revertLane;
          if (p3 === 0) c2 !== null && (c2 = c2.next = { lane: 0, revertLane: 0, gesture: null, action: l3.action, hasEagerState: l3.hasEagerState, eagerState: l3.eagerState, next: null }), f3 === Ca && (d3 = true);
          else if ((Co & p3) === p3) {
            l3 = l3.next, p3 === Ca && (d3 = true);
            continue;
          } else f3 = { lane: 0, revertLane: l3.revertLane, gesture: null, action: l3.action, hasEagerState: l3.hasEagerState, eagerState: l3.eagerState, next: null }, c2 === null ? (s3 = c2 = f3, o2 = a2) : c2 = c2.next = f3, N.lanes |= p3, Xl |= p3;
          f3 = l3.action, Eo && n3(a2, f3), a2 = l3.hasEagerState ? l3.eagerState : n3(a2, f3);
        } else p3 = { lane: f3, revertLane: l3.revertLane, gesture: l3.gesture, action: l3.action, hasEagerState: l3.hasEagerState, eagerState: l3.eagerState, next: null }, c2 === null ? (s3 = c2 = p3, o2 = a2) : c2 = c2.next = p3, N.lanes |= f3, Xl |= f3;
        l3 = l3.next;
      } while (l3 !== null && l3 !== t3);
      if (c2 === null ? o2 = a2 : c2.next = s3, !Lr(a2, e2.memoizedState) && (R = true, d3 && (n3 = wa, n3 !== null))) throw n3;
      e2.memoizedState = a2, e2.baseState = o2, e2.baseQueue = c2, r2.lastRenderedState = a2;
    }
    return i2 === null && (r2.lanes = 0), [e2.memoizedState, r2.dispatch];
  }
  function qo(e2) {
    var t3 = L(), n3 = t3.queue;
    if (n3 === null) throw Error(u2(311));
    n3.lastRenderedReducer = e2;
    var r2 = n3.dispatch, i2 = n3.pending, a2 = t3.memoizedState;
    if (i2 !== null) {
      n3.pending = null;
      var o2 = i2 = i2.next;
      do
        a2 = e2(a2, o2.action), o2 = o2.next;
      while (o2 !== i2);
      Lr(a2, t3.memoizedState) || (R = true), t3.memoizedState = a2, t3.baseQueue === null && (t3.baseState = a2), n3.lastRenderedState = a2;
    }
    return [a2, r2];
  }
  function Jo(e2, t3, n3) {
    var r2 = N, i2 = L(), a2 = k;
    if (a2) {
      if (n3 === void 0) throw Error(u2(407));
      n3 = n3();
    } else n3 = t3();
    var o2 = !Lr((P || i2).memoizedState, n3);
    if (o2 && (i2.memoizedState = n3, R = true), i2 = i2.queue, ys(Zo.bind(null, r2, i2, e2), [e2]), i2.getSnapshot !== t3 || o2 || F !== null && F.memoizedState.tag & 1) {
      if (r2.flags |= 2048, ms(9, { destroy: void 0 }, Xo.bind(null, r2, i2, n3, t3), null), W === null) throw Error(u2(349));
      a2 || Co & 127 || Yo(r2, t3, n3);
    }
    return n3;
  }
  function Yo(e2, t3, n3) {
    e2.flags |= 16384, e2 = { getSnapshot: t3, value: n3 }, t3 = N.updateQueue, t3 === null ? (t3 = Bo(), N.updateQueue = t3, t3.stores = [e2]) : (n3 = t3.stores, n3 === null ? t3.stores = [e2] : n3.push(e2));
  }
  function Xo(e2, t3, n3, r2) {
    t3.value = n3, t3.getSnapshot = r2, Qo(t3) && $o(e2);
  }
  function Zo(e2, t3, n3) {
    return n3(function() {
      Qo(t3) && $o(e2);
    });
  }
  function Qo(e2) {
    var t3 = e2.getSnapshot;
    e2 = e2.value;
    try {
      var n3 = t3();
      return !Lr(e2, n3);
    } catch {
      return true;
    }
  }
  function $o(e2) {
    var t3 = vi(e2, 2);
    t3 !== null && yu(t3, e2, 2);
  }
  function es(e2) {
    var t3 = zo();
    if (typeof e2 == `function`) {
      var n3 = e2;
      if (e2 = n3(), Eo) {
        Qe(true);
        try {
          n3();
        } finally {
          Qe(false);
        }
      }
    }
    return t3.memoizedState = t3.baseState = e2, t3.queue = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: Wo, lastRenderedState: e2 }, t3;
  }
  function ts(e2, t3, n3, r2) {
    return e2.baseState = n3, Ko(e2, P, typeof r2 == `function` ? r2 : Wo);
  }
  function ns(e2, t3, n3, r2, i2) {
    if (Ws(e2)) throw Error(u2(485));
    if (e2 = t3.action, e2 !== null) {
      var a2 = { payload: i2, action: e2, next: null, isTransition: true, status: `pending`, value: null, reason: null, listeners: [], then: function(e3) {
        a2.listeners.push(e3);
      } };
      S.T === null ? a2.isTransition = false : n3(true), r2(a2), n3 = t3.pending, n3 === null ? (a2.next = t3.pending = a2, rs(t3, a2)) : (a2.next = n3.next, t3.pending = n3.next = a2);
    }
  }
  function rs(e2, t3) {
    var n3 = t3.action, r2 = t3.payload, i2 = e2.state;
    if (t3.isTransition) {
      var a2 = S.T, o2 = {};
      S.T = o2;
      try {
        var s3 = n3(i2, r2), c2 = S.S;
        c2 !== null && c2(o2, s3), is(e2, t3, s3);
      } catch (n4) {
        os(e2, t3, n4);
      } finally {
        a2 !== null && o2.types !== null && (a2.types = o2.types), S.T = a2;
      }
    } else try {
      a2 = n3(i2, r2), is(e2, t3, a2);
    } catch (n4) {
      os(e2, t3, n4);
    }
  }
  function is(e2, t3, n3) {
    typeof n3 == `object` && n3 && typeof n3.then == `function` ? n3.then(function(n4) {
      as(e2, t3, n4);
    }, function(n4) {
      return os(e2, t3, n4);
    }) : as(e2, t3, n3);
  }
  function as(e2, t3, n3) {
    t3.status = `fulfilled`, t3.value = n3, ss(t3), e2.state = n3, t3 = e2.pending, t3 !== null && (n3 = t3.next, n3 === t3 ? e2.pending = null : (n3 = n3.next, t3.next = n3, rs(e2, n3)));
  }
  function os(e2, t3, n3) {
    var r2 = e2.pending;
    if (e2.pending = null, r2 !== null) {
      r2 = r2.next;
      do
        t3.status = `rejected`, t3.reason = n3, ss(t3), t3 = t3.next;
      while (t3 !== r2);
    }
    e2.action = null;
  }
  function ss(e2) {
    e2 = e2.listeners;
    for (var t3 = 0; t3 < e2.length; t3++) (0, e2[t3])();
  }
  function cs(e2, t3) {
    return t3;
  }
  function ls(e2, t3) {
    if (k) {
      var n3 = W.formState;
      if (n3 !== null) {
        a: {
          var r2 = N;
          if (k) {
            if (O) {
              b: {
                for (var i2 = O, a2 = Yi; i2.nodeType !== 8; ) {
                  if (!a2) {
                    i2 = null;
                    break b;
                  }
                  if (i2 = df(i2.nextSibling), i2 === null) {
                    i2 = null;
                    break b;
                  }
                }
                a2 = i2.data, i2 = a2 === `F!` || a2 === `F` ? i2 : null;
              }
              if (i2) {
                O = df(i2.nextSibling), r2 = i2.data === `F!`;
                break a;
              }
            }
            Zi(r2);
          }
          r2 = false;
        }
        r2 && (t3 = n3[0]);
      }
    }
    return n3 = zo(), n3.memoizedState = n3.baseState = t3, r2 = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: cs, lastRenderedState: t3 }, n3.queue = r2, n3 = Vs.bind(null, N, r2), r2.dispatch = n3, r2 = es(false), a2 = Us.bind(null, N, false, r2.queue), r2 = zo(), i2 = { state: t3, dispatch: null, action: e2, pending: null }, r2.queue = i2, n3 = ns.bind(null, N, i2, a2, n3), i2.dispatch = n3, r2.memoizedState = e2, [t3, n3, false];
  }
  function us(e2) {
    return ds(L(), P, e2);
  }
  function ds(e2, t3, n3) {
    if (t3 = Ko(e2, t3, cs)[0], e2 = Go(Wo)[0], typeof t3 == `object` && t3 && typeof t3.then == `function`) try {
      var r2 = Vo(t3);
    } catch (e3) {
      throw e3 === Na ? Fa : e3;
    }
    else r2 = t3;
    t3 = L();
    var i2 = t3.queue, a2 = i2.dispatch;
    return n3 !== t3.memoizedState && (N.flags |= 2048, ms(9, { destroy: void 0 }, fs.bind(null, i2, n3), null)), [r2, a2, e2];
  }
  function fs(e2, t3) {
    e2.action = t3;
  }
  function ps(e2) {
    var t3 = L(), n3 = P;
    if (n3 !== null) return ds(t3, n3, e2);
    L(), t3 = t3.memoizedState, n3 = L();
    var r2 = n3.queue.dispatch;
    return n3.memoizedState = e2, [t3, r2, false];
  }
  function ms(e2, t3, n3, r2) {
    return e2 = { tag: e2, create: n3, deps: r2, inst: t3, next: null }, t3 = N.updateQueue, t3 === null && (t3 = Bo(), N.updateQueue = t3), n3 = t3.lastEffect, n3 === null ? t3.lastEffect = e2.next = e2 : (r2 = n3.next, n3.next = e2, e2.next = r2, t3.lastEffect = e2), e2;
  }
  function hs() {
    return L().memoizedState;
  }
  function gs(e2, t3, n3, r2) {
    var i2 = zo();
    N.flags |= e2, i2.memoizedState = ms(1 | t3, { destroy: void 0 }, n3, r2 === void 0 ? null : r2);
  }
  function _s(e2, t3, n3, r2) {
    var i2 = L();
    r2 = r2 === void 0 ? null : r2;
    var a2 = i2.memoizedState.inst;
    P !== null && r2 !== null && jo(r2, P.memoizedState.deps) ? i2.memoizedState = ms(t3, a2, n3, r2) : (N.flags |= e2, i2.memoizedState = ms(1 | t3, a2, n3, r2));
  }
  function vs(e2, t3) {
    gs(8390656, 8, e2, t3);
  }
  function ys(e2, t3) {
    _s(2048, 8, e2, t3);
  }
  function bs(e2) {
    N.flags |= 4;
    var t3 = N.updateQueue;
    if (t3 === null) t3 = Bo(), N.updateQueue = t3, t3.events = [e2];
    else {
      var n3 = t3.events;
      n3 === null ? t3.events = [e2] : n3.push(e2);
    }
  }
  function xs(e2) {
    var t3 = L().memoizedState;
    return bs({ ref: t3, nextImpl: e2 }), function() {
      if (U & 2) throw Error(u2(440));
      return t3.impl.apply(void 0, arguments);
    };
  }
  function Ss(e2, t3) {
    return _s(4, 2, e2, t3);
  }
  function Cs(e2, t3) {
    return _s(4, 4, e2, t3);
  }
  function ws(e2, t3) {
    if (typeof t3 == `function`) {
      e2 = e2();
      var n3 = t3(e2);
      return function() {
        typeof n3 == `function` ? n3() : t3(null);
      };
    }
    if (t3 != null) return e2 = e2(), t3.current = e2, function() {
      t3.current = null;
    };
  }
  function Ts(e2, t3, n3) {
    n3 = n3 == null ? null : n3.concat([e2]), _s(4, 4, ws.bind(null, t3, e2), n3);
  }
  function Es() {
  }
  function Ds(e2, t3) {
    var n3 = L();
    t3 = t3 === void 0 ? null : t3;
    var r2 = n3.memoizedState;
    return t3 !== null && jo(t3, r2[1]) ? r2[0] : (n3.memoizedState = [e2, t3], e2);
  }
  function Os(e2, t3) {
    var n3 = L();
    t3 = t3 === void 0 ? null : t3;
    var r2 = n3.memoizedState;
    if (t3 !== null && jo(t3, r2[1])) return r2[0];
    if (r2 = e2(), Eo) {
      Qe(true);
      try {
        e2();
      } finally {
        Qe(false);
      }
    }
    return n3.memoizedState = [r2, t3], r2;
  }
  function ks(e2, t3, n3) {
    return n3 === void 0 || Co & 1073741824 && !(K & 261930) ? e2.memoizedState = t3 : (e2.memoizedState = n3, e2 = vu(), N.lanes |= e2, Xl |= e2, n3);
  }
  function As(e2, t3, n3, r2) {
    return Lr(n3, t3) ? n3 : lo.current === null ? !(Co & 42) || Co & 1073741824 && !(K & 261930) ? (R = true, e2.memoizedState = n3) : (e2 = vu(), N.lanes |= e2, Xl |= e2, t3) : (e2 = ks(e2, n3, r2), Lr(e2, t3) || (R = true), e2);
  }
  function js(e2, t3, n3, r2, i2) {
    var a2 = C.p;
    C.p = a2 !== 0 && 8 > a2 ? a2 : 8;
    var o2 = S.T, s3 = {};
    S.T = s3, Us(e2, false, t3, n3);
    try {
      var c2 = i2(), l3 = S.S;
      l3 !== null && l3(s3, c2), typeof c2 == `object` && c2 && typeof c2.then == `function` ? Hs(e2, t3, Da(c2, r2), _u(e2)) : Hs(e2, t3, r2, _u(e2));
    } catch (n4) {
      Hs(e2, t3, { then: function() {
      }, status: `rejected`, reason: n4 }, _u());
    } finally {
      C.p = a2, o2 !== null && s3.types !== null && (o2.types = s3.types), S.T = o2;
    }
  }
  function Ms() {
  }
  function Ns(e2, t3, n3, r2) {
    if (e2.tag !== 5) throw Error(u2(476));
    var i2 = Ps(e2).queue;
    js(e2, i2, t3, _e, n3 === null ? Ms : function() {
      return Fs(e2), n3(r2);
    });
  }
  function Ps(e2) {
    var t3 = e2.memoizedState;
    if (t3 !== null) return t3;
    t3 = { memoizedState: _e, baseState: _e, baseQueue: null, queue: { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: Wo, lastRenderedState: _e }, next: null };
    var n3 = {};
    return t3.next = { memoizedState: n3, baseState: n3, baseQueue: null, queue: { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: Wo, lastRenderedState: n3 }, next: null }, e2.memoizedState = t3, e2 = e2.alternate, e2 !== null && (e2.memoizedState = t3), t3;
  }
  function Fs(e2) {
    var t3 = Ps(e2);
    t3.next === null && (t3 = e2.alternate.memoizedState), Hs(e2, t3.next.queue, {}, _u());
  }
  function Is() {
    return A(tp);
  }
  function Ls() {
    return L().memoizedState;
  }
  function Rs() {
    return L().memoizedState;
  }
  function zs(e2) {
    for (var t3 = e2.return; t3 !== null; ) {
      switch (t3.tag) {
        case 24:
        case 3:
          var n3 = _u();
          e2 = eo(n3);
          var r2 = to(t3, e2, n3);
          r2 !== null && (yu(r2, t3, n3), no(r2, t3, n3)), t3 = { cache: ya() }, e2.payload = t3;
          return;
      }
      t3 = t3.return;
    }
  }
  function Bs(e2, t3, n3) {
    var r2 = _u();
    n3 = { lane: r2, revertLane: 0, gesture: null, action: n3, hasEagerState: false, eagerState: null, next: null }, Ws(e2) ? Gs(t3, n3) : (n3 = _i(e2, t3, n3, r2), n3 !== null && (yu(n3, e2, r2), Ks(n3, t3, r2)));
  }
  function Vs(e2, t3, n3) {
    Hs(e2, t3, n3, _u());
  }
  function Hs(e2, t3, n3, r2) {
    var i2 = { lane: r2, revertLane: 0, gesture: null, action: n3, hasEagerState: false, eagerState: null, next: null };
    if (Ws(e2)) Gs(t3, i2);
    else {
      var a2 = e2.alternate;
      if (e2.lanes === 0 && (a2 === null || a2.lanes === 0) && (a2 = t3.lastRenderedReducer, a2 !== null)) try {
        var o2 = t3.lastRenderedState, s3 = a2(o2, n3);
        if (i2.hasEagerState = true, i2.eagerState = s3, Lr(s3, o2)) return gi(e2, t3, i2, 0), W === null && hi(), false;
      } catch {
      }
      if (n3 = _i(e2, t3, i2, r2), n3 !== null) return yu(n3, e2, r2), Ks(n3, t3, r2), true;
    }
    return false;
  }
  function Us(e2, t3, n3, r2) {
    if (r2 = { lane: 2, revertLane: hd(), gesture: null, action: r2, hasEagerState: false, eagerState: null, next: null }, Ws(e2)) {
      if (t3) throw Error(u2(479));
    } else t3 = _i(e2, n3, r2, 2), t3 !== null && yu(t3, e2, 2);
  }
  function Ws(e2) {
    var t3 = e2.alternate;
    return e2 === N || t3 !== null && t3 === N;
  }
  function Gs(e2, t3) {
    To = wo = true;
    var n3 = e2.pending;
    n3 === null ? t3.next = t3 : (t3.next = n3.next, n3.next = t3), e2.pending = t3;
  }
  function Ks(e2, t3, n3) {
    if (n3 & 4194048) {
      var r2 = t3.lanes;
      r2 &= e2.pendingLanes, n3 |= r2, t3.lanes = n3, ht(e2, n3);
    }
  }
  var qs = { readContext: A, use: Ho, useCallback: I, useContext: I, useEffect: I, useImperativeHandle: I, useLayoutEffect: I, useInsertionEffect: I, useMemo: I, useReducer: I, useRef: I, useState: I, useDebugValue: I, useDeferredValue: I, useTransition: I, useSyncExternalStore: I, useId: I, useHostTransitionStatus: I, useFormState: I, useActionState: I, useOptimistic: I, useMemoCache: I, useCacheRefresh: I };
  qs.useEffectEvent = I;
  var Js = { readContext: A, use: Ho, useCallback: function(e2, t3) {
    return zo().memoizedState = [e2, t3 === void 0 ? null : t3], e2;
  }, useContext: A, useEffect: vs, useImperativeHandle: function(e2, t3, n3) {
    n3 = n3 == null ? null : n3.concat([e2]), gs(4194308, 4, ws.bind(null, t3, e2), n3);
  }, useLayoutEffect: function(e2, t3) {
    return gs(4194308, 4, e2, t3);
  }, useInsertionEffect: function(e2, t3) {
    gs(4, 2, e2, t3);
  }, useMemo: function(e2, t3) {
    var n3 = zo();
    t3 = t3 === void 0 ? null : t3;
    var r2 = e2();
    if (Eo) {
      Qe(true);
      try {
        e2();
      } finally {
        Qe(false);
      }
    }
    return n3.memoizedState = [r2, t3], r2;
  }, useReducer: function(e2, t3, n3) {
    var r2 = zo();
    if (n3 !== void 0) {
      var i2 = n3(t3);
      if (Eo) {
        Qe(true);
        try {
          n3(t3);
        } finally {
          Qe(false);
        }
      }
    } else i2 = t3;
    return r2.memoizedState = r2.baseState = i2, e2 = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: e2, lastRenderedState: i2 }, r2.queue = e2, e2 = e2.dispatch = Bs.bind(null, N, e2), [r2.memoizedState, e2];
  }, useRef: function(e2) {
    var t3 = zo();
    return e2 = { current: e2 }, t3.memoizedState = e2;
  }, useState: function(e2) {
    e2 = es(e2);
    var t3 = e2.queue, n3 = Vs.bind(null, N, t3);
    return t3.dispatch = n3, [e2.memoizedState, n3];
  }, useDebugValue: Es, useDeferredValue: function(e2, t3) {
    return ks(zo(), e2, t3);
  }, useTransition: function() {
    var e2 = es(false);
    return e2 = js.bind(null, N, e2.queue, true, false), zo().memoizedState = e2, [false, e2];
  }, useSyncExternalStore: function(e2, t3, n3) {
    var r2 = N, i2 = zo();
    if (k) {
      if (n3 === void 0) throw Error(u2(407));
      n3 = n3();
    } else {
      if (n3 = t3(), W === null) throw Error(u2(349));
      K & 127 || Yo(r2, t3, n3);
    }
    i2.memoizedState = n3;
    var a2 = { value: n3, getSnapshot: t3 };
    return i2.queue = a2, vs(Zo.bind(null, r2, a2, e2), [e2]), r2.flags |= 2048, ms(9, { destroy: void 0 }, Xo.bind(null, r2, a2, n3, t3), null), n3;
  }, useId: function() {
    var e2 = zo(), t3 = W.identifierPrefix;
    if (k) {
      var n3 = Hi, r2 = Vi;
      n3 = (r2 & ~(1 << 32 - $e(r2) - 1)).toString(32) + n3, t3 = `_` + t3 + `R_` + n3, n3 = Do++, 0 < n3 && (t3 += `H` + n3.toString(32)), t3 += `_`;
    } else n3 = Ao++, t3 = `_` + t3 + `r_` + n3.toString(32) + `_`;
    return e2.memoizedState = t3;
  }, useHostTransitionStatus: Is, useFormState: ls, useActionState: ls, useOptimistic: function(e2) {
    var t3 = zo();
    t3.memoizedState = t3.baseState = e2;
    var n3 = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: null, lastRenderedState: null };
    return t3.queue = n3, t3 = Us.bind(null, N, true, n3), n3.dispatch = t3, [e2, t3];
  }, useMemoCache: Uo, useCacheRefresh: function() {
    return zo().memoizedState = zs.bind(null, N);
  }, useEffectEvent: function(e2) {
    var t3 = zo(), n3 = { impl: e2 };
    return t3.memoizedState = n3, function() {
      if (U & 2) throw Error(u2(440));
      return n3.impl.apply(void 0, arguments);
    };
  } }, Ys = { readContext: A, use: Ho, useCallback: Ds, useContext: A, useEffect: ys, useImperativeHandle: Ts, useInsertionEffect: Ss, useLayoutEffect: Cs, useMemo: Os, useReducer: Go, useRef: hs, useState: function() {
    return Go(Wo);
  }, useDebugValue: Es, useDeferredValue: function(e2, t3) {
    return As(L(), P.memoizedState, e2, t3);
  }, useTransition: function() {
    var e2 = Go(Wo)[0], t3 = L().memoizedState;
    return [typeof e2 == `boolean` ? e2 : Vo(e2), t3];
  }, useSyncExternalStore: Jo, useId: Ls, useHostTransitionStatus: Is, useFormState: us, useActionState: us, useOptimistic: function(e2, t3) {
    return ts(L(), P, e2, t3);
  }, useMemoCache: Uo, useCacheRefresh: Rs };
  Ys.useEffectEvent = xs;
  var Xs = { readContext: A, use: Ho, useCallback: Ds, useContext: A, useEffect: ys, useImperativeHandle: Ts, useInsertionEffect: Ss, useLayoutEffect: Cs, useMemo: Os, useReducer: qo, useRef: hs, useState: function() {
    return qo(Wo);
  }, useDebugValue: Es, useDeferredValue: function(e2, t3) {
    var n3 = L();
    return P === null ? ks(n3, e2, t3) : As(n3, P.memoizedState, e2, t3);
  }, useTransition: function() {
    var e2 = qo(Wo)[0], t3 = L().memoizedState;
    return [typeof e2 == `boolean` ? e2 : Vo(e2), t3];
  }, useSyncExternalStore: Jo, useId: Ls, useHostTransitionStatus: Is, useFormState: ps, useActionState: ps, useOptimistic: function(e2, t3) {
    var n3 = L();
    return P === null ? (n3.baseState = e2, [e2, n3.queue.dispatch]) : ts(n3, P, e2, t3);
  }, useMemoCache: Uo, useCacheRefresh: Rs };
  Xs.useEffectEvent = xs;
  function Zs(e2, t3, n3, r2) {
    t3 = e2.memoizedState, n3 = n3(r2, t3), n3 = n3 == null ? t3 : v({}, t3, n3), e2.memoizedState = n3, e2.lanes === 0 && (e2.updateQueue.baseState = n3);
  }
  var Qs = { enqueueSetState: function(e2, t3, n3) {
    e2 = e2._reactInternals;
    var r2 = _u(), i2 = eo(r2);
    i2.payload = t3, n3 != null && (i2.callback = n3), t3 = to(e2, i2, r2), t3 !== null && (yu(t3, e2, r2), no(t3, e2, r2));
  }, enqueueReplaceState: function(e2, t3, n3) {
    e2 = e2._reactInternals;
    var r2 = _u(), i2 = eo(r2);
    i2.tag = 1, i2.payload = t3, n3 != null && (i2.callback = n3), t3 = to(e2, i2, r2), t3 !== null && (yu(t3, e2, r2), no(t3, e2, r2));
  }, enqueueForceUpdate: function(e2, t3) {
    e2 = e2._reactInternals;
    var n3 = _u(), r2 = eo(n3);
    r2.tag = 2, t3 != null && (r2.callback = t3), t3 = to(e2, r2, n3), t3 !== null && (yu(t3, e2, n3), no(t3, e2, n3));
  } };
  function $s(e2, t3, n3, r2, i2, a2, o2) {
    return e2 = e2.stateNode, typeof e2.shouldComponentUpdate == `function` ? e2.shouldComponentUpdate(r2, a2, o2) : t3.prototype && t3.prototype.isPureReactComponent ? !Rr(n3, r2) || !Rr(i2, a2) : true;
  }
  function ec(e2, t3, n3, r2) {
    e2 = t3.state, typeof t3.componentWillReceiveProps == `function` && t3.componentWillReceiveProps(n3, r2), typeof t3.UNSAFE_componentWillReceiveProps == `function` && t3.UNSAFE_componentWillReceiveProps(n3, r2), t3.state !== e2 && Qs.enqueueReplaceState(t3, t3.state, null);
  }
  function tc(e2, t3) {
    var n3 = t3;
    if (`ref` in t3) for (var r2 in n3 = {}, t3) r2 !== `ref` && (n3[r2] = t3[r2]);
    if (e2 = e2.defaultProps) for (var i2 in n3 === t3 && (n3 = v({}, n3)), e2) n3[i2] === void 0 && (n3[i2] = e2[i2]);
    return n3;
  }
  function nc(e2) {
    di(e2);
  }
  function rc(e2) {
    console.error(e2);
  }
  function ic(e2) {
    di(e2);
  }
  function ac(e2, t3) {
    try {
      var n3 = e2.onUncaughtError;
      n3(t3.value, { componentStack: t3.stack });
    } catch (e3) {
      setTimeout(function() {
        throw e3;
      });
    }
  }
  function oc(e2, t3, n3) {
    try {
      var r2 = e2.onCaughtError;
      r2(n3.value, { componentStack: n3.stack, errorBoundary: t3.tag === 1 ? t3.stateNode : null });
    } catch (e3) {
      setTimeout(function() {
        throw e3;
      });
    }
  }
  function sc(e2, t3, n3) {
    return n3 = eo(n3), n3.tag = 3, n3.payload = { element: null }, n3.callback = function() {
      ac(e2, t3);
    }, n3;
  }
  function cc(e2) {
    return e2 = eo(e2), e2.tag = 3, e2;
  }
  function lc(e2, t3, n3, r2) {
    var i2 = n3.type.getDerivedStateFromError;
    if (typeof i2 == `function`) {
      var a2 = r2.value;
      e2.payload = function() {
        return i2(a2);
      }, e2.callback = function() {
        oc(t3, n3, r2);
      };
    }
    var o2 = n3.stateNode;
    o2 !== null && typeof o2.componentDidCatch == `function` && (e2.callback = function() {
      oc(t3, n3, r2), typeof i2 != `function` && (cu === null ? cu = /* @__PURE__ */ new Set([this]) : cu.add(this));
      var e3 = r2.stack;
      this.componentDidCatch(r2.value, { componentStack: e3 === null ? `` : e3 });
    });
  }
  function uc(e2, t3, n3, r2, i2) {
    if (n3.flags |= 32768, typeof r2 == `object` && r2 && typeof r2.then == `function`) {
      if (t3 = n3.alternate, t3 !== null && da(t3, n3, i2, true), n3 = ho.current, n3 !== null) {
        switch (n3.tag) {
          case 31:
          case 13:
            return go === null ? ju() : n3.alternate === null && J === 0 && (J = 3), n3.flags &= -257, n3.flags |= 65536, n3.lanes = i2, r2 === Ia ? n3.flags |= 16384 : (t3 = n3.updateQueue, t3 === null ? n3.updateQueue = /* @__PURE__ */ new Set([r2]) : t3.add(r2), Yu(e2, r2, i2)), false;
          case 22:
            return n3.flags |= 65536, r2 === Ia ? n3.flags |= 16384 : (t3 = n3.updateQueue, t3 === null ? (t3 = { transitions: null, markerInstances: null, retryQueue: /* @__PURE__ */ new Set([r2]) }, n3.updateQueue = t3) : (n3 = t3.retryQueue, n3 === null ? t3.retryQueue = /* @__PURE__ */ new Set([r2]) : n3.add(r2)), Yu(e2, r2, i2)), false;
        }
        throw Error(u2(435, n3.tag));
      }
      return Yu(e2, r2, i2), ju(), false;
    }
    if (k) return t3 = ho.current, t3 === null ? (r2 !== Xi && (t3 = Error(u2(423), { cause: r2 }), ra(Ni(t3, n3))), e2 = e2.current.alternate, e2.flags |= 65536, i2 &= -i2, e2.lanes |= i2, r2 = Ni(r2, n3), i2 = sc(e2.stateNode, r2, i2), ro(e2, i2), J !== 4 && (J = 2)) : (!(t3.flags & 65536) && (t3.flags |= 256), t3.flags |= 65536, t3.lanes = i2, r2 !== Xi && (e2 = Error(u2(422), { cause: r2 }), ra(Ni(e2, n3)))), false;
    var a2 = Error(u2(520), { cause: r2 });
    if (a2 = Ni(a2, n3), tu === null ? tu = [a2] : tu.push(a2), J !== 4 && (J = 2), t3 === null) return true;
    r2 = Ni(r2, n3), n3 = t3;
    do {
      switch (n3.tag) {
        case 3:
          return n3.flags |= 65536, e2 = i2 & -i2, n3.lanes |= e2, e2 = sc(n3.stateNode, r2, e2), ro(n3, e2), false;
        case 1:
          if (t3 = n3.type, a2 = n3.stateNode, !(n3.flags & 128) && (typeof t3.getDerivedStateFromError == `function` || a2 !== null && typeof a2.componentDidCatch == `function` && (cu === null || !cu.has(a2)))) return n3.flags |= 65536, i2 &= -i2, n3.lanes |= i2, i2 = cc(i2), lc(i2, e2, n3, r2), ro(n3, i2), false;
      }
      n3 = n3.return;
    } while (n3 !== null);
    return false;
  }
  var dc = Error(u2(461)), R = false;
  function fc(e2, t3, n3, r2) {
    t3.child = e2 === null ? Xa(t3, null, n3, r2) : Ya(t3, e2.child, n3, r2);
  }
  function pc(e2, t3, n3, r2, i2) {
    n3 = n3.render;
    var a2 = t3.ref;
    if (`ref` in r2) {
      var o2 = {};
      for (var s3 in r2) s3 !== `ref` && (o2[s3] = r2[s3]);
    } else o2 = r2;
    return pa(t3), r2 = Mo(e2, t3, n3, o2, a2, i2), s3 = Io(), e2 !== null && !R ? (Lo(e2, t3, i2), Lc(e2, t3, i2)) : (k && s3 && Gi(t3), t3.flags |= 1, fc(e2, t3, r2, i2), t3.child);
  }
  function mc(e2, t3, n3, r2, i2) {
    if (e2 === null) {
      var a2 = n3.type;
      return typeof a2 == `function` && !wi(a2) && a2.defaultProps === void 0 && n3.compare === null ? (t3.tag = 15, t3.type = a2, hc(e2, t3, a2, r2, i2)) : (e2 = Di(n3.type, null, r2, t3, t3.mode, i2), e2.ref = t3.ref, e2.return = t3, t3.child = e2);
    }
    if (a2 = e2.child, !Rc(e2, i2)) {
      var o2 = a2.memoizedProps;
      if (n3 = n3.compare, n3 = n3 === null ? Rr : n3, n3(o2, r2) && e2.ref === t3.ref) return Lc(e2, t3, i2);
    }
    return t3.flags |= 1, e2 = Ti(a2, r2), e2.ref = t3.ref, e2.return = t3, t3.child = e2;
  }
  function hc(e2, t3, n3, r2, i2) {
    if (e2 !== null) {
      var a2 = e2.memoizedProps;
      if (Rr(a2, r2) && e2.ref === t3.ref) {
        if (R = false, t3.pendingProps = r2 = a2, Rc(e2, i2)) e2.flags & 131072 && (R = true);
        else return t3.lanes = e2.lanes, Lc(e2, t3, i2);
      }
    }
    return Cc(e2, t3, n3, r2, i2);
  }
  function gc(e2, t3, n3, r2) {
    var i2 = r2.children, a2 = e2 === null ? null : e2.memoizedState;
    if (e2 === null && t3.stateNode === null && (t3.stateNode = { _visibility: 1, _pendingMarkers: null, _retryCache: null, _transitions: null }), r2.mode === `hidden`) {
      if (t3.flags & 128) {
        if (a2 = a2 === null ? n3 : a2.baseLanes | n3, e2 !== null) {
          for (r2 = t3.child = e2.child, i2 = 0; r2 !== null; ) i2 = i2 | r2.lanes | r2.childLanes, r2 = r2.sibling;
          r2 = i2 & ~a2;
        } else r2 = 0, t3.child = null;
        return vc(e2, t3, a2, n3, r2);
      }
      if (n3 & 536870912) t3.memoizedState = { baseLanes: 0, cachePool: null }, e2 !== null && ja(t3, a2 === null ? null : a2.cachePool), a2 === null ? po() : fo(t3, a2), yo(t3);
      else return r2 = t3.lanes = 536870912, vc(e2, t3, a2 === null ? n3 : a2.baseLanes | n3, n3, r2);
    } else a2 === null ? (e2 !== null && ja(t3, null), po(), bo(t3)) : (ja(t3, a2.cachePool), fo(t3, a2), bo(t3), t3.memoizedState = null);
    return fc(e2, t3, i2, n3), t3.child;
  }
  function _c(e2, t3) {
    return e2 !== null && e2.tag === 22 || t3.stateNode !== null || (t3.stateNode = { _visibility: 1, _pendingMarkers: null, _retryCache: null, _transitions: null }), t3.sibling;
  }
  function vc(e2, t3, n3, r2, i2) {
    var a2 = Aa();
    return a2 = a2 === null ? null : { parent: j._currentValue, pool: a2 }, t3.memoizedState = { baseLanes: n3, cachePool: a2 }, e2 !== null && ja(t3, null), po(), yo(t3), e2 !== null && da(e2, t3, r2, true), t3.childLanes = i2, null;
  }
  function yc(e2, t3) {
    return t3 = Mc({ mode: t3.mode, children: t3.children }, e2.mode), t3.ref = e2.ref, e2.child = t3, t3.return = e2, t3;
  }
  function bc(e2, t3, n3) {
    return Ya(t3, e2.child, null, n3), e2 = yc(t3, t3.pendingProps), e2.flags |= 2, xo(t3), t3.memoizedState = null, e2;
  }
  function xc(e2, t3, n3) {
    var r2 = t3.pendingProps, i2 = !!(t3.flags & 128);
    if (t3.flags &= -129, e2 === null) {
      if (k) {
        if (r2.mode === `hidden`) return e2 = yc(t3, r2), t3.lanes = 536870912, _c(null, e2);
        if (vo(t3), (e2 = O) ? (e2 = sf(e2, Yi), e2 = e2 !== null && e2.data === `&` ? e2 : null, e2 !== null && (t3.memoizedState = { dehydrated: e2, treeContext: Bi === null ? null : { id: Vi, overflow: Hi }, retryLane: 536870912, hydrationErrors: null }, n3 = Ai(e2), n3.return = t3, t3.child = n3, D = t3, O = null)) : e2 = null, e2 === null) throw Zi(t3);
        return t3.lanes = 536870912, null;
      }
      return yc(t3, r2);
    }
    var a2 = e2.memoizedState;
    if (a2 !== null) {
      var o2 = a2.dehydrated;
      if (vo(t3), i2) {
        if (t3.flags & 256) t3.flags &= -257, t3 = bc(e2, t3, n3);
        else if (t3.memoizedState !== null) t3.child = e2.child, t3.flags |= 128, t3 = null;
        else throw Error(u2(558));
      } else if (R || da(e2, t3, n3, false), i2 = (n3 & e2.childLanes) !== 0, R || i2) {
        if (r2 = W, r2 !== null && (o2 = gt(r2, n3), o2 !== 0 && o2 !== a2.retryLane)) throw a2.retryLane = o2, vi(e2, o2), yu(r2, e2, o2), dc;
        ju(), t3 = bc(e2, t3, n3);
      } else e2 = a2.treeContext, O = df(o2.nextSibling), D = t3, k = true, Ji = null, Yi = false, e2 !== null && qi(t3, e2), t3 = yc(t3, r2), t3.flags |= 4096;
      return t3;
    }
    return e2 = Ti(e2.child, { mode: r2.mode, children: r2.children }), e2.ref = t3.ref, t3.child = e2, e2.return = t3, e2;
  }
  function Sc(e2, t3) {
    var n3 = t3.ref;
    if (n3 === null) e2 !== null && e2.ref !== null && (t3.flags |= 4194816);
    else {
      if (typeof n3 != `function` && typeof n3 != `object`) throw Error(u2(284));
      (e2 === null || e2.ref !== n3) && (t3.flags |= 4194816);
    }
  }
  function Cc(e2, t3, n3, r2, i2) {
    return pa(t3), n3 = Mo(e2, t3, n3, r2, void 0, i2), r2 = Io(), e2 !== null && !R ? (Lo(e2, t3, i2), Lc(e2, t3, i2)) : (k && r2 && Gi(t3), t3.flags |= 1, fc(e2, t3, n3, i2), t3.child);
  }
  function wc(e2, t3, n3, r2, i2, a2) {
    return pa(t3), t3.updateQueue = null, n3 = Po(t3, r2, n3, i2), No(e2), r2 = Io(), e2 !== null && !R ? (Lo(e2, t3, a2), Lc(e2, t3, a2)) : (k && r2 && Gi(t3), t3.flags |= 1, fc(e2, t3, n3, a2), t3.child);
  }
  function Tc(e2, t3, n3, r2, i2) {
    if (pa(t3), t3.stateNode === null) {
      var a2 = xi, o2 = n3.contextType;
      typeof o2 == `object` && o2 && (a2 = A(o2)), a2 = new n3(r2, a2), t3.memoizedState = a2.state !== null && a2.state !== void 0 ? a2.state : null, a2.updater = Qs, t3.stateNode = a2, a2._reactInternals = t3, a2 = t3.stateNode, a2.props = r2, a2.state = t3.memoizedState, a2.refs = {}, Qa(t3), o2 = n3.contextType, a2.context = typeof o2 == `object` && o2 ? A(o2) : xi, a2.state = t3.memoizedState, o2 = n3.getDerivedStateFromProps, typeof o2 == `function` && (Zs(t3, n3, o2, r2), a2.state = t3.memoizedState), typeof n3.getDerivedStateFromProps == `function` || typeof a2.getSnapshotBeforeUpdate == `function` || typeof a2.UNSAFE_componentWillMount != `function` && typeof a2.componentWillMount != `function` || (o2 = a2.state, typeof a2.componentWillMount == `function` && a2.componentWillMount(), typeof a2.UNSAFE_componentWillMount == `function` && a2.UNSAFE_componentWillMount(), o2 !== a2.state && Qs.enqueueReplaceState(a2, a2.state, null), oo(t3, r2, a2, i2), ao(), a2.state = t3.memoizedState), typeof a2.componentDidMount == `function` && (t3.flags |= 4194308), r2 = true;
    } else if (e2 === null) {
      a2 = t3.stateNode;
      var s3 = t3.memoizedProps, c2 = tc(n3, s3);
      a2.props = c2;
      var l3 = a2.context, u3 = n3.contextType;
      o2 = xi, typeof u3 == `object` && u3 && (o2 = A(u3));
      var d3 = n3.getDerivedStateFromProps;
      u3 = typeof d3 == `function` || typeof a2.getSnapshotBeforeUpdate == `function`, s3 = t3.pendingProps !== s3, u3 || typeof a2.UNSAFE_componentWillReceiveProps != `function` && typeof a2.componentWillReceiveProps != `function` || (s3 || l3 !== o2) && ec(t3, a2, r2, o2), Za = false;
      var f3 = t3.memoizedState;
      a2.state = f3, oo(t3, r2, a2, i2), ao(), l3 = t3.memoizedState, s3 || f3 !== l3 || Za ? (typeof d3 == `function` && (Zs(t3, n3, d3, r2), l3 = t3.memoizedState), (c2 = Za || $s(t3, n3, c2, r2, f3, l3, o2)) ? (u3 || typeof a2.UNSAFE_componentWillMount != `function` && typeof a2.componentWillMount != `function` || (typeof a2.componentWillMount == `function` && a2.componentWillMount(), typeof a2.UNSAFE_componentWillMount == `function` && a2.UNSAFE_componentWillMount()), typeof a2.componentDidMount == `function` && (t3.flags |= 4194308)) : (typeof a2.componentDidMount == `function` && (t3.flags |= 4194308), t3.memoizedProps = r2, t3.memoizedState = l3), a2.props = r2, a2.state = l3, a2.context = o2, r2 = c2) : (typeof a2.componentDidMount == `function` && (t3.flags |= 4194308), r2 = false);
    } else {
      a2 = t3.stateNode, $a(e2, t3), o2 = t3.memoizedProps, u3 = tc(n3, o2), a2.props = u3, d3 = t3.pendingProps, f3 = a2.context, l3 = n3.contextType, c2 = xi, typeof l3 == `object` && l3 && (c2 = A(l3)), s3 = n3.getDerivedStateFromProps, (l3 = typeof s3 == `function` || typeof a2.getSnapshotBeforeUpdate == `function`) || typeof a2.UNSAFE_componentWillReceiveProps != `function` && typeof a2.componentWillReceiveProps != `function` || (o2 !== d3 || f3 !== c2) && ec(t3, a2, r2, c2), Za = false, f3 = t3.memoizedState, a2.state = f3, oo(t3, r2, a2, i2), ao();
      var p3 = t3.memoizedState;
      o2 !== d3 || f3 !== p3 || Za || e2 !== null && e2.dependencies !== null && fa(e2.dependencies) ? (typeof s3 == `function` && (Zs(t3, n3, s3, r2), p3 = t3.memoizedState), (u3 = Za || $s(t3, n3, u3, r2, f3, p3, c2) || e2 !== null && e2.dependencies !== null && fa(e2.dependencies)) ? (l3 || typeof a2.UNSAFE_componentWillUpdate != `function` && typeof a2.componentWillUpdate != `function` || (typeof a2.componentWillUpdate == `function` && a2.componentWillUpdate(r2, p3, c2), typeof a2.UNSAFE_componentWillUpdate == `function` && a2.UNSAFE_componentWillUpdate(r2, p3, c2)), typeof a2.componentDidUpdate == `function` && (t3.flags |= 4), typeof a2.getSnapshotBeforeUpdate == `function` && (t3.flags |= 1024)) : (typeof a2.componentDidUpdate != `function` || o2 === e2.memoizedProps && f3 === e2.memoizedState || (t3.flags |= 4), typeof a2.getSnapshotBeforeUpdate != `function` || o2 === e2.memoizedProps && f3 === e2.memoizedState || (t3.flags |= 1024), t3.memoizedProps = r2, t3.memoizedState = p3), a2.props = r2, a2.state = p3, a2.context = c2, r2 = u3) : (typeof a2.componentDidUpdate != `function` || o2 === e2.memoizedProps && f3 === e2.memoizedState || (t3.flags |= 4), typeof a2.getSnapshotBeforeUpdate != `function` || o2 === e2.memoizedProps && f3 === e2.memoizedState || (t3.flags |= 1024), r2 = false);
    }
    return a2 = r2, Sc(e2, t3), r2 = !!(t3.flags & 128), a2 || r2 ? (a2 = t3.stateNode, n3 = r2 && typeof n3.getDerivedStateFromError != `function` ? null : a2.render(), t3.flags |= 1, e2 !== null && r2 ? (t3.child = Ya(t3, e2.child, null, i2), t3.child = Ya(t3, null, n3, i2)) : fc(e2, t3, n3, i2), t3.memoizedState = a2.state, e2 = t3.child) : e2 = Lc(e2, t3, i2), e2;
  }
  function Ec(e2, t3, n3, r2) {
    return ta(), t3.flags |= 256, fc(e2, t3, n3, r2), t3.child;
  }
  var Dc = { dehydrated: null, treeContext: null, retryLane: 0, hydrationErrors: null };
  function Oc(e2) {
    return { baseLanes: e2, cachePool: Ma() };
  }
  function kc(e2, t3, n3) {
    return e2 = e2 === null ? 0 : e2.childLanes & ~n3, t3 && (e2 |= $l), e2;
  }
  function Ac(e2, t3, n3) {
    var r2 = t3.pendingProps, i2 = false, a2 = !!(t3.flags & 128), o2;
    if ((o2 = a2) || (o2 = e2 !== null && e2.memoizedState === null ? false : !!(M.current & 2)), o2 && (i2 = true, t3.flags &= -129), o2 = !!(t3.flags & 32), t3.flags &= -33, e2 === null) {
      if (k) {
        if (i2 ? _o(t3) : bo(t3), (e2 = O) ? (e2 = sf(e2, Yi), e2 = e2 !== null && e2.data !== `&` ? e2 : null, e2 !== null && (t3.memoizedState = { dehydrated: e2, treeContext: Bi === null ? null : { id: Vi, overflow: Hi }, retryLane: 536870912, hydrationErrors: null }, n3 = Ai(e2), n3.return = t3, t3.child = n3, D = t3, O = null)) : e2 = null, e2 === null) throw Zi(t3);
        return lf(e2) ? t3.lanes = 32 : t3.lanes = 536870912, null;
      }
      var s3 = r2.children;
      return r2 = r2.fallback, i2 ? (bo(t3), i2 = t3.mode, s3 = Mc({ mode: `hidden`, children: s3 }, i2), r2 = Oi(r2, i2, n3, null), s3.return = t3, r2.return = t3, s3.sibling = r2, t3.child = s3, r2 = t3.child, r2.memoizedState = Oc(n3), r2.childLanes = kc(e2, o2, n3), t3.memoizedState = Dc, _c(null, r2)) : (_o(t3), jc(t3, s3));
    }
    var c2 = e2.memoizedState;
    if (c2 !== null && (s3 = c2.dehydrated, s3 !== null)) {
      if (a2) t3.flags & 256 ? (_o(t3), t3.flags &= -257, t3 = Nc(e2, t3, n3)) : t3.memoizedState === null ? (bo(t3), s3 = r2.fallback, i2 = t3.mode, r2 = Mc({ mode: `visible`, children: r2.children }, i2), s3 = Oi(s3, i2, n3, null), s3.flags |= 2, r2.return = t3, s3.return = t3, r2.sibling = s3, t3.child = r2, Ya(t3, e2.child, null, n3), r2 = t3.child, r2.memoizedState = Oc(n3), r2.childLanes = kc(e2, o2, n3), t3.memoizedState = Dc, t3 = _c(null, r2)) : (bo(t3), t3.child = e2.child, t3.flags |= 128, t3 = null);
      else if (_o(t3), lf(s3)) {
        if (o2 = s3.nextSibling && s3.nextSibling.dataset, o2) var l3 = o2.dgst;
        o2 = l3, r2 = Error(u2(419)), r2.stack = ``, r2.digest = o2, ra({ value: r2, source: null, stack: null }), t3 = Nc(e2, t3, n3);
      } else if (R || da(e2, t3, n3, false), o2 = (n3 & e2.childLanes) !== 0, R || o2) {
        if (o2 = W, o2 !== null && (r2 = gt(o2, n3), r2 !== 0 && r2 !== c2.retryLane)) throw c2.retryLane = r2, vi(e2, r2), yu(o2, e2, r2), dc;
        cf(s3) || ju(), t3 = Nc(e2, t3, n3);
      } else cf(s3) ? (t3.flags |= 192, t3.child = e2.child, t3 = null) : (e2 = c2.treeContext, O = df(s3.nextSibling), D = t3, k = true, Ji = null, Yi = false, e2 !== null && qi(t3, e2), t3 = jc(t3, r2.children), t3.flags |= 4096);
      return t3;
    }
    return i2 ? (bo(t3), s3 = r2.fallback, i2 = t3.mode, c2 = e2.child, l3 = c2.sibling, r2 = Ti(c2, { mode: `hidden`, children: r2.children }), r2.subtreeFlags = c2.subtreeFlags & 65011712, l3 === null ? (s3 = Oi(s3, i2, n3, null), s3.flags |= 2) : s3 = Ti(l3, s3), s3.return = t3, r2.return = t3, r2.sibling = s3, t3.child = r2, _c(null, r2), r2 = t3.child, s3 = e2.child.memoizedState, s3 === null ? s3 = Oc(n3) : (i2 = s3.cachePool, i2 === null ? i2 = Ma() : (c2 = j._currentValue, i2 = i2.parent === c2 ? i2 : { parent: c2, pool: c2 }), s3 = { baseLanes: s3.baseLanes | n3, cachePool: i2 }), r2.memoizedState = s3, r2.childLanes = kc(e2, o2, n3), t3.memoizedState = Dc, _c(e2.child, r2)) : (_o(t3), n3 = e2.child, e2 = n3.sibling, n3 = Ti(n3, { mode: `visible`, children: r2.children }), n3.return = t3, n3.sibling = null, e2 !== null && (o2 = t3.deletions, o2 === null ? (t3.deletions = [e2], t3.flags |= 16) : o2.push(e2)), t3.child = n3, t3.memoizedState = null, n3);
  }
  function jc(e2, t3) {
    return t3 = Mc({ mode: `visible`, children: t3 }, e2.mode), t3.return = e2, e2.child = t3;
  }
  function Mc(e2, t3) {
    return e2 = Ci(22, e2, null, t3), e2.lanes = 0, e2;
  }
  function Nc(e2, t3, n3) {
    return Ya(t3, e2.child, null, n3), e2 = jc(t3, t3.pendingProps.children), e2.flags |= 2, t3.memoizedState = null, e2;
  }
  function Pc(e2, t3, n3) {
    e2.lanes |= t3;
    var r2 = e2.alternate;
    r2 !== null && (r2.lanes |= t3), la(e2.return, t3, n3);
  }
  function Fc(e2, t3, n3, r2, i2, a2) {
    var o2 = e2.memoizedState;
    o2 === null ? e2.memoizedState = { isBackwards: t3, rendering: null, renderingStartTime: 0, last: r2, tail: n3, tailMode: i2, treeForkCount: a2 } : (o2.isBackwards = t3, o2.rendering = null, o2.renderingStartTime = 0, o2.last = r2, o2.tail = n3, o2.tailMode = i2, o2.treeForkCount = a2);
  }
  function Ic(e2, t3, n3) {
    var r2 = t3.pendingProps, i2 = r2.revealOrder, a2 = r2.tail;
    r2 = r2.children;
    var o2 = M.current, s3 = !!(o2 & 2);
    if (s3 ? (o2 = o2 & 1 | 2, t3.flags |= 128) : o2 &= 1, T(M, o2), fc(e2, t3, r2, n3), r2 = k ? Li : 0, !s3 && e2 !== null && e2.flags & 128) a: for (e2 = t3.child; e2 !== null; ) {
      if (e2.tag === 13) e2.memoizedState !== null && Pc(e2, n3, t3);
      else if (e2.tag === 19) Pc(e2, n3, t3);
      else if (e2.child !== null) {
        e2.child.return = e2, e2 = e2.child;
        continue;
      }
      if (e2 === t3) break a;
      for (; e2.sibling === null; ) {
        if (e2.return === null || e2.return === t3) break a;
        e2 = e2.return;
      }
      e2.sibling.return = e2.return, e2 = e2.sibling;
    }
    switch (i2) {
      case `forwards`:
        for (n3 = t3.child, i2 = null; n3 !== null; ) e2 = n3.alternate, e2 !== null && So(e2) === null && (i2 = n3), n3 = n3.sibling;
        n3 = i2, n3 === null ? (i2 = t3.child, t3.child = null) : (i2 = n3.sibling, n3.sibling = null), Fc(t3, false, i2, n3, a2, r2);
        break;
      case `backwards`:
      case `unstable_legacy-backwards`:
        for (n3 = null, i2 = t3.child, t3.child = null; i2 !== null; ) {
          if (e2 = i2.alternate, e2 !== null && So(e2) === null) {
            t3.child = i2;
            break;
          }
          e2 = i2.sibling, i2.sibling = n3, n3 = i2, i2 = e2;
        }
        Fc(t3, true, n3, null, a2, r2);
        break;
      case `together`:
        Fc(t3, false, null, null, void 0, r2);
        break;
      default:
        t3.memoizedState = null;
    }
    return t3.child;
  }
  function Lc(e2, t3, n3) {
    if (e2 !== null && (t3.dependencies = e2.dependencies), Xl |= t3.lanes, (n3 & t3.childLanes) === 0) {
      if (e2 !== null) {
        if (da(e2, t3, n3, false), (n3 & t3.childLanes) === 0) return null;
      } else return null;
    }
    if (e2 !== null && t3.child !== e2.child) throw Error(u2(153));
    if (t3.child !== null) {
      for (e2 = t3.child, n3 = Ti(e2, e2.pendingProps), t3.child = n3, n3.return = t3; e2.sibling !== null; ) e2 = e2.sibling, n3 = n3.sibling = Ti(e2, e2.pendingProps), n3.return = t3;
      n3.sibling = null;
    }
    return t3.child;
  }
  function Rc(e2, t3) {
    return (e2.lanes & t3) !== 0 || (e2 = e2.dependencies, !!(e2 !== null && fa(e2)));
  }
  function zc(e2, t3, n3) {
    switch (t3.tag) {
      case 3:
        Te(t3, t3.stateNode.containerInfo), sa(t3, j, e2.memoizedState.cache), ta();
        break;
      case 27:
      case 5:
        De(t3);
        break;
      case 4:
        Te(t3, t3.stateNode.containerInfo);
        break;
      case 10:
        sa(t3, t3.type, t3.memoizedProps.value);
        break;
      case 31:
        if (t3.memoizedState !== null) return t3.flags |= 128, vo(t3), null;
        break;
      case 13:
        var r2 = t3.memoizedState;
        if (r2 !== null) return r2.dehydrated === null ? (n3 & t3.child.childLanes) === 0 ? (_o(t3), e2 = Lc(e2, t3, n3), e2 === null ? null : e2.sibling) : Ac(e2, t3, n3) : (_o(t3), t3.flags |= 128, null);
        _o(t3);
        break;
      case 19:
        var i2 = !!(e2.flags & 128);
        if (r2 = (n3 & t3.childLanes) !== 0, r2 || (r2 = (da(e2, t3, n3, false), (n3 & t3.childLanes) !== 0)), i2) {
          if (r2) return Ic(e2, t3, n3);
          t3.flags |= 128;
        }
        if (i2 = t3.memoizedState, i2 !== null && (i2.rendering = null, i2.tail = null, i2.lastEffect = null), T(M, M.current), r2) break;
        return null;
      case 22:
        return t3.lanes = 0, gc(e2, t3, n3, t3.pendingProps);
      case 24:
        sa(t3, j, e2.memoizedState.cache);
    }
    return Lc(e2, t3, n3);
  }
  function Bc(e2, t3, n3) {
    if (e2 !== null) {
      if (e2.memoizedProps !== t3.pendingProps) R = true;
      else {
        if (!Rc(e2, n3) && !(t3.flags & 128)) return R = false, zc(e2, t3, n3);
        R = !!(e2.flags & 131072);
      }
    } else R = false, k && t3.flags & 1048576 && Wi(t3, Li, t3.index);
    switch (t3.lanes = 0, t3.tag) {
      case 16:
        a: {
          var r2 = t3.pendingProps;
          if (e2 = za(t3.elementType), t3.type = e2, typeof e2 == `function`) wi(e2) ? (r2 = tc(e2, r2), t3.tag = 1, t3 = Tc(null, t3, e2, r2, n3)) : (t3.tag = 0, t3 = Cc(null, t3, e2, r2, n3));
          else {
            if (e2 != null) {
              var i2 = e2.$$typeof;
              if (i2 === ae) {
                t3.tag = 11, t3 = pc(null, t3, e2, r2, n3);
                break a;
              }
              if (i2 === ce) {
                t3.tag = 14, t3 = mc(null, t3, e2, r2, n3);
                break a;
              }
            }
            throw t3 = he(e2) || e2, Error(u2(306, t3, ``));
          }
        }
        return t3;
      case 0:
        return Cc(e2, t3, t3.type, t3.pendingProps, n3);
      case 1:
        return r2 = t3.type, i2 = tc(r2, t3.pendingProps), Tc(e2, t3, r2, i2, n3);
      case 3:
        a: {
          if (Te(t3, t3.stateNode.containerInfo), e2 === null) throw Error(u2(387));
          r2 = t3.pendingProps;
          var a2 = t3.memoizedState;
          i2 = a2.element, $a(e2, t3), oo(t3, r2, null, n3);
          var o2 = t3.memoizedState;
          if (r2 = o2.cache, sa(t3, j, r2), r2 !== a2.cache && ua(t3, [j], n3, true), ao(), r2 = o2.element, a2.isDehydrated) {
            if (a2 = { element: r2, isDehydrated: false, cache: o2.cache }, t3.updateQueue.baseState = a2, t3.memoizedState = a2, t3.flags & 256) {
              t3 = Ec(e2, t3, r2, n3);
              break a;
            }
            if (r2 !== i2) {
              i2 = Ni(Error(u2(424)), t3), ra(i2), t3 = Ec(e2, t3, r2, n3);
              break a;
            }
            switch (e2 = t3.stateNode.containerInfo, e2.nodeType) {
              case 9:
                e2 = e2.body;
                break;
              default:
                e2 = e2.nodeName === `HTML` ? e2.ownerDocument.body : e2;
            }
            for (O = df(e2.firstChild), D = t3, k = true, Ji = null, Yi = true, n3 = Xa(t3, null, r2, n3), t3.child = n3; n3; ) n3.flags = n3.flags & -3 | 4096, n3 = n3.sibling;
          } else {
            if (ta(), r2 === i2) {
              t3 = Lc(e2, t3, n3);
              break a;
            }
            fc(e2, t3, r2, n3);
          }
          t3 = t3.child;
        }
        return t3;
      case 26:
        return Sc(e2, t3), e2 === null ? (n3 = Mf(t3.type, null, t3.pendingProps, null)) ? t3.memoizedState = n3 : k || (n3 = t3.type, e2 = t3.pendingProps, r2 = Ud(Ce.current).createElement(n3), r2[St] = t3, r2[Ct] = e2, $(r2, n3, e2), E(r2), t3.stateNode = r2) : t3.memoizedState = Mf(t3.type, e2.memoizedProps, t3.pendingProps, e2.memoizedState), null;
      case 27:
        return De(t3), e2 === null && k && (r2 = t3.stateNode = hf(t3.type, t3.pendingProps, Ce.current), D = t3, Yi = true, i2 = O, ef(t3.type) ? (ff = i2, O = df(r2.firstChild)) : O = i2), fc(e2, t3, t3.pendingProps.children, n3), Sc(e2, t3), e2 === null && (t3.flags |= 4194304), t3.child;
      case 5:
        return e2 === null && k && ((i2 = r2 = O) && (r2 = af(r2, t3.type, t3.pendingProps, Yi), r2 === null ? i2 = false : (t3.stateNode = r2, D = t3, O = df(r2.firstChild), Yi = false, i2 = true)), i2 || Zi(t3)), De(t3), i2 = t3.type, a2 = t3.pendingProps, o2 = e2 === null ? null : e2.memoizedProps, r2 = a2.children, Kd(i2, a2) ? r2 = null : o2 !== null && Kd(i2, o2) && (t3.flags |= 32), t3.memoizedState !== null && (i2 = Mo(e2, t3, Fo, null, null, n3), tp._currentValue = i2), Sc(e2, t3), fc(e2, t3, r2, n3), t3.child;
      case 6:
        return e2 === null && k && ((e2 = n3 = O) && (n3 = of(n3, t3.pendingProps, Yi), n3 === null ? e2 = false : (t3.stateNode = n3, D = t3, O = null, e2 = true)), e2 || Zi(t3)), null;
      case 13:
        return Ac(e2, t3, n3);
      case 4:
        return Te(t3, t3.stateNode.containerInfo), r2 = t3.pendingProps, e2 === null ? t3.child = Ya(t3, null, r2, n3) : fc(e2, t3, r2, n3), t3.child;
      case 11:
        return pc(e2, t3, t3.type, t3.pendingProps, n3);
      case 7:
        return fc(e2, t3, t3.pendingProps, n3), t3.child;
      case 8:
        return fc(e2, t3, t3.pendingProps.children, n3), t3.child;
      case 12:
        return fc(e2, t3, t3.pendingProps.children, n3), t3.child;
      case 10:
        return r2 = t3.pendingProps, sa(t3, t3.type, r2.value), fc(e2, t3, r2.children, n3), t3.child;
      case 9:
        return i2 = t3.type._context, r2 = t3.pendingProps.children, pa(t3), i2 = A(i2), r2 = r2(i2), t3.flags |= 1, fc(e2, t3, r2, n3), t3.child;
      case 14:
        return mc(e2, t3, t3.type, t3.pendingProps, n3);
      case 15:
        return hc(e2, t3, t3.type, t3.pendingProps, n3);
      case 19:
        return Ic(e2, t3, n3);
      case 31:
        return xc(e2, t3, n3);
      case 22:
        return gc(e2, t3, n3, t3.pendingProps);
      case 24:
        return pa(t3), r2 = A(j), e2 === null ? (i2 = Aa(), i2 === null && (i2 = W, a2 = ya(), i2.pooledCache = a2, a2.refCount++, a2 !== null && (i2.pooledCacheLanes |= n3), i2 = a2), t3.memoizedState = { parent: r2, cache: i2 }, Qa(t3), sa(t3, j, i2)) : ((e2.lanes & n3) !== 0 && ($a(e2, t3), oo(t3, null, null, n3), ao()), i2 = e2.memoizedState, a2 = t3.memoizedState, i2.parent === r2 ? (r2 = a2.cache, sa(t3, j, r2), r2 !== i2.cache && ua(t3, [j], n3, true)) : (i2 = { parent: r2, cache: r2 }, t3.memoizedState = i2, t3.lanes === 0 && (t3.memoizedState = t3.updateQueue.baseState = i2), sa(t3, j, r2))), fc(e2, t3, t3.pendingProps.children, n3), t3.child;
      case 29:
        throw t3.pendingProps;
    }
    throw Error(u2(156, t3.tag));
  }
  function Vc(e2) {
    e2.flags |= 4;
  }
  function Hc(e2, t3, n3, r2, i2) {
    if ((t3 = !!(e2.mode & 32)) && (t3 = false), t3) {
      if (e2.flags |= 16777216, (i2 & 335544128) === i2) {
        if (e2.stateNode.complete) e2.flags |= 8192;
        else if (Ou()) e2.flags |= 8192;
        else throw Ba = Ia, Pa;
      }
    } else e2.flags &= -16777217;
  }
  function Uc(e2, t3) {
    if (t3.type !== `stylesheet` || t3.state.loading & 4) e2.flags &= -16777217;
    else if (e2.flags |= 16777216, !qf(t3)) {
      if (Ou()) e2.flags |= 8192;
      else throw Ba = Ia, Pa;
    }
  }
  function Wc(e2, t3) {
    t3 !== null && (e2.flags |= 4), e2.flags & 16384 && (t3 = e2.tag === 22 ? 536870912 : ut(), e2.lanes |= t3, eu |= t3);
  }
  function Gc(e2, t3) {
    if (!k) switch (e2.tailMode) {
      case `hidden`:
        t3 = e2.tail;
        for (var n3 = null; t3 !== null; ) t3.alternate !== null && (n3 = t3), t3 = t3.sibling;
        n3 === null ? e2.tail = null : n3.sibling = null;
        break;
      case `collapsed`:
        n3 = e2.tail;
        for (var r2 = null; n3 !== null; ) n3.alternate !== null && (r2 = n3), n3 = n3.sibling;
        r2 === null ? t3 || e2.tail === null ? e2.tail = null : e2.tail.sibling = null : r2.sibling = null;
    }
  }
  function z(e2) {
    var t3 = e2.alternate !== null && e2.alternate.child === e2.child, n3 = 0, r2 = 0;
    if (t3) for (var i2 = e2.child; i2 !== null; ) n3 |= i2.lanes | i2.childLanes, r2 |= i2.subtreeFlags & 65011712, r2 |= i2.flags & 65011712, i2.return = e2, i2 = i2.sibling;
    else for (i2 = e2.child; i2 !== null; ) n3 |= i2.lanes | i2.childLanes, r2 |= i2.subtreeFlags, r2 |= i2.flags, i2.return = e2, i2 = i2.sibling;
    return e2.subtreeFlags |= r2, e2.childLanes = n3, t3;
  }
  function Kc(e2, t3, n3) {
    var r2 = t3.pendingProps;
    switch (Ki(t3), t3.tag) {
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return z(t3), null;
      case 1:
        return z(t3), null;
      case 3:
        return n3 = t3.stateNode, r2 = null, e2 !== null && (r2 = e2.memoizedState.cache), t3.memoizedState.cache !== r2 && (t3.flags |= 2048), ca(j), Ee(), n3.pendingContext && (n3.context = n3.pendingContext, n3.pendingContext = null), (e2 === null || e2.child === null) && (ea(t3) ? Vc(t3) : e2 === null || e2.memoizedState.isDehydrated && !(t3.flags & 256) || (t3.flags |= 1024, na())), z(t3), null;
      case 26:
        var i2 = t3.type, a2 = t3.memoizedState;
        return e2 === null ? (Vc(t3), a2 === null ? (z(t3), Hc(t3, i2, null, r2, n3)) : (z(t3), Uc(t3, a2))) : a2 ? a2 === e2.memoizedState ? (z(t3), t3.flags &= -16777217) : (Vc(t3), z(t3), Uc(t3, a2)) : (e2 = e2.memoizedProps, e2 !== r2 && Vc(t3), z(t3), Hc(t3, i2, e2, r2, n3)), null;
      case 27:
        if (Oe(t3), n3 = Ce.current, i2 = t3.type, e2 !== null && t3.stateNode != null) e2.memoizedProps !== r2 && Vc(t3);
        else {
          if (!r2) {
            if (t3.stateNode === null) throw Error(u2(166));
            return z(t3), null;
          }
          e2 = xe.current, ea(t3) ? Qi(t3, e2) : (e2 = hf(i2, r2, n3), t3.stateNode = e2, Vc(t3));
        }
        return z(t3), null;
      case 5:
        if (Oe(t3), i2 = t3.type, e2 !== null && t3.stateNode != null) e2.memoizedProps !== r2 && Vc(t3);
        else {
          if (!r2) {
            if (t3.stateNode === null) throw Error(u2(166));
            return z(t3), null;
          }
          if (a2 = xe.current, ea(t3)) Qi(t3, a2);
          else {
            var o2 = Ud(Ce.current);
            switch (a2) {
              case 1:
                a2 = o2.createElementNS(`http://www.w3.org/2000/svg`, i2);
                break;
              case 2:
                a2 = o2.createElementNS(`http://www.w3.org/1998/Math/MathML`, i2);
                break;
              default:
                switch (i2) {
                  case `svg`:
                    a2 = o2.createElementNS(`http://www.w3.org/2000/svg`, i2);
                    break;
                  case `math`:
                    a2 = o2.createElementNS(`http://www.w3.org/1998/Math/MathML`, i2);
                    break;
                  case `script`:
                    a2 = o2.createElement(`div`), a2.innerHTML = `<script><\/script>`, a2 = a2.removeChild(a2.firstChild);
                    break;
                  case `select`:
                    a2 = typeof r2.is == `string` ? o2.createElement(`select`, { is: r2.is }) : o2.createElement(`select`), r2.multiple ? a2.multiple = true : r2.size && (a2.size = r2.size);
                    break;
                  default:
                    a2 = typeof r2.is == `string` ? o2.createElement(i2, { is: r2.is }) : o2.createElement(i2);
                }
            }
            a2[St] = t3, a2[Ct] = r2;
            a: for (o2 = t3.child; o2 !== null; ) {
              if (o2.tag === 5 || o2.tag === 6) a2.appendChild(o2.stateNode);
              else if (o2.tag !== 4 && o2.tag !== 27 && o2.child !== null) {
                o2.child.return = o2, o2 = o2.child;
                continue;
              }
              if (o2 === t3) break a;
              for (; o2.sibling === null; ) {
                if (o2.return === null || o2.return === t3) break a;
                o2 = o2.return;
              }
              o2.sibling.return = o2.return, o2 = o2.sibling;
            }
            t3.stateNode = a2;
            a: switch ($(a2, i2, r2), i2) {
              case `button`:
              case `input`:
              case `select`:
              case `textarea`:
                r2 = !!r2.autoFocus;
                break a;
              case `img`:
                r2 = true;
                break a;
              default:
                r2 = false;
            }
            r2 && Vc(t3);
          }
        }
        return z(t3), Hc(t3, t3.type, e2 === null ? null : e2.memoizedProps, t3.pendingProps, n3), null;
      case 6:
        if (e2 && t3.stateNode != null) e2.memoizedProps !== r2 && Vc(t3);
        else {
          if (typeof r2 != `string` && t3.stateNode === null) throw Error(u2(166));
          if (e2 = Ce.current, ea(t3)) {
            if (e2 = t3.stateNode, n3 = t3.memoizedProps, r2 = null, i2 = D, i2 !== null) switch (i2.tag) {
              case 27:
              case 5:
                r2 = i2.memoizedProps;
            }
            e2[St] = t3, e2 = !!(e2.nodeValue === n3 || r2 !== null && true === r2.suppressHydrationWarning || Id(e2.nodeValue, n3)), e2 || Zi(t3, true);
          } else e2 = Ud(e2).createTextNode(r2), e2[St] = t3, t3.stateNode = e2;
        }
        return z(t3), null;
      case 31:
        if (n3 = t3.memoizedState, e2 === null || e2.memoizedState !== null) {
          if (r2 = ea(t3), n3 !== null) {
            if (e2 === null) {
              if (!r2) throw Error(u2(318));
              if (e2 = t3.memoizedState, e2 = e2 === null ? null : e2.dehydrated, !e2) throw Error(u2(557));
              e2[St] = t3;
            } else ta(), !(t3.flags & 128) && (t3.memoizedState = null), t3.flags |= 4;
            z(t3), e2 = false;
          } else n3 = na(), e2 !== null && e2.memoizedState !== null && (e2.memoizedState.hydrationErrors = n3), e2 = true;
          if (!e2) return t3.flags & 256 ? (xo(t3), t3) : (xo(t3), null);
          if (t3.flags & 128) throw Error(u2(558));
        }
        return z(t3), null;
      case 13:
        if (r2 = t3.memoizedState, e2 === null || e2.memoizedState !== null && e2.memoizedState.dehydrated !== null) {
          if (i2 = ea(t3), r2 !== null && r2.dehydrated !== null) {
            if (e2 === null) {
              if (!i2) throw Error(u2(318));
              if (i2 = t3.memoizedState, i2 = i2 === null ? null : i2.dehydrated, !i2) throw Error(u2(317));
              i2[St] = t3;
            } else ta(), !(t3.flags & 128) && (t3.memoizedState = null), t3.flags |= 4;
            z(t3), i2 = false;
          } else i2 = na(), e2 !== null && e2.memoizedState !== null && (e2.memoizedState.hydrationErrors = i2), i2 = true;
          if (!i2) return t3.flags & 256 ? (xo(t3), t3) : (xo(t3), null);
        }
        return xo(t3), t3.flags & 128 ? (t3.lanes = n3, t3) : (n3 = r2 !== null, e2 = e2 !== null && e2.memoizedState !== null, n3 && (r2 = t3.child, i2 = null, r2.alternate !== null && r2.alternate.memoizedState !== null && r2.alternate.memoizedState.cachePool !== null && (i2 = r2.alternate.memoizedState.cachePool.pool), a2 = null, r2.memoizedState !== null && r2.memoizedState.cachePool !== null && (a2 = r2.memoizedState.cachePool.pool), a2 !== i2 && (r2.flags |= 2048)), n3 !== e2 && n3 && (t3.child.flags |= 8192), Wc(t3, t3.updateQueue), z(t3), null);
      case 4:
        return Ee(), e2 === null && Ed(t3.stateNode.containerInfo), z(t3), null;
      case 10:
        return ca(t3.type), z(t3), null;
      case 19:
        if (w(M), r2 = t3.memoizedState, r2 === null) return z(t3), null;
        if (i2 = !!(t3.flags & 128), a2 = r2.rendering, a2 === null) {
          if (i2) Gc(r2, false);
          else {
            if (J !== 0 || e2 !== null && e2.flags & 128) for (e2 = t3.child; e2 !== null; ) {
              if (a2 = So(e2), a2 !== null) {
                for (t3.flags |= 128, Gc(r2, false), e2 = a2.updateQueue, t3.updateQueue = e2, Wc(t3, e2), t3.subtreeFlags = 0, e2 = n3, n3 = t3.child; n3 !== null; ) Ei(n3, e2), n3 = n3.sibling;
                return T(M, M.current & 1 | 2), k && Ui(t3, r2.treeForkCount), t3.child;
              }
              e2 = e2.sibling;
            }
            r2.tail !== null && Ve() > ou && (t3.flags |= 128, i2 = true, Gc(r2, false), t3.lanes = 4194304);
          }
        } else {
          if (!i2) {
            if (e2 = So(a2), e2 !== null) {
              if (t3.flags |= 128, i2 = true, e2 = e2.updateQueue, t3.updateQueue = e2, Wc(t3, e2), Gc(r2, true), r2.tail === null && r2.tailMode === `hidden` && !a2.alternate && !k) return z(t3), null;
            } else 2 * Ve() - r2.renderingStartTime > ou && n3 !== 536870912 && (t3.flags |= 128, i2 = true, Gc(r2, false), t3.lanes = 4194304);
          }
          r2.isBackwards ? (a2.sibling = t3.child, t3.child = a2) : (e2 = r2.last, e2 === null ? t3.child = a2 : e2.sibling = a2, r2.last = a2);
        }
        return r2.tail === null ? (z(t3), null) : (e2 = r2.tail, r2.rendering = e2, r2.tail = e2.sibling, r2.renderingStartTime = Ve(), e2.sibling = null, n3 = M.current, T(M, i2 ? n3 & 1 | 2 : n3 & 1), k && Ui(t3, r2.treeForkCount), e2);
      case 22:
      case 23:
        return xo(t3), mo(), r2 = t3.memoizedState !== null, e2 === null ? r2 && (t3.flags |= 8192) : e2.memoizedState !== null !== r2 && (t3.flags |= 8192), r2 ? n3 & 536870912 && !(t3.flags & 128) && (z(t3), t3.subtreeFlags & 6 && (t3.flags |= 8192)) : z(t3), n3 = t3.updateQueue, n3 !== null && Wc(t3, n3.retryQueue), n3 = null, e2 !== null && e2.memoizedState !== null && e2.memoizedState.cachePool !== null && (n3 = e2.memoizedState.cachePool.pool), r2 = null, t3.memoizedState !== null && t3.memoizedState.cachePool !== null && (r2 = t3.memoizedState.cachePool.pool), r2 !== n3 && (t3.flags |= 2048), e2 !== null && w(ka), null;
      case 24:
        return n3 = null, e2 !== null && (n3 = e2.memoizedState.cache), t3.memoizedState.cache !== n3 && (t3.flags |= 2048), ca(j), z(t3), null;
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(u2(156, t3.tag));
  }
  function qc(e2, t3) {
    switch (Ki(t3), t3.tag) {
      case 1:
        return e2 = t3.flags, e2 & 65536 ? (t3.flags = e2 & -65537 | 128, t3) : null;
      case 3:
        return ca(j), Ee(), e2 = t3.flags, e2 & 65536 && !(e2 & 128) ? (t3.flags = e2 & -65537 | 128, t3) : null;
      case 26:
      case 27:
      case 5:
        return Oe(t3), null;
      case 31:
        if (t3.memoizedState !== null) {
          if (xo(t3), t3.alternate === null) throw Error(u2(340));
          ta();
        }
        return e2 = t3.flags, e2 & 65536 ? (t3.flags = e2 & -65537 | 128, t3) : null;
      case 13:
        if (xo(t3), e2 = t3.memoizedState, e2 !== null && e2.dehydrated !== null) {
          if (t3.alternate === null) throw Error(u2(340));
          ta();
        }
        return e2 = t3.flags, e2 & 65536 ? (t3.flags = e2 & -65537 | 128, t3) : null;
      case 19:
        return w(M), null;
      case 4:
        return Ee(), null;
      case 10:
        return ca(t3.type), null;
      case 22:
      case 23:
        return xo(t3), mo(), e2 !== null && w(ka), e2 = t3.flags, e2 & 65536 ? (t3.flags = e2 & -65537 | 128, t3) : null;
      case 24:
        return ca(j), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Jc(e2, t3) {
    switch (Ki(t3), t3.tag) {
      case 3:
        ca(j), Ee();
        break;
      case 26:
      case 27:
      case 5:
        Oe(t3);
        break;
      case 4:
        Ee();
        break;
      case 31:
        t3.memoizedState !== null && xo(t3);
        break;
      case 13:
        xo(t3);
        break;
      case 19:
        w(M);
        break;
      case 10:
        ca(t3.type);
        break;
      case 22:
      case 23:
        xo(t3), mo(), e2 !== null && w(ka);
        break;
      case 24:
        ca(j);
    }
  }
  function Yc(e2, t3) {
    try {
      var n3 = t3.updateQueue, r2 = n3 === null ? null : n3.lastEffect;
      if (r2 !== null) {
        var i2 = r2.next;
        n3 = i2;
        do {
          if ((n3.tag & e2) === e2) {
            r2 = void 0;
            var a2 = n3.create, o2 = n3.inst;
            r2 = a2(), o2.destroy = r2;
          }
          n3 = n3.next;
        } while (n3 !== i2);
      }
    } catch (e3) {
      X(t3, t3.return, e3);
    }
  }
  function Xc(e2, t3, n3) {
    try {
      var r2 = t3.updateQueue, i2 = r2 === null ? null : r2.lastEffect;
      if (i2 !== null) {
        var a2 = i2.next;
        r2 = a2;
        do {
          if ((r2.tag & e2) === e2) {
            var o2 = r2.inst, s3 = o2.destroy;
            if (s3 !== void 0) {
              o2.destroy = void 0, i2 = t3;
              var c2 = n3, l3 = s3;
              try {
                l3();
              } catch (e3) {
                X(i2, c2, e3);
              }
            }
          }
          r2 = r2.next;
        } while (r2 !== a2);
      }
    } catch (e3) {
      X(t3, t3.return, e3);
    }
  }
  function Zc(e2) {
    var t3 = e2.updateQueue;
    if (t3 !== null) {
      var n3 = e2.stateNode;
      try {
        co(t3, n3);
      } catch (t4) {
        X(e2, e2.return, t4);
      }
    }
  }
  function Qc(e2, t3, n3) {
    n3.props = tc(e2.type, e2.memoizedProps), n3.state = e2.memoizedState;
    try {
      n3.componentWillUnmount();
    } catch (n4) {
      X(e2, t3, n4);
    }
  }
  function $c(e2, t3) {
    try {
      var n3 = e2.ref;
      if (n3 !== null) {
        switch (e2.tag) {
          case 26:
          case 27:
          case 5:
            var r2 = e2.stateNode;
            break;
          case 30:
            r2 = e2.stateNode;
            break;
          default:
            r2 = e2.stateNode;
        }
        typeof n3 == `function` ? e2.refCleanup = n3(r2) : n3.current = r2;
      }
    } catch (n4) {
      X(e2, t3, n4);
    }
  }
  function el(e2, t3) {
    var n3 = e2.ref, r2 = e2.refCleanup;
    if (n3 !== null) {
      if (typeof r2 == `function`) try {
        r2();
      } catch (n4) {
        X(e2, t3, n4);
      } finally {
        e2.refCleanup = null, e2 = e2.alternate, e2 != null && (e2.refCleanup = null);
      }
      else if (typeof n3 == `function`) try {
        n3(null);
      } catch (n4) {
        X(e2, t3, n4);
      }
      else n3.current = null;
    }
  }
  function tl(e2) {
    var t3 = e2.type, n3 = e2.memoizedProps, r2 = e2.stateNode;
    try {
      a: switch (t3) {
        case `button`:
        case `input`:
        case `select`:
        case `textarea`:
          n3.autoFocus && r2.focus();
          break a;
        case `img`:
          n3.src ? r2.src = n3.src : n3.srcSet && (r2.srcset = n3.srcSet);
      }
    } catch (t4) {
      X(e2, e2.return, t4);
    }
  }
  function nl(e2, t3, n3) {
    try {
      var r2 = e2.stateNode;
      Rd(r2, e2.type, n3, t3), r2[Ct] = t3;
    } catch (t4) {
      X(e2, e2.return, t4);
    }
  }
  function rl(e2) {
    return e2.tag === 5 || e2.tag === 3 || e2.tag === 26 || e2.tag === 27 && ef(e2.type) || e2.tag === 4;
  }
  function il(e2) {
    a: for (; ; ) {
      for (; e2.sibling === null; ) {
        if (e2.return === null || rl(e2.return)) return null;
        e2 = e2.return;
      }
      for (e2.sibling.return = e2.return, e2 = e2.sibling; e2.tag !== 5 && e2.tag !== 6 && e2.tag !== 18; ) {
        if (e2.tag === 27 && ef(e2.type) || e2.flags & 2 || e2.child === null || e2.tag === 4) continue a;
        e2.child.return = e2, e2 = e2.child;
      }
      if (!(e2.flags & 2)) return e2.stateNode;
    }
  }
  function al(e2, t3, n3) {
    var r2 = e2.tag;
    if (r2 === 5 || r2 === 6) e2 = e2.stateNode, t3 ? (n3.nodeType === 9 ? n3.body : n3.nodeName === `HTML` ? n3.ownerDocument.body : n3).insertBefore(e2, t3) : (t3 = n3.nodeType === 9 ? n3.body : n3.nodeName === `HTML` ? n3.ownerDocument.body : n3, t3.appendChild(e2), n3 = n3._reactRootContainer, n3 != null || t3.onclick !== null || (t3.onclick = hn));
    else if (r2 !== 4 && (r2 === 27 && ef(e2.type) && (n3 = e2.stateNode, t3 = null), e2 = e2.child, e2 !== null)) for (al(e2, t3, n3), e2 = e2.sibling; e2 !== null; ) al(e2, t3, n3), e2 = e2.sibling;
  }
  function ol(e2, t3, n3) {
    var r2 = e2.tag;
    if (r2 === 5 || r2 === 6) e2 = e2.stateNode, t3 ? n3.insertBefore(e2, t3) : n3.appendChild(e2);
    else if (r2 !== 4 && (r2 === 27 && ef(e2.type) && (n3 = e2.stateNode), e2 = e2.child, e2 !== null)) for (ol(e2, t3, n3), e2 = e2.sibling; e2 !== null; ) ol(e2, t3, n3), e2 = e2.sibling;
  }
  function sl(e2) {
    var t3 = e2.stateNode, n3 = e2.memoizedProps;
    try {
      for (var r2 = e2.type, i2 = t3.attributes; i2.length; ) t3.removeAttributeNode(i2[0]);
      $(t3, r2, n3), t3[St] = e2, t3[Ct] = n3;
    } catch (t4) {
      X(e2, e2.return, t4);
    }
  }
  var cl = false, B = false, ll = false, ul = typeof WeakSet == `function` ? WeakSet : Set, V = null;
  function dl(e2, t3) {
    if (e2 = e2.containerInfo, Vd = up, e2 = Hr(e2), Ur(e2)) {
      if (`selectionStart` in e2) var n3 = { start: e2.selectionStart, end: e2.selectionEnd };
      else a: {
        n3 = (n3 = e2.ownerDocument) && n3.defaultView || window;
        var r2 = n3.getSelection && n3.getSelection();
        if (r2 && r2.rangeCount !== 0) {
          n3 = r2.anchorNode;
          var i2 = r2.anchorOffset, a2 = r2.focusNode;
          r2 = r2.focusOffset;
          try {
            n3.nodeType, a2.nodeType;
          } catch {
            n3 = null;
            break a;
          }
          var o2 = 0, s3 = -1, c2 = -1, l3 = 0, d3 = 0, f3 = e2, p3 = null;
          b: for (; ; ) {
            for (var m3; f3 !== n3 || i2 !== 0 && f3.nodeType !== 3 || (s3 = o2 + i2), f3 !== a2 || r2 !== 0 && f3.nodeType !== 3 || (c2 = o2 + r2), f3.nodeType === 3 && (o2 += f3.nodeValue.length), (m3 = f3.firstChild) !== null; ) p3 = f3, f3 = m3;
            for (; ; ) {
              if (f3 === e2) break b;
              if (p3 === n3 && ++l3 === i2 && (s3 = o2), p3 === a2 && ++d3 === r2 && (c2 = o2), (m3 = f3.nextSibling) !== null) break;
              f3 = p3, p3 = f3.parentNode;
            }
            f3 = m3;
          }
          n3 = s3 === -1 || c2 === -1 ? null : { start: s3, end: c2 };
        } else n3 = null;
      }
      n3 || (n3 = { start: 0, end: 0 });
    } else n3 = null;
    for (Hd = { focusedElem: e2, selectionRange: n3 }, up = false, V = t3; V !== null; ) if (t3 = V, e2 = t3.child, t3.subtreeFlags & 1028 && e2 !== null) e2.return = t3, V = e2;
    else for (; V !== null; ) {
      switch (t3 = V, a2 = t3.alternate, e2 = t3.flags, t3.tag) {
        case 0:
          if (e2 & 4 && (e2 = t3.updateQueue, e2 = e2 === null ? null : e2.events, e2 !== null)) for (n3 = 0; n3 < e2.length; n3++) i2 = e2[n3], i2.ref.impl = i2.nextImpl;
          break;
        case 11:
        case 15:
          break;
        case 1:
          if (e2 & 1024 && a2 !== null) {
            e2 = void 0, n3 = t3, i2 = a2.memoizedProps, a2 = a2.memoizedState, r2 = n3.stateNode;
            try {
              var h3 = tc(n3.type, i2);
              e2 = r2.getSnapshotBeforeUpdate(h3, a2), r2.__reactInternalSnapshotBeforeUpdate = e2;
            } catch (e3) {
              X(n3, n3.return, e3);
            }
          }
          break;
        case 3:
          if (e2 & 1024) {
            if (e2 = t3.stateNode.containerInfo, n3 = e2.nodeType, n3 === 9) rf(e2);
            else if (n3 === 1) switch (e2.nodeName) {
              case `HEAD`:
              case `HTML`:
              case `BODY`:
                rf(e2);
                break;
              default:
                e2.textContent = ``;
            }
          }
          break;
        case 5:
        case 26:
        case 27:
        case 6:
        case 4:
        case 17:
          break;
        default:
          if (e2 & 1024) throw Error(u2(163));
      }
      if (e2 = t3.sibling, e2 !== null) {
        e2.return = t3.return, V = e2;
        break;
      }
      V = t3.return;
    }
  }
  function fl(e2, t3, n3) {
    var r2 = n3.flags;
    switch (n3.tag) {
      case 0:
      case 11:
      case 15:
        El(e2, n3), r2 & 4 && Yc(5, n3);
        break;
      case 1:
        if (El(e2, n3), r2 & 4) {
          if (e2 = n3.stateNode, t3 === null) try {
            e2.componentDidMount();
          } catch (e3) {
            X(n3, n3.return, e3);
          }
          else {
            var i2 = tc(n3.type, t3.memoizedProps);
            t3 = t3.memoizedState;
            try {
              e2.componentDidUpdate(i2, t3, e2.__reactInternalSnapshotBeforeUpdate);
            } catch (e3) {
              X(n3, n3.return, e3);
            }
          }
        }
        r2 & 64 && Zc(n3), r2 & 512 && $c(n3, n3.return);
        break;
      case 3:
        if (El(e2, n3), r2 & 64 && (e2 = n3.updateQueue, e2 !== null)) {
          if (t3 = null, n3.child !== null) switch (n3.child.tag) {
            case 27:
            case 5:
              t3 = n3.child.stateNode;
              break;
            case 1:
              t3 = n3.child.stateNode;
          }
          try {
            co(e2, t3);
          } catch (e3) {
            X(n3, n3.return, e3);
          }
        }
        break;
      case 27:
        t3 === null && r2 & 4 && sl(n3);
      case 26:
      case 5:
        El(e2, n3), t3 === null && r2 & 4 && tl(n3), r2 & 512 && $c(n3, n3.return);
        break;
      case 12:
        El(e2, n3);
        break;
      case 31:
        El(e2, n3), r2 & 4 && _l(e2, n3);
        break;
      case 13:
        El(e2, n3), r2 & 4 && vl(e2, n3), r2 & 64 && (e2 = n3.memoizedState, e2 !== null && (e2 = e2.dehydrated, e2 !== null && (n3 = Qu.bind(null, n3), uf(e2, n3))));
        break;
      case 22:
        if (r2 = n3.memoizedState !== null || cl, !r2) {
          t3 = t3 !== null && t3.memoizedState !== null || B, i2 = cl;
          var a2 = B;
          cl = r2, (B = t3) && !a2 ? Ol(e2, n3, !!(n3.subtreeFlags & 8772)) : El(e2, n3), cl = i2, B = a2;
        }
        break;
      case 30:
        break;
      default:
        El(e2, n3);
    }
  }
  function pl(e2) {
    var t3 = e2.alternate;
    t3 !== null && (e2.alternate = null, pl(t3)), e2.child = null, e2.deletions = null, e2.sibling = null, e2.tag === 5 && (t3 = e2.stateNode, t3 !== null && At(t3)), e2.stateNode = null, e2.return = null, e2.dependencies = null, e2.memoizedProps = null, e2.memoizedState = null, e2.pendingProps = null, e2.stateNode = null, e2.updateQueue = null;
  }
  var H = null, ml = false;
  function hl(e2, t3, n3) {
    for (n3 = n3.child; n3 !== null; ) gl(e2, t3, n3), n3 = n3.sibling;
  }
  function gl(e2, t3, n3) {
    if (Ze && typeof Ze.onCommitFiberUnmount == `function`) try {
      Ze.onCommitFiberUnmount(Xe, n3);
    } catch {
    }
    switch (n3.tag) {
      case 26:
        B || el(n3, t3), hl(e2, t3, n3), n3.memoizedState ? n3.memoizedState.count-- : n3.stateNode && (n3 = n3.stateNode, n3.parentNode.removeChild(n3));
        break;
      case 27:
        B || el(n3, t3);
        var r2 = H, i2 = ml;
        ef(n3.type) && (H = n3.stateNode, ml = false), hl(e2, t3, n3), gf(n3.stateNode), H = r2, ml = i2;
        break;
      case 5:
        B || el(n3, t3);
      case 6:
        if (r2 = H, i2 = ml, H = null, hl(e2, t3, n3), H = r2, ml = i2, H !== null) {
          if (ml) try {
            (H.nodeType === 9 ? H.body : H.nodeName === `HTML` ? H.ownerDocument.body : H).removeChild(n3.stateNode);
          } catch (e3) {
            X(n3, t3, e3);
          }
          else try {
            H.removeChild(n3.stateNode);
          } catch (e3) {
            X(n3, t3, e3);
          }
        }
        break;
      case 18:
        H !== null && (ml ? (e2 = H, tf(e2.nodeType === 9 ? e2.body : e2.nodeName === `HTML` ? e2.ownerDocument.body : e2, n3.stateNode), Ip(e2)) : tf(H, n3.stateNode));
        break;
      case 4:
        r2 = H, i2 = ml, H = n3.stateNode.containerInfo, ml = true, hl(e2, t3, n3), H = r2, ml = i2;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        Xc(2, n3, t3), B || Xc(4, n3, t3), hl(e2, t3, n3);
        break;
      case 1:
        B || (el(n3, t3), r2 = n3.stateNode, typeof r2.componentWillUnmount == `function` && Qc(n3, t3, r2)), hl(e2, t3, n3);
        break;
      case 21:
        hl(e2, t3, n3);
        break;
      case 22:
        B = (r2 = B) || n3.memoizedState !== null, hl(e2, t3, n3), B = r2;
        break;
      default:
        hl(e2, t3, n3);
    }
  }
  function _l(e2, t3) {
    if (t3.memoizedState === null && (e2 = t3.alternate, e2 !== null && (e2 = e2.memoizedState, e2 !== null))) {
      e2 = e2.dehydrated;
      try {
        Ip(e2);
      } catch (e3) {
        X(t3, t3.return, e3);
      }
    }
  }
  function vl(e2, t3) {
    if (t3.memoizedState === null && (e2 = t3.alternate, e2 !== null && (e2 = e2.memoizedState, e2 !== null && (e2 = e2.dehydrated, e2 !== null)))) try {
      Ip(e2);
    } catch (e3) {
      X(t3, t3.return, e3);
    }
  }
  function yl(e2) {
    switch (e2.tag) {
      case 31:
      case 13:
      case 19:
        var t3 = e2.stateNode;
        return t3 === null && (t3 = e2.stateNode = new ul()), t3;
      case 22:
        return e2 = e2.stateNode, t3 = e2._retryCache, t3 === null && (t3 = e2._retryCache = new ul()), t3;
      default:
        throw Error(u2(435, e2.tag));
    }
  }
  function bl(e2, t3) {
    var n3 = yl(e2);
    t3.forEach(function(t4) {
      if (!n3.has(t4)) {
        n3.add(t4);
        var r2 = $u.bind(null, e2, t4);
        t4.then(r2, r2);
      }
    });
  }
  function xl(e2, t3) {
    var n3 = t3.deletions;
    if (n3 !== null) for (var r2 = 0; r2 < n3.length; r2++) {
      var i2 = n3[r2], a2 = e2, o2 = t3, s3 = o2;
      a: for (; s3 !== null; ) {
        switch (s3.tag) {
          case 27:
            if (ef(s3.type)) {
              H = s3.stateNode, ml = false;
              break a;
            }
            break;
          case 5:
            H = s3.stateNode, ml = false;
            break a;
          case 3:
          case 4:
            H = s3.stateNode.containerInfo, ml = true;
            break a;
        }
        s3 = s3.return;
      }
      if (H === null) throw Error(u2(160));
      gl(a2, o2, i2), H = null, ml = false, a2 = i2.alternate, a2 !== null && (a2.return = null), i2.return = null;
    }
    if (t3.subtreeFlags & 13886) for (t3 = t3.child; t3 !== null; ) Cl(t3, e2), t3 = t3.sibling;
  }
  var Sl = null;
  function Cl(e2, t3) {
    var n3 = e2.alternate, r2 = e2.flags;
    switch (e2.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        xl(t3, e2), wl(e2), r2 & 4 && (Xc(3, e2, e2.return), Yc(3, e2), Xc(5, e2, e2.return));
        break;
      case 1:
        xl(t3, e2), wl(e2), r2 & 512 && (B || n3 === null || el(n3, n3.return)), r2 & 64 && cl && (e2 = e2.updateQueue, e2 !== null && (r2 = e2.callbacks, r2 !== null && (n3 = e2.shared.hiddenCallbacks, e2.shared.hiddenCallbacks = n3 === null ? r2 : n3.concat(r2))));
        break;
      case 26:
        var i2 = Sl;
        if (xl(t3, e2), wl(e2), r2 & 512 && (B || n3 === null || el(n3, n3.return)), r2 & 4) {
          var a2 = n3 === null ? null : n3.memoizedState;
          if (r2 = e2.memoizedState, n3 === null) {
            if (r2 === null) {
              if (e2.stateNode === null) {
                a: {
                  r2 = e2.type, n3 = e2.memoizedProps, i2 = i2.ownerDocument || i2;
                  b: switch (r2) {
                    case `title`:
                      a2 = i2.getElementsByTagName(`title`)[0], (!a2 || a2[kt] || a2[St] || a2.namespaceURI === `http://www.w3.org/2000/svg` || a2.hasAttribute(`itemprop`)) && (a2 = i2.createElement(r2), i2.head.insertBefore(a2, i2.querySelector(`head > title`))), $(a2, r2, n3), a2[St] = e2, E(a2), r2 = a2;
                      break a;
                    case `link`:
                      var o2 = Wf(`link`, `href`, i2).get(r2 + (n3.href || ``));
                      if (o2) {
                        for (var s3 = 0; s3 < o2.length; s3++) if (a2 = o2[s3], a2.getAttribute(`href`) === (n3.href == null || n3.href === `` ? null : n3.href) && a2.getAttribute(`rel`) === (n3.rel == null ? null : n3.rel) && a2.getAttribute(`title`) === (n3.title == null ? null : n3.title) && a2.getAttribute(`crossorigin`) === (n3.crossOrigin == null ? null : n3.crossOrigin)) {
                          o2.splice(s3, 1);
                          break b;
                        }
                      }
                      a2 = i2.createElement(r2), $(a2, r2, n3), i2.head.appendChild(a2);
                      break;
                    case `meta`:
                      if (o2 = Wf(`meta`, `content`, i2).get(r2 + (n3.content || ``))) {
                        for (s3 = 0; s3 < o2.length; s3++) if (a2 = o2[s3], a2.getAttribute(`content`) === (n3.content == null ? null : `` + n3.content) && a2.getAttribute(`name`) === (n3.name == null ? null : n3.name) && a2.getAttribute(`property`) === (n3.property == null ? null : n3.property) && a2.getAttribute(`http-equiv`) === (n3.httpEquiv == null ? null : n3.httpEquiv) && a2.getAttribute(`charset`) === (n3.charSet == null ? null : n3.charSet)) {
                          o2.splice(s3, 1);
                          break b;
                        }
                      }
                      a2 = i2.createElement(r2), $(a2, r2, n3), i2.head.appendChild(a2);
                      break;
                    default:
                      throw Error(u2(468, r2));
                  }
                  a2[St] = e2, E(a2), r2 = a2;
                }
                e2.stateNode = r2;
              } else Gf(i2, e2.type, e2.stateNode);
            } else e2.stateNode = zf(i2, r2, e2.memoizedProps);
          } else a2 === r2 ? r2 === null && e2.stateNode !== null && nl(e2, e2.memoizedProps, n3.memoizedProps) : (a2 === null ? n3.stateNode !== null && (n3 = n3.stateNode, n3.parentNode.removeChild(n3)) : a2.count--, r2 === null ? Gf(i2, e2.type, e2.stateNode) : zf(i2, r2, e2.memoizedProps));
        }
        break;
      case 27:
        xl(t3, e2), wl(e2), r2 & 512 && (B || n3 === null || el(n3, n3.return)), n3 !== null && r2 & 4 && nl(e2, e2.memoizedProps, n3.memoizedProps);
        break;
      case 5:
        if (xl(t3, e2), wl(e2), r2 & 512 && (B || n3 === null || el(n3, n3.return)), e2.flags & 32) {
          i2 = e2.stateNode;
          try {
            sn(i2, ``);
          } catch (t4) {
            X(e2, e2.return, t4);
          }
        }
        r2 & 4 && e2.stateNode != null && (i2 = e2.memoizedProps, nl(e2, i2, n3 === null ? i2 : n3.memoizedProps)), r2 & 1024 && (ll = true);
        break;
      case 6:
        if (xl(t3, e2), wl(e2), r2 & 4) {
          if (e2.stateNode === null) throw Error(u2(162));
          r2 = e2.memoizedProps, n3 = e2.stateNode;
          try {
            n3.nodeValue = r2;
          } catch (t4) {
            X(e2, e2.return, t4);
          }
        }
        break;
      case 3:
        if (Uf = null, i2 = Sl, Sl = yf(t3.containerInfo), xl(t3, e2), Sl = i2, wl(e2), r2 & 4 && n3 !== null && n3.memoizedState.isDehydrated) try {
          Ip(t3.containerInfo);
        } catch (t4) {
          X(e2, e2.return, t4);
        }
        ll && (ll = false, Tl(e2));
        break;
      case 4:
        r2 = Sl, Sl = yf(e2.stateNode.containerInfo), xl(t3, e2), wl(e2), Sl = r2;
        break;
      case 12:
        xl(t3, e2), wl(e2);
        break;
      case 31:
        xl(t3, e2), wl(e2), r2 & 4 && (r2 = e2.updateQueue, r2 !== null && (e2.updateQueue = null, bl(e2, r2)));
        break;
      case 13:
        xl(t3, e2), wl(e2), e2.child.flags & 8192 && e2.memoizedState !== null != (n3 !== null && n3.memoizedState !== null) && (iu = Ve()), r2 & 4 && (r2 = e2.updateQueue, r2 !== null && (e2.updateQueue = null, bl(e2, r2)));
        break;
      case 22:
        i2 = e2.memoizedState !== null;
        var c2 = n3 !== null && n3.memoizedState !== null, l3 = cl, d3 = B;
        if (cl = l3 || i2, B = d3 || c2, xl(t3, e2), B = d3, cl = l3, wl(e2), r2 & 8192) a: for (t3 = e2.stateNode, t3._visibility = i2 ? t3._visibility & -2 : t3._visibility | 1, i2 && (n3 === null || c2 || cl || B || Dl(e2)), n3 = null, t3 = e2; ; ) {
          if (t3.tag === 5 || t3.tag === 26) {
            if (n3 === null) {
              c2 = n3 = t3;
              try {
                if (a2 = c2.stateNode, i2) o2 = a2.style, typeof o2.setProperty == `function` ? o2.setProperty(`display`, `none`, `important`) : o2.display = `none`;
                else {
                  s3 = c2.stateNode;
                  var f3 = c2.memoizedProps.style, p3 = f3 != null && f3.hasOwnProperty(`display`) ? f3.display : null;
                  s3.style.display = p3 == null || typeof p3 == `boolean` ? `` : (`` + p3).trim();
                }
              } catch (e3) {
                X(c2, c2.return, e3);
              }
            }
          } else if (t3.tag === 6) {
            if (n3 === null) {
              c2 = t3;
              try {
                c2.stateNode.nodeValue = i2 ? `` : c2.memoizedProps;
              } catch (e3) {
                X(c2, c2.return, e3);
              }
            }
          } else if (t3.tag === 18) {
            if (n3 === null) {
              c2 = t3;
              try {
                var m3 = c2.stateNode;
                i2 ? nf(m3, true) : nf(c2.stateNode, false);
              } catch (e3) {
                X(c2, c2.return, e3);
              }
            }
          } else if ((t3.tag !== 22 && t3.tag !== 23 || t3.memoizedState === null || t3 === e2) && t3.child !== null) {
            t3.child.return = t3, t3 = t3.child;
            continue;
          }
          if (t3 === e2) break a;
          for (; t3.sibling === null; ) {
            if (t3.return === null || t3.return === e2) break a;
            n3 === t3 && (n3 = null), t3 = t3.return;
          }
          n3 === t3 && (n3 = null), t3.sibling.return = t3.return, t3 = t3.sibling;
        }
        r2 & 4 && (r2 = e2.updateQueue, r2 !== null && (n3 = r2.retryQueue, n3 !== null && (r2.retryQueue = null, bl(e2, n3))));
        break;
      case 19:
        xl(t3, e2), wl(e2), r2 & 4 && (r2 = e2.updateQueue, r2 !== null && (e2.updateQueue = null, bl(e2, r2)));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        xl(t3, e2), wl(e2);
    }
  }
  function wl(e2) {
    var t3 = e2.flags;
    if (t3 & 2) {
      try {
        for (var n3, r2 = e2.return; r2 !== null; ) {
          if (rl(r2)) {
            n3 = r2;
            break;
          }
          r2 = r2.return;
        }
        if (n3 == null) throw Error(u2(160));
        switch (n3.tag) {
          case 27:
            var i2 = n3.stateNode;
            ol(e2, il(e2), i2);
            break;
          case 5:
            var a2 = n3.stateNode;
            n3.flags & 32 && (sn(a2, ``), n3.flags &= -33), ol(e2, il(e2), a2);
            break;
          case 3:
          case 4:
            var o2 = n3.stateNode.containerInfo;
            al(e2, il(e2), o2);
            break;
          default:
            throw Error(u2(161));
        }
      } catch (t4) {
        X(e2, e2.return, t4);
      }
      e2.flags &= -3;
    }
    t3 & 4096 && (e2.flags &= -4097);
  }
  function Tl(e2) {
    if (e2.subtreeFlags & 1024) for (e2 = e2.child; e2 !== null; ) {
      var t3 = e2;
      Tl(t3), t3.tag === 5 && t3.flags & 1024 && t3.stateNode.reset(), e2 = e2.sibling;
    }
  }
  function El(e2, t3) {
    if (t3.subtreeFlags & 8772) for (t3 = t3.child; t3 !== null; ) fl(e2, t3.alternate, t3), t3 = t3.sibling;
  }
  function Dl(e2) {
    for (e2 = e2.child; e2 !== null; ) {
      var t3 = e2;
      switch (t3.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          Xc(4, t3, t3.return), Dl(t3);
          break;
        case 1:
          el(t3, t3.return);
          var n3 = t3.stateNode;
          typeof n3.componentWillUnmount == `function` && Qc(t3, t3.return, n3), Dl(t3);
          break;
        case 27:
          gf(t3.stateNode);
        case 26:
        case 5:
          el(t3, t3.return), Dl(t3);
          break;
        case 22:
          t3.memoizedState === null && Dl(t3);
          break;
        case 30:
          Dl(t3);
          break;
        default:
          Dl(t3);
      }
      e2 = e2.sibling;
    }
  }
  function Ol(e2, t3, n3) {
    for (n3 && (n3 = !!(t3.subtreeFlags & 8772)), t3 = t3.child; t3 !== null; ) {
      var r2 = t3.alternate, i2 = e2, a2 = t3, o2 = a2.flags;
      switch (a2.tag) {
        case 0:
        case 11:
        case 15:
          Ol(i2, a2, n3), Yc(4, a2);
          break;
        case 1:
          if (Ol(i2, a2, n3), r2 = a2, i2 = r2.stateNode, typeof i2.componentDidMount == `function`) try {
            i2.componentDidMount();
          } catch (e3) {
            X(r2, r2.return, e3);
          }
          if (r2 = a2, i2 = r2.updateQueue, i2 !== null) {
            var s3 = r2.stateNode;
            try {
              var c2 = i2.shared.hiddenCallbacks;
              if (c2 !== null) for (i2.shared.hiddenCallbacks = null, i2 = 0; i2 < c2.length; i2++) so(c2[i2], s3);
            } catch (e3) {
              X(r2, r2.return, e3);
            }
          }
          n3 && o2 & 64 && Zc(a2), $c(a2, a2.return);
          break;
        case 27:
          sl(a2);
        case 26:
        case 5:
          Ol(i2, a2, n3), n3 && r2 === null && o2 & 4 && tl(a2), $c(a2, a2.return);
          break;
        case 12:
          Ol(i2, a2, n3);
          break;
        case 31:
          Ol(i2, a2, n3), n3 && o2 & 4 && _l(i2, a2);
          break;
        case 13:
          Ol(i2, a2, n3), n3 && o2 & 4 && vl(i2, a2);
          break;
        case 22:
          a2.memoizedState === null && Ol(i2, a2, n3), $c(a2, a2.return);
          break;
        case 30:
          break;
        default:
          Ol(i2, a2, n3);
      }
      t3 = t3.sibling;
    }
  }
  function kl(e2, t3) {
    var n3 = null;
    e2 !== null && e2.memoizedState !== null && e2.memoizedState.cachePool !== null && (n3 = e2.memoizedState.cachePool.pool), e2 = null, t3.memoizedState !== null && t3.memoizedState.cachePool !== null && (e2 = t3.memoizedState.cachePool.pool), e2 !== n3 && (e2 != null && e2.refCount++, n3 != null && ba(n3));
  }
  function Al(e2, t3) {
    e2 = null, t3.alternate !== null && (e2 = t3.alternate.memoizedState.cache), t3 = t3.memoizedState.cache, t3 !== e2 && (t3.refCount++, e2 != null && ba(e2));
  }
  function jl(e2, t3, n3, r2) {
    if (t3.subtreeFlags & 10256) for (t3 = t3.child; t3 !== null; ) Ml(e2, t3, n3, r2), t3 = t3.sibling;
  }
  function Ml(e2, t3, n3, r2) {
    var i2 = t3.flags;
    switch (t3.tag) {
      case 0:
      case 11:
      case 15:
        jl(e2, t3, n3, r2), i2 & 2048 && Yc(9, t3);
        break;
      case 1:
        jl(e2, t3, n3, r2);
        break;
      case 3:
        jl(e2, t3, n3, r2), i2 & 2048 && (e2 = null, t3.alternate !== null && (e2 = t3.alternate.memoizedState.cache), t3 = t3.memoizedState.cache, t3 !== e2 && (t3.refCount++, e2 != null && ba(e2)));
        break;
      case 12:
        if (i2 & 2048) {
          jl(e2, t3, n3, r2), e2 = t3.stateNode;
          try {
            var a2 = t3.memoizedProps, o2 = a2.id, s3 = a2.onPostCommit;
            typeof s3 == `function` && s3(o2, t3.alternate === null ? `mount` : `update`, e2.passiveEffectDuration, -0);
          } catch (e3) {
            X(t3, t3.return, e3);
          }
        } else jl(e2, t3, n3, r2);
        break;
      case 31:
        jl(e2, t3, n3, r2);
        break;
      case 13:
        jl(e2, t3, n3, r2);
        break;
      case 23:
        break;
      case 22:
        a2 = t3.stateNode, o2 = t3.alternate, t3.memoizedState === null ? a2._visibility & 2 ? jl(e2, t3, n3, r2) : (a2._visibility |= 2, Nl(e2, t3, n3, r2, !!(t3.subtreeFlags & 10256) || false)) : a2._visibility & 2 ? jl(e2, t3, n3, r2) : Pl(e2, t3), i2 & 2048 && kl(o2, t3);
        break;
      case 24:
        jl(e2, t3, n3, r2), i2 & 2048 && Al(t3.alternate, t3);
        break;
      default:
        jl(e2, t3, n3, r2);
    }
  }
  function Nl(e2, t3, n3, r2, i2) {
    for (i2 && (i2 = !!(t3.subtreeFlags & 10256) || false), t3 = t3.child; t3 !== null; ) {
      var a2 = e2, o2 = t3, s3 = n3, c2 = r2, l3 = o2.flags;
      switch (o2.tag) {
        case 0:
        case 11:
        case 15:
          Nl(a2, o2, s3, c2, i2), Yc(8, o2);
          break;
        case 23:
          break;
        case 22:
          var u3 = o2.stateNode;
          o2.memoizedState === null ? (u3._visibility |= 2, Nl(a2, o2, s3, c2, i2)) : u3._visibility & 2 ? Nl(a2, o2, s3, c2, i2) : Pl(a2, o2), i2 && l3 & 2048 && kl(o2.alternate, o2);
          break;
        case 24:
          Nl(a2, o2, s3, c2, i2), i2 && l3 & 2048 && Al(o2.alternate, o2);
          break;
        default:
          Nl(a2, o2, s3, c2, i2);
      }
      t3 = t3.sibling;
    }
  }
  function Pl(e2, t3) {
    if (t3.subtreeFlags & 10256) for (t3 = t3.child; t3 !== null; ) {
      var n3 = e2, r2 = t3, i2 = r2.flags;
      switch (r2.tag) {
        case 22:
          Pl(n3, r2), i2 & 2048 && kl(r2.alternate, r2);
          break;
        case 24:
          Pl(n3, r2), i2 & 2048 && Al(r2.alternate, r2);
          break;
        default:
          Pl(n3, r2);
      }
      t3 = t3.sibling;
    }
  }
  var Fl = 8192;
  function Il(e2, t3, n3) {
    if (e2.subtreeFlags & Fl) for (e2 = e2.child; e2 !== null; ) Ll(e2, t3, n3), e2 = e2.sibling;
  }
  function Ll(e2, t3, n3) {
    switch (e2.tag) {
      case 26:
        Il(e2, t3, n3), e2.flags & Fl && e2.memoizedState !== null && Jf(n3, Sl, e2.memoizedState, e2.memoizedProps);
        break;
      case 5:
        Il(e2, t3, n3);
        break;
      case 3:
      case 4:
        var r2 = Sl;
        Sl = yf(e2.stateNode.containerInfo), Il(e2, t3, n3), Sl = r2;
        break;
      case 22:
        e2.memoizedState === null && (r2 = e2.alternate, r2 !== null && r2.memoizedState !== null ? (r2 = Fl, Fl = 16777216, Il(e2, t3, n3), Fl = r2) : Il(e2, t3, n3));
        break;
      default:
        Il(e2, t3, n3);
    }
  }
  function Rl(e2) {
    var t3 = e2.alternate;
    if (t3 !== null && (e2 = t3.child, e2 !== null)) {
      t3.child = null;
      do
        t3 = e2.sibling, e2.sibling = null, e2 = t3;
      while (e2 !== null);
    }
  }
  function zl(e2) {
    var t3 = e2.deletions;
    if (e2.flags & 16) {
      if (t3 !== null) for (var n3 = 0; n3 < t3.length; n3++) {
        var r2 = t3[n3];
        V = r2, Hl(r2, e2);
      }
      Rl(e2);
    }
    if (e2.subtreeFlags & 10256) for (e2 = e2.child; e2 !== null; ) Bl(e2), e2 = e2.sibling;
  }
  function Bl(e2) {
    switch (e2.tag) {
      case 0:
      case 11:
      case 15:
        zl(e2), e2.flags & 2048 && Xc(9, e2, e2.return);
        break;
      case 3:
        zl(e2);
        break;
      case 12:
        zl(e2);
        break;
      case 22:
        var t3 = e2.stateNode;
        e2.memoizedState !== null && t3._visibility & 2 && (e2.return === null || e2.return.tag !== 13) ? (t3._visibility &= -3, Vl(e2)) : zl(e2);
        break;
      default:
        zl(e2);
    }
  }
  function Vl(e2) {
    var t3 = e2.deletions;
    if (e2.flags & 16) {
      if (t3 !== null) for (var n3 = 0; n3 < t3.length; n3++) {
        var r2 = t3[n3];
        V = r2, Hl(r2, e2);
      }
      Rl(e2);
    }
    for (e2 = e2.child; e2 !== null; ) {
      switch (t3 = e2, t3.tag) {
        case 0:
        case 11:
        case 15:
          Xc(8, t3, t3.return), Vl(t3);
          break;
        case 22:
          n3 = t3.stateNode, n3._visibility & 2 && (n3._visibility &= -3, Vl(t3));
          break;
        default:
          Vl(t3);
      }
      e2 = e2.sibling;
    }
  }
  function Hl(e2, t3) {
    for (; V !== null; ) {
      var n3 = V;
      switch (n3.tag) {
        case 0:
        case 11:
        case 15:
          Xc(8, n3, t3);
          break;
        case 23:
        case 22:
          if (n3.memoizedState !== null && n3.memoizedState.cachePool !== null) {
            var r2 = n3.memoizedState.cachePool.pool;
            r2 != null && r2.refCount++;
          }
          break;
        case 24:
          ba(n3.memoizedState.cache);
      }
      if (r2 = n3.child, r2 !== null) r2.return = n3, V = r2;
      else a: for (n3 = e2; V !== null; ) {
        r2 = V;
        var i2 = r2.sibling, a2 = r2.return;
        if (pl(r2), r2 === n3) {
          V = null;
          break a;
        }
        if (i2 !== null) {
          i2.return = a2, V = i2;
          break a;
        }
        V = a2;
      }
    }
  }
  var Ul = { getCacheForType: function(e2) {
    var t3 = A(j), n3 = t3.data.get(e2);
    return n3 === void 0 && (n3 = e2(), t3.data.set(e2, n3)), n3;
  }, cacheSignal: function() {
    return A(j).controller.signal;
  } }, Wl = typeof WeakMap == `function` ? WeakMap : Map, U = 0, W = null, G = null, K = 0, q = 0, Gl = null, Kl = false, ql = false, Jl = false, Yl = 0, J = 0, Xl = 0, Zl = 0, Ql = 0, $l = 0, eu = 0, tu = null, nu = null, ru = false, iu = 0, au = 0, ou = 1 / 0, su = null, cu = null, Y = 0, lu = null, uu = null, du = 0, fu = 0, pu = null, mu = null, hu = 0, gu = null;
  function _u() {
    return U & 2 && K !== 0 ? K & -K : S.T === null ? yt() : hd();
  }
  function vu() {
    if ($l === 0) {
      if (!(K & 536870912) || k) {
        var e2 = it;
        it <<= 1, !(it & 3932160) && (it = 262144), $l = e2;
      } else $l = 536870912;
    }
    return e2 = ho.current, e2 !== null && (e2.flags |= 32), $l;
  }
  function yu(e2, t3, n3) {
    (e2 === W && (q === 2 || q === 9) || e2.cancelPendingCommit !== null) && (Eu(e2, 0), Cu(e2, K, $l, false)), ft(e2, n3), (!(U & 2) || e2 !== W) && (e2 === W && (!(U & 2) && (Zl |= n3), J === 4 && Cu(e2, K, $l, false)), sd(e2));
  }
  function bu(e2, t3, n3) {
    if (U & 6) throw Error(u2(327));
    var r2 = !n3 && !(t3 & 127) && (t3 & e2.expiredLanes) === 0 || ct(e2, t3), i2 = r2 ? Pu(e2, t3) : Mu(e2, t3, true), a2 = r2;
    do {
      if (i2 === 0) {
        ql && !r2 && Cu(e2, t3, 0, false);
        break;
      }
      if (n3 = e2.current.alternate, a2 && !Su(n3)) {
        i2 = Mu(e2, t3, false), a2 = false;
        continue;
      }
      if (i2 === 2) {
        if (a2 = t3, e2.errorRecoveryDisabledLanes & a2) var o2 = 0;
        else o2 = e2.pendingLanes & -536870913, o2 = o2 === 0 ? o2 & 536870912 ? 536870912 : 0 : o2;
        if (o2 !== 0) {
          t3 = o2;
          a: {
            var s3 = e2;
            i2 = tu;
            var c2 = s3.current.memoizedState.isDehydrated;
            if (c2 && (Eu(s3, o2).flags |= 256), o2 = Mu(s3, o2, false), o2 !== 2) {
              if (Jl && !c2) {
                s3.errorRecoveryDisabledLanes |= a2, Zl |= a2, i2 = 4;
                break a;
              }
              a2 = nu, nu = i2, a2 !== null && (nu === null ? nu = a2 : nu.push.apply(nu, a2));
            }
            i2 = o2;
          }
          if (a2 = false, i2 !== 2) continue;
        }
      }
      if (i2 === 1) {
        Eu(e2, 0), Cu(e2, t3, 0, true);
        break;
      }
      a: {
        switch (r2 = e2, a2 = i2, a2) {
          case 0:
          case 1:
            throw Error(u2(345));
          case 4:
            if ((t3 & 4194048) !== t3) break;
          case 6:
            Cu(r2, t3, $l, !Kl);
            break a;
          case 2:
            nu = null;
            break;
          case 3:
          case 5:
            break;
          default:
            throw Error(u2(329));
        }
        if ((t3 & 62914560) === t3 && (i2 = iu + 300 - Ve(), 10 < i2)) {
          if (Cu(r2, t3, $l, !Kl), st(r2, 0, true) !== 0) break a;
          du = t3, r2.timeoutHandle = Yd(xu.bind(null, r2, n3, nu, su, ru, t3, $l, Zl, eu, Kl, a2, `Throttled`, -0, 0), i2);
          break a;
        }
        xu(r2, n3, nu, su, ru, t3, $l, Zl, eu, Kl, a2, null, -0, 0);
      }
      break;
    } while (1);
    sd(e2);
  }
  function xu(e2, t3, n3, r2, i2, a2, o2, s3, c2, l3, u3, d3, f3, p3) {
    if (e2.timeoutHandle = -1, d3 = t3.subtreeFlags, d3 & 8192 || (d3 & 16785408) == 16785408) {
      d3 = { stylesheets: null, count: 0, imgCount: 0, imgBytes: 0, suspenseyImages: [], waitingForImages: true, waitingForViewTransition: false, unsuspend: hn }, Ll(t3, a2, d3);
      var m3 = (a2 & 62914560) === a2 ? iu - Ve() : (a2 & 4194048) === a2 ? au - Ve() : 0;
      if (m3 = Xf(d3, m3), m3 !== null) {
        du = a2, e2.cancelPendingCommit = m3(Vu.bind(null, e2, t3, a2, n3, r2, i2, o2, s3, c2, u3, d3, null, f3, p3)), Cu(e2, a2, o2, !l3);
        return;
      }
    }
    Vu(e2, t3, a2, n3, r2, i2, o2, s3, c2);
  }
  function Su(e2) {
    for (var t3 = e2; ; ) {
      var n3 = t3.tag;
      if ((n3 === 0 || n3 === 11 || n3 === 15) && t3.flags & 16384 && (n3 = t3.updateQueue, n3 !== null && (n3 = n3.stores, n3 !== null))) for (var r2 = 0; r2 < n3.length; r2++) {
        var i2 = n3[r2], a2 = i2.getSnapshot;
        i2 = i2.value;
        try {
          if (!Lr(a2(), i2)) return false;
        } catch {
          return false;
        }
      }
      if (n3 = t3.child, t3.subtreeFlags & 16384 && n3 !== null) n3.return = t3, t3 = n3;
      else {
        if (t3 === e2) break;
        for (; t3.sibling === null; ) {
          if (t3.return === null || t3.return === e2) return true;
          t3 = t3.return;
        }
        t3.sibling.return = t3.return, t3 = t3.sibling;
      }
    }
    return true;
  }
  function Cu(e2, t3, n3, r2) {
    t3 &= ~Ql, t3 &= ~Zl, e2.suspendedLanes |= t3, e2.pingedLanes &= ~t3, r2 && (e2.warmLanes |= t3), r2 = e2.expirationTimes;
    for (var i2 = t3; 0 < i2; ) {
      var a2 = 31 - $e(i2), o2 = 1 << a2;
      r2[a2] = -1, i2 &= ~o2;
    }
    n3 !== 0 && mt(e2, n3, t3);
  }
  function wu() {
    return U & 6 ? true : (cd(0, false), false);
  }
  function Tu() {
    if (G !== null) {
      if (q === 0) var e2 = G.return;
      else e2 = G, oa = aa = null, Ro(e2), Ua = null, Wa = 0, e2 = G;
      for (; e2 !== null; ) Jc(e2.alternate, e2), e2 = e2.return;
      G = null;
    }
  }
  function Eu(e2, t3) {
    var n3 = e2.timeoutHandle;
    n3 !== -1 && (e2.timeoutHandle = -1, Xd(n3)), n3 = e2.cancelPendingCommit, n3 !== null && (e2.cancelPendingCommit = null, n3()), du = 0, Tu(), W = e2, G = n3 = Ti(e2.current, null), K = t3, q = 0, Gl = null, Kl = false, ql = ct(e2, t3), Jl = false, eu = $l = Ql = Zl = Xl = J = 0, nu = tu = null, ru = false, t3 & 8 && (t3 |= t3 & 32);
    var r2 = e2.entangledLanes;
    if (r2 !== 0) for (e2 = e2.entanglements, r2 &= t3; 0 < r2; ) {
      var i2 = 31 - $e(r2), a2 = 1 << i2;
      t3 |= e2[i2], r2 &= ~a2;
    }
    return Yl = t3, hi(), n3;
  }
  function Du(e2, t3) {
    N = null, S.H = qs, t3 === Na || t3 === Fa ? (t3 = Va(), q = 3) : t3 === Pa ? (t3 = Va(), q = 4) : q = t3 === dc ? 8 : typeof t3 == `object` && t3 && typeof t3.then == `function` ? 6 : 1, Gl = t3, G === null && (J = 1, ac(e2, Ni(t3, e2.current)));
  }
  function Ou() {
    var e2 = ho.current;
    return e2 === null ? true : (K & 4194048) === K ? go === null : (K & 62914560) === K || K & 536870912 ? e2 === go : false;
  }
  function ku() {
    var e2 = S.H;
    return S.H = qs, e2 === null ? qs : e2;
  }
  function Au() {
    var e2 = S.A;
    return S.A = Ul, e2;
  }
  function ju() {
    J = 4, Kl || (K & 4194048) !== K && ho.current !== null || (ql = true), !(Xl & 134217727) && !(Zl & 134217727) || W === null || Cu(W, K, $l, false);
  }
  function Mu(e2, t3, n3) {
    var r2 = U;
    U |= 2;
    var i2 = ku(), a2 = Au();
    (W !== e2 || K !== t3) && (su = null, Eu(e2, t3)), t3 = false;
    var o2 = J;
    a: do
      try {
        if (q !== 0 && G !== null) {
          var s3 = G, c2 = Gl;
          switch (q) {
            case 8:
              Tu(), o2 = 6;
              break a;
            case 3:
            case 2:
            case 9:
            case 6:
              ho.current === null && (t3 = true);
              var l3 = q;
              if (q = 0, Gl = null, Ru(e2, s3, c2, l3), n3 && ql) {
                o2 = 0;
                break a;
              }
              break;
            default:
              l3 = q, q = 0, Gl = null, Ru(e2, s3, c2, l3);
          }
        }
        Nu(), o2 = J;
        break;
      } catch (t4) {
        Du(e2, t4);
      }
    while (1);
    return t3 && e2.shellSuspendCounter++, oa = aa = null, U = r2, S.H = i2, S.A = a2, G === null && (W = null, K = 0, hi()), o2;
  }
  function Nu() {
    for (; G !== null; ) Iu(G);
  }
  function Pu(e2, t3) {
    var n3 = U;
    U |= 2;
    var r2 = ku(), i2 = Au();
    W !== e2 || K !== t3 ? (su = null, ou = Ve() + 500, Eu(e2, t3)) : ql = ct(e2, t3);
    a: do
      try {
        if (q !== 0 && G !== null) {
          t3 = G;
          var a2 = Gl;
          b: switch (q) {
            case 1:
              q = 0, Gl = null, Ru(e2, t3, a2, 1);
              break;
            case 2:
            case 9:
              if (La(a2)) {
                q = 0, Gl = null, Lu(t3);
                break;
              }
              t3 = function() {
                q !== 2 && q !== 9 || W !== e2 || (q = 7), sd(e2);
              }, a2.then(t3, t3);
              break a;
            case 3:
              q = 7;
              break a;
            case 4:
              q = 5;
              break a;
            case 7:
              La(a2) ? (q = 0, Gl = null, Lu(t3)) : (q = 0, Gl = null, Ru(e2, t3, a2, 7));
              break;
            case 5:
              var o2 = null;
              switch (G.tag) {
                case 26:
                  o2 = G.memoizedState;
                case 5:
                case 27:
                  var s3 = G;
                  if (o2 ? qf(o2) : s3.stateNode.complete) {
                    q = 0, Gl = null;
                    var c2 = s3.sibling;
                    if (c2 !== null) G = c2;
                    else {
                      var l3 = s3.return;
                      l3 === null ? G = null : (G = l3, zu(l3));
                    }
                    break b;
                  }
              }
              q = 0, Gl = null, Ru(e2, t3, a2, 5);
              break;
            case 6:
              q = 0, Gl = null, Ru(e2, t3, a2, 6);
              break;
            case 8:
              Tu(), J = 6;
              break a;
            default:
              throw Error(u2(462));
          }
        }
        Fu();
        break;
      } catch (t4) {
        Du(e2, t4);
      }
    while (1);
    return oa = aa = null, S.H = r2, S.A = i2, U = n3, G === null ? (W = null, K = 0, hi(), J) : 0;
  }
  function Fu() {
    for (; G !== null && !ze(); ) Iu(G);
  }
  function Iu(e2) {
    var t3 = Bc(e2.alternate, e2, Yl);
    e2.memoizedProps = e2.pendingProps, t3 === null ? zu(e2) : G = t3;
  }
  function Lu(e2) {
    var t3 = e2, n3 = t3.alternate;
    switch (t3.tag) {
      case 15:
      case 0:
        t3 = wc(n3, t3, t3.pendingProps, t3.type, void 0, K);
        break;
      case 11:
        t3 = wc(n3, t3, t3.pendingProps, t3.type.render, t3.ref, K);
        break;
      case 5:
        Ro(t3);
      default:
        Jc(n3, t3), t3 = G = Ei(t3, Yl), t3 = Bc(n3, t3, Yl);
    }
    e2.memoizedProps = e2.pendingProps, t3 === null ? zu(e2) : G = t3;
  }
  function Ru(e2, t3, n3, r2) {
    oa = aa = null, Ro(t3), Ua = null, Wa = 0;
    var i2 = t3.return;
    try {
      if (uc(e2, i2, t3, n3, K)) {
        J = 1, ac(e2, Ni(n3, e2.current)), G = null;
        return;
      }
    } catch (t4) {
      if (i2 !== null) throw G = i2, t4;
      J = 1, ac(e2, Ni(n3, e2.current)), G = null;
      return;
    }
    t3.flags & 32768 ? (k || r2 === 1 ? e2 = true : ql || K & 536870912 ? e2 = false : (Kl = e2 = true, (r2 === 2 || r2 === 9 || r2 === 3 || r2 === 6) && (r2 = ho.current, r2 !== null && r2.tag === 13 && (r2.flags |= 16384))), Bu(t3, e2)) : zu(t3);
  }
  function zu(e2) {
    var t3 = e2;
    do {
      if (t3.flags & 32768) {
        Bu(t3, Kl);
        return;
      }
      e2 = t3.return;
      var n3 = Kc(t3.alternate, t3, Yl);
      if (n3 !== null) {
        G = n3;
        return;
      }
      if (t3 = t3.sibling, t3 !== null) {
        G = t3;
        return;
      }
      G = t3 = e2;
    } while (t3 !== null);
    J === 0 && (J = 5);
  }
  function Bu(e2, t3) {
    do {
      var n3 = qc(e2.alternate, e2);
      if (n3 !== null) {
        n3.flags &= 32767, G = n3;
        return;
      }
      if (n3 = e2.return, n3 !== null && (n3.flags |= 32768, n3.subtreeFlags = 0, n3.deletions = null), !t3 && (e2 = e2.sibling, e2 !== null)) {
        G = e2;
        return;
      }
      G = e2 = n3;
    } while (e2 !== null);
    J = 6, G = null;
  }
  function Vu(e2, t3, n3, r2, i2, a2, o2, s3, c2) {
    e2.cancelPendingCommit = null;
    do
      Ku();
    while (Y !== 0);
    if (U & 6) throw Error(u2(327));
    if (t3 !== null) {
      if (t3 === e2.current) throw Error(u2(177));
      if (a2 = t3.lanes | t3.childLanes, a2 |= mi, pt(e2, n3, a2, o2, s3, c2), e2 === W && (G = W = null, K = 0), uu = t3, lu = e2, du = n3, fu = a2, pu = i2, mu = r2, t3.subtreeFlags & 10256 || t3.flags & 10256 ? (e2.callbackNode = null, e2.callbackPriority = 0, ed(Ge, function() {
        return qu(), null;
      })) : (e2.callbackNode = null, e2.callbackPriority = 0), r2 = !!(t3.flags & 13878), t3.subtreeFlags & 13878 || r2) {
        r2 = S.T, S.T = null, i2 = C.p, C.p = 2, o2 = U, U |= 4;
        try {
          dl(e2, t3, n3);
        } finally {
          U = o2, C.p = i2, S.T = r2;
        }
      }
      Y = 1, Hu(), Uu(), Wu();
    }
  }
  function Hu() {
    if (Y === 1) {
      Y = 0;
      var e2 = lu, t3 = uu, n3 = !!(t3.flags & 13878);
      if (t3.subtreeFlags & 13878 || n3) {
        n3 = S.T, S.T = null;
        var r2 = C.p;
        C.p = 2;
        var i2 = U;
        U |= 4;
        try {
          Cl(t3, e2);
          var a2 = Hd, o2 = Hr(e2.containerInfo), s3 = a2.focusedElem, c2 = a2.selectionRange;
          if (o2 !== s3 && s3 && s3.ownerDocument && Vr(s3.ownerDocument.documentElement, s3)) {
            if (c2 !== null && Ur(s3)) {
              var l3 = c2.start, u3 = c2.end;
              if (u3 === void 0 && (u3 = l3), `selectionStart` in s3) s3.selectionStart = l3, s3.selectionEnd = Math.min(u3, s3.value.length);
              else {
                var d3 = s3.ownerDocument || document, f3 = d3 && d3.defaultView || window;
                if (f3.getSelection) {
                  var p3 = f3.getSelection(), m3 = s3.textContent.length, h3 = Math.min(c2.start, m3), g2 = c2.end === void 0 ? h3 : Math.min(c2.end, m3);
                  !p3.extend && h3 > g2 && (o2 = g2, g2 = h3, h3 = o2);
                  var _2 = Br(s3, h3), v2 = Br(s3, g2);
                  if (_2 && v2 && (p3.rangeCount !== 1 || p3.anchorNode !== _2.node || p3.anchorOffset !== _2.offset || p3.focusNode !== v2.node || p3.focusOffset !== v2.offset)) {
                    var y2 = d3.createRange();
                    y2.setStart(_2.node, _2.offset), p3.removeAllRanges(), h3 > g2 ? (p3.addRange(y2), p3.extend(v2.node, v2.offset)) : (y2.setEnd(v2.node, v2.offset), p3.addRange(y2));
                  }
                }
              }
            }
            for (d3 = [], p3 = s3; p3 = p3.parentNode; ) p3.nodeType === 1 && d3.push({ element: p3, left: p3.scrollLeft, top: p3.scrollTop });
            for (typeof s3.focus == `function` && s3.focus(), s3 = 0; s3 < d3.length; s3++) {
              var b2 = d3[s3];
              b2.element.scrollLeft = b2.left, b2.element.scrollTop = b2.top;
            }
          }
          up = !!Vd, Hd = Vd = null;
        } finally {
          U = i2, C.p = r2, S.T = n3;
        }
      }
      e2.current = t3, Y = 2;
    }
  }
  function Uu() {
    if (Y === 2) {
      Y = 0;
      var e2 = lu, t3 = uu, n3 = !!(t3.flags & 8772);
      if (t3.subtreeFlags & 8772 || n3) {
        n3 = S.T, S.T = null;
        var r2 = C.p;
        C.p = 2;
        var i2 = U;
        U |= 4;
        try {
          fl(e2, t3.alternate, t3);
        } finally {
          U = i2, C.p = r2, S.T = n3;
        }
      }
      Y = 3;
    }
  }
  function Wu() {
    if (Y === 4 || Y === 3) {
      Y = 0, Be();
      var e2 = lu, t3 = uu, n3 = du, r2 = mu;
      t3.subtreeFlags & 10256 || t3.flags & 10256 ? Y = 5 : (Y = 0, uu = lu = null, Gu(e2, e2.pendingLanes));
      var i2 = e2.pendingLanes;
      if (i2 === 0 && (cu = null), vt(n3), t3 = t3.stateNode, Ze && typeof Ze.onCommitFiberRoot == `function`) try {
        Ze.onCommitFiberRoot(Xe, t3, void 0, (t3.current.flags & 128) == 128);
      } catch {
      }
      if (r2 !== null) {
        t3 = S.T, i2 = C.p, C.p = 2, S.T = null;
        try {
          for (var a2 = e2.onRecoverableError, o2 = 0; o2 < r2.length; o2++) {
            var s3 = r2[o2];
            a2(s3.value, { componentStack: s3.stack });
          }
        } finally {
          S.T = t3, C.p = i2;
        }
      }
      du & 3 && Ku(), sd(e2), i2 = e2.pendingLanes, n3 & 261930 && i2 & 42 ? e2 === gu ? hu++ : (hu = 0, gu = e2) : hu = 0, cd(0, false);
    }
  }
  function Gu(e2, t3) {
    (e2.pooledCacheLanes &= t3) === 0 && (t3 = e2.pooledCache, t3 != null && (e2.pooledCache = null, ba(t3)));
  }
  function Ku() {
    return Hu(), Uu(), Wu(), qu();
  }
  function qu() {
    if (Y !== 5) return false;
    var e2 = lu, t3 = fu;
    fu = 0;
    var n3 = vt(du), r2 = S.T, i2 = C.p;
    try {
      C.p = 32 > n3 ? 32 : n3, S.T = null, n3 = pu, pu = null;
      var a2 = lu, o2 = du;
      if (Y = 0, uu = lu = null, du = 0, U & 6) throw Error(u2(331));
      var s3 = U;
      if (U |= 4, Bl(a2.current), Ml(a2, a2.current, o2, n3), U = s3, cd(0, false), Ze && typeof Ze.onPostCommitFiberRoot == `function`) try {
        Ze.onPostCommitFiberRoot(Xe, a2);
      } catch {
      }
      return true;
    } finally {
      C.p = i2, S.T = r2, Gu(e2, t3);
    }
  }
  function Ju(e2, t3, n3) {
    t3 = Ni(n3, t3), t3 = sc(e2.stateNode, t3, 2), e2 = to(e2, t3, 2), e2 !== null && (ft(e2, 2), sd(e2));
  }
  function X(e2, t3, n3) {
    if (e2.tag === 3) Ju(e2, e2, n3);
    else for (; t3 !== null; ) {
      if (t3.tag === 3) {
        Ju(t3, e2, n3);
        break;
      }
      if (t3.tag === 1) {
        var r2 = t3.stateNode;
        if (typeof t3.type.getDerivedStateFromError == `function` || typeof r2.componentDidCatch == `function` && (cu === null || !cu.has(r2))) {
          e2 = Ni(n3, e2), n3 = cc(2), r2 = to(t3, n3, 2), r2 !== null && (lc(n3, r2, t3, e2), ft(r2, 2), sd(r2));
          break;
        }
      }
      t3 = t3.return;
    }
  }
  function Yu(e2, t3, n3) {
    var r2 = e2.pingCache;
    if (r2 === null) {
      r2 = e2.pingCache = new Wl();
      var i2 = /* @__PURE__ */ new Set();
      r2.set(t3, i2);
    } else i2 = r2.get(t3), i2 === void 0 && (i2 = /* @__PURE__ */ new Set(), r2.set(t3, i2));
    i2.has(n3) || (Jl = true, i2.add(n3), e2 = Xu.bind(null, e2, t3, n3), t3.then(e2, e2));
  }
  function Xu(e2, t3, n3) {
    var r2 = e2.pingCache;
    r2 !== null && r2.delete(t3), e2.pingedLanes |= e2.suspendedLanes & n3, e2.warmLanes &= ~n3, W === e2 && (K & n3) === n3 && (J === 4 || J === 3 && (K & 62914560) === K && 300 > Ve() - iu ? !(U & 2) && Eu(e2, 0) : Ql |= n3, eu === K && (eu = 0)), sd(e2);
  }
  function Zu(e2, t3) {
    t3 === 0 && (t3 = ut()), e2 = vi(e2, t3), e2 !== null && (ft(e2, t3), sd(e2));
  }
  function Qu(e2) {
    var t3 = e2.memoizedState, n3 = 0;
    t3 !== null && (n3 = t3.retryLane), Zu(e2, n3);
  }
  function $u(e2, t3) {
    var n3 = 0;
    switch (e2.tag) {
      case 31:
      case 13:
        var r2 = e2.stateNode, i2 = e2.memoizedState;
        i2 !== null && (n3 = i2.retryLane);
        break;
      case 19:
        r2 = e2.stateNode;
        break;
      case 22:
        r2 = e2.stateNode._retryCache;
        break;
      default:
        throw Error(u2(314));
    }
    r2 !== null && r2.delete(t3), Zu(e2, n3);
  }
  function ed(e2, t3) {
    return Le(e2, t3);
  }
  var td = null, nd = null, rd = false, id = false, ad = false, od = 0;
  function sd(e2) {
    e2 !== nd && e2.next === null && (nd === null ? td = nd = e2 : nd = nd.next = e2), id = true, rd || (rd = true, md());
  }
  function cd(e2, t3) {
    if (!ad && id) {
      ad = true;
      do
        for (var n3 = false, r2 = td; r2 !== null; ) {
          if (!t3) {
            if (e2 !== 0) {
              var i2 = r2.pendingLanes;
              if (i2 === 0) var a2 = 0;
              else {
                var o2 = r2.suspendedLanes, s3 = r2.pingedLanes;
                a2 = (1 << 31 - $e(42 | e2) + 1) - 1, a2 &= i2 & ~(o2 & ~s3), a2 = a2 & 201326741 ? a2 & 201326741 | 1 : a2 ? a2 | 2 : 0;
              }
              a2 !== 0 && (n3 = true, pd(r2, a2));
            } else a2 = K, a2 = st(r2, r2 === W ? a2 : 0, r2.cancelPendingCommit !== null || r2.timeoutHandle !== -1), !(a2 & 3) || ct(r2, a2) || (n3 = true, pd(r2, a2));
          }
          r2 = r2.next;
        }
      while (n3);
      ad = false;
    }
  }
  function ld() {
    ud();
  }
  function ud() {
    id = rd = false;
    var e2 = 0;
    od !== 0 && Jd() && (e2 = od);
    for (var t3 = Ve(), n3 = null, r2 = td; r2 !== null; ) {
      var i2 = r2.next, a2 = dd(r2, t3);
      a2 === 0 ? (r2.next = null, n3 === null ? td = i2 : n3.next = i2, i2 === null && (nd = n3)) : (n3 = r2, (e2 !== 0 || a2 & 3) && (id = true)), r2 = i2;
    }
    Y !== 0 && Y !== 5 || cd(e2, false), od !== 0 && (od = 0);
  }
  function dd(e2, t3) {
    for (var n3 = e2.suspendedLanes, r2 = e2.pingedLanes, i2 = e2.expirationTimes, a2 = e2.pendingLanes & -62914561; 0 < a2; ) {
      var o2 = 31 - $e(a2), s3 = 1 << o2, c2 = i2[o2];
      c2 === -1 ? ((s3 & n3) === 0 || (s3 & r2) !== 0) && (i2[o2] = lt(s3, t3)) : c2 <= t3 && (e2.expiredLanes |= s3), a2 &= ~s3;
    }
    if (t3 = W, n3 = K, n3 = st(e2, e2 === t3 ? n3 : 0, e2.cancelPendingCommit !== null || e2.timeoutHandle !== -1), r2 = e2.callbackNode, n3 === 0 || e2 === t3 && (q === 2 || q === 9) || e2.cancelPendingCommit !== null) return r2 !== null && r2 !== null && Re(r2), e2.callbackNode = null, e2.callbackPriority = 0;
    if (!(n3 & 3) || ct(e2, n3)) {
      if (t3 = n3 & -n3, t3 === e2.callbackPriority) return t3;
      switch (r2 !== null && Re(r2), vt(n3)) {
        case 2:
        case 8:
          n3 = We;
          break;
        case 32:
          n3 = Ge;
          break;
        case 268435456:
          n3 = qe;
          break;
        default:
          n3 = Ge;
      }
      return r2 = fd.bind(null, e2), n3 = Le(n3, r2), e2.callbackPriority = t3, e2.callbackNode = n3, t3;
    }
    return r2 !== null && r2 !== null && Re(r2), e2.callbackPriority = 2, e2.callbackNode = null, 2;
  }
  function fd(e2, t3) {
    if (Y !== 0 && Y !== 5) return e2.callbackNode = null, e2.callbackPriority = 0, null;
    var n3 = e2.callbackNode;
    if (Ku() && e2.callbackNode !== n3) return null;
    var r2 = K;
    return r2 = st(e2, e2 === W ? r2 : 0, e2.cancelPendingCommit !== null || e2.timeoutHandle !== -1), r2 === 0 ? null : (bu(e2, r2, t3), dd(e2, Ve()), e2.callbackNode != null && e2.callbackNode === n3 ? fd.bind(null, e2) : null);
  }
  function pd(e2, t3) {
    if (Ku()) return null;
    bu(e2, t3, true);
  }
  function md() {
    Qd(function() {
      U & 6 ? Le(Ue, ld) : ud();
    });
  }
  function hd() {
    if (od === 0) {
      var e2 = Ca;
      e2 === 0 && (e2 = rt, rt <<= 1, !(rt & 261888) && (rt = 256)), od = e2;
    }
    return od;
  }
  function gd(e2) {
    return e2 == null || typeof e2 == `symbol` || typeof e2 == `boolean` ? null : typeof e2 == `function` ? e2 : mn(`` + e2);
  }
  function _d(e2, t3) {
    var n3 = t3.ownerDocument.createElement(`input`);
    return n3.name = t3.name, n3.value = t3.value, e2.id && n3.setAttribute(`form`, e2.id), t3.parentNode.insertBefore(n3, t3), e2 = new FormData(e2), n3.parentNode.removeChild(n3), e2;
  }
  function vd(e2, t3, n3, r2, i2) {
    if (t3 === `submit` && n3 && n3.stateNode === i2) {
      var a2 = gd((i2[Ct] || null).action), o2 = r2.submitter;
      o2 && (t3 = (t3 = o2[Ct] || null) ? gd(t3.formAction) : o2.getAttribute(`formAction`), t3 !== null && (a2 = t3, o2 = null));
      var s3 = new In(`action`, `action`, null, r2, i2);
      e2.push({ event: s3, listeners: [{ instance: null, listener: function() {
        if (r2.defaultPrevented) {
          if (od !== 0) {
            var e3 = o2 ? _d(i2, o2) : new FormData(i2);
            Ns(n3, { pending: true, data: e3, method: i2.method, action: a2 }, null, e3);
          }
        } else typeof a2 == `function` && (s3.preventDefault(), e3 = o2 ? _d(i2, o2) : new FormData(i2), Ns(n3, { pending: true, data: e3, method: i2.method, action: a2 }, a2, e3));
      }, currentTarget: i2 }] });
    }
  }
  for (var yd = 0; yd < li.length; yd++) {
    var bd = li[yd];
    ui(bd.toLowerCase(), `on` + (bd[0].toUpperCase() + bd.slice(1)));
  }
  ui(ti, `onAnimationEnd`), ui(ni, `onAnimationIteration`), ui(ri, `onAnimationStart`), ui(`dblclick`, `onDoubleClick`), ui(`focusin`, `onFocus`), ui(`focusout`, `onBlur`), ui(ii, `onTransitionRun`), ui(ai, `onTransitionStart`), ui(oi, `onTransitionCancel`), ui(si, `onTransitionEnd`), Rt(`onMouseEnter`, [`mouseout`, `mouseover`]), Rt(`onMouseLeave`, [`mouseout`, `mouseover`]), Rt(`onPointerEnter`, [`pointerout`, `pointerover`]), Rt(`onPointerLeave`, [`pointerout`, `pointerover`]), Lt(`onChange`, `change click focusin focusout input keydown keyup selectionchange`.split(` `)), Lt(`onSelect`, `focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)), Lt(`onBeforeInput`, [`compositionend`, `keypress`, `textInput`, `paste`]), Lt(`onCompositionEnd`, `compositionend focusout keydown keypress keyup mousedown`.split(` `)), Lt(`onCompositionStart`, `compositionstart focusout keydown keypress keyup mousedown`.split(` `)), Lt(`onCompositionUpdate`, `compositionupdate focusout keydown keypress keyup mousedown`.split(` `));
  var xd = `abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `), Sd = new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(xd));
  function Cd(e2, t3) {
    t3 = !!(t3 & 4);
    for (var n3 = 0; n3 < e2.length; n3++) {
      var r2 = e2[n3], i2 = r2.event;
      r2 = r2.listeners;
      a: {
        var a2 = void 0;
        if (t3) for (var o2 = r2.length - 1; 0 <= o2; o2--) {
          var s3 = r2[o2], c2 = s3.instance, l3 = s3.currentTarget;
          if (s3 = s3.listener, c2 !== a2 && i2.isPropagationStopped()) break a;
          a2 = s3, i2.currentTarget = l3;
          try {
            a2(i2);
          } catch (e3) {
            di(e3);
          }
          i2.currentTarget = null, a2 = c2;
        }
        else for (o2 = 0; o2 < r2.length; o2++) {
          if (s3 = r2[o2], c2 = s3.instance, l3 = s3.currentTarget, s3 = s3.listener, c2 !== a2 && i2.isPropagationStopped()) break a;
          a2 = s3, i2.currentTarget = l3;
          try {
            a2(i2);
          } catch (e3) {
            di(e3);
          }
          i2.currentTarget = null, a2 = c2;
        }
      }
    }
  }
  function Z(e2, t3) {
    var n3 = t3[Tt];
    n3 === void 0 && (n3 = t3[Tt] = /* @__PURE__ */ new Set());
    var r2 = e2 + `__bubble`;
    n3.has(r2) || (Dd(t3, e2, 2, false), n3.add(r2));
  }
  function wd(e2, t3, n3) {
    var r2 = 0;
    t3 && (r2 |= 4), Dd(n3, e2, r2, t3);
  }
  var Td = `_reactListening` + Math.random().toString(36).slice(2);
  function Ed(e2) {
    if (!e2[Td]) {
      e2[Td] = true, Ft.forEach(function(t4) {
        t4 !== `selectionchange` && (Sd.has(t4) || wd(t4, false, e2), wd(t4, true, e2));
      });
      var t3 = e2.nodeType === 9 ? e2 : e2.ownerDocument;
      t3 === null || t3[Td] || (t3[Td] = true, wd(`selectionchange`, false, t3));
    }
  }
  function Dd(e2, t3, n3, r2) {
    switch (_p(t3)) {
      case 2:
        var i2 = dp;
        break;
      case 8:
        i2 = fp;
        break;
      default:
        i2 = pp;
    }
    n3 = i2.bind(null, t3, n3, e2), i2 = void 0, !Tn || t3 !== `touchstart` && t3 !== `touchmove` && t3 !== `wheel` || (i2 = true), r2 ? i2 === void 0 ? e2.addEventListener(t3, n3, true) : e2.addEventListener(t3, n3, { capture: true, passive: i2 }) : i2 === void 0 ? e2.addEventListener(t3, n3, false) : e2.addEventListener(t3, n3, { passive: i2 });
  }
  function Od(e2, t3, n3, r2, i2) {
    var a2 = r2;
    if (!(t3 & 1) && !(t3 & 2) && r2 !== null) a: for (; ; ) {
      if (r2 === null) return;
      var o2 = r2.tag;
      if (o2 === 3 || o2 === 4) {
        var s3 = r2.stateNode.containerInfo;
        if (s3 === i2) break;
        if (o2 === 4) for (o2 = r2.return; o2 !== null; ) {
          var c2 = o2.tag;
          if ((c2 === 3 || c2 === 4) && o2.stateNode.containerInfo === i2) return;
          o2 = o2.return;
        }
        for (; s3 !== null; ) {
          if (o2 = jt(s3), o2 === null) return;
          if (c2 = o2.tag, c2 === 5 || c2 === 6 || c2 === 26 || c2 === 27) {
            r2 = a2 = o2;
            continue a;
          }
          s3 = s3.parentNode;
        }
      }
      r2 = r2.return;
    }
    Sn(function() {
      var r3 = a2, i3 = _n(n3), o3 = [];
      a: {
        var s4 = ci.get(e2);
        if (s4 !== void 0) {
          var c3 = In, l3 = e2;
          switch (e2) {
            case `keypress`:
              if (jn(n3) === 0) break a;
            case `keydown`:
            case `keyup`:
              c3 = er;
              break;
            case `focusin`:
              l3 = `focus`, c3 = Gn;
              break;
            case `focusout`:
              l3 = `blur`, c3 = Gn;
              break;
            case `beforeblur`:
            case `afterblur`:
              c3 = Gn;
              break;
            case `click`:
              if (n3.button === 2) break a;
            case `auxclick`:
            case `dblclick`:
            case `mousedown`:
            case `mousemove`:
            case `mouseup`:
            case `mouseout`:
            case `mouseover`:
            case `contextmenu`:
              c3 = Un;
              break;
            case `drag`:
            case `dragend`:
            case `dragenter`:
            case `dragexit`:
            case `dragleave`:
            case `dragover`:
            case `dragstart`:
            case `drop`:
              c3 = Wn;
              break;
            case `touchcancel`:
            case `touchend`:
            case `touchmove`:
            case `touchstart`:
              c3 = nr;
              break;
            case ti:
            case ni:
            case ri:
              c3 = Kn;
              break;
            case si:
              c3 = rr;
              break;
            case `scroll`:
            case `scrollend`:
              c3 = Rn;
              break;
            case `wheel`:
              c3 = ir;
              break;
            case `copy`:
            case `cut`:
            case `paste`:
              c3 = qn;
              break;
            case `gotpointercapture`:
            case `lostpointercapture`:
            case `pointercancel`:
            case `pointerdown`:
            case `pointermove`:
            case `pointerout`:
            case `pointerover`:
            case `pointerup`:
              c3 = tr;
              break;
            case `toggle`:
            case `beforetoggle`:
              c3 = ar;
          }
          var u3 = !!(t3 & 4), d3 = !u3 && (e2 === `scroll` || e2 === `scrollend`), p3 = u3 ? s4 === null ? null : s4 + `Capture` : s4;
          u3 = [];
          for (var m3 = r3, h3; m3 !== null; ) {
            var g2 = m3;
            if (h3 = g2.stateNode, g2 = g2.tag, g2 !== 5 && g2 !== 26 && g2 !== 27 || h3 === null || p3 === null || (g2 = Cn(m3, p3), g2 != null && u3.push(kd(m3, g2, h3))), d3) break;
            m3 = m3.return;
          }
          0 < u3.length && (s4 = new c3(s4, l3, null, n3, i3), o3.push({ event: s4, listeners: u3 }));
        }
      }
      if (!(t3 & 7)) {
        a: {
          if (s4 = e2 === `mouseover` || e2 === `pointerover`, c3 = e2 === `mouseout` || e2 === `pointerout`, s4 && n3 !== gn && (l3 = n3.relatedTarget || n3.fromElement) && (jt(l3) || l3[wt])) break a;
          if ((c3 || s4) && (s4 = i3.window === i3 ? i3 : (s4 = i3.ownerDocument) ? s4.defaultView || s4.parentWindow : window, c3 ? (l3 = n3.relatedTarget || n3.toElement, c3 = r3, l3 = l3 ? jt(l3) : null, l3 !== null && (d3 = f2(l3), u3 = l3.tag, l3 !== d3 || u3 !== 5 && u3 !== 27 && u3 !== 6) && (l3 = null)) : (c3 = null, l3 = r3), c3 !== l3)) {
            if (u3 = Un, g2 = `onMouseLeave`, p3 = `onMouseEnter`, m3 = `mouse`, (e2 === `pointerout` || e2 === `pointerover`) && (u3 = tr, g2 = `onPointerLeave`, p3 = `onPointerEnter`, m3 = `pointer`), d3 = c3 == null ? s4 : Nt(c3), h3 = l3 == null ? s4 : Nt(l3), s4 = new u3(g2, m3 + `leave`, c3, n3, i3), s4.target = d3, s4.relatedTarget = h3, g2 = null, jt(i3) === r3 && (u3 = new u3(p3, m3 + `enter`, l3, n3, i3), u3.target = h3, u3.relatedTarget = d3, g2 = u3), d3 = g2, c3 && l3) b: {
              for (u3 = jd, p3 = c3, m3 = l3, h3 = 0, g2 = p3; g2; g2 = u3(g2)) h3++;
              g2 = 0;
              for (var _2 = m3; _2; _2 = u3(_2)) g2++;
              for (; 0 < h3 - g2; ) p3 = u3(p3), h3--;
              for (; 0 < g2 - h3; ) m3 = u3(m3), g2--;
              for (; h3--; ) {
                if (p3 === m3 || m3 !== null && p3 === m3.alternate) {
                  u3 = p3;
                  break b;
                }
                p3 = u3(p3), m3 = u3(m3);
              }
              u3 = null;
            }
            else u3 = null;
            c3 !== null && Md(o3, s4, c3, u3, false), l3 !== null && d3 !== null && Md(o3, d3, l3, u3, true);
          }
        }
        a: {
          if (s4 = r3 ? Nt(r3) : window, c3 = s4.nodeName && s4.nodeName.toLowerCase(), c3 === `select` || c3 === `input` && s4.type === `file`) var v2 = Tr;
          else if (yr(s4)) {
            if (Er) v2 = Fr;
            else {
              v2 = Nr;
              var y2 = Mr;
            }
          } else c3 = s4.nodeName, !c3 || c3.toLowerCase() !== `input` || s4.type !== `checkbox` && s4.type !== `radio` ? r3 && dn(r3.elementType) && (v2 = Tr) : v2 = Pr;
          if (v2 && (v2 = v2(e2, r3))) {
            br(o3, v2, n3, i3);
            break a;
          }
          y2 && y2(e2, s4, r3), e2 === `focusout` && r3 && s4.type === `number` && r3.memoizedProps.value != null && nn(s4, `number`, s4.value);
        }
        switch (y2 = r3 ? Nt(r3) : window, e2) {
          case `focusin`:
            (yr(y2) || y2.contentEditable === `true`) && (Gr = y2, Kr = r3, qr = null);
            break;
          case `focusout`:
            qr = Kr = Gr = null;
            break;
          case `mousedown`:
            Jr = true;
            break;
          case `contextmenu`:
          case `mouseup`:
          case `dragend`:
            Jr = false, Yr(o3, n3, i3);
            break;
          case `selectionchange`:
            if (Wr) break;
          case `keydown`:
          case `keyup`:
            Yr(o3, n3, i3);
        }
        var b2;
        if (sr) b: {
          switch (e2) {
            case `compositionstart`:
              var x2 = `onCompositionStart`;
              break b;
            case `compositionend`:
              x2 = `onCompositionEnd`;
              break b;
            case `compositionupdate`:
              x2 = `onCompositionUpdate`;
              break b;
          }
          x2 = void 0;
        }
        else hr ? pr(e2, n3) && (x2 = `onCompositionEnd`) : e2 === `keydown` && n3.keyCode === 229 && (x2 = `onCompositionStart`);
        x2 && (ur && n3.locale !== `ko` && (hr || x2 !== `onCompositionStart` ? x2 === `onCompositionEnd` && hr && (b2 = An()) : (Dn = i3, On = `value` in Dn ? Dn.value : Dn.textContent, hr = true)), y2 = Ad(r3, x2), 0 < y2.length && (x2 = new Jn(x2, e2, null, n3, i3), o3.push({ event: x2, listeners: y2 }), b2 ? x2.data = b2 : (b2 = mr(n3), b2 !== null && (x2.data = b2)))), (b2 = lr ? gr(e2, n3) : _r(e2, n3)) && (x2 = Ad(r3, `onBeforeInput`), 0 < x2.length && (y2 = new Jn(`onBeforeInput`, `beforeinput`, null, n3, i3), o3.push({ event: y2, listeners: x2 }), y2.data = b2)), vd(o3, e2, r3, n3, i3);
      }
      Cd(o3, t3);
    });
  }
  function kd(e2, t3, n3) {
    return { instance: e2, listener: t3, currentTarget: n3 };
  }
  function Ad(e2, t3) {
    for (var n3 = t3 + `Capture`, r2 = []; e2 !== null; ) {
      var i2 = e2, a2 = i2.stateNode;
      if (i2 = i2.tag, i2 !== 5 && i2 !== 26 && i2 !== 27 || a2 === null || (i2 = Cn(e2, n3), i2 != null && r2.unshift(kd(e2, i2, a2)), i2 = Cn(e2, t3), i2 != null && r2.push(kd(e2, i2, a2))), e2.tag === 3) return r2;
      e2 = e2.return;
    }
    return [];
  }
  function jd(e2) {
    if (e2 === null) return null;
    do
      e2 = e2.return;
    while (e2 && e2.tag !== 5 && e2.tag !== 27);
    return e2 || null;
  }
  function Md(e2, t3, n3, r2, i2) {
    for (var a2 = t3._reactName, o2 = []; n3 !== null && n3 !== r2; ) {
      var s3 = n3, c2 = s3.alternate, l3 = s3.stateNode;
      if (s3 = s3.tag, c2 !== null && c2 === r2) break;
      s3 !== 5 && s3 !== 26 && s3 !== 27 || l3 === null || (c2 = l3, i2 ? (l3 = Cn(n3, a2), l3 != null && o2.unshift(kd(n3, l3, c2))) : i2 || (l3 = Cn(n3, a2), l3 != null && o2.push(kd(n3, l3, c2)))), n3 = n3.return;
    }
    o2.length !== 0 && e2.push({ event: t3, listeners: o2 });
  }
  var Nd = /\r\n?/g, Pd = /\u0000|\uFFFD/g;
  function Fd(e2) {
    return (typeof e2 == `string` ? e2 : `` + e2).replace(Nd, `
`).replace(Pd, ``);
  }
  function Id(e2, t3) {
    return t3 = Fd(t3), Fd(e2) === t3;
  }
  function Q(e2, t3, n3, r2, i2, a2) {
    switch (n3) {
      case `children`:
        typeof r2 == `string` ? t3 === `body` || t3 === `textarea` && r2 === `` || sn(e2, r2) : (typeof r2 == `number` || typeof r2 == `bigint`) && t3 !== `body` && sn(e2, `` + r2);
        break;
      case `className`:
        Wt(e2, `class`, r2);
        break;
      case `tabIndex`:
        Wt(e2, `tabindex`, r2);
        break;
      case `dir`:
      case `role`:
      case `viewBox`:
      case `width`:
      case `height`:
        Wt(e2, n3, r2);
        break;
      case `style`:
        un(e2, r2, a2);
        break;
      case `data`:
        if (t3 !== `object`) {
          Wt(e2, `data`, r2);
          break;
        }
      case `src`:
      case `href`:
        if (r2 === `` && (t3 !== `a` || n3 !== `href`)) {
          e2.removeAttribute(n3);
          break;
        }
        if (r2 == null || typeof r2 == `function` || typeof r2 == `symbol` || typeof r2 == `boolean`) {
          e2.removeAttribute(n3);
          break;
        }
        r2 = mn(`` + r2), e2.setAttribute(n3, r2);
        break;
      case `action`:
      case `formAction`:
        if (typeof r2 == `function`) {
          e2.setAttribute(n3, `javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);
          break;
        }
        if (typeof a2 == `function` && (n3 === `formAction` ? (t3 !== `input` && Q(e2, t3, `name`, i2.name, i2, null), Q(e2, t3, `formEncType`, i2.formEncType, i2, null), Q(e2, t3, `formMethod`, i2.formMethod, i2, null), Q(e2, t3, `formTarget`, i2.formTarget, i2, null)) : (Q(e2, t3, `encType`, i2.encType, i2, null), Q(e2, t3, `method`, i2.method, i2, null), Q(e2, t3, `target`, i2.target, i2, null))), r2 == null || typeof r2 == `symbol` || typeof r2 == `boolean`) {
          e2.removeAttribute(n3);
          break;
        }
        r2 = mn(`` + r2), e2.setAttribute(n3, r2);
        break;
      case `onClick`:
        r2 != null && (e2.onclick = hn);
        break;
      case `onScroll`:
        r2 != null && Z(`scroll`, e2);
        break;
      case `onScrollEnd`:
        r2 != null && Z(`scrollend`, e2);
        break;
      case `dangerouslySetInnerHTML`:
        if (r2 != null) {
          if (typeof r2 != `object` || !(`__html` in r2)) throw Error(u2(61));
          if (n3 = r2.__html, n3 != null) {
            if (i2.children != null) throw Error(u2(60));
            e2.innerHTML = n3;
          }
        }
        break;
      case `multiple`:
        e2.multiple = r2 && typeof r2 != `function` && typeof r2 != `symbol`;
        break;
      case `muted`:
        e2.muted = r2 && typeof r2 != `function` && typeof r2 != `symbol`;
        break;
      case `suppressContentEditableWarning`:
      case `suppressHydrationWarning`:
      case `defaultValue`:
      case `defaultChecked`:
      case `innerHTML`:
      case `ref`:
        break;
      case `autoFocus`:
        break;
      case `xlinkHref`:
        if (r2 == null || typeof r2 == `function` || typeof r2 == `boolean` || typeof r2 == `symbol`) {
          e2.removeAttribute(`xlink:href`);
          break;
        }
        n3 = mn(`` + r2), e2.setAttributeNS(`http://www.w3.org/1999/xlink`, `xlink:href`, n3);
        break;
      case `contentEditable`:
      case `spellCheck`:
      case `draggable`:
      case `value`:
      case `autoReverse`:
      case `externalResourcesRequired`:
      case `focusable`:
      case `preserveAlpha`:
        r2 != null && typeof r2 != `function` && typeof r2 != `symbol` ? e2.setAttribute(n3, `` + r2) : e2.removeAttribute(n3);
        break;
      case `inert`:
      case `allowFullScreen`:
      case `async`:
      case `autoPlay`:
      case `controls`:
      case `default`:
      case `defer`:
      case `disabled`:
      case `disablePictureInPicture`:
      case `disableRemotePlayback`:
      case `formNoValidate`:
      case `hidden`:
      case `loop`:
      case `noModule`:
      case `noValidate`:
      case `open`:
      case `playsInline`:
      case `readOnly`:
      case `required`:
      case `reversed`:
      case `scoped`:
      case `seamless`:
      case `itemScope`:
        r2 && typeof r2 != `function` && typeof r2 != `symbol` ? e2.setAttribute(n3, ``) : e2.removeAttribute(n3);
        break;
      case `capture`:
      case `download`:
        true === r2 ? e2.setAttribute(n3, ``) : false !== r2 && r2 != null && typeof r2 != `function` && typeof r2 != `symbol` ? e2.setAttribute(n3, r2) : e2.removeAttribute(n3);
        break;
      case `cols`:
      case `rows`:
      case `size`:
      case `span`:
        r2 != null && typeof r2 != `function` && typeof r2 != `symbol` && !isNaN(r2) && 1 <= r2 ? e2.setAttribute(n3, r2) : e2.removeAttribute(n3);
        break;
      case `rowSpan`:
      case `start`:
        r2 == null || typeof r2 == `function` || typeof r2 == `symbol` || isNaN(r2) ? e2.removeAttribute(n3) : e2.setAttribute(n3, r2);
        break;
      case `popover`:
        Z(`beforetoggle`, e2), Z(`toggle`, e2), Ut(e2, `popover`, r2);
        break;
      case `xlinkActuate`:
        Gt(e2, `http://www.w3.org/1999/xlink`, `xlink:actuate`, r2);
        break;
      case `xlinkArcrole`:
        Gt(e2, `http://www.w3.org/1999/xlink`, `xlink:arcrole`, r2);
        break;
      case `xlinkRole`:
        Gt(e2, `http://www.w3.org/1999/xlink`, `xlink:role`, r2);
        break;
      case `xlinkShow`:
        Gt(e2, `http://www.w3.org/1999/xlink`, `xlink:show`, r2);
        break;
      case `xlinkTitle`:
        Gt(e2, `http://www.w3.org/1999/xlink`, `xlink:title`, r2);
        break;
      case `xlinkType`:
        Gt(e2, `http://www.w3.org/1999/xlink`, `xlink:type`, r2);
        break;
      case `xmlBase`:
        Gt(e2, `http://www.w3.org/XML/1998/namespace`, `xml:base`, r2);
        break;
      case `xmlLang`:
        Gt(e2, `http://www.w3.org/XML/1998/namespace`, `xml:lang`, r2);
        break;
      case `xmlSpace`:
        Gt(e2, `http://www.w3.org/XML/1998/namespace`, `xml:space`, r2);
        break;
      case `is`:
        Ut(e2, `is`, r2);
        break;
      case `innerText`:
      case `textContent`:
        break;
      default:
        (!(2 < n3.length) || n3[0] !== `o` && n3[0] !== `O` || n3[1] !== `n` && n3[1] !== `N`) && (n3 = fn.get(n3) || n3, Ut(e2, n3, r2));
    }
  }
  function Ld(e2, t3, n3, r2, i2, a2) {
    switch (n3) {
      case `style`:
        un(e2, r2, a2);
        break;
      case `dangerouslySetInnerHTML`:
        if (r2 != null) {
          if (typeof r2 != `object` || !(`__html` in r2)) throw Error(u2(61));
          if (n3 = r2.__html, n3 != null) {
            if (i2.children != null) throw Error(u2(60));
            e2.innerHTML = n3;
          }
        }
        break;
      case `children`:
        typeof r2 == `string` ? sn(e2, r2) : (typeof r2 == `number` || typeof r2 == `bigint`) && sn(e2, `` + r2);
        break;
      case `onScroll`:
        r2 != null && Z(`scroll`, e2);
        break;
      case `onScrollEnd`:
        r2 != null && Z(`scrollend`, e2);
        break;
      case `onClick`:
        r2 != null && (e2.onclick = hn);
        break;
      case `suppressContentEditableWarning`:
      case `suppressHydrationWarning`:
      case `innerHTML`:
      case `ref`:
        break;
      case `innerText`:
      case `textContent`:
        break;
      default:
        if (!It.hasOwnProperty(n3)) a: {
          if (n3[0] === `o` && n3[1] === `n` && (i2 = n3.endsWith(`Capture`), t3 = n3.slice(2, i2 ? n3.length - 7 : void 0), a2 = e2[Ct] || null, a2 = a2 == null ? null : a2[n3], typeof a2 == `function` && e2.removeEventListener(t3, a2, i2), typeof r2 == `function`)) {
            typeof a2 != `function` && a2 !== null && (n3 in e2 ? e2[n3] = null : e2.hasAttribute(n3) && e2.removeAttribute(n3)), e2.addEventListener(t3, r2, i2);
            break a;
          }
          n3 in e2 ? e2[n3] = r2 : true === r2 ? e2.setAttribute(n3, ``) : Ut(e2, n3, r2);
        }
    }
  }
  function $(e2, t3, n3) {
    switch (t3) {
      case `div`:
      case `span`:
      case `svg`:
      case `path`:
      case `a`:
      case `g`:
      case `p`:
      case `li`:
        break;
      case `img`:
        Z(`error`, e2), Z(`load`, e2);
        var r2 = false, i2 = false, a2;
        for (a2 in n3) if (n3.hasOwnProperty(a2)) {
          var o2 = n3[a2];
          if (o2 != null) switch (a2) {
            case `src`:
              r2 = true;
              break;
            case `srcSet`:
              i2 = true;
              break;
            case `children`:
            case `dangerouslySetInnerHTML`:
              throw Error(u2(137, t3));
            default:
              Q(e2, t3, a2, o2, n3, null);
          }
        }
        i2 && Q(e2, t3, `srcSet`, n3.srcSet, n3, null), r2 && Q(e2, t3, `src`, n3.src, n3, null);
        return;
      case `input`:
        Z(`invalid`, e2);
        var s3 = a2 = o2 = i2 = null, c2 = null, l3 = null;
        for (r2 in n3) if (n3.hasOwnProperty(r2)) {
          var d3 = n3[r2];
          if (d3 != null) switch (r2) {
            case `name`:
              i2 = d3;
              break;
            case `type`:
              o2 = d3;
              break;
            case `checked`:
              c2 = d3;
              break;
            case `defaultChecked`:
              l3 = d3;
              break;
            case `value`:
              a2 = d3;
              break;
            case `defaultValue`:
              s3 = d3;
              break;
            case `children`:
            case `dangerouslySetInnerHTML`:
              if (d3 != null) throw Error(u2(137, t3));
              break;
            default:
              Q(e2, t3, r2, d3, n3, null);
          }
        }
        tn(e2, a2, s3, c2, l3, o2, i2, false);
        return;
      case `select`:
        for (i2 in Z(`invalid`, e2), r2 = o2 = a2 = null, n3) if (n3.hasOwnProperty(i2) && (s3 = n3[i2], s3 != null)) switch (i2) {
          case `value`:
            a2 = s3;
            break;
          case `defaultValue`:
            o2 = s3;
            break;
          case `multiple`:
            r2 = s3;
          default:
            Q(e2, t3, i2, s3, n3, null);
        }
        t3 = a2, n3 = o2, e2.multiple = !!r2, t3 == null ? n3 != null && rn(e2, !!r2, n3, true) : rn(e2, !!r2, t3, false);
        return;
      case `textarea`:
        for (o2 in Z(`invalid`, e2), a2 = i2 = r2 = null, n3) if (n3.hasOwnProperty(o2) && (s3 = n3[o2], s3 != null)) switch (o2) {
          case `value`:
            r2 = s3;
            break;
          case `defaultValue`:
            i2 = s3;
            break;
          case `children`:
            a2 = s3;
            break;
          case `dangerouslySetInnerHTML`:
            if (s3 != null) throw Error(u2(91));
            break;
          default:
            Q(e2, t3, o2, s3, n3, null);
        }
        on(e2, r2, i2, a2);
        return;
      case `option`:
        for (c2 in n3) if (n3.hasOwnProperty(c2) && (r2 = n3[c2], r2 != null)) switch (c2) {
          case `selected`:
            e2.selected = r2 && typeof r2 != `function` && typeof r2 != `symbol`;
            break;
          default:
            Q(e2, t3, c2, r2, n3, null);
        }
        return;
      case `dialog`:
        Z(`beforetoggle`, e2), Z(`toggle`, e2), Z(`cancel`, e2), Z(`close`, e2);
        break;
      case `iframe`:
      case `object`:
        Z(`load`, e2);
        break;
      case `video`:
      case `audio`:
        for (r2 = 0; r2 < xd.length; r2++) Z(xd[r2], e2);
        break;
      case `image`:
        Z(`error`, e2), Z(`load`, e2);
        break;
      case `details`:
        Z(`toggle`, e2);
        break;
      case `embed`:
      case `source`:
      case `link`:
        Z(`error`, e2), Z(`load`, e2);
      case `area`:
      case `base`:
      case `br`:
      case `col`:
      case `hr`:
      case `keygen`:
      case `meta`:
      case `param`:
      case `track`:
      case `wbr`:
      case `menuitem`:
        for (l3 in n3) if (n3.hasOwnProperty(l3) && (r2 = n3[l3], r2 != null)) switch (l3) {
          case `children`:
          case `dangerouslySetInnerHTML`:
            throw Error(u2(137, t3));
          default:
            Q(e2, t3, l3, r2, n3, null);
        }
        return;
      default:
        if (dn(t3)) {
          for (d3 in n3) n3.hasOwnProperty(d3) && (r2 = n3[d3], r2 !== void 0 && Ld(e2, t3, d3, r2, n3, void 0));
          return;
        }
    }
    for (s3 in n3) n3.hasOwnProperty(s3) && (r2 = n3[s3], r2 != null && Q(e2, t3, s3, r2, n3, null));
  }
  function Rd(e2, t3, n3, r2) {
    switch (t3) {
      case `div`:
      case `span`:
      case `svg`:
      case `path`:
      case `a`:
      case `g`:
      case `p`:
      case `li`:
        break;
      case `input`:
        var i2 = null, a2 = null, o2 = null, s3 = null, c2 = null, l3 = null, d3 = null;
        for (m3 in n3) {
          var f3 = n3[m3];
          if (n3.hasOwnProperty(m3) && f3 != null) switch (m3) {
            case `checked`:
              break;
            case `value`:
              break;
            case `defaultValue`:
              c2 = f3;
            default:
              r2.hasOwnProperty(m3) || Q(e2, t3, m3, null, r2, f3);
          }
        }
        for (var p3 in r2) {
          var m3 = r2[p3];
          if (f3 = n3[p3], r2.hasOwnProperty(p3) && (m3 != null || f3 != null)) switch (p3) {
            case `type`:
              a2 = m3;
              break;
            case `name`:
              i2 = m3;
              break;
            case `checked`:
              l3 = m3;
              break;
            case `defaultChecked`:
              d3 = m3;
              break;
            case `value`:
              o2 = m3;
              break;
            case `defaultValue`:
              s3 = m3;
              break;
            case `children`:
            case `dangerouslySetInnerHTML`:
              if (m3 != null) throw Error(u2(137, t3));
              break;
            default:
              m3 !== f3 && Q(e2, t3, p3, m3, r2, f3);
          }
        }
        en(e2, o2, s3, c2, l3, d3, a2, i2);
        return;
      case `select`:
        for (a2 in m3 = o2 = s3 = p3 = null, n3) if (c2 = n3[a2], n3.hasOwnProperty(a2) && c2 != null) switch (a2) {
          case `value`:
            break;
          case `multiple`:
            m3 = c2;
          default:
            r2.hasOwnProperty(a2) || Q(e2, t3, a2, null, r2, c2);
        }
        for (i2 in r2) if (a2 = r2[i2], c2 = n3[i2], r2.hasOwnProperty(i2) && (a2 != null || c2 != null)) switch (i2) {
          case `value`:
            p3 = a2;
            break;
          case `defaultValue`:
            s3 = a2;
            break;
          case `multiple`:
            o2 = a2;
          default:
            a2 !== c2 && Q(e2, t3, i2, a2, r2, c2);
        }
        t3 = s3, n3 = o2, r2 = m3, p3 == null ? !!r2 != !!n3 && (t3 == null ? rn(e2, !!n3, n3 ? [] : ``, false) : rn(e2, !!n3, t3, true)) : rn(e2, !!n3, p3, false);
        return;
      case `textarea`:
        for (s3 in m3 = p3 = null, n3) if (i2 = n3[s3], n3.hasOwnProperty(s3) && i2 != null && !r2.hasOwnProperty(s3)) switch (s3) {
          case `value`:
            break;
          case `children`:
            break;
          default:
            Q(e2, t3, s3, null, r2, i2);
        }
        for (o2 in r2) if (i2 = r2[o2], a2 = n3[o2], r2.hasOwnProperty(o2) && (i2 != null || a2 != null)) switch (o2) {
          case `value`:
            p3 = i2;
            break;
          case `defaultValue`:
            m3 = i2;
            break;
          case `children`:
            break;
          case `dangerouslySetInnerHTML`:
            if (i2 != null) throw Error(u2(91));
            break;
          default:
            i2 !== a2 && Q(e2, t3, o2, i2, r2, a2);
        }
        an(e2, p3, m3);
        return;
      case `option`:
        for (var h3 in n3) if (p3 = n3[h3], n3.hasOwnProperty(h3) && p3 != null && !r2.hasOwnProperty(h3)) switch (h3) {
          case `selected`:
            e2.selected = false;
            break;
          default:
            Q(e2, t3, h3, null, r2, p3);
        }
        for (c2 in r2) if (p3 = r2[c2], m3 = n3[c2], r2.hasOwnProperty(c2) && p3 !== m3 && (p3 != null || m3 != null)) switch (c2) {
          case `selected`:
            e2.selected = p3 && typeof p3 != `function` && typeof p3 != `symbol`;
            break;
          default:
            Q(e2, t3, c2, p3, r2, m3);
        }
        return;
      case `img`:
      case `link`:
      case `area`:
      case `base`:
      case `br`:
      case `col`:
      case `embed`:
      case `hr`:
      case `keygen`:
      case `meta`:
      case `param`:
      case `source`:
      case `track`:
      case `wbr`:
      case `menuitem`:
        for (var g2 in n3) p3 = n3[g2], n3.hasOwnProperty(g2) && p3 != null && !r2.hasOwnProperty(g2) && Q(e2, t3, g2, null, r2, p3);
        for (l3 in r2) if (p3 = r2[l3], m3 = n3[l3], r2.hasOwnProperty(l3) && p3 !== m3 && (p3 != null || m3 != null)) switch (l3) {
          case `children`:
          case `dangerouslySetInnerHTML`:
            if (p3 != null) throw Error(u2(137, t3));
            break;
          default:
            Q(e2, t3, l3, p3, r2, m3);
        }
        return;
      default:
        if (dn(t3)) {
          for (var _2 in n3) p3 = n3[_2], n3.hasOwnProperty(_2) && p3 !== void 0 && !r2.hasOwnProperty(_2) && Ld(e2, t3, _2, void 0, r2, p3);
          for (d3 in r2) p3 = r2[d3], m3 = n3[d3], !r2.hasOwnProperty(d3) || p3 === m3 || p3 === void 0 && m3 === void 0 || Ld(e2, t3, d3, p3, r2, m3);
          return;
        }
    }
    for (var v2 in n3) p3 = n3[v2], n3.hasOwnProperty(v2) && p3 != null && !r2.hasOwnProperty(v2) && Q(e2, t3, v2, null, r2, p3);
    for (f3 in r2) p3 = r2[f3], m3 = n3[f3], !r2.hasOwnProperty(f3) || p3 === m3 || p3 == null && m3 == null || Q(e2, t3, f3, p3, r2, m3);
  }
  function zd(e2) {
    switch (e2) {
      case `css`:
      case `script`:
      case `font`:
      case `img`:
      case `image`:
      case `input`:
      case `link`:
        return true;
      default:
        return false;
    }
  }
  function Bd() {
    if (typeof performance.getEntriesByType == `function`) {
      for (var e2 = 0, t3 = 0, n3 = performance.getEntriesByType(`resource`), r2 = 0; r2 < n3.length; r2++) {
        var i2 = n3[r2], a2 = i2.transferSize, o2 = i2.initiatorType, s3 = i2.duration;
        if (a2 && s3 && zd(o2)) {
          for (o2 = 0, s3 = i2.responseEnd, r2 += 1; r2 < n3.length; r2++) {
            var c2 = n3[r2], l3 = c2.startTime;
            if (l3 > s3) break;
            var u3 = c2.transferSize, d3 = c2.initiatorType;
            u3 && zd(d3) && (c2 = c2.responseEnd, o2 += u3 * (c2 < s3 ? 1 : (s3 - l3) / (c2 - l3)));
          }
          if (--r2, t3 += 8 * (a2 + o2) / (i2.duration / 1e3), e2++, 10 < e2) break;
        }
      }
      if (0 < e2) return t3 / e2 / 1e6;
    }
    return navigator.connection && (e2 = navigator.connection.downlink, typeof e2 == `number`) ? e2 : 5;
  }
  var Vd = null, Hd = null;
  function Ud(e2) {
    return e2.nodeType === 9 ? e2 : e2.ownerDocument;
  }
  function Wd(e2) {
    switch (e2) {
      case `http://www.w3.org/2000/svg`:
        return 1;
      case `http://www.w3.org/1998/Math/MathML`:
        return 2;
      default:
        return 0;
    }
  }
  function Gd(e2, t3) {
    if (e2 === 0) switch (t3) {
      case `svg`:
        return 1;
      case `math`:
        return 2;
      default:
        return 0;
    }
    return e2 === 1 && t3 === `foreignObject` ? 0 : e2;
  }
  function Kd(e2, t3) {
    return e2 === `textarea` || e2 === `noscript` || typeof t3.children == `string` || typeof t3.children == `number` || typeof t3.children == `bigint` || typeof t3.dangerouslySetInnerHTML == `object` && t3.dangerouslySetInnerHTML !== null && t3.dangerouslySetInnerHTML.__html != null;
  }
  var qd = null;
  function Jd() {
    var e2 = window.event;
    return e2 && e2.type === `popstate` ? e2 !== qd && (qd = e2, true) : (qd = null, false);
  }
  var Yd = typeof setTimeout == `function` ? setTimeout : void 0, Xd = typeof clearTimeout == `function` ? clearTimeout : void 0, Zd = typeof Promise == `function` ? Promise : void 0, Qd = typeof queueMicrotask == `function` ? queueMicrotask : Zd === void 0 ? Yd : function(e2) {
    return Zd.resolve(null).then(e2).catch($d);
  };
  function $d(e2) {
    setTimeout(function() {
      throw e2;
    });
  }
  function ef(e2) {
    return e2 === `head`;
  }
  function tf(e2, t3) {
    var n3 = t3, r2 = 0;
    do {
      var i2 = n3.nextSibling;
      if (e2.removeChild(n3), i2 && i2.nodeType === 8) {
        if (n3 = i2.data, n3 === `/$` || n3 === `/&`) {
          if (r2 === 0) {
            e2.removeChild(i2), Ip(t3);
            return;
          }
          r2--;
        } else if (n3 === `$` || n3 === `$?` || n3 === `$~` || n3 === `$!` || n3 === `&`) r2++;
        else if (n3 === `html`) gf(e2.ownerDocument.documentElement);
        else if (n3 === `head`) {
          n3 = e2.ownerDocument.head, gf(n3);
          for (var a2 = n3.firstChild; a2; ) {
            var o2 = a2.nextSibling, s3 = a2.nodeName;
            a2[kt] || s3 === `SCRIPT` || s3 === `STYLE` || s3 === `LINK` && a2.rel.toLowerCase() === `stylesheet` || n3.removeChild(a2), a2 = o2;
          }
        } else n3 === `body` && gf(e2.ownerDocument.body);
      }
      n3 = i2;
    } while (n3);
    Ip(t3);
  }
  function nf(e2, t3) {
    var n3 = e2;
    e2 = 0;
    do {
      var r2 = n3.nextSibling;
      if (n3.nodeType === 1 ? t3 ? (n3._stashedDisplay = n3.style.display, n3.style.display = `none`) : (n3.style.display = n3._stashedDisplay || ``, n3.getAttribute(`style`) === `` && n3.removeAttribute(`style`)) : n3.nodeType === 3 && (t3 ? (n3._stashedText = n3.nodeValue, n3.nodeValue = ``) : n3.nodeValue = n3._stashedText || ``), r2 && r2.nodeType === 8) {
        if (n3 = r2.data, n3 === `/$`) {
          if (e2 === 0) break;
          e2--;
        } else n3 !== `$` && n3 !== `$?` && n3 !== `$~` && n3 !== `$!` || e2++;
      }
      n3 = r2;
    } while (n3);
  }
  function rf(e2) {
    var t3 = e2.firstChild;
    for (t3 && t3.nodeType === 10 && (t3 = t3.nextSibling); t3; ) {
      var n3 = t3;
      switch (t3 = t3.nextSibling, n3.nodeName) {
        case `HTML`:
        case `HEAD`:
        case `BODY`:
          rf(n3), At(n3);
          continue;
        case `SCRIPT`:
        case `STYLE`:
          continue;
        case `LINK`:
          if (n3.rel.toLowerCase() === `stylesheet`) continue;
      }
      e2.removeChild(n3);
    }
  }
  function af(e2, t3, n3, r2) {
    for (; e2.nodeType === 1; ) {
      var i2 = n3;
      if (e2.nodeName.toLowerCase() !== t3.toLowerCase()) {
        if (!r2 && (e2.nodeName !== `INPUT` || e2.type !== `hidden`)) break;
      } else if (!r2) {
        if (t3 === `input` && e2.type === `hidden`) {
          var a2 = i2.name == null ? null : `` + i2.name;
          if (i2.type === `hidden` && e2.getAttribute(`name`) === a2) return e2;
        } else return e2;
      } else if (!e2[kt]) switch (t3) {
        case `meta`:
          if (!e2.hasAttribute(`itemprop`)) break;
          return e2;
        case `link`:
          if (a2 = e2.getAttribute(`rel`), a2 === `stylesheet` && e2.hasAttribute(`data-precedence`) || a2 !== i2.rel || e2.getAttribute(`href`) !== (i2.href == null || i2.href === `` ? null : i2.href) || e2.getAttribute(`crossorigin`) !== (i2.crossOrigin == null ? null : i2.crossOrigin) || e2.getAttribute(`title`) !== (i2.title == null ? null : i2.title)) break;
          return e2;
        case `style`:
          if (e2.hasAttribute(`data-precedence`)) break;
          return e2;
        case `script`:
          if (a2 = e2.getAttribute(`src`), (a2 !== (i2.src == null ? null : i2.src) || e2.getAttribute(`type`) !== (i2.type == null ? null : i2.type) || e2.getAttribute(`crossorigin`) !== (i2.crossOrigin == null ? null : i2.crossOrigin)) && a2 && e2.hasAttribute(`async`) && !e2.hasAttribute(`itemprop`)) break;
          return e2;
        default:
          return e2;
      }
      if (e2 = df(e2.nextSibling), e2 === null) break;
    }
    return null;
  }
  function of(e2, t3, n3) {
    if (t3 === ``) return null;
    for (; e2.nodeType !== 3; ) if ((e2.nodeType !== 1 || e2.nodeName !== `INPUT` || e2.type !== `hidden`) && !n3 || (e2 = df(e2.nextSibling), e2 === null)) return null;
    return e2;
  }
  function sf(e2, t3) {
    for (; e2.nodeType !== 8; ) if ((e2.nodeType !== 1 || e2.nodeName !== `INPUT` || e2.type !== `hidden`) && !t3 || (e2 = df(e2.nextSibling), e2 === null)) return null;
    return e2;
  }
  function cf(e2) {
    return e2.data === `$?` || e2.data === `$~`;
  }
  function lf(e2) {
    return e2.data === `$!` || e2.data === `$?` && e2.ownerDocument.readyState !== `loading`;
  }
  function uf(e2, t3) {
    var n3 = e2.ownerDocument;
    if (e2.data === `$~`) e2._reactRetry = t3;
    else if (e2.data !== `$?` || n3.readyState !== `loading`) t3();
    else {
      var r2 = function() {
        t3(), n3.removeEventListener(`DOMContentLoaded`, r2);
      };
      n3.addEventListener(`DOMContentLoaded`, r2), e2._reactRetry = r2;
    }
  }
  function df(e2) {
    for (; e2 != null; e2 = e2.nextSibling) {
      var t3 = e2.nodeType;
      if (t3 === 1 || t3 === 3) break;
      if (t3 === 8) {
        if (t3 = e2.data, t3 === `$` || t3 === `$!` || t3 === `$?` || t3 === `$~` || t3 === `&` || t3 === `F!` || t3 === `F`) break;
        if (t3 === `/$` || t3 === `/&`) return null;
      }
    }
    return e2;
  }
  var ff = null;
  function pf(e2) {
    e2 = e2.nextSibling;
    for (var t3 = 0; e2; ) {
      if (e2.nodeType === 8) {
        var n3 = e2.data;
        if (n3 === `/$` || n3 === `/&`) {
          if (t3 === 0) return df(e2.nextSibling);
          t3--;
        } else n3 !== `$` && n3 !== `$!` && n3 !== `$?` && n3 !== `$~` && n3 !== `&` || t3++;
      }
      e2 = e2.nextSibling;
    }
    return null;
  }
  function mf(e2) {
    e2 = e2.previousSibling;
    for (var t3 = 0; e2; ) {
      if (e2.nodeType === 8) {
        var n3 = e2.data;
        if (n3 === `$` || n3 === `$!` || n3 === `$?` || n3 === `$~` || n3 === `&`) {
          if (t3 === 0) return e2;
          t3--;
        } else n3 !== `/$` && n3 !== `/&` || t3++;
      }
      e2 = e2.previousSibling;
    }
    return null;
  }
  function hf(e2, t3, n3) {
    switch (t3 = Ud(n3), e2) {
      case `html`:
        if (e2 = t3.documentElement, !e2) throw Error(u2(452));
        return e2;
      case `head`:
        if (e2 = t3.head, !e2) throw Error(u2(453));
        return e2;
      case `body`:
        if (e2 = t3.body, !e2) throw Error(u2(454));
        return e2;
      default:
        throw Error(u2(451));
    }
  }
  function gf(e2) {
    for (var t3 = e2.attributes; t3.length; ) e2.removeAttributeNode(t3[0]);
    At(e2);
  }
  var _f = /* @__PURE__ */ new Map(), vf = /* @__PURE__ */ new Set();
  function yf(e2) {
    return typeof e2.getRootNode == `function` ? e2.getRootNode() : e2.nodeType === 9 ? e2 : e2.ownerDocument;
  }
  var bf = C.d;
  C.d = { f: xf, r: Sf, D: Tf, C: Ef, L: Df, m: Of, X: Af, S: kf, M: jf };
  function xf() {
    var e2 = bf.f(), t3 = wu();
    return e2 || t3;
  }
  function Sf(e2) {
    var t3 = Mt(e2);
    t3 !== null && t3.tag === 5 && t3.type === `form` ? Fs(t3) : bf.r(e2);
  }
  var Cf = typeof document > `u` ? null : document;
  function wf(e2, t3, n3) {
    var r2 = Cf;
    if (r2 && typeof t3 == `string` && t3) {
      var i2 = $t(t3);
      i2 = `link[rel="` + e2 + `"][href="` + i2 + `"]`, typeof n3 == `string` && (i2 += `[crossorigin="` + n3 + `"]`), vf.has(i2) || (vf.add(i2), e2 = { rel: e2, crossOrigin: n3, href: t3 }, r2.querySelector(i2) === null && (t3 = r2.createElement(`link`), $(t3, `link`, e2), E(t3), r2.head.appendChild(t3)));
    }
  }
  function Tf(e2) {
    bf.D(e2), wf(`dns-prefetch`, e2, null);
  }
  function Ef(e2, t3) {
    bf.C(e2, t3), wf(`preconnect`, e2, t3);
  }
  function Df(e2, t3, n3) {
    bf.L(e2, t3, n3);
    var r2 = Cf;
    if (r2 && e2 && t3) {
      var i2 = `link[rel="preload"][as="` + $t(t3) + `"]`;
      t3 === `image` && n3 && n3.imageSrcSet ? (i2 += `[imagesrcset="` + $t(n3.imageSrcSet) + `"]`, typeof n3.imageSizes == `string` && (i2 += `[imagesizes="` + $t(n3.imageSizes) + `"]`)) : i2 += `[href="` + $t(e2) + `"]`;
      var a2 = i2;
      switch (t3) {
        case `style`:
          a2 = Nf(e2);
          break;
        case `script`:
          a2 = Lf(e2);
      }
      _f.has(a2) || (e2 = v({ rel: `preload`, href: t3 === `image` && n3 && n3.imageSrcSet ? void 0 : e2, as: t3 }, n3), _f.set(a2, e2), r2.querySelector(i2) !== null || t3 === `style` && r2.querySelector(Pf(a2)) || t3 === `script` && r2.querySelector(Rf(a2)) || (t3 = r2.createElement(`link`), $(t3, `link`, e2), E(t3), r2.head.appendChild(t3)));
    }
  }
  function Of(e2, t3) {
    bf.m(e2, t3);
    var n3 = Cf;
    if (n3 && e2) {
      var r2 = t3 && typeof t3.as == `string` ? t3.as : `script`, i2 = `link[rel="modulepreload"][as="` + $t(r2) + `"][href="` + $t(e2) + `"]`, a2 = i2;
      switch (r2) {
        case `audioworklet`:
        case `paintworklet`:
        case `serviceworker`:
        case `sharedworker`:
        case `worker`:
        case `script`:
          a2 = Lf(e2);
      }
      if (!_f.has(a2) && (e2 = v({ rel: `modulepreload`, href: e2 }, t3), _f.set(a2, e2), n3.querySelector(i2) === null)) {
        switch (r2) {
          case `audioworklet`:
          case `paintworklet`:
          case `serviceworker`:
          case `sharedworker`:
          case `worker`:
          case `script`:
            if (n3.querySelector(Rf(a2))) return;
        }
        r2 = n3.createElement(`link`), $(r2, `link`, e2), E(r2), n3.head.appendChild(r2);
      }
    }
  }
  function kf(e2, t3, n3) {
    bf.S(e2, t3, n3);
    var r2 = Cf;
    if (r2 && e2) {
      var i2 = Pt(r2).hoistableStyles, a2 = Nf(e2);
      t3 || (t3 = `default`);
      var o2 = i2.get(a2);
      if (!o2) {
        var s3 = { loading: 0, preload: null };
        if (o2 = r2.querySelector(Pf(a2))) s3.loading = 5;
        else {
          e2 = v({ rel: `stylesheet`, href: e2, "data-precedence": t3 }, n3), (n3 = _f.get(a2)) && Vf(e2, n3);
          var c2 = o2 = r2.createElement(`link`);
          E(c2), $(c2, `link`, e2), c2._p = new Promise(function(e3, t4) {
            c2.onload = e3, c2.onerror = t4;
          }), c2.addEventListener(`load`, function() {
            s3.loading |= 1;
          }), c2.addEventListener(`error`, function() {
            s3.loading |= 2;
          }), s3.loading |= 4, Bf(o2, t3, r2);
        }
        o2 = { type: `stylesheet`, instance: o2, count: 1, state: s3 }, i2.set(a2, o2);
      }
    }
  }
  function Af(e2, t3) {
    bf.X(e2, t3);
    var n3 = Cf;
    if (n3 && e2) {
      var r2 = Pt(n3).hoistableScripts, i2 = Lf(e2), a2 = r2.get(i2);
      a2 || (a2 = n3.querySelector(Rf(i2)), a2 || (e2 = v({ src: e2, async: true }, t3), (t3 = _f.get(i2)) && Hf(e2, t3), a2 = n3.createElement(`script`), E(a2), $(a2, `link`, e2), n3.head.appendChild(a2)), a2 = { type: `script`, instance: a2, count: 1, state: null }, r2.set(i2, a2));
    }
  }
  function jf(e2, t3) {
    bf.M(e2, t3);
    var n3 = Cf;
    if (n3 && e2) {
      var r2 = Pt(n3).hoistableScripts, i2 = Lf(e2), a2 = r2.get(i2);
      a2 || (a2 = n3.querySelector(Rf(i2)), a2 || (e2 = v({ src: e2, async: true, type: `module` }, t3), (t3 = _f.get(i2)) && Hf(e2, t3), a2 = n3.createElement(`script`), E(a2), $(a2, `link`, e2), n3.head.appendChild(a2)), a2 = { type: `script`, instance: a2, count: 1, state: null }, r2.set(i2, a2));
    }
  }
  function Mf(e2, t3, n3, r2) {
    var i2 = (i2 = Ce.current) ? yf(i2) : null;
    if (!i2) throw Error(u2(446));
    switch (e2) {
      case `meta`:
      case `title`:
        return null;
      case `style`:
        return typeof n3.precedence == `string` && typeof n3.href == `string` ? (t3 = Nf(n3.href), n3 = Pt(i2).hoistableStyles, r2 = n3.get(t3), r2 || (r2 = { type: `style`, instance: null, count: 0, state: null }, n3.set(t3, r2)), r2) : { type: `void`, instance: null, count: 0, state: null };
      case `link`:
        if (n3.rel === `stylesheet` && typeof n3.href == `string` && typeof n3.precedence == `string`) {
          e2 = Nf(n3.href);
          var a2 = Pt(i2).hoistableStyles, o2 = a2.get(e2);
          if (o2 || (i2 = i2.ownerDocument || i2, o2 = { type: `stylesheet`, instance: null, count: 0, state: { loading: 0, preload: null } }, a2.set(e2, o2), (a2 = i2.querySelector(Pf(e2))) && !a2._p && (o2.instance = a2, o2.state.loading = 5), _f.has(e2) || (n3 = { rel: `preload`, as: `style`, href: n3.href, crossOrigin: n3.crossOrigin, integrity: n3.integrity, media: n3.media, hrefLang: n3.hrefLang, referrerPolicy: n3.referrerPolicy }, _f.set(e2, n3), a2 || If(i2, e2, n3, o2.state))), t3 && r2 === null) throw Error(u2(528, ``));
          return o2;
        }
        if (t3 && r2 !== null) throw Error(u2(529, ``));
        return null;
      case `script`:
        return t3 = n3.async, n3 = n3.src, typeof n3 == `string` && t3 && typeof t3 != `function` && typeof t3 != `symbol` ? (t3 = Lf(n3), n3 = Pt(i2).hoistableScripts, r2 = n3.get(t3), r2 || (r2 = { type: `script`, instance: null, count: 0, state: null }, n3.set(t3, r2)), r2) : { type: `void`, instance: null, count: 0, state: null };
      default:
        throw Error(u2(444, e2));
    }
  }
  function Nf(e2) {
    return `href="` + $t(e2) + `"`;
  }
  function Pf(e2) {
    return `link[rel="stylesheet"][` + e2 + `]`;
  }
  function Ff(e2) {
    return v({}, e2, { "data-precedence": e2.precedence, precedence: null });
  }
  function If(e2, t3, n3, r2) {
    e2.querySelector(`link[rel="preload"][as="style"][` + t3 + `]`) ? r2.loading = 1 : (t3 = e2.createElement(`link`), r2.preload = t3, t3.addEventListener(`load`, function() {
      return r2.loading |= 1;
    }), t3.addEventListener(`error`, function() {
      return r2.loading |= 2;
    }), $(t3, `link`, n3), E(t3), e2.head.appendChild(t3));
  }
  function Lf(e2) {
    return `[src="` + $t(e2) + `"]`;
  }
  function Rf(e2) {
    return `script[async]` + e2;
  }
  function zf(e2, t3, n3) {
    if (t3.count++, t3.instance === null) switch (t3.type) {
      case `style`:
        var r2 = e2.querySelector(`style[data-href~="` + $t(n3.href) + `"]`);
        if (r2) return t3.instance = r2, E(r2), r2;
        var i2 = v({}, n3, { "data-href": n3.href, "data-precedence": n3.precedence, href: null, precedence: null });
        return r2 = (e2.ownerDocument || e2).createElement(`style`), E(r2), $(r2, `style`, i2), Bf(r2, n3.precedence, e2), t3.instance = r2;
      case `stylesheet`:
        i2 = Nf(n3.href);
        var a2 = e2.querySelector(Pf(i2));
        if (a2) return t3.state.loading |= 4, t3.instance = a2, E(a2), a2;
        r2 = Ff(n3), (i2 = _f.get(i2)) && Vf(r2, i2), a2 = (e2.ownerDocument || e2).createElement(`link`), E(a2);
        var o2 = a2;
        return o2._p = new Promise(function(e3, t4) {
          o2.onload = e3, o2.onerror = t4;
        }), $(a2, `link`, r2), t3.state.loading |= 4, Bf(a2, n3.precedence, e2), t3.instance = a2;
      case `script`:
        return a2 = Lf(n3.src), (i2 = e2.querySelector(Rf(a2))) ? (t3.instance = i2, E(i2), i2) : (r2 = n3, (i2 = _f.get(a2)) && (r2 = v({}, n3), Hf(r2, i2)), e2 = e2.ownerDocument || e2, i2 = e2.createElement(`script`), E(i2), $(i2, `link`, r2), e2.head.appendChild(i2), t3.instance = i2);
      case `void`:
        return null;
      default:
        throw Error(u2(443, t3.type));
    }
    else t3.type === `stylesheet` && !(t3.state.loading & 4) && (r2 = t3.instance, t3.state.loading |= 4, Bf(r2, n3.precedence, e2));
    return t3.instance;
  }
  function Bf(e2, t3, n3) {
    for (var r2 = n3.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`), i2 = r2.length ? r2[r2.length - 1] : null, a2 = i2, o2 = 0; o2 < r2.length; o2++) {
      var s3 = r2[o2];
      if (s3.dataset.precedence === t3) a2 = s3;
      else if (a2 !== i2) break;
    }
    a2 ? a2.parentNode.insertBefore(e2, a2.nextSibling) : (t3 = n3.nodeType === 9 ? n3.head : n3, t3.insertBefore(e2, t3.firstChild));
  }
  function Vf(e2, t3) {
    e2.crossOrigin ?? (e2.crossOrigin = t3.crossOrigin), e2.referrerPolicy ?? (e2.referrerPolicy = t3.referrerPolicy), e2.title ?? (e2.title = t3.title);
  }
  function Hf(e2, t3) {
    e2.crossOrigin ?? (e2.crossOrigin = t3.crossOrigin), e2.referrerPolicy ?? (e2.referrerPolicy = t3.referrerPolicy), e2.integrity ?? (e2.integrity = t3.integrity);
  }
  var Uf = null;
  function Wf(e2, t3, n3) {
    if (Uf === null) {
      var r2 = /* @__PURE__ */ new Map(), i2 = Uf = /* @__PURE__ */ new Map();
      i2.set(n3, r2);
    } else i2 = Uf, r2 = i2.get(n3), r2 || (r2 = /* @__PURE__ */ new Map(), i2.set(n3, r2));
    if (r2.has(e2)) return r2;
    for (r2.set(e2, null), n3 = n3.getElementsByTagName(e2), i2 = 0; i2 < n3.length; i2++) {
      var a2 = n3[i2];
      if (!(a2[kt] || a2[St] || e2 === `link` && a2.getAttribute(`rel`) === `stylesheet`) && a2.namespaceURI !== `http://www.w3.org/2000/svg`) {
        var o2 = a2.getAttribute(t3) || ``;
        o2 = e2 + o2;
        var s3 = r2.get(o2);
        s3 ? s3.push(a2) : r2.set(o2, [a2]);
      }
    }
    return r2;
  }
  function Gf(e2, t3, n3) {
    e2 = e2.ownerDocument || e2, e2.head.insertBefore(n3, t3 === `title` ? e2.querySelector(`head > title`) : null);
  }
  function Kf(e2, t3, n3) {
    if (n3 === 1 || t3.itemProp != null) return false;
    switch (e2) {
      case `meta`:
      case `title`:
        return true;
      case `style`:
        if (typeof t3.precedence != `string` || typeof t3.href != `string` || t3.href === ``) break;
        return true;
      case `link`:
        if (typeof t3.rel != `string` || typeof t3.href != `string` || t3.href === `` || t3.onLoad || t3.onError) break;
        switch (t3.rel) {
          case `stylesheet`:
            return e2 = t3.disabled, typeof t3.precedence == `string` && e2 == null;
          default:
            return true;
        }
      case `script`:
        if (t3.async && typeof t3.async != `function` && typeof t3.async != `symbol` && !t3.onLoad && !t3.onError && t3.src && typeof t3.src == `string`) return true;
    }
    return false;
  }
  function qf(e2) {
    return !(e2.type === `stylesheet` && !(e2.state.loading & 3));
  }
  function Jf(e2, t3, n3, r2) {
    if (n3.type === `stylesheet` && (typeof r2.media != `string` || false !== matchMedia(r2.media).matches) && !(n3.state.loading & 4)) {
      if (n3.instance === null) {
        var i2 = Nf(r2.href), a2 = t3.querySelector(Pf(i2));
        if (a2) {
          t3 = a2._p, typeof t3 == `object` && t3 && typeof t3.then == `function` && (e2.count++, e2 = Zf.bind(e2), t3.then(e2, e2)), n3.state.loading |= 4, n3.instance = a2, E(a2);
          return;
        }
        a2 = t3.ownerDocument || t3, r2 = Ff(r2), (i2 = _f.get(i2)) && Vf(r2, i2), a2 = a2.createElement(`link`), E(a2);
        var o2 = a2;
        o2._p = new Promise(function(e3, t4) {
          o2.onload = e3, o2.onerror = t4;
        }), $(a2, `link`, r2), n3.instance = a2;
      }
      e2.stylesheets === null && (e2.stylesheets = /* @__PURE__ */ new Map()), e2.stylesheets.set(n3, t3), (t3 = n3.state.preload) && !(n3.state.loading & 3) && (e2.count++, n3 = Zf.bind(e2), t3.addEventListener(`load`, n3), t3.addEventListener(`error`, n3));
    }
  }
  var Yf = 0;
  function Xf(e2, t3) {
    return e2.stylesheets && e2.count === 0 && $f(e2, e2.stylesheets), 0 < e2.count || 0 < e2.imgCount ? function(n3) {
      var r2 = setTimeout(function() {
        if (e2.stylesheets && $f(e2, e2.stylesheets), e2.unsuspend) {
          var t4 = e2.unsuspend;
          e2.unsuspend = null, t4();
        }
      }, 6e4 + t3);
      0 < e2.imgBytes && Yf === 0 && (Yf = 62500 * Bd());
      var i2 = setTimeout(function() {
        if (e2.waitingForImages = false, e2.count === 0 && (e2.stylesheets && $f(e2, e2.stylesheets), e2.unsuspend)) {
          var t4 = e2.unsuspend;
          e2.unsuspend = null, t4();
        }
      }, (e2.imgBytes > Yf ? 50 : 800) + t3);
      return e2.unsuspend = n3, function() {
        e2.unsuspend = null, clearTimeout(r2), clearTimeout(i2);
      };
    } : null;
  }
  function Zf() {
    if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
      if (this.stylesheets) $f(this, this.stylesheets);
      else if (this.unsuspend) {
        var e2 = this.unsuspend;
        this.unsuspend = null, e2();
      }
    }
  }
  var Qf = null;
  function $f(e2, t3) {
    e2.stylesheets = null, e2.unsuspend !== null && (e2.count++, Qf = /* @__PURE__ */ new Map(), t3.forEach(ep, e2), Qf = null, Zf.call(e2));
  }
  function ep(e2, t3) {
    if (!(t3.state.loading & 4)) {
      var n3 = Qf.get(e2);
      if (n3) var r2 = n3.get(null);
      else {
        n3 = /* @__PURE__ */ new Map(), Qf.set(e2, n3);
        for (var i2 = e2.querySelectorAll(`link[data-precedence],style[data-precedence]`), a2 = 0; a2 < i2.length; a2++) {
          var o2 = i2[a2];
          (o2.nodeName === `LINK` || o2.getAttribute(`media`) !== `not all`) && (n3.set(o2.dataset.precedence, o2), r2 = o2);
        }
        r2 && n3.set(null, r2);
      }
      i2 = t3.instance, o2 = i2.getAttribute(`data-precedence`), a2 = n3.get(o2) || r2, a2 === r2 && n3.set(null, i2), n3.set(o2, i2), this.count++, r2 = Zf.bind(this), i2.addEventListener(`load`, r2), i2.addEventListener(`error`, r2), a2 ? a2.parentNode.insertBefore(i2, a2.nextSibling) : (e2 = e2.nodeType === 9 ? e2.head : e2, e2.insertBefore(i2, e2.firstChild)), t3.state.loading |= 4;
    }
  }
  var tp = { $$typeof: ie, Provider: null, Consumer: null, _currentValue: _e, _currentValue2: _e, _threadCount: 0 };
  function np(e2, t3, n3, r2, i2, a2, o2, s3, c2) {
    this.tag = 1, this.containerInfo = e2, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = dt(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = dt(0), this.hiddenUpdates = dt(null), this.identifierPrefix = r2, this.onUncaughtError = i2, this.onCaughtError = a2, this.onRecoverableError = o2, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = c2, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function rp(e2, t3, n3, r2, i2, a2, o2, s3, c2, l3, u3, d3) {
    return e2 = new np(e2, t3, n3, o2, c2, l3, u3, d3, s3), t3 = 1, true === a2 && (t3 |= 24), a2 = Ci(3, null, null, t3), e2.current = a2, a2.stateNode = e2, t3 = ya(), t3.refCount++, e2.pooledCache = t3, t3.refCount++, a2.memoizedState = { element: r2, isDehydrated: n3, cache: t3 }, Qa(a2), e2;
  }
  function ip(e2) {
    return e2 ? (e2 = xi, e2) : xi;
  }
  function ap(e2, t3, n3, r2, i2, a2) {
    i2 = ip(i2), r2.context === null ? r2.context = i2 : r2.pendingContext = i2, r2 = eo(t3), r2.payload = { element: n3 }, a2 = a2 === void 0 ? null : a2, a2 !== null && (r2.callback = a2), n3 = to(e2, r2, t3), n3 !== null && (yu(n3, e2, t3), no(n3, e2, t3));
  }
  function op(e2, t3) {
    if (e2 = e2.memoizedState, e2 !== null && e2.dehydrated !== null) {
      var n3 = e2.retryLane;
      e2.retryLane = n3 !== 0 && n3 < t3 ? n3 : t3;
    }
  }
  function sp(e2, t3) {
    op(e2, t3), (e2 = e2.alternate) && op(e2, t3);
  }
  function cp(e2) {
    if (e2.tag === 13 || e2.tag === 31) {
      var t3 = vi(e2, 67108864);
      t3 !== null && yu(t3, e2, 67108864), sp(e2, 67108864);
    }
  }
  function lp(e2) {
    if (e2.tag === 13 || e2.tag === 31) {
      var t3 = _u();
      t3 = _t(t3);
      var n3 = vi(e2, t3);
      n3 !== null && yu(n3, e2, t3), sp(e2, t3);
    }
  }
  var up = true;
  function dp(e2, t3, n3, r2) {
    var i2 = S.T;
    S.T = null;
    var a2 = C.p;
    try {
      C.p = 2, pp(e2, t3, n3, r2);
    } finally {
      C.p = a2, S.T = i2;
    }
  }
  function fp(e2, t3, n3, r2) {
    var i2 = S.T;
    S.T = null;
    var a2 = C.p;
    try {
      C.p = 8, pp(e2, t3, n3, r2);
    } finally {
      C.p = a2, S.T = i2;
    }
  }
  function pp(e2, t3, n3, r2) {
    if (up) {
      var i2 = mp(r2);
      if (i2 === null) Od(e2, t3, r2, hp, n3), Ep(e2, r2);
      else if (Op(i2, e2, t3, n3, r2)) r2.stopPropagation();
      else if (Ep(e2, r2), t3 & 4 && -1 < Tp.indexOf(e2)) {
        for (; i2 !== null; ) {
          var a2 = Mt(i2);
          if (a2 !== null) switch (a2.tag) {
            case 3:
              if (a2 = a2.stateNode, a2.current.memoizedState.isDehydrated) {
                var o2 = ot(a2.pendingLanes);
                if (o2 !== 0) {
                  var s3 = a2;
                  for (s3.pendingLanes |= 2, s3.entangledLanes |= 2; o2; ) {
                    var c2 = 1 << 31 - $e(o2);
                    s3.entanglements[1] |= c2, o2 &= ~c2;
                  }
                  sd(a2), !(U & 6) && (ou = Ve() + 500, cd(0, false));
                }
              }
              break;
            case 31:
            case 13:
              s3 = vi(a2, 2), s3 !== null && yu(s3, a2, 2), wu(), sp(a2, 2);
          }
          if (a2 = mp(r2), a2 === null && Od(e2, t3, r2, hp, n3), a2 === i2) break;
          i2 = a2;
        }
        i2 !== null && r2.stopPropagation();
      } else Od(e2, t3, r2, null, n3);
    }
  }
  function mp(e2) {
    return e2 = _n(e2), gp(e2);
  }
  var hp = null;
  function gp(e2) {
    if (hp = null, e2 = jt(e2), e2 !== null) {
      var t3 = f2(e2);
      if (t3 === null) e2 = null;
      else {
        var n3 = t3.tag;
        if (n3 === 13) {
          if (e2 = p2(t3), e2 !== null) return e2;
          e2 = null;
        } else if (n3 === 31) {
          if (e2 = m2(t3), e2 !== null) return e2;
          e2 = null;
        } else if (n3 === 3) {
          if (t3.stateNode.current.memoizedState.isDehydrated) return t3.tag === 3 ? t3.stateNode.containerInfo : null;
          e2 = null;
        } else t3 !== e2 && (e2 = null);
      }
    }
    return hp = e2, null;
  }
  function _p(e2) {
    switch (e2) {
      case `beforetoggle`:
      case `cancel`:
      case `click`:
      case `close`:
      case `contextmenu`:
      case `copy`:
      case `cut`:
      case `auxclick`:
      case `dblclick`:
      case `dragend`:
      case `dragstart`:
      case `drop`:
      case `focusin`:
      case `focusout`:
      case `input`:
      case `invalid`:
      case `keydown`:
      case `keypress`:
      case `keyup`:
      case `mousedown`:
      case `mouseup`:
      case `paste`:
      case `pause`:
      case `play`:
      case `pointercancel`:
      case `pointerdown`:
      case `pointerup`:
      case `ratechange`:
      case `reset`:
      case `resize`:
      case `seeked`:
      case `submit`:
      case `toggle`:
      case `touchcancel`:
      case `touchend`:
      case `touchstart`:
      case `volumechange`:
      case `change`:
      case `selectionchange`:
      case `textInput`:
      case `compositionstart`:
      case `compositionend`:
      case `compositionupdate`:
      case `beforeblur`:
      case `afterblur`:
      case `beforeinput`:
      case `blur`:
      case `fullscreenchange`:
      case `focus`:
      case `hashchange`:
      case `popstate`:
      case `select`:
      case `selectstart`:
        return 2;
      case `drag`:
      case `dragenter`:
      case `dragexit`:
      case `dragleave`:
      case `dragover`:
      case `mousemove`:
      case `mouseout`:
      case `mouseover`:
      case `pointermove`:
      case `pointerout`:
      case `pointerover`:
      case `scroll`:
      case `touchmove`:
      case `wheel`:
      case `mouseenter`:
      case `mouseleave`:
      case `pointerenter`:
      case `pointerleave`:
        return 8;
      case `message`:
        switch (He()) {
          case Ue:
            return 2;
          case We:
            return 8;
          case Ge:
          case Ke:
            return 32;
          case qe:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var vp = false, yp = null, bp = null, xp = null, Sp = /* @__PURE__ */ new Map(), Cp = /* @__PURE__ */ new Map(), wp = [], Tp = `mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);
  function Ep(e2, t3) {
    switch (e2) {
      case `focusin`:
      case `focusout`:
        yp = null;
        break;
      case `dragenter`:
      case `dragleave`:
        bp = null;
        break;
      case `mouseover`:
      case `mouseout`:
        xp = null;
        break;
      case `pointerover`:
      case `pointerout`:
        Sp.delete(t3.pointerId);
        break;
      case `gotpointercapture`:
      case `lostpointercapture`:
        Cp.delete(t3.pointerId);
    }
  }
  function Dp(e2, t3, n3, r2, i2, a2) {
    return e2 === null || e2.nativeEvent !== a2 ? (e2 = { blockedOn: t3, domEventName: n3, eventSystemFlags: r2, nativeEvent: a2, targetContainers: [i2] }, t3 !== null && (t3 = Mt(t3), t3 !== null && cp(t3)), e2) : (e2.eventSystemFlags |= r2, t3 = e2.targetContainers, i2 !== null && t3.indexOf(i2) === -1 && t3.push(i2), e2);
  }
  function Op(e2, t3, n3, r2, i2) {
    switch (t3) {
      case `focusin`:
        return yp = Dp(yp, e2, t3, n3, r2, i2), true;
      case `dragenter`:
        return bp = Dp(bp, e2, t3, n3, r2, i2), true;
      case `mouseover`:
        return xp = Dp(xp, e2, t3, n3, r2, i2), true;
      case `pointerover`:
        var a2 = i2.pointerId;
        return Sp.set(a2, Dp(Sp.get(a2) || null, e2, t3, n3, r2, i2)), true;
      case `gotpointercapture`:
        return a2 = i2.pointerId, Cp.set(a2, Dp(Cp.get(a2) || null, e2, t3, n3, r2, i2)), true;
    }
    return false;
  }
  function kp(e2) {
    var t3 = jt(e2.target);
    if (t3 !== null) {
      var n3 = f2(t3);
      if (n3 !== null) {
        if (t3 = n3.tag, t3 === 13) {
          if (t3 = p2(n3), t3 !== null) {
            e2.blockedOn = t3, bt(e2.priority, function() {
              lp(n3);
            });
            return;
          }
        } else if (t3 === 31) {
          if (t3 = m2(n3), t3 !== null) {
            e2.blockedOn = t3, bt(e2.priority, function() {
              lp(n3);
            });
            return;
          }
        } else if (t3 === 3 && n3.stateNode.current.memoizedState.isDehydrated) {
          e2.blockedOn = n3.tag === 3 ? n3.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e2.blockedOn = null;
  }
  function Ap(e2) {
    if (e2.blockedOn !== null) return false;
    for (var t3 = e2.targetContainers; 0 < t3.length; ) {
      var n3 = mp(e2.nativeEvent);
      if (n3 === null) {
        n3 = e2.nativeEvent;
        var r2 = new n3.constructor(n3.type, n3);
        gn = r2, n3.target.dispatchEvent(r2), gn = null;
      } else return t3 = Mt(n3), t3 !== null && cp(t3), e2.blockedOn = n3, false;
      t3.shift();
    }
    return true;
  }
  function jp(e2, t3, n3) {
    Ap(e2) && n3.delete(t3);
  }
  function Mp() {
    vp = false, yp !== null && Ap(yp) && (yp = null), bp !== null && Ap(bp) && (bp = null), xp !== null && Ap(xp) && (xp = null), Sp.forEach(jp), Cp.forEach(jp);
  }
  function Np(e2, t3) {
    e2.blockedOn === t3 && (e2.blockedOn = null, vp || (vp = true, n2.unstable_scheduleCallback(n2.unstable_NormalPriority, Mp)));
  }
  var Pp = null;
  function Fp(e2) {
    Pp !== e2 && (Pp = e2, n2.unstable_scheduleCallback(n2.unstable_NormalPriority, function() {
      Pp === e2 && (Pp = null);
      for (var t3 = 0; t3 < e2.length; t3 += 3) {
        var n3 = e2[t3], r2 = e2[t3 + 1], i2 = e2[t3 + 2];
        if (typeof r2 != `function`) {
          if (gp(r2 || n3) === null) continue;
          break;
        }
        var a2 = Mt(n3);
        a2 !== null && (e2.splice(t3, 3), t3 -= 3, Ns(a2, { pending: true, data: i2, method: n3.method, action: r2 }, r2, i2));
      }
    }));
  }
  function Ip(e2) {
    function t3(t4) {
      return Np(t4, e2);
    }
    yp !== null && Np(yp, e2), bp !== null && Np(bp, e2), xp !== null && Np(xp, e2), Sp.forEach(t3), Cp.forEach(t3);
    for (var n3 = 0; n3 < wp.length; n3++) {
      var r2 = wp[n3];
      r2.blockedOn === e2 && (r2.blockedOn = null);
    }
    for (; 0 < wp.length && (n3 = wp[0], n3.blockedOn === null); ) kp(n3), n3.blockedOn === null && wp.shift();
    if (n3 = (e2.ownerDocument || e2).$$reactFormReplay, n3 != null) for (r2 = 0; r2 < n3.length; r2 += 3) {
      var i2 = n3[r2], a2 = n3[r2 + 1], o2 = i2[Ct] || null;
      if (typeof a2 == `function`) o2 || Fp(n3);
      else if (o2) {
        var s3 = null;
        if (a2 && a2.hasAttribute(`formAction`)) {
          if (i2 = a2, o2 = a2[Ct] || null) s3 = o2.formAction;
          else if (gp(i2) !== null) continue;
        } else s3 = o2.action;
        typeof s3 == `function` ? n3[r2 + 1] = s3 : (n3.splice(r2, 3), r2 -= 3), Fp(n3);
      }
    }
  }
  function Lp() {
    function e2(e3) {
      e3.canIntercept && e3.info === `react-transition` && e3.intercept({ handler: function() {
        return new Promise(function(e4) {
          return i2 = e4;
        });
      }, focusReset: `manual`, scroll: `manual` });
    }
    function t3() {
      i2 !== null && (i2(), i2 = null), r2 || setTimeout(n3, 20);
    }
    function n3() {
      if (!r2 && !navigation.transition) {
        var e3 = navigation.currentEntry;
        e3 && e3.url != null && navigation.navigate(e3.url, { state: e3.getState(), info: `react-transition`, history: `replace` });
      }
    }
    if (typeof navigation == `object`) {
      var r2 = false, i2 = null;
      return navigation.addEventListener(`navigate`, e2), navigation.addEventListener(`navigatesuccess`, t3), navigation.addEventListener(`navigateerror`, t3), setTimeout(n3, 100), function() {
        r2 = true, navigation.removeEventListener(`navigate`, e2), navigation.removeEventListener(`navigatesuccess`, t3), navigation.removeEventListener(`navigateerror`, t3), i2 !== null && (i2(), i2 = null);
      };
    }
  }
  function Rp(e2) {
    this._internalRoot = e2;
  }
  zp.prototype.render = Rp.prototype.render = function(e2) {
    var t3 = this._internalRoot;
    if (t3 === null) throw Error(u2(409));
    var n3 = t3.current;
    ap(n3, _u(), e2, t3, null, null);
  }, zp.prototype.unmount = Rp.prototype.unmount = function() {
    var e2 = this._internalRoot;
    if (e2 !== null) {
      this._internalRoot = null;
      var t3 = e2.containerInfo;
      ap(e2.current, 2, null, e2, null, null), wu(), t3[wt] = null;
    }
  };
  function zp(e2) {
    this._internalRoot = e2;
  }
  zp.prototype.unstable_scheduleHydration = function(e2) {
    if (e2) {
      var t3 = yt();
      e2 = { blockedOn: null, target: e2, priority: t3 };
      for (var n3 = 0; n3 < wp.length && t3 !== 0 && t3 < wp[n3].priority; n3++) ;
      wp.splice(n3, 0, e2), n3 === 0 && kp(e2);
    }
  };
  var Bp = s2.version;
  if (Bp !== `19.2.8`) throw Error(u2(527, Bp, `19.2.8`));
  C.findDOMNode = function(e2) {
    var t3 = e2._reactInternals;
    if (t3 === void 0) throw typeof e2.render == `function` ? Error(u2(188)) : (e2 = Object.keys(e2).join(`,`), Error(u2(268, e2)));
    return e2 = g(t3), e2 = e2 === null ? null : _(e2), e2 = e2 === null ? null : e2.stateNode, e2;
  };
  var Vp = { bundleType: 0, version: `19.2.8`, rendererPackageName: `react-dom`, currentDispatcherRef: S, reconcilerVersion: `19.2.8` };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u`) {
    var Hp = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Hp.isDisabled && Hp.supportsFiber) try {
      Xe = Hp.inject(Vp), Ze = Hp;
    } catch {
    }
  }
  t2.createRoot = function(e2, t3) {
    if (!d2(e2)) throw Error(u2(299));
    var n3 = false, r2 = ``, i2 = nc, a2 = rc, o2 = ic;
    return t3 != null && (true === t3.unstable_strictMode && (n3 = true), t3.identifierPrefix !== void 0 && (r2 = t3.identifierPrefix), t3.onUncaughtError !== void 0 && (i2 = t3.onUncaughtError), t3.onCaughtError !== void 0 && (a2 = t3.onCaughtError), t3.onRecoverableError !== void 0 && (o2 = t3.onRecoverableError)), t3 = rp(e2, 1, false, null, null, n3, r2, null, i2, a2, o2, Lp), e2[wt] = t3.current, Ed(e2), new Rp(t3);
  }, t2.hydrateRoot = function(e2, t3, n3) {
    if (!d2(e2)) throw Error(u2(299));
    var r2 = false, i2 = ``, a2 = nc, o2 = rc, s3 = ic, c2 = null;
    return n3 != null && (true === n3.unstable_strictMode && (r2 = true), n3.identifierPrefix !== void 0 && (i2 = n3.identifierPrefix), n3.onUncaughtError !== void 0 && (a2 = n3.onUncaughtError), n3.onCaughtError !== void 0 && (o2 = n3.onCaughtError), n3.onRecoverableError !== void 0 && (s3 = n3.onRecoverableError), n3.formState !== void 0 && (c2 = n3.formState)), t3 = rp(e2, 1, true, t3, n3 ?? null, r2, i2, c2, a2, o2, s3, Lp), t3.context = ip(null), n3 = t3.current, r2 = _u(), r2 = _t(r2), i2 = eo(r2), i2.callback = null, to(n3, i2, r2), n3 = r2, t3.current.lanes = n3, ft(t3, n3), sd(t3), e2[wt] = t3.current, Ed(e2), new zp(t3);
  }, t2.version = `19.2.8`;
})), u = t(n(((e2, t2) => {
  function n2() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`)) try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n2);
    } catch (e3) {
      console.error(e3);
    }
  }
  n2(), t2.exports = l();
}))()), d = u, f = d.createRoot, p = d.hydrateRoot, m = d.version, h = Reflect.get(u, `default`) ?? u;
export {
  f as createRoot,
  h as default,
  p as hydrateRoot,
  m as version
};
