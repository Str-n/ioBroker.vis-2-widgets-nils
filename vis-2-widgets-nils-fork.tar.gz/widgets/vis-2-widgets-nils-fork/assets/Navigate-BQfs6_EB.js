import { a as e, t } from "./rolldown-runtime-C0FnF6B9.js";
import { B as n, F as r, I as i, L as a, M as o, N as s, O as c, R as l, S as u, T as d, b as f, g as p, k as m, w as h, y as g, z as _ } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { C as v, D as y, F as b, H as x, I as S, J as C, K as w, L as T, P as E, S as D, X as ee, Y as te, _ as ne, b as re, d as ie, dt as ae, et as oe, ft as O, it as se, l as ce, n as le, nt as ue, pt as k, q as de, st as fe, u as pe, v as me, x as he, y as A } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as j } from "./Generic-BOiMPpxz.js";
import { t as ge } from "./PinCodeDialog-BOKi9bwC.js";
var _e = fe(O(`path`, { d: `M20 9H4v2h16zM4 15h16v-2H4z` }), `DragHandle`);
n(), se();
function M(e4) {
  return `Minified Redux error #${e4}; visit https://redux.js.org/Errors?code=${e4} for the full message or use the non-minified dev environment for full errors. `;
}
var ve = typeof Symbol == `function` && Symbol.observable || `@@observable`, ye = () => Math.random().toString(36).substring(7).split(``).join(`.`), be = { INIT: `@@redux/INIT${ye()}`, REPLACE: `@@redux/REPLACE${ye()}`, PROBE_UNKNOWN_ACTION: () => `@@redux/PROBE_UNKNOWN_ACTION${ye()}` };
function xe(e4) {
  if (typeof e4 != `object` || !e4) return false;
  let t2 = e4;
  for (; Object.getPrototypeOf(t2) !== null; ) t2 = Object.getPrototypeOf(t2);
  return Object.getPrototypeOf(e4) === t2 || Object.getPrototypeOf(e4) === null;
}
function Se(e4, t2, n2) {
  if (typeof e4 != `function`) throw Error(M(2));
  if (typeof t2 == `function` && typeof n2 == `function` || typeof n2 == `function` && typeof arguments[3] == `function`) throw Error(M(0));
  if (typeof t2 == `function` && n2 === void 0 && (n2 = t2, t2 = void 0), n2 !== void 0) {
    if (typeof n2 != `function`) throw Error(M(1));
    return n2(Se)(e4, t2);
  }
  let r2 = e4, i2 = t2, a2 = /* @__PURE__ */ new Map(), o2 = a2, s2 = 0, c2 = false;
  function l2() {
    o2 === a2 && (o2 = /* @__PURE__ */ new Map(), a2.forEach((e5, t3) => {
      o2.set(t3, e5);
    }));
  }
  function u2() {
    if (c2) throw Error(M(3));
    return i2;
  }
  function d2(e5) {
    if (typeof e5 != `function`) throw Error(M(4));
    if (c2) throw Error(M(5));
    let t3 = true;
    l2();
    let n3 = s2++;
    return o2.set(n3, e5), function() {
      if (t3) {
        if (c2) throw Error(M(6));
        t3 = false, l2(), o2.delete(n3), a2 = null;
      }
    };
  }
  function f2(e5) {
    if (!xe(e5)) throw Error(M(7));
    if (e5.type === void 0) throw Error(M(8));
    if (typeof e5.type != `string`) throw Error(M(17));
    if (c2) throw Error(M(9));
    try {
      c2 = true, i2 = r2(i2, e5);
    } finally {
      c2 = false;
    }
    return (a2 = o2).forEach((e6) => {
      e6();
    }), e5;
  }
  function p2(e5) {
    if (typeof e5 != `function`) throw Error(M(10));
    r2 = e5, f2({ type: be.REPLACE });
  }
  function m2() {
    let e5 = d2;
    return { subscribe(t3) {
      if (typeof t3 != `object` || !t3) throw Error(M(11));
      function n3() {
        let e6 = t3;
        e6.next && e6.next(u2());
      }
      return n3(), { unsubscribe: e5(n3) };
    }, [ve]() {
      return this;
    } };
  }
  return f2({ type: be.INIT }), { dispatch: f2, subscribe: d2, getState: u2, replaceReducer: p2, [ve]: m2 };
}
function Ce(e4, t2) {
  return function(...n2) {
    return t2(e4.apply(this, n2));
  };
}
function we(e4, t2) {
  if (typeof e4 == `function`) return Ce(e4, t2);
  if (typeof e4 != `object` || !e4) throw Error(M(16));
  let n2 = {};
  for (let r2 in e4) {
    let i2 = e4[r2];
    typeof i2 == `function` && (n2[r2] = Ce(i2, t2));
  }
  return n2;
}
function Te(...e4) {
  return e4.length === 0 ? (e5) => e5 : e4.length === 1 ? e4[0] : e4.reduce((e5, t2) => (...n2) => e5(t2(...n2)));
}
function Ee(...e4) {
  return (t2) => (n2, r2) => {
    let i2 = t2(n2, r2), a2 = () => {
      throw Error(M(15));
    }, o2 = { getState: i2.getState, dispatch: (e5, ...t3) => a2(e5, ...t3) };
    return a2 = Te(...e4.map((e5) => e5(o2)))(i2.dispatch), { ...i2, dispatch: a2 };
  };
}
var De = t(((t2) => {
  var r2 = (n(), e(_));
  r2.useSyncExternalStore, r2.useRef, r2.useEffect, r2.useMemo, r2.useDebugValue;
}));
t(((e4, t2) => {
  t2.exports = De();
}))();
var Oe = l.startsWith(`19`), ke = /* @__PURE__ */ Symbol.for(Oe ? `react.transitional.element` : `react.element`), Ae = /* @__PURE__ */ Symbol.for(`react.portal`), je = /* @__PURE__ */ Symbol.for(`react.fragment`), Me = /* @__PURE__ */ Symbol.for(`react.strict_mode`), Ne = /* @__PURE__ */ Symbol.for(`react.profiler`), Pe = /* @__PURE__ */ Symbol.for(`react.consumer`), Fe = /* @__PURE__ */ Symbol.for(`react.context`), Ie = /* @__PURE__ */ Symbol.for(`react.forward_ref`), Le = /* @__PURE__ */ Symbol.for(`react.suspense`), Re = /* @__PURE__ */ Symbol.for(`react.suspense_list`), ze = /* @__PURE__ */ Symbol.for(`react.memo`), Be = /* @__PURE__ */ Symbol.for(`react.lazy`), Ve = Ie, He = ze;
function Ue(e4) {
  if (typeof e4 == `object` && e4) {
    let { $$typeof: t2 } = e4;
    switch (t2) {
      case ke:
        switch (e4 = e4.type, e4) {
          case je:
          case Ne:
          case Me:
          case Le:
          case Re:
            return e4;
          default:
            switch (e4 && (e4 = e4.$$typeof), e4) {
              case Fe:
              case Ie:
              case Be:
              case ze:
                return e4;
              case Pe:
                return e4;
              default:
                return t2;
            }
        }
      case Ae:
        return t2;
    }
  }
}
function We(e4) {
  return Ue(e4) === ze;
}
function Ge(e4, t2, n2, r2, { areStatesEqual: i2, areOwnPropsEqual: a2, areStatePropsEqual: o2 }) {
  let s2 = false, c2, l2, u2, d2, f2;
  function p2(i3, a3) {
    return c2 = i3, l2 = a3, u2 = e4(c2, l2), d2 = t2(r2, l2), f2 = n2(u2, d2, l2), s2 = true, f2;
  }
  function m2() {
    return u2 = e4(c2, l2), t2.dependsOnOwnProps && (d2 = t2(r2, l2)), f2 = n2(u2, d2, l2), f2;
  }
  function h2() {
    return e4.dependsOnOwnProps && (u2 = e4(c2, l2)), t2.dependsOnOwnProps && (d2 = t2(r2, l2)), f2 = n2(u2, d2, l2), f2;
  }
  function g2() {
    let t3 = e4(c2, l2), r3 = !o2(t3, u2);
    return u2 = t3, r3 && (f2 = n2(u2, d2, l2)), f2;
  }
  function _2(e5, t3) {
    let n3 = !a2(t3, l2), r3 = !i2(e5, c2, t3, l2);
    return c2 = e5, l2 = t3, n3 && r3 ? m2() : n3 ? h2() : r3 ? g2() : f2;
  }
  return function(e5, t3) {
    return s2 ? _2(e5, t3) : p2(e5, t3);
  };
}
function Ke(e4, { initMapStateToProps: t2, initMapDispatchToProps: n2, initMergeProps: r2, ...i2 }) {
  return Ge(t2(e4, i2), n2(e4, i2), r2(e4, i2), e4, i2);
}
function qe(e4, t2) {
  let n2 = {};
  for (let r2 in e4) {
    let i2 = e4[r2];
    typeof i2 == `function` && (n2[r2] = (...e5) => t2(i2(...e5)));
  }
  return n2;
}
function Je(e4) {
  return function(t2) {
    let n2 = e4(t2);
    function r2() {
      return n2;
    }
    return r2.dependsOnOwnProps = false, r2;
  };
}
function Ye(e4) {
  return e4.dependsOnOwnProps ? !!e4.dependsOnOwnProps : e4.length !== 1;
}
function Xe(e4, t2) {
  return function(t3, { displayName: n2 }) {
    let r2 = function(e5, t4) {
      return r2.dependsOnOwnProps ? r2.mapToProps(e5, t4) : r2.mapToProps(e5, void 0);
    };
    return r2.dependsOnOwnProps = true, r2.mapToProps = function(t4, n3) {
      r2.mapToProps = e4, r2.dependsOnOwnProps = Ye(e4);
      let i2 = r2(t4, n3);
      return typeof i2 == `function` && (r2.mapToProps = i2, r2.dependsOnOwnProps = Ye(i2), i2 = r2(t4, n3)), i2;
    }, r2;
  };
}
function Ze(e4, t2) {
  return (n2, r2) => {
    throw Error(`Invalid value of type ${typeof e4} for ${t2} argument when connecting component ${r2.wrappedComponentName}.`);
  };
}
function Qe(e4) {
  return e4 && typeof e4 == `object` ? Je((t2) => qe(e4, t2)) : e4 ? typeof e4 == `function` ? Xe(e4, `mapDispatchToProps`) : Ze(e4, `mapDispatchToProps`) : Je((e5) => ({ dispatch: e5 }));
}
function $e(e4) {
  return e4 ? typeof e4 == `function` ? Xe(e4, `mapStateToProps`) : Ze(e4, `mapStateToProps`) : Je(() => ({}));
}
function et(e4, t2, n2) {
  return { ...n2, ...e4, ...t2 };
}
function tt(e4) {
  return function(t2, { displayName: n2, areMergedPropsEqual: r2 }) {
    let i2 = false, a2;
    return function(t3, n3, o2) {
      let s2 = e4(t3, n3, o2);
      return i2 ? r2(s2, a2) || (a2 = s2) : (i2 = true, a2 = s2), a2;
    };
  };
}
function nt(e4) {
  return e4 ? typeof e4 == `function` ? tt(e4) : Ze(e4, `mergeProps`) : () => et;
}
function rt(e4) {
  e4();
}
function it() {
  let e4 = null, t2 = null;
  return { clear() {
    e4 = null, t2 = null;
  }, notify() {
    rt(() => {
      let t3 = e4;
      for (; t3; ) t3.callback(), t3 = t3.next;
    });
  }, get() {
    let t3 = [], n2 = e4;
    for (; n2; ) t3.push(n2), n2 = n2.next;
    return t3;
  }, subscribe(n2) {
    let r2 = true, i2 = t2 = { callback: n2, next: null, prev: t2 };
    return i2.prev ? i2.prev.next = i2 : e4 = i2, function() {
      r2 && e4 !== null && (r2 = false, i2.next ? i2.next.prev = i2.prev : t2 = i2.prev, i2.prev ? i2.prev.next = i2.next : e4 = i2.next);
    };
  } };
}
var at = { notify() {
}, get: () => [] };
function ot(e4, t2) {
  let n2, r2 = at, i2 = 0, a2 = false;
  function o2(e5) {
    u2();
    let t3 = r2.subscribe(e5), n3 = false;
    return () => {
      n3 || (n3 = true, t3(), d2());
    };
  }
  function s2() {
    r2.notify();
  }
  function c2() {
    m2.onStateChange && m2.onStateChange();
  }
  function l2() {
    return a2;
  }
  function u2() {
    i2++, n2 || (n2 = t2 ? t2.addNestedSub(c2) : e4.subscribe(c2), r2 = it());
  }
  function d2() {
    i2--, n2 && i2 === 0 && (n2(), n2 = void 0, r2.clear(), r2 = at);
  }
  function f2() {
    a2 || (a2 = true, u2());
  }
  function p2() {
    a2 && (a2 = false, d2());
  }
  let m2 = { addNestedSub: o2, notifyNestedSubs: s2, handleChangeWrapper: c2, isSubscribed: l2, trySubscribe: f2, tryUnsubscribe: p2, getListeners: () => r2 };
  return m2;
}
var st = typeof window < `u` && window.document !== void 0 && window.document.createElement !== void 0, ct = typeof navigator < `u` && navigator.product === `ReactNative`, lt = st || ct ? o : m;
function ut(e4, t2) {
  return e4 === t2 ? e4 !== 0 || t2 !== 0 || 1 / e4 == 1 / t2 : e4 !== e4 && t2 !== t2;
}
function dt(e4, t2) {
  if (ut(e4, t2)) return true;
  if (typeof e4 != `object` || !e4 || typeof t2 != `object` || !t2) return false;
  let n2 = Object.keys(e4), r2 = Object.keys(t2);
  if (n2.length !== r2.length) return false;
  for (let r3 = 0; r3 < n2.length; r3++) if (!Object.prototype.hasOwnProperty.call(t2, n2[r3]) || !ut(e4[n2[r3]], t2[n2[r3]])) return false;
  return true;
}
var ft = { childContextTypes: true, contextType: true, contextTypes: true, defaultProps: true, displayName: true, getDefaultProps: true, getDerivedStateFromError: true, getDerivedStateFromProps: true, mixins: true, propTypes: true, type: true }, pt = { name: true, length: true, prototype: true, caller: true, callee: true, arguments: true, arity: true }, mt = { $$typeof: true, render: true, defaultProps: true, displayName: true, propTypes: true }, ht = { $$typeof: true, compare: true, defaultProps: true, displayName: true, propTypes: true, type: true }, gt = { [Ve]: mt, [He]: ht };
function _t(e4) {
  return We(e4) ? ht : gt[e4.$$typeof] || ft;
}
var vt = Object.defineProperty, yt = Object.getOwnPropertyNames, bt = Object.getOwnPropertySymbols, xt = Object.getOwnPropertyDescriptor, St = Object.getPrototypeOf, Ct = Object.prototype;
function wt(e4, t2) {
  if (typeof t2 != `string`) {
    if (Ct) {
      let n3 = St(t2);
      n3 && n3 !== Ct && wt(e4, n3);
    }
    let n2 = yt(t2);
    bt && (n2 = n2.concat(bt(t2)));
    let r2 = _t(e4), i2 = _t(t2);
    for (let a2 = 0; a2 < n2.length; ++a2) {
      let o2 = n2[a2];
      if (!pt[o2] && !(i2 && i2[o2]) && !(r2 && r2[o2])) {
        let n3 = xt(t2, o2);
        try {
          vt(e4, o2, n3);
        } catch {
        }
      }
    }
  }
  return e4;
}
var Tt = /* @__PURE__ */ Symbol.for(`react-redux-context`), Et = typeof globalThis < `u` ? globalThis : {};
function Dt() {
  if (!g) return {};
  let e4 = Et[Tt] ?? (Et[Tt] = /* @__PURE__ */ new Map()), t2 = e4.get(g);
  return t2 || (t2 = g(null), e4.set(g, t2)), t2;
}
var Ot = Dt(), kt = [null, null];
function At(e4, t2, n2) {
  lt(() => e4(...t2), n2);
}
function jt(e4, t2, n2, r2, i2, a2) {
  e4.current = r2, n2.current = false, i2.current && (i2.current = null, a2());
}
function Mt(e4, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2) {
  if (!e4) return () => {
  };
  let d2 = false, f2 = null, p2 = () => {
    if (d2 || !s2.current) return;
    let e5 = t2.getState(), n3, p3;
    try {
      n3 = r2(e5, i2.current);
    } catch (e6) {
      p3 = e6, f2 = e6;
    }
    p3 || (f2 = null), n3 === a2.current ? o2.current || l2() : (a2.current = n3, c2.current = n3, o2.current = true, u2());
  };
  return n2.onStateChange = p2, n2.trySubscribe(), p2(), () => {
    if (d2 = true, n2.tryUnsubscribe(), n2.onStateChange = null, f2) throw f2;
  };
}
function Nt(e4, t2) {
  return e4 === t2;
}
function Pt(e4, t2, n2, { pure: i2, areStatesEqual: o2 = Nt, areOwnPropsEqual: l2 = dt, areStatePropsEqual: d2 = dt, areMergedPropsEqual: p2 = dt, forwardRef: m2 = false, context: g2 = Ot } = {}) {
  let _2 = g2, v2 = $e(e4), y2 = Qe(t2), b2 = nt(n2), x2 = !!e4;
  return (e5) => {
    let t3 = e5.displayName || e5.name || `Component`, n3 = `Connect(${t3})`, i3 = { shouldHandleStateChanges: x2, displayName: n3, wrappedComponentName: t3, WrappedComponent: e5, initMapStateToProps: v2, initMapDispatchToProps: y2, initMergeProps: b2, areStatesEqual: o2, areStatePropsEqual: d2, areOwnPropsEqual: l2, areMergedPropsEqual: p2 };
    function g3(t4) {
      let [n4, o3, l3] = s(() => {
        let { reactReduxForwardedRef: e6, ...n5 } = t4;
        return [t4.context, e6, n5];
      }, [t4]), u2 = s(() => {
        let e6 = _2;
        return n4 == null ? void 0 : n4.Consumer, e6;
      }, [n4, _2]), d3 = c(u2), p3 = !!t4.store && !!t4.store.getState && !!t4.store.dispatch, m3 = !!d3 && !!d3.store, h2 = p3 ? t4.store : d3.store, g4 = m3 ? d3.getServerState : h2.getState, v3 = s(() => Ke(h2.dispatch, i3), [h2]), [y3, b3] = s(() => {
        if (!x2) return kt;
        let e6 = ot(h2, p3 ? void 0 : d3.subscription);
        return [e6, e6.notifyNestedSubs.bind(e6)];
      }, [h2, p3, d3]), S3 = s(() => p3 ? d3 : { ...d3, subscription: y3 }, [p3, d3, y3]), C2 = r(void 0), w2 = r(l3), T2 = r(void 0), E2 = r(false), D2 = r(false), ee2 = r(void 0);
      lt(() => (D2.current = true, () => {
        D2.current = false;
      }), []);
      let te2 = s(() => () => T2.current && l3 === w2.current ? T2.current : v3(h2.getState(), l3), [h2, l3]), ne2 = s(() => (e6) => y3 ? Mt(x2, h2, y3, v3, w2, C2, E2, D2, T2, b3, e6) : () => {
      }, [y3]);
      At(jt, [w2, C2, E2, l3, T2, b3]);
      let re2;
      try {
        re2 = a(ne2, te2, g4 ? () => v3(g4(), l3) : te2);
      } catch (e6) {
        throw ee2.current && (e6.message += `
The error may be correlated with this previous error:
${ee2.current.stack}

`), e6;
      }
      lt(() => {
        ee2.current = void 0, T2.current = void 0, C2.current = re2;
      });
      let ie2 = s(() => f(e5, { ...re2, ref: o3 }), [o3, e5, re2]);
      return s(() => x2 ? f(u2.Provider, { value: S3 }, ie2) : ie2, [u2, ie2, S3]);
    }
    let S2 = h(g3);
    if (S2.WrappedComponent = e5, S2.displayName = g3.displayName = n3, m2) {
      let t4 = u(function(e6, t5) {
        return f(S2, { ...e6, reactReduxForwardedRef: t5 });
      });
      return t4.displayName = n3, t4.WrappedComponent = e5, wt(t4, e5);
    }
    return wt(S2, e5);
  };
}
var Ft = Pt;
function It(e4) {
  let { children: t2, context: n2, serverState: r2, store: i2 } = e4, a2 = s(() => {
    let e5 = ot(i2);
    return { store: i2, subscription: e5, getServerState: r2 ? () => r2 : void 0 };
  }, [i2, r2]), o2 = s(() => i2.getState(), [i2]);
  return lt(() => {
    let { subscription: e5 } = a2;
    return e5.onStateChange = e5.notifyNestedSubs, e5.trySubscribe(), o2 !== i2.getState() && e5.notifyNestedSubs(), () => {
      e5.tryUnsubscribe(), e5.onStateChange = void 0;
    };
  }, [a2, o2]), f((n2 || Ot).Provider, { value: a2 }, t2);
}
var Lt = It, Rt = `Invariant failed`;
function zt(e4, t2) {
  if (!e4) throw Error(Rt);
}
var N = function(e4) {
  var t2 = e4.top, n2 = e4.right, r2 = e4.bottom, i2 = e4.left;
  return { top: t2, right: n2, bottom: r2, left: i2, width: n2 - i2, height: r2 - t2, x: i2, y: t2, center: { x: (n2 + i2) / 2, y: (r2 + t2) / 2 } };
}, Bt = function(e4, t2) {
  return { top: e4.top - t2.top, left: e4.left - t2.left, bottom: e4.bottom + t2.bottom, right: e4.right + t2.right };
}, Vt = function(e4, t2) {
  return { top: e4.top + t2.top, left: e4.left + t2.left, bottom: e4.bottom - t2.bottom, right: e4.right - t2.right };
}, Ht = function(e4, t2) {
  return { top: e4.top + t2.y, left: e4.left + t2.x, bottom: e4.bottom + t2.y, right: e4.right + t2.x };
}, Ut = { top: 0, right: 0, bottom: 0, left: 0 }, Wt = function(e4) {
  var t2 = e4.borderBox, n2 = e4.margin, r2 = n2 === void 0 ? Ut : n2, i2 = e4.border, a2 = i2 === void 0 ? Ut : i2, o2 = e4.padding, s2 = o2 === void 0 ? Ut : o2, c2 = N(Bt(t2, r2)), l2 = N(Vt(t2, a2)), u2 = N(Vt(l2, s2));
  return { marginBox: c2, borderBox: N(t2), paddingBox: l2, contentBox: u2, margin: r2, border: a2, padding: s2 };
}, P = function(e4) {
  var t2 = e4.slice(0, -2);
  if (e4.slice(-2) !== `px`) return 0;
  var n2 = Number(t2);
  return isNaN(n2) && zt(false), n2;
}, Gt = function() {
  return { x: window.pageXOffset, y: window.pageYOffset };
}, Kt = function(e4, t2) {
  var n2 = e4.borderBox, r2 = e4.border, i2 = e4.margin, a2 = e4.padding;
  return Wt({ borderBox: Ht(n2, t2), border: r2, margin: i2, padding: a2 });
}, qt = function(e4, t2) {
  return t2 === void 0 && (t2 = Gt()), Kt(e4, t2);
}, Jt = function(e4, t2) {
  return Wt({ borderBox: e4, margin: { top: P(t2.marginTop), right: P(t2.marginRight), bottom: P(t2.marginBottom), left: P(t2.marginLeft) }, padding: { top: P(t2.paddingTop), right: P(t2.paddingRight), bottom: P(t2.paddingBottom), left: P(t2.paddingLeft) }, border: { top: P(t2.borderTopWidth), right: P(t2.borderRightWidth), bottom: P(t2.borderBottomWidth), left: P(t2.borderLeftWidth) } });
}, Yt = function(e4) {
  return Jt(e4.getBoundingClientRect(), window.getComputedStyle(e4));
}, Xt = function(e4) {
  var t2 = [], n2 = null, r2 = function() {
    t2 = [...arguments], !n2 && (n2 = requestAnimationFrame(function() {
      n2 = null, e4.apply(void 0, t2);
    }));
  };
  return r2.cancel = function() {
    n2 && (n2 = (cancelAnimationFrame(n2), null));
  }, r2;
};
function Zt() {
  return Zt = Object.assign ? Object.assign.bind() : function(e4) {
    for (var t2 = 1; t2 < arguments.length; t2++) {
      var n2 = arguments[t2];
      for (var r2 in n2) ({}).hasOwnProperty.call(n2, r2) && (e4[r2] = n2[r2]);
    }
    return e4;
  }, Zt.apply(null, arguments);
}
n();
function Qt(e4, t2) {
}
Qt.bind(null, `warn`), Qt.bind(null, `error`);
function F() {
}
function $t(e4, t2) {
  return { ...e4, ...t2 };
}
function I(e4, t2, n2) {
  let r2 = t2.map((t3) => {
    let r3 = $t(n2, t3.options);
    return e4.addEventListener(t3.eventName, t3.fn, r3), function() {
      e4.removeEventListener(t3.eventName, t3.fn, r3);
    };
  });
  return function() {
    r2.forEach((e5) => {
      e5();
    });
  };
}
var en = `Invariant failed`, tn = class extends Error {
};
tn.prototype.toString = function() {
  return this.message;
};
function L(e4, t2) {
  throw new tn(en);
}
var nn = class extends p.Component {
  constructor(...e4) {
    super(...e4), this.callbacks = null, this.unbind = F, this.onWindowError = (e5) => {
      let t2 = this.getCallbacks();
      t2.isDragging() && t2.tryAbort(), e5.error instanceof tn && e5.preventDefault();
    }, this.getCallbacks = () => {
      if (!this.callbacks) throw Error(`Unable to find AppCallbacks in <ErrorBoundary/>`);
      return this.callbacks;
    }, this.setCallbacks = (e5) => {
      this.callbacks = e5;
    };
  }
  componentDidMount() {
    this.unbind = I(window, [{ eventName: `error`, fn: this.onWindowError }]);
  }
  componentDidCatch(e4) {
    if (e4 instanceof tn) {
      this.setState({});
      return;
    }
    throw e4;
  }
  componentWillUnmount() {
    this.unbind();
  }
  render() {
    return this.props.children(this.setCallbacks);
  }
}, rn = `
  Press space bar to start a drag.
  When dragging you can use the arrow keys to move the item around and escape to cancel.
  Some screen readers may require you to be in focus mode or to use your pass through key
`, an = (e4) => e4 + 1, on = (e4) => `
  You have lifted an item in position ${an(e4.source.index)}
`, sn = (e4, t2) => {
  let n2 = e4.droppableId === t2.droppableId, r2 = an(e4.index), i2 = an(t2.index);
  return n2 ? `
      You have moved the item from position ${r2}
      to position ${i2}
    ` : `
    You have moved the item from position ${r2}
    in list ${e4.droppableId}
    to list ${t2.droppableId}
    in position ${i2}
  `;
}, cn = (e4, t2, n2) => t2.droppableId === n2.droppableId ? `
      The item ${e4}
      has been combined with ${n2.draggableId}` : `
      The item ${e4}
      in list ${t2.droppableId}
      has been combined with ${n2.draggableId}
      in list ${n2.droppableId}
    `, ln = (e4) => {
  let t2 = e4.destination;
  if (t2) return sn(e4.source, t2);
  let n2 = e4.combine;
  return n2 ? cn(e4.draggableId, e4.source, n2) : `You are over an area that cannot be dropped on`;
}, un = (e4) => `
  The item has returned to its starting position
  of ${an(e4.index)}
`, dn = { dragHandleUsageInstructions: rn, onDragStart: on, onDragUpdate: ln, onDragEnd: (e4) => {
  if (e4.reason === `CANCEL`) return `
      Movement cancelled.
      ${un(e4.source)}
    `;
  let t2 = e4.destination, n2 = e4.combine;
  return t2 ? `
      You have dropped the item.
      ${sn(e4.source, t2)}
    ` : n2 ? `
      You have dropped the item.
      ${cn(e4.draggableId, e4.source, n2)}
    ` : `
    The item has been dropped while not over a drop area.
    ${un(e4.source)}
  `;
} };
function fn(e4, t2) {
  return !!(e4 === t2 || Number.isNaN(e4) && Number.isNaN(t2));
}
function pn(e4, t2) {
  if (e4.length !== t2.length) return false;
  for (let n2 = 0; n2 < e4.length; n2++) if (!fn(e4[n2], t2[n2])) return false;
  return true;
}
function R(e4, t2) {
  let n2 = i(() => ({ inputs: t2, result: e4() }))[0], a2 = r(true), o2 = r(n2), s2 = a2.current || t2 && o2.current.inputs && pn(t2, o2.current.inputs) ? o2.current : { inputs: t2, result: e4() };
  return m(() => {
    a2.current = false, o2.current = s2;
  }, [s2]), s2.result;
}
function z(e4, t2) {
  return R(() => e4, t2);
}
var B = { x: 0, y: 0 }, V = (e4, t2) => ({ x: e4.x + t2.x, y: e4.y + t2.y }), H = (e4, t2) => ({ x: e4.x - t2.x, y: e4.y - t2.y }), U = (e4, t2) => e4.x === t2.x && e4.y === t2.y, mn = (e4) => ({ x: e4.x === 0 ? 0 : -e4.x, y: e4.y === 0 ? 0 : -e4.y }), W = (e4, t2, n2 = 0) => e4 === `x` ? { x: t2, y: n2 } : { x: n2, y: t2 }, hn = (e4, t2) => Math.sqrt((t2.x - e4.x) ** 2 + (t2.y - e4.y) ** 2), gn = (e4, t2) => Math.min(...t2.map((t3) => hn(e4, t3))), _n = (e4) => (t2) => ({ x: e4(t2.x), y: e4(t2.y) }), vn = (e4, t2) => {
  let n2 = N({ top: Math.max(t2.top, e4.top), right: Math.min(t2.right, e4.right), bottom: Math.min(t2.bottom, e4.bottom), left: Math.max(t2.left, e4.left) });
  return n2.width <= 0 || n2.height <= 0 ? null : n2;
}, yn = (e4, t2) => ({ top: e4.top + t2.y, left: e4.left + t2.x, bottom: e4.bottom + t2.y, right: e4.right + t2.x }), bn = (e4) => [{ x: e4.left, y: e4.top }, { x: e4.right, y: e4.top }, { x: e4.left, y: e4.bottom }, { x: e4.right, y: e4.bottom }], xn = { top: 0, right: 0, bottom: 0, left: 0 }, Sn = (e4, t2) => t2 ? yn(e4, t2.scroll.diff.displacement) : e4, Cn = (e4, t2, n2) => n2 && n2.increasedBy ? { ...e4, [t2.end]: e4[t2.end] + n2.increasedBy[t2.line] } : e4, wn = (e4, t2) => t2 && t2.shouldClipSubject ? vn(t2.pageMarginBox, e4) : N(e4), Tn = ({ page: e4, withPlaceholder: t2, axis: n2, frame: r2 }) => ({ page: e4, withPlaceholder: t2, active: wn(Cn(Sn(e4.marginBox, r2), n2, t2), r2) }), En = (e4, t2) => {
  !e4.frame && L();
  let n2 = e4.frame, r2 = H(t2, n2.scroll.initial), i2 = mn(r2), a2 = { ...n2, scroll: { initial: n2.scroll.initial, current: t2, diff: { value: r2, displacement: i2 }, max: n2.scroll.max } }, o2 = Tn({ page: e4.subject.page, withPlaceholder: e4.subject.withPlaceholder, axis: e4.axis, frame: a2 });
  return { ...e4, frame: a2, subject: o2 };
};
function G(e4, t2 = pn) {
  let n2 = null;
  function r2(...r3) {
    if (n2 && n2.lastThis === this && t2(r3, n2.lastArgs)) return n2.lastResult;
    let i2 = e4.apply(this, r3);
    return n2 = { lastResult: i2, lastArgs: r3, lastThis: this }, i2;
  }
  return r2.clear = function() {
    n2 = null;
  }, r2;
}
var Dn = G((e4) => e4.reduce((e5, t2) => (e5[t2.descriptor.id] = t2, e5), {})), On = G((e4) => e4.reduce((e5, t2) => (e5[t2.descriptor.id] = t2, e5), {})), kn = G((e4) => Object.values(e4)), An = G((e4) => Object.values(e4)), jn = G((e4, t2) => An(t2).filter((t3) => e4 === t3.descriptor.droppableId).sort((e5, t3) => e5.descriptor.index - t3.descriptor.index));
function Mn(e4) {
  return e4.at && e4.at.type === `REORDER` ? e4.at.destination : null;
}
function Nn(e4) {
  return e4.at && e4.at.type === `COMBINE` ? e4.at.combine : null;
}
var Pn = G((e4, t2) => t2.filter((t3) => t3.descriptor.id !== e4.descriptor.id)), Fn = ({ isMovingForward: e4, draggable: t2, destination: n2, insideDestination: r2, previousImpact: i2 }) => {
  if (!n2.isCombineEnabled || !Mn(i2)) return null;
  function a2(e5) {
    let t3 = { type: `COMBINE`, combine: { draggableId: e5, droppableId: n2.descriptor.id } };
    return { ...i2, at: t3 };
  }
  let o2 = i2.displaced.all, s2 = o2.length ? o2[0] : null;
  if (e4) return s2 ? a2(s2) : null;
  let c2 = Pn(t2, r2);
  if (!s2) {
    if (!c2.length) return null;
    let e5 = c2[c2.length - 1];
    return a2(e5.descriptor.id);
  }
  let l2 = c2.findIndex((e5) => e5.descriptor.id === s2);
  l2 === -1 && L();
  let u2 = l2 - 1;
  if (u2 < 0) return null;
  let d2 = c2[u2];
  return a2(d2.descriptor.id);
}, In = (e4, t2) => e4.descriptor.droppableId === t2.descriptor.id, Ln = { point: B, value: 0 }, Rn = { invisible: {}, visible: {}, all: [] }, zn = { displaced: Rn, displacedBy: Ln, at: null }, K = (e4, t2) => (n2) => e4 <= n2 && n2 <= t2, Bn = (e4) => {
  let t2 = K(e4.top, e4.bottom), n2 = K(e4.left, e4.right);
  return (r2) => {
    if (t2(r2.top) && t2(r2.bottom) && n2(r2.left) && n2(r2.right)) return true;
    let i2 = t2(r2.top) || t2(r2.bottom), a2 = n2(r2.left) || n2(r2.right);
    if (i2 && a2) return true;
    let o2 = r2.top < e4.top && r2.bottom > e4.bottom, s2 = r2.left < e4.left && r2.right > e4.right;
    return o2 && s2 ? true : o2 && a2 || s2 && i2;
  };
}, Vn = (e4) => {
  let t2 = K(e4.top, e4.bottom), n2 = K(e4.left, e4.right);
  return (e5) => t2(e5.top) && t2(e5.bottom) && n2(e5.left) && n2(e5.right);
}, Hn = { direction: `vertical`, line: `y`, crossAxisLine: `x`, start: `top`, end: `bottom`, size: `height`, crossAxisStart: `left`, crossAxisEnd: `right`, crossAxisSize: `width` }, Un = { direction: `horizontal`, line: `x`, crossAxisLine: `y`, start: `left`, end: `right`, size: `width`, crossAxisStart: `top`, crossAxisEnd: `bottom`, crossAxisSize: `height` }, Wn = (e4) => (t2) => {
  let n2 = K(t2.top, t2.bottom), r2 = K(t2.left, t2.right);
  return (t3) => e4 === Hn ? n2(t3.top) && n2(t3.bottom) : r2(t3.left) && r2(t3.right);
}, Gn = (e4, t2) => yn(e4, t2.frame ? t2.frame.scroll.diff.displacement : B), Kn = (e4, t2, n2) => t2.subject.active ? n2(t2.subject.active)(e4) : false, qn = (e4, t2, n2) => n2(t2)(e4), Jn = ({ target: e4, destination: t2, viewport: n2, withDroppableDisplacement: r2, isVisibleThroughFrameFn: i2 }) => {
  let a2 = r2 ? Gn(e4, t2) : e4;
  return Kn(a2, t2, i2) && qn(a2, n2, i2);
}, Yn = (e4) => Jn({ ...e4, isVisibleThroughFrameFn: Bn }), Xn = (e4) => Jn({ ...e4, isVisibleThroughFrameFn: Vn }), Zn = (e4) => Jn({ ...e4, isVisibleThroughFrameFn: Wn(e4.destination.axis) }), Qn = (e4, t2, n2) => {
  if (typeof n2 == `boolean`) return n2;
  if (!t2) return true;
  let { invisible: r2, visible: i2 } = t2;
  if (r2[e4]) return false;
  let a2 = i2[e4];
  return !a2 || a2.shouldAnimate;
};
function $n(e4, t2) {
  let n2 = e4.page.marginBox;
  return N(Bt(n2, { top: t2.point.y, right: 0, bottom: 0, left: t2.point.x }));
}
function er({ afterDragging: e4, destination: t2, displacedBy: n2, viewport: r2, forceShouldAnimate: i2, last: a2 }) {
  return e4.reduce(function(e5, o2) {
    let s2 = $n(o2, n2), c2 = o2.descriptor.id;
    if (e5.all.push(c2), !Yn({ target: s2, destination: t2, viewport: r2, withDroppableDisplacement: true })) return e5.invisible[o2.descriptor.id] = true, e5;
    let l2 = { draggableId: c2, shouldAnimate: Qn(c2, a2, i2) };
    return e5.visible[c2] = l2, e5;
  }, { all: [], visible: {}, invisible: {} });
}
function tr(e4, t2) {
  if (!e4.length) return 0;
  let n2 = e4[e4.length - 1].descriptor.index;
  return t2.inHomeList ? n2 : n2 + 1;
}
function nr({ insideDestination: e4, inHomeList: t2, displacedBy: n2, destination: r2 }) {
  let i2 = tr(e4, { inHomeList: t2 });
  return { displaced: Rn, displacedBy: n2, at: { type: `REORDER`, destination: { droppableId: r2.descriptor.id, index: i2 } } };
}
function rr({ draggable: e4, insideDestination: t2, destination: n2, viewport: r2, displacedBy: i2, last: a2, index: o2, forceShouldAnimate: s2 }) {
  let c2 = In(e4, n2);
  if (o2 == null) return nr({ insideDestination: t2, inHomeList: c2, displacedBy: i2, destination: n2 });
  let l2 = t2.find((e5) => e5.descriptor.index === o2);
  if (!l2) return nr({ insideDestination: t2, inHomeList: c2, displacedBy: i2, destination: n2 });
  let u2 = Pn(e4, t2), d2 = t2.indexOf(l2);
  return { displaced: er({ afterDragging: u2.slice(d2), destination: n2, displacedBy: i2, last: a2, viewport: r2.frame, forceShouldAnimate: s2 }), displacedBy: i2, at: { type: `REORDER`, destination: { droppableId: n2.descriptor.id, index: o2 } } };
}
function q(e4, t2) {
  return !!t2.effected[e4];
}
var ir = ({ isMovingForward: e4, destination: t2, draggables: n2, combine: r2, afterCritical: i2 }) => {
  if (!t2.isCombineEnabled) return null;
  let a2 = r2.draggableId, o2 = n2[a2].descriptor.index;
  return q(a2, i2) ? e4 ? o2 : o2 - 1 : e4 ? o2 + 1 : o2;
}, ar = ({ isMovingForward: e4, isInHomeList: t2, insideDestination: n2, location: r2 }) => {
  if (!n2.length) return null;
  let i2 = r2.index, a2 = e4 ? i2 + 1 : i2 - 1, o2 = n2[0].descriptor.index, s2 = n2[n2.length - 1].descriptor.index, c2 = t2 ? s2 : s2 + 1;
  return a2 < o2 || a2 > c2 ? null : a2;
}, or = ({ isMovingForward: e4, isInHomeList: t2, draggable: n2, draggables: r2, destination: i2, insideDestination: a2, previousImpact: o2, viewport: s2, afterCritical: c2 }) => {
  let l2 = o2.at;
  if (!l2 && L(), l2.type === `REORDER`) {
    let r3 = ar({ isMovingForward: e4, isInHomeList: t2, location: l2.destination, insideDestination: a2 });
    return r3 == null ? null : rr({ draggable: n2, insideDestination: a2, destination: i2, viewport: s2, last: o2.displaced, displacedBy: o2.displacedBy, index: r3 });
  }
  let u2 = ir({ isMovingForward: e4, destination: i2, displaced: o2.displaced, draggables: r2, combine: l2.combine, afterCritical: c2 });
  return u2 == null ? null : rr({ draggable: n2, insideDestination: a2, destination: i2, viewport: s2, last: o2.displaced, displacedBy: o2.displacedBy, index: u2 });
}, sr = ({ displaced: e4, afterCritical: t2, combineWith: n2, displacedBy: r2 }) => {
  let i2 = !!(e4.visible[n2] || e4.invisible[n2]);
  return q(n2, t2) ? i2 ? B : mn(r2.point) : i2 ? r2.point : B;
}, cr = ({ afterCritical: e4, impact: t2, draggables: n2 }) => {
  let r2 = Nn(t2);
  !r2 && L();
  let i2 = r2.draggableId, a2 = n2[i2].page.borderBox.center;
  return V(a2, sr({ displaced: t2.displaced, afterCritical: e4, combineWith: i2, displacedBy: t2.displacedBy }));
}, lr = (e4, t2) => t2.margin[e4.start] + t2.borderBox[e4.size] / 2, ur = (e4, t2) => t2.margin[e4.end] + t2.borderBox[e4.size] / 2, dr = (e4, t2, n2) => t2[e4.crossAxisStart] + n2.margin[e4.crossAxisStart] + n2.borderBox[e4.crossAxisSize] / 2, fr = ({ axis: e4, moveRelativeTo: t2, isMoving: n2 }) => W(e4.line, t2.marginBox[e4.end] + lr(e4, n2), dr(e4, t2.marginBox, n2)), pr = ({ axis: e4, moveRelativeTo: t2, isMoving: n2 }) => W(e4.line, t2.marginBox[e4.start] - ur(e4, n2), dr(e4, t2.marginBox, n2)), mr = ({ axis: e4, moveInto: t2, isMoving: n2 }) => W(e4.line, t2.contentBox[e4.start] + lr(e4, n2), dr(e4, t2.contentBox, n2)), hr = ({ impact: e4, draggable: t2, draggables: n2, droppable: r2, afterCritical: i2 }) => {
  let a2 = jn(r2.descriptor.id, n2), o2 = t2.page, s2 = r2.axis;
  if (!a2.length) return mr({ axis: s2, moveInto: r2.page, isMoving: o2 });
  let { displaced: c2, displacedBy: l2 } = e4, u2 = c2.all[0];
  if (u2) {
    let e5 = n2[u2];
    return q(u2, i2) ? pr({ axis: s2, moveRelativeTo: e5.page, isMoving: o2 }) : pr({ axis: s2, moveRelativeTo: Kt(e5.page, l2.point), isMoving: o2 });
  }
  let d2 = a2[a2.length - 1];
  return d2.descriptor.id === t2.descriptor.id ? o2.borderBox.center : q(d2.descriptor.id, i2) ? fr({ axis: s2, moveRelativeTo: Kt(d2.page, mn(i2.displacedBy.point)), isMoving: o2 }) : fr({ axis: s2, moveRelativeTo: d2.page, isMoving: o2 });
}, gr = (e4, t2) => {
  let n2 = e4.frame;
  return n2 ? V(t2, n2.scroll.diff.displacement) : t2;
}, _r = ({ impact: e4, draggable: t2, droppable: n2, draggables: r2, afterCritical: i2 }) => {
  let a2 = t2.page.borderBox.center, o2 = e4.at;
  return !n2 || !o2 ? a2 : o2.type === `REORDER` ? hr({ impact: e4, draggable: t2, draggables: r2, droppable: n2, afterCritical: i2 }) : cr({ impact: e4, draggables: r2, afterCritical: i2 });
}, vr = (e4) => {
  let t2 = _r(e4), n2 = e4.droppable;
  return n2 ? gr(n2, t2) : t2;
}, yr = (e4, t2) => {
  let n2 = H(t2, e4.scroll.initial), r2 = mn(n2);
  return { frame: N({ top: t2.y, bottom: t2.y + e4.frame.height, left: t2.x, right: t2.x + e4.frame.width }), scroll: { initial: e4.scroll.initial, max: e4.scroll.max, current: t2, diff: { value: n2, displacement: r2 } } };
};
function br(e4, t2) {
  return e4.map((e5) => t2[e5]);
}
function xr(e4, t2) {
  for (let n2 = 0; n2 < t2.length; n2++) {
    let r2 = t2[n2].visible[e4];
    if (r2) return r2;
  }
  return null;
}
var Sr = ({ impact: e4, viewport: t2, destination: n2, draggables: r2, maxScrollChange: i2 }) => {
  let a2 = yr(t2, V(t2.scroll.current, i2)), o2 = n2.frame ? En(n2, V(n2.frame.scroll.current, i2)) : n2, s2 = e4.displaced, c2 = er({ afterDragging: br(s2.all, r2), destination: n2, displacedBy: e4.displacedBy, viewport: a2.frame, last: s2, forceShouldAnimate: false }), l2 = er({ afterDragging: br(s2.all, r2), destination: o2, displacedBy: e4.displacedBy, viewport: t2.frame, last: s2, forceShouldAnimate: false }), u2 = {}, d2 = {}, f2 = [s2, c2, l2];
  return s2.all.forEach((e5) => {
    let t3 = xr(e5, f2);
    if (t3) {
      d2[e5] = t3;
      return;
    }
    u2[e5] = true;
  }), { ...e4, displaced: { all: s2.all, invisible: u2, visible: d2 } };
}, Cr = (e4, t2) => V(e4.scroll.diff.displacement, t2), wr = ({ pageBorderBoxCenter: e4, draggable: t2, viewport: n2 }) => {
  let r2 = H(Cr(n2, e4), t2.page.borderBox.center);
  return V(t2.client.borderBox.center, r2);
}, Tr = ({ draggable: e4, destination: t2, newPageBorderBoxCenter: n2, viewport: r2, withDroppableDisplacement: i2, onlyOnMainAxis: a2 = false }) => {
  let o2 = H(n2, e4.page.borderBox.center), s2 = { target: yn(e4.page.borderBox, o2), destination: t2, withDroppableDisplacement: i2, viewport: r2 };
  return a2 ? Zn(s2) : Xn(s2);
}, Er = ({ isMovingForward: e4, draggable: t2, destination: n2, draggables: r2, previousImpact: i2, viewport: a2, previousPageBorderBoxCenter: o2, previousClientSelection: s2, afterCritical: c2 }) => {
  if (!n2.isEnabled) return null;
  let l2 = jn(n2.descriptor.id, r2), u2 = In(t2, n2), d2 = Fn({ isMovingForward: e4, draggable: t2, destination: n2, insideDestination: l2, previousImpact: i2 }) || or({ isMovingForward: e4, isInHomeList: u2, draggable: t2, draggables: r2, destination: n2, insideDestination: l2, previousImpact: i2, viewport: a2, afterCritical: c2 });
  if (!d2) return null;
  let f2 = vr({ impact: d2, draggable: t2, droppable: n2, draggables: r2, afterCritical: c2 });
  if (Tr({ draggable: t2, destination: n2, newPageBorderBoxCenter: f2, viewport: a2.frame, withDroppableDisplacement: false, onlyOnMainAxis: true })) return { clientSelection: wr({ pageBorderBoxCenter: f2, draggable: t2, viewport: a2 }), impact: d2, scrollJumpRequest: null };
  let p2 = H(f2, o2);
  return { clientSelection: s2, impact: Sr({ impact: d2, viewport: a2, destination: n2, draggables: r2, maxScrollChange: p2 }), scrollJumpRequest: p2 };
}, J = (e4) => {
  let t2 = e4.subject.active;
  return !t2 && L(), t2;
}, Dr = ({ isMovingForward: e4, pageBorderBoxCenter: t2, source: n2, droppables: r2, viewport: i2 }) => {
  let a2 = n2.subject.active;
  if (!a2) return null;
  let o2 = n2.axis, s2 = K(a2[o2.start], a2[o2.end]), c2 = kn(r2).filter((e5) => e5 !== n2).filter((e5) => e5.isEnabled).filter((e5) => !!e5.subject.active).filter((e5) => Bn(i2.frame)(J(e5))).filter((t3) => {
    let n3 = J(t3);
    return e4 ? a2[o2.crossAxisEnd] < n3[o2.crossAxisEnd] : n3[o2.crossAxisStart] < a2[o2.crossAxisStart];
  }).filter((e5) => {
    let t3 = J(e5), n3 = K(t3[o2.start], t3[o2.end]);
    return s2(t3[o2.start]) || s2(t3[o2.end]) || n3(a2[o2.start]) || n3(a2[o2.end]);
  }).sort((t3, n3) => {
    let r3 = J(t3)[o2.crossAxisStart], i3 = J(n3)[o2.crossAxisStart];
    return e4 ? r3 - i3 : i3 - r3;
  }).filter((e5, t3, n3) => J(e5)[o2.crossAxisStart] === J(n3[0])[o2.crossAxisStart]);
  if (!c2.length) return null;
  if (c2.length === 1) return c2[0];
  let l2 = c2.filter((e5) => K(J(e5)[o2.start], J(e5)[o2.end])(t2[o2.line]));
  return l2.length === 1 ? l2[0] : l2.length > 1 ? l2.sort((e5, t3) => J(e5)[o2.start] - J(t3)[o2.start])[0] : c2.sort((e5, n3) => {
    let r3 = gn(t2, bn(J(e5))), i3 = gn(t2, bn(J(n3)));
    return r3 === i3 ? J(e5)[o2.start] - J(n3)[o2.start] : r3 - i3;
  })[0];
}, Or = (e4, t2) => {
  let n2 = e4.page.borderBox.center;
  return q(e4.descriptor.id, t2) ? H(n2, t2.displacedBy.point) : n2;
}, kr = (e4, t2) => {
  let n2 = e4.page.borderBox;
  return q(e4.descriptor.id, t2) ? yn(n2, mn(t2.displacedBy.point)) : n2;
}, Ar = ({ pageBorderBoxCenter: e4, viewport: t2, destination: n2, insideDestination: r2, afterCritical: i2 }) => r2.filter((e5) => Xn({ target: kr(e5, i2), destination: n2, viewport: t2.frame, withDroppableDisplacement: true })).sort((t3, r3) => {
  let a2 = hn(e4, gr(n2, Or(t3, i2))), o2 = hn(e4, gr(n2, Or(r3, i2)));
  return a2 < o2 ? -1 : o2 < a2 ? 1 : t3.descriptor.index - r3.descriptor.index;
})[0] || null, jr = G(function(e4, t2) {
  let n2 = t2[e4.line];
  return { value: n2, point: W(e4.line, n2) };
}), Mr = (e4, t2, n2) => {
  let r2 = e4.axis;
  if (e4.descriptor.mode === `virtual`) return W(r2.line, t2[r2.line]);
  let i2 = e4.subject.page.contentBox[r2.size], a2 = jn(e4.descriptor.id, n2).reduce((e5, t3) => e5 + t3.client.marginBox[r2.size], 0) + t2[r2.line] - i2;
  return a2 <= 0 ? null : W(r2.line, a2);
}, Nr = (e4, t2) => ({ ...e4, scroll: { ...e4.scroll, max: t2 } }), Pr = (e4, t2, n2) => {
  let r2 = e4.frame;
  In(t2, e4) && L(), e4.subject.withPlaceholder && L();
  let i2 = jr(e4.axis, t2.displaceBy).point, a2 = Mr(e4, i2, n2), o2 = { placeholderSize: i2, increasedBy: a2, oldFrameMaxScroll: e4.frame ? e4.frame.scroll.max : null };
  if (!r2) {
    let t3 = Tn({ page: e4.subject.page, withPlaceholder: o2, axis: e4.axis, frame: e4.frame });
    return { ...e4, subject: t3 };
  }
  let s2 = Nr(r2, a2 ? V(r2.scroll.max, a2) : r2.scroll.max), c2 = Tn({ page: e4.subject.page, withPlaceholder: o2, axis: e4.axis, frame: s2 });
  return { ...e4, subject: c2, frame: s2 };
}, Fr = (e4) => {
  let t2 = e4.subject.withPlaceholder;
  !t2 && L();
  let n2 = e4.frame;
  if (!n2) {
    let t3 = Tn({ page: e4.subject.page, axis: e4.axis, frame: null, withPlaceholder: null });
    return { ...e4, subject: t3 };
  }
  let r2 = t2.oldFrameMaxScroll;
  !r2 && L();
  let i2 = Nr(n2, r2), a2 = Tn({ page: e4.subject.page, axis: e4.axis, frame: i2, withPlaceholder: null });
  return { ...e4, subject: a2, frame: i2 };
}, Ir = ({ previousPageBorderBoxCenter: e4, moveRelativeTo: t2, insideDestination: n2, draggable: r2, draggables: i2, destination: a2, viewport: o2, afterCritical: s2 }) => {
  if (!t2) {
    if (n2.length) return null;
    let e5 = { displaced: Rn, displacedBy: Ln, at: { type: `REORDER`, destination: { droppableId: a2.descriptor.id, index: 0 } } }, t3 = vr({ impact: e5, draggable: r2, droppable: a2, draggables: i2, afterCritical: s2 });
    return Tr({ draggable: r2, destination: In(r2, a2) ? a2 : Pr(a2, r2, i2), newPageBorderBoxCenter: t3, viewport: o2.frame, withDroppableDisplacement: false, onlyOnMainAxis: true }) ? e5 : null;
  }
  let c2 = e4[a2.axis.line] <= t2.page.borderBox.center[a2.axis.line], l2 = (() => {
    let e5 = t2.descriptor.index;
    return t2.descriptor.id === r2.descriptor.id || c2 ? e5 : e5 + 1;
  })();
  return rr({ draggable: r2, insideDestination: n2, destination: a2, viewport: o2, displacedBy: jr(a2.axis, r2.displaceBy), last: Rn, index: l2 });
}, Lr = ({ isMovingForward: e4, previousPageBorderBoxCenter: t2, draggable: n2, isOver: r2, draggables: i2, droppables: a2, viewport: o2, afterCritical: s2 }) => {
  let c2 = Dr({ isMovingForward: e4, pageBorderBoxCenter: t2, source: r2, droppables: a2, viewport: o2 });
  if (!c2) return null;
  let l2 = jn(c2.descriptor.id, i2), u2 = Ir({ previousPageBorderBoxCenter: t2, destination: c2, draggable: n2, draggables: i2, moveRelativeTo: Ar({ pageBorderBoxCenter: t2, viewport: o2, destination: c2, insideDestination: l2, afterCritical: s2 }), insideDestination: l2, viewport: o2, afterCritical: s2 });
  return u2 ? { clientSelection: wr({ pageBorderBoxCenter: vr({ impact: u2, draggable: n2, droppable: c2, draggables: i2, afterCritical: s2 }), draggable: n2, viewport: o2 }), impact: u2, scrollJumpRequest: null } : null;
}, Y = (e4) => {
  let t2 = e4.at;
  return t2 ? t2.type === `REORDER` ? t2.destination.droppableId : t2.combine.droppableId : null;
}, Rr = (e4, t2) => {
  let n2 = Y(e4);
  return n2 ? t2[n2] : null;
}, zr = ({ state: e4, type: t2 }) => {
  let n2 = Rr(e4.impact, e4.dimensions.droppables), r2 = !!n2, i2 = e4.dimensions.droppables[e4.critical.droppable.id], a2 = n2 || i2, o2 = a2.axis.direction, s2 = o2 === `vertical` && (t2 === `MOVE_UP` || t2 === `MOVE_DOWN`) || o2 === `horizontal` && (t2 === `MOVE_LEFT` || t2 === `MOVE_RIGHT`);
  if (s2 && !r2) return null;
  let c2 = t2 === `MOVE_DOWN` || t2 === `MOVE_RIGHT`, l2 = e4.dimensions.draggables[e4.critical.draggable.id], u2 = e4.current.page.borderBoxCenter, { draggables: d2, droppables: f2 } = e4.dimensions;
  return s2 ? Er({ isMovingForward: c2, previousPageBorderBoxCenter: u2, draggable: l2, destination: a2, draggables: d2, viewport: e4.viewport, previousClientSelection: e4.current.client.selection, previousImpact: e4.impact, afterCritical: e4.afterCritical }) : Lr({ isMovingForward: c2, previousPageBorderBoxCenter: u2, draggable: l2, isOver: a2, draggables: d2, droppables: f2, viewport: e4.viewport, afterCritical: e4.afterCritical });
};
function X(e4) {
  return e4.phase === `DRAGGING` || e4.phase === `COLLECTING`;
}
function Br(e4) {
  let t2 = K(e4.top, e4.bottom), n2 = K(e4.left, e4.right);
  return function(e5) {
    return t2(e5.y) && n2(e5.x);
  };
}
function Vr(e4, t2) {
  return e4.left < t2.right && e4.right > t2.left && e4.top < t2.bottom && e4.bottom > t2.top;
}
function Hr({ pageBorderBox: e4, draggable: t2, candidates: n2 }) {
  let r2 = t2.page.borderBox.center, i2 = n2.map((t3) => {
    let n3 = t3.axis, i3 = W(t3.axis.line, e4.center[n3.line], t3.page.borderBox.center[n3.crossAxisLine]);
    return { id: t3.descriptor.id, distance: hn(r2, i3) };
  }).sort((e5, t3) => t3.distance - e5.distance);
  return i2[0] ? i2[0].id : null;
}
function Ur({ pageBorderBox: e4, draggable: t2, droppables: n2 }) {
  let r2 = kn(n2).filter((t3) => {
    if (!t3.isEnabled) return false;
    let n3 = t3.subject.active;
    if (!n3 || !Vr(e4, n3)) return false;
    if (Br(n3)(e4.center)) return true;
    let r3 = t3.axis, i2 = n3.center[r3.crossAxisLine], a2 = e4[r3.crossAxisStart], o2 = e4[r3.crossAxisEnd], s2 = K(n3[r3.crossAxisStart], n3[r3.crossAxisEnd]), c2 = s2(a2), l2 = s2(o2);
    return !c2 && !l2 ? true : c2 ? a2 < i2 : o2 > i2;
  });
  return r2.length ? r2.length === 1 ? r2[0].descriptor.id : Hr({ pageBorderBox: e4, draggable: t2, candidates: r2 }) : null;
}
var Wr = (e4, t2) => N(yn(e4, t2)), Gr = (e4, t2) => {
  let n2 = e4.frame;
  return n2 ? Wr(t2, n2.scroll.diff.value) : t2;
};
function Kr({ displaced: e4, id: t2 }) {
  return !!(e4.visible[t2] || e4.invisible[t2]);
}
function qr({ draggable: e4, closest: t2, inHomeList: n2 }) {
  return t2 ? n2 && t2.descriptor.index > e4.descriptor.index ? t2.descriptor.index - 1 : t2.descriptor.index : null;
}
var Jr = ({ pageBorderBoxWithDroppableScroll: e4, draggable: t2, destination: n2, insideDestination: r2, last: i2, viewport: a2, afterCritical: o2 }) => {
  let s2 = n2.axis, c2 = jr(n2.axis, t2.displaceBy), l2 = c2.value, u2 = e4[s2.start], d2 = e4[s2.end];
  return rr({ draggable: t2, insideDestination: r2, destination: n2, viewport: a2, last: i2, displacedBy: c2, index: qr({ draggable: t2, closest: Pn(t2, r2).find((e5) => {
    let t3 = e5.descriptor.id, n3 = e5.page.borderBox.center[s2.line], r3 = q(t3, o2), a3 = Kr({ displaced: i2, id: t3 });
    return r3 ? a3 ? d2 <= n3 : u2 < n3 - l2 : a3 ? d2 <= n3 + l2 : u2 < n3;
  }) || null, inHomeList: In(t2, n2) }) });
}, Yr = 4, Xr = ({ draggable: e4, pageBorderBoxWithDroppableScroll: t2, previousImpact: n2, destination: r2, insideDestination: i2, afterCritical: a2 }) => {
  if (!r2.isCombineEnabled) return null;
  let o2 = r2.axis, s2 = jr(r2.axis, e4.displaceBy), c2 = s2.value, l2 = t2[o2.start], u2 = t2[o2.end], d2 = Pn(e4, i2).find((e5) => {
    let t3 = e5.descriptor.id, r3 = e5.page.borderBox, i3 = r3[o2.size] / Yr, s3 = q(t3, a2), d3 = Kr({ displaced: n2.displaced, id: t3 });
    return s3 ? d3 ? u2 > r3[o2.start] + i3 && u2 < r3[o2.end] - i3 : l2 > r3[o2.start] - c2 + i3 && l2 < r3[o2.end] - c2 - i3 : d3 ? u2 > r3[o2.start] + c2 + i3 && u2 < r3[o2.end] + c2 - i3 : l2 > r3[o2.start] + i3 && l2 < r3[o2.end] - i3;
  });
  return d2 ? { displacedBy: s2, displaced: n2.displaced, at: { type: `COMBINE`, combine: { draggableId: d2.descriptor.id, droppableId: r2.descriptor.id } } } : null;
}, Zr = ({ pageOffset: e4, draggable: t2, draggables: n2, droppables: r2, previousImpact: i2, viewport: a2, afterCritical: o2 }) => {
  let s2 = Wr(t2.page.borderBox, e4), c2 = Ur({ pageBorderBox: s2, draggable: t2, droppables: r2 });
  if (!c2) return zn;
  let l2 = r2[c2], u2 = jn(l2.descriptor.id, n2), d2 = Gr(l2, s2);
  return Xr({ pageBorderBoxWithDroppableScroll: d2, draggable: t2, previousImpact: i2, destination: l2, insideDestination: u2, afterCritical: o2 }) || Jr({ pageBorderBoxWithDroppableScroll: d2, draggable: t2, destination: l2, insideDestination: u2, last: i2.displaced, viewport: a2, afterCritical: o2 });
}, Qr = (e4, t2) => ({ ...e4, [t2.descriptor.id]: t2 }), $r = ({ previousImpact: e4, impact: t2, droppables: n2 }) => {
  let r2 = Y(e4), i2 = Y(t2);
  if (!r2 || r2 === i2) return n2;
  let a2 = n2[r2];
  return a2.subject.withPlaceholder ? Qr(n2, Fr(a2)) : n2;
}, ei = ({ draggable: e4, draggables: t2, droppables: n2, previousImpact: r2, impact: i2 }) => {
  let a2 = $r({ previousImpact: r2, impact: i2, droppables: n2 }), o2 = Y(i2);
  if (!o2) return a2;
  let s2 = n2[o2];
  return In(e4, s2) || s2.subject.withPlaceholder ? a2 : Qr(a2, Pr(s2, e4, t2));
}, ti = ({ state: e4, clientSelection: t2, dimensions: n2, viewport: r2, impact: i2, scrollJumpRequest: a2 }) => {
  let o2 = r2 || e4.viewport, s2 = n2 || e4.dimensions, c2 = t2 || e4.current.client.selection, l2 = H(c2, e4.initial.client.selection), u2 = { offset: l2, selection: c2, borderBoxCenter: V(e4.initial.client.borderBoxCenter, l2) }, d2 = { selection: V(u2.selection, o2.scroll.current), borderBoxCenter: V(u2.borderBoxCenter, o2.scroll.current), offset: V(u2.offset, o2.scroll.diff.value) }, f2 = { client: u2, page: d2 };
  if (e4.phase === `COLLECTING`) return { ...e4, dimensions: s2, viewport: o2, current: f2 };
  let p2 = s2.draggables[e4.critical.draggable.id], m2 = i2 || Zr({ pageOffset: d2.offset, draggable: p2, draggables: s2.draggables, droppables: s2.droppables, previousImpact: e4.impact, viewport: o2, afterCritical: e4.afterCritical }), h2 = ei({ draggable: p2, impact: m2, previousImpact: e4.impact, draggables: s2.draggables, droppables: s2.droppables });
  return { ...e4, current: f2, dimensions: { draggables: s2.draggables, droppables: h2 }, impact: m2, viewport: o2, scrollJumpRequest: a2 || null, forceShouldAnimate: !a2 && null };
};
function ni(e4, t2) {
  return e4.map((e5) => t2[e5]);
}
var ri = ({ impact: e4, viewport: t2, draggables: n2, destination: r2, forceShouldAnimate: i2 }) => {
  let a2 = e4.displaced, o2 = er({ afterDragging: ni(a2.all, n2), destination: r2, displacedBy: e4.displacedBy, viewport: t2.frame, forceShouldAnimate: i2, last: a2 });
  return { ...e4, displaced: o2 };
}, ii = ({ impact: e4, draggable: t2, droppable: n2, draggables: r2, viewport: i2, afterCritical: a2 }) => wr({ pageBorderBoxCenter: vr({ impact: e4, draggable: t2, draggables: r2, droppable: n2, afterCritical: a2 }), draggable: t2, viewport: i2 }), ai = ({ state: e4, dimensions: t2, viewport: n2 }) => {
  e4.movementMode !== `SNAP` && L();
  let r2 = e4.impact, i2 = n2 || e4.viewport, a2 = t2 || e4.dimensions, { draggables: o2, droppables: s2 } = a2, c2 = o2[e4.critical.draggable.id], l2 = Y(r2);
  !l2 && L();
  let u2 = s2[l2], d2 = ri({ impact: r2, viewport: i2, destination: u2, draggables: o2 });
  return ti({ impact: d2, clientSelection: ii({ impact: d2, draggable: c2, droppable: u2, draggables: o2, viewport: i2, afterCritical: e4.afterCritical }), state: e4, dimensions: a2, viewport: i2 });
}, oi = (e4) => ({ index: e4.index, droppableId: e4.droppableId }), si = ({ draggable: e4, home: t2, draggables: n2, viewport: r2 }) => {
  let i2 = jr(t2.axis, e4.displaceBy), a2 = jn(t2.descriptor.id, n2), o2 = a2.indexOf(e4);
  o2 === -1 && L();
  let s2 = a2.slice(o2 + 1), c2 = s2.reduce((e5, t3) => (e5[t3.descriptor.id] = true, e5), {}), l2 = { inVirtualList: t2.descriptor.mode === `virtual`, displacedBy: i2, effected: c2 };
  return { impact: { displaced: er({ afterDragging: s2, destination: t2, displacedBy: i2, last: null, viewport: r2.frame, forceShouldAnimate: false }), displacedBy: i2, at: { type: `REORDER`, destination: oi(e4.descriptor) } }, afterCritical: l2 };
}, ci = (e4, t2) => ({ draggables: e4.draggables, droppables: Qr(e4.droppables, t2) }), li = ({ draggable: e4, offset: t2, initialWindowScroll: n2 }) => {
  let r2 = Kt(e4.client, t2), i2 = qt(r2, n2);
  return { ...e4, placeholder: { ...e4.placeholder, client: r2 }, client: r2, page: i2 };
}, ui = (e4) => {
  let t2 = e4.frame;
  return !t2 && L(), t2;
}, di = ({ additions: e4, updatedDroppables: t2, viewport: n2 }) => {
  let r2 = n2.scroll.diff.value;
  return e4.map((e5) => {
    let i2 = t2[e5.descriptor.droppableId], a2 = ui(i2).scroll.diff.value;
    return li({ draggable: e5, offset: V(r2, a2), initialWindowScroll: n2.scroll.initial });
  });
}, fi = ({ state: e4, published: t2 }) => {
  let n2 = t2.modified.map((t3) => {
    let n3 = e4.dimensions.droppables[t3.droppableId];
    return En(n3, t3.scroll);
  }), r2 = { ...e4.dimensions.droppables, ...Dn(n2) }, i2 = On(di({ additions: t2.additions, updatedDroppables: r2, viewport: e4.viewport })), a2 = { ...e4.dimensions.draggables, ...i2 };
  t2.removals.forEach((e5) => {
    delete a2[e5];
  });
  let o2 = { droppables: r2, draggables: a2 }, s2 = Y(e4.impact), c2 = s2 ? o2.droppables[s2] : null, l2 = o2.draggables[e4.critical.draggable.id], u2 = o2.droppables[e4.critical.droppable.id], { impact: d2, afterCritical: f2 } = si({ draggable: l2, home: u2, draggables: a2, viewport: e4.viewport }), p2 = c2 && c2.isCombineEnabled ? e4.impact : d2, m2 = Zr({ pageOffset: e4.current.page.offset, draggable: o2.draggables[e4.critical.draggable.id], draggables: o2.draggables, droppables: o2.droppables, previousImpact: p2, viewport: e4.viewport, afterCritical: f2 }), h2 = { ...e4, phase: `DRAGGING`, impact: m2, onLiftImpact: d2, dimensions: o2, afterCritical: f2, forceShouldAnimate: false };
  return e4.phase === `COLLECTING` ? h2 : { ...h2, phase: `DROP_PENDING`, reason: e4.reason, isWaiting: false };
}, pi = (e4) => e4.movementMode === `SNAP`, mi = (e4, t2, n2) => {
  let r2 = ci(e4.dimensions, t2);
  return !pi(e4) || n2 ? ti({ state: e4, dimensions: r2 }) : ai({ state: e4, dimensions: r2 });
};
function hi(e4) {
  return e4.isDragging && e4.movementMode === `SNAP` ? { ...e4, scrollJumpRequest: null } : e4;
}
var gi = { phase: `IDLE`, completed: null, shouldFlush: false }, _i = (e4 = gi, t2) => {
  if (t2.type === `FLUSH`) return { ...gi, shouldFlush: true };
  if (t2.type === `INITIAL_PUBLISH`) {
    e4.phase !== `IDLE` && L();
    let { critical: n2, clientSelection: r2, viewport: i2, dimensions: a2, movementMode: o2 } = t2.payload, s2 = a2.draggables[n2.draggable.id], c2 = a2.droppables[n2.droppable.id], l2 = { selection: r2, borderBoxCenter: s2.client.borderBox.center, offset: B }, u2 = { client: l2, page: { selection: V(l2.selection, i2.scroll.initial), borderBoxCenter: V(l2.selection, i2.scroll.initial), offset: V(l2.selection, i2.scroll.diff.value) } }, d2 = kn(a2.droppables).every((e5) => !e5.isFixedOnPage), { impact: f2, afterCritical: p2 } = si({ draggable: s2, home: c2, draggables: a2.draggables, viewport: i2 });
    return { phase: `DRAGGING`, isDragging: true, critical: n2, movementMode: o2, dimensions: a2, initial: u2, current: u2, isWindowScrollAllowed: d2, impact: f2, afterCritical: p2, onLiftImpact: f2, viewport: i2, scrollJumpRequest: null, forceShouldAnimate: null };
  }
  if (t2.type === `COLLECTION_STARTING`) return e4.phase === `COLLECTING` || e4.phase === `DROP_PENDING` ? e4 : (e4.phase !== `DRAGGING` && L(), { ...e4, phase: `COLLECTING` });
  if (t2.type === `PUBLISH_WHILE_DRAGGING`) return e4.phase !== `COLLECTING` && e4.phase !== `DROP_PENDING` && L(), fi({ state: e4, published: t2.payload });
  if (t2.type === `MOVE`) {
    if (e4.phase === `DROP_PENDING`) return e4;
    !X(e4) && L();
    let { client: n2 } = t2.payload;
    return U(n2, e4.current.client.selection) ? e4 : ti({ state: e4, clientSelection: n2, impact: pi(e4) ? e4.impact : null });
  }
  if (t2.type === `UPDATE_DROPPABLE_SCROLL`) {
    if (e4.phase === `DROP_PENDING` || e4.phase === `COLLECTING`) return hi(e4);
    !X(e4) && L();
    let { id: n2, newScroll: r2 } = t2.payload, i2 = e4.dimensions.droppables[n2];
    return i2 ? mi(e4, En(i2, r2), false) : e4;
  }
  if (t2.type === `UPDATE_DROPPABLE_IS_ENABLED`) {
    if (e4.phase === `DROP_PENDING`) return e4;
    !X(e4) && L();
    let { id: n2, isEnabled: r2 } = t2.payload, i2 = e4.dimensions.droppables[n2];
    return !i2 && L(), i2.isEnabled === r2 && L(), mi(e4, { ...i2, isEnabled: r2 }, true);
  }
  if (t2.type === `UPDATE_DROPPABLE_IS_COMBINE_ENABLED`) {
    if (e4.phase === `DROP_PENDING`) return e4;
    !X(e4) && L();
    let { id: n2, isCombineEnabled: r2 } = t2.payload, i2 = e4.dimensions.droppables[n2];
    return !i2 && L(), i2.isCombineEnabled === r2 && L(), mi(e4, { ...i2, isCombineEnabled: r2 }, true);
  }
  if (t2.type === `MOVE_BY_WINDOW_SCROLL`) {
    if (e4.phase === `DROP_PENDING` || e4.phase === `DROP_ANIMATING`) return e4;
    !X(e4) && L(), !e4.isWindowScrollAllowed && L();
    let n2 = t2.payload.newScroll;
    if (U(e4.viewport.scroll.current, n2)) return hi(e4);
    let r2 = yr(e4.viewport, n2);
    return pi(e4) ? ai({ state: e4, viewport: r2 }) : ti({ state: e4, viewport: r2 });
  }
  if (t2.type === `UPDATE_VIEWPORT_MAX_SCROLL`) {
    if (!X(e4)) return e4;
    let n2 = t2.payload.maxScroll;
    if (U(n2, e4.viewport.scroll.max)) return e4;
    let r2 = { ...e4.viewport, scroll: { ...e4.viewport.scroll, max: n2 } };
    return { ...e4, viewport: r2 };
  }
  if (t2.type === `MOVE_UP` || t2.type === `MOVE_DOWN` || t2.type === `MOVE_LEFT` || t2.type === `MOVE_RIGHT`) {
    if (e4.phase === `COLLECTING` || e4.phase === `DROP_PENDING`) return e4;
    e4.phase !== `DRAGGING` && L();
    let n2 = zr({ state: e4, type: t2.type });
    return n2 ? ti({ state: e4, impact: n2.impact, clientSelection: n2.clientSelection, scrollJumpRequest: n2.scrollJumpRequest }) : e4;
  }
  if (t2.type === `DROP_PENDING`) {
    let n2 = t2.payload.reason;
    return e4.phase !== `COLLECTING` && L(), { ...e4, phase: `DROP_PENDING`, isWaiting: true, reason: n2 };
  }
  if (t2.type === `DROP_ANIMATE`) {
    let { completed: n2, dropDuration: r2, newHomeClientOffset: i2 } = t2.payload;
    return e4.phase !== `DRAGGING` && e4.phase !== `DROP_PENDING` && L(), { phase: `DROP_ANIMATING`, completed: n2, dropDuration: r2, newHomeClientOffset: i2, dimensions: e4.dimensions };
  }
  if (t2.type === `DROP_COMPLETE`) {
    let { completed: e5 } = t2.payload;
    return { phase: `IDLE`, completed: e5, shouldFlush: false };
  }
  return e4;
};
function Z(e4, t2) {
  return e4 instanceof Object && `type` in e4 && e4.type === t2;
}
var vi = (e4) => ({ type: `BEFORE_INITIAL_CAPTURE`, payload: e4 }), yi = (e4) => ({ type: `LIFT`, payload: e4 }), bi = (e4) => ({ type: `INITIAL_PUBLISH`, payload: e4 }), xi = (e4) => ({ type: `PUBLISH_WHILE_DRAGGING`, payload: e4 }), Si = () => ({ type: `COLLECTION_STARTING`, payload: null }), Ci = (e4) => ({ type: `UPDATE_DROPPABLE_SCROLL`, payload: e4 }), wi = (e4) => ({ type: `UPDATE_DROPPABLE_IS_ENABLED`, payload: e4 }), Ti = (e4) => ({ type: `UPDATE_DROPPABLE_IS_COMBINE_ENABLED`, payload: e4 }), Ei = (e4) => ({ type: `MOVE`, payload: e4 }), Di = (e4) => ({ type: `MOVE_BY_WINDOW_SCROLL`, payload: e4 }), Oi = (e4) => ({ type: `UPDATE_VIEWPORT_MAX_SCROLL`, payload: e4 }), ki = () => ({ type: `MOVE_UP`, payload: null }), Ai = () => ({ type: `MOVE_DOWN`, payload: null }), ji = () => ({ type: `MOVE_RIGHT`, payload: null }), Mi = () => ({ type: `MOVE_LEFT`, payload: null }), Ni = () => ({ type: `FLUSH`, payload: null }), Pi = (e4) => ({ type: `DROP_ANIMATE`, payload: e4 }), Fi = (e4) => ({ type: `DROP_COMPLETE`, payload: e4 }), Ii = (e4) => ({ type: `DROP`, payload: e4 }), Li = (e4) => ({ type: `DROP_PENDING`, payload: e4 }), Ri = () => ({ type: `DROP_ANIMATION_FINISHED`, payload: null }), zi = (e4) => ({ getState: t2, dispatch: n2 }) => (r2) => (i2) => {
  if (!Z(i2, `LIFT`)) {
    r2(i2);
    return;
  }
  let { id: a2, clientSelection: o2, movementMode: s2 } = i2.payload, c2 = t2();
  c2.phase === `DROP_ANIMATING` && n2(Fi({ completed: c2.completed })), t2().phase !== `IDLE` && L(), n2(Ni()), n2(vi({ draggableId: a2, movementMode: s2 }));
  let l2 = { draggableId: a2, scrollOptions: { shouldPublishImmediately: s2 === `SNAP` } }, { critical: u2, dimensions: d2, viewport: f2 } = e4.startPublishing(l2);
  n2(bi({ critical: u2, dimensions: d2, clientSelection: o2, movementMode: s2, viewport: f2 }));
}, Bi = (e4) => () => (t2) => (n2) => {
  Z(n2, `INITIAL_PUBLISH`) && e4.dragging(), Z(n2, `DROP_ANIMATE`) && e4.dropping(n2.payload.completed.result.reason), (Z(n2, `FLUSH`) || Z(n2, `DROP_COMPLETE`)) && e4.resting(), t2(n2);
}, Vi = { outOfTheWay: `cubic-bezier(0.2, 0, 0, 1)`, drop: `cubic-bezier(.2,1,.1,1)` }, Hi = { opacity: { drop: 0, combining: 0.7 }, scale: { drop: 0.75 } }, Ui = { outOfTheWay: 0.2, minDropTime: 0.33, maxDropTime: 0.55 }, Q = `${Ui.outOfTheWay}s ${Vi.outOfTheWay}`, Wi = { fluid: `opacity ${Q}`, snap: `transform ${Q}, opacity ${Q}`, drop: (e4) => {
  let t2 = `${e4}s ${Vi.drop}`;
  return `transform ${t2}, opacity ${t2}`;
}, outOfTheWay: `transform ${Q}`, placeholder: `height ${Q}, width ${Q}, margin ${Q}` }, Gi = (e4) => U(e4, B) ? void 0 : `translate(${e4.x}px, ${e4.y}px)`, Ki = { moveTo: Gi, drop: (e4, t2) => {
  let n2 = Gi(e4);
  if (n2) return t2 ? `${n2} scale(${Hi.scale.drop})` : n2;
} }, { minDropTime: qi, maxDropTime: Ji } = Ui, Yi = Ji - qi, Xi = 1500, Zi = 0.6, Qi = ({ current: e4, destination: t2, reason: n2 }) => {
  let r2 = hn(e4, t2);
  if (r2 <= 0) return qi;
  if (r2 >= Xi) return Ji;
  let i2 = qi + r2 / Xi * Yi, a2 = n2 === `CANCEL` ? i2 * Zi : i2;
  return Number(a2.toFixed(2));
}, $i = ({ impact: e4, draggable: t2, dimensions: n2, viewport: r2, afterCritical: i2 }) => {
  let { draggables: a2, droppables: o2 } = n2, s2 = Y(e4), c2 = s2 ? o2[s2] : null, l2 = o2[t2.descriptor.droppableId];
  return H(ii({ impact: e4, draggable: t2, draggables: a2, afterCritical: i2, droppable: c2 || l2, viewport: r2 }), t2.client.borderBox.center);
}, ea = ({ draggables: e4, reason: t2, lastImpact: n2, home: r2, viewport: i2, onLiftImpact: a2 }) => !n2.at || t2 !== `DROP` ? { impact: ri({ draggables: e4, impact: a2, destination: r2, viewport: i2, forceShouldAnimate: true }), didDropInsideDroppable: false } : n2.at.type === `REORDER` ? { impact: n2, didDropInsideDroppable: true } : { impact: { ...n2, displaced: Rn }, didDropInsideDroppable: true }, ta = ({ getState: e4, dispatch: t2 }) => (n2) => (r2) => {
  if (!Z(r2, `DROP`)) {
    n2(r2);
    return;
  }
  let i2 = e4(), a2 = r2.payload.reason;
  if (i2.phase === `COLLECTING`) {
    t2(Li({ reason: a2 }));
    return;
  }
  if (i2.phase === `IDLE`) return;
  i2.phase === `DROP_PENDING` && i2.isWaiting && L(), i2.phase !== `DRAGGING` && i2.phase !== `DROP_PENDING` && L();
  let o2 = i2.critical, s2 = i2.dimensions, c2 = s2.draggables[i2.critical.draggable.id], { impact: l2, didDropInsideDroppable: u2 } = ea({ reason: a2, lastImpact: i2.impact, afterCritical: i2.afterCritical, onLiftImpact: i2.onLiftImpact, home: i2.dimensions.droppables[i2.critical.droppable.id], viewport: i2.viewport, draggables: i2.dimensions.draggables }), d2 = u2 ? Mn(l2) : null, f2 = u2 ? Nn(l2) : null, p2 = { index: o2.draggable.index, droppableId: o2.droppable.id }, m2 = { draggableId: c2.descriptor.id, type: c2.descriptor.type, source: p2, reason: a2, mode: i2.movementMode, destination: d2, combine: f2 }, h2 = $i({ impact: l2, draggable: c2, dimensions: s2, viewport: i2.viewport, afterCritical: i2.afterCritical }), g2 = { critical: i2.critical, afterCritical: i2.afterCritical, result: m2, impact: l2 };
  if (U(i2.current.client.offset, h2) && !m2.combine) {
    t2(Fi({ completed: g2 }));
    return;
  }
  t2(Pi({ newHomeClientOffset: h2, dropDuration: Qi({ current: i2.current.client.offset, destination: h2, reason: a2 }), completed: g2 }));
}, na = () => ({ x: window.pageXOffset, y: window.pageYOffset });
function ra(e4) {
  return { eventName: `scroll`, options: { passive: true, capture: false }, fn: (t2) => {
    (t2.target === window || t2.target === window.document) && e4();
  } };
}
function ia({ onWindowScroll: e4 }) {
  function t2() {
    e4(na());
  }
  let n2 = Xt(t2), r2 = ra(n2), i2 = F;
  function a2() {
    return i2 !== F;
  }
  function o2() {
    a2() && L(), i2 = I(window, [r2]);
  }
  function s2() {
    !a2() && L(), n2.cancel(), i2(), i2 = F;
  }
  return { start: o2, stop: s2, isActive: a2 };
}
var aa = (e4) => Z(e4, `DROP_COMPLETE`) || Z(e4, `DROP_ANIMATE`) || Z(e4, `FLUSH`), oa = (e4) => {
  let t2 = ia({ onWindowScroll: (t3) => {
    e4.dispatch(Di({ newScroll: t3 }));
  } });
  return (e5) => (n2) => {
    !t2.isActive() && Z(n2, `INITIAL_PUBLISH`) && t2.start(), t2.isActive() && aa(n2) && t2.stop(), e5(n2);
  };
}, sa = (e4) => {
  let t2 = false, n2 = false, r2 = setTimeout(() => {
    n2 = true;
  }), i2 = (i3) => {
    t2 || n2 || (t2 = true, e4(i3), clearTimeout(r2));
  };
  return i2.wasCalled = () => t2, i2;
}, ca = () => {
  let e4 = [], t2 = (t3) => {
    let n2 = e4.findIndex((e5) => e5.timerId === t3);
    n2 === -1 && L();
    let [r2] = e4.splice(n2, 1);
    r2.callback();
  };
  return { add: (n2) => {
    let r2 = setTimeout(() => t2(r2)), i2 = { timerId: r2, callback: n2 };
    e4.push(i2);
  }, flush: () => {
    if (!e4.length) return;
    let t3 = [...e4];
    e4.length = 0, t3.forEach((e5) => {
      clearTimeout(e5.timerId), e5.callback();
    });
  } };
}, la = (e4, t2) => e4 == null && t2 == null ? true : e4 == null || t2 == null ? false : e4.droppableId === t2.droppableId && e4.index === t2.index, ua = (e4, t2) => e4 == null && t2 == null ? true : e4 == null || t2 == null ? false : e4.draggableId === t2.draggableId && e4.droppableId === t2.droppableId, da = (e4, t2) => {
  if (e4 === t2) return true;
  let n2 = e4.draggable.id === t2.draggable.id && e4.draggable.droppableId === t2.draggable.droppableId && e4.draggable.type === t2.draggable.type && e4.draggable.index === t2.draggable.index, r2 = e4.droppable.id === t2.droppable.id && e4.droppable.type === t2.droppable.type;
  return n2 && r2;
}, fa = (e4, t2) => {
  t2();
}, pa = (e4, t2) => ({ draggableId: e4.draggable.id, type: e4.droppable.type, source: { droppableId: e4.droppable.id, index: e4.draggable.index }, mode: t2 });
function ma(e4, t2, n2, r2) {
  if (!e4) {
    n2(r2(t2));
    return;
  }
  let i2 = sa(n2);
  e4(t2, { announce: i2 }), i2.wasCalled() || n2(r2(t2));
}
var ha = (e4, t2) => {
  let n2 = ca(), r2 = null, i2 = (t3, n3) => {
    r2 && L(), fa(`onBeforeCapture`, () => {
      let r3 = e4().onBeforeCapture;
      r3 && r3({ draggableId: t3, mode: n3 });
    });
  }, a2 = (t3, n3) => {
    r2 && L(), fa(`onBeforeDragStart`, () => {
      let r3 = e4().onBeforeDragStart;
      r3 && r3(pa(t3, n3));
    });
  }, o2 = (i3, a3) => {
    r2 && L();
    let o3 = pa(i3, a3);
    r2 = { mode: a3, lastCritical: i3, lastLocation: o3.source, lastCombine: null }, n2.add(() => {
      fa(`onDragStart`, () => ma(e4().onDragStart, o3, t2, dn.onDragStart));
    });
  }, s2 = (i3, a3) => {
    let o3 = Mn(a3), s3 = Nn(a3);
    !r2 && L();
    let c3 = !da(i3, r2.lastCritical);
    c3 && (r2.lastCritical = i3);
    let l3 = !la(r2.lastLocation, o3);
    l3 && (r2.lastLocation = o3);
    let u2 = !ua(r2.lastCombine, s3);
    if (u2 && (r2.lastCombine = s3), !c3 && !l3 && !u2) return;
    let d2 = { ...pa(i3, r2.mode), combine: s3, destination: o3 };
    n2.add(() => {
      fa(`onDragUpdate`, () => ma(e4().onDragUpdate, d2, t2, dn.onDragUpdate));
    });
  }, c2 = () => {
    !r2 && L(), n2.flush();
  }, l2 = (n3) => {
    !r2 && L(), r2 = null, fa(`onDragEnd`, () => ma(e4().onDragEnd, n3, t2, dn.onDragEnd));
  };
  return { beforeCapture: i2, beforeStart: a2, start: o2, update: s2, flush: c2, drop: l2, abort: () => {
    if (!r2) return;
    let e5 = { ...pa(r2.lastCritical, r2.mode), combine: null, destination: null, reason: `CANCEL` };
    l2(e5);
  } };
}, ga = (e4, t2) => {
  let n2 = ha(e4, t2);
  return (e5) => (t3) => (r2) => {
    if (Z(r2, `BEFORE_INITIAL_CAPTURE`)) {
      n2.beforeCapture(r2.payload.draggableId, r2.payload.movementMode);
      return;
    }
    if (Z(r2, `INITIAL_PUBLISH`)) {
      let e6 = r2.payload.critical;
      n2.beforeStart(e6, r2.payload.movementMode), t3(r2), n2.start(e6, r2.payload.movementMode);
      return;
    }
    if (Z(r2, `DROP_COMPLETE`)) {
      let e6 = r2.payload.completed.result;
      n2.flush(), t3(r2), n2.drop(e6);
      return;
    }
    if (t3(r2), Z(r2, `FLUSH`)) {
      n2.abort();
      return;
    }
    let i2 = e5.getState();
    i2.phase === `DRAGGING` && n2.update(i2.critical, i2.impact);
  };
}, _a = (e4) => (t2) => (n2) => {
  if (!Z(n2, `DROP_ANIMATION_FINISHED`)) {
    t2(n2);
    return;
  }
  let r2 = e4.getState();
  r2.phase !== `DROP_ANIMATING` && L(), e4.dispatch(Fi({ completed: r2.completed }));
}, va = (e4) => {
  let t2 = null, n2 = null;
  function r2() {
    n2 && (n2 = (cancelAnimationFrame(n2), null)), t2 && (t2 = (t2(), null));
  }
  return (i2) => (a2) => {
    if ((Z(a2, `FLUSH`) || Z(a2, `DROP_COMPLETE`) || Z(a2, `DROP_ANIMATION_FINISHED`)) && r2(), i2(a2), !Z(a2, `DROP_ANIMATE`)) return;
    let o2 = { eventName: `scroll`, options: { capture: true, passive: false, once: true }, fn: function() {
      e4.getState().phase === `DROP_ANIMATING` && e4.dispatch(Ri());
    } };
    n2 = requestAnimationFrame(() => {
      n2 = null, t2 = I(window, [o2]);
    });
  };
}, ya = (e4) => () => (t2) => (n2) => {
  (Z(n2, `DROP_COMPLETE`) || Z(n2, `FLUSH`) || Z(n2, `DROP_ANIMATE`)) && e4.stopPublishing(), t2(n2);
}, ba = (e4) => {
  let t2 = false;
  return () => (n2) => (r2) => {
    if (Z(r2, `INITIAL_PUBLISH`)) {
      t2 = true, e4.tryRecordFocus(r2.payload.critical.draggable.id), n2(r2), e4.tryRestoreFocusRecorded();
      return;
    }
    if (n2(r2), t2) {
      if (Z(r2, `FLUSH`)) {
        t2 = false, e4.tryRestoreFocusRecorded();
        return;
      }
      if (Z(r2, `DROP_COMPLETE`)) {
        t2 = false;
        let n3 = r2.payload.completed.result;
        n3.combine && e4.tryShiftRecord(n3.draggableId, n3.combine.draggableId), e4.tryRestoreFocusRecorded();
      }
    }
  };
}, xa = (e4) => Z(e4, `DROP_COMPLETE`) || Z(e4, `DROP_ANIMATE`) || Z(e4, `FLUSH`), Sa = (e4) => (t2) => (n2) => (r2) => {
  if (xa(r2)) {
    e4.stop(), n2(r2);
    return;
  }
  if (Z(r2, `INITIAL_PUBLISH`)) {
    n2(r2);
    let i2 = t2.getState();
    i2.phase !== `DRAGGING` && L(), e4.start(i2);
    return;
  }
  n2(r2), e4.scroll(t2.getState());
}, Ca = (e4) => (t2) => (n2) => {
  if (t2(n2), !Z(n2, `PUBLISH_WHILE_DRAGGING`)) return;
  let r2 = e4.getState();
  r2.phase === `DROP_PENDING` && (r2.isWaiting || e4.dispatch(Ii({ reason: r2.reason })));
}, wa = Te, Ta = ({ dimensionMarshal: e4, focusMarshal: t2, styleMarshal: n2, getResponders: r2, announce: i2, autoScroller: a2 }) => Se(_i, wa(Ee(Bi(n2), ya(e4), zi(e4), ta, _a, va, Ca, Sa(a2), oa, ba(t2), ga(r2, i2)))), Ea = () => ({ additions: {}, removals: {}, modified: {} });
function Da({ registry: e4, callbacks: t2 }) {
  let n2 = Ea(), r2 = null, i2 = () => {
    r2 || (r2 = (t2.collectionStarting(), requestAnimationFrame(() => {
      r2 = null;
      let { additions: i3, removals: a2, modified: o2 } = n2, s2 = Object.keys(i3).map((t3) => e4.draggable.getById(t3).getDimension(B)).sort((e5, t3) => e5.descriptor.index - t3.descriptor.index), c2 = Object.keys(o2).map((t3) => ({ droppableId: t3, scroll: e4.droppable.getById(t3).callbacks.getScrollWhileDragging() })), l2 = { additions: s2, removals: Object.keys(a2), modified: c2 };
      n2 = Ea(), t2.publish(l2);
    })));
  };
  return { add: (e5) => {
    let t3 = e5.descriptor.id;
    n2.additions[t3] = e5, n2.modified[e5.descriptor.droppableId] = true, n2.removals[t3] && delete n2.removals[t3], i2();
  }, remove: (e5) => {
    let t3 = e5.descriptor;
    n2.removals[t3.id] = true, n2.modified[t3.droppableId] = true, n2.additions[t3.id] && delete n2.additions[t3.id], i2();
  }, stop: () => {
    r2 && (cancelAnimationFrame(r2), r2 = null, n2 = Ea());
  } };
}
var Oa = ({ scrollHeight: e4, scrollWidth: t2, height: n2, width: r2 }) => {
  let i2 = H({ x: t2, y: e4 }, { x: r2, y: n2 });
  return { x: Math.max(0, i2.x), y: Math.max(0, i2.y) };
}, ka = () => {
  let e4 = document.documentElement;
  return !e4 && L(), e4;
}, Aa = () => {
  let e4 = ka();
  return Oa({ scrollHeight: e4.scrollHeight, scrollWidth: e4.scrollWidth, width: e4.clientWidth, height: e4.clientHeight });
}, ja = () => {
  let e4 = na(), t2 = Aa(), n2 = e4.y, r2 = e4.x, i2 = ka(), a2 = i2.clientWidth, o2 = i2.clientHeight;
  return { frame: N({ top: n2, left: r2, right: r2 + a2, bottom: n2 + o2 }), scroll: { initial: e4, current: e4, max: t2, diff: { value: B, displacement: B } } };
}, Ma = ({ critical: e4, scrollOptions: t2, registry: n2 }) => {
  let r2 = ja(), i2 = r2.scroll.current, a2 = e4.droppable, o2 = n2.droppable.getAllByType(a2.type).map((e5) => e5.callbacks.getDimensionAndWatchScroll(i2, t2));
  return { dimensions: { draggables: On(n2.draggable.getAllByType(e4.draggable.type).map((e5) => e5.getDimension(i2))), droppables: Dn(o2) }, critical: e4, viewport: r2 };
};
function Na(e4, t2, n2) {
  return n2.descriptor.id !== t2.id && n2.descriptor.type === t2.type && e4.droppable.getById(n2.descriptor.droppableId).descriptor.mode === `virtual`;
}
var Pa = (e4, t2) => {
  let n2 = null, r2 = Da({ callbacks: { publish: t2.publishWhileDragging, collectionStarting: t2.collectionStarting }, registry: e4 }), i2 = (r3, i3) => {
    !e4.droppable.exists(r3) && L(), n2 && t2.updateDroppableIsEnabled({ id: r3, isEnabled: i3 });
  }, a2 = (r3, i3) => {
    n2 && (!e4.droppable.exists(r3) && L(), t2.updateDroppableIsCombineEnabled({ id: r3, isCombineEnabled: i3 }));
  }, o2 = (r3, i3) => {
    n2 && (!e4.droppable.exists(r3) && L(), t2.updateDroppableScroll({ id: r3, newScroll: i3 }));
  }, s2 = (t3, r3) => {
    n2 && e4.droppable.getById(t3).callbacks.scroll(r3);
  }, c2 = () => {
    if (!n2) return;
    r2.stop();
    let t3 = n2.critical.droppable;
    e4.droppable.getAllByType(t3.type).forEach((e5) => e5.callbacks.dragStopped()), n2.unsubscribe(), n2 = null;
  }, l2 = (t3) => {
    !n2 && L();
    let i3 = n2.critical.draggable;
    t3.type === `ADDITION` && Na(e4, i3, t3.value) && r2.add(t3.value), t3.type === `REMOVAL` && Na(e4, i3, t3.value) && r2.remove(t3.value);
  };
  return { updateDroppableIsEnabled: i2, updateDroppableIsCombineEnabled: a2, scrollDroppable: s2, updateDroppableScroll: o2, startPublishing: (t3) => {
    n2 && L();
    let r3 = e4.draggable.getById(t3.draggableId), i3 = e4.droppable.getById(r3.descriptor.droppableId), a3 = { draggable: r3.descriptor, droppable: i3.descriptor };
    return n2 = { critical: a3, unsubscribe: e4.subscribe(l2) }, Ma({ critical: a3, registry: e4, scrollOptions: t3.scrollOptions });
  }, stopPublishing: c2 };
}, Fa = (e4, t2) => e4.phase === `IDLE` ? true : e4.phase !== `DROP_ANIMATING` || e4.completed.result.draggableId === t2 ? false : e4.completed.result.reason === `DROP`, Ia = (e4) => {
  window.scrollBy(e4.x, e4.y);
}, La = G((e4) => kn(e4).filter((e5) => !(!e5.isEnabled || !e5.frame))), Ra = (e4, t2) => La(t2).find((t3) => (!t3.frame && L(), Br(t3.frame.pageMarginBox)(e4))) || null, za = ({ center: e4, destination: t2, droppables: n2 }) => {
  if (t2) {
    let e5 = n2[t2];
    return e5.frame ? e5 : null;
  }
  return Ra(e4, n2);
}, Ba = { startFromPercentage: 0.25, maxScrollAtPercentage: 0.05, maxPixelScroll: 28, ease: (e4) => e4 ** 2, durationDampening: { stopDampeningAt: 1200, accelerateAt: 360 }, disabled: false }, Va = (e4, t2, n2 = () => Ba) => {
  let r2 = n2();
  return { startScrollingFrom: e4[t2.size] * r2.startFromPercentage, maxScrollValueAt: e4[t2.size] * r2.maxScrollAtPercentage };
}, Ha = ({ startOfRange: e4, endOfRange: t2, current: n2 }) => {
  let r2 = t2 - e4;
  return r2 === 0 ? 0 : (n2 - e4) / r2;
}, Ua = 1, Wa = (e4, t2, n2 = () => Ba) => {
  let r2 = n2();
  if (e4 > t2.startScrollingFrom) return 0;
  if (e4 <= t2.maxScrollValueAt) return r2.maxPixelScroll;
  if (e4 === t2.startScrollingFrom) return Ua;
  let i2 = 1 - Ha({ startOfRange: t2.maxScrollValueAt, endOfRange: t2.startScrollingFrom, current: e4 }), a2 = r2.maxPixelScroll * r2.ease(i2);
  return Math.ceil(a2);
}, Ga = (e4, t2, n2) => {
  let r2 = n2(), i2 = r2.durationDampening.accelerateAt, a2 = r2.durationDampening.stopDampeningAt, o2 = t2, s2 = a2, c2 = Date.now() - o2;
  if (c2 >= a2) return e4;
  if (c2 < i2) return Ua;
  let l2 = Ha({ startOfRange: i2, endOfRange: s2, current: c2 }), u2 = e4 * r2.ease(l2);
  return Math.ceil(u2);
}, Ka = ({ distanceToEdge: e4, thresholds: t2, dragStartTime: n2, shouldUseTimeDampening: r2, getAutoScrollerOptions: i2 }) => {
  let a2 = Wa(e4, t2, i2);
  return a2 === 0 ? 0 : r2 ? Math.max(Ga(a2, n2, i2), Ua) : a2;
}, qa = ({ container: e4, distanceToEdges: t2, dragStartTime: n2, axis: r2, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 }) => {
  let o2 = Va(e4, r2, a2);
  return t2[r2.end] < t2[r2.start] ? Ka({ distanceToEdge: t2[r2.end], thresholds: o2, dragStartTime: n2, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 }) : -1 * Ka({ distanceToEdge: t2[r2.start], thresholds: o2, dragStartTime: n2, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 });
}, Ja = ({ container: e4, subject: t2, proposedScroll: n2 }) => {
  let r2 = t2.height > e4.height, i2 = t2.width > e4.width;
  return !i2 && !r2 ? n2 : i2 && r2 ? null : { x: i2 ? 0 : n2.x, y: r2 ? 0 : n2.y };
}, Ya = _n((e4) => e4 === 0 ? 0 : e4), Xa = ({ dragStartTime: e4, container: t2, subject: n2, center: r2, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 }) => {
  let o2 = { top: r2.y - t2.top, right: t2.right - r2.x, bottom: t2.bottom - r2.y, left: r2.x - t2.left }, s2 = qa({ container: t2, distanceToEdges: o2, dragStartTime: e4, axis: Hn, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 }), c2 = Ya({ x: qa({ container: t2, distanceToEdges: o2, dragStartTime: e4, axis: Un, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 }), y: s2 });
  if (U(c2, B)) return null;
  let l2 = Ja({ container: t2, subject: n2, proposedScroll: c2 });
  return l2 ? U(l2, B) ? null : l2 : null;
}, Za = _n((e4) => e4 === 0 ? 0 : e4 > 0 ? 1 : -1), Qa = /* @__PURE__ */ (() => {
  let e4 = (e5, t2) => e5 < 0 ? e5 : e5 > t2 ? e5 - t2 : 0;
  return ({ current: t2, max: n2, change: r2 }) => {
    let i2 = V(t2, r2), a2 = { x: e4(i2.x, n2.x), y: e4(i2.y, n2.y) };
    return U(a2, B) ? null : a2;
  };
})(), $a = ({ max: e4, current: t2, change: n2 }) => {
  let r2 = { x: Math.max(t2.x, e4.x), y: Math.max(t2.y, e4.y) }, i2 = Za(n2), a2 = Qa({ max: r2, current: t2, change: i2 });
  return !a2 || i2.x !== 0 && a2.x === 0 || i2.y !== 0 && a2.y === 0;
}, eo = (e4, t2) => $a({ current: e4.scroll.current, max: e4.scroll.max, change: t2 }), to = (e4, t2) => {
  if (!eo(e4, t2)) return null;
  let n2 = e4.scroll.max, r2 = e4.scroll.current;
  return Qa({ current: r2, max: n2, change: t2 });
}, no = (e4, t2) => {
  let n2 = e4.frame;
  return n2 ? $a({ current: n2.scroll.current, max: n2.scroll.max, change: t2 }) : false;
}, ro = (e4, t2) => {
  let n2 = e4.frame;
  return !n2 || !no(e4, t2) ? null : Qa({ current: n2.scroll.current, max: n2.scroll.max, change: t2 });
}, io = ({ viewport: e4, subject: t2, center: n2, dragStartTime: r2, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 }) => {
  let o2 = Xa({ dragStartTime: r2, container: e4.frame, subject: t2, center: n2, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 });
  return o2 && eo(e4, o2) ? o2 : null;
}, ao = ({ droppable: e4, subject: t2, center: n2, dragStartTime: r2, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 }) => {
  let o2 = e4.frame;
  if (!o2) return null;
  let s2 = Xa({ dragStartTime: r2, container: o2.pageMarginBox, subject: t2, center: n2, shouldUseTimeDampening: i2, getAutoScrollerOptions: a2 });
  return s2 && no(e4, s2) ? s2 : null;
}, oo = ({ state: e4, dragStartTime: t2, shouldUseTimeDampening: n2, scrollWindow: r2, scrollDroppable: i2, getAutoScrollerOptions: a2 }) => {
  let o2 = e4.current.page.borderBoxCenter, s2 = e4.dimensions.draggables[e4.critical.draggable.id].page.marginBox;
  if (e4.isWindowScrollAllowed) {
    let i3 = e4.viewport, c3 = io({ dragStartTime: t2, viewport: i3, subject: s2, center: o2, shouldUseTimeDampening: n2, getAutoScrollerOptions: a2 });
    if (c3) {
      r2(c3);
      return;
    }
  }
  let c2 = za({ center: o2, destination: Y(e4.impact), droppables: e4.dimensions.droppables });
  if (!c2) return;
  let l2 = ao({ dragStartTime: t2, droppable: c2, subject: s2, center: o2, shouldUseTimeDampening: n2, getAutoScrollerOptions: a2 });
  l2 && i2(c2.descriptor.id, l2);
}, so = ({ scrollWindow: e4, scrollDroppable: t2, getAutoScrollerOptions: n2 = () => Ba }) => {
  let r2 = Xt(e4), i2 = Xt(t2), a2 = null, o2 = (e5) => {
    !a2 && L();
    let { shouldUseTimeDampening: t3, dragStartTime: o3 } = a2;
    oo({ state: e5, scrollWindow: r2, scrollDroppable: i2, dragStartTime: o3, shouldUseTimeDampening: t3, getAutoScrollerOptions: n2 });
  };
  return { start: (e5) => {
    a2 && L();
    let t3 = Date.now(), r3 = false, i3 = () => {
      r3 = true;
    };
    oo({ state: e5, dragStartTime: 0, shouldUseTimeDampening: false, scrollWindow: i3, scrollDroppable: i3, getAutoScrollerOptions: n2 }), a2 = { dragStartTime: t3, shouldUseTimeDampening: r3 }, r3 && o2(e5);
  }, stop: () => {
    a2 && (a2 = (r2.cancel(), i2.cancel(), null));
  }, scroll: o2 };
}, co = ({ move: e4, scrollDroppable: t2, scrollWindow: n2 }) => {
  let r2 = (t3, n3) => {
    e4({ client: V(t3.current.client.selection, n3) });
  }, i2 = (e5, n3) => {
    if (!no(e5, n3)) return n3;
    let r3 = ro(e5, n3);
    if (!r3) return t2(e5.descriptor.id, n3), null;
    let i3 = H(n3, r3);
    return t2(e5.descriptor.id, i3), H(n3, i3);
  }, a2 = (e5, t3, r3) => {
    if (!e5 || !eo(t3, r3)) return r3;
    let i3 = to(t3, r3);
    if (!i3) return n2(r3), null;
    let a3 = H(r3, i3);
    return n2(a3), H(r3, a3);
  };
  return (e5) => {
    let t3 = e5.scrollJumpRequest;
    if (!t3) return;
    let n3 = Y(e5.impact);
    !n3 && L();
    let o2 = i2(e5.dimensions.droppables[n3], t3);
    if (!o2) return;
    let s2 = e5.viewport, c2 = a2(e5.isWindowScrollAllowed, s2, o2);
    c2 && r2(e5, c2);
  };
}, lo = ({ scrollDroppable: e4, scrollWindow: t2, move: n2, getAutoScrollerOptions: r2 }) => {
  let i2 = so({ scrollWindow: t2, scrollDroppable: e4, getAutoScrollerOptions: r2 }), a2 = co({ move: n2, scrollWindow: t2, scrollDroppable: e4 });
  return { scroll: (e5) => {
    if (!(r2().disabled || e5.phase !== `DRAGGING`)) {
      if (e5.movementMode === `FLUID`) {
        i2.scroll(e5);
        return;
      }
      e5.scrollJumpRequest && a2(e5);
    }
  }, start: i2.start, stop: i2.stop };
}, uo = `data-rfd`, fo = (() => {
  let e4 = `${uo}-drag-handle`;
  return { base: e4, draggableId: `${e4}-draggable-id`, contextId: `${e4}-context-id` };
})(), po = (() => {
  let e4 = `${uo}-draggable`;
  return { base: e4, contextId: `${e4}-context-id`, id: `${e4}-id` };
})(), mo = (() => {
  let e4 = `${uo}-droppable`;
  return { base: e4, contextId: `${e4}-context-id`, id: `${e4}-id` };
})(), ho = { contextId: `${uo}-scroll-container-context-id` }, go = (e4) => (t2) => `[${t2}="${e4}"]`, _o = (e4, t2) => e4.map((e5) => {
  let n2 = e5.styles[t2];
  return n2 ? `${e5.selector} { ${n2} }` : ``;
}).join(` `), vo = `pointer-events: none;`, yo = (e4) => {
  let t2 = go(e4), n2 = (() => {
    let e5 = `
      cursor: -webkit-grab;
      cursor: grab;
    `;
    return { selector: t2(fo.contextId), styles: { always: `
          -webkit-touch-callout: none;
          -webkit-tap-highlight-color: rgba(0,0,0,0);
          touch-action: manipulation;
        `, resting: e5, dragging: vo, dropAnimating: e5 } };
  })(), r2 = [(() => {
    let e5 = `
      transition: ${Wi.outOfTheWay};
    `;
    return { selector: t2(po.contextId), styles: { dragging: e5, dropAnimating: e5, userCancel: e5 } };
  })(), n2, { selector: t2(mo.contextId), styles: { always: `overflow-anchor: none;` } }, { selector: `body`, styles: { dragging: `
        cursor: grabbing;
        cursor: -webkit-grabbing;
        user-select: none;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        overflow-anchor: none;
      ` } }];
  return { always: _o(r2, `always`), resting: _o(r2, `resting`), dragging: _o(r2, `dragging`), dropAnimating: _o(r2, `dropAnimating`), userCancel: _o(r2, `userCancel`) };
}, $ = typeof window < `u` && window.document !== void 0 && window.document.createElement !== void 0 ? o : m, bo = () => {
  let e4 = document.querySelector(`head`);
  return !e4 && L(), e4;
}, xo = (e4) => {
  let t2 = document.createElement(`style`);
  return e4 && t2.setAttribute(`nonce`, e4), t2.type = `text/css`, t2;
};
function So(e4, t2) {
  let n2 = R(() => yo(e4), [e4]), i2 = r(null), a2 = r(null), o2 = z(G((e5) => {
    let t3 = a2.current;
    !t3 && L(), t3.textContent = e5;
  }), []), s2 = z((e5) => {
    let t3 = i2.current;
    !t3 && L(), t3.textContent = e5;
  }, []);
  $(() => {
    (i2.current || a2.current) && L();
    let r2 = xo(t2), c3 = xo(t2);
    return i2.current = r2, a2.current = c3, r2.setAttribute(`${uo}-always`, e4), c3.setAttribute(`${uo}-dynamic`, e4), bo().appendChild(r2), bo().appendChild(c3), s2(n2.always), o2(n2.resting), () => {
      let e5 = (e6) => {
        let t3 = e6.current;
        !t3 && L(), bo().removeChild(t3), e6.current = null;
      };
      e5(i2), e5(a2);
    };
  }, [t2, s2, o2, n2.always, n2.resting, e4]);
  let c2 = z(() => o2(n2.dragging), [o2, n2.dragging]), l2 = z((e5) => {
    if (e5 === `DROP`) {
      o2(n2.dropAnimating);
      return;
    }
    o2(n2.userCancel);
  }, [o2, n2.dropAnimating, n2.userCancel]), u2 = z(() => {
    a2.current && o2(n2.resting);
  }, [o2, n2.resting]);
  return R(() => ({ dragging: c2, dropping: l2, resting: u2 }), [c2, l2, u2]);
}
function Co(e4, t2) {
  return Array.from(e4.querySelectorAll(t2));
}
var wo = (e4) => e4 && e4.ownerDocument && e4.ownerDocument.defaultView ? e4.ownerDocument.defaultView : window;
function To(e4) {
  return e4 instanceof wo(e4).HTMLElement;
}
function Eo(e4, t2) {
  let n2 = `[${fo.contextId}="${e4}"]`, r2 = Co(document, n2);
  if (!r2.length) return null;
  let i2 = r2.find((e5) => e5.getAttribute(fo.draggableId) === t2);
  return !i2 || !To(i2) ? null : i2;
}
function Do(e4) {
  let t2 = r({}), n2 = r(null), i2 = r(null), a2 = r(false), o2 = z(function(e5, n3) {
    let r2 = { id: e5, focus: n3 };
    return t2.current[e5] = r2, function() {
      let n4 = t2.current;
      n4[e5] !== r2 && delete n4[e5];
    };
  }, []), s2 = z(function(t3) {
    let n3 = Eo(e4, t3);
    n3 && n3 !== document.activeElement && n3.focus();
  }, [e4]), c2 = z(function(e5, t3) {
    n2.current === e5 && (n2.current = t3);
  }, []), l2 = z(function() {
    i2.current || a2.current && (i2.current = requestAnimationFrame(() => {
      i2.current = null;
      let e5 = n2.current;
      e5 && s2(e5);
    }));
  }, [s2]), u2 = z(function(e5) {
    n2.current = null;
    let t3 = document.activeElement;
    t3 && t3.getAttribute(fo.draggableId) === e5 && (n2.current = e5);
  }, []);
  return $(() => (a2.current = true, function() {
    a2.current = false;
    let e5 = i2.current;
    e5 && cancelAnimationFrame(e5);
  }), []), R(() => ({ register: o2, tryRecordFocus: u2, tryRestoreFocusRecorded: l2, tryShiftRecord: c2 }), [o2, u2, l2, c2]);
}
function Oo() {
  let e4 = { draggables: {}, droppables: {} }, t2 = [];
  function n2(e5) {
    return t2.push(e5), function() {
      let n3 = t2.indexOf(e5);
      n3 !== -1 && t2.splice(n3, 1);
    };
  }
  function r2(e5) {
    t2.length && t2.forEach((t3) => t3(e5));
  }
  function i2(t3) {
    return e4.draggables[t3] || null;
  }
  function a2(e5) {
    let t3 = i2(e5);
    return !t3 && L(), t3;
  }
  let o2 = { register: (t3) => {
    e4.draggables[t3.descriptor.id] = t3, r2({ type: `ADDITION`, value: t3 });
  }, update: (t3, n3) => {
    let r3 = e4.draggables[n3.descriptor.id];
    r3 && r3.uniqueId === t3.uniqueId && (delete e4.draggables[n3.descriptor.id], e4.draggables[t3.descriptor.id] = t3);
  }, unregister: (t3) => {
    let n3 = t3.descriptor.id, a3 = i2(n3);
    a3 && t3.uniqueId === a3.uniqueId && (delete e4.draggables[n3], e4.droppables[t3.descriptor.droppableId] && r2({ type: `REMOVAL`, value: t3 }));
  }, getById: a2, findById: i2, exists: (e5) => !!i2(e5), getAllByType: (t3) => Object.values(e4.draggables).filter((e5) => e5.descriptor.type === t3) };
  function s2(t3) {
    return e4.droppables[t3] || null;
  }
  function c2(e5) {
    let t3 = s2(e5);
    return !t3 && L(), t3;
  }
  let l2 = { register: (t3) => {
    e4.droppables[t3.descriptor.id] = t3;
  }, unregister: (t3) => {
    let n3 = s2(t3.descriptor.id);
    n3 && t3.uniqueId === n3.uniqueId && delete e4.droppables[t3.descriptor.id];
  }, getById: c2, findById: s2, exists: (e5) => !!s2(e5), getAllByType: (t3) => Object.values(e4.droppables).filter((e5) => e5.descriptor.type === t3) };
  function u2() {
    e4.draggables = {}, e4.droppables = {}, t2.length = 0;
  }
  return { draggable: o2, droppable: l2, subscribe: n2, clean: u2 };
}
function ko() {
  let e4 = R(Oo, []);
  return m(() => function() {
    e4.clean();
  }, [e4]), e4;
}
var Ao = p.createContext(null), jo = () => {
  let e4 = document.body;
  return !e4 && L(), e4;
}, Mo = { position: `absolute`, width: `1px`, height: `1px`, margin: `-1px`, border: `0`, padding: `0`, overflow: `hidden`, clip: `rect(0 0 0 0)`, "clip-path": `inset(100%)` }, No = (e4) => `rfd-announcement-${e4}`;
function Po(e4) {
  let t2 = R(() => No(e4), [e4]), n2 = r(null);
  return m(function() {
    let e5 = document.createElement(`div`);
    return n2.current = e5, e5.id = t2, e5.setAttribute(`aria-live`, `assertive`), e5.setAttribute(`aria-atomic`, `true`), Zt(e5.style, Mo), jo().appendChild(e5), function() {
      setTimeout(function() {
        let t3 = jo();
        t3.contains(e5) && t3.removeChild(e5), e5 === n2.current && (n2.current = null);
      });
    };
  }, [t2]), z((e5) => {
    let t3 = n2.current;
    if (t3) {
      t3.textContent = e5;
      return;
    }
  }, []);
}
var Fo = { separator: `::` };
function Io(e4, t2 = Fo) {
  let n2 = p.useId();
  return R(() => `${e4}${t2.separator}${n2}`, [t2.separator, e4, n2]);
}
function Lo({ contextId: e4, uniqueId: t2 }) {
  return `rfd-hidden-text-${e4}-${t2}`;
}
function Ro({ contextId: e4, text: t2 }) {
  let n2 = Io(`hidden-text`, { separator: `-` }), r2 = R(() => Lo({ contextId: e4, uniqueId: n2 }), [n2, e4]);
  return m(function() {
    let e5 = document.createElement(`div`);
    return e5.id = r2, e5.textContent = t2, e5.style.display = `none`, jo().appendChild(e5), function() {
      let t3 = jo();
      t3.contains(e5) && t3.removeChild(e5);
    };
  }, [r2, t2]), r2;
}
var zo = p.createContext(null);
function Bo(e4) {
  let t2 = r(e4);
  return m(() => {
    t2.current = e4;
  }), t2;
}
function Vo() {
  let e4 = null;
  function t2() {
    return !!e4;
  }
  function n2(t3) {
    return t3 === e4;
  }
  function r2(t3) {
    e4 && L();
    let n3 = { abandon: t3 };
    return e4 = n3, n3;
  }
  function i2() {
    !e4 && L(), e4 = null;
  }
  function a2() {
    e4 && (e4.abandon(), i2());
  }
  return { isClaimed: t2, isActive: n2, claim: r2, release: i2, tryAbandon: a2 };
}
function Ho(e4) {
  return e4.phase === `IDLE` || e4.phase === `DROP_ANIMATING` ? false : e4.isDragging;
}
var Uo = 9, Wo = 13, Go = 27, Ko = 32, qo = 33, Jo = 34, Yo = 35, Xo = 36, Zo = 37, Qo = 38, $o = 39, es = 40, ts = { [Wo]: true, [Uo]: true }, ns = (e4) => {
  ts[e4.keyCode] && e4.preventDefault();
}, rs = (() => {
  let e4 = `visibilitychange`;
  return typeof document > `u` ? e4 : [e4, `ms${e4}`, `webkit${e4}`, `moz${e4}`, `o${e4}`].find((e5) => `on${e5}` in document) || e4;
})(), is = 0, as = 5;
function os(e4, t2) {
  return Math.abs(t2.x - e4.x) >= as || Math.abs(t2.y - e4.y) >= as;
}
var ss = { type: `IDLE` };
function cs({ cancel: e4, completed: t2, getPhase: n2, setPhase: r2 }) {
  return [{ eventName: `mousemove`, fn: (e5) => {
    let { button: t3, clientX: i2, clientY: a2 } = e5;
    if (t3 !== is) return;
    let o2 = { x: i2, y: a2 }, s2 = n2();
    if (s2.type === `DRAGGING`) {
      e5.preventDefault(), s2.actions.move(o2);
      return;
    }
    s2.type !== `PENDING` && L();
    let c2 = s2.point;
    os(c2, o2) && (e5.preventDefault(), r2({ type: `DRAGGING`, actions: s2.actions.fluidLift(o2) }));
  } }, { eventName: `mouseup`, fn: (r3) => {
    let i2 = n2();
    if (i2.type !== `DRAGGING`) {
      e4();
      return;
    }
    r3.preventDefault(), i2.actions.drop({ shouldBlockNextClick: true }), t2();
  } }, { eventName: `mousedown`, fn: (t3) => {
    n2().type === `DRAGGING` && t3.preventDefault(), e4();
  } }, { eventName: `keydown`, fn: (t3) => {
    if (n2().type === `PENDING`) {
      e4();
      return;
    }
    if (t3.keyCode === Go) {
      t3.preventDefault(), e4();
      return;
    }
    ns(t3);
  } }, { eventName: `resize`, fn: e4 }, { eventName: `scroll`, options: { passive: true, capture: false }, fn: () => {
    n2().type === `PENDING` && e4();
  } }, { eventName: `webkitmouseforcedown`, fn: (t3) => {
    let r3 = n2();
    if (r3.type === `IDLE` && L(), r3.actions.shouldRespectForcePress()) {
      e4();
      return;
    }
    t3.preventDefault();
  } }, { eventName: rs, fn: e4 }];
}
function ls(e4) {
  let t2 = r(ss), n2 = r(F), i2 = R(() => ({ eventName: `mousedown`, fn: function(t3) {
    if (t3.defaultPrevented || t3.button !== is || t3.ctrlKey || t3.metaKey || t3.shiftKey || t3.altKey) return;
    let r2 = e4.findClosestDraggableId(t3);
    if (!r2) return;
    let i3 = e4.tryGetLock(r2, s2, { sourceEvent: t3 });
    if (!i3) return;
    t3.preventDefault();
    let a3 = { x: t3.clientX, y: t3.clientY };
    n2.current(), u2(i3, a3);
  } }), [e4]), a2 = R(() => ({ eventName: `webkitmouseforcewillbegin`, fn: (t3) => {
    if (t3.defaultPrevented) return;
    let n3 = e4.findClosestDraggableId(t3);
    if (!n3) return;
    let r2 = e4.findOptionsForDraggable(n3);
    r2 && (r2.shouldRespectForcePress || e4.canGetLock(n3) && t3.preventDefault());
  } }), [e4]), o2 = z(function() {
    n2.current = I(window, [a2, i2], { passive: false, capture: true });
  }, [a2, i2]), s2 = z(() => {
    t2.current.type !== `IDLE` && (t2.current = ss, n2.current(), o2());
  }, [o2]), c2 = z(() => {
    let e5 = t2.current;
    s2(), e5.type === `DRAGGING` && e5.actions.cancel({ shouldBlockNextClick: true }), e5.type === `PENDING` && e5.actions.abort();
  }, [s2]), l2 = z(function() {
    let e5 = { capture: true, passive: false }, r2 = cs({ cancel: c2, completed: s2, getPhase: () => t2.current, setPhase: (e6) => {
      t2.current = e6;
    } });
    n2.current = I(window, r2, e5);
  }, [c2, s2]), u2 = z(function(e5, n3) {
    t2.current.type !== `IDLE` && L(), t2.current = { type: `PENDING`, point: n3, actions: e5 }, l2();
  }, [l2]);
  $(function() {
    return o2(), function() {
      n2.current();
    };
  }, [o2]);
}
function us() {
}
var ds = { [Jo]: true, [qo]: true, [Xo]: true, [Yo]: true };
function fs(e4, t2) {
  function n2() {
    t2(), e4.cancel();
  }
  function r2() {
    t2(), e4.drop();
  }
  return [{ eventName: `keydown`, fn: (t3) => {
    if (t3.keyCode === Go) {
      t3.preventDefault(), n2();
      return;
    }
    if (t3.keyCode === Ko) {
      t3.preventDefault(), r2();
      return;
    }
    if (t3.keyCode === es) {
      t3.preventDefault(), e4.moveDown();
      return;
    }
    if (t3.keyCode === Qo) {
      t3.preventDefault(), e4.moveUp();
      return;
    }
    if (t3.keyCode === $o) {
      t3.preventDefault(), e4.moveRight();
      return;
    }
    if (t3.keyCode === Zo) {
      t3.preventDefault(), e4.moveLeft();
      return;
    }
    if (ds[t3.keyCode]) {
      t3.preventDefault();
      return;
    }
    ns(t3);
  } }, { eventName: `mousedown`, fn: n2 }, { eventName: `mouseup`, fn: n2 }, { eventName: `click`, fn: n2 }, { eventName: `touchstart`, fn: n2 }, { eventName: `resize`, fn: n2 }, { eventName: `wheel`, fn: n2, options: { passive: true } }, { eventName: rs, fn: n2 }];
}
function ps(e4) {
  let t2 = r(us), n2 = R(() => ({ eventName: `keydown`, fn: function(n3) {
    if (n3.defaultPrevented || n3.keyCode !== Ko) return;
    let r2 = e4.findClosestDraggableId(n3);
    if (!r2) return;
    let a2 = e4.tryGetLock(r2, c2, { sourceEvent: n3 });
    if (!a2) return;
    n3.preventDefault();
    let o2 = true, s2 = a2.snapLift();
    t2.current();
    function c2() {
      !o2 && L(), o2 = false, t2.current(), i2();
    }
    t2.current = I(window, fs(s2, c2), { capture: true, passive: false });
  } }), [e4]), i2 = z(function() {
    t2.current = I(window, [n2], { passive: false, capture: true });
  }, [n2]);
  $(function() {
    return i2(), function() {
      t2.current();
    };
  }, [i2]);
}
var ms = { type: `IDLE` }, hs = 120, gs = 0.15;
function _s({ cancel: e4, getPhase: t2 }) {
  return [{ eventName: `orientationchange`, fn: e4 }, { eventName: `resize`, fn: e4 }, { eventName: `contextmenu`, fn: (e5) => {
    e5.preventDefault();
  } }, { eventName: `keydown`, fn: (n2) => {
    if (t2().type !== `DRAGGING`) {
      e4();
      return;
    }
    n2.keyCode === Go && n2.preventDefault(), e4();
  } }, { eventName: rs, fn: e4 }];
}
function vs({ cancel: e4, completed: t2, getPhase: n2 }) {
  return [{ eventName: `touchmove`, options: { capture: false }, fn: (t3) => {
    let r2 = n2();
    if (r2.type !== `DRAGGING`) {
      e4();
      return;
    }
    r2.hasMoved = true;
    let { clientX: i2, clientY: a2 } = t3.touches[0], o2 = { x: i2, y: a2 };
    t3.preventDefault(), r2.actions.move(o2);
  } }, { eventName: `touchend`, fn: (r2) => {
    let i2 = n2();
    if (i2.type !== `DRAGGING`) {
      e4();
      return;
    }
    r2.preventDefault(), i2.actions.drop({ shouldBlockNextClick: true }), t2();
  } }, { eventName: `touchcancel`, fn: (t3) => {
    if (n2().type !== `DRAGGING`) {
      e4();
      return;
    }
    t3.preventDefault(), e4();
  } }, { eventName: `touchforcechange`, fn: (t3) => {
    let r2 = n2();
    r2.type === `IDLE` && L();
    let i2 = t3.touches[0];
    if (!i2 || !(i2.force >= gs)) return;
    let a2 = r2.actions.shouldRespectForcePress();
    if (r2.type === `PENDING`) {
      a2 && e4();
      return;
    }
    if (a2) {
      if (r2.hasMoved) {
        t3.preventDefault();
        return;
      }
      e4();
      return;
    }
    t3.preventDefault();
  } }, { eventName: rs, fn: e4 }];
}
function ys(e4) {
  let t2 = r(ms), n2 = r(F), i2 = z(function() {
    return t2.current;
  }, []), a2 = z(function(e5) {
    t2.current = e5;
  }, []), o2 = R(() => ({ eventName: `touchstart`, fn: function(t3) {
    if (t3.defaultPrevented) return;
    let r2 = e4.findClosestDraggableId(t3);
    if (!r2) return;
    let i3 = e4.tryGetLock(r2, c2, { sourceEvent: t3 });
    if (!i3) return;
    let { clientX: a3, clientY: o3 } = t3.touches[0], s3 = { x: a3, y: o3 };
    n2.current(), f2(i3, s3);
  } }), [e4]), s2 = z(function() {
    n2.current = I(window, [o2], { capture: true, passive: false });
  }, [o2]), c2 = z(() => {
    let e5 = t2.current;
    e5.type !== `IDLE` && (e5.type === `PENDING` && clearTimeout(e5.longPressTimerId), a2(ms), n2.current(), s2());
  }, [s2, a2]), l2 = z(() => {
    let e5 = t2.current;
    c2(), e5.type === `DRAGGING` && e5.actions.cancel({ shouldBlockNextClick: true }), e5.type === `PENDING` && e5.actions.abort();
  }, [c2]), u2 = z(function() {
    let e5 = { capture: true, passive: false }, t3 = { cancel: l2, completed: c2, getPhase: i2 }, r2 = I(window, vs(t3), e5), a3 = I(window, _s(t3), e5);
    n2.current = function() {
      r2(), a3();
    };
  }, [l2, i2, c2]), d2 = z(function() {
    let e5 = i2();
    e5.type !== `PENDING` && L();
    let t3 = e5.actions.fluidLift(e5.point);
    a2({ type: `DRAGGING`, actions: t3, hasMoved: false });
  }, [i2, a2]), f2 = z(function(e5, t3) {
    i2().type !== `IDLE` && L();
    let n3 = setTimeout(d2, hs);
    a2({ type: `PENDING`, point: t3, actions: e5, longPressTimerId: n3 }), u2();
  }, [u2, i2, a2, d2]);
  $(function() {
    return s2(), function() {
      n2.current();
      let e5 = i2();
      e5.type === `PENDING` && (clearTimeout(e5.longPressTimerId), a2(ms));
    };
  }, [i2, s2, a2]), $(function() {
    return I(window, [{ eventName: `touchmove`, fn: () => {
    }, options: { capture: false, passive: false } }]);
  }, []);
}
var bs = [`input`, `button`, `textarea`, `select`, `option`, `optgroup`, `video`, `audio`];
function xs(e4, t2) {
  if (t2 == null) return false;
  if (bs.includes(t2.tagName.toLowerCase())) return true;
  let n2 = t2.getAttribute(`contenteditable`);
  return n2 === `true` || n2 === `` || t2 !== e4 && xs(e4, t2.parentElement);
}
function Ss(e4, t2) {
  let n2 = t2.target;
  return To(n2) ? xs(e4, n2) : false;
}
var Cs = (e4) => N(e4.getBoundingClientRect()).center;
function ws(e4) {
  return e4 instanceof wo(e4).Element;
}
var Ts = (() => {
  let e4 = `matches`;
  return typeof document > `u` ? e4 : [e4, `msMatchesSelector`, `webkitMatchesSelector`].find((e5) => e5 in Element.prototype) || e4;
})();
function Es(e4, t2) {
  return e4 == null ? null : e4[Ts](t2) ? e4 : Es(e4.parentElement, t2);
}
function Ds(e4, t2) {
  return e4.closest ? e4.closest(t2) : Es(e4, t2);
}
function Os(e4) {
  return `[${fo.contextId}="${e4}"]`;
}
function ks(e4, t2) {
  let n2 = t2.target;
  if (!ws(n2)) return null;
  let r2 = Ds(n2, Os(e4));
  return !r2 || !To(r2) ? null : r2;
}
function As(e4, t2) {
  let n2 = ks(e4, t2);
  return n2 ? n2.getAttribute(fo.draggableId) : null;
}
function js(e4, t2) {
  let n2 = `[${po.contextId}="${e4}"]`, r2 = Co(document, n2).find((e5) => e5.getAttribute(po.id) === t2);
  return !r2 || !To(r2) ? null : r2;
}
function Ms(e4) {
  e4.preventDefault();
}
function Ns({ expected: e4, phase: t2, isLockActive: n2, shouldWarn: r2 }) {
  return !(!n2() || e4 !== t2);
}
function Ps({ lockAPI: e4, store: t2, registry: n2, draggableId: r2 }) {
  if (e4.isClaimed()) return false;
  let i2 = n2.draggable.findById(r2);
  return !(!i2 || !i2.options.isEnabled || !Fa(t2.getState(), r2));
}
function Fs({ lockAPI: e4, contextId: t2, store: n2, registry: r2, draggableId: i2, forceSensorStop: a2, sourceEvent: o2 }) {
  if (!Ps({ lockAPI: e4, store: n2, registry: r2, draggableId: i2 })) return null;
  let s2 = r2.draggable.getById(i2), c2 = js(t2, s2.descriptor.id);
  if (!c2 || o2 && !s2.options.canDragInteractiveElements && Ss(c2, o2)) return null;
  let l2 = e4.claim(a2 || F), u2 = `PRE_DRAG`;
  function d2() {
    return s2.options.shouldRespectForcePress;
  }
  function f2() {
    return e4.isActive(l2);
  }
  function p2(e5, t3) {
    Ns({ expected: e5, phase: u2, isLockActive: f2, shouldWarn: true }) && n2.dispatch(t3());
  }
  let m2 = p2.bind(null, `DRAGGING`);
  function h2(t3) {
    function r3() {
      e4.release(), u2 = `COMPLETED`;
    }
    u2 !== `PRE_DRAG` && (r3(), L()), n2.dispatch(yi(t3.liftActionArgs)), u2 = `DRAGGING`;
    function i3(e5, i4 = { shouldBlockNextClick: false }) {
      if (t3.cleanup(), i4.shouldBlockNextClick) {
        let e6 = I(window, [{ eventName: `click`, fn: Ms, options: { once: true, passive: false, capture: true } }]);
        setTimeout(e6);
      }
      r3(), n2.dispatch(Ii({ reason: e5 }));
    }
    return { isActive: () => Ns({ expected: `DRAGGING`, phase: u2, isLockActive: f2, shouldWarn: false }), shouldRespectForcePress: d2, drop: (e5) => i3(`DROP`, e5), cancel: (e5) => i3(`CANCEL`, e5), ...t3.actions };
  }
  function g2(e5) {
    let t3 = Xt((e6) => {
      m2(() => Ei({ client: e6 }));
    });
    return { ...h2({ liftActionArgs: { id: i2, clientSelection: e5, movementMode: `FLUID` }, cleanup: () => t3.cancel(), actions: { move: t3 } }), move: t3 };
  }
  function _2() {
    return h2({ liftActionArgs: { id: i2, clientSelection: Cs(c2), movementMode: `SNAP` }, cleanup: F, actions: { moveUp: () => m2(ki), moveRight: () => m2(ji), moveDown: () => m2(Ai), moveLeft: () => m2(Mi) } });
  }
  function v2() {
    Ns({ expected: `PRE_DRAG`, phase: u2, isLockActive: f2, shouldWarn: true }) && e4.release();
  }
  return { isActive: () => Ns({ expected: `PRE_DRAG`, phase: u2, isLockActive: f2, shouldWarn: false }), shouldRespectForcePress: d2, fluidLift: g2, snapLift: _2, abort: v2 };
}
var Is = [ls, ps, ys];
function Ls({ contextId: e4, store: t2, registry: n2, customSensors: r2, enableDefaultSensors: a2 }) {
  let o2 = [...a2 ? Is : [], ...r2 || []], s2 = i(() => Vo())[0], c2 = z(function(e5, t3) {
    Ho(e5) && !Ho(t3) && s2.tryAbandon();
  }, [s2]);
  $(function() {
    let e5 = t2.getState();
    return t2.subscribe(() => {
      let n3 = t2.getState();
      c2(e5, n3), e5 = n3;
    });
  }, [s2, t2, c2]), $(() => s2.tryAbandon, [s2.tryAbandon]);
  let l2 = z((e5) => Ps({ lockAPI: s2, registry: n2, store: t2, draggableId: e5 }), [s2, n2, t2]), u2 = z((r3, i2, a3) => Fs({ lockAPI: s2, registry: n2, contextId: e4, store: t2, draggableId: r3, forceSensorStop: i2 || null, sourceEvent: a3 && a3.sourceEvent ? a3.sourceEvent : null }), [e4, s2, n2, t2]), d2 = z((t3) => As(e4, t3), [e4]), f2 = z((e5) => {
    let t3 = n2.draggable.findById(e5);
    return t3 ? t3.options : null;
  }, [n2.draggable]), p2 = z(function() {
    s2.isClaimed() && (s2.tryAbandon(), t2.getState().phase !== `IDLE` && t2.dispatch(Ni()));
  }, [s2, t2]), m2 = z(() => s2.isClaimed(), [s2]), h2 = R(() => ({ canGetLock: l2, tryGetLock: u2, findClosestDraggableId: d2, findOptionsForDraggable: f2, tryReleaseLock: p2, isLockClaimed: m2 }), [l2, u2, d2, f2, p2, m2]);
  for (let e5 = 0; e5 < o2.length; e5++) o2[e5](h2);
}
var Rs = (e4) => ({ onBeforeCapture: (t2) => {
  ue(() => {
    e4.onBeforeCapture && e4.onBeforeCapture(t2);
  });
}, onBeforeDragStart: e4.onBeforeDragStart, onDragStart: e4.onDragStart, onDragEnd: e4.onDragEnd, onDragUpdate: e4.onDragUpdate }), zs = (e4) => ({ ...Ba, ...e4.autoScrollerOptions, durationDampening: { ...Ba.durationDampening, ...e4.autoScrollerOptions } });
function Bs(e4) {
  return !e4.current && L(), e4.current;
}
function Vs(e4) {
  let { contextId: t2, setCallbacks: n2, sensors: i2, nonce: a2, dragHandleUsageInstructions: o2 } = e4, s2 = r(null), c2 = Bo(e4), l2 = z(() => Rs(c2.current), [c2]), u2 = z(() => zs(c2.current), [c2]), d2 = Po(t2), f2 = Ro({ contextId: t2, text: o2 }), h2 = So(t2, a2), g2 = z((e5) => {
    Bs(s2).dispatch(e5);
  }, []), _2 = R(() => we({ publishWhileDragging: xi, updateDroppableScroll: Ci, updateDroppableIsEnabled: wi, updateDroppableIsCombineEnabled: Ti, collectionStarting: Si }, g2), [g2]), v2 = ko(), y2 = R(() => Pa(v2, _2), [v2, _2]), b2 = R(() => lo({ scrollWindow: Ia, scrollDroppable: y2.scrollDroppable, getAutoScrollerOptions: u2, ...we({ move: Ei }, g2) }), [y2.scrollDroppable, g2, u2]), x2 = Do(t2), S2 = R(() => Ta({ announce: d2, autoScroller: b2, dimensionMarshal: y2, focusMarshal: x2, getResponders: l2, styleMarshal: h2 }), [d2, b2, y2, x2, l2, h2]);
  s2.current = S2;
  let C2 = z(() => {
    let e5 = Bs(s2);
    e5.getState().phase !== `IDLE` && e5.dispatch(Ni());
  }, []), w2 = z(() => {
    let e5 = Bs(s2).getState();
    return e5.phase === `DROP_ANIMATING` || e5.phase !== `IDLE` && e5.isDragging;
  }, []);
  n2(R(() => ({ isDragging: w2, tryAbort: C2 }), [w2, C2]));
  let T2 = z((e5) => Fa(Bs(s2).getState(), e5), []), E2 = z(() => X(Bs(s2).getState()), []), D2 = R(() => ({ marshal: y2, focus: x2, contextId: t2, canLift: T2, isMovementAllowed: E2, dragHandleUsageInstructionsId: f2, registry: v2 }), [t2, y2, f2, x2, T2, E2, v2]);
  return Ls({ contextId: t2, store: S2, registry: v2, customSensors: i2 || null, enableDefaultSensors: e4.enableDefaultSensors !== false }), m(() => C2, [C2]), p.createElement(zo.Provider, { value: D2 }, p.createElement(Lt, { context: Ao, store: S2 }, e4.children));
}
function Hs() {
  return p.useId();
}
function Us(e4) {
  let t2 = Hs(), n2 = e4.dragHandleUsageInstructions || dn.dragHandleUsageInstructions;
  return p.createElement(nn, null, (r2) => p.createElement(Vs, { nonce: e4.nonce, contextId: t2, setCallbacks: r2, dragHandleUsageInstructions: n2, enableDefaultSensors: e4.enableDefaultSensors, sensors: e4.sensors, onBeforeCapture: e4.onBeforeCapture, onBeforeDragStart: e4.onBeforeDragStart, onDragStart: e4.onDragStart, onDragUpdate: e4.onDragUpdate, onDragEnd: e4.onDragEnd, autoScrollerOptions: e4.autoScrollerOptions }, e4.children));
}
var Ws = { dragging: 5e3, dropAnimating: 4500 }, Gs = (e4, t2) => t2 ? Wi.drop(t2.duration) : e4 ? Wi.snap : Wi.fluid, Ks = (e4, t2) => {
  if (e4) return t2 ? Hi.opacity.drop : Hi.opacity.combining;
}, qs = (e4) => e4.forceShouldAnimate == null ? e4.mode === `SNAP` : e4.forceShouldAnimate;
function Js(e4) {
  let t2 = e4.dimension.client, { offset: n2, combineWith: r2, dropping: i2 } = e4, a2 = !!r2, o2 = qs(e4), s2 = !!i2, c2 = s2 ? Ki.drop(n2, a2) : Ki.moveTo(n2);
  return { position: `fixed`, top: t2.marginBox.top, left: t2.marginBox.left, boxSizing: `border-box`, width: t2.borderBox.width, height: t2.borderBox.height, transition: Gs(o2, i2), transform: c2, opacity: Ks(a2, s2), zIndex: s2 ? Ws.dropAnimating : Ws.dragging, pointerEvents: `none` };
}
function Ys(e4) {
  return { transform: Ki.moveTo(e4.offset), transition: e4.shouldAnimateDisplacement ? void 0 : `none` };
}
function Xs(e4) {
  return e4.type === `DRAGGING` ? Js(e4) : Ys(e4);
}
function Zs(e4, t2, n2 = B) {
  let r2 = window.getComputedStyle(t2), i2 = Jt(t2.getBoundingClientRect(), r2), a2 = qt(i2, n2);
  return { descriptor: e4, placeholder: { client: i2, tagName: t2.tagName.toLowerCase(), display: r2.display }, displaceBy: { x: i2.marginBox.width, y: i2.marginBox.height }, client: i2, page: a2 };
}
function Qs(e4) {
  let t2 = Io(`draggable`), { descriptor: n2, registry: i2, getDraggableRef: a2, canDragInteractiveElements: o2, shouldRespectForcePress: s2, isEnabled: c2 } = e4, l2 = R(() => ({ canDragInteractiveElements: o2, shouldRespectForcePress: s2, isEnabled: c2 }), [o2, c2, s2]), u2 = z((e5) => {
    let t3 = a2();
    return !t3 && L(), Zs(n2, t3, e5);
  }, [n2, a2]), d2 = R(() => ({ uniqueId: t2, descriptor: n2, options: l2, getDimension: u2 }), [n2, u2, l2, t2]), f2 = r(d2), p2 = r(true);
  $(() => (i2.draggable.register(f2.current), () => i2.draggable.unregister(f2.current)), [i2.draggable]), $(() => {
    if (p2.current) {
      p2.current = false;
      return;
    }
    let e5 = f2.current;
    f2.current = d2, i2.draggable.update(d2, e5);
  }, [d2, i2.draggable]);
}
var $s = p.createContext(null);
function ec(e4) {
  let t2 = c(e4);
  return !t2 && L(), t2;
}
function tc(e4) {
  e4.preventDefault();
}
var nc = (e4) => {
  let t2 = r(null), n2 = z((e5 = null) => {
    t2.current = e5;
  }, []), i2 = z(() => t2.current, []), { contextId: a2, dragHandleUsageInstructionsId: o2, registry: s2 } = ec(zo), { type: c2, droppableId: l2 } = ec($s), u2 = R(() => ({ id: e4.draggableId, index: e4.index, type: c2, droppableId: l2 }), [e4.draggableId, e4.index, c2, l2]), { children: d2, draggableId: f2, isEnabled: m2, shouldRespectForcePress: h2, canDragInteractiveElements: g2, isClone: _2, mapped: v2, dropAnimationFinished: y2 } = e4;
  _2 || Qs(R(() => ({ descriptor: u2, registry: s2, getDraggableRef: i2, canDragInteractiveElements: g2, shouldRespectForcePress: h2, isEnabled: m2 }), [u2, s2, i2, g2, h2, m2]));
  let b2 = R(() => m2 ? { tabIndex: 0, role: `button`, "aria-describedby": o2, "data-rfd-drag-handle-draggable-id": f2, "data-rfd-drag-handle-context-id": a2, draggable: false, onDragStart: tc } : null, [a2, o2, f2, m2]), x2 = z((e5) => {
    v2.type === `DRAGGING` && v2.dropping && e5.propertyName === `transform` && ue(y2);
  }, [y2, v2]), S2 = R(() => {
    let e5 = Xs(v2), t3 = v2.type === `DRAGGING` && v2.dropping ? x2 : void 0;
    return { innerRef: n2, draggableProps: { "data-rfd-draggable-context-id": a2, "data-rfd-draggable-id": f2, style: e5, onTransitionEnd: t3 }, dragHandleProps: b2 };
  }, [a2, b2, f2, v2, x2, n2]), C2 = R(() => ({ draggableId: u2.id, type: u2.type, source: { index: u2.index, droppableId: u2.droppableId } }), [u2.droppableId, u2.id, u2.index, u2.type]);
  return p.createElement(p.Fragment, null, d2(S2, v2.snapshot, C2));
}, rc = (e4, t2) => e4 === t2, ic = (e4) => {
  let { combine: t2, destination: n2 } = e4;
  return n2 ? n2.droppableId : t2 ? t2.droppableId : null;
}, ac = (e4) => e4.combine ? e4.combine.draggableId : null, oc = (e4) => e4.at && e4.at.type === `COMBINE` ? e4.at.combine.draggableId : null;
function sc() {
  let e4 = G((e5, t3) => ({ x: e5, y: t3 })), t2 = G((e5, t3, n3 = null, r2 = null, i2 = null) => ({ isDragging: true, isClone: t3, isDropAnimating: !!i2, dropAnimation: i2, mode: e5, draggingOver: n3, combineWith: r2, combineTargetFor: null })), n2 = G((e5, n3, r2, i2, a2 = null, o2 = null, s2 = null) => ({ mapped: { type: `DRAGGING`, dropping: null, draggingOver: a2, combineWith: o2, mode: n3, offset: e5, dimension: r2, forceShouldAnimate: s2, snapshot: t2(n3, i2, a2, o2, null) } }));
  return (r2, i2) => {
    if (Ho(r2)) {
      if (r2.critical.draggable.id !== i2.draggableId) return null;
      let t3 = r2.current.client.offset, a2 = r2.dimensions.draggables[i2.draggableId], o2 = Y(r2.impact), s2 = oc(r2.impact), c2 = r2.forceShouldAnimate;
      return n2(e4(t3.x, t3.y), r2.movementMode, a2, i2.isClone, o2, s2, c2);
    }
    if (r2.phase === `DROP_ANIMATING`) {
      let e5 = r2.completed;
      if (e5.result.draggableId !== i2.draggableId) return null;
      let n3 = i2.isClone, a2 = r2.dimensions.draggables[i2.draggableId], o2 = e5.result, s2 = o2.mode, c2 = ic(o2), l2 = ac(o2), u2 = { duration: r2.dropDuration, curve: Vi.drop, moveTo: r2.newHomeClientOffset, opacity: l2 ? Hi.opacity.drop : null, scale: l2 ? Hi.scale.drop : null };
      return { mapped: { type: `DRAGGING`, offset: r2.newHomeClientOffset, dimension: a2, dropping: u2, draggingOver: c2, combineWith: l2, mode: s2, forceShouldAnimate: null, snapshot: t2(s2, n3, c2, l2, u2) } };
    }
    return null;
  };
}
function cc(e4 = null) {
  return { isDragging: false, isDropAnimating: false, isClone: false, dropAnimation: null, mode: null, draggingOver: null, combineTargetFor: e4, combineWith: null };
}
var lc = { mapped: { type: `SECONDARY`, offset: B, combineTargetFor: null, shouldAnimateDisplacement: true, snapshot: cc(null) } };
function uc() {
  let e4 = G((e5, t3) => ({ x: e5, y: t3 })), t2 = G(cc), n2 = G((e5, n3 = null, r3) => ({ mapped: { type: `SECONDARY`, offset: e5, combineTargetFor: n3, shouldAnimateDisplacement: r3, snapshot: t2(n3) } })), r2 = (e5) => e5 ? n2(B, e5, true) : null, i2 = (t3, i3, a2, o2) => {
    let s2 = a2.displaced.visible[t3], c2 = !!(o2.inVirtualList && o2.effected[t3]), l2 = Nn(a2), u2 = l2 && l2.draggableId === t3 ? i3 : null;
    if (!s2) {
      if (!c2) return r2(u2);
      if (a2.displaced.invisible[t3]) return null;
      let i4 = mn(o2.displacedBy.point), s3 = e4(i4.x, i4.y);
      return n2(s3, u2, true);
    }
    if (c2) return r2(u2);
    let d2 = a2.displacedBy.point, f2 = e4(d2.x, d2.y);
    return n2(f2, u2, s2.shouldAnimate);
  };
  return (e5, t3) => {
    if (Ho(e5)) return e5.critical.draggable.id === t3.draggableId ? null : i2(t3.draggableId, e5.critical.draggable.id, e5.impact, e5.afterCritical);
    if (e5.phase === `DROP_ANIMATING`) {
      let n3 = e5.completed;
      return n3.result.draggableId === t3.draggableId ? null : i2(t3.draggableId, n3.result.draggableId, n3.impact, n3.afterCritical);
    }
    return null;
  };
}
var dc = Ft(() => {
  let e4 = sc(), t2 = uc();
  return (n2, r2) => e4(n2, r2) || t2(n2, r2) || lc;
}, { dropAnimationFinished: Ri }, null, { context: Ao, areStatePropsEqual: rc })(nc);
function fc(e4) {
  return ec($s).isUsingCloneFor === e4.draggableId && !e4.isClone ? null : p.createElement(dc, e4);
}
function pc(e4) {
  let t2 = typeof e4.isDragDisabled != `boolean` || !e4.isDragDisabled, n2 = !!e4.disableInteractiveElementBlocking, r2 = !!e4.shouldRespectForcePress;
  return p.createElement(fc, Zt({}, e4, { isClone: false, isEnabled: t2, canDragInteractiveElements: n2, shouldRespectForcePress: r2 }));
}
var mc = (e4) => (t2) => e4 === t2, hc = mc(`scroll`), gc = mc(`auto`), _c = (e4, t2) => t2(e4.overflowX) || t2(e4.overflowY), vc = (e4) => {
  let t2 = window.getComputedStyle(e4), n2 = { overflowX: t2.overflowX, overflowY: t2.overflowY };
  return _c(n2, hc) || _c(n2, gc);
}, yc = () => false, bc = (e4) => e4 == null ? null : e4 === document.body ? yc() ? e4 : null : e4 === document.documentElement ? null : vc(e4) ? e4 : bc(e4.parentElement), xc = (e4) => ({ x: e4.scrollLeft, y: e4.scrollTop }), Sc = (e4) => e4 ? window.getComputedStyle(e4).position === `fixed` || Sc(e4.parentElement) : false, Cc = (e4) => ({ closestScrollable: bc(e4), isFixedOnPage: Sc(e4) }), wc = ({ descriptor: e4, isEnabled: t2, isCombineEnabled: n2, isFixedOnPage: r2, direction: i2, client: a2, page: o2, closest: s2 }) => {
  let c2 = (() => {
    if (!s2) return null;
    let { scrollSize: e5, client: t3 } = s2, n3 = Oa({ scrollHeight: e5.scrollHeight, scrollWidth: e5.scrollWidth, height: t3.paddingBox.height, width: t3.paddingBox.width });
    return { pageMarginBox: s2.page.marginBox, frameClient: t3, scrollSize: e5, shouldClipSubject: s2.shouldClipSubject, scroll: { initial: s2.scroll, current: s2.scroll, max: n3, diff: { value: B, displacement: B } } };
  })(), l2 = i2 === `vertical` ? Hn : Un;
  return { descriptor: e4, isCombineEnabled: n2, isFixedOnPage: r2, axis: l2, isEnabled: t2, client: a2, page: o2, frame: c2, subject: Tn({ page: o2, withPlaceholder: null, axis: l2, frame: c2 }) };
}, Tc = (e4, t2) => {
  let n2 = Yt(e4);
  if (!t2 || e4 !== t2) return n2;
  let r2 = n2.paddingBox.top - t2.scrollTop, i2 = n2.paddingBox.left - t2.scrollLeft, a2 = r2 + t2.scrollHeight;
  return Wt({ borderBox: Bt({ top: r2, right: i2 + t2.scrollWidth, bottom: a2, left: i2 }, n2.border), margin: n2.margin, border: n2.border, padding: n2.padding });
}, Ec = ({ ref: e4, descriptor: t2, env: n2, windowScroll: r2, direction: i2, isDropDisabled: a2, isCombineEnabled: o2, shouldClipSubject: s2 }) => {
  let c2 = n2.closestScrollable, l2 = Tc(e4, c2), u2 = qt(l2, r2), d2 = (() => {
    if (!c2) return null;
    let e5 = Yt(c2), t3 = { scrollHeight: c2.scrollHeight, scrollWidth: c2.scrollWidth };
    return { client: e5, page: qt(e5, r2), scroll: xc(c2), scrollSize: t3, shouldClipSubject: s2 };
  })();
  return wc({ descriptor: t2, isEnabled: !a2, isCombineEnabled: o2, isFixedOnPage: n2.isFixedOnPage, direction: i2, client: l2, page: u2, closest: d2 });
}, Dc = { passive: false }, Oc = { passive: true }, kc = (e4) => e4.shouldPublishImmediately ? Dc : Oc, Ac = (e4) => e4 && e4.env.closestScrollable || null;
function jc(e4) {
  let t2 = r(null), n2 = ec(zo), i2 = Io(`droppable`), { registry: a2, marshal: o2 } = n2, s2 = Bo(e4), c2 = R(() => ({ id: e4.droppableId, type: e4.type, mode: e4.mode }), [e4.droppableId, e4.mode, e4.type]), l2 = r(c2), u2 = R(() => G((e5, n3) => {
    !t2.current && L();
    let r2 = { x: e5, y: n3 };
    o2.updateDroppableScroll(c2.id, r2);
  }), [c2.id, o2]), d2 = z(() => {
    let e5 = t2.current;
    return !e5 || !e5.env.closestScrollable ? B : xc(e5.env.closestScrollable);
  }, []), f2 = z(() => {
    let e5 = d2();
    u2(e5.x, e5.y);
  }, [d2, u2]), p2 = R(() => Xt(f2), [f2]), m2 = z(() => {
    let e5 = t2.current, n3 = Ac(e5);
    if (!(e5 && n3) && L(), e5.scrollOptions.shouldPublishImmediately) {
      f2();
      return;
    }
    p2();
  }, [p2, f2]), h2 = z((e5, r2) => {
    t2.current && L();
    let i3 = s2.current, a3 = i3.getDroppableRef();
    !a3 && L();
    let o3 = Cc(a3), l3 = { ref: a3, descriptor: c2, env: o3, scrollOptions: r2 };
    t2.current = l3;
    let u3 = Ec({ ref: a3, descriptor: c2, env: o3, windowScroll: e5, direction: i3.direction, isDropDisabled: i3.isDropDisabled, isCombineEnabled: i3.isCombineEnabled, shouldClipSubject: !i3.ignoreContainerClipping }), d3 = o3.closestScrollable;
    return d3 && (d3.setAttribute(ho.contextId, n2.contextId), d3.addEventListener(`scroll`, m2, kc(l3.scrollOptions))), u3;
  }, [n2.contextId, c2, m2, s2]), g2 = z(() => {
    let e5 = t2.current, n3 = Ac(e5);
    return !(e5 && n3) && L(), xc(n3);
  }, []), _2 = z(() => {
    let e5 = t2.current;
    !e5 && L();
    let n3 = Ac(e5);
    t2.current = null, n3 && (p2.cancel(), n3.removeAttribute(ho.contextId), n3.removeEventListener(`scroll`, m2, kc(e5.scrollOptions)));
  }, [m2, p2]), v2 = z((e5) => {
    let n3 = t2.current;
    !n3 && L();
    let r2 = Ac(n3);
    !r2 && L(), r2.scrollTop += e5.y, r2.scrollLeft += e5.x;
  }, []), y2 = R(() => ({ getDimensionAndWatchScroll: h2, getScrollWhileDragging: g2, dragStopped: _2, scroll: v2 }), [_2, h2, g2, v2]), b2 = R(() => ({ uniqueId: i2, descriptor: c2, callbacks: y2 }), [y2, c2, i2]);
  $(() => (l2.current = b2.descriptor, a2.droppable.register(b2), () => {
    t2.current && _2(), a2.droppable.unregister(b2);
  }), [y2, c2, _2, b2, o2, a2.droppable]), $(() => {
    t2.current && o2.updateDroppableIsEnabled(l2.current.id, !e4.isDropDisabled);
  }, [e4.isDropDisabled, o2]), $(() => {
    t2.current && o2.updateDroppableIsCombineEnabled(l2.current.id, e4.isCombineEnabled);
  }, [e4.isCombineEnabled, o2]);
}
function Mc() {
}
var Nc = { width: 0, height: 0, margin: xn }, Pc = ({ isAnimatingOpenOnMount: e4, placeholder: t2, animate: n2 }) => e4 || n2 === `close` ? Nc : { height: t2.client.borderBox.height, width: t2.client.borderBox.width, margin: t2.client.margin }, Fc = ({ isAnimatingOpenOnMount: e4, placeholder: t2, animate: n2 }) => {
  let r2 = Pc({ isAnimatingOpenOnMount: e4, placeholder: t2, animate: n2 });
  return { display: t2.display, boxSizing: `border-box`, width: r2.width, height: r2.height, marginTop: r2.margin.top, marginRight: r2.margin.right, marginBottom: r2.margin.bottom, marginLeft: r2.margin.left, flexShrink: `0`, flexGrow: `0`, pointerEvents: `none`, transition: n2 === `none` ? null : Wi.placeholder };
}, Ic = p.memo((e4) => {
  let t2 = r(null), n2 = z(() => {
    t2.current && (t2.current = (clearTimeout(t2.current), null));
  }, []), { animate: a2, onTransitionEnd: o2, onClose: s2, contextId: c2 } = e4, [l2, u2] = i(e4.animate === `open`);
  m(() => l2 ? a2 === `open` ? t2.current ? Mc : (t2.current = setTimeout(() => {
    t2.current = null, u2(false);
  }), n2) : (n2(), u2(false), Mc) : Mc, [a2, l2, n2]);
  let d2 = z((e5) => {
    e5.propertyName === `height` && (o2(), a2 === `close` && s2());
  }, [a2, s2, o2]), f2 = Fc({ isAnimatingOpenOnMount: l2, animate: e4.animate, placeholder: e4.placeholder });
  return p.createElement(e4.placeholder.tagName, { style: f2, "data-rfd-placeholder-context-id": c2, onTransitionEnd: d2, ref: e4.innerRef });
}), Lc = class extends p.PureComponent {
  constructor(...e4) {
    super(...e4), this.state = { isVisible: !!this.props.on, data: this.props.on, animate: this.props.shouldAnimate && this.props.on ? `open` : `none` }, this.onClose = () => {
      this.state.animate === `close` && this.setState({ isVisible: false });
    };
  }
  static getDerivedStateFromProps(e4, t2) {
    return e4.shouldAnimate ? e4.on ? { isVisible: true, data: e4.on, animate: `open` } : t2.isVisible ? { isVisible: true, data: t2.data, animate: `close` } : { isVisible: false, animate: `close`, data: null } : { isVisible: !!e4.on, data: e4.on, animate: `none` };
  }
  render() {
    if (!this.state.isVisible) return null;
    let e4 = { onClose: this.onClose, data: this.state.data, animate: this.state.animate };
    return this.props.children(e4);
  }
}, Rc = (e4) => {
  let t2 = c(zo);
  !t2 && L();
  let { contextId: n2, isMovementAllowed: i2 } = t2, a2 = r(null), o2 = r(null), { children: s2, droppableId: l2, type: u2, mode: d2, direction: f2, ignoreContainerClipping: m2, isDropDisabled: h2, isCombineEnabled: g2, snapshot: _2, useClone: v2, updateViewportMaxScroll: y2, getContainerForClone: b2 } = e4, x2 = z(() => a2.current, []), S2 = z((e5 = null) => {
    a2.current = e5;
  }, []);
  z(() => o2.current, []);
  let C2 = z((e5 = null) => {
    o2.current = e5;
  }, []), w2 = z(() => {
    i2() && y2({ maxScroll: Aa() });
  }, [i2, y2]);
  jc({ droppableId: l2, type: u2, mode: d2, direction: f2, isDropDisabled: h2, isCombineEnabled: g2, ignoreContainerClipping: m2, getDroppableRef: x2 });
  let T2 = R(() => p.createElement(Lc, { on: e4.placeholder, shouldAnimate: e4.shouldAnimatePlaceholder }, ({ onClose: e5, data: t3, animate: r2 }) => p.createElement(Ic, { placeholder: t3, onClose: e5, innerRef: C2, animate: r2, contextId: n2, onTransitionEnd: w2 })), [n2, w2, e4.placeholder, e4.shouldAnimatePlaceholder, C2]), E2 = R(() => ({ innerRef: S2, placeholder: T2, droppableProps: { "data-rfd-droppable-id": l2, "data-rfd-droppable-context-id": n2 } }), [n2, l2, T2, S2]), D2 = v2 ? v2.dragging.draggableId : null, ee2 = R(() => ({ droppableId: l2, type: u2, isUsingCloneFor: D2 }), [l2, D2, u2]);
  function te2() {
    if (!v2) return null;
    let { dragging: e5, render: t3 } = v2, n3 = p.createElement(fc, { draggableId: e5.draggableId, index: e5.source.index, isClone: true, isEnabled: true, shouldRespectForcePress: false, canDragInteractiveElements: true }, (n4, r2) => t3(n4, r2, e5));
    return oe.createPortal(n3, b2());
  }
  return p.createElement($s.Provider, { value: ee2 }, s2(E2, _2), te2());
};
function zc() {
  return !document.body && L(), document.body;
}
var Bc = { mode: `standard`, type: `DEFAULT`, direction: `vertical`, isDropDisabled: false, isCombineEnabled: false, ignoreContainerClipping: false, renderClone: null, getContainerForClone: zc }, Vc = (e4) => {
  let t2 = { ...e4 }, n2;
  for (n2 in Bc) e4[n2] === void 0 && (t2 = { ...t2, [n2]: Bc[n2] });
  return t2;
}, Hc = (e4, t2) => e4 === t2.droppable.type, Uc = (e4, t2) => t2.draggables[e4.draggable.id], Wc = Ft(() => {
  let e4 = { placeholder: null, shouldAnimatePlaceholder: true, snapshot: { isDraggingOver: false, draggingOverWith: null, draggingFromThisWith: null, isUsingPlaceholder: false }, useClone: null }, t2 = { ...e4, shouldAnimatePlaceholder: false }, n2 = G((e5) => ({ draggableId: e5.id, type: e5.type, source: { index: e5.index, droppableId: e5.droppableId } })), r2 = G((r3, i2, a2, o2, s2, c2) => {
    let l2 = s2.descriptor.id;
    if (s2.descriptor.droppableId === r3) {
      let e5 = c2 ? { render: c2, dragging: n2(s2.descriptor) } : null, t3 = { isDraggingOver: a2, draggingOverWith: a2 ? l2 : null, draggingFromThisWith: l2, isUsingPlaceholder: true };
      return { placeholder: s2.placeholder, shouldAnimatePlaceholder: false, snapshot: t3, useClone: e5 };
    }
    if (!i2) return t2;
    if (!o2) return e4;
    let u2 = { isDraggingOver: a2, draggingOverWith: l2, draggingFromThisWith: null, isUsingPlaceholder: true };
    return { placeholder: s2.placeholder, shouldAnimatePlaceholder: true, snapshot: u2, useClone: null };
  });
  return (n3, i2) => {
    let a2 = Vc(i2), o2 = a2.droppableId, s2 = a2.type, c2 = !a2.isDropDisabled, l2 = a2.renderClone;
    if (Ho(n3)) {
      let e5 = n3.critical;
      if (!Hc(s2, e5)) return t2;
      let i3 = Uc(e5, n3.dimensions), a3 = Y(n3.impact) === o2;
      return r2(o2, c2, a3, a3, i3, l2);
    }
    if (n3.phase === `DROP_ANIMATING`) {
      let e5 = n3.completed;
      if (!Hc(s2, e5.critical)) return t2;
      let i3 = Uc(e5.critical, n3.dimensions);
      return r2(o2, c2, ic(e5.result) === o2, Y(e5.impact) === o2, i3, l2);
    }
    if (n3.phase === `IDLE` && n3.completed && !n3.shouldFlush) {
      let r3 = n3.completed;
      if (!Hc(s2, r3.critical)) return t2;
      let i3 = Y(r3.impact) === o2, a3 = !!(r3.impact.at && r3.impact.at.type === `COMBINE`), c3 = r3.critical.droppable.id === o2;
      return i3 ? a3 ? e4 : t2 : c3 ? e4 : t2;
    }
    return t2;
  };
}, { updateViewportMaxScroll: Oi }, (e4, t2, n2) => ({ ...Vc(n2), ...e4, ...t2 }), { context: Ao, areStatePropsEqual: rc })(Rc);
n();
var Gc = class e2 extends d {
  constructor(t2) {
    super(t2), this.state = { count: t2.data.count, editLines: [], originalData: JSON.stringify(t2.data), ...e2.widgetData2State(t2.data), open: false, showEditDialog: null };
  }
  static getDerivedStateFromProps(t2, n2) {
    return JSON.stringify(t2.data) === n2.originalData ? null : { originalData: JSON.stringify(t2.data), ...e2.widgetData2State(t2.data) };
  }
  static widgetData2State(e4) {
    let t2 = [];
    for (let n2 = 1; n2 <= e4.count; n2++) t2.push({ view: e4[`view${n2}`], link: e4[`link${n2}`], linkSelf: e4[`linkSelf${n2}`], linkHidden: e4[`linkHidden${n2}`], icon: e4[`icon${n2}`], iconSmall: e4[`iconSmall${n2}`], iconEnabled: e4[`iconEnabled${n2}`], iconEnabledSmall: e4[`iconEnabledSmall${n2}`], color: e4[`color${n2}`], colorEnabled: e4[`colorEnabled${n2}`], title: e4[`title${n2}`], titleEnabled: e4[`titleEnabled${n2}`], pinCode: e4[`pinCode${n2}`], oidPinCode: e4[`oid-pinCode${n2}`], disabled: e4[`disabled${n2}`], hide: e4[`hide${n2}`] });
    return { editLines: t2, count: e4.count };
  }
  static state2WidgetData(e4, t2) {
    let n2 = { ...t2 };
    for (let t3 = 1; t3 <= e4.count; t3++) {
      let r2 = e4.editLines[t3 - 1];
      n2[`view${t3}`] = r2.view, n2[`link${t3}`] = r2.link, n2[`linkSelf${t3}`] = r2.linkSelf, n2[`linkHidden${t3}`] = r2.linkHidden, n2[`icon${t3}`] = r2.icon, n2[`iconSmall${t3}`] = r2.iconSmall, n2[`iconEnabled${t3}`] = r2.iconEnabled, n2[`iconEnabledSmall${t3}`] = r2.iconEnabledSmall, n2[`color${t3}`] = r2.color, n2[`colorEnabled${t3}`] = r2.colorEnabled, n2[`title${t3}`] = r2.title, n2[`titleEnabled${t3}`] = r2.titleEnabled, n2[`pinCode${t3}`] = r2.pinCode, n2[`oid-pinCode${t3}`] = r2.oidPinCode, n2[`disabled${t3}`] = r2.disabled, n2[`hide${t3}`] = r2.hide;
    }
    return n2;
  }
  isSelected() {
    return false;
  }
  renderButton(e4) {
    var _a2, _b, _c2, _d, _e2, _f, _g, _h, _i2;
    let t2 = this.props.views[e4.view], n2 = this.isSelected() ? e4.colorEnabled || e4.color || ((_a2 = t2 == null ? void 0 : t2.settings) == null ? void 0 : _a2.navigationSelectedColor) : void 0;
    n2 || (n2 = e4.color || ((_b = t2 == null ? void 0 : t2.settings) == null ? void 0 : _b.navigationColor) || ((_c2 = t2 == null ? void 0 : t2.settings) == null ? void 0 : _c2.navigationBarColor));
    let r2 = this.isSelected() ? e4.titleEnabled : ``;
    r2 || (r2 = e4.title || ((_d = t2 == null ? void 0 : t2.settings) == null ? void 0 : _d.navigationTitle) || ((_e2 = t2 == null ? void 0 : t2.settings) == null ? void 0 : _e2.navigationBarText) || ``), r2 || (r2 = e4.view || ``);
    let i2 = ``, a2 = null;
    return this.isSelected() && (i2 = e4.iconEnabled || e4.iconEnabledSmall), i2 || (i2 = e4.icon || e4.iconSmall), i2 || (i2 = e4.view ? ((_f = t2 == null ? void 0 : t2.settings) == null ? void 0 : _f.navigationIcon) || ((_g = t2 == null ? void 0 : t2.settings) == null ? void 0 : _g.navigationImage) || ((_h = t2 == null ? void 0 : t2.settings) == null ? void 0 : _h.navigationBarIcon) || ((_i2 = t2 == null ? void 0 : t2.settings) == null ? void 0 : _i2.navigationBarImage) : ``), i2 && (a2 = O(le, { src: i2, style: { width: 24, height: 24 } })), O(y, { variant: `contained`, style: { color: n2, whiteSpace: `nowrap` }, startIcon: a2, children: r2 });
  }
  renderLine(e4) {
    return O(pc, { draggableId: e4.toString(), index: e4, children: (t2, n2) => k(D, { ref: t2.innerRef, ...t2.draggableProps, style: { ...t2.draggableProps.style, backgroundColor: n2.isDragging ? `#334455` : void 0 }, children: [O(A, { children: O(`div`, { ...t2.dragHandleProps, style: { display: `inline-block`, width: 24, marginRight: 8 }, children: O(_e, {}) }) }), O(A, { children: O(v, { variant: `standard`, value: this.state.editLines[e4].title, onChange: (t3) => {
      let n3 = [...this.state.editLines];
      n3[e4].title = t3.target.value, this.setState({ editLines: n3 });
    } }) }), O(A, { children: O(v, { variant: `standard`, value: this.state.editLines[e4].titleEnabled, onChange: (t3) => {
      let n3 = [...this.state.editLines];
      n3[e4].titleEnabled = t3.target.value, this.setState({ editLines: n3 });
    } }) }), O(A, { children: O(v, { variant: `standard`, value: this.state.editLines[e4].pinCode, onChange: (t3) => {
      let n3 = [...this.state.editLines];
      n3[e4].pinCode = t3.target.value, this.setState({ editLines: n3 });
    } }) }), O(A, { children: this.renderButton(this.state.editLines[e4]) }), O(A, { children: O(x, { onClick: () => this.setState({ editLines: this.state.editLines.filter((t3, n3) => n3 !== e4) }), children: O(ce, {}) }) })] }, e4) }, e4);
  }
  renderDialog() {
    return this.state.open ? k(E, { maxWidth: `xl`, fullWidth: true, open: true, onClose: () => {
      this.setState({ open: false });
    }, children: [O(T, { children: j.t(`Re-order`) }), O(S, { children: O(re, { component: ee, children: k(ne, { size: `small`, children: [O(he, { children: k(D, { children: [O(A, {}), O(A, { children: j.t(`title`) }), O(A, { children: j.t(`titleEnabled`) }), O(A, { children: j.t(`pincode`) }), O(A, {}), O(A, {})] }) }), O(Us, { onDragEnd: (e4) => {
      let t2 = [...this.state.editLines], [n2] = t2.splice(e4.source.index, 1);
      t2.splice(e4.destination.index, 0, n2), this.setState({ editLines: t2 });
    }, children: O(Wc, { droppableId: `items`, type: `ROW`, children: (e4, t2) => k(me, { ref: e4.innerRef, ...e4.droppableProps, style: { backgroundColor: t2.isDraggingOver ? `#112233` : void 0 }, children: [this.state.editLines.map((e5, t3) => this.renderLine(t3)), e4.placeholder] }) }) })] }) }) }), k(b, { children: [O(y, { variant: `contained`, disabled: this.state.originalData === JSON.stringify(e2.state2WidgetData(this.state, this.props.data)), onClick: () => {
      this.setState({ open: false }), this.props.setData(e2.state2WidgetData(this.state, this.props.data));
    }, color: `primary`, startIcon: O(ie, {}), children: j.t(`Apply`) }), O(y, { variant: `contained`, onClick: () => this.setState({ open: false }), color: `grey`, startIcon: O(pe, {}), children: j.t(`Close`) })] })] }) : null;
  }
  render() {
    return k(`div`, { children: [O(y, { disabled: this.props.selectedWidgets.length > 1, variant: `contained`, onClick: () => this.setState({ open: true }), children: j.t(`Re-order`) }), this.renderDialog()] });
  }
};
n();
var Kc = class e3 extends j {
  constructor(e4) {
    super(e4), this.state = { ...this.state, dialogPin: null, menuTarget: null, invalidPin: false, lockPinInput: `` };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Navigate`, visSet: `vis-2-widgets-nils-fork`, visName: `Navigate`, visWidgetLabel: `navigate`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `variant`, label: `variant`, type: `select`, options: [`text`, `outlined`, `contained`] }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard` }, { name: `title`, label: `title`, type: `text` }, { name: `icon`, type: `image`, label: `icon`, hidden: `!!data["iconSmall" + index]` }, { name: `iconSmall`, type: `icon64`, label: `small_icon`, hidden: `!!data["icon" + index]` }, { name: `showCurrentView`, type: `checkbox`, label: `show_current_view`, noBinding: false, hidden: (e4) => {
      let t2 = e4;
      for (let e5 = 1; e5 <= t2.count; e5++) if (t2[`view${e5}`]) return false;
      return true;
    } }, { name: `pinCodeReturnButton`, type: `select`, options: [`submit`, `backspace`], default: `submit`, label: `pincode_return_button`, hidden: (e4) => {
      let t2 = e4;
      for (let e5 = 1; e5 <= t2.count; e5++) if (t2[`oid-pinCode${e5}`] || t2[`pinCode${e5}`]) return false;
      return true;
    } }, { name: `count`, type: `number`, default: 1, label: `count` }, { label: ``, name: `_settings`, type: `custom`, component: (e4, t2, n2, r2) => O(Gc, { data: t2, setData: (e5) => {
      n2(e5);
    }, Editor: r2.Editor, views: r2.context.views, selectedWidgets: r2.selectedWidgets }) }] }, { name: `item`, label: `group_item`, indexFrom: 1, indexTo: `count`, fields: [{ name: `view`, type: `views`, label: `view`, hidden: `!!data["link" + index]` }, { name: `link`, type: `text`, label: `URL`, hidden: `!!data["view" + index]` }, { name: `title`, type: `text`, label: `title`, noButton: true }, { name: `titleEnabled`, type: `text`, label: `titleEnabled`, noButton: true, hidden: `!data["view" + index]` }, { name: `icon`, type: `image`, label: `icon`, hidden: `!!data["iconSmall" + index] || (!data["view" + index] && !data["link" + index])` }, { name: `iconSmall`, type: `icon64`, label: `small_icon`, hidden: `!!data["icon" + index] || (!data["view" + index] && !data["link" + index])` }, { name: `iconEnabled`, type: `image`, label: `icon_active`, hidden: `!!data["iconEnabledSmall" + index] || !data["view" + index]` }, { name: `iconEnabledSmall`, type: `icon64`, label: `small_icon_active`, hidden: `!!data["iconEnabled" + index] || !data["view" + index]` }, { name: `color`, type: `color`, label: `color`, hidden: `!data["view" + index] && !data["link" + index]` }, { name: `colorEnabled`, type: `color`, label: `color_active`, hidden: `!data["view" + index]` }, { name: `hide`, type: `checkbox`, label: `hide`, tooltip: `hide_tooltip`, noBinding: false, hidden: `!data["view" + index] && !data["link" + index]` }, { name: `disabled`, type: `checkbox`, label: `disabled`, noBinding: false, hidden: `!data["view" + index] && !data["link" + index]` }, { name: `pinCode`, label: `pincode`, onChange: (e4, t2, n2, r2, i2) => {
      var _a2;
      let a2 = t2;
      return ((_a2 = a2[`pinCode${i2}`]) == null ? void 0 : _a2.match(/[^0-9]/g)) && (a2[`pinCode${i2}`] = a2[`pinCode${i2}`].replace(/[^0-9]/g, ``), n2(a2)), Promise.resolve();
    }, hidden: `!!data["oid-pinCode" + index] || (!data["view" + index] && !data["link" + index])` }, { name: `oid-pinCode`, type: `id`, label: `pincode_oid`, hidden: `!!data["pinCode" + index] || (!data["view" + index] && !data["link" + index])` }] }], visDefaultStyle: { width: `100%`, height: 72, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_navigate.png` };
  }
  getWidgetInfo() {
    return e3.getWidgetInfo();
  }
  isSelected(e4) {
    return this.state.rxData[`view${e4}`] === this.props.view;
  }
  getStateIcon(e4) {
    var _a2, _b, _c2, _d, _e2, _f, _g, _h;
    let t2 = ``, n2 = null;
    return this.isSelected(e4) && (t2 = this.state.rxData[`iconEnabled${e4}`] || this.state.rxData[`iconEnabledSmall${e4}`]), t2 || (t2 = this.state.rxData[`icon${e4}`] || this.state.rxData[`iconSmall${e4}`]), t2 || (t2 = this.state.rxData[`view${e4}`] ? ((_b = (_a2 = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _a2.settings) == null ? void 0 : _b.navigationIcon) || ((_d = (_c2 = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _c2.settings) == null ? void 0 : _d.navigationImage) || ((_f = (_e2 = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _e2.settings) == null ? void 0 : _f.navigationBarIcon) || ((_h = (_g = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _g.settings) == null ? void 0 : _h.navigationBarImage) : ``), t2 && (n2 = O(le, { src: t2, style: { width: 24, height: 24 } })), n2;
  }
  getColor(e4) {
    var _a2, _b, _c2, _d, _e2, _f;
    let t2 = this.isSelected(e4) ? this.state.rxData[`colorEnabled${e4}`] || this.state.rxData[`color${e4}`] || ((_b = (_a2 = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _a2.settings) == null ? void 0 : _b.navigationSelectedColor) : void 0;
    return t2 || (t2 = this.state.rxData[`color${e4}`] || ((_d = (_c2 = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _c2.settings) == null ? void 0 : _d.navigationColor) || ((_f = (_e2 = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _e2.settings) == null ? void 0 : _f.navigationBarColor)), t2;
  }
  renderUnlockDialog() {
    return this.state.dialogPin ? O(ge, { pinCode: this.getPinCode(this.state.dialogPin), pinCodeReturnButton: this.state.rxData.pinCodeReturnButton === `backspace` ? `backspace` : `submit`, onClose: (e4) => {
      e4 && this.onItemClick(this.state.dialogPin, true), this.setState({ dialogPin: null });
    } }) : null;
  }
  getTitle(e4) {
    var _a2, _b, _c2, _d;
    let t2 = this.isSelected(e4) ? this.state.rxData[`titleEnabled${e4}`] : ``;
    return t2 || (t2 = this.state.rxData[`title${e4}`] || ((_b = (_a2 = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _a2.settings) == null ? void 0 : _b.navigationTitle) || ((_d = (_c2 = this.props.context.views[this.state.rxData[`view${e4}`]]) == null ? void 0 : _c2.settings) == null ? void 0 : _d.navigationBarText) || ``), t2 || (t2 = this.state.rxData[`view${e4}`] || ``), t2;
  }
  renderMenu() {
    var _a2, _b, _c2, _d;
    if (!this.state.menuTarget) return null;
    let e4 = [];
    for (let t3 = 1; t3 <= this.state.rxData.count; t3++) e4[t3] = this.getStateIcon(t3);
    let t2 = !!e4.find((e5) => e5), n2 = [];
    for (let r2 = 1; r2 <= this.state.rxData.count; r2++) if ((this.state.rxData[`link${r2}`] || this.state.rxData[`view${r2}`]) && this.state.rxData[`hide${r2}`] !== true && this.state.rxData[`hide${r2}`] !== `true`) {
      let i2 = this.isSelected(r2) ? this.state.rxData[`titleEnabled${r2}`] : ``;
      i2 || (i2 = this.state.rxData[`title${r2}`] || ((_b = (_a2 = this.props.context.views[this.state.rxData[`view${r2}`]]) == null ? void 0 : _a2.settings) == null ? void 0 : _b.navigationTitle) || ((_d = (_c2 = this.props.context.views[this.state.rxData[`view${r2}`]]) == null ? void 0 : _c2.settings) == null ? void 0 : _d.navigationBarText) || ``), i2 || (i2 = this.state.rxData[`view${r2}`] || ``), n2.push(k(te, { style: { color: this.getColor(r2) }, selected: this.isSelected(r2), onClick: () => this.setState({ menuTarget: null }, () => this.onItemClick(r2)), disabled: this.state.rxData[`disabled${r2}`] === true || this.state.rxData[`disabled${r2}`] === `true`, children: [t2 ? O(w, { children: O(le, { src: e4[r2], style: { height: 24, width: `auto` } }) }) : null, O(de, { children: i2 })] }, r2));
    }
    return O(C, { open: true, anchorEl: this.state.menuTarget, onClose: () => this.setState({ menuTarget: null }), children: n2 });
  }
  getPinCode(e4) {
    return this.state.rxData[`oid-pinCode${e4}`] ? this.getPropertyValue(`oid-pinCode${e4}`) : this.state.rxData[`pinCode${e4}`];
  }
  onItemClick(e4, t2) {
    if (this.state.rxData[`disabled${e4}`] === true || this.state.rxData[`disabled${e4}`] === `true`) return;
    if (!t2 && this.getPinCode(e4)) {
      this.setState({ dialogPin: e4 });
      return;
    }
    let n2 = this.state.rxData[`link${e4}`], r2 = this.state.rxData[`linkSelf${e4}`] === true || this.state.rxData[`linkSelf${e4}`] === `true`, i2 = this.state.rxData[`linkHidden${e4}`] === true || this.state.rxData[`linkHidden${e4}`] === `true`, a2 = this.state.rxData[`view${e4}`];
    if (n2) {
      if (r2) window.location.href = n2;
      else if (i2) try {
        fetch(n2).catch((e5) => console.warn(`Cannot call "${n2}": ${e5}`));
      } catch (e5) {
        console.warn(`Cannot call "${n2}": ${e5.toString()}`);
      }
      else window.open(n2, `_blank`);
    } else a2 && this.props.context.changeView(a2, a2);
  }
  onClick(e4) {
    e4.stopPropagation();
    let t2 = 0, n2 = null;
    for (let e5 = 1; e5 <= this.state.rxData.count; e5++) (this.state.rxData[`link${e5}`] || this.state.rxData[`view${e5}`]) && this.state.rxData[`hide${e5}`] !== true && this.state.rxData[`hide${e5}`] !== `true` && (t2++, n2 = e5);
    t2 > 1 ? this.setState({ menuTarget: e4.target }) : n2 !== null && this.onItemClick(n2);
  }
  renderWidgetBody(e4) {
    var _a2;
    super.renderWidgetBody(e4);
    let t2 = ``, n2 = null, r2 = ``;
    if (this.state.rxData.showCurrentView) {
      for (let e5 = 1; e5 <= this.state.rxData.count; e5++) if (this.props.view === this.state.rxData[`view${e5}`]) {
        t2 = this.getTitle(e5) || ``, r2 = this.getColor(e5) || ``, n2 = this.getStateIcon(e5);
        break;
      }
    }
    t2 || (t2 = this.state.rxData.title || this.state.rxData.widgetTitle || ``), r2 || (r2 = ((_a2 = this.state.rxStyle) == null ? void 0 : _a2.color) || void 0), n2 || (n2 = this.state.rxData.icon || this.state.rxData.iconSmall ? O(le, { src: this.state.rxData.icon || this.state.rxData.iconSmall, style: { height: 24, width: `auto` } }) : null);
    let i2 = k(ae, { children: [this.renderUnlockDialog(), this.renderMenu(), O(y, { variant: this.state.rxData.variant, onClick: (e5) => this.onClick(e5), startIcon: n2, style: { color: r2 }, children: t2 })] });
    return this.wrapContent(i2);
  }
};
export {
  Kc as default
};
