let P, __, $, s, A_, Q;
let __tla = (async () => {
  const f = "__mf_init____mf__virtual/__mfe_internal__vis2nilsForkWidgets__mf_v__runtimeInit__mf_v__.js__";
  let o = globalThis[f];
  if (!o) {
    let _, m;
    const n = new Promise((t, i) => {
      _ = t, m = i;
    });
    o = globalThis[f] = {
      initPromise: n,
      initResolve: _,
      initReject: m
    }, typeof window > "u" && _({
      loadRemote: function() {
        return Promise.resolve(void 0);
      },
      loadShare: function() {
        return Promise.resolve(void 0);
      }
    });
  }
  const r = o.initPromise, a = r.then((_) => _.loadShare("@iobroker/adapter-react-v5", {
    customShareInfo: {
      shareConfig: {
        singleton: true,
        strictVersion: false,
        requiredVersion: "*"
      }
    }
  })), e = await a.then((_) => typeof _ == "function" ? _() : _);
  e.__esModule ? e.default : e.default;
  let l, c, I, d, S, g, u, C, p, T, D, b, h, R, v, x, E, O, M, w, F, y, A, j, B, L, V, N, U, k, G, W, q, z, H, K, X, J, Y, Z, e_, o_, m_, f_, n_, t_, i_, r_, a_, l_, c_, s_, I_, d_, S_, g_, u_, C_, p_, T_, D_, b_, h_, R_, P_, v_, x_, E_, O_, M_, w_, F_, y_, j_, B_, L_, V_, N_, U_, k_, G_, W_, q_, z_, H_, K_, X_, J_, Q_, Y_, Z_, $_, _e, ee, oe;
  ({ Theme: l, GenericApp: c, I18n: s, printPrompt: I, ColorPicker: d, ComplexCron: S, copy: g, CustomModal: u, FileBrowser: C, FileBrowserClass: p, EXTENSIONS: T, FileViewer: D, FileViewerClass: b, getSystemIcon: h, getSelectIdIcon: R, Icon: P, IconPicker: v, IconSelector: x, Image: E, DeviceTypeSelector: O, DeviceTypeIcon: M, STATES_NAME_ICONS: w, extendDeviceTypeTranslation: F, Loader: y, Logo: A, MDUtils: j, ObjectBrowserClass: B, ObjectBrowser: L, getSelectIdIconFromObjects: V, ITEM_IMAGES: N, InfoBox: U, Router: k, SaveCloseButtons: G, Schedule: W, SelectWithIcon: q, TabContainer: z, TabContent: H, TabHeader: K, TableResize: X, TextWithIcon: J, ToggleThemeMenu: Q, TreeTable: Y, UploadImage: Z, Utils: $, withWidth: __, cron2state: e_, SimpleCron: o_, convertCronToText: m_, LoaderVendor: f_, LoaderPT: n_, LoaderMV: t_, IconAdapter: i_, IconAlias: r_, IconButtonImage: a_, IconChannel: l_, IconClearFilter: c_, IconClosed: s_, IconCopy: I_, IconDevice: d_, IconDocument: S_, IconDocumentReadOnly: g_, IconExpert: u_, IconFx: C_, IconInstance: p_, IconLogout: T_, IconNoIcon: D_, IconOpen: b_, IconState: h_, IconVacuum: R_, DialogComplexCron: P_, ComplexCronDialog: v_, DialogConfirm: x_, Confirm: E_, DialogCron: O_, Cron: M_, DialogError: w_, Error: F_, DialogMessage: y_, Message: A_, DialogSelectID: j_, SelectID: B_, DialogSelectFile: L_, SelectFile: V_, DialogSimpleCron: N_, SimpleCronDialog: U_, DialogTextInput: k_, TextInput: G_, Connection: W_, PROGRESS: q_, ERRORS: z_, PERMISSION_ERROR: H_, AdminConnection: K_, dictionary: X_, LegacyConnection: J_, pattern2RegEx: Q_, getAttrInObject: Y_, setAttrInObject: Z_, iobUriToString: $_, iobUriParse: _e, iobUriRead: ee, moduleFederationShared: oe } = e);
})();
export {
  P as _,
  __tla,
  __ as a,
  $ as b,
  s as c,
  A_ as d,
  Q as e
};
