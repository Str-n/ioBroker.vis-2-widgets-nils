import { B as e } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { ft as t, pt as n, z as r } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { n as i, t as a } from "./WindowClosed-Di23zk5M.js";
e();
var o = { cardContent: { flex: 1, display: `flex`, justifyContent: `center`, alignItems: `center`, width: `100%`, overflow: `visible`, height: `100%` }, fabWindowIcon: { position: `relative`, zIndex: 2, width: `100%`, height: `100%`, color: `rgba(255, 255, 255, 0.92)`, transition: `transform 0.2s ease, color 0.2s ease` }, fabWindow: { position: `relative`, zIndex: 1, width: `92%`, height: `92%`, overflow: `visible`, transition: `transform 0.2s ease` }, fabBlind: { position: `absolute`, zIndex: 1, top: `31%`, left: `27%`, width: `46%`, maxHeight: `42%`, background: `repeating-linear-gradient(to bottom, rgba(222, 232, 239, 0.9) 0 3px, rgba(194, 210, 221, 0.9) 3px 4px)`, boxShadow: `0 0 0 1px rgba(30, 49, 61, 0.25)`, transition: `height 0.25s ease` }, fabWindowState: { position: `absolute`, zIndex: 2, top: 3, right: 3, display: `flex`, alignItems: `center`, justifyContent: `center`, width: 11, height: 11, border: `1px solid rgba(0, 0, 0, 0.3)`, borderRadius: `50%`, color: `#10202b`, fontSize: `0.45rem`, fontWeight: 800, lineHeight: 1 } }, s = class e2 extends i {
  lastRxData;
  updateTimeout;
  constructor(e3) {
    super(e3), this.state = { ...this.state, objects: [] };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Blinds`, visSet: `vis-2-widgets-nils-fork`, visName: `Blinds`, visWidgetLabel: `blinds`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox`, hidden: `!!data.externalDialog` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard` }, { name: `sashCount`, type: `number`, default: 1, label: `sash_count` }, { name: `ratio`, type: `slider`, min: 0.1, max: 3, step: 0.1, label: `window_ratio`, default: 1 }, { name: `borderWidth`, type: `slider`, min: 0, max: 100, step: 0.1, label: `border_width`, default: 0.1 }, { name: `oid`, type: `id`, default: ``, label: `blinds_position_oid`, noInit: true, onChange: async (e3, t2, n2, r2) => {
      if (t2[e3.name]) {
        let i2 = await r2.getObject(t2[e3.name]);
        if (i2 == null ? void 0 : i2.common) {
          let e4 = false, a2 = i2._id.split(`.`);
          a2.pop();
          let o2 = await r2.getObjectViewSystem(`state`, `${a2.join(`.`)}.`, `${a2.join(`.`)}.\u9999`);
          o2 && Object.values(o2).forEach((n3) => {
            var _a, _b;
            ((_b = (_a = n3 == null ? void 0 : n3.common) == null ? void 0 : _a.role) == null ? void 0 : _b.includes(`stop`)) && (t2.blinds_stop_oid = n3._id, e4 = true);
          }), e4 && n2(t2);
        }
      }
    } }, { name: `oid_stop`, type: `id`, default: ``, label: `blinds_stop_oid`, noInit: true, hidden: (e3) => !e3.oid }, { label: `show_value`, type: `checkbox`, name: `showValue`, hidden: (e3) => !e3.oid, default: true }, { label: `min_position`, type: `number`, hidden: (e3) => !e3.oid, name: `min` }, { label: `max_position`, type: `number`, hidden: (e3) => !e3.oid, name: `max` }, { label: `invert_position`, type: `checkbox`, hidden: (e3) => !e3.oid, name: `invert` }, { name: `externalDialog`, label: `use_as_dialog`, type: `checkbox`, tooltip: `use_as_dialog_tooltip` }] }, { name: `sashes`, label: `sash`, indexFrom: 1, indexTo: `sashCount`, fields: [{ name: `slideSensor_oid`, type: `id`, label: `slide_sensor_oid`, noInit: true }, { name: `slideHandle_oid`, type: `id`, label: `handle_sensor_oid`, noInit: true }, { name: `slideType`, type: `select`, label: `sash_type`, options: [{ value: ``, label: `sash_none` }, { value: `left`, label: `left` }, { value: `right`, label: `right` }, { value: `top`, label: `top` }, { value: `bottom`, label: `bottom` }] }, { name: `slideRatio`, type: `slider`, label: `slide_ratio`, default: 1, min: 0.1, max: 4, step: 0.1, hidden: (e3) => e3.sashCount < 2 }, { name: `slidePos_oid`, type: `id`, default: ``, label: `blinds_position_oid`, hidden: (e3) => !!e3.oid, noInit: true, onChange: async (e3, t2, n2, r2) => {
      if (t2[e3.name]) {
        let i2 = await r2.getObject(t2[e3.name]), a2 = e3.name.match(/(\d+)$/)[1];
        if (i2 == null ? void 0 : i2.common) {
          let e4 = false, o2 = i2._id.split(`.`);
          o2.pop();
          let s2 = await r2.getObjectViewSystem(`state`, `${o2.join(`.`)}.`, `${o2.join(`.`)}.\u9999`);
          s2 && Object.values(s2).forEach((n3) => {
            var _a, _b;
            ((_b = (_a = n3 == null ? void 0 : n3.common) == null ? void 0 : _a.role) == null ? void 0 : _b.includes(`stop`)) && (t2[`slideStop_oid${a2}`] = n3._id, e4 = true);
          }), e4 && n2(t2);
        }
      }
    } }, { name: `slideStop_oid`, type: `id`, default: ``, label: `blinds_stop_oid`, noInit: true, hidden: (e3, t2) => !!e3.oid || !e3[`slidePos_oid${t2}`] }, { label: `min_position`, type: `number`, hidden: (e3, t2) => !!e3.oid || !e3[`slidePos_oid${t2}`], name: `slideMin` }, { label: `max_position`, type: `number`, hidden: (e3, t2) => !!e3.oid || !e3[`slidePos_oid${t2}`], name: `slideMax` }, { label: `invert_position`, type: `checkbox`, hidden: (e3, t2) => !!e3.oid || !e3[`slidePos_oid${t2}`], name: `slideInvert` }] }], visDefaultStyle: { width: `40px`, height: `40px`, position: `absolute` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_blinds.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  getWindowState() {
    let e3 = false;
    for (let t2 = 1; t2 <= (this.state.rxData.sashCount || 1); t2++) {
      let n2 = this.state.rxData[`slideHandle_oid${t2}`], r2 = this.state.rxData[`slideSensor_oid${t2}`], i2 = n2 || r2;
      if (!i2) continue;
      let a2 = this.state.values[`${i2}.val`];
      if (a2 != null) {
        if (n2 && (a2 === 2 || a2 === `2` ? a2 = 1 : (a2 === 1 || a2 === `1`) && (a2 = 2)), a2 === 1 || a2 === 2 || a2 === `1` || a2 === `2` || a2 === true || a2 === `true` || a2 === `open` || a2 === `opened` || a2 === `tilt` || a2 === `tilted`) return `open`;
        (a2 === 0 || a2 === `0` || a2 === false || a2 === `false` || a2 === `close` || a2 === `closed`) && (e3 = true);
      }
    }
    return e3 ? `closed` : `unknown`;
  }
  renderWindowFab(e3, i2) {
    let s2 = this.getWindowState(), c = s2 === `open`, l = e3 === null ? null : Math.max(0, Math.min(100, 100 - e3)), u = s2 === `unknown` ? `?` : c ? `O` : `C`, d = [this.state.rxData.widgetTitle || `Blinds`, e3 === null ? null : `${e3}% position`, s2 === `unknown` ? null : `window ${c ? `open` : `closed`}`].filter(Boolean).join(`, `);
    return n(r, { size: `small`, color: `primary`, "aria-label": d, onClick: i2 ? (e4) => {
      e4.preventDefault(), e4.stopPropagation(), this.lastClick = Date.now(), this.setState({ showBlindsDialog: true });
    } : void 0, sx: { width: `100%`, height: `100%`, minWidth: 0, minHeight: 0, padding: 0, position: `relative` }, children: [n(`div`, { style: { ...o.fabWindow, ...c ? { transform: `perspective(48px) rotateY(-20deg)` } : void 0 }, children: [l === null ? null : t(`div`, { style: { ...o.fabBlind, height: `${l * 0.42}%` } }), t(a, { style: { ...o.fabWindowIcon, ...c ? { color: `#b9f2ce` } : void 0 } })] }), s2 === `unknown` ? null : t(`span`, { "aria-hidden": `true`, style: { ...o.fabWindowState, background: c ? `#7be0a2` : `#dce7ed` }, children: u })] });
  }
  async propertiesUpdate() {
    var _a;
    let e3 = JSON.stringify(this.state.rxData);
    if (this.lastRxData === e3) return;
    this.lastRxData = e3;
    let t2 = [], n2 = [];
    for (let e4 = 1; e4 <= this.state.rxData.sashCount; e4++) this.state.rxData[`slidePos_oid${e4}`] && this.state.rxData[`slidePos_oid${e4}`] !== `nothing_selected` && n2.push(this.state.rxData[`slidePos_oid${e4}`]);
    this.state.rxData.oid && this.state.rxData.oid !== `nothing_selected` && n2.push(this.state.rxData.oid);
    let r2 = n2.length ? await this.props.context.socket.getObjectsById(n2) : {}, i2 = ((_a = r2[this.state.rxData.oid] || null) == null ? void 0 : _a.common) || {};
    for (let e4 = 1; e4 <= this.state.rxData.sashCount; e4++) if (this.state.rxData[`slidePos_oid${e4}`] && this.state.rxData[`slidePos_oid${e4}`] !== `nothing_selected`) {
      let n3 = r2[this.state.rxData[`slidePos_oid${e4}`]];
      t2[e4] = { common: (n3 == null ? void 0 : n3.common) || {}, _id: this.state.rxData[`slidePos_oid${e4}`], widgetType: `blinds` };
    }
    (JSON.stringify(t2) !== JSON.stringify(this.state.objects) || JSON.stringify(i2) !== JSON.stringify(this.state.main)) && this.setState({ objects: t2, main: i2 });
  }
  async componentDidMount() {
    super.componentDidMount(), await this.propertiesUpdate();
  }
  async onRxDataChanged() {
    await this.propertiesUpdate();
  }
  onCommand(e3) {
    let t2 = super.onCommand(e3);
    if (t2 === false) {
      if (e3 === `openDialog`) return this.setState({ showBlindsDialog: true }), true;
      if (e3 === `closeDialog`) return this.setState({ showBlindsDialog: false }), true;
    }
    return t2;
  }
  renderWidgetBody(e3) {
    super.renderWidgetBody(e3), e3.style.overflow = `visible`, e3.style.overflowX = `visible`, e3.style.overflowY = `visible`;
    let t2 = JSON.stringify(this.state.rxData);
    this.lastRxData !== t2 && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
      this.updateTimeout = void 0, await this.propertiesUpdate();
    }, 50)));
    let r2 = this.getMinMaxPosition(0), i2 = r2.hasControl ? Math.round(r2.shutterPos) : null, a2 = n(`div`, { style: o.cardContent, children: [this.renderBlindsDialog(), this.renderWindowFab(i2, r2.hasControl)] });
    return this.state.rxData.externalDialog && !this.props.editMode ? this.renderBlindsDialog() : this.state.rxData.noCard || e3.widget.usedInWidget ? a2 : this.wrapContent(a2, this.state.rxData.showValue && r2.hasControl ? n(`span`, { children: [r2.shutterPos, `%`] }) : null);
  }
};
export {
  s as default
};
