var e = [`history`, `sql`, `influxdb`], t = class extends window.visRxWidget {
  getPropertyValue = (e2) => this.state.values[`${this.state.rxData[e2]}.val`];
  static getI18nPrefix() {
    return `vis_2_widgets_nils_`;
  }
  static getHistoryInstance(t2, n) {
    var _a;
    if ((_a = t2 == null ? void 0 : t2.common) == null ? void 0 : _a.custom) {
      if (t2.common.custom[n]) return n;
      for (let n2 in t2.common.custom) if (e.includes(n2.split(`.`)[0])) return n2;
    }
    return null;
  }
  async getParentObject(e2) {
    let t2 = e2.split(`.`);
    t2.pop();
    let n = t2.join(`.`);
    return await this.props.context.socket.getObject(n) ?? null;
  }
  static getObjectIcon(e2, t2, n) {
    n || (n = `../..`);
    let r = ``, i = e2 == null ? void 0 : e2.common;
    if (i) {
      let a = i.icon;
      if (a) {
        if (a.startsWith(`data:image/`)) r = a;
        else if (a.includes(`.`)) {
          let o;
          e2.type === `instance` || e2.type === `adapter` ? r = `${n}/adapter/${i.name}/${a}` : t2 && t2.startsWith(`system.adapter.`) ? (o = t2.split(`.`, 3), a[0] === `/` ? o[2] += a : o[2] += `/${a}`, r = `${n}/adapter/${o[2]}`) : (o = t2.split(`.`, 2), a[0] === `/` ? o[0] += a : o[0] += `/${a}`, r = `${n}/adapter/${o[0]}`);
        } else return null;
      }
    }
    return r || null;
  }
};
export {
  t
};
