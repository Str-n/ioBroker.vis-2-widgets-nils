import { j as t, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { _ as y, u as S, m as w, v as D, w as R, e as f, c as g, a as G, b as I, d as V, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { A as k, B as T, C as B, D as E, E as P, a as Z, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CpkBFb5h.js";
import { _ as U, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CxgaxSjv.js";
import { G as c } from "./Generic-DDdmRdK-.js";
import { __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
let A, _, Q, x, $, p, Y, M;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  $ = function(l) {
    return t.jsxs("svg", {
      viewBox: "0 0 360 360",
      xmlns: "http://www.w3.org/2000/svg",
      style: l.style,
      children: [
        t.jsx("path", {
          fill: "currentColor",
          d: "M 330.46 100.64 Q 351.46 139.72 350.97 184.28 Q 350.96 185.00 350.24 185.00 L 347.50 185.00 Q 347.00 185.00 347.00 185.50 L 347.00 193.37 Q 347.00 194.00 347.63 194.00 L 349.80 194.00 Q 350.47 194.00 350.42 194.67 C 344.01 276.68 279.41 342.29 198.02 350.15 C 102.00 359.42 18.58 287.54 12.39 191.62 Q 12.35 191.00 12.97 191.00 L 14.47 191.00 Q 15.01 191.00 15.01 190.46 L 15.00 183.62 Q 14.99 183.00 14.37 183.00 L 12.53 183.00 Q 12.09 183.00 12.09 182.56 C 11.80 95.69 76.68 22.25 163.51 13.11 C 223.60 6.78 281.26 32.21 317.43 80.29 A 0.42 0.42 0.0 0 0 318.16 80.17 L 323.63 63.55 A 0.53 0.52 17.9 0 1 324.29 63.22 L 328.97 64.78 Q 329.56 64.98 329.37 65.57 L 322.36 86.46 Q 322.19 86.97 322.48 87.43 L 326.10 93.06 Q 326.39 93.51 326.93 93.58 L 348.86 96.52 Q 349.39 96.59 349.32 97.12 L 348.69 101.93 Q 348.61 102.54 348.01 102.46 L 330.81 100.13 Q 330.13 100.04 330.46 100.64 Z M 212.79 184.77 C 182.63 212.40 133.76 194.13 129.34 153.02 Q 129.28 152.50 128.76 152.50 L 21.03 152.50 A 0.53 0.52 4.5 0 0 20.51 152.94 C 1.62 261.25 92.99 357.54 201.51 343.78 C 277.79 334.11 337.83 272.59 344.40 195.57 C 355.70 63.05 212.90 -26.21 98.05 41.00 C 59.13 63.78 32.69 101.49 21.88 145.42 Q 21.61 146.50 22.72 146.50 L 128.46 146.50 Q 128.90 146.50 128.94 146.07 Q 131.26 119.63 151.75 106.22 C 184.91 84.50 226.66 107.87 228.98 146.00 Q 229.01 146.50 229.51 146.50 L 337.25 146.50 Q 338.00 146.50 338.00 147.25 L 338.00 151.75 Q 338.00 152.50 337.25 152.50 L 229.25 152.50 Q 228.75 152.50 228.69 153.00 Q 226.50 172.21 212.79 184.77 Z M 222.95 148.00 A 43.95 43.95 0.0 0 0 179.00 104.05 A 43.95 43.95 0.0 0 0 135.05 148.00 A 43.95 43.95 0.0 0 0 179.00 191.95 A 43.95 43.95 0.0 0 0 222.95 148.00 Z"
        }),
        t.jsx("path", {
          fill: "#a0a0a0",
          d: " M 234.86 54.37 Q 237.06 56.61 233.37 58.52 A 2.80 2.79 44.2 0 1 230.87 58.55 Q 178.34 32.73 126.63 59.92 A 2.35 2.35 0.0 0 1 123.30 58.57 Q 122.82 57.10 123.23 55.66 Q 123.37 55.14 123.84 54.88 C 157.72 35.70 198.72 35.20 233.14 53.20 Q 234.31 53.81 234.86 54.37 Z"
        }),
        t.jsx("path", {
          fill: "currentColor",
          d: " M 153.81 56.69 Q 155.34 56.33 156.14 55.70 A 1.12 1.09 -58.9 0 1 157.01 55.47 Q 159.34 55.82 161.29 54.58 A 1.24 1.22 -55.7 0 1 162.15 54.41 C 165.00 54.94 166.83 53.51 169.29 53.51 Q 178.97 53.49 188.64 53.50 C 191.13 53.51 193.05 54.90 195.91 54.44 Q 196.47 54.36 196.95 54.65 Q 198.86 55.80 201.11 55.49 Q 201.63 55.42 202.03 55.76 C 203.10 56.70 204.44 56.54 205.63 57.07 Q 209.27 58.70 211.98 61.56 Q 212.37 61.97 212.42 62.53 L 212.75 66.42 A 1.23 1.18 -31.8 0 1 212.55 67.20 L 209.96 71.11 Q 209.71 71.50 209.25 71.50 L 193.25 71.50 A 0.50 0.50 0.0 0 1 192.75 70.99 Q 192.75 70.80 192.75 70.61 Q 192.74 70.16 192.29 70.17 L 148.62 71.47 Q 148.05 71.48 147.86 70.95 C 146.80 68.02 144.00 63.58 146.73 60.83 Q 149.97 57.58 153.81 56.69 Z M 187.04 56.93 Q 178.43 55.86 169.96 57.11 Q 169.43 57.18 169.42 57.72 Q 169.37 59.98 170.21 62.04 Q 170.38 62.47 170.41 62.93 L 170.67 66.86 Q 170.71 67.50 171.35 67.50 L 186.25 67.50 A 1.32 1.31 86.2 0 0 187.55 66.01 Q 187.12 62.74 188.59 59.88 A 2.03 2.03 0.0 0 0 187.04 56.93 Z M 167.55 67.30 A 0.31 0.30 -13.3 0 0 167.80 66.90 Q 166.45 62.88 166.42 58.72 Q 166.41 57.32 165.02 57.42 C 163.40 57.54 162.36 58.27 160.75 58.45 Q 154.55 59.13 149.36 62.70 Q 148.95 62.98 149.08 63.45 L 150.62 68.92 Q 150.74 69.34 151.18 69.29 L 167.55 67.30 Z M 208.27 67.58 C 214.74 60.58 196.37 58.91 194.06 57.33 A 1.58 1.58 0.0 0 0 191.59 58.57 L 191.43 62.59 A 0.38 0.38 0.0 0 1 191.39 62.76 Q 190.44 64.75 190.34 66.95 Q 190.31 67.58 190.94 67.57 L 196.52 67.47 Q 196.92 67.47 197.12 67.81 L 197.40 68.28 Q 197.57 68.56 197.89 68.56 L 204.23 68.48 Q 204.75 68.47 205.04 68.90 Q 205.79 69.98 206.94 69.51 Q 207.29 69.37 207.39 69.00 Q 207.60 68.30 208.27 67.58 Z"
        }),
        t.jsx("path", {
          fill: "currentColor",
          d: " M 159.80 309.70 Q 160.31 307.85 160.90 306.05 Q 161.11 305.42 161.44 305.23 Q 161.70 305.07 161.98 305.12 Q 162.47 305.21 162.30 305.69 L 160.32 311.22 A 1.04 1.03 -45.8 0 1 158.38 311.25 L 156.12 305.42 Q 156.00 305.09 156.34 305.05 L 156.75 304.99 A 0.74 0.74 0.0 0 1 157.55 305.48 L 159.03 309.73 Q 159.46 310.96 159.80 309.70 Z"
        }),
        t.jsx("path", {
          fill: "currentColor",
          d: " M 175.18 311.15 C 171.14 315.72 166.72 304.88 173.66 305.10 Q 175.04 305.14 174.99 306.40 A 0.41 0.40 -66.3 0 1 174.30 306.67 L 174.00 306.37 Q 173.04 305.42 172.22 306.49 Q 170.50 308.73 172.13 310.85 A 0.65 0.64 63.1 0 0 172.82 311.08 L 174.81 310.55 A 0.37 0.37 0.0 0 1 175.18 311.15 Z"
        }),
        t.jsx("path", {
          fill: "currentColor",
          d: " M 179.13 311.01 Q 180.78 310.85 181.22 309.24 A 0.43 0.38 48.6 0 0 181.22 308.99 Q 180.70 307.15 181.17 305.34 A 0.55 0.55 0.0 0 1 182.25 305.48 L 182.25 311.59 Q 182.25 312.23 181.65 312.01 L 180.91 311.74 Q 180.48 311.58 180.05 311.75 C 175.85 313.45 176.89 307.92 176.64 306.03 A 0.83 0.75 56.0 0 1 176.70 305.60 Q 177.12 304.69 177.73 305.11 A 0.28 0.27 -73.9 0 1 177.85 305.34 L 177.95 309.97 A 1.08 1.07 -3.5 0 0 179.13 311.01 Z"
        }),
        t.jsx("path", {
          fill: "currentColor",
          d: " M 188.74 309.68 L 188.76 305.51 A 0.53 0.53 0.0 0 1 189.27 304.98 Q 189.61 304.97 189.81 305.13 Q 189.96 305.25 189.96 305.53 Q 190.06 308.61 189.98 311.70 Q 189.96 312.37 189.42 311.97 L 188.88 311.58 A 0.65 0.65 0.0 0 0 188.14 311.55 Q 186.22 312.75 184.77 311.10 A 0.82 0.81 -67.4 0 1 184.56 310.58 L 184.37 305.50 A 0.49 0.48 1.6 0 1 184.90 305.00 Q 185.51 305.05 185.47 305.75 Q 185.32 308.20 185.75 310.02 A 1.52 1.51 -51.5 0 0 188.74 309.68 Z"
        }),
        t.jsx("path", {
          fill: "currentColor",
          d: " M 196.21 307.08 A 1.21 1.21 0.0 0 0 193.89 306.64 Q 192.94 308.94 193.29 311.41 Q 193.36 311.90 192.87 311.99 Q 192.41 312.08 192.14 311.79 Q 191.96 311.59 191.98 311.17 Q 192.12 308.69 192.10 306.20 Q 192.10 305.69 192.58 305.55 Q 194.99 304.88 197.23 305.78 Q 197.77 306.00 198.22 305.62 Q 199.55 304.50 200.99 305.59 Q 201.48 305.97 201.57 306.57 Q 201.91 309.05 201.70 311.55 A 0.60 0.60 0.0 0 1 200.50 311.50 L 200.50 306.82 A 0.64 0.64 0.0 0 0 199.63 306.22 L 197.96 306.87 Q 197.50 307.04 197.50 307.54 L 197.50 311.25 A 0.75 0.53 -55.1 0 1 196.28 311.69 L 196.21 307.08 Z"
        }),
        t.jsx("path", {
          fill: "currentColor",
          d: " M 166.19 306.06 Q 165.20 305.95 163.65 306.73 A 0.26 0.25 54.0 0 1 163.36 306.68 L 163.06 306.39 Q 162.74 306.06 163.15 305.85 Q 165.37 304.69 167.67 305.57 A 0.83 0.81 -81.0 0 1 168.19 306.31 L 168.38 311.17 Q 168.40 311.74 167.83 311.77 L 164.15 311.96 A 0.95 0.95 0.0 0 1 163.14 311.01 Q 163.14 307.54 166.75 308.06 A 0.37 0.36 -82.6 0 0 167.17 307.73 Q 167.33 306.19 166.19 306.06 Z M 165.15 310.91 Q 166.31 311.37 166.98 310.36 A 0.88 0.88 0.0 0 0 166.25 309.00 L 165.00 309.00 A 1.14 0.94 70.8 0 0 164.37 310.71 Q 164.44 310.82 164.72 310.82 Q 164.94 310.82 165.15 310.91 Z"
        })
      ]
    });
  };
  A = function(l) {
    return t.jsx("svg", {
      viewBox: "0 0 512 512",
      width: l.width || 20,
      height: l.height || l.width || 20,
      xmlns: "http://www.w3.org/2000/svg",
      style: l.style,
      children: t.jsx("path", {
        fill: "currentColor",
        d: "M352.57 128c-28.09 0-54.09 4.52-77.06 12.86l12.41-123.11C289 7.31 279.81-1.18 269.33.13 189.63 10.13 128 77.64 128 159.43c0 28.09 4.52 54.09 12.86 77.06L17.75 224.08C7.31 223-1.18 232.19.13 242.67c10 79.7 77.51 141.33 159.3 141.33 28.09 0 54.09-4.52 77.06-12.86l-12.41 123.11c-1.05 10.43 8.11 18.93 18.59 17.62 79.7-10 141.33-77.51 141.33-159.3 0-28.09-4.52-54.09-12.86-77.06l123.11 12.41c10.44 1.05 18.93-8.11 17.62-18.59-10-79.7-77.51-141.33-159.3-141.33zM256 288a32 32 0 1 1 32-32 32 32 0 0 1-32 32z"
      })
    });
  };
  let i, m, L;
  i = {
    vacuumBattery: {
      display: "flex",
      alignItems: "center",
      gap: 4
    },
    vacuumSensorsContainer: {
      overflow: "auto"
    },
    vacuumSensors: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 4,
      minWidth: "min-content"
    },
    vacuumButtons: {
      display: "flex",
      alignItems: "center",
      gap: 4
    },
    vacuumContent: {
      width: "100%",
      height: "100%",
      overflow: "auto"
    },
    vacuumMapContainer: {
      flex: 1
    },
    vacuumTopPanel: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    },
    vacuumBottomPanel: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    },
    vacuumSensorCard: {
      boxShadow: "none",
      backgroundColor: "transparent"
    },
    vacuumSensorCardContent: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      textAlign: "center",
      padding: 2,
      paddingBottom: 2
    },
    vacuumSensorBigText: {
      fontSize: 20
    },
    vacuumSensorSmallText: {
      fontSize: 12
    },
    vacuumImage: {
      width: "100%",
      height: "100%",
      objectFit: "contain",
      color: "grey"
    },
    vacuumSpeedContainer: {
      gap: 4,
      display: "flex",
      alignItems: "center"
    },
    tooltip: {
      pointerEvents: "none"
    }
  };
  p = {
    status: {
      role: "value.state"
    },
    battery: {
      role: "value.battery"
    },
    "is-charging": {
      name: "is_charging"
    },
    "fan-speed": {
      role: "level.suction"
    },
    "sensors-left": {
      role: "value.usage.sensors"
    },
    "filter-left": {
      role: "value.usage.filter"
    },
    "main-brush-left": {
      role: "value.usage.brush"
    },
    "side-brush-left": {
      role: "value.usage.brush.side"
    },
    "cleaning-count": {
      name: "cleanups"
    },
    start: {
      role: "button",
      name: "start"
    },
    home: {
      role: "button",
      name: "home"
    },
    pause: {
      role: "button",
      name: "pause"
    },
    map64: {
      role: "vacuum.map.base64"
    }
  };
  m = async (l, e, n, a) => {
    if (e[l.name]) {
      const s = await a.getObject(e[l.name]);
      if (s && s.common) {
        let o = s._id.split(".");
        o.pop();
        let u = await a.getObject(o.join("."));
        if (!u) return;
        (u.type === "channel" || u.type === "folder") && (o.pop(), u = await a.getObject(o.join("."))), u.type !== "device" && (o = s._id.split("."), o.pop());
        const r = await a.getObjectViewSystem("state", `${o.join(".")}.`, `${o.join(".")}.\u9999`);
        if (r) {
          let d = false;
          for (const h in p) e[`vacuum-${h}-oid`] || Object.values(r).forEach((v) => {
            var _a;
            if (v._id.split(".").includes("rooms")) {
              e["vacuum-rooms"] || (d = true, e["vacuum-rooms"] = true);
              return;
            }
            const O = (_a = v.common) == null ? void 0 : _a.role, j = p[h].role;
            if (j && !(O == null ? void 0 : O.includes(j))) return;
            const C = p[h].name;
            C && !v._id.split(".").pop().toLowerCase().includes(C) || (d = true, e[`vacuum-${h}-oid`] = v._id);
          });
          d && n(e);
        }
      }
    }
  };
  _ = [
    "cleaning",
    "spot Cleaning",
    "zone cleaning",
    "room cleaning"
  ];
  Q = [
    "pause",
    "waiting"
  ];
  x = [
    "charging",
    "charging Erro"
  ];
  L = [
    "back to home",
    "docking"
  ];
  M = (l) => {
    if (typeof l == "boolean") {
      if (l) return "green";
    } else {
      l == null && (l = "");
      const e = l.toString().toLowerCase();
      if (_.includes(e)) return "green";
      if (Q.includes(e)) return "yellow";
      if (x.includes(e)) return "gray";
      if (L.includes(e)) return "blue";
    }
  };
  class b extends c {
    constructor(e) {
      super(e), this.state = {
        ...this.state,
        objects: {},
        rooms: []
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2Vacuum",
        visSet: "vis-2-widgets-nils-fork",
        visWidgetLabel: "vacuum",
        visName: "Vacuum",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                hidden: "!!data.externalDialog"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard || !!data.externalDialog"
              },
              {
                name: "externalDialog",
                label: "use_as_dialog",
                type: "checkbox",
                tooltip: "use_as_dialog_tooltip"
              }
            ]
          },
          {
            name: "sensors",
            label: "sensors",
            fields: [
              {
                label: "status",
                name: "vacuum-status-oid",
                type: "id",
                onChange: m
              },
              {
                label: "battery",
                name: "vacuum-battery-oid",
                type: "id",
                onChange: m
              },
              {
                label: "is_charging",
                name: "vacuum-is-charging-oid",
                type: "id",
                onChange: m
              },
              {
                label: "fan_speed",
                name: "vacuum-fan-speed-oid",
                type: "id",
                onChange: m
              },
              {
                label: "sensors_left",
                name: "vacuum-sensors-left-oid",
                type: "id",
                onChange: m
              },
              {
                label: "filter_left",
                name: "vacuum-filter-left-oid",
                type: "id",
                onChange: m
              },
              {
                label: "main_brush_left",
                name: "vacuum-main-brush-left-oid",
                type: "id",
                onChange: m
              },
              {
                label: "side_brush_left",
                name: "vacuum-side-brush-left-oid",
                type: "id",
                onChange: m
              },
              {
                label: "cleaning_count",
                name: "vacuum-cleaning-count-oid",
                type: "id",
                onChange: m
              }
            ]
          },
          {
            name: "map",
            label: "map",
            fields: [
              {
                label: "rooms",
                name: "vacuum-use-rooms",
                type: "checkbox",
                tooltip: "rooms_tooltip"
              },
              {
                label: "map64",
                name: "vacuum-map64-oid",
                type: "id",
                onChange: m
              },
              {
                label: "useDefaultPicture",
                name: "vacuum-use-default-picture",
                type: "checkbox",
                default: true,
                hidden: '!!data["vacuum-map64-oid"]'
              },
              {
                label: "ownImage",
                name: "vacuum-own-image",
                type: "image",
                hidden: '!!data["vacuum-map64-oid"] || !data["vacuum-use-default-picture"]'
              }
            ]
          },
          {
            name: "actions",
            label: "actions",
            fields: [
              {
                label: "start",
                name: "vacuum-start-oid",
                type: "id"
              },
              {
                label: "home",
                name: "vacuum-home-oid",
                type: "id"
              },
              {
                label: "pause",
                name: "vacuum-pause-oid",
                type: "id"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 400,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_vacuum.png"
      };
    }
    getWidgetInfo() {
      return b.getWidgetInfo();
    }
    async componentDidMount() {
      super.componentDidMount(), await this.vacuumPropertiesUpdate();
    }
    async onRxDataChanged() {
      await this.vacuumPropertiesUpdate();
    }
    async vacuumPropertiesUpdate() {
      const e = {}, n = [], a = Object.keys(p);
      for (let u = 0; u < a.length; u++) {
        const r = this.state.rxData[`vacuum-${a[u]}-oid`];
        r && n.push(r);
      }
      const s = await this.props.context.socket.getObjectsById(n);
      Object.values(s).forEach((u) => {
        const r = a.find((d) => this.state.rxData[`vacuum-${d}-oid`] === u._id);
        r && (e[r] = u);
      });
      const o = await this.vacuumLoadRooms();
      this.setState({
        objects: e,
        rooms: o
      });
    }
    async vacuumLoadRooms() {
      if (this.state.rxData["vacuum-use-rooms"] && this.state.rxData["vacuum-status-oid"]) {
        const e = this.state.rxData["vacuum-status-oid"].split(".");
        if (e.length === 4) {
          e.pop(), e.pop(), e.push("rooms");
          const n = await this.props.context.socket.getObjectViewSystem("channel", `${e.join(".")}.room`, `${e.join(".")}.room\u9999`), a = [];
          return Object.keys(n).forEach((s) => {
            var _a;
            return a.push({
              value: `${s}.roomClean`,
              label: c.getText(((_a = n[s].common) == null ? void 0 : _a.name) || s.split(".").pop() || "")
            });
          }), a.sort((s, o) => s.label.localeCompare(o.label)), a;
        }
      }
      return null;
    }
    vacuumGetValue(e, n) {
      var _a;
      const a = this.vacuumGetObj(e);
      if (!a) return null;
      const s = this.state.values[`${a._id}.val`];
      return !n && ((_a = a.common) == null ? void 0 : _a.states) && a.common.states[s] !== void 0 && a.common.states[s] !== null ? a.common.states[s] : s;
    }
    vacuumGetObj(e) {
      return this.state.objects[e];
    }
    vacuumRenderBattery() {
      var _a;
      const e = this.vacuumGetObj("battery");
      return e ? t.jsxs("div", {
        style: i.vacuumBattery,
        children: [
          this.vacuumGetObj("is-charging") && this.vacuumGetValue("is-charging") ? t.jsx(k, {}) : t.jsx(T, {}),
          this.vacuumGetValue("battery") || 0,
          " ",
          (_a = e.common) == null ? void 0 : _a.unit
        ]
      }) : null;
    }
    vacuumRenderSpeed() {
      const e = this.vacuumGetObj("fan-speed");
      if (!e) return null;
      let n = null;
      Array.isArray(e.common.states) ? (n = {}, e.common.states.forEach((s) => n[s] = s)) : n = e.common.states;
      let a = this.vacuumGetValue("fan-speed", true);
      return a == null && (a = ""), a = a.toString(), [
        t.jsx(y, {
          style: i.vacuumSpeedContainer,
          endIcon: t.jsx(A, {}),
          onClick: (s) => {
            s.stopPropagation(), this.setState({
              showSpeedMenu: s.currentTarget
            });
          },
          children: n[a] !== void 0 && n[a] !== null ? c.t(n[a]).replace("vis_2_widgets_nils_", "") : a
        }, "speed"),
        this.state.showSpeedMenu ? t.jsx(S, {
          open: true,
          anchorEl: this.state.showSpeedMenu,
          onClose: () => this.setState({
            showSpeedMenu: null
          }),
          children: Object.keys(n).map((s) => t.jsx(w, {
            selected: a === s,
            onClick: () => {
              this.setState({
                showSpeedMenu: null
              }, () => this.props.context.setValue(this.state.rxData["vacuum-fan-speed-oid"], s));
            },
            children: c.t(n[s]).replace("vis_2_widgets_nils_", "")
          }, s))
        }, "speedMenu") : null
      ];
    }
    vacuumRenderRooms() {
      var _a;
      return ((_a = this.state.rooms) == null ? void 0 : _a.length) ? [
        t.jsx(y, {
          variant: "outlined",
          color: "grey",
          onClick: (e) => this.setState({
            showRoomsMenu: e.currentTarget
          }),
          children: c.t("Room")
        }, "rooms"),
        this.state.showRoomsMenu ? t.jsx(S, {
          onClose: () => this.setState({
            showRoomsMenu: null
          }),
          open: true,
          anchorEl: this.state.showRoomsMenu,
          children: this.state.rooms.map((e) => t.jsx(w, {
            value: e.value,
            onClick: () => {
              const n = e.value;
              this.setState({
                showRoomsMenu: null
              }, () => this.props.context.setValue(n, true));
            },
            children: e.label
          }, e.value))
        }, "roomsMenu") : null
      ] : null;
    }
    vacuumRenderSensors() {
      const e = [
        "filter-left",
        "side-brush-left",
        "main-brush-left",
        "sensors-left",
        "cleaning-count"
      ].filter((n) => this.vacuumGetObj(n));
      return e.length ? t.jsx("div", {
        style: i.vacuumSensorsContainer,
        children: t.jsx("div", {
          style: i.vacuumSensors,
          children: e.map((n) => {
            const a = this.vacuumGetObj(n);
            return t.jsx(D, {
              style: i.vacuumSensorCard,
              children: t.jsxs(R, {
                style: {
                  ...i.vacuumSensorCardContent,
                  paddingBottom: 2
                },
                children: [
                  t.jsxs("div", {
                    children: [
                      t.jsx("span", {
                        style: i.vacuumSensorBigText,
                        children: this.vacuumGetValue(n) || 0
                      }),
                      " ",
                      t.jsx("span", {
                        style: i.vacuumSensorSmallText,
                        children: a.common.unit
                      })
                    ]
                  }),
                  t.jsx("div", {
                    children: t.jsx("span", {
                      style: i.vacuumSensorSmallText,
                      children: c.t(n.replaceAll("-", "_"))
                    })
                  })
                ]
              })
            }, n);
          })
        })
      }) : null;
    }
    vacuumRenderButtons() {
      let e;
      const n = this.vacuumGetObj("status");
      let a = "", s;
      if (n) {
        const o = this.vacuumGetValue("status");
        e = M(o), typeof o == "boolean" ? (s = o ? "cleaning" : "pause", a = o ? "Cleaning" : "Pause") : (o == null && (a = ""), a = (o || "").toString(), s = a.toLowerCase());
      }
      return t.jsxs("div", {
        style: i.vacuumButtons,
        children: [
          this.vacuumGetObj("start") && (!s || !_.includes(s)) && t.jsx(f, {
            title: c.t("Start"),
            slotProps: {
              popper: {
                sx: i.tooltip
              }
            },
            children: t.jsx(g, {
              onClick: () => this.props.context.setValue(this.state.rxData["vacuum-start-oid"], true),
              children: t.jsx(B, {})
            })
          }),
          this.vacuumGetObj("pause") && (!s || !Q.includes(s)) && (!s || !x.includes(s)) && t.jsx(f, {
            title: c.t("Pause"),
            slotProps: {
              popper: {
                sx: i.tooltip
              }
            },
            children: t.jsx(g, {
              onClick: () => this.props.context.setValue(this.state.rxData["vacuum-pause-oid"], true),
              children: t.jsx(E, {})
            })
          }),
          this.vacuumGetObj("home") && (!s || !x.includes(s)) && t.jsx(f, {
            title: c.t("Home"),
            slotProps: {
              popper: {
                sx: i.tooltip
              }
            },
            children: t.jsx(g, {
              onClick: () => this.props.context.setValue(this.state.rxData["vacuum-home-oid"], true),
              children: t.jsx(P, {})
            })
          }),
          n && t.jsx(f, {
            title: c.t("Status"),
            slotProps: {
              popper: {
                sx: i.tooltip
              }
            },
            children: t.jsx("div", {
              style: {
                color: e
              },
              children: c.t(a).replace("vis_2_widgets_nils_", "")
            })
          })
        ]
      });
    }
    vacuumRenderMap() {
      const e = this.vacuumGetObj("map64");
      return !e || !this.state.values[`${e._id}.val`] ? this.state.rxData["vacuum-use-default-picture"] ? t.jsx($, {
        style: i.vacuumImage
      }) : this.state.rxData["vacuum-own-image"] ? t.jsx(U, {
        src: this.state.rxData["vacuum-own-image"],
        style: i.vacuumImage
      }) : null : t.jsx("img", {
        src: this.state.values[`${e._id}.val`],
        alt: "vacuum",
        style: i.vacuumImage
      });
    }
    onCommand(e) {
      const n = super.onCommand(e);
      if (n === false) {
        if (e === "openDialog") return this.setState({
          dialog: true
        }), true;
        if (e === "closeDialog") return this.setState({
          dialog: false
        }), true;
      }
      return n;
    }
    renderWidgetBody(e) {
      super.renderWidgetBody(e);
      const n = this.vacuumRenderRooms(), a = this.vacuumRenderBattery();
      let s = 0;
      n ? s += 36 : a && (s += 24);
      const o = this.vacuumRenderSensors();
      o && (s += 46);
      const u = this.vacuumRenderButtons(), r = this.vacuumRenderSpeed();
      (u || n) && (s += 40);
      const d = this.vacuumRenderMap(), h = t.jsxs("div", {
        style: i.vacuumContent,
        children: [
          a || n ? t.jsxs("div", {
            style: i.vacuumTopPanel,
            children: [
              n,
              a
            ]
          }) : null,
          d ? t.jsx("div", {
            style: {
              ...i.vacuumMapContainer,
              height: `calc(100% - ${s + 5}px)`,
              width: "100%"
            },
            children: d
          }) : null,
          o,
          u || r ? t.jsxs("div", {
            style: i.vacuumBottomPanel,
            children: [
              u,
              r
            ]
          }) : null
        ]
      });
      return this.state.rxData.externalDialog && !this.props.editMode ? this.state.dialog ? t.jsxs(G, {
        open: true,
        onClose: () => this.setState({
          dialog: null
        }),
        children: [
          t.jsxs(I, {
            children: [
              this.state.rxData.widgetTitle,
              t.jsx(g, {
                style: {
                  float: "right",
                  zIndex: 2
                },
                onClick: () => this.setState({
                  dialog: null
                }),
                children: t.jsx(Z, {})
              })
            ]
          }),
          t.jsx(V, {
            children: h
          })
        ]
      }) : null : this.wrapContent(h);
    }
  }
  Y = Object.freeze(Object.defineProperty({
    __proto__: null,
    FanIcon: A,
    VACUUM_CHARGING_STATES: x,
    VACUUM_CLEANING_STATES: _,
    VACUUM_GOING_HOME_STATES: L,
    VACUUM_ID_ROLES: p,
    VACUUM_PAUSE_STATES: Q,
    default: b,
    vacuumGetStatusColor: M
  }, Symbol.toStringTag, {
    value: "Module"
  }));
});
export {
  A as F,
  _ as V,
  __tla,
  Q as a,
  x as b,
  $ as c,
  p as d,
  Y as e,
  M as v
};
