import { j as w, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { a as Tt, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { a as Bt, b as Pt, c as jt, d as Gt, e as ot, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { _ as Ht, n as At, o as Ot, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CgDCyMuJ.js";
import { _ as K, i as _t, e as G, m as V, a as Y, b as zt, c as xt, d as Wt, M as Ft, f as Vt, g as Et, h as Dt, C as $t, G as bt, j as lt, k as Nt, l as ct, p as Ut, n as tt, s as Zt, Z as et, o as Jt, q as ht, r as dt, t as Yt, R as Ct, u as qt, v as E, w as Kt, x as W, y as Xt, z as Qt, A as Mt, B as te, D as ee, E as ie, F as ae, H as ne, I as re, J as se, K as oe, L as q, N as le, O as ce, P as wt, Q as $, S as it, T as he, U as It, V as de, W as ue, X as pe, Y as fe, $ as ge, a0 as N, a1 as me, a2 as ve, a3 as ye, a4 as _e, a5 as U, a6 as xe, a7 as De, a8 as be, a9 as Ce, __tla as __tla_4 } from "./installSVGRenderer-It2PVbYG.js";
import { _ as ut, __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-Buo0KxVv.js";
import { m as we, O as Ie, i as Se, a as Le, b as Re, c as ke, __tla as __tla_6 } from "./ObjectChart-BD1xDyiH.js";
import { G as L } from "./Generic-DDdmRdK-.js";
import { __tla as __tla_7 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
import "./tslib.es6-BuLyYyFn.js";
let j;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })()
]).then(async () => {
  var Te = function(s, i) {
    if (i === "all") return {
      type: "all",
      title: s.getLocaleModel().get([
        "legend",
        "selector",
        "all"
      ])
    };
    if (i === "inverse") return {
      type: "inverse",
      title: s.getLocaleModel().get([
        "legend",
        "selector",
        "inverse"
      ])
    };
  }, at = (function(s) {
    K(i, s);
    function i() {
      var t = s !== null && s.apply(this, arguments) || this;
      return t.type = i.type, t.layoutMode = {
        type: "box",
        ignoreSize: true
      }, t;
    }
    return i.prototype.init = function(t, e, a) {
      this.mergeDefaultAndTheme(t, a), t.selected = t.selected || {}, this._updateSelector(t);
    }, i.prototype.mergeOption = function(t, e) {
      s.prototype.mergeOption.call(this, t, e), this._updateSelector(t);
    }, i.prototype._updateSelector = function(t) {
      var e = t.selector, a = this.ecModel;
      e === true && (e = t.selector = [
        "all",
        "inverse"
      ]), _t(e) && G(e, function(n, r) {
        Y(n) && (n = {
          type: n
        }), e[r] = V(n, Te(a, n.type));
      });
    }, i.prototype.optionUpdated = function() {
      this._updateData(this.ecModel);
      var t = this._data;
      if (t[0] && this.get("selectedMode") === "single") {
        for (var e = false, a = 0; a < t.length; a++) {
          var n = t[a].get("name");
          if (this.isSelected(n)) {
            this.select(n), e = true;
            break;
          }
        }
        !e && this.select(t[0].get("name"));
      }
    }, i.prototype._updateData = function(t) {
      var e = [], a = [];
      t.eachRawSeries(function(o) {
        var c = o.name;
        a.push(c);
        var d;
        if (o.legendVisualProvider) {
          var l = o.legendVisualProvider, u = l.getAllNames();
          t.isSeriesFiltered(o) || (a = a.concat(u)), u.length ? e = e.concat(u) : d = true;
        } else d = true;
        d && zt(o) && e.push(o.name);
      }), this._availableNames = a;
      var n = this.get("data") || e, r = xt(), h = Wt(n, function(o) {
        return (Y(o) || Vt(o)) && (o = {
          name: o
        }), r.get(o.name) ? null : (r.set(o.name, true), new Ft(o, this, this.ecModel));
      }, this);
      this._data = Et(h, function(o) {
        return !!o;
      });
    }, i.prototype.getData = function() {
      return this._data;
    }, i.prototype.select = function(t) {
      var e = this.option.selected, a = this.get("selectedMode");
      if (a === "single") {
        var n = this._data;
        G(n, function(r) {
          e[r.get("name")] = false;
        });
      }
      e[t] = true;
    }, i.prototype.unSelect = function(t) {
      this.get("selectedMode") !== "single" && (this.option.selected[t] = false);
    }, i.prototype.toggleSelected = function(t) {
      var e = this.option.selected;
      e.hasOwnProperty(t) || (e[t] = true), this[e[t] ? "unSelect" : "select"](t);
    }, i.prototype.allSelect = function() {
      var t = this._data, e = this.option.selected;
      G(t, function(a) {
        e[a.get("name", true)] = true;
      });
    }, i.prototype.inverseSelect = function() {
      var t = this._data, e = this.option.selected;
      G(t, function(a) {
        var n = a.get("name", true);
        e.hasOwnProperty(n) || (e[n] = true), e[n] = !e[n];
      });
    }, i.prototype.isSelected = function(t) {
      var e = this.option.selected;
      return !(e.hasOwnProperty(t) && !e[t]) && Dt(this._availableNames, t) >= 0;
    }, i.prototype.getOrient = function() {
      return this.get("orient") === "vertical" ? {
        index: 1,
        name: "vertical"
      } : {
        index: 0,
        name: "horizontal"
      };
    }, i.type = "legend.plain", i.dependencies = [
      "series"
    ], i.defaultOption = {
      z: 4,
      show: true,
      orient: "horizontal",
      left: "center",
      top: 0,
      align: "auto",
      backgroundColor: "rgba(0,0,0,0)",
      borderColor: "#ccc",
      borderRadius: 0,
      borderWidth: 0,
      padding: 5,
      itemGap: 10,
      itemWidth: 25,
      itemHeight: 14,
      symbolRotate: "inherit",
      symbolKeepAspect: true,
      inactiveColor: "#ccc",
      inactiveBorderColor: "#ccc",
      inactiveBorderWidth: "auto",
      itemStyle: {
        color: "inherit",
        opacity: "inherit",
        borderColor: "inherit",
        borderWidth: "auto",
        borderCap: "inherit",
        borderJoin: "inherit",
        borderDashOffset: "inherit",
        borderMiterLimit: "inherit"
      },
      lineStyle: {
        width: "auto",
        color: "inherit",
        inactiveColor: "#ccc",
        inactiveWidth: 2,
        opacity: "inherit",
        type: "inherit",
        cap: "inherit",
        join: "inherit",
        dashOffset: "inherit",
        miterLimit: "inherit"
      },
      textStyle: {
        color: "#333"
      },
      selectedMode: true,
      selector: false,
      selectorLabel: {
        show: true,
        borderRadius: 10,
        padding: [
          3,
          5,
          3,
          5
        ],
        fontSize: 12,
        fontFamily: "sans-serif",
        color: "#666",
        borderWidth: 1,
        borderColor: "#666"
      },
      emphasis: {
        selectorLabel: {
          show: true,
          color: "#eee",
          backgroundColor: "#666"
        }
      },
      selectorPosition: "auto",
      selectorItemGap: 7,
      selectorButtonGap: 10,
      tooltip: {
        show: false
      }
    }, i;
  })($t), z = W, nt = G, Z = bt, St = (function(s) {
    K(i, s);
    function i() {
      var t = s !== null && s.apply(this, arguments) || this;
      return t.type = i.type, t.newlineDisabled = false, t;
    }
    return i.prototype.init = function() {
      this.group.add(this._contentGroup = new Z()), this.group.add(this._selectorGroup = new Z()), this._isFirstRender = true;
    }, i.prototype.getContentGroup = function() {
      return this._contentGroup;
    }, i.prototype.getSelectorGroup = function() {
      return this._selectorGroup;
    }, i.prototype.render = function(t, e, a) {
      var n = this._isFirstRender;
      if (this._isFirstRender = false, this.resetInner(), !!t.get("show", true)) {
        var r = t.get("align"), h = t.get("orient");
        (!r || r === "auto") && (r = t.get("left") === "right" && h === "vertical" ? "right" : "left");
        var o = t.get("selector", true), c = t.get("selectorPosition", true);
        o && (!c || c === "auto") && (c = h === "horizontal" ? "end" : "start"), this.renderInner(r, t, e, a, o, h, c);
        var d = t.getBoxLayoutParams(), l = {
          width: a.getWidth(),
          height: a.getHeight()
        }, u = t.get("padding"), f = lt(d, l, u), m = this.layoutInner(t, r, f, n, o, c), p = lt(Nt({
          width: m.width,
          height: m.height
        }, d), l, u);
        this.group.x = p.x - m.x, this.group.y = p.y - m.y, this.group.markRedraw(), this.group.add(this._backgroundEl = we(m, t));
      }
    }, i.prototype.resetInner = function() {
      this.getContentGroup().removeAll(), this._backgroundEl && this.group.remove(this._backgroundEl), this.getSelectorGroup().removeAll();
    }, i.prototype.renderInner = function(t, e, a, n, r, h, o) {
      var c = this.getContentGroup(), d = xt(), l = e.get("selectedMode"), u = [];
      a.eachRawSeries(function(f) {
        !f.get("legendHoverLink") && u.push(f.id);
      }), nt(e.getData(), function(f, m) {
        var p = f.get("name");
        if (!this.newlineDisabled && (p === "" || p === `
`)) {
          var g = new Z();
          g.newline = true, c.add(g);
          return;
        }
        var y = a.getSeriesByName(p)[0];
        if (!d.get(p)) if (y) {
          var v = y.getData(), _ = v.getVisual("legendLineStyle") || {}, I = v.getVisual("legendIcon"), b = v.getVisual("style"), C = this._createItem(y, p, m, f, e, t, _, b, I, l, n);
          C.on("click", z(pt, p, null, n, u)).on("mouseover", z(rt, y.name, null, n, u)).on("mouseout", z(st, y.name, null, n, u)), a.ssr && C.eachChild(function(D) {
            var x = ct(D);
            x.seriesIndex = y.seriesIndex, x.dataIndex = m, x.ssrType = "legend";
          }), d.set(p, true);
        } else a.eachRawSeries(function(D) {
          if (!d.get(p) && D.legendVisualProvider) {
            var x = D.legendVisualProvider;
            if (!x.containName(p)) return;
            var T = x.indexOfName(p), S = x.getItemVisual(T, "style"), B = x.getItemVisual(T, "legendIcon"), R = Ut(S.fill);
            R && R[3] === 0 && (R[3] = 0.2, S = tt(tt({}, S), {
              fill: Zt(R, "rgba")
            }));
            var P = this._createItem(D, p, m, f, e, t, {}, S, B, l, n);
            P.on("click", z(pt, null, p, n, u)).on("mouseover", z(rt, null, p, n, u)).on("mouseout", z(st, null, p, n, u)), a.ssr && P.eachChild(function(A) {
              var H = ct(A);
              H.seriesIndex = D.seriesIndex, H.dataIndex = m, H.ssrType = "legend";
            }), d.set(p, true);
          }
        }, this);
      }, this), r && this._createSelector(r, e, n, h, o);
    }, i.prototype._createSelector = function(t, e, a, n, r) {
      var h = this.getSelectorGroup();
      nt(t, function(c) {
        var d = c.type, l = new et({
          style: {
            x: 0,
            y: 0,
            align: "center",
            verticalAlign: "middle"
          },
          onclick: function() {
            a.dispatchAction({
              type: d === "all" ? "legendAllSelect" : "legendInverseSelect",
              legendId: e.id
            });
          }
        });
        h.add(l);
        var u = e.getModel("selectorLabel"), f = e.getModel([
          "emphasis",
          "selectorLabel"
        ]);
        Jt(l, {
          normal: u,
          emphasis: f
        }, {
          defaultText: c.title
        }), ht(l);
      });
    }, i.prototype._createItem = function(t, e, a, n, r, h, o, c, d, l, u) {
      var f = t.visualDrawType, m = r.get("itemWidth"), p = r.get("itemHeight"), g = r.isSelected(e), y = n.get("symbolRotate"), v = n.get("symbolKeepAspect"), _ = n.get("icon");
      d = _ || d || "roundRect";
      var I = Be(d, n, o, c, f, g, u), b = new Z(), C = n.getModel("textStyle");
      if (dt(t.getLegendIcon) && (!_ || _ === "inherit")) b.add(t.getLegendIcon({
        itemWidth: m,
        itemHeight: p,
        icon: d,
        iconRotate: y,
        itemStyle: I.itemStyle,
        lineStyle: I.lineStyle,
        symbolKeepAspect: v
      }));
      else {
        var D = _ === "inherit" && t.getData().getVisual("symbol") ? y === "inherit" ? t.getData().getVisual("symbolRotate") : y : 0;
        b.add(Pe({
          itemWidth: m,
          itemHeight: p,
          icon: d,
          iconRotate: D,
          itemStyle: I.itemStyle,
          symbolKeepAspect: v
        }));
      }
      var x = h === "left" ? m + 5 : -5, T = h, S = r.get("formatter"), B = e;
      Y(S) && S ? B = S.replace("{name}", e ?? "") : dt(S) && (B = S(e));
      var R = g ? C.getTextColor() : n.get("inactiveColor");
      b.add(new et({
        style: Yt(C, {
          text: B,
          x,
          y: p / 2,
          fill: R,
          align: T,
          verticalAlign: "middle"
        }, {
          inheritColor: R
        })
      }));
      var P = new Ct({
        shape: b.getBoundingRect(),
        style: {
          fill: "transparent"
        }
      }), A = n.getModel("tooltip");
      return A.get("show") && qt({
        el: P,
        componentModel: r,
        itemName: e,
        itemTooltipOption: A.option
      }), b.add(P), b.eachChild(function(H) {
        H.silent = true;
      }), P.silent = !l, this.getContentGroup().add(b), ht(b), b.__legendDataIndex = a, b;
    }, i.prototype.layoutInner = function(t, e, a, n, r, h) {
      var o = this.getContentGroup(), c = this.getSelectorGroup();
      E(t.get("orient"), o, t.get("itemGap"), a.width, a.height);
      var d = o.getBoundingRect(), l = [
        -d.x,
        -d.y
      ];
      if (c.markRedraw(), o.markRedraw(), r) {
        E("horizontal", c, t.get("selectorItemGap", true));
        var u = c.getBoundingRect(), f = [
          -u.x,
          -u.y
        ], m = t.get("selectorButtonGap", true), p = t.getOrient().index, g = p === 0 ? "width" : "height", y = p === 0 ? "height" : "width", v = p === 0 ? "y" : "x";
        h === "end" ? f[p] += d[g] + m : l[p] += u[g] + m, f[1 - p] += d[y] / 2 - u[y] / 2, c.x = f[0], c.y = f[1], o.x = l[0], o.y = l[1];
        var _ = {
          x: 0,
          y: 0
        };
        return _[g] = d[g] + m + u[g], _[y] = Math.max(d[y], u[y]), _[v] = Math.min(0, u[v] + f[1 - p]), _;
      } else return o.x = l[0], o.y = l[1], this.group.getBoundingRect();
    }, i.prototype.remove = function() {
      this.getContentGroup().removeAll(), this._isFirstRender = true;
    }, i.type = "legend.plain", i;
  })(Kt);
  function Be(s, i, t, e, a, n, r) {
    function h(g, y) {
      g.lineWidth === "auto" && (g.lineWidth = y.lineWidth > 0 ? 2 : 0), nt(g, function(v, _) {
        g[_] === "inherit" && (g[_] = y[_]);
      });
    }
    var o = i.getModel("itemStyle"), c = o.getItemStyle(), d = s.lastIndexOf("empty", 0) === 0 ? "fill" : "stroke", l = o.getShallow("decal");
    c.decal = !l || l === "inherit" ? e.decal : Xt(l, r), c.fill === "inherit" && (c.fill = e[a]), c.stroke === "inherit" && (c.stroke = e[d]), c.opacity === "inherit" && (c.opacity = (a === "fill" ? e : t).opacity), h(c, e);
    var u = i.getModel("lineStyle"), f = u.getLineStyle();
    if (h(f, t), c.fill === "auto" && (c.fill = e.fill), c.stroke === "auto" && (c.stroke = e.fill), f.stroke === "auto" && (f.stroke = e.fill), !n) {
      var m = i.get("inactiveBorderWidth"), p = c[d];
      c.lineWidth = m === "auto" ? e.lineWidth > 0 && p ? 2 : 0 : c.lineWidth, c.fill = i.get("inactiveColor"), c.stroke = i.get("inactiveBorderColor"), f.stroke = u.get("inactiveColor"), f.lineWidth = u.get("inactiveWidth");
    }
    return {
      itemStyle: c,
      lineStyle: f
    };
  }
  function Pe(s) {
    var i = s.icon || "roundRect", t = Qt(i, 0, 0, s.itemWidth, s.itemHeight, s.itemStyle.fill, s.symbolKeepAspect);
    return t.setStyle(s.itemStyle), t.rotation = (s.iconRotate || 0) * Math.PI / 180, t.setOrigin([
      s.itemWidth / 2,
      s.itemHeight / 2
    ]), i.indexOf("empty") > -1 && (t.style.stroke = t.style.fill, t.style.fill = "#fff", t.style.lineWidth = 2), t;
  }
  function pt(s, i, t, e) {
    st(s, i, t, e), t.dispatchAction({
      type: "legendToggleSelect",
      name: s ?? i
    }), rt(s, i, t, e);
  }
  function Lt(s) {
    for (var i = s.getZr().storage.getDisplayList(), t, e = 0, a = i.length; e < a && !(t = i[e].states.emphasis); ) e++;
    return t && t.hoverLayer;
  }
  function rt(s, i, t, e) {
    Lt(t) || t.dispatchAction({
      type: "highlight",
      seriesName: s,
      name: i,
      excludeSeriesId: e
    });
  }
  function st(s, i, t, e) {
    Lt(t) || t.dispatchAction({
      type: "downplay",
      seriesName: s,
      name: i,
      excludeSeriesId: e
    });
  }
  function je(s) {
    var i = s.findComponents({
      mainType: "legend"
    });
    i && i.length && s.filterSeries(function(t) {
      for (var e = 0; e < i.length; e++) if (!i[e].isSelected(t.name)) return false;
      return true;
    });
  }
  function F(s, i, t) {
    var e = s === "allSelect" || s === "inverseSelect", a = {}, n = [];
    t.eachComponent({
      mainType: "legend",
      query: i
    }, function(h) {
      e ? h[s]() : h[s](i.name), ft(h, a), n.push(h.componentIndex);
    });
    var r = {};
    return t.eachComponent("legend", function(h) {
      G(a, function(o, c) {
        h[o ? "select" : "unSelect"](c);
      }), ft(h, r);
    }), e ? {
      selected: r,
      legendIndex: n
    } : {
      name: i.name,
      selected: r
    };
  }
  function ft(s, i) {
    var t = i || {};
    return G(s.getData(), function(e) {
      var a = e.get("name");
      if (!(a === `
` || a === "")) {
        var n = s.isSelected(a);
        Mt(t, a) ? t[a] = t[a] && n : t[a] = n;
      }
    }), t;
  }
  function Ge(s) {
    s.registerAction("legendToggleSelect", "legendselectchanged", W(F, "toggleSelected")), s.registerAction("legendAllSelect", "legendselectall", W(F, "allSelect")), s.registerAction("legendInverseSelect", "legendinverseselect", W(F, "inverseSelect")), s.registerAction("legendSelect", "legendselected", W(F, "select")), s.registerAction("legendUnSelect", "legendunselected", W(F, "unSelect"));
  }
  function Rt(s) {
    s.registerComponentModel(at), s.registerComponentView(St), s.registerProcessor(s.PRIORITY.PROCESSOR.SERIES_FILTER, je), s.registerSubTypeDefaulter("legend", function() {
      return "plain";
    }), Ge(s);
  }
  var He = (function(s) {
    K(i, s);
    function i() {
      var t = s !== null && s.apply(this, arguments) || this;
      return t.type = i.type, t;
    }
    return i.prototype.setScrollDataIndex = function(t) {
      this.option.scrollDataIndex = t;
    }, i.prototype.init = function(t, e, a) {
      var n = te(t);
      s.prototype.init.call(this, t, e, a), gt(this, t, n);
    }, i.prototype.mergeOption = function(t, e) {
      s.prototype.mergeOption.call(this, t, e), gt(this, this.option, t);
    }, i.type = "legend.scroll", i.defaultOption = ee(at.defaultOption, {
      scrollDataIndex: 0,
      pageButtonItemGap: 5,
      pageButtonGap: null,
      pageButtonPosition: "end",
      pageFormatter: "{current}/{total}",
      pageIcons: {
        horizontal: [
          "M0,0L12,-10L12,10z",
          "M0,0L-12,-10L-12,10z"
        ],
        vertical: [
          "M0,0L20,0L10,-20z",
          "M0,0L20,0L10,20z"
        ]
      },
      pageIconColor: "#2f4554",
      pageIconInactiveColor: "#aaa",
      pageIconSize: 15,
      pageTextStyle: {
        color: "#333"
      },
      animationDurationUpdate: 800
    }), i;
  })(at);
  function gt(s, i, t) {
    var e = s.getOrient(), a = [
      1,
      1
    ];
    a[e.index] = 0, ie(i, t, {
      type: "box",
      ignoreSize: !!a
    });
  }
  var mt = bt, X = [
    "width",
    "height"
  ], Q = [
    "x",
    "y"
  ], Ae = (function(s) {
    K(i, s);
    function i() {
      var t = s !== null && s.apply(this, arguments) || this;
      return t.type = i.type, t.newlineDisabled = true, t._currentIndex = 0, t;
    }
    return i.prototype.init = function() {
      s.prototype.init.call(this), this.group.add(this._containerGroup = new mt()), this._containerGroup.add(this.getContentGroup()), this.group.add(this._controllerGroup = new mt());
    }, i.prototype.resetInner = function() {
      s.prototype.resetInner.call(this), this._controllerGroup.removeAll(), this._containerGroup.removeClipPath(), this._containerGroup.__rectSize = null;
    }, i.prototype.renderInner = function(t, e, a, n, r, h, o) {
      var c = this;
      s.prototype.renderInner.call(this, t, e, a, n, r, h, o);
      var d = this._controllerGroup, l = e.get("pageIconSize", true), u = _t(l) ? l : [
        l,
        l
      ];
      m("pagePrev", 0);
      var f = e.getModel("pageTextStyle");
      d.add(new et({
        name: "pageText",
        style: {
          text: "xx/xx",
          fill: f.getTextColor(),
          font: f.getFont(),
          verticalAlign: "middle",
          align: "center"
        },
        silent: true
      })), m("pageNext", 1);
      function m(p, g) {
        var y = p + "DataIndex", v = ae(e.get("pageIcons", true)[e.getOrient().name][g], {
          onclick: ne(c._pageGo, c, y, e, n)
        }, {
          x: -u[0] / 2,
          y: -u[1] / 2,
          width: u[0],
          height: u[1]
        });
        v.name = p, d.add(v);
      }
    }, i.prototype.layoutInner = function(t, e, a, n, r, h) {
      var o = this.getSelectorGroup(), c = t.getOrient().index, d = X[c], l = Q[c], u = X[1 - c], f = Q[1 - c];
      r && E("horizontal", o, t.get("selectorItemGap", true));
      var m = t.get("selectorButtonGap", true), p = o.getBoundingRect(), g = [
        -p.x,
        -p.y
      ], y = re(a);
      r && (y[d] = a[d] - p[d] - m);
      var v = this._layoutContentAndController(t, n, y, c, d, u, f, l);
      if (r) {
        if (h === "end") g[c] += v[d] + m;
        else {
          var _ = p[d] + m;
          g[c] -= _, v[l] -= _;
        }
        v[d] += p[d] + m, g[1 - c] += v[f] + v[u] / 2 - p[u] / 2, v[u] = Math.max(v[u], p[u]), v[f] = Math.min(v[f], p[f] + g[1 - c]), o.x = g[0], o.y = g[1], o.markRedraw();
      }
      return v;
    }, i.prototype._layoutContentAndController = function(t, e, a, n, r, h, o, c) {
      var d = this.getContentGroup(), l = this._containerGroup, u = this._controllerGroup;
      E(t.get("orient"), d, t.get("itemGap"), n ? a.width : null, n ? null : a.height), E("horizontal", u, t.get("pageButtonItemGap", true));
      var f = d.getBoundingRect(), m = u.getBoundingRect(), p = this._showController = f[r] > a[r], g = [
        -f.x,
        -f.y
      ];
      e || (g[n] = d[c]);
      var y = [
        0,
        0
      ], v = [
        -m.x,
        -m.y
      ], _ = se(t.get("pageButtonGap", true), t.get("itemGap", true));
      if (p) {
        var I = t.get("pageButtonPosition", true);
        I === "end" ? v[n] += a[r] - m[r] : y[n] += m[r] + _;
      }
      v[1 - n] += f[h] / 2 - m[h] / 2, d.setPosition(g), l.setPosition(y), u.setPosition(v);
      var b = {
        x: 0,
        y: 0
      };
      if (b[r] = p ? a[r] : f[r], b[h] = Math.max(f[h], m[h]), b[o] = Math.min(0, m[o] + v[1 - n]), l.__rectSize = a[r], p) {
        var C = {
          x: 0,
          y: 0
        };
        C[r] = Math.max(a[r] - m[r] - _, 0), C[h] = b[h], l.setClipPath(new Ct({
          shape: C
        })), l.__rectSize = C[r];
      } else u.eachChild(function(x) {
        x.attr({
          invisible: true,
          silent: true
        });
      });
      var D = this._getPageInfo(t);
      return D.pageIndex != null && oe(d, {
        x: D.contentPosition[0],
        y: D.contentPosition[1]
      }, p ? t : null), this._updatePageInfoView(t, D), b;
    }, i.prototype._pageGo = function(t, e, a) {
      var n = this._getPageInfo(e)[t];
      n != null && a.dispatchAction({
        type: "legendScroll",
        scrollDataIndex: n,
        legendId: e.id
      });
    }, i.prototype._updatePageInfoView = function(t, e) {
      var a = this._controllerGroup;
      G([
        "pagePrev",
        "pageNext"
      ], function(d) {
        var l = d + "DataIndex", u = e[l] != null, f = a.childOfName(d);
        f && (f.setStyle("fill", u ? t.get("pageIconColor", true) : t.get("pageIconInactiveColor", true)), f.cursor = u ? "pointer" : "default");
      });
      var n = a.childOfName("pageText"), r = t.get("pageFormatter"), h = e.pageIndex, o = h != null ? h + 1 : 0, c = e.pageCount;
      n && r && n.setStyle("text", Y(r) ? r.replace("{current}", o == null ? "" : o + "").replace("{total}", c == null ? "" : c + "") : r({
        current: o,
        total: c
      }));
    }, i.prototype._getPageInfo = function(t) {
      var e = t.get("scrollDataIndex", true), a = this.getContentGroup(), n = this._containerGroup.__rectSize, r = t.getOrient().index, h = X[r], o = Q[r], c = this._findTargetItemIndex(e), d = a.children(), l = d[c], u = d.length, f = u ? 1 : 0, m = {
        contentPosition: [
          a.x,
          a.y
        ],
        pageCount: f,
        pageIndex: f - 1,
        pagePrevDataIndex: null,
        pageNextDataIndex: null
      };
      if (!l) return m;
      var p = I(l);
      m.contentPosition[r] = -p.s;
      for (var g = c + 1, y = p, v = p, _ = null; g <= u; ++g) _ = I(d[g]), (!_ && v.e > y.s + n || _ && !b(_, y.s)) && (v.i > y.i ? y = v : y = _, y && (m.pageNextDataIndex == null && (m.pageNextDataIndex = y.i), ++m.pageCount)), v = _;
      for (var g = c - 1, y = p, v = p, _ = null; g >= -1; --g) _ = I(d[g]), (!_ || !b(v, _.s)) && y.i < v.i && (v = y, m.pagePrevDataIndex == null && (m.pagePrevDataIndex = y.i), ++m.pageCount, ++m.pageIndex), y = _;
      return m;
      function I(C) {
        if (C) {
          var D = C.getBoundingRect(), x = D[o] + C[o];
          return {
            s: x,
            e: x + D[h],
            i: C.__legendDataIndex
          };
        }
      }
      function b(C, D) {
        return C.e >= D && C.s <= D + n;
      }
    }, i.prototype._findTargetItemIndex = function(t) {
      if (!this._showController) return 0;
      var e, a = this.getContentGroup(), n;
      return a.eachChild(function(r, h) {
        var o = r.__legendDataIndex;
        n == null && o != null && (n = h), o === t && (e = h);
      }), e ?? n;
    }, i.type = "legend.scroll", i;
  })(St);
  function Oe(s) {
    s.registerAction("legendScroll", "legendscroll", function(i, t) {
      var e = i.scrollDataIndex;
      e != null && t.eachComponent({
        mainType: "legend",
        subType: "scroll",
        query: i
      }, function(a) {
        a.setScrollDataIndex(e);
      });
    });
  }
  function ze(s) {
    q(Rt), s.registerComponentModel(He), s.registerComponentView(Ae), Oe(s);
  }
  function We(s) {
    q(Rt), q(ze);
  }
  function vt(s, i, t) {
    var e = de.createCanvas(), a = i.getWidth(), n = i.getHeight(), r = e.style;
    return r && (r.position = "absolute", r.left = "0", r.top = "0", r.width = a + "px", r.height = n + "px", e.setAttribute("data-zr-dom-id", s)), e.width = a * t, e.height = n * t, e;
  }
  var M = (function(s) {
    le(i, s);
    function i(t, e, a) {
      var n = s.call(this) || this;
      n.motionBlur = false, n.lastFrameAlpha = 0.7, n.dpr = 1, n.virtual = false, n.config = {}, n.incremental = false, n.zlevel = 0, n.maxRepaintRectCount = 5, n.__dirty = true, n.__firstTimePaint = true, n.__used = false, n.__drawIndex = 0, n.__startIndex = 0, n.__endIndex = 0, n.__prevStartIndex = null, n.__prevEndIndex = null;
      var r;
      a = a || It, typeof t == "string" ? r = vt(t, e, a) : ce(t) && (r = t, t = r.id), n.id = t, n.dom = r;
      var h = r.style;
      return h && (wt(r), r.onselectstart = function() {
        return false;
      }, h.padding = "0", h.margin = "0", h.borderWidth = "0"), n.painter = e, n.dpr = a, n;
    }
    return i.prototype.getElementCount = function() {
      return this.__endIndex - this.__startIndex;
    }, i.prototype.afterBrush = function() {
      this.__prevStartIndex = this.__startIndex, this.__prevEndIndex = this.__endIndex;
    }, i.prototype.initContext = function() {
      this.ctx = this.dom.getContext("2d"), this.ctx.dpr = this.dpr;
    }, i.prototype.setUnpainted = function() {
      this.__firstTimePaint = true;
    }, i.prototype.createBackBuffer = function() {
      var t = this.dpr;
      this.domBack = vt("back-" + this.id, this.painter, t), this.ctxBack = this.domBack.getContext("2d"), t !== 1 && this.ctxBack.scale(t, t);
    }, i.prototype.createRepaintRects = function(t, e, a, n) {
      if (this.__firstTimePaint) return this.__firstTimePaint = false, null;
      var r = [], h = this.maxRepaintRectCount, o = false, c = new $(0, 0, 0, 0);
      function d(v) {
        if (!(!v.isFinite() || v.isZero())) if (r.length === 0) {
          var _ = new $(0, 0, 0, 0);
          _.copy(v), r.push(_);
        } else {
          for (var I = false, b = 1 / 0, C = 0, D = 0; D < r.length; ++D) {
            var x = r[D];
            if (x.intersect(v)) {
              var T = new $(0, 0, 0, 0);
              T.copy(x), T.union(v), r[D] = T, I = true;
              break;
            } else if (o) {
              c.copy(v), c.union(x);
              var S = v.width * v.height, B = x.width * x.height, R = c.width * c.height, P = R - S - B;
              P < b && (b = P, C = D);
            }
          }
          if (o && (r[C].union(v), I = true), !I) {
            var _ = new $(0, 0, 0, 0);
            _.copy(v), r.push(_);
          }
          o || (o = r.length >= h);
        }
      }
      for (var l = this.__startIndex; l < this.__endIndex; ++l) {
        var u = t[l];
        if (u) {
          var f = u.shouldBePainted(a, n, true, true), m = u.__isRendered && (u.__dirty & it || !f) ? u.getPrevPaintRect() : null;
          m && d(m);
          var p = f && (u.__dirty & it || !u.__isRendered) ? u.getPaintRect() : null;
          p && d(p);
        }
      }
      for (var l = this.__prevStartIndex; l < this.__prevEndIndex; ++l) {
        var u = e[l], f = u && u.shouldBePainted(a, n, true, true);
        if (u && (!f || !u.__zr) && u.__isRendered) {
          var m = u.getPrevPaintRect();
          m && d(m);
        }
      }
      var g;
      do {
        g = false;
        for (var l = 0; l < r.length; ) {
          if (r[l].isZero()) {
            r.splice(l, 1);
            continue;
          }
          for (var y = l + 1; y < r.length; ) r[l].intersect(r[y]) ? (g = true, r[l].union(r[y]), r.splice(y, 1)) : y++;
          l++;
        }
      } while (g);
      return this._paintRects = r, r;
    }, i.prototype.debugGetPaintRects = function() {
      return (this._paintRects || []).slice();
    }, i.prototype.resize = function(t, e) {
      var a = this.dpr, n = this.dom, r = n.style, h = this.domBack;
      r && (r.width = t + "px", r.height = e + "px"), n.width = t * a, n.height = e * a, h && (h.width = t * a, h.height = e * a, a !== 1 && this.ctxBack.scale(a, a));
    }, i.prototype.clear = function(t, e, a) {
      var n = this.dom, r = this.ctx, h = n.width, o = n.height;
      e = e || this.clearColor;
      var c = this.motionBlur && !t, d = this.lastFrameAlpha, l = this.dpr, u = this;
      c && (this.domBack || this.createBackBuffer(), this.ctxBack.globalCompositeOperation = "copy", this.ctxBack.drawImage(n, 0, 0, h / l, o / l));
      var f = this.domBack;
      function m(p, g, y, v) {
        if (r.clearRect(p, g, y, v), e && e !== "transparent") {
          var _ = void 0;
          if (ue(e)) {
            var I = e.global || e.__width === y && e.__height === v;
            _ = I && e.__canvasGradient || pe(r, e, {
              x: 0,
              y: 0,
              width: y,
              height: v
            }), e.__canvasGradient = _, e.__width = y, e.__height = v;
          } else fe(e) && (e.scaleX = e.scaleX || l, e.scaleY = e.scaleY || l, _ = ge(r, e, {
            dirty: function() {
              u.setUnpainted(), u.painter.refresh();
            }
          }));
          r.save(), r.fillStyle = _ || e, r.fillRect(p, g, y, v), r.restore();
        }
        c && (r.save(), r.globalAlpha = d, r.drawImage(f, p, g, y, v), r.restore());
      }
      !a || c ? m(0, 0, h, o) : a.length && G(a, function(p) {
        m(p.x * l, p.y * l, p.width * l, p.height * l);
      });
    }, i;
  })(he), yt = 1e5, O = 314159, J = 0.01, Fe = 1e-3;
  function Ve(s) {
    return s ? s.__builtin__ ? true : !(typeof s.resize != "function" || typeof s.refresh != "function") : false;
  }
  function Ee(s, i) {
    var t = document.createElement("div");
    return t.style.cssText = [
      "position:relative",
      "width:" + s + "px",
      "height:" + i + "px",
      "padding:0",
      "margin:0",
      "border-width:0"
    ].join(";") + ";", t;
  }
  var $e = (function() {
    function s(i, t, e, a) {
      this.type = "canvas", this._zlevelList = [], this._prevDisplayList = [], this._layers = {}, this._layerConfig = {}, this._needsManuallyCompositing = false, this.type = "canvas";
      var n = !i.nodeName || i.nodeName.toUpperCase() === "CANVAS";
      this._opts = e = tt({}, e || {}), this.dpr = e.devicePixelRatio || It, this._singleCanvas = n, this.root = i;
      var r = i.style;
      r && (wt(i), i.innerHTML = ""), this.storage = t;
      var h = this._zlevelList;
      this._prevDisplayList = [];
      var o = this._layers;
      if (n) {
        var d = i, l = d.width, u = d.height;
        e.width != null && (l = e.width), e.height != null && (u = e.height), this.dpr = e.devicePixelRatio || 1, d.width = l * this.dpr, d.height = u * this.dpr, this._width = l, this._height = u;
        var f = new M(d, this, this.dpr);
        f.__builtin__ = true, f.initContext(), o[O] = f, f.zlevel = O, h.push(O), this._domRoot = i;
      } else {
        this._width = U(i, 0, e), this._height = U(i, 1, e);
        var c = this._domRoot = Ee(this._width, this._height);
        i.appendChild(c);
      }
    }
    return s.prototype.getType = function() {
      return "canvas";
    }, s.prototype.isSingleCanvas = function() {
      return this._singleCanvas;
    }, s.prototype.getViewportRoot = function() {
      return this._domRoot;
    }, s.prototype.getViewportRootOffset = function() {
      var i = this.getViewportRoot();
      if (i) return {
        offsetLeft: i.offsetLeft || 0,
        offsetTop: i.offsetTop || 0
      };
    }, s.prototype.refresh = function(i) {
      var t = this.storage.getDisplayList(true), e = this._prevDisplayList, a = this._zlevelList;
      this._redrawId = Math.random(), this._paintList(t, e, i, this._redrawId);
      for (var n = 0; n < a.length; n++) {
        var r = a[n], h = this._layers[r];
        if (!h.__builtin__ && h.refresh) {
          var o = n === 0 ? this._backgroundColor : null;
          h.refresh(o);
        }
      }
      return this._opts.useDirtyRect && (this._prevDisplayList = t.slice()), this;
    }, s.prototype.refreshHover = function() {
      this._paintHoverList(this.storage.getDisplayList(false));
    }, s.prototype._paintHoverList = function(i) {
      var t = i.length, e = this._hoverlayer;
      if (e && e.clear(), !!t) {
        for (var a = {
          inHover: true,
          viewWidth: this._width,
          viewHeight: this._height
        }, n, r = 0; r < t; r++) {
          var h = i[r];
          h.__inHover && (e || (e = this._hoverlayer = this.getLayer(yt)), n || (n = e.ctx, n.save()), N(n, h, a, r === t - 1));
        }
        n && n.restore();
      }
    }, s.prototype.getHoverLayer = function() {
      return this.getLayer(yt);
    }, s.prototype.paintOne = function(i, t) {
      me(i, t);
    }, s.prototype._paintList = function(i, t, e, a) {
      if (this._redrawId === a) {
        e = e || false, this._updateLayerStatus(i);
        var n = this._doPaintList(i, t, e), r = n.finished, h = n.needsRefreshHover;
        if (this._needsManuallyCompositing && this._compositeManually(), h && this._paintHoverList(i), r) this.eachLayer(function(c) {
          c.afterBrush && c.afterBrush();
        });
        else {
          var o = this;
          ve(function() {
            o._paintList(i, t, e, a);
          });
        }
      }
    }, s.prototype._compositeManually = function() {
      var i = this.getLayer(O).ctx, t = this._domRoot.width, e = this._domRoot.height;
      i.clearRect(0, 0, t, e), this.eachBuiltinLayer(function(a) {
        a.virtual && i.drawImage(a.dom, 0, 0, t, e);
      });
    }, s.prototype._doPaintList = function(i, t, e) {
      for (var a = this, n = [], r = this._opts.useDirtyRect, h = 0; h < this._zlevelList.length; h++) {
        var o = this._zlevelList[h], c = this._layers[o];
        c.__builtin__ && c !== this._hoverlayer && (c.__dirty || e) && n.push(c);
      }
      for (var d = true, l = false, u = function(p) {
        var g = n[p], y = g.ctx, v = r && g.createRepaintRects(i, t, f._width, f._height), _ = e ? g.__startIndex : g.__drawIndex, I = !e && g.incremental && Date.now, b = I && Date.now(), C = g.zlevel === f._zlevelList[0] ? f._backgroundColor : null;
        if (g.__startIndex === g.__endIndex) g.clear(false, C, v);
        else if (_ === g.__startIndex) {
          var D = i[_];
          (!D.incremental || !D.notClear || e) && g.clear(false, C, v);
        }
        _ === -1 && (console.error("For some unknown reason. drawIndex is -1"), _ = g.__startIndex);
        var x, T = function(P) {
          var A = {
            inHover: false,
            allClipped: false,
            prevEl: null,
            viewWidth: a._width,
            viewHeight: a._height
          };
          for (x = _; x < g.__endIndex; x++) {
            var H = i[x];
            if (H.__inHover && (l = true), a._doPaintEl(H, g, r, P, A, x === g.__endIndex - 1), I) {
              var kt = Date.now() - b;
              if (kt > 15) break;
            }
          }
          A.prevElClipPaths && y.restore();
        };
        if (v) if (v.length === 0) x = g.__endIndex;
        else for (var S = f.dpr, B = 0; B < v.length; ++B) {
          var R = v[B];
          y.save(), y.beginPath(), y.rect(R.x * S, R.y * S, R.width * S, R.height * S), y.clip(), T(R), y.restore();
        }
        else y.save(), T(), y.restore();
        g.__drawIndex = x, g.__drawIndex < g.__endIndex && (d = false);
      }, f = this, m = 0; m < n.length; m++) u(m);
      return ye.wxa && G(this._layers, function(p) {
        p && p.ctx && p.ctx.draw && p.ctx.draw();
      }), {
        finished: d,
        needsRefreshHover: l
      };
    }, s.prototype._doPaintEl = function(i, t, e, a, n, r) {
      var h = t.ctx;
      if (e) {
        var o = i.getPaintRect();
        (!a || o && o.intersect(a)) && (N(h, i, n, r), i.setPrevPaintRect(o));
      } else N(h, i, n, r);
    }, s.prototype.getLayer = function(i, t) {
      this._singleCanvas && !this._needsManuallyCompositing && (i = O);
      var e = this._layers[i];
      return e || (e = new M("zr_" + i, this, this.dpr), e.zlevel = i, e.__builtin__ = true, this._layerConfig[i] ? V(e, this._layerConfig[i], true) : this._layerConfig[i - J] && V(e, this._layerConfig[i - J], true), t && (e.virtual = t), this.insertLayer(i, e), e.initContext()), e;
    }, s.prototype.insertLayer = function(i, t) {
      var e = this._layers, a = this._zlevelList, n = a.length, r = this._domRoot, h = null, o = -1;
      if (!e[i] && Ve(t)) {
        if (n > 0 && i > a[0]) {
          for (o = 0; o < n - 1 && !(a[o] < i && a[o + 1] > i); o++) ;
          h = e[a[o]];
        }
        if (a.splice(o + 1, 0, i), e[i] = t, !t.virtual) if (h) {
          var c = h.dom;
          c.nextSibling ? r.insertBefore(t.dom, c.nextSibling) : r.appendChild(t.dom);
        } else r.firstChild ? r.insertBefore(t.dom, r.firstChild) : r.appendChild(t.dom);
        t.painter || (t.painter = this);
      }
    }, s.prototype.eachLayer = function(i, t) {
      for (var e = this._zlevelList, a = 0; a < e.length; a++) {
        var n = e[a];
        i.call(t, this._layers[n], n);
      }
    }, s.prototype.eachBuiltinLayer = function(i, t) {
      for (var e = this._zlevelList, a = 0; a < e.length; a++) {
        var n = e[a], r = this._layers[n];
        r.__builtin__ && i.call(t, r, n);
      }
    }, s.prototype.eachOtherLayer = function(i, t) {
      for (var e = this._zlevelList, a = 0; a < e.length; a++) {
        var n = e[a], r = this._layers[n];
        r.__builtin__ || i.call(t, r, n);
      }
    }, s.prototype.getLayers = function() {
      return this._layers;
    }, s.prototype._updateLayerStatus = function(i) {
      this.eachBuiltinLayer(function(l, u) {
        l.__dirty = l.__used = false;
      });
      function t(l) {
        n && (n.__endIndex !== l && (n.__dirty = true), n.__endIndex = l);
      }
      if (this._singleCanvas) for (var e = 1; e < i.length; e++) {
        var a = i[e];
        if (a.zlevel !== i[e - 1].zlevel || a.incremental) {
          this._needsManuallyCompositing = true;
          break;
        }
      }
      var n = null, r = 0, h, o;
      for (o = 0; o < i.length; o++) {
        var a = i[o], c = a.zlevel, d = void 0;
        h !== c && (h = c, r = 0), a.incremental ? (d = this.getLayer(c + Fe, this._needsManuallyCompositing), d.incremental = true, r = 1) : d = this.getLayer(c + (r > 0 ? J : 0), this._needsManuallyCompositing), d.__builtin__ || _e("ZLevel " + c + " has been used by unkown layer " + d.id), d !== n && (d.__used = true, d.__startIndex !== o && (d.__dirty = true), d.__startIndex = o, d.incremental ? d.__drawIndex = -1 : d.__drawIndex = o, t(o), n = d), a.__dirty & it && !a.__inHover && (d.__dirty = true, d.incremental && d.__drawIndex < 0 && (d.__drawIndex = o));
      }
      t(o), this.eachBuiltinLayer(function(l, u) {
        !l.__used && l.getElementCount() > 0 && (l.__dirty = true, l.__startIndex = l.__endIndex = l.__drawIndex = 0), l.__dirty && l.__drawIndex < 0 && (l.__drawIndex = l.__startIndex);
      });
    }, s.prototype.clear = function() {
      return this.eachBuiltinLayer(this._clearLayer), this;
    }, s.prototype._clearLayer = function(i) {
      i.clear();
    }, s.prototype.setBackgroundColor = function(i) {
      this._backgroundColor = i, G(this._layers, function(t) {
        t.setUnpainted();
      });
    }, s.prototype.configLayer = function(i, t) {
      if (t) {
        var e = this._layerConfig;
        e[i] ? V(e[i], t, true) : e[i] = t;
        for (var a = 0; a < this._zlevelList.length; a++) {
          var n = this._zlevelList[a];
          if (n === i || n === i + J) {
            var r = this._layers[n];
            V(r, e[i], true);
          }
        }
      }
    }, s.prototype.delLayer = function(i) {
      var t = this._layers, e = this._zlevelList, a = t[i];
      a && (a.dom.parentNode.removeChild(a.dom), delete t[i], e.splice(Dt(e, i), 1));
    }, s.prototype.resize = function(i, t) {
      if (this._domRoot.style) {
        var e = this._domRoot;
        e.style.display = "none";
        var a = this._opts, n = this.root;
        if (i != null && (a.width = i), t != null && (a.height = t), i = U(n, 0, a), t = U(n, 1, a), e.style.display = "", this._width !== i || t !== this._height) {
          e.style.width = i + "px", e.style.height = t + "px";
          for (var r in this._layers) this._layers.hasOwnProperty(r) && this._layers[r].resize(i, t);
          this.refresh(true);
        }
        this._width = i, this._height = t;
      } else {
        if (i == null || t == null) return;
        this._width = i, this._height = t, this.getLayer(O).resize(i, t);
      }
      return this;
    }, s.prototype.clearLayer = function(i) {
      var t = this._layers[i];
      t && t.clear();
    }, s.prototype.dispose = function() {
      this.root.innerHTML = "", this.root = this.storage = this._domRoot = this._layers = null;
    }, s.prototype.getRenderedCanvas = function(i) {
      if (i = i || {}, this._singleCanvas && !this._compositeManually) return this._layers[O].dom;
      var t = new M("image", this, i.pixelRatio || this.dpr);
      t.initContext(), t.clear(false, i.backgroundColor || this._backgroundColor);
      var e = t.ctx;
      if (i.pixelRatio <= this.dpr) {
        this.refresh();
        var a = t.dom.width, n = t.dom.height;
        this.eachLayer(function(l) {
          l.__builtin__ ? e.drawImage(l.dom, 0, 0, a, n) : l.renderToCanvas && (e.save(), l.renderToCanvas(e), e.restore());
        });
      } else for (var r = {
        inHover: false,
        viewWidth: this._width,
        viewHeight: this._height
      }, h = this.storage.getDisplayList(true), o = 0, c = h.length; o < c; o++) {
        var d = h[o];
        N(e, d, r, o === c - 1);
      }
      return t.dom;
    }, s.prototype.getWidth = function() {
      return this._width;
    }, s.prototype.getHeight = function() {
      return this._height;
    }, s;
  })();
  function Ne(s) {
    s.registerPainter("canvas", $e);
  }
  q([
    be,
    Se,
    Le,
    Re,
    ke,
    Ce,
    We,
    Ne
  ]);
  const k = {
    chart: {
      height: "calc(100% - 40px)",
      width: "100%"
    },
    mainDiv: {
      marginLeft: 10,
      color: "rgba(243,177,31)",
      display: "inline-block",
      lineHeight: "24px"
    },
    temperatureValue: {
      verticalAlign: "middle",
      fontSize: 28
    },
    temperatureUnit: {
      paddingLeft: 5,
      opacity: 0.6,
      fontSize: 14,
      verticalAlign: "middle"
    },
    mainIcon: {
      verticalAlign: "middle",
      marginRight: 4,
      fontSize: 20,
      width: 20
    },
    secondaryDiv: {
      color: "rgba(77,134,255)",
      display: "inline-block",
      float: "right",
      marginRight: 12,
      lineHeight: "24px"
    },
    humidityValue: {
      verticalAlign: "middle"
    },
    humidityUnit: {
      paddingLeft: 5,
      opacity: 0.6,
      fontSize: 14,
      verticalAlign: "middle"
    },
    secondaryIcon: {
      verticalAlign: "middle",
      fontSize: 20,
      marginRight: 4
    },
    newValueLight: {
      animation: "vis-2-widgets-nils-fork-newValueAnimationLight 2s ease-in-out"
    },
    newValueDark: {
      animation: "vis-2-widgets-nils-fork-newValueAnimationDark 2s ease-in-out"
    },
    tooltip: {
      pointerEvents: "none"
    }
  };
  j = class extends L {
    refContainer = Tt.createRef();
    mainTimer;
    updateTimeout;
    lastRxData;
    constructor(i) {
      super(i), this.state = {
        ...this.state,
        showDialog: false,
        dialogTab: 0,
        isChart: false,
        containerHeight: 0,
        chartData: {}
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2Actual",
        visSet: "vis-2-widgets-nils-fork",
        visSetLabel: "set_label",
        visSetColor: "#0783ff",
        visWidgetLabel: "actual_value_with_chart",
        visName: "Actual values",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                noBinding: false
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "data.noCard === true"
              },
              {
                name: "timeInterval",
                label: "chart_time_interval",
                tooltip: "hours",
                type: "slider",
                min: 0,
                max: 48,
                step: 1,
                default: 12
              },
              {
                name: "updateInterval",
                label: "chart_update_interval",
                tooltip: "seconds",
                type: "slider",
                min: 10,
                max: 360,
                step: 1,
                default: 60
              }
            ]
          },
          {
            name: "main",
            label: "main_object",
            fields: [
              {
                label: "oid",
                name: "oid-main",
                type: "id"
              },
              {
                label: "title",
                name: "title-main",
                type: "text",
                noButton: true,
                hidden: '!data["oid-main"] || data["oid-main"] === "nothing_selected"'
              },
              {
                label: "icon",
                name: "icon-main",
                type: "icon64",
                hidden: '!data["oid-main"] || data["oid-main"] === "nothing_selected"'
              },
              {
                label: "unit",
                name: "unit-main",
                type: "text",
                noButton: true,
                hidden: '!data["oid-main"] || data["oid-main"] === "nothing_selected"'
              },
              {
                label: "hide_chart",
                name: "noChart",
                noBinding: false,
                type: "checkbox",
                hidden: '!data["oid-main"] || data["oid-main"] === "nothing_selected"'
              },
              {
                label: "color",
                name: "color-main",
                type: "color",
                hidden: '!data["oid-main"] || data["oid-main"] === "nothing_selected"'
              },
              {
                label: "font_size",
                name: "font-size-main",
                type: "slider",
                min: 1,
                max: 100,
                hidden: '!data["oid-main"] || data["oid-main"] === "nothing_selected"'
              },
              {
                label: "font_style",
                name: "font-style-main",
                type: "select",
                noTranslation: true,
                options: [
                  {
                    value: "normal",
                    label: "normal"
                  },
                  {
                    value: "italic",
                    label: "italic"
                  }
                ],
                hidden: '!data["oid-main"] || data["oid-main"] === "nothing_selected"'
              },
              {
                label: "digits_after_comma",
                name: "digits_after_comma_main",
                type: "number",
                min: 0,
                max: 10,
                hidden: '!data["oid-main"] || data["oid-main"] === "nothing_selected"'
              }
            ]
          },
          {
            name: "secondary",
            label: "secondary_object",
            fields: [
              {
                label: "oid",
                name: "oid-secondary",
                type: "id"
              },
              {
                label: "title",
                name: "title-secondary",
                type: "text",
                noButton: true,
                hidden: '!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"'
              },
              {
                label: "icon",
                name: "icon-secondary",
                type: "icon64",
                hidden: '!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"'
              },
              {
                label: "unit",
                name: "unit-secondary",
                type: "text",
                noButton: true,
                hidden: '!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"'
              },
              {
                label: "hide_chart",
                name: "noChart-secondary",
                noBinding: false,
                type: "checkbox",
                hidden: '!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"'
              },
              {
                label: "color",
                name: "color-secondary",
                type: "color",
                hidden: '!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"'
              },
              {
                label: "font_size",
                name: "font-size-secondary",
                type: "slider",
                min: 1,
                max: 100,
                hidden: '!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"'
              },
              {
                label: "font_style",
                name: "font-style-secondary",
                type: "select",
                noTranslation: true,
                options: [
                  {
                    value: "normal",
                    label: "normal"
                  },
                  {
                    value: "italic",
                    label: "italic"
                  }
                ],
                hidden: '!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"'
              },
              {
                label: "digits_after_comma",
                name: "digits_after_comma_secondary",
                type: "number",
                min: 0,
                max: 10,
                hidden: '!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"'
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_actual.png"
      };
    }
    getWidgetInfo() {
      return j.getWidgetInfo();
    }
    async getIcon(i, t) {
      var _a, _b;
      if (!t.common.icon && (t.type === "state" || t.type === "channel")) {
        const e = i.split("."), a = await this.props.context.socket.getObject(e.slice(0, -1).join("."));
        if (!((_a = a == null ? void 0 : a.common) == null ? void 0 : _a.icon) && (t.type === "state" || t.type === "channel")) {
          const n = await this.props.context.socket.getObject(e.slice(0, -2).join("."));
          ((_b = n == null ? void 0 : n.common) == null ? void 0 : _b.icon) && (t.common.icon = n.common.icon, (n.type === "instance" || n.type === "adapter") && (t.common.icon = `../${n.common.name}.admin/${t.common.icon}`));
        } else t.common.icon = a.common.icon, (a.type === "instance" || a.type === "adapter") && (t.common.icon = `../${a.common.name}.admin/${t.common.icon}`);
      }
      if (t.common.icon && t.common.icon.startsWith("/")) {
        const e = i.split(".");
        t.common.icon = `../adapter/${e[0]}${t.common.icon}`;
      }
    }
    async propertiesUpdate() {
      var _a, _b, _c, _d, _e2, _f, _g, _h;
      const i = JSON.stringify(this.state.rxData);
      if (this.lastRxData === i) return;
      this.lastRxData = i;
      const t = {}, e = [];
      this.state.rxData["oid-main"] && this.state.rxData["oid-main"] !== "nothing_selected" && e.push(this.state.rxData["oid-main"]), this.state.rxData["oid-secondary"] && this.state.rxData["oid-secondary"] !== "nothing_selected" && e.push(this.state.rxData["oid-secondary"]);
      const a = e.length ? await this.props.context.socket.getObjectsById(e) : {};
      if (this.state.rxData["oid-main"] && this.state.rxData["oid-main"] !== "nothing_selected") {
        const l = a[this.state.rxData["oid-main"]];
        l ? (l.common || (l.common = {}), await this.getIcon(this.state.rxData["oid-main"], l), t.main = {
          common: l.common,
          _id: l._id
        }) : t.main = {
          common: {},
          _id: ""
        };
      }
      if (this.state.rxData["oid-secondary"] && this.state.rxData["oid-secondary"] !== "nothing_selected") {
        const l = a[this.state.rxData["oid-secondary"]];
        l ? (l.common = l.common || {}, await this.getIcon(this.state.rxData["oid-secondary"], l), t.secondary = {
          common: l.common,
          _id: l._id
        }) : t.secondary = {
          common: {},
          _id: ""
        };
      }
      const n = (_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory, r = L.getHistoryInstance(t.main, n), h = L.getHistoryInstance(t.secondary, n), o = this.state.rxData.noChart !== true && this.state.rxData.noChart !== "true" && !!r || this.state.rxData["noChart-secondary"] !== true && this.state.rxData["noChart-secondary"] !== "true" && !!h, c = {
        objects: t,
        isChart: o
      };
      this.mainTimer && (clearInterval(this.mainTimer), this.mainTimer = void 0);
      let d = false;
      this.state.rxData.noChart !== true && this.state.rxData.noChart !== "true" && r && ((_e2 = (_d = (_c = t.main) == null ? void 0 : _c.common) == null ? void 0 : _d.custom) == null ? void 0 : _e2[r]) ? (await this.readHistory(t.main._id, r), this.mainTimer || (this.mainTimer = setInterval(async () => {
        var _a2, _b2, _c2;
        await this.readHistory(this.state.objects.main._id, r), this.state.rxData["noChart-secondary"] !== true && this.state.rxData["noChart-secondary"] !== "true" && h && ((_c2 = (_b2 = (_a2 = this.state.objects.secondary) == null ? void 0 : _a2.common) == null ? void 0 : _b2.custom) == null ? void 0 : _c2[h]) && await this.readHistory(this.state.objects.secondary._id, h);
      }, parseInt(this.state.rxData.updateInterval, 10) * 1e3 || 6e4))) : this.state.chartData[this.state.rxData["oid-main"]] && (this.state.chartData[this.state.rxData["oid-main"]] = null, d = true), this.state.rxData["noChart-secondary"] !== true && this.state.rxData["noChart-secondary"] !== "true" && h && ((_h = (_g = (_f = t.secondary) == null ? void 0 : _f.common) == null ? void 0 : _g.custom) == null ? void 0 : _h[h]) ? (await this.readHistory(t.secondary._id, h), this.mainTimer || (this.mainTimer = setInterval(() => this.readHistory(this.state.objects.secondary._id, h), parseInt(this.state.rxData.updateInterval, 10) * 60 || 6e4))) : this.state.chartData[this.state.rxData["oid-secondary"]] && (this.state.chartData[this.state.rxData["oid-secondary"]] = null, d = true), (d || JSON.stringify(t) !== JSON.stringify(this.state.objects) || o !== this.state.isChart) && this.setState(c);
    }
    static convertData(i, t) {
      const e = [];
      if (!(i == null ? void 0 : i.length)) return e;
      for (let a = 0; a < i.length; a++) i[a].val === true ? i[a].val = 1 : i[a].val === false && (i[a].val = 0), e.push({
        value: [
          i[a].ts,
          i[a].val
        ]
      });
      return (t.min === void 0 || t.max === void 0) && (t.min = i[0].ts, t.max = i[i.length - 1].ts), e;
    }
    readHistory = (i, t) => {
      const e = this.state.rxData.timeInterval || 12, a = /* @__PURE__ */ new Date();
      a.setHours(a.getHours() - e), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
      const n = a.getTime(), r = Date.now(), h = {
        instance: t,
        start: n,
        end: r,
        step: 18e5,
        from: false,
        ack: false,
        q: false,
        addId: false,
        aggregate: "minmax"
      };
      let o;
      return this.props.context.socket.getHistory(i, h).then((c) => (o = c, this.props.context.socket.getState(i))).then((c) => {
        if ((o == null ? void 0 : o[0]) && o[0].ts !== n && o.unshift({
          ts: n,
          val: null
        }), o) {
          o.sort((f, m) => f.ts > m.ts ? 1 : f.ts < m.ts ? -1 : 0).filter((f) => f.val !== null), c && c.val !== null && c.val !== void 0 && o.push({
            ts: Date.now(),
            val: c.val
          });
          const d = {}, l = j.convertData(o, d), u = this.state.chartData;
          u[i] = {
            data: l,
            min: d.min,
            max: d.max
          }, this.setState({
            chartData: u
          });
        }
      }).catch((c) => console.error(`Cannot read history: ${c}`));
    };
    async componentDidMount() {
      super.componentDidMount(), await this.propertiesUpdate();
    }
    componentWillUnmount() {
      this.mainTimer && (clearInterval(this.mainTimer), this.mainTimer = void 0), super.componentWillUnmount();
    }
    async onRxDataChanged() {
      await this.propertiesUpdate();
    }
    static getColor(i, t) {
      let e, a, n;
      if (i.startsWith("#")) e = parseInt(i.substring(1, 3), 16), a = parseInt(i.substring(3, 5), 16), n = parseInt(i.substring(5, 7), 16);
      else if (i.startsWith("rgb(")) {
        const r = i.replace("rgb(", "").replace(")", "").split(",");
        e = parseInt(r[0], 10), a = parseInt(r[1], 10), n = parseInt(r[2], 10);
      } else if (i.startsWith("rgba(")) {
        const r = i.replace("rgba(", "").replace(")", "").split(",");
        e = parseInt(r[0], 10), a = parseInt(r[1], 10), n = parseInt(r[2], 10);
      }
      return `rgba(${e},${a},${n},${t})`;
    }
    getOptions() {
      var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l, _m, _n;
      const i = [];
      if (this.state.chartData[this.state.rxData["oid-main"]] && this.state.rxData.noChart !== true && this.state.rxData.noChart !== "true") {
        let e = this.state.rxData["title-main"] || L.getText(((_c = (_b = (_a = this.state.objects) == null ? void 0 : _a.main) == null ? void 0 : _b.common) == null ? void 0 : _c.name) || "");
        e || ((_g = (_f = (_e2 = (_d = this.state.objects) == null ? void 0 : _d.secondary) == null ? void 0 : _e2.common) == null ? void 0 : _f.role) == null ? void 0 : _g.includes("temperature")) && (e = L.t("temperature").replace("vis_2_widgets_nils_", ""));
        const a = j.getColor(this.state.rxData["color-main"] || "#F3B11F", 0.65), n = j.getColor(this.state.rxData["color-main"] || "#F3B11F", 0.14);
        i.push({
          areaStyle: {
            color: n
          },
          lineStyle: {
            color: a
          },
          type: "line",
          smooth: true,
          showSymbol: false,
          data: this.state.chartData[this.state.rxData["oid-main"]].data,
          name: e
        });
      }
      if (this.state.chartData[this.state.rxData["oid-secondary"]] && this.state.rxData["noData-secondary"] !== true && this.state.rxData["noData-secondary"] !== "true") {
        let e = this.state.rxData["title-secondary"] || L.getText(((_j = (_i = (_h = this.state.objects) == null ? void 0 : _h.secondary) == null ? void 0 : _i.common) == null ? void 0 : _j.name) || "");
        e || ((_n = (_m = (_l = (_k = this.state.objects) == null ? void 0 : _k.secondary) == null ? void 0 : _l.common) == null ? void 0 : _m.role) == null ? void 0 : _n.includes("humidity")) && (e = L.t("humidity").replace("vis_2_widgets_nils_", ""));
        const a = j.getColor(this.state.rxData["color-secondary"] || "#F3B11F", 0.65), n = j.getColor(this.state.rxData["color-secondary"] || "#F3B11F", 0.14);
        i.push({
          areaStyle: {
            color: n
          },
          lineStyle: {
            color: a
          },
          type: "line",
          smooth: true,
          showSymbol: false,
          data: this.state.chartData[this.state.rxData["oid-secondary"]].data,
          name: e
        });
      }
      return {
        animation: false,
        backgroundColor: "transparent",
        grid: {
          show: false,
          left: 0,
          top: 0,
          right: 0,
          bottom: 0
        },
        legend: void 0,
        calculable: true,
        xAxis: {
          show: false,
          boundaryGap: false,
          type: "time"
        },
        yAxis: {
          show: false
        },
        series: i
      };
    }
    componentDidUpdate() {
      this.refContainer.current && this.state.containerHeight !== this.refContainer.current.clientHeight && this.setState({
        containerHeight: this.refContainer.current.clientHeight
      });
    }
    renderDialog() {
      var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t2, _u, _v, _w, _x;
      if (!this.state.showDialog) return null;
      const i = j.getColor(this.state.rxData["color-main"] || "#F3B11F", 0.65), t = j.getColor(this.state.rxData["color-main"] || "#F3B11F", 0.14), e = j.getColor(this.state.rxData["color-secondary"] || "#F3B11F", 0.65), a = j.getColor(this.state.rxData["color-secondary"] || "#F3B11F", 0.14);
      return w.jsxs(Bt, {
        sx: {
          "& .MuiDialog-paper": {
            height: "100%"
          }
        },
        maxWidth: "lg",
        fullWidth: true,
        open: true,
        onClose: () => this.setState({
          showDialog: false
        }),
        children: [
          w.jsxs(Pt, {
            children: [
              this.state.rxData.widgetTitle,
              w.jsx(jt, {
                style: {
                  float: "right"
                },
                onClick: () => this.setState({
                  showDialog: false
                }),
                children: w.jsx(Ht, {})
              })
            ]
          }),
          w.jsx(Gt, {
            children: w.jsx(Ie, {
              t: (n) => L.t(n),
              lang: L.getLanguage(),
              socket: this.props.context.socket,
              obj: ((_a = this.state.objects) == null ? void 0 : _a.main) || ((_b = this.state.objects) == null ? void 0 : _b.secondary),
              obj2: ((_c = this.state.objects) == null ? void 0 : _c.main) ? (_d = this.state.objects) == null ? void 0 : _d.secondary : null,
              unit: ((_e2 = this.state.objects) == null ? void 0 : _e2.main) ? this.state.rxData["unit-main"] || ((_f = this.state.objects.main.common) == null ? void 0 : _f.unit) || "" : this.state.rxData["unit-secondary"] || ((_i = (_h = (_g = this.state.objects) == null ? void 0 : _g.secondary) == null ? void 0 : _h.common) == null ? void 0 : _i.unit) || "",
              unit2: this.state.rxData["unit-secondary"] || ((_l = (_k = (_j = this.state.objects) == null ? void 0 : _j.secondary) == null ? void 0 : _k.common) == null ? void 0 : _l.unit) || "",
              title: ((_m = this.state.objects) == null ? void 0 : _m.main) ? this.state.rxData["title-main"] || L.getText((_n = this.state.objects.main.common) == null ? void 0 : _n.name) : this.state.rxData["title-secondary"] || L.getText(((_q = (_p = (_o = this.state.objects) == null ? void 0 : _o.secondary) == null ? void 0 : _p.common) == null ? void 0 : _q.name) || ""),
              title2: this.state.rxData["title-secondary"] || L.getText(((_t2 = (_s = (_r = this.state.objects) == null ? void 0 : _r.secondary) == null ? void 0 : _s.common) == null ? void 0 : _t2.name) || ""),
              objLineType: "line",
              obj2LineType: "line",
              objColor: i,
              obj2Color: e,
              objBackgroundColor: t,
              obj2BackgroundColor: a,
              themeType: this.props.context.themeType,
              historyInstance: L.getHistoryInstance(this.state.objects.main || this.state.objects.secondary, ((_v = (_u = this.props.context.systemConfig) == null ? void 0 : _u.common) == null ? void 0 : _v.defaultHistory) || "history.0"),
              historyInstance2: L.getHistoryInstance(this.state.objects.secondary, ((_x = (_w = this.props.context.systemConfig) == null ? void 0 : _w.common) == null ? void 0 : _x.defaultHistory) || "history.0"),
              noToolbar: false,
              systemConfig: this.props.context.systemConfig,
              dateFormat: this.props.context.systemConfig.common.dateFormat,
              chartTitle: ""
            })
          })
        ]
      });
    }
    renderWidgetBody(i) {
      var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t2, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F;
      super.renderWidgetBody(i);
      const t = JSON.stringify(this.state.rxData);
      this.lastRxData !== t && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
        this.updateTimeout = void 0, await this.propertiesUpdate();
      }, 50)));
      const e = !this.state.showDialog && this.state.isChart ? (u) => {
        u == null ? void 0 : u.preventDefault(), u == null ? void 0 : u.stopPropagation(), this.setState({
          showDialog: true
        });
      } : void 0, a = this.props.context.themeType === "dark" ? k.newValueDark : k.newValueLight, n = ((_a = this.state.objects) == null ? void 0 : _a.main) && this.state.values[`${this.state.rxData["oid-main"]}.val`] !== void 0 ? this.formatValue(this.state.values[`${this.state.rxData["oid-main"]}.val`], this.state.rxData.digits_after_comma_main) : void 0, r = ((_b = this.state.objects) == null ? void 0 : _b.secondary) && this.state.values[`${this.state.rxData["oid-secondary"]}.val`] !== void 0 ? this.formatValue(this.state.values[`${this.state.rxData["oid-secondary"]}.val`], this.state.rxData.digits_after_comma_secondary) : void 0;
      let h = this.state.rxData["icon-main"] || ((_e2 = (_d = (_c = this.state.objects) == null ? void 0 : _c.main) == null ? void 0 : _d.common) == null ? void 0 : _e2.icon);
      h ? h = w.jsx(ut, {
        src: h,
        style: {
          ...k.mainIcon,
          width: 24,
          color: this.state.rxData["color-main"]
        }
      }) : ((_i = (_h = (_g = (_f = this.state.objects) == null ? void 0 : _f.main) == null ? void 0 : _g.common) == null ? void 0 : _h.role) == null ? void 0 : _i.includes("temperature")) || ((_m = (_l = (_k = (_j = this.state.objects) == null ? void 0 : _j.main) == null ? void 0 : _k.common) == null ? void 0 : _l.unit) == null ? void 0 : _m.includes("\xB0")) ? h = w.jsx(At, {
        style: k.mainIcon
      }) : h = null;
      let o = this.state.rxData["icon-secondary"] || ((_p = (_o = (_n = this.state.objects) == null ? void 0 : _n.secondary) == null ? void 0 : _o.common) == null ? void 0 : _p.icon);
      o ? o = w.jsx(ut, {
        src: o,
        style: {
          ...k.secondaryIcon,
          width: 20,
          color: this.state.rxData["color-secondary"]
        }
      }) : ((_t2 = (_s = (_r = (_q = this.state.objects) == null ? void 0 : _q.secondary) == null ? void 0 : _r.common) == null ? void 0 : _s.role) == null ? void 0 : _t2.includes("humidity")) ? o = w.jsx(Ot, {
        style: k.secondaryIcon
      }) : o = null;
      const c = parseInt(this.state.rxData["font-size-main"], 10) || 0, d = parseInt(this.state.rxData["font-size-secondary"], 10) || 0, l = w.jsxs("div", {
        style: {
          width: "100%",
          height: this.state.rxData.noCard !== true && this.state.rxData.noCard !== "true" && !i.widget.usedInWidget && this.state.rxData.widgetTitle ? "calc(100% - 32px)" : "100%"
        },
        ref: this.refContainer,
        children: [
          w.jsx("style", {
            children: `
@keyframes vis-2-widgets-nils-fork-newValueAnimationLight {
    0% {
        color: #00bd00;
    }
    80% {
        color: #008000;
    }
    100% {
        color: rgba(243,177,31);
    }
}
@keyframes vis-2-widgets-nils-fork-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: rgba(243,177,31);
    }
}                
                `
          }),
          n !== void 0 ? w.jsx(ot, {
            title: this.state.rxData["title-main"] || L.getText(((_w = (_v = (_u = this.state.objects) == null ? void 0 : _u.main) == null ? void 0 : _v.common) == null ? void 0 : _w.name) || "") || null,
            slotProps: {
              popper: {
                sx: k.tooltip
              }
            },
            children: w.jsxs("div", {
              style: k.mainDiv,
              children: [
                h,
                w.jsx("span", {
                  style: {
                    ...k.temperatureValue,
                    ...a,
                    fontSize: c || void 0,
                    fontStyle: this.state.rxData["font-style-main"],
                    color: this.state.rxData["color-main"]
                  },
                  children: n
                }, `${n}valText`),
                w.jsx("span", {
                  style: {
                    ...k.temperatureUnit,
                    fontSize: c ? c * 0.5 : void 0,
                    fontStyle: this.state.rxData["font-style-main"],
                    color: this.state.rxData["color-main"]
                  },
                  children: this.state.rxData["unit-main"] || ((_z = (_y = (_x = this.state.objects) == null ? void 0 : _x.main) == null ? void 0 : _y.common) == null ? void 0 : _z.unit)
                })
              ]
            })
          }) : null,
          r !== void 0 ? w.jsx(ot, {
            title: this.state.rxData["title-secondary"] || L.getText(((_C = (_B = (_A = this.state.objects) == null ? void 0 : _A.secondary) == null ? void 0 : _B.common) == null ? void 0 : _C.name) || "") || null,
            slotProps: {
              popper: {
                sx: k.tooltip
              }
            },
            children: w.jsxs("div", {
              style: k.secondaryDiv,
              children: [
                o,
                w.jsx("span", {
                  style: {
                    ...k.humidityValue,
                    ...a,
                    fontSize: d || void 0,
                    fontStyle: this.state.rxData["font-style-secondary"],
                    color: this.state.rxData["color-secondary"]
                  },
                  children: r
                }, `${r}valText`),
                w.jsx("span", {
                  style: {
                    ...k.humidityUnit,
                    fontSize: d ? d / 2 : void 0,
                    fontStyle: this.state.rxData["font-style-secondary"],
                    color: this.state.rxData["color-secondary"]
                  },
                  children: this.state.rxData["unit-secondary"] || ((_F = (_E = (_D = this.state.objects) == null ? void 0 : _D.secondary) == null ? void 0 : _E.common) == null ? void 0 : _F.unit)
                })
              ]
            })
          }) : null,
          this.state.containerHeight && (this.state.chartData[this.state.rxData["oid-main"]] || this.state.chartData[this.state.rxData["oid-secondary"]]) ? w.jsx(xe, {
            echarts: De,
            option: this.getOptions(),
            notMerge: true,
            lazyUpdate: true,
            theme: this.props.context.themeType === "dark" ? "dark" : "",
            style: {
              ...k.chart,
              height: this.state.containerHeight - 26,
              width: "100%"
            }
          }) : null,
          this.renderDialog()
        ]
      });
      return this.state.rxData.noCard === true || this.state.rxData.noCard === "true" || i.widget.usedInWidget ? l : this.wrapContent(l, null, {
        paddingLeft: 0,
        paddingRight: 0,
        paddingBottom: 0,
        height: "calc(100% - 16px)"
      }, {
        paddingLeft: 16
      }, e);
    }
  };
});
export {
  __tla,
  j as default
};
