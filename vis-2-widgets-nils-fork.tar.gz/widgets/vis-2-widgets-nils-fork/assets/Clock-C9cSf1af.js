import { j as o, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { _ as x, a as k, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { G as C } from "./Generic-DDdmRdK-.js";
import { __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
let h;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  const S = 90, m = (a) => a * 30 - S, b = (a) => a * 6, v = [
    12,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11
  ], c = {
    analogClockBase: {
      borderRadius: "50%",
      borderStyle: "solid",
      display: "flex",
      justifyContent: "center",
      alignItems: "center"
    },
    analogClockBaseCenter: {
      borderRadius: "50%",
      zIndex: 2
    },
    tickLabel: {
      position: "absolute",
      borderRadius: 2,
      transformOrigin: "center"
    },
    hourLabel: {
      position: "absolute",
      display: "flex",
      transformOrigin: "center"
    },
    hourLabelSpan: {
      fontWeight: 500
    }
  };
  class w extends x {
    render() {
      const t = Math.round(0.064 * this.props.size), e = Math.round(0.036 * this.props.size);
      return o.jsxs("div", {
        style: {
          ...c.analogClockBase,
          width: this.props.size,
          height: this.props.size,
          backgroundColor: this.props.backgroundColor,
          borderColor: this.props.ticksColor,
          borderWidth: this.props.size * 0.012
        },
        children: [
          o.jsx("div", {
            style: {
              ...c.analogClockBaseCenter,
              backgroundColor: this.props.withSeconds ? this.props.secondHandColor : this.props.handsColor,
              width: this.props.size * 0.05,
              height: this.props.size * 0.05
            }
          }),
          Array.from(Array(60)).map((i, s) => o.jsx("div", {
            style: {
              ...c.tickLabel,
              width: s % 5 ? Math.round(e / 2) : e,
              height: s % 5 ? Math.round(e / 9) : Math.round(e / 3),
              backgroundColor: this.props.ticksColor,
              transform: `rotate(${b(s)}deg) translateX(${this.props.size * 0.46}px)`
            }
          }, s.toString())),
          this.props.showNumbers && v.map((i, s) => o.jsx("div", {
            style: {
              ...c.hourLabel,
              color: this.props.ticksColor,
              transform: `rotate(${m(s)}deg) translateX(${this.props.size * 0.4}px)`
            },
            children: o.jsx("span", {
              style: {
                ...c.hourLabelSpan,
                transform: `rotate(${-1 * m(s)}deg)`,
                fontSize: t
              },
              children: i
            })
          }, i.toString() + s.toString())),
          this.props.children
        ]
      });
    }
  }
  const u = 90, D = (a, t) => a * 30 + t * 0.5 - u, z = (a, t, e) => a * 360 + t * 6 + e / 12 - u, $ = (a, t) => a * 360 + t * 6 - u, p = {
    analogClock: {
      verticalAlign: "middle"
    },
    hourHand: {
      position: "absolute",
      zIndex: 1,
      transformOrigin: "center",
      transition: "transform linear 0.5s"
    },
    minuteHand: {
      position: "absolute",
      transformOrigin: "center",
      transition: "transform linear 0.5s"
    },
    secondHand: {
      position: "absolute",
      transformOrigin: "center",
      transition: "transform linear 1s"
    }
  };
  class T extends x {
    render() {
      const t = /* @__PURE__ */ new Date(), e = t.getHours() % 12, i = t.getMinutes(), s = t.getSeconds(), n = this.props.size * 0.45, r = Math.round(this.props.size / 50);
      return o.jsx("div", {
        style: {
          ...p.analogClock,
          ...this.props.style
        },
        children: o.jsxs(w, {
          backgroundColor: this.props.backgroundColor || (this.props.themeType === "dark" ? "#111" : "#EEE"),
          ticksColor: this.props.ticksColor || (this.props.themeType === "dark" ? "#dedede" : "#212121"),
          handsColor: this.props.handsColor || (this.props.themeType === "dark" ? "#dedede" : "#212121"),
          secondHandColor: this.props.secondHandColor || "#F44336",
          showNumbers: this.props.showNumbers,
          size: this.props.size,
          withSeconds: this.props.withSeconds,
          children: [
            o.jsx("div", {
              style: {
                ...p.hourHand,
                width: this.props.size * 0.3,
                height: r,
                borderRadius: `0 ${Math.round(r / 2)}px ${Math.round(r / 2)}px 0`,
                backgroundColor: this.props.handsColor || (this.props.themeType === "dark" ? "#dedede" : "#212121"),
                transform: `rotate(${D(e, i)}deg) translateX(${this.props.size * 0.3 / 2}px)`
              }
            }),
            o.jsx("div", {
              style: {
                ...p.minuteHand,
                width: this.props.size * 0.4,
                height: r,
                borderRadius: `0 ${Math.round(r / 2)}px ${Math.round(r / 2)}px 0`,
                backgroundColor: this.props.handsColor || (this.props.themeType === "dark" ? "#dedede" : "#212121"),
                transform: `rotate(${z(e, i, s)}deg) translateX(${this.props.size * 0.4 / 2}px)`
              }
            }),
            this.props.withSeconds ? o.jsx("div", {
              style: {
                ...p.secondHand,
                width: n,
                height: this.props.size / 100,
                borderRadius: `0 ${Math.round(this.props.size / 500)}px ${Math.round(this.props.size / 500)}px 0`,
                backgroundColor: this.props.secondHandColor || "#F44336",
                transform: `rotate(${$(i, s)}deg) translateX(${n / 2}px)`
              }
            }) : null
          ]
        })
      });
    }
  }
  const g = {
    uClock: {
      verticalAlign: "middle",
      animation: "vis-2-widgets-nils-fork-uClockFadeIn 500ms ease-in-out",
      animationFillMode: "both",
      backgroundColor: "#fff",
      borderRadius: "50%"
    },
    uClockHand: {
      transition: "transform 200ms cubic-bezier(0.175, 0.885, 0.32, 1.275)"
    }
  };
  h = class extends C {
    refContainer = k.createRef();
    rotations;
    timeInterval;
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        time: /* @__PURE__ */ new Date(),
        width: 0,
        fontSizeSvg: 0,
        textWidthSvg: 0
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2Clock",
        visSet: "vis-2-widgets-nils-fork",
        visWidgetLabel: "clock",
        visName: "Clock",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox"
              },
              {
                name: "type",
                label: "type",
                type: "select",
                options: [
                  {
                    value: "analog",
                    label: "analog"
                  },
                  {
                    value: "analog2",
                    label: "analog2"
                  },
                  {
                    value: "digital",
                    label: "digital"
                  },
                  {
                    value: "digital2",
                    label: "digital2"
                  }
                ],
                default: "analog"
              },
              {
                name: "backgroundColor",
                hidden: 'data.type === "digital" || data.type === "digital2"',
                label: "background",
                type: "color"
              },
              {
                name: "ticksColor",
                hidden: 'data.type === "digital" || data.type === "digital2"',
                label: "color",
                type: "color"
              },
              {
                name: "handsColor",
                hidden: 'data.type === "digital" || data.type === "digital2"',
                label: "hands_color",
                type: "color"
              },
              {
                name: "secondHandColor",
                hidden: 'data.type === "digital" || data.type === "digital2"',
                label: "seconds_hand_color",
                type: "color"
              },
              {
                name: "withSeconds",
                label: "with_seconds",
                type: "checkbox",
                default: true
              },
              {
                name: "showNumbers",
                hidden: 'data.type === "digital" || data.type === "digital2"',
                label: "show_numbers",
                type: "checkbox",
                default: true
              },
              {
                name: "blinkDelimiter",
                label: "blink",
                hidden: '(data.type !== "digital" && data.type !== "digital2") || data.withSeconds',
                type: "checkbox",
                default: true
              },
              {
                name: "hoursFormat",
                label: "am_pm",
                hidden: 'data.type !== "digital" && data.type !== "digital2"',
                type: "select",
                options: [
                  "24",
                  "12"
                ],
                noTranslation: true,
                default: "24"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_clock.png"
      };
    }
    getWidgetInfo() {
      return h.getWidgetInfo();
    }
    nextTick = () => {
      const t = this.state.rxData || {}, e = /* @__PURE__ */ new Date();
      let i;
      t.withSeconds || t.type === "digital2" && t.blinkDelimiter ? i = 1e3 - e.getMilliseconds() : i = 1e3 - e.getMilliseconds() + 1e3 * (60 - e.getSeconds()), this.timeInterval = setTimeout(this.nextTick, i), this.setState({
        time: e
      });
    };
    onRxDataChanged() {
      this.timeInterval && clearTimeout(this.timeInterval), this.timeInterval = setTimeout(() => {
        this.timeInterval = void 0, this.nextTick();
      }, 1e3 - (/* @__PURE__ */ new Date()).getMilliseconds());
    }
    componentDidMount() {
      super.componentDidMount(), this.timeInterval = this.timeInterval || setTimeout(() => {
        this.timeInterval = void 0, this.nextTick();
      }, 1e3 - (/* @__PURE__ */ new Date()).getMilliseconds()), this.recalculateWidth();
    }
    recalculateWidth() {
      if (this.refContainer.current) {
        let t = this.refContainer.current.clientWidth;
        this.state.rxData.type !== "digital" && this.state.rxData.type !== "digital2" && t > this.refContainer.current.clientHeight && (t = this.refContainer.current.clientHeight);
        const e = this.getDigitalClockText(true);
        let i = e.digits.join(":");
        if (e.ampm && (i += ` ${e.ampm}`), t !== this.state.width || this.state.height !== this.refContainer.current.clientHeight || this.state.timeFormat !== i) {
          let s = 0, n = 0;
          if (this.state.rxData.type === "digital" || this.state.rxData.type === "digital2") {
            const r = this.getDigitalClockText(true);
            let l = `${r.digits[0]}${r.hideDelimiter ? " " : ":"}${r.digits[1]}${r.digits[2] ? `:${r.digits[2]}` : ""}`;
            this.state.rxData.type === "digital" && this.state.rxData.hoursFormat === "12" && (l += " mm"), n = h.calculateFontSize(l, this.refContainer.current.clientWidth, this.refContainer.current.clientHeight), s = h.getTextWidth(l, `normal ${n}px Arial`);
          }
          this.setState({
            width: t,
            height: this.refContainer.current.clientHeight,
            timeFormat: i,
            fontSizeSvg: n,
            textWidthSvg: s
          });
        }
      }
    }
    componentWillUnmount() {
      this.timeInterval && (clearTimeout(this.timeInterval), this.timeInterval = void 0), super.componentWillUnmount();
    }
    componentDidUpdate(t, e) {
      super.componentDidUpdate(t, e), this.recalculateWidth();
    }
    renderSimpleClock() {
      const t = this.state.rxData || {}, e = /* @__PURE__ */ new Date(), i = e.getSeconds(), s = e.getMinutes(), n = e.getHours() % 12;
      this.rotations = this.rotations || [
        0,
        0,
        0
      ], i === 0 && (this.rotations[0] += 1), s === 0 && i === 0 && (this.rotations[1] += 1), n === 0 && s === 0 && i === 0 && (this.rotations[2] += 1);
      const r = i / 60 * 360 + this.rotations[0] * 360, l = s / 60 * 360 + this.rotations[1] * 360, f = n / 12 * 360 + s / 60 * 30 + this.rotations[2] * 360;
      return o.jsxs("svg", {
        viewBox: "0 0 100 100",
        color: t.ticksColor || (this.props.context.themeType === "dark" ? "#dedede" : "#212121"),
        fill: "currentColor",
        width: this.state.width,
        height: this.state.width,
        style: {
          ...g.uClock,
          backgroundColor: t.backgroundColor || (this.props.context.themeType === "dark" ? "#111" : "#EEE")
        },
        children: [
          [
            ...Array(12)
          ].map((y, d) => o.jsx("line", {
            style: {
              transformOrigin: "center"
            },
            stroke: "currentColor",
            opacity: 0.7,
            strokeWidth: 1,
            transform: `rotate(${30 * d})`,
            strokeLinecap: "round",
            x1: "50",
            y1: "5",
            x2: "50",
            y2: "10"
          }, d)),
          o.jsx("line", {
            stroke: t.handsColor || (this.props.context.themeType === "dark" ? "#dedede" : "#212121"),
            style: {
              ...g.uClockHand,
              transform: `rotate(${f}deg)`,
              transformOrigin: "center"
            },
            strokeLinecap: "round",
            strokeWidth: "1.5",
            x1: "50",
            y1: "25",
            x2: "50",
            y2: "50"
          }),
          o.jsx("line", {
            stroke: t.handsColor || (this.props.context.themeType === "dark" ? "#dedede" : "#212121"),
            style: {
              ...g.uClockHand,
              transform: `rotate(${l}deg)`,
              transformOrigin: "center"
            },
            strokeLinecap: "round",
            strokeWidth: "1.5",
            x1: "50",
            y1: "10",
            x2: "50",
            y2: "50"
          }),
          o.jsx("circle", {
            stroke: "currentColor",
            cx: "50",
            cy: "50",
            r: "3"
          }),
          t.withSeconds ? o.jsxs("g", {
            style: {
              ...g.uClockHand,
              transform: `rotate(${r}deg)`,
              transformOrigin: "center"
            },
            stroke: "currentColor",
            color: t.secondHandColor || "#F44336",
            strokeWidth: "1",
            children: [
              o.jsx("line", {
                x1: "50",
                y1: "10",
                x2: "50",
                y2: "60",
                strokeLinecap: "round"
              }),
              o.jsx("circle", {
                cx: "50",
                cy: "50",
                r: "1.5"
              })
            ]
          }) : null,
          t.showNumbers ? [
            ...Array(12)
          ].map((y, d) => o.jsx("g", {
            style: {
              transformOrigin: "center center",
              transform: `rotate(${30 * (d + 1)}deg)`
            },
            children: o.jsx("text", {
              x: d + 1 > 9 ? 46 : 48,
              y: "18",
              stroke: "currentColor",
              fontSize: 6,
              children: d + 1
            })
          }, d.toString())) : null
        ]
      });
    }
    renderAnalogClock() {
      const t = this.state.rxData || {};
      return o.jsx(T, {
        style: {
          marginTop: this.refContainer.current.clientHeight > this.refContainer.current.clientWidth ? (this.refContainer.current.clientHeight - this.refContainer.current.clientWidth) / 2 : void 0,
          marginLeft: this.refContainer.current.clientHeight < this.refContainer.current.clientWidth ? (this.refContainer.current.clientWidth - this.refContainer.current.clientHeight) / 2 : void 0
        },
        size: this.state.width,
        ticksColor: t.ticksColor,
        backgroundColor: t.backgroundColor,
        showNumbers: t.showNumbers,
        withSeconds: t.withSeconds,
        handsColor: t.handsColor,
        secondHandColor: t.secondHandColor,
        themeType: this.props.context.themeType
      });
    }
    getDigitalClockText(t) {
      const e = this.state.rxData || {}, i = [];
      if (t) return i.push("00"), i.push("00"), e.withSeconds && i.push("00"), {
        ampm: e.hoursFormat === "12" ? "pm" : void 0,
        digits: i
      };
      const s = /* @__PURE__ */ new Date();
      return e.hoursFormat === "12" ? i.push((s.getHours() % 12).toString().padStart(2, "0")) : i.push(s.getHours().toString().padStart(2, "0")), i.push(s.getMinutes().toString().padStart(2, "0")), e.withSeconds && i.push(s.getSeconds().toString().padStart(2, "0")), {
        ampm: e.hoursFormat === "12" ? s.getHours() > 11 ? "pm" : "am" : void 0,
        digits: i,
        hideDelimiter: !e.withSeconds && e.blinkDelimiter && s.getSeconds() % 2 === 0
      };
    }
    renderDigitalClock() {
      const t = this.getDigitalClockText(), e = [
        o.jsx("span", {
          children: t.digits[0]
        }, "hours"),
        o.jsx("span", {
          style: {
            opacity: t.hideDelimiter ? 0 : 1
          },
          children: ":"
        }, "delimiter1"),
        o.jsx("span", {
          children: t.digits[1]
        }, "minutes"),
        t.digits.length > 2 ? o.jsx("span", {
          style: {
            opacity: t.hideDelimiter ? 0 : 1
          },
          children: ":"
        }, "delimiter2") : null,
        t.digits.length > 2 ? o.jsx("span", {
          children: t.digits[2]
        }, "seconds") : null,
        t.ampm ? o.jsxs("span", {
          style: {
            fontSize: "50%"
          },
          children: [
            "\xA0",
            t.ampm
          ]
        }, "ampm") : null
      ];
      return o.jsx("div", {
        style: {
          display: "inline-block",
          margin: "0 auto",
          fontSize: this.state.rxStyle["font-size"] || this.state.fontSizeSvg
        },
        children: e
      });
    }
    static getTextWidth(t, e) {
      const s = document.createElement("canvas").getContext("2d");
      return s.font = e, s.measureText(t).width;
    }
    static calculateFontSize(t, e, i, s = "Arial", n = "normal") {
      let r = i, l = h.getTextWidth(t, `${n} ${r}px ${s}`);
      for (; (l > e || r > i) && r > 6; ) r -= 1, l = h.getTextWidth(t, `${n} ${r}px ${s}`);
      return r;
    }
    renderDigitalClock2() {
      var _a;
      const t = this.state.rxData || {}, e = this.getDigitalClockText(), i = `${e.digits[0]}${e.hideDelimiter ? " " : ":"}${e.digits[1]}${e.digits[2] ? `:${e.digits[2]}` : ""}`, s = t.withSeconds ? this.state.fontSizeSvg / 3 : t.blinkDelimiter ? this.state.fontSizeSvg / 4 : this.state.fontSizeSvg / 3, n = h.getTextWidth("mm", `normal ${s}px Arial`);
      return o.jsxs("svg", {
        viewBox: `0 0 ${this.state.width} ${this.state.height}`,
        color: ((_a = this.state.rxStyle) == null ? void 0 : _a.color) || (this.props.context.themeType === "dark" ? "#dedede" : "#212121"),
        fill: "currentColor",
        width: this.state.width,
        height: this.state.height,
        children: [
          o.jsx("text", {
            x: "50%",
            y: "50%",
            fontSize: this.state.fontSizeSvg,
            dominantBaseline: "middle",
            textAnchor: "middle",
            fontFamily: t.withSeconds || !t.blinkDelimiter ? void 0 : "monospace",
            children: i
          }),
          e.ampm ? o.jsx("text", {
            x: "50%",
            y: "50%",
            transform: `translate(${this.state.textWidthSvg / 2 - n}, ${this.state.fontSizeSvg * 0.55})`,
            fontSize: s,
            children: e.ampm === "pm" ? "PM" : "AM"
          }) : null
        ]
      });
    }
    renderWidgetBody(t) {
      super.renderWidgetBody(t);
      let e = null;
      if (this.state.width) {
        switch (this.state.rxData.type) {
          case "analog2":
            e = this.renderAnalogClock(), this.resizeLocked = !this.props.isRelative;
            break;
          case "digital":
            this.resizeLocked = false, e = this.renderDigitalClock();
            break;
          case "digital2":
            this.resizeLocked = false, e = this.renderDigitalClock2();
            break;
          case "analog":
          default:
            e = this.renderSimpleClock(), this.resizeLocked = !this.props.isRelative;
            break;
        }
        this.timeInterval = this.timeInterval || setTimeout(() => {
          this.timeInterval = void 0, this.nextTick();
        }, 1e3 - (/* @__PURE__ */ new Date()).getMilliseconds());
      }
      const i = {
        textAlign: "center",
        lineHeight: this.state.height ? `${this.state.height}px` : void 0,
        fontFamily: this.state.rxStyle["font-family"],
        textShadow: this.state.rxStyle["text-shadow"],
        fontStyle: this.state.rxStyle["font-style"],
        fontWeight: this.state.rxStyle["font-weight"],
        fontVariant: this.state.rxStyle["font-variant"]
      };
      i.width = "calc(100% - 4px)", i.height = "calc(100% - 8px)", i.margin = "auto";
      const s = o.jsxs("div", {
        style: i,
        ref: this.refContainer,
        children: [
          o.jsx("style", {
            children: `
@keyframes vis-2-widgets-nils-fork-uClockFadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}               
                `
          }),
          e
        ]
      });
      return this.state.rxData.noCard || t.widget.usedInWidget ? s : this.wrapContent(s, null);
    }
  };
});
export {
  __tla,
  h as default
};
