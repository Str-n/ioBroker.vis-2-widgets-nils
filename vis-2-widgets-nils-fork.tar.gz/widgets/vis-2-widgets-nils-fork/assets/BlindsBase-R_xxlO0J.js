import { j as r, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { G as N } from "./Generic-DDdmRdK-.js";
import { _ as D, a as _, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { n as g, _ as f, a as S, b as j, c as M, d as k, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { _ as C, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_system__loadShare__.js-BtyZ_WHy.js";
import { q as b, L as T, M as B, N as O, _ as $, __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CgDCyMuJ.js";
import { c as v, __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-Buo0KxVv.js";
let U, H;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  const w = "widgets/vis-2-widgets-nils-fork/img", u = {
    dialog: {
      maxWidth: "1000px",
      width: "calc(100vw - 32px)"
    },
    dialogContent: {
      padding: 0,
      background: "#b8d2dd",
      overflow: "hidden"
    },
    dialogTitle: {
      textAlign: "center"
    },
    sceneStack: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "0.75em",
      width: "100%"
    },
    buttonStopStyle: {
      float: "left"
    },
    sliderText: {
      display: "inline-block"
    },
    sliderStyle: {
      marginTop: "1em",
      marginBottom: "1em",
      position: "relative",
      zIndex: 11,
      width: "10em",
      borderRadius: "2em",
      overflow: "hidden",
      background: "transparent",
      cursor: "pointer",
      boxShadow: "none",
      height: "20em",
      boxSizing: "border-box"
    },
    scene: {
      position: "relative",
      width: "100%",
      maxWidth: "620px",
      aspectRatio: "1024 / 1536",
      backgroundColor: "#dfeaf2",
      backgroundImage: `linear-gradient(180deg, rgba(13,20,31,0.12), rgba(13,20,31,0.12)), url("${w}/person-at-window.png")`,
      backgroundRepeat: "no-repeat",
      backgroundPosition: "center center",
      backgroundSize: "100% 100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      margin: "0 auto"
    },
    sceneWindow: {
      position: "absolute",
      inset: 0,
      backgroundImage: `url("${w}/personatemptywindow.png")`,
      backgroundRepeat: "no-repeat",
      backgroundPosition: "center center",
      backgroundSize: "100% 100%",
      pointerEvents: "none",
      zIndex: 2
    },
    blindWindow: {
      position: "absolute",
      left: "10%",
      right: "10%",
      top: "0%",
      bottom: "23%",
      zIndex: 1,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "transparent",
      overflow: "hidden"
    }
  }, x = "#c7c70e";
  class d extends D {
    static types = {
      value: 0,
      dimmer: 1,
      blinds: 2
    };
    static mouseDown = false;
    button = {
      time: 0,
      name: "",
      timer: null,
      timeUp: 0
    };
    refSlider = _.createRef();
    type;
    top = void 0;
    height = void 0;
    controlTimer = null;
    constructor(t) {
      super(t), this.state = {
        value: this.props.startValue || 0,
        toggleValue: this.props.startToggleValue || false,
        lastControl: 0
      }, this.type = this.props.type || d.types.dimmer;
    }
    static getDerivedStateFromProps(t, e) {
      let a = null;
      return t.startValue !== e.value && !d.mouseDown && Date.now() - e.lastControl > 1e3 && (a = {}, a.value = t.startValue), t.startToggleValue !== void 0 && t.startToggleValue !== e.toggleValue && (a || (a = {}), a.toggleValue = t.startToggleValue), a || null;
    }
    eventToValue(t) {
      const e = t.touches ? t.touches[t.touches.length - 1].clientY : t.clientY;
      let a = 100 - Math.round((e - this.top) / this.height * 100);
      a > 100 ? a = 100 : a < 0 && (a = 0), this.setState({
        value: a
      }), Date.now() - this.state.lastControl > 200 && this.type !== d.types.blinds && this.setState({
        lastControl: Date.now()
      }, () => this.onValueChanged(a));
    }
    onMouseMove = (t) => {
      d.mouseDown && (t.preventDefault(), t.stopPropagation(), this.eventToValue(t));
    };
    onMouseDown = (t) => {
      if (t.preventDefault(), t.stopPropagation(), !this.height) if (this.refSlider.current) this.height = this.refSlider.current.offsetHeight, this.top = this.refSlider.current.getBoundingClientRect().top;
      else return;
      d.mouseDown = true, this.eventToValue(t), window.document.addEventListener("mousemove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.addEventListener("mouseup", this.onMouseUp, {
        passive: false,
        capture: true
      }), window.document.addEventListener("touchmove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.addEventListener("touchend", this.onMouseUp, {
        passive: false,
        capture: true
      });
    };
    onValueChanged(t) {
      var _a, _b;
      this.props.controlTimeout ? (this.controlTimer && (clearTimeout(this.controlTimer), this.controlTimer = null), this.controlTimer = setTimeout(() => {
        var _a2, _b2;
        (_b2 = (_a2 = this.props).onValueChange) == null ? void 0 : _b2.call(_a2, t);
      }, this.props.controlTimeout)) : (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, t);
    }
    onMouseUp = (t) => {
      t.preventDefault(), t.stopPropagation(), d.mouseDown && (d.mouseDown = false, window.document.removeEventListener("mousemove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("mouseup", this.onMouseUp, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("touchmove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("touchend", this.onMouseUp, {
        passive: false,
        capture: true
      })), this.setState({
        lastControl: Date.now()
      }, () => {
        var _a, _b;
        (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, this.state.value, true);
      });
    };
    componentWillUnmount() {
      d.mouseDown && (d.mouseDown = false, window.document.removeEventListener("mousemove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("mouseup", this.onMouseUp, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("touchmove", this.onMouseMove, {
        passive: false,
        capture: true
      }), window.document.removeEventListener("touchend", this.onMouseUp, {
        passive: false,
        capture: true
      }));
    }
    getTopButtonName() {
      switch (this.props.type) {
        case d.types.blinds:
          return r.jsx(T, {
            style: {
              width: 20,
              height: 20
            }
          });
        case d.types.dimmer:
          return r.jsx(b, {
            style: {
              color: x,
              width: 20,
              height: 20
            }
          });
        default:
          return v.t("ON");
      }
    }
    getBottomButtonName() {
      switch (this.props.type) {
        case d.types.blinds:
          return r.jsx(B, {
            style: {
              width: 20,
              height: 20
            }
          });
        case d.types.dimmer:
          return r.jsx(b, {
            style: {
              width: 20,
              height: 20
            }
          });
        default:
          return v.t("OFF");
      }
    }
    onButtonDown(t, e) {
      t == null ? void 0 : t.stopPropagation(), !(Date.now() - this.button.time < 50) && (this.button.timer && clearTimeout(this.button.timer), this.button.name = e, this.button.time = Date.now(), this.button.timer = setTimeout(() => {
        this.button.timer = null;
        let a;
        switch (this.button.name) {
          case "top":
            a = 100;
            break;
          case "bottom":
            a = 0;
            break;
        }
        a !== void 0 && this.setState({
          value: a
        }, () => {
          var _a, _b;
          return (_b = (_a = this.props).onValueChange) == null ? void 0 : _b.call(_a, a, true);
        });
      }, 400));
    }
    getSliderColor() {
      if (this.props.type !== d.types.blinds) {
        if (this.props.type === d.types.dimmer) {
          const t = this.state.value;
          return C(x, 1 - (t / 70 + 0.3));
        }
        return "#888";
      }
    }
    getValueText() {
      let t = "%";
      return this.props.type !== d.types.blinds && this.props.type !== d.types.dimmer && (t = this.props.unit || ""), this.state.value + t;
    }
    getToggleButton() {
      return this.props.onToggle ? r.jsx(g, {
        onClick: this.props.onToggle,
        className: "dimmer-button",
        style: u.buttonToggleStyle,
        children: r.jsx(b, {})
      }) : null;
    }
    getStopButton() {
      return this.props.onStop ? r.jsx(g, {
        style: u.buttonStopStyle,
        size: "small",
        onClick: this.props.onStop,
        color: "secondary",
        children: r.jsx(O, {})
      }) : null;
    }
    generateContent() {
      const t = {
        position: "absolute",
        width: "100%",
        left: 0,
        height: `${this.props.type === d.types.blinds ? 100 - this.state.value : this.state.value}%`,
        background: this.props.background || this.getSliderColor(),
        transitionProperty: "height",
        transitionDuration: "0.1s"
      }, e = {
        position: "absolute",
        width: "2em",
        height: "0.3em",
        left: "calc(50% - 1em)",
        background: "white",
        borderRadius: "0.4em"
      };
      this.props.type === d.types.blinds ? (t.top = 0, e.bottom = "0.4em", t.backgroundImage = "linear-gradient(0deg, #949494 4.55%, #c9c9c9 4.55%, #c9c9c9 50%, #949494 50%, #949494 54.55%, #c9c9c9 54.55%, #c9c9c9 100%)", t.backgroundSize = "100% 2.5em", t.backgroundPosition = "center bottom") : (t.bottom = 0, e.top = "0.4em");
      const a = {
        ...u.sliderStyle,
        width: "100%",
        height: "85%",
        minHeight: "250px",
        margin: 0,
        background: "transparent",
        boxShadow: "none",
        borderRadius: 0,
        overflow: "hidden"
      };
      return r.jsxs("div", {
        className: "vis-2-slider-wrapper",
        style: u.sceneStack,
        children: [
          r.jsx(f, {
            variant: "outlined",
            onClick: (i) => this.onButtonDown(i, "top"),
            children: this.getTopButtonName()
          }),
          r.jsxs("div", {
            style: u.scene,
            children: [
              r.jsx("div", {
                style: u.sceneWindow
              }),
              r.jsx("div", {
                style: u.blindWindow,
                children: r.jsx("div", {
                  className: "vis-2-slider-blind",
                  ref: this.refSlider,
                  onMouseDown: this.onMouseDown,
                  onTouchStart: this.onMouseDown,
                  onClick: (i) => i.stopPropagation(),
                  style: a,
                  children: r.jsx("div", {
                    style: t,
                    className: "vis-2-slider-inside",
                    children: r.jsx("div", {
                      style: e,
                      className: "vis-2-slider-handler"
                    })
                  })
                })
              })
            ]
          }),
          r.jsx(f, {
            variant: "outlined",
            onClick: (i) => this.onButtonDown(i, "bottom"),
            children: this.getBottomButtonName()
          }),
          this.getToggleButton()
        ]
      });
    }
    render() {
      return r.jsxs(S, {
        open: true,
        onClose: () => this.props.onClose(),
        PaperProps: {
          style: u.dialog
        },
        children: [
          r.jsxs(j, {
            style: u.dialogTitle,
            children: [
              this.getStopButton(),
              r.jsx("div", {
                style: u.sliderText,
                children: this.getValueText()
              }),
              r.jsx(M, {
                onClick: () => this.props.onClose(),
                style: {
                  float: "right"
                },
                children: r.jsx($, {})
              })
            ]
          }),
          r.jsx(k, {
            style: u.dialogContent,
            children: this.generateContent()
          })
        ]
      });
    }
  }
  let m;
  m = {
    blindHandle: {
      position: "absolute",
      borderColor: "#a5aaad",
      borderStyle: "solid",
      background: "linear-gradient(to bottom, rgba(226, 226, 226, 1) 0%, rgba(219, 219, 219, 1) 50%, rgba(209, 209, 209, 1) 51%, rgba(254, 254, 254, 1) 100%)"
    },
    blindBlind: {
      backgroundImage: "linear-gradient(0deg, #949494 4.55%, #c9c9c9 4.55%, #c9c9c9 50%, #949494 50%, #949494 54.55%, #c9c9c9 54.55%, #c9c9c9 100%)",
      backgroundSize: "100% 20px",
      backgroundPosition: "center bottom",
      width: "100%",
      position: "absolute",
      transitionProperty: "height",
      transitionDuration: "0.3s"
    },
    blindBlind1: {
      height: "100%",
      boxSizing: "border-box",
      borderStyle: "solid",
      background: "linear-gradient(45deg, rgba(173, 174, 178, 1) 0%, rgba(251, 251, 251, 1) 100%)"
    },
    blindBlind2: {
      position: "relative",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
      borderStyle: "solid",
      borderColor: "rgba(0, 0, 0, 0)"
    },
    blindBlind3: {
      position: "relative",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
      background: "linear-gradient(to bottom, rgba(0, 0, 0, 0.8) 0%, rgba(0, 51, 135, 0.83) 100%)"
    },
    blindBlind4: {
      position: "relative",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
      borderStyle: "solid",
      background: "linear-gradient(45deg, rgba(221, 231, 243, 0.7) 0%, rgba(120, 132, 146, 0.7) 52%, rgba(166, 178, 190, 0.7) 68%, rgba(201, 206, 210, 0.7) 100%)",
      transitionProperty: "transform",
      transitionDuration: "0.3s",
      transformOrigin: "0 100%"
    },
    blindBlind4_left: {
      transformOrigin: "0 0"
    },
    blindBlind4_right: {
      transformOrigin: "100% 0"
    },
    blindBlind4_top: {
      transformOrigin: "0 100%"
    },
    blindBlind4_bottom: {
      transformOrigin: "0 0"
    },
    blindBlind4Opened_left: {
      transform: "skew(0deg, 10deg) scale(0.9, 1)"
    },
    blindBlind4Opened_right: {
      transform: "skew(0deg, -10deg) scale(0.9, 1)"
    },
    blindBlind4Opened_top: {
      transform: "skew(-10deg, 0deg) scale(1, 0.9)"
    },
    blindBlind4Opened_bottom: {
      transform: "skew(10deg, 0deg) scale(1, 0.9)"
    },
    blindBlind4_tilted: {
      transform: "skew(-10deg, 0deg) scale(1, 0.9)",
      transformOrigin: "0 100%"
    },
    blindHandleBG: {},
    blindHandleTiltedBG: {
      background: "linear-gradient(to bottom, rgba(241, 231, 103, 1) 0%, rgba(254, 182, 69, 1) 100%)"
    }
  };
  H = m;
  U = class extends N {
    constructor(t) {
      super(t), this.state = {
        ...this.state,
        showBlindsDialog: null
      };
    }
    getMinMaxPosition(t, e) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
      const a = t ? this.state.rxData[`slideStop_oid${t}`] : this.state.rxData.oid_stop;
      let i = t && !this.state.rxData.oid ? this.state.rxData[`slidePos_oid${t}`] : this.state.rxData.oid, n = t && !this.state.rxData.oid ? this.state.rxData[`slideInvert${t}`] === true || this.state.rxData[`slideInvert${t}`] === "true" : this.state.rxData.invert === true || this.state.rxData.invert === "true";
      e !== void 0 && (i = this.state.rxData[`slidePos_oid${t}`] !== "nothing_selected" ? this.state.rxData[`slidePos_oid${t}`] : "", n = this.state.rxData[`slideInvert${e}`] === true || this.state.rxData[`slideInvert${e}`] === "true"), t && (i === "nothing_selected" || !i) && (i = this.state.rxData.oid, n = this.state.rxData.invert === true || this.state.rxData.invert === "true");
      let l, s;
      if (!t) l = parseFloat(this.state.rxData.min), Number.isNaN(l) && (((_a = this.state.main) == null ? void 0 : _a.min) === void 0 || Number.isNaN((_b = this.state.main) == null ? void 0 : _b.min) ? l = 0 : l = this.state.main.min), s = parseFloat(this.state.rxData.max), Number.isNaN(s) && (((_c = this.state.main) == null ? void 0 : _c.max) === void 0 || Number.isNaN((_d = this.state.main) == null ? void 0 : _d.max) ? s = 100 : s = this.state.main.max);
      else if (e !== void 0) {
        const h = typeof this.state.objects[e] == "object" ? parseFloat((_f = (_e = this.state.objects[e]) == null ? void 0 : _e.common) == null ? void 0 : _f.min) : void 0;
        h === void 0 || Number.isNaN(h) ? ((_g = this.state.main) == null ? void 0 : _g.min) === void 0 || Number.isNaN(parseFloat(this.state.main.min)) ? l = 0 : l = this.state.main.min : l = h;
        const p = typeof this.state.objects[e] == "object" ? parseFloat((_i = (_h = this.state.objects[e]) == null ? void 0 : _h.common) == null ? void 0 : _i.max) : void 0;
        p === void 0 || Number.isNaN(p) ? ((_j = this.state.main) == null ? void 0 : _j.max) === void 0 || Number.isNaN(this.state.main.max) ? s = 100 : s = this.state.main.max : s = p;
      } else {
        if (l = parseFloat(this.state.rxData[`slideMin${t}`]), Number.isNaN(l)) {
          const h = typeof this.state.objects[t] == "object" ? parseFloat((_l = (_k = this.state.objects[t]) == null ? void 0 : _k.common) == null ? void 0 : _l.min) : void 0;
          h === void 0 || Number.isNaN(h) ? (l = parseFloat(this.state.rxData.min), Number.isNaN(l) && (l = parseFloat((_m = this.state.main) == null ? void 0 : _m.min), Number.isNaN(l) && (l = 0))) : l = h;
        }
        if (s = parseFloat(this.state.rxData[`slideMax${t}`]), Number.isNaN(s)) {
          const h = typeof this.state.objects[t] == "object" ? parseFloat((_o = (_n = this.state.objects[t]) == null ? void 0 : _n.common) == null ? void 0 : _o.max) : void 0;
          h === void 0 || Number.isNaN(h) ? (s = parseFloat(this.state.rxData.max), Number.isNaN(s) && (s = parseFloat((_p = this.state.main) == null ? void 0 : _p.max), Number.isNaN(s) && (s = 100))) : s = h;
        }
      }
      let o = this.state.values[`${i}.val`];
      return o == null ? o = 0 : (o < l && (o = l), o > s && (o = s), o = Math.round(100 * (o - l) / (s - l))), n && (o = 100 - o), {
        min: l,
        max: s,
        shutterPos: o,
        invert: n,
        stopOid: a,
        positionOid: i,
        customOid: i !== this.state.rxData.oid,
        hasControl: i !== "nothing_selected" && !!i
      };
    }
    renderBlindsDialog() {
      if (this.state.showBlindsDialog !== null) {
        const t = this.getMinMaxPosition(this.state.showBlindsDialog === true ? 0 : this.state.showBlindsDialog, this.state.showBlindsDialogIndexOfButton);
        return r.jsx(d, {
          onClose: () => {
            this.lastClick = Date.now(), this.setState({
              showBlindsDialog: null
            });
          },
          onStop: t.stopOid && t.stopOid !== "nothing_selected" ? () => this.props.context.setValue(t.stopOid, true) : void 0,
          controlTimeout: parseInt(this.state.rxData.timeout, 10) || 0,
          onValueChange: (e, a) => {
            t.invert && (e = 100 - e), e = (t.max - t.min) / 100 * e + t.min, a && this.props.context.setValue(t.positionOid, e);
          },
          startValue: t.shutterPos,
          type: d.types.blinds
        });
      }
      return null;
    }
    renderOneWindow(t, e) {
      const a = this.getMinMaxPosition(t, e.indexOfButton);
      let i = null, n = null;
      e.handleOid && (i = this.state.values[`${e.handleOid}.val`], i === 2 || i === "2" ? i = 1 : (i === 1 || i === "1") && (i = 2), i === "1" || i === true || i === "true" || i === "open" || i === "opened" ? i = 1 : (i === "2" || i === "tilt" || i === "tilted") && (i = 2), n = i), e.slideOid && (n = this.state.values[`${e.slideOid}.val`], (n === 2 || n === "2") && (n = 2), n === "1" || n === true || n === "true" || n === "open" || n === "opened" ? n = 1 : (n === "2" || n === "tilt" || n === "tilted") && (n = 2), e.handleOid || (i = n));
      let l = null;
      if (e.type) {
        let s = Math.round(e.borderWidth / 3);
        s < 1 && (s = 1);
        const o = {
          borderWidth: s,
          transitionProperty: "transform",
          transitionDuration: "0.3s"
        };
        if (e.type === "left" || e.type === "right" ? (o.top = "50%", o.width = e.borderWidth, o.height = "10%") : (e.type === "top" || e.type === "bottom") && (o.left = "50%", o.height = e.borderWidth, o.width = "10%"), e.type === "left" ? o.left = `calc(100% - ${s * 2 + e.borderWidth}px)` : e.type === "bottom" && (o.top = `calc(100% - ${s * 2 + e.borderWidth}px)`), i) if (e.type === "right") {
          const h = Math.round(s + e.borderWidth / 2);
          o.transformOrigin = `${h}px ${h}px`, o.top = `calc(50% + ${h}px)`, i === 1 ? o.transform = "rotate(-90deg)" : i === 2 && (o.transform = "rotate(180deg)");
        } else if (e.type === "bottom") {
          const h = Math.round(s + e.borderWidth / 2);
          o.transformOrigin = `${h}px ${h}px`, i === 1 ? o.transform = "rotate(-90deg)" : i === 2 && (o.transform = "rotate(180deg)");
        } else i === 1 ? o.transform = "rotate(90deg)" : i === 2 && (o.transform = "rotate(180deg)");
        l = r.jsx("div", {
          className: "vis-2-blinds-handle",
          style: {
            ...m.blindHandle,
            ...i === 2 ? m.blindHandleTiltedBG : void 0,
            ...o
          }
        });
      }
      return r.jsx("div", {
        className: "vis-2-blinds-outside",
        style: {
          ...m.blindBlind1,
          borderWidth: e.borderWidth,
          borderColor: "#a9a7a8",
          flex: e.flex || 1
        },
        children: r.jsx("div", {
          className: "vis-2-blinds-inside",
          style: {
            ...m.blindBlind2,
            borderWidth: e.borderWidth
          },
          onClick: a.customOid ? (s) => {
            s.preventDefault(), s.stopPropagation(), this.lastClick = Date.now(), this.setState({
              showBlindsDialog: t,
              showBlindsDialogIndexOfButton: e.indexOfButton
            });
          } : void 0,
          children: r.jsxs("div", {
            style: m.blindBlind3,
            className: "vis-2-blinds-inside-2",
            children: [
              r.jsx("div", {
                style: {
                  ...m.blindBlind,
                  height: `${100 - a.shutterPos}%`
                },
                className: "vis-2-blinds-closed"
              }),
              r.jsx("div", {
                className: "vis-2-blinds-opened",
                style: {
                  ...m.blindBlind4,
                  ...e.type ? m[`blindBlind4_${e.type}`] : void 0,
                  ...n === 1 && e.type ? m[`blindBlind4Opened_${e.type}`] : void 0,
                  ...n === 2 && e.type ? m.blindBlind4_tilted : void 0,
                  borderWidth: e.borderWidth,
                  borderColor: "#a5aaad"
                },
                children: l
              })
            ]
          })
        })
      }, t);
    }
    renderWindows(t, e) {
      let a, i;
      const n = parseFloat(this.state.rxData.ratio) || 1;
      i = t.height, a = Math.round(i * n), a > t.width && (a = t.width, i = Math.round(a / n));
      const l = t.width > t.height ? t.height : t.width;
      let s = parseFloat(this.state.rxData.borderWidth) || 2.5;
      s = Math.round(l * s / 10) / 10, s < 1 && (s = 1);
      const o = [], h = this.state.rxData.sashCount !== void 0 ? this.state.rxData.sashCount : 1;
      for (let c = 1; c <= h; c++) {
        const y = {
          slideOid: this.state.rxData[`slideSensor_oid${c}`],
          handleOid: this.state.rxData[`slideHandle_oid${c}`],
          type: this.state.rxData[`slideType${c}`],
          flex: this.state.rxData[`slideRatio${c}`],
          borderWidth: s,
          size: t,
          indexOfButton: e
        };
        o.push(this.renderOneWindow(c, y));
      }
      const p = {
        paddingTop: s,
        paddingBottom: s - 1,
        paddingRight: s + 1,
        paddingLeft: s + 1,
        width: a,
        height: i,
        display: "flex",
        alignItems: "stretch",
        margin: "auto"
      };
      return r.jsx("div", {
        style: p,
        children: o
      });
    }
  };
});
export {
  U as B,
  H as S,
  __tla
};
