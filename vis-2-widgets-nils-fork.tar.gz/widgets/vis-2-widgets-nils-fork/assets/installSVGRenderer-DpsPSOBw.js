import { a as e, n as t, r as n, t as r } from "./rolldown-runtime-C0FnF6B9.js";
import { B as i, z as a } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
var o = n({ __assign: () => A, __asyncDelegator: () => S, __asyncGenerator: () => x, __asyncValues: () => C, __await: () => b, __awaiter: () => f, __classPrivateFieldGet: () => D, __classPrivateFieldSet: () => O, __createBinding: () => j, __decorate: () => l, __exportStar: () => m, __extends: () => s, __generator: () => p, __importDefault: () => E, __importStar: () => T, __makeTemplateObject: () => w, __metadata: () => d, __param: () => u, __read: () => g, __rest: () => c, __spread: () => _, __spreadArray: () => y, __spreadArrays: () => v, __values: () => h });
function s(e2, t2) {
  if (typeof t2 != `function` && t2 !== null) throw TypeError(`Class extends value ` + String(t2) + ` is not a constructor or null`);
  k(e2, t2);
  function n2() {
    this.constructor = e2;
  }
  e2.prototype = t2 === null ? Object.create(t2) : (n2.prototype = t2.prototype, new n2());
}
function c(e2, t2) {
  var n2 = {};
  for (var r2 in e2) Object.prototype.hasOwnProperty.call(e2, r2) && t2.indexOf(r2) < 0 && (n2[r2] = e2[r2]);
  if (e2 != null && typeof Object.getOwnPropertySymbols == `function`) for (var i2 = 0, r2 = Object.getOwnPropertySymbols(e2); i2 < r2.length; i2++) t2.indexOf(r2[i2]) < 0 && Object.prototype.propertyIsEnumerable.call(e2, r2[i2]) && (n2[r2[i2]] = e2[r2[i2]]);
  return n2;
}
function l(e2, t2, n2, r2) {
  var i2 = arguments.length, a2 = i2 < 3 ? t2 : r2 === null ? r2 = Object.getOwnPropertyDescriptor(t2, n2) : r2, o2;
  if (typeof Reflect == `object` && typeof Reflect.decorate == `function`) a2 = Reflect.decorate(e2, t2, n2, r2);
  else for (var s2 = e2.length - 1; s2 >= 0; s2--) (o2 = e2[s2]) && (a2 = (i2 < 3 ? o2(a2) : i2 > 3 ? o2(t2, n2, a2) : o2(t2, n2)) || a2);
  return i2 > 3 && a2 && Object.defineProperty(t2, n2, a2), a2;
}
function u(e2, t2) {
  return function(n2, r2) {
    t2(n2, r2, e2);
  };
}
function d(e2, t2) {
  if (typeof Reflect == `object` && typeof Reflect.metadata == `function`) return Reflect.metadata(e2, t2);
}
function f(e2, t2, n2, r2) {
  function i2(e3) {
    return e3 instanceof n2 ? e3 : new n2(function(t3) {
      t3(e3);
    });
  }
  return new (n2 || (n2 = Promise))(function(n3, a2) {
    function o2(e3) {
      try {
        c2(r2.next(e3));
      } catch (e4) {
        a2(e4);
      }
    }
    function s2(e3) {
      try {
        c2(r2.throw(e3));
      } catch (e4) {
        a2(e4);
      }
    }
    function c2(e3) {
      e3.done ? n3(e3.value) : i2(e3.value).then(o2, s2);
    }
    c2((r2 = r2.apply(e2, t2 || [])).next());
  });
}
function p(e2, t2) {
  var n2 = { label: 0, sent: function() {
    if (a2[0] & 1) throw a2[1];
    return a2[1];
  }, trys: [], ops: [] }, r2, i2, a2, o2 = { next: s2(0), throw: s2(1), return: s2(2) };
  return typeof Symbol == `function` && (o2[Symbol.iterator] = function() {
    return this;
  }), o2;
  function s2(e3) {
    return function(t3) {
      return c2([e3, t3]);
    };
  }
  function c2(o3) {
    if (r2) throw TypeError(`Generator is already executing.`);
    for (; n2; ) try {
      if (r2 = 1, i2 && (a2 = o3[0] & 2 ? i2.return : o3[0] ? i2.throw || ((a2 = i2.return) && a2.call(i2), 0) : i2.next) && !(a2 = a2.call(i2, o3[1])).done) return a2;
      switch (i2 = 0, a2 && (o3 = [o3[0] & 2, a2.value]), o3[0]) {
        case 0:
        case 1:
          a2 = o3;
          break;
        case 4:
          return n2.label++, { value: o3[1], done: false };
        case 5:
          n2.label++, i2 = o3[1], o3 = [0];
          continue;
        case 7:
          o3 = n2.ops.pop(), n2.trys.pop();
          continue;
        default:
          if (a2 = n2.trys, !(a2 = a2.length > 0 && a2[a2.length - 1]) && (o3[0] === 6 || o3[0] === 2)) {
            n2 = 0;
            continue;
          }
          if (o3[0] === 3 && (!a2 || o3[1] > a2[0] && o3[1] < a2[3])) {
            n2.label = o3[1];
            break;
          }
          if (o3[0] === 6 && n2.label < a2[1]) {
            n2.label = a2[1], a2 = o3;
            break;
          }
          if (a2 && n2.label < a2[2]) {
            n2.label = a2[2], n2.ops.push(o3);
            break;
          }
          a2[2] && n2.ops.pop(), n2.trys.pop();
          continue;
      }
      o3 = t2.call(e2, n2);
    } catch (e3) {
      o3 = [6, e3], i2 = 0;
    } finally {
      r2 = a2 = 0;
    }
    if (o3[0] & 5) throw o3[1];
    return { value: o3[0] ? o3[1] : void 0, done: true };
  }
}
function m(e2, t2) {
  for (var n2 in e2) n2 !== "default" && !Object.prototype.hasOwnProperty.call(t2, n2) && j(t2, e2, n2);
}
function h(e2) {
  var t2 = typeof Symbol == `function` && Symbol.iterator, n2 = t2 && e2[t2], r2 = 0;
  if (n2) return n2.call(e2);
  if (e2 && typeof e2.length == `number`) return { next: function() {
    return e2 && r2 >= e2.length && (e2 = void 0), { value: e2 && e2[r2++], done: !e2 };
  } };
  throw TypeError(t2 ? `Object is not iterable.` : `Symbol.iterator is not defined.`);
}
function g(e2, t2) {
  var n2 = typeof Symbol == `function` && e2[Symbol.iterator];
  if (!n2) return e2;
  var r2 = n2.call(e2), i2, a2 = [], o2;
  try {
    for (; (t2 === void 0 || t2-- > 0) && !(i2 = r2.next()).done; ) a2.push(i2.value);
  } catch (e3) {
    o2 = { error: e3 };
  } finally {
    try {
      i2 && !i2.done && (n2 = r2.return) && n2.call(r2);
    } finally {
      if (o2) throw o2.error;
    }
  }
  return a2;
}
function _() {
  for (var e2 = [], t2 = 0; t2 < arguments.length; t2++) e2 = e2.concat(g(arguments[t2]));
  return e2;
}
function v() {
  for (var e2 = 0, t2 = 0, n2 = arguments.length; t2 < n2; t2++) e2 += arguments[t2].length;
  for (var r2 = Array(e2), i2 = 0, t2 = 0; t2 < n2; t2++) for (var a2 = arguments[t2], o2 = 0, s2 = a2.length; o2 < s2; o2++, i2++) r2[i2] = a2[o2];
  return r2;
}
function y(e2, t2, n2) {
  if (n2 || arguments.length === 2) for (var r2 = 0, i2 = t2.length, a2; r2 < i2; r2++) (a2 || !(r2 in t2)) && (a2 || (a2 = Array.prototype.slice.call(t2, 0, r2)), a2[r2] = t2[r2]);
  return e2.concat(a2 || t2);
}
function b(e2) {
  return this instanceof b ? (this.v = e2, this) : new b(e2);
}
function x(e2, t2, n2) {
  if (!Symbol.asyncIterator) throw TypeError(`Symbol.asyncIterator is not defined.`);
  var r2 = n2.apply(e2, t2 || []), i2, a2 = [];
  return i2 = {}, o2(`next`), o2(`throw`), o2(`return`), i2[Symbol.asyncIterator] = function() {
    return this;
  }, i2;
  function o2(e3) {
    r2[e3] && (i2[e3] = function(t3) {
      return new Promise(function(n3, r3) {
        a2.push([e3, t3, n3, r3]) > 1 || s2(e3, t3);
      });
    });
  }
  function s2(e3, t3) {
    try {
      c2(r2[e3](t3));
    } catch (e4) {
      d2(a2[0][3], e4);
    }
  }
  function c2(e3) {
    e3.value instanceof b ? Promise.resolve(e3.value.v).then(l2, u2) : d2(a2[0][2], e3);
  }
  function l2(e3) {
    s2(`next`, e3);
  }
  function u2(e3) {
    s2(`throw`, e3);
  }
  function d2(e3, t3) {
    e3(t3), a2.shift(), a2.length && s2(a2[0][0], a2[0][1]);
  }
}
function S(e2) {
  var t2 = {}, n2;
  return r2(`next`), r2(`throw`, function(e3) {
    throw e3;
  }), r2(`return`), t2[Symbol.iterator] = function() {
    return this;
  }, t2;
  function r2(r3, i2) {
    t2[r3] = e2[r3] ? function(t3) {
      return (n2 = !n2) ? { value: b(e2[r3](t3)), done: r3 === `return` } : i2 ? i2(t3) : t3;
    } : i2;
  }
}
function C(e2) {
  if (!Symbol.asyncIterator) throw TypeError(`Symbol.asyncIterator is not defined.`);
  var t2 = e2[Symbol.asyncIterator], n2;
  return t2 ? t2.call(e2) : (e2 = typeof h == `function` ? h(e2) : e2[Symbol.iterator](), n2 = {}, r2(`next`), r2(`throw`), r2(`return`), n2[Symbol.asyncIterator] = function() {
    return this;
  }, n2);
  function r2(t3) {
    n2[t3] = e2[t3] && function(n3) {
      return new Promise(function(r3, a2) {
        n3 = e2[t3](n3), i2(r3, a2, n3.done, n3.value);
      });
    };
  }
  function i2(e3, t3, n3, r3) {
    Promise.resolve(r3).then(function(t4) {
      e3({ value: t4, done: n3 });
    }, t3);
  }
}
function w(e2, t2) {
  return Object.defineProperty ? Object.defineProperty(e2, "raw", { value: t2 }) : e2.raw = t2, e2;
}
function T(e2) {
  if (e2 && e2.__esModule) return e2;
  var t2 = {};
  if (e2 != null) for (var n2 in e2) n2 !== "default" && Object.prototype.hasOwnProperty.call(e2, n2) && j(t2, e2, n2);
  return ee(t2, e2), t2;
}
function E(e2) {
  return e2 && e2.__esModule ? e2 : { default: e2 };
}
function D(e2, t2, n2, r2) {
  if (n2 === `a` && !r2) throw TypeError(`Private accessor was defined without a getter`);
  if (typeof t2 == `function` ? e2 !== t2 || !r2 : !t2.has(e2)) throw TypeError(`Cannot read private member from an object whose class did not declare it`);
  return n2 === `m` ? r2 : n2 === `a` ? r2.call(e2) : r2 ? r2.value : t2.get(e2);
}
function O(e2, t2, n2, r2, i2) {
  if (r2 === `m`) throw TypeError(`Private method is not writable`);
  if (r2 === `a` && !i2) throw TypeError(`Private accessor was defined without a setter`);
  if (typeof t2 == `function` ? e2 !== t2 || !i2 : !t2.has(e2)) throw TypeError(`Cannot write private member to an object whose class did not declare it`);
  return r2 === `a` ? i2.call(e2, n2) : i2 ? i2.value = n2 : t2.set(e2, n2), n2;
}
var k, A, j, ee, M = t((() => {
  k = function(e2, t2) {
    return k = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e3, t3) {
      e3.__proto__ = t3;
    } || function(e3, t3) {
      for (var n2 in t3) Object.prototype.hasOwnProperty.call(t3, n2) && (e3[n2] = t3[n2]);
    }, k(e2, t2);
  }, A = function() {
    return A = Object.assign || function(e2) {
      for (var t2, n2 = 1, r2 = arguments.length; n2 < r2; n2++) for (var i2 in t2 = arguments[n2], t2) Object.prototype.hasOwnProperty.call(t2, i2) && (e2[i2] = t2[i2]);
      return e2;
    }, A.apply(this, arguments);
  }, j = Object.create ? (function(e2, t2, n2, r2) {
    r2 === void 0 && (r2 = n2), Object.defineProperty(e2, r2, { enumerable: true, get: function() {
      return t2[n2];
    } });
  }) : (function(e2, t2, n2, r2) {
    r2 === void 0 && (r2 = n2), e2[r2] = t2[n2];
  }), ee = Object.create ? (function(e2, t2) {
    Object.defineProperty(e2, "default", { enumerable: true, value: t2 });
  }) : function(e2, t2) {
    e2.default = t2;
  };
})), N = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.default = void 0;
  var t2 = 1;
  e2.default = function() {
    return `${t2++}`;
  };
})), te = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.default = void 0, e2.default = function(e3) {
    var t2 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 60, n2 = null;
    return function() {
      var r2 = this, i2 = [...arguments];
      clearTimeout(n2), n2 = setTimeout(function() {
        e3.apply(r2, i2);
      }, t2);
    };
  };
})), ne = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.SizeSensorId = e2.SensorTabIndex = e2.SensorClassName = void 0, e2.SizeSensorId = `size-sensor-id`, e2.SensorClassName = `size-sensor-object`, e2.SensorTabIndex = `-1`;
})), re = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.createSensor = void 0;
  var t2 = r2(te()), n2 = ne();
  function r2(e3) {
    return e3 && e3.__esModule ? e3 : { default: e3 };
  }
  e2.createSensor = function(e3, r3) {
    var i2 = void 0, a2 = [], o2 = function() {
      getComputedStyle(e3).position === `static` && (e3.style.position = `relative`);
      var t3 = document.createElement(`object`);
      return t3.onload = function() {
        t3.contentDocument.defaultView.addEventListener(`resize`, s2), s2();
      }, t3.style.display = `block`, t3.style.position = `absolute`, t3.style.top = `0`, t3.style.left = `0`, t3.style.height = `100%`, t3.style.width = `100%`, t3.style.overflow = `hidden`, t3.style.pointerEvents = `none`, t3.style.zIndex = `-1`, t3.style.opacity = `0`, t3.setAttribute(`class`, n2.SensorClassName), t3.setAttribute(`tabindex`, n2.SensorTabIndex), t3.type = `text/html`, e3.appendChild(t3), t3.data = `about:blank`, t3;
    }, s2 = (0, t2.default)(function() {
      a2.forEach(function(t3) {
        t3(e3);
      });
    }), c2 = function(e4) {
      i2 || (i2 = o2()), a2.indexOf(e4) === -1 && a2.push(e4);
    }, l2 = function() {
      i2 && i2.parentNode && (i2.contentDocument && i2.contentDocument.defaultView.removeEventListener(`resize`, s2), i2.parentNode.removeChild(i2), e3.removeAttribute(n2.SizeSensorId), i2 = void 0, a2 = [], r3 && r3());
    };
    return { element: e3, bind: c2, destroy: l2, unbind: function(e4) {
      var t3 = a2.indexOf(e4);
      t3 !== -1 && a2.splice(t3, 1), a2.length === 0 && i2 && l2();
    } };
  };
})), ie = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.createSensor = void 0;
  var t2 = ne(), n2 = r2(te());
  function r2(e3) {
    return e3 && e3.__esModule ? e3 : { default: e3 };
  }
  e2.createSensor = function(e3, r3) {
    var i2 = void 0, a2 = [], o2 = (0, n2.default)(function() {
      a2.forEach(function(t3) {
        t3(e3);
      });
    }), s2 = function() {
      var t3 = new ResizeObserver(o2);
      return t3.observe(e3), o2(), t3;
    }, c2 = function(e4) {
      i2 || (i2 = s2()), a2.indexOf(e4) === -1 && a2.push(e4);
    }, l2 = function() {
      i2 && i2.disconnect(), a2 = [], i2 = void 0, e3.removeAttribute(t2.SizeSensorId), r3 && r3();
    };
    return { element: e3, bind: c2, destroy: l2, unbind: function(e4) {
      var t3 = a2.indexOf(e4);
      t3 !== -1 && a2.splice(t3, 1), a2.length === 0 && i2 && l2();
    } };
  };
})), ae = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.createSensor = void 0;
  var t2 = re(), n2 = ie();
  e2.createSensor = typeof ResizeObserver < `u` ? n2.createSensor : t2.createSensor;
})), oe = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.removeSensor = e2.getSensor = e2.Sensors = void 0;
  var t2 = i2(N()), n2 = ae(), r2 = ne();
  function i2(e3) {
    return e3 && e3.__esModule ? e3 : { default: e3 };
  }
  var a2 = e2.Sensors = {};
  function o2(e3) {
    e3 && a2[e3] && delete a2[e3];
  }
  e2.getSensor = function(e3) {
    var i3 = e3.getAttribute(r2.SizeSensorId);
    if (i3 && a2[i3]) return a2[i3];
    var s2 = (0, t2.default)();
    e3.setAttribute(r2.SizeSensorId, s2);
    var c2 = (0, n2.createSensor)(e3, function() {
      return o2(s2);
    });
    return a2[s2] = c2, c2;
  }, e2.removeSensor = function(e3) {
    var t3 = e3.element.getAttribute(r2.SizeSensorId);
    e3.destroy(), o2(t3);
  };
})), se = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.ver = e2.clear = e2.bind = void 0;
  var t2 = oe();
  e2.bind = function(e3, n2) {
    var r2 = (0, t2.getSensor)(e3);
    return r2.bind(n2), function() {
      r2.unbind(n2);
    };
  }, e2.clear = function(e3) {
    var n2 = (0, t2.getSensor)(e3);
    (0, t2.removeSensor)(n2);
  }, e2.ver = `1.0.3`;
})), ce = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.pick = void 0;
  function t2(e3, t3) {
    var n2 = {};
    return t3.forEach(function(t4) {
      n2[t4] = e3[t4];
    }), n2;
  }
  e2.pick = t2;
})), le = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.isFunction = void 0;
  function t2(e3) {
    return typeof e3 == `function`;
  }
  e2.isFunction = t2;
})), ue = r(((e2) => {
  Object.defineProperty(e2, "__esModule", { value: true }), e2.isString = void 0;
  function t2(e3) {
    return typeof e3 == `string`;
  }
  e2.isString = t2;
})), de = r(((e2, t2) => {
  t2.exports = function e3(t3, n2) {
    if (t3 === n2) return true;
    if (t3 && n2 && typeof t3 == `object` && typeof n2 == `object`) {
      if (t3.constructor !== n2.constructor) return false;
      var r2, i2, a2;
      if (Array.isArray(t3)) {
        if (r2 = t3.length, r2 != n2.length) return false;
        for (i2 = r2; i2-- !== 0; ) if (!e3(t3[i2], n2[i2])) return false;
        return true;
      }
      if (t3.constructor === RegExp) return t3.source === n2.source && t3.flags === n2.flags;
      if (t3.valueOf !== Object.prototype.valueOf) return t3.valueOf() === n2.valueOf();
      if (t3.toString !== Object.prototype.toString) return t3.toString() === n2.toString();
      if (a2 = Object.keys(t3), r2 = a2.length, r2 !== Object.keys(n2).length) return false;
      for (i2 = r2; i2-- !== 0; ) if (!Object.prototype.hasOwnProperty.call(n2, a2[i2])) return false;
      for (i2 = r2; i2-- !== 0; ) {
        var o2 = a2[i2];
        if (!e3(t3[o2], n2[o2])) return false;
      }
      return true;
    }
    return t3 !== t3 && n2 !== n2;
  };
})), P = r(((t2) => {
  Object.defineProperty(t2, "__esModule", { value: true }), t2.isEqual = void 0, t2.isEqual = (M(), e(o)).__importDefault(de()).default;
})), F = r(((t2) => {
  Object.defineProperty(t2, "__esModule", { value: true });
  var n2 = (M(), e(o)), r2 = n2.__importStar((i(), e(a))), s2 = se(), c2 = ce(), l2 = le(), u2 = ue(), d2 = P();
  t2.default = (function(e2) {
    n2.__extends(t3, e2);
    function t3(t4) {
      var n3 = e2.call(this, t4) || this;
      return n3.echarts = t4.echarts, n3.ele = null, n3.isInitialResize = true, n3.eventHandlerRefs = {}, n3;
    }
    return t3.prototype.componentDidMount = function() {
      this.renderNewEcharts();
    }, t3.prototype.componentDidUpdate = function(e3) {
      var t4 = this.props.shouldSetOption;
      if (!(0, l2.isFunction)(t4) || t4(e3, this.props)) {
        if (!(0, d2.isEqual)(e3.theme, this.props.theme) || !(0, d2.isEqual)(e3.opts, this.props.opts)) {
          this.dispose(), this.renderNewEcharts();
          return;
        }
        var n3 = this.getEchartsInstance();
        (0, d2.isEqual)(e3.onEvents, this.props.onEvents) || (this.unbindEvents(n3), this.bindEvents(n3, this.props.onEvents));
        var r3 = [`option`, `notMerge`, `replaceMerge`, `lazyUpdate`, `showLoading`, `loadingOption`];
        (0, d2.isEqual)((0, c2.pick)(this.props, r3), (0, c2.pick)(e3, r3)) || this.updateEChartsOption(), (!(0, d2.isEqual)(e3.style, this.props.style) || !(0, d2.isEqual)(e3.className, this.props.className)) && this.resize();
      }
    }, t3.prototype.componentWillUnmount = function() {
      this.dispose();
    }, t3.prototype.initEchartsInstance = function() {
      return n2.__awaiter(this, void 0, void 0, function() {
        var e3 = this;
        return n2.__generator(this, function(t4) {
          return [2, new Promise(function(t5) {
            e3.echarts.init(e3.ele, e3.props.theme, e3.props.opts), e3.getEchartsInstance().on(`finished`, function() {
              var r3 = e3.ele.clientWidth, i2 = e3.ele.clientHeight;
              e3.echarts.dispose(e3.ele);
              var a2 = n2.__assign({ width: r3, height: i2 }, e3.props.opts);
              t5(e3.echarts.init(e3.ele, e3.props.theme, a2));
            });
          })];
        });
      });
    }, t3.prototype.getEchartsInstance = function() {
      return this.echarts.getInstanceByDom(this.ele);
    }, t3.prototype.dispose = function() {
      if (this.ele) {
        try {
          (0, s2.clear)(this.ele);
        } catch (e3) {
          console.warn(e3);
        }
        this.echarts.dispose(this.ele);
      }
    }, t3.prototype.renderNewEcharts = function() {
      return n2.__awaiter(this, void 0, void 0, function() {
        var e3, t4, r3, i2, a2, o2, c3 = this;
        return n2.__generator(this, function(n3) {
          switch (n3.label) {
            case 0:
              return e3 = this.props, t4 = e3.onEvents, r3 = e3.onChartReady, i2 = e3.autoResize, a2 = i2 === void 0 || i2, [4, this.initEchartsInstance()];
            case 1:
              return n3.sent(), o2 = this.updateEChartsOption(), this.bindEvents(o2, t4 || {}), (0, l2.isFunction)(r3) && r3(o2), this.ele && a2 && (0, s2.bind)(this.ele, function() {
                c3.resize();
              }), [2];
          }
        });
      });
    }, t3.prototype.bindEvents = function(e3, t4) {
      var n3 = this, r3 = function(t5, r4) {
        if ((0, u2.isString)(t5) && (0, l2.isFunction)(r4)) {
          var i3 = function(t6) {
            r4(t6, e3);
          };
          e3.on(t5, i3), n3.eventHandlerRefs[t5] = i3;
        }
      };
      for (var i2 in t4) Object.prototype.hasOwnProperty.call(t4, i2) && r3(i2, t4[i2]);
    }, t3.prototype.unbindEvents = function(e3) {
      for (var t4 = 0, n3 = Object.entries(this.eventHandlerRefs); t4 < n3.length; t4++) {
        var r3 = n3[t4], i2 = r3[0], a2 = r3[1];
        e3.off(i2, a2);
      }
      this.eventHandlerRefs = {};
    }, t3.prototype.updateEChartsOption = function() {
      var e3 = this.props, t4 = e3.option, n3 = e3.notMerge, r3 = n3 !== void 0 && n3, i2 = e3.replaceMerge, a2 = i2 === void 0 ? null : i2, o2 = e3.lazyUpdate, s3 = o2 !== void 0 && o2, c3 = e3.showLoading, l3 = e3.loadingOption, u3 = l3 === void 0 ? null : l3, d3 = this.getEchartsInstance();
      return d3.setOption(t4, { notMerge: r3, replaceMerge: a2, lazyUpdate: s3 }), c3 ? d3.showLoading(u3) : d3.hideLoading(), d3;
    }, t3.prototype.resize = function() {
      var e3 = this.getEchartsInstance();
      if (!this.isInitialResize) try {
        e3.resize({ width: `auto`, height: `auto` });
      } catch (e4) {
        console.warn(e4);
      }
      this.isInitialResize = false;
    }, t3.prototype.render = function() {
      var e3 = this, t4 = this.props, i2 = t4.style, a2 = t4.className, o2 = a2 === void 0 ? `` : a2;
      t4.echarts, t4.option, t4.theme, t4.notMerge, t4.replaceMerge, t4.lazyUpdate, t4.showLoading, t4.loadingOption, t4.opts, t4.onChartReady, t4.onEvents, t4.shouldSetOption, t4.autoResize;
      var s3 = n2.__rest(t4, [`style`, `className`, `echarts`, `option`, `theme`, `notMerge`, `replaceMerge`, `lazyUpdate`, `showLoading`, `loadingOption`, `opts`, `onChartReady`, `onEvents`, `shouldSetOption`, `autoResize`]), c3 = n2.__assign({ height: 300 }, i2);
      return r2.default.createElement(`div`, n2.__assign({ ref: function(t5) {
        e3.ele = t5;
      }, style: c3, className: `echarts-for-react ${o2}` }, s3));
    }, t3;
  })(r2.PureComponent);
}));
M();
var fe = /* @__PURE__ */ (function() {
  function e2() {
    this.firefox = false, this.ie = false, this.edge = false, this.newEdge = false, this.weChat = false;
  }
  return e2;
})(), I = new (/* @__PURE__ */ (function() {
  function e2() {
    this.browser = new fe(), this.node = false, this.wxa = false, this.worker = false, this.svgSupported = false, this.touchEventsSupported = false, this.pointerEventsSupported = false, this.domSupported = false, this.transformSupported = false, this.transform3dSupported = false, this.hasGlobalWindow = typeof window < `u`;
  }
  return e2;
})())();
typeof wx == `object` && typeof wx.getSystemInfoSync == `function` ? (I.wxa = true, I.touchEventsSupported = true) : typeof document > `u` && typeof self < `u` ? I.worker = true : !I.hasGlobalWindow || `Deno` in window ? (I.node = true, I.svgSupported = true) : pe(navigator.userAgent, I);
function pe(e2, t2) {
  var n2 = t2.browser, r2 = e2.match(/Firefox\/([\d.]+)/), i2 = e2.match(/MSIE\s([\d.]+)/) || e2.match(/Trident\/.+?rv:(([\d.]+))/), a2 = e2.match(/Edge?\/([\d.]+)/), o2 = /micromessenger/i.test(e2);
  r2 && (n2.firefox = true, n2.version = r2[1]), i2 && (n2.ie = true, n2.version = i2[1]), a2 && (n2.edge = true, n2.version = a2[1], n2.newEdge = +a2[1].split(`.`)[0] > 18), o2 && (n2.weChat = true), t2.svgSupported = typeof SVGRect < `u`, t2.touchEventsSupported = `ontouchstart` in window && !n2.ie && !n2.edge, t2.pointerEventsSupported = `onpointerdown` in window && (n2.edge || n2.ie && +n2.version >= 11), t2.domSupported = typeof document < `u`;
  var s2 = document.documentElement.style;
  t2.transform3dSupported = (n2.ie && `transition` in s2 || n2.edge || `WebKitCSSMatrix` in window && `m11` in new WebKitCSSMatrix() || `MozPerspective` in s2) && !(`OTransition` in s2), t2.transformSupported = t2.transform3dSupported || n2.ie && +n2.version >= 9;
}
var me = `12px sans-serif`, he = 20, ge = 100, _e = `007LLmW'55;N0500LLLLLLLLLL00NNNLzWW\\\\WQb\\0FWLg\\bWb\\WQ\\WrWWQ000CL5LLFLL0LL**F*gLLLL5F0LF\\FFF5.5N`;
function ve(e2) {
  var t2 = {};
  if (typeof JSON > `u`) return t2;
  for (var n2 = 0; n2 < e2.length; n2++) {
    var r2 = String.fromCharCode(n2 + 32);
    t2[r2] = (e2.charCodeAt(n2) - he) / ge;
  }
  return t2;
}
var ye = ve(_e), be = { createCanvas: function() {
  return typeof document < `u` && document.createElement(`canvas`);
}, measureText: /* @__PURE__ */ (function() {
  var e2, t2;
  return function(n2, r2) {
    if (!e2) {
      var i2 = be.createCanvas();
      e2 = i2 && i2.getContext(`2d`);
    }
    if (e2) return t2 !== r2 && (t2 = e2.font = r2 || `12px sans-serif`), e2.measureText(n2);
    n2 || (n2 = ``), r2 || (r2 = `12px sans-serif`);
    var a2 = /((?:\d+)?\.?\d*)px/.exec(r2), o2 = a2 && +a2[1] || 12, s2 = 0;
    if (r2.indexOf(`mono`) >= 0) s2 = o2 * n2.length;
    else for (var c2 = 0; c2 < n2.length; c2++) {
      var l2 = ye[n2[c2]];
      s2 += l2 == null ? o2 : l2 * o2;
    }
    return { width: s2 };
  };
})(), loadImage: function(e2, t2, n2) {
  var r2 = new Image();
  return r2.onload = t2, r2.onerror = n2, r2.src = e2, r2;
} };
function xe(e2) {
  for (var t2 in be) e2[t2] && (be[t2] = e2[t2]);
}
var Se = n({ HashMap: () => _t, RADIAN_TO_DEGREE: () => Ct, assert: () => lt, bind: () => Ye, clone: () => L, concatArray: () => vt, createCanvas: () => Be, createHashMap: () => J, createObject: () => yt, curry: () => Xe, defaults: () => ze, disableUserSelect: () => bt, each: () => z, eqNaN: () => it, extend: () => R, filter: () => Ke, find: () => qe, guid: () => Fe, hasOwn: () => xt, indexOf: () => Ve, inherits: () => He, isArray: () => H, isArrayLike: () => We, isBuiltInObject: () => Qe, isDom: () => et, isFunction: () => U, isGradientObject: () => tt, isImagePatternObject: () => nt, isNumber: () => G, isObject: () => K, isPrimitive: () => pt, isRegExp: () => rt, isString: () => W, isStringSafe: () => Ze, isTypedArray: () => $e, keys: () => V, logError: () => Ie, map: () => B, merge: () => Le, mergeAll: () => Re, mixin: () => Ue, noop: () => St, normalizeCssArray: () => ct, reduce: () => Ge, retrieve: () => at, retrieve2: () => q, retrieve3: () => ot, setAsPrimitive: () => ft, slice: () => st, trim: () => ut }), Ce = Ge([`Function`, `RegExp`, `Date`, `Error`, `CanvasGradient`, `CanvasPattern`, `Image`, `Canvas`], function(e2, t2) {
  return e2[`[object ` + t2 + `]`] = true, e2;
}, {}), we = Ge([`Int8`, `Uint8`, `Uint8Clamped`, `Int16`, `Uint16`, `Int32`, `Uint32`, `Float32`, `Float64`], function(e2, t2) {
  return e2[`[object ` + t2 + `Array]`] = true, e2;
}, {}), Te = Object.prototype.toString, Ee = Array.prototype, De = Ee.forEach, Oe = Ee.filter, ke = Ee.slice, Ae = Ee.map, je = function() {
}.constructor, Me = je ? je.prototype : null, Ne = `__proto__`, Pe = 2311;
function Fe() {
  return Pe++;
}
function Ie() {
  var e2 = [...arguments];
  typeof console < `u` && console.error.apply(console, e2);
}
function L(e2) {
  if (typeof e2 != `object` || !e2) return e2;
  var t2 = e2, n2 = Te.call(e2);
  if (n2 === `[object Array]`) {
    if (!pt(e2)) {
      t2 = [];
      for (var r2 = 0, i2 = e2.length; r2 < i2; r2++) t2[r2] = L(e2[r2]);
    }
  } else if (we[n2]) {
    if (!pt(e2)) {
      var a2 = e2.constructor;
      if (a2.from) t2 = a2.from(e2);
      else {
        t2 = new a2(e2.length);
        for (var r2 = 0, i2 = e2.length; r2 < i2; r2++) t2[r2] = e2[r2];
      }
    }
  } else if (!Ce[n2] && !pt(e2) && !et(e2)) for (var o2 in t2 = {}, e2) e2.hasOwnProperty(o2) && o2 !== Ne && (t2[o2] = L(e2[o2]));
  return t2;
}
function Le(e2, t2, n2) {
  if (!K(t2) || !K(e2)) return n2 ? L(t2) : e2;
  for (var r2 in t2) if (t2.hasOwnProperty(r2) && r2 !== Ne) {
    var i2 = e2[r2], a2 = t2[r2];
    K(a2) && K(i2) && !H(a2) && !H(i2) && !et(a2) && !et(i2) && !Qe(a2) && !Qe(i2) && !pt(a2) && !pt(i2) ? Le(i2, a2, n2) : (n2 || !(r2 in e2)) && (e2[r2] = L(t2[r2]));
  }
  return e2;
}
function Re(e2, t2) {
  for (var n2 = e2[0], r2 = 1, i2 = e2.length; r2 < i2; r2++) n2 = Le(n2, e2[r2], t2);
  return n2;
}
function R(e2, t2) {
  if (Object.assign) Object.assign(e2, t2);
  else for (var n2 in t2) t2.hasOwnProperty(n2) && n2 !== Ne && (e2[n2] = t2[n2]);
  return e2;
}
function ze(e2, t2, n2) {
  for (var r2 = V(t2), i2 = 0, a2 = r2.length; i2 < a2; i2++) {
    var o2 = r2[i2];
    (n2 ? t2[o2] != null : e2[o2] == null) && (e2[o2] = t2[o2]);
  }
  return e2;
}
var Be = be.createCanvas;
function Ve(e2, t2) {
  if (e2) {
    if (e2.indexOf) return e2.indexOf(t2);
    for (var n2 = 0, r2 = e2.length; n2 < r2; n2++) if (e2[n2] === t2) return n2;
  }
  return -1;
}
function He(e2, t2) {
  var n2 = e2.prototype;
  function r2() {
  }
  for (var i2 in r2.prototype = t2.prototype, e2.prototype = new r2(), n2) n2.hasOwnProperty(i2) && (e2.prototype[i2] = n2[i2]);
  e2.prototype.constructor = e2, e2.superClass = t2;
}
function Ue(e2, t2, n2) {
  if (e2 = `prototype` in e2 ? e2.prototype : e2, t2 = `prototype` in t2 ? t2.prototype : t2, Object.getOwnPropertyNames) for (var r2 = Object.getOwnPropertyNames(t2), i2 = 0; i2 < r2.length; i2++) {
    var a2 = r2[i2];
    a2 !== `constructor` && (n2 ? t2[a2] != null : e2[a2] == null) && (e2[a2] = t2[a2]);
  }
  else ze(e2, t2, n2);
}
function We(e2) {
  return !e2 || typeof e2 == `string` ? false : typeof e2.length == `number`;
}
function z(e2, t2, n2) {
  if (e2 && t2) {
    if (e2.forEach && e2.forEach === De) e2.forEach(t2, n2);
    else if (e2.length === +e2.length) for (var r2 = 0, i2 = e2.length; r2 < i2; r2++) t2.call(n2, e2[r2], r2, e2);
    else for (var a2 in e2) e2.hasOwnProperty(a2) && t2.call(n2, e2[a2], a2, e2);
  }
}
function B(e2, t2, n2) {
  if (!e2) return [];
  if (!t2) return st(e2);
  if (e2.map && e2.map === Ae) return e2.map(t2, n2);
  for (var r2 = [], i2 = 0, a2 = e2.length; i2 < a2; i2++) r2.push(t2.call(n2, e2[i2], i2, e2));
  return r2;
}
function Ge(e2, t2, n2, r2) {
  if (e2 && t2) {
    for (var i2 = 0, a2 = e2.length; i2 < a2; i2++) n2 = t2.call(r2, n2, e2[i2], i2, e2);
    return n2;
  }
}
function Ke(e2, t2, n2) {
  if (!e2) return [];
  if (!t2) return st(e2);
  if (e2.filter && e2.filter === Oe) return e2.filter(t2, n2);
  for (var r2 = [], i2 = 0, a2 = e2.length; i2 < a2; i2++) t2.call(n2, e2[i2], i2, e2) && r2.push(e2[i2]);
  return r2;
}
function qe(e2, t2, n2) {
  if (e2 && t2) {
    for (var r2 = 0, i2 = e2.length; r2 < i2; r2++) if (t2.call(n2, e2[r2], r2, e2)) return e2[r2];
  }
}
function V(e2) {
  if (!e2) return [];
  if (Object.keys) return Object.keys(e2);
  var t2 = [];
  for (var n2 in e2) e2.hasOwnProperty(n2) && t2.push(n2);
  return t2;
}
function Je(e2, t2) {
  var n2 = [...arguments].slice(2);
  return function() {
    return e2.apply(t2, n2.concat(ke.call(arguments)));
  };
}
var Ye = Me && U(Me.bind) ? Me.call.bind(Me.bind) : Je;
function Xe(e2) {
  var t2 = [...arguments].slice(1);
  return function() {
    return e2.apply(this, t2.concat(ke.call(arguments)));
  };
}
function H(e2) {
  return Array.isArray ? Array.isArray(e2) : Te.call(e2) === `[object Array]`;
}
function U(e2) {
  return typeof e2 == `function`;
}
function W(e2) {
  return typeof e2 == `string`;
}
function Ze(e2) {
  return Te.call(e2) === `[object String]`;
}
function G(e2) {
  return typeof e2 == `number`;
}
function K(e2) {
  var t2 = typeof e2;
  return t2 === `function` || !!e2 && t2 === `object`;
}
function Qe(e2) {
  return !!Ce[Te.call(e2)];
}
function $e(e2) {
  return !!we[Te.call(e2)];
}
function et(e2) {
  return typeof e2 == `object` && typeof e2.nodeType == `number` && typeof e2.ownerDocument == `object`;
}
function tt(e2) {
  return e2.colorStops != null;
}
function nt(e2) {
  return e2.image != null;
}
function rt(e2) {
  return Te.call(e2) === `[object RegExp]`;
}
function it(e2) {
  return e2 !== e2;
}
function at() {
  for (var e2 = [...arguments], t2 = 0, n2 = e2.length; t2 < n2; t2++) if (e2[t2] != null) return e2[t2];
}
function q(e2, t2) {
  return e2 ?? t2;
}
function ot(e2, t2, n2) {
  return e2 ?? t2 ?? n2;
}
function st(e2) {
  var t2 = [...arguments].slice(1);
  return ke.apply(e2, t2);
}
function ct(e2) {
  if (typeof e2 == `number`) return [e2, e2, e2, e2];
  var t2 = e2.length;
  return t2 === 2 ? [e2[0], e2[1], e2[0], e2[1]] : t2 === 3 ? [e2[0], e2[1], e2[2], e2[1]] : e2;
}
function lt(e2, t2) {
  if (!e2) throw Error(t2);
}
function ut(e2) {
  return e2 == null ? null : typeof e2.trim == `function` ? e2.trim() : e2.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ``);
}
var dt = `__ec_primitive__`;
function ft(e2) {
  e2[dt] = true;
}
function pt(e2) {
  return e2[dt];
}
var mt = (function() {
  function e2() {
    this.data = {};
  }
  return e2.prototype.delete = function(e3) {
    var t2 = this.has(e3);
    return t2 && delete this.data[e3], t2;
  }, e2.prototype.has = function(e3) {
    return this.data.hasOwnProperty(e3);
  }, e2.prototype.get = function(e3) {
    return this.data[e3];
  }, e2.prototype.set = function(e3, t2) {
    return this.data[e3] = t2, this;
  }, e2.prototype.keys = function() {
    return V(this.data);
  }, e2.prototype.forEach = function(e3) {
    var t2 = this.data;
    for (var n2 in t2) t2.hasOwnProperty(n2) && e3(t2[n2], n2);
  }, e2;
})(), ht = typeof Map == `function`;
function gt() {
  return ht ? /* @__PURE__ */ new Map() : new mt();
}
var _t = (function() {
  function e2(t2) {
    var n2 = H(t2);
    this.data = gt();
    var r2 = this;
    t2 instanceof e2 ? t2.each(i2) : t2 && z(t2, i2);
    function i2(e3, t3) {
      n2 ? r2.set(e3, t3) : r2.set(t3, e3);
    }
  }
  return e2.prototype.hasKey = function(e3) {
    return this.data.has(e3);
  }, e2.prototype.get = function(e3) {
    return this.data.get(e3);
  }, e2.prototype.set = function(e3, t2) {
    return this.data.set(e3, t2), t2;
  }, e2.prototype.each = function(e3, t2) {
    this.data.forEach(function(n2, r2) {
      e3.call(t2, n2, r2);
    });
  }, e2.prototype.keys = function() {
    var e3 = this.data.keys();
    return ht ? Array.from(e3) : e3;
  }, e2.prototype.removeKey = function(e3) {
    this.data.delete(e3);
  }, e2;
})();
function J(e2) {
  return new _t(e2);
}
function vt(e2, t2) {
  for (var n2 = new e2.constructor(e2.length + t2.length), r2 = 0; r2 < e2.length; r2++) n2[r2] = e2[r2];
  for (var i2 = e2.length, r2 = 0; r2 < t2.length; r2++) n2[r2 + i2] = t2[r2];
  return n2;
}
function yt(e2, t2) {
  var n2;
  if (Object.create) n2 = Object.create(e2);
  else {
    var r2 = function() {
    };
    r2.prototype = e2, n2 = new r2();
  }
  return t2 && R(n2, t2), n2;
}
function bt(e2) {
  var t2 = e2.style;
  t2.webkitUserSelect = `none`, t2.userSelect = `none`, t2.webkitTapHighlightColor = `rgba(0,0,0,0)`, t2[`-webkit-touch-callout`] = `none`;
}
function xt(e2, t2) {
  return e2.hasOwnProperty(t2);
}
function St() {
}
var Ct = 180 / Math.PI, wt = n({ add: () => kt, applyTransform: () => qt, clone: () => Dt, copy: () => Et, create: () => Tt, dist: () => Ht, distSquare: () => Wt, distance: () => Vt, distanceSquare: () => Ut, div: () => Lt, dot: () => Rt, len: () => Mt, lenSquare: () => Pt, length: () => Nt, lengthSquare: () => Ft, lerp: () => Kt, max: () => Yt, min: () => Jt, mul: () => It, negate: () => Gt, normalize: () => Bt, scale: () => zt, scaleAndAdd: () => At, set: () => Ot, sub: () => jt });
function Tt(e2, t2) {
  return e2 ?? (e2 = 0), t2 ?? (t2 = 0), [e2, t2];
}
function Et(e2, t2) {
  return e2[0] = t2[0], e2[1] = t2[1], e2;
}
function Dt(e2) {
  return [e2[0], e2[1]];
}
function Ot(e2, t2, n2) {
  return e2[0] = t2, e2[1] = n2, e2;
}
function kt(e2, t2, n2) {
  return e2[0] = t2[0] + n2[0], e2[1] = t2[1] + n2[1], e2;
}
function At(e2, t2, n2, r2) {
  return e2[0] = t2[0] + n2[0] * r2, e2[1] = t2[1] + n2[1] * r2, e2;
}
function jt(e2, t2, n2) {
  return e2[0] = t2[0] - n2[0], e2[1] = t2[1] - n2[1], e2;
}
function Mt(e2) {
  return Math.sqrt(Pt(e2));
}
var Nt = Mt;
function Pt(e2) {
  return e2[0] * e2[0] + e2[1] * e2[1];
}
var Ft = Pt;
function It(e2, t2, n2) {
  return e2[0] = t2[0] * n2[0], e2[1] = t2[1] * n2[1], e2;
}
function Lt(e2, t2, n2) {
  return e2[0] = t2[0] / n2[0], e2[1] = t2[1] / n2[1], e2;
}
function Rt(e2, t2) {
  return e2[0] * t2[0] + e2[1] * t2[1];
}
function zt(e2, t2, n2) {
  return e2[0] = t2[0] * n2, e2[1] = t2[1] * n2, e2;
}
function Bt(e2, t2) {
  var n2 = Mt(t2);
  return n2 === 0 ? (e2[0] = 0, e2[1] = 0) : (e2[0] = t2[0] / n2, e2[1] = t2[1] / n2), e2;
}
function Vt(e2, t2) {
  return Math.sqrt((e2[0] - t2[0]) * (e2[0] - t2[0]) + (e2[1] - t2[1]) * (e2[1] - t2[1]));
}
var Ht = Vt;
function Ut(e2, t2) {
  return (e2[0] - t2[0]) * (e2[0] - t2[0]) + (e2[1] - t2[1]) * (e2[1] - t2[1]);
}
var Wt = Ut;
function Gt(e2, t2) {
  return e2[0] = -t2[0], e2[1] = -t2[1], e2;
}
function Kt(e2, t2, n2, r2) {
  return e2[0] = t2[0] + r2 * (n2[0] - t2[0]), e2[1] = t2[1] + r2 * (n2[1] - t2[1]), e2;
}
function qt(e2, t2, n2) {
  var r2 = t2[0], i2 = t2[1];
  return e2[0] = n2[0] * r2 + n2[2] * i2 + n2[4], e2[1] = n2[1] * r2 + n2[3] * i2 + n2[5], e2;
}
function Jt(e2, t2, n2) {
  return e2[0] = Math.min(t2[0], n2[0]), e2[1] = Math.min(t2[1], n2[1]), e2;
}
function Yt(e2, t2, n2) {
  return e2[0] = Math.max(t2[0], n2[0]), e2[1] = Math.max(t2[1], n2[1]), e2;
}
var Xt = /* @__PURE__ */ (function() {
  function e2(e3, t2) {
    this.target = e3, this.topTarget = t2 && t2.topTarget;
  }
  return e2;
})(), Zt = (function() {
  function e2(e3) {
    this.handler = e3, e3.on(`mousedown`, this._dragStart, this), e3.on(`mousemove`, this._drag, this), e3.on(`mouseup`, this._dragEnd, this);
  }
  return e2.prototype._dragStart = function(e3) {
    for (var t2 = e3.target; t2 && !t2.draggable; ) t2 = t2.parent || t2.__hostTarget;
    t2 && (this._draggingTarget = t2, t2.dragging = true, this._x = e3.offsetX, this._y = e3.offsetY, this.handler.dispatchToElement(new Xt(t2, e3), `dragstart`, e3.event));
  }, e2.prototype._drag = function(e3) {
    var t2 = this._draggingTarget;
    if (t2) {
      var n2 = e3.offsetX, r2 = e3.offsetY, i2 = n2 - this._x, a2 = r2 - this._y;
      this._x = n2, this._y = r2, t2.drift(i2, a2, e3), this.handler.dispatchToElement(new Xt(t2, e3), `drag`, e3.event);
      var o2 = this.handler.findHover(n2, r2, t2).target, s2 = this._dropTarget;
      this._dropTarget = o2, t2 !== o2 && (s2 && o2 !== s2 && this.handler.dispatchToElement(new Xt(s2, e3), `dragleave`, e3.event), o2 && o2 !== s2 && this.handler.dispatchToElement(new Xt(o2, e3), `dragenter`, e3.event));
    }
  }, e2.prototype._dragEnd = function(e3) {
    var t2 = this._draggingTarget;
    t2 && (t2.dragging = false), this.handler.dispatchToElement(new Xt(t2, e3), `dragend`, e3.event), this._dropTarget && this.handler.dispatchToElement(new Xt(this._dropTarget, e3), `drop`, e3.event), this._draggingTarget = null, this._dropTarget = null;
  }, e2;
})(), Qt = (function() {
  function e2(e3) {
    e3 && (this._$eventProcessor = e3);
  }
  return e2.prototype.on = function(e3, t2, n2, r2) {
    this._$handlers || (this._$handlers = {});
    var i2 = this._$handlers;
    if (typeof t2 == `function` && (r2 = n2, n2 = t2, t2 = null), !n2 || !e3) return this;
    var a2 = this._$eventProcessor;
    t2 != null && a2 && a2.normalizeQuery && (t2 = a2.normalizeQuery(t2)), i2[e3] || (i2[e3] = []);
    for (var o2 = 0; o2 < i2[e3].length; o2++) if (i2[e3][o2].h === n2) return this;
    var s2 = { h: n2, query: t2, ctx: r2 || this, callAtLast: n2.zrEventfulCallAtLast }, c2 = i2[e3].length - 1, l2 = i2[e3][c2];
    return l2 && l2.callAtLast ? i2[e3].splice(c2, 0, s2) : i2[e3].push(s2), this;
  }, e2.prototype.isSilent = function(e3) {
    var t2 = this._$handlers;
    return !t2 || !t2[e3] || !t2[e3].length;
  }, e2.prototype.off = function(e3, t2) {
    var n2 = this._$handlers;
    if (!n2) return this;
    if (!e3) return this._$handlers = {}, this;
    if (t2) {
      if (n2[e3]) {
        for (var r2 = [], i2 = 0, a2 = n2[e3].length; i2 < a2; i2++) n2[e3][i2].h !== t2 && r2.push(n2[e3][i2]);
        n2[e3] = r2;
      }
      n2[e3] && n2[e3].length === 0 && delete n2[e3];
    } else delete n2[e3];
    return this;
  }, e2.prototype.trigger = function(e3) {
    var t2 = [...arguments].slice(1);
    if (!this._$handlers) return this;
    var n2 = this._$handlers[e3], r2 = this._$eventProcessor;
    if (n2) for (var i2 = t2.length, a2 = n2.length, o2 = 0; o2 < a2; o2++) {
      var s2 = n2[o2];
      if (!(r2 && r2.filter && s2.query != null && !r2.filter(e3, s2.query))) switch (i2) {
        case 0:
          s2.h.call(s2.ctx);
          break;
        case 1:
          s2.h.call(s2.ctx, t2[0]);
          break;
        case 2:
          s2.h.call(s2.ctx, t2[0], t2[1]);
          break;
        default:
          s2.h.apply(s2.ctx, t2);
      }
    }
    return r2 && r2.afterTrigger && r2.afterTrigger(e3), this;
  }, e2.prototype.triggerWithContext = function(e3) {
    var t2 = [...arguments].slice(1);
    if (!this._$handlers) return this;
    var n2 = this._$handlers[e3], r2 = this._$eventProcessor;
    if (n2) for (var i2 = t2.length, a2 = t2[i2 - 1], o2 = n2.length, s2 = 0; s2 < o2; s2++) {
      var c2 = n2[s2];
      if (!(r2 && r2.filter && c2.query != null && !r2.filter(e3, c2.query))) switch (i2) {
        case 0:
          c2.h.call(a2);
          break;
        case 1:
          c2.h.call(a2, t2[0]);
          break;
        case 2:
          c2.h.call(a2, t2[0], t2[1]);
          break;
        default:
          c2.h.apply(a2, t2.slice(1, i2 - 1));
      }
    }
    return r2 && r2.afterTrigger && r2.afterTrigger(e3), this;
  }, e2;
})(), $t = Math.log(2);
function en(e2, t2, n2, r2, i2, a2) {
  var o2 = r2 + `-` + i2, s2 = e2.length;
  if (a2.hasOwnProperty(o2)) return a2[o2];
  if (t2 === 1) {
    var c2 = Math.round(Math.log((1 << s2) - 1 & ~i2) / $t);
    return e2[n2][c2];
  }
  for (var l2 = r2 | 1 << n2, u2 = n2 + 1; r2 & 1 << u2; ) u2++;
  for (var d2 = 0, f2 = 0, p2 = 0; f2 < s2; f2++) {
    var m2 = 1 << f2;
    m2 & i2 || (d2 += (p2 % 2 ? -1 : 1) * e2[n2][f2] * en(e2, t2 - 1, u2, l2, i2 | m2, a2), p2++);
  }
  return a2[o2] = d2, d2;
}
function tn(e2, t2) {
  var n2 = [[e2[0], e2[1], 1, 0, 0, 0, -t2[0] * e2[0], -t2[0] * e2[1]], [0, 0, 0, e2[0], e2[1], 1, -t2[1] * e2[0], -t2[1] * e2[1]], [e2[2], e2[3], 1, 0, 0, 0, -t2[2] * e2[2], -t2[2] * e2[3]], [0, 0, 0, e2[2], e2[3], 1, -t2[3] * e2[2], -t2[3] * e2[3]], [e2[4], e2[5], 1, 0, 0, 0, -t2[4] * e2[4], -t2[4] * e2[5]], [0, 0, 0, e2[4], e2[5], 1, -t2[5] * e2[4], -t2[5] * e2[5]], [e2[6], e2[7], 1, 0, 0, 0, -t2[6] * e2[6], -t2[6] * e2[7]], [0, 0, 0, e2[6], e2[7], 1, -t2[7] * e2[6], -t2[7] * e2[7]]], r2 = {}, i2 = en(n2, 8, 0, 0, 0, r2);
  if (i2 !== 0) {
    for (var a2 = [], o2 = 0; o2 < 8; o2++) for (var s2 = 0; s2 < 8; s2++) a2[s2] ?? (a2[s2] = 0), a2[s2] += ((o2 + s2) % 2 ? -1 : 1) * en(n2, 7, +(o2 === 0), 1 << o2, 1 << s2, r2) / i2 * t2[o2];
    return function(e3, t3, n3) {
      var r3 = t3 * a2[6] + n3 * a2[7] + 1;
      e3[0] = (t3 * a2[0] + n3 * a2[1] + a2[2]) / r3, e3[1] = (t3 * a2[3] + n3 * a2[4] + a2[5]) / r3;
    };
  }
}
var nn = `___zrEVENTSAVED`, rn = [];
function an(e2, t2, n2, r2, i2) {
  return on(rn, t2, r2, i2, true) && on(e2, n2, rn[0], rn[1]);
}
function on(e2, t2, n2, r2, i2) {
  if (t2.getBoundingClientRect && I.domSupported && !ln(t2)) {
    var a2 = t2[nn] || (t2[nn] = {}), o2 = cn(sn(t2, a2), a2, i2);
    if (o2) return o2(e2, n2, r2), true;
  }
  return false;
}
function sn(e2, t2) {
  var n2 = t2.markers;
  if (n2) return n2;
  n2 = t2.markers = [];
  for (var r2 = [`left`, `right`], i2 = [`top`, `bottom`], a2 = 0; a2 < 4; a2++) {
    var o2 = document.createElement(`div`), s2 = o2.style, c2 = a2 % 2, l2 = (a2 >> 1) % 2;
    s2.cssText = [`position: absolute`, `visibility: hidden`, `padding: 0`, `margin: 0`, `border-width: 0`, `user-select: none`, `width:0`, `height:0`, r2[c2] + `:0`, i2[l2] + `:0`, r2[1 - c2] + `:auto`, i2[1 - l2] + `:auto`, ``].join(`!important;`), e2.appendChild(o2), n2.push(o2);
  }
  return n2;
}
function cn(e2, t2, n2) {
  for (var r2 = n2 ? `invTrans` : `trans`, i2 = t2[r2], a2 = t2.srcCoords, o2 = [], s2 = [], c2 = true, l2 = 0; l2 < 4; l2++) {
    var u2 = e2[l2].getBoundingClientRect(), d2 = 2 * l2, f2 = u2.left, p2 = u2.top;
    o2.push(f2, p2), c2 = c2 && a2 && f2 === a2[d2] && p2 === a2[d2 + 1], s2.push(e2[l2].offsetLeft, e2[l2].offsetTop);
  }
  return c2 && i2 ? i2 : (t2.srcCoords = o2, t2[r2] = n2 ? tn(s2, o2) : tn(o2, s2));
}
function ln(e2) {
  return e2.nodeName.toUpperCase() === `CANVAS`;
}
var un = /([&<>"'])/g, dn = { "&": `&amp;`, "<": `&lt;`, ">": `&gt;`, '"': `&quot;`, "'": `&#39;` };
function fn(e2) {
  return e2 == null ? `` : (e2 + ``).replace(un, function(e3, t2) {
    return dn[t2];
  });
}
var pn = /^(?:mouse|pointer|contextmenu|drag|drop)|click/, mn = [], hn = I.browser.firefox && +I.browser.version.split(`.`)[0] < 39;
function gn(e2, t2, n2, r2) {
  return n2 || (n2 = {}), r2 ? _n(e2, t2, n2) : hn && t2.layerX != null && t2.layerX !== t2.offsetX ? (n2.zrX = t2.layerX, n2.zrY = t2.layerY) : t2.offsetX == null ? _n(e2, t2, n2) : (n2.zrX = t2.offsetX, n2.zrY = t2.offsetY), n2;
}
function _n(e2, t2, n2) {
  if (I.domSupported && e2.getBoundingClientRect) {
    var r2 = t2.clientX, i2 = t2.clientY;
    if (ln(e2)) {
      var a2 = e2.getBoundingClientRect();
      n2.zrX = r2 - a2.left, n2.zrY = i2 - a2.top;
      return;
    }
    if (on(mn, e2, r2, i2)) {
      n2.zrX = mn[0], n2.zrY = mn[1];
      return;
    }
  }
  n2.zrX = n2.zrY = 0;
}
function vn(e2) {
  return e2 || window.event;
}
function yn(e2, t2, n2) {
  if (t2 = vn(t2), t2.zrX != null) return t2;
  var r2 = t2.type;
  if (r2 && r2.indexOf(`touch`) >= 0) {
    var i2 = r2 === `touchend` ? t2.changedTouches[0] : t2.targetTouches[0];
    i2 && gn(e2, i2, t2, n2);
  } else {
    gn(e2, t2, t2, n2);
    var a2 = bn(t2);
    t2.zrDelta = a2 ? a2 / 120 : -(t2.detail || 0) / 3;
  }
  var o2 = t2.button;
  return t2.which == null && o2 !== void 0 && pn.test(t2.type) && (t2.which = o2 & 1 ? 1 : o2 & 2 ? 3 : o2 & 4 ? 2 : 0), t2;
}
function bn(e2) {
  var t2 = e2.wheelDelta;
  if (t2) return t2;
  var n2 = e2.deltaX, r2 = e2.deltaY;
  if (n2 == null || r2 == null) return t2;
  var i2 = Math.abs(r2 === 0 ? n2 : r2), a2 = r2 > 0 ? -1 : r2 < 0 ? 1 : n2 > 0 ? -1 : 1;
  return 3 * i2 * a2;
}
function xn(e2, t2, n2, r2) {
  e2.addEventListener(t2, n2, r2);
}
function Sn(e2, t2, n2, r2) {
  e2.removeEventListener(t2, n2, r2);
}
var Cn = function(e2) {
  e2.preventDefault(), e2.stopPropagation(), e2.cancelBubble = true;
}, wn = (function() {
  function e2() {
    this._track = [];
  }
  return e2.prototype.recognize = function(e3, t2, n2) {
    return this._doTrack(e3, t2, n2), this._recognize(e3);
  }, e2.prototype.clear = function() {
    return this._track.length = 0, this;
  }, e2.prototype._doTrack = function(e3, t2, n2) {
    var r2 = e3.touches;
    if (r2) {
      for (var i2 = { points: [], touches: [], target: t2, event: e3 }, a2 = 0, o2 = r2.length; a2 < o2; a2++) {
        var s2 = r2[a2], c2 = gn(n2, s2, {});
        i2.points.push([c2.zrX, c2.zrY]), i2.touches.push(s2);
      }
      this._track.push(i2);
    }
  }, e2.prototype._recognize = function(e3) {
    for (var t2 in Dn) if (Dn.hasOwnProperty(t2)) {
      var n2 = Dn[t2](this._track, e3);
      if (n2) return n2;
    }
  }, e2;
})();
function Tn(e2) {
  var t2 = e2[1][0] - e2[0][0], n2 = e2[1][1] - e2[0][1];
  return Math.sqrt(t2 * t2 + n2 * n2);
}
function En(e2) {
  return [(e2[0][0] + e2[1][0]) / 2, (e2[0][1] + e2[1][1]) / 2];
}
var Dn = { pinch: function(e2, t2) {
  var n2 = e2.length;
  if (n2) {
    var r2 = (e2[n2 - 1] || {}).points, i2 = (e2[n2 - 2] || {}).points || r2;
    if (i2 && i2.length > 1 && r2 && r2.length > 1) {
      var a2 = Tn(r2) / Tn(i2);
      !isFinite(a2) && (a2 = 1), t2.pinchScale = a2;
      var o2 = En(r2);
      return t2.pinchX = o2[0], t2.pinchY = o2[1], { type: `pinch`, target: e2[0].target, event: t2 };
    }
  }
} }, On = n({ clone: () => Ln, copy: () => jn, create: () => kn, identity: () => An, invert: () => In, mul: () => Mn, rotate: () => Pn, scale: () => Fn, translate: () => Nn });
function kn() {
  return [1, 0, 0, 1, 0, 0];
}
function An(e2) {
  return e2[0] = 1, e2[1] = 0, e2[2] = 0, e2[3] = 1, e2[4] = 0, e2[5] = 0, e2;
}
function jn(e2, t2) {
  return e2[0] = t2[0], e2[1] = t2[1], e2[2] = t2[2], e2[3] = t2[3], e2[4] = t2[4], e2[5] = t2[5], e2;
}
function Mn(e2, t2, n2) {
  var r2 = t2[0] * n2[0] + t2[2] * n2[1], i2 = t2[1] * n2[0] + t2[3] * n2[1], a2 = t2[0] * n2[2] + t2[2] * n2[3], o2 = t2[1] * n2[2] + t2[3] * n2[3], s2 = t2[0] * n2[4] + t2[2] * n2[5] + t2[4], c2 = t2[1] * n2[4] + t2[3] * n2[5] + t2[5];
  return e2[0] = r2, e2[1] = i2, e2[2] = a2, e2[3] = o2, e2[4] = s2, e2[5] = c2, e2;
}
function Nn(e2, t2, n2) {
  return e2[0] = t2[0], e2[1] = t2[1], e2[2] = t2[2], e2[3] = t2[3], e2[4] = t2[4] + n2[0], e2[5] = t2[5] + n2[1], e2;
}
function Pn(e2, t2, n2, r2) {
  r2 === void 0 && (r2 = [0, 0]);
  var i2 = t2[0], a2 = t2[2], o2 = t2[4], s2 = t2[1], c2 = t2[3], l2 = t2[5], u2 = Math.sin(n2), d2 = Math.cos(n2);
  return e2[0] = i2 * d2 + s2 * u2, e2[1] = -i2 * u2 + s2 * d2, e2[2] = a2 * d2 + c2 * u2, e2[3] = -a2 * u2 + d2 * c2, e2[4] = d2 * (o2 - r2[0]) + u2 * (l2 - r2[1]) + r2[0], e2[5] = d2 * (l2 - r2[1]) - u2 * (o2 - r2[0]) + r2[1], e2;
}
function Fn(e2, t2, n2) {
  var r2 = n2[0], i2 = n2[1];
  return e2[0] = t2[0] * r2, e2[1] = t2[1] * i2, e2[2] = t2[2] * r2, e2[3] = t2[3] * i2, e2[4] = t2[4] * r2, e2[5] = t2[5] * i2, e2;
}
function In(e2, t2) {
  var n2 = t2[0], r2 = t2[2], i2 = t2[4], a2 = t2[1], o2 = t2[3], s2 = t2[5], c2 = n2 * o2 - a2 * r2;
  return c2 ? (c2 = 1 / c2, e2[0] = o2 * c2, e2[1] = -a2 * c2, e2[2] = -r2 * c2, e2[3] = n2 * c2, e2[4] = (r2 * s2 - o2 * i2) * c2, e2[5] = (a2 * i2 - n2 * s2) * c2, e2) : null;
}
function Ln(e2) {
  var t2 = kn();
  return jn(t2, e2), t2;
}
var Y = (function() {
  function e2(e3, t2) {
    this.x = e3 || 0, this.y = t2 || 0;
  }
  return e2.prototype.copy = function(e3) {
    return this.x = e3.x, this.y = e3.y, this;
  }, e2.prototype.clone = function() {
    return new e2(this.x, this.y);
  }, e2.prototype.set = function(e3, t2) {
    return this.x = e3, this.y = t2, this;
  }, e2.prototype.equal = function(e3) {
    return e3.x === this.x && e3.y === this.y;
  }, e2.prototype.add = function(e3) {
    return this.x += e3.x, this.y += e3.y, this;
  }, e2.prototype.scale = function(e3) {
    this.x *= e3, this.y *= e3;
  }, e2.prototype.scaleAndAdd = function(e3, t2) {
    this.x += e3.x * t2, this.y += e3.y * t2;
  }, e2.prototype.sub = function(e3) {
    return this.x -= e3.x, this.y -= e3.y, this;
  }, e2.prototype.dot = function(e3) {
    return this.x * e3.x + this.y * e3.y;
  }, e2.prototype.len = function() {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  }, e2.prototype.lenSquare = function() {
    return this.x * this.x + this.y * this.y;
  }, e2.prototype.normalize = function() {
    var e3 = this.len();
    return this.x /= e3, this.y /= e3, this;
  }, e2.prototype.distance = function(e3) {
    var t2 = this.x - e3.x, n2 = this.y - e3.y;
    return Math.sqrt(t2 * t2 + n2 * n2);
  }, e2.prototype.distanceSquare = function(e3) {
    var t2 = this.x - e3.x, n2 = this.y - e3.y;
    return t2 * t2 + n2 * n2;
  }, e2.prototype.negate = function() {
    return this.x = -this.x, this.y = -this.y, this;
  }, e2.prototype.transform = function(e3) {
    if (e3) {
      var t2 = this.x, n2 = this.y;
      return this.x = e3[0] * t2 + e3[2] * n2 + e3[4], this.y = e3[1] * t2 + e3[3] * n2 + e3[5], this;
    }
  }, e2.prototype.toArray = function(e3) {
    return e3[0] = this.x, e3[1] = this.y, e3;
  }, e2.prototype.fromArray = function(e3) {
    this.x = e3[0], this.y = e3[1];
  }, e2.set = function(e3, t2, n2) {
    e3.x = t2, e3.y = n2;
  }, e2.copy = function(e3, t2) {
    e3.x = t2.x, e3.y = t2.y;
  }, e2.len = function(e3) {
    return Math.sqrt(e3.x * e3.x + e3.y * e3.y);
  }, e2.lenSquare = function(e3) {
    return e3.x * e3.x + e3.y * e3.y;
  }, e2.dot = function(e3, t2) {
    return e3.x * t2.x + e3.y * t2.y;
  }, e2.add = function(e3, t2, n2) {
    e3.x = t2.x + n2.x, e3.y = t2.y + n2.y;
  }, e2.sub = function(e3, t2, n2) {
    e3.x = t2.x - n2.x, e3.y = t2.y - n2.y;
  }, e2.scale = function(e3, t2, n2) {
    e3.x = t2.x * n2, e3.y = t2.y * n2;
  }, e2.scaleAndAdd = function(e3, t2, n2, r2) {
    e3.x = t2.x + n2.x * r2, e3.y = t2.y + n2.y * r2;
  }, e2.lerp = function(e3, t2, n2, r2) {
    var i2 = 1 - r2;
    e3.x = i2 * t2.x + r2 * n2.x, e3.y = i2 * t2.y + r2 * n2.y;
  }, e2;
})(), Rn = Math.min, zn = Math.max, Bn = new Y(), Vn = new Y(), Hn = new Y(), Un = new Y(), Wn = new Y(), Gn = new Y(), X = (function() {
  function e2(e3, t2, n2, r2) {
    n2 < 0 && (e3 += n2, n2 = -n2), r2 < 0 && (t2 += r2, r2 = -r2), this.x = e3, this.y = t2, this.width = n2, this.height = r2;
  }
  return e2.prototype.union = function(e3) {
    var t2 = Rn(e3.x, this.x), n2 = Rn(e3.y, this.y);
    this.width = isFinite(this.x) && isFinite(this.width) ? zn(e3.x + e3.width, this.x + this.width) - t2 : e3.width, this.height = isFinite(this.y) && isFinite(this.height) ? zn(e3.y + e3.height, this.y + this.height) - n2 : e3.height, this.x = t2, this.y = n2;
  }, e2.prototype.applyTransform = function(t2) {
    e2.applyTransform(this, this, t2);
  }, e2.prototype.calculateTransform = function(e3) {
    var t2 = this, n2 = e3.width / t2.width, r2 = e3.height / t2.height, i2 = kn();
    return Nn(i2, i2, [-t2.x, -t2.y]), Fn(i2, i2, [n2, r2]), Nn(i2, i2, [e3.x, e3.y]), i2;
  }, e2.prototype.intersect = function(t2, n2) {
    if (!t2) return false;
    t2 instanceof e2 || (t2 = e2.create(t2));
    var r2 = this, i2 = r2.x, a2 = r2.x + r2.width, o2 = r2.y, s2 = r2.y + r2.height, c2 = t2.x, l2 = t2.x + t2.width, u2 = t2.y, d2 = t2.y + t2.height, f2 = !(a2 < c2 || l2 < i2 || s2 < u2 || d2 < o2);
    if (n2) {
      var p2 = 1 / 0, m2 = 0, h2 = Math.abs(a2 - c2), g2 = Math.abs(l2 - i2), _2 = Math.abs(s2 - u2), v2 = Math.abs(d2 - o2), y2 = Math.min(h2, g2), b2 = Math.min(_2, v2);
      a2 < c2 || l2 < i2 ? y2 > m2 && (m2 = y2, h2 < g2 ? Y.set(Gn, -h2, 0) : Y.set(Gn, g2, 0)) : y2 < p2 && (p2 = y2, h2 < g2 ? Y.set(Wn, h2, 0) : Y.set(Wn, -g2, 0)), s2 < u2 || d2 < o2 ? b2 > m2 && (m2 = b2, _2 < v2 ? Y.set(Gn, 0, -_2) : Y.set(Gn, 0, v2)) : y2 < p2 && (p2 = y2, _2 < v2 ? Y.set(Wn, 0, _2) : Y.set(Wn, 0, -v2));
    }
    return n2 && Y.copy(n2, f2 ? Wn : Gn), f2;
  }, e2.prototype.contain = function(e3, t2) {
    var n2 = this;
    return e3 >= n2.x && e3 <= n2.x + n2.width && t2 >= n2.y && t2 <= n2.y + n2.height;
  }, e2.prototype.clone = function() {
    return new e2(this.x, this.y, this.width, this.height);
  }, e2.prototype.copy = function(t2) {
    e2.copy(this, t2);
  }, e2.prototype.plain = function() {
    return { x: this.x, y: this.y, width: this.width, height: this.height };
  }, e2.prototype.isFinite = function() {
    return isFinite(this.x) && isFinite(this.y) && isFinite(this.width) && isFinite(this.height);
  }, e2.prototype.isZero = function() {
    return this.width === 0 || this.height === 0;
  }, e2.create = function(t2) {
    return new e2(t2.x, t2.y, t2.width, t2.height);
  }, e2.copy = function(e3, t2) {
    e3.x = t2.x, e3.y = t2.y, e3.width = t2.width, e3.height = t2.height;
  }, e2.applyTransform = function(t2, n2, r2) {
    if (!r2) {
      t2 !== n2 && e2.copy(t2, n2);
      return;
    }
    if (r2[1] < 1e-5 && r2[1] > -1e-5 && r2[2] < 1e-5 && r2[2] > -1e-5) {
      var i2 = r2[0], a2 = r2[3], o2 = r2[4], s2 = r2[5];
      t2.x = n2.x * i2 + o2, t2.y = n2.y * a2 + s2, t2.width = n2.width * i2, t2.height = n2.height * a2, t2.width < 0 && (t2.x += t2.width, t2.width = -t2.width), t2.height < 0 && (t2.y += t2.height, t2.height = -t2.height);
      return;
    }
    Bn.x = Hn.x = n2.x, Bn.y = Un.y = n2.y, Vn.x = Un.x = n2.x + n2.width, Vn.y = Hn.y = n2.y + n2.height, Bn.transform(r2), Un.transform(r2), Vn.transform(r2), Hn.transform(r2), t2.x = Rn(Bn.x, Vn.x, Hn.x, Un.x), t2.y = Rn(Bn.y, Vn.y, Hn.y, Un.y);
    var c2 = zn(Bn.x, Vn.x, Hn.x, Un.x), l2 = zn(Bn.y, Vn.y, Hn.y, Un.y);
    t2.width = c2 - t2.x, t2.height = l2 - t2.y;
  }, e2;
})(), Kn = `silent`;
function qn(e2, t2, n2) {
  return { type: e2, event: n2, target: t2.target, topTarget: t2.topTarget, cancelBubble: false, offsetX: n2.zrX, offsetY: n2.zrY, gestureEvent: n2.gestureEvent, pinchX: n2.pinchX, pinchY: n2.pinchY, pinchScale: n2.pinchScale, wheelDelta: n2.zrDelta, zrByTouch: n2.zrByTouch, which: n2.which, stop: Jn };
}
function Jn() {
  Cn(this.event);
}
var Yn = (function(e2) {
  s(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3.handler = null, t3;
  }
  return t2.prototype.dispose = function() {
  }, t2.prototype.setCursor = function() {
  }, t2;
})(Qt), Xn = /* @__PURE__ */ (function() {
  function e2(e3, t2) {
    this.x = e3, this.y = t2;
  }
  return e2;
})(), Zn = [`click`, `dblclick`, `mousewheel`, `mouseout`, `mouseup`, `mousedown`, `mousemove`, `contextmenu`], Qn = new X(0, 0, 0, 0), $n = (function(e2) {
  s(t2, e2);
  function t2(t3, n2, r2, i2, a2) {
    var o2 = e2.call(this) || this;
    return o2._hovered = new Xn(0, 0), o2.storage = t3, o2.painter = n2, o2.painterRoot = i2, o2._pointerSize = a2, r2 || (r2 = new Yn()), o2.proxy = null, o2.setHandlerProxy(r2), o2._draggingMgr = new Zt(o2), o2;
  }
  return t2.prototype.setHandlerProxy = function(e3) {
    this.proxy && this.proxy.dispose(), e3 && (z(Zn, function(t3) {
      e3.on && e3.on(t3, this[t3], this);
    }, this), e3.handler = this), this.proxy = e3;
  }, t2.prototype.mousemove = function(e3) {
    var t3 = e3.zrX, n2 = e3.zrY, r2 = nr(this, t3, n2), i2 = this._hovered, a2 = i2.target;
    a2 && !a2.__zr && (i2 = this.findHover(i2.x, i2.y), a2 = i2.target);
    var o2 = this._hovered = r2 ? new Xn(t3, n2) : this.findHover(t3, n2), s2 = o2.target, c2 = this.proxy;
    c2.setCursor && c2.setCursor(s2 ? s2.cursor : `default`), a2 && s2 !== a2 && this.dispatchToElement(i2, `mouseout`, e3), this.dispatchToElement(o2, `mousemove`, e3), s2 && s2 !== a2 && this.dispatchToElement(o2, `mouseover`, e3);
  }, t2.prototype.mouseout = function(e3) {
    var t3 = e3.zrEventControl;
    t3 !== `only_globalout` && this.dispatchToElement(this._hovered, `mouseout`, e3), t3 !== `no_globalout` && this.trigger(`globalout`, { type: `globalout`, event: e3 });
  }, t2.prototype.resize = function() {
    this._hovered = new Xn(0, 0);
  }, t2.prototype.dispatch = function(e3, t3) {
    var n2 = this[e3];
    n2 && n2.call(this, t3);
  }, t2.prototype.dispose = function() {
    this.proxy.dispose(), this.storage = null, this.proxy = null, this.painter = null;
  }, t2.prototype.setCursorStyle = function(e3) {
    var t3 = this.proxy;
    t3.setCursor && t3.setCursor(e3);
  }, t2.prototype.dispatchToElement = function(e3, t3, n2) {
    e3 || (e3 = {});
    var r2 = e3.target;
    if (!(r2 && r2.silent)) {
      for (var i2 = `on` + t3, a2 = qn(t3, e3, n2); r2 && (r2[i2] && (a2.cancelBubble = !!r2[i2].call(r2, a2)), r2.trigger(t3, a2), r2 = r2.__hostTarget ? r2.__hostTarget : r2.parent, !a2.cancelBubble); ) ;
      a2.cancelBubble || (this.trigger(t3, a2), this.painter && this.painter.eachOtherLayer && this.painter.eachOtherLayer(function(e4) {
        typeof e4[i2] == `function` && e4[i2].call(e4, a2), e4.trigger && e4.trigger(t3, a2);
      }));
    }
  }, t2.prototype.findHover = function(e3, t3, n2) {
    var r2 = this.storage.getDisplayList(), i2 = new Xn(e3, t3);
    if (tr(r2, i2, e3, t3, n2), this._pointerSize && !i2.target) {
      for (var a2 = [], o2 = this._pointerSize, s2 = o2 / 2, c2 = new X(e3 - s2, t3 - s2, o2, o2), l2 = r2.length - 1; l2 >= 0; l2--) {
        var u2 = r2[l2];
        u2 !== n2 && !u2.ignore && !u2.ignoreCoarsePointer && (!u2.parent || !u2.parent.ignoreCoarsePointer) && (Qn.copy(u2.getBoundingRect()), u2.transform && Qn.applyTransform(u2.transform), Qn.intersect(c2) && a2.push(u2));
      }
      if (a2.length) {
        for (var d2 = 4, f2 = Math.PI / 12, p2 = Math.PI * 2, m2 = 0; m2 < s2; m2 += d2) for (var h2 = 0; h2 < p2; h2 += f2) if (tr(a2, i2, e3 + m2 * Math.cos(h2), t3 + m2 * Math.sin(h2), n2), i2.target) return i2;
      }
    }
    return i2;
  }, t2.prototype.processGesture = function(e3, t3) {
    this._gestureMgr || (this._gestureMgr = new wn());
    var n2 = this._gestureMgr;
    t3 === `start` && n2.clear();
    var r2 = n2.recognize(e3, this.findHover(e3.zrX, e3.zrY, null).target, this.proxy.dom);
    if (t3 === `end` && n2.clear(), r2) {
      var i2 = r2.type;
      e3.gestureEvent = i2;
      var a2 = new Xn();
      a2.target = r2.target, this.dispatchToElement(a2, i2, r2.event);
    }
  }, t2;
})(Qt);
z([`click`, `mousedown`, `mouseup`, `mousewheel`, `dblclick`, `contextmenu`], function(e2) {
  $n.prototype[e2] = function(t2) {
    var n2 = t2.zrX, r2 = t2.zrY, i2 = nr(this, n2, r2), a2, o2;
    if ((e2 !== `mouseup` || !i2) && (a2 = this.findHover(n2, r2), o2 = a2.target), e2 === `mousedown`) this._downEl = o2, this._downPoint = [t2.zrX, t2.zrY], this._upEl = o2;
    else if (e2 === `mouseup`) this._upEl = o2;
    else if (e2 === `click`) {
      if (this._downEl !== this._upEl || !this._downPoint || Ht(this._downPoint, [t2.zrX, t2.zrY]) > 4) return;
      this._downPoint = null;
    }
    this.dispatchToElement(a2, e2, t2);
  };
});
function er(e2, t2, n2) {
  if (e2[e2.rectHover ? `rectContain` : `contain`](t2, n2)) {
    for (var r2 = e2, i2 = void 0, a2 = false; r2; ) {
      if (r2.ignoreClip && (a2 = true), !a2) {
        var o2 = r2.getClipPath();
        if (o2 && !o2.contain(t2, n2)) return false;
      }
      r2.silent && (i2 = true), r2 = r2.__hostTarget || r2.parent;
    }
    return !i2 || Kn;
  }
  return false;
}
function tr(e2, t2, n2, r2, i2) {
  for (var a2 = e2.length - 1; a2 >= 0; a2--) {
    var o2 = e2[a2], s2 = void 0;
    if (o2 !== i2 && !o2.ignore && (s2 = er(o2, n2, r2)) && (!t2.topTarget && (t2.topTarget = o2), s2 !== Kn)) {
      t2.target = o2;
      break;
    }
  }
}
function nr(e2, t2, n2) {
  var r2 = e2.painter;
  return t2 < 0 || t2 > r2.getWidth() || n2 < 0 || n2 > r2.getHeight();
}
var rr = 32, ir = 7;
function ar(e2) {
  for (var t2 = 0; e2 >= rr; ) t2 |= e2 & 1, e2 >>= 1;
  return e2 + t2;
}
function or(e2, t2, n2, r2) {
  var i2 = t2 + 1;
  if (i2 === n2) return 1;
  if (r2(e2[i2++], e2[t2]) < 0) {
    for (; i2 < n2 && r2(e2[i2], e2[i2 - 1]) < 0; ) i2++;
    sr(e2, t2, i2);
  } else for (; i2 < n2 && r2(e2[i2], e2[i2 - 1]) >= 0; ) i2++;
  return i2 - t2;
}
function sr(e2, t2, n2) {
  for (n2--; t2 < n2; ) {
    var r2 = e2[t2];
    e2[t2++] = e2[n2], e2[n2--] = r2;
  }
}
function cr(e2, t2, n2, r2, i2) {
  for (r2 === t2 && r2++; r2 < n2; r2++) {
    for (var a2 = e2[r2], o2 = t2, s2 = r2, c2; o2 < s2; ) c2 = o2 + s2 >>> 1, i2(a2, e2[c2]) < 0 ? s2 = c2 : o2 = c2 + 1;
    var l2 = r2 - o2;
    switch (l2) {
      case 3:
        e2[o2 + 3] = e2[o2 + 2];
      case 2:
        e2[o2 + 2] = e2[o2 + 1];
      case 1:
        e2[o2 + 1] = e2[o2];
        break;
      default:
        for (; l2 > 0; ) e2[o2 + l2] = e2[o2 + l2 - 1], l2--;
    }
    e2[o2] = a2;
  }
}
function lr(e2, t2, n2, r2, i2, a2) {
  var o2 = 0, s2 = 0, c2 = 1;
  if (a2(e2, t2[n2 + i2]) > 0) {
    for (s2 = r2 - i2; c2 < s2 && a2(e2, t2[n2 + i2 + c2]) > 0; ) o2 = c2, c2 = (c2 << 1) + 1, c2 <= 0 && (c2 = s2);
    c2 > s2 && (c2 = s2), o2 += i2, c2 += i2;
  } else {
    for (s2 = i2 + 1; c2 < s2 && a2(e2, t2[n2 + i2 - c2]) <= 0; ) o2 = c2, c2 = (c2 << 1) + 1, c2 <= 0 && (c2 = s2);
    c2 > s2 && (c2 = s2);
    var l2 = o2;
    o2 = i2 - c2, c2 = i2 - l2;
  }
  for (o2++; o2 < c2; ) {
    var u2 = o2 + (c2 - o2 >>> 1);
    a2(e2, t2[n2 + u2]) > 0 ? o2 = u2 + 1 : c2 = u2;
  }
  return c2;
}
function ur(e2, t2, n2, r2, i2, a2) {
  var o2 = 0, s2 = 0, c2 = 1;
  if (a2(e2, t2[n2 + i2]) < 0) {
    for (s2 = i2 + 1; c2 < s2 && a2(e2, t2[n2 + i2 - c2]) < 0; ) o2 = c2, c2 = (c2 << 1) + 1, c2 <= 0 && (c2 = s2);
    c2 > s2 && (c2 = s2);
    var l2 = o2;
    o2 = i2 - c2, c2 = i2 - l2;
  } else {
    for (s2 = r2 - i2; c2 < s2 && a2(e2, t2[n2 + i2 + c2]) >= 0; ) o2 = c2, c2 = (c2 << 1) + 1, c2 <= 0 && (c2 = s2);
    c2 > s2 && (c2 = s2), o2 += i2, c2 += i2;
  }
  for (o2++; o2 < c2; ) {
    var u2 = o2 + (c2 - o2 >>> 1);
    a2(e2, t2[n2 + u2]) < 0 ? c2 = u2 : o2 = u2 + 1;
  }
  return c2;
}
function dr(e2, t2) {
  var n2 = ir, r2, i2, a2 = 0, o2 = [];
  r2 = [], i2 = [];
  function s2(e3, t3) {
    r2[a2] = e3, i2[a2] = t3, a2 += 1;
  }
  function c2() {
    for (; a2 > 1; ) {
      var e3 = a2 - 2;
      if (e3 >= 1 && i2[e3 - 1] <= i2[e3] + i2[e3 + 1] || e3 >= 2 && i2[e3 - 2] <= i2[e3] + i2[e3 - 1]) i2[e3 - 1] < i2[e3 + 1] && e3--;
      else if (i2[e3] > i2[e3 + 1]) break;
      u2(e3);
    }
  }
  function l2() {
    for (; a2 > 1; ) {
      var e3 = a2 - 2;
      e3 > 0 && i2[e3 - 1] < i2[e3 + 1] && e3--, u2(e3);
    }
  }
  function u2(n3) {
    var o3 = r2[n3], s3 = i2[n3], c3 = r2[n3 + 1], l3 = i2[n3 + 1];
    i2[n3] = s3 + l3, n3 === a2 - 3 && (r2[n3 + 1] = r2[n3 + 2], i2[n3 + 1] = i2[n3 + 2]), a2--;
    var u3 = ur(e2[c3], e2, o3, s3, 0, t2);
    o3 += u3, s3 -= u3, s3 !== 0 && (l3 = lr(e2[o3 + s3 - 1], e2, c3, l3, l3 - 1, t2), l3 !== 0 && (s3 <= l3 ? d2(o3, s3, c3, l3) : f2(o3, s3, c3, l3)));
  }
  function d2(r3, i3, a3, s3) {
    var c3 = 0;
    for (c3 = 0; c3 < i3; c3++) o2[c3] = e2[r3 + c3];
    var l3 = 0, u3 = a3, d3 = r3;
    if (e2[d3++] = e2[u3++], --s3 === 0) {
      for (c3 = 0; c3 < i3; c3++) e2[d3 + c3] = o2[l3 + c3];
      return;
    }
    if (i3 === 1) {
      for (c3 = 0; c3 < s3; c3++) e2[d3 + c3] = e2[u3 + c3];
      e2[d3 + s3] = o2[l3];
      return;
    }
    for (var f3 = n2, p2, m2, h2; ; ) {
      p2 = 0, m2 = 0, h2 = false;
      do
        if (t2(e2[u3], o2[l3]) < 0) {
          if (e2[d3++] = e2[u3++], m2++, p2 = 0, --s3 === 0) {
            h2 = true;
            break;
          }
        } else if (e2[d3++] = o2[l3++], p2++, m2 = 0, --i3 === 1) {
          h2 = true;
          break;
        }
      while ((p2 | m2) < f3);
      if (h2) break;
      do {
        if (p2 = ur(e2[u3], o2, l3, i3, 0, t2), p2 !== 0) {
          for (c3 = 0; c3 < p2; c3++) e2[d3 + c3] = o2[l3 + c3];
          if (d3 += p2, l3 += p2, i3 -= p2, i3 <= 1) {
            h2 = true;
            break;
          }
        }
        if (e2[d3++] = e2[u3++], --s3 === 0) {
          h2 = true;
          break;
        }
        if (m2 = lr(o2[l3], e2, u3, s3, 0, t2), m2 !== 0) {
          for (c3 = 0; c3 < m2; c3++) e2[d3 + c3] = e2[u3 + c3];
          if (d3 += m2, u3 += m2, s3 -= m2, s3 === 0) {
            h2 = true;
            break;
          }
        }
        if (e2[d3++] = o2[l3++], --i3 === 1) {
          h2 = true;
          break;
        }
        f3--;
      } while (p2 >= ir || m2 >= ir);
      if (h2) break;
      f3 < 0 && (f3 = 0), f3 += 2;
    }
    if (n2 = f3, n2 < 1 && (n2 = 1), i3 === 1) {
      for (c3 = 0; c3 < s3; c3++) e2[d3 + c3] = e2[u3 + c3];
      e2[d3 + s3] = o2[l3];
    } else if (i3 === 0) throw Error();
    else for (c3 = 0; c3 < i3; c3++) e2[d3 + c3] = o2[l3 + c3];
  }
  function f2(r3, i3, a3, s3) {
    var c3 = 0;
    for (c3 = 0; c3 < s3; c3++) o2[c3] = e2[a3 + c3];
    var l3 = r3 + i3 - 1, u3 = s3 - 1, d3 = a3 + s3 - 1, f3 = 0, p2 = 0;
    if (e2[d3--] = e2[l3--], --i3 === 0) {
      for (f3 = d3 - (s3 - 1), c3 = 0; c3 < s3; c3++) e2[f3 + c3] = o2[c3];
      return;
    }
    if (s3 === 1) {
      for (d3 -= i3, l3 -= i3, p2 = d3 + 1, f3 = l3 + 1, c3 = i3 - 1; c3 >= 0; c3--) e2[p2 + c3] = e2[f3 + c3];
      e2[d3] = o2[u3];
      return;
    }
    for (var m2 = n2; ; ) {
      var h2 = 0, g2 = 0, _2 = false;
      do
        if (t2(o2[u3], e2[l3]) < 0) {
          if (e2[d3--] = e2[l3--], h2++, g2 = 0, --i3 === 0) {
            _2 = true;
            break;
          }
        } else if (e2[d3--] = o2[u3--], g2++, h2 = 0, --s3 === 1) {
          _2 = true;
          break;
        }
      while ((h2 | g2) < m2);
      if (_2) break;
      do {
        if (h2 = i3 - ur(o2[u3], e2, r3, i3, i3 - 1, t2), h2 !== 0) {
          for (d3 -= h2, l3 -= h2, i3 -= h2, p2 = d3 + 1, f3 = l3 + 1, c3 = h2 - 1; c3 >= 0; c3--) e2[p2 + c3] = e2[f3 + c3];
          if (i3 === 0) {
            _2 = true;
            break;
          }
        }
        if (e2[d3--] = o2[u3--], --s3 === 1) {
          _2 = true;
          break;
        }
        if (g2 = s3 - lr(e2[l3], o2, 0, s3, s3 - 1, t2), g2 !== 0) {
          for (d3 -= g2, u3 -= g2, s3 -= g2, p2 = d3 + 1, f3 = u3 + 1, c3 = 0; c3 < g2; c3++) e2[p2 + c3] = o2[f3 + c3];
          if (s3 <= 1) {
            _2 = true;
            break;
          }
        }
        if (e2[d3--] = e2[l3--], --i3 === 0) {
          _2 = true;
          break;
        }
        m2--;
      } while (h2 >= ir || g2 >= ir);
      if (_2) break;
      m2 < 0 && (m2 = 0), m2 += 2;
    }
    if (n2 = m2, n2 < 1 && (n2 = 1), s3 === 1) {
      for (d3 -= i3, l3 -= i3, p2 = d3 + 1, f3 = l3 + 1, c3 = i3 - 1; c3 >= 0; c3--) e2[p2 + c3] = e2[f3 + c3];
      e2[d3] = o2[u3];
    } else if (s3 === 0) throw Error();
    else for (f3 = d3 - (s3 - 1), c3 = 0; c3 < s3; c3++) e2[f3 + c3] = o2[c3];
  }
  return { mergeRuns: c2, forceMergeRuns: l2, pushRun: s2 };
}
function fr(e2, t2, n2, r2) {
  n2 || (n2 = 0), r2 || (r2 = e2.length);
  var i2 = r2 - n2;
  if (!(i2 < 2)) {
    var a2 = 0;
    if (i2 < rr) {
      a2 = or(e2, n2, r2, t2), cr(e2, n2, r2, n2 + a2, t2);
      return;
    }
    var o2 = dr(e2, t2), s2 = ar(i2);
    do {
      if (a2 = or(e2, n2, r2, t2), a2 < s2) {
        var c2 = i2;
        c2 > s2 && (c2 = s2), cr(e2, n2, n2 + c2, n2 + a2, t2), a2 = c2;
      }
      o2.pushRun(n2, a2), o2.mergeRuns(), i2 -= a2, n2 += a2;
    } while (i2 !== 0);
    o2.forceMergeRuns();
  }
}
var pr = false;
function mr() {
  pr || (pr = true, console.warn(`z / z2 / zlevel of displayable is invalid, which may cause unexpected errors`));
}
function hr(e2, t2) {
  return e2.zlevel === t2.zlevel ? e2.z === t2.z ? e2.z2 - t2.z2 : e2.z - t2.z : e2.zlevel - t2.zlevel;
}
var gr = (function() {
  function e2() {
    this._roots = [], this._displayList = [], this._displayListLen = 0, this.displayableSortFunc = hr;
  }
  return e2.prototype.traverse = function(e3, t2) {
    for (var n2 = 0; n2 < this._roots.length; n2++) this._roots[n2].traverse(e3, t2);
  }, e2.prototype.getDisplayList = function(e3, t2) {
    t2 || (t2 = false);
    var n2 = this._displayList;
    return (e3 || !n2.length) && this.updateDisplayList(t2), n2;
  }, e2.prototype.updateDisplayList = function(e3) {
    this._displayListLen = 0;
    for (var t2 = this._roots, n2 = this._displayList, r2 = 0, i2 = t2.length; r2 < i2; r2++) this._updateAndAddDisplayable(t2[r2], null, e3);
    n2.length = this._displayListLen, fr(n2, hr);
  }, e2.prototype._updateAndAddDisplayable = function(e3, t2, n2) {
    if (!e3.ignore || n2) {
      e3.beforeUpdate(), e3.update(), e3.afterUpdate();
      var r2 = e3.getClipPath();
      if (e3.ignoreClip) t2 = null;
      else if (r2) {
        t2 = t2 ? t2.slice() : [];
        for (var i2 = r2, a2 = e3; i2; ) i2.parent = a2, i2.updateTransform(), t2.push(i2), a2 = i2, i2 = i2.getClipPath();
      }
      if (e3.childrenRef) {
        for (var o2 = e3.childrenRef(), s2 = 0; s2 < o2.length; s2++) {
          var c2 = o2[s2];
          e3.__dirty && (c2.__dirty |= 1), this._updateAndAddDisplayable(c2, t2, n2);
        }
        e3.__dirty = 0;
      } else {
        var l2 = e3;
        t2 && t2.length ? l2.__clipPaths = t2 : l2.__clipPaths && l2.__clipPaths.length > 0 && (l2.__clipPaths = []), isNaN(l2.z) && (mr(), l2.z = 0), isNaN(l2.z2) && (mr(), l2.z2 = 0), isNaN(l2.zlevel) && (mr(), l2.zlevel = 0), this._displayList[this._displayListLen++] = l2;
      }
      var u2 = e3.getDecalElement && e3.getDecalElement();
      u2 && this._updateAndAddDisplayable(u2, t2, n2);
      var d2 = e3.getTextGuideLine();
      d2 && this._updateAndAddDisplayable(d2, t2, n2);
      var f2 = e3.getTextContent();
      f2 && this._updateAndAddDisplayable(f2, t2, n2);
    }
  }, e2.prototype.addRoot = function(e3) {
    e3.__zr && e3.__zr.storage === this || this._roots.push(e3);
  }, e2.prototype.delRoot = function(e3) {
    if (e3 instanceof Array) {
      for (var t2 = 0, n2 = e3.length; t2 < n2; t2++) this.delRoot(e3[t2]);
      return;
    }
    var r2 = Ve(this._roots, e3);
    r2 >= 0 && this._roots.splice(r2, 1);
  }, e2.prototype.delAllRoots = function() {
    this._roots = [], this._displayList = [], this._displayListLen = 0;
  }, e2.prototype.getRoots = function() {
    return this._roots;
  }, e2.prototype.dispose = function() {
    this._displayList = null, this._roots = null;
  }, e2;
})(), _r = I.hasGlobalWindow && (window.requestAnimationFrame && window.requestAnimationFrame.bind(window) || window.msRequestAnimationFrame && window.msRequestAnimationFrame.bind(window) || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame) || function(e2) {
  return setTimeout(e2, 16);
}, vr = { linear: function(e2) {
  return e2;
}, quadraticIn: function(e2) {
  return e2 * e2;
}, quadraticOut: function(e2) {
  return e2 * (2 - e2);
}, quadraticInOut: function(e2) {
  return (e2 *= 2) < 1 ? 0.5 * e2 * e2 : -0.5 * (--e2 * (e2 - 2) - 1);
}, cubicIn: function(e2) {
  return e2 * e2 * e2;
}, cubicOut: function(e2) {
  return --e2 * e2 * e2 + 1;
}, cubicInOut: function(e2) {
  return (e2 *= 2) < 1 ? 0.5 * e2 * e2 * e2 : 0.5 * ((e2 -= 2) * e2 * e2 + 2);
}, quarticIn: function(e2) {
  return e2 * e2 * e2 * e2;
}, quarticOut: function(e2) {
  return 1 - --e2 * e2 * e2 * e2;
}, quarticInOut: function(e2) {
  return (e2 *= 2) < 1 ? 0.5 * e2 * e2 * e2 * e2 : -0.5 * ((e2 -= 2) * e2 * e2 * e2 - 2);
}, quinticIn: function(e2) {
  return e2 * e2 * e2 * e2 * e2;
}, quinticOut: function(e2) {
  return --e2 * e2 * e2 * e2 * e2 + 1;
}, quinticInOut: function(e2) {
  return (e2 *= 2) < 1 ? 0.5 * e2 * e2 * e2 * e2 * e2 : 0.5 * ((e2 -= 2) * e2 * e2 * e2 * e2 + 2);
}, sinusoidalIn: function(e2) {
  return 1 - Math.cos(e2 * Math.PI / 2);
}, sinusoidalOut: function(e2) {
  return Math.sin(e2 * Math.PI / 2);
}, sinusoidalInOut: function(e2) {
  return 0.5 * (1 - Math.cos(Math.PI * e2));
}, exponentialIn: function(e2) {
  return e2 === 0 ? 0 : 1024 ** (e2 - 1);
}, exponentialOut: function(e2) {
  return e2 === 1 ? 1 : 1 - 2 ** (-10 * e2);
}, exponentialInOut: function(e2) {
  return e2 === 0 ? 0 : e2 === 1 ? 1 : (e2 *= 2) < 1 ? 0.5 * 1024 ** (e2 - 1) : 0.5 * (-(2 ** (-10 * (e2 - 1))) + 2);
}, circularIn: function(e2) {
  return 1 - Math.sqrt(1 - e2 * e2);
}, circularOut: function(e2) {
  return Math.sqrt(1 - --e2 * e2);
}, circularInOut: function(e2) {
  return (e2 *= 2) < 1 ? -0.5 * (Math.sqrt(1 - e2 * e2) - 1) : 0.5 * (Math.sqrt(1 - (e2 -= 2) * e2) + 1);
}, elasticIn: function(e2) {
  var t2, n2 = 0.1, r2 = 0.4;
  return e2 === 0 ? 0 : e2 === 1 ? 1 : (!n2 || n2 < 1 ? (n2 = 1, t2 = r2 / 4) : t2 = r2 * Math.asin(1 / n2) / (2 * Math.PI), -(n2 * 2 ** (10 * --e2) * Math.sin((e2 - t2) * (2 * Math.PI) / r2)));
}, elasticOut: function(e2) {
  var t2, n2 = 0.1, r2 = 0.4;
  return e2 === 0 ? 0 : e2 === 1 ? 1 : (!n2 || n2 < 1 ? (n2 = 1, t2 = r2 / 4) : t2 = r2 * Math.asin(1 / n2) / (2 * Math.PI), n2 * 2 ** (-10 * e2) * Math.sin((e2 - t2) * (2 * Math.PI) / r2) + 1);
}, elasticInOut: function(e2) {
  var t2, n2 = 0.1, r2 = 0.4;
  return e2 === 0 ? 0 : e2 === 1 ? 1 : (!n2 || n2 < 1 ? (n2 = 1, t2 = r2 / 4) : t2 = r2 * Math.asin(1 / n2) / (2 * Math.PI), (e2 *= 2) < 1 ? -0.5 * (n2 * 2 ** (10 * --e2) * Math.sin((e2 - t2) * (2 * Math.PI) / r2)) : n2 * 2 ** (-10 * --e2) * Math.sin((e2 - t2) * (2 * Math.PI) / r2) * 0.5 + 1);
}, backIn: function(e2) {
  var t2 = 1.70158;
  return e2 * e2 * ((t2 + 1) * e2 - t2);
}, backOut: function(e2) {
  var t2 = 1.70158;
  return --e2 * e2 * ((t2 + 1) * e2 + t2) + 1;
}, backInOut: function(e2) {
  var t2 = 2.5949095;
  return (e2 *= 2) < 1 ? 0.5 * (e2 * e2 * ((t2 + 1) * e2 - t2)) : 0.5 * ((e2 -= 2) * e2 * ((t2 + 1) * e2 + t2) + 2);
}, bounceIn: function(e2) {
  return 1 - vr.bounceOut(1 - e2);
}, bounceOut: function(e2) {
  return e2 < 1 / 2.75 ? 7.5625 * e2 * e2 : e2 < 2 / 2.75 ? 7.5625 * (e2 -= 1.5 / 2.75) * e2 + 0.75 : e2 < 2.5 / 2.75 ? 7.5625 * (e2 -= 2.25 / 2.75) * e2 + 0.9375 : 7.5625 * (e2 -= 2.625 / 2.75) * e2 + 0.984375;
}, bounceInOut: function(e2) {
  return e2 < 0.5 ? vr.bounceIn(e2 * 2) * 0.5 : vr.bounceOut(e2 * 2 - 1) * 0.5 + 0.5;
} }, yr = Math.pow, br = Math.sqrt, xr = 1e-8, Sr = 1e-4, Cr = br(3), wr = 1 / 3, Tr = Tt(), Er = Tt(), Dr = Tt();
function Or(e2) {
  return e2 > -xr && e2 < xr;
}
function kr(e2) {
  return e2 > xr || e2 < -xr;
}
function Ar(e2, t2, n2, r2, i2) {
  var a2 = 1 - i2;
  return a2 * a2 * (a2 * e2 + 3 * i2 * t2) + i2 * i2 * (i2 * r2 + 3 * a2 * n2);
}
function jr(e2, t2, n2, r2, i2) {
  var a2 = 1 - i2;
  return 3 * (((t2 - e2) * a2 + 2 * (n2 - t2) * i2) * a2 + (r2 - n2) * i2 * i2);
}
function Mr(e2, t2, n2, r2, i2, a2) {
  var o2 = r2 + 3 * (t2 - n2) - e2, s2 = 3 * (n2 - t2 * 2 + e2), c2 = 3 * (t2 - e2), l2 = e2 - i2, u2 = s2 * s2 - 3 * o2 * c2, d2 = s2 * c2 - 9 * o2 * l2, f2 = c2 * c2 - 3 * s2 * l2, p2 = 0;
  if (Or(u2) && Or(d2)) {
    if (Or(s2)) a2[0] = 0;
    else {
      var m2 = -c2 / s2;
      m2 >= 0 && m2 <= 1 && (a2[p2++] = m2);
    }
  } else {
    var h2 = d2 * d2 - 4 * u2 * f2;
    if (Or(h2)) {
      var g2 = d2 / u2, m2 = -s2 / o2 + g2, _2 = -g2 / 2;
      m2 >= 0 && m2 <= 1 && (a2[p2++] = m2), _2 >= 0 && _2 <= 1 && (a2[p2++] = _2);
    } else if (h2 > 0) {
      var v2 = br(h2), y2 = u2 * s2 + 1.5 * o2 * (-d2 + v2), b2 = u2 * s2 + 1.5 * o2 * (-d2 - v2);
      y2 = y2 < 0 ? -yr(-y2, wr) : yr(y2, wr), b2 = b2 < 0 ? -yr(-b2, wr) : yr(b2, wr);
      var m2 = (-s2 - (y2 + b2)) / (3 * o2);
      m2 >= 0 && m2 <= 1 && (a2[p2++] = m2);
    } else {
      var x2 = (2 * u2 * s2 - 3 * o2 * d2) / (2 * br(u2 * u2 * u2)), S2 = Math.acos(x2) / 3, C2 = br(u2), w2 = Math.cos(S2), m2 = (-s2 - 2 * C2 * w2) / (3 * o2), _2 = (-s2 + C2 * (w2 + Cr * Math.sin(S2))) / (3 * o2), T2 = (-s2 + C2 * (w2 - Cr * Math.sin(S2))) / (3 * o2);
      m2 >= 0 && m2 <= 1 && (a2[p2++] = m2), _2 >= 0 && _2 <= 1 && (a2[p2++] = _2), T2 >= 0 && T2 <= 1 && (a2[p2++] = T2);
    }
  }
  return p2;
}
function Nr(e2, t2, n2, r2, i2) {
  var a2 = 6 * n2 - 12 * t2 + 6 * e2, o2 = 9 * t2 + 3 * r2 - 3 * e2 - 9 * n2, s2 = 3 * t2 - 3 * e2, c2 = 0;
  if (Or(o2)) {
    if (kr(a2)) {
      var l2 = -s2 / a2;
      l2 >= 0 && l2 <= 1 && (i2[c2++] = l2);
    }
  } else {
    var u2 = a2 * a2 - 4 * o2 * s2;
    if (Or(u2)) i2[0] = -a2 / (2 * o2);
    else if (u2 > 0) {
      var d2 = br(u2), l2 = (-a2 + d2) / (2 * o2), f2 = (-a2 - d2) / (2 * o2);
      l2 >= 0 && l2 <= 1 && (i2[c2++] = l2), f2 >= 0 && f2 <= 1 && (i2[c2++] = f2);
    }
  }
  return c2;
}
function Pr(e2, t2, n2, r2, i2, a2) {
  var o2 = (t2 - e2) * i2 + e2, s2 = (n2 - t2) * i2 + t2, c2 = (r2 - n2) * i2 + n2, l2 = (s2 - o2) * i2 + o2, u2 = (c2 - s2) * i2 + s2, d2 = (u2 - l2) * i2 + l2;
  a2[0] = e2, a2[1] = o2, a2[2] = l2, a2[3] = d2, a2[4] = d2, a2[5] = u2, a2[6] = c2, a2[7] = r2;
}
function Fr(e2, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2) {
  var d2, f2 = 5e-3, p2 = 1 / 0, m2, h2, g2, _2;
  Tr[0] = c2, Tr[1] = l2;
  for (var v2 = 0; v2 < 1; v2 += 0.05) Er[0] = Ar(e2, n2, i2, o2, v2), Er[1] = Ar(t2, r2, a2, s2, v2), g2 = Wt(Tr, Er), g2 < p2 && (d2 = v2, p2 = g2);
  p2 = 1 / 0;
  for (var y2 = 0; y2 < 32 && !(f2 < Sr); y2++) m2 = d2 - f2, h2 = d2 + f2, Er[0] = Ar(e2, n2, i2, o2, m2), Er[1] = Ar(t2, r2, a2, s2, m2), g2 = Wt(Er, Tr), m2 >= 0 && g2 < p2 ? (d2 = m2, p2 = g2) : (Dr[0] = Ar(e2, n2, i2, o2, h2), Dr[1] = Ar(t2, r2, a2, s2, h2), _2 = Wt(Dr, Tr), h2 <= 1 && _2 < p2 ? (d2 = h2, p2 = _2) : f2 *= 0.5);
  return u2 && (u2[0] = Ar(e2, n2, i2, o2, d2), u2[1] = Ar(t2, r2, a2, s2, d2)), br(p2);
}
function Ir(e2, t2, n2, r2, i2, a2, o2, s2, c2) {
  for (var l2 = e2, u2 = t2, d2 = 0, f2 = 1 / c2, p2 = 1; p2 <= c2; p2++) {
    var m2 = p2 * f2, h2 = Ar(e2, n2, i2, o2, m2), g2 = Ar(t2, r2, a2, s2, m2), _2 = h2 - l2, v2 = g2 - u2;
    d2 += Math.sqrt(_2 * _2 + v2 * v2), l2 = h2, u2 = g2;
  }
  return d2;
}
function Lr(e2, t2, n2, r2) {
  var i2 = 1 - r2;
  return i2 * (i2 * e2 + 2 * r2 * t2) + r2 * r2 * n2;
}
function Rr(e2, t2, n2, r2) {
  return 2 * ((1 - r2) * (t2 - e2) + r2 * (n2 - t2));
}
function zr(e2, t2, n2, r2, i2) {
  var a2 = e2 - 2 * t2 + n2, o2 = 2 * (t2 - e2), s2 = e2 - r2, c2 = 0;
  if (Or(a2)) {
    if (kr(o2)) {
      var l2 = -s2 / o2;
      l2 >= 0 && l2 <= 1 && (i2[c2++] = l2);
    }
  } else {
    var u2 = o2 * o2 - 4 * a2 * s2;
    if (Or(u2)) {
      var l2 = -o2 / (2 * a2);
      l2 >= 0 && l2 <= 1 && (i2[c2++] = l2);
    } else if (u2 > 0) {
      var d2 = br(u2), l2 = (-o2 + d2) / (2 * a2), f2 = (-o2 - d2) / (2 * a2);
      l2 >= 0 && l2 <= 1 && (i2[c2++] = l2), f2 >= 0 && f2 <= 1 && (i2[c2++] = f2);
    }
  }
  return c2;
}
function Br(e2, t2, n2) {
  var r2 = e2 + n2 - 2 * t2;
  return r2 === 0 ? 0.5 : (e2 - t2) / r2;
}
function Vr(e2, t2, n2, r2, i2) {
  var a2 = (t2 - e2) * r2 + e2, o2 = (n2 - t2) * r2 + t2, s2 = (o2 - a2) * r2 + a2;
  i2[0] = e2, i2[1] = a2, i2[2] = s2, i2[3] = s2, i2[4] = o2, i2[5] = n2;
}
function Hr(e2, t2, n2, r2, i2, a2, o2, s2, c2) {
  var l2, u2 = 5e-3, d2 = 1 / 0;
  Tr[0] = o2, Tr[1] = s2;
  for (var f2 = 0; f2 < 1; f2 += 0.05) {
    Er[0] = Lr(e2, n2, i2, f2), Er[1] = Lr(t2, r2, a2, f2);
    var p2 = Wt(Tr, Er);
    p2 < d2 && (l2 = f2, d2 = p2);
  }
  d2 = 1 / 0;
  for (var m2 = 0; m2 < 32 && !(u2 < Sr); m2++) {
    var h2 = l2 - u2, g2 = l2 + u2;
    Er[0] = Lr(e2, n2, i2, h2), Er[1] = Lr(t2, r2, a2, h2);
    var p2 = Wt(Er, Tr);
    if (h2 >= 0 && p2 < d2) l2 = h2, d2 = p2;
    else {
      Dr[0] = Lr(e2, n2, i2, g2), Dr[1] = Lr(t2, r2, a2, g2);
      var _2 = Wt(Dr, Tr);
      g2 <= 1 && _2 < d2 ? (l2 = g2, d2 = _2) : u2 *= 0.5;
    }
  }
  return c2 && (c2[0] = Lr(e2, n2, i2, l2), c2[1] = Lr(t2, r2, a2, l2)), br(d2);
}
function Ur(e2, t2, n2, r2, i2, a2, o2) {
  for (var s2 = e2, c2 = t2, l2 = 0, u2 = 1 / o2, d2 = 1; d2 <= o2; d2++) {
    var f2 = d2 * u2, p2 = Lr(e2, n2, i2, f2), m2 = Lr(t2, r2, a2, f2), h2 = p2 - s2, g2 = m2 - c2;
    l2 += Math.sqrt(h2 * h2 + g2 * g2), s2 = p2, c2 = m2;
  }
  return l2;
}
var Wr = /cubic-bezier\(([0-9,\.e ]+)\)/;
function Gr(e2) {
  var t2 = e2 && Wr.exec(e2);
  if (t2) {
    var n2 = t2[1].split(`,`), r2 = +ut(n2[0]), i2 = +ut(n2[1]), a2 = +ut(n2[2]), o2 = +ut(n2[3]);
    if (isNaN(r2 + i2 + a2 + o2)) return;
    var s2 = [];
    return function(e3) {
      return e3 <= 0 ? 0 : e3 >= 1 ? 1 : Mr(0, r2, a2, 1, e3, s2) && Ar(0, i2, o2, 1, s2[0]);
    };
  }
}
var Kr = (function() {
  function e2(e3) {
    this._inited = false, this._startTime = 0, this._pausedTime = 0, this._paused = false, this._life = e3.life || 1e3, this._delay = e3.delay || 0, this.loop = e3.loop || false, this.onframe = e3.onframe || St, this.ondestroy = e3.ondestroy || St, this.onrestart = e3.onrestart || St, e3.easing && this.setEasing(e3.easing);
  }
  return e2.prototype.step = function(e3, t2) {
    if (this._inited || (this._inited = (this._startTime = e3 + this._delay, true)), this._paused) {
      this._pausedTime += t2;
      return;
    }
    var n2 = this._life, r2 = e3 - this._startTime - this._pausedTime, i2 = r2 / n2;
    i2 < 0 && (i2 = 0), i2 = Math.min(i2, 1);
    var a2 = this.easingFunc, o2 = a2 ? a2(i2) : i2;
    if (this.onframe(o2), i2 === 1) {
      if (this.loop) {
        var s2 = r2 % n2;
        this._startTime = e3 - s2, this._pausedTime = 0, this.onrestart();
      } else return true;
    }
    return false;
  }, e2.prototype.pause = function() {
    this._paused = true;
  }, e2.prototype.resume = function() {
    this._paused = false;
  }, e2.prototype.setEasing = function(e3) {
    this.easing = e3, this.easingFunc = U(e3) ? e3 : vr[e3] || Gr(e3);
  }, e2;
})(), qr = /* @__PURE__ */ (function() {
  function e2(e3) {
    this.value = e3;
  }
  return e2;
})(), Jr = (function() {
  function e2() {
    this._len = 0;
  }
  return e2.prototype.insert = function(e3) {
    var t2 = new qr(e3);
    return this.insertEntry(t2), t2;
  }, e2.prototype.insertEntry = function(e3) {
    this.head ? (this.tail.next = e3, e3.prev = this.tail, e3.next = null, this.tail = e3) : this.head = this.tail = e3, this._len++;
  }, e2.prototype.remove = function(e3) {
    var t2 = e3.prev, n2 = e3.next;
    t2 ? t2.next = n2 : this.head = n2, n2 ? n2.prev = t2 : this.tail = t2, e3.next = e3.prev = null, this._len--;
  }, e2.prototype.len = function() {
    return this._len;
  }, e2.prototype.clear = function() {
    this.head = this.tail = null, this._len = 0;
  }, e2;
})(), Yr = (function() {
  function e2(e3) {
    this._list = new Jr(), this._maxSize = 10, this._map = {}, this._maxSize = e3;
  }
  return e2.prototype.put = function(e3, t2) {
    var n2 = this._list, r2 = this._map, i2 = null;
    if (r2[e3] == null) {
      var a2 = n2.len(), o2 = this._lastRemovedEntry;
      if (a2 >= this._maxSize && a2 > 0) {
        var s2 = n2.head;
        n2.remove(s2), delete r2[s2.key], i2 = s2.value, this._lastRemovedEntry = s2;
      }
      o2 ? o2.value = t2 : o2 = new qr(t2), o2.key = e3, n2.insertEntry(o2), r2[e3] = o2;
    }
    return i2;
  }, e2.prototype.get = function(e3) {
    var t2 = this._map[e3], n2 = this._list;
    if (t2 != null) return t2 !== n2.tail && (n2.remove(t2), n2.insertEntry(t2)), t2.value;
  }, e2.prototype.clear = function() {
    this._list.clear(), this._map = {};
  }, e2.prototype.len = function() {
    return this._list.len();
  }, e2;
})(), Xr = n({ fastLerp: () => hi, fastMapToColor: () => gi, lerp: () => _i, lift: () => pi, liftColor: () => Ti, lum: () => Si, mapToColor: () => vi, modifyAlpha: () => bi, modifyHSL: () => yi, parse: () => ui, random: () => Ci, stringify: () => xi, toHex: () => mi }), Zr = { transparent: [0, 0, 0, 0], aliceblue: [240, 248, 255, 1], antiquewhite: [250, 235, 215, 1], aqua: [0, 255, 255, 1], aquamarine: [127, 255, 212, 1], azure: [240, 255, 255, 1], beige: [245, 245, 220, 1], bisque: [255, 228, 196, 1], black: [0, 0, 0, 1], blanchedalmond: [255, 235, 205, 1], blue: [0, 0, 255, 1], blueviolet: [138, 43, 226, 1], brown: [165, 42, 42, 1], burlywood: [222, 184, 135, 1], cadetblue: [95, 158, 160, 1], chartreuse: [127, 255, 0, 1], chocolate: [210, 105, 30, 1], coral: [255, 127, 80, 1], cornflowerblue: [100, 149, 237, 1], cornsilk: [255, 248, 220, 1], crimson: [220, 20, 60, 1], cyan: [0, 255, 255, 1], darkblue: [0, 0, 139, 1], darkcyan: [0, 139, 139, 1], darkgoldenrod: [184, 134, 11, 1], darkgray: [169, 169, 169, 1], darkgreen: [0, 100, 0, 1], darkgrey: [169, 169, 169, 1], darkkhaki: [189, 183, 107, 1], darkmagenta: [139, 0, 139, 1], darkolivegreen: [85, 107, 47, 1], darkorange: [255, 140, 0, 1], darkorchid: [153, 50, 204, 1], darkred: [139, 0, 0, 1], darksalmon: [233, 150, 122, 1], darkseagreen: [143, 188, 143, 1], darkslateblue: [72, 61, 139, 1], darkslategray: [47, 79, 79, 1], darkslategrey: [47, 79, 79, 1], darkturquoise: [0, 206, 209, 1], darkviolet: [148, 0, 211, 1], deeppink: [255, 20, 147, 1], deepskyblue: [0, 191, 255, 1], dimgray: [105, 105, 105, 1], dimgrey: [105, 105, 105, 1], dodgerblue: [30, 144, 255, 1], firebrick: [178, 34, 34, 1], floralwhite: [255, 250, 240, 1], forestgreen: [34, 139, 34, 1], fuchsia: [255, 0, 255, 1], gainsboro: [220, 220, 220, 1], ghostwhite: [248, 248, 255, 1], gold: [255, 215, 0, 1], goldenrod: [218, 165, 32, 1], gray: [128, 128, 128, 1], green: [0, 128, 0, 1], greenyellow: [173, 255, 47, 1], grey: [128, 128, 128, 1], honeydew: [240, 255, 240, 1], hotpink: [255, 105, 180, 1], indianred: [205, 92, 92, 1], indigo: [75, 0, 130, 1], ivory: [255, 255, 240, 1], khaki: [240, 230, 140, 1], lavender: [230, 230, 250, 1], lavenderblush: [255, 240, 245, 1], lawngreen: [124, 252, 0, 1], lemonchiffon: [255, 250, 205, 1], lightblue: [173, 216, 230, 1], lightcoral: [240, 128, 128, 1], lightcyan: [224, 255, 255, 1], lightgoldenrodyellow: [250, 250, 210, 1], lightgray: [211, 211, 211, 1], lightgreen: [144, 238, 144, 1], lightgrey: [211, 211, 211, 1], lightpink: [255, 182, 193, 1], lightsalmon: [255, 160, 122, 1], lightseagreen: [32, 178, 170, 1], lightskyblue: [135, 206, 250, 1], lightslategray: [119, 136, 153, 1], lightslategrey: [119, 136, 153, 1], lightsteelblue: [176, 196, 222, 1], lightyellow: [255, 255, 224, 1], lime: [0, 255, 0, 1], limegreen: [50, 205, 50, 1], linen: [250, 240, 230, 1], magenta: [255, 0, 255, 1], maroon: [128, 0, 0, 1], mediumaquamarine: [102, 205, 170, 1], mediumblue: [0, 0, 205, 1], mediumorchid: [186, 85, 211, 1], mediumpurple: [147, 112, 219, 1], mediumseagreen: [60, 179, 113, 1], mediumslateblue: [123, 104, 238, 1], mediumspringgreen: [0, 250, 154, 1], mediumturquoise: [72, 209, 204, 1], mediumvioletred: [199, 21, 133, 1], midnightblue: [25, 25, 112, 1], mintcream: [245, 255, 250, 1], mistyrose: [255, 228, 225, 1], moccasin: [255, 228, 181, 1], navajowhite: [255, 222, 173, 1], navy: [0, 0, 128, 1], oldlace: [253, 245, 230, 1], olive: [128, 128, 0, 1], olivedrab: [107, 142, 35, 1], orange: [255, 165, 0, 1], orangered: [255, 69, 0, 1], orchid: [218, 112, 214, 1], palegoldenrod: [238, 232, 170, 1], palegreen: [152, 251, 152, 1], paleturquoise: [175, 238, 238, 1], palevioletred: [219, 112, 147, 1], papayawhip: [255, 239, 213, 1], peachpuff: [255, 218, 185, 1], peru: [205, 133, 63, 1], pink: [255, 192, 203, 1], plum: [221, 160, 221, 1], powderblue: [176, 224, 230, 1], purple: [128, 0, 128, 1], red: [255, 0, 0, 1], rosybrown: [188, 143, 143, 1], royalblue: [65, 105, 225, 1], saddlebrown: [139, 69, 19, 1], salmon: [250, 128, 114, 1], sandybrown: [244, 164, 96, 1], seagreen: [46, 139, 87, 1], seashell: [255, 245, 238, 1], sienna: [160, 82, 45, 1], silver: [192, 192, 192, 1], skyblue: [135, 206, 235, 1], slateblue: [106, 90, 205, 1], slategray: [112, 128, 144, 1], slategrey: [112, 128, 144, 1], snow: [255, 250, 250, 1], springgreen: [0, 255, 127, 1], steelblue: [70, 130, 180, 1], tan: [210, 180, 140, 1], teal: [0, 128, 128, 1], thistle: [216, 191, 216, 1], tomato: [255, 99, 71, 1], turquoise: [64, 224, 208, 1], violet: [238, 130, 238, 1], wheat: [245, 222, 179, 1], white: [255, 255, 255, 1], whitesmoke: [245, 245, 245, 1], yellow: [255, 255, 0, 1], yellowgreen: [154, 205, 50, 1] };
function Qr(e2) {
  return e2 = Math.round(e2), e2 < 0 ? 0 : e2 > 255 ? 255 : e2;
}
function $r(e2) {
  return e2 = Math.round(e2), e2 < 0 ? 0 : e2 > 360 ? 360 : e2;
}
function ei(e2) {
  return e2 < 0 ? 0 : e2 > 1 ? 1 : e2;
}
function ti(e2) {
  var t2 = e2;
  return t2.length && t2.charAt(t2.length - 1) === `%` ? Qr(parseFloat(t2) / 100 * 255) : Qr(parseInt(t2, 10));
}
function ni(e2) {
  var t2 = e2;
  return t2.length && t2.charAt(t2.length - 1) === `%` ? ei(parseFloat(t2) / 100) : ei(parseFloat(t2));
}
function ri(e2, t2, n2) {
  return n2 < 0 ? n2 += 1 : n2 > 1 && --n2, n2 * 6 < 1 ? e2 + (t2 - e2) * n2 * 6 : n2 * 2 < 1 ? t2 : n2 * 3 < 2 ? e2 + (t2 - e2) * (2 / 3 - n2) * 6 : e2;
}
function ii(e2, t2, n2) {
  return e2 + (t2 - e2) * n2;
}
function ai(e2, t2, n2, r2, i2) {
  return e2[0] = t2, e2[1] = n2, e2[2] = r2, e2[3] = i2, e2;
}
function oi(e2, t2) {
  return e2[0] = t2[0], e2[1] = t2[1], e2[2] = t2[2], e2[3] = t2[3], e2;
}
var si = new Yr(20), ci = null;
function li(e2, t2) {
  ci && oi(ci, t2), ci = si.put(e2, ci || t2.slice());
}
function ui(e2, t2) {
  if (e2) {
    t2 || (t2 = []);
    var n2 = si.get(e2);
    if (n2) return oi(t2, n2);
    e2 += ``;
    var r2 = e2.replace(/ /g, ``).toLowerCase();
    if (r2 in Zr) return oi(t2, Zr[r2]), li(e2, t2), t2;
    var i2 = r2.length;
    if (r2.charAt(0) === `#`) {
      if (i2 === 4 || i2 === 5) {
        var a2 = parseInt(r2.slice(1, 4), 16);
        if (!(a2 >= 0 && a2 <= 4095)) {
          ai(t2, 0, 0, 0, 1);
          return;
        }
        return ai(t2, (a2 & 3840) >> 4 | (a2 & 3840) >> 8, a2 & 240 | (a2 & 240) >> 4, a2 & 15 | (a2 & 15) << 4, i2 === 5 ? parseInt(r2.slice(4), 16) / 15 : 1), li(e2, t2), t2;
      }
      if (i2 === 7 || i2 === 9) {
        var a2 = parseInt(r2.slice(1, 7), 16);
        if (!(a2 >= 0 && a2 <= 16777215)) {
          ai(t2, 0, 0, 0, 1);
          return;
        }
        return ai(t2, (a2 & 16711680) >> 16, (a2 & 65280) >> 8, a2 & 255, i2 === 9 ? parseInt(r2.slice(7), 16) / 255 : 1), li(e2, t2), t2;
      }
      return;
    }
    var o2 = r2.indexOf(`(`), s2 = r2.indexOf(`)`);
    if (o2 !== -1 && s2 + 1 === i2) {
      var c2 = r2.substr(0, o2), l2 = r2.substr(o2 + 1, s2 - (o2 + 1)).split(`,`), u2 = 1;
      switch (c2) {
        case `rgba`:
          if (l2.length !== 4) return l2.length === 3 ? ai(t2, +l2[0], +l2[1], +l2[2], 1) : ai(t2, 0, 0, 0, 1);
          u2 = ni(l2.pop());
        case `rgb`:
          if (l2.length >= 3) return ai(t2, ti(l2[0]), ti(l2[1]), ti(l2[2]), l2.length === 3 ? u2 : ni(l2[3])), li(e2, t2), t2;
          ai(t2, 0, 0, 0, 1);
          return;
        case `hsla`:
          if (l2.length !== 4) {
            ai(t2, 0, 0, 0, 1);
            return;
          }
          return l2[3] = ni(l2[3]), di(l2, t2), li(e2, t2), t2;
        case `hsl`:
          if (l2.length !== 3) {
            ai(t2, 0, 0, 0, 1);
            return;
          }
          return di(l2, t2), li(e2, t2), t2;
        default:
          return;
      }
    }
    ai(t2, 0, 0, 0, 1);
  }
}
function di(e2, t2) {
  var n2 = (parseFloat(e2[0]) % 360 + 360) % 360 / 360, r2 = ni(e2[1]), i2 = ni(e2[2]), a2 = i2 <= 0.5 ? i2 * (r2 + 1) : i2 + r2 - i2 * r2, o2 = i2 * 2 - a2;
  return t2 || (t2 = []), ai(t2, Qr(ri(o2, a2, n2 + 1 / 3) * 255), Qr(ri(o2, a2, n2) * 255), Qr(ri(o2, a2, n2 - 1 / 3) * 255), 1), e2.length === 4 && (t2[3] = e2[3]), t2;
}
function fi(e2) {
  if (e2) {
    var t2 = e2[0] / 255, n2 = e2[1] / 255, r2 = e2[2] / 255, i2 = Math.min(t2, n2, r2), a2 = Math.max(t2, n2, r2), o2 = a2 - i2, s2 = (a2 + i2) / 2, c2, l2;
    if (o2 === 0) c2 = 0, l2 = 0;
    else {
      l2 = s2 < 0.5 ? o2 / (a2 + i2) : o2 / (2 - a2 - i2);
      var u2 = ((a2 - t2) / 6 + o2 / 2) / o2, d2 = ((a2 - n2) / 6 + o2 / 2) / o2, f2 = ((a2 - r2) / 6 + o2 / 2) / o2;
      t2 === a2 ? c2 = f2 - d2 : n2 === a2 ? c2 = 1 / 3 + u2 - f2 : r2 === a2 && (c2 = 2 / 3 + d2 - u2), c2 < 0 && (c2 += 1), c2 > 1 && --c2;
    }
    var p2 = [c2 * 360, l2, s2];
    return e2[3] != null && p2.push(e2[3]), p2;
  }
}
function pi(e2, t2) {
  var n2 = ui(e2);
  if (n2) {
    for (var r2 = 0; r2 < 3; r2++) t2 < 0 ? n2[r2] = n2[r2] * (1 - t2) | 0 : n2[r2] = (255 - n2[r2]) * t2 + n2[r2] | 0, n2[r2] > 255 ? n2[r2] = 255 : n2[r2] < 0 && (n2[r2] = 0);
    return xi(n2, n2.length === 4 ? `rgba` : `rgb`);
  }
}
function mi(e2) {
  var t2 = ui(e2);
  if (t2) return ((1 << 24) + (t2[0] << 16) + (t2[1] << 8) + +t2[2]).toString(16).slice(1);
}
function hi(e2, t2, n2) {
  if (t2 && t2.length && e2 >= 0 && e2 <= 1) {
    n2 || (n2 = []);
    var r2 = e2 * (t2.length - 1), i2 = Math.floor(r2), a2 = Math.ceil(r2), o2 = t2[i2], s2 = t2[a2], c2 = r2 - i2;
    return n2[0] = Qr(ii(o2[0], s2[0], c2)), n2[1] = Qr(ii(o2[1], s2[1], c2)), n2[2] = Qr(ii(o2[2], s2[2], c2)), n2[3] = ei(ii(o2[3], s2[3], c2)), n2;
  }
}
var gi = hi;
function _i(e2, t2, n2) {
  if (t2 && t2.length && e2 >= 0 && e2 <= 1) {
    var r2 = e2 * (t2.length - 1), i2 = Math.floor(r2), a2 = Math.ceil(r2), o2 = ui(t2[i2]), s2 = ui(t2[a2]), c2 = r2 - i2, l2 = xi([Qr(ii(o2[0], s2[0], c2)), Qr(ii(o2[1], s2[1], c2)), Qr(ii(o2[2], s2[2], c2)), ei(ii(o2[3], s2[3], c2))], `rgba`);
    return n2 ? { color: l2, leftIndex: i2, rightIndex: a2, value: r2 } : l2;
  }
}
var vi = _i;
function yi(e2, t2, n2, r2) {
  var i2 = ui(e2);
  if (e2) return i2 = fi(i2), t2 != null && (i2[0] = $r(t2)), n2 != null && (i2[1] = ni(n2)), r2 != null && (i2[2] = ni(r2)), xi(di(i2), `rgba`);
}
function bi(e2, t2) {
  var n2 = ui(e2);
  if (n2 && t2 != null) return n2[3] = ei(t2), xi(n2, `rgba`);
}
function xi(e2, t2) {
  if (e2 && e2.length) {
    var n2 = e2[0] + `,` + e2[1] + `,` + e2[2];
    return (t2 === `rgba` || t2 === `hsva` || t2 === `hsla`) && (n2 += `,` + e2[3]), t2 + `(` + n2 + `)`;
  }
}
function Si(e2, t2) {
  var n2 = ui(e2);
  return n2 ? (0.299 * n2[0] + 0.587 * n2[1] + 0.114 * n2[2]) * n2[3] / 255 + (1 - n2[3]) * t2 : 0;
}
function Ci() {
  return xi([Math.round(Math.random() * 255), Math.round(Math.random() * 255), Math.round(Math.random() * 255)], `rgb`);
}
var wi = new Yr(100);
function Ti(e2) {
  if (W(e2)) {
    var t2 = wi.get(e2);
    return t2 || (t2 = pi(e2, -0.1), wi.put(e2, t2)), t2;
  }
  if (tt(e2)) {
    var n2 = R({}, e2);
    return n2.colorStops = B(e2.colorStops, function(e3) {
      return { offset: e3.offset, color: pi(e3.color, -0.1) };
    }), n2;
  }
  return e2;
}
var Ei = Math.round;
function Di(e2) {
  var t2;
  if (!e2 || e2 === `transparent`) e2 = `none`;
  else if (typeof e2 == `string` && e2.indexOf(`rgba`) > -1) {
    var n2 = ui(e2);
    n2 && (e2 = `rgb(` + n2[0] + `,` + n2[1] + `,` + n2[2] + `)`, t2 = n2[3]);
  }
  return { color: e2, opacity: t2 ?? 1 };
}
var Oi = 1e-4;
function ki(e2) {
  return e2 < Oi && e2 > -Oi;
}
function Ai(e2) {
  return Ei(e2 * 1e3) / 1e3;
}
function ji(e2) {
  return Ei(e2 * 1e4) / 1e4;
}
function Mi(e2) {
  return `matrix(` + Ai(e2[0]) + `,` + Ai(e2[1]) + `,` + Ai(e2[2]) + `,` + Ai(e2[3]) + `,` + ji(e2[4]) + `,` + ji(e2[5]) + `)`;
}
var Ni = { left: `start`, right: `end`, center: `middle`, middle: `middle` };
function Pi(e2, t2, n2) {
  return n2 === `top` ? e2 += t2 / 2 : n2 === `bottom` && (e2 -= t2 / 2), e2;
}
function Fi(e2) {
  return e2 && (e2.shadowBlur || e2.shadowOffsetX || e2.shadowOffsetY);
}
function Ii(e2) {
  var t2 = e2.style, n2 = e2.getGlobalScale();
  return [t2.shadowColor, (t2.shadowBlur || 0).toFixed(2), (t2.shadowOffsetX || 0).toFixed(2), (t2.shadowOffsetY || 0).toFixed(2), n2[0], n2[1]].join(`,`);
}
function Li(e2) {
  return e2 && !!e2.image;
}
function Ri(e2) {
  return e2 && !!e2.svgElement;
}
function zi(e2) {
  return Li(e2) || Ri(e2);
}
function Bi(e2) {
  return e2.type === `linear`;
}
function Vi(e2) {
  return e2.type === `radial`;
}
function Hi(e2) {
  return e2 && (e2.type === `linear` || e2.type === `radial`);
}
function Ui(e2) {
  return `url(#` + e2 + `)`;
}
function Wi(e2) {
  var t2 = e2.getGlobalScale(), n2 = Math.max(t2[0], t2[1]);
  return Math.max(Math.ceil(Math.log(n2) / Math.log(10)), 1);
}
function Gi(e2) {
  var t2 = e2.x || 0, n2 = e2.y || 0, r2 = (e2.rotation || 0) * Ct, i2 = q(e2.scaleX, 1), a2 = q(e2.scaleY, 1), o2 = e2.skewX || 0, s2 = e2.skewY || 0, c2 = [];
  return (t2 || n2) && c2.push(`translate(` + t2 + `px,` + n2 + `px)`), r2 && c2.push(`rotate(` + r2 + `)`), (i2 !== 1 || a2 !== 1) && c2.push(`scale(` + i2 + `,` + a2 + `)`), (o2 || s2) && c2.push(`skew(` + Ei(o2 * Ct) + `deg, ` + Ei(s2 * Ct) + `deg)`), c2.join(` `);
}
var Ki = (function() {
  return I.hasGlobalWindow && U(window.btoa) ? function(e2) {
    return window.btoa(unescape(encodeURIComponent(e2)));
  } : typeof Buffer < `u` ? function(e2) {
    return Buffer.from(e2).toString(`base64`);
  } : function(e2) {
    return null;
  };
})(), qi = Array.prototype.slice;
function Ji(e2, t2, n2) {
  return (t2 - e2) * n2 + e2;
}
function Yi(e2, t2, n2, r2) {
  for (var i2 = t2.length, a2 = 0; a2 < i2; a2++) e2[a2] = Ji(t2[a2], n2[a2], r2);
  return e2;
}
function Xi(e2, t2, n2, r2) {
  for (var i2 = t2.length, a2 = i2 && t2[0].length, o2 = 0; o2 < i2; o2++) {
    e2[o2] || (e2[o2] = []);
    for (var s2 = 0; s2 < a2; s2++) e2[o2][s2] = Ji(t2[o2][s2], n2[o2][s2], r2);
  }
  return e2;
}
function Zi(e2, t2, n2, r2) {
  for (var i2 = t2.length, a2 = 0; a2 < i2; a2++) e2[a2] = t2[a2] + n2[a2] * r2;
  return e2;
}
function Qi(e2, t2, n2, r2) {
  for (var i2 = t2.length, a2 = i2 && t2[0].length, o2 = 0; o2 < i2; o2++) {
    e2[o2] || (e2[o2] = []);
    for (var s2 = 0; s2 < a2; s2++) e2[o2][s2] = t2[o2][s2] + n2[o2][s2] * r2;
  }
  return e2;
}
function $i(e2, t2) {
  for (var n2 = e2.length, r2 = t2.length, i2 = n2 > r2 ? t2 : e2, a2 = Math.min(n2, r2), o2 = i2[a2 - 1] || { color: [0, 0, 0, 0], offset: 0 }, s2 = a2; s2 < Math.max(n2, r2); s2++) i2.push({ offset: o2.offset, color: o2.color.slice() });
}
function ea(e2, t2, n2) {
  var r2 = e2, i2 = t2;
  if (r2.push && i2.push) {
    var a2 = r2.length, o2 = i2.length;
    if (a2 !== o2) {
      if (a2 > o2) r2.length = o2;
      else for (var s2 = a2; s2 < o2; s2++) r2.push(n2 === 1 ? i2[s2] : qi.call(i2[s2]));
    }
    for (var c2 = r2[0] && r2[0].length, s2 = 0; s2 < r2.length; s2++) if (n2 === 1) isNaN(r2[s2]) && (r2[s2] = i2[s2]);
    else for (var l2 = 0; l2 < c2; l2++) isNaN(r2[s2][l2]) && (r2[s2][l2] = i2[s2][l2]);
  }
}
function ta(e2) {
  if (We(e2)) {
    var t2 = e2.length;
    if (We(e2[0])) {
      for (var n2 = [], r2 = 0; r2 < t2; r2++) n2.push(qi.call(e2[r2]));
      return n2;
    }
    return qi.call(e2);
  }
  return e2;
}
function na(e2) {
  return e2[0] = Math.floor(e2[0]) || 0, e2[1] = Math.floor(e2[1]) || 0, e2[2] = Math.floor(e2[2]) || 0, e2[3] = e2[3] == null ? 1 : e2[3], `rgba(` + e2.join(`,`) + `)`;
}
function ra(e2) {
  return We(e2 && e2[0]) ? 2 : 1;
}
var ia = 0, aa = 1, oa = 2, sa = 3, ca = 4, la = 5, ua = 6;
function da(e2) {
  return e2 === ca || e2 === la;
}
function fa(e2) {
  return e2 === aa || e2 === oa;
}
var pa = [0, 0, 0, 0], ma = (function() {
  function e2(e3) {
    this.keyframes = [], this.discrete = false, this._invalid = false, this._needsSort = false, this._lastFr = 0, this._lastFrP = 0, this.propName = e3;
  }
  return e2.prototype.isFinished = function() {
    return this._finished;
  }, e2.prototype.setFinished = function() {
    this._finished = true, this._additiveTrack && this._additiveTrack.setFinished();
  }, e2.prototype.needsAnimate = function() {
    return this.keyframes.length >= 1;
  }, e2.prototype.getAdditiveTrack = function() {
    return this._additiveTrack;
  }, e2.prototype.addKeyframe = function(e3, t2, n2) {
    this._needsSort = true;
    var r2 = this.keyframes, i2 = r2.length, a2 = false, o2 = ua, s2 = t2;
    if (We(t2)) {
      var c2 = ra(t2);
      o2 = c2, (c2 === 1 && !G(t2[0]) || c2 === 2 && !G(t2[0][0])) && (a2 = true);
    } else if (G(t2) && !it(t2)) o2 = ia;
    else if (W(t2)) {
      if (!isNaN(+t2)) o2 = ia;
      else {
        var l2 = ui(t2);
        l2 && (s2 = l2, o2 = sa);
      }
    } else if (tt(t2)) {
      var u2 = R({}, s2);
      u2.colorStops = B(t2.colorStops, function(e4) {
        return { offset: e4.offset, color: ui(e4.color) };
      }), Bi(t2) ? o2 = ca : Vi(t2) && (o2 = la), s2 = u2;
    }
    i2 === 0 ? this.valType = o2 : (o2 !== this.valType || o2 === ua) && (a2 = true), this.discrete = this.discrete || a2;
    var d2 = { time: e3, value: s2, rawValue: t2, percent: 0 };
    return n2 && (d2.easing = n2, d2.easingFunc = U(n2) ? n2 : vr[n2] || Gr(n2)), r2.push(d2), d2;
  }, e2.prototype.prepare = function(e3, t2) {
    var n2 = this.keyframes;
    this._needsSort && n2.sort(function(e4, t3) {
      return e4.time - t3.time;
    });
    for (var r2 = this.valType, i2 = n2.length, a2 = n2[i2 - 1], o2 = this.discrete, s2 = fa(r2), c2 = da(r2), l2 = 0; l2 < i2; l2++) {
      var u2 = n2[l2], d2 = u2.value, f2 = a2.value;
      u2.percent = u2.time / e3, o2 || (s2 && l2 !== i2 - 1 ? ea(d2, f2, r2) : c2 && $i(d2.colorStops, f2.colorStops));
    }
    if (!o2 && r2 !== la && t2 && this.needsAnimate() && t2.needsAnimate() && r2 === t2.valType && !t2._finished) {
      this._additiveTrack = t2;
      for (var p2 = n2[0].value, l2 = 0; l2 < i2; l2++) r2 === ia ? n2[l2].additiveValue = n2[l2].value - p2 : r2 === sa ? n2[l2].additiveValue = Zi([], n2[l2].value, p2, -1) : fa(r2) && (n2[l2].additiveValue = r2 === aa ? Zi([], n2[l2].value, p2, -1) : Qi([], n2[l2].value, p2, -1));
    }
  }, e2.prototype.step = function(e3, t2) {
    if (!this._finished) {
      this._additiveTrack && this._additiveTrack._finished && (this._additiveTrack = null);
      var n2 = this._additiveTrack != null, r2 = n2 ? `additiveValue` : `value`, i2 = this.valType, a2 = this.keyframes, o2 = a2.length, s2 = this.propName, c2 = i2 === sa, l2, u2 = this._lastFr, d2 = Math.min, f2, p2;
      if (o2 === 1) f2 = p2 = a2[0];
      else {
        if (t2 < 0) l2 = 0;
        else if (t2 < this._lastFrP) {
          for (l2 = d2(u2 + 1, o2 - 1); l2 >= 0 && !(a2[l2].percent <= t2); l2--) ;
          l2 = d2(l2, o2 - 2);
        } else {
          for (l2 = u2; l2 < o2 && !(a2[l2].percent > t2); l2++) ;
          l2 = d2(l2 - 1, o2 - 2);
        }
        p2 = a2[l2 + 1], f2 = a2[l2];
      }
      if (f2 && p2) {
        this._lastFr = l2, this._lastFrP = t2;
        var m2 = p2.percent - f2.percent, h2 = m2 === 0 ? 1 : d2((t2 - f2.percent) / m2, 1);
        p2.easingFunc && (h2 = p2.easingFunc(h2));
        var g2 = n2 ? this._additiveValue : c2 ? pa : e3[s2];
        if ((fa(i2) || c2) && !g2 && (g2 = this._additiveValue = []), this.discrete) e3[s2] = h2 < 1 ? f2.rawValue : p2.rawValue;
        else if (fa(i2)) i2 === aa ? Yi(g2, f2[r2], p2[r2], h2) : Xi(g2, f2[r2], p2[r2], h2);
        else if (da(i2)) {
          var _2 = f2[r2], v2 = p2[r2], y2 = i2 === ca;
          e3[s2] = { type: y2 ? `linear` : `radial`, x: Ji(_2.x, v2.x, h2), y: Ji(_2.y, v2.y, h2), colorStops: B(_2.colorStops, function(e4, t3) {
            var n3 = v2.colorStops[t3];
            return { offset: Ji(e4.offset, n3.offset, h2), color: na(Yi([], e4.color, n3.color, h2)) };
          }), global: v2.global }, y2 ? (e3[s2].x2 = Ji(_2.x2, v2.x2, h2), e3[s2].y2 = Ji(_2.y2, v2.y2, h2)) : e3[s2].r = Ji(_2.r, v2.r, h2);
        } else if (c2) Yi(g2, f2[r2], p2[r2], h2), n2 || (e3[s2] = na(g2));
        else {
          var b2 = Ji(f2[r2], p2[r2], h2);
          n2 ? this._additiveValue = b2 : e3[s2] = b2;
        }
        n2 && this._addToTarget(e3);
      }
    }
  }, e2.prototype._addToTarget = function(e3) {
    var t2 = this.valType, n2 = this.propName, r2 = this._additiveValue;
    t2 === ia ? e3[n2] = e3[n2] + r2 : t2 === sa ? (ui(e3[n2], pa), Zi(pa, pa, r2, 1), e3[n2] = na(pa)) : t2 === aa ? Zi(e3[n2], e3[n2], r2, 1) : t2 === oa && Qi(e3[n2], e3[n2], r2, 1);
  }, e2;
})(), ha = (function() {
  function e2(e3, t2, n2, r2) {
    if (this._tracks = {}, this._trackKeys = [], this._maxTime = 0, this._started = 0, this._clip = null, this._target = e3, this._loop = t2, t2 && r2) {
      Ie(`Can' use additive animation on looped animation.`);
      return;
    }
    this._additiveAnimators = r2, this._allowDiscrete = n2;
  }
  return e2.prototype.getMaxTime = function() {
    return this._maxTime;
  }, e2.prototype.getDelay = function() {
    return this._delay;
  }, e2.prototype.getLoop = function() {
    return this._loop;
  }, e2.prototype.getTarget = function() {
    return this._target;
  }, e2.prototype.changeTarget = function(e3) {
    this._target = e3;
  }, e2.prototype.when = function(e3, t2, n2) {
    return this.whenWithKeys(e3, t2, V(t2), n2);
  }, e2.prototype.whenWithKeys = function(e3, t2, n2, r2) {
    for (var i2 = this._tracks, a2 = 0; a2 < n2.length; a2++) {
      var o2 = n2[a2], s2 = i2[o2];
      if (!s2) {
        s2 = i2[o2] = new ma(o2);
        var c2 = void 0, l2 = this._getAdditiveTrack(o2);
        if (l2) {
          var u2 = l2.keyframes, d2 = u2[u2.length - 1];
          c2 = d2 && d2.value, l2.valType === sa && c2 && (c2 = na(c2));
        } else c2 = this._target[o2];
        if (c2 == null) continue;
        e3 > 0 && s2.addKeyframe(0, ta(c2), r2), this._trackKeys.push(o2);
      }
      s2.addKeyframe(e3, ta(t2[o2]), r2);
    }
    return this._maxTime = Math.max(this._maxTime, e3), this;
  }, e2.prototype.pause = function() {
    this._clip.pause(), this._paused = true;
  }, e2.prototype.resume = function() {
    this._clip.resume(), this._paused = false;
  }, e2.prototype.isPaused = function() {
    return !!this._paused;
  }, e2.prototype.duration = function(e3) {
    return this._maxTime = e3, this._force = true, this;
  }, e2.prototype._doneCallback = function() {
    this._setTracksFinished(), this._clip = null;
    var e3 = this._doneCbs;
    if (e3) for (var t2 = e3.length, n2 = 0; n2 < t2; n2++) e3[n2].call(this);
  }, e2.prototype._abortedCallback = function() {
    this._setTracksFinished();
    var e3 = this.animation, t2 = this._abortedCbs;
    if (e3 && e3.removeClip(this._clip), this._clip = null, t2) for (var n2 = 0; n2 < t2.length; n2++) t2[n2].call(this);
  }, e2.prototype._setTracksFinished = function() {
    for (var e3 = this._tracks, t2 = this._trackKeys, n2 = 0; n2 < t2.length; n2++) e3[t2[n2]].setFinished();
  }, e2.prototype._getAdditiveTrack = function(e3) {
    var t2, n2 = this._additiveAnimators;
    if (n2) for (var r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2].getTrack(e3);
      i2 && (t2 = i2);
    }
    return t2;
  }, e2.prototype.start = function(e3) {
    if (!(this._started > 0)) {
      this._started = 1;
      for (var t2 = this, n2 = [], r2 = this._maxTime || 0, i2 = 0; i2 < this._trackKeys.length; i2++) {
        var a2 = this._trackKeys[i2], o2 = this._tracks[a2], s2 = this._getAdditiveTrack(a2), c2 = o2.keyframes, l2 = c2.length;
        if (o2.prepare(r2, s2), o2.needsAnimate()) {
          if (!this._allowDiscrete && o2.discrete) {
            var u2 = c2[l2 - 1];
            u2 && (t2._target[o2.propName] = u2.rawValue), o2.setFinished();
          } else n2.push(o2);
        }
      }
      if (n2.length || this._force) {
        var d2 = new Kr({ life: r2, loop: this._loop, delay: this._delay || 0, onframe: function(e4) {
          t2._started = 2;
          var r3 = t2._additiveAnimators;
          if (r3) {
            for (var i3 = false, a3 = 0; a3 < r3.length; a3++) if (r3[a3]._clip) {
              i3 = true;
              break;
            }
            i3 || (t2._additiveAnimators = null);
          }
          for (var a3 = 0; a3 < n2.length; a3++) n2[a3].step(t2._target, e4);
          var o3 = t2._onframeCbs;
          if (o3) for (var a3 = 0; a3 < o3.length; a3++) o3[a3](t2._target, e4);
        }, ondestroy: function() {
          t2._doneCallback();
        } });
        this._clip = d2, this.animation && this.animation.addClip(d2), e3 && d2.setEasing(e3);
      } else this._doneCallback();
      return this;
    }
  }, e2.prototype.stop = function(e3) {
    if (this._clip) {
      var t2 = this._clip;
      e3 && t2.onframe(1), this._abortedCallback();
    }
  }, e2.prototype.delay = function(e3) {
    return this._delay = e3, this;
  }, e2.prototype.during = function(e3) {
    return e3 && (this._onframeCbs || (this._onframeCbs = []), this._onframeCbs.push(e3)), this;
  }, e2.prototype.done = function(e3) {
    return e3 && (this._doneCbs || (this._doneCbs = []), this._doneCbs.push(e3)), this;
  }, e2.prototype.aborted = function(e3) {
    return e3 && (this._abortedCbs || (this._abortedCbs = []), this._abortedCbs.push(e3)), this;
  }, e2.prototype.getClip = function() {
    return this._clip;
  }, e2.prototype.getTrack = function(e3) {
    return this._tracks[e3];
  }, e2.prototype.getTracks = function() {
    var e3 = this;
    return B(this._trackKeys, function(t2) {
      return e3._tracks[t2];
    });
  }, e2.prototype.stopTracks = function(e3, t2) {
    if (!e3.length || !this._clip) return true;
    for (var n2 = this._tracks, r2 = this._trackKeys, i2 = 0; i2 < e3.length; i2++) {
      var a2 = n2[e3[i2]];
      a2 && !a2.isFinished() && (t2 ? a2.step(this._target, 1) : this._started === 1 && a2.step(this._target, 0), a2.setFinished());
    }
    for (var o2 = true, i2 = 0; i2 < r2.length; i2++) if (!n2[r2[i2]].isFinished()) {
      o2 = false;
      break;
    }
    return o2 && this._abortedCallback(), o2;
  }, e2.prototype.saveTo = function(e3, t2, n2) {
    if (e3) {
      t2 || (t2 = this._trackKeys);
      for (var r2 = 0; r2 < t2.length; r2++) {
        var i2 = t2[r2], a2 = this._tracks[i2];
        if (a2 && !a2.isFinished()) {
          var o2 = a2.keyframes, s2 = o2[n2 ? 0 : o2.length - 1];
          s2 && (e3[i2] = ta(s2.rawValue));
        }
      }
    }
  }, e2.prototype.__changeFinalValue = function(e3, t2) {
    t2 || (t2 = V(e3));
    for (var n2 = 0; n2 < t2.length; n2++) {
      var r2 = t2[n2], i2 = this._tracks[r2];
      if (i2) {
        var a2 = i2.keyframes;
        if (a2.length > 1) {
          var o2 = a2.pop();
          i2.addKeyframe(o2.time, e3[r2]), i2.prepare(this._maxTime, i2.getAdditiveTrack());
        }
      }
    }
  }, e2;
})();
M();
function ga() {
  return (/* @__PURE__ */ new Date()).getTime();
}
var _a = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    var n2 = e2.call(this) || this;
    return n2._running = false, n2._time = 0, n2._pausedTime = 0, n2._pauseStart = 0, n2._paused = false, t3 || (t3 = {}), n2.stage = t3.stage || {}, n2;
  }
  return t2.prototype.addClip = function(e3) {
    e3.animation && this.removeClip(e3), this._head ? (this._tail.next = e3, e3.prev = this._tail, e3.next = null, this._tail = e3) : this._head = this._tail = e3, e3.animation = this;
  }, t2.prototype.addAnimator = function(e3) {
    e3.animation = this;
    var t3 = e3.getClip();
    t3 && this.addClip(t3);
  }, t2.prototype.removeClip = function(e3) {
    if (e3.animation) {
      var t3 = e3.prev, n2 = e3.next;
      t3 ? t3.next = n2 : this._head = n2, n2 ? n2.prev = t3 : this._tail = t3, e3.next = e3.prev = e3.animation = null;
    }
  }, t2.prototype.removeAnimator = function(e3) {
    var t3 = e3.getClip();
    t3 && this.removeClip(t3), e3.animation = null;
  }, t2.prototype.update = function(e3) {
    for (var t3 = ga() - this._pausedTime, n2 = t3 - this._time, r2 = this._head; r2; ) {
      var i2 = r2.next;
      r2.step(t3, n2) ? (r2.ondestroy(), this.removeClip(r2), r2 = i2) : r2 = i2;
    }
    this._time = t3, e3 || (this.trigger(`frame`, n2), this.stage.update && this.stage.update());
  }, t2.prototype._startLoop = function() {
    var e3 = this;
    this._running = true;
    function t3() {
      e3._running && (_r(t3), !e3._paused && e3.update());
    }
    _r(t3);
  }, t2.prototype.start = function() {
    this._running || (this._time = ga(), this._pausedTime = 0, this._startLoop());
  }, t2.prototype.stop = function() {
    this._running = false;
  }, t2.prototype.pause = function() {
    this._paused || (this._paused = (this._pauseStart = ga(), true));
  }, t2.prototype.resume = function() {
    this._paused && (this._paused = (this._pausedTime += ga() - this._pauseStart, false));
  }, t2.prototype.clear = function() {
    for (var e3 = this._head; e3; ) {
      var t3 = e3.next;
      e3.prev = e3.next = e3.animation = null, e3 = t3;
    }
    this._head = this._tail = null;
  }, t2.prototype.isFinished = function() {
    return this._head == null;
  }, t2.prototype.animate = function(e3, t3) {
    t3 || (t3 = {}), this.start();
    var n2 = new ha(e3, t3.loop);
    return this.addAnimator(n2), n2;
  }, t2;
})(Qt);
M();
var va = 300, ya = I.domSupported, ba = (function() {
  var e2 = [`click`, `dblclick`, `mousewheel`, `wheel`, `mouseout`, `mouseup`, `mousedown`, `mousemove`, `contextmenu`], t2 = [`touchstart`, `touchend`, `touchmove`], n2 = { pointerdown: 1, pointerup: 1, pointermove: 1, pointerout: 1 };
  return { mouse: e2, touch: t2, pointer: B(e2, function(e3) {
    var t3 = e3.replace(`mouse`, `pointer`);
    return n2.hasOwnProperty(t3) ? t3 : e3;
  }) };
})(), xa = { mouse: [`mousemove`, `mouseup`], pointer: [`pointermove`, `pointerup`] }, Sa = false;
function Ca(e2) {
  var t2 = e2.pointerType;
  return t2 === `pen` || t2 === `touch`;
}
function wa(e2) {
  e2.touching = true, e2.touchTimer != null && (clearTimeout(e2.touchTimer), e2.touchTimer = null), e2.touchTimer = setTimeout(function() {
    e2.touching = false, e2.touchTimer = null;
  }, 700);
}
function Ta(e2) {
  e2 && (e2.zrByTouch = true);
}
function Ea(e2, t2) {
  return yn(e2.dom, new Oa(e2, t2), true);
}
function Da(e2, t2) {
  for (var n2 = t2, r2 = false; n2 && n2.nodeType !== 9 && !(r2 = n2.domBelongToZr || n2 !== t2 && n2 === e2.painterRoot); ) n2 = n2.parentNode;
  return r2;
}
var Oa = /* @__PURE__ */ (function() {
  function e2(e3, t2) {
    this.stopPropagation = St, this.stopImmediatePropagation = St, this.preventDefault = St, this.type = t2.type, this.target = this.currentTarget = e3.dom, this.pointerType = t2.pointerType, this.clientX = t2.clientX, this.clientY = t2.clientY;
  }
  return e2;
})(), ka = { mousedown: function(e2) {
  e2 = yn(this.dom, e2), this.__mayPointerCapture = [e2.zrX, e2.zrY], this.trigger(`mousedown`, e2);
}, mousemove: function(e2) {
  e2 = yn(this.dom, e2);
  var t2 = this.__mayPointerCapture;
  t2 && (e2.zrX !== t2[0] || e2.zrY !== t2[1]) && this.__togglePointerCapture(true), this.trigger(`mousemove`, e2);
}, mouseup: function(e2) {
  e2 = yn(this.dom, e2), this.__togglePointerCapture(false), this.trigger(`mouseup`, e2);
}, mouseout: function(e2) {
  e2 = yn(this.dom, e2);
  var t2 = e2.toElement || e2.relatedTarget;
  Da(this, t2) || (this.__pointerCapturing && (e2.zrEventControl = `no_globalout`), this.trigger(`mouseout`, e2));
}, wheel: function(e2) {
  Sa = true, e2 = yn(this.dom, e2), this.trigger(`mousewheel`, e2);
}, mousewheel: function(e2) {
  Sa || (e2 = yn(this.dom, e2), this.trigger(`mousewheel`, e2));
}, touchstart: function(e2) {
  e2 = yn(this.dom, e2), Ta(e2), this.__lastTouchMoment = /* @__PURE__ */ new Date(), this.handler.processGesture(e2, `start`), ka.mousemove.call(this, e2), ka.mousedown.call(this, e2);
}, touchmove: function(e2) {
  e2 = yn(this.dom, e2), Ta(e2), this.handler.processGesture(e2, `change`), ka.mousemove.call(this, e2);
}, touchend: function(e2) {
  e2 = yn(this.dom, e2), Ta(e2), this.handler.processGesture(e2, `end`), ka.mouseup.call(this, e2), +/* @__PURE__ */ new Date() - this.__lastTouchMoment < va && ka.click.call(this, e2);
}, pointerdown: function(e2) {
  ka.mousedown.call(this, e2);
}, pointermove: function(e2) {
  Ca(e2) || ka.mousemove.call(this, e2);
}, pointerup: function(e2) {
  ka.mouseup.call(this, e2);
}, pointerout: function(e2) {
  Ca(e2) || ka.mouseout.call(this, e2);
} };
z([`click`, `dblclick`, `contextmenu`], function(e2) {
  ka[e2] = function(t2) {
    t2 = yn(this.dom, t2), this.trigger(e2, t2);
  };
});
var Aa = { pointermove: function(e2) {
  Ca(e2) || Aa.mousemove.call(this, e2);
}, pointerup: function(e2) {
  Aa.mouseup.call(this, e2);
}, mousemove: function(e2) {
  this.trigger(`mousemove`, e2);
}, mouseup: function(e2) {
  var t2 = this.__pointerCapturing;
  this.__togglePointerCapture(false), this.trigger(`mouseup`, e2), t2 && (e2.zrEventControl = `only_globalout`, this.trigger(`mouseout`, e2));
} };
function ja(e2, t2) {
  var n2 = t2.domHandlers;
  I.pointerEventsSupported ? z(ba.pointer, function(r2) {
    Na(t2, r2, function(t3) {
      n2[r2].call(e2, t3);
    });
  }) : (I.touchEventsSupported && z(ba.touch, function(r2) {
    Na(t2, r2, function(i2) {
      n2[r2].call(e2, i2), wa(t2);
    });
  }), z(ba.mouse, function(r2) {
    Na(t2, r2, function(i2) {
      i2 = vn(i2), t2.touching || n2[r2].call(e2, i2);
    });
  }));
}
function Ma(e2, t2) {
  I.pointerEventsSupported ? z(xa.pointer, n2) : I.touchEventsSupported || z(xa.mouse, n2);
  function n2(n3) {
    function r2(r3) {
      r3 = vn(r3), Da(e2, r3.target) || (r3 = Ea(e2, r3), t2.domHandlers[n3].call(e2, r3));
    }
    Na(t2, n3, r2, { capture: true });
  }
}
function Na(e2, t2, n2, r2) {
  e2.mounted[t2] = n2, e2.listenerOpts[t2] = r2, xn(e2.domTarget, t2, n2, r2);
}
function Pa(e2) {
  var t2 = e2.mounted;
  for (var n2 in t2) t2.hasOwnProperty(n2) && Sn(e2.domTarget, n2, t2[n2], e2.listenerOpts[n2]);
  e2.mounted = {};
}
var Fa = /* @__PURE__ */ (function() {
  function e2(e3, t2) {
    this.mounted = {}, this.listenerOpts = {}, this.touching = false, this.domTarget = e3, this.domHandlers = t2;
  }
  return e2;
})(), Ia = (function(e2) {
  s(t2, e2);
  function t2(t3, n2) {
    var r2 = e2.call(this) || this;
    return r2.__pointerCapturing = false, r2.dom = t3, r2.painterRoot = n2, r2._localHandlerScope = new Fa(t3, ka), ya && (r2._globalHandlerScope = new Fa(document, Aa)), ja(r2, r2._localHandlerScope), r2;
  }
  return t2.prototype.dispose = function() {
    Pa(this._localHandlerScope), ya && Pa(this._globalHandlerScope);
  }, t2.prototype.setCursor = function(e3) {
    this.dom.style && (this.dom.style.cursor = e3 || `default`);
  }, t2.prototype.__togglePointerCapture = function(e3) {
    if (this.__mayPointerCapture = null, ya && +this.__pointerCapturing ^ e3) {
      this.__pointerCapturing = e3;
      var t3 = this._globalHandlerScope;
      e3 ? Ma(this, t3) : Pa(t3);
    }
  }, t2;
})(Qt), La = 1;
I.hasGlobalWindow && (La = Math.max(window.devicePixelRatio || window.screen && window.screen.deviceXDPI / window.screen.logicalXDPI || 1, 1));
var Ra = La, za = 0.4, Ba = `#333`, Va = `#ccc`, Ha = `#eee`, Ua = An, Wa = 5e-5;
function Ga(e2) {
  return e2 > Wa || e2 < -Wa;
}
var Ka = [], qa = [], Ja = kn(), Ya = Math.abs, Xa = (function() {
  function e2() {
  }
  return e2.prototype.getLocalTransform = function(t2) {
    return e2.getLocalTransform(this, t2);
  }, e2.prototype.setPosition = function(e3) {
    this.x = e3[0], this.y = e3[1];
  }, e2.prototype.setScale = function(e3) {
    this.scaleX = e3[0], this.scaleY = e3[1];
  }, e2.prototype.setSkew = function(e3) {
    this.skewX = e3[0], this.skewY = e3[1];
  }, e2.prototype.setOrigin = function(e3) {
    this.originX = e3[0], this.originY = e3[1];
  }, e2.prototype.needLocalTransform = function() {
    return Ga(this.rotation) || Ga(this.x) || Ga(this.y) || Ga(this.scaleX - 1) || Ga(this.scaleY - 1) || Ga(this.skewX) || Ga(this.skewY);
  }, e2.prototype.updateTransform = function() {
    var e3 = this.parent && this.parent.transform, t2 = this.needLocalTransform(), n2 = this.transform;
    if (!(t2 || e3)) {
      n2 && (Ua(n2), this.invTransform = null);
      return;
    }
    n2 || (n2 = kn()), t2 ? this.getLocalTransform(n2) : Ua(n2), e3 && (t2 ? Mn(n2, e3, n2) : jn(n2, e3)), this.transform = n2, this._resolveGlobalScaleRatio(n2);
  }, e2.prototype._resolveGlobalScaleRatio = function(e3) {
    var t2 = this.globalScaleRatio;
    if (t2 != null && t2 !== 1) {
      this.getGlobalScale(Ka);
      var n2 = Ka[0] < 0 ? -1 : 1, r2 = Ka[1] < 0 ? -1 : 1, i2 = ((Ka[0] - n2) * t2 + n2) / Ka[0] || 0, a2 = ((Ka[1] - r2) * t2 + r2) / Ka[1] || 0;
      e3[0] *= i2, e3[1] *= i2, e3[2] *= a2, e3[3] *= a2;
    }
    this.invTransform = this.invTransform || kn(), In(this.invTransform, e3);
  }, e2.prototype.getComputedTransform = function() {
    for (var e3 = this, t2 = []; e3; ) t2.push(e3), e3 = e3.parent;
    for (; e3 = t2.pop(); ) e3.updateTransform();
    return this.transform;
  }, e2.prototype.setLocalTransform = function(e3) {
    if (e3) {
      var t2 = e3[0] * e3[0] + e3[1] * e3[1], n2 = e3[2] * e3[2] + e3[3] * e3[3], r2 = Math.atan2(e3[1], e3[0]), i2 = Math.PI / 2 + r2 - Math.atan2(e3[3], e3[2]);
      n2 = Math.sqrt(n2) * Math.cos(i2), t2 = Math.sqrt(t2), this.skewX = i2, this.skewY = 0, this.rotation = -r2, this.x = +e3[4], this.y = +e3[5], this.scaleX = t2, this.scaleY = n2, this.originX = 0, this.originY = 0;
    }
  }, e2.prototype.decomposeTransform = function() {
    if (this.transform) {
      var e3 = this.parent, t2 = this.transform;
      e3 && e3.transform && (e3.invTransform = e3.invTransform || kn(), Mn(qa, e3.invTransform, t2), t2 = qa);
      var n2 = this.originX, r2 = this.originY;
      (n2 || r2) && (Ja[4] = n2, Ja[5] = r2, Mn(qa, t2, Ja), qa[4] -= n2, qa[5] -= r2, t2 = qa), this.setLocalTransform(t2);
    }
  }, e2.prototype.getGlobalScale = function(e3) {
    var t2 = this.transform;
    return e3 || (e3 = []), t2 ? (e3[0] = Math.sqrt(t2[0] * t2[0] + t2[1] * t2[1]), e3[1] = Math.sqrt(t2[2] * t2[2] + t2[3] * t2[3]), t2[0] < 0 && (e3[0] = -e3[0]), t2[3] < 0 && (e3[1] = -e3[1]), e3) : (e3[0] = 1, e3[1] = 1, e3);
  }, e2.prototype.transformCoordToLocal = function(e3, t2) {
    var n2 = [e3, t2], r2 = this.invTransform;
    return r2 && qt(n2, n2, r2), n2;
  }, e2.prototype.transformCoordToGlobal = function(e3, t2) {
    var n2 = [e3, t2], r2 = this.transform;
    return r2 && qt(n2, n2, r2), n2;
  }, e2.prototype.getLineScale = function() {
    var e3 = this.transform;
    return e3 && Ya(e3[0] - 1) > 1e-10 && Ya(e3[3] - 1) > 1e-10 ? Math.sqrt(Ya(e3[0] * e3[3] - e3[2] * e3[1])) : 1;
  }, e2.prototype.copyTransform = function(e3) {
    Qa(this, e3);
  }, e2.getLocalTransform = function(e3, t2) {
    t2 || (t2 = []);
    var n2 = e3.originX || 0, r2 = e3.originY || 0, i2 = e3.scaleX, a2 = e3.scaleY, o2 = e3.anchorX, s2 = e3.anchorY, c2 = e3.rotation || 0, l2 = e3.x, u2 = e3.y, d2 = e3.skewX ? Math.tan(e3.skewX) : 0, f2 = e3.skewY ? Math.tan(-e3.skewY) : 0;
    if (n2 || r2 || o2 || s2) {
      var p2 = n2 + o2, m2 = r2 + s2;
      t2[4] = -p2 * i2 - d2 * m2 * a2, t2[5] = -m2 * a2 - f2 * p2 * i2;
    } else t2[4] = t2[5] = 0;
    return t2[0] = i2, t2[3] = a2, t2[1] = f2 * i2, t2[2] = d2 * a2, c2 && Pn(t2, t2, c2), t2[4] += n2 + l2, t2[5] += r2 + u2, t2;
  }, e2.initDefaultProps = (function() {
    var t2 = e2.prototype;
    t2.scaleX = t2.scaleY = t2.globalScaleRatio = 1, t2.x = t2.y = t2.originX = t2.originY = t2.skewX = t2.skewY = t2.rotation = t2.anchorX = t2.anchorY = 0;
  })(), e2;
})(), Za = [`x`, `y`, `originX`, `originY`, `anchorX`, `anchorY`, `rotation`, `scaleX`, `scaleY`, `skewX`, `skewY`];
function Qa(e2, t2) {
  for (var n2 = 0; n2 < Za.length; n2++) {
    var r2 = Za[n2];
    e2[r2] = t2[r2];
  }
}
var $a = {};
function eo(e2, t2) {
  t2 || (t2 = `12px sans-serif`);
  var n2 = $a[t2];
  n2 || (n2 = $a[t2] = new Yr(500));
  var r2 = n2.get(e2);
  return r2 ?? (r2 = be.measureText(e2, t2).width, n2.put(e2, r2)), r2;
}
function to(e2, t2, n2, r2) {
  var i2 = eo(e2, t2), a2 = ao(t2);
  return new X(ro(0, i2, n2), io(0, a2, r2), i2, a2);
}
function no(e2, t2, n2, r2) {
  var i2 = ((e2 || ``) + ``).split(`
`);
  if (i2.length === 1) return to(i2[0], t2, n2, r2);
  for (var a2 = new X(0, 0, 0, 0), o2 = 0; o2 < i2.length; o2++) {
    var s2 = to(i2[o2], t2, n2, r2);
    o2 === 0 ? a2.copy(s2) : a2.union(s2);
  }
  return a2;
}
function ro(e2, t2, n2) {
  return n2 === `right` ? e2 -= t2 : n2 === `center` && (e2 -= t2 / 2), e2;
}
function io(e2, t2, n2) {
  return n2 === `middle` ? e2 -= t2 / 2 : n2 === `bottom` && (e2 -= t2), e2;
}
function ao(e2) {
  return eo(`\u56FD`, e2);
}
function oo(e2, t2) {
  return typeof e2 == `string` ? e2.lastIndexOf(`%`) >= 0 ? parseFloat(e2) / 100 * t2 : parseFloat(e2) : e2;
}
function so(e2, t2, n2) {
  var r2 = t2.position || `inside`, i2 = t2.distance == null ? 5 : t2.distance, a2 = n2.height, o2 = n2.width, s2 = a2 / 2, c2 = n2.x, l2 = n2.y, u2 = `left`, d2 = `top`;
  if (r2 instanceof Array) c2 += oo(r2[0], n2.width), l2 += oo(r2[1], n2.height), u2 = null, d2 = null;
  else switch (r2) {
    case `left`:
      c2 -= i2, l2 += s2, u2 = `right`, d2 = `middle`;
      break;
    case `right`:
      c2 += i2 + o2, l2 += s2, d2 = `middle`;
      break;
    case `top`:
      c2 += o2 / 2, l2 -= i2, u2 = `center`, d2 = `bottom`;
      break;
    case `bottom`:
      c2 += o2 / 2, l2 += a2 + i2, u2 = `center`;
      break;
    case `inside`:
      c2 += o2 / 2, l2 += s2, u2 = `center`, d2 = `middle`;
      break;
    case `insideLeft`:
      c2 += i2, l2 += s2, d2 = `middle`;
      break;
    case `insideRight`:
      c2 += o2 - i2, l2 += s2, u2 = `right`, d2 = `middle`;
      break;
    case `insideTop`:
      c2 += o2 / 2, l2 += i2, u2 = `center`;
      break;
    case `insideBottom`:
      c2 += o2 / 2, l2 += a2 - i2, u2 = `center`, d2 = `bottom`;
      break;
    case `insideTopLeft`:
      c2 += i2, l2 += i2;
      break;
    case `insideTopRight`:
      c2 += o2 - i2, l2 += i2, u2 = `right`;
      break;
    case `insideBottomLeft`:
      c2 += i2, l2 += a2 - i2, d2 = `bottom`;
      break;
    case `insideBottomRight`:
      c2 += o2 - i2, l2 += a2 - i2, u2 = `right`, d2 = `bottom`;
  }
  return e2 || (e2 = {}), e2.x = c2, e2.y = l2, e2.align = u2, e2.verticalAlign = d2, e2;
}
var co = `__zr_normal__`, lo = Za.concat([`ignore`]), uo = Ge(Za, function(e2, t2) {
  return e2[t2] = true, e2;
}, { ignore: false }), fo = {}, po = new X(0, 0, 0, 0), mo = (function() {
  function e2(e3) {
    this.id = Fe(), this.animators = [], this.currentStates = [], this.states = {}, this._init(e3);
  }
  return e2.prototype._init = function(e3) {
    this.attr(e3);
  }, e2.prototype.drift = function(e3, t2, n2) {
    switch (this.draggable) {
      case `horizontal`:
        t2 = 0;
        break;
      case `vertical`:
        e3 = 0;
    }
    var r2 = this.transform;
    r2 || (r2 = this.transform = [1, 0, 0, 1, 0, 0]), r2[4] += e3, r2[5] += t2, this.decomposeTransform(), this.markRedraw();
  }, e2.prototype.beforeUpdate = function() {
  }, e2.prototype.afterUpdate = function() {
  }, e2.prototype.update = function() {
    this.updateTransform(), this.__dirty && this.updateInnerText();
  }, e2.prototype.updateInnerText = function(e3) {
    var t2 = this._textContent;
    if (t2 && (!t2.ignore || e3)) {
      this.textConfig || (this.textConfig = {});
      var n2 = this.textConfig, r2 = n2.local, i2 = t2.innerTransformable, a2 = void 0, o2 = void 0, s2 = false;
      i2.parent = r2 ? this : null;
      var c2 = false;
      if (i2.copyTransform(t2), n2.position != null) {
        var l2 = po;
        n2.layoutRect ? l2.copy(n2.layoutRect) : l2.copy(this.getBoundingRect()), r2 || l2.applyTransform(this.transform), this.calculateTextPosition ? this.calculateTextPosition(fo, n2, l2) : so(fo, n2, l2), i2.x = fo.x, i2.y = fo.y, a2 = fo.align, o2 = fo.verticalAlign;
        var u2 = n2.origin;
        if (u2 && n2.rotation != null) {
          var d2 = void 0, f2 = void 0;
          u2 === `center` ? (d2 = l2.width * 0.5, f2 = l2.height * 0.5) : (d2 = oo(u2[0], l2.width), f2 = oo(u2[1], l2.height)), c2 = true, i2.originX = -i2.x + d2 + (r2 ? 0 : l2.x), i2.originY = -i2.y + f2 + (r2 ? 0 : l2.y);
        }
      }
      n2.rotation != null && (i2.rotation = n2.rotation);
      var p2 = n2.offset;
      p2 && (i2.x += p2[0], i2.y += p2[1], c2 || (i2.originX = -p2[0], i2.originY = -p2[1]));
      var m2 = n2.inside == null ? typeof n2.position == `string` && n2.position.indexOf(`inside`) >= 0 : n2.inside, h2 = this._innerTextDefaultStyle || (this._innerTextDefaultStyle = {}), g2 = void 0, _2 = void 0, v2 = void 0;
      m2 && this.canBeInsideText() ? (g2 = n2.insideFill, _2 = n2.insideStroke, (g2 == null || g2 === `auto`) && (g2 = this.getInsideTextFill()), (_2 == null || _2 === `auto`) && (_2 = this.getInsideTextStroke(g2), v2 = true)) : (g2 = n2.outsideFill, _2 = n2.outsideStroke, (g2 == null || g2 === `auto`) && (g2 = this.getOutsideFill()), (_2 == null || _2 === `auto`) && (_2 = this.getOutsideStroke(g2), v2 = true)), g2 || (g2 = `#000`), (g2 !== h2.fill || _2 !== h2.stroke || v2 !== h2.autoStroke || a2 !== h2.align || o2 !== h2.verticalAlign) && (s2 = true, h2.fill = g2, h2.stroke = _2, h2.autoStroke = v2, h2.align = a2, h2.verticalAlign = o2, t2.setDefaultTextStyle(h2)), t2.__dirty |= 1, s2 && t2.dirtyStyle(true);
    }
  }, e2.prototype.canBeInsideText = function() {
    return true;
  }, e2.prototype.getInsideTextFill = function() {
    return `#fff`;
  }, e2.prototype.getInsideTextStroke = function(e3) {
    return `#000`;
  }, e2.prototype.getOutsideFill = function() {
    return this.__zr && this.__zr.isDarkMode() ? Va : Ba;
  }, e2.prototype.getOutsideStroke = function(e3) {
    var t2 = this.__zr && this.__zr.getBackgroundColor(), n2 = typeof t2 == `string` && ui(t2);
    n2 || (n2 = [255, 255, 255, 1]);
    for (var r2 = n2[3], i2 = this.__zr.isDarkMode(), a2 = 0; a2 < 3; a2++) n2[a2] = n2[a2] * r2 + (i2 ? 0 : 255) * (1 - r2);
    return n2[3] = 1, xi(n2, `rgba`);
  }, e2.prototype.traverse = function(e3, t2) {
  }, e2.prototype.attrKV = function(e3, t2) {
    e3 === `textConfig` ? this.setTextConfig(t2) : e3 === `textContent` ? this.setTextContent(t2) : e3 === `clipPath` ? this.setClipPath(t2) : e3 === `extra` ? (this.extra = this.extra || {}, R(this.extra, t2)) : this[e3] = t2;
  }, e2.prototype.hide = function() {
    this.ignore = true, this.markRedraw();
  }, e2.prototype.show = function() {
    this.ignore = false, this.markRedraw();
  }, e2.prototype.attr = function(e3, t2) {
    if (typeof e3 == `string`) this.attrKV(e3, t2);
    else if (K(e3)) for (var n2 = V(e3), r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2];
      this.attrKV(i2, e3[i2]);
    }
    return this.markRedraw(), this;
  }, e2.prototype.saveCurrentToNormalState = function(e3) {
    this._innerSaveToNormal(e3);
    for (var t2 = this._normalState, n2 = 0; n2 < this.animators.length; n2++) {
      var r2 = this.animators[n2], i2 = r2.__fromStateTransition;
      if (!(r2.getLoop() || i2 && i2 !== `__zr_normal__`)) {
        var a2 = r2.targetName, o2 = a2 ? t2[a2] : t2;
        r2.saveTo(o2);
      }
    }
  }, e2.prototype._innerSaveToNormal = function(e3) {
    var t2 = this._normalState;
    t2 || (t2 = this._normalState = {}), e3.textConfig && !t2.textConfig && (t2.textConfig = this.textConfig), this._savePrimaryToNormal(e3, t2, lo);
  }, e2.prototype._savePrimaryToNormal = function(e3, t2, n2) {
    for (var r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2];
      e3[i2] != null && !(i2 in t2) && (t2[i2] = this[i2]);
    }
  }, e2.prototype.hasState = function() {
    return this.currentStates.length > 0;
  }, e2.prototype.getState = function(e3) {
    return this.states[e3];
  }, e2.prototype.ensureState = function(e3) {
    var t2 = this.states;
    return t2[e3] || (t2[e3] = {}), t2[e3];
  }, e2.prototype.clearStates = function(e3) {
    this.useState(co, false, e3);
  }, e2.prototype.useState = function(e3, t2, n2, r2) {
    var i2 = e3 === co;
    if (this.hasState() || !i2) {
      var a2 = this.currentStates, o2 = this.stateTransition;
      if (!(Ve(a2, e3) >= 0 && (t2 || a2.length === 1))) {
        var s2;
        if (this.stateProxy && !i2 && (s2 = this.stateProxy(e3)), s2 || (s2 = this.states && this.states[e3]), !s2 && !i2) {
          Ie(`State ` + e3 + ` not exists.`);
          return;
        }
        i2 || this.saveCurrentToNormalState(s2);
        var c2 = !!(s2 && s2.hoverLayer || r2);
        c2 && this._toggleHoverLayerFlag(true), this._applyStateObj(e3, s2, this._normalState, t2, !n2 && !this.__inHover && o2 && o2.duration > 0, o2);
        var l2 = this._textContent, u2 = this._textGuide;
        return l2 && l2.useState(e3, t2, n2, c2), u2 && u2.useState(e3, t2, n2, c2), i2 ? (this.currentStates = [], this._normalState = {}) : t2 ? this.currentStates.push(e3) : this.currentStates = [e3], this._updateAnimationTargets(), this.markRedraw(), !c2 && this.__inHover && (this._toggleHoverLayerFlag(false), this.__dirty &= -2), s2;
      }
    }
  }, e2.prototype.useStates = function(e3, t2, n2) {
    if (!e3.length) this.clearStates();
    else {
      var r2 = [], i2 = this.currentStates, a2 = e3.length, o2 = a2 === i2.length;
      if (o2) {
        for (var s2 = 0; s2 < a2; s2++) if (e3[s2] !== i2[s2]) {
          o2 = false;
          break;
        }
      }
      if (o2) return;
      for (var s2 = 0; s2 < a2; s2++) {
        var c2 = e3[s2], l2 = void 0;
        this.stateProxy && (l2 = this.stateProxy(c2, e3)), l2 || (l2 = this.states[c2]), l2 && r2.push(l2);
      }
      var u2 = r2[a2 - 1], d2 = !!(u2 && u2.hoverLayer || n2);
      d2 && this._toggleHoverLayerFlag(true);
      var f2 = this._mergeStates(r2), p2 = this.stateTransition;
      this.saveCurrentToNormalState(f2), this._applyStateObj(e3.join(`,`), f2, this._normalState, false, !t2 && !this.__inHover && p2 && p2.duration > 0, p2);
      var m2 = this._textContent, h2 = this._textGuide;
      m2 && m2.useStates(e3, t2, d2), h2 && h2.useStates(e3, t2, d2), this._updateAnimationTargets(), this.currentStates = e3.slice(), this.markRedraw(), !d2 && this.__inHover && (this._toggleHoverLayerFlag(false), this.__dirty &= -2);
    }
  }, e2.prototype.isSilent = function() {
    for (var e3 = this.silent, t2 = this.parent; !e3 && t2; ) {
      if (t2.silent) {
        e3 = true;
        break;
      }
      t2 = t2.parent;
    }
    return e3;
  }, e2.prototype._updateAnimationTargets = function() {
    for (var e3 = 0; e3 < this.animators.length; e3++) {
      var t2 = this.animators[e3];
      t2.targetName && t2.changeTarget(this[t2.targetName]);
    }
  }, e2.prototype.removeState = function(e3) {
    var t2 = Ve(this.currentStates, e3);
    if (t2 >= 0) {
      var n2 = this.currentStates.slice();
      n2.splice(t2, 1), this.useStates(n2);
    }
  }, e2.prototype.replaceState = function(e3, t2, n2) {
    var r2 = this.currentStates.slice(), i2 = Ve(r2, e3), a2 = Ve(r2, t2) >= 0;
    i2 >= 0 ? a2 ? r2.splice(i2, 1) : r2[i2] = t2 : n2 && !a2 && r2.push(t2), this.useStates(r2);
  }, e2.prototype.toggleState = function(e3, t2) {
    t2 ? this.useState(e3, true) : this.removeState(e3);
  }, e2.prototype._mergeStates = function(e3) {
    for (var t2 = {}, n2, r2 = 0; r2 < e3.length; r2++) {
      var i2 = e3[r2];
      R(t2, i2), i2.textConfig && (n2 || (n2 = {}), R(n2, i2.textConfig));
    }
    return n2 && (t2.textConfig = n2), t2;
  }, e2.prototype._applyStateObj = function(e3, t2, n2, r2, i2, a2) {
    var o2 = !(t2 && r2);
    t2 && t2.textConfig ? (this.textConfig = R({}, r2 ? this.textConfig : n2.textConfig), R(this.textConfig, t2.textConfig)) : o2 && n2.textConfig && (this.textConfig = n2.textConfig);
    for (var s2 = {}, c2 = false, l2 = 0; l2 < lo.length; l2++) {
      var u2 = lo[l2], d2 = i2 && uo[u2];
      t2 && t2[u2] != null ? d2 ? (c2 = true, s2[u2] = t2[u2]) : this[u2] = t2[u2] : o2 && n2[u2] != null && (d2 ? (c2 = true, s2[u2] = n2[u2]) : this[u2] = n2[u2]);
    }
    if (!i2) for (var l2 = 0; l2 < this.animators.length; l2++) {
      var f2 = this.animators[l2], p2 = f2.targetName;
      f2.getLoop() || f2.__changeFinalValue(p2 ? (t2 || n2)[p2] : t2 || n2);
    }
    c2 && this._transitionState(e3, s2, a2);
  }, e2.prototype._attachComponent = function(e3) {
    if ((!e3.__zr || e3.__hostTarget) && e3 !== this) {
      var t2 = this.__zr;
      t2 && e3.addSelfToZr(t2), e3.__zr = t2, e3.__hostTarget = this;
    }
  }, e2.prototype._detachComponent = function(e3) {
    e3.__zr && e3.removeSelfFromZr(e3.__zr), e3.__zr = null, e3.__hostTarget = null;
  }, e2.prototype.getClipPath = function() {
    return this._clipPath;
  }, e2.prototype.setClipPath = function(e3) {
    this._clipPath && this._clipPath !== e3 && this.removeClipPath(), this._attachComponent(e3), this._clipPath = e3, this.markRedraw();
  }, e2.prototype.removeClipPath = function() {
    var e3 = this._clipPath;
    e3 && (this._detachComponent(e3), this._clipPath = null, this.markRedraw());
  }, e2.prototype.getTextContent = function() {
    return this._textContent;
  }, e2.prototype.setTextContent = function(e3) {
    var t2 = this._textContent;
    t2 !== e3 && (t2 && t2 !== e3 && this.removeTextContent(), e3.innerTransformable = new Xa(), this._attachComponent(e3), this._textContent = e3, this.markRedraw());
  }, e2.prototype.setTextConfig = function(e3) {
    this.textConfig || (this.textConfig = {}), R(this.textConfig, e3), this.markRedraw();
  }, e2.prototype.removeTextConfig = function() {
    this.textConfig = null, this.markRedraw();
  }, e2.prototype.removeTextContent = function() {
    var e3 = this._textContent;
    e3 && (e3.innerTransformable = null, this._detachComponent(e3), this._textContent = null, this._innerTextDefaultStyle = null, this.markRedraw());
  }, e2.prototype.getTextGuideLine = function() {
    return this._textGuide;
  }, e2.prototype.setTextGuideLine = function(e3) {
    this._textGuide && this._textGuide !== e3 && this.removeTextGuideLine(), this._attachComponent(e3), this._textGuide = e3, this.markRedraw();
  }, e2.prototype.removeTextGuideLine = function() {
    var e3 = this._textGuide;
    e3 && (this._detachComponent(e3), this._textGuide = null, this.markRedraw());
  }, e2.prototype.markRedraw = function() {
    this.__dirty |= 1;
    var e3 = this.__zr;
    e3 && (this.__inHover ? e3.refreshHover() : e3.refresh()), this.__hostTarget && this.__hostTarget.markRedraw();
  }, e2.prototype.dirty = function() {
    this.markRedraw();
  }, e2.prototype._toggleHoverLayerFlag = function(e3) {
    this.__inHover = e3;
    var t2 = this._textContent, n2 = this._textGuide;
    t2 && (t2.__inHover = e3), n2 && (n2.__inHover = e3);
  }, e2.prototype.addSelfToZr = function(e3) {
    if (this.__zr !== e3) {
      this.__zr = e3;
      var t2 = this.animators;
      if (t2) for (var n2 = 0; n2 < t2.length; n2++) e3.animation.addAnimator(t2[n2]);
      this._clipPath && this._clipPath.addSelfToZr(e3), this._textContent && this._textContent.addSelfToZr(e3), this._textGuide && this._textGuide.addSelfToZr(e3);
    }
  }, e2.prototype.removeSelfFromZr = function(e3) {
    if (this.__zr) {
      this.__zr = null;
      var t2 = this.animators;
      if (t2) for (var n2 = 0; n2 < t2.length; n2++) e3.animation.removeAnimator(t2[n2]);
      this._clipPath && this._clipPath.removeSelfFromZr(e3), this._textContent && this._textContent.removeSelfFromZr(e3), this._textGuide && this._textGuide.removeSelfFromZr(e3);
    }
  }, e2.prototype.animate = function(e3, t2, n2) {
    var r2 = new ha(e3 ? this[e3] : this, t2, n2);
    return e3 && (r2.targetName = e3), this.addAnimator(r2, e3), r2;
  }, e2.prototype.addAnimator = function(e3, t2) {
    var n2 = this.__zr, r2 = this;
    e3.during(function() {
      r2.updateDuringAnimation(t2);
    }).done(function() {
      var t3 = r2.animators, n3 = Ve(t3, e3);
      n3 >= 0 && t3.splice(n3, 1);
    }), this.animators.push(e3), n2 && n2.animation.addAnimator(e3), n2 && n2.wakeUp();
  }, e2.prototype.updateDuringAnimation = function(e3) {
    this.markRedraw();
  }, e2.prototype.stopAnimation = function(e3, t2) {
    for (var n2 = this.animators, r2 = n2.length, i2 = [], a2 = 0; a2 < r2; a2++) {
      var o2 = n2[a2];
      !e3 || e3 === o2.scope ? o2.stop(t2) : i2.push(o2);
    }
    return this.animators = i2, this;
  }, e2.prototype.animateTo = function(e3, t2, n2) {
    ho(this, e3, t2, n2);
  }, e2.prototype.animateFrom = function(e3, t2, n2) {
    ho(this, e3, t2, n2, true);
  }, e2.prototype._transitionState = function(e3, t2, n2, r2) {
    for (var i2 = ho(this, t2, n2, r2), a2 = 0; a2 < i2.length; a2++) i2[a2].__fromStateTransition = e3;
  }, e2.prototype.getBoundingRect = function() {
    return null;
  }, e2.prototype.getPaintRect = function() {
    return null;
  }, e2.initDefaultProps = (function() {
    var t2 = e2.prototype;
    t2.type = `element`, t2.name = ``, t2.ignore = t2.silent = t2.isGroup = t2.draggable = t2.dragging = t2.ignoreClip = t2.__inHover = false, t2.__dirty = 1;
    function n2(e3, n3, r2, i2) {
      Object.defineProperty(t2, e3, { get: function() {
        if (!this[n3]) {
          var e4 = this[n3] = [];
          a2(this, e4);
        }
        return this[n3];
      }, set: function(e4) {
        this[r2] = e4[0], this[i2] = e4[1], this[n3] = e4, a2(this, e4);
      } });
      function a2(e4, t3) {
        Object.defineProperty(t3, 0, { get: function() {
          return e4[r2];
        }, set: function(t4) {
          e4[r2] = t4;
        } }), Object.defineProperty(t3, 1, { get: function() {
          return e4[i2];
        }, set: function(t4) {
          e4[i2] = t4;
        } });
      }
    }
    Object.defineProperty && (n2(`position`, `_legacyPos`, `x`, `y`), n2(`scale`, `_legacyScale`, `scaleX`, `scaleY`), n2(`origin`, `_legacyOrigin`, `originX`, `originY`));
  })(), e2;
})();
Ue(mo, Qt), Ue(mo, Xa);
function ho(e2, t2, n2, r2, i2) {
  n2 || (n2 = {});
  var a2 = [];
  xo(e2, ``, e2, t2, n2, r2, a2, i2);
  var o2 = a2.length, s2 = false, c2 = n2.done, l2 = n2.aborted, u2 = function() {
    s2 = true, o2--, o2 <= 0 && (s2 ? c2 && c2() : l2 && l2());
  }, d2 = function() {
    o2--, o2 <= 0 && (s2 ? c2 && c2() : l2 && l2());
  };
  o2 || c2 && c2(), a2.length > 0 && n2.during && a2[0].during(function(e3, t3) {
    n2.during(t3);
  });
  for (var f2 = 0; f2 < a2.length; f2++) {
    var p2 = a2[f2];
    u2 && p2.done(u2), d2 && p2.aborted(d2), n2.force && p2.duration(n2.duration), p2.start(n2.easing);
  }
  return a2;
}
function go(e2, t2, n2) {
  for (var r2 = 0; r2 < n2; r2++) e2[r2] = t2[r2];
}
function _o(e2) {
  return We(e2[0]);
}
function vo(e2, t2, n2) {
  if (We(t2[n2])) {
    if (We(e2[n2]) || (e2[n2] = []), $e(t2[n2])) {
      var r2 = t2[n2].length;
      e2[n2].length !== r2 && (e2[n2] = new t2[n2].constructor(r2), go(e2[n2], t2[n2], r2));
    } else {
      var i2 = t2[n2], a2 = e2[n2], o2 = i2.length;
      if (_o(i2)) for (var s2 = i2[0].length, c2 = 0; c2 < o2; c2++) a2[c2] ? go(a2[c2], i2[c2], s2) : a2[c2] = Array.prototype.slice.call(i2[c2]);
      else go(a2, i2, o2);
      a2.length = i2.length;
    }
  } else e2[n2] = t2[n2];
}
function yo(e2, t2) {
  return e2 === t2 || We(e2) && We(t2) && bo(e2, t2);
}
function bo(e2, t2) {
  var n2 = e2.length;
  if (n2 !== t2.length) return false;
  for (var r2 = 0; r2 < n2; r2++) if (e2[r2] !== t2[r2]) return false;
  return true;
}
function xo(e2, t2, n2, r2, i2, a2, o2, s2) {
  for (var c2 = V(r2), l2 = i2.duration, u2 = i2.delay, d2 = i2.additive, f2 = i2.setToFinal, p2 = !K(a2), m2 = e2.animators, h2 = [], g2 = 0; g2 < c2.length; g2++) {
    var _2 = c2[g2], v2 = r2[_2];
    if (v2 != null && n2[_2] != null && (p2 || a2[_2])) {
      if (K(v2) && !We(v2) && !tt(v2)) {
        if (t2) {
          s2 || (n2[_2] = v2, e2.updateDuringAnimation(t2));
          continue;
        }
        xo(e2, _2, n2[_2], v2, i2, a2 && a2[_2], o2, s2);
      } else h2.push(_2);
    } else s2 || (n2[_2] = v2, e2.updateDuringAnimation(t2), h2.push(_2));
  }
  var y2 = h2.length;
  if (!d2 && y2) for (var b2 = 0; b2 < m2.length; b2++) {
    var x2 = m2[b2];
    if (x2.targetName === t2 && x2.stopTracks(h2)) {
      var S2 = Ve(m2, x2);
      m2.splice(S2, 1);
    }
  }
  if (i2.force || (h2 = Ke(h2, function(e3) {
    return !yo(r2[e3], n2[e3]);
  }), y2 = h2.length), y2 > 0 || i2.force && !o2.length) {
    var C2 = void 0, w2 = void 0, T2 = void 0;
    if (s2) {
      w2 = {}, f2 && (C2 = {});
      for (var b2 = 0; b2 < y2; b2++) {
        var _2 = h2[b2];
        w2[_2] = n2[_2], f2 ? C2[_2] = r2[_2] : n2[_2] = r2[_2];
      }
    } else if (f2) {
      T2 = {};
      for (var b2 = 0; b2 < y2; b2++) {
        var _2 = h2[b2];
        T2[_2] = ta(n2[_2]), vo(n2, r2, _2);
      }
    }
    var x2 = new ha(n2, false, false, d2 ? Ke(m2, function(e3) {
      return e3.targetName === t2;
    }) : null);
    x2.targetName = t2, i2.scope && (x2.scope = i2.scope), f2 && C2 && x2.whenWithKeys(0, C2, h2), T2 && x2.whenWithKeys(0, T2, h2), x2.whenWithKeys(l2 ?? 500, s2 ? w2 : r2, h2).delay(u2 || 0), e2.addAnimator(x2, t2), o2.push(x2);
  }
}
M();
var So = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    var n2 = e2.call(this) || this;
    return n2.isGroup = true, n2._children = [], n2.attr(t3), n2;
  }
  return t2.prototype.childrenRef = function() {
    return this._children;
  }, t2.prototype.children = function() {
    return this._children.slice();
  }, t2.prototype.childAt = function(e3) {
    return this._children[e3];
  }, t2.prototype.childOfName = function(e3) {
    for (var t3 = this._children, n2 = 0; n2 < t3.length; n2++) if (t3[n2].name === e3) return t3[n2];
  }, t2.prototype.childCount = function() {
    return this._children.length;
  }, t2.prototype.add = function(e3) {
    return e3 && e3 !== this && e3.parent !== this && (this._children.push(e3), this._doAdd(e3)), this;
  }, t2.prototype.addBefore = function(e3, t3) {
    if (e3 && e3 !== this && e3.parent !== this && t3 && t3.parent === this) {
      var n2 = this._children, r2 = n2.indexOf(t3);
      r2 >= 0 && (n2.splice(r2, 0, e3), this._doAdd(e3));
    }
    return this;
  }, t2.prototype.replace = function(e3, t3) {
    var n2 = Ve(this._children, e3);
    return n2 >= 0 && this.replaceAt(t3, n2), this;
  }, t2.prototype.replaceAt = function(e3, t3) {
    var n2 = this._children, r2 = n2[t3];
    if (e3 && e3 !== this && e3.parent !== this && e3 !== r2) {
      n2[t3] = e3, r2.parent = null;
      var i2 = this.__zr;
      i2 && r2.removeSelfFromZr(i2), this._doAdd(e3);
    }
    return this;
  }, t2.prototype._doAdd = function(e3) {
    e3.parent && e3.parent.remove(e3), e3.parent = this;
    var t3 = this.__zr;
    t3 && t3 !== e3.__zr && e3.addSelfToZr(t3), t3 && t3.refresh();
  }, t2.prototype.remove = function(e3) {
    var t3 = this.__zr, n2 = this._children, r2 = Ve(n2, e3);
    return r2 < 0 ? this : (n2.splice(r2, 1), e3.parent = null, t3 && e3.removeSelfFromZr(t3), t3 && t3.refresh(), this);
  }, t2.prototype.removeAll = function() {
    for (var e3 = this._children, t3 = this.__zr, n2 = 0; n2 < e3.length; n2++) {
      var r2 = e3[n2];
      t3 && r2.removeSelfFromZr(t3), r2.parent = null;
    }
    return e3.length = 0, this;
  }, t2.prototype.eachChild = function(e3, t3) {
    for (var n2 = this._children, r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2];
      e3.call(t3, i2, r2);
    }
    return this;
  }, t2.prototype.traverse = function(e3, t3) {
    for (var n2 = 0; n2 < this._children.length; n2++) {
      var r2 = this._children[n2], i2 = e3.call(t3, r2);
      r2.isGroup && !i2 && r2.traverse(e3, t3);
    }
    return this;
  }, t2.prototype.addSelfToZr = function(t3) {
    e2.prototype.addSelfToZr.call(this, t3);
    for (var n2 = 0; n2 < this._children.length; n2++) this._children[n2].addSelfToZr(t3);
  }, t2.prototype.removeSelfFromZr = function(t3) {
    e2.prototype.removeSelfFromZr.call(this, t3);
    for (var n2 = 0; n2 < this._children.length; n2++) this._children[n2].removeSelfFromZr(t3);
  }, t2.prototype.getBoundingRect = function(e3) {
    for (var t3 = new X(0, 0, 0, 0), n2 = e3 || this._children, r2 = [], i2 = null, a2 = 0; a2 < n2.length; a2++) {
      var o2 = n2[a2];
      if (!(o2.ignore || o2.invisible)) {
        var s2 = o2.getBoundingRect(), c2 = o2.getLocalTransform(r2);
        c2 ? (X.applyTransform(t3, s2, c2), i2 || (i2 = t3.clone()), i2.union(t3)) : (i2 || (i2 = s2.clone()), i2.union(s2));
      }
    }
    return i2 || t3;
  }, t2;
})(mo);
So.prototype.type = `group`;
var Co = n({ dispose: () => Ao, disposeAll: () => jo, getElementSSRData: () => Fo, getInstance: () => Mo, init: () => ko, registerPainter: () => No, registerSSRDataGetter: () => Io, version: () => Lo }), wo = {}, To = {};
function Eo(e2) {
  delete To[e2];
}
function Do(e2) {
  if (!e2) return false;
  if (typeof e2 == `string`) return Si(e2, 1) < za;
  if (e2.colorStops) {
    for (var t2 = e2.colorStops, n2 = 0, r2 = t2.length, i2 = 0; i2 < r2; i2++) n2 += Si(t2[i2].color, 1);
    return n2 /= r2, n2 < za;
  }
  return false;
}
var Oo = (function() {
  function e2(e3, t2, n2) {
    var r2 = this;
    this._sleepAfterStill = 10, this._stillFrameAccum = 0, this._needsRefresh = true, this._needsRefreshHover = true, this._darkMode = false, n2 || (n2 = {}), this.dom = t2, this.id = e3;
    var i2 = new gr(), a2 = n2.renderer || `canvas`;
    wo[a2] || (a2 = V(wo)[0]), n2.useDirtyRect = n2.useDirtyRect != null && n2.useDirtyRect;
    var o2 = new wo[a2](t2, i2, n2, e3), s2 = n2.ssr || o2.ssrOnly;
    this.storage = i2, this.painter = o2;
    var c2 = !I.node && !I.worker && !s2 ? new Ia(o2.getViewportRoot(), o2.root) : null, l2 = n2.useCoarsePointer, u2 = l2 == null || l2 === `auto` ? I.touchEventsSupported : !!l2, d2 = 44, f2;
    u2 && (f2 = q(n2.pointerSize, d2)), this.handler = new $n(i2, o2, c2, o2.root, f2), this.animation = new _a({ stage: { update: s2 ? null : function() {
      return r2._flush(true);
    } } }), s2 || this.animation.start();
  }
  return e2.prototype.add = function(e3) {
    !this._disposed && e3 && (this.storage.addRoot(e3), e3.addSelfToZr(this), this.refresh());
  }, e2.prototype.remove = function(e3) {
    !this._disposed && e3 && (this.storage.delRoot(e3), e3.removeSelfFromZr(this), this.refresh());
  }, e2.prototype.configLayer = function(e3, t2) {
    this._disposed || (this.painter.configLayer && this.painter.configLayer(e3, t2), this.refresh());
  }, e2.prototype.setBackgroundColor = function(e3) {
    this._disposed || (this.painter.setBackgroundColor && this.painter.setBackgroundColor(e3), this.refresh(), this._backgroundColor = e3, this._darkMode = Do(e3));
  }, e2.prototype.getBackgroundColor = function() {
    return this._backgroundColor;
  }, e2.prototype.setDarkMode = function(e3) {
    this._darkMode = e3;
  }, e2.prototype.isDarkMode = function() {
    return this._darkMode;
  }, e2.prototype.refreshImmediately = function(e3) {
    this._disposed || (e3 || this.animation.update(true), this._needsRefresh = false, this.painter.refresh(), this._needsRefresh = false);
  }, e2.prototype.refresh = function() {
    this._disposed || (this._needsRefresh = true, this.animation.start());
  }, e2.prototype.flush = function() {
    this._disposed || this._flush(false);
  }, e2.prototype._flush = function(e3) {
    var t2, n2 = ga();
    this._needsRefresh && (t2 = true, this.refreshImmediately(e3)), this._needsRefreshHover && (t2 = true, this.refreshHoverImmediately());
    var r2 = ga();
    t2 ? (this._stillFrameAccum = 0, this.trigger(`rendered`, { elapsedTime: r2 - n2 })) : this._sleepAfterStill > 0 && (this._stillFrameAccum++, this._stillFrameAccum > this._sleepAfterStill && this.animation.stop());
  }, e2.prototype.setSleepAfterStill = function(e3) {
    this._sleepAfterStill = e3;
  }, e2.prototype.wakeUp = function() {
    this._disposed || (this.animation.start(), this._stillFrameAccum = 0);
  }, e2.prototype.refreshHover = function() {
    this._needsRefreshHover = true;
  }, e2.prototype.refreshHoverImmediately = function() {
    this._disposed || (this._needsRefreshHover = false, this.painter.refreshHover && this.painter.getType() === `canvas` && this.painter.refreshHover());
  }, e2.prototype.resize = function(e3) {
    this._disposed || (e3 || (e3 = {}), this.painter.resize(e3.width, e3.height), this.handler.resize());
  }, e2.prototype.clearAnimation = function() {
    this._disposed || this.animation.clear();
  }, e2.prototype.getWidth = function() {
    if (!this._disposed) return this.painter.getWidth();
  }, e2.prototype.getHeight = function() {
    if (!this._disposed) return this.painter.getHeight();
  }, e2.prototype.setCursorStyle = function(e3) {
    this._disposed || this.handler.setCursorStyle(e3);
  }, e2.prototype.findHover = function(e3, t2) {
    if (!this._disposed) return this.handler.findHover(e3, t2);
  }, e2.prototype.on = function(e3, t2, n2) {
    return this._disposed || this.handler.on(e3, t2, n2), this;
  }, e2.prototype.off = function(e3, t2) {
    this._disposed || this.handler.off(e3, t2);
  }, e2.prototype.trigger = function(e3, t2) {
    this._disposed || this.handler.trigger(e3, t2);
  }, e2.prototype.clear = function() {
    if (!this._disposed) {
      for (var e3 = this.storage.getRoots(), t2 = 0; t2 < e3.length; t2++) e3[t2] instanceof So && e3[t2].removeSelfFromZr(this);
      this.storage.delAllRoots(), this.painter.clear();
    }
  }, e2.prototype.dispose = function() {
    this._disposed || (this.animation.stop(), this.clear(), this.storage.dispose(), this.painter.dispose(), this.handler.dispose(), this.animation = this.storage = this.painter = this.handler = null, this._disposed = true, Eo(this.id));
  }, e2;
})();
function ko(e2, t2) {
  var n2 = new Oo(Fe(), e2, t2);
  return To[n2.id] = n2, n2;
}
function Ao(e2) {
  e2.dispose();
}
function jo() {
  for (var e2 in To) To.hasOwnProperty(e2) && To[e2].dispose();
  To = {};
}
function Mo(e2) {
  return To[e2];
}
function No(e2, t2) {
  wo[e2] = t2;
}
var Po;
function Fo(e2) {
  if (typeof Po == `function`) return Po(e2);
}
function Io(e2) {
  Po = e2;
}
var Lo = `5.6.1`, Ro = 1e-4, zo = 20;
function Bo(e2) {
  return e2.replace(/^\s+|\s+$/g, ``);
}
function Vo(e2, t2, n2, r2) {
  var i2 = t2[0], a2 = t2[1], o2 = n2[0], s2 = n2[1], c2 = a2 - i2, l2 = s2 - o2;
  if (c2 === 0) return l2 === 0 ? o2 : (o2 + s2) / 2;
  if (r2) {
    if (c2 > 0) {
      if (e2 <= i2) return o2;
      if (e2 >= a2) return s2;
    } else if (e2 >= i2) return o2;
    else if (e2 <= a2) return s2;
  } else {
    if (e2 === i2) return o2;
    if (e2 === a2) return s2;
  }
  return (e2 - i2) / c2 * l2 + o2;
}
function Ho(e2, t2) {
  switch (e2) {
    case `center`:
    case `middle`:
      e2 = `50%`;
      break;
    case `left`:
    case `top`:
      e2 = `0%`;
      break;
    case `right`:
    case `bottom`:
      e2 = `100%`;
  }
  return W(e2) ? Bo(e2).match(/%$/) ? parseFloat(e2) / 100 * t2 : parseFloat(e2) : e2 == null ? NaN : +e2;
}
function Uo(e2, t2, n2) {
  return t2 ?? (t2 = 10), t2 = Math.min(Math.max(0, t2), zo), e2 = (+e2).toFixed(t2), n2 ? e2 : +e2;
}
function Wo(e2) {
  return e2.sort(function(e3, t2) {
    return e3 - t2;
  }), e2;
}
function Go(e2) {
  if (e2 = +e2, isNaN(e2)) return 0;
  if (e2 > 1e-14) {
    for (var t2 = 1, n2 = 0; n2 < 15; n2++, t2 *= 10) if (Math.round(e2 * t2) / t2 === e2) return n2;
  }
  return Ko(e2);
}
function Ko(e2) {
  var t2 = e2.toString().toLowerCase(), n2 = t2.indexOf(`e`), r2 = n2 > 0 ? +t2.slice(n2 + 1) : 0, i2 = n2 > 0 ? n2 : t2.length, a2 = t2.indexOf(`.`), o2 = a2 < 0 ? 0 : i2 - 1 - a2;
  return Math.max(0, o2 - r2);
}
function qo(e2, t2) {
  var n2 = Math.log, r2 = Math.LN10, i2 = Math.floor(n2(e2[1] - e2[0]) / r2), a2 = Math.round(n2(Math.abs(t2[1] - t2[0])) / r2), o2 = Math.min(Math.max(-i2 + a2, 0), 20);
  return isFinite(o2) ? o2 : 20;
}
function Jo(e2, t2, n2) {
  return e2[t2] && Yo(e2, n2)[t2] || 0;
}
function Yo(e2, t2) {
  var n2 = Ge(e2, function(e3, t3) {
    return e3 + (isNaN(t3) ? 0 : t3);
  }, 0);
  if (n2 === 0) return [];
  for (var r2 = 10 ** t2, i2 = B(e2, function(e3) {
    return (isNaN(e3) ? 0 : e3) / n2 * r2 * 100;
  }), a2 = r2 * 100, o2 = B(i2, function(e3) {
    return Math.floor(e3);
  }), s2 = Ge(o2, function(e3, t3) {
    return e3 + t3;
  }, 0), c2 = B(i2, function(e3, t3) {
    return e3 - o2[t3];
  }); s2 < a2; ) {
    for (var l2 = -1 / 0, u2 = null, d2 = 0, f2 = c2.length; d2 < f2; ++d2) c2[d2] > l2 && (l2 = c2[d2], u2 = d2);
    ++o2[u2], c2[u2] = 0, ++s2;
  }
  return B(o2, function(e3) {
    return e3 / r2;
  });
}
function Xo(e2, t2) {
  var n2 = Math.max(Go(e2), Go(t2)), r2 = e2 + t2;
  return n2 > zo ? r2 : Uo(r2, n2);
}
var Zo = 9007199254740991;
function Qo(e2) {
  var t2 = Math.PI * 2;
  return (e2 % t2 + t2) % t2;
}
function $o(e2) {
  return e2 > -Ro && e2 < Ro;
}
var es = /^(?:(\d{4})(?:[-\/](\d{1,2})(?:[-\/](\d{1,2})(?:[T ](\d{1,2})(?::(\d{1,2})(?::(\d{1,2})(?:[.,](\d+))?)?)?(Z|[\+\-]\d\d:?\d\d)?)?)?)?)?$/;
function ts(e2) {
  if (e2 instanceof Date) return e2;
  if (W(e2)) {
    var t2 = es.exec(e2);
    if (!t2) return /* @__PURE__ */ new Date(NaN);
    if (t2[8]) {
      var n2 = +t2[4] || 0;
      return t2[8].toUpperCase() !== `Z` && (n2 -= +t2[8].slice(0, 3)), new Date(Date.UTC(+t2[1], (t2[2] || 1) - 1, +t2[3] || 1, n2, +(t2[5] || 0), +t2[6] || 0, t2[7] ? +t2[7].substring(0, 3) : 0));
    }
    return new Date(+t2[1], (t2[2] || 1) - 1, +t2[3] || 1, +t2[4] || 0, +(t2[5] || 0), +t2[6] || 0, t2[7] ? +t2[7].substring(0, 3) : 0);
  }
  return e2 == null ? /* @__PURE__ */ new Date(NaN) : new Date(Math.round(e2));
}
function ns(e2) {
  return 10 ** rs(e2);
}
function rs(e2) {
  if (e2 === 0) return 0;
  var t2 = Math.floor(Math.log(e2) / Math.LN10);
  return e2 / 10 ** t2 >= 10 && t2++, t2;
}
function is(e2, t2) {
  var n2 = rs(e2), r2 = 10 ** n2, i2 = e2 / r2;
  return e2 = (t2 ? i2 < 1.5 ? 1 : i2 < 2.5 ? 2 : i2 < 4 ? 3 : i2 < 7 ? 5 : 10 : i2 < 1 ? 1 : i2 < 2 ? 2 : i2 < 3 ? 3 : i2 < 5 ? 5 : 10) * r2, n2 >= -20 ? +e2.toFixed(n2 < 0 ? -n2 : 0) : e2;
}
function as(e2, t2) {
  var n2 = (e2.length - 1) * t2 + 1, r2 = Math.floor(n2), i2 = +e2[r2 - 1], a2 = n2 - r2;
  return a2 ? i2 + a2 * (e2[r2] - i2) : i2;
}
function os(e2) {
  e2.sort(function(e3, t3) {
    return s2(e3, t3, 0) ? -1 : 1;
  });
  for (var t2 = -1 / 0, n2 = 1, r2 = 0; r2 < e2.length; ) {
    for (var i2 = e2[r2].interval, a2 = e2[r2].close, o2 = 0; o2 < 2; o2++) i2[o2] <= t2 && (i2[o2] = t2, a2[o2] = o2 ? 1 : 1 - n2), t2 = i2[o2], n2 = a2[o2];
    i2[0] === i2[1] && a2[0] * a2[1] !== 1 ? e2.splice(r2, 1) : r2++;
  }
  return e2;
  function s2(e3, t3, n3) {
    return e3.interval[n3] < t3.interval[n3] || e3.interval[n3] === t3.interval[n3] && (e3.close[n3] - t3.close[n3] === (n3 ? -1 : 1) || !n3 && s2(e3, t3, 1));
  }
}
function ss(e2) {
  var t2 = parseFloat(e2);
  return t2 == e2 && (t2 !== 0 || !W(e2) || e2.indexOf(`x`) <= 0) ? t2 : NaN;
}
function cs(e2) {
  return !isNaN(ss(e2));
}
function ls() {
  return Math.round(Math.random() * 9);
}
function us(e2, t2) {
  return t2 === 0 ? e2 : us(t2, e2 % t2);
}
function ds(e2, t2) {
  return e2 == null ? t2 : t2 == null ? e2 : e2 * t2 / us(e2, t2);
}
function fs(e2) {
  throw Error(e2);
}
function ps(e2, t2, n2) {
  return (t2 - e2) * n2 + e2;
}
var ms = `series\0`, hs = `\0_ec_\0`;
function gs(e2) {
  return e2 instanceof Array ? e2 : e2 == null ? [] : [e2];
}
function _s(e2, t2, n2) {
  if (e2) {
    e2[t2] = e2[t2] || {}, e2.emphasis = e2.emphasis || {}, e2.emphasis[t2] = e2.emphasis[t2] || {};
    for (var r2 = 0, i2 = n2.length; r2 < i2; r2++) {
      var a2 = n2[r2];
      !e2.emphasis[t2].hasOwnProperty(a2) && e2[t2].hasOwnProperty(a2) && (e2.emphasis[t2][a2] = e2[t2][a2]);
    }
  }
}
var vs = `fontStyle.fontWeight.fontSize.fontFamily.rich.tag.color.textBorderColor.textBorderWidth.width.height.lineHeight.align.verticalAlign.baseline.shadowColor.shadowBlur.shadowOffsetX.shadowOffsetY.textShadowColor.textShadowBlur.textShadowOffsetX.textShadowOffsetY.backgroundColor.borderColor.borderWidth.borderRadius.padding`.split(`.`);
function ys(e2) {
  return K(e2) && !H(e2) && !(e2 instanceof Date) ? e2.value : e2;
}
function bs(e2) {
  return K(e2) && !(e2 instanceof Array);
}
function xs(e2, t2, n2) {
  var r2 = n2 === `normalMerge`, i2 = n2 === `replaceMerge`, a2 = n2 === `replaceAll`;
  e2 || (e2 = []), t2 = (t2 || []).slice();
  var o2 = J();
  z(t2, function(e3, n3) {
    if (!K(e3)) {
      t2[n3] = null;
      return;
    }
  });
  var s2 = Ss(e2, o2, n2);
  return (r2 || i2) && Cs(s2, e2, o2, t2), r2 && ws(s2, t2), r2 || i2 ? Ts(s2, t2, i2) : a2 && Es(s2, t2), Ds(s2), s2;
}
function Ss(e2, t2, n2) {
  var r2 = [];
  if (n2 === `replaceAll`) return r2;
  for (var i2 = 0; i2 < e2.length; i2++) {
    var a2 = e2[i2];
    a2 && a2.id != null && t2.set(a2.id, i2), r2.push({ existing: n2 === `replaceMerge` || Ms(a2) ? null : a2, newOption: null, keyInfo: null, brandNew: null });
  }
  return r2;
}
function Cs(e2, t2, n2, r2) {
  z(r2, function(i2, a2) {
    if (i2 && i2.id != null) {
      var o2 = ks(i2.id), s2 = n2.get(o2);
      if (s2 != null) {
        var c2 = e2[s2];
        lt(!c2.newOption, `Duplicated option on id "` + o2 + `".`), c2.newOption = i2, c2.existing = t2[s2], r2[a2] = null;
      }
    }
  });
}
function ws(e2, t2) {
  z(t2, function(n2, r2) {
    if (n2 && n2.name != null) for (var i2 = 0; i2 < e2.length; i2++) {
      var a2 = e2[i2].existing;
      if (!e2[i2].newOption && a2 && (a2.id == null || n2.id == null) && !Ms(n2) && !Ms(a2) && Os(`name`, a2, n2)) {
        e2[i2].newOption = n2, t2[r2] = null;
        return;
      }
    }
  });
}
function Ts(e2, t2, n2) {
  z(t2, function(t3) {
    if (t3) {
      for (var r2, i2 = 0; (r2 = e2[i2]) && (r2.newOption || Ms(r2.existing) || r2.existing && t3.id != null && !Os(`id`, t3, r2.existing)); ) i2++;
      r2 ? (r2.newOption = t3, r2.brandNew = n2) : e2.push({ newOption: t3, brandNew: n2, existing: null, keyInfo: null }), i2++;
    }
  });
}
function Es(e2, t2) {
  z(t2, function(t3) {
    e2.push({ newOption: t3, brandNew: true, existing: null, keyInfo: null });
  });
}
function Ds(e2) {
  var t2 = J();
  z(e2, function(e3) {
    var n2 = e3.existing;
    n2 && t2.set(n2.id, e3);
  }), z(e2, function(e3) {
    var n2 = e3.newOption;
    lt(!n2 || n2.id == null || !t2.get(n2.id) || t2.get(n2.id) === e3, `id duplicates: ` + (n2 && n2.id)), n2 && n2.id != null && t2.set(n2.id, e3), !e3.keyInfo && (e3.keyInfo = {});
  }), z(e2, function(e3, n2) {
    var r2 = e3.existing, i2 = e3.newOption, a2 = e3.keyInfo;
    if (K(i2)) {
      if (a2.name = i2.name == null ? r2 ? r2.name : ms + n2 : ks(i2.name), r2) a2.id = ks(r2.id);
      else if (i2.id != null) a2.id = ks(i2.id);
      else {
        var o2 = 0;
        do
          a2.id = `\0` + a2.name + `\0` + o2++;
        while (t2.get(a2.id));
      }
      t2.set(a2.id, e3);
    }
  });
}
function Os(e2, t2, n2) {
  var r2 = As(t2[e2], null), i2 = As(n2[e2], null);
  return r2 != null && i2 != null && r2 === i2;
}
function ks(e2) {
  return As(e2, ``);
}
function As(e2, t2) {
  return e2 == null ? t2 : W(e2) ? e2 : G(e2) || Ze(e2) ? e2 + `` : t2;
}
function js(e2) {
  var t2 = e2.name;
  return !!(t2 && t2.indexOf(ms));
}
function Ms(e2) {
  return e2 && e2.id != null && ks(e2.id).indexOf(hs) === 0;
}
function Ns(e2) {
  return hs + e2;
}
function Ps(e2, t2, n2) {
  z(e2, function(e3) {
    var r2 = e3.newOption;
    K(r2) && (e3.keyInfo.mainType = t2, e3.keyInfo.subType = Fs(t2, r2, e3.existing, n2));
  });
}
function Fs(e2, t2, n2, r2) {
  return t2.type ? t2.type : n2 ? n2.subType : r2.determineSubType(e2, t2);
}
function Is(e2, t2) {
  if (t2.dataIndexInside != null) return t2.dataIndexInside;
  if (t2.dataIndex != null) return H(t2.dataIndex) ? B(t2.dataIndex, function(t3) {
    return e2.indexOfRawIndex(t3);
  }) : e2.indexOfRawIndex(t2.dataIndex);
  if (t2.name != null) return H(t2.name) ? B(t2.name, function(t3) {
    return e2.indexOfName(t3);
  }) : e2.indexOfName(t2.name);
}
function Ls() {
  var e2 = `__ec_inner_` + Rs++;
  return function(t2) {
    return t2[e2] || (t2[e2] = {});
  };
}
var Rs = ls();
function zs(e2, t2, n2) {
  var r2 = Bs(t2, n2), i2 = r2.mainTypeSpecified, a2 = r2.queryOptionMap, o2 = r2.others, s2 = n2 ? n2.defaultMainType : null;
  return !i2 && s2 && a2.set(s2, {}), a2.each(function(t3, r3) {
    var i3 = Us(e2, r3, t3, { useDefault: s2 === r3, enableAll: n2 && n2.enableAll != null ? n2.enableAll : true, enableNone: n2 && n2.enableNone != null ? n2.enableNone : true });
    o2[r3 + `Models`] = i3.models, o2[r3 + `Model`] = i3.models[0];
  }), o2;
}
function Bs(e2, t2) {
  var n2;
  if (W(e2)) {
    var r2 = {};
    r2[e2 + `Index`] = 0, n2 = r2;
  } else n2 = e2;
  var i2 = J(), a2 = {}, o2 = false;
  return z(n2, function(e3, n3) {
    if (n3 === `dataIndex` || n3 === `dataIndexInside`) {
      a2[n3] = e3;
      return;
    }
    var r3 = n3.match(/^(\w+)(Index|Id|Name)$/) || [], s2 = r3[1], c2 = (r3[2] || ``).toLowerCase();
    if (!(!s2 || !c2 || t2 && t2.includeMainTypes && Ve(t2.includeMainTypes, s2) < 0)) {
      o2 || (o2 = !!s2);
      var l2 = i2.get(s2) || i2.set(s2, {});
      l2[c2] = e3;
    }
  }), { mainTypeSpecified: o2, queryOptionMap: i2, others: a2 };
}
var Vs = { useDefault: true, enableAll: false, enableNone: false }, Hs = { useDefault: false, enableAll: true, enableNone: true };
function Us(e2, t2, n2, r2) {
  r2 || (r2 = Vs);
  var i2 = n2.index, a2 = n2.id, o2 = n2.name, s2 = { models: null, specified: i2 != null || a2 != null || o2 != null };
  if (!s2.specified) {
    var c2 = void 0;
    return s2.models = r2.useDefault && (c2 = e2.getComponent(t2)) ? [c2] : [], s2;
  }
  return i2 === `none` || i2 === false ? (lt(r2.enableNone, '`"none"` or `false` is not a valid value on index option.'), s2.models = [], s2) : (i2 === `all` && (lt(r2.enableAll, '`"all"` is not a valid value on index option.'), i2 = a2 = o2 = null), s2.models = e2.queryComponents({ mainType: t2, index: i2, id: a2, name: o2 }), s2);
}
function Ws(e2, t2, n2) {
  e2.setAttribute ? e2.setAttribute(t2, n2) : e2[t2] = n2;
}
function Gs(e2, t2) {
  return e2.getAttribute ? e2.getAttribute(t2) : e2[t2];
}
function Ks(e2) {
  return e2 === `auto` ? I.domSupported ? `html` : `richText` : e2 || `html`;
}
function qs(e2, t2, n2, r2, i2) {
  var a2 = t2 == null || t2 === `auto`;
  if (r2 == null) return r2;
  if (G(r2)) {
    var o2 = ps(n2 || 0, r2, i2);
    return Uo(o2, a2 ? Math.max(Go(n2 || 0), Go(r2)) : t2);
  }
  if (W(r2)) return i2 < 1 ? n2 : r2;
  for (var s2 = [], c2 = n2, l2 = r2, u2 = Math.max(c2 ? c2.length : 0, l2.length), d2 = 0; d2 < u2; ++d2) {
    var f2 = e2.getDimensionInfo(d2);
    if (f2 && f2.type === `ordinal`) s2[d2] = (i2 < 1 && c2 ? c2 : l2)[d2];
    else {
      var p2 = c2 && c2[d2] ? c2[d2] : 0, m2 = l2[d2], o2 = ps(p2, m2, i2);
      s2[d2] = Uo(o2, a2 ? Math.max(Go(p2), Go(m2)) : t2);
    }
  }
  return s2;
}
M();
var Js = `.`, Ys = `___EC__COMPONENT__CONTAINER___`, Xs = `___EC__EXTENDED_CLASS___`;
function Zs(e2) {
  var t2 = { main: ``, sub: `` };
  if (e2) {
    var n2 = e2.split(Js);
    t2.main = n2[0] || ``, t2.sub = n2[1] || ``;
  }
  return t2;
}
function Qs(e2) {
  lt(/^[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)?$/.test(e2), `componentType "` + e2 + `" illegal`);
}
function $s(e2) {
  return !!(e2 && e2[Xs]);
}
function ec(e2, t2) {
  e2.$constructor = e2, e2.extend = function(e3) {
    var t3 = this, n2;
    return tc(t3) ? n2 = (function(e4) {
      s(t4, e4);
      function t4() {
        return e4.apply(this, arguments) || this;
      }
      return t4;
    })(t3) : (n2 = function() {
      (e3.$constructor || t3).apply(this, arguments);
    }, He(n2, this)), R(n2.prototype, e3), n2[Xs] = true, n2.extend = this.extend, n2.superCall = ac, n2.superApply = oc, n2.superClass = t3, n2;
  };
}
function tc(e2) {
  return U(e2) && /^class\s/.test(Function.prototype.toString.call(e2));
}
function nc(e2, t2) {
  e2.extend = t2.extend;
}
var rc = Math.round(Math.random() * 10);
function ic(e2) {
  var t2 = [`__\0is_clz`, rc++].join(`_`);
  e2.prototype[t2] = true, e2.isInstance = function(e3) {
    return !!(e3 && e3[t2]);
  };
}
function ac(e2, t2) {
  var n2 = [...arguments].slice(2);
  return this.superClass.prototype[t2].apply(e2, n2);
}
function oc(e2, t2, n2) {
  return this.superClass.prototype[t2].apply(e2, n2);
}
function sc(e2) {
  var t2 = {};
  e2.registerClass = function(e3) {
    var r2 = e3.type || e3.prototype.type;
    if (r2) {
      Qs(r2), e3.prototype.type = r2;
      var i2 = Zs(r2);
      if (!i2.sub) t2[i2.main] = e3;
      else if (i2.sub !== Ys) {
        var a2 = n2(i2);
        a2[i2.sub] = e3;
      }
    }
    return e3;
  }, e2.getClass = function(e3, n3, r2) {
    var i2 = t2[e3];
    if (i2 && i2[Ys] && (i2 = n3 ? i2[n3] : null), r2 && !i2) throw Error(n3 ? `Component ` + e3 + `.` + (n3 || ``) + ` is used but not imported.` : e3 + `.type should be specified.`);
    return i2;
  }, e2.getClassesByMainType = function(e3) {
    var n3 = Zs(e3), r2 = [], i2 = t2[n3.main];
    return i2 && i2[Ys] ? z(i2, function(e4, t3) {
      t3 !== Ys && r2.push(e4);
    }) : r2.push(i2), r2;
  }, e2.hasClass = function(e3) {
    return !!t2[Zs(e3).main];
  }, e2.getAllClassMainTypes = function() {
    var e3 = [];
    return z(t2, function(t3, n3) {
      e3.push(n3);
    }), e3;
  }, e2.hasSubTypes = function(e3) {
    var n3 = t2[Zs(e3).main];
    return n3 && n3[Ys];
  };
  function n2(e3) {
    var n3 = t2[e3.main];
    return (!n3 || !n3[Ys]) && (n3 = t2[e3.main] = {}, n3[Ys] = true), n3;
  }
}
function cc(e2, t2) {
  for (var n2 = 0; n2 < e2.length; n2++) e2[n2][1] || (e2[n2][1] = e2[n2][0]);
  return t2 || (t2 = false), function(n3, r2, i2) {
    for (var a2 = {}, o2 = 0; o2 < e2.length; o2++) {
      var s2 = e2[o2][1];
      if (!(r2 && Ve(r2, s2) >= 0 || i2 && Ve(i2, s2) < 0)) {
        var c2 = n3.getShallow(s2, t2);
        c2 != null && (a2[e2[o2][0]] = c2);
      }
    }
    return a2;
  };
}
var lc = cc([[`fill`, `color`], [`shadowBlur`], [`shadowOffsetX`], [`shadowOffsetY`], [`opacity`], [`shadowColor`]]), uc = (function() {
  function e2() {
  }
  return e2.prototype.getAreaStyle = function(e3, t2) {
    return lc(this, e3, t2);
  }, e2;
})(), dc = new Yr(50);
function fc(e2) {
  if (typeof e2 == `string`) {
    var t2 = dc.get(e2);
    return t2 && t2.image;
  }
  return e2;
}
function pc(e2, t2, n2, r2, i2) {
  if (!e2) return t2;
  if (typeof e2 == `string`) {
    if (t2 && t2.__zrImageSrc === e2 || !n2) return t2;
    var a2 = dc.get(e2), o2 = { hostEl: n2, cb: r2, cbPayload: i2 };
    return a2 ? (t2 = a2.image, !hc(t2) && a2.pending.push(o2)) : (t2 = be.loadImage(e2, mc, mc), t2.__zrImageSrc = e2, dc.put(e2, t2.__cachedImgObj = { image: t2, pending: [o2] })), t2;
  }
  return e2;
}
function mc() {
  var e2 = this.__cachedImgObj;
  this.onload = this.onerror = this.__cachedImgObj = null;
  for (var t2 = 0; t2 < e2.pending.length; t2++) {
    var n2 = e2.pending[t2], r2 = n2.cb;
    r2 && r2(this, n2.cbPayload), n2.hostEl.dirty();
  }
  e2.pending.length = 0;
}
function hc(e2) {
  return e2 && e2.width && e2.height;
}
var gc = /\{([a-zA-Z0-9_]+)\|([^}]*)\}/g;
function _c(e2, t2, n2, r2, i2) {
  var a2 = {};
  return vc(a2, e2, t2, n2, r2, i2), a2.text;
}
function vc(e2, t2, n2, r2, i2, a2) {
  if (!n2) {
    e2.text = ``, e2.isTruncated = false;
    return;
  }
  var o2 = (t2 + ``).split(`
`);
  a2 = yc(n2, r2, i2, a2);
  for (var s2 = false, c2 = {}, l2 = 0, u2 = o2.length; l2 < u2; l2++) bc(c2, o2[l2], a2), o2[l2] = c2.textLine, s2 || (s2 = c2.isTruncated);
  e2.text = o2.join(`
`), e2.isTruncated = s2;
}
function yc(e2, t2, n2, r2) {
  r2 || (r2 = {});
  var i2 = R({}, r2);
  i2.font = t2, n2 = q(n2, `...`), i2.maxIterations = q(r2.maxIterations, 2);
  var a2 = i2.minChar = q(r2.minChar, 0);
  i2.cnCharWidth = eo(`\u56FD`, t2);
  var o2 = i2.ascCharWidth = eo(`a`, t2);
  i2.placeholder = q(r2.placeholder, ``);
  for (var s2 = e2 = Math.max(0, e2 - 1), c2 = 0; c2 < a2 && s2 >= o2; c2++) s2 -= o2;
  var l2 = eo(n2, t2);
  return l2 > s2 && (n2 = ``, l2 = 0), s2 = e2 - l2, i2.ellipsis = n2, i2.ellipsisWidth = l2, i2.contentWidth = s2, i2.containerWidth = e2, i2;
}
function bc(e2, t2, n2) {
  var r2 = n2.containerWidth, i2 = n2.font, a2 = n2.contentWidth;
  if (!r2) {
    e2.textLine = ``, e2.isTruncated = false;
    return;
  }
  var o2 = eo(t2, i2);
  if (o2 <= r2) {
    e2.textLine = t2, e2.isTruncated = false;
    return;
  }
  for (var s2 = 0; ; s2++) {
    if (o2 <= a2 || s2 >= n2.maxIterations) {
      t2 += n2.ellipsis;
      break;
    }
    var c2 = s2 === 0 ? xc(t2, a2, n2.ascCharWidth, n2.cnCharWidth) : o2 > 0 ? Math.floor(t2.length * a2 / o2) : 0;
    t2 = t2.substr(0, c2), o2 = eo(t2, i2);
  }
  t2 === `` && (t2 = n2.placeholder), e2.textLine = t2, e2.isTruncated = true;
}
function xc(e2, t2, n2, r2) {
  for (var i2 = 0, a2 = 0, o2 = e2.length; a2 < o2 && i2 < t2; a2++) {
    var s2 = e2.charCodeAt(a2);
    i2 += 0 <= s2 && s2 <= 127 ? n2 : r2;
  }
  return a2;
}
function Sc(e2, t2) {
  e2 != null && (e2 += ``);
  var n2 = t2.overflow, r2 = t2.padding, i2 = t2.font, a2 = n2 === `truncate`, o2 = ao(i2), s2 = q(t2.lineHeight, o2), c2 = !!t2.backgroundColor, l2 = t2.lineOverflow === `truncate`, u2 = false, d2 = t2.width, f2 = d2 != null && (n2 === `break` || n2 === `breakAll`) ? e2 ? jc(e2, t2.font, d2, n2 === `breakAll`, 0).lines : [] : e2 ? e2.split(`
`) : [], p2 = f2.length * s2, m2 = q(t2.height, p2);
  if (p2 > m2 && l2) {
    var h2 = Math.floor(m2 / s2);
    u2 || (u2 = f2.length > h2), f2 = f2.slice(0, h2);
  }
  if (e2 && a2 && d2 != null) for (var g2 = yc(d2, i2, t2.ellipsis, { minChar: t2.truncateMinChar, placeholder: t2.placeholder }), _2 = {}, v2 = 0; v2 < f2.length; v2++) bc(_2, f2[v2], g2), f2[v2] = _2.textLine, u2 || (u2 = _2.isTruncated);
  for (var y2 = m2, b2 = 0, v2 = 0; v2 < f2.length; v2++) b2 = Math.max(eo(f2[v2], i2), b2);
  d2 ?? (d2 = b2);
  var x2 = b2;
  return r2 && (y2 += r2[0] + r2[2], x2 += r2[1] + r2[3], d2 += r2[1] + r2[3]), c2 && (x2 = d2), { lines: f2, height: m2, outerWidth: x2, outerHeight: y2, lineHeight: s2, calculatedLineHeight: o2, contentWidth: b2, contentHeight: p2, width: d2, isTruncated: u2 };
}
var Cc = /* @__PURE__ */ (function() {
  function e2() {
  }
  return e2;
})(), wc = /* @__PURE__ */ (function() {
  function e2(e3) {
    this.tokens = [], e3 && (this.tokens = e3);
  }
  return e2;
})(), Tc = /* @__PURE__ */ (function() {
  function e2() {
    this.width = 0, this.height = 0, this.contentWidth = 0, this.contentHeight = 0, this.outerWidth = 0, this.outerHeight = 0, this.lines = [], this.isTruncated = false;
  }
  return e2;
})();
function Ec(e2, t2) {
  var n2 = new Tc();
  if (e2 != null && (e2 += ``), !e2) return n2;
  for (var r2 = t2.width, i2 = t2.height, a2 = t2.overflow, o2 = (a2 === `break` || a2 === `breakAll`) && r2 != null ? { width: r2, accumWidth: 0, breakAll: a2 === `breakAll` } : null, s2 = gc.lastIndex = 0, c2; (c2 = gc.exec(e2)) != null; ) {
    var l2 = c2.index;
    l2 > s2 && Dc(n2, e2.substring(s2, l2), t2, o2), Dc(n2, c2[2], t2, o2, c2[1]), s2 = gc.lastIndex;
  }
  s2 < e2.length && Dc(n2, e2.substring(s2, e2.length), t2, o2);
  var u2 = [], d2 = 0, f2 = 0, p2 = t2.padding, m2 = a2 === `truncate`, h2 = t2.lineOverflow === `truncate`, g2 = {};
  function _2(e3, t3, n3) {
    e3.width = t3, e3.lineHeight = n3, d2 += n3, f2 = Math.max(f2, t3);
  }
  outer: for (var v2 = 0; v2 < n2.lines.length; v2++) {
    for (var y2 = n2.lines[v2], b2 = 0, x2 = 0, S2 = 0; S2 < y2.tokens.length; S2++) {
      var C2 = y2.tokens[S2], w2 = C2.styleName && t2.rich[C2.styleName] || {}, T2 = C2.textPadding = w2.padding, E2 = T2 ? T2[1] + T2[3] : 0, D2 = C2.font = w2.font || t2.font;
      C2.contentHeight = ao(D2);
      var O2 = q(w2.height, C2.contentHeight);
      if (C2.innerHeight = O2, T2 && (O2 += T2[0] + T2[2]), C2.height = O2, C2.lineHeight = ot(w2.lineHeight, t2.lineHeight, O2), C2.align = w2 && w2.align || t2.align, C2.verticalAlign = w2 && w2.verticalAlign || `middle`, h2 && i2 != null && d2 + C2.lineHeight > i2) {
        var k2 = n2.lines.length;
        S2 > 0 ? (y2.tokens = y2.tokens.slice(0, S2), _2(y2, x2, b2), n2.lines = n2.lines.slice(0, v2 + 1)) : n2.lines = n2.lines.slice(0, v2), n2.isTruncated = n2.isTruncated || n2.lines.length < k2;
        break outer;
      }
      var A2 = w2.width, j2 = A2 == null || A2 === `auto`;
      if (typeof A2 == `string` && A2.charAt(A2.length - 1) === `%`) C2.percentWidth = A2, u2.push(C2), C2.contentWidth = eo(C2.text, D2);
      else {
        if (j2) {
          var ee2 = w2.backgroundColor, M2 = ee2 && ee2.image;
          M2 && (M2 = fc(M2), hc(M2) && (C2.width = Math.max(C2.width, M2.width * O2 / M2.height)));
        }
        var N2 = m2 && r2 != null ? r2 - x2 : null;
        N2 != null && N2 < C2.width ? !j2 || N2 < E2 ? (C2.text = ``, C2.width = C2.contentWidth = 0) : (vc(g2, C2.text, N2 - E2, D2, t2.ellipsis, { minChar: t2.truncateMinChar }), C2.text = g2.text, n2.isTruncated = n2.isTruncated || g2.isTruncated, C2.width = C2.contentWidth = eo(C2.text, D2)) : C2.contentWidth = eo(C2.text, D2);
      }
      C2.width += E2, x2 += C2.width, w2 && (b2 = Math.max(b2, C2.lineHeight));
    }
    _2(y2, x2, b2);
  }
  n2.outerWidth = n2.width = q(r2, f2), n2.outerHeight = n2.height = q(i2, d2), n2.contentHeight = d2, n2.contentWidth = f2, p2 && (n2.outerWidth += p2[1] + p2[3], n2.outerHeight += p2[0] + p2[2]);
  for (var v2 = 0; v2 < u2.length; v2++) {
    var C2 = u2[v2], te2 = C2.percentWidth;
    C2.width = parseInt(te2, 10) / 100 * n2.width;
  }
  return n2;
}
function Dc(e2, t2, n2, r2, i2) {
  var a2 = t2 === ``, o2 = i2 && n2.rich[i2] || {}, s2 = e2.lines, c2 = o2.font || n2.font, l2 = false, u2, d2;
  if (r2) {
    var f2 = o2.padding, p2 = f2 ? f2[1] + f2[3] : 0;
    if (o2.width != null && o2.width !== `auto`) {
      var m2 = oo(o2.width, r2.width) + p2;
      s2.length > 0 && m2 + r2.accumWidth > r2.width && (u2 = t2.split(`
`), l2 = true), r2.accumWidth = m2;
    } else {
      var h2 = jc(t2, c2, r2.width, r2.breakAll, r2.accumWidth);
      r2.accumWidth = h2.accumWidth + p2, d2 = h2.linesWidths, u2 = h2.lines;
    }
  } else u2 = t2.split(`
`);
  for (var g2 = 0; g2 < u2.length; g2++) {
    var _2 = u2[g2], v2 = new Cc();
    if (v2.styleName = i2, v2.text = _2, v2.isLineHolder = !_2 && !a2, v2.width = typeof o2.width == `number` ? o2.width : d2 ? d2[g2] : eo(_2, c2), !g2 && !l2) {
      var y2 = (s2[s2.length - 1] || (s2[0] = new wc())).tokens, b2 = y2.length;
      b2 === 1 && y2[0].isLineHolder ? y2[0] = v2 : (_2 || !b2 || a2) && y2.push(v2);
    } else s2.push(new wc([v2]));
  }
}
function Oc(e2) {
  var t2 = e2.charCodeAt(0);
  return t2 >= 32 && t2 <= 591 || t2 >= 880 && t2 <= 4351 || t2 >= 4608 && t2 <= 5119 || t2 >= 7680 && t2 <= 8303;
}
var kc = Ge(`,&?/;] `.split(``), function(e2, t2) {
  return e2[t2] = true, e2;
}, {});
function Ac(e2) {
  return !Oc(e2) || !!kc[e2];
}
function jc(e2, t2, n2, r2, i2) {
  for (var a2 = [], o2 = [], s2 = ``, c2 = ``, l2 = 0, u2 = 0, d2 = 0; d2 < e2.length; d2++) {
    var f2 = e2.charAt(d2);
    if (f2 === `
`) {
      c2 && (s2 += c2, u2 += l2), a2.push(s2), o2.push(u2), s2 = ``, c2 = ``, l2 = 0, u2 = 0;
      continue;
    }
    var p2 = eo(f2, t2), m2 = !r2 && !Ac(f2);
    if (a2.length ? u2 + p2 > n2 : i2 + u2 + p2 > n2) {
      u2 ? (s2 || c2) && (m2 ? (s2 || (s2 = c2, c2 = ``, l2 = 0, u2 = l2), a2.push(s2), o2.push(u2 - l2), c2 += f2, l2 += p2, s2 = ``, u2 = l2) : (c2 && (s2 += c2, c2 = ``, l2 = 0), a2.push(s2), o2.push(u2), s2 = f2, u2 = p2)) : m2 ? (a2.push(c2), o2.push(l2), c2 = f2, l2 = p2) : (a2.push(f2), o2.push(p2));
      continue;
    }
    u2 += p2, m2 ? (c2 += f2, l2 += p2) : (c2 && (s2 += c2, c2 = ``, l2 = 0), s2 += f2);
  }
  return !a2.length && !s2 && (s2 = e2, c2 = ``, l2 = 0), c2 && (s2 += c2), s2 && (a2.push(s2), o2.push(u2)), a2.length === 1 && (u2 += i2), { accumWidth: u2, lines: a2, linesWidths: o2 };
}
M();
var Mc = `__zr_style_` + Math.round(Math.random() * 10), Nc = { shadowBlur: 0, shadowOffsetX: 0, shadowOffsetY: 0, shadowColor: `#000`, opacity: 1, blend: `source-over` }, Pc = { style: { shadowBlur: true, shadowOffsetX: true, shadowOffsetY: true, shadowColor: true, opacity: true } };
Nc[Mc] = true;
var Fc = [`z`, `z2`, `invisible`], Ic = [`invisible`], Lc = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype._init = function(t3) {
    for (var n2 = V(t3), r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2];
      i2 === `style` ? this.useStyle(t3[i2]) : e2.prototype.attrKV.call(this, i2, t3[i2]);
    }
    this.style || this.useStyle({});
  }, t2.prototype.beforeBrush = function() {
  }, t2.prototype.afterBrush = function() {
  }, t2.prototype.innerBeforeBrush = function() {
  }, t2.prototype.innerAfterBrush = function() {
  }, t2.prototype.shouldBePainted = function(e3, t3, n2, r2) {
    var i2 = this.transform;
    if (this.ignore || this.invisible || this.style.opacity === 0 || this.culling && Bc(this, e3, t3) || i2 && !i2[0] && !i2[3]) return false;
    if (n2 && this.__clipPaths) {
      for (var a2 = 0; a2 < this.__clipPaths.length; ++a2) if (this.__clipPaths[a2].isZeroArea()) return false;
    }
    if (r2 && this.parent) for (var o2 = this.parent; o2; ) {
      if (o2.ignore) return false;
      o2 = o2.parent;
    }
    return true;
  }, t2.prototype.contain = function(e3, t3) {
    return this.rectContain(e3, t3);
  }, t2.prototype.traverse = function(e3, t3) {
    e3.call(t3, this);
  }, t2.prototype.rectContain = function(e3, t3) {
    var n2 = this.transformCoordToLocal(e3, t3);
    return this.getBoundingRect().contain(n2[0], n2[1]);
  }, t2.prototype.getPaintRect = function() {
    var e3 = this._paintRect;
    if (!this._paintRect || this.__dirty) {
      var t3 = this.transform, n2 = this.getBoundingRect(), r2 = this.style, i2 = r2.shadowBlur || 0, a2 = r2.shadowOffsetX || 0, o2 = r2.shadowOffsetY || 0;
      e3 = this._paintRect || (this._paintRect = new X(0, 0, 0, 0)), t3 ? X.applyTransform(e3, n2, t3) : e3.copy(n2), (i2 || a2 || o2) && (e3.width += i2 * 2 + Math.abs(a2), e3.height += i2 * 2 + Math.abs(o2), e3.x = Math.min(e3.x, e3.x + a2 - i2), e3.y = Math.min(e3.y, e3.y + o2 - i2));
      var s2 = this.dirtyRectTolerance;
      e3.isZero() || (e3.x = Math.floor(e3.x - s2), e3.y = Math.floor(e3.y - s2), e3.width = Math.ceil(e3.width + 1 + s2 * 2), e3.height = Math.ceil(e3.height + 1 + s2 * 2));
    }
    return e3;
  }, t2.prototype.setPrevPaintRect = function(e3) {
    e3 ? (this._prevPaintRect = this._prevPaintRect || new X(0, 0, 0, 0), this._prevPaintRect.copy(e3)) : this._prevPaintRect = null;
  }, t2.prototype.getPrevPaintRect = function() {
    return this._prevPaintRect;
  }, t2.prototype.animateStyle = function(e3) {
    return this.animate(`style`, e3);
  }, t2.prototype.updateDuringAnimation = function(e3) {
    e3 === `style` ? this.dirtyStyle() : this.markRedraw();
  }, t2.prototype.attrKV = function(t3, n2) {
    t3 === `style` ? this.style ? this.setStyle(n2) : this.useStyle(n2) : e2.prototype.attrKV.call(this, t3, n2);
  }, t2.prototype.setStyle = function(e3, t3) {
    return typeof e3 == `string` ? this.style[e3] = t3 : R(this.style, e3), this.dirtyStyle(), this;
  }, t2.prototype.dirtyStyle = function(e3) {
    e3 || this.markRedraw(), this.__dirty |= 2, this._rect && (this._rect = null);
  }, t2.prototype.dirty = function() {
    this.dirtyStyle();
  }, t2.prototype.styleChanged = function() {
    return !!(this.__dirty & 2);
  }, t2.prototype.styleUpdated = function() {
    this.__dirty &= -3;
  }, t2.prototype.createStyle = function(e3) {
    return yt(Nc, e3);
  }, t2.prototype.useStyle = function(e3) {
    e3[Mc] || (e3 = this.createStyle(e3)), this.__inHover ? this.__hoverStyle = e3 : this.style = e3, this.dirtyStyle();
  }, t2.prototype.isStyleObject = function(e3) {
    return e3[Mc];
  }, t2.prototype._innerSaveToNormal = function(t3) {
    e2.prototype._innerSaveToNormal.call(this, t3);
    var n2 = this._normalState;
    t3.style && !n2.style && (n2.style = this._mergeStyle(this.createStyle(), this.style)), this._savePrimaryToNormal(t3, n2, Fc);
  }, t2.prototype._applyStateObj = function(t3, n2, r2, i2, a2, o2) {
    e2.prototype._applyStateObj.call(this, t3, n2, r2, i2, a2, o2);
    var s2 = !(n2 && i2), c2;
    if (n2 && n2.style ? a2 ? i2 ? c2 = n2.style : (c2 = this._mergeStyle(this.createStyle(), r2.style), this._mergeStyle(c2, n2.style)) : (c2 = this._mergeStyle(this.createStyle(), i2 ? this.style : r2.style), this._mergeStyle(c2, n2.style)) : s2 && (c2 = r2.style), c2) {
      if (a2) {
        var l2 = this.style;
        if (this.style = this.createStyle(s2 ? {} : l2), s2) for (var u2 = V(l2), d2 = 0; d2 < u2.length; d2++) {
          var f2 = u2[d2];
          f2 in c2 && (c2[f2] = c2[f2], this.style[f2] = l2[f2]);
        }
        for (var p2 = V(c2), d2 = 0; d2 < p2.length; d2++) {
          var f2 = p2[d2];
          this.style[f2] = this.style[f2];
        }
        this._transitionState(t3, { style: c2 }, o2, this.getAnimationStyleProps());
      } else this.useStyle(c2);
    }
    for (var m2 = this.__inHover ? Ic : Fc, d2 = 0; d2 < m2.length; d2++) {
      var f2 = m2[d2];
      n2 && n2[f2] != null ? this[f2] = n2[f2] : s2 && r2[f2] != null && (this[f2] = r2[f2]);
    }
  }, t2.prototype._mergeStates = function(t3) {
    for (var n2 = e2.prototype._mergeStates.call(this, t3), r2, i2 = 0; i2 < t3.length; i2++) {
      var a2 = t3[i2];
      a2.style && (r2 || (r2 = {}), this._mergeStyle(r2, a2.style));
    }
    return r2 && (n2.style = r2), n2;
  }, t2.prototype._mergeStyle = function(e3, t3) {
    return R(e3, t3), e3;
  }, t2.prototype.getAnimationStyleProps = function() {
    return Pc;
  }, t2.initDefaultProps = (function() {
    var e3 = t2.prototype;
    e3.type = `displayable`, e3.invisible = false, e3.z = 0, e3.z2 = 0, e3.zlevel = 0, e3.culling = false, e3.cursor = `pointer`, e3.rectHover = false, e3.incremental = false, e3._rect = null, e3.dirtyRectTolerance = 0, e3.__dirty = 3;
  })(), t2;
})(mo), Rc = new X(0, 0, 0, 0), zc = new X(0, 0, 0, 0);
function Bc(e2, t2, n2) {
  return Rc.copy(e2.getBoundingRect()), e2.transform && Rc.applyTransform(e2.transform), zc.width = t2, zc.height = n2, !Rc.intersect(zc);
}
var Vc = Math.min, Hc = Math.max, Uc = Math.sin, Wc = Math.cos, Gc = Math.PI * 2, Kc = Tt(), qc = Tt(), Jc = Tt();
function Yc(e2, t2, n2, r2, i2, a2) {
  i2[0] = Vc(e2, n2), i2[1] = Vc(t2, r2), a2[0] = Hc(e2, n2), a2[1] = Hc(t2, r2);
}
var Xc = [], Zc = [];
function Qc(e2, t2, n2, r2, i2, a2, o2, s2, c2, l2) {
  var u2 = Nr, d2 = Ar, f2 = u2(e2, n2, i2, o2, Xc);
  c2[0] = 1 / 0, c2[1] = 1 / 0, l2[0] = -1 / 0, l2[1] = -1 / 0;
  for (var p2 = 0; p2 < f2; p2++) {
    var m2 = d2(e2, n2, i2, o2, Xc[p2]);
    c2[0] = Vc(m2, c2[0]), l2[0] = Hc(m2, l2[0]);
  }
  f2 = u2(t2, r2, a2, s2, Zc);
  for (var p2 = 0; p2 < f2; p2++) {
    var h2 = d2(t2, r2, a2, s2, Zc[p2]);
    c2[1] = Vc(h2, c2[1]), l2[1] = Hc(h2, l2[1]);
  }
  c2[0] = Vc(e2, c2[0]), l2[0] = Hc(e2, l2[0]), c2[0] = Vc(o2, c2[0]), l2[0] = Hc(o2, l2[0]), c2[1] = Vc(t2, c2[1]), l2[1] = Hc(t2, l2[1]), c2[1] = Vc(s2, c2[1]), l2[1] = Hc(s2, l2[1]);
}
function $c(e2, t2, n2, r2, i2, a2, o2, s2) {
  var c2 = Br, l2 = Lr, u2 = Hc(Vc(c2(e2, n2, i2), 1), 0), d2 = Hc(Vc(c2(t2, r2, a2), 1), 0), f2 = l2(e2, n2, i2, u2), p2 = l2(t2, r2, a2, d2);
  o2[0] = Vc(e2, i2, f2), o2[1] = Vc(t2, a2, p2), s2[0] = Hc(e2, i2, f2), s2[1] = Hc(t2, a2, p2);
}
function el(e2, t2, n2, r2, i2, a2, o2, s2, c2) {
  var l2 = Jt, u2 = Yt, d2 = Math.abs(i2 - a2);
  if (d2 % Gc < 1e-4 && d2 > 1e-4) {
    s2[0] = e2 - n2, s2[1] = t2 - r2, c2[0] = e2 + n2, c2[1] = t2 + r2;
    return;
  }
  if (Kc[0] = Wc(i2) * n2 + e2, Kc[1] = Uc(i2) * r2 + t2, qc[0] = Wc(a2) * n2 + e2, qc[1] = Uc(a2) * r2 + t2, l2(s2, Kc, qc), u2(c2, Kc, qc), i2 %= Gc, i2 < 0 && (i2 += Gc), a2 %= Gc, a2 < 0 && (a2 += Gc), i2 > a2 && !o2 ? a2 += Gc : i2 < a2 && o2 && (i2 += Gc), o2) {
    var f2 = a2;
    a2 = i2, i2 = f2;
  }
  for (var p2 = 0; p2 < a2; p2 += Math.PI / 2) p2 > i2 && (Jc[0] = Wc(p2) * n2 + e2, Jc[1] = Uc(p2) * r2 + t2, l2(s2, Jc, s2), u2(c2, Jc, c2));
}
var Z = { M: 1, L: 2, C: 3, Q: 4, A: 5, Z: 6, R: 7 }, tl = [], nl = [], rl = [], il = [], al = [], ol = [], sl = Math.min, cl = Math.max, ll = Math.cos, ul = Math.sin, dl = Math.abs, fl = Math.PI, pl = fl * 2, ml = typeof Float32Array < `u`, hl = [];
function gl(e2) {
  return Math.round(e2 / fl * 1e8) / 1e8 % 2 * fl;
}
function _l(e2, t2) {
  var n2 = gl(e2[0]);
  n2 < 0 && (n2 += pl);
  var r2 = n2 - e2[0], i2 = e2[1];
  i2 += r2, !t2 && i2 - n2 >= pl ? i2 = n2 + pl : t2 && n2 - i2 >= pl ? i2 = n2 - pl : !t2 && n2 > i2 ? i2 = n2 + (pl - gl(n2 - i2)) : t2 && n2 < i2 && (i2 = n2 - (pl - gl(i2 - n2))), e2[0] = n2, e2[1] = i2;
}
var vl = (function() {
  function e2(e3) {
    this.dpr = 1, this._xi = 0, this._yi = 0, this._x0 = 0, this._y0 = 0, this._len = 0, e3 && (this._saveData = false), this._saveData && (this.data = []);
  }
  return e2.prototype.increaseVersion = function() {
    this._version++;
  }, e2.prototype.getVersion = function() {
    return this._version;
  }, e2.prototype.setScale = function(e3, t2, n2) {
    n2 || (n2 = 0), n2 > 0 && (this._ux = dl(n2 / Ra / e3) || 0, this._uy = dl(n2 / Ra / t2) || 0);
  }, e2.prototype.setDPR = function(e3) {
    this.dpr = e3;
  }, e2.prototype.setContext = function(e3) {
    this._ctx = e3;
  }, e2.prototype.getContext = function() {
    return this._ctx;
  }, e2.prototype.beginPath = function() {
    return this._ctx && this._ctx.beginPath(), this.reset(), this;
  }, e2.prototype.reset = function() {
    this._saveData && (this._len = 0), this._pathSegLen && (this._pathSegLen = null, this._pathLen = 0), this._version++;
  }, e2.prototype.moveTo = function(e3, t2) {
    return this._drawPendingPt(), this.addData(Z.M, e3, t2), this._ctx && this._ctx.moveTo(e3, t2), this._x0 = e3, this._y0 = t2, this._xi = e3, this._yi = t2, this;
  }, e2.prototype.lineTo = function(e3, t2) {
    var n2 = dl(e3 - this._xi), r2 = dl(t2 - this._yi), i2 = n2 > this._ux || r2 > this._uy;
    if (this.addData(Z.L, e3, t2), this._ctx && i2 && this._ctx.lineTo(e3, t2), i2) this._xi = e3, this._yi = t2, this._pendingPtDist = 0;
    else {
      var a2 = n2 * n2 + r2 * r2;
      a2 > this._pendingPtDist && (this._pendingPtX = e3, this._pendingPtY = t2, this._pendingPtDist = a2);
    }
    return this;
  }, e2.prototype.bezierCurveTo = function(e3, t2, n2, r2, i2, a2) {
    return this._drawPendingPt(), this.addData(Z.C, e3, t2, n2, r2, i2, a2), this._ctx && this._ctx.bezierCurveTo(e3, t2, n2, r2, i2, a2), this._xi = i2, this._yi = a2, this;
  }, e2.prototype.quadraticCurveTo = function(e3, t2, n2, r2) {
    return this._drawPendingPt(), this.addData(Z.Q, e3, t2, n2, r2), this._ctx && this._ctx.quadraticCurveTo(e3, t2, n2, r2), this._xi = n2, this._yi = r2, this;
  }, e2.prototype.arc = function(e3, t2, n2, r2, i2, a2) {
    this._drawPendingPt(), hl[0] = r2, hl[1] = i2, _l(hl, a2), r2 = hl[0], i2 = hl[1];
    var o2 = i2 - r2;
    return this.addData(Z.A, e3, t2, n2, n2, r2, o2, 0, +!a2), this._ctx && this._ctx.arc(e3, t2, n2, r2, i2, a2), this._xi = ll(i2) * n2 + e3, this._yi = ul(i2) * n2 + t2, this;
  }, e2.prototype.arcTo = function(e3, t2, n2, r2, i2) {
    return this._drawPendingPt(), this._ctx && this._ctx.arcTo(e3, t2, n2, r2, i2), this;
  }, e2.prototype.rect = function(e3, t2, n2, r2) {
    return this._drawPendingPt(), this._ctx && this._ctx.rect(e3, t2, n2, r2), this.addData(Z.R, e3, t2, n2, r2), this;
  }, e2.prototype.closePath = function() {
    this._drawPendingPt(), this.addData(Z.Z);
    var e3 = this._ctx, t2 = this._x0, n2 = this._y0;
    return e3 && e3.closePath(), this._xi = t2, this._yi = n2, this;
  }, e2.prototype.fill = function(e3) {
    e3 && e3.fill(), this.toStatic();
  }, e2.prototype.stroke = function(e3) {
    e3 && e3.stroke(), this.toStatic();
  }, e2.prototype.len = function() {
    return this._len;
  }, e2.prototype.setData = function(e3) {
    var t2 = e3.length;
    !(this.data && this.data.length === t2) && ml && (this.data = new Float32Array(t2));
    for (var n2 = 0; n2 < t2; n2++) this.data[n2] = e3[n2];
    this._len = t2;
  }, e2.prototype.appendPath = function(e3) {
    e3 instanceof Array || (e3 = [e3]);
    for (var t2 = e3.length, n2 = 0, r2 = this._len, i2 = 0; i2 < t2; i2++) n2 += e3[i2].len();
    ml && this.data instanceof Float32Array && (this.data = new Float32Array(r2 + n2));
    for (var i2 = 0; i2 < t2; i2++) for (var a2 = e3[i2].data, o2 = 0; o2 < a2.length; o2++) this.data[r2++] = a2[o2];
    this._len = r2;
  }, e2.prototype.addData = function(e3, t2, n2, r2, i2, a2, o2, s2, c2) {
    if (this._saveData) {
      var l2 = this.data;
      this._len + arguments.length > l2.length && (this._expandData(), l2 = this.data);
      for (var u2 = 0; u2 < arguments.length; u2++) l2[this._len++] = arguments[u2];
    }
  }, e2.prototype._drawPendingPt = function() {
    this._pendingPtDist > 0 && (this._ctx && this._ctx.lineTo(this._pendingPtX, this._pendingPtY), this._pendingPtDist = 0);
  }, e2.prototype._expandData = function() {
    if (!(this.data instanceof Array)) {
      for (var e3 = [], t2 = 0; t2 < this._len; t2++) e3[t2] = this.data[t2];
      this.data = e3;
    }
  }, e2.prototype.toStatic = function() {
    if (this._saveData) {
      this._drawPendingPt();
      var e3 = this.data;
      e3 instanceof Array && (e3.length = this._len, ml && this._len > 11 && (this.data = new Float32Array(e3)));
    }
  }, e2.prototype.getBoundingRect = function() {
    rl[0] = rl[1] = al[0] = al[1] = Number.MAX_VALUE, il[0] = il[1] = ol[0] = ol[1] = -Number.MAX_VALUE;
    for (var e3 = this.data, t2 = 0, n2 = 0, r2 = 0, i2 = 0, a2 = 0; a2 < this._len; ) {
      var o2 = e3[a2++], s2 = a2 === 1;
      switch (s2 && (t2 = e3[a2], n2 = e3[a2 + 1], r2 = t2, i2 = n2), o2) {
        case Z.M:
          t2 = r2 = e3[a2++], n2 = i2 = e3[a2++], al[0] = r2, al[1] = i2, ol[0] = r2, ol[1] = i2;
          break;
        case Z.L:
          Yc(t2, n2, e3[a2], e3[a2 + 1], al, ol), t2 = e3[a2++], n2 = e3[a2++];
          break;
        case Z.C:
          Qc(t2, n2, e3[a2++], e3[a2++], e3[a2++], e3[a2++], e3[a2], e3[a2 + 1], al, ol), t2 = e3[a2++], n2 = e3[a2++];
          break;
        case Z.Q:
          $c(t2, n2, e3[a2++], e3[a2++], e3[a2], e3[a2 + 1], al, ol), t2 = e3[a2++], n2 = e3[a2++];
          break;
        case Z.A:
          var c2 = e3[a2++], l2 = e3[a2++], u2 = e3[a2++], d2 = e3[a2++], f2 = e3[a2++], p2 = e3[a2++] + f2;
          a2 += 1;
          var m2 = !e3[a2++];
          s2 && (r2 = ll(f2) * u2 + c2, i2 = ul(f2) * d2 + l2), el(c2, l2, u2, d2, f2, p2, m2, al, ol), t2 = ll(p2) * u2 + c2, n2 = ul(p2) * d2 + l2;
          break;
        case Z.R:
          r2 = t2 = e3[a2++], i2 = n2 = e3[a2++];
          var h2 = e3[a2++], g2 = e3[a2++];
          Yc(r2, i2, r2 + h2, i2 + g2, al, ol);
          break;
        case Z.Z:
          t2 = r2, n2 = i2;
      }
      Jt(rl, rl, al), Yt(il, il, ol);
    }
    return a2 === 0 && (rl[0] = rl[1] = il[0] = il[1] = 0), new X(rl[0], rl[1], il[0] - rl[0], il[1] - rl[1]);
  }, e2.prototype._calculateLength = function() {
    var e3 = this.data, t2 = this._len, n2 = this._ux, r2 = this._uy, i2 = 0, a2 = 0, o2 = 0, s2 = 0;
    this._pathSegLen || (this._pathSegLen = []);
    for (var c2 = this._pathSegLen, l2 = 0, u2 = 0, d2 = 0; d2 < t2; ) {
      var f2 = e3[d2++], p2 = d2 === 1;
      p2 && (i2 = e3[d2], a2 = e3[d2 + 1], o2 = i2, s2 = a2);
      var m2 = -1;
      switch (f2) {
        case Z.M:
          i2 = o2 = e3[d2++], a2 = s2 = e3[d2++];
          break;
        case Z.L:
          var h2 = e3[d2++], g2 = e3[d2++], _2 = h2 - i2, v2 = g2 - a2;
          (dl(_2) > n2 || dl(v2) > r2 || d2 === t2 - 1) && (m2 = Math.sqrt(_2 * _2 + v2 * v2), i2 = h2, a2 = g2);
          break;
        case Z.C:
          var y2 = e3[d2++], b2 = e3[d2++], h2 = e3[d2++], g2 = e3[d2++], x2 = e3[d2++], S2 = e3[d2++];
          m2 = Ir(i2, a2, y2, b2, h2, g2, x2, S2, 10), i2 = x2, a2 = S2;
          break;
        case Z.Q:
          var y2 = e3[d2++], b2 = e3[d2++], h2 = e3[d2++], g2 = e3[d2++];
          m2 = Ur(i2, a2, y2, b2, h2, g2, 10), i2 = h2, a2 = g2;
          break;
        case Z.A:
          var C2 = e3[d2++], w2 = e3[d2++], T2 = e3[d2++], E2 = e3[d2++], D2 = e3[d2++], O2 = e3[d2++], k2 = O2 + D2;
          d2 += 1, p2 && (o2 = ll(D2) * T2 + C2, s2 = ul(D2) * E2 + w2), m2 = cl(T2, E2) * sl(pl, Math.abs(O2)), i2 = ll(k2) * T2 + C2, a2 = ul(k2) * E2 + w2;
          break;
        case Z.R:
          o2 = i2 = e3[d2++], s2 = a2 = e3[d2++];
          var A2 = e3[d2++], j2 = e3[d2++];
          m2 = A2 * 2 + j2 * 2;
          break;
        case Z.Z:
          var _2 = o2 - i2, v2 = s2 - a2;
          m2 = Math.sqrt(_2 * _2 + v2 * v2), i2 = o2, a2 = s2;
      }
      m2 >= 0 && (c2[u2++] = m2, l2 += m2);
    }
    return this._pathLen = l2, l2;
  }, e2.prototype.rebuildPath = function(e3, t2) {
    var n2 = this.data, r2 = this._ux, i2 = this._uy, a2 = this._len, o2, s2, c2, l2, u2, d2, f2 = t2 < 1, p2, m2, h2 = 0, g2 = 0, _2, v2 = 0, y2, b2;
    if (!(f2 && (this._pathSegLen || this._calculateLength(), p2 = this._pathSegLen, m2 = this._pathLen, _2 = t2 * m2, !_2))) lo: for (var x2 = 0; x2 < a2; ) {
      var S2 = n2[x2++], C2 = x2 === 1;
      switch (C2 && (c2 = n2[x2], l2 = n2[x2 + 1], o2 = c2, s2 = l2), S2 !== Z.L && v2 > 0 && (e3.lineTo(y2, b2), v2 = 0), S2) {
        case Z.M:
          o2 = c2 = n2[x2++], s2 = l2 = n2[x2++], e3.moveTo(c2, l2);
          break;
        case Z.L:
          u2 = n2[x2++], d2 = n2[x2++];
          var w2 = dl(u2 - c2), T2 = dl(d2 - l2);
          if (w2 > r2 || T2 > i2) {
            if (f2) {
              var E2 = p2[g2++];
              if (h2 + E2 > _2) {
                var D2 = (_2 - h2) / E2;
                e3.lineTo(c2 * (1 - D2) + u2 * D2, l2 * (1 - D2) + d2 * D2);
                break lo;
              }
              h2 += E2;
            }
            e3.lineTo(u2, d2), c2 = u2, l2 = d2, v2 = 0;
          } else {
            var O2 = w2 * w2 + T2 * T2;
            O2 > v2 && (y2 = u2, b2 = d2, v2 = O2);
          }
          break;
        case Z.C:
          var k2 = n2[x2++], A2 = n2[x2++], j2 = n2[x2++], ee2 = n2[x2++], M2 = n2[x2++], N2 = n2[x2++];
          if (f2) {
            var E2 = p2[g2++];
            if (h2 + E2 > _2) {
              var D2 = (_2 - h2) / E2;
              Pr(c2, k2, j2, M2, D2, tl), Pr(l2, A2, ee2, N2, D2, nl), e3.bezierCurveTo(tl[1], nl[1], tl[2], nl[2], tl[3], nl[3]);
              break lo;
            }
            h2 += E2;
          }
          e3.bezierCurveTo(k2, A2, j2, ee2, M2, N2), c2 = M2, l2 = N2;
          break;
        case Z.Q:
          var k2 = n2[x2++], A2 = n2[x2++], j2 = n2[x2++], ee2 = n2[x2++];
          if (f2) {
            var E2 = p2[g2++];
            if (h2 + E2 > _2) {
              var D2 = (_2 - h2) / E2;
              Vr(c2, k2, j2, D2, tl), Vr(l2, A2, ee2, D2, nl), e3.quadraticCurveTo(tl[1], nl[1], tl[2], nl[2]);
              break lo;
            }
            h2 += E2;
          }
          e3.quadraticCurveTo(k2, A2, j2, ee2), c2 = j2, l2 = ee2;
          break;
        case Z.A:
          var te2 = n2[x2++], ne2 = n2[x2++], re2 = n2[x2++], ie2 = n2[x2++], ae2 = n2[x2++], oe2 = n2[x2++], se2 = n2[x2++], ce2 = !n2[x2++], le2 = re2 > ie2 ? re2 : ie2, ue2 = dl(re2 - ie2) > 1e-3, de2 = ae2 + oe2, P2 = false;
          if (f2) {
            var E2 = p2[g2++];
            h2 + E2 > _2 && (de2 = ae2 + oe2 * (_2 - h2) / E2, P2 = true), h2 += E2;
          }
          if (ue2 && e3.ellipse ? e3.ellipse(te2, ne2, re2, ie2, se2, ae2, de2, ce2) : e3.arc(te2, ne2, le2, ae2, de2, ce2), P2) break lo;
          C2 && (o2 = ll(ae2) * re2 + te2, s2 = ul(ae2) * ie2 + ne2), c2 = ll(de2) * re2 + te2, l2 = ul(de2) * ie2 + ne2;
          break;
        case Z.R:
          o2 = c2 = n2[x2], s2 = l2 = n2[x2 + 1], u2 = n2[x2++], d2 = n2[x2++];
          var F2 = n2[x2++], fe2 = n2[x2++];
          if (f2) {
            var E2 = p2[g2++];
            if (h2 + E2 > _2) {
              var I2 = _2 - h2;
              e3.moveTo(u2, d2), e3.lineTo(u2 + sl(I2, F2), d2), I2 -= F2, I2 > 0 && e3.lineTo(u2 + F2, d2 + sl(I2, fe2)), I2 -= fe2, I2 > 0 && e3.lineTo(u2 + cl(F2 - I2, 0), d2 + fe2), I2 -= F2, I2 > 0 && e3.lineTo(u2, d2 + cl(fe2 - I2, 0));
              break lo;
            }
            h2 += E2;
          }
          e3.rect(u2, d2, F2, fe2);
          break;
        case Z.Z:
          if (f2) {
            var E2 = p2[g2++];
            if (h2 + E2 > _2) {
              var D2 = (_2 - h2) / E2;
              e3.lineTo(c2 * (1 - D2) + o2 * D2, l2 * (1 - D2) + s2 * D2);
              break lo;
            }
            h2 += E2;
          }
          e3.closePath(), c2 = o2, l2 = s2;
      }
    }
  }, e2.prototype.clone = function() {
    var t2 = new e2(), n2 = this.data;
    return t2.data = n2.slice ? n2.slice() : Array.prototype.slice.call(n2), t2._len = this._len, t2;
  }, e2.CMD = Z, e2.initDefaultProps = (function() {
    var t2 = e2.prototype;
    t2._saveData = true, t2._ux = 0, t2._uy = 0, t2._pendingPtDist = 0, t2._version = 0;
  })(), e2;
})();
function yl(e2, t2, n2, r2, i2, a2, o2) {
  if (i2 === 0) return false;
  var s2 = i2, c2 = 0, l2 = e2;
  if (o2 > t2 + s2 && o2 > r2 + s2 || o2 < t2 - s2 && o2 < r2 - s2 || a2 > e2 + s2 && a2 > n2 + s2 || a2 < e2 - s2 && a2 < n2 - s2) return false;
  if (e2 !== n2) c2 = (t2 - r2) / (e2 - n2), l2 = (e2 * r2 - n2 * t2) / (e2 - n2);
  else return Math.abs(a2 - e2) <= s2 / 2;
  var u2 = c2 * a2 - o2 + l2;
  return u2 * u2 / (c2 * c2 + 1) <= s2 / 2 * s2 / 2;
}
function bl(e2, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2) {
  if (c2 === 0) return false;
  var d2 = c2;
  return u2 > t2 + d2 && u2 > r2 + d2 && u2 > a2 + d2 && u2 > s2 + d2 || u2 < t2 - d2 && u2 < r2 - d2 && u2 < a2 - d2 && u2 < s2 - d2 || l2 > e2 + d2 && l2 > n2 + d2 && l2 > i2 + d2 && l2 > o2 + d2 || l2 < e2 - d2 && l2 < n2 - d2 && l2 < i2 - d2 && l2 < o2 - d2 ? false : Fr(e2, t2, n2, r2, i2, a2, o2, s2, l2, u2, null) <= d2 / 2;
}
function xl(e2, t2, n2, r2, i2, a2, o2, s2, c2) {
  if (o2 === 0) return false;
  var l2 = o2;
  return c2 > t2 + l2 && c2 > r2 + l2 && c2 > a2 + l2 || c2 < t2 - l2 && c2 < r2 - l2 && c2 < a2 - l2 || s2 > e2 + l2 && s2 > n2 + l2 && s2 > i2 + l2 || s2 < e2 - l2 && s2 < n2 - l2 && s2 < i2 - l2 ? false : Hr(e2, t2, n2, r2, i2, a2, s2, c2, null) <= l2 / 2;
}
var Sl = Math.PI * 2;
function Cl(e2) {
  return e2 %= Sl, e2 < 0 && (e2 += Sl), e2;
}
var wl = Math.PI * 2;
function Tl(e2, t2, n2, r2, i2, a2, o2, s2, c2) {
  if (o2 === 0) return false;
  var l2 = o2;
  s2 -= e2, c2 -= t2;
  var u2 = Math.sqrt(s2 * s2 + c2 * c2);
  if (u2 - l2 > n2 || u2 + l2 < n2) return false;
  if (Math.abs(r2 - i2) % wl < 1e-4) return true;
  if (a2) {
    var d2 = r2;
    r2 = Cl(i2), i2 = Cl(d2);
  } else r2 = Cl(r2), i2 = Cl(i2);
  r2 > i2 && (i2 += wl);
  var f2 = Math.atan2(c2, s2);
  return f2 < 0 && (f2 += wl), f2 >= r2 && f2 <= i2 || f2 + wl >= r2 && f2 + wl <= i2;
}
function El(e2, t2, n2, r2, i2, a2) {
  if (a2 > t2 && a2 > r2 || a2 < t2 && a2 < r2 || r2 === t2) return 0;
  var o2 = (a2 - t2) / (r2 - t2), s2 = r2 < t2 ? 1 : -1;
  (o2 === 1 || o2 === 0) && (s2 = r2 < t2 ? 0.5 : -0.5);
  var c2 = o2 * (n2 - e2) + e2;
  return c2 === i2 ? 1 / 0 : c2 > i2 ? s2 : 0;
}
var Dl = vl.CMD, Ol = Math.PI * 2, kl = 1e-4;
function Al(e2, t2) {
  return Math.abs(e2 - t2) < kl;
}
var jl = [-1, -1, -1], Ml = [-1, -1];
function Nl() {
  var e2 = Ml[0];
  Ml[0] = Ml[1], Ml[1] = e2;
}
function Pl(e2, t2, n2, r2, i2, a2, o2, s2, c2, l2) {
  if (l2 > t2 && l2 > r2 && l2 > a2 && l2 > s2 || l2 < t2 && l2 < r2 && l2 < a2 && l2 < s2) return 0;
  var u2 = Mr(t2, r2, a2, s2, l2, jl);
  if (u2 === 0) return 0;
  for (var d2 = 0, f2 = -1, p2 = void 0, m2 = void 0, h2 = 0; h2 < u2; h2++) {
    var g2 = jl[h2], _2 = g2 === 0 || g2 === 1 ? 0.5 : 1;
    Ar(e2, n2, i2, o2, g2) < c2 || (f2 < 0 && (f2 = Nr(t2, r2, a2, s2, Ml), Ml[1] < Ml[0] && f2 > 1 && Nl(), p2 = Ar(t2, r2, a2, s2, Ml[0]), f2 > 1 && (m2 = Ar(t2, r2, a2, s2, Ml[1]))), f2 === 2 ? g2 < Ml[0] ? d2 += p2 < t2 ? _2 : -_2 : g2 < Ml[1] ? d2 += m2 < p2 ? _2 : -_2 : d2 += s2 < m2 ? _2 : -_2 : g2 < Ml[0] ? d2 += p2 < t2 ? _2 : -_2 : d2 += s2 < p2 ? _2 : -_2);
  }
  return d2;
}
function Fl(e2, t2, n2, r2, i2, a2, o2, s2) {
  if (s2 > t2 && s2 > r2 && s2 > a2 || s2 < t2 && s2 < r2 && s2 < a2) return 0;
  var c2 = zr(t2, r2, a2, s2, jl);
  if (c2 === 0) return 0;
  var l2 = Br(t2, r2, a2);
  if (l2 >= 0 && l2 <= 1) {
    for (var u2 = 0, d2 = Lr(t2, r2, a2, l2), f2 = 0; f2 < c2; f2++) {
      var p2 = jl[f2] === 0 || jl[f2] === 1 ? 0.5 : 1, m2 = Lr(e2, n2, i2, jl[f2]);
      m2 < o2 || (jl[f2] < l2 ? u2 += d2 < t2 ? p2 : -p2 : u2 += a2 < d2 ? p2 : -p2);
    }
    return u2;
  }
  var p2 = jl[0] === 0 || jl[0] === 1 ? 0.5 : 1, m2 = Lr(e2, n2, i2, jl[0]);
  return m2 < o2 ? 0 : a2 < t2 ? p2 : -p2;
}
function Il(e2, t2, n2, r2, i2, a2, o2, s2) {
  if (s2 -= t2, s2 > n2 || s2 < -n2) return 0;
  var c2 = Math.sqrt(n2 * n2 - s2 * s2);
  jl[0] = -c2, jl[1] = c2;
  var l2 = Math.abs(r2 - i2);
  if (l2 < 1e-4) return 0;
  if (l2 >= Ol - 1e-4) {
    r2 = 0, i2 = Ol;
    var u2 = a2 ? 1 : -1;
    return o2 >= jl[0] + e2 && o2 <= jl[1] + e2 ? u2 : 0;
  }
  if (r2 > i2) {
    var d2 = r2;
    r2 = i2, i2 = d2;
  }
  r2 < 0 && (r2 += Ol, i2 += Ol);
  for (var f2 = 0, p2 = 0; p2 < 2; p2++) {
    var m2 = jl[p2];
    if (m2 + e2 > o2) {
      var h2 = Math.atan2(s2, m2), u2 = a2 ? 1 : -1;
      h2 < 0 && (h2 = Ol + h2), (h2 >= r2 && h2 <= i2 || h2 + Ol >= r2 && h2 + Ol <= i2) && (h2 > Math.PI / 2 && h2 < Math.PI * 1.5 && (u2 = -u2), f2 += u2);
    }
  }
  return f2;
}
function Ll(e2, t2, n2, r2, i2) {
  for (var a2 = e2.data, o2 = e2.len(), s2 = 0, c2 = 0, l2 = 0, u2 = 0, d2 = 0, f2, p2, m2 = 0; m2 < o2; ) {
    var h2 = a2[m2++], g2 = m2 === 1;
    switch (h2 === Dl.M && m2 > 1 && (n2 || (s2 += El(c2, l2, u2, d2, r2, i2))), g2 && (c2 = a2[m2], l2 = a2[m2 + 1], u2 = c2, d2 = l2), h2) {
      case Dl.M:
        u2 = a2[m2++], d2 = a2[m2++], c2 = u2, l2 = d2;
        break;
      case Dl.L:
        if (n2) {
          if (yl(c2, l2, a2[m2], a2[m2 + 1], t2, r2, i2)) return true;
        } else s2 += El(c2, l2, a2[m2], a2[m2 + 1], r2, i2) || 0;
        c2 = a2[m2++], l2 = a2[m2++];
        break;
      case Dl.C:
        if (n2) {
          if (bl(c2, l2, a2[m2++], a2[m2++], a2[m2++], a2[m2++], a2[m2], a2[m2 + 1], t2, r2, i2)) return true;
        } else s2 += Pl(c2, l2, a2[m2++], a2[m2++], a2[m2++], a2[m2++], a2[m2], a2[m2 + 1], r2, i2) || 0;
        c2 = a2[m2++], l2 = a2[m2++];
        break;
      case Dl.Q:
        if (n2) {
          if (xl(c2, l2, a2[m2++], a2[m2++], a2[m2], a2[m2 + 1], t2, r2, i2)) return true;
        } else s2 += Fl(c2, l2, a2[m2++], a2[m2++], a2[m2], a2[m2 + 1], r2, i2) || 0;
        c2 = a2[m2++], l2 = a2[m2++];
        break;
      case Dl.A:
        var _2 = a2[m2++], v2 = a2[m2++], y2 = a2[m2++], b2 = a2[m2++], x2 = a2[m2++], S2 = a2[m2++];
        m2 += 1;
        var C2 = !!(1 - a2[m2++]);
        f2 = Math.cos(x2) * y2 + _2, p2 = Math.sin(x2) * b2 + v2, g2 ? (u2 = f2, d2 = p2) : s2 += El(c2, l2, f2, p2, r2, i2);
        var w2 = (r2 - _2) * b2 / y2 + _2;
        if (n2) {
          if (Tl(_2, v2, b2, x2, x2 + S2, C2, t2, w2, i2)) return true;
        } else s2 += Il(_2, v2, b2, x2, x2 + S2, C2, w2, i2);
        c2 = Math.cos(x2 + S2) * y2 + _2, l2 = Math.sin(x2 + S2) * b2 + v2;
        break;
      case Dl.R:
        u2 = c2 = a2[m2++], d2 = l2 = a2[m2++];
        var T2 = a2[m2++], E2 = a2[m2++];
        if (f2 = u2 + T2, p2 = d2 + E2, n2) {
          if (yl(u2, d2, f2, d2, t2, r2, i2) || yl(f2, d2, f2, p2, t2, r2, i2) || yl(f2, p2, u2, p2, t2, r2, i2) || yl(u2, p2, u2, d2, t2, r2, i2)) return true;
        } else s2 += El(f2, d2, f2, p2, r2, i2), s2 += El(u2, p2, u2, d2, r2, i2);
        break;
      case Dl.Z:
        if (n2) {
          if (yl(c2, l2, u2, d2, t2, r2, i2)) return true;
        } else s2 += El(c2, l2, u2, d2, r2, i2);
        c2 = u2, l2 = d2;
    }
  }
  return !n2 && !Al(l2, d2) && (s2 += El(c2, l2, u2, d2, r2, i2) || 0), s2 !== 0;
}
function Rl(e2, t2, n2) {
  return Ll(e2, 0, false, t2, n2);
}
function zl(e2, t2, n2, r2) {
  return Ll(e2, t2, true, n2, r2);
}
M();
var Bl = ze({ fill: `#000`, stroke: null, strokePercent: 1, fillOpacity: 1, strokeOpacity: 1, lineDashOffset: 0, lineWidth: 1, lineCap: `butt`, miterLimit: 10, strokeNoScale: false, strokeFirst: false }, Nc), Vl = { style: ze({ fill: true, stroke: true, strokePercent: true, fillOpacity: true, strokeOpacity: true, lineDashOffset: true, lineWidth: true, miterLimit: true }, Pc.style) }, Hl = Za.concat([`invisible`, `culling`, `z`, `z2`, `zlevel`, `parent`]), Q = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.update = function() {
    var n2 = this;
    e2.prototype.update.call(this);
    var r2 = this.style;
    if (r2.decal) {
      var i2 = this._decalEl = this._decalEl || new t2();
      i2.buildPath === t2.prototype.buildPath && (i2.buildPath = function(e3) {
        n2.buildPath(e3, n2.shape);
      }), i2.silent = true;
      var a2 = i2.style;
      for (var o2 in r2) a2[o2] !== r2[o2] && (a2[o2] = r2[o2]);
      a2.fill = r2.fill ? r2.decal : null, a2.decal = null, a2.shadowColor = null, r2.strokeFirst && (a2.stroke = null);
      for (var s2 = 0; s2 < Hl.length; ++s2) i2[Hl[s2]] = this[Hl[s2]];
      i2.__dirty |= 1;
    } else this._decalEl && (this._decalEl = null);
  }, t2.prototype.getDecalElement = function() {
    return this._decalEl;
  }, t2.prototype._init = function(t3) {
    var n2 = V(t3);
    this.shape = this.getDefaultShape();
    var r2 = this.getDefaultStyle();
    r2 && this.useStyle(r2);
    for (var i2 = 0; i2 < n2.length; i2++) {
      var a2 = n2[i2], o2 = t3[a2];
      a2 === `style` ? this.style ? R(this.style, o2) : this.useStyle(o2) : a2 === `shape` ? R(this.shape, o2) : e2.prototype.attrKV.call(this, a2, o2);
    }
    this.style || this.useStyle({});
  }, t2.prototype.getDefaultStyle = function() {
    return null;
  }, t2.prototype.getDefaultShape = function() {
    return {};
  }, t2.prototype.canBeInsideText = function() {
    return this.hasFill();
  }, t2.prototype.getInsideTextFill = function() {
    var e3 = this.style.fill;
    if (e3 !== `none`) {
      if (W(e3)) {
        var t3 = Si(e3, 0);
        return t3 > 0.5 ? Ba : t3 > 0.2 ? Ha : Va;
      }
      if (e3) return Va;
    }
    return Ba;
  }, t2.prototype.getInsideTextStroke = function(e3) {
    var t3 = this.style.fill;
    if (W(t3)) {
      var n2 = this.__zr;
      if (!!(n2 && n2.isDarkMode()) == Si(e3, 0) < 0.4) return t3;
    }
  }, t2.prototype.buildPath = function(e3, t3, n2) {
  }, t2.prototype.pathUpdated = function() {
    this.__dirty &= -5;
  }, t2.prototype.getUpdatedPathProxy = function(e3) {
    return !this.path && this.createPathProxy(), this.path.beginPath(), this.buildPath(this.path, this.shape, e3), this.path;
  }, t2.prototype.createPathProxy = function() {
    this.path = new vl(false);
  }, t2.prototype.hasStroke = function() {
    var e3 = this.style, t3 = e3.stroke;
    return !(t3 == null || t3 === `none` || !(e3.lineWidth > 0));
  }, t2.prototype.hasFill = function() {
    var e3 = this.style.fill;
    return e3 != null && e3 !== `none`;
  }, t2.prototype.getBoundingRect = function() {
    var e3 = this._rect, t3 = this.style, n2 = !e3;
    if (n2) {
      var r2 = false;
      this.path || (r2 = true, this.createPathProxy());
      var i2 = this.path;
      (r2 || this.__dirty & 4) && (i2.beginPath(), this.buildPath(i2, this.shape, false), this.pathUpdated()), e3 = i2.getBoundingRect();
    }
    if (this._rect = e3, this.hasStroke() && this.path && this.path.len() > 0) {
      var a2 = this._rectStroke || (this._rectStroke = e3.clone());
      if (this.__dirty || n2) {
        a2.copy(e3);
        var o2 = t3.strokeNoScale ? this.getLineScale() : 1, s2 = t3.lineWidth;
        if (!this.hasFill()) {
          var c2 = this.strokeContainThreshold;
          s2 = Math.max(s2, c2 ?? 4);
        }
        o2 > 1e-10 && (a2.width += s2 / o2, a2.height += s2 / o2, a2.x -= s2 / o2 / 2, a2.y -= s2 / o2 / 2);
      }
      return a2;
    }
    return e3;
  }, t2.prototype.contain = function(e3, t3) {
    var n2 = this.transformCoordToLocal(e3, t3), r2 = this.getBoundingRect(), i2 = this.style;
    if (e3 = n2[0], t3 = n2[1], r2.contain(e3, t3)) {
      var a2 = this.path;
      if (this.hasStroke()) {
        var o2 = i2.lineWidth, s2 = i2.strokeNoScale ? this.getLineScale() : 1;
        if (s2 > 1e-10 && (this.hasFill() || (o2 = Math.max(o2, this.strokeContainThreshold)), zl(a2, o2 / s2, e3, t3))) return true;
      }
      if (this.hasFill()) return Rl(a2, e3, t3);
    }
    return false;
  }, t2.prototype.dirtyShape = function() {
    this.__dirty |= 4, this._rect && (this._rect = null), this._decalEl && this._decalEl.dirtyShape(), this.markRedraw();
  }, t2.prototype.dirty = function() {
    this.dirtyStyle(), this.dirtyShape();
  }, t2.prototype.animateShape = function(e3) {
    return this.animate(`shape`, e3);
  }, t2.prototype.updateDuringAnimation = function(e3) {
    e3 === `style` ? this.dirtyStyle() : e3 === `shape` ? this.dirtyShape() : this.markRedraw();
  }, t2.prototype.attrKV = function(t3, n2) {
    t3 === `shape` ? this.setShape(n2) : e2.prototype.attrKV.call(this, t3, n2);
  }, t2.prototype.setShape = function(e3, t3) {
    var n2 = this.shape;
    return n2 || (n2 = this.shape = {}), typeof e3 == `string` ? n2[e3] = t3 : R(n2, e3), this.dirtyShape(), this;
  }, t2.prototype.shapeChanged = function() {
    return !!(this.__dirty & 4);
  }, t2.prototype.createStyle = function(e3) {
    return yt(Bl, e3);
  }, t2.prototype._innerSaveToNormal = function(t3) {
    e2.prototype._innerSaveToNormal.call(this, t3);
    var n2 = this._normalState;
    t3.shape && !n2.shape && (n2.shape = R({}, this.shape));
  }, t2.prototype._applyStateObj = function(t3, n2, r2, i2, a2, o2) {
    e2.prototype._applyStateObj.call(this, t3, n2, r2, i2, a2, o2);
    var s2 = !(n2 && i2), c2;
    if (n2 && n2.shape ? a2 ? i2 ? c2 = n2.shape : (c2 = R({}, r2.shape), R(c2, n2.shape)) : (c2 = R({}, i2 ? this.shape : r2.shape), R(c2, n2.shape)) : s2 && (c2 = r2.shape), c2) {
      if (a2) {
        this.shape = R({}, this.shape);
        for (var l2 = {}, u2 = V(c2), d2 = 0; d2 < u2.length; d2++) {
          var f2 = u2[d2];
          typeof c2[f2] == `object` ? this.shape[f2] = c2[f2] : l2[f2] = c2[f2];
        }
        this._transitionState(t3, { shape: l2 }, o2);
      } else this.shape = c2, this.dirtyShape();
    }
  }, t2.prototype._mergeStates = function(t3) {
    for (var n2 = e2.prototype._mergeStates.call(this, t3), r2, i2 = 0; i2 < t3.length; i2++) {
      var a2 = t3[i2];
      a2.shape && (r2 || (r2 = {}), this._mergeStyle(r2, a2.shape));
    }
    return r2 && (n2.shape = r2), n2;
  }, t2.prototype.getAnimationStyleProps = function() {
    return Vl;
  }, t2.prototype.isZeroArea = function() {
    return false;
  }, t2.extend = function(e3) {
    var n2 = (function(t3) {
      s(n3, t3);
      function n3(n4) {
        var r3 = t3.call(this, n4) || this;
        return e3.init && e3.init.call(r3, n4), r3;
      }
      return n3.prototype.getDefaultStyle = function() {
        return L(e3.style);
      }, n3.prototype.getDefaultShape = function() {
        return L(e3.shape);
      }, n3;
    })(t2);
    for (var r2 in e3) typeof e3[r2] == `function` && (n2.prototype[r2] = e3[r2]);
    return n2;
  }, t2.initDefaultProps = (function() {
    var e3 = t2.prototype;
    e3.type = `path`, e3.strokeContainThreshold = 5, e3.segmentIgnoreThreshold = 0, e3.subPixelOptimize = false, e3.autoBatch = false, e3.__dirty = 7;
  })(), t2;
})(Lc);
M();
var Ul = ze({ strokeFirst: true, font: me, x: 0, y: 0, textAlign: `left`, textBaseline: `top`, miterLimit: 2 }, Bl), Wl = (function(e2) {
  s(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.hasStroke = function() {
    var e3 = this.style, t3 = e3.stroke;
    return t3 != null && t3 !== `none` && e3.lineWidth > 0;
  }, t2.prototype.hasFill = function() {
    var e3 = this.style.fill;
    return e3 != null && e3 !== `none`;
  }, t2.prototype.createStyle = function(e3) {
    return yt(Ul, e3);
  }, t2.prototype.setBoundingRect = function(e3) {
    this._rect = e3;
  }, t2.prototype.getBoundingRect = function() {
    var e3 = this.style;
    if (!this._rect) {
      var t3 = e3.text;
      t3 == null ? t3 = `` : t3 += ``;
      var n2 = no(t3, e3.font, e3.textAlign, e3.textBaseline);
      if (n2.x += e3.x || 0, n2.y += e3.y || 0, this.hasStroke()) {
        var r2 = e3.lineWidth;
        n2.x -= r2 / 2, n2.y -= r2 / 2, n2.width += r2, n2.height += r2;
      }
      this._rect = n2;
    }
    return this._rect;
  }, t2.initDefaultProps = (function() {
    var e3 = t2.prototype;
    e3.dirtyRectTolerance = 10;
  })(), t2;
})(Lc);
Wl.prototype.type = `tspan`, M();
var Gl = ze({ x: 0, y: 0 }, Nc), Kl = { style: ze({ x: true, y: true, width: true, height: true, sx: true, sy: true, sWidth: true, sHeight: true }, Pc.style) };
function ql(e2) {
  return !!(e2 && typeof e2 != `string` && e2.width && e2.height);
}
var Jl = (function(e2) {
  s(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.createStyle = function(e3) {
    return yt(Gl, e3);
  }, t2.prototype._getSize = function(e3) {
    var t3 = this.style, n2 = t3[e3];
    if (n2 != null) return n2;
    var r2 = ql(t3.image) ? t3.image : this.__image;
    if (!r2) return 0;
    var i2 = e3 === `width` ? `height` : `width`, a2 = t3[i2];
    return a2 == null ? r2[e3] : r2[e3] / r2[i2] * a2;
  }, t2.prototype.getWidth = function() {
    return this._getSize(`width`);
  }, t2.prototype.getHeight = function() {
    return this._getSize(`height`);
  }, t2.prototype.getAnimationStyleProps = function() {
    return Kl;
  }, t2.prototype.getBoundingRect = function() {
    var e3 = this.style;
    return this._rect || (this._rect = new X(e3.x || 0, e3.y || 0, this.getWidth(), this.getHeight())), this._rect;
  }, t2;
})(Lc);
Jl.prototype.type = `image`;
function Yl(e2, t2) {
  var n2 = t2.x, r2 = t2.y, i2 = t2.width, a2 = t2.height, o2 = t2.r, s2, c2, l2, u2;
  i2 < 0 && (n2 += i2, i2 = -i2), a2 < 0 && (r2 += a2, a2 = -a2), typeof o2 == `number` ? s2 = c2 = l2 = u2 = o2 : o2 instanceof Array ? o2.length === 1 ? s2 = c2 = l2 = u2 = o2[0] : o2.length === 2 ? (s2 = l2 = o2[0], c2 = u2 = o2[1]) : o2.length === 3 ? (s2 = o2[0], c2 = u2 = o2[1], l2 = o2[2]) : (s2 = o2[0], c2 = o2[1], l2 = o2[2], u2 = o2[3]) : s2 = c2 = l2 = u2 = 0;
  var d2;
  s2 + c2 > i2 && (d2 = s2 + c2, s2 *= i2 / d2, c2 *= i2 / d2), l2 + u2 > i2 && (d2 = l2 + u2, l2 *= i2 / d2, u2 *= i2 / d2), c2 + l2 > a2 && (d2 = c2 + l2, c2 *= a2 / d2, l2 *= a2 / d2), s2 + u2 > a2 && (d2 = s2 + u2, s2 *= a2 / d2, u2 *= a2 / d2), e2.moveTo(n2 + s2, r2), e2.lineTo(n2 + i2 - c2, r2), c2 !== 0 && e2.arc(n2 + i2 - c2, r2 + c2, c2, -Math.PI / 2, 0), e2.lineTo(n2 + i2, r2 + a2 - l2), l2 !== 0 && e2.arc(n2 + i2 - l2, r2 + a2 - l2, l2, 0, Math.PI / 2), e2.lineTo(n2 + u2, r2 + a2), u2 !== 0 && e2.arc(n2 + u2, r2 + a2 - u2, u2, Math.PI / 2, Math.PI), e2.lineTo(n2, r2 + s2), s2 !== 0 && e2.arc(n2 + s2, r2 + s2, s2, Math.PI, Math.PI * 1.5);
}
var Xl = Math.round;
function Zl(e2, t2, n2) {
  if (t2) {
    var r2 = t2.x1, i2 = t2.x2, a2 = t2.y1, o2 = t2.y2;
    e2.x1 = r2, e2.x2 = i2, e2.y1 = a2, e2.y2 = o2;
    var s2 = n2 && n2.lineWidth;
    return s2 ? (Xl(r2 * 2) === Xl(i2 * 2) && (e2.x1 = e2.x2 = $l(r2, s2, true)), Xl(a2 * 2) === Xl(o2 * 2) && (e2.y1 = e2.y2 = $l(a2, s2, true)), e2) : e2;
  }
}
function Ql(e2, t2, n2) {
  if (t2) {
    var r2 = t2.x, i2 = t2.y, a2 = t2.width, o2 = t2.height;
    e2.x = r2, e2.y = i2, e2.width = a2, e2.height = o2;
    var s2 = n2 && n2.lineWidth;
    return s2 ? (e2.x = $l(r2, s2, true), e2.y = $l(i2, s2, true), e2.width = Math.max($l(r2 + a2, s2, false) - e2.x, a2 === 0 ? 0 : 1), e2.height = Math.max($l(i2 + o2, s2, false) - e2.y, o2 === 0 ? 0 : 1), e2) : e2;
  }
}
function $l(e2, t2, n2) {
  if (!t2) return e2;
  var r2 = Xl(e2 * 2);
  return (r2 + Xl(t2)) % 2 == 0 ? r2 / 2 : (r2 + (n2 ? 1 : -1)) / 2;
}
M();
var eu = /* @__PURE__ */ (function() {
  function e2() {
    this.x = 0, this.y = 0, this.width = 0, this.height = 0;
  }
  return e2;
})(), tu = {}, nu = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultShape = function() {
    return new eu();
  }, t2.prototype.buildPath = function(e3, t3) {
    var n2, r2, i2, a2;
    if (this.subPixelOptimize) {
      var o2 = Ql(tu, t3, this.style);
      n2 = o2.x, r2 = o2.y, i2 = o2.width, a2 = o2.height, o2.r = t3.r, t3 = o2;
    } else n2 = t3.x, r2 = t3.y, i2 = t3.width, a2 = t3.height;
    t3.r ? Yl(e3, t3) : e3.rect(n2, r2, i2, a2);
  }, t2.prototype.isZeroArea = function() {
    return !this.shape.width || !this.shape.height;
  }, t2;
})(Q);
nu.prototype.type = `rect`, M();
var ru = { fill: `#000` }, iu = 2, au = { style: ze({ fill: true, stroke: true, fillOpacity: true, strokeOpacity: true, lineWidth: true, fontSize: true, lineHeight: true, width: true, height: true, textShadowColor: true, textShadowBlur: true, textShadowOffsetX: true, textShadowOffsetY: true, backgroundColor: true, padding: true, borderColor: true, borderWidth: true, borderRadius: true }, Pc.style) }, ou = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    var n2 = e2.call(this) || this;
    return n2.type = `text`, n2._children = [], n2._defaultStyle = ru, n2.attr(t3), n2;
  }
  return t2.prototype.childrenRef = function() {
    return this._children;
  }, t2.prototype.update = function() {
    e2.prototype.update.call(this), this.styleChanged() && this._updateSubTexts();
    for (var t3 = 0; t3 < this._children.length; t3++) {
      var n2 = this._children[t3];
      n2.zlevel = this.zlevel, n2.z = this.z, n2.z2 = this.z2, n2.culling = this.culling, n2.cursor = this.cursor, n2.invisible = this.invisible;
    }
  }, t2.prototype.updateTransform = function() {
    var t3 = this.innerTransformable;
    t3 ? (t3.updateTransform(), t3.transform && (this.transform = t3.transform)) : e2.prototype.updateTransform.call(this);
  }, t2.prototype.getLocalTransform = function(t3) {
    var n2 = this.innerTransformable;
    return n2 ? n2.getLocalTransform(t3) : e2.prototype.getLocalTransform.call(this, t3);
  }, t2.prototype.getComputedTransform = function() {
    return this.__hostTarget && (this.__hostTarget.getComputedTransform(), this.__hostTarget.updateInnerText(true)), e2.prototype.getComputedTransform.call(this);
  }, t2.prototype._updateSubTexts = function() {
    this._childCursor = 0, pu(this.style), this.style.rich ? this._updateRichTexts() : this._updatePlainTexts(), this._children.length = this._childCursor, this.styleUpdated();
  }, t2.prototype.addSelfToZr = function(t3) {
    e2.prototype.addSelfToZr.call(this, t3);
    for (var n2 = 0; n2 < this._children.length; n2++) this._children[n2].__zr = t3;
  }, t2.prototype.removeSelfFromZr = function(t3) {
    e2.prototype.removeSelfFromZr.call(this, t3);
    for (var n2 = 0; n2 < this._children.length; n2++) this._children[n2].__zr = null;
  }, t2.prototype.getBoundingRect = function() {
    if (this.styleChanged() && this._updateSubTexts(), !this._rect) {
      for (var e3 = new X(0, 0, 0, 0), t3 = this._children, n2 = [], r2 = null, i2 = 0; i2 < t3.length; i2++) {
        var a2 = t3[i2], o2 = a2.getBoundingRect(), s2 = a2.getLocalTransform(n2);
        s2 ? (e3.copy(o2), e3.applyTransform(s2), r2 || (r2 = e3.clone()), r2.union(e3)) : (r2 || (r2 = o2.clone()), r2.union(o2));
      }
      this._rect = r2 || e3;
    }
    return this._rect;
  }, t2.prototype.setDefaultTextStyle = function(e3) {
    this._defaultStyle = e3 || ru;
  }, t2.prototype.setTextContent = function(e3) {
  }, t2.prototype._mergeStyle = function(e3, t3) {
    if (!t3) return e3;
    var n2 = t3.rich, r2 = e3.rich || n2 && {};
    return R(e3, t3), n2 && r2 ? (this._mergeRich(r2, n2), e3.rich = r2) : r2 && (e3.rich = r2), e3;
  }, t2.prototype._mergeRich = function(e3, t3) {
    for (var n2 = V(t3), r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2];
      e3[i2] = e3[i2] || {}, R(e3[i2], t3[i2]);
    }
  }, t2.prototype.getAnimationStyleProps = function() {
    return au;
  }, t2.prototype._getOrCreateChild = function(e3) {
    var t3 = this._children[this._childCursor];
    return (!t3 || !(t3 instanceof e3)) && (t3 = new e3()), this._children[this._childCursor++] = t3, t3.__zr = this.__zr, t3.parent = this, t3;
  }, t2.prototype._updatePlainTexts = function() {
    var e3 = this.style, t3 = e3.font || `12px sans-serif`, n2 = e3.padding, r2 = Sc(vu(e3), e3), i2 = yu(e3), a2 = !!e3.backgroundColor, o2 = r2.outerHeight, s2 = r2.outerWidth, c2 = r2.contentWidth, l2 = r2.lines, u2 = r2.lineHeight, d2 = this._defaultStyle;
    this.isTruncated = !!r2.isTruncated;
    var f2 = e3.x || 0, p2 = e3.y || 0, m2 = e3.align || d2.align || `left`, h2 = e3.verticalAlign || d2.verticalAlign || `top`, g2 = f2, _2 = io(p2, r2.contentHeight, h2);
    if (i2 || n2) {
      var v2 = ro(f2, s2, m2), y2 = io(p2, o2, h2);
      i2 && this._renderBackground(e3, e3, v2, y2, s2, o2);
    }
    _2 += u2 / 2, n2 && (g2 = _u(f2, m2, n2), h2 === `top` ? _2 += n2[0] : h2 === `bottom` && (_2 -= n2[2]));
    for (var b2 = 0, x2 = false, S2 = gu(`fill` in e3 ? e3.fill : (x2 = true, d2.fill)), C2 = hu(`stroke` in e3 ? e3.stroke : !a2 && (!d2.autoStroke || x2) ? (b2 = iu, d2.stroke) : null), w2 = e3.textShadowBlur > 0, T2 = e3.width != null && (e3.overflow === `truncate` || e3.overflow === `break` || e3.overflow === `breakAll`), E2 = r2.calculatedLineHeight, D2 = 0; D2 < l2.length; D2++) {
      var O2 = this._getOrCreateChild(Wl), k2 = O2.createStyle();
      O2.useStyle(k2), k2.text = l2[D2], k2.x = g2, k2.y = _2, m2 && (k2.textAlign = m2), k2.textBaseline = `middle`, k2.opacity = e3.opacity, k2.strokeFirst = true, w2 && (k2.shadowBlur = e3.textShadowBlur || 0, k2.shadowColor = e3.textShadowColor || `transparent`, k2.shadowOffsetX = e3.textShadowOffsetX || 0, k2.shadowOffsetY = e3.textShadowOffsetY || 0), k2.stroke = C2, k2.fill = S2, C2 && (k2.lineWidth = e3.lineWidth || b2, k2.lineDash = e3.lineDash, k2.lineDashOffset = e3.lineDashOffset || 0), k2.font = t3, du(k2, e3), _2 += u2, T2 && O2.setBoundingRect(new X(ro(k2.x, c2, k2.textAlign), io(k2.y, E2, k2.textBaseline), c2, E2));
    }
  }, t2.prototype._updateRichTexts = function() {
    var e3 = this.style, t3 = Ec(vu(e3), e3), n2 = t3.width, r2 = t3.outerWidth, i2 = t3.outerHeight, a2 = e3.padding, o2 = e3.x || 0, s2 = e3.y || 0, c2 = this._defaultStyle, l2 = e3.align || c2.align, u2 = e3.verticalAlign || c2.verticalAlign;
    this.isTruncated = !!t3.isTruncated;
    var d2 = ro(o2, r2, l2), f2 = io(s2, i2, u2), p2 = d2, m2 = f2;
    a2 && (p2 += a2[3], m2 += a2[0]);
    var h2 = p2 + n2;
    yu(e3) && this._renderBackground(e3, e3, d2, f2, r2, i2);
    for (var g2 = !!e3.backgroundColor, _2 = 0; _2 < t3.lines.length; _2++) {
      for (var v2 = t3.lines[_2], y2 = v2.tokens, b2 = y2.length, x2 = v2.lineHeight, S2 = v2.width, C2 = 0, w2 = p2, T2 = h2, E2 = b2 - 1, D2 = void 0; C2 < b2 && (D2 = y2[C2], !D2.align || D2.align === `left`); ) this._placeToken(D2, e3, x2, m2, w2, `left`, g2), S2 -= D2.width, w2 += D2.width, C2++;
      for (; E2 >= 0 && (D2 = y2[E2], D2.align === `right`); ) this._placeToken(D2, e3, x2, m2, T2, `right`, g2), S2 -= D2.width, T2 -= D2.width, E2--;
      for (w2 += (n2 - (w2 - p2) - (h2 - T2) - S2) / 2; C2 <= E2; ) D2 = y2[C2], this._placeToken(D2, e3, x2, m2, w2 + D2.width / 2, `center`, g2), w2 += D2.width, C2++;
      m2 += x2;
    }
  }, t2.prototype._placeToken = function(e3, t3, n2, r2, i2, a2, o2) {
    var s2 = t3.rich[e3.styleName] || {};
    s2.text = e3.text;
    var c2 = e3.verticalAlign, l2 = r2 + n2 / 2;
    c2 === `top` ? l2 = r2 + e3.height / 2 : c2 === `bottom` && (l2 = r2 + n2 - e3.height / 2), !e3.isLineHolder && yu(s2) && this._renderBackground(s2, t3, a2 === `right` ? i2 - e3.width : a2 === `center` ? i2 - e3.width / 2 : i2, l2 - e3.height / 2, e3.width, e3.height);
    var u2 = !!s2.backgroundColor, d2 = e3.textPadding;
    d2 && (i2 = _u(i2, a2, d2), l2 -= e3.height / 2 - d2[0] - e3.innerHeight / 2);
    var f2 = this._getOrCreateChild(Wl), p2 = f2.createStyle();
    f2.useStyle(p2);
    var m2 = this._defaultStyle, h2 = false, g2 = 0, _2 = gu(`fill` in s2 ? s2.fill : `fill` in t3 ? t3.fill : (h2 = true, m2.fill)), v2 = hu(`stroke` in s2 ? s2.stroke : `stroke` in t3 ? t3.stroke : !u2 && !o2 && (!m2.autoStroke || h2) ? (g2 = iu, m2.stroke) : null), y2 = s2.textShadowBlur > 0 || t3.textShadowBlur > 0;
    p2.text = e3.text, p2.x = i2, p2.y = l2, y2 && (p2.shadowBlur = s2.textShadowBlur || t3.textShadowBlur || 0, p2.shadowColor = s2.textShadowColor || t3.textShadowColor || `transparent`, p2.shadowOffsetX = s2.textShadowOffsetX || t3.textShadowOffsetX || 0, p2.shadowOffsetY = s2.textShadowOffsetY || t3.textShadowOffsetY || 0), p2.textAlign = a2, p2.textBaseline = `middle`, p2.font = e3.font || `12px sans-serif`, p2.opacity = ot(s2.opacity, t3.opacity, 1), du(p2, s2), v2 && (p2.lineWidth = ot(s2.lineWidth, t3.lineWidth, g2), p2.lineDash = q(s2.lineDash, t3.lineDash), p2.lineDashOffset = t3.lineDashOffset || 0, p2.stroke = v2), _2 && (p2.fill = _2);
    var b2 = e3.contentWidth, x2 = e3.contentHeight;
    f2.setBoundingRect(new X(ro(p2.x, b2, p2.textAlign), io(p2.y, x2, p2.textBaseline), b2, x2));
  }, t2.prototype._renderBackground = function(e3, t3, n2, r2, i2, a2) {
    var o2 = e3.backgroundColor, s2 = e3.borderWidth, c2 = e3.borderColor, l2 = o2 && o2.image, u2 = o2 && !l2, d2 = e3.borderRadius, f2 = this, p2, m2;
    if (u2 || e3.lineHeight || s2 && c2) {
      p2 = this._getOrCreateChild(nu), p2.useStyle(p2.createStyle()), p2.style.fill = null;
      var h2 = p2.shape;
      h2.x = n2, h2.y = r2, h2.width = i2, h2.height = a2, h2.r = d2, p2.dirtyShape();
    }
    if (u2) {
      var g2 = p2.style;
      g2.fill = o2 || null, g2.fillOpacity = q(e3.fillOpacity, 1);
    } else if (l2) {
      m2 = this._getOrCreateChild(Jl), m2.onload = function() {
        f2.dirtyStyle();
      };
      var _2 = m2.style;
      _2.image = o2.image, _2.x = n2, _2.y = r2, _2.width = i2, _2.height = a2;
    }
    if (s2 && c2) {
      var g2 = p2.style;
      g2.lineWidth = s2, g2.stroke = c2, g2.strokeOpacity = q(e3.strokeOpacity, 1), g2.lineDash = e3.borderDash, g2.lineDashOffset = e3.borderDashOffset || 0, p2.strokeContainThreshold = 0, p2.hasFill() && p2.hasStroke() && (g2.strokeFirst = true, g2.lineWidth *= 2);
    }
    var v2 = (p2 || m2).style;
    v2.shadowBlur = e3.shadowBlur || 0, v2.shadowColor = e3.shadowColor || `transparent`, v2.shadowOffsetX = e3.shadowOffsetX || 0, v2.shadowOffsetY = e3.shadowOffsetY || 0, v2.opacity = ot(e3.opacity, t3.opacity, 1);
  }, t2.makeFont = function(e3) {
    var t3 = ``;
    return fu(e3) && (t3 = [e3.fontStyle, e3.fontWeight, uu(e3.fontSize), e3.fontFamily || `sans-serif`].join(` `)), t3 && ut(t3) || e3.textFont || e3.font;
  }, t2;
})(Lc), su = { left: true, right: 1, center: 1 }, cu = { top: 1, bottom: 1, middle: 1 }, lu = [`fontStyle`, `fontWeight`, `fontSize`, `fontFamily`];
function uu(e2) {
  return typeof e2 == `string` && (e2.indexOf(`px`) !== -1 || e2.indexOf(`rem`) !== -1 || e2.indexOf(`em`) !== -1) ? e2 : isNaN(+e2) ? `12px` : e2 + `px`;
}
function du(e2, t2) {
  for (var n2 = 0; n2 < lu.length; n2++) {
    var r2 = lu[n2], i2 = t2[r2];
    i2 != null && (e2[r2] = i2);
  }
}
function fu(e2) {
  return e2.fontSize != null || e2.fontFamily || e2.fontWeight;
}
function pu(e2) {
  return mu(e2), z(e2.rich, mu), e2;
}
function mu(e2) {
  if (e2) {
    e2.font = ou.makeFont(e2);
    var t2 = e2.align;
    t2 === `middle` && (t2 = `center`), e2.align = t2 == null || su[t2] ? t2 : `left`;
    var n2 = e2.verticalAlign;
    n2 === `center` && (n2 = `middle`), e2.verticalAlign = n2 == null || cu[n2] ? n2 : `top`, e2.padding && (e2.padding = ct(e2.padding));
  }
}
function hu(e2, t2) {
  return e2 == null || t2 <= 0 || e2 === `transparent` || e2 === `none` ? null : e2.image || e2.colorStops ? `#000` : e2;
}
function gu(e2) {
  return e2 == null || e2 === `none` ? null : e2.image || e2.colorStops ? `#000` : e2;
}
function _u(e2, t2, n2) {
  return t2 === `right` ? e2 - n2[1] : t2 === `center` ? e2 + n2[3] / 2 - n2[1] / 2 : e2 + n2[3];
}
function vu(e2) {
  var t2 = e2.text;
  return t2 != null && (t2 += ``), t2;
}
function yu(e2) {
  return !!(e2.backgroundColor || e2.lineHeight || e2.borderWidth && e2.borderColor);
}
var bu = Ls(), xu = function(e2, t2, n2, r2) {
  if (r2) {
    var i2 = bu(r2);
    i2.dataIndex = n2, i2.dataType = t2, i2.seriesIndex = e2, i2.ssrType = `chart`, r2.type === `group` && r2.traverse(function(r3) {
      var i3 = bu(r3);
      i3.seriesIndex = e2, i3.dataIndex = n2, i3.dataType = t2, i3.ssrType = `chart`;
    });
  }
}, Su = 1, Cu = {}, wu = Ls(), Tu = Ls(), Eu = [`emphasis`, `blur`, `select`], Du = [`normal`, `emphasis`, `blur`, `select`], Ou = `highlight`, ku = `downplay`, Au = `select`, ju = `unselect`, Mu = `toggleSelect`;
function Nu(e2) {
  return e2 != null && e2 !== `none`;
}
function Pu(e2, t2, n2) {
  e2.onHoverStateChange && (e2.hoverState || 0) !== n2 && e2.onHoverStateChange(t2), e2.hoverState = n2;
}
function Fu(e2) {
  Pu(e2, `emphasis`, 2);
}
function Iu(e2) {
  e2.hoverState === 2 && Pu(e2, `normal`, 0);
}
function Lu(e2) {
  Pu(e2, `blur`, 1);
}
function Ru(e2) {
  e2.hoverState === 1 && Pu(e2, `normal`, 0);
}
function zu(e2) {
  e2.selected = true;
}
function Bu(e2) {
  e2.selected = false;
}
function Vu(e2, t2, n2) {
  t2(e2, n2);
}
function Hu(e2, t2, n2) {
  Vu(e2, t2, n2), e2.isGroup && e2.traverse(function(e3) {
    Vu(e3, t2, n2);
  });
}
function Uu(e2, t2) {
  switch (t2) {
    case `emphasis`:
      e2.hoverState = 2;
      break;
    case `normal`:
      e2.hoverState = 0;
      break;
    case `blur`:
      e2.hoverState = 1;
      break;
    case `select`:
      e2.selected = true;
  }
}
function Wu(e2, t2, n2, r2) {
  for (var i2 = e2.style, a2 = {}, o2 = 0; o2 < t2.length; o2++) {
    var s2 = t2[o2];
    a2[s2] = i2[s2] ?? (r2 && r2[s2]);
  }
  for (var o2 = 0; o2 < e2.animators.length; o2++) {
    var c2 = e2.animators[o2];
    c2.__fromStateTransition && c2.__fromStateTransition.indexOf(n2) < 0 && c2.targetName === `style` && c2.saveTo(a2, t2);
  }
  return a2;
}
function Gu(e2, t2, n2, r2) {
  var i2 = n2 && Ve(n2, `select`) >= 0, a2 = false;
  if (e2 instanceof Q) {
    var o2 = wu(e2), s2 = i2 && o2.selectFill || o2.normalFill, c2 = i2 && o2.selectStroke || o2.normalStroke;
    if (Nu(s2) || Nu(c2)) {
      r2 || (r2 = {});
      var l2 = r2.style || {};
      l2.fill === `inherit` ? (a2 = true, r2 = R({}, r2), l2 = R({}, l2), l2.fill = s2) : !Nu(l2.fill) && Nu(s2) ? (a2 = true, r2 = R({}, r2), l2 = R({}, l2), l2.fill = Ti(s2)) : !Nu(l2.stroke) && Nu(c2) && (a2 || (r2 = R({}, r2), l2 = R({}, l2)), l2.stroke = Ti(c2)), r2.style = l2;
    }
  }
  if (r2 && r2.z2 == null) {
    a2 || (r2 = R({}, r2));
    var u2 = e2.z2EmphasisLift;
    r2.z2 = e2.z2 + (u2 ?? 10);
  }
  return r2;
}
function Ku(e2, t2, n2) {
  if (n2 && n2.z2 == null) {
    n2 = R({}, n2);
    var r2 = e2.z2SelectLift;
    n2.z2 = e2.z2 + (r2 ?? 9);
  }
  return n2;
}
function qu(e2, t2, n2) {
  var r2 = Ve(e2.currentStates, t2) >= 0, i2 = e2.style.opacity, a2 = r2 ? null : Wu(e2, [`opacity`], t2, { opacity: 1 });
  n2 || (n2 = {});
  var o2 = n2.style || {};
  return o2.opacity ?? (n2 = R({}, n2), o2 = R({ opacity: r2 ? i2 : a2.opacity * 0.1 }, o2), n2.style = o2), n2;
}
function Ju(e2, t2) {
  var n2 = this.states[e2];
  if (this.style) {
    if (e2 === `emphasis`) return Gu(this, e2, t2, n2);
    if (e2 === `blur`) return qu(this, e2, n2);
    if (e2 === `select`) return Ku(this, e2, n2);
  }
  return n2;
}
function Yu(e2) {
  e2.stateProxy = Ju;
  var t2 = e2.getTextContent(), n2 = e2.getTextGuideLine();
  t2 && (t2.stateProxy = Ju), n2 && (n2.stateProxy = Ju);
}
function Xu(e2, t2) {
  !id(e2, t2) && !e2.__highByOuter && Hu(e2, Fu);
}
function Zu(e2, t2) {
  !id(e2, t2) && !e2.__highByOuter && Hu(e2, Iu);
}
function Qu(e2, t2) {
  e2.__highByOuter |= 1 << (t2 || 0), Hu(e2, Fu);
}
function $u(e2, t2) {
  !(e2.__highByOuter &= ~(1 << (t2 || 0))) && Hu(e2, Iu);
}
function ed(e2) {
  Hu(e2, Lu);
}
function td(e2) {
  Hu(e2, Ru);
}
function nd(e2) {
  Hu(e2, zu);
}
function rd(e2) {
  Hu(e2, Bu);
}
function id(e2, t2) {
  return e2.__highDownSilentOnTouch && t2.zrByTouch;
}
function ad(e2) {
  var t2 = e2.getModel(), n2 = [], r2 = [];
  t2.eachComponent(function(t3, i2) {
    var a2 = Tu(i2), o2 = t3 === `series`, s2 = o2 ? e2.getViewOfSeriesModel(i2) : e2.getViewOfComponentModel(i2);
    !o2 && r2.push(s2), a2.isBlured && (s2.group.traverse(function(e3) {
      Ru(e3);
    }), o2 && n2.push(i2)), a2.isBlured = false;
  }), z(r2, function(e3) {
    e3 && e3.toggleBlurSeries && e3.toggleBlurSeries(n2, false, t2);
  });
}
function od(e2, t2, n2, r2) {
  var i2 = r2.getModel();
  n2 || (n2 = `coordinateSystem`);
  function a2(e3, t3) {
    for (var n3 = 0; n3 < t3.length; n3++) {
      var r3 = e3.getItemGraphicEl(t3[n3]);
      r3 && td(r3);
    }
  }
  if (e2 != null && t2 && t2 !== `none`) {
    var o2 = i2.getSeriesByIndex(e2), s2 = o2.coordinateSystem;
    s2 && s2.master && (s2 = s2.master);
    var c2 = [];
    i2.eachSeries(function(e3) {
      var i3 = o2 === e3, l2 = e3.coordinateSystem;
      if (l2 && l2.master && (l2 = l2.master), !(n2 === `series` && !i3 || n2 === `coordinateSystem` && !(l2 && s2 ? l2 === s2 : i3) || t2 === `series` && i3)) {
        if (r2.getViewOfSeriesModel(e3).group.traverse(function(e4) {
          e4.__highByOuter && i3 && t2 === `self` || Lu(e4);
        }), We(t2)) a2(e3.getData(), t2);
        else if (K(t2)) for (var u2 = V(t2), d2 = 0; d2 < u2.length; d2++) a2(e3.getData(u2[d2]), t2[u2[d2]]);
        c2.push(e3), Tu(e3).isBlured = true;
      }
    }), i2.eachComponent(function(e3, t3) {
      if (e3 !== `series`) {
        var n3 = r2.getViewOfComponentModel(t3);
        n3 && n3.toggleBlurSeries && n3.toggleBlurSeries(c2, true, i2);
      }
    });
  }
}
function sd(e2, t2, n2) {
  if (e2 != null && t2 != null) {
    var r2 = n2.getModel().getComponent(e2, t2);
    if (r2) {
      Tu(r2).isBlured = true;
      var i2 = n2.getViewOfComponentModel(r2);
      i2 && i2.focusBlurEnabled && i2.group.traverse(function(e3) {
        Lu(e3);
      });
    }
  }
}
function cd(e2, t2, n2) {
  var r2 = e2.seriesIndex, i2 = e2.getData(t2.dataType);
  if (i2) {
    var a2 = Is(i2, t2);
    a2 = (H(a2) ? a2[0] : a2) || 0;
    var o2 = i2.getItemGraphicEl(a2);
    if (!o2) for (var s2 = i2.count(), c2 = 0; !o2 && c2 < s2; ) o2 = i2.getItemGraphicEl(c2++);
    if (o2) {
      var l2 = bu(o2);
      od(r2, l2.focus, l2.blurScope, n2);
    } else {
      var u2 = e2.get([`emphasis`, `focus`]), d2 = e2.get([`emphasis`, `blurScope`]);
      u2 != null && od(r2, u2, d2, n2);
    }
  }
}
function ld(e2, t2, n2, r2) {
  var i2 = { focusSelf: false, dispatchers: null };
  if (e2 == null || e2 === `series` || t2 == null || n2 == null) return i2;
  var a2 = r2.getModel().getComponent(e2, t2);
  if (!a2) return i2;
  var o2 = r2.getViewOfComponentModel(a2);
  if (!o2 || !o2.findHighDownDispatchers) return i2;
  for (var s2 = o2.findHighDownDispatchers(n2), c2, l2 = 0; l2 < s2.length; l2++) if (bu(s2[l2]).focus === `self`) {
    c2 = true;
    break;
  }
  return { focusSelf: c2, dispatchers: s2 };
}
function ud(e2, t2, n2) {
  var r2 = bu(e2), i2 = ld(r2.componentMainType, r2.componentIndex, r2.componentHighDownName, n2), a2 = i2.dispatchers, o2 = i2.focusSelf;
  a2 ? (o2 && sd(r2.componentMainType, r2.componentIndex, n2), z(a2, function(e3) {
    return Xu(e3, t2);
  })) : (od(r2.seriesIndex, r2.focus, r2.blurScope, n2), r2.focus === `self` && sd(r2.componentMainType, r2.componentIndex, n2), Xu(e2, t2));
}
function dd(e2, t2, n2) {
  ad(n2);
  var r2 = bu(e2), i2 = ld(r2.componentMainType, r2.componentIndex, r2.componentHighDownName, n2).dispatchers;
  i2 ? z(i2, function(e3) {
    return Zu(e3, t2);
  }) : Zu(e2, t2);
}
function fd(e2, t2, n2) {
  if (Td(t2)) {
    var r2 = t2.dataType, i2 = Is(e2.getData(r2), t2);
    H(i2) || (i2 = [i2]), e2[t2.type === `toggleSelect` ? `toggleSelect` : t2.type === `select` ? `select` : `unselect`](i2, r2);
  }
}
function pd(e2) {
  z(e2.getAllData(), function(t2) {
    var n2 = t2.data, r2 = t2.type;
    n2.eachItemGraphicEl(function(t3, n3) {
      e2.isSelected(n3, r2) ? nd(t3) : rd(t3);
    });
  });
}
function md(e2) {
  var t2 = [];
  return e2.eachSeries(function(e3) {
    z(e3.getAllData(), function(n2) {
      n2.data;
      var r2 = n2.type, i2 = e3.getSelectedDataIndices();
      if (i2.length > 0) {
        var a2 = { dataIndex: i2, seriesIndex: e3.seriesIndex };
        r2 != null && (a2.dataType = r2), t2.push(a2);
      }
    });
  }), t2;
}
function hd(e2, t2, n2) {
  Sd(e2, true), Hu(e2, Yu), vd(e2, t2, n2);
}
function gd(e2) {
  Sd(e2, false);
}
function _d(e2, t2, n2, r2) {
  r2 ? gd(e2) : hd(e2, t2, n2);
}
function vd(e2, t2, n2) {
  var r2 = bu(e2);
  t2 == null ? r2.focus && (r2.focus = null) : (r2.focus = t2, r2.blurScope = n2);
}
var yd = [`emphasis`, `blur`, `select`], bd = { itemStyle: `getItemStyle`, lineStyle: `getLineStyle`, areaStyle: `getAreaStyle` };
function xd(e2, t2, n2, r2) {
  n2 || (n2 = `itemStyle`);
  for (var i2 = 0; i2 < yd.length; i2++) {
    var a2 = yd[i2], o2 = t2.getModel([a2, n2]), s2 = e2.ensureState(a2);
    s2.style = r2 ? r2(o2) : o2[bd[n2]]();
  }
}
function Sd(e2, t2) {
  var n2 = t2 === false, r2 = e2;
  e2.highDownSilentOnTouch && (r2.__highDownSilentOnTouch = e2.highDownSilentOnTouch), (!n2 || r2.__highDownDispatcher) && (r2.__highByOuter = r2.__highByOuter || 0, r2.__highDownDispatcher = !n2);
}
function Cd(e2) {
  return !!(e2 && e2.__highDownDispatcher);
}
function wd(e2) {
  var t2 = Cu[e2];
  return t2 == null && Su <= 32 && (t2 = Cu[e2] = Su++), t2;
}
function Td(e2) {
  var t2 = e2.type;
  return t2 === `select` || t2 === `unselect` || t2 === `toggleSelect`;
}
function Ed(e2) {
  var t2 = e2.type;
  return t2 === `highlight` || t2 === `downplay`;
}
function Dd(e2) {
  var t2 = wu(e2);
  t2.normalFill = e2.style.fill, t2.normalStroke = e2.style.stroke;
  var n2 = e2.states.select || {};
  t2.selectFill = n2.style && n2.style.fill || null, t2.selectStroke = n2.style && n2.style.stroke || null;
}
var Od = vl.CMD, kd = [[], [], []], Ad = Math.sqrt, jd = Math.atan2;
function Md(e2, t2) {
  if (t2) {
    var n2 = e2.data, r2 = e2.len(), i2, a2, o2, s2, c2, l2, u2 = Od.M, d2 = Od.C, f2 = Od.L, p2 = Od.R, m2 = Od.A, h2 = Od.Q;
    for (o2 = 0, s2 = 0; o2 < r2; ) {
      switch (i2 = n2[o2++], s2 = o2, a2 = 0, i2) {
        case u2:
          a2 = 1;
          break;
        case f2:
          a2 = 1;
          break;
        case d2:
          a2 = 3;
          break;
        case h2:
          a2 = 2;
          break;
        case m2:
          var g2 = t2[4], _2 = t2[5], v2 = Ad(t2[0] * t2[0] + t2[1] * t2[1]), y2 = Ad(t2[2] * t2[2] + t2[3] * t2[3]), b2 = jd(-t2[1] / y2, t2[0] / v2);
          n2[o2] *= v2, n2[o2++] += g2, n2[o2] *= y2, n2[o2++] += _2, n2[o2++] *= v2, n2[o2++] *= y2, n2[o2++] += b2, n2[o2++] += b2, o2 += 2, s2 = o2;
          break;
        case p2:
          l2[0] = n2[o2++], l2[1] = n2[o2++], qt(l2, l2, t2), n2[s2++] = l2[0], n2[s2++] = l2[1], l2[0] += n2[o2++], l2[1] += n2[o2++], qt(l2, l2, t2), n2[s2++] = l2[0], n2[s2++] = l2[1];
      }
      for (c2 = 0; c2 < a2; c2++) {
        var x2 = kd[c2];
        x2[0] = n2[o2++], x2[1] = n2[o2++], qt(x2, x2, t2), n2[s2++] = x2[0], n2[s2++] = x2[1];
      }
    }
    e2.increaseVersion();
  }
}
M();
var Nd = Math.sqrt, Pd = Math.sin, Fd = Math.cos, Id = Math.PI;
function Ld(e2) {
  return Math.sqrt(e2[0] * e2[0] + e2[1] * e2[1]);
}
function Rd(e2, t2) {
  return (e2[0] * t2[0] + e2[1] * t2[1]) / (Ld(e2) * Ld(t2));
}
function zd(e2, t2) {
  return (e2[0] * t2[1] < e2[1] * t2[0] ? -1 : 1) * Math.acos(Rd(e2, t2));
}
function Bd(e2, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2) {
  var d2 = Id / 180 * c2, f2 = Fd(d2) * (e2 - n2) / 2 + Pd(d2) * (t2 - r2) / 2, p2 = -1 * Pd(d2) * (e2 - n2) / 2 + Fd(d2) * (t2 - r2) / 2, m2 = f2 * f2 / (o2 * o2) + p2 * p2 / (s2 * s2);
  m2 > 1 && (o2 *= Nd(m2), s2 *= Nd(m2));
  var h2 = (i2 === a2 ? -1 : 1) * Nd((o2 * o2 * (s2 * s2) - o2 * o2 * (p2 * p2) - s2 * s2 * (f2 * f2)) / (o2 * o2 * (p2 * p2) + s2 * s2 * (f2 * f2))) || 0, g2 = h2 * o2 * p2 / s2, _2 = h2 * -s2 * f2 / o2, v2 = (e2 + n2) / 2 + Fd(d2) * g2 - Pd(d2) * _2, y2 = (t2 + r2) / 2 + Pd(d2) * g2 + Fd(d2) * _2, b2 = zd([1, 0], [(f2 - g2) / o2, (p2 - _2) / s2]), x2 = [(f2 - g2) / o2, (p2 - _2) / s2], S2 = [(-1 * f2 - g2) / o2, (-1 * p2 - _2) / s2], C2 = zd(x2, S2);
  if (Rd(x2, S2) <= -1 && (C2 = Id), Rd(x2, S2) >= 1 && (C2 = 0), C2 < 0) {
    var w2 = Math.round(C2 / Id * 1e6) / 1e6;
    C2 = Id * 2 + w2 % 2 * Id;
  }
  u2.addData(l2, v2, y2, o2, s2, b2, C2, d2, a2);
}
var Vd = /([mlvhzcqtsa])([^mlvhzcqtsa]*)/gi, Hd = /-?([0-9]*\.)?[0-9]+([eE]-?[0-9]+)?/g;
function Ud(e2) {
  var t2 = new vl();
  if (!e2) return t2;
  var n2 = 0, r2 = 0, i2 = n2, a2 = r2, o2, s2 = vl.CMD, c2 = e2.match(Vd);
  if (!c2) return t2;
  for (var l2 = 0; l2 < c2.length; l2++) {
    for (var u2 = c2[l2], d2 = u2.charAt(0), f2 = void 0, p2 = u2.match(Hd) || [], m2 = p2.length, h2 = 0; h2 < m2; h2++) p2[h2] = parseFloat(p2[h2]);
    for (var g2 = 0; g2 < m2; ) {
      var _2 = void 0, v2 = void 0, y2 = void 0, b2 = void 0, x2 = void 0, S2 = void 0, C2 = void 0, w2 = n2, T2 = r2, E2 = void 0, D2 = void 0;
      switch (d2) {
        case `l`:
          n2 += p2[g2++], r2 += p2[g2++], f2 = s2.L, t2.addData(f2, n2, r2);
          break;
        case `L`:
          n2 = p2[g2++], r2 = p2[g2++], f2 = s2.L, t2.addData(f2, n2, r2);
          break;
        case `m`:
          n2 += p2[g2++], r2 += p2[g2++], f2 = s2.M, t2.addData(f2, n2, r2), i2 = n2, a2 = r2, d2 = `l`;
          break;
        case `M`:
          n2 = p2[g2++], r2 = p2[g2++], f2 = s2.M, t2.addData(f2, n2, r2), i2 = n2, a2 = r2, d2 = `L`;
          break;
        case `h`:
          n2 += p2[g2++], f2 = s2.L, t2.addData(f2, n2, r2);
          break;
        case `H`:
          n2 = p2[g2++], f2 = s2.L, t2.addData(f2, n2, r2);
          break;
        case `v`:
          r2 += p2[g2++], f2 = s2.L, t2.addData(f2, n2, r2);
          break;
        case `V`:
          r2 = p2[g2++], f2 = s2.L, t2.addData(f2, n2, r2);
          break;
        case `C`:
          f2 = s2.C, t2.addData(f2, p2[g2++], p2[g2++], p2[g2++], p2[g2++], p2[g2++], p2[g2++]), n2 = p2[g2 - 2], r2 = p2[g2 - 1];
          break;
        case `c`:
          f2 = s2.C, t2.addData(f2, p2[g2++] + n2, p2[g2++] + r2, p2[g2++] + n2, p2[g2++] + r2, p2[g2++] + n2, p2[g2++] + r2), n2 += p2[g2 - 2], r2 += p2[g2 - 1];
          break;
        case `S`:
          _2 = n2, v2 = r2, E2 = t2.len(), D2 = t2.data, o2 === s2.C && (_2 += n2 - D2[E2 - 4], v2 += r2 - D2[E2 - 3]), f2 = s2.C, w2 = p2[g2++], T2 = p2[g2++], n2 = p2[g2++], r2 = p2[g2++], t2.addData(f2, _2, v2, w2, T2, n2, r2);
          break;
        case `s`:
          _2 = n2, v2 = r2, E2 = t2.len(), D2 = t2.data, o2 === s2.C && (_2 += n2 - D2[E2 - 4], v2 += r2 - D2[E2 - 3]), f2 = s2.C, w2 = n2 + p2[g2++], T2 = r2 + p2[g2++], n2 += p2[g2++], r2 += p2[g2++], t2.addData(f2, _2, v2, w2, T2, n2, r2);
          break;
        case `Q`:
          w2 = p2[g2++], T2 = p2[g2++], n2 = p2[g2++], r2 = p2[g2++], f2 = s2.Q, t2.addData(f2, w2, T2, n2, r2);
          break;
        case `q`:
          w2 = p2[g2++] + n2, T2 = p2[g2++] + r2, n2 += p2[g2++], r2 += p2[g2++], f2 = s2.Q, t2.addData(f2, w2, T2, n2, r2);
          break;
        case `T`:
          _2 = n2, v2 = r2, E2 = t2.len(), D2 = t2.data, o2 === s2.Q && (_2 += n2 - D2[E2 - 4], v2 += r2 - D2[E2 - 3]), n2 = p2[g2++], r2 = p2[g2++], f2 = s2.Q, t2.addData(f2, _2, v2, n2, r2);
          break;
        case `t`:
          _2 = n2, v2 = r2, E2 = t2.len(), D2 = t2.data, o2 === s2.Q && (_2 += n2 - D2[E2 - 4], v2 += r2 - D2[E2 - 3]), n2 += p2[g2++], r2 += p2[g2++], f2 = s2.Q, t2.addData(f2, _2, v2, n2, r2);
          break;
        case `A`:
          y2 = p2[g2++], b2 = p2[g2++], x2 = p2[g2++], S2 = p2[g2++], C2 = p2[g2++], w2 = n2, T2 = r2, n2 = p2[g2++], r2 = p2[g2++], f2 = s2.A, Bd(w2, T2, n2, r2, S2, C2, y2, b2, x2, f2, t2);
          break;
        case `a`:
          y2 = p2[g2++], b2 = p2[g2++], x2 = p2[g2++], S2 = p2[g2++], C2 = p2[g2++], w2 = n2, T2 = r2, n2 += p2[g2++], r2 += p2[g2++], f2 = s2.A, Bd(w2, T2, n2, r2, S2, C2, y2, b2, x2, f2, t2);
      }
    }
    (d2 === `z` || d2 === `Z`) && (f2 = s2.Z, t2.addData(f2), n2 = i2, r2 = a2), o2 = f2;
  }
  return t2.toStatic(), t2;
}
var Wd = (function(e2) {
  s(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.applyTransform = function(e3) {
  }, t2;
})(Q);
function Gd(e2) {
  return e2.setData != null;
}
function Kd(e2, t2) {
  var n2 = Ud(e2), r2 = R({}, t2);
  return r2.buildPath = function(e3) {
    if (Gd(e3)) {
      e3.setData(n2.data);
      var t3 = e3.getContext();
      t3 && e3.rebuildPath(t3, 1);
    } else {
      var t3 = e3;
      n2.rebuildPath(t3, 1);
    }
  }, r2.applyTransform = function(e3) {
    Md(n2, e3), this.dirtyShape();
  }, r2;
}
function qd(e2, t2) {
  return new Wd(Kd(e2, t2));
}
function Jd(e2, t2) {
  var n2 = Kd(e2, t2);
  return (function(e3) {
    s(t3, e3);
    function t3(t4) {
      var r2 = e3.call(this, t4) || this;
      return r2.applyTransform = n2.applyTransform, r2.buildPath = n2.buildPath, r2;
    }
    return t3;
  })(Wd);
}
function Yd(e2, t2) {
  for (var n2 = [], r2 = e2.length, i2 = 0; i2 < r2; i2++) {
    var a2 = e2[i2];
    n2.push(a2.getUpdatedPathProxy(true));
  }
  var o2 = new Q(t2);
  return o2.createPathProxy(), o2.buildPath = function(e3) {
    if (Gd(e3)) {
      e3.appendPath(n2);
      var t3 = e3.getContext();
      t3 && e3.rebuildPath(t3, 1);
    }
  }, o2;
}
M();
var Xd = /* @__PURE__ */ (function() {
  function e2() {
    this.cx = 0, this.cy = 0, this.r = 0;
  }
  return e2;
})(), Zd = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultShape = function() {
    return new Xd();
  }, t2.prototype.buildPath = function(e3, t3) {
    e3.moveTo(t3.cx + t3.r, t3.cy), e3.arc(t3.cx, t3.cy, t3.r, 0, Math.PI * 2);
  }, t2;
})(Q);
Zd.prototype.type = `circle`, M();
var Qd = /* @__PURE__ */ (function() {
  function e2() {
    this.cx = 0, this.cy = 0, this.rx = 0, this.ry = 0;
  }
  return e2;
})(), $d = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultShape = function() {
    return new Qd();
  }, t2.prototype.buildPath = function(e3, t3) {
    var n2 = 0.5522848, r2 = t3.cx, i2 = t3.cy, a2 = t3.rx, o2 = t3.ry, s2 = a2 * n2, c2 = o2 * n2;
    e3.moveTo(r2 - a2, i2), e3.bezierCurveTo(r2 - a2, i2 - c2, r2 - s2, i2 - o2, r2, i2 - o2), e3.bezierCurveTo(r2 + s2, i2 - o2, r2 + a2, i2 - c2, r2 + a2, i2), e3.bezierCurveTo(r2 + a2, i2 + c2, r2 + s2, i2 + o2, r2, i2 + o2), e3.bezierCurveTo(r2 - s2, i2 + o2, r2 - a2, i2 + c2, r2 - a2, i2), e3.closePath();
  }, t2;
})(Q);
$d.prototype.type = `ellipse`;
var ef = Math.PI, tf = ef * 2, nf = Math.sin, rf = Math.cos, af = Math.acos, of = Math.atan2, sf = Math.abs, cf = Math.sqrt, lf = Math.max, uf = Math.min, df = 1e-4;
function ff(e2, t2, n2, r2, i2, a2, o2, s2) {
  var c2 = n2 - e2, l2 = r2 - t2, u2 = o2 - i2, d2 = s2 - a2, f2 = d2 * c2 - u2 * l2;
  if (!(f2 * f2 < df)) return f2 = (u2 * (t2 - a2) - d2 * (e2 - i2)) / f2, [e2 + f2 * c2, t2 + f2 * l2];
}
function pf(e2, t2, n2, r2, i2, a2, o2) {
  var s2 = e2 - n2, c2 = t2 - r2, l2 = (o2 ? a2 : -a2) / cf(s2 * s2 + c2 * c2), u2 = l2 * c2, d2 = -l2 * s2, f2 = e2 + u2, p2 = t2 + d2, m2 = n2 + u2, h2 = r2 + d2, g2 = (f2 + m2) / 2, _2 = (p2 + h2) / 2, v2 = m2 - f2, y2 = h2 - p2, b2 = v2 * v2 + y2 * y2, x2 = i2 - a2, S2 = f2 * h2 - m2 * p2, C2 = (y2 < 0 ? -1 : 1) * cf(lf(0, x2 * x2 * b2 - S2 * S2)), w2 = (S2 * y2 - v2 * C2) / b2, T2 = (-S2 * v2 - y2 * C2) / b2, E2 = (S2 * y2 + v2 * C2) / b2, D2 = (-S2 * v2 + y2 * C2) / b2, O2 = w2 - g2, k2 = T2 - _2, A2 = E2 - g2, j2 = D2 - _2;
  return O2 * O2 + k2 * k2 > A2 * A2 + j2 * j2 && (w2 = E2, T2 = D2), { cx: w2, cy: T2, x0: -u2, y0: -d2, x1: w2 * (i2 / x2 - 1), y1: T2 * (i2 / x2 - 1) };
}
function mf(e2) {
  var t2;
  if (H(e2)) {
    var n2 = e2.length;
    if (!n2) return e2;
    t2 = n2 === 1 ? [e2[0], e2[0], 0, 0] : n2 === 2 ? [e2[0], e2[0], e2[1], e2[1]] : n2 === 3 ? e2.concat(e2[2]) : e2;
  } else t2 = [e2, e2, e2, e2];
  return t2;
}
function hf(e2, t2) {
  var n2, r2 = lf(t2.r, 0), i2 = lf(t2.r0 || 0, 0), a2 = r2 > 0;
  if (a2 || i2 > 0) {
    if (a2 || (r2 = i2, i2 = 0), i2 > r2) {
      var o2 = r2;
      r2 = i2, i2 = o2;
    }
    var s2 = t2.startAngle, c2 = t2.endAngle;
    if (!(isNaN(s2) || isNaN(c2))) {
      var l2 = t2.cx, u2 = t2.cy, d2 = !!t2.clockwise, f2 = sf(c2 - s2), p2 = f2 > tf && f2 % tf;
      if (p2 > df && (f2 = p2), !(r2 > df)) e2.moveTo(l2, u2);
      else if (f2 > tf - df) e2.moveTo(l2 + r2 * rf(s2), u2 + r2 * nf(s2)), e2.arc(l2, u2, r2, s2, c2, !d2), i2 > df && (e2.moveTo(l2 + i2 * rf(c2), u2 + i2 * nf(c2)), e2.arc(l2, u2, i2, c2, s2, d2));
      else {
        var m2 = void 0, h2 = void 0, g2 = void 0, _2 = void 0, v2 = void 0, y2 = void 0, b2 = void 0, x2 = void 0, S2 = void 0, C2 = void 0, w2 = void 0, T2 = void 0, E2 = void 0, D2 = void 0, O2 = void 0, k2 = void 0, A2 = r2 * rf(s2), j2 = r2 * nf(s2), ee2 = i2 * rf(c2), M2 = i2 * nf(c2), N2 = f2 > df;
        if (N2) {
          var te2 = t2.cornerRadius;
          te2 && (n2 = mf(te2), m2 = n2[0], h2 = n2[1], g2 = n2[2], _2 = n2[3]);
          var ne2 = sf(r2 - i2) / 2;
          if (v2 = uf(ne2, g2), y2 = uf(ne2, _2), b2 = uf(ne2, m2), x2 = uf(ne2, h2), w2 = S2 = lf(v2, y2), T2 = C2 = lf(b2, x2), (S2 > df || C2 > df) && (E2 = r2 * rf(c2), D2 = r2 * nf(c2), O2 = i2 * rf(s2), k2 = i2 * nf(s2), f2 < ef)) {
            var re2 = ff(A2, j2, O2, k2, E2, D2, ee2, M2);
            if (re2) {
              var ie2 = A2 - re2[0], ae2 = j2 - re2[1], oe2 = E2 - re2[0], se2 = D2 - re2[1], ce2 = 1 / nf(af((ie2 * oe2 + ae2 * se2) / (cf(ie2 * ie2 + ae2 * ae2) * cf(oe2 * oe2 + se2 * se2))) / 2), le2 = cf(re2[0] * re2[0] + re2[1] * re2[1]);
              w2 = uf(S2, (r2 - le2) / (ce2 + 1)), T2 = uf(C2, (i2 - le2) / (ce2 - 1));
            }
          }
        }
        if (!N2) e2.moveTo(l2 + A2, u2 + j2);
        else if (w2 > df) {
          var ue2 = uf(g2, w2), de2 = uf(_2, w2), P2 = pf(O2, k2, A2, j2, r2, ue2, d2), F2 = pf(E2, D2, ee2, M2, r2, de2, d2);
          e2.moveTo(l2 + P2.cx + P2.x0, u2 + P2.cy + P2.y0), w2 < S2 && ue2 === de2 ? e2.arc(l2 + P2.cx, u2 + P2.cy, w2, of(P2.y0, P2.x0), of(F2.y0, F2.x0), !d2) : (ue2 > 0 && e2.arc(l2 + P2.cx, u2 + P2.cy, ue2, of(P2.y0, P2.x0), of(P2.y1, P2.x1), !d2), e2.arc(l2, u2, r2, of(P2.cy + P2.y1, P2.cx + P2.x1), of(F2.cy + F2.y1, F2.cx + F2.x1), !d2), de2 > 0 && e2.arc(l2 + F2.cx, u2 + F2.cy, de2, of(F2.y1, F2.x1), of(F2.y0, F2.x0), !d2));
        } else e2.moveTo(l2 + A2, u2 + j2), e2.arc(l2, u2, r2, s2, c2, !d2);
        if (!(i2 > df) || !N2) e2.lineTo(l2 + ee2, u2 + M2);
        else if (T2 > df) {
          var ue2 = uf(m2, T2), de2 = uf(h2, T2), P2 = pf(ee2, M2, E2, D2, i2, -de2, d2), F2 = pf(A2, j2, O2, k2, i2, -ue2, d2);
          e2.lineTo(l2 + P2.cx + P2.x0, u2 + P2.cy + P2.y0), T2 < C2 && ue2 === de2 ? e2.arc(l2 + P2.cx, u2 + P2.cy, T2, of(P2.y0, P2.x0), of(F2.y0, F2.x0), !d2) : (de2 > 0 && e2.arc(l2 + P2.cx, u2 + P2.cy, de2, of(P2.y0, P2.x0), of(P2.y1, P2.x1), !d2), e2.arc(l2, u2, i2, of(P2.cy + P2.y1, P2.cx + P2.x1), of(F2.cy + F2.y1, F2.cx + F2.x1), d2), ue2 > 0 && e2.arc(l2 + F2.cx, u2 + F2.cy, ue2, of(F2.y1, F2.x1), of(F2.y0, F2.x0), !d2));
        } else e2.lineTo(l2 + ee2, u2 + M2), e2.arc(l2, u2, i2, c2, s2, d2);
      }
      e2.closePath();
    }
  }
}
M();
var gf = /* @__PURE__ */ (function() {
  function e2() {
    this.cx = 0, this.cy = 0, this.r0 = 0, this.r = 0, this.startAngle = 0, this.endAngle = Math.PI * 2, this.clockwise = true, this.cornerRadius = 0;
  }
  return e2;
})(), _f = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultShape = function() {
    return new gf();
  }, t2.prototype.buildPath = function(e3, t3) {
    hf(e3, t3);
  }, t2.prototype.isZeroArea = function() {
    return this.shape.startAngle === this.shape.endAngle || this.shape.r === this.shape.r0;
  }, t2;
})(Q);
_f.prototype.type = `sector`, M();
var vf = /* @__PURE__ */ (function() {
  function e2() {
    this.cx = 0, this.cy = 0, this.r = 0, this.r0 = 0;
  }
  return e2;
})(), yf = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultShape = function() {
    return new vf();
  }, t2.prototype.buildPath = function(e3, t3) {
    var n2 = t3.cx, r2 = t3.cy, i2 = Math.PI * 2;
    e3.moveTo(n2 + t3.r, r2), e3.arc(n2, r2, t3.r, 0, i2, false), e3.moveTo(n2 + t3.r0, r2), e3.arc(n2, r2, t3.r0, 0, i2, true);
  }, t2;
})(Q);
yf.prototype.type = `ring`;
function bf(e2, t2, n2, r2) {
  var i2 = [], a2 = [], o2 = [], s2 = [], c2, l2, u2, d2;
  if (r2) {
    u2 = [1 / 0, 1 / 0], d2 = [-1 / 0, -1 / 0];
    for (var f2 = 0, p2 = e2.length; f2 < p2; f2++) Jt(u2, u2, e2[f2]), Yt(d2, d2, e2[f2]);
    Jt(u2, u2, r2[0]), Yt(d2, d2, r2[1]);
  }
  for (var f2 = 0, p2 = e2.length; f2 < p2; f2++) {
    var m2 = e2[f2];
    if (n2) c2 = e2[f2 ? f2 - 1 : p2 - 1], l2 = e2[(f2 + 1) % p2];
    else if (f2 === 0 || f2 === p2 - 1) {
      i2.push(Dt(e2[f2]));
      continue;
    } else c2 = e2[f2 - 1], l2 = e2[f2 + 1];
    jt(a2, l2, c2), zt(a2, a2, t2);
    var h2 = Vt(m2, c2), g2 = Vt(m2, l2), _2 = h2 + g2;
    _2 !== 0 && (h2 /= _2, g2 /= _2), zt(o2, a2, -h2), zt(s2, a2, g2);
    var v2 = kt([], m2, o2), y2 = kt([], m2, s2);
    r2 && (Yt(v2, v2, u2), Jt(v2, v2, d2), Yt(y2, y2, u2), Jt(y2, y2, d2)), i2.push(v2), i2.push(y2);
  }
  return n2 && i2.push(i2.shift()), i2;
}
function xf(e2, t2, n2) {
  var r2 = t2.smooth, i2 = t2.points;
  if (i2 && i2.length >= 2) {
    if (r2) {
      var a2 = bf(i2, r2, n2, t2.smoothConstraint);
      e2.moveTo(i2[0][0], i2[0][1]);
      for (var o2 = i2.length, s2 = 0; s2 < (n2 ? o2 : o2 - 1); s2++) {
        var c2 = a2[s2 * 2], l2 = a2[s2 * 2 + 1], u2 = i2[(s2 + 1) % o2];
        e2.bezierCurveTo(c2[0], c2[1], l2[0], l2[1], u2[0], u2[1]);
      }
    } else {
      e2.moveTo(i2[0][0], i2[0][1]);
      for (var s2 = 1, d2 = i2.length; s2 < d2; s2++) e2.lineTo(i2[s2][0], i2[s2][1]);
    }
    n2 && e2.closePath();
  }
}
M();
var Sf = /* @__PURE__ */ (function() {
  function e2() {
    this.points = null, this.smooth = 0, this.smoothConstraint = null;
  }
  return e2;
})(), Cf = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultShape = function() {
    return new Sf();
  }, t2.prototype.buildPath = function(e3, t3) {
    xf(e3, t3, true);
  }, t2;
})(Q);
Cf.prototype.type = `polygon`, M();
var wf = /* @__PURE__ */ (function() {
  function e2() {
    this.points = null, this.percent = 1, this.smooth = 0, this.smoothConstraint = null;
  }
  return e2;
})(), Tf = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultStyle = function() {
    return { stroke: `#000`, fill: null };
  }, t2.prototype.getDefaultShape = function() {
    return new wf();
  }, t2.prototype.buildPath = function(e3, t3) {
    xf(e3, t3, false);
  }, t2;
})(Q);
Tf.prototype.type = `polyline`, M();
var Ef = {}, Df = /* @__PURE__ */ (function() {
  function e2() {
    this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.percent = 1;
  }
  return e2;
})(), Of = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultStyle = function() {
    return { stroke: `#000`, fill: null };
  }, t2.prototype.getDefaultShape = function() {
    return new Df();
  }, t2.prototype.buildPath = function(e3, t3) {
    var n2, r2, i2, a2;
    if (this.subPixelOptimize) {
      var o2 = Zl(Ef, t3, this.style);
      n2 = o2.x1, r2 = o2.y1, i2 = o2.x2, a2 = o2.y2;
    } else n2 = t3.x1, r2 = t3.y1, i2 = t3.x2, a2 = t3.y2;
    var s2 = t3.percent;
    s2 !== 0 && (e3.moveTo(n2, r2), s2 < 1 && (i2 = n2 * (1 - s2) + i2 * s2, a2 = r2 * (1 - s2) + a2 * s2), e3.lineTo(i2, a2));
  }, t2.prototype.pointAt = function(e3) {
    var t3 = this.shape;
    return [t3.x1 * (1 - e3) + t3.x2 * e3, t3.y1 * (1 - e3) + t3.y2 * e3];
  }, t2;
})(Q);
Of.prototype.type = `line`, M();
var kf = [], Af = /* @__PURE__ */ (function() {
  function e2() {
    this.x1 = 0, this.y1 = 0, this.x2 = 0, this.y2 = 0, this.cpx1 = 0, this.cpy1 = 0, this.percent = 1;
  }
  return e2;
})();
function jf(e2, t2, n2) {
  var r2 = e2.cpx2, i2 = e2.cpy2;
  return r2 != null || i2 != null ? [(n2 ? jr : Ar)(e2.x1, e2.cpx1, e2.cpx2, e2.x2, t2), (n2 ? jr : Ar)(e2.y1, e2.cpy1, e2.cpy2, e2.y2, t2)] : [(n2 ? Rr : Lr)(e2.x1, e2.cpx1, e2.x2, t2), (n2 ? Rr : Lr)(e2.y1, e2.cpy1, e2.y2, t2)];
}
var Mf = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultStyle = function() {
    return { stroke: `#000`, fill: null };
  }, t2.prototype.getDefaultShape = function() {
    return new Af();
  }, t2.prototype.buildPath = function(e3, t3) {
    var n2 = t3.x1, r2 = t3.y1, i2 = t3.x2, a2 = t3.y2, o2 = t3.cpx1, s2 = t3.cpy1, c2 = t3.cpx2, l2 = t3.cpy2, u2 = t3.percent;
    u2 !== 0 && (e3.moveTo(n2, r2), c2 == null || l2 == null ? (u2 < 1 && (Vr(n2, o2, i2, u2, kf), o2 = kf[1], i2 = kf[2], Vr(r2, s2, a2, u2, kf), s2 = kf[1], a2 = kf[2]), e3.quadraticCurveTo(o2, s2, i2, a2)) : (u2 < 1 && (Pr(n2, o2, c2, i2, u2, kf), o2 = kf[1], c2 = kf[2], i2 = kf[3], Pr(r2, s2, l2, a2, u2, kf), s2 = kf[1], l2 = kf[2], a2 = kf[3]), e3.bezierCurveTo(o2, s2, c2, l2, i2, a2)));
  }, t2.prototype.pointAt = function(e3) {
    return jf(this.shape, e3, false);
  }, t2.prototype.tangentAt = function(e3) {
    var t3 = jf(this.shape, e3, true);
    return Bt(t3, t3);
  }, t2;
})(Q);
Mf.prototype.type = `bezier-curve`, M();
var Nf = /* @__PURE__ */ (function() {
  function e2() {
    this.cx = 0, this.cy = 0, this.r = 0, this.startAngle = 0, this.endAngle = Math.PI * 2, this.clockwise = true;
  }
  return e2;
})(), Pf = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    return e2.call(this, t3) || this;
  }
  return t2.prototype.getDefaultStyle = function() {
    return { stroke: `#000`, fill: null };
  }, t2.prototype.getDefaultShape = function() {
    return new Nf();
  }, t2.prototype.buildPath = function(e3, t3) {
    var n2 = t3.cx, r2 = t3.cy, i2 = Math.max(t3.r, 0), a2 = t3.startAngle, o2 = t3.endAngle, s2 = t3.clockwise, c2 = Math.cos(a2), l2 = Math.sin(a2);
    e3.moveTo(c2 * i2 + n2, l2 * i2 + r2), e3.arc(n2, r2, i2, a2, o2, !s2);
  }, t2;
})(Q);
Pf.prototype.type = `arc`, M();
var Ff = (function(e2) {
  s(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3.type = `compound`, t3;
  }
  return t2.prototype._updatePathDirty = function() {
    for (var e3 = this.shape.paths, t3 = this.shapeChanged(), n2 = 0; n2 < e3.length; n2++) t3 || (t3 = e3[n2].shapeChanged());
    t3 && this.dirtyShape();
  }, t2.prototype.beforeBrush = function() {
    this._updatePathDirty();
    for (var e3 = this.shape.paths || [], t3 = this.getGlobalScale(), n2 = 0; n2 < e3.length; n2++) e3[n2].path || e3[n2].createPathProxy(), e3[n2].path.setScale(t3[0], t3[1], e3[n2].segmentIgnoreThreshold);
  }, t2.prototype.buildPath = function(e3, t3) {
    for (var n2 = t3.paths || [], r2 = 0; r2 < n2.length; r2++) n2[r2].buildPath(e3, n2[r2].shape, true);
  }, t2.prototype.afterBrush = function() {
    for (var e3 = this.shape.paths || [], t3 = 0; t3 < e3.length; t3++) e3[t3].pathUpdated();
  }, t2.prototype.getBoundingRect = function() {
    return this._updatePathDirty.call(this), Q.prototype.getBoundingRect.call(this);
  }, t2;
})(Q), If = (function() {
  function e2(e3) {
    this.colorStops = e3 || [];
  }
  return e2.prototype.addColorStop = function(e3, t2) {
    this.colorStops.push({ offset: e3, color: t2 });
  }, e2;
})();
M();
var Lf = (function(e2) {
  s(t2, e2);
  function t2(t3, n2, r2, i2, a2, o2) {
    var s2 = e2.call(this, a2) || this;
    return s2.x = t3 ?? 0, s2.y = n2 ?? 0, s2.x2 = r2 ?? 1, s2.y2 = i2 ?? 0, s2.type = `linear`, s2.global = o2 || false, s2;
  }
  return t2;
})(If);
M();
var Rf = (function(e2) {
  s(t2, e2);
  function t2(t3, n2, r2, i2, a2) {
    var o2 = e2.call(this, i2) || this;
    return o2.x = t3 ?? 0.5, o2.y = n2 ?? 0.5, o2.r = r2 ?? 0.5, o2.type = `radial`, o2.global = a2 || false, o2;
  }
  return t2;
})(If), zf = [0, 0], Bf = [0, 0], Vf = new Y(), Hf = new Y(), Uf = (function() {
  function e2(e3, t2) {
    this._corners = [], this._axes = [], this._origin = [0, 0];
    for (var n2 = 0; n2 < 4; n2++) this._corners[n2] = new Y();
    for (var n2 = 0; n2 < 2; n2++) this._axes[n2] = new Y();
    e3 && this.fromBoundingRect(e3, t2);
  }
  return e2.prototype.fromBoundingRect = function(e3, t2) {
    var n2 = this._corners, r2 = this._axes, i2 = e3.x, a2 = e3.y, o2 = i2 + e3.width, s2 = a2 + e3.height;
    if (n2[0].set(i2, a2), n2[1].set(o2, a2), n2[2].set(o2, s2), n2[3].set(i2, s2), t2) for (var c2 = 0; c2 < 4; c2++) n2[c2].transform(t2);
    Y.sub(r2[0], n2[1], n2[0]), Y.sub(r2[1], n2[3], n2[0]), r2[0].normalize(), r2[1].normalize();
    for (var c2 = 0; c2 < 2; c2++) this._origin[c2] = r2[c2].dot(n2[0]);
  }, e2.prototype.intersect = function(e3, t2) {
    var n2 = true, r2 = !t2;
    return Vf.set(1 / 0, 1 / 0), Hf.set(0, 0), !this._intersectCheckOneSide(this, e3, Vf, Hf, r2, 1) && (n2 = false, r2) || !this._intersectCheckOneSide(e3, this, Vf, Hf, r2, -1) && (n2 = false, r2) || r2 || Y.copy(t2, n2 ? Vf : Hf), n2;
  }, e2.prototype._intersectCheckOneSide = function(e3, t2, n2, r2, i2, a2) {
    for (var o2 = true, s2 = 0; s2 < 2; s2++) {
      var c2 = this._axes[s2];
      if (this._getProjMinMaxOnAxis(s2, e3._corners, zf), this._getProjMinMaxOnAxis(s2, t2._corners, Bf), zf[1] < Bf[0] || zf[0] > Bf[1]) {
        if (o2 = false, i2) return o2;
        var l2 = Math.abs(Bf[0] - zf[1]), u2 = Math.abs(zf[0] - Bf[1]);
        Math.min(l2, u2) > r2.len() && (l2 < u2 ? Y.scale(r2, c2, -l2 * a2) : Y.scale(r2, c2, u2 * a2));
      } else if (n2) {
        var l2 = Math.abs(Bf[0] - zf[1]), u2 = Math.abs(zf[0] - Bf[1]);
        Math.min(l2, u2) < n2.len() && (l2 < u2 ? Y.scale(n2, c2, l2 * a2) : Y.scale(n2, c2, -u2 * a2));
      }
    }
    return o2;
  }, e2.prototype._getProjMinMaxOnAxis = function(e3, t2, n2) {
    for (var r2 = this._axes[e3], i2 = this._origin, a2 = t2[0].dot(r2) + i2[e3], o2 = a2, s2 = a2, c2 = 1; c2 < t2.length; c2++) {
      var l2 = t2[c2].dot(r2) + i2[e3];
      o2 = Math.min(l2, o2), s2 = Math.max(l2, s2);
    }
    n2[0] = o2, n2[1] = s2;
  }, e2;
})();
M();
var Wf = [], Gf = (function(e2) {
  s(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3.notClear = true, t3.incremental = true, t3._displayables = [], t3._temporaryDisplayables = [], t3._cursor = 0, t3;
  }
  return t2.prototype.traverse = function(e3, t3) {
    e3.call(t3, this);
  }, t2.prototype.useStyle = function() {
    this.style = {};
  }, t2.prototype.getCursor = function() {
    return this._cursor;
  }, t2.prototype.innerAfterBrush = function() {
    this._cursor = this._displayables.length;
  }, t2.prototype.clearDisplaybles = function() {
    this._displayables = [], this._temporaryDisplayables = [], this._cursor = 0, this.markRedraw(), this.notClear = false;
  }, t2.prototype.clearTemporalDisplayables = function() {
    this._temporaryDisplayables = [];
  }, t2.prototype.addDisplayable = function(e3, t3) {
    t3 ? this._temporaryDisplayables.push(e3) : this._displayables.push(e3), this.markRedraw();
  }, t2.prototype.addDisplayables = function(e3, t3) {
    t3 || (t3 = false);
    for (var n2 = 0; n2 < e3.length; n2++) this.addDisplayable(e3[n2], t3);
  }, t2.prototype.getDisplayables = function() {
    return this._displayables;
  }, t2.prototype.getTemporalDisplayables = function() {
    return this._temporaryDisplayables;
  }, t2.prototype.eachPendingDisplayable = function(e3) {
    for (var t3 = this._cursor; t3 < this._displayables.length; t3++) e3 && e3(this._displayables[t3]);
    for (var t3 = 0; t3 < this._temporaryDisplayables.length; t3++) e3 && e3(this._temporaryDisplayables[t3]);
  }, t2.prototype.update = function() {
    this.updateTransform();
    for (var e3 = this._cursor; e3 < this._displayables.length; e3++) {
      var t3 = this._displayables[e3];
      t3.parent = this, t3.update(), t3.parent = null;
    }
    for (var e3 = 0; e3 < this._temporaryDisplayables.length; e3++) {
      var t3 = this._temporaryDisplayables[e3];
      t3.parent = this, t3.update(), t3.parent = null;
    }
  }, t2.prototype.getBoundingRect = function() {
    if (!this._rect) {
      for (var e3 = new X(1 / 0, 1 / 0, -1 / 0, -1 / 0), t3 = 0; t3 < this._displayables.length; t3++) {
        var n2 = this._displayables[t3], r2 = n2.getBoundingRect().clone();
        n2.needLocalTransform() && r2.applyTransform(n2.getLocalTransform(Wf)), e3.union(r2);
      }
      this._rect = e3;
    }
    return this._rect;
  }, t2.prototype.contain = function(e3, t3) {
    var n2 = this.transformCoordToLocal(e3, t3);
    if (this.getBoundingRect().contain(n2[0], n2[1])) {
      for (var r2 = 0; r2 < this._displayables.length; r2++) if (this._displayables[r2].contain(e3, t3)) return true;
    }
    return false;
  }, t2;
})(Lc), Kf = Ls();
function qf(e2, t2, n2, r2, i2) {
  var a2;
  if (t2 && t2.ecModel) {
    var o2 = t2.ecModel.getUpdatePayload();
    a2 = o2 && o2.animation;
  }
  var s2 = t2 && t2.isAnimationEnabled(), c2 = e2 === `update`;
  if (s2) {
    var l2 = void 0, u2 = void 0, d2 = void 0;
    return r2 ? (l2 = q(r2.duration, 200), u2 = q(r2.easing, `cubicOut`), d2 = 0) : (l2 = t2.getShallow(c2 ? `animationDurationUpdate` : `animationDuration`), u2 = t2.getShallow(c2 ? `animationEasingUpdate` : `animationEasing`), d2 = t2.getShallow(c2 ? `animationDelayUpdate` : `animationDelay`)), a2 && (a2.duration != null && (l2 = a2.duration), a2.easing != null && (u2 = a2.easing), a2.delay != null && (d2 = a2.delay)), U(d2) && (d2 = d2(n2, i2)), U(l2) && (l2 = l2(n2)), { duration: l2 || 0, delay: d2, easing: u2 };
  }
  return null;
}
function Jf(e2, t2, n2, r2, i2, a2, o2) {
  var s2 = false, c2;
  U(i2) ? (o2 = a2, a2 = i2, i2 = null) : K(i2) && (a2 = i2.cb, o2 = i2.during, s2 = i2.isFrom, c2 = i2.removeOpt, i2 = i2.dataIndex);
  var l2 = e2 === `leave`;
  l2 || t2.stopAnimation(`leave`);
  var u2 = qf(e2, r2, i2, l2 ? c2 || {} : null, r2 && r2.getAnimationDelayParams ? r2.getAnimationDelayParams(t2, i2) : null);
  if (u2 && u2.duration > 0) {
    var d2 = u2.duration, f2 = u2.delay, p2 = u2.easing, m2 = { duration: d2, delay: f2 || 0, easing: p2, done: a2, force: !!a2 || !!o2, setToFinal: !l2, scope: e2, during: o2 };
    s2 ? t2.animateFrom(n2, m2) : t2.animateTo(n2, m2);
  } else t2.stopAnimation(), !s2 && t2.attr(n2), o2 && o2(1), a2 && a2();
}
function Yf(e2, t2, n2, r2, i2, a2) {
  Jf(`update`, e2, t2, n2, r2, i2, a2);
}
function Xf(e2, t2, n2, r2, i2, a2) {
  Jf(`enter`, e2, t2, n2, r2, i2, a2);
}
function Zf(e2) {
  if (!e2.__zr) return true;
  for (var t2 = 0; t2 < e2.animators.length; t2++) if (e2.animators[t2].scope === `leave`) return true;
  return false;
}
function Qf(e2, t2, n2, r2, i2, a2) {
  Zf(e2) || Jf(`leave`, e2, t2, n2, r2, i2, a2);
}
function $f(e2, t2, n2, r2) {
  e2.removeTextContent(), e2.removeTextGuideLine(), Qf(e2, { style: { opacity: 0 } }, t2, n2, r2);
}
function ep(e2, t2, n2) {
  function r2() {
    e2.parent && e2.parent.remove(e2);
  }
  e2.isGroup ? e2.traverse(function(e3) {
    e3.isGroup || $f(e3, t2, n2, r2);
  }) : $f(e2, t2, n2, r2);
}
function tp(e2) {
  Kf(e2).oldStyle = e2.style;
}
var np = n({ Arc: () => Pf, BezierCurve: () => Mf, BoundingRect: () => X, Circle: () => Zd, CompoundPath: () => Ff, Ellipse: () => $d, Group: () => So, Image: () => Jl, IncrementalDisplayable: () => Gf, Line: () => Of, LinearGradient: () => Lf, OrientedBoundingRect: () => Uf, Path: () => Q, Point: () => Y, Polygon: () => Cf, Polyline: () => Tf, RadialGradient: () => Rf, Rect: () => nu, Ring: () => yf, Sector: () => _f, Text: () => ou, applyTransform: () => bp, clipPointsByRect: () => Tp, clipRectByRect: () => Ep, createIcon: () => Dp, extendPath: () => cp, extendShape: () => op, getShapeClass: () => up, getTransform: () => yp, groupTransition: () => wp, initProps: () => Xf, isElementRemoved: () => Zf, lineLineIntersect: () => kp, linePolygonIntersect: () => Op, makeImage: () => fp, makePath: () => dp, mergePath: () => mp, registerShape: () => lp, removeElement: () => Qf, removeElementWithFadeOut: () => ep, resizePath: () => hp, setTooltipConfig: () => Mp, subPixelOptimize: () => vp, subPixelOptimizeLine: () => gp, subPixelOptimizeRect: () => _p, transformDirection: () => xp, traverseElements: () => Pp, updateProps: () => Yf }), rp = Math.max, ip = Math.min, ap = {};
function op(e2) {
  return Q.extend(e2);
}
var sp = Jd;
function cp(e2, t2) {
  return sp(e2, t2);
}
function lp(e2, t2) {
  ap[e2] = t2;
}
function up(e2) {
  if (ap.hasOwnProperty(e2)) return ap[e2];
}
function dp(e2, t2, n2, r2) {
  var i2 = qd(e2, t2);
  return n2 && (r2 === `center` && (n2 = pp(n2, i2.getBoundingRect())), hp(i2, n2)), i2;
}
function fp(e2, t2, n2) {
  var r2 = new Jl({ style: { image: e2, x: t2.x, y: t2.y, width: t2.width, height: t2.height }, onload: function(e3) {
    if (n2 === `center`) {
      var i2 = { width: e3.width, height: e3.height };
      r2.setStyle(pp(t2, i2));
    }
  } });
  return r2;
}
function pp(e2, t2) {
  var n2 = t2.width / t2.height, r2 = e2.height * n2, i2;
  r2 <= e2.width ? i2 = e2.height : (r2 = e2.width, i2 = r2 / n2);
  var a2 = e2.x + e2.width / 2, o2 = e2.y + e2.height / 2;
  return { x: a2 - r2 / 2, y: o2 - i2 / 2, width: r2, height: i2 };
}
var mp = Yd;
function hp(e2, t2) {
  if (e2.applyTransform) {
    var n2 = e2.getBoundingRect().calculateTransform(t2);
    e2.applyTransform(n2);
  }
}
function gp(e2, t2) {
  return Zl(e2, e2, { lineWidth: t2 }), e2;
}
function _p(e2) {
  return Ql(e2.shape, e2.shape, e2.style), e2;
}
var vp = $l;
function yp(e2, t2) {
  for (var n2 = An([]); e2 && e2 !== t2; ) Mn(n2, e2.getLocalTransform(), n2), e2 = e2.parent;
  return n2;
}
function bp(e2, t2, n2) {
  return t2 && !We(t2) && (t2 = Xa.getLocalTransform(t2)), n2 && (t2 = In([], t2)), qt([], e2, t2);
}
function xp(e2, t2, n2) {
  var r2 = t2[4] === 0 || t2[5] === 0 || t2[0] === 0 ? 1 : Math.abs(2 * t2[4] / t2[0]), i2 = t2[4] === 0 || t2[5] === 0 || t2[2] === 0 ? 1 : Math.abs(2 * t2[4] / t2[2]), a2 = [e2 === `left` ? -r2 : e2 === `right` ? r2 : 0, e2 === `top` ? -i2 : e2 === `bottom` ? i2 : 0];
  return a2 = bp(a2, t2, n2), Math.abs(a2[0]) > Math.abs(a2[1]) ? a2[0] > 0 ? `right` : `left` : a2[1] > 0 ? `bottom` : `top`;
}
function Sp(e2) {
  return !e2.isGroup;
}
function Cp(e2) {
  return e2.shape != null;
}
function wp(e2, t2, n2) {
  if (!e2 || !t2) return;
  function r2(e3) {
    var t3 = {};
    return e3.traverse(function(e4) {
      Sp(e4) && e4.anid && (t3[e4.anid] = e4);
    }), t3;
  }
  function i2(e3) {
    var t3 = { x: e3.x, y: e3.y, rotation: e3.rotation };
    return Cp(e3) && (t3.shape = R({}, e3.shape)), t3;
  }
  var a2 = r2(e2);
  t2.traverse(function(e3) {
    if (Sp(e3) && e3.anid) {
      var t3 = a2[e3.anid];
      if (t3) {
        var r3 = i2(e3);
        e3.attr(i2(t3)), Yf(e3, r3, n2, bu(e3).dataIndex);
      }
    }
  });
}
function Tp(e2, t2) {
  return B(e2, function(e3) {
    var n2 = e3[0];
    n2 = rp(n2, t2.x), n2 = ip(n2, t2.x + t2.width);
    var r2 = e3[1];
    return r2 = rp(r2, t2.y), r2 = ip(r2, t2.y + t2.height), [n2, r2];
  });
}
function Ep(e2, t2) {
  var n2 = rp(e2.x, t2.x), r2 = ip(e2.x + e2.width, t2.x + t2.width), i2 = rp(e2.y, t2.y), a2 = ip(e2.y + e2.height, t2.y + t2.height);
  if (r2 >= n2 && a2 >= i2) return { x: n2, y: i2, width: r2 - n2, height: a2 - i2 };
}
function Dp(e2, t2, n2) {
  var r2 = R({ rectHover: true }, t2), i2 = r2.style = { strokeNoScale: true };
  if (n2 || (n2 = { x: -1, y: -1, width: 2, height: 2 }), e2) return e2.indexOf(`image://`) === 0 ? (i2.image = e2.slice(8), ze(i2, n2), new Jl(r2)) : dp(e2.replace(`path://`, ``), r2, n2, `center`);
}
function Op(e2, t2, n2, r2, i2) {
  for (var a2 = 0, o2 = i2[i2.length - 1]; a2 < i2.length; a2++) {
    var s2 = i2[a2];
    if (kp(e2, t2, n2, r2, s2[0], s2[1], o2[0], o2[1])) return true;
    o2 = s2;
  }
}
function kp(e2, t2, n2, r2, i2, a2, o2, s2) {
  var c2 = n2 - e2, l2 = r2 - t2, u2 = o2 - i2, d2 = s2 - a2, f2 = Ap(u2, d2, c2, l2);
  if (jp(f2)) return false;
  var p2 = e2 - i2, m2 = t2 - a2, h2 = Ap(p2, m2, c2, l2) / f2;
  if (h2 < 0 || h2 > 1) return false;
  var g2 = Ap(p2, m2, u2, d2) / f2;
  return !(g2 < 0 || g2 > 1);
}
function Ap(e2, t2, n2, r2) {
  return e2 * r2 - n2 * t2;
}
function jp(e2) {
  return e2 <= 1e-6 && e2 >= -1e-6;
}
function Mp(e2) {
  var t2 = e2.itemTooltipOption, n2 = e2.componentModel, r2 = e2.itemName, i2 = W(t2) ? { formatter: t2 } : t2, a2 = n2.mainType, o2 = n2.componentIndex, s2 = { componentType: a2, name: r2, $vars: [`name`] };
  s2[a2 + `Index`] = o2;
  var c2 = e2.formatterParamsExtra;
  c2 && z(V(c2), function(e3) {
    xt(s2, e3) || (s2[e3] = c2[e3], s2.$vars.push(e3));
  });
  var l2 = bu(e2.el);
  l2.componentMainType = a2, l2.componentIndex = o2, l2.tooltipConfig = { name: r2, option: ze({ content: r2, encodeHTMLContent: true, formatterParams: s2 }, i2) };
}
function Np(e2, t2) {
  var n2;
  e2.isGroup && (n2 = t2(e2)), n2 || e2.traverse(t2);
}
function Pp(e2, t2) {
  if (e2) {
    if (H(e2)) for (var n2 = 0; n2 < e2.length; n2++) Np(e2[n2], t2);
    else Np(e2, t2);
  }
}
lp(`circle`, Zd), lp(`ellipse`, $d), lp(`sector`, _f), lp(`ring`, yf), lp(`polygon`, Cf), lp(`polyline`, Tf), lp(`rect`, nu), lp(`line`, Of), lp(`bezierCurve`, Mf), lp(`arc`, Pf);
var Fp = {};
function Ip(e2, t2) {
  for (var n2 = 0; n2 < Eu.length; n2++) {
    var r2 = Eu[n2], i2 = t2[r2], a2 = e2.ensureState(r2);
    a2.style = a2.style || {}, a2.style.text = i2;
  }
  var o2 = e2.currentStates.slice();
  e2.clearStates(true), e2.setStyle({ text: t2.normal }), e2.useStates(o2, true);
}
function Lp(e2, t2, n2) {
  var r2 = e2.labelFetcher, i2 = e2.labelDataIndex, a2 = e2.labelDimIndex, o2 = t2.normal, s2;
  r2 && (s2 = r2.getFormattedLabel(i2, `normal`, null, a2, o2 && o2.get(`formatter`), n2 == null ? null : { interpolatedValue: n2 })), s2 ?? (s2 = U(e2.defaultText) ? e2.defaultText(i2, e2, n2) : e2.defaultText);
  for (var c2 = { normal: s2 }, l2 = 0; l2 < Eu.length; l2++) {
    var u2 = Eu[l2], d2 = t2[u2];
    c2[u2] = q(r2 ? r2.getFormattedLabel(i2, u2, null, a2, d2 && d2.get(`formatter`)) : null, s2);
  }
  return c2;
}
function Rp(e2, t2, n2, r2) {
  n2 || (n2 = Fp);
  for (var i2 = e2 instanceof ou, a2 = false, o2 = 0; o2 < Du.length; o2++) {
    var s2 = t2[Du[o2]];
    if (s2 && s2.getShallow(`show`)) {
      a2 = true;
      break;
    }
  }
  var c2 = i2 ? e2 : e2.getTextContent();
  if (a2) {
    i2 || (c2 || (c2 = new ou(), e2.setTextContent(c2)), e2.stateProxy && (c2.stateProxy = e2.stateProxy));
    var l2 = Lp(n2, t2), u2 = t2.normal, d2 = !!u2.getShallow(`show`), f2 = Bp(u2, r2 && r2.normal, n2, false, !i2);
    f2.text = l2.normal, i2 || e2.setTextConfig(Vp(u2, n2, false));
    for (var o2 = 0; o2 < Eu.length; o2++) {
      var p2 = Eu[o2], s2 = t2[p2];
      if (s2) {
        var m2 = c2.ensureState(p2), h2 = !!q(s2.getShallow(`show`), d2);
        if (h2 !== d2 && (m2.ignore = !h2), m2.style = Bp(s2, r2 && r2[p2], n2, true, !i2), m2.style.text = l2[p2], !i2) {
          var g2 = e2.ensureState(p2);
          g2.textConfig = Vp(s2, n2, true);
        }
      }
    }
    c2.silent = !!u2.getShallow(`silent`), c2.style.x != null && (f2.x = c2.style.x), c2.style.y != null && (f2.y = c2.style.y), c2.ignore = !d2, c2.useStyle(f2), c2.dirty(), n2.enableTextSetter && (Yp(c2).setLabelText = function(e3) {
      var r3 = Lp(n2, t2, e3);
      Ip(c2, r3);
    });
  } else c2 && (c2.ignore = true);
  e2.dirty();
}
function zp(e2, t2) {
  t2 || (t2 = `label`);
  for (var n2 = { normal: e2.getModel(t2) }, r2 = 0; r2 < Eu.length; r2++) {
    var i2 = Eu[r2];
    n2[i2] = e2.getModel([i2, t2]);
  }
  return n2;
}
function Bp(e2, t2, n2, r2, i2) {
  var a2 = {};
  return Hp(a2, e2, n2, r2, i2), t2 && R(a2, t2), a2;
}
function Vp(e2, t2, n2) {
  t2 || (t2 = {});
  var r2 = {}, i2, a2 = e2.getShallow(`rotate`), o2 = q(e2.getShallow(`distance`), n2 ? null : 5), s2 = e2.getShallow(`offset`);
  return i2 = e2.getShallow(`position`) || (n2 ? null : `inside`), i2 === `outside` && (i2 = t2.defaultOutsidePosition || `top`), i2 != null && (r2.position = i2), s2 != null && (r2.offset = s2), a2 != null && (a2 *= Math.PI / 180, r2.rotation = a2), o2 != null && (r2.distance = o2), r2.outsideFill = e2.get(`color`) === `inherit` ? t2.inheritColor || null : `auto`, r2;
}
function Hp(e2, t2, n2, r2, i2) {
  n2 || (n2 = Fp);
  var a2 = t2.ecModel, o2 = a2 && a2.option.textStyle, s2 = Up(t2), c2;
  if (s2) {
    for (var l2 in c2 = {}, s2) if (s2.hasOwnProperty(l2)) {
      var u2 = t2.getModel([`rich`, l2]);
      qp(c2[l2] = {}, u2, o2, n2, r2, i2, false, true);
    }
  }
  c2 && (e2.rich = c2);
  var d2 = t2.get(`overflow`);
  d2 && (e2.overflow = d2);
  var f2 = t2.get(`minMargin`);
  f2 != null && (e2.margin = f2), qp(e2, t2, o2, n2, r2, i2, true, false);
}
function Up(e2) {
  for (var t2; e2 && e2 !== e2.ecModel; ) {
    var n2 = (e2.option || Fp).rich;
    if (n2) {
      t2 || (t2 = {});
      for (var r2 = V(n2), i2 = 0; i2 < r2.length; i2++) {
        var a2 = r2[i2];
        t2[a2] = 1;
      }
    }
    e2 = e2.parentModel;
  }
  return t2;
}
var Wp = [`fontStyle`, `fontWeight`, `fontSize`, `fontFamily`, `textShadowColor`, `textShadowBlur`, `textShadowOffsetX`, `textShadowOffsetY`], Gp = [`align`, `lineHeight`, `width`, `height`, `tag`, `verticalAlign`, `ellipsis`], Kp = [`padding`, `borderWidth`, `borderRadius`, `borderDashOffset`, `backgroundColor`, `borderColor`, `shadowColor`, `shadowBlur`, `shadowOffsetX`, `shadowOffsetY`];
function qp(e2, t2, n2, r2, i2, a2, o2, s2) {
  n2 = !i2 && n2 || Fp;
  var c2 = r2 && r2.inheritColor, l2 = t2.getShallow(`color`), u2 = t2.getShallow(`textBorderColor`), d2 = q(t2.getShallow(`opacity`), n2.opacity);
  (l2 === `inherit` || l2 === `auto`) && (l2 = c2 || null), (u2 === `inherit` || u2 === `auto`) && (u2 = c2 || null), a2 || (l2 || (l2 = n2.color), u2 || (u2 = n2.textBorderColor)), l2 != null && (e2.fill = l2), u2 != null && (e2.stroke = u2);
  var f2 = q(t2.getShallow(`textBorderWidth`), n2.textBorderWidth);
  f2 != null && (e2.lineWidth = f2);
  var p2 = q(t2.getShallow(`textBorderType`), n2.textBorderType);
  p2 != null && (e2.lineDash = p2);
  var m2 = q(t2.getShallow(`textBorderDashOffset`), n2.textBorderDashOffset);
  m2 != null && (e2.lineDashOffset = m2), !i2 && d2 == null && !s2 && (d2 = r2 && r2.defaultOpacity), d2 != null && (e2.opacity = d2), !i2 && !a2 && e2.fill == null && r2.inheritColor && (e2.fill = r2.inheritColor);
  for (var h2 = 0; h2 < Wp.length; h2++) {
    var g2 = Wp[h2], _2 = q(t2.getShallow(g2), n2[g2]);
    _2 != null && (e2[g2] = _2);
  }
  for (var h2 = 0; h2 < Gp.length; h2++) {
    var g2 = Gp[h2], _2 = t2.getShallow(g2);
    _2 != null && (e2[g2] = _2);
  }
  if (e2.verticalAlign == null) {
    var v2 = t2.getShallow(`baseline`);
    v2 != null && (e2.verticalAlign = v2);
  }
  if (!o2 || !r2.disableBox) {
    for (var h2 = 0; h2 < Kp.length; h2++) {
      var g2 = Kp[h2], _2 = t2.getShallow(g2);
      _2 != null && (e2[g2] = _2);
    }
    var y2 = t2.getShallow(`borderType`);
    y2 != null && (e2.borderDash = y2), (e2.backgroundColor === `auto` || e2.backgroundColor === `inherit`) && c2 && (e2.backgroundColor = c2), (e2.borderColor === `auto` || e2.borderColor === `inherit`) && c2 && (e2.borderColor = c2);
  }
}
function Jp(e2, t2) {
  var n2 = t2 && t2.getModel(`textStyle`);
  return ut([e2.fontStyle || n2 && n2.getShallow(`fontStyle`) || ``, e2.fontWeight || n2 && n2.getShallow(`fontWeight`) || ``, (e2.fontSize || n2 && n2.getShallow(`fontSize`) || 12) + `px`, e2.fontFamily || n2 && n2.getShallow(`fontFamily`) || `sans-serif`].join(` `));
}
var Yp = Ls(), Xp = [`textStyle`, `color`], Zp = [`fontStyle`, `fontWeight`, `fontSize`, `fontFamily`, `padding`, `lineHeight`, `rich`, `width`, `height`, `overflow`], Qp = new ou(), $p = (function() {
  function e2() {
  }
  return e2.prototype.getTextColor = function(e3) {
    var t2 = this.ecModel;
    return this.getShallow(`color`) || (!e3 && t2 ? t2.get(Xp) : null);
  }, e2.prototype.getFont = function() {
    return Jp({ fontStyle: this.getShallow(`fontStyle`), fontWeight: this.getShallow(`fontWeight`), fontSize: this.getShallow(`fontSize`), fontFamily: this.getShallow(`fontFamily`) }, this.ecModel);
  }, e2.prototype.getTextRect = function(e3) {
    for (var t2 = { text: e3, verticalAlign: this.getShallow(`verticalAlign`) || this.getShallow(`baseline`) }, n2 = 0; n2 < Zp.length; n2++) t2[Zp[n2]] = this.getShallow(Zp[n2]);
    return Qp.useStyle(t2), Qp.update(), Qp.getBoundingRect();
  }, e2;
})(), em = [[`lineWidth`, `width`], [`stroke`, `color`], [`opacity`], [`shadowBlur`], [`shadowOffsetX`], [`shadowOffsetY`], [`shadowColor`], [`lineDash`, `type`], [`lineDashOffset`, `dashOffset`], [`lineCap`, `cap`], [`lineJoin`, `join`], [`miterLimit`]], tm = cc(em), nm = (function() {
  function e2() {
  }
  return e2.prototype.getLineStyle = function(e3) {
    return tm(this, e3);
  }, e2;
})(), rm = [[`fill`, `color`], [`stroke`, `borderColor`], [`lineWidth`, `borderWidth`], [`opacity`], [`shadowBlur`], [`shadowOffsetX`], [`shadowOffsetY`], [`shadowColor`], [`lineDash`, `borderType`], [`lineDashOffset`, `borderDashOffset`], [`lineCap`, `borderCap`], [`lineJoin`, `borderJoin`], [`miterLimit`, `borderMiterLimit`]], im = cc(rm), am = (function() {
  function e2() {
  }
  return e2.prototype.getItemStyle = function(e3, t2) {
    return im(this, e3, t2);
  }, e2;
})(), om = (function() {
  function e2(e3, t2, n2) {
    this.parentModel = t2, this.ecModel = n2, this.option = e3;
  }
  return e2.prototype.init = function(e3, t2, n2) {
  }, e2.prototype.mergeOption = function(e3, t2) {
    Le(this.option, e3, true);
  }, e2.prototype.get = function(e3, t2) {
    return e3 == null ? this.option : this._doGet(this.parsePath(e3), !t2 && this.parentModel);
  }, e2.prototype.getShallow = function(e3, t2) {
    var n2 = this.option, r2 = n2 == null ? n2 : n2[e3];
    if (r2 == null && !t2) {
      var i2 = this.parentModel;
      i2 && (r2 = i2.getShallow(e3));
    }
    return r2;
  }, e2.prototype.getModel = function(t2, n2) {
    var r2 = t2 != null, i2 = r2 ? this.parsePath(t2) : null, a2 = r2 ? this._doGet(i2) : this.option;
    return n2 || (n2 = this.parentModel && this.parentModel.getModel(this.resolveParentPath(i2))), new e2(a2, n2, this.ecModel);
  }, e2.prototype.isEmpty = function() {
    return this.option == null;
  }, e2.prototype.restoreData = function() {
  }, e2.prototype.clone = function() {
    var e3 = this.constructor;
    return new e3(L(this.option));
  }, e2.prototype.parsePath = function(e3) {
    return typeof e3 == `string` ? e3.split(`.`) : e3;
  }, e2.prototype.resolveParentPath = function(e3) {
    return e3;
  }, e2.prototype.isAnimationEnabled = function() {
    if (!I.node && this.option) {
      if (this.option.animation != null) return !!this.option.animation;
      if (this.parentModel) return this.parentModel.isAnimationEnabled();
    }
  }, e2.prototype._doGet = function(e3, t2) {
    var n2 = this.option;
    if (!e3) return n2;
    for (var r2 = 0; r2 < e3.length && !(e3[r2] && (n2 = n2 && typeof n2 == `object` ? n2[e3[r2]] : null, n2 == null)); r2++) ;
    return n2 == null && t2 && (n2 = t2._doGet(this.resolveParentPath(e3), t2.parentModel)), n2;
  }, e2;
})();
ec(om), ic(om), Ue(om, nm), Ue(om, am), Ue(om, uc), Ue(om, $p);
var sm = Math.round(Math.random() * 10);
function cm(e2) {
  return [e2 || ``, sm++].join(`_`);
}
function lm(e2) {
  var t2 = {};
  e2.registerSubTypeDefaulter = function(e3, n2) {
    var r2 = Zs(e3);
    t2[r2.main] = n2;
  }, e2.determineSubType = function(n2, r2) {
    var i2 = r2.type;
    if (!i2) {
      var a2 = Zs(n2).main;
      e2.hasSubTypes(n2) && t2[a2] && (i2 = t2[a2](r2));
    }
    return i2;
  };
}
function um(e2, t2) {
  e2.topologicalTravel = function(e3, t3, r3, i3) {
    if (!e3.length) return;
    var a2 = n2(t3), o2 = a2.graph, s2 = a2.noEntryList, c2 = {};
    for (z(e3, function(e4) {
      c2[e4] = true;
    }); s2.length; ) {
      var l2 = s2.pop(), u2 = o2[l2], d2 = !!c2[l2];
      d2 && (r3.call(i3, l2, u2.originalDeps.slice()), delete c2[l2]), z(u2.successor, d2 ? p2 : f2);
    }
    z(c2, function() {
      throw Error(``);
    });
    function f2(e4) {
      o2[e4].entryCount--, o2[e4].entryCount === 0 && s2.push(e4);
    }
    function p2(e4) {
      c2[e4] = true, f2(e4);
    }
  };
  function n2(e3) {
    var n3 = {}, a2 = [];
    return z(e3, function(o2) {
      var s2 = r2(n3, o2), c2 = i2(s2.originalDeps = t2(o2), e3);
      s2.entryCount = c2.length, s2.entryCount === 0 && a2.push(o2), z(c2, function(e4) {
        Ve(s2.predecessor, e4) < 0 && s2.predecessor.push(e4);
        var t3 = r2(n3, e4);
        Ve(t3.successor, e4) < 0 && t3.successor.push(o2);
      });
    }), { graph: n3, noEntryList: a2 };
  }
  function r2(e3, t3) {
    return e3[t3] || (e3[t3] = { predecessor: [], successor: [] }), e3[t3];
  }
  function i2(e3, t3) {
    var n3 = [];
    return z(e3, function(e4) {
      Ve(t3, e4) >= 0 && n3.push(e4);
    }), n3;
  }
}
function dm(e2, t2) {
  return Le(Le({}, e2, true), t2, true);
}
var fm = { time: { month: [`January`, `February`, `March`, `April`, `May`, `June`, `July`, `August`, `September`, `October`, `November`, `December`], monthAbbr: [`Jan`, `Feb`, `Mar`, `Apr`, `May`, `Jun`, `Jul`, `Aug`, `Sep`, `Oct`, `Nov`, `Dec`], dayOfWeek: [`Sunday`, `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`], dayOfWeekAbbr: [`Sun`, `Mon`, `Tue`, `Wed`, `Thu`, `Fri`, `Sat`] }, legend: { selector: { all: `All`, inverse: `Inv` } }, toolbox: { brush: { title: { rect: `Box Select`, polygon: `Lasso Select`, lineX: `Horizontally Select`, lineY: `Vertically Select`, keep: `Keep Selections`, clear: `Clear Selections` } }, dataView: { title: `Data View`, lang: [`Data View`, `Close`, `Refresh`] }, dataZoom: { title: { zoom: `Zoom`, back: `Zoom Reset` } }, magicType: { title: { line: `Switch to Line Chart`, bar: `Switch to Bar Chart`, stack: `Stack`, tiled: `Tile` } }, restore: { title: `Restore` }, saveAsImage: { title: `Save as Image`, lang: [`Right Click to Save Image`] } }, series: { typeNames: { pie: `Pie chart`, bar: `Bar chart`, line: `Line chart`, scatter: `Scatter plot`, effectScatter: `Ripple scatter plot`, radar: `Radar chart`, tree: `Tree`, treemap: `Treemap`, boxplot: `Boxplot`, candlestick: `Candlestick`, k: `K line chart`, heatmap: `Heat map`, map: `Map`, parallel: `Parallel coordinate map`, lines: `Line graph`, graph: `Relationship graph`, sankey: `Sankey diagram`, funnel: `Funnel chart`, gauge: `Gauge`, pictorialBar: `Pictorial bar`, themeRiver: `Theme River Map`, sunburst: `Sunburst`, custom: `Custom chart`, chart: `Chart` } }, aria: { general: { withTitle: `This is a chart about "{title}"`, withoutTitle: `This is a chart` }, series: { single: { prefix: ``, withName: ` with type {seriesType} named {seriesName}.`, withoutName: ` with type {seriesType}.` }, multiple: { prefix: `. It consists of {seriesCount} series count.`, withName: ` The {seriesId} series is a {seriesType} representing {seriesName}.`, withoutName: ` The {seriesId} series is a {seriesType}.`, separator: { middle: ``, end: `` } } }, data: { allData: `The data is as follows: `, partialData: `The first {displayCnt} items are: `, withName: `the data for {name} is {value}`, withoutName: `{value}`, separator: { middle: `, `, end: `. ` } } } }, pm = { time: { month: [`\u4E00\u6708`, `\u4E8C\u6708`, `\u4E09\u6708`, `\u56DB\u6708`, `\u4E94\u6708`, `\u516D\u6708`, `\u4E03\u6708`, `\u516B\u6708`, `\u4E5D\u6708`, `\u5341\u6708`, `\u5341\u4E00\u6708`, `\u5341\u4E8C\u6708`], monthAbbr: [`1\u6708`, `2\u6708`, `3\u6708`, `4\u6708`, `5\u6708`, `6\u6708`, `7\u6708`, `8\u6708`, `9\u6708`, `10\u6708`, `11\u6708`, `12\u6708`], dayOfWeek: [`\u661F\u671F\u65E5`, `\u661F\u671F\u4E00`, `\u661F\u671F\u4E8C`, `\u661F\u671F\u4E09`, `\u661F\u671F\u56DB`, `\u661F\u671F\u4E94`, `\u661F\u671F\u516D`], dayOfWeekAbbr: [`\u65E5`, `\u4E00`, `\u4E8C`, `\u4E09`, `\u56DB`, `\u4E94`, `\u516D`] }, legend: { selector: { all: `\u5168\u9009`, inverse: `\u53CD\u9009` } }, toolbox: { brush: { title: { rect: `\u77E9\u5F62\u9009\u62E9`, polygon: `\u5708\u9009`, lineX: `\u6A2A\u5411\u9009\u62E9`, lineY: `\u7EB5\u5411\u9009\u62E9`, keep: `\u4FDD\u6301\u9009\u62E9`, clear: `\u6E05\u9664\u9009\u62E9` } }, dataView: { title: `\u6570\u636E\u89C6\u56FE`, lang: [`\u6570\u636E\u89C6\u56FE`, `\u5173\u95ED`, `\u5237\u65B0`] }, dataZoom: { title: { zoom: `\u533A\u57DF\u7F29\u653E`, back: `\u533A\u57DF\u7F29\u653E\u8FD8\u539F` } }, magicType: { title: { line: `\u5207\u6362\u4E3A\u6298\u7EBF\u56FE`, bar: `\u5207\u6362\u4E3A\u67F1\u72B6\u56FE`, stack: `\u5207\u6362\u4E3A\u5806\u53E0`, tiled: `\u5207\u6362\u4E3A\u5E73\u94FA` } }, restore: { title: `\u8FD8\u539F` }, saveAsImage: { title: `\u4FDD\u5B58\u4E3A\u56FE\u7247`, lang: [`\u53F3\u952E\u53E6\u5B58\u4E3A\u56FE\u7247`] } }, series: { typeNames: { pie: `\u997C\u56FE`, bar: `\u67F1\u72B6\u56FE`, line: `\u6298\u7EBF\u56FE`, scatter: `\u6563\u70B9\u56FE`, effectScatter: `\u6D9F\u6F2A\u6563\u70B9\u56FE`, radar: `\u96F7\u8FBE\u56FE`, tree: `\u6811\u56FE`, treemap: `\u77E9\u5F62\u6811\u56FE`, boxplot: `\u7BB1\u578B\u56FE`, candlestick: `K\u7EBF\u56FE`, k: `K\u7EBF\u56FE`, heatmap: `\u70ED\u529B\u56FE`, map: `\u5730\u56FE`, parallel: `\u5E73\u884C\u5750\u6807\u56FE`, lines: `\u7EBF\u56FE`, graph: `\u5173\u7CFB\u56FE`, sankey: `\u6851\u57FA\u56FE`, funnel: `\u6F0F\u6597\u56FE`, gauge: `\u4EEA\u8868\u76D8\u56FE`, pictorialBar: `\u8C61\u5F62\u67F1\u56FE`, themeRiver: `\u4E3B\u9898\u6CB3\u6D41\u56FE`, sunburst: `\u65ED\u65E5\u56FE`, custom: `\u81EA\u5B9A\u4E49\u56FE\u8868`, chart: `\u56FE\u8868` } }, aria: { general: { withTitle: `\u8FD9\u662F\u4E00\u4E2A\u5173\u4E8E\u201C{title}\u201D\u7684\u56FE\u8868\u3002`, withoutTitle: `\u8FD9\u662F\u4E00\u4E2A\u56FE\u8868\uFF0C` }, series: { single: { prefix: ``, withName: `\u56FE\u8868\u7C7B\u578B\u662F{seriesType}\uFF0C\u8868\u793A{seriesName}\u3002`, withoutName: `\u56FE\u8868\u7C7B\u578B\u662F{seriesType}\u3002` }, multiple: { prefix: `\u5B83\u7531{seriesCount}\u4E2A\u56FE\u8868\u7CFB\u5217\u7EC4\u6210\u3002`, withName: `\u7B2C{seriesId}\u4E2A\u7CFB\u5217\u662F\u4E00\u4E2A\u8868\u793A{seriesName}\u7684{seriesType}\uFF0C`, withoutName: `\u7B2C{seriesId}\u4E2A\u7CFB\u5217\u662F\u4E00\u4E2A{seriesType}\uFF0C`, separator: { middle: `\uFF1B`, end: `\u3002` } } }, data: { allData: `\u5176\u6570\u636E\u662F\u2014\u2014`, partialData: `\u5176\u4E2D\uFF0C\u524D{displayCnt}\u9879\u662F\u2014\u2014`, withName: `{name}\u7684\u6570\u636E\u662F{value}`, withoutName: `{value}`, separator: { middle: `\uFF0C`, end: `` } } } }, mm = `ZH`, hm = `EN`, gm = hm, _m = {}, vm = {}, ym = I.domSupported ? (function() {
  return (document.documentElement.lang || navigator.language || navigator.browserLanguage || gm).toUpperCase().indexOf(mm) > -1 ? mm : gm;
})() : gm;
function bm(e2, t2) {
  e2 = e2.toUpperCase(), vm[e2] = new om(t2), _m[e2] = t2;
}
function xm(e2) {
  if (W(e2)) {
    var t2 = _m[e2.toUpperCase()] || {};
    return e2 === mm || e2 === hm ? L(t2) : Le(L(t2), L(_m[gm]), false);
  }
  return Le(L(e2), L(_m[gm]), false);
}
function Sm(e2) {
  return vm[e2];
}
function Cm() {
  return vm[gm];
}
bm(hm, fm), bm(mm, pm);
var wm = 1e3, Tm = wm * 60, Em = Tm * 60, Dm = Em * 24, Om = Dm * 365, km = { year: `{yyyy}`, month: `{MMM}`, day: `{d}`, hour: `{HH}:{mm}`, minute: `{HH}:{mm}`, second: `{HH}:{mm}:{ss}`, millisecond: `{HH}:{mm}:{ss} {SSS}`, none: `{yyyy}-{MM}-{dd} {HH}:{mm}:{ss} {SSS}` }, Am = `{yyyy}-{MM}-{dd}`, jm = { year: `{yyyy}`, month: `{yyyy}-{MM}`, day: Am, hour: Am + ` ` + km.hour, minute: Am + ` ` + km.minute, second: Am + ` ` + km.second, millisecond: km.none }, Mm = [`year`, `month`, `day`, `hour`, `minute`, `second`, `millisecond`], Nm = [`year`, `half-year`, `quarter`, `month`, `week`, `half-week`, `day`, `half-day`, `quarter-day`, `hour`, `minute`, `second`, `millisecond`];
function Pm(e2, t2) {
  return e2 += ``, `0000`.substr(0, t2 - e2.length) + e2;
}
function Fm(e2) {
  switch (e2) {
    case `half-year`:
    case `quarter`:
      return `month`;
    case `week`:
    case `half-week`:
      return `day`;
    case `half-day`:
    case `quarter-day`:
      return `hour`;
    default:
      return e2;
  }
}
function Im(e2) {
  return e2 === Fm(e2);
}
function Lm(e2) {
  switch (e2) {
    case `year`:
    case `month`:
      return `day`;
    case `millisecond`:
      return `millisecond`;
    default:
      return `second`;
  }
}
function Rm(e2, t2, n2, r2) {
  var i2 = ts(e2), a2 = i2[Hm(n2)](), o2 = i2[Um(n2)]() + 1, s2 = Math.floor((o2 - 1) / 3) + 1, c2 = i2[Wm(n2)](), l2 = i2[`get` + (n2 ? `UTC` : ``) + `Day`](), u2 = i2[Gm(n2)](), d2 = (u2 - 1) % 12 + 1, f2 = i2[Km(n2)](), p2 = i2[qm(n2)](), m2 = i2[Jm(n2)](), h2 = u2 >= 12 ? `pm` : `am`, g2 = h2.toUpperCase(), _2 = (r2 instanceof om ? r2 : Sm(r2 || ym) || Cm()).getModel(`time`), v2 = _2.get(`month`), y2 = _2.get(`monthAbbr`), b2 = _2.get(`dayOfWeek`), x2 = _2.get(`dayOfWeekAbbr`);
  return (t2 || ``).replace(/{a}/g, h2 + ``).replace(/{A}/g, g2 + ``).replace(/{yyyy}/g, a2 + ``).replace(/{yy}/g, Pm(a2 % 100 + ``, 2)).replace(/{Q}/g, s2 + ``).replace(/{MMMM}/g, v2[o2 - 1]).replace(/{MMM}/g, y2[o2 - 1]).replace(/{MM}/g, Pm(o2, 2)).replace(/{M}/g, o2 + ``).replace(/{dd}/g, Pm(c2, 2)).replace(/{d}/g, c2 + ``).replace(/{eeee}/g, b2[l2]).replace(/{ee}/g, x2[l2]).replace(/{e}/g, l2 + ``).replace(/{HH}/g, Pm(u2, 2)).replace(/{H}/g, u2 + ``).replace(/{hh}/g, Pm(d2 + ``, 2)).replace(/{h}/g, d2 + ``).replace(/{mm}/g, Pm(f2, 2)).replace(/{m}/g, f2 + ``).replace(/{ss}/g, Pm(p2, 2)).replace(/{s}/g, p2 + ``).replace(/{SSS}/g, Pm(m2, 3)).replace(/{S}/g, m2 + ``);
}
function zm(e2, t2, n2, r2, i2) {
  var a2 = null;
  if (W(n2)) a2 = n2;
  else if (U(n2)) a2 = n2(e2.value, t2, { level: e2.level });
  else {
    var o2 = R({}, km);
    if (e2.level > 0) for (var s2 = 0; s2 < Mm.length; ++s2) o2[Mm[s2]] = `{primary|` + o2[Mm[s2]] + `}`;
    var c2 = n2 ? n2.inherit === false ? n2 : ze(n2, o2) : o2, l2 = Bm(e2.value, i2);
    if (c2[l2]) a2 = c2[l2];
    else if (c2.inherit) {
      for (var s2 = Nm.indexOf(l2) - 1; s2 >= 0; --s2) if (c2[l2]) {
        a2 = c2[l2];
        break;
      }
      a2 || (a2 = o2.none);
    }
    if (H(a2)) {
      var u2 = e2.level == null ? 0 : e2.level >= 0 ? e2.level : a2.length + e2.level;
      u2 = Math.min(u2, a2.length - 1), a2 = a2[u2];
    }
  }
  return Rm(new Date(e2.value), a2, i2, r2);
}
function Bm(e2, t2) {
  var n2 = ts(e2), r2 = n2[Um(t2)]() + 1, i2 = n2[Wm(t2)](), a2 = n2[Gm(t2)](), o2 = n2[Km(t2)](), s2 = n2[qm(t2)](), c2 = n2[Jm(t2)]() === 0, l2 = c2 && s2 === 0, u2 = l2 && o2 === 0, d2 = u2 && a2 === 0, f2 = d2 && i2 === 1;
  return f2 && r2 === 1 ? `year` : f2 ? `month` : d2 ? `day` : u2 ? `hour` : l2 ? `minute` : c2 ? `second` : `millisecond`;
}
function Vm(e2, t2, n2) {
  var r2 = G(e2) ? ts(e2) : e2;
  switch (t2 || (t2 = Bm(e2, n2)), t2) {
    case `year`:
      return r2[Hm(n2)]();
    case `half-year`:
      return +(r2[Um(n2)]() >= 6);
    case `quarter`:
      return Math.floor((r2[Um(n2)]() + 1) / 4);
    case `month`:
      return r2[Um(n2)]();
    case `day`:
      return r2[Wm(n2)]();
    case `half-day`:
      return r2[Gm(n2)]() / 24;
    case `hour`:
      return r2[Gm(n2)]();
    case `minute`:
      return r2[Km(n2)]();
    case `second`:
      return r2[qm(n2)]();
    case `millisecond`:
      return r2[Jm(n2)]();
  }
}
function Hm(e2) {
  return e2 ? `getUTCFullYear` : `getFullYear`;
}
function Um(e2) {
  return e2 ? `getUTCMonth` : `getMonth`;
}
function Wm(e2) {
  return e2 ? `getUTCDate` : `getDate`;
}
function Gm(e2) {
  return e2 ? `getUTCHours` : `getHours`;
}
function Km(e2) {
  return e2 ? `getUTCMinutes` : `getMinutes`;
}
function qm(e2) {
  return e2 ? `getUTCSeconds` : `getSeconds`;
}
function Jm(e2) {
  return e2 ? `getUTCMilliseconds` : `getMilliseconds`;
}
function Ym(e2) {
  return e2 ? `setUTCFullYear` : `setFullYear`;
}
function Xm(e2) {
  return e2 ? `setUTCMonth` : `setMonth`;
}
function Zm(e2) {
  return e2 ? `setUTCDate` : `setDate`;
}
function Qm(e2) {
  return e2 ? `setUTCHours` : `setHours`;
}
function $m(e2) {
  return e2 ? `setUTCMinutes` : `setMinutes`;
}
function eh(e2) {
  return e2 ? `setUTCSeconds` : `setSeconds`;
}
function th(e2) {
  return e2 ? `setUTCMilliseconds` : `setMilliseconds`;
}
function nh(e2, t2, n2, r2, i2, a2, o2, s2) {
  return new ou({ style: { text: e2, font: t2, align: n2, verticalAlign: r2, padding: i2, rich: a2, overflow: o2 ? `truncate` : null, lineHeight: s2 } }).getBoundingRect();
}
function rh(e2) {
  if (!cs(e2)) return W(e2) ? e2 : `-`;
  var t2 = (e2 + ``).split(`.`);
  return t2[0].replace(/(\d{1,3})(?=(?:\d{3})+(?!\d))/g, `$1,`) + (t2.length > 1 ? `.` + t2[1] : ``);
}
function ih(e2, t2) {
  return e2 = (e2 || ``).toLowerCase().replace(/-(.)/g, function(e3, t3) {
    return t3.toUpperCase();
  }), t2 && e2 && (e2 = e2.charAt(0).toUpperCase() + e2.slice(1)), e2;
}
var ah = ct;
function oh(e2, t2, n2) {
  var r2 = `{yyyy}-{MM}-{dd} {HH}:{mm}:{ss}`;
  function i2(e3) {
    return e3 && ut(e3) ? e3 : `-`;
  }
  function a2(e3) {
    return !(e3 == null || isNaN(e3) || !isFinite(e3));
  }
  var o2 = t2 === `time`, s2 = e2 instanceof Date;
  if (o2 || s2) {
    var c2 = o2 ? ts(e2) : e2;
    if (!isNaN(+c2)) return Rm(c2, r2, n2);
    if (s2) return `-`;
  }
  if (t2 === `ordinal`) return Ze(e2) ? i2(e2) : G(e2) && a2(e2) ? e2 + `` : `-`;
  var l2 = ss(e2);
  return a2(l2) ? rh(l2) : Ze(e2) ? i2(e2) : typeof e2 == `boolean` ? e2 + `` : `-`;
}
var sh = [`a`, `b`, `c`, `d`, `e`, `f`, `g`], ch = function(e2, t2) {
  return `{` + e2 + (t2 ?? ``) + `}`;
};
function lh(e2, t2, n2) {
  H(t2) || (t2 = [t2]);
  var r2 = t2.length;
  if (!r2) return ``;
  for (var i2 = t2[0].$vars || [], a2 = 0; a2 < i2.length; a2++) {
    var o2 = sh[a2];
    e2 = e2.replace(ch(o2), ch(o2, 0));
  }
  for (var s2 = 0; s2 < r2; s2++) for (var c2 = 0; c2 < i2.length; c2++) {
    var l2 = t2[s2][i2[c2]];
    e2 = e2.replace(ch(sh[c2], s2), n2 ? fn(l2) : l2);
  }
  return e2;
}
function uh(e2, t2) {
  var n2 = W(e2) ? { color: e2, extraCssText: t2 } : e2 || {}, r2 = n2.color, i2 = n2.type;
  t2 = n2.extraCssText;
  var a2 = n2.renderMode || `html`;
  return r2 ? a2 === `html` ? i2 === `subItem` ? `<span style="display:inline-block;vertical-align:middle;margin-right:8px;margin-left:3px;border-radius:4px;width:4px;height:4px;background-color:` + fn(r2) + `;` + (t2 || ``) + `"></span>` : `<span style="display:inline-block;margin-right:4px;border-radius:10px;width:10px;height:10px;background-color:` + fn(r2) + `;` + (t2 || ``) + `"></span>` : { renderMode: a2, content: `{` + (n2.markerId || `markerX`) + `|}  `, style: i2 === `subItem` ? { width: 4, height: 4, borderRadius: 2, backgroundColor: r2 } : { width: 10, height: 10, borderRadius: 5, backgroundColor: r2 } } : ``;
}
function dh(e2, t2, n2) {
  (e2 === `week` || e2 === `month` || e2 === `quarter` || e2 === `half-year` || e2 === `year`) && (e2 = `MM-dd
yyyy`);
  var r2 = ts(t2), i2 = n2 ? `getUTC` : `get`, a2 = r2[i2 + `FullYear`](), o2 = r2[i2 + `Month`]() + 1, s2 = r2[i2 + `Date`](), c2 = r2[i2 + `Hours`](), l2 = r2[i2 + `Minutes`](), u2 = r2[i2 + `Seconds`](), d2 = r2[i2 + `Milliseconds`]();
  return e2 = e2.replace(`MM`, Pm(o2, 2)).replace(`M`, o2).replace(`yyyy`, a2).replace(`yy`, Pm(a2 % 100 + ``, 2)).replace(`dd`, Pm(s2, 2)).replace(`d`, s2).replace(`hh`, Pm(c2, 2)).replace(`h`, c2).replace(`mm`, Pm(l2, 2)).replace(`m`, l2).replace(`ss`, Pm(u2, 2)).replace(`s`, u2).replace(`SSS`, Pm(d2, 3)), e2;
}
function fh(e2) {
  return e2 && e2.charAt(0).toUpperCase() + e2.substr(1);
}
function ph(e2, t2) {
  return t2 || (t2 = `transparent`), W(e2) ? e2 : K(e2) && e2.colorStops && (e2.colorStops[0] || {}).color || t2;
}
function mh(e2, t2) {
  if (t2 === `_blank` || t2 === `blank`) {
    var n2 = window.open();
    n2.opener = null, n2.location.href = e2;
  } else window.open(e2, t2);
}
var hh = z, gh = [`left`, `right`, `top`, `bottom`, `width`, `height`], _h = [[`width`, `left`, `right`], [`height`, `top`, `bottom`]];
function vh(e2, t2, n2, r2, i2) {
  var a2 = 0, o2 = 0;
  r2 ?? (r2 = 1 / 0), i2 ?? (i2 = 1 / 0);
  var s2 = 0;
  t2.eachChild(function(c2, l2) {
    var u2 = c2.getBoundingRect(), d2 = t2.childAt(l2 + 1), f2 = d2 && d2.getBoundingRect(), p2, m2;
    if (e2 === `horizontal`) {
      var h2 = u2.width + (f2 ? -f2.x + u2.x : 0);
      p2 = a2 + h2, p2 > r2 || c2.newline ? (a2 = 0, p2 = h2, o2 += s2 + n2, s2 = u2.height) : s2 = Math.max(s2, u2.height);
    } else {
      var g2 = u2.height + (f2 ? -f2.y + u2.y : 0);
      m2 = o2 + g2, m2 > i2 || c2.newline ? (a2 += s2 + n2, o2 = 0, m2 = g2, s2 = u2.width) : s2 = Math.max(s2, u2.width);
    }
    c2.newline || (c2.x = a2, c2.y = o2, c2.markRedraw(), e2 === `horizontal` ? a2 = p2 + n2 : o2 = m2 + n2);
  });
}
var yh = vh;
Xe(vh, `vertical`), Xe(vh, `horizontal`);
function bh(e2, t2, n2) {
  n2 = ah(n2 || 0);
  var r2 = t2.width, i2 = t2.height, a2 = Ho(e2.left, r2), o2 = Ho(e2.top, i2), s2 = Ho(e2.right, r2), c2 = Ho(e2.bottom, i2), l2 = Ho(e2.width, r2), u2 = Ho(e2.height, i2), d2 = n2[2] + n2[0], f2 = n2[1] + n2[3], p2 = e2.aspect;
  switch (isNaN(l2) && (l2 = r2 - s2 - f2 - a2), isNaN(u2) && (u2 = i2 - c2 - d2 - o2), p2 != null && (isNaN(l2) && isNaN(u2) && (p2 > r2 / i2 ? l2 = r2 * 0.8 : u2 = i2 * 0.8), isNaN(l2) && (l2 = p2 * u2), isNaN(u2) && (u2 = l2 / p2)), isNaN(a2) && (a2 = r2 - s2 - l2 - f2), isNaN(o2) && (o2 = i2 - c2 - u2 - d2), e2.left || e2.right) {
    case `center`:
      a2 = r2 / 2 - l2 / 2 - n2[3];
      break;
    case `right`:
      a2 = r2 - l2 - f2;
  }
  switch (e2.top || e2.bottom) {
    case `middle`:
    case `center`:
      o2 = i2 / 2 - u2 / 2 - n2[0];
      break;
    case `bottom`:
      o2 = i2 - u2 - d2;
  }
  a2 || (a2 = 0), o2 || (o2 = 0), isNaN(l2) && (l2 = r2 - f2 - a2 - (s2 || 0)), isNaN(u2) && (u2 = i2 - d2 - o2 - (c2 || 0));
  var m2 = new X(a2 + n2[3], o2 + n2[0], l2, u2);
  return m2.margin = n2, m2;
}
function xh(e2, t2, n2, r2, i2, a2) {
  var o2 = !i2 || !i2.hv || i2.hv[0], s2 = !i2 || !i2.hv || i2.hv[1], c2 = i2 && i2.boundingMode || `all`;
  if (a2 || (a2 = e2), a2.x = e2.x, a2.y = e2.y, !o2 && !s2) return false;
  var l2;
  if (c2 === `raw`) l2 = e2.type === `group` ? new X(0, 0, +t2.width || 0, +t2.height || 0) : e2.getBoundingRect();
  else if (l2 = e2.getBoundingRect(), e2.needLocalTransform()) {
    var u2 = e2.getLocalTransform();
    l2 = l2.clone(), l2.applyTransform(u2);
  }
  var d2 = bh(ze({ width: l2.width, height: l2.height }, t2), n2, r2), f2 = o2 ? d2.x - l2.x : 0, p2 = s2 ? d2.y - l2.y : 0;
  return c2 === `raw` ? (a2.x = f2, a2.y = p2) : (a2.x += f2, a2.y += p2), a2 === e2 && e2.markRedraw(), true;
}
function Sh(e2) {
  var t2 = e2.layoutMode || e2.constructor.layoutMode;
  return K(t2) ? t2 : t2 ? { type: t2 } : null;
}
function Ch(e2, t2, n2) {
  var r2 = n2 && n2.ignoreSize;
  !H(r2) && (r2 = [r2, r2]);
  var i2 = o2(_h[0], 0), a2 = o2(_h[1], 1);
  l2(_h[0], e2, i2), l2(_h[1], e2, a2);
  function o2(n3, i3) {
    var a3 = {}, o3 = 0, l3 = {}, u2 = 0, d2 = 2;
    if (hh(n3, function(t3) {
      l3[t3] = e2[t3];
    }), hh(n3, function(e3) {
      s2(t2, e3) && (a3[e3] = l3[e3] = t2[e3]), c2(a3, e3) && o3++, c2(l3, e3) && u2++;
    }), r2[i3]) return c2(t2, n3[1]) ? l3[n3[2]] = null : c2(t2, n3[2]) && (l3[n3[1]] = null), l3;
    if (u2 === d2 || !o3) return l3;
    if (o3 >= d2) return a3;
    for (var f2 = 0; f2 < n3.length; f2++) {
      var p2 = n3[f2];
      if (!s2(a3, p2) && s2(e2, p2)) {
        a3[p2] = e2[p2];
        break;
      }
    }
    return a3;
  }
  function s2(e3, t3) {
    return e3.hasOwnProperty(t3);
  }
  function c2(e3, t3) {
    return e3[t3] != null && e3[t3] !== `auto`;
  }
  function l2(e3, t3, n3) {
    hh(e3, function(e4) {
      t3[e4] = n3[e4];
    });
  }
}
function wh(e2) {
  return Th({}, e2);
}
function Th(e2, t2) {
  return t2 && e2 && hh(gh, function(n2) {
    t2.hasOwnProperty(n2) && (e2[n2] = t2[n2]);
  }), e2;
}
M();
var Eh = Ls(), $ = (function(e2) {
  s(t2, e2);
  function t2(t3, n2, r2) {
    var i2 = e2.call(this, t3, n2, r2) || this;
    return i2.uid = cm(`ec_cpt_model`), i2;
  }
  return t2.prototype.init = function(e3, t3, n2) {
    this.mergeDefaultAndTheme(e3, n2);
  }, t2.prototype.mergeDefaultAndTheme = function(e3, t3) {
    var n2 = Sh(this), r2 = n2 ? wh(e3) : {};
    Le(e3, t3.getTheme().get(this.mainType)), Le(e3, this.getDefaultOption()), n2 && Ch(e3, r2, n2);
  }, t2.prototype.mergeOption = function(e3, t3) {
    Le(this.option, e3, true);
    var n2 = Sh(this);
    n2 && Ch(this.option, e3, n2);
  }, t2.prototype.optionUpdated = function(e3, t3) {
  }, t2.prototype.getDefaultOption = function() {
    var e3 = this.constructor;
    if (!$s(e3)) return e3.defaultOption;
    var t3 = Eh(this);
    if (!t3.defaultOption) {
      for (var n2 = [], r2 = e3; r2; ) {
        var i2 = r2.prototype.defaultOption;
        i2 && n2.push(i2), r2 = r2.superClass;
      }
      for (var a2 = {}, o2 = n2.length - 1; o2 >= 0; o2--) a2 = Le(a2, n2[o2], true);
      t3.defaultOption = a2;
    }
    return t3.defaultOption;
  }, t2.prototype.getReferringComponents = function(e3, t3) {
    var n2 = e3 + `Index`, r2 = e3 + `Id`;
    return Us(this.ecModel, e3, { index: this.get(n2, true), id: this.get(r2, true) }, t3);
  }, t2.prototype.getBoxLayoutParams = function() {
    var e3 = this;
    return { left: e3.get(`left`), top: e3.get(`top`), right: e3.get(`right`), bottom: e3.get(`bottom`), width: e3.get(`width`), height: e3.get(`height`) };
  }, t2.prototype.getZLevelKey = function() {
    return ``;
  }, t2.prototype.setZLevel = function(e3) {
    this.option.zlevel = e3;
  }, t2.protoInitialize = (function() {
    var e3 = t2.prototype;
    e3.type = `component`, e3.id = ``, e3.name = ``, e3.mainType = ``, e3.subType = ``, e3.componentIndex = 0;
  })(), t2;
})(om);
nc($, om), sc($), lm($), um($, Dh);
function Dh(e2) {
  var t2 = [];
  return z($.getClassesByMainType(e2), function(e3) {
    t2 = t2.concat(e3.dependencies || e3.prototype.dependencies || []);
  }), t2 = B(t2, function(e3) {
    return Zs(e3).main;
  }), e2 !== `dataset` && Ve(t2, `dataset`) <= 0 && t2.unshift(`dataset`), t2;
}
var Oh = ``;
typeof navigator < `u` && (Oh = navigator.platform || ``);
var kh = `rgba(0, 0, 0, 0.2)`, Ah = { darkMode: `auto`, colorBy: `series`, color: [`#5470c6`, `#91cc75`, `#fac858`, `#ee6666`, `#73c0de`, `#3ba272`, `#fc8452`, `#9a60b4`, `#ea7ccc`], gradientColor: [`#f6efa6`, `#d88273`, `#bf444c`], aria: { decal: { decals: [{ color: kh, dashArrayX: [1, 0], dashArrayY: [2, 5], symbolSize: 1, rotation: Math.PI / 6 }, { color: kh, symbol: `circle`, dashArrayX: [[8, 8], [0, 8, 8, 0]], dashArrayY: [6, 0], symbolSize: 0.8 }, { color: kh, dashArrayX: [1, 0], dashArrayY: [4, 3], rotation: -Math.PI / 4 }, { color: kh, dashArrayX: [[6, 6], [0, 6, 6, 0]], dashArrayY: [6, 0] }, { color: kh, dashArrayX: [[1, 0], [1, 6]], dashArrayY: [1, 0, 6, 0], rotation: Math.PI / 4 }, { color: kh, symbol: `triangle`, dashArrayX: [[9, 9], [0, 9, 9, 0]], dashArrayY: [7, 2], symbolSize: 0.75 }] } }, textStyle: { fontFamily: Oh.match(/^Win/) ? `Microsoft YaHei` : `sans-serif`, fontSize: 12, fontStyle: `normal`, fontWeight: `normal` }, blendMode: null, stateAnimation: { duration: 300, easing: `cubicOut` }, animation: `auto`, animationDuration: 1e3, animationDurationUpdate: 500, animationEasing: `cubicInOut`, animationEasingUpdate: `cubicInOut`, animationThreshold: 2e3, progressiveThreshold: 3e3, progressive: 400, hoverLayerThreshold: 3e3, useUTC: false }, jh = J([`tooltip`, `label`, `itemName`, `itemId`, `itemGroupId`, `itemChildGroupId`, `seriesName`]), Mh = `original`, Nh = `arrayRows`, Ph = `objectRows`, Fh = `keyedColumns`, Ih = `typedArray`, Lh = `unknown`, Rh = `column`, zh = { Must: 1, Might: 2, Not: 3 }, Bh = Ls();
function Vh(e2) {
  Bh(e2).datasetMap = J();
}
function Hh(e2, t2, n2) {
  var r2 = {}, i2 = Uh(t2);
  if (!i2 || !e2) return r2;
  var a2 = [], o2 = [], s2 = t2.ecModel, c2 = Bh(s2).datasetMap, l2 = i2.uid + `_` + n2.seriesLayoutBy, u2, d2;
  e2 = e2.slice(), z(e2, function(t3, n3) {
    var i3 = K(t3) ? t3 : e2[n3] = { name: t3 };
    i3.type === `ordinal` && u2 == null && (u2 = n3, d2 = m2(i3)), r2[i3.name] = [];
  });
  var f2 = c2.get(l2) || c2.set(l2, { categoryWayDim: d2, valueWayDim: 0 });
  z(e2, function(e3, t3) {
    var n3 = e3.name, i3 = m2(e3);
    if (u2 == null) {
      var s3 = f2.valueWayDim;
      p2(r2[n3], s3, i3), p2(o2, s3, i3), f2.valueWayDim += i3;
    } else if (u2 === t3) p2(r2[n3], 0, i3), p2(a2, 0, i3);
    else {
      var s3 = f2.categoryWayDim;
      p2(r2[n3], s3, i3), p2(o2, s3, i3), f2.categoryWayDim += i3;
    }
  });
  function p2(e3, t3, n3) {
    for (var r3 = 0; r3 < n3; r3++) e3.push(t3 + r3);
  }
  function m2(e3) {
    var t3 = e3.dimsDef;
    return t3 ? t3.length : 1;
  }
  return a2.length && (r2.itemName = a2), o2.length && (r2.seriesName = o2), r2;
}
function Uh(e2) {
  if (!e2.get(`data`, true)) return Us(e2.ecModel, `dataset`, { index: e2.get(`datasetIndex`, true), id: e2.get(`datasetId`, true) }, Vs).models[0];
}
function Wh(e2) {
  return !e2.get(`transform`, true) && !e2.get(`fromTransformResult`, true) ? [] : Us(e2.ecModel, `dataset`, { index: e2.get(`fromDatasetIndex`, true), id: e2.get(`fromDatasetId`, true) }, Vs).models;
}
function Gh(e2, t2) {
  return Kh(e2.data, e2.sourceFormat, e2.seriesLayoutBy, e2.dimensionsDefine, e2.startIndex, t2);
}
function Kh(e2, t2, n2, r2, i2, a2) {
  var o2, s2 = 5;
  if ($e(e2)) return zh.Not;
  var c2, l2;
  if (r2) {
    var u2 = r2[a2];
    K(u2) ? (c2 = u2.name, l2 = u2.type) : W(u2) && (c2 = u2);
  }
  if (l2 != null) return l2 === `ordinal` ? zh.Must : zh.Not;
  if (t2 === `arrayRows`) {
    var d2 = e2;
    if (n2 === `row`) {
      for (var f2 = d2[a2], p2 = 0; p2 < (f2 || []).length && p2 < s2; p2++) if ((o2 = b2(f2[i2 + p2])) != null) return o2;
    } else for (var p2 = 0; p2 < d2.length && p2 < s2; p2++) {
      var m2 = d2[i2 + p2];
      if (m2 && (o2 = b2(m2[a2])) != null) return o2;
    }
  } else if (t2 === `objectRows`) {
    var h2 = e2;
    if (!c2) return zh.Not;
    for (var p2 = 0; p2 < h2.length && p2 < s2; p2++) {
      var g2 = h2[p2];
      if (g2 && (o2 = b2(g2[c2])) != null) return o2;
    }
  } else if (t2 === `keyedColumns`) {
    var _2 = e2;
    if (!c2) return zh.Not;
    var f2 = _2[c2];
    if (!f2 || $e(f2)) return zh.Not;
    for (var p2 = 0; p2 < f2.length && p2 < s2; p2++) if ((o2 = b2(f2[p2])) != null) return o2;
  } else if (t2 === `original`) for (var v2 = e2, p2 = 0; p2 < v2.length && p2 < s2; p2++) {
    var g2 = v2[p2], y2 = ys(g2);
    if (!H(y2)) return zh.Not;
    if ((o2 = b2(y2[a2])) != null) return o2;
  }
  function b2(e3) {
    var t3 = W(e3);
    if (e3 != null && Number.isFinite(Number(e3)) && e3 !== ``) return t3 ? zh.Might : zh.Not;
    if (t3 && e3 !== `-`) return zh.Must;
  }
  return zh.Not;
}
var qh = J();
function Jh(e2, t2) {
  lt(qh.get(e2) == null && t2), qh.set(e2, t2);
}
function Yh(e2, t2, n2) {
  var r2 = qh.get(t2);
  if (!r2) return n2;
  var i2 = r2(e2);
  return i2 ? n2.concat(i2) : n2;
}
var Xh = Ls();
Ls();
var Zh = (function() {
  function e2() {
  }
  return e2.prototype.getColorFromPalette = function(e3, t2, n2) {
    var r2 = gs(this.get(`color`, true)), i2 = this.get(`colorLayer`, true);
    return $h(this, Xh, r2, i2, e3, t2, n2);
  }, e2.prototype.clearColorPalette = function() {
    eg(this, Xh);
  }, e2;
})();
function Qh(e2, t2) {
  for (var n2 = e2.length, r2 = 0; r2 < n2; r2++) if (e2[r2].length > t2) return e2[r2];
  return e2[n2 - 1];
}
function $h(e2, t2, n2, r2, i2, a2, o2) {
  a2 || (a2 = e2);
  var s2 = t2(a2), c2 = s2.paletteIdx || 0, l2 = s2.paletteNameMap = s2.paletteNameMap || {};
  if (l2.hasOwnProperty(i2)) return l2[i2];
  var u2 = o2 == null || !r2 ? n2 : Qh(r2, o2);
  if (u2 || (u2 = n2), u2 && u2.length) {
    var d2 = u2[c2];
    return i2 && (l2[i2] = d2), s2.paletteIdx = (c2 + 1) % u2.length, d2;
  }
}
function eg(e2, t2) {
  t2(e2).paletteIdx = 0, t2(e2).paletteNameMap = {};
}
M();
var tg, ng, rg, ig = `\0_ec_inner`, ag = 1, og = (function(e2) {
  s(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.init = function(e3, t3, n2, r2, i2, a2) {
    r2 || (r2 = {}), this.option = null, this._theme = new om(r2), this._locale = new om(i2), this._optionManager = a2;
  }, t2.prototype.setOption = function(e3, t3, n2) {
    var r2 = dg(t3);
    this._optionManager.setOption(e3, n2, r2), this._resetOption(null, r2);
  }, t2.prototype.resetOption = function(e3, t3) {
    return this._resetOption(e3, dg(t3));
  }, t2.prototype._resetOption = function(e3, t3) {
    var n2 = false, r2 = this._optionManager;
    if (!e3 || e3 === `recreate`) {
      var i2 = r2.mountOption(e3 === `recreate`);
      !this.option || e3 === `recreate` ? rg(this, i2) : (this.restoreData(), this._mergeOption(i2, t3)), n2 = true;
    }
    if ((e3 === `timeline` || e3 === `media`) && this.restoreData(), !e3 || e3 === `recreate` || e3 === `timeline`) {
      var a2 = r2.getTimelineOption(this);
      a2 && (n2 = true, this._mergeOption(a2, t3));
    }
    if (!e3 || e3 === `recreate` || e3 === `media`) {
      var o2 = r2.getMediaOption(this);
      o2.length && z(o2, function(e4) {
        n2 = true, this._mergeOption(e4, t3);
      }, this);
    }
    return n2;
  }, t2.prototype.mergeOption = function(e3) {
    this._mergeOption(e3, null);
  }, t2.prototype._mergeOption = function(e3, t3) {
    var n2 = this.option, r2 = this._componentsMap, i2 = this._componentsCount, a2 = [], o2 = J(), s2 = t3 && t3.replaceMergeMainTypeMap;
    Vh(this), z(e3, function(e4, t4) {
      e4 != null && ($.hasClass(t4) ? t4 && (a2.push(t4), o2.set(t4, true)) : n2[t4] = n2[t4] == null ? L(e4) : Le(n2[t4], e4, true));
    }), s2 && s2.each(function(e4, t4) {
      $.hasClass(t4) && !o2.get(t4) && (a2.push(t4), o2.set(t4, true));
    }), $.topologicalTravel(a2, $.getAllClassMainTypes(), c2, this);
    function c2(t4) {
      var a3 = Yh(this, t4, gs(e3[t4])), o3 = r2.get(t4), c3 = xs(o3, a3, o3 ? s2 && s2.get(t4) ? `replaceMerge` : `normalMerge` : `replaceAll`);
      Ps(c3, t4, $), n2[t4] = null, r2.set(t4, null), i2.set(t4, 0);
      var l2 = [], u2 = [], d2 = 0, f2;
      z(c3, function(e4, n3) {
        var r3 = e4.existing, i3 = e4.newOption;
        if (!i3) r3 && (r3.mergeOption({}, this), r3.optionUpdated({}, false));
        else {
          var a4 = t4 === `series`, o4 = $.getClass(t4, e4.keyInfo.subType, !a4);
          if (!o4) return;
          if (t4 === `tooltip`) {
            if (f2) return;
            f2 = true;
          }
          if (r3 && r3.constructor === o4) r3.name = e4.keyInfo.name, r3.mergeOption(i3, this), r3.optionUpdated(i3, false);
          else {
            var s3 = R({ componentIndex: n3 }, e4.keyInfo);
            r3 = new o4(i3, this, this, s3), R(r3, s3), e4.brandNew && (r3.__requireNewView = true), r3.init(i3, this, this), r3.optionUpdated(null, true);
          }
        }
        r3 ? (l2.push(r3.option), u2.push(r3), d2++) : (l2.push(void 0), u2.push(void 0));
      }, this), n2[t4] = l2, r2.set(t4, u2), i2.set(t4, d2), t4 === `series` && tg(this);
    }
    this._seriesIndices || tg(this);
  }, t2.prototype.getOption = function() {
    var e3 = L(this.option);
    return z(e3, function(t3, n2) {
      if ($.hasClass(n2)) {
        for (var r2 = gs(t3), i2 = r2.length, a2 = false, o2 = i2 - 1; o2 >= 0; o2--) r2[o2] && !Ms(r2[o2]) ? a2 = true : (r2[o2] = null, !a2 && i2--);
        r2.length = i2, e3[n2] = r2;
      }
    }), delete e3[ig], e3;
  }, t2.prototype.getTheme = function() {
    return this._theme;
  }, t2.prototype.getLocaleModel = function() {
    return this._locale;
  }, t2.prototype.setUpdatePayload = function(e3) {
    this._payload = e3;
  }, t2.prototype.getUpdatePayload = function() {
    return this._payload;
  }, t2.prototype.getComponent = function(e3, t3) {
    var n2 = this._componentsMap.get(e3);
    if (n2) {
      var r2 = n2[t3 || 0];
      if (r2) return r2;
      if (t3 == null) {
        for (var i2 = 0; i2 < n2.length; i2++) if (n2[i2]) return n2[i2];
      }
    }
  }, t2.prototype.queryComponents = function(e3) {
    var t3 = e3.mainType;
    if (!t3) return [];
    var n2 = e3.index, r2 = e3.id, i2 = e3.name, a2 = this._componentsMap.get(t3);
    if (!a2 || !a2.length) return [];
    var o2;
    return n2 == null ? o2 = r2 == null ? i2 == null ? Ke(a2, function(e4) {
      return !!e4;
    }) : lg(`name`, i2, a2) : lg(`id`, r2, a2) : (o2 = [], z(gs(n2), function(e4) {
      a2[e4] && o2.push(a2[e4]);
    })), ug(o2, e3);
  }, t2.prototype.findComponents = function(e3) {
    var t3 = e3.query, n2 = e3.mainType, r2 = i2(t3);
    return a2(ug(r2 ? this.queryComponents(r2) : Ke(this._componentsMap.get(n2), function(e4) {
      return !!e4;
    }), e3));
    function i2(e4) {
      var t4 = n2 + `Index`, r3 = n2 + `Id`, i3 = n2 + `Name`;
      return e4 && (e4[t4] != null || e4[r3] != null || e4[i3] != null) ? { mainType: n2, index: e4[t4], id: e4[r3], name: e4[i3] } : null;
    }
    function a2(t4) {
      return e3.filter ? Ke(t4, e3.filter) : t4;
    }
  }, t2.prototype.eachComponent = function(e3, t3, n2) {
    var r2 = this._componentsMap;
    if (U(e3)) {
      var i2 = t3, a2 = e3;
      r2.each(function(e4, t4) {
        for (var n3 = 0; e4 && n3 < e4.length; n3++) {
          var r3 = e4[n3];
          r3 && a2.call(i2, t4, r3, r3.componentIndex);
        }
      });
    } else for (var o2 = W(e3) ? r2.get(e3) : K(e3) ? this.findComponents(e3) : null, s2 = 0; o2 && s2 < o2.length; s2++) {
      var c2 = o2[s2];
      c2 && t3.call(n2, c2, c2.componentIndex);
    }
  }, t2.prototype.getSeriesByName = function(e3) {
    var t3 = As(e3, null);
    return Ke(this._componentsMap.get(`series`), function(e4) {
      return !!e4 && t3 != null && e4.name === t3;
    });
  }, t2.prototype.getSeriesByIndex = function(e3) {
    return this._componentsMap.get(`series`)[e3];
  }, t2.prototype.getSeriesByType = function(e3) {
    return Ke(this._componentsMap.get(`series`), function(t3) {
      return !!t3 && t3.subType === e3;
    });
  }, t2.prototype.getSeries = function() {
    return Ke(this._componentsMap.get(`series`), function(e3) {
      return !!e3;
    });
  }, t2.prototype.getSeriesCount = function() {
    return this._componentsCount.get(`series`);
  }, t2.prototype.eachSeries = function(e3, t3) {
    ng(this), z(this._seriesIndices, function(n2) {
      var r2 = this._componentsMap.get(`series`)[n2];
      e3.call(t3, r2, n2);
    }, this);
  }, t2.prototype.eachRawSeries = function(e3, t3) {
    z(this._componentsMap.get(`series`), function(n2) {
      n2 && e3.call(t3, n2, n2.componentIndex);
    });
  }, t2.prototype.eachSeriesByType = function(e3, t3, n2) {
    ng(this), z(this._seriesIndices, function(r2) {
      var i2 = this._componentsMap.get(`series`)[r2];
      i2.subType === e3 && t3.call(n2, i2, r2);
    }, this);
  }, t2.prototype.eachRawSeriesByType = function(e3, t3, n2) {
    return z(this.getSeriesByType(e3), t3, n2);
  }, t2.prototype.isSeriesFiltered = function(e3) {
    return ng(this), this._seriesIndicesMap.get(e3.componentIndex) == null;
  }, t2.prototype.getCurrentSeriesIndices = function() {
    return (this._seriesIndices || []).slice();
  }, t2.prototype.filterSeries = function(e3, t3) {
    ng(this);
    var n2 = [];
    z(this._seriesIndices, function(r2) {
      var i2 = this._componentsMap.get(`series`)[r2];
      e3.call(t3, i2, r2) && n2.push(r2);
    }, this), this._seriesIndices = n2, this._seriesIndicesMap = J(n2);
  }, t2.prototype.restoreData = function(e3) {
    tg(this);
    var t3 = this._componentsMap, n2 = [];
    t3.each(function(e4, t4) {
      $.hasClass(t4) && n2.push(t4);
    }), $.topologicalTravel(n2, $.getAllClassMainTypes(), function(n3) {
      z(t3.get(n3), function(t4) {
        t4 && (n3 !== `series` || !sg(t4, e3)) && t4.restoreData();
      });
    });
  }, t2.internalField = (function() {
    tg = function(e3) {
      var t3 = e3._seriesIndices = [];
      z(e3._componentsMap.get(`series`), function(e4) {
        e4 && t3.push(e4.componentIndex);
      }), e3._seriesIndicesMap = J(t3);
    }, ng = function(e3) {
    }, rg = function(e3, t3) {
      e3.option = {}, e3.option[ig] = ag, e3._componentsMap = J({ series: [] }), e3._componentsCount = J();
      var n2 = t3.aria;
      K(n2) && n2.enabled == null && (n2.enabled = true), cg(t3, e3._theme.option), Le(t3, Ah, false), e3._mergeOption(t3, null);
    };
  })(), t2;
})(om);
function sg(e2, t2) {
  if (t2) {
    var n2 = t2.seriesIndex, r2 = t2.seriesId, i2 = t2.seriesName;
    return n2 != null && e2.componentIndex !== n2 || r2 != null && e2.id !== r2 || i2 != null && e2.name !== i2;
  }
}
function cg(e2, t2) {
  var n2 = e2.color && !e2.colorLayer;
  z(t2, function(t3, r2) {
    r2 === `colorLayer` && n2 || $.hasClass(r2) || (typeof t3 == `object` ? e2[r2] = e2[r2] ? Le(e2[r2], t3, false) : L(t3) : e2[r2] ?? (e2[r2] = t3));
  });
}
function lg(e2, t2, n2) {
  if (H(t2)) {
    var r2 = J();
    return z(t2, function(e3) {
      e3 != null && As(e3, null) != null && r2.set(e3, true);
    }), Ke(n2, function(t3) {
      return t3 && r2.get(t3[e2]);
    });
  }
  var i2 = As(t2, null);
  return Ke(n2, function(t3) {
    return t3 && i2 != null && t3[e2] === i2;
  });
}
function ug(e2, t2) {
  return t2.hasOwnProperty(`subType`) ? Ke(e2, function(e3) {
    return e3 && e3.subType === t2.subType;
  }) : e2;
}
function dg(e2) {
  var t2 = J();
  return e2 && z(gs(e2.replaceMerge), function(e3) {
    t2.set(e3, true);
  }), { replaceMergeMainTypeMap: t2 };
}
Ue(og, Zh);
var fg = [`getDom`, `getZr`, `getWidth`, `getHeight`, `getDevicePixelRatio`, `dispatchAction`, `isSSR`, `isDisposed`, `on`, `off`, `getDataURL`, `getConnectedDataURL`, `getOption`, `getId`, `updateLabelLayout`], pg = /* @__PURE__ */ (function() {
  function e2(e3) {
    z(fg, function(t2) {
      this[t2] = Ye(e3[t2], e3);
    }, this);
  }
  return e2;
})(), mg = {}, hg = (function() {
  function e2() {
    this._coordinateSystems = [];
  }
  return e2.prototype.create = function(e3, t2) {
    var n2 = [];
    z(mg, function(r2, i2) {
      var a2 = r2.create(e3, t2);
      n2 = n2.concat(a2 || []);
    }), this._coordinateSystems = n2;
  }, e2.prototype.update = function(e3, t2) {
    z(this._coordinateSystems, function(n2) {
      n2.update && n2.update(e3, t2);
    });
  }, e2.prototype.getCoordinateSystems = function() {
    return this._coordinateSystems.slice();
  }, e2.register = function(e3, t2) {
    mg[e3] = t2;
  }, e2.get = function(e3) {
    return mg[e3];
  }, e2;
})(), gg = /^(min|max)?(.+)$/, _g = (function() {
  function e2(e3) {
    this._timelineOptions = [], this._mediaList = [], this._currentMediaIndices = [], this._api = e3;
  }
  return e2.prototype.setOption = function(e3, t2, n2) {
    e3 && (z(gs(e3.series), function(e4) {
      e4 && e4.data && $e(e4.data) && ft(e4.data);
    }), z(gs(e3.dataset), function(e4) {
      e4 && e4.source && $e(e4.source) && ft(e4.source);
    })), e3 = L(e3);
    var r2 = this._optionBackup, i2 = vg(e3, t2, !r2);
    this._newBaseOption = i2.baseOption, r2 ? (i2.timelineOptions.length && (r2.timelineOptions = i2.timelineOptions), i2.mediaList.length && (r2.mediaList = i2.mediaList), i2.mediaDefault && (r2.mediaDefault = i2.mediaDefault)) : this._optionBackup = i2;
  }, e2.prototype.mountOption = function(e3) {
    var t2 = this._optionBackup;
    return this._timelineOptions = t2.timelineOptions, this._mediaList = t2.mediaList, this._mediaDefault = t2.mediaDefault, this._currentMediaIndices = [], L(e3 ? t2.baseOption : this._newBaseOption);
  }, e2.prototype.getTimelineOption = function(e3) {
    var t2, n2 = this._timelineOptions;
    if (n2.length) {
      var r2 = e3.getComponent(`timeline`);
      r2 && (t2 = L(n2[r2.getCurrentIndex()]));
    }
    return t2;
  }, e2.prototype.getMediaOption = function(e3) {
    var t2 = this._api.getWidth(), n2 = this._api.getHeight(), r2 = this._mediaList, i2 = this._mediaDefault, a2 = [], o2 = [];
    if (!r2.length && !i2) return o2;
    for (var s2 = 0, c2 = r2.length; s2 < c2; s2++) yg(r2[s2].query, t2, n2) && a2.push(s2);
    return !a2.length && i2 && (a2 = [-1]), a2.length && !xg(a2, this._currentMediaIndices) && (o2 = B(a2, function(e4) {
      return L(e4 === -1 ? i2.option : r2[e4].option);
    })), this._currentMediaIndices = a2, o2;
  }, e2;
})();
function vg(e2, t2, n2) {
  var r2 = [], i2, a2, o2 = e2.baseOption, s2 = e2.timeline, c2 = e2.options, l2 = e2.media, u2 = !!e2.media, d2 = !!(c2 || s2 || o2 && o2.timeline);
  o2 ? (a2 = o2, a2.timeline || (a2.timeline = s2)) : ((d2 || u2) && (e2.options = e2.media = null), a2 = e2), u2 && H(l2) && z(l2, function(e3) {
    e3 && e3.option && (e3.query ? r2.push(e3) : i2 || (i2 = e3));
  }), f2(a2), z(c2, function(e3) {
    return f2(e3);
  }), z(r2, function(e3) {
    return f2(e3.option);
  });
  function f2(e3) {
    z(t2, function(t3) {
      t3(e3, n2);
    });
  }
  return { baseOption: a2, timelineOptions: c2 || [], mediaDefault: i2, mediaList: r2 };
}
function yg(e2, t2, n2) {
  var r2 = { width: t2, height: n2, aspectratio: t2 / n2 }, i2 = true;
  return z(e2, function(e3, t3) {
    var n3 = t3.match(gg);
    if (n3 && n3[1] && n3[2]) {
      var a2 = n3[1];
      bg(r2[n3[2].toLowerCase()], e3, a2) || (i2 = false);
    }
  }), i2;
}
function bg(e2, t2, n2) {
  return n2 === `min` ? e2 >= t2 : n2 === `max` ? e2 <= t2 : e2 === t2;
}
function xg(e2, t2) {
  return e2.join(`,`) === t2.join(`,`);
}
var Sg = z, Cg = K, wg = [`areaStyle`, `lineStyle`, `nodeStyle`, `linkStyle`, `chordStyle`, `label`, `labelLine`];
function Tg(e2) {
  var t2 = e2 && e2.itemStyle;
  if (t2) for (var n2 = 0, r2 = wg.length; n2 < r2; n2++) {
    var i2 = wg[n2], a2 = t2.normal, o2 = t2.emphasis;
    a2 && a2[i2] && (e2[i2] = e2[i2] || {}, e2[i2].normal ? Le(e2[i2].normal, a2[i2]) : e2[i2].normal = a2[i2], a2[i2] = null), o2 && o2[i2] && (e2[i2] = e2[i2] || {}, e2[i2].emphasis ? Le(e2[i2].emphasis, o2[i2]) : e2[i2].emphasis = o2[i2], o2[i2] = null);
  }
}
function Eg(e2, t2, n2) {
  if (e2 && e2[t2] && (e2[t2].normal || e2[t2].emphasis)) {
    var r2 = e2[t2].normal, i2 = e2[t2].emphasis;
    r2 && (n2 ? (e2[t2].normal = e2[t2].emphasis = null, ze(e2[t2], r2)) : e2[t2] = r2), i2 && (e2.emphasis = e2.emphasis || {}, e2.emphasis[t2] = i2, i2.focus && (e2.emphasis.focus = i2.focus), i2.blurScope && (e2.emphasis.blurScope = i2.blurScope));
  }
}
function Dg(e2) {
  Eg(e2, `itemStyle`), Eg(e2, `lineStyle`), Eg(e2, `areaStyle`), Eg(e2, `label`), Eg(e2, `labelLine`), Eg(e2, `upperLabel`), Eg(e2, `edgeLabel`);
}
function Og(e2, t2) {
  var n2 = Cg(e2) && e2[t2], r2 = Cg(n2) && n2.textStyle;
  if (r2) for (var i2 = 0, a2 = vs.length; i2 < a2; i2++) {
    var o2 = vs[i2];
    r2.hasOwnProperty(o2) && (n2[o2] = r2[o2]);
  }
}
function kg(e2) {
  e2 && (Dg(e2), Og(e2, `label`), e2.emphasis && Og(e2.emphasis, `label`));
}
function Ag(e2) {
  if (Cg(e2)) {
    Tg(e2), Dg(e2), Og(e2, `label`), Og(e2, `upperLabel`), Og(e2, `edgeLabel`), e2.emphasis && (Og(e2.emphasis, `label`), Og(e2.emphasis, `upperLabel`), Og(e2.emphasis, `edgeLabel`));
    var t2 = e2.markPoint;
    t2 && (Tg(t2), kg(t2));
    var n2 = e2.markLine;
    n2 && (Tg(n2), kg(n2));
    var r2 = e2.markArea;
    r2 && kg(r2);
    var i2 = e2.data;
    if (e2.type === `graph`) {
      i2 || (i2 = e2.nodes);
      var a2 = e2.links || e2.edges;
      if (a2 && !$e(a2)) for (var o2 = 0; o2 < a2.length; o2++) kg(a2[o2]);
      z(e2.categories, function(e3) {
        Dg(e3);
      });
    }
    if (i2 && !$e(i2)) for (var o2 = 0; o2 < i2.length; o2++) kg(i2[o2]);
    if (t2 = e2.markPoint, t2 && t2.data) for (var s2 = t2.data, o2 = 0; o2 < s2.length; o2++) kg(s2[o2]);
    if (n2 = e2.markLine, n2 && n2.data) for (var c2 = n2.data, o2 = 0; o2 < c2.length; o2++) H(c2[o2]) ? (kg(c2[o2][0]), kg(c2[o2][1])) : kg(c2[o2]);
    e2.type === `gauge` ? (Og(e2, `axisLabel`), Og(e2, `title`), Og(e2, `detail`)) : e2.type === `treemap` ? (Eg(e2.breadcrumb, `itemStyle`), z(e2.levels, function(e3) {
      Dg(e3);
    })) : e2.type === `tree` && Dg(e2.leaves);
  }
}
function jg(e2) {
  return H(e2) ? e2 : e2 ? [e2] : [];
}
function Mg(e2) {
  return (H(e2) ? e2[0] : e2) || {};
}
function Ng(e2, t2) {
  Sg(jg(e2.series), function(e3) {
    Cg(e3) && Ag(e3);
  });
  var n2 = [`xAxis`, `yAxis`, `radiusAxis`, `angleAxis`, `singleAxis`, `parallelAxis`, `radar`];
  t2 && n2.push(`valueAxis`, `categoryAxis`, `logAxis`, `timeAxis`), Sg(n2, function(t3) {
    Sg(jg(e2[t3]), function(e3) {
      e3 && (Og(e3, `axisLabel`), Og(e3.axisPointer, `label`));
    });
  }), Sg(jg(e2.parallel), function(e3) {
    var t3 = e3 && e3.parallelAxisDefault;
    Og(t3, `axisLabel`), Og(t3 && t3.axisPointer, `label`);
  }), Sg(jg(e2.calendar), function(e3) {
    Eg(e3, `itemStyle`), Og(e3, `dayLabel`), Og(e3, `monthLabel`), Og(e3, `yearLabel`);
  }), Sg(jg(e2.radar), function(e3) {
    Og(e3, `name`), e3.name && e3.axisName == null && (e3.axisName = e3.name, delete e3.name), e3.nameGap != null && e3.axisNameGap == null && (e3.axisNameGap = e3.nameGap, delete e3.nameGap);
  }), Sg(jg(e2.geo), function(e3) {
    Cg(e3) && (kg(e3), Sg(jg(e3.regions), function(e4) {
      kg(e4);
    }));
  }), Sg(jg(e2.timeline), function(e3) {
    kg(e3), Eg(e3, `label`), Eg(e3, `itemStyle`), Eg(e3, `controlStyle`, true);
    var t3 = e3.data;
    H(t3) && z(t3, function(e4) {
      K(e4) && (Eg(e4, `label`), Eg(e4, `itemStyle`));
    });
  }), Sg(jg(e2.toolbox), function(e3) {
    Eg(e3, `iconStyle`), Sg(e3.feature, function(e4) {
      Eg(e4, `iconStyle`);
    });
  }), Og(Mg(e2.axisPointer), `label`), Og(Mg(e2.tooltip).axisPointer, `label`);
}
function Pg(e2, t2) {
  for (var n2 = t2.split(`,`), r2 = e2, i2 = 0; i2 < n2.length && (r2 && (r2 = r2[n2[i2]]), r2 != null); i2++) ;
  return r2;
}
function Fg(e2, t2, n2, r2) {
  for (var i2 = t2.split(`,`), a2 = e2, o2, s2 = 0; s2 < i2.length - 1; s2++) o2 = i2[s2], a2[o2] ?? (a2[o2] = {}), a2 = a2[o2];
  (r2 || a2[i2[s2]] == null) && (a2[i2[s2]] = n2);
}
function Ig(e2) {
  e2 && z(Lg, function(t2) {
    t2[0] in e2 && !(t2[1] in e2) && (e2[t2[1]] = e2[t2[0]]);
  });
}
var Lg = [[`x`, `left`], [`y`, `top`], [`x2`, `right`], [`y2`, `bottom`]], Rg = [`grid`, `geo`, `parallel`, `legend`, `toolbox`, `title`, `visualMap`, `dataZoom`, `timeline`], zg = [[`borderRadius`, `barBorderRadius`], [`borderColor`, `barBorderColor`], [`borderWidth`, `barBorderWidth`]];
function Bg(e2) {
  var t2 = e2 && e2.itemStyle;
  if (t2) for (var n2 = 0; n2 < zg.length; n2++) {
    var r2 = zg[n2][1], i2 = zg[n2][0];
    t2[r2] != null && (t2[i2] = t2[r2]);
  }
}
function Vg(e2) {
  e2 && e2.alignTo === `edge` && e2.margin != null && e2.edgeDistance == null && (e2.edgeDistance = e2.margin);
}
function Hg(e2) {
  e2 && e2.downplay && !e2.blur && (e2.blur = e2.downplay);
}
function Ug(e2) {
  e2 && e2.focusNodeAdjacency != null && (e2.emphasis = e2.emphasis || {}, e2.emphasis.focus ?? (e2.emphasis.focus = `adjacency`));
}
function Wg(e2, t2) {
  if (e2) for (var n2 = 0; n2 < e2.length; n2++) t2(e2[n2]), e2[n2] && Wg(e2[n2].children, t2);
}
function Gg(e2, t2) {
  Ng(e2, t2), e2.series = gs(e2.series), z(e2.series, function(e3) {
    if (K(e3)) {
      var t3 = e3.type;
      if (t3 === `line`) e3.clipOverflow != null && (e3.clip = e3.clipOverflow);
      else if (t3 === `pie` || t3 === `gauge`) {
        e3.clockWise != null && (e3.clockwise = e3.clockWise), Vg(e3.label);
        var n2 = e3.data;
        if (n2 && !$e(n2)) for (var r2 = 0; r2 < n2.length; r2++) Vg(n2[r2]);
        e3.hoverOffset != null && (e3.emphasis = e3.emphasis || {}, (e3.emphasis.scaleSize = null) && (e3.emphasis.scaleSize = e3.hoverOffset));
      } else if (t3 === `gauge`) {
        var i2 = Pg(e3, `pointer.color`);
        i2 != null && Fg(e3, `itemStyle.color`, i2);
      } else if (t3 === `bar`) {
        Bg(e3), Bg(e3.backgroundStyle), Bg(e3.emphasis);
        var n2 = e3.data;
        if (n2 && !$e(n2)) for (var r2 = 0; r2 < n2.length; r2++) typeof n2[r2] == `object` && (Bg(n2[r2]), Bg(n2[r2] && n2[r2].emphasis));
      } else if (t3 === `sunburst`) {
        var a2 = e3.highlightPolicy;
        a2 && (e3.emphasis = e3.emphasis || {}, e3.emphasis.focus || (e3.emphasis.focus = a2)), Hg(e3), Wg(e3.data, Hg);
      } else t3 === `graph` || t3 === `sankey` ? Ug(e3) : t3 === `map` && (e3.mapType && !e3.map && (e3.map = e3.mapType), e3.mapLocation && ze(e3, e3.mapLocation));
      e3.hoverAnimation != null && (e3.emphasis = e3.emphasis || {}, e3.emphasis && e3.emphasis.scale == null && (e3.emphasis.scale = e3.hoverAnimation)), Ig(e3);
    }
  }), e2.dataRange && (e2.visualMap = e2.dataRange), z(Rg, function(t3) {
    var n2 = e2[t3];
    n2 && (H(n2) || (n2 = [n2]), z(n2, function(e3) {
      Ig(e3);
    }));
  });
}
function Kg(e2) {
  var t2 = J();
  e2.eachSeries(function(e3) {
    var n2 = e3.get(`stack`);
    if (n2) {
      var r2 = t2.get(n2) || t2.set(n2, []), i2 = e3.getData(), a2 = { stackResultDimension: i2.getCalculationInfo(`stackResultDimension`), stackedOverDimension: i2.getCalculationInfo(`stackedOverDimension`), stackedDimension: i2.getCalculationInfo(`stackedDimension`), stackedByDimension: i2.getCalculationInfo(`stackedByDimension`), isStackedByIndex: i2.getCalculationInfo(`isStackedByIndex`), data: i2, seriesModel: e3 };
      if (!a2.stackedDimension || !(a2.isStackedByIndex || a2.stackedByDimension)) return;
      r2.length && i2.setCalculationInfo(`stackedOnSeries`, r2[r2.length - 1].seriesModel), r2.push(a2);
    }
  }), t2.each(qg);
}
function qg(e2) {
  z(e2, function(t2, n2) {
    var r2 = [], i2 = [NaN, NaN], a2 = [t2.stackResultDimension, t2.stackedOverDimension], o2 = t2.data, s2 = t2.isStackedByIndex, c2 = t2.seriesModel.get(`stackStrategy`) || `samesign`;
    o2.modify(a2, function(a3, l2, u2) {
      var d2 = o2.get(t2.stackedDimension, u2);
      if (isNaN(d2)) return i2;
      var f2, p2;
      s2 ? p2 = o2.getRawIndex(u2) : f2 = o2.get(t2.stackedByDimension, u2);
      for (var m2 = NaN, h2 = n2 - 1; h2 >= 0; h2--) {
        var g2 = e2[h2];
        if (s2 || (p2 = g2.data.rawIndexOf(g2.stackedByDimension, f2)), p2 >= 0) {
          var _2 = g2.data.getByRawIndex(g2.stackResultDimension, p2);
          if (c2 === `all` || c2 === `positive` && _2 > 0 || c2 === `negative` && _2 < 0 || c2 === `samesign` && d2 >= 0 && _2 > 0 || c2 === `samesign` && d2 <= 0 && _2 < 0) {
            d2 = Xo(d2, _2), m2 = _2;
            break;
          }
        }
      }
      return r2[0] = d2, r2[1] = m2, r2;
    });
  });
}
var Jg = /* @__PURE__ */ (function() {
  function e2(e3) {
    this.data = e3.data || (e3.sourceFormat === `keyedColumns` ? {} : []), this.sourceFormat = e3.sourceFormat || `unknown`, this.seriesLayoutBy = e3.seriesLayoutBy || `column`, this.startIndex = e3.startIndex || 0, this.dimensionsDetectedCount = e3.dimensionsDetectedCount, this.metaRawOption = e3.metaRawOption;
    var t2 = this.dimensionsDefine = e3.dimensionsDefine;
    if (t2) for (var n2 = 0; n2 < t2.length; n2++) {
      var r2 = t2[n2];
      r2.type == null && Gh(this, n2) === zh.Must && (r2.type = `ordinal`);
    }
  }
  return e2;
})();
function Yg(e2) {
  return e2 instanceof Jg;
}
function Xg(e2, t2, n2) {
  n2 || (n2 = $g(e2));
  var r2 = t2.seriesLayoutBy, i2 = e_(e2, n2, r2, t2.sourceHeader, t2.dimensions);
  return new Jg({ data: e2, sourceFormat: n2, seriesLayoutBy: r2, dimensionsDefine: i2.dimensionsDefine, startIndex: i2.startIndex, dimensionsDetectedCount: i2.dimensionsDetectedCount, metaRawOption: L(t2) });
}
function Zg(e2) {
  return new Jg({ data: e2, sourceFormat: $e(e2) ? Ih : Mh });
}
function Qg(e2) {
  return new Jg({ data: e2.data, sourceFormat: e2.sourceFormat, seriesLayoutBy: e2.seriesLayoutBy, dimensionsDefine: L(e2.dimensionsDefine), startIndex: e2.startIndex, dimensionsDetectedCount: e2.dimensionsDetectedCount });
}
function $g(e2) {
  var t2 = Lh;
  if ($e(e2)) t2 = Ih;
  else if (H(e2)) {
    e2.length === 0 && (t2 = Nh);
    for (var n2 = 0, r2 = e2.length; n2 < r2; n2++) {
      var i2 = e2[n2];
      if (i2 != null) {
        if (H(i2) || $e(i2)) {
          t2 = Nh;
          break;
        }
        if (K(i2)) {
          t2 = Ph;
          break;
        }
      }
    }
  } else if (K(e2)) {
    for (var a2 in e2) if (xt(e2, a2) && We(e2[a2])) {
      t2 = Fh;
      break;
    }
  }
  return t2;
}
function e_(e2, t2, n2, r2, i2) {
  var a2, o2;
  if (!e2) return { dimensionsDefine: n_(i2), startIndex: o2, dimensionsDetectedCount: a2 };
  if (t2 === `arrayRows`) {
    var s2 = e2;
    r2 === `auto` || r2 == null ? r_(function(e3) {
      e3 != null && e3 !== `-` && (W(e3) ? o2 ?? (o2 = 1) : o2 = 0);
    }, n2, s2, 10) : o2 = G(r2) ? r2 : +!!r2, !i2 && o2 === 1 && (i2 = [], r_(function(e3, t3) {
      i2[t3] = e3 == null ? `` : e3 + ``;
    }, n2, s2, 1 / 0)), a2 = i2 ? i2.length : n2 === `row` ? s2.length : s2[0] ? s2[0].length : null;
  } else if (t2 === `objectRows`) i2 || (i2 = t_(e2));
  else if (t2 === `keyedColumns`) i2 || (i2 = [], z(e2, function(e3, t3) {
    i2.push(t3);
  }));
  else if (t2 === `original`) {
    var c2 = ys(e2[0]);
    a2 = H(c2) && c2.length || 1;
  }
  return { startIndex: o2, dimensionsDefine: n_(i2), dimensionsDetectedCount: a2 };
}
function t_(e2) {
  for (var t2 = 0, n2; t2 < e2.length && !(n2 = e2[t2++]); ) ;
  if (n2) return V(n2);
}
function n_(e2) {
  if (e2) {
    var t2 = J();
    return B(e2, function(e3, n2) {
      e3 = K(e3) ? e3 : { name: e3 };
      var r2 = { name: e3.name, displayName: e3.displayName, type: e3.type };
      if (r2.name == null) return r2;
      r2.name += ``, r2.displayName ?? (r2.displayName = r2.name);
      var i2 = t2.get(r2.name);
      return i2 ? r2.name += `-` + i2.count++ : t2.set(r2.name, { count: 1 }), r2;
    });
  }
}
function r_(e2, t2, n2, r2) {
  if (t2 === `row`) for (var i2 = 0; i2 < n2.length && i2 < r2; i2++) e2(n2[i2] ? n2[i2][0] : null, i2);
  else for (var a2 = n2[0] || [], i2 = 0; i2 < a2.length && i2 < r2; i2++) e2(a2[i2], i2);
}
function i_(e2) {
  var t2 = e2.sourceFormat;
  return t2 === `objectRows` || t2 === `keyedColumns`;
}
var a_, o_, s_, c_, l_, u_ = (function() {
  function e2(e3, t2) {
    var n2 = Yg(e3) ? e3 : Zg(e3);
    this._source = n2;
    var r2 = this._data = n2.data;
    n2.sourceFormat === `typedArray` && (this._offset = 0, this._dimSize = t2, this._data = r2), l_(this, r2, n2);
  }
  return e2.prototype.getSource = function() {
    return this._source;
  }, e2.prototype.count = function() {
    return 0;
  }, e2.prototype.getItem = function(e3, t2) {
  }, e2.prototype.appendData = function(e3) {
  }, e2.prototype.clean = function() {
  }, e2.protoInitialize = (function() {
    var t2 = e2.prototype;
    t2.pure = false, t2.persistent = true;
  })(), e2.internalField = (function() {
    var e3;
    l_ = function(e4, i3, a2) {
      var o2 = a2.sourceFormat, s2 = a2.seriesLayoutBy, c2 = a2.startIndex, l2 = a2.dimensionsDefine, u2 = c_[b_(o2, s2)];
      R(e4, u2), o2 === `typedArray` ? (e4.getItem = t2, e4.count = r2, e4.fillStorage = n2) : (e4.getItem = Ye(p_(o2, s2), null, i3, c2, l2), e4.count = Ye(g_(o2, s2), null, i3, c2, l2));
    };
    var t2 = function(e4, t3) {
      e4 -= this._offset, t3 || (t3 = []);
      for (var n3 = this._data, r3 = this._dimSize, i3 = r3 * e4, a2 = 0; a2 < r3; a2++) t3[a2] = n3[i3 + a2];
      return t3;
    }, n2 = function(e4, t3, n3, r3) {
      for (var i3 = this._data, a2 = this._dimSize, o2 = 0; o2 < a2; o2++) {
        for (var s2 = r3[o2], c2 = s2[0] == null ? 1 / 0 : s2[0], l2 = s2[1] == null ? -1 / 0 : s2[1], u2 = t3 - e4, d2 = n3[o2], f2 = 0; f2 < u2; f2++) {
          var p2 = i3[f2 * a2 + o2];
          d2[e4 + f2] = p2, p2 < c2 && (c2 = p2), p2 > l2 && (l2 = p2);
        }
        s2[0] = c2, s2[1] = l2;
      }
    }, r2 = function() {
      return this._data ? this._data.length / this._dimSize : 0;
    };
    c_ = (e3 = {}, e3[Nh + `_` + Rh] = { pure: true, appendData: i2 }, e3[Nh + `_row`] = { pure: true, appendData: function() {
      throw Error(`Do not support appendData when set seriesLayoutBy: "row".`);
    } }, e3[Ph] = { pure: true, appendData: i2 }, e3[Fh] = { pure: true, appendData: function(e4) {
      var t3 = this._data;
      z(e4, function(e5, n3) {
        for (var r3 = t3[n3] || (t3[n3] = []), i3 = 0; i3 < (e5 || []).length; i3++) r3.push(e5[i3]);
      });
    } }, e3[Mh] = { appendData: i2 }, e3[Ih] = { persistent: false, pure: true, appendData: function(e4) {
      this._data = e4;
    }, clean: function() {
      this._offset += this.count(), this._data = null;
    } }, e3);
    function i2(e4) {
      for (var t3 = 0; t3 < e4.length; t3++) this._data.push(e4[t3]);
    }
  })(), e2;
})(), d_ = function(e2, t2, n2, r2) {
  return e2[r2];
}, f_ = (a_ = {}, a_[Nh + `_` + Rh] = function(e2, t2, n2, r2) {
  return e2[r2 + t2];
}, a_[Nh + `_row`] = function(e2, t2, n2, r2, i2) {
  r2 += t2;
  for (var a2 = i2 || [], o2 = e2, s2 = 0; s2 < o2.length; s2++) {
    var c2 = o2[s2];
    a2[s2] = c2 ? c2[r2] : null;
  }
  return a2;
}, a_[Ph] = d_, a_[Fh] = function(e2, t2, n2, r2, i2) {
  for (var a2 = i2 || [], o2 = 0; o2 < n2.length; o2++) {
    var s2 = e2[n2[o2].name];
    a2[o2] = s2 ? s2[r2] : null;
  }
  return a2;
}, a_[Mh] = d_, a_);
function p_(e2, t2) {
  return f_[b_(e2, t2)];
}
var m_ = function(e2, t2, n2) {
  return e2.length;
}, h_ = (o_ = {}, o_[Nh + `_` + Rh] = function(e2, t2, n2) {
  return Math.max(0, e2.length - t2);
}, o_[Nh + `_row`] = function(e2, t2, n2) {
  var r2 = e2[0];
  return r2 ? Math.max(0, r2.length - t2) : 0;
}, o_[Ph] = m_, o_[Fh] = function(e2, t2, n2) {
  var r2 = e2[n2[0].name];
  return r2 ? r2.length : 0;
}, o_[Mh] = m_, o_);
function g_(e2, t2) {
  return h_[b_(e2, t2)];
}
var __ = function(e2, t2, n2) {
  return e2[t2];
}, v_ = (s_ = {}, s_[Nh] = __, s_[Ph] = function(e2, t2, n2) {
  return e2[n2];
}, s_[Fh] = __, s_[Mh] = function(e2, t2, n2) {
  var r2 = ys(e2);
  return r2 instanceof Array ? r2[t2] : r2;
}, s_[Ih] = __, s_);
function y_(e2) {
  return v_[e2];
}
function b_(e2, t2) {
  return e2 === `arrayRows` ? e2 + `_` + t2 : e2;
}
function x_(e2, t2, n2) {
  if (e2) {
    var r2 = e2.getRawDataItem(t2);
    if (r2 != null) {
      var i2 = e2.getStore(), a2 = i2.getSource().sourceFormat;
      if (n2 != null) {
        var o2 = e2.getDimensionIndex(n2), s2 = i2.getDimensionProperty(o2);
        return y_(a2)(r2, o2, s2);
      }
      var c2 = r2;
      return a2 === `original` && (c2 = ys(r2)), c2;
    }
  }
}
var S_ = /\{@(.+?)\}/g, C_ = (function() {
  function e2() {
  }
  return e2.prototype.getDataParams = function(e3, t2) {
    var n2 = this.getData(t2), r2 = this.getRawValue(e3, t2), i2 = n2.getRawIndex(e3), a2 = n2.getName(e3), o2 = n2.getRawDataItem(e3), s2 = n2.getItemVisual(e3, `style`), c2 = s2 && s2[n2.getItemVisual(e3, `drawType`) || `fill`], l2 = s2 && s2.stroke, u2 = this.mainType, d2 = u2 === `series`, f2 = n2.userOutput && n2.userOutput.get();
    return { componentType: u2, componentSubType: this.subType, componentIndex: this.componentIndex, seriesType: d2 ? this.subType : null, seriesIndex: this.seriesIndex, seriesId: d2 ? this.id : null, seriesName: d2 ? this.name : null, name: a2, dataIndex: i2, data: o2, dataType: t2, value: r2, color: c2, borderColor: l2, dimensionNames: f2 ? f2.fullDimensions : null, encode: f2 ? f2.encode : null, $vars: [`seriesName`, `name`, `value`] };
  }, e2.prototype.getFormattedLabel = function(e3, t2, n2, r2, i2, a2) {
    t2 || (t2 = `normal`);
    var o2 = this.getData(n2), s2 = this.getDataParams(e3, n2);
    if (a2 && (s2.value = a2.interpolatedValue), r2 != null && H(s2.value) && (s2.value = s2.value[r2]), i2 || (i2 = o2.getItemModel(e3).get(t2 === `normal` ? [`label`, `formatter`] : [t2, `label`, `formatter`])), U(i2)) return s2.status = t2, s2.dimensionIndex = r2, i2(s2);
    if (W(i2)) return lh(i2, s2).replace(S_, function(t3, n3) {
      var r3 = n3.length, i3 = n3;
      i3.charAt(0) === `[` && i3.charAt(r3 - 1) === `]` && (i3 = +i3.slice(1, r3 - 1));
      var s3 = x_(o2, e3, i3);
      if (a2 && H(a2.interpolatedValue)) {
        var c2 = o2.getDimensionIndex(i3);
        c2 >= 0 && (s3 = a2.interpolatedValue[c2]);
      }
      return s3 == null ? `` : s3 + ``;
    });
  }, e2.prototype.getRawValue = function(e3, t2) {
    return x_(this.getData(t2), e3);
  }, e2.prototype.formatTooltip = function(e3, t2, n2) {
  }, e2;
})();
function w_(e2) {
  var t2, n2;
  return K(e2) ? e2.type && (n2 = e2) : t2 = e2, { text: t2, frag: n2 };
}
function T_(e2) {
  return new E_(e2);
}
var E_ = (function() {
  function e2(e3) {
    e3 || (e3 = {}), this._reset = e3.reset, this._plan = e3.plan, this._count = e3.count, this._onDirty = e3.onDirty, this._dirty = true;
  }
  return e2.prototype.perform = function(e3) {
    var t2 = this._upstream, n2 = e3 && e3.skip;
    if (this._dirty && t2) {
      var r2 = this.context;
      r2.data = r2.outputData = t2.context.outputData;
    }
    this.__pipeline && (this.__pipeline.currentTask = this);
    var i2;
    this._plan && !n2 && (i2 = this._plan(this.context));
    var a2 = l2(this._modBy), o2 = this._modDataCount || 0, s2 = l2(e3 && e3.modBy), c2 = e3 && e3.modDataCount || 0;
    (a2 !== s2 || o2 !== c2) && (i2 = `reset`);
    function l2(e4) {
      return !(e4 >= 1) && (e4 = 1), e4;
    }
    var u2;
    (this._dirty || i2 === `reset`) && (this._dirty = false, u2 = this._doReset(n2)), this._modBy = s2, this._modDataCount = c2;
    var d2 = e3 && e3.step;
    if (this._dueEnd = t2 ? t2._outputDueEnd : this._count ? this._count(this.context) : 1 / 0, this._progress) {
      var f2 = this._dueIndex, p2 = Math.min(d2 == null ? 1 / 0 : this._dueIndex + d2, this._dueEnd);
      if (!n2 && (u2 || f2 < p2)) {
        var m2 = this._progress;
        if (H(m2)) for (var h2 = 0; h2 < m2.length; h2++) this._doProgress(m2[h2], f2, p2, s2, c2);
        else this._doProgress(m2, f2, p2, s2, c2);
      }
      this._dueIndex = p2;
      var g2 = this._settedOutputEnd == null ? p2 : this._settedOutputEnd;
      this._outputDueEnd = g2;
    } else this._dueIndex = this._outputDueEnd = this._settedOutputEnd == null ? this._dueEnd : this._settedOutputEnd;
    return this.unfinished();
  }, e2.prototype.dirty = function() {
    this._dirty = true, this._onDirty && this._onDirty(this.context);
  }, e2.prototype._doProgress = function(e3, t2, n2, r2, i2) {
    D_.reset(t2, n2, r2, i2), this._callingProgress = e3, this._callingProgress({ start: t2, end: n2, count: n2 - t2, next: D_.next }, this.context);
  }, e2.prototype._doReset = function(e3) {
    this._dueIndex = this._outputDueEnd = this._dueEnd = 0, this._settedOutputEnd = null;
    var t2, n2;
    !e3 && this._reset && (t2 = this._reset(this.context), t2 && t2.progress && (n2 = t2.forceFirstProgress, t2 = t2.progress), H(t2) && !t2.length && (t2 = null)), this._progress = t2, this._modBy = this._modDataCount = null;
    var r2 = this._downstream;
    return r2 && r2.dirty(), n2;
  }, e2.prototype.unfinished = function() {
    return this._progress && this._dueIndex < this._dueEnd;
  }, e2.prototype.pipe = function(e3) {
    (this._downstream !== e3 || this._dirty) && (this._downstream = e3, e3._upstream = this, e3.dirty());
  }, e2.prototype.dispose = function() {
    this._disposed || (this._disposed = (this._upstream && (this._upstream._downstream = null), this._downstream && (this._downstream._upstream = null), this._dirty = false, true));
  }, e2.prototype.getUpstream = function() {
    return this._upstream;
  }, e2.prototype.getDownstream = function() {
    return this._downstream;
  }, e2.prototype.setOutputEnd = function(e3) {
    this._outputDueEnd = this._settedOutputEnd = e3;
  }, e2;
})(), D_ = /* @__PURE__ */ (function() {
  var e2, t2, n2, r2, i2, a2 = { reset: function(c2, l2, u2, d2) {
    t2 = c2, e2 = l2, n2 = u2, r2 = d2, i2 = Math.ceil(r2 / n2), a2.next = n2 > 1 && r2 > 0 ? s2 : o2;
  } };
  return a2;
  function o2() {
    return t2 < e2 ? t2++ : null;
  }
  function s2() {
    var a3 = t2 % i2 * n2 + Math.ceil(t2 / i2), o3 = t2 >= e2 ? null : a3 < r2 ? a3 : t2;
    return t2++, o3;
  }
})();
function O_(e2, t2) {
  var n2 = t2 && t2.type;
  return n2 === `ordinal` ? e2 : (n2 === `time` && !G(e2) && e2 != null && e2 !== `-` && (e2 = +ts(e2)), e2 == null || e2 === `` ? NaN : Number(e2));
}
J({ number: function(e2) {
  return parseFloat(e2);
}, time: function(e2) {
  return +ts(e2);
}, trim: function(e2) {
  return W(e2) ? ut(e2) : e2;
} });
var k_ = { lt: function(e2, t2) {
  return e2 < t2;
}, lte: function(e2, t2) {
  return e2 <= t2;
}, gt: function(e2, t2) {
  return e2 > t2;
}, gte: function(e2, t2) {
  return e2 >= t2;
} };
(function() {
  function e2(e3, t2) {
    G(t2) || fs(``), this._opFn = k_[e3], this._rvalFloat = ss(t2);
  }
  return e2.prototype.evaluate = function(e3) {
    return G(e3) ? this._opFn(e3, this._rvalFloat) : this._opFn(ss(e3), this._rvalFloat);
  }, e2;
})();
var A_ = (function() {
  function e2(e3, t2) {
    var n2 = e3 === `desc`;
    this._resultLT = n2 ? 1 : -1, t2 ?? (t2 = n2 ? `min` : `max`), this._incomparable = t2 === `min` ? -1 / 0 : 1 / 0;
  }
  return e2.prototype.evaluate = function(e3, t2) {
    var n2 = G(e3) ? e3 : ss(e3), r2 = G(t2) ? t2 : ss(t2), i2 = isNaN(n2), a2 = isNaN(r2);
    if (i2 && (n2 = this._incomparable), a2 && (r2 = this._incomparable), i2 && a2) {
      var o2 = W(e3), s2 = W(t2);
      o2 && (n2 = s2 ? e3 : 0), s2 && (r2 = o2 ? t2 : 0);
    }
    return n2 < r2 ? this._resultLT : n2 > r2 ? -this._resultLT : 0;
  }, e2;
})();
(function() {
  function e2(e3, t2) {
    this._rval = t2, this._isEQ = e3, this._rvalTypeof = typeof t2, this._rvalFloat = ss(t2);
  }
  return e2.prototype.evaluate = function(e3) {
    var t2 = e3 === this._rval;
    if (!t2) {
      var n2 = typeof e3;
      n2 !== this._rvalTypeof && (n2 === `number` || this._rvalTypeof === `number`) && (t2 = ss(e3) === this._rvalFloat);
    }
    return this._isEQ ? t2 : !t2;
  }, e2;
})();
var j_ = (function() {
  function e2() {
  }
  return e2.prototype.getRawData = function() {
    throw Error(`not supported`);
  }, e2.prototype.getRawDataItem = function(e3) {
    throw Error(`not supported`);
  }, e2.prototype.cloneRawData = function() {
  }, e2.prototype.getDimensionInfo = function(e3) {
  }, e2.prototype.cloneAllDimensionInfo = function() {
  }, e2.prototype.count = function() {
  }, e2.prototype.retrieveValue = function(e3, t2) {
  }, e2.prototype.retrieveValueFromItem = function(e3, t2) {
  }, e2.prototype.convertValue = function(e3, t2) {
    return O_(e3, t2);
  }, e2;
})();
function M_(e2, t2) {
  var n2 = new j_(), r2 = e2.data, i2 = n2.sourceFormat = e2.sourceFormat, a2 = e2.startIndex;
  e2.seriesLayoutBy !== `column` && fs(``);
  var o2 = [], s2 = {}, c2 = e2.dimensionsDefine;
  if (c2) z(c2, function(e3, t3) {
    var n3 = e3.name, r3 = { index: t3, name: n3, displayName: e3.displayName };
    o2.push(r3), n3 != null && (xt(s2, n3) && fs(``), s2[n3] = r3);
  });
  else for (var l2 = 0; l2 < e2.dimensionsDetectedCount; l2++) o2.push({ index: l2 });
  var u2 = p_(i2, Rh);
  t2.__isBuiltIn && (n2.getRawDataItem = function(e3) {
    return u2(r2, a2, o2, e3);
  }, n2.getRawData = Ye(N_, null, e2)), n2.cloneRawData = Ye(P_, null, e2), n2.count = Ye(g_(i2, Rh), null, r2, a2, o2);
  var d2 = y_(i2);
  n2.retrieveValue = function(e3, t3) {
    return f2(u2(r2, a2, o2, e3), t3);
  };
  var f2 = n2.retrieveValueFromItem = function(e3, t3) {
    if (e3 != null) {
      var n3 = o2[t3];
      if (n3) return d2(e3, t3, n3.name);
    }
  };
  return n2.getDimensionInfo = Ye(F_, null, o2, s2), n2.cloneAllDimensionInfo = Ye(I_, null, o2), n2;
}
function N_(e2) {
  var t2 = e2.sourceFormat;
  return V_(t2) || fs(``), e2.data;
}
function P_(e2) {
  var t2 = e2.sourceFormat, n2 = e2.data;
  if (V_(t2) || fs(``), t2 === `arrayRows`) {
    for (var r2 = [], i2 = 0, a2 = n2.length; i2 < a2; i2++) r2.push(n2[i2].slice());
    return r2;
  }
  if (t2 === `objectRows`) {
    for (var r2 = [], i2 = 0, a2 = n2.length; i2 < a2; i2++) r2.push(R({}, n2[i2]));
    return r2;
  }
}
function F_(e2, t2, n2) {
  if (n2 != null) {
    if (G(n2) || !isNaN(n2) && !xt(t2, n2)) return e2[n2];
    if (xt(t2, n2)) return t2[n2];
  }
}
function I_(e2) {
  return L(e2);
}
var L_ = J();
function R_(e2) {
  e2 = L(e2);
  var t2 = e2.type, n2 = ``;
  t2 || fs(n2);
  var r2 = t2.split(`:`);
  r2.length !== 2 && fs(n2);
  var i2 = false;
  r2[0] === `echarts` && (t2 = r2[1], i2 = true), e2.__isBuiltIn = i2, L_.set(t2, e2);
}
function z_(e2, t2, n2) {
  var r2 = gs(e2), i2 = r2.length;
  i2 || fs(``);
  for (var a2 = 0, o2 = i2; a2 < o2; a2++) {
    var s2 = r2[a2];
    t2 = B_(s2, t2, n2, i2 === 1 ? null : a2), a2 !== o2 - 1 && (t2.length = Math.max(t2.length, 1));
  }
  return t2;
}
function B_(e2, t2, n2, r2) {
  var i2 = ``;
  t2.length || fs(i2), K(e2) || fs(i2);
  var a2 = e2.type, o2 = L_.get(a2);
  o2 || fs(i2);
  var s2 = B(t2, function(e3) {
    return M_(e3, o2);
  });
  return B(gs(o2.transform({ upstream: s2[0], upstreamList: s2, config: L(e2.config) })), function(e3, n3) {
    var r3 = ``;
    K(e3) || fs(r3), e3.data || fs(r3), V_($g(e3.data)) || fs(r3);
    var i3, a3 = t2[0];
    if (a3 && n3 === 0 && !e3.dimensions) {
      var o3 = a3.startIndex;
      o3 && (e3.data = a3.data.slice(0, o3).concat(e3.data)), i3 = { seriesLayoutBy: Rh, sourceHeader: o3, dimensions: a3.metaRawOption.dimensions };
    } else i3 = { seriesLayoutBy: Rh, sourceHeader: 0, dimensions: e3.dimensions };
    return Xg(e3.data, i3, null);
  });
}
function V_(e2) {
  return e2 === `arrayRows` || e2 === `objectRows`;
}
var H_ = `undefined`, U_ = typeof Uint32Array === H_ ? Array : Uint32Array, W_ = typeof Uint16Array === H_ ? Array : Uint16Array, G_ = typeof Int32Array === H_ ? Array : Int32Array, K_ = typeof Float64Array === H_ ? Array : Float64Array, q_ = { float: K_, int: G_, ordinal: Array, number: Array, time: K_ }, J_;
function Y_(e2) {
  return e2 > 65535 ? U_ : W_;
}
function X_() {
  return [1 / 0, -1 / 0];
}
function Z_(e2) {
  var t2 = e2.constructor;
  return t2 === Array ? e2.slice() : new t2(e2);
}
function Q_(e2, t2, n2, r2, i2) {
  var a2 = q_[n2 || `float`];
  if (i2) {
    var o2 = e2[t2], s2 = o2 && o2.length;
    if (s2 !== r2) {
      for (var c2 = new a2(r2), l2 = 0; l2 < s2; l2++) c2[l2] = o2[l2];
      e2[t2] = c2;
    }
  } else e2[t2] = new a2(r2);
}
var $_ = (function() {
  function e2() {
    this._chunks = [], this._rawExtent = [], this._extent = [], this._count = 0, this._rawCount = 0, this._calcDimNameToIdx = J();
  }
  return e2.prototype.initData = function(e3, t2, n2) {
    this._provider = e3, this._chunks = [], this._indices = null, this.getRawIndex = this._getRawIdxIdentity;
    var r2 = e3.getSource(), i2 = this.defaultDimValueGetter = J_[r2.sourceFormat];
    this._dimValueGetter = n2 || i2, this._rawExtent = [], i_(r2), this._dimensions = B(t2, function(e4) {
      return { type: e4.type, property: e4.property };
    }), this._initDataFromProvider(0, e3.count());
  }, e2.prototype.getProvider = function() {
    return this._provider;
  }, e2.prototype.getSource = function() {
    return this._provider.getSource();
  }, e2.prototype.ensureCalculationDimension = function(e3, t2) {
    var n2 = this._calcDimNameToIdx, r2 = this._dimensions, i2 = n2.get(e3);
    if (i2 != null) {
      if (r2[i2].type === t2) return i2;
    } else i2 = r2.length;
    return r2[i2] = { type: t2 }, n2.set(e3, i2), this._chunks[i2] = new q_[t2 || `float`](this._rawCount), this._rawExtent[i2] = X_(), i2;
  }, e2.prototype.collectOrdinalMeta = function(e3, t2) {
    var n2 = this._chunks[e3], r2 = this._dimensions[e3], i2 = this._rawExtent, a2 = r2.ordinalOffset || 0, o2 = n2.length;
    a2 === 0 && (i2[e3] = X_());
    for (var s2 = i2[e3], c2 = a2; c2 < o2; c2++) {
      var l2 = n2[c2] = t2.parseAndCollect(n2[c2]);
      isNaN(l2) || (s2[0] = Math.min(l2, s2[0]), s2[1] = Math.max(l2, s2[1]));
    }
    r2.ordinalMeta = t2, r2.ordinalOffset = o2, r2.type = `ordinal`;
  }, e2.prototype.getOrdinalMeta = function(e3) {
    return this._dimensions[e3].ordinalMeta;
  }, e2.prototype.getDimensionProperty = function(e3) {
    var t2 = this._dimensions[e3];
    return t2 && t2.property;
  }, e2.prototype.appendData = function(e3) {
    var t2 = this._provider, n2 = this.count();
    t2.appendData(e3);
    var r2 = t2.count();
    return t2.persistent || (r2 += n2), n2 < r2 && this._initDataFromProvider(n2, r2, true), [n2, r2];
  }, e2.prototype.appendValues = function(e3, t2) {
    for (var n2 = this._chunks, r2 = this._dimensions, i2 = r2.length, a2 = this._rawExtent, o2 = this.count(), s2 = o2 + Math.max(e3.length, t2 || 0), c2 = 0; c2 < i2; c2++) {
      var l2 = r2[c2];
      Q_(n2, c2, l2.type, s2, true);
    }
    for (var u2 = [], d2 = o2; d2 < s2; d2++) for (var f2 = d2 - o2, p2 = 0; p2 < i2; p2++) {
      var l2 = r2[p2], m2 = J_.arrayRows.call(this, e3[f2] || u2, l2.property, f2, p2);
      n2[p2][d2] = m2;
      var h2 = a2[p2];
      m2 < h2[0] && (h2[0] = m2), m2 > h2[1] && (h2[1] = m2);
    }
    return this._rawCount = this._count = s2, { start: o2, end: s2 };
  }, e2.prototype._initDataFromProvider = function(e3, t2, n2) {
    for (var r2 = this._provider, i2 = this._chunks, a2 = this._dimensions, o2 = a2.length, s2 = this._rawExtent, c2 = B(a2, function(e4) {
      return e4.property;
    }), l2 = 0; l2 < o2; l2++) {
      var u2 = a2[l2];
      s2[l2] || (s2[l2] = X_()), Q_(i2, l2, u2.type, t2, n2);
    }
    if (r2.fillStorage) r2.fillStorage(e3, t2, i2, s2);
    else for (var d2 = [], f2 = e3; f2 < t2; f2++) {
      d2 = r2.getItem(f2, d2);
      for (var p2 = 0; p2 < o2; p2++) {
        var m2 = i2[p2], h2 = this._dimValueGetter(d2, c2[p2], f2, p2);
        m2[f2] = h2;
        var g2 = s2[p2];
        h2 < g2[0] && (g2[0] = h2), h2 > g2[1] && (g2[1] = h2);
      }
    }
    !r2.persistent && r2.clean && r2.clean(), this._rawCount = this._count = t2, this._extent = [];
  }, e2.prototype.count = function() {
    return this._count;
  }, e2.prototype.get = function(e3, t2) {
    if (!(t2 >= 0 && t2 < this._count)) return NaN;
    var n2 = this._chunks[e3];
    return n2 ? n2[this.getRawIndex(t2)] : NaN;
  }, e2.prototype.getValues = function(e3, t2) {
    var n2 = [], r2 = [];
    if (t2 == null) {
      t2 = e3, e3 = [];
      for (var i2 = 0; i2 < this._dimensions.length; i2++) r2.push(i2);
    } else r2 = e3;
    for (var i2 = 0, a2 = r2.length; i2 < a2; i2++) n2.push(this.get(r2[i2], t2));
    return n2;
  }, e2.prototype.getByRawIndex = function(e3, t2) {
    if (!(t2 >= 0 && t2 < this._rawCount)) return NaN;
    var n2 = this._chunks[e3];
    return n2 ? n2[t2] : NaN;
  }, e2.prototype.getSum = function(e3) {
    var t2 = this._chunks[e3], n2 = 0;
    if (t2) for (var r2 = 0, i2 = this.count(); r2 < i2; r2++) {
      var a2 = this.get(e3, r2);
      isNaN(a2) || (n2 += a2);
    }
    return n2;
  }, e2.prototype.getMedian = function(e3) {
    var t2 = [];
    this.each([e3], function(e4) {
      isNaN(e4) || t2.push(e4);
    });
    var n2 = t2.sort(function(e4, t3) {
      return e4 - t3;
    }), r2 = this.count();
    return r2 === 0 ? 0 : r2 % 2 == 1 ? n2[(r2 - 1) / 2] : (n2[r2 / 2] + n2[r2 / 2 - 1]) / 2;
  }, e2.prototype.indexOfRawIndex = function(e3) {
    if (e3 >= this._rawCount || e3 < 0) return -1;
    if (!this._indices) return e3;
    var t2 = this._indices, n2 = t2[e3];
    if (n2 != null && n2 < this._count && n2 === e3) return e3;
    for (var r2 = 0, i2 = this._count - 1; r2 <= i2; ) {
      var a2 = (r2 + i2) / 2 | 0;
      if (t2[a2] < e3) r2 = a2 + 1;
      else if (t2[a2] > e3) i2 = a2 - 1;
      else return a2;
    }
    return -1;
  }, e2.prototype.indicesOfNearest = function(e3, t2, n2) {
    var r2 = this._chunks[e3], i2 = [];
    if (!r2) return i2;
    n2 ?? (n2 = 1 / 0);
    for (var a2 = 1 / 0, o2 = -1, s2 = 0, c2 = 0, l2 = this.count(); c2 < l2; c2++) {
      var u2 = t2 - r2[this.getRawIndex(c2)], d2 = Math.abs(u2);
      d2 <= n2 && ((d2 < a2 || d2 === a2 && u2 >= 0 && o2 < 0) && (a2 = d2, o2 = u2, s2 = 0), u2 === o2 && (i2[s2++] = c2));
    }
    return i2.length = s2, i2;
  }, e2.prototype.getIndices = function() {
    var e3, t2 = this._indices;
    if (t2) {
      var n2 = t2.constructor, r2 = this._count;
      if (n2 === Array) {
        e3 = new n2(r2);
        for (var i2 = 0; i2 < r2; i2++) e3[i2] = t2[i2];
      } else e3 = new n2(t2.buffer, 0, r2);
    } else {
      var n2 = Y_(this._rawCount);
      e3 = new n2(this.count());
      for (var i2 = 0; i2 < e3.length; i2++) e3[i2] = i2;
    }
    return e3;
  }, e2.prototype.filter = function(e3, t2) {
    if (!this._count) return this;
    for (var n2 = this.clone(), r2 = n2.count(), i2 = new (Y_(n2._rawCount))(r2), a2 = [], o2 = e3.length, s2 = 0, c2 = e3[0], l2 = n2._chunks, u2 = 0; u2 < r2; u2++) {
      var d2 = void 0, f2 = n2.getRawIndex(u2);
      if (o2 === 0) d2 = t2(u2);
      else if (o2 === 1) {
        var p2 = l2[c2][f2];
        d2 = t2(p2, u2);
      } else {
        for (var m2 = 0; m2 < o2; m2++) a2[m2] = l2[e3[m2]][f2];
        a2[m2] = u2, d2 = t2.apply(null, a2);
      }
      d2 && (i2[s2++] = f2);
    }
    return s2 < r2 && (n2._indices = i2), n2._count = s2, n2._extent = [], n2._updateGetRawIdx(), n2;
  }, e2.prototype.selectRange = function(e3) {
    var t2 = this.clone(), n2 = t2._count;
    if (!n2) return this;
    var r2 = V(e3), i2 = r2.length;
    if (!i2) return this;
    var a2 = t2.count(), o2 = new (Y_(t2._rawCount))(a2), s2 = 0, c2 = r2[0], l2 = e3[c2][0], u2 = e3[c2][1], d2 = t2._chunks, f2 = false;
    if (!t2._indices) {
      var p2 = 0;
      if (i2 === 1) {
        for (var m2 = d2[r2[0]], h2 = 0; h2 < n2; h2++) {
          var g2 = m2[h2];
          (g2 >= l2 && g2 <= u2 || isNaN(g2)) && (o2[s2++] = p2), p2++;
        }
        f2 = true;
      } else if (i2 === 2) {
        for (var m2 = d2[r2[0]], _2 = d2[r2[1]], v2 = e3[r2[1]][0], y2 = e3[r2[1]][1], h2 = 0; h2 < n2; h2++) {
          var g2 = m2[h2], b2 = _2[h2];
          (g2 >= l2 && g2 <= u2 || isNaN(g2)) && (b2 >= v2 && b2 <= y2 || isNaN(b2)) && (o2[s2++] = p2), p2++;
        }
        f2 = true;
      }
    }
    if (!f2) {
      if (i2 === 1) for (var h2 = 0; h2 < a2; h2++) {
        var x2 = t2.getRawIndex(h2), g2 = d2[r2[0]][x2];
        (g2 >= l2 && g2 <= u2 || isNaN(g2)) && (o2[s2++] = x2);
      }
      else for (var h2 = 0; h2 < a2; h2++) {
        for (var S2 = true, x2 = t2.getRawIndex(h2), C2 = 0; C2 < i2; C2++) {
          var w2 = r2[C2], g2 = d2[w2][x2];
          (g2 < e3[w2][0] || g2 > e3[w2][1]) && (S2 = false);
        }
        S2 && (o2[s2++] = t2.getRawIndex(h2));
      }
    }
    return s2 < a2 && (t2._indices = o2), t2._count = s2, t2._extent = [], t2._updateGetRawIdx(), t2;
  }, e2.prototype.map = function(e3, t2) {
    var n2 = this.clone(e3);
    return this._updateDims(n2, e3, t2), n2;
  }, e2.prototype.modify = function(e3, t2) {
    this._updateDims(this, e3, t2);
  }, e2.prototype._updateDims = function(e3, t2, n2) {
    for (var r2 = e3._chunks, i2 = [], a2 = t2.length, o2 = e3.count(), s2 = [], c2 = e3._rawExtent, l2 = 0; l2 < t2.length; l2++) c2[t2[l2]] = X_();
    for (var u2 = 0; u2 < o2; u2++) {
      for (var d2 = e3.getRawIndex(u2), f2 = 0; f2 < a2; f2++) s2[f2] = r2[t2[f2]][d2];
      s2[a2] = u2;
      var p2 = n2 && n2.apply(null, s2);
      if (p2 != null) {
        typeof p2 != `object` && (i2[0] = p2, p2 = i2);
        for (var l2 = 0; l2 < p2.length; l2++) {
          var m2 = t2[l2], h2 = p2[l2], g2 = c2[m2], _2 = r2[m2];
          _2 && (_2[d2] = h2), h2 < g2[0] && (g2[0] = h2), h2 > g2[1] && (g2[1] = h2);
        }
      }
    }
  }, e2.prototype.lttbDownSample = function(e3, t2) {
    var n2 = this.clone([e3], true), r2 = n2._chunks[e3], i2 = this.count(), a2 = 0, o2 = Math.floor(1 / t2), s2 = this.getRawIndex(0), c2, l2, u2, d2 = new (Y_(this._rawCount))(Math.min((Math.ceil(i2 / o2) + 2) * 2, i2));
    d2[a2++] = s2;
    for (var f2 = 1; f2 < i2 - 1; f2 += o2) {
      for (var p2 = Math.min(f2 + o2, i2 - 1), m2 = Math.min(f2 + o2 * 2, i2), h2 = (m2 + p2) / 2, g2 = 0, _2 = p2; _2 < m2; _2++) {
        var v2 = this.getRawIndex(_2), y2 = r2[v2];
        isNaN(y2) || (g2 += y2);
      }
      g2 /= m2 - p2;
      var b2 = f2, x2 = Math.min(f2 + o2, i2), S2 = f2 - 1, C2 = r2[s2];
      c2 = -1, u2 = b2;
      for (var w2 = -1, T2 = 0, _2 = b2; _2 < x2; _2++) {
        var v2 = this.getRawIndex(_2), y2 = r2[v2];
        if (isNaN(y2)) {
          T2++, w2 < 0 && (w2 = v2);
          continue;
        }
        l2 = Math.abs((S2 - h2) * (y2 - C2) - (S2 - _2) * (g2 - C2)), l2 > c2 && (c2 = l2, u2 = v2);
      }
      T2 > 0 && T2 < x2 - b2 && (d2[a2++] = Math.min(w2, u2), u2 = Math.max(w2, u2)), d2[a2++] = u2, s2 = u2;
    }
    return d2[a2++] = this.getRawIndex(i2 - 1), n2._count = a2, n2._indices = d2, n2.getRawIndex = this._getRawIdx, n2;
  }, e2.prototype.minmaxDownSample = function(e3, t2) {
    for (var n2 = this.clone([e3], true), r2 = n2._chunks, i2 = Math.floor(1 / t2), a2 = r2[e3], o2 = this.count(), s2 = new (Y_(this._rawCount))(Math.ceil(o2 / i2) * 2), c2 = 0, l2 = 0; l2 < o2; l2 += i2) {
      var u2 = l2, d2 = a2[this.getRawIndex(u2)], f2 = l2, p2 = a2[this.getRawIndex(f2)], m2 = i2;
      l2 + i2 > o2 && (m2 = o2 - l2);
      for (var h2 = 0; h2 < m2; h2++) {
        var g2 = a2[this.getRawIndex(l2 + h2)];
        g2 < d2 && (d2 = g2, u2 = l2 + h2), g2 > p2 && (p2 = g2, f2 = l2 + h2);
      }
      var _2 = this.getRawIndex(u2), v2 = this.getRawIndex(f2);
      u2 < f2 ? (s2[c2++] = _2, s2[c2++] = v2) : (s2[c2++] = v2, s2[c2++] = _2);
    }
    return n2._count = c2, n2._indices = s2, n2._updateGetRawIdx(), n2;
  }, e2.prototype.downSample = function(e3, t2, n2, r2) {
    for (var i2 = this.clone([e3], true), a2 = i2._chunks, o2 = [], s2 = Math.floor(1 / t2), c2 = a2[e3], l2 = this.count(), u2 = i2._rawExtent[e3] = X_(), d2 = new (Y_(this._rawCount))(Math.ceil(l2 / s2)), f2 = 0, p2 = 0; p2 < l2; p2 += s2) {
      s2 > l2 - p2 && (s2 = l2 - p2, o2.length = s2);
      for (var m2 = 0; m2 < s2; m2++) {
        var h2 = this.getRawIndex(p2 + m2);
        o2[m2] = c2[h2];
      }
      var g2 = n2(o2), _2 = this.getRawIndex(Math.min(p2 + r2(o2, g2) || 0, l2 - 1));
      c2[_2] = g2, g2 < u2[0] && (u2[0] = g2), g2 > u2[1] && (u2[1] = g2), d2[f2++] = _2;
    }
    return i2._count = f2, i2._indices = d2, i2._updateGetRawIdx(), i2;
  }, e2.prototype.each = function(e3, t2) {
    if (this._count) for (var n2 = e3.length, r2 = this._chunks, i2 = 0, a2 = this.count(); i2 < a2; i2++) {
      var o2 = this.getRawIndex(i2);
      switch (n2) {
        case 0:
          t2(i2);
          break;
        case 1:
          t2(r2[e3[0]][o2], i2);
          break;
        case 2:
          t2(r2[e3[0]][o2], r2[e3[1]][o2], i2);
          break;
        default:
          for (var s2 = 0, c2 = []; s2 < n2; s2++) c2[s2] = r2[e3[s2]][o2];
          c2[s2] = i2, t2.apply(null, c2);
      }
    }
  }, e2.prototype.getDataExtent = function(e3) {
    var t2 = this._chunks[e3], n2 = X_();
    if (!t2) return n2;
    var r2 = this.count(), i2 = !this._indices, a2;
    if (i2) return this._rawExtent[e3].slice();
    if (a2 = this._extent[e3], a2) return a2.slice();
    a2 = n2;
    for (var o2 = a2[0], s2 = a2[1], c2 = 0; c2 < r2; c2++) {
      var l2 = t2[this.getRawIndex(c2)];
      l2 < o2 && (o2 = l2), l2 > s2 && (s2 = l2);
    }
    return a2 = [o2, s2], this._extent[e3] = a2, a2;
  }, e2.prototype.getRawDataItem = function(e3) {
    var t2 = this.getRawIndex(e3);
    if (this._provider.persistent) return this._provider.getItem(t2);
    for (var n2 = [], r2 = this._chunks, i2 = 0; i2 < r2.length; i2++) n2.push(r2[i2][t2]);
    return n2;
  }, e2.prototype.clone = function(t2, n2) {
    var r2 = new e2(), i2 = this._chunks, a2 = t2 && Ge(t2, function(e3, t3) {
      return e3[t3] = true, e3;
    }, {});
    if (a2) for (var o2 = 0; o2 < i2.length; o2++) r2._chunks[o2] = a2[o2] ? Z_(i2[o2]) : i2[o2];
    else r2._chunks = i2;
    return this._copyCommonProps(r2), n2 || (r2._indices = this._cloneIndices()), r2._updateGetRawIdx(), r2;
  }, e2.prototype._copyCommonProps = function(e3) {
    e3._count = this._count, e3._rawCount = this._rawCount, e3._provider = this._provider, e3._dimensions = this._dimensions, e3._extent = L(this._extent), e3._rawExtent = L(this._rawExtent);
  }, e2.prototype._cloneIndices = function() {
    if (this._indices) {
      var e3 = this._indices.constructor, t2 = void 0;
      if (e3 === Array) {
        var n2 = this._indices.length;
        t2 = new e3(n2);
        for (var r2 = 0; r2 < n2; r2++) t2[r2] = this._indices[r2];
      } else t2 = new e3(this._indices);
      return t2;
    }
    return null;
  }, e2.prototype._getRawIdxIdentity = function(e3) {
    return e3;
  }, e2.prototype._getRawIdx = function(e3) {
    return e3 < this._count && e3 >= 0 ? this._indices[e3] : -1;
  }, e2.prototype._updateGetRawIdx = function() {
    this.getRawIndex = this._indices ? this._getRawIdx : this._getRawIdxIdentity;
  }, e2.internalField = (function() {
    function e3(e4, t2, n2, r2) {
      return O_(e4[r2], this._dimensions[r2]);
    }
    J_ = { arrayRows: e3, objectRows: function(e4, t2, n2, r2) {
      return O_(e4[t2], this._dimensions[r2]);
    }, keyedColumns: e3, original: function(e4, t2, n2, r2) {
      var i2 = e4 && (e4.value == null ? e4 : e4.value);
      return O_(i2 instanceof Array ? i2[r2] : i2, this._dimensions[r2]);
    }, typedArray: function(e4, t2, n2, r2) {
      return e4[r2];
    } };
  })(), e2;
})(), ev = (function() {
  function e2(e3) {
    this._sourceList = [], this._storeList = [], this._upstreamSignList = [], this._versionSignBase = 0, this._dirty = true, this._sourceHost = e3;
  }
  return e2.prototype.dirty = function() {
    this._setLocalSource([], []), this._storeList = [], this._dirty = true;
  }, e2.prototype._setLocalSource = function(e3, t2) {
    this._sourceList = e3, this._upstreamSignList = t2, this._versionSignBase++, this._versionSignBase > 9e10 && (this._versionSignBase = 0);
  }, e2.prototype._getVersionSign = function() {
    return this._sourceHost.uid + `_` + this._versionSignBase;
  }, e2.prototype.prepareSource = function() {
    this._isDirty() && (this._createSource(), this._dirty = false);
  }, e2.prototype._createSource = function() {
    this._setLocalSource([], []);
    var e3 = this._sourceHost, t2 = this._getUpstreamSourceManagers(), n2 = !!t2.length, r2, i2;
    if (tv(e3)) {
      var a2 = e3, o2 = void 0, s2 = void 0, c2 = void 0;
      if (n2) {
        var l2 = t2[0];
        l2.prepareSource(), c2 = l2.getSource(), o2 = c2.data, s2 = c2.sourceFormat, i2 = [l2._getVersionSign()];
      } else o2 = a2.get(`data`, true), s2 = $e(o2) ? Ih : Mh, i2 = [];
      var u2 = this._getSourceMetaRawOption() || {}, d2 = c2 && c2.metaRawOption || {}, f2 = q(u2.seriesLayoutBy, d2.seriesLayoutBy) || null, p2 = q(u2.sourceHeader, d2.sourceHeader), m2 = q(u2.dimensions, d2.dimensions);
      r2 = f2 !== d2.seriesLayoutBy || !!p2 != !!d2.sourceHeader || m2 ? [Xg(o2, { seriesLayoutBy: f2, sourceHeader: p2, dimensions: m2 }, s2)] : [];
    } else {
      var h2 = e3;
      if (n2) {
        var g2 = this._applyTransform(t2);
        r2 = g2.sourceList, i2 = g2.upstreamSignList;
      } else r2 = [Xg(h2.get(`source`, true), this._getSourceMetaRawOption(), null)], i2 = [];
    }
    this._setLocalSource(r2, i2);
  }, e2.prototype._applyTransform = function(e3) {
    var t2 = this._sourceHost, n2 = t2.get(`transform`, true), r2 = t2.get(`fromTransformResult`, true);
    r2 != null && e3.length !== 1 && nv(``);
    var i2, a2 = [], o2 = [];
    return z(e3, function(e4) {
      e4.prepareSource();
      var t3 = e4.getSource(r2 || 0);
      r2 != null && !t3 && nv(``), a2.push(t3), o2.push(e4._getVersionSign());
    }), n2 ? i2 = z_(n2, a2, { datasetIndex: t2.componentIndex }) : r2 != null && (i2 = [Qg(a2[0])]), { sourceList: i2, upstreamSignList: o2 };
  }, e2.prototype._isDirty = function() {
    if (this._dirty) return true;
    for (var e3 = this._getUpstreamSourceManagers(), t2 = 0; t2 < e3.length; t2++) {
      var n2 = e3[t2];
      if (n2._isDirty() || this._upstreamSignList[t2] !== n2._getVersionSign()) return true;
    }
  }, e2.prototype.getSource = function(e3) {
    e3 || (e3 = 0);
    var t2 = this._sourceList[e3];
    if (!t2) {
      var n2 = this._getUpstreamSourceManagers();
      return n2[0] && n2[0].getSource(e3);
    }
    return t2;
  }, e2.prototype.getSharedDataStore = function(e3) {
    var t2 = e3.makeStoreSchema();
    return this._innerGetDataStore(t2.dimensions, e3.source, t2.hash);
  }, e2.prototype._innerGetDataStore = function(e3, t2, n2) {
    var r2 = 0, i2 = this._storeList, a2 = i2[r2];
    a2 || (a2 = i2[r2] = {});
    var o2 = a2[n2];
    if (!o2) {
      var s2 = this._getUpstreamSourceManagers()[0];
      tv(this._sourceHost) && s2 ? o2 = s2._innerGetDataStore(e3, t2, n2) : (o2 = new $_(), o2.initData(new u_(t2, e3.length), e3)), a2[n2] = o2;
    }
    return o2;
  }, e2.prototype._getUpstreamSourceManagers = function() {
    var e3 = this._sourceHost;
    if (tv(e3)) {
      var t2 = Uh(e3);
      return t2 ? [t2.getSourceManager()] : [];
    }
    return B(Wh(e3), function(e4) {
      return e4.getSourceManager();
    });
  }, e2.prototype._getSourceMetaRawOption = function() {
    var e3 = this._sourceHost, t2, n2, r2;
    if (tv(e3)) t2 = e3.get(`seriesLayoutBy`, true), n2 = e3.get(`sourceHeader`, true), r2 = e3.get(`dimensions`, true);
    else if (!this._getUpstreamSourceManagers().length) {
      var i2 = e3;
      t2 = i2.get(`seriesLayoutBy`, true), n2 = i2.get(`sourceHeader`, true), r2 = i2.get(`dimensions`, true);
    }
    return { seriesLayoutBy: t2, sourceHeader: n2, dimensions: r2 };
  }, e2;
})();
function tv(e2) {
  return e2.mainType === `series`;
}
function nv(e2) {
  throw Error(e2);
}
var rv = `line-height:1`;
function iv(e2) {
  var t2 = e2.lineHeight;
  return t2 == null ? rv : `line-height:` + fn(t2 + ``) + `px`;
}
function av(e2, t2) {
  var n2 = e2.color || `#6e7079`, r2 = e2.fontSize || 12, i2 = e2.fontWeight || `400`, a2 = e2.color || `#464646`, o2 = e2.fontSize || 14, s2 = e2.fontWeight || `900`;
  return t2 === `html` ? { nameStyle: `font-size:` + fn(r2 + ``) + `px;color:` + fn(n2) + `;font-weight:` + fn(i2 + ``), valueStyle: `font-size:` + fn(o2 + ``) + `px;color:` + fn(a2) + `;font-weight:` + fn(s2 + ``) } : { nameStyle: { fontSize: r2, fill: n2, fontWeight: i2 }, valueStyle: { fontSize: o2, fill: a2, fontWeight: s2 } };
}
var ov = [0, 10, 20, 30], sv = [``, `
`, `

`, `


`];
function cv(e2, t2) {
  return t2.type = e2, t2;
}
function lv(e2) {
  return e2.type === `section`;
}
function uv(e2) {
  return lv(e2) ? fv : pv;
}
function dv(e2) {
  if (lv(e2)) {
    var t2 = 0, n2 = e2.blocks.length, r2 = n2 > 1 || n2 > 0 && !e2.noHeader;
    return z(e2.blocks, function(e3) {
      var n3 = dv(e3);
      n3 >= t2 && (t2 = n3 + +(r2 && (!n3 || lv(e3) && !e3.noHeader)));
    }), t2;
  }
  return 0;
}
function fv(e2, t2, n2, r2) {
  var i2 = t2.noHeader, a2 = hv(dv(t2)), o2 = [], s2 = t2.blocks || [];
  lt(!s2 || H(s2)), s2 || (s2 = []);
  var c2 = e2.orderMode;
  if (t2.sortBlocks && c2) {
    s2 = s2.slice();
    var l2 = { valueAsc: `asc`, valueDesc: `desc` };
    if (xt(l2, c2)) {
      var u2 = new A_(l2[c2], null);
      s2.sort(function(e3, t3) {
        return u2.evaluate(e3.sortParam, t3.sortParam);
      });
    } else c2 === `seriesDesc` && s2.reverse();
  }
  z(s2, function(n3, i3) {
    var s3 = t2.valueFormatter, c3 = uv(n3)(s3 ? R(R({}, e2), { valueFormatter: s3 }) : e2, n3, i3 > 0 ? a2.html : 0, r2);
    c3 != null && o2.push(c3);
  });
  var d2 = e2.renderMode === `richText` ? o2.join(a2.richText) : gv(r2, o2.join(``), i2 ? n2 : a2.html);
  if (i2) return d2;
  var f2 = oh(t2.header, `ordinal`, e2.useUTC), p2 = av(r2, e2.renderMode).nameStyle, m2 = iv(r2);
  return e2.renderMode === `richText` ? yv(e2, f2, p2) + a2.richText + d2 : gv(r2, `<div style="` + p2 + `;` + m2 + `;">` + fn(f2) + `</div>` + d2, n2);
}
function pv(e2, t2, n2, r2) {
  var i2 = e2.renderMode, a2 = t2.noName, o2 = t2.noValue, s2 = !t2.markerType, c2 = t2.name, l2 = e2.useUTC, u2 = t2.valueFormatter || e2.valueFormatter || function(e3) {
    return e3 = H(e3) ? e3 : [e3], B(e3, function(e4, t3) {
      return oh(e4, H(p2) ? p2[t3] : p2, l2);
    });
  };
  if (!(a2 && o2)) {
    var d2 = s2 ? `` : e2.markupStyleCreator.makeTooltipMarker(t2.markerType, t2.markerColor || `#333`, i2), f2 = a2 ? `` : oh(c2, `ordinal`, l2), p2 = t2.valueType, m2 = o2 ? [] : u2(t2.value, t2.dataIndex), h2 = !s2 || !a2, g2 = !s2 && a2, _2 = av(r2, i2), v2 = _2.nameStyle, y2 = _2.valueStyle;
    return i2 === `richText` ? (s2 ? `` : d2) + (a2 ? `` : yv(e2, f2, v2)) + (o2 ? `` : bv(e2, m2, h2, g2, y2)) : gv(r2, (s2 ? `` : d2) + (a2 ? `` : _v(f2, !s2, v2)) + (o2 ? `` : vv(m2, h2, g2, y2)), n2);
  }
}
function mv(e2, t2, n2, r2, i2, a2) {
  if (e2) return uv(e2)({ useUTC: i2, renderMode: n2, orderMode: r2, markupStyleCreator: t2, valueFormatter: e2.valueFormatter }, e2, 0, a2);
}
function hv(e2) {
  return { html: ov[e2], richText: sv[e2] };
}
function gv(e2, t2, n2) {
  var r2 = `<div style="clear:both"></div>`, i2 = `margin: ` + n2 + `px 0 0`, a2 = iv(e2);
  return `<div style="` + i2 + `;` + a2 + `;">` + t2 + r2 + `</div>`;
}
function _v(e2, t2, n2) {
  var r2 = t2 ? `margin-left:2px` : ``;
  return `<span style="` + n2 + `;` + r2 + `">` + fn(e2) + `</span>`;
}
function vv(e2, t2, n2, r2) {
  var i2 = t2 ? `float:right;margin-left:` + (n2 ? `10px` : `20px`) : ``;
  return e2 = H(e2) ? e2 : [e2], `<span style="` + i2 + `;` + r2 + `">` + B(e2, function(e3) {
    return fn(e3);
  }).join(`&nbsp;&nbsp;`) + `</span>`;
}
function yv(e2, t2, n2) {
  return e2.markupStyleCreator.wrapRichTextStyle(t2, n2);
}
function bv(e2, t2, n2, r2, i2) {
  var a2 = [i2], o2 = r2 ? 10 : 20;
  return n2 && a2.push({ padding: [0, 0, 0, o2], align: `right` }), e2.markupStyleCreator.wrapRichTextStyle(H(t2) ? t2.join(`  `) : t2, a2);
}
function xv(e2, t2) {
  var n2 = e2.getData().getItemVisual(t2, `style`)[e2.visualDrawType];
  return ph(n2);
}
function Sv(e2, t2) {
  return e2.get(`padding`) ?? (t2 === `richText` ? [8, 10] : 10);
}
var Cv = (function() {
  function e2() {
    this.richTextStyles = {}, this._nextStyleNameId = ls();
  }
  return e2.prototype._generateStyleName = function() {
    return `__EC_aUTo_` + this._nextStyleNameId++;
  }, e2.prototype.makeTooltipMarker = function(e3, t2, n2) {
    var r2 = n2 === `richText` ? this._generateStyleName() : null, i2 = uh({ color: t2, type: e3, renderMode: n2, markerId: r2 });
    return W(i2) ? i2 : (this.richTextStyles[r2] = i2.style, i2.content);
  }, e2.prototype.wrapRichTextStyle = function(e3, t2) {
    var n2 = {};
    H(t2) ? z(t2, function(e4) {
      return R(n2, e4);
    }) : R(n2, t2);
    var r2 = this._generateStyleName();
    return this.richTextStyles[r2] = n2, `{` + r2 + `|` + e3 + `}`;
  }, e2;
})();
function wv(e2) {
  var t2 = e2.series, n2 = e2.dataIndex, r2 = e2.multipleSeries, i2 = t2.getData(), a2 = i2.mapDimensionsAll(`defaultedTooltip`), o2 = a2.length, s2 = t2.getRawValue(n2), c2 = H(s2), l2 = xv(t2, n2), u2, d2, f2, p2;
  if (o2 > 1 || c2 && !o2) {
    var m2 = Tv(s2, t2, n2, a2, l2);
    u2 = m2.inlineValues, d2 = m2.inlineValueTypes, f2 = m2.blocks, p2 = m2.inlineValues[0];
  } else if (o2) {
    var h2 = i2.getDimensionInfo(a2[0]);
    p2 = u2 = x_(i2, n2, a2[0]), d2 = h2.type;
  } else p2 = u2 = c2 ? s2[0] : s2;
  var g2 = js(t2), _2 = g2 && t2.name || ``, v2 = i2.getName(n2), y2 = r2 ? _2 : v2;
  return cv(`section`, { header: _2, noHeader: r2 || !g2, sortParam: p2, blocks: [cv(`nameValue`, { markerType: `item`, markerColor: l2, name: y2, noName: !ut(y2), value: u2, valueType: d2, dataIndex: n2 })].concat(f2 || []) });
}
function Tv(e2, t2, n2, r2, i2) {
  var a2 = t2.getData(), o2 = Ge(e2, function(e3, t3, n3) {
    var r3 = a2.getDimensionInfo(n3);
    return e3 || (e3 = r3 && r3.tooltip !== false && r3.displayName != null);
  }, false), s2 = [], c2 = [], l2 = [];
  r2.length ? z(r2, function(e3) {
    u2(x_(a2, n2, e3), e3);
  }) : z(e2, u2);
  function u2(e3, t3) {
    var n3 = a2.getDimensionInfo(t3);
    n3 && n3.otherDims.tooltip !== false && (o2 ? l2.push(cv(`nameValue`, { markerType: `subItem`, markerColor: i2, name: n3.displayName, value: e3, valueType: n3.type })) : (s2.push(e3), c2.push(n3.type)));
  }
  return { inlineValues: s2, inlineValueTypes: c2, blocks: l2 };
}
M();
var Ev = Ls();
function Dv(e2, t2) {
  return e2.getName(t2) || e2.getId(t2);
}
var Ov = (function(e2) {
  s(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3._selectedDataIndicesMap = {}, t3;
  }
  return t2.prototype.init = function(e3, t3, n2) {
    this.seriesIndex = this.componentIndex, this.dataTask = T_({ count: jv, reset: Mv }), this.dataTask.context = { model: this }, this.mergeDefaultAndTheme(e3, n2), (Ev(this).sourceManager = new ev(this)).prepareSource();
    var r2 = this.getInitialData(e3, n2);
    Pv(r2, this), this.dataTask.context.data = r2, Ev(this).dataBeforeProcessed = r2, kv(this), this._initSelectedMapFromData(r2);
  }, t2.prototype.mergeDefaultAndTheme = function(e3, t3) {
    var n2 = Sh(this), r2 = n2 ? wh(e3) : {}, i2 = this.subType;
    $.hasClass(i2) && (i2 += `Series`), Le(e3, t3.getTheme().get(this.subType)), Le(e3, this.getDefaultOption()), _s(e3, `label`, [`show`]), this.fillDataTextStyle(e3.data), n2 && Ch(e3, r2, n2);
  }, t2.prototype.mergeOption = function(e3, t3) {
    e3 = Le(this.option, e3, true), this.fillDataTextStyle(e3.data);
    var n2 = Sh(this);
    n2 && Ch(this.option, e3, n2);
    var r2 = Ev(this).sourceManager;
    r2.dirty(), r2.prepareSource();
    var i2 = this.getInitialData(e3, t3);
    Pv(i2, this), this.dataTask.dirty(), this.dataTask.context.data = i2, Ev(this).dataBeforeProcessed = i2, kv(this), this._initSelectedMapFromData(i2);
  }, t2.prototype.fillDataTextStyle = function(e3) {
    if (e3 && !$e(e3)) for (var t3 = [`show`], n2 = 0; n2 < e3.length; n2++) e3[n2] && e3[n2].label && _s(e3[n2], `label`, t3);
  }, t2.prototype.getInitialData = function(e3, t3) {
  }, t2.prototype.appendData = function(e3) {
    this.getRawData().appendData(e3.data);
  }, t2.prototype.getData = function(e3) {
    var t3 = Iv(this);
    if (t3) {
      var n2 = t3.context.data;
      return e3 == null || !n2.getLinkedData ? n2 : n2.getLinkedData(e3);
    }
    return Ev(this).data;
  }, t2.prototype.getAllData = function() {
    var e3 = this.getData();
    return e3 && e3.getLinkedDataAll ? e3.getLinkedDataAll() : [{ data: e3 }];
  }, t2.prototype.setData = function(e3) {
    var t3 = Iv(this);
    if (t3) {
      var n2 = t3.context;
      n2.outputData = e3, t3 !== this.dataTask && (n2.data = e3);
    }
    Ev(this).data = e3;
  }, t2.prototype.getEncode = function() {
    var e3 = this.get(`encode`, true);
    if (e3) return J(e3);
  }, t2.prototype.getSourceManager = function() {
    return Ev(this).sourceManager;
  }, t2.prototype.getSource = function() {
    return this.getSourceManager().getSource();
  }, t2.prototype.getRawData = function() {
    return Ev(this).dataBeforeProcessed;
  }, t2.prototype.getColorBy = function() {
    return this.get(`colorBy`) || `series`;
  }, t2.prototype.isColorBySeries = function() {
    return this.getColorBy() === `series`;
  }, t2.prototype.getBaseAxis = function() {
    var e3 = this.coordinateSystem;
    return e3 && e3.getBaseAxis && e3.getBaseAxis();
  }, t2.prototype.formatTooltip = function(e3, t3, n2) {
    return wv({ series: this, dataIndex: e3, multipleSeries: t3 });
  }, t2.prototype.isAnimationEnabled = function() {
    var e3 = this.ecModel;
    if (I.node && !(e3 && e3.ssr)) return false;
    var t3 = this.getShallow(`animation`);
    return t3 && this.getData().count() > this.getShallow(`animationThreshold`) && (t3 = false), !!t3;
  }, t2.prototype.restoreData = function() {
    this.dataTask.dirty();
  }, t2.prototype.getColorFromPalette = function(e3, t3, n2) {
    var r2 = this.ecModel, i2 = Zh.prototype.getColorFromPalette.call(this, e3, t3, n2);
    return i2 || (i2 = r2.getColorFromPalette(e3, t3, n2)), i2;
  }, t2.prototype.coordDimToDataDim = function(e3) {
    return this.getRawData().mapDimensionsAll(e3);
  }, t2.prototype.getProgressive = function() {
    return this.get(`progressive`);
  }, t2.prototype.getProgressiveThreshold = function() {
    return this.get(`progressiveThreshold`);
  }, t2.prototype.select = function(e3, t3) {
    this._innerSelect(this.getData(t3), e3);
  }, t2.prototype.unselect = function(e3, t3) {
    var n2 = this.option.selectedMap;
    if (n2) {
      var r2 = this.option.selectedMode, i2 = this.getData(t3);
      if (r2 === `series` || n2 === `all`) {
        this.option.selectedMap = {}, this._selectedDataIndicesMap = {};
        return;
      }
      for (var a2 = 0; a2 < e3.length; a2++) {
        var o2 = e3[a2], s2 = Dv(i2, o2);
        n2[s2] = false, this._selectedDataIndicesMap[s2] = -1;
      }
    }
  }, t2.prototype.toggleSelect = function(e3, t3) {
    for (var n2 = [], r2 = 0; r2 < e3.length; r2++) n2[0] = e3[r2], this.isSelected(e3[r2], t3) ? this.unselect(n2, t3) : this.select(n2, t3);
  }, t2.prototype.getSelectedDataIndices = function() {
    if (this.option.selectedMap === `all`) return [].slice.call(this.getData().getIndices());
    for (var e3 = this._selectedDataIndicesMap, t3 = V(e3), n2 = [], r2 = 0; r2 < t3.length; r2++) {
      var i2 = e3[t3[r2]];
      i2 >= 0 && n2.push(i2);
    }
    return n2;
  }, t2.prototype.isSelected = function(e3, t3) {
    var n2 = this.option.selectedMap;
    if (!n2) return false;
    var r2 = this.getData(t3);
    return (n2 === `all` || n2[Dv(r2, e3)]) && !r2.getItemModel(e3).get([`select`, `disabled`]);
  }, t2.prototype.isUniversalTransitionEnabled = function() {
    if (this.__universalTransitionEnabled) return true;
    var e3 = this.option.universalTransition;
    return e3 ? e3 === true || e3 && e3.enabled : false;
  }, t2.prototype._innerSelect = function(e3, t3) {
    var n2, r2, i2 = this.option, a2 = i2.selectedMode, o2 = t3.length;
    if (a2 && o2) {
      if (a2 === `series`) i2.selectedMap = `all`;
      else if (a2 === `multiple`) {
        K(i2.selectedMap) || (i2.selectedMap = {});
        for (var s2 = i2.selectedMap, c2 = 0; c2 < o2; c2++) {
          var l2 = t3[c2], u2 = Dv(e3, l2);
          s2[u2] = true, this._selectedDataIndicesMap[u2] = e3.getRawIndex(l2);
        }
      } else if (a2 === `single` || a2 === true) {
        var d2 = t3[o2 - 1], u2 = Dv(e3, d2);
        i2.selectedMap = (n2 = {}, n2[u2] = true, n2), this._selectedDataIndicesMap = (r2 = {}, r2[u2] = e3.getRawIndex(d2), r2);
      }
    }
  }, t2.prototype._initSelectedMapFromData = function(e3) {
    if (!this.option.selectedMap) {
      var t3 = [];
      e3.hasItemOption && e3.each(function(n2) {
        var r2 = e3.getRawDataItem(n2);
        r2 && r2.selected && t3.push(n2);
      }), t3.length > 0 && this._innerSelect(e3, t3);
    }
  }, t2.registerClass = function(e3) {
    return $.registerClass(e3);
  }, t2.protoInitialize = (function() {
    var e3 = t2.prototype;
    e3.type = `series.__base__`, e3.seriesIndex = 0, e3.ignoreStyleOnData = false, e3.hasSymbolVisual = false, e3.defaultSymbol = `circle`, e3.visualStyleAccessPath = `itemStyle`, e3.visualDrawType = `fill`;
  })(), t2;
})($);
Ue(Ov, C_), Ue(Ov, Zh), nc(Ov, $);
function kv(e2) {
  var t2 = e2.name;
  js(e2) || (e2.name = Av(e2) || t2);
}
function Av(e2) {
  var t2 = e2.getRawData(), n2 = t2.mapDimensionsAll(`seriesName`), r2 = [];
  return z(n2, function(e3) {
    var n3 = t2.getDimensionInfo(e3);
    n3.displayName && r2.push(n3.displayName);
  }), r2.join(` `);
}
function jv(e2) {
  return e2.model.getRawData().count();
}
function Mv(e2) {
  var t2 = e2.model;
  return t2.setData(t2.getRawData().cloneShallow()), Nv;
}
function Nv(e2, t2) {
  t2.outputData && e2.end > t2.outputData.count() && t2.model.getRawData().cloneShallow(t2.outputData);
}
function Pv(e2, t2) {
  z(vt(e2.CHANGABLE_METHODS, e2.DOWNSAMPLE_METHODS), function(n2) {
    e2.wrapMethod(n2, Xe(Fv, t2));
  });
}
function Fv(e2, t2) {
  var n2 = Iv(e2);
  return n2 && n2.setOutputEnd((t2 || this).count()), t2;
}
function Iv(e2) {
  var t2 = (e2.ecModel || {}).scheduler, n2 = t2 && t2.getPipeline(e2.uid);
  if (n2) {
    var r2 = n2.currentTask;
    if (r2) {
      var i2 = r2.agentStubMap;
      i2 && (r2 = i2.get(e2.uid));
    }
    return r2;
  }
}
var Lv = (function() {
  function e2() {
    this.group = new So(), this.uid = cm(`viewComponent`);
  }
  return e2.prototype.init = function(e3, t2) {
  }, e2.prototype.render = function(e3, t2, n2, r2) {
  }, e2.prototype.dispose = function(e3, t2) {
  }, e2.prototype.updateView = function(e3, t2, n2, r2) {
  }, e2.prototype.updateLayout = function(e3, t2, n2, r2) {
  }, e2.prototype.updateVisual = function(e3, t2, n2, r2) {
  }, e2.prototype.toggleBlurSeries = function(e3, t2, n2) {
  }, e2.prototype.eachRendered = function(e3) {
    var t2 = this.group;
    t2 && t2.traverse(e3);
  }, e2;
})();
ec(Lv), sc(Lv);
function Rv() {
  var e2 = Ls();
  return function(t2) {
    var n2 = e2(t2), r2 = t2.pipelineContext, i2 = !!n2.large, a2 = !!n2.progressiveRender, o2 = n2.large = !!(r2 && r2.large), s2 = n2.progressiveRender = !!(r2 && r2.progressiveRender);
    return (i2 !== o2 || a2 !== s2) && `reset`;
  };
}
var zv = Ls(), Bv = Rv(), Vv = (function() {
  function e2() {
    this.group = new So(), this.uid = cm(`viewChart`), this.renderTask = T_({ plan: Wv, reset: Gv }), this.renderTask.context = { view: this };
  }
  return e2.prototype.init = function(e3, t2) {
  }, e2.prototype.render = function(e3, t2, n2, r2) {
  }, e2.prototype.highlight = function(e3, t2, n2, r2) {
    var i2 = e3.getData(r2 && r2.dataType);
    i2 && Uv(i2, r2, `emphasis`);
  }, e2.prototype.downplay = function(e3, t2, n2, r2) {
    var i2 = e3.getData(r2 && r2.dataType);
    i2 && Uv(i2, r2, `normal`);
  }, e2.prototype.remove = function(e3, t2) {
    this.group.removeAll();
  }, e2.prototype.dispose = function(e3, t2) {
  }, e2.prototype.updateView = function(e3, t2, n2, r2) {
    this.render(e3, t2, n2, r2);
  }, e2.prototype.updateLayout = function(e3, t2, n2, r2) {
    this.render(e3, t2, n2, r2);
  }, e2.prototype.updateVisual = function(e3, t2, n2, r2) {
    this.render(e3, t2, n2, r2);
  }, e2.prototype.eachRendered = function(e3) {
    Pp(this.group, e3);
  }, e2.markUpdateMethod = function(e3, t2) {
    zv(e3).updateMethod = t2;
  }, e2.protoInitialize = (function() {
    var t2 = e2.prototype;
    t2.type = `chart`;
  })(), e2;
})();
function Hv(e2, t2, n2) {
  e2 && Cd(e2) && (t2 === `emphasis` ? Qu : $u)(e2, n2);
}
function Uv(e2, t2, n2) {
  var r2 = Is(e2, t2), i2 = t2 && t2.highlightKey != null ? wd(t2.highlightKey) : null;
  r2 == null ? e2.eachItemGraphicEl(function(e3) {
    Hv(e3, n2, i2);
  }) : z(gs(r2), function(t3) {
    Hv(e2.getItemGraphicEl(t3), n2, i2);
  });
}
ec(Vv, [`dispose`]), sc(Vv);
function Wv(e2) {
  return Bv(e2.model);
}
function Gv(e2) {
  var t2 = e2.model, n2 = e2.ecModel, r2 = e2.api, i2 = e2.payload, a2 = t2.pipelineContext.progressiveRender, o2 = e2.view, s2 = i2 && zv(i2).updateMethod, c2 = a2 ? `incrementalPrepareRender` : s2 && o2[s2] ? s2 : `render`;
  return c2 !== `render` && o2[c2](t2, n2, r2, i2), Kv[c2];
}
var Kv = { incrementalPrepareRender: { progress: function(e2, t2) {
  t2.view.incrementalRender(e2, t2.model, t2.ecModel, t2.api, t2.payload);
} }, render: { forceFirstProgress: true, progress: function(e2, t2) {
  t2.view.render(t2.model, t2.ecModel, t2.api, t2.payload);
} } }, qv = `\0__throttleOriginMethod`, Jv = `\0__throttleRate`, Yv = `\0__throttleType`;
function Xv(e2, t2, n2) {
  var r2, i2 = 0, a2 = 0, o2 = null, s2, c2, l2, u2;
  t2 || (t2 = 0);
  function d2() {
    a2 = (/* @__PURE__ */ new Date()).getTime(), o2 = null, e2.apply(c2, l2 || []);
  }
  var f2 = function() {
    var e3 = [...arguments];
    r2 = (/* @__PURE__ */ new Date()).getTime(), c2 = this, l2 = e3;
    var f3 = u2 || t2, p2 = u2 || n2;
    u2 = null, s2 = r2 - (p2 ? i2 : a2) - f3, clearTimeout(o2), p2 ? o2 = setTimeout(d2, f3) : s2 >= 0 ? d2() : o2 = setTimeout(d2, -s2), i2 = r2;
  };
  return f2.clear = function() {
    o2 && (o2 = (clearTimeout(o2), null));
  }, f2.debounceNextCall = function(e3) {
    u2 = e3;
  }, f2;
}
function Zv(e2, t2, n2, r2) {
  var i2 = e2[t2];
  if (i2) {
    var a2 = i2[qv] || i2, o2 = i2[Yv];
    if (i2[Jv] !== n2 || o2 !== r2) {
      if (n2 == null || !r2) return e2[t2] = a2;
      i2 = e2[t2] = Xv(a2, n2, r2 === `debounce`), i2[qv] = a2, i2[Yv] = r2, i2[Jv] = n2;
    }
    return i2;
  }
}
function Qv(e2, t2) {
  var n2 = e2[t2];
  n2 && n2[qv] && (n2.clear && n2.clear(), e2[t2] = n2[qv]);
}
var $v = Ls(), ey = { itemStyle: cc(rm, true), lineStyle: cc(em, true) }, ty = { lineStyle: `stroke`, itemStyle: `fill` };
function ny(e2, t2) {
  return e2.visualStyleMapper || ey[t2] || (console.warn(`Unknown style type '` + t2 + `'.`), ey.itemStyle);
}
function ry(e2, t2) {
  return e2.visualDrawType || ty[t2] || (console.warn(`Unknown style type '` + t2 + `'.`), `fill`);
}
var iy = { createOnAllSeries: true, performRawSeries: true, reset: function(e2, t2) {
  var n2 = e2.getData(), r2 = e2.visualStyleAccessPath || `itemStyle`, i2 = e2.getModel(r2), a2 = ny(e2, r2)(i2), o2 = i2.getShallow(`decal`);
  o2 && (n2.setVisual(`decal`, o2), o2.dirty = true);
  var s2 = ry(e2, r2), c2 = a2[s2], l2 = U(c2) ? c2 : null, u2 = a2.fill === `auto` || a2.stroke === `auto`;
  if (!a2[s2] || l2 || u2) {
    var d2 = e2.getColorFromPalette(e2.name, null, t2.getSeriesCount());
    a2[s2] || (a2[s2] = d2, n2.setVisual(`colorFromPalette`, true)), a2.fill = a2.fill === `auto` || U(a2.fill) ? d2 : a2.fill, a2.stroke = a2.stroke === `auto` || U(a2.stroke) ? d2 : a2.stroke;
  }
  if (n2.setVisual(`style`, a2), n2.setVisual(`drawType`, s2), !t2.isSeriesFiltered(e2) && l2) return n2.setVisual(`colorFromPalette`, false), { dataEach: function(t3, n3) {
    var r3 = e2.getDataParams(n3), i3 = R({}, a2);
    i3[s2] = l2(r3), t3.setItemVisual(n3, `style`, i3);
  } };
} }, ay = new om(), oy = { createOnAllSeries: true, performRawSeries: true, reset: function(e2, t2) {
  if (!(e2.ignoreStyleOnData || t2.isSeriesFiltered(e2))) {
    var n2 = e2.getData(), r2 = e2.visualStyleAccessPath || `itemStyle`, i2 = ny(e2, r2), a2 = n2.getVisual(`drawType`);
    return { dataEach: n2.hasItemOption ? function(e3, t3) {
      var n3 = e3.getRawDataItem(t3);
      if (n3 && n3[r2]) {
        ay.option = n3[r2];
        var o2 = i2(ay);
        R(e3.ensureUniqueItemVisual(t3, `style`), o2), ay.option.decal && (e3.setItemVisual(t3, `decal`, ay.option.decal), ay.option.decal.dirty = true), a2 in o2 && e3.setItemVisual(t3, `colorFromPalette`, false);
      }
    } : null };
  }
} }, sy = { performRawSeries: true, overallReset: function(e2) {
  var t2 = J();
  e2.eachSeries(function(e3) {
    var n2 = e3.getColorBy();
    if (!e3.isColorBySeries()) {
      var r2 = e3.type + `-` + n2, i2 = t2.get(r2);
      i2 || (i2 = {}, t2.set(r2, i2)), $v(e3).scope = i2;
    }
  }), e2.eachSeries(function(t3) {
    if (!(t3.isColorBySeries() || e2.isSeriesFiltered(t3))) {
      var n2 = t3.getRawData(), r2 = {}, i2 = t3.getData(), a2 = $v(t3).scope, o2 = ry(t3, t3.visualStyleAccessPath || `itemStyle`);
      i2.each(function(e3) {
        var t4 = i2.getRawIndex(e3);
        r2[t4] = e3;
      }), n2.each(function(e3) {
        var s2 = r2[e3];
        if (i2.getItemVisual(s2, `colorFromPalette`)) {
          var c2 = i2.ensureUniqueItemVisual(s2, `style`), l2 = n2.getName(e3) || e3 + ``, u2 = n2.count();
          c2[o2] = t3.getColorFromPalette(l2, a2, u2);
        }
      });
    }
  });
} }, cy = Math.PI;
function ly(e2, t2) {
  t2 || (t2 = {}), ze(t2, { text: `loading`, textColor: `#000`, fontSize: 12, fontWeight: `normal`, fontStyle: `normal`, fontFamily: `sans-serif`, maskColor: `rgba(255, 255, 255, 0.8)`, showSpinner: true, color: `#5470c6`, spinnerRadius: 10, lineWidth: 5, zlevel: 0 });
  var n2 = new So(), r2 = new nu({ style: { fill: t2.maskColor }, zlevel: t2.zlevel, z: 1e4 });
  n2.add(r2);
  var i2 = new ou({ style: { text: t2.text, fill: t2.textColor, fontSize: t2.fontSize, fontWeight: t2.fontWeight, fontStyle: t2.fontStyle, fontFamily: t2.fontFamily }, zlevel: t2.zlevel, z: 10001 }), a2 = new nu({ style: { fill: `none` }, textContent: i2, textConfig: { position: `right`, distance: 10 }, zlevel: t2.zlevel, z: 10001 });
  n2.add(a2);
  var o2;
  return t2.showSpinner && (o2 = new Pf({ shape: { startAngle: -cy / 2, endAngle: -cy / 2 + 0.1, r: t2.spinnerRadius }, style: { stroke: t2.color, lineCap: `round`, lineWidth: t2.lineWidth }, zlevel: t2.zlevel, z: 10001 }), o2.animateShape(true).when(1e3, { endAngle: cy * 3 / 2 }).start(`circularInOut`), o2.animateShape(true).when(1e3, { startAngle: cy * 3 / 2 }).delay(300).start(`circularInOut`), n2.add(o2)), n2.resize = function() {
    var n3 = i2.getBoundingRect().width, s2 = t2.showSpinner ? t2.spinnerRadius : 0, c2 = (e2.getWidth() - s2 * 2 - (t2.showSpinner && n3 ? 10 : 0) - n3) / 2 - (t2.showSpinner && n3 ? 0 : 5 + n3 / 2) + (t2.showSpinner ? 0 : n3 / 2) + (n3 ? 0 : s2), l2 = e2.getHeight() / 2;
    t2.showSpinner && o2.setShape({ cx: c2, cy: l2 }), a2.setShape({ x: c2 - s2, y: l2 - s2, width: s2 * 2, height: s2 * 2 }), r2.setShape({ x: 0, y: 0, width: e2.getWidth(), height: e2.getHeight() });
  }, n2.resize(), n2;
}
var uy = (function() {
  function e2(e3, t2, n2, r2) {
    this._stageTaskMap = J(), this.ecInstance = e3, this.api = t2, n2 = this._dataProcessorHandlers = n2.slice(), r2 = this._visualHandlers = r2.slice(), this._allHandlers = n2.concat(r2);
  }
  return e2.prototype.restoreData = function(e3, t2) {
    e3.restoreData(t2), this._stageTaskMap.each(function(e4) {
      var t3 = e4.overallTask;
      t3 && t3.dirty();
    });
  }, e2.prototype.getPerformArgs = function(e3, t2) {
    if (e3.__pipeline) {
      var n2 = this._pipelineMap.get(e3.__pipeline.id), r2 = n2.context, i2 = !t2 && n2.progressiveEnabled && (!r2 || r2.progressiveRender) && e3.__idxInPipeline > n2.blockIndex ? n2.step : null, a2 = r2 && r2.modDataCount;
      return { step: i2, modBy: a2 == null ? null : Math.ceil(a2 / i2), modDataCount: a2 };
    }
  }, e2.prototype.getPipeline = function(e3) {
    return this._pipelineMap.get(e3);
  }, e2.prototype.updateStreamModes = function(e3, t2) {
    var n2 = this._pipelineMap.get(e3.uid), r2 = e3.getData().count(), i2 = n2.progressiveEnabled && t2.incrementalPrepareRender && r2 >= n2.threshold, a2 = e3.get(`large`) && r2 >= e3.get(`largeThreshold`);
    e3.pipelineContext = n2.context = { progressiveRender: i2, modDataCount: e3.get(`progressiveChunkMode`) === `mod` ? r2 : null, large: a2 };
  }, e2.prototype.restorePipelines = function(e3) {
    var t2 = this, n2 = t2._pipelineMap = J();
    e3.eachSeries(function(e4) {
      var r2 = e4.getProgressive(), i2 = e4.uid;
      n2.set(i2, { id: i2, head: null, tail: null, threshold: e4.getProgressiveThreshold(), progressiveEnabled: r2 && !(e4.preventIncremental && e4.preventIncremental()), blockIndex: -1, step: Math.round(r2 || 700), count: 0 }), t2._pipe(e4, e4.dataTask);
    });
  }, e2.prototype.prepareStageTasks = function() {
    var e3 = this._stageTaskMap, t2 = this.api.getModel(), n2 = this.api;
    z(this._allHandlers, function(r2) {
      var i2 = e3.get(r2.uid) || e3.set(r2.uid, {});
      lt(!(r2.reset && r2.overallReset), ``), r2.reset && this._createSeriesStageTask(r2, i2, t2, n2), r2.overallReset && this._createOverallStageTask(r2, i2, t2, n2);
    }, this);
  }, e2.prototype.prepareView = function(e3, t2, n2, r2) {
    var i2 = e3.renderTask, a2 = i2.context;
    a2.model = t2, a2.ecModel = n2, a2.api = r2, i2.__block = !e3.incrementalPrepareRender, this._pipe(t2, i2);
  }, e2.prototype.performDataProcessorTasks = function(e3, t2) {
    this._performStageTasks(this._dataProcessorHandlers, e3, t2, { block: true });
  }, e2.prototype.performVisualTasks = function(e3, t2, n2) {
    this._performStageTasks(this._visualHandlers, e3, t2, n2);
  }, e2.prototype._performStageTasks = function(e3, t2, n2, r2) {
    r2 || (r2 = {});
    var i2 = false, a2 = this;
    z(e3, function(e4, s2) {
      if (!(r2.visualType && r2.visualType !== e4.visualType)) {
        var c2 = a2._stageTaskMap.get(e4.uid), l2 = c2.seriesTaskMap, u2 = c2.overallTask;
        if (u2) {
          var d2, f2 = u2.agentStubMap;
          f2.each(function(e5) {
            o2(r2, e5) && (e5.dirty(), d2 = true);
          }), d2 && u2.dirty(), a2.updatePayload(u2, n2);
          var p2 = a2.getPerformArgs(u2, r2.block);
          f2.each(function(e5) {
            e5.perform(p2);
          }), u2.perform(p2) && (i2 = true);
        } else l2 && l2.each(function(s3, c3) {
          o2(r2, s3) && s3.dirty();
          var l3 = a2.getPerformArgs(s3, r2.block);
          l3.skip = !e4.performRawSeries && t2.isSeriesFiltered(s3.context.model), a2.updatePayload(s3, n2), s3.perform(l3) && (i2 = true);
        });
      }
    });
    function o2(e4, t3) {
      return e4.setDirty && (!e4.dirtyMap || e4.dirtyMap.get(t3.__pipeline.id));
    }
    this.unfinished = i2 || this.unfinished;
  }, e2.prototype.performSeriesTasks = function(e3) {
    var t2;
    e3.eachSeries(function(e4) {
      t2 = e4.dataTask.perform() || t2;
    }), this.unfinished = t2 || this.unfinished;
  }, e2.prototype.plan = function() {
    this._pipelineMap.each(function(e3) {
      var t2 = e3.tail;
      do {
        if (t2.__block) {
          e3.blockIndex = t2.__idxInPipeline;
          break;
        }
        t2 = t2.getUpstream();
      } while (t2);
    });
  }, e2.prototype.updatePayload = function(e3, t2) {
    t2 !== `remain` && (e3.context.payload = t2);
  }, e2.prototype._createSeriesStageTask = function(e3, t2, n2, r2) {
    var i2 = this, a2 = t2.seriesTaskMap, o2 = t2.seriesTaskMap = J(), s2 = e3.seriesType, c2 = e3.getTargetSeries;
    e3.createOnAllSeries ? n2.eachRawSeries(l2) : s2 ? n2.eachRawSeriesByType(s2, l2) : c2 && c2(n2, r2).each(l2);
    function l2(t3) {
      var s3 = t3.uid, c3 = o2.set(s3, a2 && a2.get(s3) || T_({ plan: hy, reset: gy, count: yy }));
      c3.context = { model: t3, ecModel: n2, api: r2, useClearVisual: e3.isVisual && !e3.isLayout, plan: e3.plan, reset: e3.reset, scheduler: i2 }, i2._pipe(t3, c3);
    }
  }, e2.prototype._createOverallStageTask = function(e3, t2, n2, r2) {
    var i2 = this, a2 = t2.overallTask = t2.overallTask || T_({ reset: dy });
    a2.context = { ecModel: n2, api: r2, overallReset: e3.overallReset, scheduler: i2 };
    var o2 = a2.agentStubMap, s2 = a2.agentStubMap = J(), c2 = e3.seriesType, l2 = e3.getTargetSeries, u2 = true, d2 = false;
    lt(!e3.createOnAllSeries, ``), c2 ? n2.eachRawSeriesByType(c2, f2) : l2 ? l2(n2, r2).each(f2) : (u2 = false, z(n2.getSeries(), f2));
    function f2(e4) {
      var t3 = e4.uid, n3 = s2.set(t3, o2 && o2.get(t3) || (d2 = true, T_({ reset: fy, onDirty: my })));
      n3.context = { model: e4, overallProgress: u2 }, n3.agent = a2, n3.__block = u2, i2._pipe(e4, n3);
    }
    d2 && a2.dirty();
  }, e2.prototype._pipe = function(e3, t2) {
    var n2 = e3.uid, r2 = this._pipelineMap.get(n2);
    !r2.head && (r2.head = t2), r2.tail && r2.tail.pipe(t2), r2.tail = t2, t2.__idxInPipeline = r2.count++, t2.__pipeline = r2;
  }, e2.wrapStageHandler = function(e3, t2) {
    return U(e3) && (e3 = { overallReset: e3, seriesType: by(e3) }), e3.uid = cm(`stageHandler`), t2 && (e3.visualType = t2), e3;
  }, e2;
})();
function dy(e2) {
  e2.overallReset(e2.ecModel, e2.api, e2.payload);
}
function fy(e2) {
  return e2.overallProgress && py;
}
function py() {
  this.agent.dirty(), this.getDownstream().dirty();
}
function my() {
  this.agent && this.agent.dirty();
}
function hy(e2) {
  return e2.plan ? e2.plan(e2.model, e2.ecModel, e2.api, e2.payload) : null;
}
function gy(e2) {
  e2.useClearVisual && e2.data.clearAllVisual();
  var t2 = e2.resetDefines = gs(e2.reset(e2.model, e2.ecModel, e2.api, e2.payload));
  return t2.length > 1 ? B(t2, function(e3, t3) {
    return vy(t3);
  }) : _y;
}
var _y = vy(0);
function vy(e2) {
  return function(t2, n2) {
    var r2 = n2.data, i2 = n2.resetDefines[e2];
    if (i2 && i2.dataEach) for (var a2 = t2.start; a2 < t2.end; a2++) i2.dataEach(r2, a2);
    else i2 && i2.progress && i2.progress(t2, r2);
  };
}
function yy(e2) {
  return e2.data.count();
}
function by(e2) {
  Cy = null;
  try {
    e2(xy, Sy);
  } catch {
  }
  return Cy;
}
var xy = {}, Sy = {}, Cy;
wy(xy, og), wy(Sy, pg), xy.eachSeriesByType = xy.eachRawSeriesByType = function(e2) {
  Cy = e2;
}, xy.eachComponent = function(e2) {
  e2.mainType === `series` && e2.subType && (Cy = e2.subType);
};
function wy(e2, t2) {
  for (var n2 in t2.prototype) e2[n2] = St;
}
var Ty = [`#37A2DA`, `#32C5E9`, `#67E0E3`, `#9FE6B8`, `#FFDB5C`, `#ff9f7f`, `#fb7293`, `#E062AE`, `#E690D1`, `#e7bcf3`, `#9d96f5`, `#8378EA`, `#96BFFF`], Ey = { color: Ty, colorLayer: [[`#37A2DA`, `#ffd85c`, `#fd7b5f`], [`#37A2DA`, `#67E0E3`, `#FFDB5C`, `#ff9f7f`, `#E062AE`, `#9d96f5`], [`#37A2DA`, `#32C5E9`, `#9FE6B8`, `#FFDB5C`, `#ff9f7f`, `#fb7293`, `#e7bcf3`, `#8378EA`, `#96BFFF`], Ty] }, Dy = `#B9B8CE`, Oy = `#100C2A`, ky = function() {
  return { axisLine: { lineStyle: { color: Dy } }, splitLine: { lineStyle: { color: `#484753` } }, splitArea: { areaStyle: { color: [`rgba(255,255,255,0.02)`, `rgba(255,255,255,0.05)`] } }, minorSplitLine: { lineStyle: { color: `#20203B` } } };
}, Ay = [`#4992ff`, `#7cffb2`, `#fddd60`, `#ff6e76`, `#58d9f9`, `#05c091`, `#ff8a45`, `#8d48e3`, `#dd79ff`], jy = { darkMode: true, color: Ay, backgroundColor: Oy, axisPointer: { lineStyle: { color: `#817f91` }, crossStyle: { color: `#817f91` }, label: { color: `#fff` } }, legend: { textStyle: { color: Dy }, pageTextStyle: { color: Dy } }, textStyle: { color: Dy }, title: { textStyle: { color: `#EEF1FA` }, subtextStyle: { color: `#B9B8CE` } }, toolbox: { iconStyle: { borderColor: Dy } }, dataZoom: { borderColor: `#71708A`, textStyle: { color: Dy }, brushStyle: { color: `rgba(135,163,206,0.3)` }, handleStyle: { color: `#353450`, borderColor: `#C5CBE3` }, moveHandleStyle: { color: `#B0B6C3`, opacity: 0.3 }, fillerColor: `rgba(135,163,206,0.2)`, emphasis: { handleStyle: { borderColor: `#91B7F2`, color: `#4D587D` }, moveHandleStyle: { color: `#636D9A`, opacity: 0.7 } }, dataBackground: { lineStyle: { color: `#71708A`, width: 1 }, areaStyle: { color: `#71708A` } }, selectedDataBackground: { lineStyle: { color: `#87A3CE` }, areaStyle: { color: `#87A3CE` } } }, visualMap: { textStyle: { color: Dy } }, timeline: { lineStyle: { color: Dy }, label: { color: Dy }, controlStyle: { color: Dy, borderColor: Dy } }, calendar: { itemStyle: { color: Oy }, dayLabel: { color: Dy }, monthLabel: { color: Dy }, yearLabel: { color: Dy } }, timeAxis: ky(), logAxis: ky(), valueAxis: ky(), categoryAxis: ky(), line: { symbol: `circle` }, graph: { color: Ay }, gauge: { title: { color: Dy }, axisLine: { lineStyle: { color: [[1, `rgba(207,212,219,0.2)`]] } }, axisLabel: { color: Dy }, detail: { color: `#EEF1FA` } }, candlestick: { itemStyle: { color: `#f64e56`, color0: `#54ea92`, borderColor: `#f64e56`, borderColor0: `#54ea92` } } };
jy.categoryAxis.splitLine.show = false;
var My = (function() {
  function e2() {
  }
  return e2.prototype.normalizeQuery = function(e3) {
    var t2 = {}, n2 = {}, r2 = {};
    if (W(e3)) {
      var i2 = Zs(e3);
      t2.mainType = i2.main || null, t2.subType = i2.sub || null;
    } else {
      var a2 = [`Index`, `Name`, `Id`], o2 = { name: 1, dataIndex: 1, dataType: 1 };
      z(e3, function(e4, i3) {
        for (var s2 = false, c2 = 0; c2 < a2.length; c2++) {
          var l2 = a2[c2], u2 = i3.lastIndexOf(l2);
          if (u2 > 0 && u2 === i3.length - l2.length) {
            var d2 = i3.slice(0, u2);
            d2 !== `data` && (t2.mainType = d2, t2[l2.toLowerCase()] = e4, s2 = true);
          }
        }
        o2.hasOwnProperty(i3) && (n2[i3] = e4, s2 = true), s2 || (r2[i3] = e4);
      });
    }
    return { cptQuery: t2, dataQuery: n2, otherQuery: r2 };
  }, e2.prototype.filter = function(e3, t2) {
    var n2 = this.eventInfo;
    if (!n2) return true;
    var r2 = n2.targetEl, i2 = n2.packedEvent, a2 = n2.model, o2 = n2.view;
    if (!a2 || !o2) return true;
    var s2 = t2.cptQuery, c2 = t2.dataQuery;
    return l2(s2, a2, `mainType`) && l2(s2, a2, `subType`) && l2(s2, a2, `index`, `componentIndex`) && l2(s2, a2, `name`) && l2(s2, a2, `id`) && l2(c2, i2, `name`) && l2(c2, i2, `dataIndex`) && l2(c2, i2, `dataType`) && (!o2.filterForExposedEvent || o2.filterForExposedEvent(e3, t2.otherQuery, r2, i2));
    function l2(e4, t3, n3, r3) {
      return e4[n3] == null || t3[r3 || n3] === e4[n3];
    }
  }, e2.prototype.afterTrigger = function() {
    this.eventInfo = null;
  }, e2;
})(), Ny = [`symbol`, `symbolSize`, `symbolRotate`, `symbolOffset`], Py = Ny.concat([`symbolKeepAspect`]), Fy = { createOnAllSeries: true, performRawSeries: true, reset: function(e2, t2) {
  var n2 = e2.getData();
  if (e2.legendIcon && n2.setVisual(`legendIcon`, e2.legendIcon), !e2.hasSymbolVisual) return;
  for (var r2 = {}, i2 = {}, a2 = false, o2 = 0; o2 < Ny.length; o2++) {
    var s2 = Ny[o2], c2 = e2.get(s2);
    U(c2) ? (a2 = true, i2[s2] = c2) : r2[s2] = c2;
  }
  if (r2.symbol = r2.symbol || e2.defaultSymbol, n2.setVisual(R({ legendIcon: e2.legendIcon || r2.symbol, symbolKeepAspect: e2.get(`symbolKeepAspect`) }, r2)), t2.isSeriesFiltered(e2)) return;
  var l2 = V(i2);
  function u2(t3, n3) {
    for (var r3 = e2.getRawValue(n3), a3 = e2.getDataParams(n3), o3 = 0; o3 < l2.length; o3++) {
      var s3 = l2[o3];
      t3.setItemVisual(n3, s3, i2[s3](r3, a3));
    }
  }
  return { dataEach: a2 ? u2 : null };
} }, Iy = { createOnAllSeries: true, performRawSeries: true, reset: function(e2, t2) {
  if (!e2.hasSymbolVisual || t2.isSeriesFiltered(e2)) return;
  var n2 = e2.getData();
  function r2(e3, t3) {
    for (var n3 = e3.getItemModel(t3), r3 = 0; r3 < Py.length; r3++) {
      var i2 = Py[r3], a2 = n3.getShallow(i2, true);
      a2 != null && e3.setItemVisual(t3, i2, a2);
    }
  }
  return { dataEach: n2.hasItemOption ? r2 : null };
} };
function Ly(e2, t2, n2) {
  switch (n2) {
    case `color`:
      return e2.getItemVisual(t2, `style`)[e2.getVisual(`drawType`)];
    case `opacity`:
      return e2.getItemVisual(t2, `style`).opacity;
    case `symbol`:
    case `symbolSize`:
    case `liftZ`:
      return e2.getItemVisual(t2, n2);
  }
}
function Ry(e2, t2) {
  switch (t2) {
    case `color`:
      return e2.getVisual(`style`)[e2.getVisual(`drawType`)];
    case `opacity`:
      return e2.getVisual(`style`).opacity;
    case `symbol`:
    case `symbolSize`:
    case `liftZ`:
      return e2.getVisual(t2);
  }
}
function zy(e2, t2, n2, r2, i2) {
  var a2 = e2 + t2;
  n2.isSilent(a2) || r2.eachComponent({ mainType: `series`, subType: `pie` }, function(e3) {
    for (var t3 = e3.seriesIndex, r3 = e3.option.selectedMap, o2 = i2.selected, s2 = 0; s2 < o2.length; s2++) if (o2[s2].seriesIndex === t3) {
      var c2 = e3.getData(), l2 = Is(c2, i2.fromActionPayload);
      n2.trigger(a2, { type: a2, seriesId: e3.id, name: H(l2) ? c2.getName(l2[0]) : c2.getName(l2), selected: W(r3) ? r3 : R({}, r3) });
    }
  });
}
function By(e2, t2, n2) {
  e2.on(`selectchanged`, function(e3) {
    var r2 = n2.getModel();
    e3.isFromClick ? (zy(`map`, `selectchanged`, t2, r2, e3), zy(`pie`, `selectchanged`, t2, r2, e3)) : e3.fromAction === `select` ? (zy(`map`, `selected`, t2, r2, e3), zy(`pie`, `selected`, t2, r2, e3)) : e3.fromAction === `unselect` && (zy(`map`, `unselected`, t2, r2, e3), zy(`pie`, `unselected`, t2, r2, e3));
  });
}
function Vy(e2, t2, n2) {
  for (var r2; e2 && !(t2(e2) && (r2 = e2, n2)); ) e2 = e2.__hostTarget || e2.parent;
  return r2;
}
var Hy = Math.round(Math.random() * 9), Uy = typeof Object.defineProperty == `function`, Wy = (function() {
  function e2() {
    this._id = `__ec_inner_` + Hy++;
  }
  return e2.prototype.get = function(e3) {
    return this._guard(e3)[this._id];
  }, e2.prototype.set = function(e3, t2) {
    var n2 = this._guard(e3);
    return Uy ? Object.defineProperty(n2, this._id, { value: t2, enumerable: false, configurable: true }) : n2[this._id] = t2, this;
  }, e2.prototype.delete = function(e3) {
    return this.has(e3) ? (delete this._guard(e3)[this._id], true) : false;
  }, e2.prototype.has = function(e3) {
    return !!this._guard(e3)[this._id];
  }, e2.prototype._guard = function(e3) {
    if (e3 !== Object(e3)) throw TypeError(`Value of WeakMap is not a non-null object.`);
    return e3;
  }, e2;
})(), Gy = Q.extend({ type: `triangle`, shape: { cx: 0, cy: 0, width: 0, height: 0 }, buildPath: function(e2, t2) {
  var n2 = t2.cx, r2 = t2.cy, i2 = t2.width / 2, a2 = t2.height / 2;
  e2.moveTo(n2, r2 - a2), e2.lineTo(n2 + i2, r2 + a2), e2.lineTo(n2 - i2, r2 + a2), e2.closePath();
} }), Ky = { line: Of, rect: nu, roundRect: nu, square: nu, circle: Zd, diamond: Q.extend({ type: `diamond`, shape: { cx: 0, cy: 0, width: 0, height: 0 }, buildPath: function(e2, t2) {
  var n2 = t2.cx, r2 = t2.cy, i2 = t2.width / 2, a2 = t2.height / 2;
  e2.moveTo(n2, r2 - a2), e2.lineTo(n2 + i2, r2), e2.lineTo(n2, r2 + a2), e2.lineTo(n2 - i2, r2), e2.closePath();
} }), pin: Q.extend({ type: `pin`, shape: { x: 0, y: 0, width: 0, height: 0 }, buildPath: function(e2, t2) {
  var n2 = t2.x, r2 = t2.y, i2 = t2.width / 5 * 3, a2 = Math.max(i2, t2.height), o2 = i2 / 2, s2 = o2 * o2 / (a2 - o2), c2 = r2 - a2 + o2 + s2, l2 = Math.asin(s2 / o2), u2 = Math.cos(l2) * o2, d2 = Math.sin(l2), f2 = Math.cos(l2), p2 = o2 * 0.6, m2 = o2 * 0.7;
  e2.moveTo(n2 - u2, c2 + s2), e2.arc(n2, c2, o2, Math.PI - l2, Math.PI * 2 + l2), e2.bezierCurveTo(n2 + u2 - d2 * p2, c2 + s2 + f2 * p2, n2, r2 - m2, n2, r2), e2.bezierCurveTo(n2, r2 - m2, n2 - u2 + d2 * p2, c2 + s2 + f2 * p2, n2 - u2, c2 + s2), e2.closePath();
} }), arrow: Q.extend({ type: `arrow`, shape: { x: 0, y: 0, width: 0, height: 0 }, buildPath: function(e2, t2) {
  var n2 = t2.height, r2 = t2.width, i2 = t2.x, a2 = t2.y, o2 = r2 / 3 * 2;
  e2.moveTo(i2, a2), e2.lineTo(i2 + o2, a2 + n2), e2.lineTo(i2, a2 + n2 / 4 * 3), e2.lineTo(i2 - o2, a2 + n2), e2.lineTo(i2, a2), e2.closePath();
} }), triangle: Gy }, qy = { line: function(e2, t2, n2, r2, i2) {
  i2.x1 = e2, i2.y1 = t2 + r2 / 2, i2.x2 = e2 + n2, i2.y2 = t2 + r2 / 2;
}, rect: function(e2, t2, n2, r2, i2) {
  i2.x = e2, i2.y = t2, i2.width = n2, i2.height = r2;
}, roundRect: function(e2, t2, n2, r2, i2) {
  i2.x = e2, i2.y = t2, i2.width = n2, i2.height = r2, i2.r = Math.min(n2, r2) / 4;
}, square: function(e2, t2, n2, r2, i2) {
  var a2 = Math.min(n2, r2);
  i2.x = e2, i2.y = t2, i2.width = a2, i2.height = a2;
}, circle: function(e2, t2, n2, r2, i2) {
  i2.cx = e2 + n2 / 2, i2.cy = t2 + r2 / 2, i2.r = Math.min(n2, r2) / 2;
}, diamond: function(e2, t2, n2, r2, i2) {
  i2.cx = e2 + n2 / 2, i2.cy = t2 + r2 / 2, i2.width = n2, i2.height = r2;
}, pin: function(e2, t2, n2, r2, i2) {
  i2.x = e2 + n2 / 2, i2.y = t2 + r2 / 2, i2.width = n2, i2.height = r2;
}, arrow: function(e2, t2, n2, r2, i2) {
  i2.x = e2 + n2 / 2, i2.y = t2 + r2 / 2, i2.width = n2, i2.height = r2;
}, triangle: function(e2, t2, n2, r2, i2) {
  i2.cx = e2 + n2 / 2, i2.cy = t2 + r2 / 2, i2.width = n2, i2.height = r2;
} }, Jy = {};
z(Ky, function(e2, t2) {
  Jy[t2] = new e2();
});
var Yy = Q.extend({ type: `symbol`, shape: { symbolType: ``, x: 0, y: 0, width: 0, height: 0 }, calculateTextPosition: function(e2, t2, n2) {
  var r2 = so(e2, t2, n2), i2 = this.shape;
  return i2 && i2.symbolType === `pin` && t2.position === `inside` && (r2.y = n2.y + n2.height * 0.4), r2;
}, buildPath: function(e2, t2, n2) {
  var r2 = t2.symbolType;
  if (r2 !== `none`) {
    var i2 = Jy[r2];
    i2 || (i2 = (r2 = `rect`, Jy[r2])), qy[r2](t2.x, t2.y, t2.width, t2.height, i2.shape), i2.buildPath(e2, i2.shape, n2);
  }
} });
function Xy(e2, t2) {
  if (this.type !== `image`) {
    var n2 = this.style;
    this.__isEmptyBrush ? (n2.stroke = e2, n2.fill = t2 || `#fff`, n2.lineWidth = 2) : this.shape.symbolType === `line` ? n2.stroke = e2 : n2.fill = e2, this.markRedraw();
  }
}
function Zy(e2, t2, n2, r2, i2, a2, o2) {
  var s2 = e2.indexOf(`empty`) === 0;
  s2 && (e2 = e2.substr(5, 1).toLowerCase() + e2.substr(6));
  var c2 = e2.indexOf(`image://`) === 0 ? fp(e2.slice(8), new X(t2, n2, r2, i2), o2 ? `center` : `cover`) : e2.indexOf(`path://`) === 0 ? dp(e2.slice(7), {}, new X(t2, n2, r2, i2), o2 ? `center` : `cover`) : new Yy({ shape: { symbolType: e2, x: t2, y: n2, width: r2, height: i2 } });
  return c2.__isEmptyBrush = s2, c2.setColor = Xy, a2 && c2.setColor(a2), c2;
}
function Qy(e2) {
  return H(e2) || (e2 = [+e2, +e2]), [e2[0] || 0, e2[1] || 0];
}
function $y(e2, t2) {
  if (e2 != null) return H(e2) || (e2 = [e2, e2]), [Ho(e2[0], t2[0]) || 0, Ho(q(e2[1], e2[0]), t2[1]) || 0];
}
function eb(e2) {
  return isFinite(e2);
}
function tb(e2, t2, n2) {
  var r2 = t2.x == null ? 0 : t2.x, i2 = t2.x2 == null ? 1 : t2.x2, a2 = t2.y == null ? 0 : t2.y, o2 = t2.y2 == null ? 0 : t2.y2;
  return t2.global || (r2 = r2 * n2.width + n2.x, i2 = i2 * n2.width + n2.x, a2 = a2 * n2.height + n2.y, o2 = o2 * n2.height + n2.y), r2 = eb(r2) ? r2 : 0, i2 = eb(i2) ? i2 : 1, a2 = eb(a2) ? a2 : 0, o2 = eb(o2) ? o2 : 0, e2.createLinearGradient(r2, a2, i2, o2);
}
function nb(e2, t2, n2) {
  var r2 = n2.width, i2 = n2.height, a2 = Math.min(r2, i2), o2 = t2.x == null ? 0.5 : t2.x, s2 = t2.y == null ? 0.5 : t2.y, c2 = t2.r == null ? 0.5 : t2.r;
  return t2.global || (o2 = o2 * r2 + n2.x, s2 = s2 * i2 + n2.y, c2 *= a2), o2 = eb(o2) ? o2 : 0.5, s2 = eb(s2) ? s2 : 0.5, c2 = c2 >= 0 && eb(c2) ? c2 : 0.5, e2.createRadialGradient(o2, s2, 0, o2, s2, c2);
}
function rb(e2, t2, n2) {
  for (var r2 = t2.type === `radial` ? nb(e2, t2, n2) : tb(e2, t2, n2), i2 = t2.colorStops, a2 = 0; a2 < i2.length; a2++) r2.addColorStop(i2[a2].offset, i2[a2].color);
  return r2;
}
function ib(e2, t2) {
  if (e2 === t2 || !e2 && !t2) return false;
  if (!e2 || !t2 || e2.length !== t2.length) return true;
  for (var n2 = 0; n2 < e2.length; n2++) if (e2[n2] !== t2[n2]) return true;
  return false;
}
function ab(e2) {
  return parseInt(e2, 10);
}
function ob(e2, t2, n2) {
  var r2 = [`width`, `height`][t2], i2 = [`clientWidth`, `clientHeight`][t2], a2 = [`paddingLeft`, `paddingTop`][t2], o2 = [`paddingRight`, `paddingBottom`][t2];
  if (n2[r2] != null && n2[r2] !== `auto`) return parseFloat(n2[r2]);
  var s2 = document.defaultView.getComputedStyle(e2);
  return (e2[i2] || ab(s2[r2]) || ab(e2.style[r2])) - (ab(s2[a2]) || 0) - (ab(s2[o2]) || 0) | 0;
}
function sb(e2, t2) {
  return !e2 || e2 === `solid` || !(t2 > 0) ? null : e2 === `dashed` ? [4 * t2, 2 * t2] : e2 === `dotted` ? [t2] : G(e2) ? [e2] : H(e2) ? e2 : null;
}
function cb(e2) {
  var t2 = e2.style, n2 = t2.lineDash && t2.lineWidth > 0 && sb(t2.lineDash, t2.lineWidth), r2 = t2.lineDashOffset;
  if (n2) {
    var i2 = t2.strokeNoScale && e2.getLineScale ? e2.getLineScale() : 1;
    i2 && i2 !== 1 && (n2 = B(n2, function(e3) {
      return e3 / i2;
    }), r2 /= i2);
  }
  return [n2, r2];
}
var lb = new vl(true);
function ub(e2) {
  var t2 = e2.stroke;
  return !(t2 == null || t2 === `none` || !(e2.lineWidth > 0));
}
function db(e2) {
  return typeof e2 == `string` && e2 !== `none`;
}
function fb(e2) {
  var t2 = e2.fill;
  return t2 != null && t2 !== `none`;
}
function pb(e2, t2) {
  if (t2.fillOpacity != null && t2.fillOpacity !== 1) {
    var n2 = e2.globalAlpha;
    e2.globalAlpha = t2.fillOpacity * t2.opacity, e2.fill(), e2.globalAlpha = n2;
  } else e2.fill();
}
function mb(e2, t2) {
  if (t2.strokeOpacity != null && t2.strokeOpacity !== 1) {
    var n2 = e2.globalAlpha;
    e2.globalAlpha = t2.strokeOpacity * t2.opacity, e2.stroke(), e2.globalAlpha = n2;
  } else e2.stroke();
}
function hb(e2, t2, n2) {
  var r2 = pc(t2.image, t2.__image, n2);
  if (hc(r2)) {
    var i2 = e2.createPattern(r2, t2.repeat || `repeat`);
    if (typeof DOMMatrix == `function` && i2 && i2.setTransform) {
      var a2 = new DOMMatrix();
      a2.translateSelf(t2.x || 0, t2.y || 0), a2.rotateSelf(0, 0, (t2.rotation || 0) * Ct), a2.scaleSelf(t2.scaleX || 1, t2.scaleY || 1), i2.setTransform(a2);
    }
    return i2;
  }
}
function gb(e2, t2, n2, r2) {
  var i2, a2 = ub(n2), o2 = fb(n2), s2 = n2.strokePercent, c2 = s2 < 1, l2 = !t2.path;
  (!t2.silent || c2) && l2 && t2.createPathProxy();
  var u2 = t2.path || lb, d2 = t2.__dirty;
  if (!r2) {
    var f2 = n2.fill, p2 = n2.stroke, m2 = o2 && !!f2.colorStops, h2 = a2 && !!p2.colorStops, g2 = o2 && !!f2.image, _2 = a2 && !!p2.image, v2 = void 0, y2 = void 0, b2 = void 0, x2 = void 0, S2 = void 0;
    (m2 || h2) && (S2 = t2.getBoundingRect()), m2 && (v2 = d2 ? rb(e2, f2, S2) : t2.__canvasFillGradient, t2.__canvasFillGradient = v2), h2 && (y2 = d2 ? rb(e2, p2, S2) : t2.__canvasStrokeGradient, t2.__canvasStrokeGradient = y2), g2 && (b2 = d2 || !t2.__canvasFillPattern ? hb(e2, f2, t2) : t2.__canvasFillPattern, t2.__canvasFillPattern = b2), _2 && (x2 = d2 || !t2.__canvasStrokePattern ? hb(e2, p2, t2) : t2.__canvasStrokePattern, t2.__canvasStrokePattern = b2), m2 ? e2.fillStyle = v2 : g2 && (b2 ? e2.fillStyle = b2 : o2 = false), h2 ? e2.strokeStyle = y2 : _2 && (x2 ? e2.strokeStyle = x2 : a2 = false);
  }
  var C2 = t2.getGlobalScale();
  u2.setScale(C2[0], C2[1], t2.segmentIgnoreThreshold);
  var w2, T2;
  e2.setLineDash && n2.lineDash && (i2 = cb(t2), w2 = i2[0], T2 = i2[1]);
  var E2 = true;
  (l2 || d2 & 4) && (u2.setDPR(e2.dpr), c2 ? u2.setContext(null) : (u2.setContext(e2), E2 = false), u2.reset(), t2.buildPath(u2, t2.shape, r2), u2.toStatic(), t2.pathUpdated()), E2 && u2.rebuildPath(e2, c2 ? s2 : 1), w2 && (e2.setLineDash(w2), e2.lineDashOffset = T2), r2 || (n2.strokeFirst ? (a2 && mb(e2, n2), o2 && pb(e2, n2)) : (o2 && pb(e2, n2), a2 && mb(e2, n2))), w2 && e2.setLineDash([]);
}
function _b(e2, t2, n2) {
  var r2 = t2.__image = pc(n2.image, t2.__image, t2, t2.onload);
  if (r2 && hc(r2)) {
    var i2 = n2.x || 0, a2 = n2.y || 0, o2 = t2.getWidth(), s2 = t2.getHeight(), c2 = r2.width / r2.height;
    if (o2 == null && s2 != null ? o2 = s2 * c2 : s2 == null && o2 != null ? s2 = o2 / c2 : o2 == null && s2 == null && (o2 = r2.width, s2 = r2.height), n2.sWidth && n2.sHeight) {
      var l2 = n2.sx || 0, u2 = n2.sy || 0;
      e2.drawImage(r2, l2, u2, n2.sWidth, n2.sHeight, i2, a2, o2, s2);
    } else if (n2.sx && n2.sy) {
      var l2 = n2.sx, u2 = n2.sy, d2 = o2 - l2, f2 = s2 - u2;
      e2.drawImage(r2, l2, u2, d2, f2, i2, a2, o2, s2);
    } else e2.drawImage(r2, i2, a2, o2, s2);
  }
}
function vb(e2, t2, n2) {
  var r2, i2 = n2.text;
  if (i2 != null && (i2 += ``), i2) {
    e2.font = n2.font || `12px sans-serif`, e2.textAlign = n2.textAlign, e2.textBaseline = n2.textBaseline;
    var a2 = void 0, o2 = void 0;
    e2.setLineDash && n2.lineDash && (r2 = cb(t2), a2 = r2[0], o2 = r2[1]), a2 && (e2.setLineDash(a2), e2.lineDashOffset = o2), n2.strokeFirst ? (ub(n2) && e2.strokeText(i2, n2.x, n2.y), fb(n2) && e2.fillText(i2, n2.x, n2.y)) : (fb(n2) && e2.fillText(i2, n2.x, n2.y), ub(n2) && e2.strokeText(i2, n2.x, n2.y)), a2 && e2.setLineDash([]);
  }
}
var yb = [`shadowBlur`, `shadowOffsetX`, `shadowOffsetY`], bb = [[`lineCap`, `butt`], [`lineJoin`, `miter`], [`miterLimit`, 10]];
function xb(e2, t2, n2, r2, i2) {
  var a2 = false;
  if (!r2 && (n2 || (n2 = {}), t2 === n2)) return false;
  if (r2 || t2.opacity !== n2.opacity) {
    Mb(e2, i2), a2 = true;
    var o2 = Math.max(Math.min(t2.opacity, 1), 0);
    e2.globalAlpha = isNaN(o2) ? Nc.opacity : o2;
  }
  (r2 || t2.blend !== n2.blend) && (a2 || (a2 = (Mb(e2, i2), true)), e2.globalCompositeOperation = t2.blend || Nc.blend);
  for (var s2 = 0; s2 < yb.length; s2++) {
    var c2 = yb[s2];
    (r2 || t2[c2] !== n2[c2]) && (a2 || (a2 = (Mb(e2, i2), true)), e2[c2] = e2.dpr * (t2[c2] || 0));
  }
  return (r2 || t2.shadowColor !== n2.shadowColor) && (a2 || (a2 = (Mb(e2, i2), true)), e2.shadowColor = t2.shadowColor || Nc.shadowColor), a2;
}
function Sb(e2, t2, n2, r2, i2) {
  var a2 = Nb(t2, i2.inHover), o2 = r2 ? null : n2 && Nb(n2, i2.inHover) || {};
  if (a2 === o2) return false;
  var s2 = xb(e2, a2, o2, r2, i2);
  if ((r2 || a2.fill !== o2.fill) && (s2 || (s2 = (Mb(e2, i2), true)), db(a2.fill) && (e2.fillStyle = a2.fill)), (r2 || a2.stroke !== o2.stroke) && (s2 || (s2 = (Mb(e2, i2), true)), db(a2.stroke) && (e2.strokeStyle = a2.stroke)), (r2 || a2.opacity !== o2.opacity) && (s2 || (s2 = (Mb(e2, i2), true)), e2.globalAlpha = a2.opacity == null ? 1 : a2.opacity), t2.hasStroke()) {
    var c2 = a2.lineWidth / (a2.strokeNoScale && t2.getLineScale ? t2.getLineScale() : 1);
    e2.lineWidth !== c2 && (s2 || (s2 = (Mb(e2, i2), true)), e2.lineWidth = c2);
  }
  for (var l2 = 0; l2 < bb.length; l2++) {
    var u2 = bb[l2], d2 = u2[0];
    (r2 || a2[d2] !== o2[d2]) && (s2 || (s2 = (Mb(e2, i2), true)), e2[d2] = a2[d2] || u2[1]);
  }
  return s2;
}
function Cb(e2, t2, n2, r2, i2) {
  return xb(e2, Nb(t2, i2.inHover), n2 && Nb(n2, i2.inHover), r2, i2);
}
function wb(e2, t2) {
  var n2 = t2.transform, r2 = e2.dpr || 1;
  n2 ? e2.setTransform(r2 * n2[0], r2 * n2[1], r2 * n2[2], r2 * n2[3], r2 * n2[4], r2 * n2[5]) : e2.setTransform(r2, 0, 0, r2, 0, 0);
}
function Tb(e2, t2, n2) {
  for (var r2 = false, i2 = 0; i2 < e2.length; i2++) {
    var a2 = e2[i2];
    r2 || (r2 = a2.isZeroArea()), wb(t2, a2), t2.beginPath(), a2.buildPath(t2, a2.shape), t2.clip();
  }
  n2.allClipped = r2;
}
function Eb(e2, t2) {
  return e2 && t2 ? e2[0] !== t2[0] || e2[1] !== t2[1] || e2[2] !== t2[2] || e2[3] !== t2[3] || e2[4] !== t2[4] || e2[5] !== t2[5] : !(!e2 && !t2);
}
var Db = 1, Ob = 2, kb = 3, Ab = 4;
function jb(e2) {
  var t2 = fb(e2), n2 = ub(e2);
  return !(e2.lineDash || !(+t2 ^ n2) || t2 && typeof e2.fill != `string` || n2 && typeof e2.stroke != `string` || e2.strokePercent < 1 || e2.strokeOpacity < 1 || e2.fillOpacity < 1);
}
function Mb(e2, t2) {
  t2.batchFill && e2.fill(), t2.batchStroke && e2.stroke(), t2.batchFill = ``, t2.batchStroke = ``;
}
function Nb(e2, t2) {
  return t2 && e2.__hoverStyle || e2.style;
}
function Pb(e2, t2) {
  Fb(e2, t2, { inHover: false, viewWidth: 0, viewHeight: 0 }, true);
}
function Fb(e2, t2, n2, r2) {
  var i2 = t2.transform;
  if (!t2.shouldBePainted(n2.viewWidth, n2.viewHeight, false, false)) {
    t2.__dirty &= -2, t2.__isRendered = false;
    return;
  }
  var a2 = t2.__clipPaths, o2 = n2.prevElClipPaths, s2 = false, c2 = false;
  if ((!o2 || ib(a2, o2)) && (o2 && o2.length && (Mb(e2, n2), e2.restore(), c2 = s2 = true, n2.prevElClipPaths = null, n2.allClipped = false, n2.prevEl = null), a2 && a2.length && (Mb(e2, n2), e2.save(), Tb(a2, e2, n2), s2 = true), n2.prevElClipPaths = a2), n2.allClipped) {
    t2.__isRendered = false;
    return;
  }
  t2.beforeBrush && t2.beforeBrush(), t2.innerBeforeBrush();
  var l2 = n2.prevEl;
  l2 || (c2 = s2 = true);
  var u2 = t2 instanceof Q && t2.autoBatch && jb(t2.style);
  s2 || Eb(i2, l2.transform) ? (Mb(e2, n2), wb(e2, t2)) : u2 || Mb(e2, n2);
  var d2 = Nb(t2, n2.inHover);
  t2 instanceof Q ? (n2.lastDrawType !== Db && (c2 = true, n2.lastDrawType = Db), Sb(e2, t2, l2, c2, n2), (!u2 || !n2.batchFill && !n2.batchStroke) && e2.beginPath(), gb(e2, t2, d2, u2), u2 && (n2.batchFill = d2.fill || ``, n2.batchStroke = d2.stroke || ``)) : t2 instanceof Wl ? (n2.lastDrawType !== kb && (c2 = true, n2.lastDrawType = kb), Sb(e2, t2, l2, c2, n2), vb(e2, t2, d2)) : t2 instanceof Jl ? (n2.lastDrawType !== Ob && (c2 = true, n2.lastDrawType = Ob), Cb(e2, t2, l2, c2, n2), _b(e2, t2, d2)) : t2.getTemporalDisplayables && (n2.lastDrawType !== Ab && (c2 = true, n2.lastDrawType = Ab), Ib(e2, t2, n2)), u2 && r2 && Mb(e2, n2), t2.innerAfterBrush(), t2.afterBrush && t2.afterBrush(), n2.prevEl = t2, t2.__dirty = 0, t2.__isRendered = true;
}
function Ib(e2, t2, n2) {
  var r2 = t2.getDisplayables(), i2 = t2.getTemporalDisplayables();
  e2.save();
  for (var a2 = { prevElClipPaths: null, prevEl: null, allClipped: false, viewWidth: n2.viewWidth, viewHeight: n2.viewHeight, inHover: n2.inHover }, o2 = t2.getCursor(), s2 = r2.length; o2 < s2; o2++) {
    var c2 = r2[o2];
    c2.beforeBrush && c2.beforeBrush(), c2.innerBeforeBrush(), Fb(e2, c2, a2, o2 === s2 - 1), c2.innerAfterBrush(), c2.afterBrush && c2.afterBrush(), a2.prevEl = c2;
  }
  for (var l2 = 0, u2 = i2.length; l2 < u2; l2++) {
    var c2 = i2[l2];
    c2.beforeBrush && c2.beforeBrush(), c2.innerBeforeBrush(), Fb(e2, c2, a2, l2 === u2 - 1), c2.innerAfterBrush(), c2.afterBrush && c2.afterBrush(), a2.prevEl = c2;
  }
  t2.clearTemporalDisplayables(), t2.notClear = true, e2.restore();
}
var Lb = new Wy(), Rb = new Yr(100), zb = [`symbol`, `symbolSize`, `symbolKeepAspect`, `color`, `backgroundColor`, `dashArrayX`, `dashArrayY`, `maxTileWidth`, `maxTileHeight`];
function Bb(e2, t2) {
  if (e2 === `none`) return null;
  var n2 = t2.getDevicePixelRatio(), r2 = t2.getZr(), i2 = r2.painter.type === `svg`;
  e2.dirty && Lb.delete(e2);
  var a2 = Lb.get(e2);
  if (a2) return a2;
  var o2 = ze(e2, { symbol: `rect`, symbolSize: 1, symbolKeepAspect: true, color: `rgba(0, 0, 0, 0.2)`, backgroundColor: null, dashArrayX: 5, dashArrayY: 5, rotation: 0, maxTileWidth: 512, maxTileHeight: 512 });
  o2.backgroundColor === `none` && (o2.backgroundColor = null);
  var s2 = { repeat: `repeat` };
  return c2(s2), s2.rotation = o2.rotation, s2.scaleX = s2.scaleY = i2 ? 1 : 1 / n2, Lb.set(e2, s2), e2.dirty = false, s2;
  function c2(e3) {
    for (var t3 = [n2], a3 = true, s3 = 0; s3 < zb.length; ++s3) {
      var c3 = o2[zb[s3]];
      if (c3 != null && !H(c3) && !W(c3) && !G(c3) && typeof c3 != `boolean`) {
        a3 = false;
        break;
      }
      t3.push(c3);
    }
    var l2;
    if (a3) {
      l2 = t3.join(`,`) + (i2 ? `-svg` : ``);
      var u2 = Rb.get(l2);
      u2 && (i2 ? e3.svgElement = u2 : e3.image = u2);
    }
    var d2 = Hb(o2.dashArrayX), f2 = Ub(o2.dashArrayY), p2 = Vb(o2.symbol), m2 = Wb(d2), h2 = Gb(f2), g2 = !i2 && be.createCanvas(), _2 = i2 && { tag: `g`, attrs: {}, key: `dcl`, children: [] }, v2 = b2(), y2;
    g2 && (g2.width = v2.width * n2, g2.height = v2.height * n2, y2 = g2.getContext(`2d`)), x2(), a3 && Rb.put(l2, g2 || _2), e3.image = g2, e3.svgElement = _2, e3.svgWidth = v2.width, e3.svgHeight = v2.height;
    function b2() {
      for (var e4 = 1, t4 = 0, n3 = m2.length; t4 < n3; ++t4) e4 = ds(e4, m2[t4]);
      for (var r3 = 1, t4 = 0, n3 = p2.length; t4 < n3; ++t4) r3 = ds(r3, p2[t4].length);
      e4 *= r3;
      var i3 = h2 * m2.length * p2.length;
      return { width: Math.max(1, Math.min(e4, o2.maxTileWidth)), height: Math.max(1, Math.min(i3, o2.maxTileHeight)) };
    }
    function x2() {
      y2 && (y2.clearRect(0, 0, g2.width, g2.height), o2.backgroundColor && (y2.fillStyle = o2.backgroundColor, y2.fillRect(0, 0, g2.width, g2.height)));
      for (var e4 = 0, t4 = 0; t4 < f2.length; ++t4) e4 += f2[t4];
      if (e4 <= 0) return;
      for (var a4 = -h2, s4 = 0, c4 = 0, l3 = 0; a4 < v2.height; ) {
        if (s4 % 2 == 0) {
          for (var u3 = c4 / 2 % p2.length, m3 = 0, b3 = 0, x3 = 0; m3 < v2.width * 2; ) {
            for (var S2 = 0, t4 = 0; t4 < d2[l3].length; ++t4) S2 += d2[l3][t4];
            if (S2 <= 0) break;
            if (b3 % 2 == 0) {
              var C2 = (1 - o2.symbolSize) * 0.5, w2 = m3 + d2[l3][b3] * C2, T2 = a4 + f2[s4] * C2, E2 = d2[l3][b3] * o2.symbolSize, D2 = f2[s4] * o2.symbolSize, O2 = x3 / 2 % p2[u3].length;
              k2(w2, T2, E2, D2, p2[u3][O2]);
            }
            m3 += d2[l3][b3], ++x3, ++b3, b3 === d2[l3].length && (b3 = 0);
          }
          ++l3, l3 === d2.length && (l3 = 0);
        }
        a4 += f2[s4], ++c4, ++s4, s4 === f2.length && (s4 = 0);
      }
      function k2(e5, t5, a5, s5, c5) {
        var l4 = i2 ? 1 : n2, u4 = Zy(c5, e5 * l4, t5 * l4, a5 * l4, s5 * l4, o2.color, o2.symbolKeepAspect);
        if (i2) {
          var d3 = r2.painter.renderOneToVNode(u4);
          d3 && _2.children.push(d3);
        } else Pb(y2, u4);
      }
    }
  }
}
function Vb(e2) {
  if (!e2 || e2.length === 0) return [[`rect`]];
  if (W(e2)) return [[e2]];
  for (var t2 = true, n2 = 0; n2 < e2.length; ++n2) if (!W(e2[n2])) {
    t2 = false;
    break;
  }
  if (t2) return Vb([e2]);
  for (var r2 = [], n2 = 0; n2 < e2.length; ++n2) W(e2[n2]) ? r2.push([e2[n2]]) : r2.push(e2[n2]);
  return r2;
}
function Hb(e2) {
  if (!e2 || e2.length === 0) return [[0, 0]];
  if (G(e2)) {
    var t2 = Math.ceil(e2);
    return [[t2, t2]];
  }
  for (var n2 = true, r2 = 0; r2 < e2.length; ++r2) if (!G(e2[r2])) {
    n2 = false;
    break;
  }
  if (n2) return Hb([e2]);
  for (var i2 = [], r2 = 0; r2 < e2.length; ++r2) if (G(e2[r2])) {
    var t2 = Math.ceil(e2[r2]);
    i2.push([t2, t2]);
  } else {
    var t2 = B(e2[r2], function(e3) {
      return Math.ceil(e3);
    });
    t2.length % 2 == 1 ? i2.push(t2.concat(t2)) : i2.push(t2);
  }
  return i2;
}
function Ub(e2) {
  if (!e2 || typeof e2 == `object` && e2.length === 0) return [0, 0];
  if (G(e2)) {
    var t2 = Math.ceil(e2);
    return [t2, t2];
  }
  var n2 = B(e2, function(e3) {
    return Math.ceil(e3);
  });
  return e2.length % 2 ? n2.concat(n2) : n2;
}
function Wb(e2) {
  return B(e2, function(e3) {
    return Gb(e3);
  });
}
function Gb(e2) {
  for (var t2 = 0, n2 = 0; n2 < e2.length; ++n2) t2 += e2[n2];
  return e2.length % 2 == 1 ? t2 * 2 : t2;
}
function Kb(e2, t2) {
  e2.eachRawSeries(function(n2) {
    if (!e2.isSeriesFiltered(n2)) {
      var r2 = n2.getData();
      r2.hasItemVisual() && r2.each(function(e3) {
        var n3 = r2.getItemVisual(e3, `decal`);
        if (n3) {
          var i3 = r2.ensureUniqueItemVisual(e3, `style`);
          i3.decal = Bb(n3, t2);
        }
      });
      var i2 = r2.getVisual(`decal`);
      if (i2) {
        var a2 = r2.getVisual(`style`);
        a2.decal = Bb(i2, t2);
      }
    }
  });
}
var qb = new Qt(), Jb = {};
function Yb(e2, t2) {
  Jb[e2] = t2;
}
function Xb(e2) {
  return Jb[e2];
}
M();
var Zb = `5.6.0`, Qb = { zrender: `5.6.1` }, $b = 1, ex = 800, tx = 900, nx = 1e3, rx = 2e3, ix = 5e3, ax = 1e3, ox = 1100, sx = 2e3, cx = 3e3, lx = 4e3, ux = 4500, dx = 4600, fx = 5e3, px = 6e3, mx = 7e3, hx = { PROCESSOR: { FILTER: nx, SERIES_FILTER: ex, STATISTIC: ix }, VISUAL: { LAYOUT: ax, PROGRESSIVE_LAYOUT: ox, GLOBAL: sx, CHART: cx, POST_CHART_LAYOUT: dx, COMPONENT: lx, BRUSH: fx, CHART_ITEM: ux, ARIA: px, DECAL: mx } }, gx = `__flagInMainProcess`, _x = `__pendingUpdate`, vx = `__needsUpdateStatus`, yx = /^[a-zA-Z0-9_]+$/, bx = `__connectUpdateStatus`, xx = 0, Sx = 1, Cx = 2;
function Tx(e2) {
  return function() {
    var t2 = [...arguments];
    if (this.isDisposed()) {
      this.id;
      return;
    }
    return Dx(this, e2, t2);
  };
}
function Ex(e2) {
  return function() {
    var t2 = [...arguments];
    return Dx(this, e2, t2);
  };
}
function Dx(e2, t2, n2) {
  return n2[0] = n2[0] && n2[0].toLowerCase(), Qt.prototype[t2].apply(e2, n2);
}
var Ox = (function(e2) {
  s(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2;
})(Qt), kx = Ox.prototype;
kx.on = Ex(`on`), kx.off = Ex(`off`);
var Ax, jx, Mx, Nx, Px, Fx, Ix, Lx, Rx, zx, Bx, Vx, Hx, Ux, Wx, Gx, Kx, qx, Jx = (function(e2) {
  s(t2, e2);
  function t2(t3, n2, r2) {
    var i2 = e2.call(this, new My()) || this;
    i2._chartsViews = [], i2._chartsMap = {}, i2._componentsViews = [], i2._componentsMap = {}, i2._pendingActions = [], r2 || (r2 = {}), W(n2) && (n2 = nS[n2]), i2._dom = t3;
    var a2 = `canvas`, o2 = `auto`, s2 = false;
    r2.ssr && Io(function(e3) {
      var t4 = bu(e3), n3 = t4.dataIndex;
      if (n3 != null) {
        var r3 = J();
        return r3.set(`series_index`, t4.seriesIndex), r3.set(`data_index`, n3), t4.ssrType && r3.set(`ssr_type`, t4.ssrType), r3;
      }
    });
    var c2 = i2._zr = ko(t3, { renderer: r2.renderer || a2, devicePixelRatio: r2.devicePixelRatio, width: r2.width, height: r2.height, ssr: r2.ssr, useDirtyRect: q(r2.useDirtyRect, s2), useCoarsePointer: q(r2.useCoarsePointer, o2), pointerSize: r2.pointerSize });
    i2._ssr = r2.ssr, i2._throttledZrFlush = Xv(Ye(c2.flush, c2), 17), n2 = L(n2), n2 && Gg(n2, true), i2._theme = n2, i2._locale = xm(r2.locale || ym), i2._coordSysMgr = new hg();
    var l2 = i2._api = Wx(i2);
    function u2(e3, t4) {
      return e3.__prio - t4.__prio;
    }
    return fr(tS, u2), fr($x, u2), i2._scheduler = new uy(i2, l2, $x, tS), i2._messageCenter = new Ox(), i2._initEvents(), i2.resize = Ye(i2.resize, i2), c2.animation.on(`frame`, i2._onframe, i2), zx(c2, i2), Bx(c2, i2), ft(i2), i2;
  }
  return t2.prototype._onframe = function() {
    if (!this._disposed) {
      qx(this);
      var e3 = this._scheduler;
      if (this[_x]) {
        var t3 = this[_x].silent;
        this[gx] = true;
        try {
          Ax(this), Nx.update.call(this, null, this[_x].updateParams);
        } catch (e4) {
          throw this[gx] = false, this[_x] = null, e4;
        }
        this._zr.flush(), this[gx] = false, this[_x] = null, Lx.call(this, t3), Rx.call(this, t3);
      } else if (e3.unfinished) {
        var n2 = $b, r2 = this._model, i2 = this._api;
        e3.unfinished = false;
        do {
          var a2 = +/* @__PURE__ */ new Date();
          e3.performSeriesTasks(r2), e3.performDataProcessorTasks(r2), Fx(this, r2), e3.performVisualTasks(r2), Ux(this, this._model, i2, `remain`, {}), n2 -= +/* @__PURE__ */ new Date() - a2;
        } while (n2 > 0 && e3.unfinished);
        e3.unfinished || this._zr.flush();
      }
    }
  }, t2.prototype.getDom = function() {
    return this._dom;
  }, t2.prototype.getId = function() {
    return this.id;
  }, t2.prototype.getZr = function() {
    return this._zr;
  }, t2.prototype.isSSR = function() {
    return this._ssr;
  }, t2.prototype.setOption = function(e3, t3, n2) {
    if (!this[gx]) {
      if (this._disposed) {
        this.id;
        return;
      }
      var r2, i2, a2;
      if (K(t3) && (n2 = t3.lazyUpdate, r2 = t3.silent, i2 = t3.replaceMerge, a2 = t3.transition, t3 = t3.notMerge), this[gx] = true, !this._model || t3) {
        var o2 = new _g(this._api), s2 = this._theme, c2 = this._model = new og();
        c2.scheduler = this._scheduler, c2.ssr = this._ssr, c2.init(null, null, null, s2, this._locale, o2);
      }
      this._model.setOption(e3, { replaceMerge: i2 }, eS);
      var l2 = { seriesTransition: a2, optionChanged: true };
      if (n2) this[_x] = { silent: r2, updateParams: l2 }, this[gx] = false, this.getZr().wakeUp();
      else {
        try {
          Ax(this), Nx.update.call(this, null, l2);
        } catch (e4) {
          throw this[_x] = null, this[gx] = false, e4;
        }
        this._ssr || this._zr.flush(), this[_x] = null, this[gx] = false, Lx.call(this, r2), Rx.call(this, r2);
      }
    }
  }, t2.prototype.setTheme = function() {
  }, t2.prototype.getModel = function() {
    return this._model;
  }, t2.prototype.getOption = function() {
    return this._model && this._model.getOption();
  }, t2.prototype.getWidth = function() {
    return this._zr.getWidth();
  }, t2.prototype.getHeight = function() {
    return this._zr.getHeight();
  }, t2.prototype.getDevicePixelRatio = function() {
    return this._zr.painter.dpr || I.hasGlobalWindow && window.devicePixelRatio || 1;
  }, t2.prototype.getRenderedCanvas = function(e3) {
    return this.renderToCanvas(e3);
  }, t2.prototype.renderToCanvas = function(e3) {
    return e3 || (e3 = {}), this._zr.painter.getRenderedCanvas({ backgroundColor: e3.backgroundColor || this._model.get(`backgroundColor`), pixelRatio: e3.pixelRatio || this.getDevicePixelRatio() });
  }, t2.prototype.renderToSVGString = function(e3) {
    return e3 || (e3 = {}), this._zr.painter.renderToString({ useViewBox: e3.useViewBox });
  }, t2.prototype.getSvgDataURL = function() {
    if (I.svgSupported) {
      var e3 = this._zr;
      return z(e3.storage.getDisplayList(), function(e4) {
        e4.stopAnimation(null, true);
      }), e3.painter.toDataURL();
    }
  }, t2.prototype.getDataURL = function(e3) {
    if (this._disposed) {
      this.id;
      return;
    }
    e3 || (e3 = {});
    var t3 = e3.excludeComponents, n2 = this._model, r2 = [], i2 = this;
    z(t3, function(e4) {
      n2.eachComponent({ mainType: e4 }, function(e5) {
        var t4 = i2._componentsMap[e5.__viewId];
        t4.group.ignore || (r2.push(t4), t4.group.ignore = true);
      });
    });
    var a2 = this._zr.painter.getType() === `svg` ? this.getSvgDataURL() : this.renderToCanvas(e3).toDataURL(`image/` + (e3 && e3.type || `png`));
    return z(r2, function(e4) {
      e4.group.ignore = false;
    }), a2;
  }, t2.prototype.getConnectedDataURL = function(e3) {
    if (this._disposed) {
      this.id;
      return;
    }
    var t3 = e3.type === `svg`, n2 = this.group, r2 = Math.min, i2 = Math.max, a2 = 1 / 0;
    if (aS[n2]) {
      var o2 = a2, s2 = a2, c2 = -a2, l2 = -a2, u2 = [], d2 = e3 && e3.pixelRatio || this.getDevicePixelRatio();
      z(iS, function(a3, d3) {
        if (a3.group === n2) {
          var f3 = t3 ? a3.getZr().painter.getSvgDom().innerHTML : a3.renderToCanvas(L(e3)), p3 = a3.getDom().getBoundingClientRect();
          o2 = r2(p3.left, o2), s2 = r2(p3.top, s2), c2 = i2(p3.right, c2), l2 = i2(p3.bottom, l2), u2.push({ dom: f3, left: p3.left, top: p3.top });
        }
      }), o2 *= d2, s2 *= d2, c2 *= d2, l2 *= d2;
      var f2 = c2 - o2, p2 = l2 - s2, m2 = be.createCanvas(), h2 = ko(m2, { renderer: t3 ? `svg` : `canvas` });
      if (h2.resize({ width: f2, height: p2 }), t3) {
        var g2 = ``;
        return z(u2, function(e4) {
          var t4 = e4.left - o2, n3 = e4.top - s2;
          g2 += `<g transform="translate(` + t4 + `,` + n3 + `)">` + e4.dom + `</g>`;
        }), h2.painter.getSvgRoot().innerHTML = g2, e3.connectedBackgroundColor && h2.painter.setBackgroundColor(e3.connectedBackgroundColor), h2.refreshImmediately(), h2.painter.toDataURL();
      }
      return e3.connectedBackgroundColor && h2.add(new nu({ shape: { x: 0, y: 0, width: f2, height: p2 }, style: { fill: e3.connectedBackgroundColor } })), z(u2, function(e4) {
        var t4 = new Jl({ style: { x: e4.left * d2 - o2, y: e4.top * d2 - s2, image: e4.dom } });
        h2.add(t4);
      }), h2.refreshImmediately(), m2.toDataURL(`image/` + (e3 && e3.type || `png`));
    }
    return this.getDataURL(e3);
  }, t2.prototype.convertToPixel = function(e3, t3) {
    return Px(this, `convertToPixel`, e3, t3);
  }, t2.prototype.convertFromPixel = function(e3, t3) {
    return Px(this, `convertFromPixel`, e3, t3);
  }, t2.prototype.containPixel = function(e3, t3) {
    if (this._disposed) {
      this.id;
      return;
    }
    var n2 = this._model, r2;
    return z(zs(n2, e3), function(e4, n3) {
      n3.indexOf(`Models`) >= 0 && z(e4, function(e5) {
        var i2 = e5.coordinateSystem;
        if (i2 && i2.containPoint) r2 || (r2 = !!i2.containPoint(t3));
        else if (n3 === `seriesModels`) {
          var a2 = this._chartsMap[e5.__viewId];
          a2 && a2.containPoint && (r2 || (r2 = a2.containPoint(t3, e5)));
        }
      }, this);
    }, this), !!r2;
  }, t2.prototype.getVisual = function(e3, t3) {
    var n2 = this._model, r2 = zs(n2, e3, { defaultMainType: `series` }), i2 = r2.seriesModel.getData(), a2 = r2.hasOwnProperty(`dataIndexInside`) ? r2.dataIndexInside : r2.hasOwnProperty(`dataIndex`) ? i2.indexOfRawIndex(r2.dataIndex) : null;
    return a2 == null ? Ry(i2, t3) : Ly(i2, a2, t3);
  }, t2.prototype.getViewOfComponentModel = function(e3) {
    return this._componentsMap[e3.__viewId];
  }, t2.prototype.getViewOfSeriesModel = function(e3) {
    return this._chartsMap[e3.__viewId];
  }, t2.prototype._initEvents = function() {
    var e3 = this;
    z(Xx, function(t3) {
      var n2 = function(n3) {
        var r2 = e3.getModel(), i2 = n3.target, a2;
        if (t3 === `globalout` ? a2 = {} : i2 && Vy(i2, function(e4) {
          var t4 = bu(e4);
          if (t4 && t4.dataIndex != null) {
            var n4 = t4.dataModel || r2.getSeriesByIndex(t4.seriesIndex);
            return a2 = n4 && n4.getDataParams(t4.dataIndex, t4.dataType, i2) || {}, true;
          }
          if (t4.eventData) return a2 = R({}, t4.eventData), true;
        }, true), a2) {
          var o2 = a2.componentType, s2 = a2.componentIndex;
          (o2 === `markLine` || o2 === `markPoint` || o2 === `markArea`) && (o2 = `series`, s2 = a2.seriesIndex);
          var c2 = o2 && s2 != null && r2.getComponent(o2, s2), l2 = c2 && e3[c2.mainType === `series` ? `_chartsMap` : `_componentsMap`][c2.__viewId];
          a2.event = n3, a2.type = t3, e3._$eventProcessor.eventInfo = { targetEl: i2, packedEvent: a2, model: c2, view: l2 }, e3.trigger(t3, a2);
        }
      };
      n2.zrEventfulCallAtLast = true, e3._zr.on(t3, n2, e3);
    }), z(Qx, function(t3, n2) {
      e3._messageCenter.on(n2, function(e4) {
        this.trigger(n2, e4);
      }, e3);
    }), z([`selectchanged`], function(t3) {
      e3._messageCenter.on(t3, function(e4) {
        this.trigger(t3, e4);
      }, e3);
    }), By(this._messageCenter, this, this._api);
  }, t2.prototype.isDisposed = function() {
    return this._disposed;
  }, t2.prototype.clear = function() {
    if (this._disposed) {
      this.id;
      return;
    }
    this.setOption({ series: [] }, true);
  }, t2.prototype.dispose = function() {
    if (this._disposed) {
      this.id;
      return;
    }
    this._disposed = true, this.getDom() && Ws(this.getDom(), cS, ``);
    var e3 = this, t3 = e3._api, n2 = e3._model;
    z(e3._componentsViews, function(e4) {
      e4.dispose(n2, t3);
    }), z(e3._chartsViews, function(e4) {
      e4.dispose(n2, t3);
    }), e3._zr.dispose(), e3._dom = e3._model = e3._chartsMap = e3._componentsMap = e3._chartsViews = e3._componentsViews = e3._scheduler = e3._api = e3._zr = e3._throttledZrFlush = e3._theme = e3._coordSysMgr = e3._messageCenter = null, delete iS[e3.id];
  }, t2.prototype.resize = function(e3) {
    if (!this[gx]) {
      if (this._disposed) {
        this.id;
        return;
      }
      this._zr.resize(e3);
      var t3 = this._model;
      if (this._loadingFX && this._loadingFX.resize(), t3) {
        var n2 = t3.resetOption(`media`), r2 = e3 && e3.silent;
        this[_x] && (r2 ?? (r2 = this[_x].silent), n2 = true, this[_x] = null), this[gx] = true;
        try {
          n2 && Ax(this), Nx.update.call(this, { type: `resize`, animation: R({ duration: 0 }, e3 && e3.animation) });
        } catch (e4) {
          throw this[gx] = false, e4;
        }
        this[gx] = false, Lx.call(this, r2), Rx.call(this, r2);
      }
    }
  }, t2.prototype.showLoading = function(e3, t3) {
    if (this._disposed) {
      this.id;
      return;
    }
    if (K(e3) && (t3 = e3, e3 = ``), e3 || (e3 = `default`), this.hideLoading(), rS[e3]) {
      var n2 = rS[e3](this._api, t3), r2 = this._zr;
      this._loadingFX = n2, r2.add(n2);
    }
  }, t2.prototype.hideLoading = function() {
    if (this._disposed) {
      this.id;
      return;
    }
    this._loadingFX && this._zr.remove(this._loadingFX), this._loadingFX = null;
  }, t2.prototype.makeActionFromEvent = function(e3) {
    var t3 = R({}, e3);
    return t3.type = Qx[e3.type], t3;
  }, t2.prototype.dispatchAction = function(e3, t3) {
    if (this._disposed) {
      this.id;
      return;
    }
    if (K(t3) || (t3 = { silent: !!t3 }), Zx[e3.type] && this._model) {
      if (this[gx]) {
        this._pendingActions.push(e3);
        return;
      }
      var n2 = t3.silent;
      Ix.call(this, e3, n2);
      var r2 = t3.flush;
      r2 ? this._zr.flush() : r2 !== false && I.browser.weChat && this._throttledZrFlush(), Lx.call(this, n2), Rx.call(this, n2);
    }
  }, t2.prototype.updateLabelLayout = function() {
    qb.trigger(`series:layoutlabels`, this._model, this._api, { updatedSeries: [] });
  }, t2.prototype.appendData = function(e3) {
    if (this._disposed) {
      this.id;
      return;
    }
    var t3 = e3.seriesIndex;
    this.getModel().getSeriesByIndex(t3).appendData(e3), this._scheduler.unfinished = true, this.getZr().wakeUp();
  }, t2.internalField = (function() {
    Ax = function(e4) {
      var t4 = e4._scheduler;
      t4.restorePipelines(e4._model), t4.prepareStageTasks(), jx(e4, true), jx(e4, false), t4.plan();
    }, jx = function(e4, t4) {
      for (var n3 = e4._model, r3 = e4._scheduler, i3 = t4 ? e4._componentsViews : e4._chartsViews, a3 = t4 ? e4._componentsMap : e4._chartsMap, o3 = e4._zr, s2 = e4._api, c3 = 0; c3 < i3.length; c3++) i3[c3].__alive = false;
      t4 ? n3.eachComponent(function(e5, t5) {
        e5 !== `series` && l3(t5);
      }) : n3.eachSeries(l3);
      function l3(e5) {
        var c4 = e5.__requireNewView;
        e5.__requireNewView = false;
        var l4 = `_ec_` + e5.id + `_` + e5.type, u3 = !c4 && a3[l4];
        if (!u3) {
          var d2 = Zs(e5.type);
          u3 = new (t4 ? Lv.getClass(d2.main, d2.sub) : Vv.getClass(d2.sub))(), u3.init(n3, s2), a3[l4] = u3, i3.push(u3), o3.add(u3.group);
        }
        e5.__viewId = u3.__id = l4, u3.__alive = true, u3.__model = e5, u3.group.__ecComponentInfo = { mainType: e5.mainType, index: e5.componentIndex }, !t4 && r3.prepareView(u3, e5, n3, s2);
      }
      for (var c3 = 0; c3 < i3.length; ) {
        var u2 = i3[c3];
        u2.__alive ? c3++ : (!t4 && u2.renderTask.dispose(), o3.remove(u2.group), u2.dispose(n3, s2), i3.splice(c3, 1), a3[u2.__id] === u2 && delete a3[u2.__id], u2.__id = u2.group.__ecComponentInfo = null);
      }
    }, Mx = function(e4, t4, n3, r3, i3) {
      var a3 = e4._model;
      if (a3.setUpdatePayload(n3), !r3) {
        z([].concat(e4._componentsViews, e4._chartsViews), u2);
        return;
      }
      var o3 = {};
      o3[r3 + `Id`] = n3[r3 + `Id`], o3[r3 + `Index`] = n3[r3 + `Index`], o3[r3 + `Name`] = n3[r3 + `Name`];
      var s2 = { mainType: r3, query: o3 };
      i3 && (s2.subType = i3);
      var c3 = n3.excludeSeriesId, l3;
      c3 != null && (l3 = J(), z(gs(c3), function(e5) {
        var t5 = As(e5, null);
        t5 != null && l3.set(t5, true);
      })), a3 && a3.eachComponent(s2, function(t5) {
        if (!(l3 && l3.get(t5.id) != null)) {
          if (Ed(n3)) {
            if (t5 instanceof Ov) n3.type === `highlight` && !n3.notBlur && !t5.get([`emphasis`, `disabled`]) && cd(t5, n3, e4._api);
            else {
              var r4 = ld(t5.mainType, t5.componentIndex, n3.name, e4._api), i4 = r4.focusSelf, a4 = r4.dispatchers;
              n3.type === `highlight` && i4 && !n3.notBlur && sd(t5.mainType, t5.componentIndex, e4._api), a4 && z(a4, function(e5) {
                n3.type === `highlight` ? Qu(e5) : $u(e5);
              });
            }
          } else Td(n3) && t5 instanceof Ov && (fd(t5, n3, e4._api), pd(t5), Kx(e4));
        }
      }, e4), a3 && a3.eachComponent(s2, function(t5) {
        l3 && l3.get(t5.id) != null || u2(e4[r3 === `series` ? `_chartsMap` : `_componentsMap`][t5.__viewId]);
      }, e4);
      function u2(r4) {
        r4 && r4.__alive && r4[t4] && r4[t4](r4.__model, a3, e4._api, n3);
      }
    }, Nx = { prepareAndUpdate: function(e4) {
      Ax(this), Nx.update.call(this, e4, { optionChanged: e4.newOption != null });
    }, update: function(t4, n3) {
      var r3 = this._model, i3 = this._api, a3 = this._zr, o3 = this._coordSysMgr, s2 = this._scheduler;
      if (r3) {
        r3.setUpdatePayload(t4), s2.restoreData(r3, t4), s2.performSeriesTasks(r3), o3.create(r3, i3), s2.performDataProcessorTasks(r3, t4), Fx(this, r3), o3.update(r3, i3), e3(r3), s2.performVisualTasks(r3, t4), Vx(this, r3, i3, t4, n3);
        var c3 = r3.get(`backgroundColor`) || `transparent`, l3 = r3.get(`darkMode`);
        a3.setBackgroundColor(c3), l3 != null && l3 !== `auto` && a3.setDarkMode(l3), qb.trigger(`afterupdate`, r3, i3);
      }
    }, updateTransform: function(t4) {
      var n3 = this, r3 = this._model, i3 = this._api;
      if (r3) {
        r3.setUpdatePayload(t4);
        var a3 = [];
        r3.eachComponent(function(e4, o4) {
          if (e4 !== `series`) {
            var s2 = n3.getViewOfComponentModel(o4);
            if (s2 && s2.__alive) {
              if (s2.updateTransform) {
                var c3 = s2.updateTransform(o4, r3, i3, t4);
                c3 && c3.update && a3.push(s2);
              } else a3.push(s2);
            }
          }
        });
        var o3 = J();
        r3.eachSeries(function(e4) {
          var a4 = n3._chartsMap[e4.__viewId];
          if (a4.updateTransform) {
            var s2 = a4.updateTransform(e4, r3, i3, t4);
            s2 && s2.update && o3.set(e4.uid, 1);
          } else o3.set(e4.uid, 1);
        }), e3(r3), this._scheduler.performVisualTasks(r3, t4, { setDirty: true, dirtyMap: o3 }), Ux(this, r3, i3, t4, {}, o3), qb.trigger(`afterupdate`, r3, i3);
      }
    }, updateView: function(t4) {
      var n3 = this._model;
      n3 && (n3.setUpdatePayload(t4), Vv.markUpdateMethod(t4, `updateView`), e3(n3), this._scheduler.performVisualTasks(n3, t4, { setDirty: true }), Vx(this, n3, this._api, t4, {}), qb.trigger(`afterupdate`, n3, this._api));
    }, updateVisual: function(t4) {
      var n3 = this, r3 = this._model;
      r3 && (r3.setUpdatePayload(t4), r3.eachSeries(function(e4) {
        e4.getData().clearAllVisual();
      }), Vv.markUpdateMethod(t4, `updateVisual`), e3(r3), this._scheduler.performVisualTasks(r3, t4, { visualType: `visual`, setDirty: true }), r3.eachComponent(function(e4, i3) {
        if (e4 !== `series`) {
          var a3 = n3.getViewOfComponentModel(i3);
          a3 && a3.__alive && a3.updateVisual(i3, r3, n3._api, t4);
        }
      }), r3.eachSeries(function(e4) {
        n3._chartsMap[e4.__viewId].updateVisual(e4, r3, n3._api, t4);
      }), qb.trigger(`afterupdate`, r3, this._api));
    }, updateLayout: function(e4) {
      Nx.update.call(this, e4);
    } }, Px = function(e4, t4, n3, r3) {
      if (e4._disposed) {
        e4.id;
        return;
      }
      for (var i3 = e4._model, a3 = e4._coordSysMgr.getCoordinateSystems(), o3, s2 = zs(i3, n3), c3 = 0; c3 < a3.length; c3++) {
        var l3 = a3[c3];
        if (l3[t4] && (o3 = l3[t4](i3, s2, r3)) != null) return o3;
      }
    }, Fx = function(e4, t4) {
      var n3 = e4._chartsMap, r3 = e4._scheduler;
      t4.eachSeries(function(e5) {
        r3.updateStreamModes(e5, n3[e5.__viewId]);
      });
    }, Ix = function(e4, t4) {
      var n3 = this, r3 = this.getModel(), i3 = e4.type, a3 = e4.escapeConnect, o3 = Zx[i3], s2 = o3.actionInfo, c3 = (s2.update || `update`).split(`:`), l3 = c3.pop(), u2 = c3[0] != null && Zs(c3[0]);
      this[gx] = true;
      var d2 = [e4], f2 = false;
      e4.batch && (f2 = true, d2 = B(e4.batch, function(t5) {
        return t5 = ze(R({}, t5), e4), t5.batch = null, t5;
      }));
      var p2 = [], m2, h2 = Td(e4), g2 = Ed(e4);
      if (g2 && ad(this._api), z(d2, function(t5) {
        if (m2 = o3.action(t5, n3._model, n3._api), m2 || (m2 = R({}, t5)), m2.type = s2.event || m2.type, p2.push(m2), g2) {
          var r4 = Bs(e4), i4 = r4.queryOptionMap, a4 = r4.mainTypeSpecified ? i4.keys()[0] : `series`;
          Mx(n3, l3, t5, a4), Kx(n3);
        } else h2 ? (Mx(n3, l3, t5, `series`), Kx(n3)) : u2 && Mx(n3, l3, t5, u2.main, u2.sub);
      }), l3 !== `none` && !g2 && !h2 && !u2) try {
        this[_x] ? (Ax(this), Nx.update.call(this, e4), this[_x] = null) : Nx[l3].call(this, e4);
      } catch (e5) {
        throw this[gx] = false, e5;
      }
      if (m2 = f2 ? { type: s2.event || i3, escapeConnect: a3, batch: p2 } : p2[0], this[gx] = false, !t4) {
        var _2 = this._messageCenter;
        if (_2.trigger(m2.type, m2), h2) {
          var v2 = { type: `selectchanged`, escapeConnect: a3, selected: md(r3), isFromClick: e4.isFromClick || false, fromAction: e4.type, fromActionPayload: e4 };
          _2.trigger(v2.type, v2);
        }
      }
    }, Lx = function(e4) {
      for (var t4 = this._pendingActions; t4.length; ) {
        var n3 = t4.shift();
        Ix.call(this, n3, e4);
      }
    }, Rx = function(e4) {
      !e4 && this.trigger(`updated`);
    }, zx = function(e4, t4) {
      e4.on(`rendered`, function(n3) {
        t4.trigger(`rendered`, n3), e4.animation.isFinished() && !t4[_x] && !t4._scheduler.unfinished && !t4._pendingActions.length && t4.trigger(`finished`);
      });
    }, Bx = function(e4, t4) {
      e4.on(`mouseover`, function(e5) {
        var n3 = e5.target, r3 = Vy(n3, Cd);
        r3 && (ud(r3, e5, t4._api), Kx(t4));
      }).on(`mouseout`, function(e5) {
        var n3 = e5.target, r3 = Vy(n3, Cd);
        r3 && (dd(r3, e5, t4._api), Kx(t4));
      }).on(`click`, function(e5) {
        var n3 = e5.target, r3 = Vy(n3, function(e6) {
          return bu(e6).dataIndex != null;
        }, true);
        if (r3) {
          var i3 = r3.selected ? `unselect` : `select`, a3 = bu(r3);
          t4._api.dispatchAction({ type: i3, dataType: a3.dataType, dataIndexInside: a3.dataIndex, seriesIndex: a3.seriesIndex, isFromClick: true });
        }
      });
    };
    function e3(e4) {
      e4.clearColorPalette(), e4.eachSeries(function(e5) {
        e5.clearColorPalette();
      });
    }
    function t3(e4) {
      var t4 = [], n3 = [], r3 = false;
      if (e4.eachComponent(function(e5, i4) {
        var a4 = i4.get(`zlevel`) || 0, o4 = i4.get(`z`) || 0, s2 = i4.getZLevelKey();
        r3 || (r3 = !!s2), (e5 === `series` ? n3 : t4).push({ zlevel: a4, z: o4, idx: i4.componentIndex, type: e5, key: s2 });
      }), r3) {
        var i3 = t4.concat(n3), a3, o3;
        fr(i3, function(e5, t5) {
          return e5.zlevel === t5.zlevel ? e5.z - t5.z : e5.zlevel - t5.zlevel;
        }), z(i3, function(t5) {
          var n4 = e4.getComponent(t5.type, t5.idx), r4 = t5.zlevel, i4 = t5.key;
          a3 != null && (r4 = Math.max(a3, r4)), i4 ? (r4 === a3 && i4 !== o3 && r4++, o3 = i4) : o3 && (o3 = (r4 === a3 && r4++, ``)), a3 = r4, n4.setZLevel(r4);
        });
      }
    }
    Vx = function(e4, n3, r3, i3, a3) {
      t3(n3), Hx(e4, n3, r3, i3, a3), z(e4._chartsViews, function(e5) {
        e5.__alive = false;
      }), Ux(e4, n3, r3, i3, a3), z(e4._chartsViews, function(e5) {
        e5.__alive || e5.remove(n3, r3);
      });
    }, Hx = function(e4, t4, n3, r3, i3, o3) {
      z(o3 || e4._componentsViews, function(e5) {
        var i4 = e5.__model;
        c2(i4, e5), e5.render(i4, t4, n3, r3), a2(i4, e5), l2(i4, e5);
      });
    }, Ux = function(e4, t4, n3, o3, s2, u2) {
      var d2 = e4._scheduler;
      s2 = R(s2 || {}, { updatedSeries: t4.getSeries() }), qb.trigger(`series:beforeupdate`, t4, n3, s2);
      var f2 = false;
      t4.eachSeries(function(t5) {
        var n4 = e4._chartsMap[t5.__viewId];
        n4.__alive = true;
        var r3 = n4.renderTask;
        d2.updatePayload(r3, o3), c2(t5, n4), u2 && u2.get(t5.uid) && r3.dirty(), r3.perform(d2.getPerformArgs(r3)) && (f2 = true), n4.group.silent = !!t5.get(`silent`), i2(t5, n4), pd(t5);
      }), d2.unfinished = f2 || d2.unfinished, qb.trigger(`series:layoutlabels`, t4, n3, s2), qb.trigger(`series:transition`, t4, n3, s2), t4.eachSeries(function(t5) {
        var n4 = e4._chartsMap[t5.__viewId];
        a2(t5, n4), l2(t5, n4);
      }), r2(e4, t4), qb.trigger(`series:afterupdate`, t4, n3, s2);
    }, Kx = function(e4) {
      e4[vx] = true, e4.getZr().wakeUp();
    }, qx = function(e4) {
      e4[vx] && (e4.getZr().storage.traverse(function(e5) {
        Zf(e5) || n2(e5);
      }), e4[vx] = false);
    };
    function n2(e4) {
      for (var t4 = [], n3 = e4.currentStates, r3 = 0; r3 < n3.length; r3++) {
        var i3 = n3[r3];
        i3 !== `emphasis` && i3 !== `blur` && i3 !== `select` && t4.push(i3);
      }
      e4.selected && e4.states.select && t4.push(`select`), e4.hoverState === 2 && e4.states.emphasis ? t4.push(`emphasis`) : e4.hoverState === 1 && e4.states.blur && t4.push(`blur`), e4.useStates(t4);
    }
    function r2(e4, t4) {
      var n3 = e4._zr.storage, r3 = 0;
      n3.traverse(function(e5) {
        e5.isGroup || r3++;
      }), r3 > t4.get(`hoverLayerThreshold`) && !I.node && !I.worker && t4.eachSeries(function(t5) {
        if (!t5.preventUsingHoverLayer) {
          var n4 = e4._chartsMap[t5.__viewId];
          n4.__alive && n4.eachRendered(function(e5) {
            e5.states.emphasis && (e5.states.emphasis.hoverLayer = true);
          });
        }
      });
    }
    function i2(e4, t4) {
      var n3 = e4.get(`blendMode`) || null;
      t4.eachRendered(function(e5) {
        e5.isGroup || (e5.style.blend = n3);
      });
    }
    function a2(e4, t4) {
      if (!e4.preventAutoZ) {
        var n3 = e4.get(`z`) || 0, r3 = e4.get(`zlevel`) || 0;
        t4.eachRendered(function(e5) {
          return o2(e5, n3, r3, -1 / 0), true;
        });
      }
    }
    function o2(e4, t4, n3, r3) {
      var i3 = e4.getTextContent(), a3 = e4.getTextGuideLine();
      if (e4.isGroup) for (var s2 = e4.childrenRef(), c3 = 0; c3 < s2.length; c3++) r3 = Math.max(o2(s2[c3], t4, n3, r3), r3);
      else e4.z = t4, e4.zlevel = n3, r3 = Math.max(e4.z2, r3);
      if (i3 && (i3.z = t4, i3.zlevel = n3, isFinite(r3) && (i3.z2 = r3 + 2)), a3) {
        var l3 = e4.textGuideLineConfig;
        a3.z = t4, a3.zlevel = n3, isFinite(r3) && (a3.z2 = r3 + (l3 && l3.showAbove ? 1 : -1));
      }
      return r3;
    }
    function c2(e4, t4) {
      t4.eachRendered(function(e5) {
        if (!Zf(e5)) {
          var t5 = e5.getTextContent(), n3 = e5.getTextGuideLine();
          e5.stateTransition && (e5.stateTransition = null), t5 && t5.stateTransition && (t5.stateTransition = null), n3 && n3.stateTransition && (n3.stateTransition = null), e5.hasState() ? (e5.prevStates = e5.currentStates, e5.clearStates()) : e5.prevStates && (e5.prevStates = null);
        }
      });
    }
    function l2(e4, t4) {
      var r3 = e4.getModel(`stateAnimation`), i3 = e4.isAnimationEnabled(), a3 = r3.get(`duration`), o3 = a3 > 0 ? { duration: a3, delay: r3.get(`delay`), easing: r3.get(`easing`) } : null;
      t4.eachRendered(function(e5) {
        if (e5.states && e5.states.emphasis) {
          if (Zf(e5)) return;
          if (e5 instanceof Q && Dd(e5), e5.__dirty) {
            var t5 = e5.prevStates;
            t5 && e5.useStates(t5);
          }
          if (i3) {
            e5.stateTransition = o3;
            var r4 = e5.getTextContent(), a4 = e5.getTextGuideLine();
            r4 && (r4.stateTransition = o3), a4 && (a4.stateTransition = o3);
          }
          e5.__dirty && n2(e5);
        }
      });
    }
    Wx = function(e4) {
      return new ((function(t4) {
        s(n3, t4);
        function n3() {
          return t4 !== null && t4.apply(this, arguments) || this;
        }
        return n3.prototype.getCoordinateSystems = function() {
          return e4._coordSysMgr.getCoordinateSystems();
        }, n3.prototype.getComponentByElement = function(t5) {
          for (; t5; ) {
            var n4 = t5.__ecComponentInfo;
            if (n4 != null) return e4._model.getComponent(n4.mainType, n4.index);
            t5 = t5.parent;
          }
        }, n3.prototype.enterEmphasis = function(t5, n4) {
          Qu(t5, n4), Kx(e4);
        }, n3.prototype.leaveEmphasis = function(t5, n4) {
          $u(t5, n4), Kx(e4);
        }, n3.prototype.enterBlur = function(t5) {
          ed(t5), Kx(e4);
        }, n3.prototype.leaveBlur = function(t5) {
          td(t5), Kx(e4);
        }, n3.prototype.enterSelect = function(t5) {
          nd(t5), Kx(e4);
        }, n3.prototype.leaveSelect = function(t5) {
          rd(t5), Kx(e4);
        }, n3.prototype.getModel = function() {
          return e4.getModel();
        }, n3.prototype.getViewOfComponentModel = function(t5) {
          return e4.getViewOfComponentModel(t5);
        }, n3.prototype.getViewOfSeriesModel = function(t5) {
          return e4.getViewOfSeriesModel(t5);
        }, n3;
      })(pg))(e4);
    }, Gx = function(e4) {
      function t4(e5, t5) {
        for (var n3 = 0; n3 < e5.length; n3++) {
          var r3 = e5[n3];
          r3[bx] = t5;
        }
      }
      z(Qx, function(n3, r3) {
        e4._messageCenter.on(r3, function(n4) {
          if (aS[e4.group] && e4[bx] !== xx) {
            if (n4 && n4.escapeConnect) return;
            var r4 = e4.makeActionFromEvent(n4), i3 = [];
            z(iS, function(t5) {
              t5 !== e4 && t5.group === e4.group && i3.push(t5);
            }), t4(i3, xx), z(i3, function(e5) {
              e5[bx] !== Sx && e5.dispatchAction(r4);
            }), t4(i3, Cx);
          }
        });
      });
    };
  })(), t2;
})(Qt), Yx = Jx.prototype;
Yx.on = Tx(`on`), Yx.off = Tx(`off`), Yx.one = function(e2, t2, n2) {
  var r2 = this;
  function i2() {
    var n3 = [...arguments];
    t2 && t2.apply && t2.apply(this, n3), r2.off(e2, i2);
  }
  this.on.call(this, e2, i2, n2);
};
var Xx = [`click`, `dblclick`, `mouseover`, `mouseout`, `mousemove`, `mousedown`, `mouseup`, `globalout`, `contextmenu`], Zx = {}, Qx = {}, $x = [], eS = [], tS = [], nS = {}, rS = {}, iS = {}, aS = {}, oS = /* @__PURE__ */ new Date() - 0, sS = /* @__PURE__ */ new Date() - 0, cS = `_echarts_instance_`;
function lS(e2, t2, n2) {
  var r2 = !(n2 && n2.ssr);
  if (r2) {
    var i2 = mS(e2);
    if (i2) return i2;
  }
  var a2 = new Jx(e2, t2, n2);
  return a2.id = `ec_` + oS++, iS[a2.id] = a2, r2 && Ws(e2, cS, a2.id), Gx(a2), qb.trigger(`afterinit`, a2), a2;
}
function uS(e2) {
  if (H(e2)) {
    var t2 = e2;
    e2 = null, z(t2, function(t3) {
      t3.group != null && (e2 = t3.group);
    }), e2 || (e2 = `g_` + sS++), z(t2, function(t3) {
      t3.group = e2;
    });
  }
  return aS[e2] = true, e2;
}
function dS(e2) {
  aS[e2] = false;
}
var fS = dS;
function pS(e2) {
  W(e2) ? e2 = iS[e2] : e2 instanceof Jx || (e2 = mS(e2)), e2 instanceof Jx && !e2.isDisposed() && e2.dispose();
}
function mS(e2) {
  return iS[Gs(e2, cS)];
}
function hS(e2) {
  return iS[e2];
}
function gS(e2, t2) {
  nS[e2] = t2;
}
function _S(e2) {
  Ve(eS, e2) < 0 && eS.push(e2);
}
function vS(e2, t2) {
  OS($x, e2, t2, rx);
}
function yS(e2) {
  xS(`afterinit`, e2);
}
function bS(e2) {
  xS(`afterupdate`, e2);
}
function xS(e2, t2) {
  qb.on(e2, t2);
}
function SS(e2, t2, n2) {
  U(t2) && (n2 = t2, t2 = ``);
  var r2 = K(e2) ? e2.type : [e2, e2 = { event: t2 }][0];
  e2.event = (e2.event || r2).toLowerCase(), t2 = e2.event, !Qx[t2] && (lt(yx.test(r2) && yx.test(t2)), Zx[r2] || (Zx[r2] = { action: n2, actionInfo: e2 }), Qx[t2] = r2);
}
function CS(e2, t2) {
  hg.register(e2, t2);
}
function wS(e2) {
  var t2 = hg.get(e2);
  if (t2) return t2.getDimensionsInfo ? t2.getDimensionsInfo() : t2.dimensions.slice();
}
function TS(e2, t2) {
  OS(tS, e2, t2, ax, `layout`);
}
function ES(e2, t2) {
  OS(tS, e2, t2, cx, `visual`);
}
var DS = [];
function OS(e2, t2, n2, r2, i2) {
  if ((U(t2) || K(t2)) && (n2 = t2, t2 = r2), !(Ve(DS, n2) >= 0)) {
    DS.push(n2);
    var a2 = uy.wrapStageHandler(n2, i2);
    a2.__prio = t2, a2.__raw = n2, e2.push(a2);
  }
}
function kS(e2, t2) {
  rS[e2] = t2;
}
function AS(e2) {
  xe({ createCanvas: e2 });
}
function jS(e2, t2, n2) {
  var r2 = Xb(`registerMap`);
  r2 && r2(e2, t2, n2);
}
function MS(e2) {
  var t2 = Xb(`getMap`);
  return t2 && t2(e2);
}
var NS = R_;
ES(sx, iy), ES(ux, oy), ES(ux, sy), ES(sx, Fy), ES(ux, Iy), ES(mx, Kb), _S(Gg), vS(tx, Kg), kS(`default`, ly), SS({ type: Ou, event: Ou, update: Ou }, St), SS({ type: ku, event: ku, update: ku }, St), SS({ type: Au, event: Au, update: Au }, St), SS({ type: ju, event: ju, update: ju }, St), SS({ type: Mu, event: Mu, update: Mu }, St), gS(`light`, Ey), gS(`dark`, jy);
var PS = {};
function FS(e2) {
  return e2 == null ? 0 : e2.length || 1;
}
function IS(e2) {
  return e2;
}
var LS = (function() {
  function e2(e3, t2, n2, r2, i2, a2) {
    this._old = e3, this._new = t2, this._oldKeyGetter = n2 || IS, this._newKeyGetter = r2 || IS, this.context = i2, this._diffModeMultiple = a2 === `multiple`;
  }
  return e2.prototype.add = function(e3) {
    return this._add = e3, this;
  }, e2.prototype.update = function(e3) {
    return this._update = e3, this;
  }, e2.prototype.updateManyToOne = function(e3) {
    return this._updateManyToOne = e3, this;
  }, e2.prototype.updateOneToMany = function(e3) {
    return this._updateOneToMany = e3, this;
  }, e2.prototype.updateManyToMany = function(e3) {
    return this._updateManyToMany = e3, this;
  }, e2.prototype.remove = function(e3) {
    return this._remove = e3, this;
  }, e2.prototype.execute = function() {
    this[this._diffModeMultiple ? `_executeMultiple` : `_executeOneToOne`]();
  }, e2.prototype._executeOneToOne = function() {
    var e3 = this._old, t2 = this._new, n2 = {}, r2 = Array(e3.length), i2 = Array(t2.length);
    this._initIndexMap(e3, null, r2, `_oldKeyGetter`), this._initIndexMap(t2, n2, i2, `_newKeyGetter`);
    for (var a2 = 0; a2 < e3.length; a2++) {
      var o2 = r2[a2], s2 = n2[o2], c2 = FS(s2);
      if (c2 > 1) {
        var l2 = s2.shift();
        s2.length === 1 && (n2[o2] = s2[0]), this._update && this._update(l2, a2);
      } else c2 === 1 ? (n2[o2] = null, this._update && this._update(s2, a2)) : this._remove && this._remove(a2);
    }
    this._performRestAdd(i2, n2);
  }, e2.prototype._executeMultiple = function() {
    var e3 = this._old, t2 = this._new, n2 = {}, r2 = {}, i2 = [], a2 = [];
    this._initIndexMap(e3, n2, i2, `_oldKeyGetter`), this._initIndexMap(t2, r2, a2, `_newKeyGetter`);
    for (var o2 = 0; o2 < i2.length; o2++) {
      var s2 = i2[o2], c2 = n2[s2], l2 = r2[s2], u2 = FS(c2), d2 = FS(l2);
      if (u2 > 1 && d2 === 1) this._updateManyToOne && this._updateManyToOne(l2, c2), r2[s2] = null;
      else if (u2 === 1 && d2 > 1) this._updateOneToMany && this._updateOneToMany(l2, c2), r2[s2] = null;
      else if (u2 === 1 && d2 === 1) this._update && this._update(l2, c2), r2[s2] = null;
      else if (u2 > 1 && d2 > 1) this._updateManyToMany && this._updateManyToMany(l2, c2), r2[s2] = null;
      else if (u2 > 1) for (var f2 = 0; f2 < u2; f2++) this._remove && this._remove(c2[f2]);
      else this._remove && this._remove(c2);
    }
    this._performRestAdd(a2, r2);
  }, e2.prototype._performRestAdd = function(e3, t2) {
    for (var n2 = 0; n2 < e3.length; n2++) {
      var r2 = e3[n2], i2 = t2[r2], a2 = FS(i2);
      if (a2 > 1) for (var o2 = 0; o2 < a2; o2++) this._add && this._add(i2[o2]);
      else a2 === 1 && this._add && this._add(i2);
      t2[r2] = null;
    }
  }, e2.prototype._initIndexMap = function(e3, t2, n2, r2) {
    for (var i2 = this._diffModeMultiple, a2 = 0; a2 < e3.length; a2++) {
      var o2 = `_ec_` + this[r2](e3[a2], a2);
      if (i2 || (n2[a2] = o2), t2) {
        var s2 = t2[o2], c2 = FS(s2);
        c2 === 0 ? (t2[o2] = a2, i2 && n2.push(o2)) : c2 === 1 ? t2[o2] = [s2, a2] : s2.push(a2);
      }
    }
  }, e2;
})(), RS = (function() {
  function e2(e3, t2) {
    this._encode = e3, this._schema = t2;
  }
  return e2.prototype.get = function() {
    return { fullDimensions: this._getFullDimensionNames(), encode: this._encode };
  }, e2.prototype._getFullDimensionNames = function() {
    return this._cachedDimNames || (this._cachedDimNames = this._schema ? this._schema.makeOutputDimensionNames() : []), this._cachedDimNames;
  }, e2;
})();
function zS(e2, t2) {
  var n2 = {}, r2 = n2.encode = {}, i2 = J(), a2 = [], o2 = [], s2 = {};
  z(e2.dimensions, function(t3) {
    var n3 = e2.getDimensionInfo(t3), c3 = n3.coordDim;
    if (c3) {
      var l3 = n3.coordDimIndex;
      BS(r2, c3)[l3] = t3, n3.isExtraCoord || (i2.set(c3, 1), HS(n3.type) && (a2[0] = t3), BS(s2, c3)[l3] = e2.getDimensionIndex(n3.name)), n3.defaultTooltip && o2.push(t3);
    }
    jh.each(function(e3, t4) {
      var i3 = BS(r2, t4), a3 = n3.otherDims[t4];
      a3 != null && a3 !== false && (i3[a3] = n3.name);
    });
  });
  var c2 = [], l2 = {};
  i2.each(function(e3, t3) {
    var n3 = r2[t3];
    l2[t3] = n3[0], c2 = c2.concat(n3);
  }), n2.dataDimsOnCoord = c2, n2.dataDimIndicesOnCoord = B(c2, function(t3) {
    return e2.getDimensionInfo(t3).storeDimIndex;
  }), n2.encodeFirstDimNotExtra = l2;
  var u2 = r2.label;
  u2 && u2.length && (a2 = u2.slice());
  var d2 = r2.tooltip;
  return d2 && d2.length ? o2 = d2.slice() : o2.length || (o2 = a2.slice()), r2.defaultedLabel = a2, r2.defaultedTooltip = o2, n2.userOutput = new RS(s2, t2), n2;
}
function BS(e2, t2) {
  return e2.hasOwnProperty(t2) || (e2[t2] = []), e2[t2];
}
function VS(e2) {
  return e2 === `category` ? `ordinal` : e2 === `time` ? `time` : `float`;
}
function HS(e2) {
  return e2 !== `ordinal` && e2 !== `time`;
}
var US = /* @__PURE__ */ (function() {
  function e2(e3) {
    this.otherDims = {}, e3 != null && R(this, e3);
  }
  return e2;
})(), WS = Ls(), GS = { float: `f`, int: `i`, ordinal: `o`, number: `n`, time: `t` }, KS = (function() {
  function e2(e3) {
    this.dimensions = e3.dimensions, this._dimOmitted = e3.dimensionOmitted, this.source = e3.source, this._fullDimCount = e3.fullDimensionCount, this._updateDimOmitted(e3.dimensionOmitted);
  }
  return e2.prototype.isDimensionOmitted = function() {
    return this._dimOmitted;
  }, e2.prototype._updateDimOmitted = function(e3) {
    this._dimOmitted = e3, e3 && (this._dimNameMap || (this._dimNameMap = YS(this.source)));
  }, e2.prototype.getSourceDimensionIndex = function(e3) {
    return q(this._dimNameMap.get(e3), -1);
  }, e2.prototype.getSourceDimension = function(e3) {
    var t2 = this.source.dimensionsDefine;
    if (t2) return t2[e3];
  }, e2.prototype.makeStoreSchema = function() {
    for (var e3 = this._fullDimCount, t2 = i_(this.source), n2 = !XS(e3), r2 = ``, i2 = [], a2 = 0, o2 = 0; a2 < e3; a2++) {
      var s2 = void 0, c2 = void 0, l2 = void 0, u2 = this.dimensions[o2];
      if (u2 && u2.storeDimIndex === a2) s2 = t2 ? u2.name : null, c2 = u2.type, l2 = u2.ordinalMeta, o2++;
      else {
        var d2 = this.getSourceDimension(a2);
        d2 && (s2 = t2 ? d2.name : null, c2 = d2.type);
      }
      i2.push({ property: s2, type: c2, ordinalMeta: l2 }), t2 && s2 != null && (!u2 || !u2.isCalculationCoord) && (r2 += n2 ? s2.replace(/\`/g, "`1").replace(/\$/g, "`2") : s2), r2 += `$`, r2 += GS[c2] || `f`, l2 && (r2 += l2.uid), r2 += `$`;
    }
    var f2 = this.source;
    return { dimensions: i2, hash: [f2.seriesLayoutBy, f2.startIndex, r2].join(`$$`) };
  }, e2.prototype.makeOutputDimensionNames = function() {
    for (var e3 = [], t2 = 0, n2 = 0; t2 < this._fullDimCount; t2++) {
      var r2 = void 0, i2 = this.dimensions[n2];
      if (i2 && i2.storeDimIndex === t2) i2.isCalculationCoord || (r2 = i2.name), n2++;
      else {
        var a2 = this.getSourceDimension(t2);
        a2 && (r2 = a2.name);
      }
      e3.push(r2);
    }
    return e3;
  }, e2.prototype.appendCalculationDimension = function(e3) {
    this.dimensions.push(e3), e3.isCalculationCoord = true, this._fullDimCount++, this._updateDimOmitted(true);
  }, e2;
})();
function qS(e2) {
  return e2 instanceof KS;
}
function JS(e2) {
  for (var t2 = J(), n2 = 0; n2 < (e2 || []).length; n2++) {
    var r2 = e2[n2], i2 = K(r2) ? r2.name : r2;
    i2 != null && t2.get(i2) == null && t2.set(i2, n2);
  }
  return t2;
}
function YS(e2) {
  var t2 = WS(e2);
  return t2.dimNameMap || (t2.dimNameMap = JS(e2.dimensionsDefine));
}
function XS(e2) {
  return e2 > 30;
}
var ZS = K, QS = B, $S = typeof Int32Array > `u` ? Array : Int32Array, eC = `e\0\0`, tC = -1, nC = [`hasItemOption`, `_nameList`, `_idList`, `_invertedIndicesMap`, `_dimSummary`, `userOutput`, `_rawData`, `_dimValueGetter`, `_nameDimIdx`, `_idDimIdx`, `_nameRepeatCount`], rC = [`_approximateExtent`], iC, aC, oC, sC, cC, lC, uC, dC = (function() {
  function e2(e3, t2) {
    this.type = `list`, this._dimOmitted = false, this._nameList = [], this._idList = [], this._visual = {}, this._layout = {}, this._itemVisuals = [], this._itemLayouts = [], this._graphicEls = [], this._approximateExtent = {}, this._calculationInfo = {}, this.hasItemOption = false, this.TRANSFERABLE_METHODS = [`cloneShallow`, `downSample`, `minmaxDownSample`, `lttbDownSample`, `map`], this.CHANGABLE_METHODS = [`filterSelf`, `selectRange`], this.DOWNSAMPLE_METHODS = [`downSample`, `minmaxDownSample`, `lttbDownSample`];
    var n2, r2 = false;
    qS(e3) ? (n2 = e3.dimensions, this._dimOmitted = e3.isDimensionOmitted(), this._schema = e3) : (r2 = true, n2 = e3), n2 || (n2 = [`x`, `y`]);
    for (var i2 = {}, a2 = [], o2 = {}, s2 = false, c2 = {}, l2 = 0; l2 < n2.length; l2++) {
      var u2 = n2[l2], d2 = W(u2) ? new US({ name: u2 }) : u2 instanceof US ? u2 : new US(u2), f2 = d2.name;
      d2.type = d2.type || `float`, d2.coordDim || (d2.coordDim = f2, d2.coordDimIndex = 0);
      var p2 = d2.otherDims = d2.otherDims || {};
      a2.push(f2), i2[f2] = d2, c2[f2] != null && (s2 = true), d2.createInvertedIndices && (o2[f2] = []), p2.itemName === 0 && (this._nameDimIdx = l2), p2.itemId === 0 && (this._idDimIdx = l2), r2 && (d2.storeDimIndex = l2);
    }
    if (this.dimensions = a2, this._dimInfos = i2, this._initGetDimensionInfo(s2), this.hostModel = t2, this._invertedIndicesMap = o2, this._dimOmitted) {
      var m2 = this._dimIdxToName = J();
      z(a2, function(e4) {
        m2.set(i2[e4].storeDimIndex, e4);
      });
    }
  }
  return e2.prototype.getDimension = function(e3) {
    var t2 = this._recognizeDimIndex(e3);
    if (t2 == null) return e3;
    if (t2 = e3, !this._dimOmitted) return this.dimensions[t2];
    var n2 = this._dimIdxToName.get(t2);
    if (n2 != null) return n2;
    var r2 = this._schema.getSourceDimension(t2);
    if (r2) return r2.name;
  }, e2.prototype.getDimensionIndex = function(e3) {
    var t2 = this._recognizeDimIndex(e3);
    if (t2 != null) return t2;
    if (e3 == null) return -1;
    var n2 = this._getDimInfo(e3);
    return n2 ? n2.storeDimIndex : this._dimOmitted ? this._schema.getSourceDimensionIndex(e3) : -1;
  }, e2.prototype._recognizeDimIndex = function(e3) {
    if (G(e3) || e3 != null && !isNaN(e3) && !this._getDimInfo(e3) && (!this._dimOmitted || this._schema.getSourceDimensionIndex(e3) < 0)) return +e3;
  }, e2.prototype._getStoreDimIndex = function(e3) {
    return this.getDimensionIndex(e3);
  }, e2.prototype.getDimensionInfo = function(e3) {
    return this._getDimInfo(this.getDimension(e3));
  }, e2.prototype._initGetDimensionInfo = function(e3) {
    var t2 = this._dimInfos;
    this._getDimInfo = e3 ? function(e4) {
      return t2.hasOwnProperty(e4) ? t2[e4] : void 0;
    } : function(e4) {
      return t2[e4];
    };
  }, e2.prototype.getDimensionsOnCoord = function() {
    return this._dimSummary.dataDimsOnCoord.slice();
  }, e2.prototype.mapDimension = function(e3, t2) {
    var n2 = this._dimSummary;
    if (t2 == null) return n2.encodeFirstDimNotExtra[e3];
    var r2 = n2.encode[e3];
    return r2 ? r2[t2] : null;
  }, e2.prototype.mapDimensionsAll = function(e3) {
    return (this._dimSummary.encode[e3] || []).slice();
  }, e2.prototype.getStore = function() {
    return this._store;
  }, e2.prototype.initData = function(e3, t2, n2) {
    var r2 = this, i2;
    if (e3 instanceof $_ && (i2 = e3), !i2) {
      var a2 = this.dimensions, o2 = Yg(e3) || We(e3) ? new u_(e3, a2.length) : e3;
      i2 = new $_();
      var s2 = QS(a2, function(e4) {
        return { type: r2._dimInfos[e4].type, property: e4 };
      });
      i2.initData(o2, s2, n2);
    }
    this._store = i2, this._nameList = (t2 || []).slice(), this._idList = [], this._nameRepeatCount = {}, this._doInit(0, i2.count()), this._dimSummary = zS(this, this._schema), this.userOutput = this._dimSummary.userOutput;
  }, e2.prototype.appendData = function(e3) {
    var t2 = this._store.appendData(e3);
    this._doInit(t2[0], t2[1]);
  }, e2.prototype.appendValues = function(e3, t2) {
    var n2 = this._store.appendValues(e3, t2 && t2.length), r2 = n2.start, i2 = n2.end, a2 = this._shouldMakeIdFromName();
    if (this._updateOrdinalMeta(), t2) for (var o2 = r2; o2 < i2; o2++) {
      var s2 = o2 - r2;
      this._nameList[o2] = t2[s2], a2 && uC(this, o2);
    }
  }, e2.prototype._updateOrdinalMeta = function() {
    for (var e3 = this._store, t2 = this.dimensions, n2 = 0; n2 < t2.length; n2++) {
      var r2 = this._dimInfos[t2[n2]];
      r2.ordinalMeta && e3.collectOrdinalMeta(r2.storeDimIndex, r2.ordinalMeta);
    }
  }, e2.prototype._shouldMakeIdFromName = function() {
    var e3 = this._store.getProvider();
    return this._idDimIdx == null && e3.getSource().sourceFormat !== `typedArray` && !e3.fillStorage;
  }, e2.prototype._doInit = function(e3, t2) {
    if (!(e3 >= t2)) {
      var n2 = this._store.getProvider();
      this._updateOrdinalMeta();
      var r2 = this._nameList, i2 = this._idList;
      if (n2.getSource().sourceFormat === `original` && !n2.pure) for (var a2 = [], o2 = e3; o2 < t2; o2++) {
        var s2 = n2.getItem(o2, a2);
        if (!this.hasItemOption && bs(s2) && (this.hasItemOption = true), s2) {
          var c2 = s2.name;
          r2[o2] == null && c2 != null && (r2[o2] = As(c2, null));
          var l2 = s2.id;
          i2[o2] == null && l2 != null && (i2[o2] = As(l2, null));
        }
      }
      if (this._shouldMakeIdFromName()) for (var o2 = e3; o2 < t2; o2++) uC(this, o2);
      iC(this);
    }
  }, e2.prototype.getApproximateExtent = function(e3) {
    return this._approximateExtent[e3] || this._store.getDataExtent(this._getStoreDimIndex(e3));
  }, e2.prototype.setApproximateExtent = function(e3, t2) {
    t2 = this.getDimension(t2), this._approximateExtent[t2] = e3.slice();
  }, e2.prototype.getCalculationInfo = function(e3) {
    return this._calculationInfo[e3];
  }, e2.prototype.setCalculationInfo = function(e3, t2) {
    ZS(e3) ? R(this._calculationInfo, e3) : this._calculationInfo[e3] = t2;
  }, e2.prototype.getName = function(e3) {
    var t2 = this.getRawIndex(e3), n2 = this._nameList[t2];
    return n2 == null && this._nameDimIdx != null && (n2 = oC(this, this._nameDimIdx, t2)), n2 ?? (n2 = ``), n2;
  }, e2.prototype._getCategory = function(e3, t2) {
    var n2 = this._store.get(e3, t2), r2 = this._store.getOrdinalMeta(e3);
    return r2 ? r2.categories[n2] : n2;
  }, e2.prototype.getId = function(e3) {
    return aC(this, this.getRawIndex(e3));
  }, e2.prototype.count = function() {
    return this._store.count();
  }, e2.prototype.get = function(e3, t2) {
    var n2 = this._store, r2 = this._dimInfos[e3];
    if (r2) return n2.get(r2.storeDimIndex, t2);
  }, e2.prototype.getByRawIndex = function(e3, t2) {
    var n2 = this._store, r2 = this._dimInfos[e3];
    if (r2) return n2.getByRawIndex(r2.storeDimIndex, t2);
  }, e2.prototype.getIndices = function() {
    return this._store.getIndices();
  }, e2.prototype.getDataExtent = function(e3) {
    return this._store.getDataExtent(this._getStoreDimIndex(e3));
  }, e2.prototype.getSum = function(e3) {
    return this._store.getSum(this._getStoreDimIndex(e3));
  }, e2.prototype.getMedian = function(e3) {
    return this._store.getMedian(this._getStoreDimIndex(e3));
  }, e2.prototype.getValues = function(e3, t2) {
    var n2 = this, r2 = this._store;
    return H(e3) ? r2.getValues(QS(e3, function(e4) {
      return n2._getStoreDimIndex(e4);
    }), t2) : r2.getValues(e3);
  }, e2.prototype.hasValue = function(e3) {
    for (var t2 = this._dimSummary.dataDimIndicesOnCoord, n2 = 0, r2 = t2.length; n2 < r2; n2++) if (isNaN(this._store.get(t2[n2], e3))) return false;
    return true;
  }, e2.prototype.indexOfName = function(e3) {
    for (var t2 = 0, n2 = this._store.count(); t2 < n2; t2++) if (this.getName(t2) === e3) return t2;
    return -1;
  }, e2.prototype.getRawIndex = function(e3) {
    return this._store.getRawIndex(e3);
  }, e2.prototype.indexOfRawIndex = function(e3) {
    return this._store.indexOfRawIndex(e3);
  }, e2.prototype.rawIndexOf = function(e3, t2) {
    var n2 = e3 && this._invertedIndicesMap[e3], r2 = n2 && n2[t2];
    return r2 == null || isNaN(r2) ? tC : r2;
  }, e2.prototype.indicesOfNearest = function(e3, t2, n2) {
    return this._store.indicesOfNearest(this._getStoreDimIndex(e3), t2, n2);
  }, e2.prototype.each = function(e3, t2, n2) {
    U(e3) && (n2 = t2, t2 = e3, e3 = []);
    var r2 = n2 || this, i2 = QS(sC(e3), this._getStoreDimIndex, this);
    this._store.each(i2, r2 ? Ye(t2, r2) : t2);
  }, e2.prototype.filterSelf = function(e3, t2, n2) {
    U(e3) && (n2 = t2, t2 = e3, e3 = []);
    var r2 = n2 || this, i2 = QS(sC(e3), this._getStoreDimIndex, this);
    return this._store = this._store.filter(i2, r2 ? Ye(t2, r2) : t2), this;
  }, e2.prototype.selectRange = function(e3) {
    var t2 = this, n2 = {}, r2 = V(e3), i2 = [];
    return z(r2, function(r3) {
      var a2 = t2._getStoreDimIndex(r3);
      n2[a2] = e3[r3], i2.push(a2);
    }), this._store = this._store.selectRange(n2), this;
  }, e2.prototype.mapArray = function(e3, t2, n2) {
    U(e3) && (n2 = t2, t2 = e3, e3 = []), n2 || (n2 = this);
    var r2 = [];
    return this.each(e3, function() {
      r2.push(t2 && t2.apply(this, arguments));
    }, n2), r2;
  }, e2.prototype.map = function(e3, t2, n2, r2) {
    var i2 = n2 || r2 || this, a2 = QS(sC(e3), this._getStoreDimIndex, this), o2 = lC(this);
    return o2._store = this._store.map(a2, i2 ? Ye(t2, i2) : t2), o2;
  }, e2.prototype.modify = function(e3, t2, n2, r2) {
    var i2 = n2 || r2 || this, a2 = QS(sC(e3), this._getStoreDimIndex, this);
    this._store.modify(a2, i2 ? Ye(t2, i2) : t2);
  }, e2.prototype.downSample = function(e3, t2, n2, r2) {
    var i2 = lC(this);
    return i2._store = this._store.downSample(this._getStoreDimIndex(e3), t2, n2, r2), i2;
  }, e2.prototype.minmaxDownSample = function(e3, t2) {
    var n2 = lC(this);
    return n2._store = this._store.minmaxDownSample(this._getStoreDimIndex(e3), t2), n2;
  }, e2.prototype.lttbDownSample = function(e3, t2) {
    var n2 = lC(this);
    return n2._store = this._store.lttbDownSample(this._getStoreDimIndex(e3), t2), n2;
  }, e2.prototype.getRawDataItem = function(e3) {
    return this._store.getRawDataItem(e3);
  }, e2.prototype.getItemModel = function(e3) {
    var t2 = this.hostModel;
    return new om(this.getRawDataItem(e3), t2, t2 && t2.ecModel);
  }, e2.prototype.diff = function(e3) {
    var t2 = this;
    return new LS(e3 ? e3.getStore().getIndices() : [], this.getStore().getIndices(), function(t3) {
      return aC(e3, t3);
    }, function(e4) {
      return aC(t2, e4);
    });
  }, e2.prototype.getVisual = function(e3) {
    var t2 = this._visual;
    return t2 && t2[e3];
  }, e2.prototype.setVisual = function(e3, t2) {
    this._visual = this._visual || {}, ZS(e3) ? R(this._visual, e3) : this._visual[e3] = t2;
  }, e2.prototype.getItemVisual = function(e3, t2) {
    var n2 = this._itemVisuals[e3];
    return (n2 && n2[t2]) ?? this.getVisual(t2);
  }, e2.prototype.hasItemVisual = function() {
    return this._itemVisuals.length > 0;
  }, e2.prototype.ensureUniqueItemVisual = function(e3, t2) {
    var n2 = this._itemVisuals, r2 = n2[e3];
    r2 || (r2 = n2[e3] = {});
    var i2 = r2[t2];
    return i2 ?? (i2 = this.getVisual(t2), H(i2) ? i2 = i2.slice() : ZS(i2) && (i2 = R({}, i2)), r2[t2] = i2), i2;
  }, e2.prototype.setItemVisual = function(e3, t2, n2) {
    var r2 = this._itemVisuals[e3] || {};
    this._itemVisuals[e3] = r2, ZS(t2) ? R(r2, t2) : r2[t2] = n2;
  }, e2.prototype.clearAllVisual = function() {
    this._visual = {}, this._itemVisuals = [];
  }, e2.prototype.setLayout = function(e3, t2) {
    ZS(e3) ? R(this._layout, e3) : this._layout[e3] = t2;
  }, e2.prototype.getLayout = function(e3) {
    return this._layout[e3];
  }, e2.prototype.getItemLayout = function(e3) {
    return this._itemLayouts[e3];
  }, e2.prototype.setItemLayout = function(e3, t2, n2) {
    this._itemLayouts[e3] = n2 ? R(this._itemLayouts[e3] || {}, t2) : t2;
  }, e2.prototype.clearItemLayouts = function() {
    this._itemLayouts.length = 0;
  }, e2.prototype.setItemGraphicEl = function(e3, t2) {
    xu(this.hostModel && this.hostModel.seriesIndex, this.dataType, e3, t2), this._graphicEls[e3] = t2;
  }, e2.prototype.getItemGraphicEl = function(e3) {
    return this._graphicEls[e3];
  }, e2.prototype.eachItemGraphicEl = function(e3, t2) {
    z(this._graphicEls, function(n2, r2) {
      n2 && e3 && e3.call(t2, n2, r2);
    });
  }, e2.prototype.cloneShallow = function(t2) {
    return t2 || (t2 = new e2(this._schema ? this._schema : QS(this.dimensions, this._getDimInfo, this), this.hostModel)), cC(t2, this), t2._store = this._store, t2;
  }, e2.prototype.wrapMethod = function(e3, t2) {
    var n2 = this[e3];
    U(n2) && (this.__wrappedMethods = this.__wrappedMethods || [], this.__wrappedMethods.push(e3), this[e3] = function() {
      var e4 = n2.apply(this, arguments);
      return t2.apply(this, [e4].concat(st(arguments)));
    });
  }, e2.internalField = (function() {
    iC = function(e3) {
      var t2 = e3._invertedIndicesMap;
      z(t2, function(n2, r2) {
        var i2 = e3._dimInfos[r2], a2 = i2.ordinalMeta, o2 = e3._store;
        if (a2) {
          n2 = t2[r2] = new $S(a2.categories.length);
          for (var s2 = 0; s2 < n2.length; s2++) n2[s2] = tC;
          for (var s2 = 0; s2 < o2.count(); s2++) n2[o2.get(i2.storeDimIndex, s2)] = s2;
        }
      });
    }, oC = function(e3, t2, n2) {
      return As(e3._getCategory(t2, n2), null);
    }, aC = function(e3, t2) {
      var n2 = e3._idList[t2];
      return n2 == null && e3._idDimIdx != null && (n2 = oC(e3, e3._idDimIdx, t2)), n2 ?? (n2 = eC + t2), n2;
    }, sC = function(e3) {
      return H(e3) || (e3 = e3 == null ? [] : [e3]), e3;
    }, lC = function(t2) {
      var n2 = new e2(t2._schema ? t2._schema : QS(t2.dimensions, t2._getDimInfo, t2), t2.hostModel);
      return cC(n2, t2), n2;
    }, cC = function(e3, t2) {
      z(nC.concat(t2.__wrappedMethods || []), function(n2) {
        t2.hasOwnProperty(n2) && (e3[n2] = t2[n2]);
      }), e3.__wrappedMethods = t2.__wrappedMethods, z(rC, function(n2) {
        e3[n2] = L(t2[n2]);
      }), e3._calculationInfo = R({}, t2._calculationInfo);
    }, uC = function(e3, t2) {
      var n2 = e3._nameList, r2 = e3._idList, i2 = e3._nameDimIdx, a2 = e3._idDimIdx, o2 = n2[t2], s2 = r2[t2];
      if (o2 == null && i2 != null && (n2[t2] = o2 = oC(e3, i2, t2)), s2 == null && a2 != null && (r2[t2] = s2 = oC(e3, a2, t2)), s2 == null && o2 != null) {
        var c2 = e3._nameRepeatCount, l2 = c2[o2] = (c2[o2] || 0) + 1;
        s2 = o2, l2 > 1 && (s2 += `__ec__` + l2), r2[t2] = s2;
      }
    };
  })(), e2;
})();
function fC(e2, t2) {
  return pC(e2, t2).dimensions;
}
function pC(e2, t2) {
  Yg(e2) || (e2 = Zg(e2)), t2 || (t2 = {});
  var n2 = t2.coordDimensions || [], r2 = t2.dimensionsDefine || e2.dimensionsDefine || [], i2 = J(), a2 = [], o2 = hC(e2, n2, r2, t2.dimensionsCount), s2 = t2.canOmitUnusedDimensions && XS(o2), c2 = r2 === e2.dimensionsDefine, l2 = c2 ? YS(e2) : JS(r2), u2 = t2.encodeDefine;
  !u2 && t2.encodeDefaulter && (u2 = t2.encodeDefaulter(e2, o2));
  for (var d2 = J(u2), f2 = new G_(o2), p2 = 0; p2 < f2.length; p2++) f2[p2] = -1;
  function m2(e3) {
    var t3 = f2[e3];
    if (t3 < 0) {
      var n3 = r2[e3], i3 = K(n3) ? n3 : { name: n3 }, o3 = new US(), s3 = i3.name;
      return s3 != null && l2.get(s3) != null && (o3.name = o3.displayName = s3), i3.type != null && (o3.type = i3.type), i3.displayName != null && (o3.displayName = i3.displayName), f2[e3] = a2.length, o3.storeDimIndex = e3, a2.push(o3), o3;
    }
    return a2[t3];
  }
  if (!s2) for (var p2 = 0; p2 < o2; p2++) m2(p2);
  d2.each(function(e3, t3) {
    var n3 = gs(e3).slice();
    if (n3.length === 1 && !W(n3[0]) && n3[0] < 0) {
      d2.set(t3, false);
      return;
    }
    var r3 = d2.set(t3, []);
    z(n3, function(e4, n4) {
      var i3 = W(e4) ? l2.get(e4) : e4;
      i3 != null && i3 < o2 && (r3[n4] = i3, g2(m2(i3), t3, n4));
    });
  });
  var h2 = 0;
  z(n2, function(e3) {
    var t3, n3, r3, i3;
    if (W(e3)) t3 = e3, i3 = {};
    else {
      i3 = e3, t3 = i3.name;
      var a3 = i3.ordinalMeta;
      i3.ordinalMeta = null, i3 = R({}, i3), i3.ordinalMeta = a3, n3 = i3.dimsDef, r3 = i3.otherDims, i3.name = i3.coordDim = i3.coordDimIndex = i3.dimsDef = i3.otherDims = null;
    }
    var s3 = d2.get(t3);
    if (s3 !== false) {
      if (s3 = gs(s3), !s3.length) for (var l3 = 0; l3 < (n3 && n3.length || 1); l3++) {
        for (; h2 < o2 && m2(h2).coordDim != null; ) h2++;
        h2 < o2 && s3.push(h2++);
      }
      z(s3, function(e4, a4) {
        var o3 = m2(e4);
        if (c2 && i3.type != null && (o3.type = i3.type), g2(ze(o3, i3), t3, a4), o3.name == null && n3) {
          var s4 = n3[a4];
          !K(s4) && (s4 = { name: s4 }), o3.name = o3.displayName = s4.name, o3.defaultTooltip = s4.defaultTooltip;
        }
        r3 && ze(o3.otherDims, r3);
      });
    }
  });
  function g2(e3, t3, n3) {
    jh.get(t3) == null ? (e3.coordDim = t3, e3.coordDimIndex = n3, i2.set(t3, true)) : e3.otherDims[t3] = n3;
  }
  var _2 = t2.generateCoord, v2 = t2.generateCoordCount, y2 = v2 != null;
  v2 = _2 ? v2 || 1 : 0;
  var b2 = _2 || `value`;
  function x2(e3) {
    e3.name ?? (e3.name = e3.coordDim);
  }
  if (s2) z(a2, function(e3) {
    x2(e3);
  }), a2.sort(function(e3, t3) {
    return e3.storeDimIndex - t3.storeDimIndex;
  });
  else for (var S2 = 0; S2 < o2; S2++) {
    var C2 = m2(S2);
    C2.coordDim ?? (C2.coordDim = gC(b2, i2, y2), C2.coordDimIndex = 0, (!_2 || v2 <= 0) && (C2.isExtraCoord = true), v2--), x2(C2), C2.type == null && (Gh(e2, S2) === zh.Must || C2.isExtraCoord && (C2.otherDims.itemName != null || C2.otherDims.seriesName != null)) && (C2.type = `ordinal`);
  }
  return mC(a2), new KS({ source: e2, dimensions: a2, fullDimensionCount: o2, dimensionOmitted: s2 });
}
function mC(e2) {
  for (var t2 = J(), n2 = 0; n2 < e2.length; n2++) {
    var r2 = e2[n2], i2 = r2.name, a2 = t2.get(i2) || 0;
    a2 > 0 && (r2.name = i2 + (a2 - 1)), a2++, t2.set(i2, a2);
  }
}
function hC(e2, t2, n2, r2) {
  var i2 = Math.max(e2.dimensionsDetectedCount || 1, t2.length, n2.length, r2 || 0);
  return z(t2, function(e3) {
    var t3;
    K(e3) && (t3 = e3.dimsDef) && (i2 = Math.max(i2, t3.length));
  }), i2;
}
function gC(e2, t2, n2) {
  if (n2 || t2.hasKey(e2)) {
    for (var r2 = 0; t2.hasKey(e2 + r2); ) r2++;
    e2 += r2;
  }
  return t2.set(e2, true), e2;
}
var _C = /* @__PURE__ */ (function() {
  function e2(e3) {
    this.coordSysDims = [], this.axisMap = J(), this.categoryAxisMap = J(), this.coordSysName = e3;
  }
  return e2;
})();
function vC(e2) {
  var t2 = e2.get(`coordinateSystem`), n2 = new _C(t2), r2 = yC[t2];
  if (r2) return r2(e2, n2, n2.axisMap, n2.categoryAxisMap), n2;
}
var yC = { cartesian2d: function(e2, t2, n2, r2) {
  var i2 = e2.getReferringComponents(`xAxis`, Vs).models[0], a2 = e2.getReferringComponents(`yAxis`, Vs).models[0];
  t2.coordSysDims = [`x`, `y`], n2.set(`x`, i2), n2.set(`y`, a2), bC(i2) && (r2.set(`x`, i2), t2.firstCategoryDimIndex = 0), bC(a2) && (r2.set(`y`, a2), t2.firstCategoryDimIndex ?? (t2.firstCategoryDimIndex = 1));
}, singleAxis: function(e2, t2, n2, r2) {
  var i2 = e2.getReferringComponents(`singleAxis`, Vs).models[0];
  t2.coordSysDims = [`single`], n2.set(`single`, i2), bC(i2) && (r2.set(`single`, i2), t2.firstCategoryDimIndex = 0);
}, polar: function(e2, t2, n2, r2) {
  var i2 = e2.getReferringComponents(`polar`, Vs).models[0], a2 = i2.findAxisModel(`radiusAxis`), o2 = i2.findAxisModel(`angleAxis`);
  t2.coordSysDims = [`radius`, `angle`], n2.set(`radius`, a2), n2.set(`angle`, o2), bC(a2) && (r2.set(`radius`, a2), t2.firstCategoryDimIndex = 0), bC(o2) && (r2.set(`angle`, o2), t2.firstCategoryDimIndex ?? (t2.firstCategoryDimIndex = 1));
}, geo: function(e2, t2, n2, r2) {
  t2.coordSysDims = [`lng`, `lat`];
}, parallel: function(e2, t2, n2, r2) {
  var i2 = e2.ecModel, a2 = i2.getComponent(`parallel`, e2.get(`parallelIndex`)), o2 = t2.coordSysDims = a2.dimensions.slice();
  z(a2.parallelAxisIndex, function(e3, a3) {
    var s2 = i2.getComponent(`parallelAxis`, e3), c2 = o2[a3];
    n2.set(c2, s2), bC(s2) && (r2.set(c2, s2), t2.firstCategoryDimIndex ?? (t2.firstCategoryDimIndex = a3));
  });
} };
function bC(e2) {
  return e2.get(`type`) === `category`;
}
function xC(e2, t2, n2) {
  n2 || (n2 = {});
  var r2 = n2.byIndex, i2 = n2.stackedCoordDimension, a2, o2, s2;
  SC(t2) ? a2 = t2 : (o2 = t2.schema, a2 = o2.dimensions, s2 = t2.store);
  var c2 = !!(e2 && e2.get(`stack`)), l2, u2, d2, f2;
  if (z(a2, function(e3, t3) {
    W(e3) && (a2[t3] = e3 = { name: e3 }), c2 && !e3.isExtraCoord && (!r2 && !l2 && e3.ordinalMeta && (l2 = e3), !u2 && e3.type !== `ordinal` && e3.type !== `time` && (!i2 || i2 === e3.coordDim) && (u2 = e3));
  }), u2 && !r2 && !l2 && (r2 = true), u2) {
    d2 = `__\0ecstackresult_` + e2.id, f2 = `__\0ecstackedover_` + e2.id, l2 && (l2.createInvertedIndices = true);
    var p2 = u2.coordDim, m2 = u2.type, h2 = 0;
    z(a2, function(e3) {
      e3.coordDim === p2 && h2++;
    });
    var g2 = { name: d2, coordDim: p2, coordDimIndex: h2, type: m2, isExtraCoord: true, isCalculationCoord: true, storeDimIndex: a2.length }, _2 = { name: f2, coordDim: f2, coordDimIndex: h2 + 1, type: m2, isExtraCoord: true, isCalculationCoord: true, storeDimIndex: a2.length + 1 };
    o2 ? (s2 && (g2.storeDimIndex = s2.ensureCalculationDimension(f2, m2), _2.storeDimIndex = s2.ensureCalculationDimension(d2, m2)), o2.appendCalculationDimension(g2), o2.appendCalculationDimension(_2)) : (a2.push(g2), a2.push(_2));
  }
  return { stackedDimension: u2 && u2.name, stackedByDimension: l2 && l2.name, isStackedByIndex: r2, stackedOverDimension: f2, stackResultDimension: d2 };
}
function SC(e2) {
  return !qS(e2.schema);
}
function CC(e2, t2) {
  return !!t2 && t2 === e2.getCalculationInfo(`stackedDimension`);
}
function wC(e2, t2) {
  return CC(e2, t2) ? e2.getCalculationInfo(`stackResultDimension`) : t2;
}
function TC(e2, t2) {
  var n2 = e2.get(`coordinateSystem`), r2 = hg.get(n2), i2;
  return t2 && t2.coordSysDims && (i2 = B(t2.coordSysDims, function(e3) {
    var n3 = { name: e3 }, r3 = t2.axisMap.get(e3);
    return r3 && (n3.type = VS(r3.get(`type`))), n3;
  })), i2 || (i2 = r2 && (r2.getDimensionsInfo ? r2.getDimensionsInfo() : r2.dimensions.slice()) || [`x`, `y`]), i2;
}
function EC(e2, t2, n2) {
  var r2, i2;
  return n2 && z(e2, function(e3, a2) {
    var o2 = e3.coordDim, s2 = n2.categoryAxisMap.get(o2);
    s2 && (r2 ?? (r2 = a2), e3.ordinalMeta = s2.getOrdinalMeta(), t2 && (e3.createInvertedIndices = true)), e3.otherDims.itemName != null && (i2 = true);
  }), !i2 && r2 != null && (e2[r2].otherDims.itemName = 0), r2;
}
function DC(e2, t2, n2) {
  n2 || (n2 = {});
  var r2 = t2.getSourceManager(), i2, a2 = false;
  e2 ? (a2 = true, i2 = Zg(e2)) : (i2 = r2.getSource(), a2 = i2.sourceFormat === Mh);
  var o2 = vC(t2), s2 = TC(t2, o2), c2 = n2.useEncodeDefaulter, l2 = U(c2) ? c2 : c2 ? Xe(Hh, s2, t2) : null, u2 = { coordDimensions: s2, generateCoord: n2.generateCoord, encodeDefine: t2.getEncode(), encodeDefaulter: l2, canOmitUnusedDimensions: !a2 }, d2 = pC(i2, u2), f2 = EC(d2.dimensions, n2.createInvertedIndices, o2), p2 = a2 ? null : r2.getSharedDataStore(d2), m2 = xC(t2, { schema: d2, store: p2 }), h2 = new dC(d2, t2);
  h2.setCalculationInfo(m2);
  var g2 = f2 != null && OC(i2) ? function(e3, t3, n3, r3) {
    return r3 === f2 ? n3 : this.defaultDimValueGetter(e3, t3, n3, r3);
  } : null;
  return h2.hasItemOption = false, h2.initData(a2 ? i2 : p2, null, g2), h2;
}
function OC(e2) {
  if (e2.sourceFormat === `original`) return !H(ys(kC(e2.data || [])));
}
function kC(e2) {
  for (var t2 = 0; t2 < e2.length && e2[t2] == null; ) t2++;
  return e2[t2];
}
var AC = (function() {
  function e2(e3) {
    this._setting = e3 || {}, this._extent = [1 / 0, -1 / 0];
  }
  return e2.prototype.getSetting = function(e3) {
    return this._setting[e3];
  }, e2.prototype.unionExtent = function(e3) {
    var t2 = this._extent;
    e3[0] < t2[0] && (t2[0] = e3[0]), e3[1] > t2[1] && (t2[1] = e3[1]);
  }, e2.prototype.unionExtentFromData = function(e3, t2) {
    this.unionExtent(e3.getApproximateExtent(t2));
  }, e2.prototype.getExtent = function() {
    return this._extent.slice();
  }, e2.prototype.setExtent = function(e3, t2) {
    var n2 = this._extent;
    isNaN(e3) || (n2[0] = e3), isNaN(t2) || (n2[1] = t2);
  }, e2.prototype.isInExtentRange = function(e3) {
    return this._extent[0] <= e3 && this._extent[1] >= e3;
  }, e2.prototype.isBlank = function() {
    return this._isBlank;
  }, e2.prototype.setBlank = function(e3) {
    this._isBlank = e3;
  }, e2;
})();
sc(AC);
var jC = 0, MC = (function() {
  function e2(e3) {
    this.categories = e3.categories || [], this._needCollect = e3.needCollect, this._deduplication = e3.deduplication, this.uid = ++jC;
  }
  return e2.createByAxisModel = function(t2) {
    var n2 = t2.option, r2 = n2.data, i2 = r2 && B(r2, NC);
    return new e2({ categories: i2, needCollect: !i2, deduplication: n2.dedplication !== false });
  }, e2.prototype.getOrdinal = function(e3) {
    return this._getOrCreateMap().get(e3);
  }, e2.prototype.parseAndCollect = function(e3) {
    var t2, n2 = this._needCollect;
    if (!W(e3) && !n2) return e3;
    if (n2 && !this._deduplication) return t2 = this.categories.length, this.categories[t2] = e3, t2;
    var r2 = this._getOrCreateMap();
    return t2 = r2.get(e3), t2 ?? (n2 ? (t2 = this.categories.length, this.categories[t2] = e3, r2.set(e3, t2)) : t2 = NaN), t2;
  }, e2.prototype._getOrCreateMap = function() {
    return this._map || (this._map = J(this.categories));
  }, e2;
})();
function NC(e2) {
  return K(e2) && e2.value != null ? e2.value : e2 + ``;
}
function PC(e2) {
  return e2.type === `interval` || e2.type === `log`;
}
function FC(e2, t2, n2, r2) {
  var i2 = {}, a2 = i2.interval = is((e2[1] - e2[0]) / t2, true);
  n2 != null && a2 < n2 && (a2 = i2.interval = n2), r2 != null && a2 > r2 && (a2 = i2.interval = r2);
  var o2 = i2.intervalPrecision = LC(a2);
  return zC(i2.niceTickExtent = [Uo(Math.ceil(e2[0] / a2) * a2, o2), Uo(Math.floor(e2[1] / a2) * a2, o2)], e2), i2;
}
function IC(e2) {
  var t2 = 10 ** rs(e2), n2 = e2 / t2;
  return n2 ? n2 === 2 ? n2 = 3 : n2 === 3 ? n2 = 5 : n2 *= 2 : n2 = 1, Uo(n2 * t2);
}
function LC(e2) {
  return Go(e2) + 2;
}
function RC(e2, t2, n2) {
  e2[t2] = Math.max(Math.min(e2[t2], n2[1]), n2[0]);
}
function zC(e2, t2) {
  !isFinite(e2[0]) && (e2[0] = t2[0]), !isFinite(e2[1]) && (e2[1] = t2[1]), RC(e2, 0, t2), RC(e2, 1, t2), e2[0] > e2[1] && (e2[0] = e2[1]);
}
function BC(e2, t2) {
  return e2 >= t2[0] && e2 <= t2[1];
}
function VC(e2, t2) {
  return t2[1] === t2[0] ? 0.5 : (e2 - t2[0]) / (t2[1] - t2[0]);
}
function HC(e2, t2) {
  return e2 * (t2[1] - t2[0]) + t2[0];
}
M();
var UC = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    var n2 = e2.call(this, t3) || this;
    n2.type = `ordinal`;
    var r2 = n2.getSetting(`ordinalMeta`);
    return r2 || (r2 = new MC({})), H(r2) && (r2 = new MC({ categories: B(r2, function(e3) {
      return K(e3) ? e3.value : e3;
    }) })), n2._ordinalMeta = r2, n2._extent = n2.getSetting(`extent`) || [0, r2.categories.length - 1], n2;
  }
  return t2.prototype.parse = function(e3) {
    return e3 == null ? NaN : W(e3) ? this._ordinalMeta.getOrdinal(e3) : Math.round(e3);
  }, t2.prototype.contain = function(e3) {
    return e3 = this.parse(e3), BC(e3, this._extent) && this._ordinalMeta.categories[e3] != null;
  }, t2.prototype.normalize = function(e3) {
    return e3 = this._getTickNumber(this.parse(e3)), VC(e3, this._extent);
  }, t2.prototype.scale = function(e3) {
    return e3 = Math.round(HC(e3, this._extent)), this.getRawOrdinalNumber(e3);
  }, t2.prototype.getTicks = function() {
    for (var e3 = [], t3 = this._extent, n2 = t3[0]; n2 <= t3[1]; ) e3.push({ value: n2 }), n2++;
    return e3;
  }, t2.prototype.getMinorTicks = function(e3) {
  }, t2.prototype.setSortInfo = function(e3) {
    if (e3 == null) {
      this._ordinalNumbersByTick = this._ticksByOrdinalNumber = null;
      return;
    }
    for (var t3 = e3.ordinalNumbers, n2 = this._ordinalNumbersByTick = [], r2 = this._ticksByOrdinalNumber = [], i2 = 0, a2 = this._ordinalMeta.categories.length, o2 = Math.min(a2, t3.length); i2 < o2; ++i2) {
      var s2 = t3[i2];
      n2[i2] = s2, r2[s2] = i2;
    }
    for (var c2 = 0; i2 < a2; ++i2) {
      for (; r2[c2] != null; ) c2++;
      n2.push(c2), r2[c2] = i2;
    }
  }, t2.prototype._getTickNumber = function(e3) {
    var t3 = this._ticksByOrdinalNumber;
    return t3 && e3 >= 0 && e3 < t3.length ? t3[e3] : e3;
  }, t2.prototype.getRawOrdinalNumber = function(e3) {
    var t3 = this._ordinalNumbersByTick;
    return t3 && e3 >= 0 && e3 < t3.length ? t3[e3] : e3;
  }, t2.prototype.getLabel = function(e3) {
    if (!this.isBlank()) {
      var t3 = this.getRawOrdinalNumber(e3.value), n2 = this._ordinalMeta.categories[t3];
      return n2 == null ? `` : n2 + ``;
    }
  }, t2.prototype.count = function() {
    return this._extent[1] - this._extent[0] + 1;
  }, t2.prototype.unionExtentFromData = function(e3, t3) {
    this.unionExtent(e3.getApproximateExtent(t3));
  }, t2.prototype.isInExtentRange = function(e3) {
    return e3 = this._getTickNumber(e3), this._extent[0] <= e3 && this._extent[1] >= e3;
  }, t2.prototype.getOrdinalMeta = function() {
    return this._ordinalMeta;
  }, t2.prototype.calcNiceTicks = function() {
  }, t2.prototype.calcNiceExtent = function() {
  }, t2.type = `ordinal`, t2;
})(AC);
AC.registerClass(UC), M();
var WC = Uo, GC = (function(e2) {
  s(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3.type = `interval`, t3._interval = 0, t3._intervalPrecision = 2, t3;
  }
  return t2.prototype.parse = function(e3) {
    return e3;
  }, t2.prototype.contain = function(e3) {
    return BC(e3, this._extent);
  }, t2.prototype.normalize = function(e3) {
    return VC(e3, this._extent);
  }, t2.prototype.scale = function(e3) {
    return HC(e3, this._extent);
  }, t2.prototype.setExtent = function(e3, t3) {
    var n2 = this._extent;
    isNaN(e3) || (n2[0] = parseFloat(e3)), isNaN(t3) || (n2[1] = parseFloat(t3));
  }, t2.prototype.unionExtent = function(e3) {
    var t3 = this._extent;
    e3[0] < t3[0] && (t3[0] = e3[0]), e3[1] > t3[1] && (t3[1] = e3[1]), this.setExtent(t3[0], t3[1]);
  }, t2.prototype.getInterval = function() {
    return this._interval;
  }, t2.prototype.setInterval = function(e3) {
    this._interval = e3, this._niceExtent = this._extent.slice(), this._intervalPrecision = LC(e3);
  }, t2.prototype.getTicks = function(e3) {
    var t3 = this._interval, n2 = this._extent, r2 = this._niceExtent, i2 = this._intervalPrecision, a2 = [];
    if (!t3) return a2;
    var o2 = 1e4;
    n2[0] < r2[0] && (e3 ? a2.push({ value: WC(r2[0] - t3, i2) }) : a2.push({ value: n2[0] }));
    for (var s2 = r2[0]; s2 <= r2[1] && (a2.push({ value: s2 }), s2 = WC(s2 + t3, i2), s2 !== a2[a2.length - 1].value); ) if (a2.length > o2) return [];
    var c2 = a2.length ? a2[a2.length - 1].value : r2[1];
    return n2[1] > c2 && (e3 ? a2.push({ value: WC(c2 + t3, i2) }) : a2.push({ value: n2[1] })), a2;
  }, t2.prototype.getMinorTicks = function(e3) {
    for (var t3 = this.getTicks(true), n2 = [], r2 = this.getExtent(), i2 = 1; i2 < t3.length; i2++) {
      for (var a2 = t3[i2], o2 = t3[i2 - 1], s2 = 0, c2 = [], l2 = (a2.value - o2.value) / e3; s2 < e3 - 1; ) {
        var u2 = WC(o2.value + (s2 + 1) * l2);
        u2 > r2[0] && u2 < r2[1] && c2.push(u2), s2++;
      }
      n2.push(c2);
    }
    return n2;
  }, t2.prototype.getLabel = function(e3, t3) {
    if (e3 == null) return ``;
    var n2 = t3 && t3.precision;
    return n2 == null ? n2 = Go(e3.value) || 0 : n2 === `auto` && (n2 = this._intervalPrecision), rh(WC(e3.value, n2, true));
  }, t2.prototype.calcNiceTicks = function(e3, t3, n2) {
    e3 || (e3 = 5);
    var r2 = this._extent, i2 = r2[1] - r2[0];
    if (isFinite(i2)) {
      i2 < 0 && (i2 = -i2, r2.reverse());
      var a2 = FC(r2, e3, t3, n2);
      this._intervalPrecision = a2.intervalPrecision, this._interval = a2.interval, this._niceExtent = a2.niceTickExtent;
    }
  }, t2.prototype.calcNiceExtent = function(e3) {
    var t3 = this._extent;
    if (t3[0] === t3[1]) {
      if (t3[0] !== 0) {
        var n2 = Math.abs(t3[0]);
        e3.fixMax || (t3[1] += n2 / 2), t3[0] -= n2 / 2;
      } else t3[1] = 1;
    }
    var r2 = t3[1] - t3[0];
    isFinite(r2) || (t3[0] = 0, t3[1] = 1), this.calcNiceTicks(e3.splitNumber, e3.minInterval, e3.maxInterval);
    var i2 = this._interval;
    e3.fixMin || (t3[0] = WC(Math.floor(t3[0] / i2) * i2)), e3.fixMax || (t3[1] = WC(Math.ceil(t3[1] / i2) * i2));
  }, t2.prototype.setNiceExtent = function(e3, t3) {
    this._niceExtent = [e3, t3];
  }, t2.type = `interval`, t2;
})(AC);
AC.registerClass(GC);
var KC = typeof Float32Array < `u`, qC = KC ? Float32Array : Array;
function JC(e2) {
  return H(e2) ? KC ? new Float32Array(e2) : e2 : new qC(e2);
}
var YC = `__ec_stack_`;
function XC(e2) {
  return e2.get(`stack`) || YC + e2.seriesIndex;
}
function ZC(e2) {
  return e2.dim + e2.index;
}
function QC(e2, t2) {
  var n2 = [];
  return t2.eachSeriesByType(e2, function(e3) {
    rw(e3) && n2.push(e3);
  }), n2;
}
function $C(e2) {
  var t2 = {};
  z(e2, function(e3) {
    var n3 = e3.coordinateSystem.getBaseAxis();
    if (n3.type === `time` || n3.type === `value`) for (var r3 = e3.getData(), i3 = n3.dim + `_` + n3.index, a3 = r3.getDimensionIndex(r3.mapDimension(n3.dim)), o3 = r3.getStore(), s3 = 0, c2 = o3.count(); s3 < c2; ++s3) {
      var l2 = o3.get(a3, s3);
      t2[i3] ? t2[i3].push(l2) : t2[i3] = [l2];
    }
  });
  var n2 = {};
  for (var r2 in t2) if (t2.hasOwnProperty(r2)) {
    var i2 = t2[r2];
    if (i2) {
      i2.sort(function(e3, t3) {
        return e3 - t3;
      });
      for (var a2 = null, o2 = 1; o2 < i2.length; ++o2) {
        var s2 = i2[o2] - i2[o2 - 1];
        s2 > 0 && (a2 = a2 === null ? s2 : Math.min(a2, s2));
      }
      n2[r2] = a2;
    }
  }
  return n2;
}
function ew(e2) {
  var t2 = $C(e2), n2 = [];
  return z(e2, function(e3) {
    var r2 = e3.coordinateSystem.getBaseAxis(), i2 = r2.getExtent(), a2;
    if (r2.type === `category`) a2 = r2.getBandWidth();
    else if (r2.type === `value` || r2.type === `time`) {
      var o2 = t2[r2.dim + `_` + r2.index], s2 = Math.abs(i2[1] - i2[0]), c2 = r2.scale.getExtent(), l2 = Math.abs(c2[1] - c2[0]);
      a2 = o2 ? s2 / l2 * o2 : s2;
    } else {
      var u2 = e3.getData();
      a2 = Math.abs(i2[1] - i2[0]) / u2.count();
    }
    var d2 = Ho(e3.get(`barWidth`), a2), f2 = Ho(e3.get(`barMaxWidth`), a2), p2 = Ho(e3.get(`barMinWidth`) || (iw(e3) ? 0.5 : 1), a2), m2 = e3.get(`barGap`), h2 = e3.get(`barCategoryGap`);
    n2.push({ bandWidth: a2, barWidth: d2, barMaxWidth: f2, barMinWidth: p2, barGap: m2, barCategoryGap: h2, axisKey: ZC(r2), stackId: XC(e3) });
  }), tw(n2);
}
function tw(e2) {
  var t2 = {};
  z(e2, function(e3, n3) {
    var r2 = e3.axisKey, i2 = e3.bandWidth, a2 = t2[r2] || { bandWidth: i2, remainedWidth: i2, autoWidthCount: 0, categoryGap: null, gap: `20%`, stacks: {} }, o2 = a2.stacks;
    t2[r2] = a2;
    var s2 = e3.stackId;
    o2[s2] || a2.autoWidthCount++, o2[s2] = o2[s2] || { width: 0, maxWidth: 0 };
    var c2 = e3.barWidth;
    c2 && !o2[s2].width && (o2[s2].width = c2, c2 = Math.min(a2.remainedWidth, c2), a2.remainedWidth -= c2);
    var l2 = e3.barMaxWidth;
    l2 && (o2[s2].maxWidth = l2);
    var u2 = e3.barMinWidth;
    u2 && (o2[s2].minWidth = u2);
    var d2 = e3.barGap;
    d2 != null && (a2.gap = d2);
    var f2 = e3.barCategoryGap;
    f2 != null && (a2.categoryGap = f2);
  });
  var n2 = {};
  return z(t2, function(e3, t3) {
    n2[t3] = {};
    var r2 = e3.stacks, i2 = e3.bandWidth, a2 = e3.categoryGap;
    if (a2 == null) {
      var o2 = V(r2).length;
      a2 = Math.max(35 - o2 * 4, 15) + `%`;
    }
    var s2 = Ho(a2, i2), c2 = Ho(e3.gap, 1), l2 = e3.remainedWidth, u2 = e3.autoWidthCount, d2 = (l2 - s2) / (u2 + (u2 - 1) * c2);
    d2 = Math.max(d2, 0), z(r2, function(e4) {
      var t4 = e4.maxWidth, n3 = e4.minWidth;
      if (e4.width) {
        var r3 = e4.width;
        t4 && (r3 = Math.min(r3, t4)), n3 && (r3 = Math.max(r3, n3)), e4.width = r3, l2 -= r3 + c2 * r3, u2--;
      } else {
        var r3 = d2;
        t4 && t4 < r3 && (r3 = Math.min(t4, l2)), n3 && n3 > r3 && (r3 = n3), r3 !== d2 && (e4.width = r3, l2 -= r3 + c2 * r3, u2--);
      }
    }), d2 = (l2 - s2) / (u2 + (u2 - 1) * c2), d2 = Math.max(d2, 0);
    var f2 = 0, p2;
    z(r2, function(e4, t4) {
      e4.width || (e4.width = d2), p2 = e4, f2 += e4.width * (1 + c2);
    }), p2 && (f2 -= p2.width * c2);
    var m2 = -f2 / 2;
    z(r2, function(e4, r3) {
      n2[t3][r3] = n2[t3][r3] || { bandWidth: i2, offset: m2, width: e4.width }, m2 += e4.width * (1 + c2);
    });
  }), n2;
}
function nw(e2, t2, n2) {
  if (e2 && t2) {
    var r2 = e2[ZC(t2)];
    return r2 != null && n2 != null ? r2[XC(n2)] : r2;
  }
}
function rw(e2) {
  return e2.coordinateSystem && e2.coordinateSystem.type === `cartesian2d`;
}
function iw(e2) {
  return e2.pipelineContext && e2.pipelineContext.large;
}
M();
var aw = function(e2, t2, n2, r2) {
  for (; n2 < r2; ) {
    var i2 = n2 + r2 >>> 1;
    e2[i2][1] < t2 ? n2 = i2 + 1 : r2 = i2;
  }
  return n2;
}, ow = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    var n2 = e2.call(this, t3) || this;
    return n2.type = `time`, n2;
  }
  return t2.prototype.getLabel = function(e3) {
    var t3 = this.getSetting(`useUTC`);
    return Rm(e3.value, jm[Lm(Fm(this._minLevelUnit))] || jm.second, t3, this.getSetting(`locale`));
  }, t2.prototype.getFormattedLabel = function(e3, t3, n2) {
    var r2 = this.getSetting(`useUTC`);
    return zm(e3, t3, n2, this.getSetting(`locale`), r2);
  }, t2.prototype.getTicks = function() {
    var e3 = this._interval, t3 = this._extent, n2 = [];
    if (!e3) return n2;
    n2.push({ value: t3[0], level: 0 });
    var r2 = this.getSetting(`useUTC`), i2 = hw(this._minLevelUnit, this._approxInterval, r2, t3);
    return n2 = n2.concat(i2), n2.push({ value: t3[1], level: 0 }), n2;
  }, t2.prototype.calcNiceExtent = function(e3) {
    var t3 = this._extent;
    if (t3[0] === t3[1] && (t3[0] -= Dm, t3[1] += Dm), t3[1] === -1 / 0 && t3[0] === 1 / 0) {
      var n2 = /* @__PURE__ */ new Date();
      t3[1] = +new Date(n2.getFullYear(), n2.getMonth(), n2.getDate()), t3[0] = t3[1] - Dm;
    }
    this.calcNiceTicks(e3.splitNumber, e3.minInterval, e3.maxInterval);
  }, t2.prototype.calcNiceTicks = function(e3, t3, n2) {
    e3 || (e3 = 10);
    var r2 = this._extent, i2 = r2[1] - r2[0];
    this._approxInterval = i2 / e3, t3 != null && this._approxInterval < t3 && (this._approxInterval = t3), n2 != null && this._approxInterval > n2 && (this._approxInterval = n2);
    var a2 = sw.length, o2 = Math.min(aw(sw, this._approxInterval, 0, a2), a2 - 1);
    this._interval = sw[o2][1], this._minLevelUnit = sw[Math.max(o2 - 1, 0)][0];
  }, t2.prototype.parse = function(e3) {
    return G(e3) ? e3 : +ts(e3);
  }, t2.prototype.contain = function(e3) {
    return BC(this.parse(e3), this._extent);
  }, t2.prototype.normalize = function(e3) {
    return VC(this.parse(e3), this._extent);
  }, t2.prototype.scale = function(e3) {
    return HC(e3, this._extent);
  }, t2.type = `time`, t2;
})(GC), sw = [[`second`, wm], [`minute`, Tm], [`hour`, Em], [`quarter-day`, Em * 6], [`half-day`, Em * 12], [`day`, Dm * 1.2], [`half-week`, Dm * 3.5], [`week`, Dm * 7], [`month`, Dm * 31], [`quarter`, Dm * 95], [`half-year`, Om / 2], [`year`, Om]];
function cw(e2, t2, n2, r2) {
  var i2 = ts(t2), a2 = ts(n2), o2 = function(e3) {
    return Vm(i2, e3, r2) === Vm(a2, e3, r2);
  }, s2 = function() {
    return o2(`year`);
  }, c2 = function() {
    return s2() && o2(`month`);
  }, l2 = function() {
    return c2() && o2(`day`);
  }, u2 = function() {
    return l2() && o2(`hour`);
  }, d2 = function() {
    return u2() && o2(`minute`);
  }, f2 = function() {
    return d2() && o2(`second`);
  }, p2 = function() {
    return f2() && o2(`millisecond`);
  };
  switch (e2) {
    case `year`:
      return s2();
    case `month`:
      return c2();
    case `day`:
      return l2();
    case `hour`:
      return u2();
    case `minute`:
      return d2();
    case `second`:
      return f2();
    case `millisecond`:
      return p2();
  }
}
function lw(e2, t2) {
  return e2 /= Dm, e2 > 16 ? 16 : e2 > 7.5 ? 7 : e2 > 3.5 ? 4 : e2 > 1.5 ? 2 : 1;
}
function uw(e2) {
  var t2 = 30 * Dm;
  return e2 /= t2, e2 > 6 ? 6 : e2 > 3 ? 3 : e2 > 2 ? 2 : 1;
}
function dw(e2) {
  return e2 /= Em, e2 > 12 ? 12 : e2 > 6 ? 6 : e2 > 3.5 ? 4 : e2 > 2 ? 2 : 1;
}
function fw(e2, t2) {
  return e2 /= t2 ? Tm : wm, e2 > 30 ? 30 : e2 > 20 ? 20 : e2 > 15 ? 15 : e2 > 10 ? 10 : e2 > 5 ? 5 : e2 > 2 ? 2 : 1;
}
function pw(e2) {
  return is(e2, true);
}
function mw(e2, t2, n2) {
  var r2 = new Date(e2);
  switch (Fm(t2)) {
    case `year`:
    case `month`:
      r2[Xm(n2)](0);
    case `day`:
      r2[Zm(n2)](1);
    case `hour`:
      r2[Qm(n2)](0);
    case `minute`:
      r2[$m(n2)](0);
    case `second`:
      r2[eh(n2)](0), r2[th(n2)](0);
  }
  return r2.getTime();
}
function hw(e2, t2, n2, r2) {
  var i2 = 1e4, a2 = Nm, o2 = 0;
  function s2(e3, t3, n3, i3, a3, o3, s3) {
    for (var c3 = new Date(t3), l3 = t3, u3 = c3[i3](); l3 < n3 && l3 <= r2[1]; ) s3.push({ value: l3 }), u3 += e3, c3[a3](u3), l3 = c3.getTime();
    s3.push({ value: l3, notAdd: true });
  }
  function c2(e3, i3, a3) {
    var o3 = [], c3 = !i3.length;
    if (!cw(Fm(e3), r2[0], r2[1], n2)) {
      c3 && (i3 = [{ value: mw(new Date(r2[0]), e3, n2) }, { value: r2[1] }]);
      for (var l3 = 0; l3 < i3.length - 1; l3++) {
        var u3 = i3[l3].value, d3 = i3[l3 + 1].value;
        if (u3 !== d3) {
          var f3 = void 0, p3 = void 0, m3 = void 0, h3 = false;
          switch (e3) {
            case `year`:
              f3 = Math.max(1, Math.round(t2 / Dm / 365)), p3 = Hm(n2), m3 = Ym(n2);
              break;
            case `half-year`:
            case `quarter`:
            case `month`:
              f3 = uw(t2), p3 = Um(n2), m3 = Xm(n2);
              break;
            case `week`:
            case `half-week`:
            case `day`:
              f3 = lw(t2, 31), p3 = Wm(n2), m3 = Zm(n2), h3 = true;
              break;
            case `half-day`:
            case `quarter-day`:
            case `hour`:
              f3 = dw(t2), p3 = Gm(n2), m3 = Qm(n2);
              break;
            case `minute`:
              f3 = fw(t2, true), p3 = Km(n2), m3 = $m(n2);
              break;
            case `second`:
              f3 = fw(t2, false), p3 = qm(n2), m3 = eh(n2);
              break;
            case `millisecond`:
              f3 = pw(t2), p3 = Jm(n2), m3 = th(n2);
          }
          s2(f3, u3, d3, p3, m3, h3, o3), e3 === `year` && a3.length > 1 && l3 === 0 && a3.unshift({ value: a3[0].value - f3 });
        }
      }
      for (var l3 = 0; l3 < o3.length; l3++) a3.push(o3[l3]);
      return o3;
    }
  }
  for (var l2 = [], u2 = [], d2 = 0, f2 = 0, p2 = 0; p2 < a2.length && o2++ < i2; ++p2) {
    var m2 = Fm(a2[p2]);
    if (Im(a2[p2]) && (c2(a2[p2], l2[l2.length - 1] || [], u2), m2 !== (a2[p2 + 1] ? Fm(a2[p2 + 1]) : null))) {
      if (u2.length) {
        f2 = d2, u2.sort(function(e3, t3) {
          return e3.value - t3.value;
        });
        for (var h2 = [], g2 = 0; g2 < u2.length; ++g2) {
          var _2 = u2[g2].value;
          (g2 === 0 || u2[g2 - 1].value !== _2) && (h2.push(u2[g2]), _2 >= r2[0] && _2 <= r2[1] && d2++);
        }
        var v2 = (r2[1] - r2[0]) / t2;
        if (d2 > v2 * 1.5 && f2 > v2 / 1.5 || (l2.push(h2), d2 > v2 || e2 === a2[p2])) break;
      }
      u2 = [];
    }
  }
  for (var y2 = Ke(B(l2, function(e3) {
    return Ke(e3, function(e4) {
      return e4.value >= r2[0] && e4.value <= r2[1] && !e4.notAdd;
    });
  }), function(e3) {
    return e3.length > 0;
  }), b2 = [], x2 = y2.length - 1, p2 = 0; p2 < y2.length; ++p2) for (var S2 = y2[p2], C2 = 0; C2 < S2.length; ++C2) b2.push({ value: S2[C2].value, level: x2 - p2 });
  b2.sort(function(e3, t3) {
    return e3.value - t3.value;
  });
  for (var w2 = [], p2 = 0; p2 < b2.length; ++p2) (p2 === 0 || b2[p2].value !== b2[p2 - 1].value) && w2.push(b2[p2]);
  return w2;
}
AC.registerClass(ow), M();
var gw = AC.prototype, _w = GC.prototype, vw = Uo, yw = Math.floor, bw = Math.ceil, xw = Math.pow, Sw = Math.log, Cw = (function(e2) {
  s(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3.type = `log`, t3.base = 10, t3._originalScale = new GC(), t3._interval = 0, t3;
  }
  return t2.prototype.getTicks = function(e3) {
    var t3 = this._originalScale, n2 = this._extent, r2 = t3.getExtent();
    return B(_w.getTicks.call(this, e3), function(e4) {
      var t4 = e4.value, i2 = Uo(xw(this.base, t4));
      return i2 = t4 === n2[0] && this._fixMin ? Tw(i2, r2[0]) : i2, i2 = t4 === n2[1] && this._fixMax ? Tw(i2, r2[1]) : i2, { value: i2 };
    }, this);
  }, t2.prototype.setExtent = function(e3, t3) {
    var n2 = Sw(this.base);
    e3 = Sw(Math.max(0, e3)) / n2, t3 = Sw(Math.max(0, t3)) / n2, _w.setExtent.call(this, e3, t3);
  }, t2.prototype.getExtent = function() {
    var e3 = this.base, t3 = gw.getExtent.call(this);
    t3[0] = xw(e3, t3[0]), t3[1] = xw(e3, t3[1]);
    var n2 = this._originalScale.getExtent();
    return this._fixMin && (t3[0] = Tw(t3[0], n2[0])), this._fixMax && (t3[1] = Tw(t3[1], n2[1])), t3;
  }, t2.prototype.unionExtent = function(e3) {
    this._originalScale.unionExtent(e3);
    var t3 = this.base;
    e3[0] = Sw(e3[0]) / Sw(t3), e3[1] = Sw(e3[1]) / Sw(t3), gw.unionExtent.call(this, e3);
  }, t2.prototype.unionExtentFromData = function(e3, t3) {
    this.unionExtent(e3.getApproximateExtent(t3));
  }, t2.prototype.calcNiceTicks = function(e3) {
    e3 || (e3 = 10);
    var t3 = this._extent, n2 = t3[1] - t3[0];
    if (!(n2 === 1 / 0 || n2 <= 0)) {
      var r2 = ns(n2);
      for (e3 / n2 * r2 <= 0.5 && (r2 *= 10); !isNaN(r2) && Math.abs(r2) < 1 && Math.abs(r2) > 0; ) r2 *= 10;
      var i2 = [Uo(bw(t3[0] / r2) * r2), Uo(yw(t3[1] / r2) * r2)];
      this._interval = r2, this._niceExtent = i2;
    }
  }, t2.prototype.calcNiceExtent = function(e3) {
    _w.calcNiceExtent.call(this, e3), this._fixMin = e3.fixMin, this._fixMax = e3.fixMax;
  }, t2.prototype.parse = function(e3) {
    return e3;
  }, t2.prototype.contain = function(e3) {
    return e3 = Sw(e3) / Sw(this.base), BC(e3, this._extent);
  }, t2.prototype.normalize = function(e3) {
    return e3 = Sw(e3) / Sw(this.base), VC(e3, this._extent);
  }, t2.prototype.scale = function(e3) {
    return e3 = HC(e3, this._extent), xw(this.base, e3);
  }, t2.type = `log`, t2;
})(AC), ww = Cw.prototype;
ww.getMinorTicks = _w.getMinorTicks, ww.getLabel = _w.getLabel;
function Tw(e2, t2) {
  return vw(e2, Go(t2));
}
AC.registerClass(Cw);
var Ew = (function() {
  function e2(e3, t2, n2) {
    this._prepareParams(e3, t2, n2);
  }
  return e2.prototype._prepareParams = function(e3, t2, n2) {
    n2[1] < n2[0] && (n2 = [NaN, NaN]), this._dataMin = n2[0], this._dataMax = n2[1];
    var r2 = this._isOrdinal = e3.type === `ordinal`;
    this._needCrossZero = e3.type === `interval` && t2.getNeedCrossZero && t2.getNeedCrossZero();
    var i2 = t2.get(`min`, true);
    i2 ?? (i2 = t2.get(`startValue`, true));
    var a2 = this._modelMinRaw = i2;
    U(a2) ? this._modelMinNum = Aw(e3, a2({ min: n2[0], max: n2[1] })) : a2 !== `dataMin` && (this._modelMinNum = Aw(e3, a2));
    var o2 = this._modelMaxRaw = t2.get(`max`, true);
    if (U(o2) ? this._modelMaxNum = Aw(e3, o2({ min: n2[0], max: n2[1] })) : o2 !== `dataMax` && (this._modelMaxNum = Aw(e3, o2)), r2) this._axisDataLen = t2.getCategories().length;
    else {
      var s2 = t2.get(`boundaryGap`), c2 = H(s2) ? s2 : [s2 || 0, s2 || 0];
      this._boundaryGapInner = typeof c2[0] == `boolean` || typeof c2[1] == `boolean` ? [0, 0] : [oo(c2[0], 1), oo(c2[1], 1)];
    }
  }, e2.prototype.calculate = function() {
    var e3 = this._isOrdinal, t2 = this._dataMin, n2 = this._dataMax, r2 = this._axisDataLen, i2 = this._boundaryGapInner, a2 = e3 ? null : n2 - t2 || Math.abs(t2), o2 = this._modelMinRaw === `dataMin` ? t2 : this._modelMinNum, s2 = this._modelMaxRaw === `dataMax` ? n2 : this._modelMaxNum, c2 = o2 != null, l2 = s2 != null;
    o2 ?? (o2 = e3 ? r2 ? 0 : NaN : t2 - i2[0] * a2), s2 ?? (s2 = e3 ? r2 ? r2 - 1 : NaN : n2 + i2[1] * a2), (o2 == null || !isFinite(o2)) && (o2 = NaN), (s2 == null || !isFinite(s2)) && (s2 = NaN);
    var u2 = it(o2) || it(s2) || e3 && !r2;
    this._needCrossZero && (o2 > 0 && s2 > 0 && !c2 && (o2 = 0), o2 < 0 && s2 < 0 && !l2 && (s2 = 0));
    var d2 = this._determinedMin, f2 = this._determinedMax;
    return d2 != null && (o2 = d2, c2 = true), f2 != null && (s2 = f2, l2 = true), { min: o2, max: s2, minFixed: c2, maxFixed: l2, isBlank: u2 };
  }, e2.prototype.modifyDataMinMax = function(e3, t2) {
    this[Ow[e3]] = t2;
  }, e2.prototype.setDeterminedMinMax = function(e3, t2) {
    var n2 = Dw[e3];
    this[n2] = t2;
  }, e2.prototype.freeze = function() {
    this.frozen = true;
  }, e2;
})(), Dw = { min: `_determinedMin`, max: `_determinedMax` }, Ow = { min: `_dataMin`, max: `_dataMax` };
function kw(e2, t2, n2) {
  var r2 = e2.rawExtentInfo;
  return r2 || (r2 = new Ew(e2, t2, n2), e2.rawExtentInfo = r2, r2);
}
function Aw(e2, t2) {
  return t2 == null ? null : it(t2) ? NaN : e2.parse(t2);
}
function jw(e2, t2) {
  var n2 = e2.type, r2 = kw(e2, t2, e2.getExtent()).calculate();
  e2.setBlank(r2.isBlank);
  var i2 = r2.min, a2 = r2.max, o2 = t2.ecModel;
  if (o2 && n2 === `time`) {
    var s2 = QC(`bar`, o2), c2 = false;
    if (z(s2, function(e3) {
      c2 || (c2 = e3.getBaseAxis() === t2.axis);
    }), c2) {
      var l2 = ew(s2), u2 = Mw(i2, a2, t2, l2);
      i2 = u2.min, a2 = u2.max;
    }
  }
  return { extent: [i2, a2], fixMin: r2.minFixed, fixMax: r2.maxFixed };
}
function Mw(e2, t2, n2, r2) {
  var i2 = n2.axis.getExtent(), a2 = Math.abs(i2[1] - i2[0]), o2 = nw(r2, n2.axis);
  if (o2 === void 0) return { min: e2, max: t2 };
  var s2 = 1 / 0;
  z(o2, function(e3) {
    s2 = Math.min(e3.offset, s2);
  });
  var c2 = -1 / 0;
  z(o2, function(e3) {
    c2 = Math.max(e3.offset + e3.width, c2);
  }), s2 = Math.abs(s2), c2 = Math.abs(c2);
  var l2 = s2 + c2, u2 = t2 - e2, d2 = u2 / (1 - (s2 + c2) / a2) - u2;
  return t2 += c2 / l2 * d2, e2 -= s2 / l2 * d2, { min: e2, max: t2 };
}
function Nw(e2, t2) {
  var n2 = t2, r2 = jw(e2, n2), i2 = r2.extent, a2 = n2.get(`splitNumber`);
  e2 instanceof Cw && (e2.base = n2.get(`logBase`));
  var o2 = e2.type, s2 = n2.get(`interval`), c2 = o2 === `interval` || o2 === `time`;
  e2.setExtent(i2[0], i2[1]), e2.calcNiceExtent({ splitNumber: a2, fixMin: r2.fixMin, fixMax: r2.fixMax, minInterval: c2 ? n2.get(`minInterval`) : null, maxInterval: c2 ? n2.get(`maxInterval`) : null }), s2 != null && e2.setInterval && e2.setInterval(s2);
}
function Pw(e2, t2) {
  if (t2 || (t2 = e2.get(`type`)), t2) switch (t2) {
    case `category`:
      return new UC({ ordinalMeta: e2.getOrdinalMeta ? e2.getOrdinalMeta() : e2.getCategories(), extent: [1 / 0, -1 / 0] });
    case `time`:
      return new ow({ locale: e2.ecModel.getLocaleModel(), useUTC: e2.ecModel.get(`useUTC`) });
    default:
      return new (AC.getClass(t2) || GC)();
  }
}
function Fw(e2) {
  var t2 = e2.scale.getExtent(), n2 = t2[0], r2 = t2[1];
  return !(n2 > 0 && r2 > 0 || n2 < 0 && r2 < 0);
}
function Iw(e2) {
  var t2 = e2.getLabelModel().get(`formatter`), n2 = e2.type === `category` ? e2.scale.getExtent()[0] : null;
  return e2.scale.type === `time` ? /* @__PURE__ */ (function(t3) {
    return function(n3, r2) {
      return e2.scale.getFormattedLabel(n3, r2, t3);
    };
  })(t2) : W(t2) ? /* @__PURE__ */ (function(t3) {
    return function(n3) {
      var r2 = e2.scale.getLabel(n3);
      return t3.replace(`{value}`, r2 ?? ``);
    };
  })(t2) : U(t2) ? /* @__PURE__ */ (function(t3) {
    return function(r2, i2) {
      return n2 != null && (i2 = r2.value - n2), t3(Lw(e2, r2), i2, r2.level == null ? null : { level: r2.level });
    };
  })(t2) : function(t3) {
    return e2.scale.getLabel(t3);
  };
}
function Lw(e2, t2) {
  return e2.type === `category` ? e2.scale.getLabel(t2) : t2.value;
}
function Rw(e2) {
  var t2 = e2.model, n2 = e2.scale;
  if (t2.get([`axisLabel`, `show`]) && !n2.isBlank()) {
    var r2, i2, a2 = n2.getExtent();
    n2 instanceof UC ? i2 = n2.count() : (r2 = n2.getTicks(), i2 = r2.length);
    var o2 = e2.getLabelModel(), s2 = Iw(e2), c2, l2 = 1;
    i2 > 40 && (l2 = Math.ceil(i2 / 40));
    for (var u2 = 0; u2 < i2; u2 += l2) {
      var d2 = s2(r2 ? r2[u2] : { value: a2[0] + u2 }, u2), f2 = zw(o2.getTextRect(d2), o2.get(`rotate`) || 0);
      c2 ? c2.union(f2) : c2 = f2;
    }
    return c2;
  }
}
function zw(e2, t2) {
  var n2 = t2 * Math.PI / 180, r2 = e2.width, i2 = e2.height, a2 = r2 * Math.abs(Math.cos(n2)) + Math.abs(i2 * Math.sin(n2)), o2 = r2 * Math.abs(Math.sin(n2)) + Math.abs(i2 * Math.cos(n2));
  return new X(e2.x, e2.y, a2, o2);
}
function Bw(e2) {
  return e2.get(`interval`) ?? `auto`;
}
function Vw(e2) {
  return e2.type === `category` && Bw(e2.getLabelModel()) === 0;
}
function Hw(e2, t2) {
  var n2 = {};
  return z(e2.mapDimensionsAll(t2), function(t3) {
    n2[wC(e2, t3)] = true;
  }), V(n2);
}
function Uw(e2, t2, n2) {
  t2 && z(Hw(t2, n2), function(n3) {
    var r2 = t2.getApproximateExtent(n3);
    r2[0] < e2[0] && (e2[0] = r2[0]), r2[1] > e2[1] && (e2[1] = r2[1]);
  });
}
var Ww = (function() {
  function e2() {
  }
  return e2.prototype.getNeedCrossZero = function() {
    return !this.option.scale;
  }, e2.prototype.getCoordSysModel = function() {
  }, e2;
})(), Gw = n({ createDimensions: () => fC, createList: () => Kw, createScale: () => Jw, createSymbol: () => Zy, createTextStyle: () => Xw, dataStack: () => qw, enableHoverEmphasis: () => hd, getECData: () => bu, getLayoutRect: () => bh, mixinAxisModelCommonMethods: () => Yw });
function Kw(e2) {
  return DC(null, e2);
}
var qw = { isDimensionStacked: CC, enableDataStack: xC, getStackedDimension: wC };
function Jw(e2, t2) {
  var n2 = t2;
  t2 instanceof om || (n2 = new om(t2));
  var r2 = Pw(n2);
  return r2.setExtent(e2[0], e2[1]), Nw(r2, n2), r2;
}
function Yw(e2) {
  Ue(e2, Ww);
}
function Xw(e2, t2) {
  return t2 || (t2 = {}), Bp(e2, null, null, t2.state !== `normal`);
}
var Zw = [], Qw = { registerPreprocessor: _S, registerProcessor: vS, registerPostInit: yS, registerPostUpdate: bS, registerUpdateLifecycle: xS, registerAction: SS, registerCoordinateSystem: CS, registerLayout: TS, registerVisual: ES, registerTransform: NS, registerLoading: kS, registerMap: jS, registerImpl: Yb, PRIORITY: hx, ComponentModel: $, ComponentView: Lv, SeriesModel: Ov, ChartView: Vv, registerComponentModel: function(e2) {
  $.registerClass(e2);
}, registerComponentView: function(e2) {
  Lv.registerClass(e2);
}, registerSeriesModel: function(e2) {
  Ov.registerClass(e2);
}, registerChartView: function(e2) {
  Vv.registerClass(e2);
}, registerSubTypeDefaulter: function(e2, t2) {
  $.registerSubTypeDefaulter(e2, t2);
}, registerPainter: function(e2, t2) {
  No(e2, t2);
} };
function $w(e2) {
  if (H(e2)) {
    z(e2, function(e3) {
      $w(e3);
    });
    return;
  }
  Ve(Zw, e2) >= 0 || (Zw.push(e2), U(e2) && (e2 = { install: e2 }), e2.install(Qw));
}
var eT = 1e-8;
function tT(e2, t2) {
  return Math.abs(e2 - t2) < eT;
}
function nT(e2, t2, n2) {
  var r2 = 0, i2 = e2[0];
  if (!i2) return false;
  for (var a2 = 1; a2 < e2.length; a2++) {
    var o2 = e2[a2];
    r2 += El(i2[0], i2[1], o2[0], o2[1], t2, n2), i2 = o2;
  }
  var s2 = e2[0];
  return (!tT(i2[0], s2[0]) || !tT(i2[1], s2[1])) && (r2 += El(i2[0], i2[1], s2[0], s2[1], t2, n2)), r2 !== 0;
}
M();
var rT = [];
function iT(e2, t2) {
  for (var n2 = 0; n2 < e2.length; n2++) qt(e2[n2], e2[n2], t2);
}
function aT(e2, t2, n2, r2) {
  for (var i2 = 0; i2 < e2.length; i2++) {
    var a2 = e2[i2];
    r2 && (a2 = r2.project(a2)), a2 && isFinite(a2[0]) && isFinite(a2[1]) && (Jt(t2, t2, a2), Yt(n2, n2, a2));
  }
}
function oT(e2) {
  for (var t2 = 0, n2 = 0, r2 = 0, i2 = e2.length, a2 = e2[i2 - 1][0], o2 = e2[i2 - 1][1], s2 = 0; s2 < i2; s2++) {
    var c2 = e2[s2][0], l2 = e2[s2][1], u2 = a2 * l2 - c2 * o2;
    t2 += u2, n2 += (a2 + c2) * u2, r2 += (o2 + l2) * u2, a2 = c2, o2 = l2;
  }
  return t2 ? [n2 / t2 / 3, r2 / t2 / 3, t2] : [e2[0][0] || 0, e2[0][1] || 0];
}
var sT = (function() {
  function e2(e3) {
    this.name = e3;
  }
  return e2.prototype.setCenter = function(e3) {
    this._center = e3;
  }, e2.prototype.getCenter = function() {
    var e3 = this._center;
    return e3 || (e3 = this._center = this.calcCenter()), e3;
  }, e2;
})(), cT = /* @__PURE__ */ (function() {
  function e2(e3, t2) {
    this.type = `polygon`, this.exterior = e3, this.interiors = t2;
  }
  return e2;
})(), lT = /* @__PURE__ */ (function() {
  function e2(e3) {
    this.type = `linestring`, this.points = e3;
  }
  return e2;
})(), uT = (function(e2) {
  s(t2, e2);
  function t2(t3, n2, r2) {
    var i2 = e2.call(this, t3) || this;
    return i2.type = `geoJSON`, i2.geometries = n2, i2._center = r2 && [r2[0], r2[1]], i2;
  }
  return t2.prototype.calcCenter = function() {
    for (var e3 = this.geometries, t3, n2 = 0, r2 = 0; r2 < e3.length; r2++) {
      var i2 = e3[r2], a2 = i2.exterior, o2 = a2 && a2.length;
      o2 > n2 && (t3 = i2, n2 = o2);
    }
    if (t3) return oT(t3.exterior);
    var s2 = this.getBoundingRect();
    return [s2.x + s2.width / 2, s2.y + s2.height / 2];
  }, t2.prototype.getBoundingRect = function(e3) {
    var t3 = this._rect;
    if (t3 && !e3) return t3;
    var n2 = [1 / 0, 1 / 0], r2 = [-1 / 0, -1 / 0], i2 = this.geometries;
    return z(i2, function(t4) {
      t4.type === `polygon` ? aT(t4.exterior, n2, r2, e3) : z(t4.points, function(t5) {
        aT(t5, n2, r2, e3);
      });
    }), isFinite(n2[0]) && isFinite(n2[1]) && isFinite(r2[0]) && isFinite(r2[1]) || (n2[0] = n2[1] = r2[0] = r2[1] = 0), t3 = new X(n2[0], n2[1], r2[0] - n2[0], r2[1] - n2[1]), e3 || (this._rect = t3), t3;
  }, t2.prototype.contain = function(e3) {
    var t3 = this.getBoundingRect(), n2 = this.geometries;
    if (!t3.contain(e3[0], e3[1])) return false;
    loopGeo: for (var r2 = 0, i2 = n2.length; r2 < i2; r2++) {
      var a2 = n2[r2];
      if (a2.type === `polygon`) {
        var o2 = a2.exterior, s2 = a2.interiors;
        if (nT(o2, e3[0], e3[1])) {
          for (var c2 = 0; c2 < (s2 ? s2.length : 0); c2++) if (nT(s2[c2], e3[0], e3[1])) continue loopGeo;
          return true;
        }
      }
    }
    return false;
  }, t2.prototype.transformTo = function(e3, t3, n2, r2) {
    var i2 = this.getBoundingRect(), a2 = i2.width / i2.height;
    n2 ? r2 || (r2 = n2 / a2) : n2 = a2 * r2;
    for (var o2 = new X(e3, t3, n2, r2), s2 = i2.calculateTransform(o2), c2 = this.geometries, l2 = 0; l2 < c2.length; l2++) {
      var u2 = c2[l2];
      u2.type === `polygon` ? (iT(u2.exterior, s2), z(u2.interiors, function(e4) {
        iT(e4, s2);
      })) : z(u2.points, function(e4) {
        iT(e4, s2);
      });
    }
    i2 = this._rect, i2.copy(o2), this._center = [i2.x + i2.width / 2, i2.y + i2.height / 2];
  }, t2.prototype.cloneShallow = function(e3) {
    e3 ?? (e3 = this.name);
    var n2 = new t2(e3, this.geometries, this._center);
    return n2._rect = this._rect, n2.transformTo = null, n2;
  }, t2;
})(sT);
(function(e2) {
  s(t2, e2);
  function t2(t3, n2) {
    var r2 = e2.call(this, t3) || this;
    return r2.type = `geoSVG`, r2._elOnlyForCalculate = n2, r2;
  }
  return t2.prototype.calcCenter = function() {
    for (var e3 = this._elOnlyForCalculate, t3 = e3.getBoundingRect(), n2 = [t3.x + t3.width / 2, t3.y + t3.height / 2], r2 = An(rT), i2 = e3; i2 && !i2.isGeoSVGGraphicRoot; ) Mn(r2, i2.getLocalTransform(), r2), i2 = i2.parent;
    return In(r2, r2), qt(n2, n2, r2), n2;
  }, t2;
})(sT);
function dT(e2) {
  if (!e2.UTF8Encoding) return e2;
  var t2 = e2, n2 = t2.UTF8Scale;
  n2 ?? (n2 = 1024);
  var r2 = t2.features;
  return z(r2, function(e3) {
    var t3 = e3.geometry, r3 = t3.encodeOffsets, i2 = t3.coordinates;
    if (r3) switch (t3.type) {
      case `LineString`:
        t3.coordinates = pT(i2, r3, n2);
        break;
      case `Polygon`:
        fT(i2, r3, n2);
        break;
      case `MultiLineString`:
        fT(i2, r3, n2);
        break;
      case `MultiPolygon`:
        z(i2, function(e4, t4) {
          return fT(e4, r3[t4], n2);
        });
    }
  }), t2.UTF8Encoding = false, t2;
}
function fT(e2, t2, n2) {
  for (var r2 = 0; r2 < e2.length; r2++) e2[r2] = pT(e2[r2], t2[r2], n2);
}
function pT(e2, t2, n2) {
  for (var r2 = [], i2 = t2[0], a2 = t2[1], o2 = 0; o2 < e2.length; o2 += 2) {
    var s2 = e2.charCodeAt(o2) - 64, c2 = e2.charCodeAt(o2 + 1) - 64;
    s2 = s2 >> 1 ^ -(s2 & 1), c2 = c2 >> 1 ^ -(c2 & 1), s2 += i2, c2 += a2, i2 = s2, a2 = c2, r2.push([s2 / n2, c2 / n2]);
  }
  return r2;
}
function mT(e2, t2) {
  return e2 = dT(e2), B(Ke(e2.features, function(e3) {
    return e3.geometry && e3.properties && e3.geometry.coordinates.length > 0;
  }), function(e3) {
    var n2 = e3.properties, r2 = e3.geometry, i2 = [];
    switch (r2.type) {
      case `Polygon`:
        var a2 = r2.coordinates;
        i2.push(new cT(a2[0], a2.slice(1)));
        break;
      case `MultiPolygon`:
        z(r2.coordinates, function(e4) {
          e4[0] && i2.push(new cT(e4[0], e4.slice(1)));
        });
        break;
      case `LineString`:
        i2.push(new lT([r2.coordinates]));
        break;
      case `MultiLineString`:
        i2.push(new lT(r2.coordinates));
    }
    var o2 = new uT(n2[t2 || `name`], i2, n2.cp);
    return o2.properties = n2, o2;
  });
}
var hT = n({ MAX_SAFE_INTEGER: () => Zo, asc: () => Wo, getPercentWithPrecision: () => Jo, getPixelPrecision: () => qo, getPrecision: () => Go, getPrecisionSafe: () => Ko, isNumeric: () => cs, isRadianAroundZero: () => $o, linearMap: () => Vo, nice: () => is, numericToNumber: () => ss, parseDate: () => ts, quantile: () => as, quantity: () => ns, quantityExponent: () => rs, reformIntervals: () => os, remRadian: () => Qo, round: () => Uo }), gT = n({ format: () => Rm, parse: () => ts }), _T = n({ Arc: () => Pf, BezierCurve: () => Mf, BoundingRect: () => X, Circle: () => Zd, CompoundPath: () => Ff, Ellipse: () => $d, Group: () => So, Image: () => Jl, IncrementalDisplayable: () => Gf, Line: () => Of, LinearGradient: () => Lf, Polygon: () => Cf, Polyline: () => Tf, RadialGradient: () => Rf, Rect: () => nu, Ring: () => yf, Sector: () => _f, Text: () => ou, clipPointsByRect: () => Tp, clipRectByRect: () => Ep, createIcon: () => Dp, extendPath: () => cp, extendShape: () => op, getShapeClass: () => up, getTransform: () => yp, initProps: () => Xf, makeImage: () => fp, makePath: () => dp, mergePath: () => mp, registerShape: () => lp, resizePath: () => hp, updateProps: () => Yf }), vT = n({ addCommas: () => rh, capitalFirst: () => fh, encodeHTML: () => fn, formatTime: () => dh, formatTpl: () => lh, getTextRect: () => nh, getTooltipMarker: () => uh, normalizeCssArray: () => ah, toCamelCase: () => ih, truncateText: () => _c }), yT = n({ bind: () => Ye, clone: () => L, curry: () => Xe, defaults: () => ze, each: () => z, extend: () => R, filter: () => Ke, indexOf: () => Ve, inherits: () => He, isArray: () => H, isFunction: () => U, isObject: () => K, isString: () => W, map: () => B, merge: () => Le, reduce: () => Ge }), bT = Ls();
function xT(e2, t2) {
  var n2 = B(t2, function(t3) {
    return e2.scale.parse(t3);
  });
  return e2.type === `time` && n2.length > 0 && (n2.sort(), n2.unshift(n2[0]), n2.push(n2[n2.length - 1])), n2;
}
function ST(e2) {
  var t2 = e2.getLabelModel().get(`customValues`);
  if (t2) {
    var n2 = Iw(e2), r2 = e2.scale.getExtent();
    return { labels: B(Ke(xT(e2, t2), function(e3) {
      return e3 >= r2[0] && e3 <= r2[1];
    }), function(t3) {
      var r3 = { value: t3 };
      return { formattedLabel: n2(r3), rawLabel: e2.scale.getLabel(r3), tickValue: t3 };
    }) };
  }
  return e2.type === `category` ? wT(e2) : DT(e2);
}
function CT(e2, t2) {
  var n2 = e2.getTickModel().get(`customValues`);
  if (n2) {
    var r2 = e2.scale.getExtent();
    return { ticks: Ke(xT(e2, n2), function(e3) {
      return e3 >= r2[0] && e3 <= r2[1];
    }) };
  }
  return e2.type === `category` ? ET(e2, t2) : { ticks: B(e2.scale.getTicks(), function(e3) {
    return e3.value;
  }) };
}
function wT(e2) {
  var t2 = e2.getLabelModel(), n2 = TT(e2, t2);
  return !t2.get(`show`) || e2.scale.isBlank() ? { labels: [], labelCategoryInterval: n2.labelCategoryInterval } : n2;
}
function TT(e2, t2) {
  var n2 = OT(e2, `labels`), r2 = Bw(t2), i2 = kT(n2, r2);
  if (i2) return i2;
  var a2, o2;
  return U(r2) ? a2 = FT(e2, r2) : (o2 = r2 === `auto` ? jT(e2) : r2, a2 = PT(e2, o2)), AT(n2, r2, { labels: a2, labelCategoryInterval: o2 });
}
function ET(e2, t2) {
  var n2 = OT(e2, `ticks`), r2 = Bw(t2), i2 = kT(n2, r2);
  if (i2) return i2;
  var a2, o2;
  if ((!t2.get(`show`) || e2.scale.isBlank()) && (a2 = []), U(r2)) a2 = FT(e2, r2, true);
  else if (r2 === `auto`) {
    var s2 = TT(e2, e2.getLabelModel());
    o2 = s2.labelCategoryInterval, a2 = B(s2.labels, function(e3) {
      return e3.tickValue;
    });
  } else o2 = r2, a2 = PT(e2, o2, true);
  return AT(n2, r2, { ticks: a2, tickCategoryInterval: o2 });
}
function DT(e2) {
  var t2 = e2.scale.getTicks(), n2 = Iw(e2);
  return { labels: B(t2, function(t3, r2) {
    return { level: t3.level, formattedLabel: n2(t3, r2), rawLabel: e2.scale.getLabel(t3), tickValue: t3.value };
  }) };
}
function OT(e2, t2) {
  return bT(e2)[t2] || (bT(e2)[t2] = []);
}
function kT(e2, t2) {
  for (var n2 = 0; n2 < e2.length; n2++) if (e2[n2].key === t2) return e2[n2].value;
}
function AT(e2, t2, n2) {
  return e2.push({ key: t2, value: n2 }), n2;
}
function jT(e2) {
  return bT(e2).autoInterval ?? (bT(e2).autoInterval = e2.calculateCategoryInterval());
}
function MT(e2) {
  var t2 = NT(e2), n2 = Iw(e2), r2 = (t2.axisRotate - t2.labelRotate) / 180 * Math.PI, i2 = e2.scale, a2 = i2.getExtent(), o2 = i2.count();
  if (a2[1] - a2[0] < 1) return 0;
  var s2 = 1;
  o2 > 40 && (s2 = Math.max(1, Math.floor(o2 / 40)));
  for (var c2 = a2[0], l2 = e2.dataToCoord(c2 + 1) - e2.dataToCoord(c2), u2 = Math.abs(l2 * Math.cos(r2)), d2 = Math.abs(l2 * Math.sin(r2)), f2 = 0, p2 = 0; c2 <= a2[1]; c2 += s2) {
    var m2 = 0, h2 = 0, g2 = no(n2({ value: c2 }), t2.font, `center`, `top`);
    m2 = g2.width * 1.3, h2 = g2.height * 1.3, f2 = Math.max(f2, m2, 7), p2 = Math.max(p2, h2, 7);
  }
  var _2 = f2 / u2, v2 = p2 / d2;
  isNaN(_2) && (_2 = 1 / 0), isNaN(v2) && (v2 = 1 / 0);
  var y2 = Math.max(0, Math.floor(Math.min(_2, v2))), b2 = bT(e2.model), x2 = e2.getExtent(), S2 = b2.lastAutoInterval, C2 = b2.lastTickCount;
  return S2 != null && C2 != null && Math.abs(S2 - y2) <= 1 && Math.abs(C2 - o2) <= 1 && S2 > y2 && b2.axisExtent0 === x2[0] && b2.axisExtent1 === x2[1] ? y2 = S2 : (b2.lastTickCount = o2, b2.lastAutoInterval = y2, b2.axisExtent0 = x2[0], b2.axisExtent1 = x2[1]), y2;
}
function NT(e2) {
  var t2 = e2.getLabelModel();
  return { axisRotate: e2.getRotate ? e2.getRotate() : e2.isHorizontal && !e2.isHorizontal() ? 90 : 0, labelRotate: t2.get(`rotate`) || 0, font: t2.getFont() };
}
function PT(e2, t2, n2) {
  var r2 = Iw(e2), i2 = e2.scale, a2 = i2.getExtent(), o2 = e2.getLabelModel(), s2 = [], c2 = Math.max((t2 || 0) + 1, 1), l2 = a2[0], u2 = i2.count();
  l2 !== 0 && c2 > 1 && u2 / c2 > 2 && (l2 = Math.round(Math.ceil(l2 / c2) * c2));
  var d2 = Vw(e2), f2 = o2.get(`showMinLabel`) || d2, p2 = o2.get(`showMaxLabel`) || d2;
  f2 && l2 !== a2[0] && h2(a2[0]);
  for (var m2 = l2; m2 <= a2[1]; m2 += c2) h2(m2);
  p2 && m2 - c2 !== a2[1] && h2(a2[1]);
  function h2(e3) {
    var t3 = { value: e3 };
    s2.push(n2 ? e3 : { formattedLabel: r2(t3), rawLabel: i2.getLabel(t3), tickValue: e3 });
  }
  return s2;
}
function FT(e2, t2, n2) {
  var r2 = e2.scale, i2 = Iw(e2), a2 = [];
  return z(r2.getTicks(), function(e3) {
    var o2 = r2.getLabel(e3), s2 = e3.value;
    t2(e3.value, o2) && a2.push(n2 ? s2 : { formattedLabel: i2(e3), rawLabel: o2, tickValue: s2 });
  }), a2;
}
var IT = [0, 1], LT = (function() {
  function e2(e3, t2, n2) {
    this.onBand = false, this.inverse = false, this.dim = e3, this.scale = t2, this._extent = n2 || [0, 0];
  }
  return e2.prototype.contain = function(e3) {
    var t2 = this._extent, n2 = Math.min(t2[0], t2[1]), r2 = Math.max(t2[0], t2[1]);
    return e3 >= n2 && e3 <= r2;
  }, e2.prototype.containData = function(e3) {
    return this.scale.contain(e3);
  }, e2.prototype.getExtent = function() {
    return this._extent.slice();
  }, e2.prototype.getPixelPrecision = function(e3) {
    return qo(e3 || this.scale.getExtent(), this._extent);
  }, e2.prototype.setExtent = function(e3, t2) {
    var n2 = this._extent;
    n2[0] = e3, n2[1] = t2;
  }, e2.prototype.dataToCoord = function(e3, t2) {
    var n2 = this._extent, r2 = this.scale;
    return e3 = r2.normalize(e3), this.onBand && r2.type === `ordinal` && (n2 = n2.slice(), RT(n2, r2.count())), Vo(e3, IT, n2, t2);
  }, e2.prototype.coordToData = function(e3, t2) {
    var n2 = this._extent, r2 = this.scale;
    this.onBand && r2.type === `ordinal` && (n2 = n2.slice(), RT(n2, r2.count()));
    var i2 = Vo(e3, n2, IT, t2);
    return this.scale.scale(i2);
  }, e2.prototype.pointToData = function(e3, t2) {
  }, e2.prototype.getTicksCoords = function(e3) {
    e3 || (e3 = {});
    var t2 = e3.tickModel || this.getTickModel(), n2 = CT(this, t2).ticks, r2 = B(n2, function(e4) {
      return { coord: this.dataToCoord(this.scale.type === `ordinal` ? this.scale.getRawOrdinalNumber(e4) : e4), tickValue: e4 };
    }, this), i2 = t2.get(`alignWithLabel`);
    return zT(this, r2, i2, e3.clamp), r2;
  }, e2.prototype.getMinorTicksCoords = function() {
    if (this.scale.type === `ordinal`) return [];
    var e3 = this.model.getModel(`minorTick`).get(`splitNumber`);
    return e3 > 0 && e3 < 100 || (e3 = 5), B(this.scale.getMinorTicks(e3), function(e4) {
      return B(e4, function(e5) {
        return { coord: this.dataToCoord(e5), tickValue: e5 };
      }, this);
    }, this);
  }, e2.prototype.getViewLabels = function() {
    return ST(this).labels;
  }, e2.prototype.getLabelModel = function() {
    return this.model.getModel(`axisLabel`);
  }, e2.prototype.getTickModel = function() {
    return this.model.getModel(`axisTick`);
  }, e2.prototype.getBandWidth = function() {
    var e3 = this._extent, t2 = this.scale.getExtent(), n2 = t2[1] - t2[0] + +!!this.onBand;
    n2 === 0 && (n2 = 1);
    var r2 = Math.abs(e3[1] - e3[0]);
    return Math.abs(r2) / n2;
  }, e2.prototype.calculateCategoryInterval = function() {
    return MT(this);
  }, e2;
})();
function RT(e2, t2) {
  var n2 = (e2[1] - e2[0]) / t2 / 2;
  e2[0] += n2, e2[1] -= n2;
}
function zT(e2, t2, n2, r2) {
  var i2 = t2.length;
  if (!e2.onBand || n2 || !i2) return;
  var a2 = e2.getExtent(), o2, s2;
  if (i2 === 1) t2[0].coord = a2[0], o2 = t2[1] = { coord: a2[1], tickValue: t2[0].tickValue };
  else {
    var c2 = t2[i2 - 1].tickValue - t2[0].tickValue, l2 = (t2[i2 - 1].coord - t2[0].coord) / c2;
    z(t2, function(e3) {
      e3.coord -= l2 / 2;
    });
    var u2 = e2.scale.getExtent();
    s2 = 1 + u2[1] - t2[i2 - 1].tickValue, o2 = { coord: t2[i2 - 1].coord + l2 * s2, tickValue: u2[1] + 1 }, t2.push(o2);
  }
  var d2 = a2[0] > a2[1];
  f2(t2[0].coord, a2[0]) && (r2 ? t2[0].coord = a2[0] : t2.shift()), r2 && f2(a2[0], t2[0].coord) && t2.unshift({ coord: a2[0] }), f2(a2[1], o2.coord) && (r2 ? o2.coord = a2[1] : t2.pop()), r2 && f2(o2.coord, a2[1]) && t2.push({ coord: a2[1] });
  function f2(e3, t3) {
    return e3 = Uo(e3), t3 = Uo(t3), d2 ? e3 > t3 : e3 < t3;
  }
}
function BT(e2) {
  var t2 = $.extend(e2);
  return $.registerClass(t2), t2;
}
function VT(e2) {
  var t2 = Lv.extend(e2);
  return Lv.registerClass(t2), t2;
}
function HT(e2) {
  var t2 = Ov.extend(e2);
  return Ov.registerClass(t2), t2;
}
function UT(e2) {
  var t2 = Vv.extend(e2);
  return Vv.registerClass(t2), t2;
}
var WT = n({ Axis: () => LT, ChartView: () => Vv, ComponentModel: () => $, ComponentView: () => Lv, List: () => dC, Model: () => om, PRIORITY: () => hx, SeriesModel: () => Ov, color: () => Xr, connect: () => uS, dataTool: () => PS, dependencies: () => Qb, disConnect: () => fS, disconnect: () => dS, dispose: () => pS, env: () => I, extendChartView: () => UT, extendComponentModel: () => BT, extendComponentView: () => VT, extendSeriesModel: () => HT, format: () => vT, getCoordinateSystemDimensions: () => wS, getInstanceByDom: () => mS, getInstanceById: () => hS, getMap: () => MS, graphic: () => _T, helper: () => Gw, init: () => lS, innerDrawElementOnCanvas: () => Pb, matrix: () => On, number: () => hT, parseGeoJSON: () => mT, parseGeoJson: () => mT, registerAction: () => SS, registerCoordinateSystem: () => CS, registerLayout: () => TS, registerLoading: () => kS, registerLocale: () => bm, registerMap: () => jS, registerPostInit: () => yS, registerPostUpdate: () => bS, registerPreprocessor: () => _S, registerProcessor: () => vS, registerTheme: () => gS, registerTransform: () => NS, registerUpdateLifecycle: () => xS, registerVisual: () => ES, setCanvasCreator: () => AS, setPlatformAPI: () => xe, throttle: () => Xv, time: () => gT, use: () => $w, util: () => yT, vector: () => wt, version: () => Zb, zrUtil: () => Se, zrender: () => Co });
M();
var GT = (function(e2) {
  s(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2.hasSymbolVisual = true, n2;
  }
  return t2.prototype.getInitialData = function(e3) {
    return DC(null, this, { useEncodeDefaulter: true });
  }, t2.prototype.getLegendIcon = function(e3) {
    var t3 = new So(), n2 = Zy(`line`, 0, e3.itemHeight / 2, e3.itemWidth, 0, e3.lineStyle.stroke, false);
    t3.add(n2), n2.setStyle(e3.lineStyle);
    var r2 = this.getData().getVisual(`symbol`), i2 = this.getData().getVisual(`symbolRotate`), a2 = r2 === `none` ? `circle` : r2, o2 = e3.itemHeight * 0.8, s2 = Zy(a2, (e3.itemWidth - o2) / 2, (e3.itemHeight - o2) / 2, o2, o2, e3.itemStyle.fill);
    return t3.add(s2), s2.setStyle(e3.itemStyle), s2.rotation = (e3.iconRotate === `inherit` ? i2 : e3.iconRotate || 0) * Math.PI / 180, s2.setOrigin([e3.itemWidth / 2, e3.itemHeight / 2]), a2.indexOf(`empty`) > -1 && (s2.style.stroke = s2.style.fill, s2.style.fill = `#fff`, s2.style.lineWidth = 2), t3;
  }, t2.type = `series.line`, t2.dependencies = [`grid`, `polar`], t2.defaultOption = { z: 3, coordinateSystem: `cartesian2d`, legendHoverLink: true, clip: true, label: { position: `top` }, endLabel: { show: false, valueAnimation: true, distance: 8 }, lineStyle: { width: 2, type: `solid` }, emphasis: { scale: true }, step: false, smooth: false, smoothMonotone: null, symbol: `emptyCircle`, symbolSize: 4, symbolRotate: null, showSymbol: true, showAllSymbol: `auto`, connectNulls: false, sampling: `none`, animationEasing: `linear`, progressive: 0, hoverLayerThreshold: 1 / 0, universalTransition: { divideShape: `clone` }, triggerLineEvent: false }, t2;
})(Ov);
function KT(e2, t2) {
  var n2 = e2.mapDimensionsAll(`defaultedLabel`), r2 = n2.length;
  if (r2 === 1) {
    var i2 = x_(e2, t2, n2[0]);
    return i2 == null ? null : i2 + ``;
  }
  if (r2) {
    for (var a2 = [], o2 = 0; o2 < n2.length; o2++) a2.push(x_(e2, t2, n2[o2]));
    return a2.join(` `);
  }
}
function qT(e2, t2) {
  var n2 = e2.mapDimensionsAll(`defaultedLabel`);
  if (!H(t2)) return t2 + ``;
  for (var r2 = [], i2 = 0; i2 < n2.length; i2++) {
    var a2 = e2.getDimensionIndex(n2[i2]);
    a2 >= 0 && r2.push(t2[a2]);
  }
  return r2.join(` `);
}
M();
var JT = (function(e2) {
  s(t2, e2);
  function t2(t3, n2, r2, i2) {
    var a2 = e2.call(this) || this;
    return a2.updateData(t3, n2, r2, i2), a2;
  }
  return t2.prototype._createSymbol = function(e3, t3, n2, r2, i2) {
    this.removeAll();
    var a2 = Zy(e3, -1, -1, 2, 2, null, i2);
    a2.attr({ z2: 100, culling: true, scaleX: r2[0] / 2, scaleY: r2[1] / 2 }), a2.drift = YT, this._symbolType = e3, this.add(a2);
  }, t2.prototype.stopSymbolAnimation = function(e3) {
    this.childAt(0).stopAnimation(null, e3);
  }, t2.prototype.getSymbolType = function() {
    return this._symbolType;
  }, t2.prototype.getSymbolPath = function() {
    return this.childAt(0);
  }, t2.prototype.highlight = function() {
    Qu(this.childAt(0));
  }, t2.prototype.downplay = function() {
    $u(this.childAt(0));
  }, t2.prototype.setZ = function(e3, t3) {
    var n2 = this.childAt(0);
    n2.zlevel = e3, n2.z = t3;
  }, t2.prototype.setDraggable = function(e3, t3) {
    var n2 = this.childAt(0);
    n2.draggable = e3, n2.cursor = !t3 && e3 ? `move` : n2.cursor;
  }, t2.prototype.updateData = function(e3, n2, r2, i2) {
    this.silent = false;
    var a2 = e3.getItemVisual(n2, `symbol`) || `circle`, o2 = e3.hostModel, s2 = t2.getSymbolSize(e3, n2), c2 = a2 !== this._symbolType, l2 = i2 && i2.disableAnimation;
    if (c2) {
      var u2 = e3.getItemVisual(n2, `symbolKeepAspect`);
      this._createSymbol(a2, e3, n2, s2, u2);
    } else {
      var d2 = this.childAt(0);
      d2.silent = false;
      var f2 = { scaleX: s2[0] / 2, scaleY: s2[1] / 2 };
      l2 ? d2.attr(f2) : Yf(d2, f2, o2, n2), tp(d2);
    }
    if (this._updateCommon(e3, n2, s2, r2, i2), c2) {
      var d2 = this.childAt(0);
      if (!l2) {
        var f2 = { scaleX: this._sizeX, scaleY: this._sizeY, style: { opacity: d2.style.opacity } };
        d2.scaleX = d2.scaleY = 0, d2.style.opacity = 0, Xf(d2, f2, o2, n2);
      }
    }
    l2 && this.childAt(0).stopAnimation(`leave`);
  }, t2.prototype._updateCommon = function(e3, t3, n2, r2, i2) {
    var a2 = this.childAt(0), o2 = e3.hostModel, s2, c2, l2, u2, d2, f2, p2, m2, h2;
    if (r2 && (s2 = r2.emphasisItemStyle, c2 = r2.blurItemStyle, l2 = r2.selectItemStyle, u2 = r2.focus, d2 = r2.blurScope, p2 = r2.labelStatesModels, m2 = r2.hoverScale, h2 = r2.cursorStyle, f2 = r2.emphasisDisabled), !r2 || e3.hasItemOption) {
      var g2 = r2 && r2.itemModel ? r2.itemModel : e3.getItemModel(t3), _2 = g2.getModel(`emphasis`);
      s2 = _2.getModel(`itemStyle`).getItemStyle(), l2 = g2.getModel([`select`, `itemStyle`]).getItemStyle(), c2 = g2.getModel([`blur`, `itemStyle`]).getItemStyle(), u2 = _2.get(`focus`), d2 = _2.get(`blurScope`), f2 = _2.get(`disabled`), p2 = zp(g2), m2 = _2.getShallow(`scale`), h2 = g2.getShallow(`cursor`);
    }
    var v2 = e3.getItemVisual(t3, `symbolRotate`);
    a2.attr(`rotation`, (v2 || 0) * Math.PI / 180 || 0);
    var y2 = $y(e3.getItemVisual(t3, `symbolOffset`), n2);
    y2 && (a2.x = y2[0], a2.y = y2[1]), h2 && a2.attr(`cursor`, h2);
    var b2 = e3.getItemVisual(t3, `style`), x2 = b2.fill;
    if (a2 instanceof Jl) {
      var S2 = a2.style;
      a2.useStyle(R({ image: S2.image, x: S2.x, y: S2.y, width: S2.width, height: S2.height }, b2));
    } else a2.__isEmptyBrush ? a2.useStyle(R({}, b2)) : a2.useStyle(b2), a2.style.decal = null, a2.setColor(x2, i2 && i2.symbolInnerColor), a2.style.strokeNoScale = true;
    var C2 = e3.getItemVisual(t3, `liftZ`), w2 = this._z2;
    C2 == null ? w2 != null && (a2.z2 = w2, this._z2 = null) : w2 ?? (this._z2 = a2.z2, a2.z2 += C2);
    var T2 = i2 && i2.useNameLabel;
    Rp(a2, p2, { labelFetcher: o2, labelDataIndex: t3, defaultText: E2, inheritColor: x2, defaultOpacity: b2.opacity });
    function E2(t4) {
      return T2 ? e3.getName(t4) : KT(e3, t4);
    }
    this._sizeX = n2[0] / 2, this._sizeY = n2[1] / 2;
    var D2 = a2.ensureState(`emphasis`);
    D2.style = s2, a2.ensureState(`select`).style = l2, a2.ensureState(`blur`).style = c2;
    var O2 = m2 == null || m2 === true ? Math.max(1.1, 3 / this._sizeY) : isFinite(m2) && m2 > 0 ? +m2 : 1;
    D2.scaleX = this._sizeX * O2, D2.scaleY = this._sizeY * O2, this.setSymbolScale(1), _d(this, u2, d2, f2);
  }, t2.prototype.setSymbolScale = function(e3) {
    this.scaleX = this.scaleY = e3;
  }, t2.prototype.fadeOut = function(e3, t3, n2) {
    var r2 = this.childAt(0), i2 = bu(this).dataIndex, a2 = n2 && n2.animation;
    if (this.silent = r2.silent = true, n2 && n2.fadeLabel) {
      var o2 = r2.getTextContent();
      o2 && Qf(o2, { style: { opacity: 0 } }, t3, { dataIndex: i2, removeOpt: a2, cb: function() {
        r2.removeTextContent();
      } });
    } else r2.removeTextContent();
    Qf(r2, { style: { opacity: 0 }, scaleX: 0, scaleY: 0 }, t3, { dataIndex: i2, cb: e3, removeOpt: a2 });
  }, t2.getSymbolSize = function(e3, t3) {
    return Qy(e3.getItemVisual(t3, `symbolSize`));
  }, t2;
})(So);
function YT(e2, t2) {
  this.parent.drift(e2, t2);
}
function XT(e2, t2, n2, r2) {
  return t2 && !isNaN(t2[0]) && !isNaN(t2[1]) && !(r2.isIgnore && r2.isIgnore(n2)) && !(r2.clipShape && !r2.clipShape.contain(t2[0], t2[1])) && e2.getItemVisual(n2, `symbol`) !== `none`;
}
function ZT(e2) {
  return e2 != null && !K(e2) && (e2 = { isIgnore: e2 }), e2 || {};
}
function QT(e2) {
  var t2 = e2.hostModel, n2 = t2.getModel(`emphasis`);
  return { emphasisItemStyle: n2.getModel(`itemStyle`).getItemStyle(), blurItemStyle: t2.getModel([`blur`, `itemStyle`]).getItemStyle(), selectItemStyle: t2.getModel([`select`, `itemStyle`]).getItemStyle(), focus: n2.get(`focus`), blurScope: n2.get(`blurScope`), emphasisDisabled: n2.get(`disabled`), hoverScale: n2.get(`scale`), labelStatesModels: zp(t2), cursorStyle: t2.get(`cursor`) };
}
var $T = (function() {
  function e2(e3) {
    this.group = new So(), this._SymbolCtor = e3 || JT;
  }
  return e2.prototype.updateData = function(e3, t2) {
    this._progressiveEls = null, t2 = ZT(t2);
    var n2 = this.group, r2 = e3.hostModel, i2 = this._data, a2 = this._SymbolCtor, o2 = t2.disableAnimation, s2 = QT(e3), c2 = { disableAnimation: o2 }, l2 = t2.getSymbolPoint || function(t3) {
      return e3.getItemLayout(t3);
    };
    i2 || n2.removeAll(), e3.diff(i2).add(function(r3) {
      var i3 = l2(r3);
      if (XT(e3, i3, r3, t2)) {
        var o3 = new a2(e3, r3, s2, c2);
        o3.setPosition(i3), e3.setItemGraphicEl(r3, o3), n2.add(o3);
      }
    }).update(function(u2, d2) {
      var f2 = i2.getItemGraphicEl(d2), p2 = l2(u2);
      if (!XT(e3, p2, u2, t2)) {
        n2.remove(f2);
        return;
      }
      var m2 = e3.getItemVisual(u2, `symbol`) || `circle`, h2 = f2 && f2.getSymbolType && f2.getSymbolType();
      if (!f2 || h2 && h2 !== m2) n2.remove(f2), f2 = new a2(e3, u2, s2, c2), f2.setPosition(p2);
      else {
        f2.updateData(e3, u2, s2, c2);
        var g2 = { x: p2[0], y: p2[1] };
        o2 ? f2.attr(g2) : Yf(f2, g2, r2);
      }
      n2.add(f2), e3.setItemGraphicEl(u2, f2);
    }).remove(function(e4) {
      var t3 = i2.getItemGraphicEl(e4);
      t3 && t3.fadeOut(function() {
        n2.remove(t3);
      }, r2);
    }).execute(), this._getSymbolPoint = l2, this._data = e3;
  }, e2.prototype.updateLayout = function() {
    var e3 = this, t2 = this._data;
    t2 && t2.eachItemGraphicEl(function(t3, n2) {
      var r2 = e3._getSymbolPoint(n2);
      t3.setPosition(r2), t3.markRedraw();
    });
  }, e2.prototype.incrementalPrepareUpdate = function(e3) {
    this._seriesScope = QT(e3), this._data = null, this.group.removeAll();
  }, e2.prototype.incrementalUpdate = function(e3, t2, n2) {
    this._progressiveEls = [], n2 = ZT(n2);
    function r2(e4) {
      e4.isGroup || (e4.incremental = true, e4.ensureState(`emphasis`).hoverLayer = true);
    }
    for (var i2 = e3.start; i2 < e3.end; i2++) {
      var a2 = t2.getItemLayout(i2);
      if (XT(t2, a2, i2, n2)) {
        var o2 = new this._SymbolCtor(t2, i2, this._seriesScope);
        o2.traverse(r2), o2.setPosition(a2), this.group.add(o2), t2.setItemGraphicEl(i2, o2), this._progressiveEls.push(o2);
      }
    }
  }, e2.prototype.eachRendered = function(e3) {
    Pp(this._progressiveEls || this.group, e3);
  }, e2.prototype.remove = function(e3) {
    var t2 = this.group, n2 = this._data;
    n2 && e3 ? n2.eachItemGraphicEl(function(e4) {
      e4.fadeOut(function() {
        t2.remove(e4);
      }, n2.hostModel);
    }) : t2.removeAll();
  }, e2;
})();
function eE(e2, t2, n2) {
  var r2 = e2.getBaseAxis(), i2 = e2.getOtherAxis(r2), a2 = tE(i2, n2), o2 = r2.dim, s2 = i2.dim, c2 = t2.mapDimension(s2), l2 = t2.mapDimension(o2), u2 = +(s2 === `x` || s2 === `radius`), d2 = B(e2.dimensions, function(e3) {
    return t2.mapDimension(e3);
  }), f2 = false, p2 = t2.getCalculationInfo(`stackResultDimension`);
  return CC(t2, d2[0]) && (f2 = true, d2[0] = p2), CC(t2, d2[1]) && (f2 = true, d2[1] = p2), { dataDimsForPoint: d2, valueStart: a2, valueAxisDim: s2, baseAxisDim: o2, stacked: !!f2, valueDim: c2, baseDim: l2, baseDataOffset: u2, stackedOverDimension: t2.getCalculationInfo(`stackedOverDimension`) };
}
function tE(e2, t2) {
  var n2 = 0, r2 = e2.scale.getExtent();
  return t2 === `start` ? n2 = r2[0] : t2 === `end` ? n2 = r2[1] : G(t2) && !isNaN(t2) ? n2 = t2 : r2[0] > 0 ? n2 = r2[0] : r2[1] < 0 && (n2 = r2[1]), n2;
}
function nE(e2, t2, n2, r2) {
  var i2 = NaN;
  e2.stacked && (i2 = n2.get(n2.getCalculationInfo(`stackedOverDimension`), r2)), isNaN(i2) && (i2 = e2.valueStart);
  var a2 = e2.baseDataOffset, o2 = [];
  return o2[a2] = n2.get(e2.baseDim, r2), o2[1 - a2] = i2, t2.dataToPoint(o2);
}
function rE(e2, t2) {
  var n2 = [];
  return t2.diff(e2).add(function(e3) {
    n2.push({ cmd: `+`, idx: e3 });
  }).update(function(e3, t3) {
    n2.push({ cmd: `=`, idx: t3, idx1: e3 });
  }).remove(function(e3) {
    n2.push({ cmd: `-`, idx: e3 });
  }).execute(), n2;
}
function iE(e2, t2, n2, r2, i2, a2, o2, s2) {
  for (var c2 = rE(e2, t2), l2 = [], u2 = [], d2 = [], f2 = [], p2 = [], m2 = [], h2 = [], g2 = eE(i2, t2, o2), _2 = e2.getLayout(`points`) || [], v2 = t2.getLayout(`points`) || [], y2 = 0; y2 < c2.length; y2++) {
    var b2 = c2[y2], x2 = true, S2 = void 0, C2 = void 0;
    switch (b2.cmd) {
      case `=`:
        S2 = b2.idx * 2, C2 = b2.idx1 * 2;
        var w2 = _2[S2], T2 = _2[S2 + 1], E2 = v2[C2], D2 = v2[C2 + 1];
        (isNaN(w2) || isNaN(T2)) && (w2 = E2, T2 = D2), l2.push(w2, T2), u2.push(E2, D2), d2.push(n2[S2], n2[S2 + 1]), f2.push(r2[C2], r2[C2 + 1]), h2.push(t2.getRawIndex(b2.idx1));
        break;
      case `+`:
        var O2 = b2.idx, k2 = g2.dataDimsForPoint, A2 = i2.dataToPoint([t2.get(k2[0], O2), t2.get(k2[1], O2)]);
        C2 = O2 * 2, l2.push(A2[0], A2[1]), u2.push(v2[C2], v2[C2 + 1]);
        var j2 = nE(g2, i2, t2, O2);
        d2.push(j2[0], j2[1]), f2.push(r2[C2], r2[C2 + 1]), h2.push(t2.getRawIndex(O2));
        break;
      case `-`:
        x2 = false;
    }
    x2 && (p2.push(b2), m2.push(m2.length));
  }
  m2.sort(function(e3, t3) {
    return h2[e3] - h2[t3];
  });
  for (var ee2 = l2.length, M2 = JC(ee2), N2 = JC(ee2), te2 = JC(ee2), ne2 = JC(ee2), re2 = [], y2 = 0; y2 < m2.length; y2++) {
    var ie2 = m2[y2], ae2 = y2 * 2, oe2 = ie2 * 2;
    M2[ae2] = l2[oe2], M2[ae2 + 1] = l2[oe2 + 1], N2[ae2] = u2[oe2], N2[ae2 + 1] = u2[oe2 + 1], te2[ae2] = d2[oe2], te2[ae2 + 1] = d2[oe2 + 1], ne2[ae2] = f2[oe2], ne2[ae2 + 1] = f2[oe2 + 1], re2[y2] = p2[ie2];
  }
  return { current: M2, next: N2, stackedOnCurrent: te2, stackedOnNext: ne2, status: re2 };
}
M();
var aE = Math.min, oE = Math.max;
function sE(e2, t2) {
  return isNaN(e2) || isNaN(t2);
}
function cE(e2, t2, n2, r2, i2, a2, o2, s2, c2) {
  for (var l2, u2, d2, f2, p2, m2, h2 = n2, g2 = 0; g2 < r2; g2++) {
    var _2 = t2[h2 * 2], v2 = t2[h2 * 2 + 1];
    if (h2 >= i2 || h2 < 0) break;
    if (sE(_2, v2)) {
      if (c2) {
        h2 += a2;
        continue;
      }
      break;
    }
    if (h2 === n2) e2[a2 > 0 ? `moveTo` : `lineTo`](_2, v2), d2 = _2, f2 = v2;
    else {
      var y2 = _2 - l2, b2 = v2 - u2;
      if (y2 * y2 + b2 * b2 < 0.5) {
        h2 += a2;
        continue;
      }
      if (o2 > 0) {
        for (var x2 = h2 + a2, S2 = t2[x2 * 2], C2 = t2[x2 * 2 + 1]; S2 === _2 && C2 === v2 && g2 < r2; ) g2++, x2 += a2, h2 += a2, S2 = t2[x2 * 2], C2 = t2[x2 * 2 + 1], _2 = t2[h2 * 2], v2 = t2[h2 * 2 + 1], y2 = _2 - l2, b2 = v2 - u2;
        var w2 = g2 + 1;
        if (c2) for (; sE(S2, C2) && w2 < r2; ) w2++, x2 += a2, S2 = t2[x2 * 2], C2 = t2[x2 * 2 + 1];
        var T2 = 0.5, E2 = 0, D2 = 0, O2 = void 0, k2 = void 0;
        if (w2 >= r2 || sE(S2, C2)) p2 = _2, m2 = v2;
        else {
          E2 = S2 - l2, D2 = C2 - u2;
          var A2 = _2 - l2, j2 = S2 - _2, ee2 = v2 - u2, M2 = C2 - v2, N2 = void 0, te2 = void 0;
          if (s2 === `x`) {
            N2 = Math.abs(A2), te2 = Math.abs(j2);
            var ne2 = E2 > 0 ? 1 : -1;
            p2 = _2 - ne2 * N2 * o2, m2 = v2, O2 = _2 + ne2 * te2 * o2, k2 = v2;
          } else if (s2 === `y`) {
            N2 = Math.abs(ee2), te2 = Math.abs(M2);
            var re2 = D2 > 0 ? 1 : -1;
            p2 = _2, m2 = v2 - re2 * N2 * o2, O2 = _2, k2 = v2 + re2 * te2 * o2;
          } else N2 = Math.sqrt(A2 * A2 + ee2 * ee2), te2 = Math.sqrt(j2 * j2 + M2 * M2), T2 = te2 / (te2 + N2), p2 = _2 - E2 * o2 * (1 - T2), m2 = v2 - D2 * o2 * (1 - T2), O2 = _2 + E2 * o2 * T2, k2 = v2 + D2 * o2 * T2, O2 = aE(O2, oE(S2, _2)), k2 = aE(k2, oE(C2, v2)), O2 = oE(O2, aE(S2, _2)), k2 = oE(k2, aE(C2, v2)), E2 = O2 - _2, D2 = k2 - v2, p2 = _2 - E2 * N2 / te2, m2 = v2 - D2 * N2 / te2, p2 = aE(p2, oE(l2, _2)), m2 = aE(m2, oE(u2, v2)), p2 = oE(p2, aE(l2, _2)), m2 = oE(m2, aE(u2, v2)), E2 = _2 - p2, D2 = v2 - m2, O2 = _2 + E2 * te2 / N2, k2 = v2 + D2 * te2 / N2;
        }
        e2.bezierCurveTo(d2, f2, p2, m2, _2, v2), d2 = O2, f2 = k2;
      } else e2.lineTo(_2, v2);
    }
    l2 = _2, u2 = v2, h2 += a2;
  }
  return g2;
}
var lE = /* @__PURE__ */ (function() {
  function e2() {
    this.smooth = 0, this.smoothConstraint = true;
  }
  return e2;
})(), uE = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    var n2 = e2.call(this, t3) || this;
    return n2.type = `ec-polyline`, n2;
  }
  return t2.prototype.getDefaultStyle = function() {
    return { stroke: `#000`, fill: null };
  }, t2.prototype.getDefaultShape = function() {
    return new lE();
  }, t2.prototype.buildPath = function(e3, t3) {
    var n2 = t3.points, r2 = 0, i2 = n2.length / 2;
    if (t3.connectNulls) {
      for (; i2 > 0 && sE(n2[i2 * 2 - 2], n2[i2 * 2 - 1]); i2--) ;
      for (; r2 < i2 && sE(n2[r2 * 2], n2[r2 * 2 + 1]); r2++) ;
    }
    for (; r2 < i2; ) r2 += cE(e3, n2, r2, i2, i2, 1, t3.smooth, t3.smoothMonotone, t3.connectNulls) + 1;
  }, t2.prototype.getPointOn = function(e3, t3) {
    this.path || (this.createPathProxy(), this.buildPath(this.path, this.shape));
    for (var n2 = this.path.data, r2 = vl.CMD, i2, a2, o2 = t3 === `x`, s2 = [], c2 = 0; c2 < n2.length; ) {
      var l2 = n2[c2++], u2 = void 0, d2 = void 0, f2 = void 0, p2 = void 0, m2 = void 0, h2 = void 0, g2 = void 0;
      switch (l2) {
        case r2.M:
          i2 = n2[c2++], a2 = n2[c2++];
          break;
        case r2.L:
          if (u2 = n2[c2++], d2 = n2[c2++], g2 = o2 ? (e3 - i2) / (u2 - i2) : (e3 - a2) / (d2 - a2), g2 <= 1 && g2 >= 0) {
            var _2 = o2 ? (d2 - a2) * g2 + a2 : (u2 - i2) * g2 + i2;
            return o2 ? [e3, _2] : [_2, e3];
          }
          i2 = u2, a2 = d2;
          break;
        case r2.C:
          u2 = n2[c2++], d2 = n2[c2++], f2 = n2[c2++], p2 = n2[c2++], m2 = n2[c2++], h2 = n2[c2++];
          var v2 = o2 ? Mr(i2, u2, f2, m2, e3, s2) : Mr(a2, d2, p2, h2, e3, s2);
          if (v2 > 0) for (var y2 = 0; y2 < v2; y2++) {
            var b2 = s2[y2];
            if (b2 <= 1 && b2 >= 0) {
              var _2 = o2 ? Ar(a2, d2, p2, h2, b2) : Ar(i2, u2, f2, m2, b2);
              return o2 ? [e3, _2] : [_2, e3];
            }
          }
          i2 = m2, a2 = h2;
      }
    }
  }, t2;
})(Q), dE = (function(e2) {
  s(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2;
})(lE), fE = (function(e2) {
  s(t2, e2);
  function t2(t3) {
    var n2 = e2.call(this, t3) || this;
    return n2.type = `ec-polygon`, n2;
  }
  return t2.prototype.getDefaultShape = function() {
    return new dE();
  }, t2.prototype.buildPath = function(e3, t3) {
    var n2 = t3.points, r2 = t3.stackedOnPoints, i2 = 0, a2 = n2.length / 2, o2 = t3.smoothMonotone;
    if (t3.connectNulls) {
      for (; a2 > 0 && sE(n2[a2 * 2 - 2], n2[a2 * 2 - 1]); a2--) ;
      for (; i2 < a2 && sE(n2[i2 * 2], n2[i2 * 2 + 1]); i2++) ;
    }
    for (; i2 < a2; ) {
      var s2 = cE(e3, n2, i2, a2, a2, 1, t3.smooth, o2, t3.connectNulls);
      cE(e3, r2, i2 + s2 - 1, s2, a2, -1, t3.stackedOnSmooth, o2, t3.connectNulls), i2 += s2 + 1, e3.closePath();
    }
  }, t2;
})(Q);
function pE(e2, t2, n2, r2, i2) {
  var a2 = e2.getArea(), o2 = a2.x, s2 = a2.y, c2 = a2.width, l2 = a2.height, u2 = n2.get([`lineStyle`, `width`]) || 0;
  o2 -= u2 / 2, s2 -= u2 / 2, c2 += u2, l2 += u2, c2 = Math.ceil(c2), o2 !== Math.floor(o2) && (o2 = Math.floor(o2), c2++);
  var d2 = new nu({ shape: { x: o2, y: s2, width: c2, height: l2 } });
  if (t2) {
    var f2 = e2.getBaseAxis(), p2 = f2.isHorizontal(), m2 = f2.inverse;
    p2 ? (m2 && (d2.shape.x += c2), d2.shape.width = 0) : (m2 || (d2.shape.y += l2), d2.shape.height = 0);
    var h2 = U(i2) ? function(e3) {
      i2(e3, d2);
    } : null;
    Xf(d2, { shape: { width: c2, height: l2, x: o2, y: s2 } }, n2, null, r2, h2);
  }
  return d2;
}
function mE(e2, t2, n2) {
  var r2 = e2.getArea(), i2 = Uo(r2.r0, 1), a2 = Uo(r2.r, 1), o2 = new _f({ shape: { cx: Uo(e2.cx, 1), cy: Uo(e2.cy, 1), r0: i2, r: a2, startAngle: r2.startAngle, endAngle: r2.endAngle, clockwise: r2.clockwise } });
  return t2 && (e2.getBaseAxis().dim === `angle` ? o2.shape.endAngle = r2.startAngle : o2.shape.r = i2, Xf(o2, { shape: { endAngle: r2.endAngle, r: a2 } }, n2)), o2;
}
function hE(e2, t2) {
  return e2.type === t2;
}
M();
function gE(e2, t2) {
  if (e2.length === t2.length) {
    for (var n2 = 0; n2 < e2.length; n2++) if (e2[n2] !== t2[n2]) return;
    return true;
  }
}
function _E(e2) {
  for (var t2 = 1 / 0, n2 = 1 / 0, r2 = -1 / 0, i2 = -1 / 0, a2 = 0; a2 < e2.length; ) {
    var o2 = e2[a2++], s2 = e2[a2++];
    isNaN(o2) || (t2 = Math.min(o2, t2), r2 = Math.max(o2, r2)), isNaN(s2) || (n2 = Math.min(s2, n2), i2 = Math.max(s2, i2));
  }
  return [[t2, n2], [r2, i2]];
}
function vE(e2, t2) {
  var n2 = _E(e2), r2 = n2[0], i2 = n2[1], a2 = _E(t2), o2 = a2[0], s2 = a2[1];
  return Math.max(Math.abs(r2[0] - o2[0]), Math.abs(r2[1] - o2[1]), Math.abs(i2[0] - s2[0]), Math.abs(i2[1] - s2[1]));
}
function yE(e2) {
  return G(e2) ? e2 : e2 ? 0.5 : 0;
}
function bE(e2, t2, n2) {
  if (!n2.valueDim) return [];
  for (var r2 = t2.count(), i2 = JC(r2 * 2), a2 = 0; a2 < r2; a2++) {
    var o2 = nE(n2, e2, t2, a2);
    i2[a2 * 2] = o2[0], i2[a2 * 2 + 1] = o2[1];
  }
  return i2;
}
function xE(e2, t2, n2, r2, i2) {
  var a2 = n2.getBaseAxis(), o2 = a2.dim === `x` || a2.dim === `radius` ? 0 : 1, s2 = [], c2 = 0, l2 = [], u2 = [], d2 = [], f2 = [];
  if (i2) {
    for (c2 = 0; c2 < e2.length; c2 += 2) {
      var p2 = t2 || e2;
      !isNaN(p2[c2]) && !isNaN(p2[c2 + 1]) && f2.push(e2[c2], e2[c2 + 1]);
    }
    e2 = f2;
  }
  for (c2 = 0; c2 < e2.length - 2; c2 += 2) switch (d2[0] = e2[c2 + 2], d2[1] = e2[c2 + 3], u2[0] = e2[c2], u2[1] = e2[c2 + 1], s2.push(u2[0], u2[1]), r2) {
    case `end`:
      l2[o2] = d2[o2], l2[1 - o2] = u2[1 - o2], s2.push(l2[0], l2[1]);
      break;
    case `middle`:
      var m2 = (u2[o2] + d2[o2]) / 2, h2 = [];
      l2[o2] = h2[o2] = m2, l2[1 - o2] = u2[1 - o2], h2[1 - o2] = d2[1 - o2], s2.push(l2[0], l2[1]), s2.push(h2[0], h2[1]);
      break;
    default:
      l2[o2] = u2[o2], l2[1 - o2] = d2[1 - o2], s2.push(l2[0], l2[1]);
  }
  return s2.push(e2[c2++], e2[c2++]), s2;
}
function SE(e2, t2) {
  var n2 = [], r2 = e2.length, i2, a2;
  function o2(e3, t3, n3) {
    var r3 = e3.coord;
    return { coord: n3, color: _i((n3 - r3) / (t3.coord - r3), [e3.color, t3.color]) };
  }
  for (var s2 = 0; s2 < r2; s2++) {
    var c2 = e2[s2], l2 = c2.coord;
    if (l2 < 0) i2 = c2;
    else if (l2 > t2) {
      a2 ? n2.push(o2(a2, c2, t2)) : i2 && n2.push(o2(i2, c2, 0), o2(i2, c2, t2));
      break;
    } else i2 && (i2 = (n2.push(o2(i2, c2, 0)), null)), n2.push(c2), a2 = c2;
  }
  return n2;
}
function CE(e2, t2, n2) {
  var r2 = e2.getVisual(`visualMeta`);
  if (r2 && r2.length && e2.count() && t2.type === `cartesian2d`) {
    for (var i2, a2, o2 = r2.length - 1; o2 >= 0; o2--) {
      var s2 = e2.getDimensionInfo(r2[o2].dimension);
      if (i2 = s2 && s2.coordDim, i2 === `x` || i2 === `y`) {
        a2 = r2[o2];
        break;
      }
    }
    if (a2) {
      var c2 = t2.getAxis(i2), l2 = B(a2.stops, function(e3) {
        return { coord: c2.toGlobalCoord(c2.dataToCoord(e3.value)), color: e3.color };
      }), u2 = l2.length, d2 = a2.outerColors.slice();
      u2 && l2[0].coord > l2[u2 - 1].coord && (l2.reverse(), d2.reverse());
      var f2 = SE(l2, i2 === `x` ? n2.getWidth() : n2.getHeight()), p2 = f2.length;
      if (!p2 && u2) return l2[0].coord < 0 ? d2[1] ? d2[1] : l2[u2 - 1].color : d2[0] ? d2[0] : l2[0].color;
      var m2 = 10, h2 = f2[0].coord - m2, g2 = f2[p2 - 1].coord + m2, _2 = g2 - h2;
      if (_2 < 1e-3) return `transparent`;
      z(f2, function(e3) {
        e3.offset = (e3.coord - h2) / _2;
      }), f2.push({ offset: p2 ? f2[p2 - 1].offset : 0.5, color: d2[1] || `transparent` }), f2.unshift({ offset: p2 ? f2[0].offset : 0.5, color: d2[0] || `transparent` });
      var v2 = new Lf(0, 0, 0, 0, f2, true);
      return v2[i2] = h2, v2[i2 + `2`] = g2, v2;
    }
  }
}
function wE(e2, t2, n2) {
  var r2 = e2.get(`showAllSymbol`), i2 = r2 === `auto`;
  if (!r2 || i2) {
    var a2 = n2.getAxesByScale(`ordinal`)[0];
    if (a2 && !(i2 && TE(a2, t2))) {
      var o2 = t2.mapDimension(a2.dim), s2 = {};
      return z(a2.getViewLabels(), function(e3) {
        var t3 = a2.scale.getRawOrdinalNumber(e3.tickValue);
        s2[t3] = 1;
      }), function(e3) {
        return !s2.hasOwnProperty(t2.get(o2, e3));
      };
    }
  }
}
function TE(e2, t2) {
  var n2 = e2.getExtent(), r2 = Math.abs(n2[1] - n2[0]) / e2.scale.count();
  isNaN(r2) && (r2 = 0);
  for (var i2 = t2.count(), a2 = Math.max(1, Math.round(i2 / 5)), o2 = 0; o2 < i2; o2 += a2) if (JT.getSymbolSize(t2, o2)[+!!e2.isHorizontal()] * 1.5 > r2) return false;
  return true;
}
function EE(e2, t2) {
  return isNaN(e2) || isNaN(t2);
}
function DE(e2) {
  for (var t2 = e2.length / 2; t2 > 0 && EE(e2[t2 * 2 - 2], e2[t2 * 2 - 1]); t2--) ;
  return t2 - 1;
}
function OE(e2, t2) {
  return [e2[t2 * 2], e2[t2 * 2 + 1]];
}
function kE(e2, t2, n2) {
  for (var r2 = e2.length / 2, i2 = n2 === `x` ? 0 : 1, a2, o2, s2 = 0, c2 = -1, l2 = 0; l2 < r2; l2++) if (o2 = e2[l2 * 2 + i2], !(isNaN(o2) || isNaN(e2[l2 * 2 + 1 - i2]))) {
    if (l2 === 0) {
      a2 = o2;
      continue;
    }
    if (a2 <= t2 && o2 >= t2 || a2 >= t2 && o2 <= t2) {
      c2 = l2;
      break;
    }
    s2 = l2, a2 = o2;
  }
  return { range: [s2, c2], t: (t2 - a2) / (o2 - a2) };
}
function AE(e2) {
  if (e2.get([`endLabel`, `show`])) return true;
  for (var t2 = 0; t2 < Eu.length; t2++) if (e2.get([Eu[t2], `endLabel`, `show`])) return true;
  return false;
}
function jE(e2, t2, n2, r2) {
  if (hE(t2, `cartesian2d`)) {
    var i2 = r2.getModel(`endLabel`), a2 = i2.get(`valueAnimation`), o2 = r2.getData(), s2 = { lastFrameIndex: 0 }, c2 = AE(r2) ? function(n3, r3) {
      e2._endLabelOnDuring(n3, r3, o2, s2, a2, i2, t2);
    } : null, l2 = t2.getBaseAxis().isHorizontal(), u2 = pE(t2, n2, r2, function() {
      var t3 = e2._endLabel;
      t3 && n2 && s2.originalX != null && t3.attr({ x: s2.originalX, y: s2.originalY });
    }, c2);
    if (!r2.get(`clip`, true)) {
      var d2 = u2.shape, f2 = Math.max(d2.width, d2.height);
      l2 ? (d2.y -= f2, d2.height += f2 * 2) : (d2.x -= f2, d2.width += f2 * 2);
    }
    return c2 && c2(1, u2), u2;
  }
  return mE(t2, n2, r2);
}
function ME(e2, t2) {
  var n2 = t2.getBaseAxis(), r2 = n2.isHorizontal(), i2 = n2.inverse, a2 = r2 ? i2 ? `right` : `left` : `center`, o2 = r2 ? `middle` : i2 ? `top` : `bottom`;
  return { normal: { align: e2.get(`align`) || a2, verticalAlign: e2.get(`verticalAlign`) || o2 } };
}
var NE = (function(e2) {
  s(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.init = function() {
    var e3 = new So(), t3 = new $T();
    this.group.add(t3.group), this._symbolDraw = t3, this._lineGroup = e3, this._changePolyState = Ye(this._changePolyState, this);
  }, t2.prototype.render = function(e3, t3, n2) {
    var r2 = e3.coordinateSystem, i2 = this.group, a2 = e3.getData(), o2 = e3.getModel(`lineStyle`), s2 = e3.getModel(`areaStyle`), c2 = a2.getLayout(`points`) || [], l2 = r2.type === `polar`, u2 = this._coordSys, d2 = this._symbolDraw, f2 = this._polyline, p2 = this._polygon, m2 = this._lineGroup, h2 = !t3.ssr && e3.get(`animation`), g2 = !s2.isEmpty(), _2 = s2.get(`origin`), v2 = eE(r2, a2, _2), y2 = g2 && bE(r2, a2, v2), b2 = e3.get(`showSymbol`), x2 = e3.get(`connectNulls`), S2 = b2 && !l2 && wE(e3, a2, r2), C2 = this._data;
    C2 && C2.eachItemGraphicEl(function(e4, t4) {
      e4.__temp && (i2.remove(e4), C2.setItemGraphicEl(t4, null));
    }), b2 || d2.remove(), i2.add(m2);
    var w2 = !l2 && e3.get(`step`), T2;
    r2 && r2.getArea && e3.get(`clip`, true) && (T2 = r2.getArea(), T2.width == null ? T2.r0 && (T2.r0 -= 0.5, T2.r += 0.5) : (T2.x -= 0.1, T2.y -= 0.1, T2.width += 0.2, T2.height += 0.2)), this._clipShapeForSymbol = T2;
    var E2 = CE(a2, r2, n2) || a2.getVisual(`style`)[a2.getVisual(`drawType`)];
    if (!(f2 && u2.type === r2.type && w2 === this._step)) b2 && d2.updateData(a2, { isIgnore: S2, clipShape: T2, disableAnimation: true, getSymbolPoint: function(e4) {
      return [c2[e4 * 2], c2[e4 * 2 + 1]];
    } }), h2 && this._initSymbolLabelAnimation(a2, r2, T2), w2 && (y2 && (y2 = xE(y2, c2, r2, w2, x2)), c2 = xE(c2, null, r2, w2, x2)), f2 = this._newPolyline(c2), g2 ? p2 = this._newPolygon(c2, y2) : p2 && (p2 = (m2.remove(p2), this._polygon = null)), l2 || this._initOrUpdateEndLabel(e3, r2, ph(E2)), m2.setClipPath(jE(this, r2, true, e3));
    else {
      g2 && !p2 ? p2 = this._newPolygon(c2, y2) : p2 && !g2 && (m2.remove(p2), p2 = this._polygon = null), l2 || this._initOrUpdateEndLabel(e3, r2, ph(E2));
      var D2 = m2.getClipPath();
      D2 ? Xf(D2, { shape: jE(this, r2, false, e3).shape }, e3) : m2.setClipPath(jE(this, r2, true, e3)), b2 && d2.updateData(a2, { isIgnore: S2, clipShape: T2, disableAnimation: true, getSymbolPoint: function(e4) {
        return [c2[e4 * 2], c2[e4 * 2 + 1]];
      } }), (!gE(this._stackedOnPoints, y2) || !gE(this._points, c2)) && (h2 ? this._doUpdateAnimation(a2, y2, r2, n2, w2, _2, x2) : (w2 && (y2 && (y2 = xE(y2, c2, r2, w2, x2)), c2 = xE(c2, null, r2, w2, x2)), f2.setShape({ points: c2 }), p2 && p2.setShape({ points: c2, stackedOnPoints: y2 })));
    }
    var O2 = e3.getModel(`emphasis`), k2 = O2.get(`focus`), A2 = O2.get(`blurScope`), j2 = O2.get(`disabled`);
    if (f2.useStyle(ze(o2.getLineStyle(), { fill: `none`, stroke: E2, lineJoin: `bevel` })), xd(f2, e3, `lineStyle`), f2.style.lineWidth > 0 && e3.get([`emphasis`, `lineStyle`, `width`]) === `bolder`) {
      var ee2 = f2.getState(`emphasis`).style;
      ee2.lineWidth = +f2.style.lineWidth + 1;
    }
    bu(f2).seriesIndex = e3.seriesIndex, _d(f2, k2, A2, j2);
    var M2 = yE(e3.get(`smooth`)), N2 = e3.get(`smoothMonotone`);
    if (f2.setShape({ smooth: M2, smoothMonotone: N2, connectNulls: x2 }), p2) {
      var te2 = a2.getCalculationInfo(`stackedOnSeries`), ne2 = 0;
      p2.useStyle(ze(s2.getAreaStyle(), { fill: E2, opacity: 0.7, lineJoin: `bevel`, decal: a2.getVisual(`style`).decal })), te2 && (ne2 = yE(te2.get(`smooth`))), p2.setShape({ smooth: M2, stackedOnSmooth: ne2, smoothMonotone: N2, connectNulls: x2 }), xd(p2, e3, `areaStyle`), bu(p2).seriesIndex = e3.seriesIndex, _d(p2, k2, A2, j2);
    }
    var re2 = this._changePolyState;
    a2.eachItemGraphicEl(function(e4) {
      e4 && (e4.onHoverStateChange = re2);
    }), this._polyline.onHoverStateChange = re2, this._data = a2, this._coordSys = r2, this._stackedOnPoints = y2, this._points = c2, this._step = w2, this._valueOrigin = _2, e3.get(`triggerLineEvent`) && (this.packEventData(e3, f2), p2 && this.packEventData(e3, p2));
  }, t2.prototype.packEventData = function(e3, t3) {
    bu(t3).eventData = { componentType: `series`, componentSubType: `line`, componentIndex: e3.componentIndex, seriesIndex: e3.seriesIndex, seriesName: e3.name, seriesType: `line` };
  }, t2.prototype.highlight = function(e3, t3, n2, r2) {
    var i2 = e3.getData(), a2 = Is(i2, r2);
    if (this._changePolyState(`emphasis`), !(a2 instanceof Array) && a2 != null && a2 >= 0) {
      var o2 = i2.getLayout(`points`), s2 = i2.getItemGraphicEl(a2);
      if (!s2) {
        var c2 = o2[a2 * 2], l2 = o2[a2 * 2 + 1];
        if (isNaN(c2) || isNaN(l2) || this._clipShapeForSymbol && !this._clipShapeForSymbol.contain(c2, l2)) return;
        var u2 = e3.get(`zlevel`) || 0, d2 = e3.get(`z`) || 0;
        s2 = new JT(i2, a2), s2.x = c2, s2.y = l2, s2.setZ(u2, d2);
        var f2 = s2.getSymbolPath().getTextContent();
        f2 && (f2.zlevel = u2, f2.z = d2, f2.z2 = this._polyline.z2 + 1), s2.__temp = true, i2.setItemGraphicEl(a2, s2), s2.stopSymbolAnimation(true), this.group.add(s2);
      }
      s2.highlight();
    } else Vv.prototype.highlight.call(this, e3, t3, n2, r2);
  }, t2.prototype.downplay = function(e3, t3, n2, r2) {
    var i2 = e3.getData(), a2 = Is(i2, r2);
    if (this._changePolyState(`normal`), a2 != null && a2 >= 0) {
      var o2 = i2.getItemGraphicEl(a2);
      o2 && (o2.__temp ? (i2.setItemGraphicEl(a2, null), this.group.remove(o2)) : o2.downplay());
    } else Vv.prototype.downplay.call(this, e3, t3, n2, r2);
  }, t2.prototype._changePolyState = function(e3) {
    var t3 = this._polygon;
    Uu(this._polyline, e3), t3 && Uu(t3, e3);
  }, t2.prototype._newPolyline = function(e3) {
    var t3 = this._polyline;
    return t3 && this._lineGroup.remove(t3), t3 = new uE({ shape: { points: e3 }, segmentIgnoreThreshold: 2, z2: 10 }), this._lineGroup.add(t3), this._polyline = t3, t3;
  }, t2.prototype._newPolygon = function(e3, t3) {
    var n2 = this._polygon;
    return n2 && this._lineGroup.remove(n2), n2 = new fE({ shape: { points: e3, stackedOnPoints: t3 }, segmentIgnoreThreshold: 2 }), this._lineGroup.add(n2), this._polygon = n2, n2;
  }, t2.prototype._initSymbolLabelAnimation = function(e3, t3, n2) {
    var r2, i2, a2 = t3.getBaseAxis(), o2 = a2.inverse;
    t3.type === `cartesian2d` ? (r2 = a2.isHorizontal(), i2 = false) : t3.type === `polar` && (r2 = a2.dim === `angle`, i2 = true);
    var s2 = e3.hostModel, c2 = s2.get(`animationDuration`);
    U(c2) && (c2 = c2(null));
    var l2 = s2.get(`animationDelay`) || 0, u2 = U(l2) ? l2(null) : l2;
    e3.eachItemGraphicEl(function(e4, a3) {
      var s3 = e4;
      if (s3) {
        var d2 = [e4.x, e4.y], f2 = void 0, p2 = void 0, m2 = void 0;
        if (n2) {
          if (i2) {
            var h2 = n2, g2 = t3.pointToCoord(d2);
            r2 ? (f2 = h2.startAngle, p2 = h2.endAngle, m2 = -g2[1] / 180 * Math.PI) : (f2 = h2.r0, p2 = h2.r, m2 = g2[0]);
          } else {
            var _2 = n2;
            r2 ? (f2 = _2.x, p2 = _2.x + _2.width, m2 = e4.x) : (f2 = _2.y + _2.height, p2 = _2.y, m2 = e4.y);
          }
        }
        var v2 = p2 === f2 ? 0 : (m2 - f2) / (p2 - f2);
        o2 && (v2 = 1 - v2);
        var y2 = U(l2) ? l2(a3) : c2 * v2 + u2, b2 = s3.getSymbolPath(), x2 = b2.getTextContent();
        s3.attr({ scaleX: 0, scaleY: 0 }), s3.animateTo({ scaleX: 1, scaleY: 1 }, { duration: 200, setToFinal: true, delay: y2 }), x2 && x2.animateFrom({ style: { opacity: 0 } }, { duration: 300, delay: y2 }), b2.disableLabelAnimation = true;
      }
    });
  }, t2.prototype._initOrUpdateEndLabel = function(e3, t3, n2) {
    var r2 = e3.getModel(`endLabel`);
    if (AE(e3)) {
      var i2 = e3.getData(), a2 = this._polyline, o2 = i2.getLayout(`points`);
      if (!o2) {
        a2.removeTextContent(), this._endLabel = null;
        return;
      }
      var s2 = this._endLabel;
      s2 || (s2 = this._endLabel = new ou({ z2: 200 }), s2.ignoreClip = true, a2.setTextContent(this._endLabel), a2.disableLabelAnimation = true);
      var c2 = DE(o2);
      c2 >= 0 && (Rp(a2, zp(e3, `endLabel`), { inheritColor: n2, labelFetcher: e3, labelDataIndex: c2, defaultText: function(e4, t4, n3) {
        return n3 == null ? KT(i2, e4) : qT(i2, n3);
      }, enableTextSetter: true }, ME(r2, t3)), a2.textConfig.position = null);
    } else this._endLabel && (this._endLabel = (this._polyline.removeTextContent(), null));
  }, t2.prototype._endLabelOnDuring = function(e3, t3, n2, r2, i2, a2, o2) {
    var s2 = this._endLabel, c2 = this._polyline;
    if (s2) {
      e3 < 1 && r2.originalX == null && (r2.originalX = s2.x, r2.originalY = s2.y);
      var l2 = n2.getLayout(`points`), u2 = n2.hostModel, d2 = u2.get(`connectNulls`), f2 = a2.get(`precision`), p2 = a2.get(`distance`) || 0, m2 = o2.getBaseAxis(), h2 = m2.isHorizontal(), g2 = m2.inverse, _2 = t3.shape, v2 = g2 ? h2 ? _2.x : _2.y + _2.height : h2 ? _2.x + _2.width : _2.y, y2 = (h2 ? p2 : 0) * (g2 ? -1 : 1), b2 = (h2 ? 0 : -p2) * (g2 ? -1 : 1), x2 = h2 ? `x` : `y`, S2 = kE(l2, v2, x2), C2 = S2.range, w2 = C2[1] - C2[0], T2 = void 0;
      if (w2 >= 1) {
        if (w2 > 1 && !d2) {
          var E2 = OE(l2, C2[0]);
          s2.attr({ x: E2[0] + y2, y: E2[1] + b2 }), i2 && (T2 = u2.getRawValue(C2[0]));
        } else {
          var E2 = c2.getPointOn(v2, x2);
          E2 && s2.attr({ x: E2[0] + y2, y: E2[1] + b2 });
          var D2 = u2.getRawValue(C2[0]), O2 = u2.getRawValue(C2[1]);
          i2 && (T2 = qs(n2, f2, D2, O2, S2.t));
        }
        r2.lastFrameIndex = C2[0];
      } else {
        var k2 = e3 === 1 || r2.lastFrameIndex > 0 ? C2[0] : 0, E2 = OE(l2, k2);
        i2 && (T2 = u2.getRawValue(k2)), s2.attr({ x: E2[0] + y2, y: E2[1] + b2 });
      }
      if (i2) {
        var A2 = Yp(s2);
        typeof A2.setLabelText == `function` && A2.setLabelText(T2);
      }
    }
  }, t2.prototype._doUpdateAnimation = function(e3, t3, n2, r2, i2, a2, o2) {
    var s2 = this._polyline, c2 = this._polygon, l2 = e3.hostModel, u2 = iE(this._data, e3, this._stackedOnPoints, t3, this._coordSys, n2, this._valueOrigin, a2), d2 = u2.current, f2 = u2.stackedOnCurrent, p2 = u2.next, m2 = u2.stackedOnNext;
    if (i2 && (f2 = xE(u2.stackedOnCurrent, u2.current, n2, i2, o2), d2 = xE(u2.current, null, n2, i2, o2), m2 = xE(u2.stackedOnNext, u2.next, n2, i2, o2), p2 = xE(u2.next, null, n2, i2, o2)), vE(d2, p2) > 3e3 || c2 && vE(f2, m2) > 3e3) {
      s2.stopAnimation(), s2.setShape({ points: p2 }), c2 && (c2.stopAnimation(), c2.setShape({ points: p2, stackedOnPoints: m2 }));
      return;
    }
    s2.shape.__points = u2.current, s2.shape.points = d2;
    var h2 = { shape: { points: p2 } };
    u2.current !== d2 && (h2.shape.__points = u2.next), s2.stopAnimation(), Yf(s2, h2, l2), c2 && (c2.setShape({ points: d2, stackedOnPoints: f2 }), c2.stopAnimation(), Yf(c2, { shape: { stackedOnPoints: m2 } }, l2), s2.shape.points !== c2.shape.points && (c2.shape.points = s2.shape.points));
    for (var g2 = [], _2 = u2.status, v2 = 0; v2 < _2.length; v2++) if (_2[v2].cmd === `=`) {
      var y2 = e3.getItemGraphicEl(_2[v2].idx1);
      y2 && g2.push({ el: y2, ptIdx: v2 });
    }
    s2.animators && s2.animators.length && s2.animators[0].during(function() {
      c2 && c2.dirtyShape();
      for (var e4 = s2.shape.__points, t4 = 0; t4 < g2.length; t4++) {
        var n3 = g2[t4].el, r3 = g2[t4].ptIdx * 2;
        n3.x = e4[r3], n3.y = e4[r3 + 1], n3.markRedraw();
      }
    });
  }, t2.prototype.remove = function(e3) {
    var t3 = this.group, n2 = this._data;
    this._lineGroup.removeAll(), this._symbolDraw.remove(true), n2 && n2.eachItemGraphicEl(function(e4, r2) {
      e4.__temp && (t3.remove(e4), n2.setItemGraphicEl(r2, null));
    }), this._polyline = this._polygon = this._coordSys = this._points = this._stackedOnPoints = this._endLabel = this._data = null;
  }, t2.type = `line`, t2;
})(Vv);
function PE(e2, t2) {
  return { seriesType: e2, plan: Rv(), reset: function(e3) {
    var n2 = e3.getData(), r2 = e3.coordinateSystem, i2 = e3.pipelineContext, a2 = t2 || i2.large;
    if (r2) {
      var o2 = B(r2.dimensions, function(e4) {
        return n2.mapDimension(e4);
      }).slice(0, 2), s2 = o2.length, c2 = n2.getCalculationInfo(`stackResultDimension`);
      CC(n2, o2[0]) && (o2[0] = c2), CC(n2, o2[1]) && (o2[1] = c2);
      var l2 = n2.getStore(), u2 = n2.getDimensionIndex(o2[0]), d2 = n2.getDimensionIndex(o2[1]);
      return s2 && { progress: function(e4, t3) {
        for (var n3 = e4.end - e4.start, i3 = a2 && JC(n3 * s2), o3 = [], c3 = [], f2 = e4.start, p2 = 0; f2 < e4.end; f2++) {
          var m2 = void 0;
          if (s2 === 1) {
            var h2 = l2.get(u2, f2);
            m2 = r2.dataToPoint(h2, null, c3);
          } else o3[0] = l2.get(u2, f2), o3[1] = l2.get(d2, f2), m2 = r2.dataToPoint(o3, null, c3);
          a2 ? (i3[p2++] = m2[0], i3[p2++] = m2[1]) : t3.setItemLayout(f2, m2.slice());
        }
        a2 && t3.setLayout(`points`, i3);
      } };
    }
  } };
}
var FE = { average: function(e2) {
  for (var t2 = 0, n2 = 0, r2 = 0; r2 < e2.length; r2++) isNaN(e2[r2]) || (t2 += e2[r2], n2++);
  return n2 === 0 ? NaN : t2 / n2;
}, sum: function(e2) {
  for (var t2 = 0, n2 = 0; n2 < e2.length; n2++) t2 += e2[n2] || 0;
  return t2;
}, max: function(e2) {
  for (var t2 = -1 / 0, n2 = 0; n2 < e2.length; n2++) e2[n2] > t2 && (t2 = e2[n2]);
  return isFinite(t2) ? t2 : NaN;
}, min: function(e2) {
  for (var t2 = 1 / 0, n2 = 0; n2 < e2.length; n2++) e2[n2] < t2 && (t2 = e2[n2]);
  return isFinite(t2) ? t2 : NaN;
}, nearest: function(e2) {
  return e2[0];
} }, IE = function(e2) {
  return Math.round(e2.length / 2);
};
function LE(e2) {
  return { seriesType: e2, reset: function(e3, t2, n2) {
    var r2 = e3.getData(), i2 = e3.get(`sampling`), a2 = e3.coordinateSystem, o2 = r2.count();
    if (o2 > 10 && a2.type === `cartesian2d` && i2) {
      var s2 = a2.getBaseAxis(), c2 = a2.getOtherAxis(s2), l2 = s2.getExtent(), u2 = n2.getDevicePixelRatio(), d2 = Math.abs(l2[1] - l2[0]) * (u2 || 1), f2 = Math.round(o2 / d2);
      if (isFinite(f2) && f2 > 1) {
        i2 === `lttb` ? e3.setData(r2.lttbDownSample(r2.mapDimension(c2.dim), 1 / f2)) : i2 === `minmax` && e3.setData(r2.minmaxDownSample(r2.mapDimension(c2.dim), 1 / f2));
        var p2 = void 0;
        W(i2) ? p2 = FE[i2] : U(i2) && (p2 = i2), p2 && e3.setData(r2.downSample(r2.mapDimension(c2.dim), 1 / f2, p2, IE));
      }
    }
  } };
}
function RE(e2) {
  e2.registerChartView(NE), e2.registerSeriesModel(GT), e2.registerLayout(PE(`line`, true)), e2.registerVisual({ seriesType: `line`, reset: function(e3) {
    var t2 = e3.getData(), n2 = e3.getModel(`lineStyle`).getLineStyle();
    n2 && !n2.stroke && (n2.stroke = t2.getVisual(`style`).fill), t2.setVisual(`legendLineStyle`, n2);
  } }), e2.registerProcessor(e2.PRIORITY.PROCESSOR.STATISTIC, LE(`line`));
}
M();
var zE = (function(e2) {
  s(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2.layoutMode = `box`, n2;
  }
  return t2.prototype.init = function(e3, t3, n2) {
    this.mergeDefaultAndTheme(e3, n2), this._initData();
  }, t2.prototype.mergeOption = function(t3) {
    e2.prototype.mergeOption.apply(this, arguments), this._initData();
  }, t2.prototype.setCurrentIndex = function(e3) {
    e3 ?? (e3 = this.option.currentIndex);
    var t3 = this._data.count();
    this.option.loop ? e3 = (e3 % t3 + t3) % t3 : (e3 >= t3 && (e3 = t3 - 1), e3 < 0 && (e3 = 0)), this.option.currentIndex = e3;
  }, t2.prototype.getCurrentIndex = function() {
    return this.option.currentIndex;
  }, t2.prototype.isIndexMax = function() {
    return this.getCurrentIndex() >= this._data.count() - 1;
  }, t2.prototype.setPlayState = function(e3) {
    this.option.autoPlay = !!e3;
  }, t2.prototype.getPlayState = function() {
    return !!this.option.autoPlay;
  }, t2.prototype._initData = function() {
    var e3 = this.option, t3 = e3.data || [], n2 = e3.axisType, r2 = this._names = [], i2;
    n2 === `category` ? (i2 = [], z(t3, function(e4, t4) {
      var n3 = As(ys(e4), ``), a3;
      K(e4) ? (a3 = L(e4), a3.value = t4) : a3 = t4, i2.push(a3), r2.push(n3);
    })) : i2 = t3;
    var a2 = { category: `ordinal`, time: `time`, value: `number` }[n2] || `number`;
    (this._data = new dC([{ name: `value`, type: a2 }], this)).initData(i2, r2);
  }, t2.prototype.getData = function() {
    return this._data;
  }, t2.prototype.getCategories = function() {
    if (this.get(`axisType`) === `category`) return this._names.slice();
  }, t2.type = `timeline`, t2.defaultOption = { z: 4, show: true, axisType: `time`, realtime: true, left: `20%`, top: null, right: `20%`, bottom: 0, width: null, height: 40, padding: 5, controlPosition: `left`, autoPlay: false, rewind: false, loop: true, playInterval: 2e3, currentIndex: 0, itemStyle: {}, label: { color: `#000` }, data: [] }, t2;
})($);
M();
var BE = (function(e2) {
  s(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.type = `timeline.slider`, t2.defaultOption = dm(zE.defaultOption, { backgroundColor: `rgba(0,0,0,0)`, borderColor: `#ccc`, borderWidth: 0, orient: `horizontal`, inverse: false, tooltip: { trigger: `item` }, symbol: `circle`, symbolSize: 12, lineStyle: { show: true, width: 2, color: `#DAE1F5` }, label: { position: `auto`, show: true, interval: `auto`, rotate: 0, color: `#A4B1D7` }, itemStyle: { color: `#A4B1D7`, borderWidth: 1 }, checkpointStyle: { symbol: `circle`, symbolSize: 15, color: `#316bf3`, borderColor: `#fff`, borderWidth: 2, shadowBlur: 2, shadowOffsetX: 1, shadowOffsetY: 1, shadowColor: `rgba(0, 0, 0, 0.3)`, animation: true, animationDuration: 300, animationEasing: `quinticInOut` }, controlStyle: { show: true, showPlayBtn: true, showPrevBtn: true, showNextBtn: true, itemSize: 24, itemGap: 12, position: `left`, playIcon: `path://M31.6,53C17.5,53,6,41.5,6,27.4S17.5,1.8,31.6,1.8C45.7,1.8,57.2,13.3,57.2,27.4S45.7,53,31.6,53z M31.6,3.3 C18.4,3.3,7.5,14.1,7.5,27.4c0,13.3,10.8,24.1,24.1,24.1C44.9,51.5,55.7,40.7,55.7,27.4C55.7,14.1,44.9,3.3,31.6,3.3z M24.9,21.3 c0-2.2,1.6-3.1,3.5-2l10.5,6.1c1.899,1.1,1.899,2.9,0,4l-10.5,6.1c-1.9,1.1-3.5,0.2-3.5-2V21.3z`, stopIcon: `path://M30.9,53.2C16.8,53.2,5.3,41.7,5.3,27.6S16.8,2,30.9,2C45,2,56.4,13.5,56.4,27.6S45,53.2,30.9,53.2z M30.9,3.5C17.6,3.5,6.8,14.4,6.8,27.6c0,13.3,10.8,24.1,24.101,24.1C44.2,51.7,55,40.9,55,27.6C54.9,14.4,44.1,3.5,30.9,3.5z M36.9,35.8c0,0.601-0.4,1-0.9,1h-1.3c-0.5,0-0.9-0.399-0.9-1V19.5c0-0.6,0.4-1,0.9-1H36c0.5,0,0.9,0.4,0.9,1V35.8z M27.8,35.8 c0,0.601-0.4,1-0.9,1h-1.3c-0.5,0-0.9-0.399-0.9-1V19.5c0-0.6,0.4-1,0.9-1H27c0.5,0,0.9,0.4,0.9,1L27.8,35.8L27.8,35.8z`, nextIcon: `M2,18.5A1.52,1.52,0,0,1,.92,18a1.49,1.49,0,0,1,0-2.12L7.81,9.36,1,3.11A1.5,1.5,0,1,1,3,.89l8,7.34a1.48,1.48,0,0,1,.49,1.09,1.51,1.51,0,0,1-.46,1.1L3,18.08A1.5,1.5,0,0,1,2,18.5Z`, prevIcon: `M10,.5A1.52,1.52,0,0,1,11.08,1a1.49,1.49,0,0,1,0,2.12L4.19,9.64,11,15.89a1.5,1.5,0,1,1-2,2.22L1,10.77A1.48,1.48,0,0,1,.5,9.68,1.51,1.51,0,0,1,1,8.58L9,.92A1.5,1.5,0,0,1,10,.5Z`, prevBtnSize: 18, nextBtnSize: 18, color: `#A4B1D7`, borderColor: `#A4B1D7`, borderWidth: 1 }, emphasis: { label: { show: true, color: `#6f778d` }, itemStyle: { color: `#316BF3` }, controlStyle: { color: `#316BF3`, borderColor: `#316BF3`, borderWidth: 2 } }, progress: { lineStyle: { color: `#316BF3` }, itemStyle: { color: `#316BF3` }, label: { color: `#6f778d` } }, data: [] }), t2;
})(zE);
Ue(BE, C_.prototype), M();
var VE = (function(e2) {
  s(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.type = `timeline`, t2;
})(Lv);
M();
var HE = (function(e2) {
  s(t2, e2);
  function t2(t3, n2, r2, i2) {
    var a2 = e2.call(this, t3, n2, r2) || this;
    return a2.type = i2 || `value`, a2;
  }
  return t2.prototype.getLabelModel = function() {
    return this.model.getModel(`label`);
  }, t2.prototype.isHorizontal = function() {
    return this.model.get(`orient`) === `horizontal`;
  }, t2;
})(LT);
M();
var UE = Math.PI, WE = Ls(), GE = (function(e2) {
  s(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.prototype.init = function(e3, t3) {
    this.api = t3;
  }, t2.prototype.render = function(e3, t3, n2) {
    if (this.model = e3, this.api = n2, this.ecModel = t3, this.group.removeAll(), e3.get(`show`, true)) {
      var r2 = this._layout(e3, n2), i2 = this._createGroup(`_mainGroup`), a2 = this._createGroup(`_labelGroup`), o2 = this._axis = this._createAxis(r2, e3);
      e3.formatTooltip = function(e4) {
        return cv(`nameValue`, { noName: true, value: o2.scale.getLabel({ value: e4 }) });
      }, z([`AxisLine`, `AxisTick`, `Control`, `CurrentPointer`], function(t4) {
        this[`_render` + t4](r2, i2, o2, e3);
      }, this), this._renderAxisLabel(r2, a2, o2, e3), this._position(r2, e3);
    }
    this._doPlayStop(), this._updateTicksStatus();
  }, t2.prototype.remove = function() {
    this._clearTimer(), this.group.removeAll();
  }, t2.prototype.dispose = function() {
    this._clearTimer();
  }, t2.prototype._layout = function(e3, t3) {
    var n2 = e3.get([`label`, `position`]), r2 = e3.get(`orient`), i2 = qE(e3, t3), a2 = n2 == null || n2 === `auto` ? r2 === `horizontal` ? i2.y + i2.height / 2 < t3.getHeight() / 2 ? `-` : `+` : i2.x + i2.width / 2 < t3.getWidth() / 2 ? `+` : `-` : W(n2) ? { horizontal: { top: `-`, bottom: `+` }, vertical: { left: `-`, right: `+` } }[r2][n2] : n2, o2 = { horizontal: `center`, vertical: a2 >= 0 || a2 === `+` ? `left` : `right` }, s2 = { horizontal: a2 >= 0 || a2 === `+` ? `top` : `bottom`, vertical: `middle` }, c2 = { horizontal: 0, vertical: UE / 2 }, l2 = r2 === `vertical` ? i2.height : i2.width, u2 = e3.getModel(`controlStyle`), d2 = u2.get(`show`, true), f2 = d2 ? u2.get(`itemSize`) : 0, p2 = d2 ? u2.get(`itemGap`) : 0, m2 = f2 + p2, h2 = e3.get([`label`, `rotate`]) || 0;
    h2 = h2 * UE / 180;
    var g2, _2, v2, y2 = u2.get(`position`, true), b2 = d2 && u2.get(`showPlayBtn`, true), x2 = d2 && u2.get(`showPrevBtn`, true), S2 = d2 && u2.get(`showNextBtn`, true), C2 = 0, w2 = l2;
    y2 === `left` || y2 === `bottom` ? (b2 && (g2 = [0, 0], C2 += m2), x2 && (_2 = [C2, 0], C2 += m2), S2 && (v2 = [w2 - f2, 0], w2 -= m2)) : (b2 && (g2 = [w2 - f2, 0], w2 -= m2), x2 && (_2 = [0, 0], C2 += m2), S2 && (v2 = [w2 - f2, 0], w2 -= m2));
    var T2 = [C2, w2];
    return e3.get(`inverse`) && T2.reverse(), { viewRect: i2, mainLength: l2, orient: r2, rotation: c2[r2], labelRotation: h2, labelPosOpt: a2, labelAlign: e3.get([`label`, `align`]) || o2[r2], labelBaseline: e3.get([`label`, `verticalAlign`]) || e3.get([`label`, `baseline`]) || s2[r2], playPosition: g2, prevBtnPosition: _2, nextBtnPosition: v2, axisExtent: T2, controlSize: f2, controlGap: p2 };
  }, t2.prototype._position = function(e3, t3) {
    var n2 = this._mainGroup, r2 = this._labelGroup, i2 = e3.viewRect;
    if (e3.orient === `vertical`) {
      var a2 = kn(), o2 = i2.x, s2 = i2.y + i2.height;
      Nn(a2, a2, [-o2, -s2]), Pn(a2, a2, -UE / 2), Nn(a2, a2, [o2, s2]), i2 = i2.clone(), i2.applyTransform(a2);
    }
    var c2 = g2(i2), l2 = g2(n2.getBoundingRect()), u2 = g2(r2.getBoundingRect()), d2 = [n2.x, n2.y], f2 = [r2.x, r2.y];
    f2[0] = d2[0] = c2[0][0];
    var p2 = e3.labelPosOpt;
    if (p2 == null || W(p2)) {
      var m2 = p2 === `+` ? 0 : 1;
      _2(d2, l2, c2, 1, m2), _2(f2, u2, c2, 1, 1 - m2);
    } else {
      var m2 = p2 >= 0 ? 0 : 1;
      _2(d2, l2, c2, 1, m2), f2[1] = d2[1] + p2;
    }
    n2.setPosition(d2), r2.setPosition(f2), n2.rotation = r2.rotation = e3.rotation, h2(n2), h2(r2);
    function h2(e4) {
      e4.originX = c2[0][0] - e4.x, e4.originY = c2[1][0] - e4.y;
    }
    function g2(e4) {
      return [[e4.x, e4.x + e4.width], [e4.y, e4.y + e4.height]];
    }
    function _2(e4, t4, n3, r3, i3) {
      e4[r3] += n3[r3][i3] - t4[r3][i3];
    }
  }, t2.prototype._createAxis = function(e3, t3) {
    var n2 = t3.getData(), r2 = t3.get(`axisType`), i2 = KE(t3, r2);
    i2.getTicks = function() {
      return n2.mapArray([`value`], function(e4) {
        return { value: e4 };
      });
    };
    var a2 = n2.getDataExtent(`value`);
    i2.setExtent(a2[0], a2[1]), i2.calcNiceTicks();
    var o2 = new HE(`value`, i2, e3.axisExtent, r2);
    return o2.model = t3, o2;
  }, t2.prototype._createGroup = function(e3) {
    var t3 = this[e3] = new So();
    return this.group.add(t3), t3;
  }, t2.prototype._renderAxisLine = function(e3, t3, n2, r2) {
    var i2 = n2.getExtent();
    if (r2.get([`lineStyle`, `show`])) {
      var a2 = new Of({ shape: { x1: i2[0], y1: 0, x2: i2[1], y2: 0 }, style: R({ lineCap: `round` }, r2.getModel(`lineStyle`).getLineStyle()), silent: true, z2: 1 });
      t3.add(a2);
      var o2 = this._progressLine = new Of({ shape: { x1: i2[0], x2: this._currentPointer ? this._currentPointer.x : i2[0], y1: 0, y2: 0 }, style: ze({ lineCap: `round`, lineWidth: a2.style.lineWidth }, r2.getModel([`progress`, `lineStyle`]).getLineStyle()), silent: true, z2: 1 });
      t3.add(o2);
    }
  }, t2.prototype._renderAxisTick = function(e3, t3, n2, r2) {
    var i2 = this, a2 = r2.getData(), o2 = n2.scale.getTicks();
    this._tickSymbols = [], z(o2, function(e4) {
      var o3 = n2.dataToCoord(e4.value), s2 = a2.getItemModel(e4.value), c2 = s2.getModel(`itemStyle`), l2 = s2.getModel([`emphasis`, `itemStyle`]), u2 = s2.getModel([`progress`, `itemStyle`]), d2 = YE(s2, c2, t3, { x: o3, y: 0, onclick: Ye(i2._changeTimeline, i2, e4.value) });
      d2.ensureState(`emphasis`).style = l2.getItemStyle(), d2.ensureState(`progress`).style = u2.getItemStyle(), hd(d2);
      var f2 = bu(d2);
      s2.get(`tooltip`) ? (f2.dataIndex = e4.value, f2.dataModel = r2) : f2.dataIndex = f2.dataModel = null, i2._tickSymbols.push(d2);
    });
  }, t2.prototype._renderAxisLabel = function(e3, t3, n2, r2) {
    var i2 = this;
    if (n2.getLabelModel().get(`show`)) {
      var a2 = r2.getData(), o2 = n2.getViewLabels();
      this._tickLabels = [], z(o2, function(r3) {
        var o3 = r3.tickValue, s2 = a2.getItemModel(o3), c2 = s2.getModel(`label`), l2 = s2.getModel([`emphasis`, `label`]), u2 = s2.getModel([`progress`, `label`]), d2 = new ou({ x: n2.dataToCoord(r3.tickValue), y: 0, rotation: e3.labelRotation - e3.rotation, onclick: Ye(i2._changeTimeline, i2, o3), silent: false, style: Bp(c2, { text: r3.formattedLabel, align: e3.labelAlign, verticalAlign: e3.labelBaseline }) });
        d2.ensureState(`emphasis`).style = Bp(l2), d2.ensureState(`progress`).style = Bp(u2), t3.add(d2), hd(d2), WE(d2).dataIndex = o3, i2._tickLabels.push(d2);
      });
    }
  }, t2.prototype._renderControl = function(e3, t3, n2, r2) {
    var i2 = e3.controlSize, a2 = e3.rotation, o2 = r2.getModel(`controlStyle`).getItemStyle(), s2 = r2.getModel([`emphasis`, `controlStyle`]).getItemStyle(), c2 = r2.getPlayState(), l2 = r2.get(`inverse`, true);
    u2(e3.nextBtnPosition, `next`, Ye(this._changeTimeline, this, l2 ? `-` : `+`)), u2(e3.prevBtnPosition, `prev`, Ye(this._changeTimeline, this, l2 ? `+` : `-`)), u2(e3.playPosition, c2 ? `stop` : `play`, Ye(this._handlePlayClick, this, !c2), true);
    function u2(e4, n3, c3, l3) {
      if (e4) {
        var u3 = oo(q(r2.get([`controlStyle`, n3 + `BtnSize`]), i2), i2), d2 = [0, -u3 / 2, u3, u3], f2 = JE(r2, n3 + `Icon`, d2, { x: e4[0], y: e4[1], originX: i2 / 2, originY: 0, rotation: l3 ? -a2 : 0, rectHover: true, style: o2, onclick: c3 });
        f2.ensureState(`emphasis`).style = s2, t3.add(f2), hd(f2);
      }
    }
  }, t2.prototype._renderCurrentPointer = function(e3, t3, n2, r2) {
    var i2 = r2.getData(), a2 = r2.getCurrentIndex(), o2 = i2.getItemModel(a2).getModel(`checkpointStyle`), s2 = this, c2 = { onCreate: function(e4) {
      e4.draggable = true, e4.drift = Ye(s2._handlePointerDrag, s2), e4.ondragend = Ye(s2._handlePointerDragend, s2), XE(e4, s2._progressLine, a2, n2, r2, true);
    }, onUpdate: function(e4) {
      XE(e4, s2._progressLine, a2, n2, r2);
    } };
    this._currentPointer = YE(o2, o2, this._mainGroup, {}, this._currentPointer, c2);
  }, t2.prototype._handlePlayClick = function(e3) {
    this._clearTimer(), this.api.dispatchAction({ type: `timelinePlayChange`, playState: e3, from: this.uid });
  }, t2.prototype._handlePointerDrag = function(e3, t3, n2) {
    this._clearTimer(), this._pointerChangeTimeline([n2.offsetX, n2.offsetY]);
  }, t2.prototype._handlePointerDragend = function(e3) {
    this._pointerChangeTimeline([e3.offsetX, e3.offsetY], true);
  }, t2.prototype._pointerChangeTimeline = function(e3, t3) {
    var n2 = this._toAxisCoord(e3)[0], r2 = this._axis, i2 = Wo(r2.getExtent().slice());
    n2 > i2[1] && (n2 = i2[1]), n2 < i2[0] && (n2 = i2[0]), this._currentPointer.x = n2, this._currentPointer.markRedraw();
    var a2 = this._progressLine;
    a2 && (a2.shape.x2 = n2, a2.dirty());
    var o2 = this._findNearestTick(n2), s2 = this.model;
    (t3 || o2 !== s2.getCurrentIndex() && s2.get(`realtime`)) && this._changeTimeline(o2);
  }, t2.prototype._doPlayStop = function() {
    var e3 = this;
    this._clearTimer(), this.model.getPlayState() && (this._timer = setTimeout(function() {
      var t3 = e3.model;
      e3._changeTimeline(t3.getCurrentIndex() + (t3.get(`rewind`, true) ? -1 : 1));
    }, this.model.get(`playInterval`)));
  }, t2.prototype._toAxisCoord = function(e3) {
    return bp(e3, this._mainGroup.getLocalTransform(), true);
  }, t2.prototype._findNearestTick = function(e3) {
    var t3 = this.model.getData(), n2 = 1 / 0, r2, i2 = this._axis;
    return t3.each([`value`], function(t4, a2) {
      var o2 = i2.dataToCoord(t4), s2 = Math.abs(o2 - e3);
      s2 < n2 && (n2 = s2, r2 = a2);
    }), r2;
  }, t2.prototype._clearTimer = function() {
    this._timer && (this._timer = (clearTimeout(this._timer), null));
  }, t2.prototype._changeTimeline = function(e3) {
    var t3 = this.model.getCurrentIndex();
    e3 === `+` ? e3 = t3 + 1 : e3 === `-` && (e3 = t3 - 1), this.api.dispatchAction({ type: `timelineChange`, currentIndex: e3, from: this.uid });
  }, t2.prototype._updateTicksStatus = function() {
    var e3 = this.model.getCurrentIndex(), t3 = this._tickSymbols, n2 = this._tickLabels;
    if (t3) for (var r2 = 0; r2 < t3.length; r2++) t3 && t3[r2] && t3[r2].toggleState(`progress`, r2 < e3);
    if (n2) for (var r2 = 0; r2 < n2.length; r2++) n2 && n2[r2] && n2[r2].toggleState(`progress`, WE(n2[r2]).dataIndex <= e3);
  }, t2.type = `timeline.slider`, t2;
})(VE);
function KE(e2, t2) {
  if (t2 || (t2 = e2.get(`type`)), t2) switch (t2) {
    case `category`:
      return new UC({ ordinalMeta: e2.getCategories(), extent: [1 / 0, -1 / 0] });
    case `time`:
      return new ow({ locale: e2.ecModel.getLocaleModel(), useUTC: e2.ecModel.get(`useUTC`) });
    default:
      return new GC();
  }
}
function qE(e2, t2) {
  return bh(e2.getBoxLayoutParams(), { width: t2.getWidth(), height: t2.getHeight() }, e2.get(`padding`));
}
function JE(e2, t2, n2, r2) {
  var i2 = r2.style, a2 = Dp(e2.get([`controlStyle`, t2]), r2 || {}, new X(n2[0], n2[1], n2[2], n2[3]));
  return i2 && a2.setStyle(i2), a2;
}
function YE(e2, t2, n2, r2, i2, a2) {
  var o2 = t2.get(`color`);
  i2 ? (i2.setColor(o2), n2.add(i2), a2 && a2.onUpdate(i2)) : (i2 = Zy(e2.get(`symbol`), -1, -1, 2, 2, o2), i2.setStyle(`strokeNoScale`, true), n2.add(i2), a2 && a2.onCreate(i2));
  var s2 = t2.getItemStyle([`color`]);
  i2.setStyle(s2), r2 = Le({ rectHover: true, z2: 100 }, r2, true);
  var c2 = Qy(e2.get(`symbolSize`));
  r2.scaleX = c2[0] / 2, r2.scaleY = c2[1] / 2;
  var l2 = $y(e2.get(`symbolOffset`), c2);
  l2 && (r2.x = (r2.x || 0) + l2[0], r2.y = (r2.y || 0) + l2[1]);
  var u2 = e2.get(`symbolRotate`);
  return r2.rotation = (u2 || 0) * Math.PI / 180 || 0, i2.attr(r2), i2.updateTransform(), i2;
}
function XE(e2, t2, n2, r2, i2, a2) {
  if (!e2.dragging) {
    var o2 = i2.getModel(`checkpointStyle`), s2 = r2.dataToCoord(i2.getData().get(`value`, n2));
    if (a2 || !o2.get(`animation`, true)) e2.attr({ x: s2, y: 0 }), t2 && t2.attr({ shape: { x2: s2 } });
    else {
      var c2 = { duration: o2.get(`animationDuration`, true), easing: o2.get(`animationEasing`, true) };
      e2.stopAnimation(null, true), e2.animateTo({ x: s2, y: 0 }, c2), t2 && t2.animateTo({ shape: { x2: s2 } }, c2);
    }
  }
}
function ZE(e2) {
  e2.registerAction({ type: `timelineChange`, event: `timelineChanged`, update: `prepareAndUpdate` }, function(e3, t2, n2) {
    var r2 = t2.getComponent(`timeline`);
    return r2 && e3.currentIndex != null && (r2.setCurrentIndex(e3.currentIndex), !r2.get(`loop`, true) && r2.isIndexMax() && r2.getPlayState() && (r2.setPlayState(false), n2.dispatchAction({ type: `timelinePlayChange`, playState: false, from: e3.from }))), t2.resetOption(`timeline`, { replaceMerge: r2.get(`replaceMerge`, true) }), ze({ currentIndex: r2.option.currentIndex }, e3);
  }), e2.registerAction({ type: `timelinePlayChange`, event: `timelinePlayChanged`, update: `update` }, function(e3, t2) {
    var n2 = t2.getComponent(`timeline`);
    n2 && e3.playState != null && n2.setPlayState(e3.playState);
  });
}
function QE(e2) {
  var t2 = e2 && e2.timeline;
  H(t2) || (t2 = t2 ? [t2] : []), z(t2, function(e3) {
    e3 && $E(e3);
  });
}
function $E(e2) {
  var t2 = e2.type, n2 = { number: `value`, time: `time` };
  if (n2[t2] && (e2.axisType = n2[t2], delete e2.type), eD(e2), tD(e2, `controlPosition`)) {
    var r2 = e2.controlStyle || (e2.controlStyle = {});
    tD(r2, `position`) || (r2.position = e2.controlPosition), r2.position === `none` && !tD(r2, `show`) && (r2.show = false, delete r2.position), delete e2.controlPosition;
  }
  z(e2.data || [], function(e3) {
    K(e3) && !H(e3) && (!tD(e3, `value`) && tD(e3, `name`) && (e3.value = e3.name), eD(e3));
  });
}
function eD(e2) {
  var t2 = e2.itemStyle || (e2.itemStyle = {}), n2 = t2.emphasis || (t2.emphasis = {}), r2 = e2.label || e2.label || {}, i2 = r2.normal || (r2.normal = {}), a2 = { normal: 1, emphasis: 1 };
  z(r2, function(e3, t3) {
    !a2[t3] && !tD(i2, t3) && (i2[t3] = e3);
  }), n2.label && !tD(r2, `emphasis`) && (r2.emphasis = n2.label, delete n2.label);
}
function tD(e2, t2) {
  return e2.hasOwnProperty(t2);
}
function nD(e2) {
  e2.registerComponentModel(BE), e2.registerComponentView(GE), e2.registerSubTypeDefaulter(`timeline`, function() {
    return `slider`;
  }), ZE(e2), e2.registerPreprocessor(QE);
}
var rD = Math.sin, iD = Math.cos, aD = Math.PI, oD = Math.PI * 2, sD = 180 / aD, cD = (function() {
  function e2() {
  }
  return e2.prototype.reset = function(e3) {
    this._start = true, this._d = [], this._str = ``, this._p = 10 ** (e3 || 4);
  }, e2.prototype.moveTo = function(e3, t2) {
    this._add(`M`, e3, t2);
  }, e2.prototype.lineTo = function(e3, t2) {
    this._add(`L`, e3, t2);
  }, e2.prototype.bezierCurveTo = function(e3, t2, n2, r2, i2, a2) {
    this._add(`C`, e3, t2, n2, r2, i2, a2);
  }, e2.prototype.quadraticCurveTo = function(e3, t2, n2, r2) {
    this._add(`Q`, e3, t2, n2, r2);
  }, e2.prototype.arc = function(e3, t2, n2, r2, i2, a2) {
    this.ellipse(e3, t2, n2, n2, 0, r2, i2, a2);
  }, e2.prototype.ellipse = function(e3, t2, n2, r2, i2, a2, o2, s2) {
    var c2 = o2 - a2, l2 = !s2, u2 = Math.abs(c2), d2 = ki(u2 - oD) || (l2 ? c2 >= oD : -c2 >= oD), f2 = c2 > 0 ? c2 % oD : c2 % oD + oD, p2 = false;
    p2 = d2 ? true : !ki(u2) && f2 >= aD == !!l2;
    var m2 = e3 + n2 * iD(a2), h2 = t2 + r2 * rD(a2);
    this._start && this._add(`M`, m2, h2);
    var g2 = Math.round(i2 * sD);
    if (d2) {
      var _2 = 1 / this._p, v2 = (l2 ? 1 : -1) * (oD - _2);
      this._add(`A`, n2, r2, g2, 1, +l2, e3 + n2 * iD(a2 + v2), t2 + r2 * rD(a2 + v2)), _2 > 0.01 && this._add(`A`, n2, r2, g2, 0, +l2, m2, h2);
    } else {
      var y2 = e3 + n2 * iD(o2), b2 = t2 + r2 * rD(o2);
      this._add(`A`, n2, r2, g2, +p2, +l2, y2, b2);
    }
  }, e2.prototype.rect = function(e3, t2, n2, r2) {
    this._add(`M`, e3, t2), this._add(`l`, n2, 0), this._add(`l`, 0, r2), this._add(`l`, -n2, 0), this._add(`Z`);
  }, e2.prototype.closePath = function() {
    this._d.length > 0 && this._add(`Z`);
  }, e2.prototype._add = function(e3, t2, n2, r2, i2, a2, o2, s2, c2) {
    for (var l2 = [], u2 = this._p, d2 = 1; d2 < arguments.length; d2++) {
      var f2 = arguments[d2];
      if (isNaN(f2)) {
        this._invalid = true;
        return;
      }
      l2.push(Math.round(f2 * u2) / u2);
    }
    this._d.push(e3 + l2.join(` `)), this._start = e3 === `Z`;
  }, e2.prototype.generateStr = function() {
    this._str = this._invalid ? `` : this._d.join(``), this._d = [];
  }, e2.prototype.getStr = function() {
    return this._str;
  }, e2;
})(), lD = `none`, uD = Math.round;
function dD(e2) {
  var t2 = e2.fill;
  return t2 != null && t2 !== lD;
}
function fD(e2) {
  var t2 = e2.stroke;
  return t2 != null && t2 !== lD;
}
var pD = [`lineCap`, `miterLimit`, `lineJoin`], mD = B(pD, function(e2) {
  return `stroke-` + e2.toLowerCase();
});
function hD(e2, t2, n2, r2) {
  var i2 = t2.opacity == null ? 1 : t2.opacity;
  if (n2 instanceof Jl) {
    e2(`opacity`, i2);
    return;
  }
  if (dD(t2)) {
    var a2 = Di(t2.fill);
    e2(`fill`, a2.color);
    var o2 = t2.fillOpacity == null ? a2.opacity * i2 : t2.fillOpacity * a2.opacity * i2;
    (r2 || o2 < 1) && e2(`fill-opacity`, o2);
  } else e2(`fill`, lD);
  if (fD(t2)) {
    var s2 = Di(t2.stroke);
    e2(`stroke`, s2.color);
    var c2 = t2.strokeNoScale ? n2.getLineScale() : 1, l2 = c2 ? (t2.lineWidth || 0) / c2 : 0, u2 = t2.strokeOpacity == null ? s2.opacity * i2 : t2.strokeOpacity * s2.opacity * i2, d2 = t2.strokeFirst;
    if ((r2 || l2 !== 1) && e2(`stroke-width`, l2), (r2 || d2) && e2(`paint-order`, d2 ? `stroke` : `fill`), (r2 || u2 < 1) && e2(`stroke-opacity`, u2), t2.lineDash) {
      var f2 = cb(n2), p2 = f2[0], m2 = f2[1];
      p2 && (m2 = uD(m2 || 0), e2(`stroke-dasharray`, p2.join(`,`)), (m2 || r2) && e2(`stroke-dashoffset`, m2));
    } else r2 && e2(`stroke-dasharray`, lD);
    for (var h2 = 0; h2 < pD.length; h2++) {
      var g2 = pD[h2];
      if (r2 || t2[g2] !== Bl[g2]) {
        var _2 = t2[g2] || Bl[g2];
        _2 && e2(mD[h2], _2);
      }
    }
  } else r2 && e2(`stroke`, lD);
}
var gD = `http://www.w3.org/2000/svg`, _D = `http://www.w3.org/1999/xlink`, vD = `http://www.w3.org/2000/xmlns/`, yD = `http://www.w3.org/XML/1998/namespace`, bD = `ecmeta_`;
function xD(e2) {
  return document.createElementNS(gD, e2);
}
function SD(e2, t2, n2, r2, i2) {
  return { tag: e2, attrs: n2 || {}, children: r2, text: i2, key: t2 };
}
function CD(e2, t2) {
  var n2 = [];
  if (t2) for (var r2 in t2) {
    var i2 = t2[r2], a2 = r2;
    i2 !== false && (i2 !== true && i2 != null && (a2 += `="` + i2 + `"`), n2.push(a2));
  }
  return `<` + e2 + ` ` + n2.join(` `) + `>`;
}
function wD(e2) {
  return `</` + e2 + `>`;
}
function TD(e2, t2) {
  t2 || (t2 = {});
  var n2 = t2.newline ? `
` : ``;
  function r2(e3) {
    var t3 = e3.children, i2 = e3.tag, a2 = e3.attrs, o2 = e3.text;
    return CD(i2, a2) + (i2 === `style` ? o2 || `` : fn(o2)) + (t3 ? `` + n2 + B(t3, function(e4) {
      return r2(e4);
    }).join(n2) + n2 : ``) + wD(i2);
  }
  return r2(e2);
}
function ED(e2, t2, n2) {
  n2 || (n2 = {});
  var r2 = n2.newline ? `
` : ``, i2 = ` {` + r2, a2 = r2 + `}`, o2 = B(V(e2), function(t3) {
    return t3 + i2 + B(V(e2[t3]), function(n3) {
      return n3 + `:` + e2[t3][n3] + `;`;
    }).join(r2) + a2;
  }).join(r2), s2 = B(V(t2), function(e3) {
    return `@keyframes ` + e3 + i2 + B(V(t2[e3]), function(n3) {
      return n3 + i2 + B(V(t2[e3][n3]), function(r3) {
        var i3 = t2[e3][n3][r3];
        return r3 === `d` && (i3 = `path("` + i3 + `")`), r3 + `:` + i3 + `;`;
      }).join(r2) + a2;
    }).join(r2) + a2;
  }).join(r2);
  return !o2 && !s2 ? `` : [`<![CDATA[`, o2, s2, `]]>`].join(r2);
}
function DD(e2) {
  return { zrId: e2, shadowCache: {}, patternCache: {}, gradientCache: {}, clipPathCache: {}, defs: {}, cssNodes: {}, cssAnims: {}, cssStyleCache: {}, cssAnimIdx: 0, shadowIdx: 0, gradientIdx: 0, patternIdx: 0, clipPathIdx: 0 };
}
function OD(e2, t2, n2, r2) {
  return SD(`svg`, `root`, { width: e2, height: t2, xmlns: gD, "xmlns:xlink": _D, version: `1.1`, baseProfile: `full`, viewBox: r2 ? `0 0 ` + e2 + ` ` + t2 : false }, n2);
}
var kD = 0;
function AD() {
  return kD++;
}
var jD = { cubicIn: `0.32,0,0.67,0`, cubicOut: `0.33,1,0.68,1`, cubicInOut: `0.65,0,0.35,1`, quadraticIn: `0.11,0,0.5,0`, quadraticOut: `0.5,1,0.89,1`, quadraticInOut: `0.45,0,0.55,1`, quarticIn: `0.5,0,0.75,0`, quarticOut: `0.25,1,0.5,1`, quarticInOut: `0.76,0,0.24,1`, quinticIn: `0.64,0,0.78,0`, quinticOut: `0.22,1,0.36,1`, quinticInOut: `0.83,0,0.17,1`, sinusoidalIn: `0.12,0,0.39,0`, sinusoidalOut: `0.61,1,0.88,1`, sinusoidalInOut: `0.37,0,0.63,1`, exponentialIn: `0.7,0,0.84,0`, exponentialOut: `0.16,1,0.3,1`, exponentialInOut: `0.87,0,0.13,1`, circularIn: `0.55,0,1,0.45`, circularOut: `0,0.55,0.45,1`, circularInOut: `0.85,0,0.15,1` }, MD = `transform-origin`;
function ND(e2, t2, n2) {
  var r2 = R({}, e2.shape);
  R(r2, t2), e2.buildPath(n2, r2);
  var i2 = new cD();
  return i2.reset(Wi(e2)), n2.rebuildPath(i2, 1), i2.generateStr(), i2.getStr();
}
function PD(e2, t2) {
  var n2 = t2.originX, r2 = t2.originY;
  (n2 || r2) && (e2[MD] = n2 + `px ` + r2 + `px`);
}
var FD = { fill: `fill`, opacity: `opacity`, lineWidth: `stroke-width`, lineDashOffset: `stroke-dashoffset` };
function ID(e2, t2) {
  var n2 = t2.zrId + `-ani-` + t2.cssAnimIdx++;
  return t2.cssAnims[n2] = e2, n2;
}
function LD(e2, t2, n2) {
  var r2 = e2.shape.paths, i2 = {}, a2, o2;
  if (z(r2, function(e3) {
    var t3 = DD(n2.zrId);
    t3.animation = true, zD(e3, {}, t3, true);
    var r3 = t3.cssAnims, s3 = t3.cssNodes, c2 = V(r3), l2 = c2.length;
    if (l2) {
      o2 = c2[l2 - 1];
      var u2 = r3[o2];
      for (var d2 in u2) {
        var f2 = u2[d2];
        i2[d2] = i2[d2] || { d: `` }, i2[d2].d += f2.d || ``;
      }
      for (var p2 in s3) {
        var m2 = s3[p2].animation;
        m2.indexOf(o2) >= 0 && (a2 = m2);
      }
    }
  }), a2) {
    t2.d = false;
    var s2 = ID(i2, n2);
    return a2.replace(o2, s2);
  }
}
function RD(e2) {
  return W(e2) ? jD[e2] ? `cubic-bezier(` + jD[e2] + `)` : Gr(e2) ? e2 : `` : ``;
}
function zD(e2, t2, n2, r2) {
  var i2 = e2.animators, a2 = i2.length, o2 = [];
  if (e2 instanceof Ff) {
    var s2 = LD(e2, t2, n2);
    if (s2) o2.push(s2);
    else if (!a2) return;
  } else if (!a2) return;
  for (var c2 = {}, l2 = 0; l2 < a2; l2++) {
    var u2 = i2[l2], d2 = [u2.getMaxTime() / 1e3 + `s`], f2 = RD(u2.getClip().easing), p2 = u2.getDelay();
    f2 ? d2.push(f2) : d2.push(`linear`), p2 && d2.push(p2 / 1e3 + `s`), u2.getLoop() && d2.push(`infinite`);
    var m2 = d2.join(` `);
    c2[m2] = c2[m2] || [m2, []], c2[m2][1].push(u2);
  }
  function h2(i3) {
    var a3 = i3[1], o3 = a3.length, s3 = {}, c3 = {}, l3 = {}, u3 = `animation-timing-function`;
    function d3(e3, t3, n3) {
      for (var r3 = e3.getTracks(), i4 = e3.getMaxTime(), a4 = 0; a4 < r3.length; a4++) {
        var o4 = r3[a4];
        if (o4.needsAnimate()) {
          var s4 = o4.keyframes, c4 = o4.propName;
          if (n3 && (c4 = n3(c4)), c4) for (var l4 = 0; l4 < s4.length; l4++) {
            var d4 = s4[l4], f4 = Math.round(d4.time / i4 * 100) + `%`, p4 = RD(d4.easing), m4 = d4.rawValue;
            (W(m4) || G(m4)) && (t3[f4] = t3[f4] || {}, t3[f4][c4] = d4.rawValue, p4 && (t3[f4][u3] = p4));
          }
        }
      }
    }
    for (var f3 = 0; f3 < o3; f3++) {
      var p3 = a3[f3], m3 = p3.targetName;
      m3 ? m3 === `shape` && d3(p3, c3) : !r2 && d3(p3, s3);
    }
    for (var h3 in s3) {
      var g3 = {};
      Qa(g3, e2), R(g3, s3[h3]);
      var _3 = Gi(g3), v2 = s3[h3][u3];
      l3[h3] = _3 ? { transform: _3 } : {}, PD(l3[h3], g3), v2 && (l3[h3][u3] = v2);
    }
    var y2, b2 = true;
    for (var h3 in c3) {
      l3[h3] = l3[h3] || {};
      var x2 = !y2, v2 = c3[h3][u3];
      x2 && (y2 = new vl());
      var S2 = y2.len();
      y2.reset(), l3[h3].d = ND(e2, c3[h3], y2);
      var C2 = y2.len();
      if (!x2 && S2 !== C2) {
        b2 = false;
        break;
      }
      v2 && (l3[h3][u3] = v2);
    }
    if (!b2) for (var h3 in l3) delete l3[h3].d;
    if (!r2) for (var f3 = 0; f3 < o3; f3++) {
      var p3 = a3[f3], m3 = p3.targetName;
      m3 === `style` && d3(p3, l3, function(e3) {
        return FD[e3];
      });
    }
    for (var w2 = V(l3), T2 = true, E2, f3 = 1; f3 < w2.length; f3++) {
      var D2 = w2[f3 - 1], O2 = w2[f3];
      if (l3[D2][MD] !== l3[O2][MD]) {
        T2 = false;
        break;
      }
      E2 = l3[D2][MD];
    }
    if (T2 && E2) {
      for (var h3 in l3) l3[h3][MD] && delete l3[h3][MD];
      t2[MD] = E2;
    }
    if (Ke(w2, function(e3) {
      return V(l3[e3]).length > 0;
    }).length) return ID(l3, n2) + ` ` + i3[0] + ` both`;
  }
  for (var g2 in c2) {
    var s2 = h2(c2[g2]);
    s2 && o2.push(s2);
  }
  if (o2.length) {
    var _2 = n2.zrId + `-cls-` + AD();
    n2.cssNodes[`.` + _2] = { animation: o2.join(`,`) }, t2.class = _2;
  }
}
function BD(e2, t2, n2) {
  if (!e2.ignore) {
    if (e2.isSilent()) {
      var r2 = { "pointer-events": `none` };
      VD(r2, t2, n2, true);
    } else {
      var i2 = e2.states.emphasis && e2.states.emphasis.style ? e2.states.emphasis.style : {}, a2 = i2.fill;
      if (!a2) {
        var o2 = e2.style && e2.style.fill, s2 = e2.states.select && e2.states.select.style && e2.states.select.style.fill, c2 = e2.currentStates.indexOf(`select`) >= 0 && s2 || o2;
        c2 && (a2 = Ti(c2));
      }
      var l2 = i2.lineWidth;
      if (l2) {
        var u2 = !i2.strokeNoScale && e2.transform ? e2.transform[0] : 1;
        l2 /= u2;
      }
      var r2 = { cursor: `pointer` };
      a2 && (r2.fill = a2), i2.stroke && (r2.stroke = i2.stroke), l2 && (r2[`stroke-width`] = l2), VD(r2, t2, n2, true);
    }
  }
}
function VD(e2, t2, n2, r2) {
  var i2 = JSON.stringify(e2), a2 = n2.cssStyleCache[i2];
  a2 || (a2 = n2.zrId + `-cls-` + AD(), n2.cssStyleCache[i2] = a2, n2.cssNodes[`.` + a2 + (r2 ? `:hover` : ``)] = e2), t2.class = t2.class ? t2.class + ` ` + a2 : a2;
}
var HD = Math.round;
function UD(e2) {
  return e2 && W(e2.src);
}
function WD(e2) {
  return e2 && U(e2.toDataURL);
}
function GD(e2, t2, n2, r2) {
  hD(function(i2, a2) {
    var o2 = i2 === `fill` || i2 === `stroke`;
    o2 && Hi(a2) ? oO(t2, e2, i2, r2) : o2 && zi(a2) ? sO(n2, e2, i2, r2) : e2[i2] = a2, o2 && r2.ssr && a2 === `none` && (e2[`pointer-events`] = `visible`);
  }, t2, n2, false), aO(n2, e2, r2);
}
function KD(e2, t2) {
  var n2 = Fo(t2);
  n2 && (n2.each(function(t3, n3) {
    t3 != null && (e2[(`ecmeta_` + n3).toLowerCase()] = t3 + ``);
  }), t2.isSilent() && (e2[bD + `silent`] = `true`));
}
function qD(e2) {
  return ki(e2[0] - 1) && ki(e2[1]) && ki(e2[2]) && ki(e2[3] - 1);
}
function JD(e2) {
  return ki(e2[4]) && ki(e2[5]);
}
function YD(e2, t2, n2) {
  if (t2 && !(JD(t2) && qD(t2))) {
    var r2 = n2 ? 10 : 1e4;
    e2.transform = qD(t2) ? `translate(` + HD(t2[4] * r2) / r2 + ` ` + HD(t2[5] * r2) / r2 + `)` : Mi(t2);
  }
}
function XD(e2, t2, n2) {
  for (var r2 = e2.points, i2 = [], a2 = 0; a2 < r2.length; a2++) i2.push(HD(r2[a2][0] * n2) / n2), i2.push(HD(r2[a2][1] * n2) / n2);
  t2.points = i2.join(` `);
}
function ZD(e2) {
  return !e2.smooth;
}
function QD(e2) {
  var t2 = B(e2, function(e3) {
    return typeof e3 == `string` ? [e3, e3] : e3;
  });
  return function(e3, n2, r2) {
    for (var i2 = 0; i2 < t2.length; i2++) {
      var a2 = t2[i2], o2 = e3[a2[0]];
      o2 != null && (n2[a2[1]] = HD(o2 * r2) / r2);
    }
  };
}
var $D = { circle: [QD([`cx`, `cy`, `r`])], polyline: [XD, ZD], polygon: [XD, ZD] };
function eO(e2) {
  for (var t2 = e2.animators, n2 = 0; n2 < t2.length; n2++) if (t2[n2].targetName === `shape`) return true;
  return false;
}
function tO(e2, t2) {
  var n2 = e2.style, r2 = e2.shape, i2 = $D[e2.type], a2 = {}, o2 = t2.animation, s2 = `path`, c2 = e2.style.strokePercent, l2 = t2.compress && Wi(e2) || 4;
  if (i2 && !t2.willUpdate && (!i2[1] || i2[1](r2)) && !(o2 && eO(e2)) && !(c2 < 1)) {
    s2 = e2.type;
    var u2 = 10 ** l2;
    i2[0](r2, a2, u2);
  } else {
    var d2 = !e2.path || e2.shapeChanged();
    e2.path || e2.createPathProxy();
    var f2 = e2.path;
    d2 && (f2.beginPath(), e2.buildPath(f2, e2.shape), e2.pathUpdated());
    var p2 = f2.getVersion(), m2 = e2, h2 = m2.__svgPathBuilder;
    (m2.__svgPathVersion !== p2 || !h2 || c2 !== m2.__svgPathStrokePercent) && (h2 || (h2 = m2.__svgPathBuilder = new cD()), h2.reset(l2), f2.rebuildPath(h2, c2), h2.generateStr(), m2.__svgPathVersion = p2, m2.__svgPathStrokePercent = c2), a2.d = h2.getStr();
  }
  return YD(a2, e2.transform), GD(a2, n2, e2, t2), KD(a2, e2), t2.animation && zD(e2, a2, t2), t2.emphasis && BD(e2, a2, t2), SD(s2, e2.id + ``, a2);
}
function nO(e2, t2) {
  var n2 = e2.style, r2 = n2.image;
  if (r2 && !W(r2) && (UD(r2) ? r2 = r2.src : WD(r2) && (r2 = r2.toDataURL())), r2) {
    var i2 = n2.x || 0, a2 = n2.y || 0, o2 = n2.width, s2 = n2.height, c2 = { href: r2, width: o2, height: s2 };
    return i2 && (c2.x = i2), a2 && (c2.y = a2), YD(c2, e2.transform), GD(c2, n2, e2, t2), KD(c2, e2), t2.animation && zD(e2, c2, t2), SD(`image`, e2.id + ``, c2);
  }
}
function rO(e2, t2) {
  var n2 = e2.style, r2 = n2.text;
  if (r2 != null && (r2 += ``), !(!r2 || isNaN(n2.x) || isNaN(n2.y))) {
    var i2 = n2.font || `12px sans-serif`, a2 = n2.x || 0, o2 = Pi(n2.y || 0, ao(i2), n2.textBaseline), s2 = { "dominant-baseline": `central`, "text-anchor": Ni[n2.textAlign] || n2.textAlign };
    if (fu(n2)) {
      var c2 = ``, l2 = n2.fontStyle, u2 = uu(n2.fontSize);
      if (!parseFloat(u2)) return;
      var d2 = n2.fontFamily || `sans-serif`, f2 = n2.fontWeight;
      c2 += `font-size:` + u2 + `;font-family:` + d2 + `;`, l2 && l2 !== `normal` && (c2 += `font-style:` + l2 + `;`), f2 && f2 !== `normal` && (c2 += `font-weight:` + f2 + `;`), s2.style = c2;
    } else s2.style = `font: ` + i2;
    return r2.match(/\s/) && (s2[`xml:space`] = `preserve`), a2 && (s2.x = a2), o2 && (s2.y = o2), YD(s2, e2.transform), GD(s2, n2, e2, t2), KD(s2, e2), t2.animation && zD(e2, s2, t2), SD(`text`, e2.id + ``, s2, void 0, r2);
  }
}
function iO(e2, t2) {
  if (e2 instanceof Q) return tO(e2, t2);
  if (e2 instanceof Jl) return nO(e2, t2);
  if (e2 instanceof Wl) return rO(e2, t2);
}
function aO(e2, t2, n2) {
  var r2 = e2.style;
  if (Fi(r2)) {
    var i2 = Ii(e2), a2 = n2.shadowCache, o2 = a2[i2];
    if (!o2) {
      var s2 = e2.getGlobalScale(), c2 = s2[0], l2 = s2[1];
      if (!c2 || !l2) return;
      var u2 = r2.shadowOffsetX || 0, d2 = r2.shadowOffsetY || 0, f2 = r2.shadowBlur, p2 = Di(r2.shadowColor), m2 = p2.opacity, h2 = p2.color, g2 = f2 / 2 / c2, _2 = f2 / 2 / l2, v2 = g2 + ` ` + _2;
      o2 = n2.zrId + `-s` + n2.shadowIdx++, n2.defs[o2] = SD(`filter`, o2, { id: o2, x: `-100%`, y: `-100%`, width: `300%`, height: `300%` }, [SD(`feDropShadow`, ``, { dx: u2 / c2, dy: d2 / l2, stdDeviation: v2, "flood-color": h2, "flood-opacity": m2 })]), a2[i2] = o2;
    }
    t2.filter = Ui(o2);
  }
}
function oO(e2, t2, n2, r2) {
  var i2 = e2[n2], a2, o2 = { gradientUnits: i2.global ? `userSpaceOnUse` : `objectBoundingBox` };
  if (Bi(i2)) a2 = `linearGradient`, o2.x1 = i2.x, o2.y1 = i2.y, o2.x2 = i2.x2, o2.y2 = i2.y2;
  else if (Vi(i2)) a2 = `radialGradient`, o2.cx = q(i2.x, 0.5), o2.cy = q(i2.y, 0.5), o2.r = q(i2.r, 0.5);
  else return;
  for (var s2 = i2.colorStops, c2 = [], l2 = 0, u2 = s2.length; l2 < u2; ++l2) {
    var d2 = ji(s2[l2].offset) * 100 + `%`, f2 = s2[l2].color, p2 = Di(f2), m2 = p2.color, h2 = p2.opacity, g2 = { offset: d2 };
    g2[`stop-color`] = m2, h2 < 1 && (g2[`stop-opacity`] = h2), c2.push(SD(`stop`, l2 + ``, g2));
  }
  var _2 = TD(SD(a2, ``, o2, c2)), v2 = r2.gradientCache, y2 = v2[_2];
  y2 || (y2 = r2.zrId + `-g` + r2.gradientIdx++, v2[_2] = y2, o2.id = y2, r2.defs[y2] = SD(a2, y2, o2, c2)), t2[n2] = Ui(y2);
}
function sO(e2, t2, n2, r2) {
  var i2 = e2.style[n2], a2 = e2.getBoundingRect(), o2 = {}, s2 = i2.repeat, c2 = s2 === `no-repeat`, l2 = s2 === `repeat-x`, u2 = s2 === `repeat-y`, d2;
  if (Li(i2)) {
    var f2 = i2.imageWidth, p2 = i2.imageHeight, m2 = void 0, h2 = i2.image;
    if (W(h2) ? m2 = h2 : UD(h2) ? m2 = h2.src : WD(h2) && (m2 = h2.toDataURL()), typeof Image > `u`) {
      var g2 = `Image width/height must been given explictly in svg-ssr renderer.`;
      lt(f2, g2), lt(p2, g2);
    } else if (f2 == null || p2 == null) {
      var _2 = function(e3, t3) {
        if (e3) {
          var n3 = e3.elm, r3 = f2 || t3.width, i3 = p2 || t3.height;
          e3.tag === `pattern` && (l2 ? (i3 = 1, r3 /= a2.width) : u2 && (r3 = 1, i3 /= a2.height)), e3.attrs.width = r3, e3.attrs.height = i3, n3 && (n3.setAttribute(`width`, r3), n3.setAttribute(`height`, i3));
        }
      }, v2 = pc(m2, null, e2, function(e3) {
        c2 || _2(S2, e3), _2(d2, e3);
      });
      v2 && v2.width && v2.height && (f2 || (f2 = v2.width), p2 || (p2 = v2.height));
    }
    d2 = SD(`image`, `img`, { href: m2, width: f2, height: p2 }), o2.width = f2, o2.height = p2;
  } else i2.svgElement && (d2 = L(i2.svgElement), o2.width = i2.svgWidth, o2.height = i2.svgHeight);
  if (d2) {
    var y2, b2;
    c2 ? y2 = b2 = 1 : l2 ? (b2 = 1, y2 = o2.width / a2.width) : u2 ? (y2 = 1, b2 = o2.height / a2.height) : o2.patternUnits = `userSpaceOnUse`, y2 != null && !isNaN(y2) && (o2.width = y2), b2 != null && !isNaN(b2) && (o2.height = b2);
    var x2 = Gi(i2);
    x2 && (o2.patternTransform = x2);
    var S2 = SD(`pattern`, ``, o2, [d2]), C2 = TD(S2), w2 = r2.patternCache, T2 = w2[C2];
    T2 || (T2 = r2.zrId + `-p` + r2.patternIdx++, w2[C2] = T2, o2.id = T2, S2 = r2.defs[T2] = SD(`pattern`, T2, o2, [d2])), t2[n2] = Ui(T2);
  }
}
function cO(e2, t2, n2) {
  var r2 = n2.clipPathCache, i2 = n2.defs, a2 = r2[e2.id];
  if (!a2) {
    a2 = n2.zrId + `-c` + n2.clipPathIdx++;
    var o2 = { id: a2 };
    r2[e2.id] = a2, i2[a2] = SD(`clipPath`, a2, o2, [tO(e2, n2)]);
  }
  t2[`clip-path`] = Ui(a2);
}
function lO(e2) {
  return document.createTextNode(e2);
}
function uO(e2, t2, n2) {
  e2.insertBefore(t2, n2);
}
function dO(e2, t2) {
  e2.removeChild(t2);
}
function fO(e2, t2) {
  e2.appendChild(t2);
}
function pO(e2) {
  return e2.parentNode;
}
function mO(e2) {
  return e2.nextSibling;
}
function hO(e2, t2) {
  e2.textContent = t2;
}
var gO = 58, _O = 120, vO = SD(``, ``);
function yO(e2) {
  return e2 === void 0;
}
function bO(e2) {
  return e2 !== void 0;
}
function xO(e2, t2, n2) {
  for (var r2 = {}, i2 = t2; i2 <= n2; ++i2) {
    var a2 = e2[i2].key;
    a2 !== void 0 && (r2[a2] = i2);
  }
  return r2;
}
function SO(e2, t2) {
  var n2 = e2.key === t2.key;
  return e2.tag === t2.tag && n2;
}
function CO(e2) {
  var t2, n2 = e2.children, r2 = e2.tag;
  if (bO(r2)) {
    var i2 = e2.elm = xD(r2);
    if (EO(vO, e2), H(n2)) for (t2 = 0; t2 < n2.length; ++t2) {
      var a2 = n2[t2];
      a2 != null && fO(i2, CO(a2));
    }
    else bO(e2.text) && !K(e2.text) && fO(i2, lO(e2.text));
  } else e2.elm = lO(e2.text);
  return e2.elm;
}
function wO(e2, t2, n2, r2, i2) {
  for (; r2 <= i2; ++r2) {
    var a2 = n2[r2];
    a2 != null && uO(e2, CO(a2), t2);
  }
}
function TO(e2, t2, n2, r2) {
  for (; n2 <= r2; ++n2) {
    var i2 = t2[n2];
    i2 != null && (bO(i2.tag) ? dO(pO(i2.elm), i2.elm) : dO(e2, i2.elm));
  }
}
function EO(e2, t2) {
  var n2, r2 = t2.elm, i2 = e2 && e2.attrs || {}, a2 = t2.attrs || {};
  if (i2 !== a2) {
    for (n2 in a2) {
      var o2 = a2[n2];
      i2[n2] !== o2 && (o2 === true ? r2.setAttribute(n2, ``) : o2 === false ? r2.removeAttribute(n2) : n2 === `style` ? r2.style.cssText = o2 : n2.charCodeAt(0) === _O ? n2 === `xmlns:xlink` || n2 === `xmlns` ? r2.setAttributeNS(vD, n2, o2) : n2.charCodeAt(3) === gO ? r2.setAttributeNS(yD, n2, o2) : n2.charCodeAt(5) === gO ? r2.setAttributeNS(_D, n2, o2) : r2.setAttribute(n2, o2) : r2.setAttribute(n2, o2));
    }
    for (n2 in i2) n2 in a2 || r2.removeAttribute(n2);
  }
}
function DO(e2, t2, n2) {
  for (var r2 = 0, i2 = 0, a2 = t2.length - 1, o2 = t2[0], s2 = t2[a2], c2 = n2.length - 1, l2 = n2[0], u2 = n2[c2], d2, f2, p2, m2; r2 <= a2 && i2 <= c2; ) o2 == null ? o2 = t2[++r2] : s2 == null ? s2 = t2[--a2] : l2 == null ? l2 = n2[++i2] : u2 == null ? u2 = n2[--c2] : SO(o2, l2) ? (OO(o2, l2), o2 = t2[++r2], l2 = n2[++i2]) : SO(s2, u2) ? (OO(s2, u2), s2 = t2[--a2], u2 = n2[--c2]) : SO(o2, u2) ? (OO(o2, u2), uO(e2, o2.elm, mO(s2.elm)), o2 = t2[++r2], u2 = n2[--c2]) : SO(s2, l2) ? (OO(s2, l2), uO(e2, s2.elm, o2.elm), s2 = t2[--a2], l2 = n2[++i2]) : (yO(d2) && (d2 = xO(t2, r2, a2)), f2 = d2[l2.key], yO(f2) ? uO(e2, CO(l2), o2.elm) : (p2 = t2[f2], p2.tag === l2.tag ? (OO(p2, l2), t2[f2] = void 0, uO(e2, p2.elm, o2.elm)) : uO(e2, CO(l2), o2.elm)), l2 = n2[++i2]);
  (r2 <= a2 || i2 <= c2) && (r2 > a2 ? (m2 = n2[c2 + 1] == null ? null : n2[c2 + 1].elm, wO(e2, m2, n2, i2, c2)) : TO(e2, t2, r2, a2));
}
function OO(e2, t2) {
  var n2 = t2.elm = e2.elm, r2 = e2.children, i2 = t2.children;
  e2 !== t2 && (EO(e2, t2), yO(t2.text) ? bO(r2) && bO(i2) ? r2 !== i2 && DO(n2, r2, i2) : bO(i2) ? (bO(e2.text) && hO(n2, ``), wO(n2, null, i2, 0, i2.length - 1)) : bO(r2) ? TO(n2, r2, 0, r2.length - 1) : bO(e2.text) && hO(n2, ``) : e2.text !== t2.text && (bO(r2) && TO(n2, r2, 0, r2.length - 1), hO(n2, t2.text)));
}
function kO(e2, t2) {
  if (SO(e2, t2)) OO(e2, t2);
  else {
    var n2 = e2.elm, r2 = pO(n2);
    CO(t2), r2 !== null && (uO(r2, t2.elm, mO(n2)), TO(r2, [e2], 0, 0));
  }
  return t2;
}
var AO = 0, jO = (function() {
  function e2(e3, t2, n2) {
    if (this.type = `svg`, this.refreshHover = MO(`refreshHover`), this.configLayer = MO(`configLayer`), this.storage = t2, this._opts = n2 = R({}, n2), this.root = e3, this._id = `zr` + AO++, this._oldVNode = OD(n2.width, n2.height), e3 && !n2.ssr) {
      var r2 = this._viewport = document.createElement(`div`);
      r2.style.cssText = `position:relative;overflow:hidden`;
      var i2 = this._svgDom = this._oldVNode.elm = xD(`svg`);
      EO(null, this._oldVNode), r2.appendChild(i2), e3.appendChild(r2);
    }
    this.resize(n2.width, n2.height);
  }
  return e2.prototype.getType = function() {
    return this.type;
  }, e2.prototype.getViewportRoot = function() {
    return this._viewport;
  }, e2.prototype.getViewportRootOffset = function() {
    var e3 = this.getViewportRoot();
    if (e3) return { offsetLeft: e3.offsetLeft || 0, offsetTop: e3.offsetTop || 0 };
  }, e2.prototype.getSvgDom = function() {
    return this._svgDom;
  }, e2.prototype.refresh = function() {
    if (this.root) {
      var e3 = this.renderToVNode({ willUpdate: true });
      e3.attrs.style = `position:absolute;left:0;top:0;user-select:none`, kO(this._oldVNode, e3), this._oldVNode = e3;
    }
  }, e2.prototype.renderOneToVNode = function(e3) {
    return iO(e3, DD(this._id));
  }, e2.prototype.renderToVNode = function(e3) {
    e3 || (e3 = {});
    var t2 = this.storage.getDisplayList(true), n2 = this._width, r2 = this._height, i2 = DD(this._id);
    i2.animation = e3.animation, i2.willUpdate = e3.willUpdate, i2.compress = e3.compress, i2.emphasis = e3.emphasis, i2.ssr = this._opts.ssr;
    var a2 = [], o2 = this._bgVNode = NO(n2, r2, this._backgroundColor, i2);
    o2 && a2.push(o2);
    var s2 = e3.compress ? null : this._mainVNode = SD(`g`, `main`, {}, []);
    this._paintList(t2, i2, s2 ? s2.children : a2), s2 && a2.push(s2);
    var c2 = B(V(i2.defs), function(e4) {
      return i2.defs[e4];
    });
    if (c2.length && a2.push(SD(`defs`, `defs`, {}, c2)), e3.animation) {
      var l2 = ED(i2.cssNodes, i2.cssAnims, { newline: true });
      if (l2) {
        var u2 = SD(`style`, `stl`, {}, [], l2);
        a2.push(u2);
      }
    }
    return OD(n2, r2, a2, e3.useViewBox);
  }, e2.prototype.renderToString = function(e3) {
    return e3 || (e3 = {}), TD(this.renderToVNode({ animation: q(e3.cssAnimation, true), emphasis: q(e3.cssEmphasis, true), willUpdate: false, compress: true, useViewBox: q(e3.useViewBox, true) }), { newline: true });
  }, e2.prototype.setBackgroundColor = function(e3) {
    this._backgroundColor = e3;
  }, e2.prototype.getSvgRoot = function() {
    return this._mainVNode && this._mainVNode.elm;
  }, e2.prototype._paintList = function(e3, t2, n2) {
    for (var r2 = e3.length, i2 = [], a2 = 0, o2, s2, c2 = 0, l2 = 0; l2 < r2; l2++) {
      var u2 = e3[l2];
      if (!u2.invisible) {
        var d2 = u2.__clipPaths, f2 = d2 && d2.length || 0, p2 = s2 && s2.length || 0, m2 = void 0;
        for (m2 = Math.max(f2 - 1, p2 - 1); m2 >= 0 && !(d2 && s2 && d2[m2] === s2[m2]); m2--) ;
        for (var h2 = p2 - 1; h2 > m2; h2--) a2--, o2 = i2[a2 - 1];
        for (var g2 = m2 + 1; g2 < f2; g2++) {
          var _2 = {};
          cO(d2[g2], _2, t2);
          var v2 = SD(`g`, `clip-g-` + c2++, _2, []);
          (o2 ? o2.children : n2).push(v2), i2[a2++] = v2, o2 = v2;
        }
        s2 = d2;
        var y2 = iO(u2, t2);
        y2 && (o2 ? o2.children : n2).push(y2);
      }
    }
  }, e2.prototype.resize = function(e3, t2) {
    var n2 = this._opts, r2 = this.root, i2 = this._viewport;
    if (e3 != null && (n2.width = e3), t2 != null && (n2.height = t2), r2 && i2 && (i2.style.display = `none`, e3 = ob(r2, 0, n2), t2 = ob(r2, 1, n2), i2.style.display = ``), this._width !== e3 || this._height !== t2) {
      if (this._width = e3, this._height = t2, i2) {
        var a2 = i2.style;
        a2.width = e3 + `px`, a2.height = t2 + `px`;
      }
      if (zi(this._backgroundColor)) this.refresh();
      else {
        var o2 = this._svgDom;
        o2 && (o2.setAttribute(`width`, e3), o2.setAttribute(`height`, t2));
        var s2 = this._bgVNode && this._bgVNode.elm;
        s2 && (s2.setAttribute(`width`, e3), s2.setAttribute(`height`, t2));
      }
    }
  }, e2.prototype.getWidth = function() {
    return this._width;
  }, e2.prototype.getHeight = function() {
    return this._height;
  }, e2.prototype.dispose = function() {
    this.root && (this.root.innerHTML = ``), this._svgDom = this._viewport = this.storage = this._oldVNode = this._bgVNode = this._mainVNode = null;
  }, e2.prototype.clear = function() {
    this._svgDom && (this._svgDom.innerHTML = null), this._oldVNode = null;
  }, e2.prototype.toDataURL = function(e3) {
    var t2 = this.renderToString(), n2 = `data:image/svg+xml;`;
    return e3 ? (t2 = Ki(t2), t2 && n2 + `base64,` + t2) : n2 + `charset=UTF-8,` + encodeURIComponent(t2);
  }, e2;
})();
function MO(e2) {
  return function() {
  };
}
function NO(e2, t2, n2, r2) {
  var i2;
  if (n2 && n2 !== `none`) {
    if (i2 = SD(`rect`, `bg`, { width: e2, height: t2, x: `0`, y: `0` }), Hi(n2)) oO({ fill: n2 }, i2.attrs, `fill`, r2);
    else if (zi(n2)) sO({ style: { fill: n2 }, dirty: St, getBoundingRect: function() {
      return { width: e2, height: t2 };
    } }, i2.attrs, `fill`, r2);
    else {
      var a2 = Di(n2), o2 = a2.color, s2 = a2.opacity;
      i2.attrs.fill = o2, s2 < 1 && (i2.attrs[`fill-opacity`] = s2);
    }
  }
  return i2;
}
function PO(e2) {
  e2.registerPainter(`svg`, jO);
}
export {
  mh as $,
  An as $t,
  Zy as A,
  V as An,
  js as At,
  w_ as B,
  I as Bn,
  $o as Bt,
  SS as C,
  et as Cn,
  $u as Ct,
  hb as D,
  G as Dn,
  Hs as Dt,
  Pb as E,
  nt as En,
  nu as Et,
  Lv as F,
  St as Fn,
  Is as Ft,
  wh as G,
  So as Gt,
  $ as H,
  s as Hn,
  Ho as Ht,
  Cv as I,
  at as In,
  Us as It,
  xh as J,
  ui as Jt,
  bh as K,
  no as Kt,
  mv as L,
  q as Ln,
  fs as Lt,
  Vy as M,
  B as Mn,
  Ns as Mt,
  Qv as N,
  Le as Nn,
  zs as Nt,
  rb as O,
  K as On,
  Vs as Ot,
  Zv as P,
  Ue as Pn,
  Bs as Pt,
  ih as Q,
  kn as Qt,
  cv as R,
  ut as Rn,
  Wo as Rt,
  LS as S,
  H as Sn,
  Qu as St,
  Fb as T,
  tt as Tn,
  ou as Tt,
  yh as U,
  M as Un,
  Qo as Ut,
  Jh as V,
  F as Vn,
  Vo as Vt,
  Sh as W,
  Uo as Wt,
  lh as X,
  _r as Xt,
  ph as Y,
  xi as Yt,
  ah as Z,
  X as Zt,
  kw as _,
  z as _n,
  Uf as _t,
  LT as a,
  yn as an,
  Jp as at,
  PC as b,
  xt as bn,
  Cf as bt,
  Pw as c,
  an as cn,
  Tp as ct,
  Hw as d,
  Ye as dn,
  np as dt,
  In as en,
  Rm as et,
  jw as f,
  L as fn,
  wp as ft,
  Uw as g,
  bt as gn,
  Yf as gt,
  Vw as h,
  ze as hn,
  xp as ht,
  WT as i,
  xn as in,
  Bp as it,
  $y as j,
  Ie as jn,
  Ls as jt,
  ob as k,
  W as kn,
  Ks as kt,
  Rw as l,
  Qt as ln,
  Dp as lt,
  Nw as m,
  Xe as mn,
  gp as mt,
  nD as n,
  Pn as nn,
  dm as nt,
  $w as o,
  Cn as on,
  Rp as ot,
  Fw as p,
  J as pn,
  Mp as pt,
  Ch as q,
  Ra as qt,
  RE as r,
  Nn as rn,
  om as rt,
  Ww as s,
  fn as sn,
  bp as st,
  PO as t,
  Mn as tn,
  cm as tt,
  Lw as u,
  qt as un,
  yp as ut,
  GC as v,
  R as vn,
  Of as vt,
  Bb as w,
  U as wn,
  bu as wt,
  MC as x,
  Ve as xn,
  hd as xt,
  IC as y,
  Ke as yn,
  Tf as yt,
  Sv as z,
  be as zn,
  qo as zt
};
