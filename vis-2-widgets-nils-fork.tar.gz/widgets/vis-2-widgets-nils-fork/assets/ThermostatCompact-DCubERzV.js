import { B as e } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as t, H as n, I as r, L as i, P as a, dt as o, ft as s, pt as c, u as l } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as u } from "./Generic-BOiMPpxz.js";
import d from "./Thermostat-DBcZxdN_.js";
e();
var f = class e2 extends d {
  static getWidgetInfo() {
    return { ...d.getWidgetInfo(), id: `tplNils2ThermostatCompact`, visName: `Thermostat Compact`, visWidgetLabel: `thermostat compact`, visDefaultStyle: { position: `relative`, width: `100%`, height: 42, display: `inline-block` } };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  renderWidgetBody(e3) {
    var _a, _b, _c, _d;
    let d2 = this.state.values[`${this.state.rxData[`oid-temp-actual`]}.val`] ?? this.state.values[`${this.state.rxData[`oid-temp-set`]}.val`] ?? null, f2 = this.state.rxData.unit || ((_b = (_a = this.state.tempStateObject) == null ? void 0 : _a.common) == null ? void 0 : _b.unit) || ((_d = (_c = this.state.tempObject) == null ? void 0 : _c.common) == null ? void 0 : _d.unit) || ``, p = d2 == null ? u.t(`temperature`) : `${this.formatValue(d2)}${f2}`, m = this.state.values[`${this.state.rxData[`oid-humidity`]}.val`], h = m == null ? u.t(`humidity`) : `${this.formatValue(m)}%`, g = super.renderWidgetBody({ ...e3, widget: { ...e3.widget, usedInWidget: true } });
    return c(o, { children: [s(t, { variant: `contained`, color: `primary`, size: `small`, onClick: () => this.setState({ dialog: true }), className: `thermostat-compact-button${this.state.rxData[`oid-humidity`] && this.state.rxData[`oid-humidity`] !== `nothing_selected` ? ` thermostat-compact-button--with-humidity` : ``}`, children: c(`span`, { className: `thermostat-compact-label`, children: [s(`span`, { children: p }), this.state.rxData[`oid-humidity`] && this.state.rxData[`oid-humidity`] !== `nothing_selected` ? s(`span`, { style: { fontSize: 10, fontWeight: `normal` }, children: h }) : null] }) }), c(a, { open: !!this.state.dialog, onClose: () => this.setState({ dialog: false }), maxWidth: `lg`, fullWidth: true, children: [c(i, { children: [this.state.rxData.widgetTitle || u.t(`thermostat`), s(n, { style: { float: `right`, zIndex: 2 }, onClick: () => this.setState({ dialog: false }), children: s(l, {}) })] }), s(r, { style: { minWidth: 180, minHeight: 180 }, children: g })] })] });
  }
};
export {
  f as default
};
