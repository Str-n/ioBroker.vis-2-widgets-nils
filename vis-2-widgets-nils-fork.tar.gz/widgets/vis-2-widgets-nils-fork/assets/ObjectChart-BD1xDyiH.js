import { j as M, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { _ as Dr, b as Pe, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { h as Ir, i as kr, j as Pr, k as Rr, l as Or, m as O, n as Er, o as Br, f as zr, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { aa as te, Q as Rt, _ as C, C as ct, ab as tt, ac as Hr, ad as jr, k as V, m as P, e as y, ae as Vr, B as Wr, E as Nr, af as Yr, d as H, g as Hi, ag as Gr, ah as mt, ai as Fr, aj as Ct, ak as Zr, al as Xr, am as Yt, an as Gt, j as jt, ao as $r, O as et, h as F, ap as Ur, aq as Kr, ar as qr, as as ee, at as Re, au as Qr, G as st, Z as it, t as Mt, u as ye, l as Y, n as xt, av as Ot, aw as Et, a as z, ax as Jr, z as tn, ay as ji, M as ot, J as vt, r as rt, az as en, aA as rn, aB as Vi, aC as Oe, aD as Bt, f as nn, x as k, I as N, i as j, w as ft, c as yt, R as lt, aE as kt, aF as an, aG as Vt, aH as ie, H as Z, aI as Wi, T as on, aJ as sn, aK as ln, aL as un, aM as Ni, aN as hn, aO as cn, F as Yi, aP as fn, aQ as Gi, aR as re, K as dn, aS as Fi, aT as pn, aU as vn, aV as be, aW as Zi, aX as gn, a3 as B, aY as mn, L as Lt, aZ as xn, a_ as Tt, a$ as yn, b0 as bn, b1 as _n, b2 as wn, v as Tn, b3 as An, b4 as Sn, b5 as Ee, b6 as Be, b7 as Cn, b8 as ne, b9 as ze, ba as Xi, bb as Mn, bc as Ln, bd as $i, be as Dn, bf as In, bg as zt, bh as Ui, bi as kn, bj as Pn, bk as Rn, bl as He, bm as On, bn as Ft, bo as je, bp as Ve, bq as En, br as Bn, bs as zn, bt as We, bu as Hn, bv as jn, bw as Ne, a6 as Vn, a7 as Wn, a8 as Nn, a9 as Yn, bx as Gn, __tla as __tla_3 } from "./installSVGRenderer-It2PVbYG.js";
import { a as Fn, b as Zn, __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-Buo0KxVv.js";
let Ns, Os, ks, _o, fs, zo;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })()
]).then(async () => {
  function Xn(i) {
    for (var t = [], e = 0; e < i.length; e++) {
      var n = i[e];
      if (!n.defaultAttr.ignore) {
        var r = n.label, a = r.getComputedTransform(), o = r.getBoundingRect(), s = !a || a[1] < 1e-5 && a[2] < 1e-5, l = r.style.margin || 0, u = o.clone();
        u.applyTransform(a), u.x -= l / 2, u.y -= l / 2, u.width += l, u.height += l;
        var h = s ? new te(o, a) : null;
        t.push({
          label: r,
          labelLine: n.labelLine,
          rect: u,
          localRect: o,
          obb: h,
          priority: n.priority,
          defaultAttr: n.defaultAttr,
          layoutOption: n.computedLayoutOption,
          axisAligned: s,
          transform: a
        });
      }
    }
    return t;
  }
  function $n(i) {
    var t = [];
    i.sort(function(v, g) {
      return g.priority - v.priority;
    });
    var e = new Rt(0, 0, 0, 0);
    function n(v) {
      if (!v.ignore) {
        var g = v.ensureState("emphasis");
        g.ignore == null && (g.ignore = false);
      }
      v.ignore = true;
    }
    for (var r = 0; r < i.length; r++) {
      var a = i[r], o = a.axisAligned, s = a.localRect, l = a.transform, u = a.label, h = a.labelLine;
      e.copy(a.rect), e.width -= 0.1, e.height -= 0.1, e.x += 0.05, e.y += 0.05;
      for (var c = a.obb, d = false, p = 0; p < t.length; p++) {
        var f = t[p];
        if (e.intersect(f.rect)) {
          if (o && f.axisAligned) {
            d = true;
            break;
          }
          if (f.obb || (f.obb = new te(f.localRect, f.transform)), c || (c = new te(s, l)), c.intersect(f.obb)) {
            d = true;
            break;
          }
        }
      }
      d ? (n(u), h && n(h)) : (u.attr("ignore", a.defaultAttr.ignore), h && h.attr("ignore", a.defaultAttr.labelGuideIgnore), t.push(a));
    }
  }
  var Un = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.type = "grid", t.dependencies = [
      "xAxis",
      "yAxis"
    ], t.layoutMode = "box", t.defaultOption = {
      show: false,
      z: 0,
      left: "10%",
      top: 60,
      right: "10%",
      bottom: 70,
      containLabel: false,
      backgroundColor: "rgba(0,0,0,0)",
      borderWidth: 1,
      borderColor: "#ccc"
    }, t;
  })(ct), ae = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.prototype.getCoordSysModel = function() {
      return this.getReferringComponents("grid", tt).models[0];
    }, t.type = "cartesian2dAxis", t;
  })(ct);
  Hr(ae, jr);
  var Ki = {
    show: true,
    z: 0,
    inverse: false,
    name: "",
    nameLocation: "end",
    nameRotate: null,
    nameTruncate: {
      maxWidth: null,
      ellipsis: "...",
      placeholder: "."
    },
    nameTextStyle: {},
    nameGap: 15,
    silent: false,
    triggerEvent: false,
    tooltip: {
      show: false
    },
    axisPointer: {},
    axisLine: {
      show: true,
      onZero: true,
      onZeroAxisIndex: null,
      lineStyle: {
        color: "#6E7079",
        width: 1,
        type: "solid"
      },
      symbol: [
        "none",
        "none"
      ],
      symbolSize: [
        10,
        15
      ]
    },
    axisTick: {
      show: true,
      inside: false,
      length: 5,
      lineStyle: {
        width: 1
      }
    },
    axisLabel: {
      show: true,
      inside: false,
      rotate: 0,
      showMinLabel: null,
      showMaxLabel: null,
      margin: 8,
      fontSize: 12
    },
    splitLine: {
      show: true,
      showMinLine: true,
      showMaxLine: true,
      lineStyle: {
        color: [
          "#E0E6F1"
        ],
        width: 1,
        type: "solid"
      }
    },
    splitArea: {
      show: false,
      areaStyle: {
        color: [
          "rgba(250,250,250,0.2)",
          "rgba(210,219,238,0.2)"
        ]
      }
    }
  }, Kn = P({
    boundaryGap: true,
    deduplication: null,
    splitLine: {
      show: false
    },
    axisTick: {
      alignWithLabel: false,
      interval: "auto"
    },
    axisLabel: {
      interval: "auto"
    }
  }, Ki), _e = P({
    boundaryGap: [
      0,
      0
    ],
    axisLine: {
      show: "auto"
    },
    axisTick: {
      show: "auto"
    },
    splitNumber: 5,
    minorTick: {
      show: false,
      splitNumber: 5,
      length: 3,
      lineStyle: {}
    },
    minorSplitLine: {
      show: false,
      lineStyle: {
        color: "#F4F7FD",
        width: 1
      }
    }
  }, Ki), qn = P({
    splitNumber: 6,
    axisLabel: {
      showMinLabel: false,
      showMaxLabel: false,
      rich: {
        primary: {
          fontWeight: "bold"
        }
      }
    },
    splitLine: {
      show: false
    }
  }, _e), Qn = V({
    logBase: 10
  }, _e);
  const Jn = {
    category: Kn,
    value: _e,
    time: qn,
    log: Qn
  };
  var ta = {
    value: 1,
    category: 1,
    time: 1,
    log: 1
  };
  function Ye(i, t, e, n) {
    y(ta, function(r, a) {
      var o = P(P({}, Jn[a], true), n, true), s = (function(l) {
        C(u, l);
        function u() {
          var h = l !== null && l.apply(this, arguments) || this;
          return h.type = t + "Axis." + a, h;
        }
        return u.prototype.mergeDefaultAndTheme = function(h, c) {
          var d = Vr(this), p = d ? Wr(h) : {}, f = c.getTheme();
          P(h, f.get(a + "Axis")), P(h, this.getDefaultOption()), h.type = Ge(h), d && Nr(h, p, d);
        }, u.prototype.optionUpdated = function() {
          var h = this.option;
          h.type === "category" && (this.__ordinalMeta = Yr.createByAxisModel(this));
        }, u.prototype.getCategories = function(h) {
          var c = this.option;
          if (c.type === "category") return h ? c.data : this.__ordinalMeta.categories;
        }, u.prototype.getOrdinalMeta = function() {
          return this.__ordinalMeta;
        }, u.type = t + "Axis." + a, u.defaultOption = o, u;
      })(e);
      i.registerComponentModel(s);
    }), i.registerSubTypeDefaulter(t + "Axis", Ge);
  }
  function Ge(i) {
    return i.type || (i.data ? "category" : "value");
  }
  var ea = (function() {
    function i(t) {
      this.type = "cartesian", this._dimList = [], this._axes = {}, this.name = t || "";
    }
    return i.prototype.getAxis = function(t) {
      return this._axes[t];
    }, i.prototype.getAxes = function() {
      return H(this._dimList, function(t) {
        return this._axes[t];
      }, this);
    }, i.prototype.getAxesByScale = function(t) {
      return t = t.toLowerCase(), Hi(this.getAxes(), function(e) {
        return e.scale.type === t;
      });
    }, i.prototype.addAxis = function(t) {
      var e = t.dim;
      this._axes[e] = t, this._dimList.push(e);
    }, i;
  })(), oe = [
    "x",
    "y"
  ];
  function Fe(i) {
    return i.type === "interval" || i.type === "time";
  }
  var ia = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = "cartesian2d", e.dimensions = oe, e;
    }
    return t.prototype.calcAffineTransform = function() {
      this._transform = this._invTransform = null;
      var e = this.getAxis("x").scale, n = this.getAxis("y").scale;
      if (!(!Fe(e) || !Fe(n))) {
        var r = e.getExtent(), a = n.getExtent(), o = this.dataToPoint([
          r[0],
          a[0]
        ]), s = this.dataToPoint([
          r[1],
          a[1]
        ]), l = r[1] - r[0], u = a[1] - a[0];
        if (!(!l || !u)) {
          var h = (s[0] - o[0]) / l, c = (s[1] - o[1]) / u, d = o[0] - r[0] * h, p = o[1] - a[0] * c, f = this._transform = [
            h,
            0,
            0,
            c,
            d,
            p
          ];
          this._invTransform = Gr([], f);
        }
      }
    }, t.prototype.getBaseAxis = function() {
      return this.getAxesByScale("ordinal")[0] || this.getAxesByScale("time")[0] || this.getAxis("x");
    }, t.prototype.containPoint = function(e) {
      var n = this.getAxis("x"), r = this.getAxis("y");
      return n.contain(n.toLocalCoord(e[0])) && r.contain(r.toLocalCoord(e[1]));
    }, t.prototype.containData = function(e) {
      return this.getAxis("x").containData(e[0]) && this.getAxis("y").containData(e[1]);
    }, t.prototype.containZone = function(e, n) {
      var r = this.dataToPoint(e), a = this.dataToPoint(n), o = this.getArea(), s = new Rt(r[0], r[1], a[0] - r[0], a[1] - r[1]);
      return o.intersect(s);
    }, t.prototype.dataToPoint = function(e, n, r) {
      r = r || [];
      var a = e[0], o = e[1];
      if (this._transform && a != null && isFinite(a) && o != null && isFinite(o)) return mt(r, e, this._transform);
      var s = this.getAxis("x"), l = this.getAxis("y");
      return r[0] = s.toGlobalCoord(s.dataToCoord(a, n)), r[1] = l.toGlobalCoord(l.dataToCoord(o, n)), r;
    }, t.prototype.clampData = function(e, n) {
      var r = this.getAxis("x").scale, a = this.getAxis("y").scale, o = r.getExtent(), s = a.getExtent(), l = r.parse(e[0]), u = a.parse(e[1]);
      return n = n || [], n[0] = Math.min(Math.max(Math.min(o[0], o[1]), l), Math.max(o[0], o[1])), n[1] = Math.min(Math.max(Math.min(s[0], s[1]), u), Math.max(s[0], s[1])), n;
    }, t.prototype.pointToData = function(e, n) {
      var r = [];
      if (this._invTransform) return mt(r, e, this._invTransform);
      var a = this.getAxis("x"), o = this.getAxis("y");
      return r[0] = a.coordToData(a.toLocalCoord(e[0]), n), r[1] = o.coordToData(o.toLocalCoord(e[1]), n), r;
    }, t.prototype.getOtherAxis = function(e) {
      return this.getAxis(e.dim === "x" ? "y" : "x");
    }, t.prototype.getArea = function(e) {
      e = e || 0;
      var n = this.getAxis("x").getGlobalExtent(), r = this.getAxis("y").getGlobalExtent(), a = Math.min(n[0], n[1]) - e, o = Math.min(r[0], r[1]) - e, s = Math.max(n[0], n[1]) - a + e, l = Math.max(r[0], r[1]) - o + e;
      return new Rt(a, o, s, l);
    }, t;
  })(ea), ra = (function(i) {
    C(t, i);
    function t(e, n, r, a, o) {
      var s = i.call(this, e, n, r) || this;
      return s.index = 0, s.type = a || "value", s.position = o || "bottom", s;
    }
    return t.prototype.isHorizontal = function() {
      var e = this.position;
      return e === "top" || e === "bottom";
    }, t.prototype.getGlobalExtent = function(e) {
      var n = this.getExtent();
      return n[0] = this.toGlobalCoord(n[0]), n[1] = this.toGlobalCoord(n[1]), e && n[0] > n[1] && n.reverse(), n;
    }, t.prototype.pointToData = function(e, n) {
      return this.coordToData(this.toLocalCoord(e[this.dim === "x" ? 0 : 1]), n);
    }, t.prototype.setCategorySortInfo = function(e) {
      if (this.type !== "category") return false;
      this.model.option.categorySortInfo = e, this.scale.setSortInfo(e);
    }, t;
  })(Fr);
  function se(i, t, e) {
    e = e || {};
    var n = i.coordinateSystem, r = t.axis, a = {}, o = r.getAxesOnZeroOf()[0], s = r.position, l = o ? "onZero" : s, u = r.dim, h = n.getRect(), c = [
      h.x,
      h.x + h.width,
      h.y,
      h.y + h.height
    ], d = {
      left: 0,
      right: 1,
      top: 0,
      bottom: 1,
      onZero: 2
    }, p = t.get("offset") || 0, f = u === "x" ? [
      c[2] - p,
      c[3] + p
    ] : [
      c[0] - p,
      c[1] + p
    ];
    if (o) {
      var v = o.toGlobalCoord(o.dataToCoord(0));
      f[d.onZero] = Math.max(Math.min(v, f[1]), f[0]);
    }
    a.position = [
      u === "y" ? f[d[l]] : c[0],
      u === "x" ? f[d[l]] : c[3]
    ], a.rotation = Math.PI / 2 * (u === "x" ? 0 : 1);
    var g = {
      top: -1,
      bottom: 1,
      left: -1,
      right: 1
    };
    a.labelDirection = a.tickDirection = a.nameDirection = g[s], a.labelOffset = o ? f[d[s]] - f[d.onZero] : 0, t.get([
      "axisTick",
      "inside"
    ]) && (a.tickDirection = -a.tickDirection), Ct(e.labelInside, t.get([
      "axisLabel",
      "inside"
    ])) && (a.labelDirection = -a.labelDirection);
    var m = t.get([
      "axisLabel",
      "rotate"
    ]);
    return a.labelRotate = l === "top" ? -m : m, a.z2 = 1, a;
  }
  function Ze(i) {
    return i.get("coordinateSystem") === "cartesian2d";
  }
  function Xe(i) {
    var t = {
      xAxisModel: null,
      yAxisModel: null
    };
    return y(t, function(e, n) {
      var r = n.replace(/Model$/, ""), a = i.getReferringComponents(r, tt).models[0];
      t[n] = a;
    }), t;
  }
  var Zt = Math.log;
  function na(i, t, e) {
    var n = Zr.prototype, r = n.getTicks.call(e), a = n.getTicks.call(e, true), o = r.length - 1, s = n.getInterval.call(e), l = Xr(i, t), u = l.extent, h = l.fixMin, c = l.fixMax;
    if (i.type === "log") {
      var d = Zt(i.base);
      u = [
        Zt(u[0]) / d,
        Zt(u[1]) / d
      ];
    }
    i.setExtent(u[0], u[1]), i.calcNiceExtent({
      splitNumber: o,
      fixMin: h,
      fixMax: c
    });
    var p = n.getExtent.call(i);
    h && (u[0] = p[0]), c && (u[1] = p[1]);
    var f = n.getInterval.call(i), v = u[0], g = u[1];
    if (h && c) f = (g - v) / o;
    else if (h) for (g = u[0] + f * o; g < u[1] && isFinite(g) && isFinite(u[1]); ) f = Yt(f), g = u[0] + f * o;
    else if (c) for (v = u[1] - f * o; v > u[0] && isFinite(v) && isFinite(u[0]); ) f = Yt(f), v = u[1] - f * o;
    else {
      var m = i.getTicks().length - 1;
      m > o && (f = Yt(f));
      var _ = f * o;
      g = Math.ceil(u[1] / f) * f, v = Gt(g - _), v < 0 && u[0] >= 0 ? (v = 0, g = Gt(_)) : g > 0 && u[1] <= 0 && (g = 0, v = -Gt(_));
    }
    var x = (r[0].value - a[0].value) / s, b = (r[o].value - a[o].value) / s;
    n.setExtent.call(i, v + f * x, g + f * b), n.setInterval.call(i, f), (x || b) && n.setNiceExtent.call(i, v + f, g - f);
  }
  var aa = (function() {
    function i(t, e, n) {
      this.type = "grid", this._coordsMap = {}, this._coordsList = [], this._axesMap = {}, this._axesList = [], this.axisPointerEnabled = true, this.dimensions = oe, this._initCartesian(t, e, n), this.model = t;
    }
    return i.prototype.getRect = function() {
      return this._rect;
    }, i.prototype.update = function(t, e) {
      var n = this._axesMap;
      this._updateScale(t, this.model);
      function r(o) {
        var s, l = qr(o), u = l.length;
        if (u) {
          for (var h = [], c = u - 1; c >= 0; c--) {
            var d = +l[c], p = o[d], f = p.model, v = p.scale;
            ee(v) && f.get("alignTicks") && f.get("interval") == null ? h.push(p) : (Re(v, f), ee(v) && (s = p));
          }
          h.length && (s || (s = h.pop(), Re(s.scale, s.model)), y(h, function(g) {
            na(g.scale, g.model, s.scale);
          }));
        }
      }
      r(n.x), r(n.y);
      var a = {};
      y(n.x, function(o) {
        $e(n, "y", o, a);
      }), y(n.y, function(o) {
        $e(n, "x", o, a);
      }), this.resize(this.model, e);
    }, i.prototype.resize = function(t, e, n) {
      var r = t.getBoxLayoutParams(), a = !n && t.get("containLabel"), o = jt(r, {
        width: e.getWidth(),
        height: e.getHeight()
      });
      this._rect = o;
      var s = this._axesList;
      l(), a && (y(s, function(u) {
        if (!u.model.get([
          "axisLabel",
          "inside"
        ])) {
          var h = $r(u);
          if (h) {
            var c = u.isHorizontal() ? "height" : "width", d = u.model.get([
              "axisLabel",
              "margin"
            ]);
            o[c] -= h[c] + d, u.position === "top" ? o.y += h.height + d : u.position === "left" && (o.x += h.width + d);
          }
        }
      }), l()), y(this._coordsList, function(u) {
        u.calcAffineTransform();
      });
      function l() {
        y(s, function(u) {
          var h = u.isHorizontal(), c = h ? [
            0,
            o.width
          ] : [
            0,
            o.height
          ], d = u.inverse ? 1 : 0;
          u.setExtent(c[d], c[1 - d]), oa(u, h ? o.x : o.y);
        });
      }
    }, i.prototype.getAxis = function(t, e) {
      var n = this._axesMap[t];
      if (n != null) return n[e || 0];
    }, i.prototype.getAxes = function() {
      return this._axesList.slice();
    }, i.prototype.getCartesian = function(t, e) {
      if (t != null && e != null) {
        var n = "x" + t + "y" + e;
        return this._coordsMap[n];
      }
      et(t) && (e = t.yAxisIndex, t = t.xAxisIndex);
      for (var r = 0, a = this._coordsList; r < a.length; r++) if (a[r].getAxis("x").index === t || a[r].getAxis("y").index === e) return a[r];
    }, i.prototype.getCartesians = function() {
      return this._coordsList.slice();
    }, i.prototype.convertToPixel = function(t, e, n) {
      var r = this._findConvertTarget(e);
      return r.cartesian ? r.cartesian.dataToPoint(n) : r.axis ? r.axis.toGlobalCoord(r.axis.dataToCoord(n)) : null;
    }, i.prototype.convertFromPixel = function(t, e, n) {
      var r = this._findConvertTarget(e);
      return r.cartesian ? r.cartesian.pointToData(n) : r.axis ? r.axis.coordToData(r.axis.toLocalCoord(n)) : null;
    }, i.prototype._findConvertTarget = function(t) {
      var e = t.seriesModel, n = t.xAxisModel || e && e.getReferringComponents("xAxis", tt).models[0], r = t.yAxisModel || e && e.getReferringComponents("yAxis", tt).models[0], a = t.gridModel, o = this._coordsList, s, l;
      if (e) s = e.coordinateSystem, F(o, s) < 0 && (s = null);
      else if (n && r) s = this.getCartesian(n.componentIndex, r.componentIndex);
      else if (n) l = this.getAxis("x", n.componentIndex);
      else if (r) l = this.getAxis("y", r.componentIndex);
      else if (a) {
        var u = a.coordinateSystem;
        u === this && (s = this._coordsList[0]);
      }
      return {
        cartesian: s,
        axis: l
      };
    }, i.prototype.containPoint = function(t) {
      var e = this._coordsList[0];
      if (e) return e.containPoint(t);
    }, i.prototype._initCartesian = function(t, e, n) {
      var r = this, a = this, o = {
        left: false,
        right: false,
        top: false,
        bottom: false
      }, s = {
        x: {},
        y: {}
      }, l = {
        x: 0,
        y: 0
      };
      if (e.eachComponent("xAxis", u("x"), this), e.eachComponent("yAxis", u("y"), this), !l.x || !l.y) {
        this._axesMap = {}, this._axesList = [];
        return;
      }
      this._axesMap = s, y(s.x, function(h, c) {
        y(s.y, function(d, p) {
          var f = "x" + c + "y" + p, v = new ia(f);
          v.master = r, v.model = t, r._coordsMap[f] = v, r._coordsList.push(v), v.addAxis(h), v.addAxis(d);
        });
      });
      function u(h) {
        return function(c, d) {
          if (Xt(c, t)) {
            var p = c.get("position");
            h === "x" ? p !== "top" && p !== "bottom" && (p = o.bottom ? "top" : "bottom") : p !== "left" && p !== "right" && (p = o.left ? "right" : "left"), o[p] = true;
            var f = new ra(h, Ur(c), [
              0,
              0
            ], c.get("type"), p), v = f.type === "category";
            f.onBand = v && c.get("boundaryGap"), f.inverse = c.get("inverse"), c.axis = f, f.model = c, f.grid = a, f.index = d, a._axesList.push(f), s[h][d] = f, l[h]++;
          }
        };
      }
    }, i.prototype._updateScale = function(t, e) {
      y(this._axesList, function(r) {
        if (r.scale.setExtent(1 / 0, -1 / 0), r.type === "category") {
          var a = r.model.get("categorySortInfo");
          r.scale.setSortInfo(a);
        }
      }), t.eachSeries(function(r) {
        if (Ze(r)) {
          var a = Xe(r), o = a.xAxisModel, s = a.yAxisModel;
          if (!Xt(o, e) || !Xt(s, e)) return;
          var l = this.getCartesian(o.componentIndex, s.componentIndex), u = r.getData(), h = l.getAxis("x"), c = l.getAxis("y");
          n(u, h), n(u, c);
        }
      }, this);
      function n(r, a) {
        y(Kr(r, a.dim), function(o) {
          a.scale.unionExtentFromData(r, o);
        });
      }
    }, i.prototype.getTooltipAxes = function(t) {
      var e = [], n = [];
      return y(this.getCartesians(), function(r) {
        var a = t != null && t !== "auto" ? r.getAxis(t) : r.getBaseAxis(), o = r.getOtherAxis(a);
        F(e, a) < 0 && e.push(a), F(n, o) < 0 && n.push(o);
      }), {
        baseAxes: e,
        otherAxes: n
      };
    }, i.create = function(t, e) {
      var n = [];
      return t.eachComponent("grid", function(r, a) {
        var o = new i(r, t, e);
        o.name = "grid_" + a, o.resize(r, e, true), r.coordinateSystem = o, n.push(o);
      }), t.eachSeries(function(r) {
        if (Ze(r)) {
          var a = Xe(r), o = a.xAxisModel, s = a.yAxisModel, l = o.getCoordSysModel(), u = l.coordinateSystem;
          r.coordinateSystem = u.getCartesian(o.componentIndex, s.componentIndex);
        }
      }), n;
    }, i.dimensions = oe, i;
  })();
  function Xt(i, t) {
    return i.getCoordSysModel() === t;
  }
  function $e(i, t, e, n) {
    e.getAxesOnZeroOf = function() {
      return a ? [
        a
      ] : [];
    };
    var r = i[t], a, o = e.model, s = o.get([
      "axisLine",
      "onZero"
    ]), l = o.get([
      "axisLine",
      "onZeroAxisIndex"
    ]);
    if (!s) return;
    if (l != null) Ue(r[l]) && (a = r[l]);
    else for (var u in r) if (r.hasOwnProperty(u) && Ue(r[u]) && !n[h(r[u])]) {
      a = r[u];
      break;
    }
    a && (n[h(a)] = true);
    function h(c) {
      return c.dim + "_" + c.index;
    }
  }
  function Ue(i) {
    return i && i.type !== "category" && i.type !== "time" && Qr(i);
  }
  function oa(i, t) {
    var e = i.getExtent(), n = e[0] + e[1];
    i.toGlobalCoord = i.dim === "x" ? function(r) {
      return r + t;
    } : function(r) {
      return n - r + t;
    }, i.toLocalCoord = i.dim === "x" ? function(r) {
      return r - t;
    } : function(r) {
      return n - r + t;
    };
  }
  var Q = Math.PI, J = (function() {
    function i(t, e) {
      this.group = new st(), this.opt = e, this.axisModel = t, V(e, {
        labelOffset: 0,
        nameDirection: 1,
        tickDirection: 1,
        labelDirection: 1,
        silent: true,
        handleAutoShown: function() {
          return true;
        }
      });
      var n = new st({
        x: e.position[0],
        y: e.position[1],
        rotation: e.rotation
      });
      n.updateTransform(), this._transformGroup = n;
    }
    return i.prototype.hasBuilder = function(t) {
      return !!Ke[t];
    }, i.prototype.add = function(t) {
      Ke[t](this.opt, this.axisModel, this.group, this._transformGroup);
    }, i.prototype.getGroup = function() {
      return this.group;
    }, i.innerTextLayout = function(t, e, n) {
      var r = ji(e - t), a, o;
      return Bt(r) ? (o = n > 0 ? "top" : "bottom", a = "center") : Bt(r - Q) ? (o = n > 0 ? "bottom" : "top", a = "center") : (o = "middle", r > 0 && r < Q ? a = n > 0 ? "right" : "left" : a = n > 0 ? "left" : "right"), {
        rotation: r,
        textAlign: a,
        textVerticalAlign: o
      };
    }, i.makeAxisEventDataBase = function(t) {
      var e = {
        componentType: t.mainType,
        componentIndex: t.componentIndex
      };
      return e[t.mainType + "Index"] = t.componentIndex, e;
    }, i.isLabelSilent = function(t) {
      var e = t.get("tooltip");
      return t.get("silent") || !(t.get("triggerEvent") || e && e.show);
    }, i;
  })(), Ke = {
    axisLine: function(i, t, e, n) {
      var r = t.get([
        "axisLine",
        "show"
      ]);
      if (r === "auto" && i.handleAutoShown && (r = i.handleAutoShown("axisLine")), !!r) {
        var a = t.axis.getExtent(), o = n.transform, s = [
          a[0],
          0
        ], l = [
          a[1],
          0
        ], u = s[0] > l[0];
        o && (mt(s, s, o), mt(l, l, o));
        var h = xt({
          lineCap: "round"
        }, t.getModel([
          "axisLine",
          "lineStyle"
        ]).getLineStyle()), c = new Ot({
          shape: {
            x1: s[0],
            y1: s[1],
            x2: l[0],
            y2: l[1]
          },
          style: h,
          strokeContainThreshold: i.strokeContainThreshold || 5,
          silent: true,
          z2: 1
        });
        Et(c.shape, c.style.lineWidth), c.anid = "line", e.add(c);
        var d = t.get([
          "axisLine",
          "symbol"
        ]);
        if (d != null) {
          var p = t.get([
            "axisLine",
            "symbolSize"
          ]);
          z(d) && (d = [
            d,
            d
          ]), (z(p) || nn(p)) && (p = [
            p,
            p
          ]);
          var f = Jr(t.get([
            "axisLine",
            "symbolOffset"
          ]) || 0, p), v = p[0], g = p[1];
          y([
            {
              rotate: i.rotation + Math.PI / 2,
              offset: f[0],
              r: 0
            },
            {
              rotate: i.rotation - Math.PI / 2,
              offset: f[1],
              r: Math.sqrt((s[0] - l[0]) * (s[0] - l[0]) + (s[1] - l[1]) * (s[1] - l[1]))
            }
          ], function(m, _) {
            if (d[_] !== "none" && d[_] != null) {
              var x = tn(d[_], -v / 2, -g / 2, v, g, h.stroke, true), b = m.r + m.offset, w = u ? l : s;
              x.attr({
                rotation: m.rotate,
                x: w[0] + b * Math.cos(i.rotation),
                y: w[1] - b * Math.sin(i.rotation),
                silent: true,
                z2: 11
              }), e.add(x);
            }
          });
        }
      }
    },
    axisTickLabel: function(i, t, e, n) {
      var r = ua(e, n, t, i), a = ca(e, n, t, i);
      if (la(t, a, r), ha(e, n, t, i.tickDirection), t.get([
        "axisLabel",
        "hideOverlap"
      ])) {
        var o = Xn(H(a, function(s) {
          return {
            label: s,
            priority: s.z2,
            defaultAttr: {
              ignore: s.ignore
            }
          };
        }));
        $n(o);
      }
    },
    axisName: function(i, t, e, n) {
      var r = Ct(i.axisName, t.get("name"));
      if (r) {
        var a = t.get("nameLocation"), o = i.nameDirection, s = t.getModel("nameTextStyle"), l = t.get("nameGap") || 0, u = t.axis.getExtent(), h = u[0] > u[1] ? -1 : 1, c = [
          a === "start" ? u[0] - h * l : a === "end" ? u[1] + h * l : (u[0] + u[1]) / 2,
          Qe(a) ? i.labelOffset + o * l : 0
        ], d, p = t.get("nameRotate");
        p != null && (p = p * Q / 180);
        var f;
        Qe(a) ? d = J.innerTextLayout(i.rotation, p ?? i.rotation, o) : (d = sa(i.rotation, a, p || 0, u), f = i.axisNameAvailableWidth, f != null && (f = Math.abs(f / Math.sin(d.rotation)), !isFinite(f) && (f = null)));
        var v = s.getFont(), g = t.get("nameTruncate", true) || {}, m = g.ellipsis, _ = Ct(i.nameTruncateMaxWidth, g.maxWidth, f), x = new it({
          x: c[0],
          y: c[1],
          rotation: d.rotation,
          silent: J.isLabelSilent(t),
          style: Mt(s, {
            text: r,
            font: v,
            overflow: "truncate",
            width: _,
            ellipsis: m,
            fill: s.getTextColor() || t.get([
              "axisLine",
              "lineStyle",
              "color"
            ]),
            align: s.get("align") || d.textAlign,
            verticalAlign: s.get("verticalAlign") || d.textVerticalAlign
          }),
          z2: 1
        });
        if (ye({
          el: x,
          componentModel: t,
          itemName: r
        }), x.__fullText = r, x.anid = "name", t.get("triggerEvent")) {
          var b = J.makeAxisEventDataBase(t);
          b.targetType = "axisName", b.name = r, Y(x).eventData = b;
        }
        n.add(x), x.updateTransform(), e.add(x), x.decomposeTransform();
      }
    }
  };
  function sa(i, t, e, n) {
    var r = ji(e - i), a, o, s = n[0] > n[1], l = t === "start" && !s || t !== "start" && s;
    return Bt(r - Q / 2) ? (o = l ? "bottom" : "top", a = "center") : Bt(r - Q * 1.5) ? (o = l ? "top" : "bottom", a = "center") : (o = "middle", r < Q * 1.5 && r > Q / 2 ? a = l ? "left" : "right" : a = l ? "right" : "left"), {
      rotation: r,
      textAlign: a,
      textVerticalAlign: o
    };
  }
  function la(i, t, e) {
    if (!en(i.axis)) {
      var n = i.get([
        "axisLabel",
        "showMinLabel"
      ]), r = i.get([
        "axisLabel",
        "showMaxLabel"
      ]);
      t = t || [], e = e || [];
      var a = t[0], o = t[1], s = t[t.length - 1], l = t[t.length - 2], u = e[0], h = e[1], c = e[e.length - 1], d = e[e.length - 2];
      n === false ? (W(a), W(u)) : qe(a, o) && (n ? (W(o), W(h)) : (W(a), W(u))), r === false ? (W(s), W(c)) : qe(l, s) && (r ? (W(l), W(d)) : (W(s), W(c)));
    }
  }
  function W(i) {
    i && (i.ignore = true);
  }
  function qe(i, t) {
    var e = i && i.getBoundingRect().clone(), n = t && t.getBoundingRect().clone();
    if (!(!e || !n)) {
      var r = rn([]);
      return Vi(r, r, -i.rotation), e.applyTransform(Oe([], r, i.getLocalTransform())), n.applyTransform(Oe([], r, t.getLocalTransform())), e.intersect(n);
    }
  }
  function Qe(i) {
    return i === "middle" || i === "center";
  }
  function qi(i, t, e, n, r) {
    for (var a = [], o = [], s = [], l = 0; l < i.length; l++) {
      var u = i[l].coord;
      o[0] = u, o[1] = 0, s[0] = u, s[1] = e, t && (mt(o, o, t), mt(s, s, t));
      var h = new Ot({
        shape: {
          x1: o[0],
          y1: o[1],
          x2: s[0],
          y2: s[1]
        },
        style: n,
        z2: 2,
        autoBatch: true,
        silent: true
      });
      Et(h.shape, h.style.lineWidth), h.anid = r + "_" + i[l].tickValue, a.push(h);
    }
    return a;
  }
  function ua(i, t, e, n) {
    var r = e.axis, a = e.getModel("axisTick"), o = a.get("show");
    if (o === "auto" && n.handleAutoShown && (o = n.handleAutoShown("axisTick")), !(!o || r.scale.isBlank())) {
      for (var s = a.getModel("lineStyle"), l = n.tickDirection * a.get("length"), u = r.getTicksCoords(), h = qi(u, t.transform, l, V(s.getLineStyle(), {
        stroke: e.get([
          "axisLine",
          "lineStyle",
          "color"
        ])
      }), "ticks"), c = 0; c < h.length; c++) i.add(h[c]);
      return h;
    }
  }
  function ha(i, t, e, n) {
    var r = e.axis, a = e.getModel("minorTick");
    if (!(!a.get("show") || r.scale.isBlank())) {
      var o = r.getMinorTicksCoords();
      if (o.length) for (var s = a.getModel("lineStyle"), l = n * a.get("length"), u = V(s.getLineStyle(), V(e.getModel("axisTick").getLineStyle(), {
        stroke: e.get([
          "axisLine",
          "lineStyle",
          "color"
        ])
      })), h = 0; h < o.length; h++) for (var c = qi(o[h], t.transform, l, u, "minorticks_" + h), d = 0; d < c.length; d++) i.add(c[d]);
    }
  }
  function ca(i, t, e, n) {
    var r = e.axis, a = Ct(n.axisLabelShow, e.get([
      "axisLabel",
      "show"
    ]));
    if (!(!a || r.scale.isBlank())) {
      var o = e.getModel("axisLabel"), s = o.get("margin"), l = r.getViewLabels(), u = (Ct(n.labelRotate, o.get("rotate")) || 0) * Q / 180, h = J.innerTextLayout(n.rotation, u, n.labelDirection), c = e.getCategories && e.getCategories(true), d = [], p = J.isLabelSilent(e), f = e.get("triggerEvent");
      return y(l, function(v, g) {
        var m = r.scale.type === "ordinal" ? r.scale.getRawOrdinalNumber(v.tickValue) : v.tickValue, _ = v.formattedLabel, x = v.rawLabel, b = o;
        if (c && c[m]) {
          var w = c[m];
          et(w) && w.textStyle && (b = new ot(w.textStyle, o, e.ecModel));
        }
        var T = b.getTextColor() || e.get([
          "axisLine",
          "lineStyle",
          "color"
        ]), A = r.dataToCoord(m), S = b.getShallow("align", true) || h.textAlign, L = vt(b.getShallow("alignMinLabel", true), S), D = vt(b.getShallow("alignMaxLabel", true), S), I = b.getShallow("verticalAlign", true) || b.getShallow("baseline", true) || h.textVerticalAlign, X = vt(b.getShallow("verticalAlignMinLabel", true), I), K = vt(b.getShallow("verticalAlignMaxLabel", true), I), R = new it({
          x: A,
          y: n.labelOffset + n.labelDirection * s,
          rotation: h.rotation,
          silent: p,
          z2: 10 + (v.level || 0),
          style: Mt(b, {
            text: _,
            align: g === 0 ? L : g === l.length - 1 ? D : S,
            verticalAlign: g === 0 ? X : g === l.length - 1 ? K : I,
            fill: rt(T) ? T(r.type === "category" ? x : r.type === "value" ? m + "" : m, g) : T
          })
        });
        if (R.anid = "label_" + m, ye({
          el: R,
          componentModel: e,
          itemName: _,
          formatterParamsExtra: {
            isTruncated: function() {
              return R.isTruncated;
            },
            value: x,
            tickIndex: g
          }
        }), f) {
          var wt = J.makeAxisEventDataBase(e);
          wt.targetType = "axisLabel", wt.value = x, wt.tickIndex = g, r.type === "category" && (wt.dataIndex = m), Y(R).eventData = wt;
        }
        t.add(R), R.updateTransform(), d.push(R), i.add(R), R.decomposeTransform();
      }), d;
    }
  }
  function fa(i, t) {
    var e = {
      axesInfo: {},
      seriesInvolved: false,
      coordSysAxesInfo: {},
      coordSysMap: {}
    };
    return da(e, i, t), e.seriesInvolved && va(e, i), e;
  }
  function da(i, t, e) {
    var n = t.getComponent("tooltip"), r = t.getComponent("axisPointer"), a = r.get("link", true) || [], o = [];
    y(e.getCoordinateSystems(), function(s) {
      if (!s.axisPointerEnabled) return;
      var l = Dt(s.model), u = i.coordSysAxesInfo[l] = {};
      i.coordSysMap[l] = s;
      var h = s.model, c = h.getModel("tooltip", n);
      if (y(s.getAxes(), k(v, false, null)), s.getTooltipAxes && n && c.get("show")) {
        var d = c.get("trigger") === "axis", p = c.get([
          "axisPointer",
          "type"
        ]) === "cross", f = s.getTooltipAxes(c.get([
          "axisPointer",
          "axis"
        ]));
        (d || p) && y(f.baseAxes, k(v, p ? "cross" : true, d)), p && y(f.otherAxes, k(v, "cross", false));
      }
      function v(g, m, _) {
        var x = _.model.getModel("axisPointer", r), b = x.get("show");
        if (!(!b || b === "auto" && !g && !le(x))) {
          m == null && (m = x.get("triggerTooltip")), x = g ? pa(_, c, r, t, g, m) : x;
          var w = x.get("snap"), T = x.get("triggerEmphasis"), A = Dt(_.model), S = m || w || _.type === "category", L = i.axesInfo[A] = {
            key: A,
            axis: _,
            coordSys: s,
            axisPointerModel: x,
            triggerTooltip: m,
            triggerEmphasis: T,
            involveSeries: S,
            snap: w,
            useHandle: le(x),
            seriesModels: [],
            linkGroup: null
          };
          u[A] = L, i.seriesInvolved = i.seriesInvolved || S;
          var D = ga(a, _);
          if (D != null) {
            var I = o[D] || (o[D] = {
              axesInfo: {}
            });
            I.axesInfo[A] = L, I.mapper = a[D].mapper, L.linkGroup = I;
          }
        }
      }
    });
  }
  function pa(i, t, e, n, r, a) {
    var o = t.getModel("axisPointer"), s = [
      "type",
      "snap",
      "lineStyle",
      "shadowStyle",
      "label",
      "animation",
      "animationDurationUpdate",
      "animationEasingUpdate",
      "z"
    ], l = {};
    y(s, function(d) {
      l[d] = N(o.get(d));
    }), l.snap = i.type !== "category" && !!a, o.get("type") === "cross" && (l.type = "line");
    var u = l.label || (l.label = {});
    if (u.show == null && (u.show = false), r === "cross") {
      var h = o.get([
        "label",
        "show"
      ]);
      if (u.show = h ?? true, !a) {
        var c = l.lineStyle = o.get("crossStyle");
        c && V(u, c.textStyle);
      }
    }
    return i.model.getModel("axisPointer", new ot(l, e, n));
  }
  function va(i, t) {
    t.eachSeries(function(e) {
      var n = e.coordinateSystem, r = e.get([
        "tooltip",
        "trigger"
      ], true), a = e.get([
        "tooltip",
        "show"
      ], true);
      !n || r === "none" || r === false || r === "item" || a === false || e.get([
        "axisPointer",
        "show"
      ], true) === false || y(i.coordSysAxesInfo[Dt(n.model)], function(o) {
        var s = o.axis;
        n.getAxis(s.dim) === s && (o.seriesModels.push(e), o.seriesDataCount == null && (o.seriesDataCount = 0), o.seriesDataCount += e.getData().count());
      });
    });
  }
  function ga(i, t) {
    for (var e = t.model, n = t.dim, r = 0; r < i.length; r++) {
      var a = i[r] || {};
      if ($t(a[n + "AxisId"], e.id) || $t(a[n + "AxisIndex"], e.componentIndex) || $t(a[n + "AxisName"], e.name)) return r;
    }
  }
  function $t(i, t) {
    return i === "all" || j(i) && F(i, t) >= 0 || i === t;
  }
  function ma(i) {
    var t = we(i);
    if (t) {
      var e = t.axisPointerModel, n = t.axis.scale, r = e.option, a = e.get("status"), o = e.get("value");
      o != null && (o = n.parse(o));
      var s = le(e);
      a == null && (r.status = s ? "show" : "hide");
      var l = n.getExtent().slice();
      l[0] > l[1] && l.reverse(), (o == null || o > l[1]) && (o = l[1]), o < l[0] && (o = l[0]), r.value = o, s && (r.status = t.axis.scale.isBlank() ? "hide" : "show");
    }
  }
  function we(i) {
    var t = (i.ecModel.getComponent("axisPointer") || {}).coordSysAxesInfo;
    return t && t.axesInfo[Dt(i)];
  }
  function xa(i) {
    var t = we(i);
    return t && t.axisPointerModel;
  }
  function le(i) {
    return !!i.get([
      "handle",
      "show"
    ]);
  }
  function Dt(i) {
    return i.type + "||" + i.id;
  }
  var Je = {}, Qi = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.prototype.render = function(e, n, r, a) {
      this.axisPointerClass && ma(e), i.prototype.render.apply(this, arguments), this._doUpdateAxisPointerClass(e, r, true);
    }, t.prototype.updateAxisPointer = function(e, n, r, a) {
      this._doUpdateAxisPointerClass(e, r, false);
    }, t.prototype.remove = function(e, n) {
      var r = this._axisPointer;
      r && r.remove(n);
    }, t.prototype.dispose = function(e, n) {
      this._disposeAxisPointer(n), i.prototype.dispose.apply(this, arguments);
    }, t.prototype._doUpdateAxisPointerClass = function(e, n, r) {
      var a = t.getAxisPointerClass(this.axisPointerClass);
      if (a) {
        var o = xa(e);
        o ? (this._axisPointer || (this._axisPointer = new a())).render(e, o, n, r) : this._disposeAxisPointer(n);
      }
    }, t.prototype._disposeAxisPointer = function(e) {
      this._axisPointer && this._axisPointer.dispose(e), this._axisPointer = null;
    }, t.registerAxisPointerClass = function(e, n) {
      Je[e] = n;
    }, t.getAxisPointerClass = function(e) {
      return e && Je[e];
    }, t.type = "axis", t;
  })(ft), ue = kt();
  function ya(i, t, e, n) {
    var r = e.axis;
    if (!r.scale.isBlank()) {
      var a = e.getModel("splitArea"), o = a.getModel("areaStyle"), s = o.get("color"), l = n.coordinateSystem.getRect(), u = r.getTicksCoords({
        tickModel: a,
        clamp: true
      });
      if (u.length) {
        var h = s.length, c = ue(i).splitAreaColors, d = yt(), p = 0;
        if (c) for (var f = 0; f < u.length; f++) {
          var v = c.get(u[f].tickValue);
          if (v != null) {
            p = (v + (h - 1) * f) % h;
            break;
          }
        }
        var g = r.toGlobalCoord(u[0].coord), m = o.getAreaStyle();
        s = j(s) ? s : [
          s
        ];
        for (var f = 1; f < u.length; f++) {
          var _ = r.toGlobalCoord(u[f].coord), x = void 0, b = void 0, w = void 0, T = void 0;
          r.isHorizontal() ? (x = g, b = l.y, w = _ - x, T = l.height, g = x + w) : (x = l.x, b = g, w = l.width, T = _ - b, g = b + T);
          var A = u[f - 1].tickValue;
          A != null && d.set(A, p), t.add(new lt({
            anid: A != null ? "area_" + A : null,
            shape: {
              x,
              y: b,
              width: w,
              height: T
            },
            style: V({
              fill: s[p]
            }, m),
            autoBatch: true,
            silent: true
          })), p = (p + 1) % h;
        }
        ue(i).splitAreaColors = d;
      }
    }
  }
  function ba(i) {
    ue(i).splitAreaColors = null;
  }
  var _a = [
    "axisLine",
    "axisTickLabel",
    "axisName"
  ], wa = [
    "splitArea",
    "splitLine",
    "minorSplitLine"
  ], Ji = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e.axisPointerClass = "CartesianAxisPointer", e;
    }
    return t.prototype.render = function(e, n, r, a) {
      this.group.removeAll();
      var o = this._axisGroup;
      if (this._axisGroup = new st(), this.group.add(this._axisGroup), !!e.get("show")) {
        var s = e.getCoordSysModel(), l = se(s, e), u = new J(e, xt({
          handleAutoShown: function(c) {
            for (var d = s.coordinateSystem.getCartesians(), p = 0; p < d.length; p++) if (ee(d[p].getOtherAxis(e.axis).scale)) return true;
            return false;
          }
        }, l));
        y(_a, u.add, u), this._axisGroup.add(u.getGroup()), y(wa, function(c) {
          e.get([
            c,
            "show"
          ]) && Ta[c](this, this._axisGroup, e, s);
        }, this);
        var h = a && a.type === "changeAxisOrder" && a.isInitSort;
        h || an(o, this._axisGroup, e), i.prototype.render.call(this, e, n, r, a);
      }
    }, t.prototype.remove = function() {
      ba(this);
    }, t.type = "cartesianAxis", t;
  })(Qi), Ta = {
    splitLine: function(i, t, e, n) {
      var r = e.axis;
      if (!r.scale.isBlank()) {
        var a = e.getModel("splitLine"), o = a.getModel("lineStyle"), s = o.get("color"), l = a.get("showMinLine") !== false, u = a.get("showMaxLine") !== false;
        s = j(s) ? s : [
          s
        ];
        for (var h = n.coordinateSystem.getRect(), c = r.isHorizontal(), d = 0, p = r.getTicksCoords({
          tickModel: a
        }), f = [], v = [], g = o.getLineStyle(), m = 0; m < p.length; m++) {
          var _ = r.toGlobalCoord(p[m].coord);
          if (!(m === 0 && !l || m === p.length - 1 && !u)) {
            var x = p[m].tickValue;
            c ? (f[0] = _, f[1] = h.y, v[0] = _, v[1] = h.y + h.height) : (f[0] = h.x, f[1] = _, v[0] = h.x + h.width, v[1] = _);
            var b = d++ % s.length, w = new Ot({
              anid: x != null ? "line_" + x : null,
              autoBatch: true,
              shape: {
                x1: f[0],
                y1: f[1],
                x2: v[0],
                y2: v[1]
              },
              style: V({
                stroke: s[b]
              }, g),
              silent: true
            });
            Et(w.shape, g.lineWidth), t.add(w);
          }
        }
      }
    },
    minorSplitLine: function(i, t, e, n) {
      var r = e.axis, a = e.getModel("minorSplitLine"), o = a.getModel("lineStyle"), s = n.coordinateSystem.getRect(), l = r.isHorizontal(), u = r.getMinorTicksCoords();
      if (u.length) for (var h = [], c = [], d = o.getLineStyle(), p = 0; p < u.length; p++) for (var f = 0; f < u[p].length; f++) {
        var v = r.toGlobalCoord(u[p][f].coord);
        l ? (h[0] = v, h[1] = s.y, c[0] = v, c[1] = s.y + s.height) : (h[0] = s.x, h[1] = v, c[0] = s.x + s.width, c[1] = v);
        var g = new Ot({
          anid: "minor_line_" + u[p][f].tickValue,
          autoBatch: true,
          shape: {
            x1: h[0],
            y1: h[1],
            x2: c[0],
            y2: c[1]
          },
          style: d,
          silent: true
        });
        Et(g.shape, d.lineWidth), t.add(g);
      }
    },
    splitArea: function(i, t, e, n) {
      ya(i, t, e, n);
    }
  }, tr = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.type = "xAxis", t;
  })(Ji), Aa = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = tr.type, e;
    }
    return t.type = "yAxis", t;
  })(Ji), Sa = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = "grid", e;
    }
    return t.prototype.render = function(e, n) {
      this.group.removeAll(), e.get("show") && this.group.add(new lt({
        shape: e.coordinateSystem.getRect(),
        style: V({
          fill: e.get("backgroundColor")
        }, e.getItemStyle()),
        silent: true,
        z2: -1
      }));
    }, t.type = "grid", t;
  })(ft), ti = {
    offset: 0
  };
  function Ca(i) {
    i.registerComponentView(Sa), i.registerComponentModel(Un), i.registerCoordinateSystem("cartesian2d", aa), Ye(i, "x", ae, ti), Ye(i, "y", ae, ti), i.registerComponentView(tr), i.registerComponentView(Aa), i.registerPreprocessor(function(t) {
      t.xAxis && t.yAxis && !t.grid && (t.grid = {});
    });
  }
  var ei = "\0_ec_interaction_mutex";
  function Ma(i, t, e) {
    var n = er(i);
    n[t] = e;
  }
  function La(i, t, e) {
    var n = er(i), r = n[t];
    r === e && (n[t] = null);
  }
  function er(i) {
    return i[ei] || (i[ei] = {});
  }
  Vt({
    type: "takeGlobalCursor",
    event: "globalCursorTaken",
    update: "update"
  }, ie);
  var Da = {
    axisPointer: 1,
    tooltip: 1,
    brush: 1
  };
  function Ia(i, t, e) {
    var n = t.getComponentByElement(i.topTarget), r = n && n.coordinateSystem;
    return n && n !== e && !Da.hasOwnProperty(n.mainType) && r && r.model !== e;
  }
  function ir(i, t, e, n, r, a) {
    i = i || 0;
    var o = e[1] - e[0];
    if (r != null && (r = dt(r, [
      0,
      o
    ])), a != null && (a = Math.max(a, r ?? 0)), n === "all") {
      var s = Math.abs(t[1] - t[0]);
      s = dt(s, [
        0,
        o
      ]), r = a = dt(s, [
        r,
        a
      ]), n = 0;
    }
    t[0] = dt(t[0], e), t[1] = dt(t[1], e);
    var l = Ut(t, n);
    t[n] += i;
    var u = r || 0, h = e.slice();
    l.sign < 0 ? h[0] += u : h[1] -= u, t[n] = dt(t[n], h);
    var c;
    return c = Ut(t, n), r != null && (c.sign !== l.sign || c.span < r) && (t[1 - n] = t[n] + l.sign * r), c = Ut(t, n), a != null && c.span > a && (t[1 - n] = t[n] + c.sign * a), t;
  }
  function Ut(i, t) {
    var e = i[t] - i[1 - t];
    return {
      span: Math.abs(e),
      sign: e > 0 ? -1 : e < 0 ? 1 : t ? -1 : 1
    };
  }
  function dt(i, t) {
    return Math.min(t[1] != null ? t[1] : 1 / 0, Math.max(t[0] != null ? t[0] : -1 / 0, i));
  }
  var ut = true, It = Math.min, bt = Math.max, ka = Math.pow, Pa = 1e4, Ra = 6, Oa = 6, ii = "globalPan", Ea = {
    w: [
      0,
      0
    ],
    e: [
      0,
      1
    ],
    n: [
      1,
      0
    ],
    s: [
      1,
      1
    ]
  }, Ba = {
    w: "ew",
    e: "ew",
    n: "ns",
    s: "ns",
    ne: "nesw",
    sw: "nesw",
    nw: "nwse",
    se: "nwse"
  }, ri = {
    brushStyle: {
      lineWidth: 2,
      stroke: "rgba(210,219,238,0.3)",
      fill: "#D2DBEE"
    },
    transformable: true,
    brushMode: "single",
    removeOnClick: false
  }, za = 0, Ha = (function(i) {
    C(t, i);
    function t(e) {
      var n = i.call(this) || this;
      return n._track = [], n._covers = [], n._handlers = {}, n._zr = e, n.group = new st(), n._uid = "brushController_" + za++, y(Fa, function(r, a) {
        this._handlers[a] = Z(r, this);
      }, n), n;
    }
    return t.prototype.enableBrush = function(e) {
      return this._brushType && this._doDisableBrush(), e.brushType && this._doEnableBrush(e), this;
    }, t.prototype._doEnableBrush = function(e) {
      var n = this._zr;
      this._enableGlobalPan || Ma(n, ii, this._uid), y(this._handlers, function(r, a) {
        n.on(a, r);
      }), this._brushType = e.brushType, this._brushOption = P(N(ri), e, true);
    }, t.prototype._doDisableBrush = function() {
      var e = this._zr;
      La(e, ii, this._uid), y(this._handlers, function(n, r) {
        e.off(r, n);
      }), this._brushType = this._brushOption = null;
    }, t.prototype.setPanels = function(e) {
      if (e && e.length) {
        var n = this._panels = {};
        y(e, function(r) {
          n[r.panelId] = N(r);
        });
      } else this._panels = null;
      return this;
    }, t.prototype.mount = function(e) {
      e = e || {}, this._enableGlobalPan = e.enableGlobalPan;
      var n = this.group;
      return this._zr.add(n), n.attr({
        x: e.x || 0,
        y: e.y || 0,
        rotation: e.rotation || 0,
        scaleX: e.scaleX || 1,
        scaleY: e.scaleY || 1
      }), this._transform = n.getLocalTransform(), this;
    }, t.prototype.updateCovers = function(e) {
      e = H(e, function(d) {
        return P(N(ri), d, true);
      });
      var n = "\0-brush-index-", r = this._covers, a = this._covers = [], o = this, s = this._creatingCover;
      return new Wi(r, e, u, l).add(h).update(h).remove(c).execute(), this;
      function l(d, p) {
        return (d.id != null ? d.id : n + p) + "-" + d.brushType;
      }
      function u(d, p) {
        return l(d.__brushOption, p);
      }
      function h(d, p) {
        var f = e[d];
        if (p != null && r[p] === s) a[d] = r[p];
        else {
          var v = a[d] = p != null ? (r[p].__brushOption = f, r[p]) : nr(o, rr(o, f));
          Te(o, v);
        }
      }
      function c(d) {
        r[d] !== s && o.group.remove(r[d]);
      }
    }, t.prototype.unmount = function() {
      return this.enableBrush(false), he(this), this._zr.remove(this.group), this;
    }, t.prototype.dispose = function() {
      this.unmount(), this.off();
    }, t;
  })(on);
  function rr(i, t) {
    var e = Wt[t.brushType].createCover(i, t);
    return e.__brushOption = t, or(e, t), i.group.add(e), e;
  }
  function nr(i, t) {
    var e = Ae(t);
    return e.endCreating && (e.endCreating(i, t), or(t, t.__brushOption)), t;
  }
  function ar(i, t) {
    var e = t.__brushOption;
    Ae(t).updateCoverShape(i, t, e.range, e);
  }
  function or(i, t) {
    var e = t.z;
    e == null && (e = Pa), i.traverse(function(n) {
      n.z = e, n.z2 = e;
    });
  }
  function Te(i, t) {
    Ae(t).updateCommon(i, t), ar(i, t);
  }
  function Ae(i) {
    return Wt[i.__brushOption.brushType];
  }
  function Se(i, t, e) {
    var n = i._panels;
    if (!n) return ut;
    var r, a = i._transform;
    return y(n, function(o) {
      o.isTargetByCursor(t, e, a) && (r = o);
    }), r;
  }
  function sr(i, t) {
    var e = i._panels;
    if (!e) return ut;
    var n = t.__brushOption.panelId;
    return n != null ? e[n] : ut;
  }
  function he(i) {
    var t = i._covers, e = t.length;
    return y(t, function(n) {
      i.group.remove(n);
    }, i), t.length = 0, !!e;
  }
  function ht(i, t) {
    var e = H(i._covers, function(n) {
      var r = n.__brushOption, a = N(r.range);
      return {
        brushType: r.brushType,
        panelId: r.panelId,
        range: a
      };
    });
    i.trigger("brush", {
      areas: e,
      isEnd: !!t.isEnd,
      removeOnClick: !!t.removeOnClick
    });
  }
  function ja(i) {
    var t = i._track;
    if (!t.length) return false;
    var e = t[t.length - 1], n = t[0], r = e[0] - n[0], a = e[1] - n[1], o = ka(r * r + a * a, 0.5);
    return o > Ra;
  }
  function lr(i) {
    var t = i.length - 1;
    return t < 0 && (t = 0), [
      i[0],
      i[t]
    ];
  }
  function ur(i, t, e, n) {
    var r = new st();
    return r.add(new lt({
      name: "main",
      style: Ce(e),
      silent: true,
      draggable: true,
      cursor: "move",
      drift: k(ni, i, t, r, [
        "n",
        "s",
        "w",
        "e"
      ]),
      ondragend: k(ht, t, {
        isEnd: true
      })
    })), y(n, function(a) {
      r.add(new lt({
        name: a.join(""),
        style: {
          opacity: 0
        },
        draggable: true,
        silent: true,
        invisible: true,
        drift: k(ni, i, t, r, a),
        ondragend: k(ht, t, {
          isEnd: true
        })
      }));
    }), r;
  }
  function hr(i, t, e, n) {
    var r = n.brushStyle.lineWidth || 0, a = bt(r, Oa), o = e[0][0], s = e[1][0], l = o - r / 2, u = s - r / 2, h = e[0][1], c = e[1][1], d = h - a + r / 2, p = c - a + r / 2, f = h - o, v = c - s, g = f + r, m = v + r;
    $(i, t, "main", o, s, f, v), n.transformable && ($(i, t, "w", l, u, a, m), $(i, t, "e", d, u, a, m), $(i, t, "n", l, u, g, a), $(i, t, "s", l, p, g, a), $(i, t, "nw", l, u, a, a), $(i, t, "ne", d, u, a, a), $(i, t, "sw", l, p, a, a), $(i, t, "se", d, p, a, a));
  }
  function ce(i, t) {
    var e = t.__brushOption, n = e.transformable, r = t.childAt(0);
    r.useStyle(Ce(e)), r.attr({
      silent: !n,
      cursor: n ? "move" : "default"
    }), y([
      [
        "w"
      ],
      [
        "e"
      ],
      [
        "n"
      ],
      [
        "s"
      ],
      [
        "s",
        "e"
      ],
      [
        "s",
        "w"
      ],
      [
        "n",
        "e"
      ],
      [
        "n",
        "w"
      ]
    ], function(a) {
      var o = t.childOfName(a.join("")), s = a.length === 1 ? fe(i, a[0]) : Wa(i, a);
      o && o.attr({
        silent: !n,
        invisible: !n,
        cursor: n ? Ba[s] + "-resize" : null
      });
    });
  }
  function $(i, t, e, n, r, a, o) {
    var s = t.childOfName(e);
    s && s.setShape(Ya(Me(i, t, [
      [
        n,
        r
      ],
      [
        n + a,
        r + o
      ]
    ])));
  }
  function Ce(i) {
    return V({
      strokeNoScale: true
    }, i.brushStyle);
  }
  function cr(i, t, e, n) {
    var r = [
      It(i, e),
      It(t, n)
    ], a = [
      bt(i, e),
      bt(t, n)
    ];
    return [
      [
        r[0],
        a[0]
      ],
      [
        r[1],
        a[1]
      ]
    ];
  }
  function Va(i) {
    return Ni(i.group);
  }
  function fe(i, t) {
    var e = {
      w: "left",
      e: "right",
      n: "top",
      s: "bottom"
    }, n = {
      left: "w",
      right: "e",
      top: "n",
      bottom: "s"
    }, r = un(e[t], Va(i));
    return n[r];
  }
  function Wa(i, t) {
    var e = [
      fe(i, t[0]),
      fe(i, t[1])
    ];
    return (e[0] === "e" || e[0] === "w") && e.reverse(), e.join("");
  }
  function ni(i, t, e, n, r, a) {
    var o = e.__brushOption, s = i.toRectRange(o.range), l = fr(t, r, a);
    y(n, function(u) {
      var h = Ea[u];
      s[h[0]][h[1]] += l[h[0]];
    }), o.range = i.fromRectRange(cr(s[0][0], s[1][0], s[0][1], s[1][1])), Te(t, e), ht(t, {
      isEnd: false
    });
  }
  function Na(i, t, e, n) {
    var r = t.__brushOption.range, a = fr(i, e, n);
    y(r, function(o) {
      o[0] += a[0], o[1] += a[1];
    }), Te(i, t), ht(i, {
      isEnd: false
    });
  }
  function fr(i, t, e) {
    var n = i.group, r = n.transformCoordToLocal(t, e), a = n.transformCoordToLocal(0, 0);
    return [
      r[0] - a[0],
      r[1] - a[1]
    ];
  }
  function Me(i, t, e) {
    var n = sr(i, t);
    return n && n !== ut ? n.clipPath(e, i._transform) : N(e);
  }
  function Ya(i) {
    var t = It(i[0][0], i[1][0]), e = It(i[0][1], i[1][1]), n = bt(i[0][0], i[1][0]), r = bt(i[0][1], i[1][1]);
    return {
      x: t,
      y: e,
      width: n - t,
      height: r - e
    };
  }
  function Ga(i, t, e) {
    if (!(!i._brushType || Za(i, t.offsetX, t.offsetY))) {
      var n = i._zr, r = i._covers, a = Se(i, t, e);
      if (!i._dragging) for (var o = 0; o < r.length; o++) {
        var s = r[o].__brushOption;
        if (a && (a === ut || s.panelId === a.panelId) && Wt[s.brushType].contain(r[o], e[0], e[1])) return;
      }
      a && n.setCursorStyle("crosshair");
    }
  }
  function de(i) {
    var t = i.event;
    t.preventDefault && t.preventDefault();
  }
  function pe(i, t, e) {
    return i.childOfName("main").contain(t, e);
  }
  function dr(i, t, e, n) {
    var r = i._creatingCover, a = i._creatingPanel, o = i._brushOption, s;
    if (i._track.push(e.slice()), ja(i) || r) {
      if (a && !r) {
        o.brushMode === "single" && he(i);
        var l = N(o);
        l.brushType = ai(l.brushType, a), l.panelId = a === ut ? null : a.panelId, r = i._creatingCover = rr(i, l), i._covers.push(r);
      }
      if (r) {
        var u = Wt[ai(i._brushType, a)], h = r.__brushOption;
        h.range = u.getCreatingRange(Me(i, r, i._track)), n && (nr(i, r), u.updateCommon(i, r)), ar(i, r), s = {
          isEnd: n
        };
      }
    } else n && o.brushMode === "single" && o.removeOnClick && Se(i, t, e) && he(i) && (s = {
      isEnd: n,
      removeOnClick: true
    });
    return s;
  }
  function ai(i, t) {
    return i === "auto" ? t.defaultBrushType : i;
  }
  var Fa = {
    mousedown: function(i) {
      if (this._dragging) oi(this, i);
      else if (!i.target || !i.target.draggable) {
        de(i);
        var t = this.group.transformCoordToLocal(i.offsetX, i.offsetY);
        this._creatingCover = null;
        var e = this._creatingPanel = Se(this, i, t);
        e && (this._dragging = true, this._track = [
          t.slice()
        ]);
      }
    },
    mousemove: function(i) {
      var t = i.offsetX, e = i.offsetY, n = this.group.transformCoordToLocal(t, e);
      if (Ga(this, i, n), this._dragging) {
        de(i);
        var r = dr(this, i, n, false);
        r && ht(this, r);
      }
    },
    mouseup: function(i) {
      oi(this, i);
    }
  };
  function oi(i, t) {
    if (i._dragging) {
      de(t);
      var e = t.offsetX, n = t.offsetY, r = i.group.transformCoordToLocal(e, n), a = dr(i, t, r, true);
      i._dragging = false, i._track = [], i._creatingCover = null, a && ht(i, a);
    }
  }
  function Za(i, t, e) {
    var n = i._zr;
    return t < 0 || t > n.getWidth() || e < 0 || e > n.getHeight();
  }
  var Wt = {
    lineX: si(0),
    lineY: si(1),
    rect: {
      createCover: function(i, t) {
        function e(n) {
          return n;
        }
        return ur({
          toRectRange: e,
          fromRectRange: e
        }, i, t, [
          [
            "w"
          ],
          [
            "e"
          ],
          [
            "n"
          ],
          [
            "s"
          ],
          [
            "s",
            "e"
          ],
          [
            "s",
            "w"
          ],
          [
            "n",
            "e"
          ],
          [
            "n",
            "w"
          ]
        ]);
      },
      getCreatingRange: function(i) {
        var t = lr(i);
        return cr(t[1][0], t[1][1], t[0][0], t[0][1]);
      },
      updateCoverShape: function(i, t, e, n) {
        hr(i, t, e, n);
      },
      updateCommon: ce,
      contain: pe
    },
    polygon: {
      createCover: function(i, t) {
        var e = new st();
        return e.add(new ln({
          name: "main",
          style: Ce(t),
          silent: true
        })), e;
      },
      getCreatingRange: function(i) {
        return i;
      },
      endCreating: function(i, t) {
        t.remove(t.childAt(0)), t.add(new sn({
          name: "main",
          draggable: true,
          drift: k(Na, i, t),
          ondragend: k(ht, i, {
            isEnd: true
          })
        }));
      },
      updateCoverShape: function(i, t, e, n) {
        t.childAt(0).setShape({
          points: Me(i, t, e)
        });
      },
      updateCommon: ce,
      contain: pe
    }
  };
  function si(i) {
    return {
      createCover: function(t, e) {
        return ur({
          toRectRange: function(n) {
            var r = [
              n,
              [
                0,
                100
              ]
            ];
            return i && r.reverse(), r;
          },
          fromRectRange: function(n) {
            return n[i];
          }
        }, t, e, [
          [
            [
              "w"
            ],
            [
              "e"
            ]
          ],
          [
            [
              "n"
            ],
            [
              "s"
            ]
          ]
        ][i]);
      },
      getCreatingRange: function(t) {
        var e = lr(t), n = It(e[0][i], e[1][i]), r = bt(e[0][i], e[1][i]);
        return [
          n,
          r
        ];
      },
      updateCoverShape: function(t, e, n, r) {
        var a, o = sr(t, e);
        if (o !== ut && o.getLinearBrushOtherExtent) a = o.getLinearBrushOtherExtent(i);
        else {
          var s = t._zr;
          a = [
            0,
            [
              s.getWidth(),
              s.getHeight()
            ][1 - i]
          ];
        }
        var l = [
          n,
          a
        ];
        i && l.reverse(), hr(t, e, l, r);
      },
      updateCommon: ce,
      contain: pe
    };
  }
  function Xa(i) {
    return i = Le(i), function(t) {
      return hn(t, i);
    };
  }
  function $a(i, t) {
    return i = Le(i), function(e) {
      var n = t ?? e, r = n ? i.width : i.height, a = n ? i.x : i.y;
      return [
        a,
        a + (r || 0)
      ];
    };
  }
  function Ua(i, t, e) {
    var n = Le(i);
    return function(r, a) {
      return n.contain(a[0], a[1]) && !Ia(r, t, e);
    };
  }
  function Le(i) {
    return Rt.create(i);
  }
  var at = kt(), li = N, Kt = Z, Ka = (function() {
    function i() {
      this._dragging = false, this.animationThreshold = 15;
    }
    return i.prototype.render = function(t, e, n, r) {
      var a = e.get("value"), o = e.get("status");
      if (this._axisModel = t, this._axisPointerModel = e, this._api = n, !(!r && this._lastValue === a && this._lastStatus === o)) {
        this._lastValue = a, this._lastStatus = o;
        var s = this._group, l = this._handle;
        if (!o || o === "hide") {
          s && s.hide(), l && l.hide();
          return;
        }
        s && s.show(), l && l.show();
        var u = {};
        this.makeElOption(u, a, t, e, n);
        var h = u.graphicKey;
        h !== this._lastGraphicKey && this.clear(n), this._lastGraphicKey = h;
        var c = this._moveAnimation = this.determineAnimation(t, e);
        if (!s) s = this._group = new st(), this.createPointerEl(s, u, t, e), this.createLabelEl(s, u, t, e), n.getZr().add(s);
        else {
          var d = k(ui, e, c);
          this.updatePointerEl(s, u, d), this.updateLabelEl(s, u, d, e);
        }
        ci(s, e, true), this._renderHandle(a);
      }
    }, i.prototype.remove = function(t) {
      this.clear(t);
    }, i.prototype.dispose = function(t) {
      this.clear(t);
    }, i.prototype.determineAnimation = function(t, e) {
      var n = e.get("animation"), r = t.axis, a = r.type === "category", o = e.get("snap");
      if (!o && !a) return false;
      if (n === "auto" || n == null) {
        var s = this.animationThreshold;
        if (a && r.getBandWidth() > s) return true;
        if (o) {
          var l = we(t).seriesDataCount, u = r.getExtent();
          return Math.abs(u[0] - u[1]) / l > s;
        }
        return false;
      }
      return n === true;
    }, i.prototype.makeElOption = function(t, e, n, r, a) {
    }, i.prototype.createPointerEl = function(t, e, n, r) {
      var a = e.pointer;
      if (a) {
        var o = at(t).pointerEl = new cn[a.type](li(e.pointer));
        t.add(o);
      }
    }, i.prototype.createLabelEl = function(t, e, n, r) {
      if (e.label) {
        var a = at(t).labelEl = new it(li(e.label));
        t.add(a), hi(a, r);
      }
    }, i.prototype.updatePointerEl = function(t, e, n) {
      var r = at(t).pointerEl;
      r && e.pointer && (r.setStyle(e.pointer.style), n(r, {
        shape: e.pointer.shape
      }));
    }, i.prototype.updateLabelEl = function(t, e, n, r) {
      var a = at(t).labelEl;
      a && (a.setStyle(e.label.style), n(a, {
        x: e.label.x,
        y: e.label.y
      }), hi(a, r));
    }, i.prototype._renderHandle = function(t) {
      if (!(this._dragging || !this.updateHandleTransform)) {
        var e = this._axisPointerModel, n = this._api.getZr(), r = this._handle, a = e.getModel("handle"), o = e.get("status");
        if (!a.get("show") || !o || o === "hide") {
          r && n.remove(r), this._handle = null;
          return;
        }
        var s;
        this._handle || (s = true, r = this._handle = Yi(a.get("icon"), {
          cursor: "move",
          draggable: true,
          onmousemove: function(u) {
            fn(u.event);
          },
          onmousedown: Kt(this._onHandleDragMove, this, 0, 0),
          drift: Kt(this._onHandleDragMove, this),
          ondragend: Kt(this._onHandleDragEnd, this)
        }), n.add(r)), ci(r, e, false), r.setStyle(a.getItemStyle(null, [
          "color",
          "borderColor",
          "borderWidth",
          "opacity",
          "shadowColor",
          "shadowBlur",
          "shadowOffsetX",
          "shadowOffsetY"
        ]));
        var l = a.get("size");
        j(l) || (l = [
          l,
          l
        ]), r.scaleX = l[0] / 2, r.scaleY = l[1] / 2, Gi(this, "_doDispatchAxisPointer", a.get("throttle") || 0, "fixRate"), this._moveHandleToValue(t, s);
      }
    }, i.prototype._moveHandleToValue = function(t, e) {
      ui(this._axisPointerModel, !e && this._moveAnimation, this._handle, qt(this.getHandleTransform(t, this._axisModel, this._axisPointerModel)));
    }, i.prototype._onHandleDragMove = function(t, e) {
      var n = this._handle;
      if (n) {
        this._dragging = true;
        var r = this.updateHandleTransform(qt(n), [
          t,
          e
        ], this._axisModel, this._axisPointerModel);
        this._payloadInfo = r, n.stopAnimation(), n.attr(qt(r)), at(n).lastProp = null, this._doDispatchAxisPointer();
      }
    }, i.prototype._doDispatchAxisPointer = function() {
      var t = this._handle;
      if (t) {
        var e = this._payloadInfo, n = this._axisModel;
        this._api.dispatchAction({
          type: "updateAxisPointer",
          x: e.cursorPoint[0],
          y: e.cursorPoint[1],
          tooltipOption: e.tooltipOption,
          axesInfo: [
            {
              axisDim: n.axis.dim,
              axisIndex: n.componentIndex
            }
          ]
        });
      }
    }, i.prototype._onHandleDragEnd = function() {
      this._dragging = false;
      var t = this._handle;
      if (t) {
        var e = this._axisPointerModel.get("value");
        this._moveHandleToValue(e), this._api.dispatchAction({
          type: "hideTip"
        });
      }
    }, i.prototype.clear = function(t) {
      this._lastValue = null, this._lastStatus = null;
      var e = t.getZr(), n = this._group, r = this._handle;
      e && n && (this._lastGraphicKey = null, n && e.remove(n), r && e.remove(r), this._group = null, this._handle = null, this._payloadInfo = null), re(this, "_doDispatchAxisPointer");
    }, i.prototype.doClear = function() {
    }, i.prototype.buildLabel = function(t, e, n) {
      return n = n || 0, {
        x: t[n],
        y: t[1 - n],
        width: e[n],
        height: e[1 - n]
      };
    }, i;
  })();
  function ui(i, t, e, n) {
    pr(at(e).lastProp, n) || (at(e).lastProp = n, t ? dn(e, n, i) : (e.stopAnimation(), e.attr(n)));
  }
  function pr(i, t) {
    if (et(i) && et(t)) {
      var e = true;
      return y(t, function(n, r) {
        e = e && pr(i[r], n);
      }), !!e;
    } else return i === t;
  }
  function hi(i, t) {
    i[t.get([
      "label",
      "show"
    ]) ? "show" : "hide"]();
  }
  function qt(i) {
    return {
      x: i.x || 0,
      y: i.y || 0,
      rotation: i.rotation || 0
    };
  }
  function ci(i, t, e) {
    var n = t.get("z"), r = t.get("zlevel");
    i && i.traverse(function(a) {
      a.type !== "group" && (n != null && (a.z = n), r != null && (a.zlevel = r), a.silent = e);
    });
  }
  function qa(i) {
    var t = i.get("type"), e = i.getModel(t + "Style"), n;
    return t === "line" ? (n = e.getLineStyle(), n.fill = null) : t === "shadow" && (n = e.getAreaStyle(), n.stroke = null), n;
  }
  function Qa(i, t, e, n, r) {
    var a = e.get("value"), o = vr(a, t.axis, t.ecModel, e.get("seriesDataIndices"), {
      precision: e.get([
        "label",
        "precision"
      ]),
      formatter: e.get([
        "label",
        "formatter"
      ])
    }), s = e.getModel("label"), l = be(s.get("padding") || 0), u = s.getFont(), h = Zi(o, u), c = r.position, d = h.width + l[1] + l[3], p = h.height + l[0] + l[2], f = r.align;
    f === "right" && (c[0] -= d), f === "center" && (c[0] -= d / 2);
    var v = r.verticalAlign;
    v === "bottom" && (c[1] -= p), v === "middle" && (c[1] -= p / 2), Ja(c, d, p, n);
    var g = s.get("backgroundColor");
    (!g || g === "auto") && (g = t.get([
      "axisLine",
      "lineStyle",
      "color"
    ])), i.label = {
      x: c[0],
      y: c[1],
      style: Mt(s, {
        text: o,
        font: u,
        fill: s.getTextColor(),
        padding: l,
        backgroundColor: g
      }),
      z2: 10
    };
  }
  function Ja(i, t, e, n) {
    var r = n.getWidth(), a = n.getHeight();
    i[0] = Math.min(i[0] + t, r) - t, i[1] = Math.min(i[1] + e, a) - e, i[0] = Math.max(i[0], 0), i[1] = Math.max(i[1], 0);
  }
  function vr(i, t, e, n, r) {
    i = t.scale.parse(i);
    var a = t.scale.getLabel({
      value: i
    }, {
      precision: r.precision
    }), o = r.formatter;
    if (o) {
      var s = {
        value: Fi(t, {
          value: i
        }),
        axisDimension: t.dim,
        axisIndex: t.index,
        seriesData: []
      };
      y(n, function(l) {
        var u = e.getSeriesByIndex(l.seriesIndex), h = l.dataIndexInside, c = u && u.getDataParams(h);
        c && s.seriesData.push(c);
      }), z(o) ? a = o.replace("{value}", a) : rt(o) && (a = o(s));
    }
    return a;
  }
  function gr(i, t, e) {
    var n = gn();
    return Vi(n, n, e.rotation), pn(n, n, e.position), vn([
      i.dataToCoord(t),
      (e.labelOffset || 0) + (e.labelDirection || 1) * (e.labelMargin || 0)
    ], n);
  }
  function to(i, t, e, n, r, a) {
    var o = J.innerTextLayout(e.rotation, 0, e.labelDirection);
    e.labelMargin = r.get([
      "label",
      "margin"
    ]), Qa(t, n, r, a, {
      position: gr(n.axis, i, e),
      align: o.textAlign,
      verticalAlign: o.textVerticalAlign
    });
  }
  function eo(i, t, e) {
    return e = e || 0, {
      x1: i[e],
      y1: i[1 - e],
      x2: t[e],
      y2: t[1 - e]
    };
  }
  function io(i, t, e) {
    return e = e || 0, {
      x: i[e],
      y: i[1 - e],
      width: t[e],
      height: t[1 - e]
    };
  }
  var ro = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.prototype.makeElOption = function(e, n, r, a, o) {
      var s = r.axis, l = s.grid, u = a.get("type"), h = fi(l, s).getOtherAxis(s).getGlobalExtent(), c = s.toGlobalCoord(s.dataToCoord(n, true));
      if (u && u !== "none") {
        var d = qa(a), p = no[u](s, c, h);
        p.style = d, e.graphicKey = p.type, e.pointer = p;
      }
      var f = se(l.model, r);
      to(n, e, f, r, a, o);
    }, t.prototype.getHandleTransform = function(e, n, r) {
      var a = se(n.axis.grid.model, n, {
        labelInside: false
      });
      a.labelMargin = r.get([
        "handle",
        "margin"
      ]);
      var o = gr(n.axis, e, a);
      return {
        x: o[0],
        y: o[1],
        rotation: a.rotation + (a.labelDirection < 0 ? Math.PI : 0)
      };
    }, t.prototype.updateHandleTransform = function(e, n, r, a) {
      var o = r.axis, s = o.grid, l = o.getGlobalExtent(true), u = fi(s, o).getOtherAxis(o).getGlobalExtent(), h = o.dim === "x" ? 0 : 1, c = [
        e.x,
        e.y
      ];
      c[h] += n[h], c[h] = Math.min(l[1], c[h]), c[h] = Math.max(l[0], c[h]);
      var d = (u[1] + u[0]) / 2, p = [
        d,
        d
      ];
      p[h] = c[h];
      var f = [
        {
          verticalAlign: "middle"
        },
        {
          align: "center"
        }
      ];
      return {
        x: c[0],
        y: c[1],
        rotation: e.rotation,
        cursorPoint: p,
        tooltipOption: f[h]
      };
    }, t;
  })(Ka);
  function fi(i, t) {
    var e = {};
    return e[t.dim + "AxisIndex"] = t.index, i.getCartesian(e);
  }
  var no = {
    line: function(i, t, e) {
      var n = eo([
        t,
        e[0]
      ], [
        t,
        e[1]
      ], di(i));
      return {
        type: "Line",
        subPixelOptimize: true,
        shape: n
      };
    },
    shadow: function(i, t, e) {
      var n = Math.max(1, i.getBandWidth()), r = e[1] - e[0];
      return {
        type: "Rect",
        shape: io([
          t - n / 2,
          e[0]
        ], [
          n,
          r
        ], di(i))
      };
    }
  };
  function di(i) {
    return i.dim === "x" ? 0 : 1;
  }
  var ao = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.type = "axisPointer", t.defaultOption = {
      show: "auto",
      z: 50,
      type: "line",
      snap: false,
      triggerTooltip: true,
      triggerEmphasis: true,
      value: null,
      status: null,
      link: [],
      animation: null,
      animationDurationUpdate: 200,
      lineStyle: {
        color: "#B9BEC9",
        width: 1,
        type: "dashed"
      },
      shadowStyle: {
        color: "rgba(210,219,238,0.2)"
      },
      label: {
        show: true,
        formatter: null,
        precision: "auto",
        margin: 3,
        color: "#fff",
        padding: [
          5,
          7,
          5,
          7
        ],
        backgroundColor: "auto",
        borderColor: null,
        borderWidth: 0,
        borderRadius: 3
      },
      handle: {
        show: false,
        icon: "M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7v-1.2h6.6z M13.3,22H6.7v-1.2h6.6z M13.3,19.6H6.7v-1.2h6.6z",
        size: 45,
        margin: 50,
        color: "#333",
        shadowBlur: 3,
        shadowColor: "#aaa",
        shadowOffsetX: 0,
        shadowOffsetY: 2,
        throttle: 40
      }
    }, t;
  })(ct), U = kt(), oo = y;
  function mr(i, t, e) {
    if (!B.node) {
      var n = t.getZr();
      U(n).records || (U(n).records = {}), so(n, t);
      var r = U(n).records[i] || (U(n).records[i] = {});
      r.handler = e;
    }
  }
  function so(i, t) {
    if (U(i).initialized) return;
    U(i).initialized = true, e("click", k(pi, "click")), e("mousemove", k(pi, "mousemove")), e("globalout", uo);
    function e(n, r) {
      i.on(n, function(a) {
        var o = ho(t);
        oo(U(i).records, function(s) {
          s && r(s, a, o.dispatchAction);
        }), lo(o.pendings, t);
      });
    }
  }
  function lo(i, t) {
    var e = i.showTip.length, n = i.hideTip.length, r;
    e ? r = i.showTip[e - 1] : n && (r = i.hideTip[n - 1]), r && (r.dispatchAction = null, t.dispatchAction(r));
  }
  function uo(i, t, e) {
    i.handler("leave", null, e);
  }
  function pi(i, t, e, n) {
    t.handler(i, e, n);
  }
  function ho(i) {
    var t = {
      showTip: [],
      hideTip: []
    }, e = function(n) {
      var r = t[n.type];
      r ? r.push(n) : (n.dispatchAction = e, i.dispatchAction(n));
    };
    return {
      dispatchAction: e,
      pendings: t
    };
  }
  function ve(i, t) {
    if (!B.node) {
      var e = t.getZr(), n = (U(e).records || {})[i];
      n && (U(e).records[i] = null);
    }
  }
  var co = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.prototype.render = function(e, n, r) {
      var a = n.getComponent("tooltip"), o = e.get("triggerOn") || a && a.get("triggerOn") || "mousemove|click";
      mr("axisPointer", r, function(s, l, u) {
        o !== "none" && (s === "leave" || o.indexOf(s) >= 0) && u({
          type: "updateAxisPointer",
          currTrigger: s,
          x: l && l.offsetX,
          y: l && l.offsetY
        });
      });
    }, t.prototype.remove = function(e, n) {
      ve("axisPointer", n);
    }, t.prototype.dispose = function(e, n) {
      ve("axisPointer", n);
    }, t.type = "axisPointer", t;
  })(ft);
  function xr(i, t) {
    var e = [], n = i.seriesIndex, r;
    if (n == null || !(r = t.getSeriesByIndex(n))) return {
      point: []
    };
    var a = r.getData(), o = mn(a, i);
    if (o == null || o < 0 || j(o)) return {
      point: []
    };
    var s = a.getItemGraphicEl(o), l = r.coordinateSystem;
    if (r.getTooltipPosition) e = r.getTooltipPosition(o) || [];
    else if (l && l.dataToPoint) if (i.isStacked) {
      var u = l.getBaseAxis(), h = l.getOtherAxis(u), c = h.dim, d = u.dim, p = c === "x" || c === "radius" ? 1 : 0, f = a.mapDimension(d), v = [];
      v[p] = a.get(f, o), v[1 - p] = a.get(a.getCalculationInfo("stackResultDimension"), o), e = l.dataToPoint(v) || [];
    } else e = l.dataToPoint(a.getValues(H(l.dimensions, function(m) {
      return a.mapDimension(m);
    }), o)) || [];
    else if (s) {
      var g = s.getBoundingRect().clone();
      g.applyTransform(s.transform), e = [
        g.x + g.width / 2,
        g.y + g.height / 2
      ];
    }
    return {
      point: e,
      el: s
    };
  }
  var vi = kt();
  function fo(i, t, e) {
    var n = i.currTrigger, r = [
      i.x,
      i.y
    ], a = i, o = i.dispatchAction || Z(e.dispatchAction, e), s = t.getComponent("axisPointer").coordSysAxesInfo;
    if (s) {
      Pt(r) && (r = xr({
        seriesIndex: a.seriesIndex,
        dataIndex: a.dataIndex
      }, t).point);
      var l = Pt(r), u = a.axesInfo, h = s.axesInfo, c = n === "leave" || Pt(r), d = {}, p = {}, f = {
        list: [],
        map: {}
      }, v = {
        showPointer: k(vo, p),
        showTooltip: k(go, f)
      };
      y(s.coordSysMap, function(m, _) {
        var x = l || m.containPoint(r);
        y(s.coordSysAxesInfo[_], function(b, w) {
          var T = b.axis, A = bo(u, b);
          if (!c && x && (!u || A)) {
            var S = A && A.value;
            S == null && !l && (S = T.pointToData(r)), S != null && gi(b, S, v, false, d);
          }
        });
      });
      var g = {};
      return y(h, function(m, _) {
        var x = m.linkGroup;
        x && !p[_] && y(x.axesInfo, function(b, w) {
          var T = p[w];
          if (b !== m && T) {
            var A = T.value;
            x.mapper && (A = m.axis.scale.parse(x.mapper(A, mi(b), mi(m)))), g[m.key] = A;
          }
        });
      }), y(g, function(m, _) {
        gi(h[_], m, v, true, d);
      }), mo(p, h, d), xo(f, r, i, o), yo(h, o, e), d;
    }
  }
  function gi(i, t, e, n, r) {
    var a = i.axis;
    if (!(a.scale.isBlank() || !a.containData(t))) {
      if (!i.involveSeries) {
        e.showPointer(i, t);
        return;
      }
      var o = po(t, i), s = o.payloadBatch, l = o.snapToValue;
      s[0] && r.seriesIndex == null && xt(r, s[0]), !n && i.snap && a.containData(l) && l != null && (t = l), e.showPointer(i, t, s), e.showTooltip(i, o, l);
    }
  }
  function po(i, t) {
    var e = t.axis, n = e.dim, r = i, a = [], o = Number.MAX_VALUE, s = -1;
    return y(t.seriesModels, function(l, u) {
      var h = l.getData().mapDimensionsAll(n), c, d;
      if (l.getAxisTooltipData) {
        var p = l.getAxisTooltipData(h, i, e);
        d = p.dataIndices, c = p.nestestValue;
      } else {
        if (d = l.getData().indicesOfNearest(h[0], i, e.type === "category" ? 0.5 : null), !d.length) return;
        c = l.getData().get(h[0], d[0]);
      }
      if (!(c == null || !isFinite(c))) {
        var f = i - c, v = Math.abs(f);
        v <= o && ((v < o || f >= 0 && s < 0) && (o = v, s = f, r = c, a.length = 0), y(d, function(g) {
          a.push({
            seriesIndex: l.seriesIndex,
            dataIndexInside: g,
            dataIndex: l.getData().getRawIndex(g)
          });
        }));
      }
    }), {
      payloadBatch: a,
      snapToValue: r
    };
  }
  function vo(i, t, e, n) {
    i[t.key] = {
      value: e,
      payloadBatch: n
    };
  }
  function go(i, t, e, n) {
    var r = e.payloadBatch, a = t.axis, o = a.model, s = t.axisPointerModel;
    if (!(!t.triggerTooltip || !r.length)) {
      var l = t.coordSys.model, u = Dt(l), h = i.map[u];
      h || (h = i.map[u] = {
        coordSysId: l.id,
        coordSysIndex: l.componentIndex,
        coordSysType: l.type,
        coordSysMainType: l.mainType,
        dataByAxis: []
      }, i.list.push(h)), h.dataByAxis.push({
        axisDim: a.dim,
        axisIndex: o.componentIndex,
        axisType: o.type,
        axisId: o.id,
        value: n,
        valueLabelOpt: {
          precision: s.get([
            "label",
            "precision"
          ]),
          formatter: s.get([
            "label",
            "formatter"
          ])
        },
        seriesDataIndices: r.slice()
      });
    }
  }
  function mo(i, t, e) {
    var n = e.axesInfo = [];
    y(t, function(r, a) {
      var o = r.axisPointerModel.option, s = i[a];
      s ? (!r.useHandle && (o.status = "show"), o.value = s.value, o.seriesDataIndices = (s.payloadBatch || []).slice()) : !r.useHandle && (o.status = "hide"), o.status === "show" && n.push({
        axisDim: r.axis.dim,
        axisIndex: r.axis.model.componentIndex,
        value: o.value
      });
    });
  }
  function xo(i, t, e, n) {
    if (Pt(t) || !i.list.length) {
      n({
        type: "hideTip"
      });
      return;
    }
    var r = ((i.list[0].dataByAxis[0] || {}).seriesDataIndices || [])[0] || {};
    n({
      type: "showTip",
      escapeConnect: true,
      x: t[0],
      y: t[1],
      tooltipOption: e.tooltipOption,
      position: e.position,
      dataIndexInside: r.dataIndexInside,
      dataIndex: r.dataIndex,
      seriesIndex: r.seriesIndex,
      dataByCoordSys: i.list
    });
  }
  function yo(i, t, e) {
    var n = e.getZr(), r = "axisPointerLastHighlights", a = vi(n)[r] || {}, o = vi(n)[r] = {};
    y(i, function(u, h) {
      var c = u.axisPointerModel.option;
      c.status === "show" && u.triggerEmphasis && y(c.seriesDataIndices, function(d) {
        var p = d.seriesIndex + " | " + d.dataIndex;
        o[p] = d;
      });
    });
    var s = [], l = [];
    y(a, function(u, h) {
      !o[h] && l.push(u);
    }), y(o, function(u, h) {
      !a[h] && s.push(u);
    }), l.length && e.dispatchAction({
      type: "downplay",
      escapeConnect: true,
      notBlur: true,
      batch: l
    }), s.length && e.dispatchAction({
      type: "highlight",
      escapeConnect: true,
      notBlur: true,
      batch: s
    });
  }
  function bo(i, t) {
    for (var e = 0; e < (i || []).length; e++) {
      var n = i[e];
      if (t.axis.dim === n.axisDim && t.axis.model.componentIndex === n.axisIndex) return n;
    }
  }
  function mi(i) {
    var t = i.axis.model, e = {}, n = e.axisDim = i.axis.dim;
    return e.axisIndex = e[n + "AxisIndex"] = t.componentIndex, e.axisName = e[n + "AxisName"] = t.name, e.axisId = e[n + "AxisId"] = t.id, e;
  }
  function Pt(i) {
    return !i || i[0] == null || isNaN(i[0]) || i[1] == null || isNaN(i[1]);
  }
  function yr(i) {
    Qi.registerAxisPointerClass("CartesianAxisPointer", ro), i.registerComponentModel(ao), i.registerComponentView(co), i.registerPreprocessor(function(t) {
      if (t) {
        (!t.axisPointer || t.axisPointer.length === 0) && (t.axisPointer = {});
        var e = t.axisPointer.link;
        e && !j(e) && (t.axisPointer.link = [
          e
        ]);
      }
    }), i.registerProcessor(i.PRIORITY.PROCESSOR.STATISTIC, function(t, e) {
      t.getComponent("axisPointer").coordSysAxesInfo = fa(t, e);
    }), i.registerAction({
      type: "updateAxisPointer",
      event: "updateAxisPointer",
      update: ":updateAxisPointer"
    }, fo);
  }
  _o = function(i) {
    Lt(Ca), Lt(yr);
  };
  var xi = [
    "x",
    "y",
    "radius",
    "angle",
    "single"
  ], wo = [
    "cartesian2d",
    "polar",
    "singleAxis"
  ];
  function To(i) {
    var t = i.get("coordinateSystem");
    return F(wo, t) >= 0;
  }
  function gt(i) {
    return i + "Axis";
  }
  function Ao(i, t) {
    var e = yt(), n = [], r = yt();
    i.eachComponent({
      mainType: "dataZoom",
      query: t
    }, function(h) {
      r.get(h.uid) || s(h);
    });
    var a;
    do
      a = false, i.eachComponent("dataZoom", o);
    while (a);
    function o(h) {
      !r.get(h.uid) && l(h) && (s(h), a = true);
    }
    function s(h) {
      r.set(h.uid, true), n.push(h), u(h);
    }
    function l(h) {
      var c = false;
      return h.eachTargetAxis(function(d, p) {
        var f = e.get(d);
        f && f[p] && (c = true);
      }), c;
    }
    function u(h) {
      h.eachTargetAxis(function(c, d) {
        (e.get(c) || e.set(c, []))[d] = true;
      });
    }
    return n;
  }
  var Qt = (function() {
    function i() {
      this.indexList = [], this.indexMap = [];
    }
    return i.prototype.add = function(t) {
      this.indexMap[t] || (this.indexList.push(t), this.indexMap[t] = true);
    }, i;
  })(), So = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e._autoThrottle = true, e._noTarget = true, e._rangePropMode = [
        "percent",
        "percent"
      ], e;
    }
    return t.prototype.init = function(e, n, r) {
      var a = yi(e);
      this.settledOption = a, this.mergeDefaultAndTheme(e, r), this._doInit(a);
    }, t.prototype.mergeOption = function(e) {
      var n = yi(e);
      P(this.option, e, true), P(this.settledOption, n, true), this._doInit(n);
    }, t.prototype._doInit = function(e) {
      var n = this.option;
      this._setDefaultThrottle(e), this._updateRangeUse(e);
      var r = this.settledOption;
      y([
        [
          "start",
          "startValue"
        ],
        [
          "end",
          "endValue"
        ]
      ], function(a, o) {
        this._rangePropMode[o] === "value" && (n[a[0]] = r[a[0]] = null);
      }, this), this._resetTarget();
    }, t.prototype._resetTarget = function() {
      var e = this.get("orient", true), n = this._targetAxisInfoMap = yt(), r = this._fillSpecifiedTargetAxis(n);
      r ? this._orient = e || this._makeAutoOrientByTargetAxis() : (this._orient = e || "horizontal", this._fillAutoTargetAxisByOrient(n, this._orient)), this._noTarget = true, n.each(function(a) {
        a.indexList.length && (this._noTarget = false);
      }, this);
    }, t.prototype._fillSpecifiedTargetAxis = function(e) {
      var n = false;
      return y(xi, function(r) {
        var a = this.getReferringComponents(gt(r), xn);
        if (a.specified) {
          n = true;
          var o = new Qt();
          y(a.models, function(s) {
            o.add(s.componentIndex);
          }), e.set(r, o);
        }
      }, this), n;
    }, t.prototype._fillAutoTargetAxisByOrient = function(e, n) {
      var r = this.ecModel, a = true;
      if (a) {
        var o = n === "vertical" ? "y" : "x", s = r.findComponents({
          mainType: o + "Axis"
        });
        l(s, o);
      }
      if (a) {
        var s = r.findComponents({
          mainType: "singleAxis",
          filter: function(h) {
            return h.get("orient", true) === n;
          }
        });
        l(s, "single");
      }
      function l(u, h) {
        var c = u[0];
        if (c) {
          var d = new Qt();
          if (d.add(c.componentIndex), e.set(h, d), a = false, h === "x" || h === "y") {
            var p = c.getReferringComponents("grid", tt).models[0];
            p && y(u, function(f) {
              c.componentIndex !== f.componentIndex && p === f.getReferringComponents("grid", tt).models[0] && d.add(f.componentIndex);
            });
          }
        }
      }
      a && y(xi, function(u) {
        if (a) {
          var h = r.findComponents({
            mainType: gt(u),
            filter: function(d) {
              return d.get("type", true) === "category";
            }
          });
          if (h[0]) {
            var c = new Qt();
            c.add(h[0].componentIndex), e.set(u, c), a = false;
          }
        }
      }, this);
    }, t.prototype._makeAutoOrientByTargetAxis = function() {
      var e;
      return this.eachTargetAxis(function(n) {
        !e && (e = n);
      }, this), e === "y" ? "vertical" : "horizontal";
    }, t.prototype._setDefaultThrottle = function(e) {
      if (e.hasOwnProperty("throttle") && (this._autoThrottle = false), this._autoThrottle) {
        var n = this.ecModel.option;
        this.option.throttle = n.animation && n.animationDurationUpdate > 0 ? 100 : 20;
      }
    }, t.prototype._updateRangeUse = function(e) {
      var n = this._rangePropMode, r = this.get("rangeMode");
      y([
        [
          "start",
          "startValue"
        ],
        [
          "end",
          "endValue"
        ]
      ], function(a, o) {
        var s = e[a[0]] != null, l = e[a[1]] != null;
        s && !l ? n[o] = "percent" : !s && l ? n[o] = "value" : r ? n[o] = r[o] : s && (n[o] = "percent");
      });
    }, t.prototype.noTarget = function() {
      return this._noTarget;
    }, t.prototype.getFirstTargetAxisModel = function() {
      var e;
      return this.eachTargetAxis(function(n, r) {
        e == null && (e = this.ecModel.getComponent(gt(n), r));
      }, this), e;
    }, t.prototype.eachTargetAxis = function(e, n) {
      this._targetAxisInfoMap.each(function(r, a) {
        y(r.indexList, function(o) {
          e.call(n, a, o);
        });
      });
    }, t.prototype.getAxisProxy = function(e, n) {
      var r = this.getAxisModel(e, n);
      if (r) return r.__dzAxisProxy;
    }, t.prototype.getAxisModel = function(e, n) {
      var r = this._targetAxisInfoMap.get(e);
      if (r && r.indexMap[n]) return this.ecModel.getComponent(gt(e), n);
    }, t.prototype.setRawRange = function(e) {
      var n = this.option, r = this.settledOption;
      y([
        [
          "start",
          "startValue"
        ],
        [
          "end",
          "endValue"
        ]
      ], function(a) {
        (e[a[0]] != null || e[a[1]] != null) && (n[a[0]] = r[a[0]] = e[a[0]], n[a[1]] = r[a[1]] = e[a[1]]);
      }, this), this._updateRangeUse(e);
    }, t.prototype.setCalculatedRange = function(e) {
      var n = this.option;
      y([
        "start",
        "startValue",
        "end",
        "endValue"
      ], function(r) {
        n[r] = e[r];
      });
    }, t.prototype.getPercentRange = function() {
      var e = this.findRepresentativeAxisProxy();
      if (e) return e.getDataPercentWindow();
    }, t.prototype.getValueRange = function(e, n) {
      if (e == null && n == null) {
        var r = this.findRepresentativeAxisProxy();
        if (r) return r.getDataValueWindow();
      } else return this.getAxisProxy(e, n).getDataValueWindow();
    }, t.prototype.findRepresentativeAxisProxy = function(e) {
      if (e) return e.__dzAxisProxy;
      for (var n, r = this._targetAxisInfoMap.keys(), a = 0; a < r.length; a++) for (var o = r[a], s = this._targetAxisInfoMap.get(o), l = 0; l < s.indexList.length; l++) {
        var u = this.getAxisProxy(o, s.indexList[l]);
        if (u.hostedBy(this)) return u;
        n || (n = u);
      }
      return n;
    }, t.prototype.getRangePropMode = function() {
      return this._rangePropMode.slice();
    }, t.prototype.getOrient = function() {
      return this._orient;
    }, t.type = "dataZoom", t.dependencies = [
      "xAxis",
      "yAxis",
      "radiusAxis",
      "angleAxis",
      "singleAxis",
      "series",
      "toolbox"
    ], t.defaultOption = {
      z: 4,
      filterMode: "filter",
      start: 0,
      end: 100
    }, t;
  })(ct);
  function yi(i) {
    var t = {};
    return y([
      "start",
      "end",
      "startValue",
      "endValue",
      "throttle"
    ], function(e) {
      i.hasOwnProperty(e) && (t[e] = i[e]);
    }), t;
  }
  var Co = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.type = "dataZoom.select", t;
  })(So), Mo = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.prototype.render = function(e, n, r, a) {
      this.dataZoomModel = e, this.ecModel = n, this.api = r;
    }, t.type = "dataZoom", t;
  })(ft), Lo = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.type = "dataZoom.select", t;
  })(Mo), pt = y, bi = wn, Do = (function() {
    function i(t, e, n, r) {
      this._dimName = t, this._axisIndex = e, this.ecModel = r, this._dataZoomModel = n;
    }
    return i.prototype.hostedBy = function(t) {
      return this._dataZoomModel === t;
    }, i.prototype.getDataValueWindow = function() {
      return this._valueWindow.slice();
    }, i.prototype.getDataPercentWindow = function() {
      return this._percentWindow.slice();
    }, i.prototype.getTargetSeriesModels = function() {
      var t = [];
      return this.ecModel.eachSeries(function(e) {
        if (To(e)) {
          var n = gt(this._dimName), r = e.getReferringComponents(n, tt).models[0];
          r && this._axisIndex === r.componentIndex && t.push(e);
        }
      }, this), t;
    }, i.prototype.getAxisModel = function() {
      return this.ecModel.getComponent(this._dimName + "Axis", this._axisIndex);
    }, i.prototype.getMinMaxSpan = function() {
      return N(this._minMaxSpan);
    }, i.prototype.calculateDataWindow = function(t) {
      var e = this._dataExtent, n = this.getAxisModel(), r = n.axis.scale, a = this._dataZoomModel.getRangePropMode(), o = [
        0,
        100
      ], s = [], l = [], u;
      pt([
        "start",
        "end"
      ], function(d, p) {
        var f = t[d], v = t[d + "Value"];
        a[p] === "percent" ? (f == null && (f = o[p]), v = r.parse(Tt(f, o, e))) : (u = true, v = v == null ? e[p] : r.parse(v), f = Tt(v, e, o)), l[p] = v == null || isNaN(v) ? e[p] : v, s[p] = f == null || isNaN(f) ? o[p] : f;
      }), bi(l), bi(s);
      var h = this._minMaxSpan;
      u ? c(l, s, e, o, false) : c(s, l, o, e, true);
      function c(d, p, f, v, g) {
        var m = g ? "Span" : "ValueSpan";
        ir(0, d, f, "all", h["min" + m], h["max" + m]);
        for (var _ = 0; _ < 2; _++) p[_] = Tt(d[_], f, v, true), g && (p[_] = r.parse(p[_]));
      }
      return {
        valueWindow: l,
        percentWindow: s
      };
    }, i.prototype.reset = function(t) {
      if (t === this._dataZoomModel) {
        var e = this.getTargetSeriesModels();
        this._dataExtent = Io(this, this._dimName, e), this._updateMinMaxSpan();
        var n = this.calculateDataWindow(t.settledOption);
        this._valueWindow = n.valueWindow, this._percentWindow = n.percentWindow, this._setAxisModel();
      }
    }, i.prototype.filterData = function(t, e) {
      if (t !== this._dataZoomModel) return;
      var n = this._dimName, r = this.getTargetSeriesModels(), a = t.get("filterMode"), o = this._valueWindow;
      if (a === "none") return;
      pt(r, function(l) {
        var u = l.getData(), h = u.mapDimensionsAll(n);
        if (h.length) {
          if (a === "weakFilter") {
            var c = u.getStore(), d = H(h, function(p) {
              return u.getDimensionIndex(p);
            }, u);
            u.filterSelf(function(p) {
              for (var f, v, g, m = 0; m < h.length; m++) {
                var _ = c.get(d[m], p), x = !isNaN(_), b = _ < o[0], w = _ > o[1];
                if (x && !b && !w) return true;
                x && (g = true), b && (f = true), w && (v = true);
              }
              return g && f && v;
            });
          } else pt(h, function(p) {
            if (a === "empty") l.setData(u = u.map(p, function(v) {
              return s(v) ? v : NaN;
            }));
            else {
              var f = {};
              f[p] = o, u.selectRange(f);
            }
          });
          pt(h, function(p) {
            u.setApproximateExtent(o, p);
          });
        }
      });
      function s(l) {
        return l >= o[0] && l <= o[1];
      }
    }, i.prototype._updateMinMaxSpan = function() {
      var t = this._minMaxSpan = {}, e = this._dataZoomModel, n = this._dataExtent;
      pt([
        "min",
        "max"
      ], function(r) {
        var a = e.get(r + "Span"), o = e.get(r + "ValueSpan");
        o != null && (o = this.getAxisModel().axis.scale.parse(o)), o != null ? a = Tt(n[0] + o, n, [
          0,
          100
        ], true) : a != null && (o = Tt(a, [
          0,
          100
        ], n, true) - n[0]), t[r + "Span"] = a, t[r + "ValueSpan"] = o;
      }, this);
    }, i.prototype._setAxisModel = function() {
      var t = this.getAxisModel(), e = this._percentWindow, n = this._valueWindow;
      if (e) {
        var r = yn(n, [
          0,
          500
        ]);
        r = Math.min(r, 20);
        var a = t.axis.scale.rawExtentInfo;
        e[0] !== 0 && a.setDeterminedMinMax("min", +n[0].toFixed(r)), e[1] !== 100 && a.setDeterminedMinMax("max", +n[1].toFixed(r)), a.freeze();
      }
    }, i;
  })();
  function Io(i, t, e) {
    var n = [
      1 / 0,
      -1 / 0
    ];
    pt(e, function(o) {
      bn(n, o.getData(), t);
    });
    var r = i.getAxisModel(), a = _n(r.axis.scale, r, n).calculate();
    return [
      a.min,
      a.max
    ];
  }
  var ko = {
    getTargetSeries: function(i) {
      function t(r) {
        i.eachComponent("dataZoom", function(a) {
          a.eachTargetAxis(function(o, s) {
            var l = i.getComponent(gt(o), s);
            r(o, s, l, a);
          });
        });
      }
      t(function(r, a, o, s) {
        o.__dzAxisProxy = null;
      });
      var e = [];
      t(function(r, a, o, s) {
        o.__dzAxisProxy || (o.__dzAxisProxy = new Do(r, a, s, i), e.push(o.__dzAxisProxy));
      });
      var n = yt();
      return y(e, function(r) {
        y(r.getTargetSeriesModels(), function(a) {
          n.set(a.uid, a);
        });
      }), n;
    },
    overallReset: function(i, t) {
      i.eachComponent("dataZoom", function(e) {
        e.eachTargetAxis(function(n, r) {
          e.getAxisProxy(n, r).reset(e);
        }), e.eachTargetAxis(function(n, r) {
          e.getAxisProxy(n, r).filterData(e, t);
        });
      }), i.eachComponent("dataZoom", function(e) {
        var n = e.findRepresentativeAxisProxy();
        if (n) {
          var r = n.getDataPercentWindow(), a = n.getDataValueWindow();
          e.setCalculatedRange({
            start: r[0],
            end: r[1],
            startValue: a[0],
            endValue: a[1]
          });
        }
      });
    }
  };
  function Po(i) {
    i.registerAction("dataZoom", function(t, e) {
      var n = Ao(e, t);
      y(n, function(r) {
        r.setRawRange({
          start: t.start,
          end: t.end,
          startValue: t.startValue,
          endValue: t.endValue
        });
      });
    });
  }
  var _i = false;
  function Ro(i) {
    _i || (_i = true, i.registerProcessor(i.PRIORITY.PROCESSOR.FILTER, ko), Po(i), i.registerSubTypeDefaulter("dataZoom", function() {
      return "slider";
    }));
  }
  function Oo(i) {
    i.registerComponentModel(Co), i.registerComponentView(Lo), Ro(i);
  }
  var G = /* @__PURE__ */ (function() {
    function i() {
    }
    return i;
  })(), br = {};
  function At(i, t) {
    br[i] = t;
  }
  function _r(i) {
    return br[i];
  }
  var Eo = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.prototype.optionUpdated = function() {
      i.prototype.optionUpdated.apply(this, arguments);
      var e = this.ecModel;
      y(this.option.feature, function(n, r) {
        var a = _r(r);
        a && (a.getDefaultOption && (a.defaultOption = a.getDefaultOption(e)), P(n, a.defaultOption));
      });
    }, t.type = "toolbox", t.layoutMode = {
      type: "box",
      ignoreSize: true
    }, t.defaultOption = {
      show: true,
      z: 6,
      orient: "horizontal",
      left: "right",
      top: "top",
      backgroundColor: "transparent",
      borderColor: "#ccc",
      borderRadius: 0,
      borderWidth: 0,
      padding: 5,
      itemSize: 15,
      itemGap: 8,
      showTitle: true,
      iconStyle: {
        borderColor: "#666",
        color: "none"
      },
      emphasis: {
        iconStyle: {
          borderColor: "#3E98C5"
        }
      },
      tooltip: {
        show: false,
        position: "bottom"
      }
    }, t;
  })(ct);
  function Bo(i, t, e) {
    var n = t.getBoxLayoutParams(), r = t.get("padding"), a = {
      width: e.getWidth(),
      height: e.getHeight()
    }, o = jt(n, a, r);
    Tn(t.get("orient"), i, t.get("itemGap"), o.width, o.height), An(i, n, a, r);
  }
  zo = function(i, t) {
    var e = be(t.get("padding")), n = t.getItemStyle([
      "color",
      "opacity"
    ]);
    return n.fill = t.get("backgroundColor"), i = new lt({
      shape: {
        x: i.x - e[3],
        y: i.y - e[0],
        width: i.width + e[1] + e[3],
        height: i.height + e[0] + e[2],
        r: t.get("borderRadius")
      },
      style: n,
      silent: true,
      z2: -1
    }), i;
  };
  var Ho = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.prototype.render = function(e, n, r, a) {
      var o = this.group;
      if (o.removeAll(), !e.get("show")) return;
      var s = +e.get("itemSize"), l = e.get("orient") === "vertical", u = e.get("feature") || {}, h = this._features || (this._features = {}), c = [];
      y(u, function(f, v) {
        c.push(v);
      }), new Wi(this._featureNames || [], c).add(d).update(d).remove(k(d, null)).execute(), this._featureNames = c;
      function d(f, v) {
        var g = c[f], m = c[v], _ = u[g], x = new ot(_, e, e.ecModel), b;
        if (a && a.newTitle != null && a.featureName === g && (_.title = a.newTitle), g && !m) {
          if (jo(g)) b = {
            onclick: x.option.onclick,
            featureName: g
          };
          else {
            var w = _r(g);
            if (!w) return;
            b = new w();
          }
          h[g] = b;
        } else if (b = h[m], !b) return;
        b.uid = Sn("toolbox-feature"), b.model = x, b.ecModel = n, b.api = r;
        var T = b instanceof G;
        if (!g && m) {
          T && b.dispose && b.dispose(n, r);
          return;
        }
        if (!x.get("show") || T && b.unusable) {
          T && b.remove && b.remove(n, r);
          return;
        }
        p(x, b, g), x.setIconStatus = function(A, S) {
          var L = this.option, D = this.iconPaths;
          L.iconStatus = L.iconStatus || {}, L.iconStatus[A] = S, D[A] && (S === "emphasis" ? Ee : Be)(D[A]);
        }, b instanceof G && b.render && b.render(x, n, r, a);
      }
      function p(f, v, g) {
        var m = f.getModel("iconStyle"), _ = f.getModel([
          "emphasis",
          "iconStyle"
        ]), x = v instanceof G && v.getIcons ? v.getIcons() : f.get("icon"), b = f.get("title") || {}, w, T;
        z(x) ? (w = {}, w[g] = x) : w = x, z(b) ? (T = {}, T[g] = b) : T = b;
        var A = f.iconPaths = {};
        y(w, function(S, L) {
          var D = Yi(S, {}, {
            x: -s / 2,
            y: -s / 2,
            width: s,
            height: s
          });
          D.setStyle(m.getItemStyle());
          var I = D.ensureState("emphasis");
          I.style = _.getItemStyle();
          var X = new it({
            style: {
              text: T[L],
              align: _.get("textAlign"),
              borderRadius: _.get("textBorderRadius"),
              padding: _.get("textPadding"),
              fill: null,
              font: Cn({
                fontStyle: _.get("textFontStyle"),
                fontFamily: _.get("textFontFamily"),
                fontSize: _.get("textFontSize"),
                fontWeight: _.get("textFontWeight")
              }, n)
            },
            ignore: true
          });
          D.setTextContent(X), ye({
            el: D,
            componentModel: e,
            itemName: L,
            formatterParamsExtra: {
              title: T[L]
            }
          }), D.__title = T[L], D.on("mouseover", function() {
            var K = _.getItemStyle(), R = l ? e.get("right") == null && e.get("left") !== "right" ? "right" : "left" : e.get("bottom") == null && e.get("top") !== "bottom" ? "bottom" : "top";
            X.setStyle({
              fill: _.get("textFill") || K.fill || K.stroke || "#000",
              backgroundColor: _.get("textBackgroundColor")
            }), D.setTextConfig({
              position: _.get("textPosition") || R
            }), X.ignore = !e.get("showTitle"), r.enterEmphasis(this);
          }).on("mouseout", function() {
            f.get([
              "iconStatus",
              L
            ]) !== "emphasis" && r.leaveEmphasis(this), X.hide();
          }), (f.get([
            "iconStatus",
            L
          ]) === "emphasis" ? Ee : Be)(D), o.add(D), D.on("click", Z(v.onclick, v, n, r, L)), A[L] = D;
        });
      }
      Bo(o, e, r), o.add(zo(o.getBoundingRect(), e)), l || o.eachChild(function(f) {
        var v = f.__title, g = f.ensureState("emphasis"), m = g.textConfig || (g.textConfig = {}), _ = f.getTextContent(), x = _ && _.ensureState("emphasis");
        if (x && !rt(x) && v) {
          var b = x.style || (x.style = {}), w = Zi(v, it.makeFont(b)), T = f.x + o.x, A = f.y + o.y + s, S = false;
          A + w.height > r.getHeight() && (m.position = "top", S = true);
          var L = S ? -5 - w.height : s + 10;
          T + w.width / 2 > r.getWidth() ? (m.position = [
            "100%",
            L
          ], b.align = "right") : T - w.width / 2 < 0 && (m.position = [
            0,
            L
          ], b.align = "left");
        }
      });
    }, t.prototype.updateView = function(e, n, r, a) {
      y(this._features, function(o) {
        o instanceof G && o.updateView && o.updateView(o.model, n, r, a);
      });
    }, t.prototype.remove = function(e, n) {
      y(this._features, function(r) {
        r instanceof G && r.remove && r.remove(e, n);
      }), this.group.removeAll();
    }, t.prototype.dispose = function(e, n) {
      y(this._features, function(r) {
        r instanceof G && r.dispose && r.dispose(e, n);
      });
    }, t.type = "toolbox", t;
  })(ft);
  function jo(i) {
    return i.indexOf("my") === 0;
  }
  var Vo = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.prototype.onclick = function(e, n) {
      var r = this.model, a = r.get("name") || e.get("title.0.text") || "echarts", o = n.getZr().painter.getType() === "svg", s = o ? "svg" : r.get("type", true) || "png", l = n.getConnectedDataURL({
        type: s,
        backgroundColor: r.get("backgroundColor", true) || e.get("backgroundColor") || "#fff",
        connectedBackgroundColor: r.get("connectedBackgroundColor"),
        excludeComponents: r.get("excludeComponents"),
        pixelRatio: r.get("pixelRatio")
      }), u = B.browser;
      if (typeof MouseEvent == "function" && (u.newEdge || !u.ie && !u.edge)) {
        var h = document.createElement("a");
        h.download = a + "." + s, h.target = "_blank", h.href = l;
        var c = new MouseEvent("click", {
          view: document.defaultView,
          bubbles: true,
          cancelable: false
        });
        h.dispatchEvent(c);
      } else if (window.navigator.msSaveOrOpenBlob || o) {
        var d = l.split(","), p = d[0].indexOf("base64") > -1, f = o ? decodeURIComponent(d[1]) : d[1];
        p && (f = window.atob(f));
        var v = a + "." + s;
        if (window.navigator.msSaveOrOpenBlob) {
          for (var g = f.length, m = new Uint8Array(g); g--; ) m[g] = f.charCodeAt(g);
          var _ = new Blob([
            m
          ]);
          window.navigator.msSaveOrOpenBlob(_, v);
        } else {
          var x = document.createElement("iframe");
          document.body.appendChild(x);
          var b = x.contentWindow, w = b.document;
          w.open("image/svg+xml", "replace"), w.write(f), w.close(), b.focus(), w.execCommand("SaveAs", true, v), document.body.removeChild(x);
        }
      } else {
        var T = r.get("lang"), A = '<body style="margin:0;"><img src="' + l + '" style="max-width:100%;" title="' + (T && T[0] || "") + '" /></body>', S = window.open();
        S.document.write(A), S.document.title = a;
      }
    }, t.getDefaultOption = function(e) {
      var n = {
        show: true,
        icon: "M4.7,22.9L29.3,45.5L54.7,23.4M4.6,43.6L4.6,58L53.8,58L53.8,43.6M29.2,45.1L29.2,0",
        title: e.getLocaleModel().get([
          "toolbox",
          "saveAsImage",
          "title"
        ]),
        type: "png",
        connectedBackgroundColor: "#fff",
        name: "",
        excludeComponents: [
          "toolbox"
        ],
        lang: e.getLocaleModel().get([
          "toolbox",
          "saveAsImage",
          "lang"
        ])
      };
      return n;
    }, t;
  })(G), wi = "__ec_magicType_stack__", Wo = [
    [
      "line",
      "bar"
    ],
    [
      "stack"
    ]
  ], No = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.prototype.getIcons = function() {
      var e = this.model, n = e.get("icon"), r = {};
      return y(e.get("type"), function(a) {
        n[a] && (r[a] = n[a]);
      }), r;
    }, t.getDefaultOption = function(e) {
      var n = {
        show: true,
        type: [],
        icon: {
          line: "M4.1,28.9h7.1l9.3-22l7.4,38l9.7-19.7l3,12.8h14.9M4.1,58h51.4",
          bar: "M6.7,22.9h10V48h-10V22.9zM24.9,13h10v35h-10V13zM43.2,2h10v46h-10V2zM3.1,58h53.7",
          stack: "M8.2,38.4l-8.4,4.1l30.6,15.3L60,42.5l-8.1-4.1l-21.5,11L8.2,38.4z M51.9,30l-8.1,4.2l-13.4,6.9l-13.9-6.9L8.2,30l-8.4,4.2l8.4,4.2l22.2,11l21.5-11l8.1-4.2L51.9,30z M51.9,21.7l-8.1,4.2L35.7,30l-5.3,2.8L24.9,30l-8.4-4.1l-8.3-4.2l-8.4,4.2L8.2,30l8.3,4.2l13.9,6.9l13.4-6.9l8.1-4.2l8.1-4.1L51.9,21.7zM30.4,2.2L-0.2,17.5l8.4,4.1l8.3,4.2l8.4,4.2l5.5,2.7l5.3-2.7l8.1-4.2l8.1-4.2l8.1-4.1L30.4,2.2z"
        },
        title: e.getLocaleModel().get([
          "toolbox",
          "magicType",
          "title"
        ]),
        option: {},
        seriesIndex: {}
      };
      return n;
    }, t.prototype.onclick = function(e, n, r) {
      var a = this.model, o = a.get([
        "seriesIndex",
        r
      ]);
      if (Ti[r]) {
        var s = {
          series: []
        }, l = function(c) {
          var d = c.subType, p = c.id, f = Ti[r](d, p, c, a);
          f && (V(f, c.option), s.series.push(f));
          var v = c.coordinateSystem;
          if (v && v.type === "cartesian2d" && (r === "line" || r === "bar")) {
            var g = v.getAxesByScale("ordinal")[0];
            if (g) {
              var m = g.dim, _ = m + "Axis", x = c.getReferringComponents(_, tt).models[0], b = x.componentIndex;
              s[_] = s[_] || [];
              for (var w = 0; w <= b; w++) s[_][b] = s[_][b] || {};
              s[_][b].boundaryGap = r === "bar";
            }
          }
        };
        y(Wo, function(c) {
          F(c, r) >= 0 && y(c, function(d) {
            a.setIconStatus(d, "normal");
          });
        }), a.setIconStatus(r, "emphasis"), e.eachComponent({
          mainType: "series",
          query: o == null ? null : {
            seriesIndex: o
          }
        }, l);
        var u, h = r;
        r === "stack" && (u = P({
          stack: a.option.title.tiled,
          tiled: a.option.title.stack
        }, a.option.title), a.get([
          "iconStatus",
          r
        ]) !== "emphasis" && (h = "tiled")), n.dispatchAction({
          type: "changeMagicType",
          currentType: h,
          newOption: s,
          newTitle: u,
          featureName: "magicType"
        });
      }
    }, t;
  })(G), Ti = {
    line: function(i, t, e, n) {
      if (i === "bar") return P({
        id: t,
        type: "line",
        data: e.get("data"),
        stack: e.get("stack"),
        markPoint: e.get("markPoint"),
        markLine: e.get("markLine")
      }, n.get([
        "option",
        "line"
      ]) || {}, true);
    },
    bar: function(i, t, e, n) {
      if (i === "line") return P({
        id: t,
        type: "bar",
        data: e.get("data"),
        stack: e.get("stack"),
        markPoint: e.get("markPoint"),
        markLine: e.get("markLine")
      }, n.get([
        "option",
        "bar"
      ]) || {}, true);
    },
    stack: function(i, t, e, n) {
      var r = e.get("stack") === wi;
      if (i === "line" || i === "bar") return n.setIconStatus("stack", r ? "normal" : "emphasis"), P({
        id: t,
        stack: r ? "" : wi
      }, n.get([
        "option",
        "stack"
      ]) || {}, true);
    }
  };
  Vt({
    type: "changeMagicType",
    event: "magicTypeChanged",
    update: "prepareAndUpdate"
  }, function(i, t) {
    t.mergeOption(i.newOption);
  });
  var Nt = new Array(60).join("-"), _t = "	";
  function Yo(i) {
    var t = {}, e = [], n = [];
    return i.eachRawSeries(function(r) {
      var a = r.coordinateSystem;
      if (a && (a.type === "cartesian2d" || a.type === "polar")) {
        var o = a.getBaseAxis();
        if (o.type === "category") {
          var s = o.dim + "_" + o.index;
          t[s] || (t[s] = {
            categoryAxis: o,
            valueAxis: a.getOtherAxis(o),
            series: []
          }, n.push({
            axisDim: o.dim,
            axisIndex: o.index
          })), t[s].series.push(r);
        } else e.push(r);
      } else e.push(r);
    }), {
      seriesGroupByCategoryAxis: t,
      other: e,
      meta: n
    };
  }
  function Go(i) {
    var t = [];
    return y(i, function(e, n) {
      var r = e.categoryAxis, a = e.valueAxis, o = a.dim, s = [
        " "
      ].concat(H(e.series, function(p) {
        return p.name;
      })), l = [
        r.model.getCategories()
      ];
      y(e.series, function(p) {
        var f = p.getRawData();
        l.push(p.getRawData().mapArray(f.mapDimension(o), function(v) {
          return v;
        }));
      });
      for (var u = [
        s.join(_t)
      ], h = 0; h < l[0].length; h++) {
        for (var c = [], d = 0; d < l.length; d++) c.push(l[d][h]);
        u.push(c.join(_t));
      }
      t.push(u.join(`
`));
    }), t.join(`

` + Nt + `

`);
  }
  function Fo(i) {
    return H(i, function(t) {
      var e = t.getRawData(), n = [
        t.name
      ], r = [];
      return e.each(e.dimensions, function() {
        for (var a = arguments.length, o = arguments[a - 1], s = e.getName(o), l = 0; l < a - 1; l++) r[l] = arguments[l];
        n.push((s ? s + _t : "") + r.join(_t));
      }), n.join(`
`);
    }).join(`

` + Nt + `

`);
  }
  function Zo(i) {
    var t = Yo(i);
    return {
      value: Hi([
        Go(t.seriesGroupByCategoryAxis),
        Fo(t.other)
      ], function(e) {
        return !!e.replace(/[\n\t\s]/g, "");
      }).join(`

` + Nt + `

`),
      meta: t.meta
    };
  }
  function Ht(i) {
    return i.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
  }
  function Xo(i) {
    var t = i.slice(0, i.indexOf(`
`));
    if (t.indexOf(_t) >= 0) return true;
  }
  var ge = new RegExp("[" + _t + "]+", "g");
  function $o(i) {
    for (var t = i.split(/\n+/g), e = Ht(t.shift()).split(ge), n = [], r = H(e, function(l) {
      return {
        name: l,
        data: []
      };
    }), a = 0; a < t.length; a++) {
      var o = Ht(t[a]).split(ge);
      n.push(o.shift());
      for (var s = 0; s < o.length; s++) r[s] && (r[s].data[a] = o[s]);
    }
    return {
      series: r,
      categories: n
    };
  }
  function Uo(i) {
    for (var t = i.split(/\n+/g), e = Ht(t.shift()), n = [], r = 0; r < t.length; r++) {
      var a = Ht(t[r]);
      if (a) {
        var o = a.split(ge), s = "", l = void 0, u = false;
        isNaN(o[0]) ? (u = true, s = o[0], o = o.slice(1), n[r] = {
          name: s,
          value: []
        }, l = n[r].value) : l = n[r] = [];
        for (var h = 0; h < o.length; h++) l.push(+o[h]);
        l.length === 1 && (u ? n[r].value = l[0] : n[r] = l[0]);
      }
    }
    return {
      name: e,
      data: n
    };
  }
  function Ko(i, t) {
    var e = i.split(new RegExp(`
*` + Nt + `
*`, "g")), n = {
      series: []
    };
    return y(e, function(r, a) {
      if (Xo(r)) {
        var o = $o(r), s = t[a], l = s.axisDim + "Axis";
        s && (n[l] = n[l] || [], n[l][s.axisIndex] = {
          data: o.categories
        }, n.series = n.series.concat(o.series));
      } else {
        var o = Uo(r);
        n.series.push(o);
      }
    }), n;
  }
  var qo = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.prototype.onclick = function(e, n) {
      setTimeout(function() {
        n.dispatchAction({
          type: "hideTip"
        });
      });
      var r = n.getDom(), a = this.model;
      this._dom && r.removeChild(this._dom);
      var o = document.createElement("div");
      o.style.cssText = "position:absolute;top:0;bottom:0;left:0;right:0;padding:5px", o.style.backgroundColor = a.get("backgroundColor") || "#fff";
      var s = document.createElement("h4"), l = a.get("lang") || [];
      s.innerHTML = l[0] || a.get("title"), s.style.cssText = "margin:10px 20px", s.style.color = a.get("textColor");
      var u = document.createElement("div"), h = document.createElement("textarea");
      u.style.cssText = "overflow:auto";
      var c = a.get("optionToContent"), d = a.get("contentToOption"), p = Zo(e);
      if (rt(c)) {
        var f = c(n.getOption());
        z(f) ? u.innerHTML = f : ne(f) && u.appendChild(f);
      } else {
        h.readOnly = a.get("readOnly");
        var v = h.style;
        v.cssText = "display:block;width:100%;height:100%;font-family:monospace;font-size:14px;line-height:1.6rem;resize:none;box-sizing:border-box;outline:none", v.color = a.get("textColor"), v.borderColor = a.get("textareaBorderColor"), v.backgroundColor = a.get("textareaColor"), h.value = p.value, u.appendChild(h);
      }
      var g = p.meta, m = document.createElement("div");
      m.style.cssText = "position:absolute;bottom:5px;left:0;right:0";
      var _ = "float:right;margin-right:20px;border:none;cursor:pointer;padding:2px 5px;font-size:12px;border-radius:3px", x = document.createElement("div"), b = document.createElement("div");
      _ += ";background-color:" + a.get("buttonColor"), _ += ";color:" + a.get("buttonTextColor");
      var w = this;
      function T() {
        r.removeChild(o), w._dom = null;
      }
      ze(x, "click", T), ze(b, "click", function() {
        if (d == null && c != null || d != null && c == null) {
          T();
          return;
        }
        var A;
        try {
          rt(d) ? A = d(u, n.getOption()) : A = Ko(h.value, g);
        } catch (S) {
          throw T(), new Error("Data view format error " + S);
        }
        A && n.dispatchAction({
          type: "changeDataView",
          newOption: A
        }), T();
      }), x.innerHTML = l[1], b.innerHTML = l[2], b.style.cssText = x.style.cssText = _, !a.get("readOnly") && m.appendChild(b), m.appendChild(x), o.appendChild(s), o.appendChild(u), o.appendChild(m), u.style.height = r.clientHeight - 80 + "px", r.appendChild(o), this._dom = o;
    }, t.prototype.remove = function(e, n) {
      this._dom && n.getDom().removeChild(this._dom);
    }, t.prototype.dispose = function(e, n) {
      this.remove(e, n);
    }, t.getDefaultOption = function(e) {
      var n = {
        show: true,
        readOnly: false,
        optionToContent: null,
        contentToOption: null,
        icon: "M17.5,17.3H33 M17.5,17.3H33 M45.4,29.5h-28 M11.5,2v56H51V14.8L38.4,2H11.5z M38.4,2.2v12.7H51 M45.4,41.7h-28",
        title: e.getLocaleModel().get([
          "toolbox",
          "dataView",
          "title"
        ]),
        lang: e.getLocaleModel().get([
          "toolbox",
          "dataView",
          "lang"
        ]),
        backgroundColor: "#fff",
        textColor: "#000",
        textareaColor: "#fff",
        textareaBorderColor: "#333",
        buttonColor: "#c23531",
        buttonTextColor: "#fff"
      };
      return n;
    }, t;
  })(G);
  function Qo(i, t) {
    return H(i, function(e, n) {
      var r = t && t[n];
      if (et(r) && !j(r)) {
        var a = et(e) && !j(e);
        a || (e = {
          value: e
        });
        var o = r.name != null && e.name == null;
        return e = V(e, r), o && delete e.name, e;
      } else return e;
    });
  }
  Vt({
    type: "changeDataView",
    event: "dataViewChanged",
    update: "prepareAndUpdate"
  }, function(i, t) {
    var e = [];
    y(i.newOption.series, function(n) {
      var r = t.getSeriesByName(n.name)[0];
      if (!r) e.push(xt({
        type: "scatter"
      }, n));
      else {
        var a = r.get("data");
        e.push({
          name: n.name,
          data: Qo(n.data, a)
        });
      }
    }), t.mergeOption(V({
      series: e
    }, i.newOption));
  });
  var wr = y, Tr = kt();
  function Jo(i, t) {
    var e = De(i);
    wr(t, function(n, r) {
      for (var a = e.length - 1; a >= 0; a--) {
        var o = e[a];
        if (o[r]) break;
      }
      if (a < 0) {
        var s = i.queryComponents({
          mainType: "dataZoom",
          subType: "select",
          id: r
        })[0];
        if (s) {
          var l = s.getPercentRange();
          e[0][r] = {
            dataZoomId: r,
            start: l[0],
            end: l[1]
          };
        }
      }
    }), e.push(t);
  }
  function ts(i) {
    var t = De(i), e = t[t.length - 1];
    t.length > 1 && t.pop();
    var n = {};
    return wr(e, function(r, a) {
      for (var o = t.length - 1; o >= 0; o--) if (r = t[o][a], r) {
        n[a] = r;
        break;
      }
    }), n;
  }
  function es(i) {
    Tr(i).snapshots = null;
  }
  function is(i) {
    return De(i).length;
  }
  function De(i) {
    var t = Tr(i);
    return t.snapshots || (t.snapshots = [
      {}
    ]), t.snapshots;
  }
  var rs = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.prototype.onclick = function(e, n) {
      es(e), n.dispatchAction({
        type: "restore",
        from: this.uid
      });
    }, t.getDefaultOption = function(e) {
      var n = {
        show: true,
        icon: "M3.8,33.4 M47,18.9h9.8V8.7 M56.3,20.1 C52.1,9,40.5,0.6,26.8,2.1C12.6,3.7,1.6,16.2,2.1,30.6 M13,41.1H3.1v10.2 M3.7,39.9c4.2,11.1,15.8,19.5,29.5,18 c14.2-1.6,25.2-14.1,24.7-28.5",
        title: e.getLocaleModel().get([
          "toolbox",
          "restore",
          "title"
        ])
      };
      return n;
    }, t;
  })(G);
  Vt({
    type: "restore",
    event: "restore",
    update: "prepareAndUpdate"
  }, function(i, t) {
    t.resetOption("recreate");
  });
  var ns = [
    "grid",
    "xAxis",
    "yAxis",
    "geo",
    "graph",
    "polar",
    "radiusAxis",
    "angleAxis",
    "bmap"
  ], Ar = (function() {
    function i(t, e, n) {
      var r = this;
      this._targetInfoList = [];
      var a = Ai(e, t);
      y(as, function(o, s) {
        (!n || !n.include || F(n.include, s) >= 0) && o(a, r._targetInfoList);
      });
    }
    return i.prototype.setOutputRanges = function(t, e) {
      return this.matchOutputRanges(t, e, function(n, r, a) {
        if ((n.coordRanges || (n.coordRanges = [])).push(r), !n.coordRange) {
          n.coordRange = r;
          var o = Jt[n.brushType](0, a, r);
          n.__rangeOffset = {
            offset: Li[n.brushType](o.values, n.range, [
              1,
              1
            ]),
            xyMinMax: o.xyMinMax
          };
        }
      }), t;
    }, i.prototype.matchOutputRanges = function(t, e, n) {
      y(t, function(r) {
        var a = this.findTargetInfo(r, e);
        a && a !== true && y(a.coordSyses, function(o) {
          var s = Jt[r.brushType](1, o, r.range, true);
          n(r, s.values, o, e);
        });
      }, this);
    }, i.prototype.setInputRanges = function(t, e) {
      y(t, function(n) {
        var r = this.findTargetInfo(n, e);
        if (n.range = n.range || [], r && r !== true) {
          n.panelId = r.panelId;
          var a = Jt[n.brushType](0, r.coordSys, n.coordRange), o = n.__rangeOffset;
          n.range = o ? Li[n.brushType](a.values, o.offset, os(a.xyMinMax, o.xyMinMax)) : a.values;
        }
      }, this);
    }, i.prototype.makePanelOpts = function(t, e) {
      return H(this._targetInfoList, function(n) {
        var r = n.getPanelRect();
        return {
          panelId: n.panelId,
          defaultBrushType: e ? e(n) : null,
          clipPath: Xa(r),
          isTargetByCursor: Ua(r, t, n.coordSysModel),
          getLinearBrushOtherExtent: $a(r)
        };
      });
    }, i.prototype.controlSeries = function(t, e, n) {
      var r = this.findTargetInfo(t, n);
      return r === true || r && F(r.coordSyses, e.coordinateSystem) >= 0;
    }, i.prototype.findTargetInfo = function(t, e) {
      for (var n = this._targetInfoList, r = Ai(e, t), a = 0; a < n.length; a++) {
        var o = n[a], s = t.panelId;
        if (s) {
          if (o.panelId === s) return o;
        } else for (var l = 0; l < Si.length; l++) if (Si[l](r, o)) return o;
      }
      return true;
    }, i;
  })();
  function me(i) {
    return i[0] > i[1] && i.reverse(), i;
  }
  function Ai(i, t) {
    return Xi(i, t, {
      includeMainTypes: ns
    });
  }
  var as = {
    grid: function(i, t) {
      var e = i.xAxisModels, n = i.yAxisModels, r = i.gridModels, a = yt(), o = {}, s = {};
      !e && !n && !r || (y(e, function(l) {
        var u = l.axis.grid.model;
        a.set(u.id, u), o[u.id] = true;
      }), y(n, function(l) {
        var u = l.axis.grid.model;
        a.set(u.id, u), s[u.id] = true;
      }), y(r, function(l) {
        a.set(l.id, l), o[l.id] = true, s[l.id] = true;
      }), a.each(function(l) {
        var u = l.coordinateSystem, h = [];
        y(u.getCartesians(), function(c, d) {
          (F(e, c.getAxis("x").model) >= 0 || F(n, c.getAxis("y").model) >= 0) && h.push(c);
        }), t.push({
          panelId: "grid--" + l.id,
          gridModel: l,
          coordSysModel: l,
          coordSys: h[0],
          coordSyses: h,
          getPanelRect: Ci.grid,
          xAxisDeclared: o[l.id],
          yAxisDeclared: s[l.id]
        });
      }));
    },
    geo: function(i, t) {
      y(i.geoModels, function(e) {
        var n = e.coordinateSystem;
        t.push({
          panelId: "geo--" + e.id,
          geoModel: e,
          coordSysModel: e,
          coordSys: n,
          coordSyses: [
            n
          ],
          getPanelRect: Ci.geo
        });
      });
    }
  }, Si = [
    function(i, t) {
      var e = i.xAxisModel, n = i.yAxisModel, r = i.gridModel;
      return !r && e && (r = e.axis.grid.model), !r && n && (r = n.axis.grid.model), r && r === t.gridModel;
    },
    function(i, t) {
      var e = i.geoModel;
      return e && e === t.geoModel;
    }
  ], Ci = {
    grid: function() {
      return this.coordSys.master.getRect().clone();
    },
    geo: function() {
      var i = this.coordSys, t = i.getBoundingRect().clone();
      return t.applyTransform(Ni(i)), t;
    }
  }, Jt = {
    lineX: k(Mi, 0),
    lineY: k(Mi, 1),
    rect: function(i, t, e, n) {
      var r = i ? t.pointToData([
        e[0][0],
        e[1][0]
      ], n) : t.dataToPoint([
        e[0][0],
        e[1][0]
      ], n), a = i ? t.pointToData([
        e[0][1],
        e[1][1]
      ], n) : t.dataToPoint([
        e[0][1],
        e[1][1]
      ], n), o = [
        me([
          r[0],
          a[0]
        ]),
        me([
          r[1],
          a[1]
        ])
      ];
      return {
        values: o,
        xyMinMax: o
      };
    },
    polygon: function(i, t, e, n) {
      var r = [
        [
          1 / 0,
          -1 / 0
        ],
        [
          1 / 0,
          -1 / 0
        ]
      ], a = H(e, function(o) {
        var s = i ? t.pointToData(o, n) : t.dataToPoint(o, n);
        return r[0][0] = Math.min(r[0][0], s[0]), r[1][0] = Math.min(r[1][0], s[1]), r[0][1] = Math.max(r[0][1], s[0]), r[1][1] = Math.max(r[1][1], s[1]), s;
      });
      return {
        values: a,
        xyMinMax: r
      };
    }
  };
  function Mi(i, t, e, n) {
    var r = e.getAxis([
      "x",
      "y"
    ][i]), a = me(H([
      0,
      1
    ], function(s) {
      return t ? r.coordToData(r.toLocalCoord(n[s]), true) : r.toGlobalCoord(r.dataToCoord(n[s]));
    })), o = [];
    return o[i] = a, o[1 - i] = [
      NaN,
      NaN
    ], {
      values: a,
      xyMinMax: o
    };
  }
  var Li = {
    lineX: k(Di, 0),
    lineY: k(Di, 1),
    rect: function(i, t, e) {
      return [
        [
          i[0][0] - e[0] * t[0][0],
          i[0][1] - e[0] * t[0][1]
        ],
        [
          i[1][0] - e[1] * t[1][0],
          i[1][1] - e[1] * t[1][1]
        ]
      ];
    },
    polygon: function(i, t, e) {
      return H(i, function(n, r) {
        return [
          n[0] - e[0] * t[r][0],
          n[1] - e[1] * t[r][1]
        ];
      });
    }
  };
  function Di(i, t, e, n) {
    return [
      t[0] - n[i] * e[0],
      t[1] - n[i] * e[1]
    ];
  }
  function os(i, t) {
    var e = Ii(i), n = Ii(t), r = [
      e[0] / n[0],
      e[1] / n[1]
    ];
    return isNaN(r[0]) && (r[0] = 1), isNaN(r[1]) && (r[1] = 1), r;
  }
  function Ii(i) {
    return i ? [
      i[0][1] - i[0][0],
      i[1][1] - i[1][0]
    ] : [
      NaN,
      NaN
    ];
  }
  var xe = y, ss = Ln("toolbox-dataZoom_"), ls = (function(i) {
    C(t, i);
    function t() {
      return i !== null && i.apply(this, arguments) || this;
    }
    return t.prototype.render = function(e, n, r, a) {
      this._brushController || (this._brushController = new Ha(r.getZr()), this._brushController.on("brush", Z(this._onBrush, this)).mount()), cs(e, n, this, a, r), hs(e, n);
    }, t.prototype.onclick = function(e, n, r) {
      us[r].call(this);
    }, t.prototype.remove = function(e, n) {
      this._brushController && this._brushController.unmount();
    }, t.prototype.dispose = function(e, n) {
      this._brushController && this._brushController.dispose();
    }, t.prototype._onBrush = function(e) {
      var n = e.areas;
      if (!e.isEnd || !n.length) return;
      var r = {}, a = this.ecModel;
      this._brushController.updateCovers([]);
      var o = new Ar(Ie(this.model), a, {
        include: [
          "grid"
        ]
      });
      o.matchOutputRanges(n, a, function(u, h, c) {
        if (c.type === "cartesian2d") {
          var d = u.brushType;
          d === "rect" ? (s("x", c, h[0]), s("y", c, h[1])) : s({
            lineX: "x",
            lineY: "y"
          }[d], c, h);
        }
      }), Jo(a, r), this._dispatchZoomAction(r);
      function s(u, h, c) {
        var d = h.getAxis(u), p = d.model, f = l(u, p, a), v = f.findRepresentativeAxisProxy(p).getMinMaxSpan();
        (v.minValueSpan != null || v.maxValueSpan != null) && (c = ir(0, c.slice(), d.scale.getExtent(), 0, v.minValueSpan, v.maxValueSpan)), f && (r[f.id] = {
          dataZoomId: f.id,
          startValue: c[0],
          endValue: c[1]
        });
      }
      function l(u, h, c) {
        var d;
        return c.eachComponent({
          mainType: "dataZoom",
          subType: "select"
        }, function(p) {
          var f = p.getAxisModel(u, h.componentIndex);
          f && (d = p);
        }), d;
      }
    }, t.prototype._dispatchZoomAction = function(e) {
      var n = [];
      xe(e, function(r, a) {
        n.push(N(r));
      }), n.length && this.api.dispatchAction({
        type: "dataZoom",
        from: this.uid,
        batch: n
      });
    }, t.getDefaultOption = function(e) {
      var n = {
        show: true,
        filterMode: "filter",
        icon: {
          zoom: "M0,13.5h26.9 M13.5,26.9V0 M32.1,13.5H58V58H13.5 V32.1",
          back: "M22,1.4L9.9,13.5l12.3,12.3 M10.3,13.5H54.9v44.6 H10.3v-26"
        },
        title: e.getLocaleModel().get([
          "toolbox",
          "dataZoom",
          "title"
        ]),
        brushStyle: {
          borderWidth: 0,
          color: "rgba(210,219,238,0.2)"
        }
      };
      return n;
    }, t;
  })(G), us = {
    zoom: function() {
      var i = !this._isZoomActive;
      this.api.dispatchAction({
        type: "takeGlobalCursor",
        key: "dataZoomSelect",
        dataZoomSelectActive: i
      });
    },
    back: function() {
      this._dispatchZoomAction(ts(this.ecModel));
    }
  };
  function Ie(i) {
    var t = {
      xAxisIndex: i.get("xAxisIndex", true),
      yAxisIndex: i.get("yAxisIndex", true),
      xAxisId: i.get("xAxisId", true),
      yAxisId: i.get("yAxisId", true)
    };
    return t.xAxisIndex == null && t.xAxisId == null && (t.xAxisIndex = "all"), t.yAxisIndex == null && t.yAxisId == null && (t.yAxisIndex = "all"), t;
  }
  function hs(i, t) {
    i.setIconStatus("back", is(t) > 1 ? "emphasis" : "normal");
  }
  function cs(i, t, e, n, r) {
    var a = e._isZoomActive;
    n && n.type === "takeGlobalCursor" && (a = n.key === "dataZoomSelect" ? n.dataZoomSelectActive : false), e._isZoomActive = a, i.setIconStatus("zoom", a ? "emphasis" : "normal");
    var o = new Ar(Ie(i), t, {
      include: [
        "grid"
      ]
    }), s = o.makePanelOpts(r, function(l) {
      return l.xAxisDeclared && !l.yAxisDeclared ? "lineX" : !l.xAxisDeclared && l.yAxisDeclared ? "lineY" : "rect";
    });
    e._brushController.setPanels(s).enableBrush(a && s.length ? {
      brushType: "auto",
      brushStyle: i.getModel("brushStyle").getItemStyle()
    } : false);
  }
  Mn("dataZoom", function(i) {
    var t = i.getComponent("toolbox", 0), e = [
      "feature",
      "dataZoom"
    ];
    if (!t || t.get(e) == null) return;
    var n = t.getModel(e), r = [], a = Ie(n), o = Xi(i, a);
    xe(o.xAxisModels, function(l) {
      return s(l, "xAxis", "xAxisIndex");
    }), xe(o.yAxisModels, function(l) {
      return s(l, "yAxis", "yAxisIndex");
    });
    function s(l, u, h) {
      var c = l.componentIndex, d = {
        type: "select",
        $fromToolbox: true,
        filterMode: n.get("filterMode", true) || "filter",
        id: ss + u + c
      };
      d[h] = c, r.push(d);
    }
    return r;
  });
  fs = function(i) {
    i.registerComponentModel(Eo), i.registerComponentView(Ho), At("saveAsImage", Vo), At("magicType", No), At("dataView", qo), At("dataZoom", ls), At("restore", rs), Lt(Oo);
  };
  var ds = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.type = "tooltip", t.dependencies = [
      "axisPointer"
    ], t.defaultOption = {
      z: 60,
      show: true,
      showContent: true,
      trigger: "item",
      triggerOn: "mousemove|click",
      alwaysShowContent: false,
      displayMode: "single",
      renderMode: "auto",
      confine: null,
      showDelay: 0,
      hideDelay: 100,
      transitionDuration: 0.4,
      enterable: false,
      backgroundColor: "#fff",
      shadowBlur: 10,
      shadowColor: "rgba(0, 0, 0, .2)",
      shadowOffsetX: 1,
      shadowOffsetY: 2,
      borderRadius: 4,
      borderWidth: 1,
      padding: null,
      extraCssText: "",
      axisPointer: {
        type: "line",
        axis: "auto",
        animation: "auto",
        animationDurationUpdate: 200,
        animationEasingUpdate: "exponentialOut",
        crossStyle: {
          color: "#999",
          width: 1,
          type: "dashed",
          textStyle: {}
        }
      },
      textStyle: {
        color: "#666",
        fontSize: 14
      }
    }, t;
  })(ct);
  function Sr(i) {
    var t = i.get("confine");
    return t != null ? !!t : i.get("renderMode") === "richText";
  }
  function Cr(i) {
    if (B.domSupported) {
      for (var t = document.documentElement.style, e = 0, n = i.length; e < n; e++) if (i[e] in t) return i[e];
    }
  }
  var Mr = Cr([
    "transform",
    "webkitTransform",
    "OTransform",
    "MozTransform",
    "msTransform"
  ]), ps = Cr([
    "webkitTransition",
    "transition",
    "OTransition",
    "MozTransition",
    "msTransition"
  ]);
  function Lr(i, t) {
    if (!i) return t;
    t = $i(t, true);
    var e = i.indexOf(t);
    return i = e === -1 ? t : "-" + i.slice(0, e) + "-" + t, i.toLowerCase();
  }
  function vs(i, t) {
    var e = i.currentStyle || document.defaultView && document.defaultView.getComputedStyle(i);
    return e ? e[t] : null;
  }
  var gs = Lr(ps, "transition"), ke = Lr(Mr, "transform"), ms = "position:absolute;display:block;border-style:solid;white-space:nowrap;z-index:9999999;" + (B.transform3dSupported ? "will-change:transform;" : "");
  function xs(i) {
    return i = i === "left" ? "right" : i === "right" ? "left" : i === "top" ? "bottom" : "top", i;
  }
  function ys(i, t, e) {
    if (!z(e) || e === "inside") return "";
    var n = i.get("backgroundColor"), r = i.get("borderWidth");
    t = zt(t);
    var a = xs(e), o = Math.max(Math.round(r) * 1.5, 6), s = "", l = ke + ":", u;
    F([
      "left",
      "right"
    ], a) > -1 ? (s += "top:50%", l += "translateY(-50%) rotate(" + (u = a === "left" ? -225 : -45) + "deg)") : (s += "left:50%", l += "translateX(-50%) rotate(" + (u = a === "top" ? 225 : 45) + "deg)");
    var h = u * Math.PI / 180, c = o + r, d = c * Math.abs(Math.cos(h)) + c * Math.abs(Math.sin(h)), p = Math.round(((d - Math.SQRT2 * r) / 2 + Math.SQRT2 * r - (d - c) / 2) * 100) / 100;
    s += ";" + a + ":-" + p + "px";
    var f = t + " solid " + r + "px;", v = [
      "position:absolute;width:" + o + "px;height:" + o + "px;z-index:-1;",
      s + ";" + l + ";",
      "border-bottom:" + f,
      "border-right:" + f,
      "background-color:" + n + ";"
    ];
    return '<div style="' + v.join("") + '"></div>';
  }
  function bs(i, t) {
    var e = "cubic-bezier(0.23,1,0.32,1)", n = " " + i / 2 + "s " + e, r = "opacity" + n + ",visibility" + n;
    return t || (n = " " + i + "s " + e, r += B.transformSupported ? "," + ke + n : ",left" + n + ",top" + n), gs + ":" + r;
  }
  function ki(i, t, e) {
    var n = i.toFixed(0) + "px", r = t.toFixed(0) + "px";
    if (!B.transformSupported) return e ? "top:" + r + ";left:" + n + ";" : [
      [
        "top",
        r
      ],
      [
        "left",
        n
      ]
    ];
    var a = B.transform3dSupported, o = "translate" + (a ? "3d" : "") + "(" + n + "," + r + (a ? ",0" : "") + ")";
    return e ? "top:0;left:0;" + ke + ":" + o + ";" : [
      [
        "top",
        0
      ],
      [
        "left",
        0
      ],
      [
        Mr,
        o
      ]
    ];
  }
  function _s(i) {
    var t = [], e = i.get("fontSize"), n = i.getTextColor();
    n && t.push("color:" + n), t.push("font:" + i.getFont());
    var r = vt(i.get("lineHeight"), Math.round(e * 3 / 2));
    e && t.push("line-height:" + r + "px");
    var a = i.get("textShadowColor"), o = i.get("textShadowBlur") || 0, s = i.get("textShadowOffsetX") || 0, l = i.get("textShadowOffsetY") || 0;
    return a && o && t.push("text-shadow:" + s + "px " + l + "px " + o + "px " + a), y([
      "decoration",
      "align"
    ], function(u) {
      var h = i.get(u);
      h && t.push("text-" + u + ":" + h);
    }), t.join(";");
  }
  function ws(i, t, e) {
    var n = [], r = i.get("transitionDuration"), a = i.get("backgroundColor"), o = i.get("shadowBlur"), s = i.get("shadowColor"), l = i.get("shadowOffsetX"), u = i.get("shadowOffsetY"), h = i.getModel("textStyle"), c = Ui(i, "html"), d = l + "px " + u + "px " + o + "px " + s;
    return n.push("box-shadow:" + d), t && r && n.push(bs(r, e)), a && n.push("background-color:" + a), y([
      "width",
      "color",
      "radius"
    ], function(p) {
      var f = "border-" + p, v = $i(f), g = i.get(v);
      g != null && n.push(f + ":" + g + (p === "color" ? "" : "px"));
    }), n.push(_s(h)), c != null && n.push("padding:" + be(c).join("px ") + "px"), n.join(";") + ";";
  }
  function Pi(i, t, e, n, r) {
    var a = t && t.painter;
    if (e) {
      var o = a && a.getViewportRoot();
      o && In(i, o, e, n, r);
    } else {
      i[0] = n, i[1] = r;
      var s = a && a.getViewportRootOffset();
      s && (i[0] += s.offsetLeft, i[1] += s.offsetTop);
    }
    i[2] = i[0] / t.getWidth(), i[3] = i[1] / t.getHeight();
  }
  var Ts = (function() {
    function i(t, e) {
      if (this._show = false, this._styleCoord = [
        0,
        0,
        0,
        0
      ], this._enterable = true, this._alwaysShowContent = false, this._firstShow = true, this._longHide = true, B.wxa) return null;
      var n = document.createElement("div");
      n.domBelongToZr = true, this.el = n;
      var r = this._zr = t.getZr(), a = e.appendTo, o = a && (z(a) ? document.querySelector(a) : ne(a) ? a : rt(a) && a(t.getDom()));
      Pi(this._styleCoord, r, o, t.getWidth() / 2, t.getHeight() / 2), (o || t.getDom()).appendChild(n), this._api = t, this._container = o;
      var s = this;
      n.onmouseenter = function() {
        s._enterable && (clearTimeout(s._hideTimeout), s._show = true), s._inContent = true;
      }, n.onmousemove = function(l) {
        if (l = l || window.event, !s._enterable) {
          var u = r.handler, h = r.painter.getViewportRoot();
          Dn(h, l, true), u.dispatch("mousemove", l);
        }
      }, n.onmouseleave = function() {
        s._inContent = false, s._enterable && s._show && s.hideLater(s._hideDelay);
      };
    }
    return i.prototype.update = function(t) {
      if (!this._container) {
        var e = this._api.getDom(), n = vs(e, "position"), r = e.style;
        r.position !== "absolute" && n !== "absolute" && (r.position = "relative");
      }
      var a = t.get("alwaysShowContent");
      a && this._moveIfResized(), this._alwaysShowContent = a, this.el.className = t.get("className") || "";
    }, i.prototype.show = function(t, e) {
      clearTimeout(this._hideTimeout), clearTimeout(this._longHideTimeout);
      var n = this.el, r = n.style, a = this._styleCoord;
      n.innerHTML ? r.cssText = ms + ws(t, !this._firstShow, this._longHide) + ki(a[0], a[1], true) + ("border-color:" + zt(e) + ";") + (t.get("extraCssText") || "") + (";pointer-events:" + (this._enterable ? "auto" : "none")) : r.display = "none", this._show = true, this._firstShow = false, this._longHide = false;
    }, i.prototype.setContent = function(t, e, n, r, a) {
      var o = this.el;
      if (t == null) {
        o.innerHTML = "";
        return;
      }
      var s = "";
      if (z(a) && n.get("trigger") === "item" && !Sr(n) && (s = ys(n, r, a)), z(t)) o.innerHTML = t + s;
      else if (t) {
        o.innerHTML = "", j(t) || (t = [
          t
        ]);
        for (var l = 0; l < t.length; l++) ne(t[l]) && t[l].parentNode !== o && o.appendChild(t[l]);
        if (s && o.childNodes.length) {
          var u = document.createElement("div");
          u.innerHTML = s, o.appendChild(u);
        }
      }
    }, i.prototype.setEnterable = function(t) {
      this._enterable = t;
    }, i.prototype.getSize = function() {
      var t = this.el;
      return t ? [
        t.offsetWidth,
        t.offsetHeight
      ] : [
        0,
        0
      ];
    }, i.prototype.moveTo = function(t, e) {
      if (this.el) {
        var n = this._styleCoord;
        if (Pi(n, this._zr, this._container, t, e), n[0] != null && n[1] != null) {
          var r = this.el.style, a = ki(n[0], n[1]);
          y(a, function(o) {
            r[o[0]] = o[1];
          });
        }
      }
    }, i.prototype._moveIfResized = function() {
      var t = this._styleCoord[2], e = this._styleCoord[3];
      this.moveTo(t * this._zr.getWidth(), e * this._zr.getHeight());
    }, i.prototype.hide = function() {
      var t = this, e = this.el.style;
      e.visibility = "hidden", e.opacity = "0", B.transform3dSupported && (e.willChange = ""), this._show = false, this._longHideTimeout = setTimeout(function() {
        return t._longHide = true;
      }, 500);
    }, i.prototype.hideLater = function(t) {
      this._show && !(this._inContent && this._enterable) && !this._alwaysShowContent && (t ? (this._hideDelay = t, this._show = false, this._hideTimeout = setTimeout(Z(this.hide, this), t)) : this.hide());
    }, i.prototype.isShow = function() {
      return this._show;
    }, i.prototype.dispose = function() {
      clearTimeout(this._hideTimeout), clearTimeout(this._longHideTimeout);
      var t = this.el.parentNode;
      t && t.removeChild(this.el), this.el = this._container = null;
    }, i;
  })(), As = (function() {
    function i(t) {
      this._show = false, this._styleCoord = [
        0,
        0,
        0,
        0
      ], this._alwaysShowContent = false, this._enterable = true, this._zr = t.getZr(), Oi(this._styleCoord, this._zr, t.getWidth() / 2, t.getHeight() / 2);
    }
    return i.prototype.update = function(t) {
      var e = t.get("alwaysShowContent");
      e && this._moveIfResized(), this._alwaysShowContent = e;
    }, i.prototype.show = function() {
      this._hideTimeout && clearTimeout(this._hideTimeout), this.el.show(), this._show = true;
    }, i.prototype.setContent = function(t, e, n, r, a) {
      var o = this;
      et(t) && kn(""), this.el && this._zr.remove(this.el);
      var s = n.getModel("textStyle");
      this.el = new it({
        style: {
          rich: e.richTextStyles,
          text: t,
          lineHeight: 22,
          borderWidth: 1,
          borderColor: r,
          textShadowColor: s.get("textShadowColor"),
          fill: n.get([
            "textStyle",
            "color"
          ]),
          padding: Ui(n, "richText"),
          verticalAlign: "top",
          align: "left"
        },
        z: n.get("z")
      }), y([
        "backgroundColor",
        "borderRadius",
        "shadowColor",
        "shadowBlur",
        "shadowOffsetX",
        "shadowOffsetY"
      ], function(u) {
        o.el.style[u] = n.get(u);
      }), y([
        "textShadowBlur",
        "textShadowOffsetX",
        "textShadowOffsetY"
      ], function(u) {
        o.el.style[u] = s.get(u) || 0;
      }), this._zr.add(this.el);
      var l = this;
      this.el.on("mouseover", function() {
        l._enterable && (clearTimeout(l._hideTimeout), l._show = true), l._inContent = true;
      }), this.el.on("mouseout", function() {
        l._enterable && l._show && l.hideLater(l._hideDelay), l._inContent = false;
      });
    }, i.prototype.setEnterable = function(t) {
      this._enterable = t;
    }, i.prototype.getSize = function() {
      var t = this.el, e = this.el.getBoundingRect(), n = Ri(t.style);
      return [
        e.width + n.left + n.right,
        e.height + n.top + n.bottom
      ];
    }, i.prototype.moveTo = function(t, e) {
      var n = this.el;
      if (n) {
        var r = this._styleCoord;
        Oi(r, this._zr, t, e), t = r[0], e = r[1];
        var a = n.style, o = q(a.borderWidth || 0), s = Ri(a);
        n.x = t + o + s.left, n.y = e + o + s.top, n.markRedraw();
      }
    }, i.prototype._moveIfResized = function() {
      var t = this._styleCoord[2], e = this._styleCoord[3];
      this.moveTo(t * this._zr.getWidth(), e * this._zr.getHeight());
    }, i.prototype.hide = function() {
      this.el && this.el.hide(), this._show = false;
    }, i.prototype.hideLater = function(t) {
      this._show && !(this._inContent && this._enterable) && !this._alwaysShowContent && (t ? (this._hideDelay = t, this._show = false, this._hideTimeout = setTimeout(Z(this.hide, this), t)) : this.hide());
    }, i.prototype.isShow = function() {
      return this._show;
    }, i.prototype.dispose = function() {
      this._zr.remove(this.el);
    }, i;
  })();
  function q(i) {
    return Math.max(0, i);
  }
  function Ri(i) {
    var t = q(i.shadowBlur || 0), e = q(i.shadowOffsetX || 0), n = q(i.shadowOffsetY || 0);
    return {
      left: q(t - e),
      right: q(t + e),
      top: q(t - n),
      bottom: q(t + n)
    };
  }
  function Oi(i, t, e, n) {
    i[0] = e, i[1] = n, i[2] = i[0] / t.getWidth(), i[3] = i[1] / t.getHeight();
  }
  var Ss = new lt({
    shape: {
      x: -1,
      y: -1,
      width: 2,
      height: 2
    }
  }), Cs = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.prototype.init = function(e, n) {
      if (!(B.node || !n.getDom())) {
        var r = e.getComponent("tooltip"), a = this._renderMode = Pn(r.get("renderMode"));
        this._tooltipContent = a === "richText" ? new As(n) : new Ts(n, {
          appendTo: r.get("appendToBody", true) ? "body" : r.get("appendTo", true)
        });
      }
    }, t.prototype.render = function(e, n, r) {
      if (!(B.node || !r.getDom())) {
        this.group.removeAll(), this._tooltipModel = e, this._ecModel = n, this._api = r;
        var a = this._tooltipContent;
        a.update(e), a.setEnterable(e.get("enterable")), this._initGlobalListener(), this._keepShow(), this._renderMode !== "richText" && e.get("transitionDuration") ? Gi(this, "_updatePosition", 50, "fixRate") : re(this, "_updatePosition");
      }
    }, t.prototype._initGlobalListener = function() {
      var e = this._tooltipModel, n = e.get("triggerOn");
      mr("itemTooltip", this._api, Z(function(r, a, o) {
        n !== "none" && (n.indexOf(r) >= 0 ? this._tryShow(a, o) : r === "leave" && this._hide(o));
      }, this));
    }, t.prototype._keepShow = function() {
      var e = this._tooltipModel, n = this._ecModel, r = this._api, a = e.get("triggerOn");
      if (this._lastX != null && this._lastY != null && a !== "none" && a !== "click") {
        var o = this;
        clearTimeout(this._refreshUpdateTimeout), this._refreshUpdateTimeout = setTimeout(function() {
          !r.isDisposed() && o.manuallyShowTip(e, n, r, {
            x: o._lastX,
            y: o._lastY,
            dataByCoordSys: o._lastDataByCoordSys
          });
        });
      }
    }, t.prototype.manuallyShowTip = function(e, n, r, a) {
      if (!(a.from === this.uid || B.node || !r.getDom())) {
        var o = Ei(a, r);
        this._ticket = "";
        var s = a.dataByCoordSys, l = Is(a, n, r);
        if (l) {
          var u = l.el.getBoundingRect().clone();
          u.applyTransform(l.el.transform), this._tryShow({
            offsetX: u.x + u.width / 2,
            offsetY: u.y + u.height / 2,
            target: l.el,
            position: a.position,
            positionDefault: "bottom"
          }, o);
        } else if (a.tooltip && a.x != null && a.y != null) {
          var h = Ss;
          h.x = a.x, h.y = a.y, h.update(), Y(h).tooltipConfig = {
            name: null,
            option: a.tooltip
          }, this._tryShow({
            offsetX: a.x,
            offsetY: a.y,
            target: h
          }, o);
        } else if (s) this._tryShow({
          offsetX: a.x,
          offsetY: a.y,
          position: a.position,
          dataByCoordSys: s,
          tooltipOption: a.tooltipOption
        }, o);
        else if (a.seriesIndex != null) {
          if (this._manuallyAxisShowTip(e, n, r, a)) return;
          var c = xr(a, n), d = c.point[0], p = c.point[1];
          d != null && p != null && this._tryShow({
            offsetX: d,
            offsetY: p,
            target: c.el,
            position: a.position,
            positionDefault: "bottom"
          }, o);
        } else a.x != null && a.y != null && (r.dispatchAction({
          type: "updateAxisPointer",
          x: a.x,
          y: a.y
        }), this._tryShow({
          offsetX: a.x,
          offsetY: a.y,
          position: a.position,
          target: r.getZr().findHover(a.x, a.y).target
        }, o));
      }
    }, t.prototype.manuallyHideTip = function(e, n, r, a) {
      var o = this._tooltipContent;
      this._tooltipModel && o.hideLater(this._tooltipModel.get("hideDelay")), this._lastX = this._lastY = this._lastDataByCoordSys = null, a.from !== this.uid && this._hide(Ei(a, r));
    }, t.prototype._manuallyAxisShowTip = function(e, n, r, a) {
      var o = a.seriesIndex, s = a.dataIndex, l = n.getComponent("axisPointer").coordSysAxesInfo;
      if (!(o == null || s == null || l == null)) {
        var u = n.getSeriesByIndex(o);
        if (u) {
          var h = u.getData(), c = St([
            h.getItemModel(s),
            u,
            (u.coordinateSystem || {}).model
          ], this._tooltipModel);
          if (c.get("trigger") === "axis") return r.dispatchAction({
            type: "updateAxisPointer",
            seriesIndex: o,
            dataIndex: s,
            position: a.position
          }), true;
        }
      }
    }, t.prototype._tryShow = function(e, n) {
      var r = e.target, a = this._tooltipModel;
      if (a) {
        this._lastX = e.offsetX, this._lastY = e.offsetY;
        var o = e.dataByCoordSys;
        if (o && o.length) this._showAxisTooltip(o, e);
        else if (r) {
          var s = Y(r);
          if (s.ssrType === "legend") return;
          this._lastDataByCoordSys = null;
          var l, u;
          Rn(r, function(h) {
            if (Y(h).dataIndex != null) return l = h, true;
            if (Y(h).tooltipConfig != null) return u = h, true;
          }, true), l ? this._showSeriesItemTooltip(e, l, n) : u ? this._showComponentItemTooltip(e, u, n) : this._hide(n);
        } else this._lastDataByCoordSys = null, this._hide(n);
      }
    }, t.prototype._showOrMove = function(e, n) {
      var r = e.get("showDelay");
      n = Z(n, this), clearTimeout(this._showTimout), r > 0 ? this._showTimout = setTimeout(n, r) : n();
    }, t.prototype._showAxisTooltip = function(e, n) {
      var r = this._ecModel, a = this._tooltipModel, o = [
        n.offsetX,
        n.offsetY
      ], s = St([
        n.tooltipOption
      ], a), l = this._renderMode, u = [], h = He("section", {
        blocks: [],
        noHeader: true
      }), c = [], d = new Ft();
      y(e, function(_) {
        y(_.dataByAxis, function(x) {
          var b = r.getComponent(x.axisDim + "Axis", x.axisIndex), w = x.value;
          if (!(!b || w == null)) {
            var T = vr(w, b.axis, r, x.seriesDataIndices, x.valueLabelOpt), A = He("section", {
              header: T,
              noHeader: !On(T),
              sortBlocks: true,
              blocks: []
            });
            h.blocks.push(A), y(x.seriesDataIndices, function(S) {
              var L = r.getSeriesByIndex(S.seriesIndex), D = S.dataIndexInside, I = L.getDataParams(D);
              if (!(I.dataIndex < 0)) {
                I.axisDim = x.axisDim, I.axisIndex = x.axisIndex, I.axisType = x.axisType, I.axisId = x.axisId, I.axisValue = Fi(b.axis, {
                  value: w
                }), I.axisValueLabel = T, I.marker = d.makeTooltipMarker("item", zt(I.color), l);
                var X = je(L.formatTooltip(D, true, null)), K = X.frag;
                if (K) {
                  var R = St([
                    L
                  ], a).get("valueFormatter");
                  A.blocks.push(R ? xt({
                    valueFormatter: R
                  }, K) : K);
                }
                X.text && c.push(X.text), u.push(I);
              }
            });
          }
        });
      }), h.blocks.reverse(), c.reverse();
      var p = n.position, f = s.get("order"), v = Ve(h, d, l, f, r.get("useUTC"), s.get("textStyle"));
      v && c.unshift(v);
      var g = l === "richText" ? `

` : "<br/>", m = c.join(g);
      this._showOrMove(s, function() {
        this._updateContentNotChangedOnAxis(e, u) ? this._updatePosition(s, p, o[0], o[1], this._tooltipContent, u) : this._showTooltipContent(s, m, u, Math.random() + "", o[0], o[1], p, null, d);
      });
    }, t.prototype._showSeriesItemTooltip = function(e, n, r) {
      var a = this._ecModel, o = Y(n), s = o.seriesIndex, l = a.getSeriesByIndex(s), u = o.dataModel || l, h = o.dataIndex, c = o.dataType, d = u.getData(c), p = this._renderMode, f = e.positionDefault, v = St([
        d.getItemModel(h),
        u,
        l && (l.coordinateSystem || {}).model
      ], this._tooltipModel, f ? {
        position: f
      } : null), g = v.get("trigger");
      if (!(g != null && g !== "item")) {
        var m = u.getDataParams(h, c), _ = new Ft();
        m.marker = _.makeTooltipMarker("item", zt(m.color), p);
        var x = je(u.formatTooltip(h, false, c)), b = v.get("order"), w = v.get("valueFormatter"), T = x.frag, A = T ? Ve(w ? xt({
          valueFormatter: w
        }, T) : T, _, p, b, a.get("useUTC"), v.get("textStyle")) : x.text, S = "item_" + u.name + "_" + h;
        this._showOrMove(v, function() {
          this._showTooltipContent(v, A, m, S, e.offsetX, e.offsetY, e.position, e.target, _);
        }), r({
          type: "showTip",
          dataIndexInside: h,
          dataIndex: d.getRawIndex(h),
          seriesIndex: s,
          from: this.uid
        });
      }
    }, t.prototype._showComponentItemTooltip = function(e, n, r) {
      var a = this._renderMode === "html", o = Y(n), s = o.tooltipConfig, l = s.option || {}, u = l.encodeHTMLContent;
      if (z(l)) {
        var h = l;
        l = {
          content: h,
          formatter: h
        }, u = true;
      }
      u && a && l.content && (l = N(l), l.content = En(l.content));
      var c = [
        l
      ], d = this._ecModel.getComponent(o.componentMainType, o.componentIndex);
      d && c.push(d), c.push({
        formatter: l.content
      });
      var p = e.positionDefault, f = St(c, this._tooltipModel, p ? {
        position: p
      } : null), v = f.get("content"), g = Math.random() + "", m = new Ft();
      this._showOrMove(f, function() {
        var _ = N(f.get("formatterParams") || {});
        this._showTooltipContent(f, v, _, g, e.offsetX, e.offsetY, e.position, n, m);
      }), r({
        type: "showTip",
        from: this.uid
      });
    }, t.prototype._showTooltipContent = function(e, n, r, a, o, s, l, u, h) {
      if (this._ticket = "", !(!e.get("showContent") || !e.get("show"))) {
        var c = this._tooltipContent;
        c.setEnterable(e.get("enterable"));
        var d = e.get("formatter");
        l = l || e.get("position");
        var p = n, f = this._getNearestPoint([
          o,
          s
        ], r, e.get("trigger"), e.get("borderColor")), v = f.color;
        if (d) if (z(d)) {
          var g = e.ecModel.get("useUTC"), m = j(r) ? r[0] : r, _ = m && m.axisType && m.axisType.indexOf("time") >= 0;
          p = d, _ && (p = Bn(m.axisValue, p, g)), p = zn(p, r, true);
        } else if (rt(d)) {
          var x = Z(function(b, w) {
            b === this._ticket && (c.setContent(w, h, e, v, l), this._updatePosition(e, l, o, s, c, r, u));
          }, this);
          this._ticket = a, p = d(r, a, x);
        } else p = d;
        c.setContent(p, h, e, v, l), c.show(e, v), this._updatePosition(e, l, o, s, c, r, u);
      }
    }, t.prototype._getNearestPoint = function(e, n, r, a) {
      if (r === "axis" || j(n)) return {
        color: a || (this._renderMode === "html" ? "#fff" : "none")
      };
      if (!j(n)) return {
        color: a || n.color || n.borderColor
      };
    }, t.prototype._updatePosition = function(e, n, r, a, o, s, l) {
      var u = this._api.getWidth(), h = this._api.getHeight();
      n = n || e.get("position");
      var c = o.getSize(), d = e.get("align"), p = e.get("verticalAlign"), f = l && l.getBoundingRect().clone();
      if (l && f.applyTransform(l.transform), rt(n) && (n = n([
        r,
        a
      ], s, o.el, f, {
        viewSize: [
          u,
          h
        ],
        contentSize: c.slice()
      })), j(n)) r = We(n[0], u), a = We(n[1], h);
      else if (et(n)) {
        var v = n;
        v.width = c[0], v.height = c[1];
        var g = jt(v, {
          width: u,
          height: h
        });
        r = g.x, a = g.y, d = null, p = null;
      } else if (z(n) && l) {
        var m = Ds(n, f, c, e.get("borderWidth"));
        r = m[0], a = m[1];
      } else {
        var m = Ms(r, a, o, u, h, d ? null : 20, p ? null : 20);
        r = m[0], a = m[1];
      }
      if (d && (r -= Bi(d) ? c[0] / 2 : d === "right" ? c[0] : 0), p && (a -= Bi(p) ? c[1] / 2 : p === "bottom" ? c[1] : 0), Sr(e)) {
        var m = Ls(r, a, o, u, h);
        r = m[0], a = m[1];
      }
      o.moveTo(r, a);
    }, t.prototype._updateContentNotChangedOnAxis = function(e, n) {
      var r = this._lastDataByCoordSys, a = this._cbParamsList, o = !!r && r.length === e.length;
      return o && y(r, function(s, l) {
        var u = s.dataByAxis || [], h = e[l] || {}, c = h.dataByAxis || [];
        o = o && u.length === c.length, o && y(u, function(d, p) {
          var f = c[p] || {}, v = d.seriesDataIndices || [], g = f.seriesDataIndices || [];
          o = o && d.value === f.value && d.axisType === f.axisType && d.axisId === f.axisId && v.length === g.length, o && y(v, function(m, _) {
            var x = g[_];
            o = o && m.seriesIndex === x.seriesIndex && m.dataIndex === x.dataIndex;
          }), a && y(d.seriesDataIndices, function(m) {
            var _ = m.seriesIndex, x = n[_], b = a[_];
            x && b && b.data !== x.data && (o = false);
          });
        });
      }), this._lastDataByCoordSys = e, this._cbParamsList = n, !!o;
    }, t.prototype._hide = function(e) {
      this._lastDataByCoordSys = null, e({
        type: "hideTip",
        from: this.uid
      });
    }, t.prototype.dispose = function(e, n) {
      B.node || !n.getDom() || (re(this, "_updatePosition"), this._tooltipContent.dispose(), ve("itemTooltip", n));
    }, t.type = "tooltip", t;
  })(ft);
  function St(i, t, e) {
    var n = t.ecModel, r;
    e ? (r = new ot(e, n, n), r = new ot(t.option, r, n)) : r = t;
    for (var a = i.length - 1; a >= 0; a--) {
      var o = i[a];
      o && (o instanceof ot && (o = o.get("tooltip", true)), z(o) && (o = {
        formatter: o
      }), o && (r = new ot(o, r, n)));
    }
    return r;
  }
  function Ei(i, t) {
    return i.dispatchAction || Z(t.dispatchAction, t);
  }
  function Ms(i, t, e, n, r, a, o) {
    var s = e.getSize(), l = s[0], u = s[1];
    return a != null && (i + l + a + 2 > n ? i -= l + a : i += a), o != null && (t + u + o > r ? t -= u + o : t += o), [
      i,
      t
    ];
  }
  function Ls(i, t, e, n, r) {
    var a = e.getSize(), o = a[0], s = a[1];
    return i = Math.min(i + o, n) - o, t = Math.min(t + s, r) - s, i = Math.max(i, 0), t = Math.max(t, 0), [
      i,
      t
    ];
  }
  function Ds(i, t, e, n) {
    var r = e[0], a = e[1], o = Math.ceil(Math.SQRT2 * n) + 8, s = 0, l = 0, u = t.width, h = t.height;
    switch (i) {
      case "inside":
        s = t.x + u / 2 - r / 2, l = t.y + h / 2 - a / 2;
        break;
      case "top":
        s = t.x + u / 2 - r / 2, l = t.y - a - o;
        break;
      case "bottom":
        s = t.x + u / 2 - r / 2, l = t.y + h + o;
        break;
      case "left":
        s = t.x - r - o, l = t.y + h / 2 - a / 2;
        break;
      case "right":
        s = t.x + u + o, l = t.y + h / 2 - a / 2;
    }
    return [
      s,
      l
    ];
  }
  function Bi(i) {
    return i === "center" || i === "middle";
  }
  function Is(i, t, e) {
    var n = Hn(i).queryOptionMap, r = n.keys()[0];
    if (!(!r || r === "series")) {
      var a = jn(t, r, n.get(r), {
        useDefault: false,
        enableAll: false,
        enableNone: false
      }), o = a.models[0];
      if (o) {
        var s = e.getViewOfComponentModel(o), l;
        if (s.group.traverse(function(u) {
          var h = Y(u).tooltipConfig;
          if (h && h.name === i.name) return l = u, true;
        }), l) return {
          componentMainType: r,
          componentIndex: o.componentIndex,
          el: l
        };
      }
    }
  }
  ks = function(i) {
    Lt(yr), i.registerComponentModel(ds), i.registerComponentView(Cs), i.registerAction({
      type: "showTip",
      event: "showTip",
      update: "tooltip:manuallyShowTip"
    }, ie), i.registerAction({
      type: "hideTip",
      event: "hideTip",
      update: "tooltip:manuallyHideTip"
    }, ie);
  };
  var Ps = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e.layoutMode = {
        type: "box",
        ignoreSize: true
      }, e;
    }
    return t.type = "title", t.defaultOption = {
      z: 6,
      show: true,
      text: "",
      target: "blank",
      subtext: "",
      subtarget: "blank",
      left: 0,
      top: 0,
      backgroundColor: "rgba(0,0,0,0)",
      borderColor: "#ccc",
      borderWidth: 0,
      padding: 5,
      itemGap: 10,
      textStyle: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#464646"
      },
      subtextStyle: {
        fontSize: 12,
        color: "#6E7079"
      }
    }, t;
  })(ct), Rs = (function(i) {
    C(t, i);
    function t() {
      var e = i !== null && i.apply(this, arguments) || this;
      return e.type = t.type, e;
    }
    return t.prototype.render = function(e, n, r) {
      if (this.group.removeAll(), !!e.get("show")) {
        var a = this.group, o = e.getModel("textStyle"), s = e.getModel("subtextStyle"), l = e.get("textAlign"), u = vt(e.get("textBaseline"), e.get("textVerticalAlign")), h = new it({
          style: Mt(o, {
            text: e.get("text"),
            fill: o.getTextColor()
          }, {
            disableBox: true
          }),
          z2: 10
        }), c = h.getBoundingRect(), d = e.get("subtext"), p = new it({
          style: Mt(s, {
            text: d,
            fill: s.getTextColor(),
            y: c.height + e.get("itemGap"),
            verticalAlign: "top"
          }, {
            disableBox: true
          }),
          z2: 10
        }), f = e.get("link"), v = e.get("sublink"), g = e.get("triggerEvent", true);
        h.silent = !f && !g, p.silent = !v && !g, f && h.on("click", function() {
          Ne(f, "_" + e.get("target"));
        }), v && p.on("click", function() {
          Ne(v, "_" + e.get("subtarget"));
        }), Y(h).eventData = Y(p).eventData = g ? {
          componentType: "title",
          componentIndex: e.componentIndex
        } : null, a.add(h), d && a.add(p);
        var m = a.getBoundingRect(), _ = e.getBoxLayoutParams();
        _.width = m.width, _.height = m.height;
        var x = jt(_, {
          width: r.getWidth(),
          height: r.getHeight()
        }, e.get("padding"));
        l || (l = e.get("left") || e.get("right"), l === "middle" && (l = "center"), l === "right" ? x.x += x.width : l === "center" && (x.x += x.width / 2)), u || (u = e.get("top") || e.get("bottom"), u === "center" && (u = "middle"), u === "bottom" ? x.y += x.height : u === "middle" && (x.y += x.height / 2), u = u || "top"), a.x = x.x, a.y = x.y, a.markRedraw();
        var b = {
          align: l,
          verticalAlign: u
        };
        h.setStyle(b), p.setStyle(b), m = a.getBoundingRect();
        var w = x.margin, T = e.getItemStyle([
          "color",
          "opacity"
        ]);
        T.fill = e.get("backgroundColor");
        var A = new lt({
          shape: {
            x: m.x - w[3],
            y: m.y - w[0],
            width: m.width + w[1] + w[3],
            height: m.height + w[0] + w[2],
            r: e.get("borderRadius")
          },
          style: T,
          subPixelOptimize: true,
          silent: true
        });
        a.add(A);
      }
    }, t.type = "title", t;
  })(ft);
  Os = function(i) {
    i.registerComponentModel(Ps), i.registerComponentView(Rs);
  };
  Lt([
    Nn,
    fs,
    Os,
    ks,
    _o,
    Yn,
    Gn
  ]);
  function Es(i) {
    return M.jsx("svg", {
      viewBox: "0 0 512 512",
      width: i.width || 20,
      height: i.height || i.width || 20,
      xmlns: "http://www.w3.org/2000/svg",
      style: i.style,
      children: M.jsx("path", {
        fill: "currentColor",
        d: "M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z"
      })
    });
  }
  const zi = {
    chartWithToolbar: (i) => {
      var _a2;
      return {
        height: `calc(100% - ${parseFloat(((_a2 = i == null ? void 0 : i.mixins) == null ? void 0 : _a2.toolbar.minHeight) || "48") + 8}px)`
      };
    },
    chartWithoutToolbar: {
      height: "100%"
    }
  }, E = 80, nt = 25;
  class Bs extends Dr {
    readTimeout = null;
    timeTimer = null;
    start;
    end;
    echartsReact = null;
    rangeRef = Pe();
    maxYLenTimeout = null;
    maxYLenTimeout2 = null;
    timerResize = null;
    mouseDown = false;
    chart = {};
    divRef = Pe();
    unit;
    unit2;
    minY;
    maxY;
    minX;
    maxX;
    chartValues = null;
    constructor(t) {
      var _a2, _b, _c, _d;
      if (super(t), this.props.from) this.start = this.props.from;
      else {
        const a = /* @__PURE__ */ new Date();
        a.setHours(a.getHours() - 168), this.start = a.getTime();
      }
      this.props.end ? this.end = this.props.end : this.end = Date.now();
      let e = window.localStorage.getItem("App.relativeRange") || "30";
      const n = parseInt(window.localStorage.getItem("App.absoluteStart"), 10) || 0, r = parseInt(window.localStorage.getItem("App.absoluteEnd"), 10) || 0;
      (!n || !r) && (!e || e === "absolute") && (e = "30"), r && n && (e = "absolute"), this.state = {
        chartHeight: 300,
        chartWidth: 500,
        relativeRange: e,
        splitLine: window.localStorage.getItem("App.splitLine") === "true",
        max: r,
        maxYLen: 0,
        maxYLen2: 0
      }, this.unit = this.props.unit ? ` ${this.props.unit}` : ((_b = (_a2 = this.props.obj) == null ? void 0 : _a2.common) == null ? void 0 : _b.unit) ? ` ${this.props.obj.common.unit}` : "", this.unit2 = this.props.unit2 ? ` ${this.props.unit2}` : ((_d = (_c = this.props.obj2) == null ? void 0 : _c.common) == null ? void 0 : _d.unit) ? ` ${this.props.obj2.common.unit}` : "";
    }
    componentDidMount() {
      var _a2;
      const t = [];
      this.props.obj._id && this.props.obj._id !== "nothing_selected" && t.push(this.props.obj._id), ((_a2 = this.props.obj2) == null ? void 0 : _a2._id) && this.props.obj2._id !== "nothing_selected" && t.push(this.props.obj2._id), t.length && this.props.socket.subscribeState(t, this.onChange), window.addEventListener("resize", this.onResize), this.setRelativeInterval(this.state.relativeRange, true, () => this.forceUpdate());
    }
    componentWillUnmount() {
      var _a2;
      this.readTimeout && (clearTimeout(this.readTimeout), this.readTimeout = null), this.timeTimer && clearTimeout(this.timeTimer), this.timeTimer = null, this.maxYLenTimeout && clearTimeout(this.maxYLenTimeout), this.maxYLenTimeout = null, this.maxYLenTimeout2 && clearTimeout(this.maxYLenTimeout2), this.maxYLenTimeout2 = null;
      const t = [];
      this.props.obj._id && this.props.obj._id !== "nothing_selected" && t.push(this.props.obj._id), ((_a2 = this.props.obj2) == null ? void 0 : _a2._id) && this.props.obj2._id !== "nothing_selected" && t.push(this.props.obj2._id), t.length && this.props.socket.unsubscribeState(t, this.onChange), window.removeEventListener("resize", this.onResize);
    }
    onResize = () => {
      this.timerResize && clearTimeout(this.timerResize), this.timerResize = setTimeout(() => {
        this.timerResize = null, this.componentDidUpdate();
      });
    };
    onChange = (t, e) => {
      var _a2, _b, _c;
      (t === this.props.obj._id || t === ((_a2 = this.props.obj2) == null ? void 0 : _a2._id)) && e && (!this.state.max || e.ts - this.state.max < 12e4) && ((_c = (_b = this.chartValues) == null ? void 0 : _b[t]) == null ? void 0 : _c.push({
        val: e.val,
        ts: e.ts
      }), e.ts >= this.chart.min && e.ts <= this.chart.max + 3e5 && this.updateChart());
    };
    async readHistory(t, e, n) {
      var _a2;
      const r = {
        instance: n === ((_a2 = this.props.obj2) == null ? void 0 : _a2._id) ? this.props.historyInstance2 : this.props.historyInstance,
        start: t,
        end: e,
        from: false,
        ack: false,
        q: false,
        addId: false,
        aggregate: "none",
        returnNewestEntries: true
      };
      !n && e - t > 6e4 * 30 && !(this.props.obj.common.type === "boolean" || this.props.obj.common.type === "number" && this.props.obj.common.states) && (r.aggregate = "minmax");
      const a = await this.props.socket.getHistory(n, r), o = [];
      let s = null, l = null;
      for (let u = 0; u < a.length; u++) !o.length || o[o.length - 1].ts < a[u].ts ? o.push(a[u]) : o[o.length - 1].ts === a[u].ts && o[o.length - 1].val !== a[u].ts && console.error("Strange data!"), (s === null || a[u].val < s) && (s = a[u].val), (l === null || a[u].val > l) && (l = a[u].val);
      return o.sort((u, h) => u.ts > h.ts ? 1 : u.ts < h.ts ? -1 : 0), n || (n = this.props.obj._id), this.chartValues || (this.chartValues = {}), this.minY || (this.minY = {}), this.maxY || (this.maxY = {}), this.minX || (this.minX = {}), this.maxX || (this.maxX = {}), this.chartValues[n] = o, this.minY[n] = s, this.maxY[n] = l, this.minX[n] = s, this.maxX[n] = l, this.minY[n] < 10 ? this.minY[n] = Math.round(this.minY[n] * 10) / 10 : this.minY[n] = Math.ceil(this.minY[n]), this.maxY[n] < 10 ? this.maxY[n] = Math.round(this.maxY[n] * 10) / 10 : this.maxY[n] = Math.ceil(this.maxY[n]), o;
    }
    convertData(t, e) {
      t || (t = this.chartValues[e]);
      const n = [];
      if (!(t == null ? void 0 : t.length)) return n;
      for (let r = 0; r < t.length; r++) {
        const a = {
          value: [
            t[r].ts,
            t[r].val
          ]
        };
        t[r].i && (a.exact = false), n.push(a);
      }
      return e === this.props.obj._id && !this.chart.min && (this.chart.min = t[0].ts, this.chart.max = t[t.length - 1].ts), n;
    }
    static getColor(t, e) {
      let n, r, a;
      if (t.startsWith("#")) n = parseInt(t.substring(1, 3), 16), r = parseInt(t.substring(3, 5), 16), a = parseInt(t.substring(5, 7), 16);
      else if (t.startsWith("rgb(")) {
        const o = t.replace("rgb(", "").replace(")", "").split(",");
        n = parseInt(o[0], 10), r = parseInt(o[1], 10), a = parseInt(o[2], 10);
      } else if (t.startsWith("rgba(")) {
        const o = t.replace("rgba(", "").replace(")", "").split(",");
        n = parseInt(o[0], 10), r = parseInt(o[1], 10), a = parseInt(o[2], 10);
      }
      return `rgba(${n},${r},${a},${e})`;
    }
    getOption() {
      var _a2, _b, _c, _d, _e2, _f, _g, _h, _i2, _j, _k, _l;
      let t;
      if (this.minY[this.props.obj._id] !== null && this.minY[this.props.obj._id] !== void 0 && (t = (this.minY[this.props.obj._id].toString() + this.unit).length * 9 + 12), this.maxY[this.props.obj._id] !== null && this.maxY[this.props.obj._id] !== void 0) {
        const s = (this.maxY[this.props.obj._id].toString() + this.unit).length * 9 + 12;
        s > t && (t = s);
      }
      if (this.state.maxYLen) {
        const s = this.state.maxYLen * 9 + 12;
        s > t && (t = s);
      }
      let e;
      if (this.props.obj2) {
        if (this.minY[this.props.obj2._id] !== null && this.minY[this.props.obj2._id] !== void 0 && (e = (this.minY[this.props.obj2._id].toString() + this.unit2).length * 9 + 12), this.maxY[this.props.obj2._id] !== null && this.maxY[this.props.obj2._id] !== void 0) {
          const s = (this.maxY[this.props.obj2._id].toString() + this.unit2).length * 9 + 12;
          s > e && (e = s);
        }
        if (this.state.maxYLen2) {
          const s = this.state.maxYLen2 * 9 + 12;
          s > e && (e = s);
        }
      }
      const n = {
        xAxisIndex: 0,
        type: "line",
        step: this.props.objLineType === "step" ? "start" : void 0,
        showSymbol: false,
        hoverAnimation: true,
        animation: false,
        data: this.convertData(null, this.props.obj._id),
        areaStyle: {
          color: this.props.objBackgroundColor || "rgba(243,177,31,0.14)"
        },
        lineStyle: {
          color: this.props.objColor || "#f5ba4d"
        }
      }, r = [
        {
          type: "value",
          boundaryGap: [
            0,
            "100%"
          ],
          splitLine: {
            show: this.props.noToolbar || !!this.state.splitLine
          },
          splitNumber: Math.round(this.state.chartHeight / 50),
          name: this.props.title || void 0,
          nameTextStyle: {
            align: "left"
          },
          axisLabel: {
            formatter: (s) => {
              let l;
              return s = Math.round(s * 10) / 10, this.props.isFloatComma ? l = s.toString().replace(",", ".") + this.unit : l = s + this.unit, this.state.maxYLen < l.length && (this.maxYLenTimeout && clearTimeout(this.maxYLenTimeout), this.maxYLenTimeout = setTimeout((u) => this.setState({
                maxYLen: u
              }), 200, l.length)), l;
            },
            showMaxLabel: true,
            showMinLabel: true
          },
          axisTick: {
            alignWithLabel: true
          }
        }
      ];
      let a;
      if (this.props.obj2 && (a = {
        xAxisIndex: 0,
        type: "line",
        yAxisIndex: 1,
        step: this.props.obj2LineType === "step" || !this.props.obj2LineType ? "start" : void 0,
        showSymbol: false,
        hoverAnimation: true,
        animation: false,
        data: this.convertData(null, this.props.obj2._id),
        areaStyle: {
          color: this.props.obj2BackgroundColor || "rgba(141,243,31,0.14)"
        },
        lineStyle: {
          color: this.props.obj2Color || "#21b400"
        }
      }, r.push({
        type: "value",
        alignTicks: true,
        boundaryGap: [
          0,
          "100%"
        ],
        name: this.props.title2 || void 0,
        nameTextStyle: {
          align: "right"
        },
        splitLine: {
          show: this.props.noToolbar || !!this.state.splitLine
        },
        splitNumber: Math.round(this.state.chartHeight / 50),
        axisLabel: {
          formatter: (s) => {
            let l;
            return s = Math.round(s * 10) / 10, this.props.isFloatComma ? l = s.toString().replace(",", ".") + this.unit2 : l = s + this.unit2, this.state.maxYLen2 < l.length && (this.maxYLenTimeout2 && clearTimeout(this.maxYLenTimeout2), this.maxYLenTimeout2 = setTimeout((u) => this.setState({
              maxYLen2: u
            }), 200, l.length)), l;
          },
          showMaxLabel: true,
          showMinLabel: true
        },
        axisTick: {
          alignWithLabel: true
        }
      })), ((_b = (_a2 = this.props.obj) == null ? void 0 : _a2.common) == null ? void 0 : _b.type) === "boolean") n.step = "end", r[0].axisLabel.showMaxLabel = false, r[0].axisLabel.formatter = (s) => s === 1 ? "TRUE" : "FALSE", r[0].max = 1.5, r[0].interval = 1, t = 50;
      else if (((_d = (_c = this.props.obj) == null ? void 0 : _c.common) == null ? void 0 : _d.type) === "number" && this.props.obj.common.states) {
        n.step = "end", r[0].axisLabel.showMaxLabel = false, r[0].axisLabel.formatter = (u) => this.props.obj.common.states[u] !== void 0 ? this.props.obj.common.states[u] : u;
        const s = Object.keys(this.props.obj.common.states);
        s.sort(), r[0].max = parseFloat(s[s.length - 1]) + 0.5, r[0].interval = 1;
        let l = "";
        for (let u = 0; u < s.length; u++) typeof this.props.obj.common.states[s[u]] == "string" && this.props.obj.common.states[s[u]].length > l.length && (l = this.props.obj.common.states[s[u]]);
        t = (l.length * 9 || 50) + 12;
      } else ((_f = (_e2 = this.props.obj) == null ? void 0 : _e2.common) == null ? void 0 : _f.type) === "number" && (this.props.obj.common.min !== void 0 && this.props.obj.common.max !== void 0 ? (r[0].max = this.props.obj.common.max, r[0].min = this.props.obj.common.min) : this.props.obj.common.unit === "%" && (r[0].max = 100, r[0].min = 0));
      if (((_h = (_g = this.props.obj2) == null ? void 0 : _g.common) == null ? void 0 : _h.type) === "boolean") n.step = "end", r[1].axisLabel.showMaxLabel = false, r[1].axisLabel.formatter = (s) => s === 1 ? "TRUE" : "FALSE", r[1].max = 1.5, r[1].interval = 1, e = 50;
      else if (((_j = (_i2 = this.props.obj2) == null ? void 0 : _i2.common) == null ? void 0 : _j.type) === "number" && this.props.obj2.common.states) {
        n.step = "end", r[1].axisLabel.showMaxLabel = false, r[1].axisLabel.formatter = (u) => this.props.obj2.common.states[u] !== void 0 ? this.props.obj2.common.states[u] : u;
        const s = Object.keys(this.props.obj2.common.states);
        s.sort(), r[1].max = parseFloat(s[s.length - 1]) + 0.5, r[1].interval = 1;
        let l = "";
        for (let u = 0; u < s.length; u++) typeof this.props.obj2.common.states[s[u]] == "string" && this.props.obj2.common.states[s[u]].length > l.length && (l = this.props.obj2.common.states[s[u]]);
        e = (l.length * 9 || 50) + 12;
      } else ((_l = (_k = this.props.obj2) == null ? void 0 : _k.common) == null ? void 0 : _l.type) === "number" && (this.props.obj2.common.min !== void 0 && this.props.obj2.common.max !== void 0 ? (r[1].max = this.props.obj2.common.max, r[1].min = this.props.obj2.common.min) : this.props.obj2.common.unit === "%" && (r[1].max = 100, r[1].min = 0));
      const o = this.chart.withSeconds ? Math.round((this.state.chartWidth - nt - E) / 100) : Math.round((this.state.chartWidth - nt - E) / 60);
      return {
        backgroundColor: "transparent",
        title: {
          text: this.props.noToolbar ? "" : this.props.chartTitle !== void 0 ? this.props.chartTitle : Zn.getObjectNameFromObj(this.props.obj, this.props.lang),
          padding: [
            10,
            0,
            0,
            t ? t + 10 : E + 10
          ]
        },
        grid: {
          left: t || E,
          top: r[0].name || r[1] && r[1].name ? 38 : 8,
          right: e || (this.props.noToolbar ? 5 : nt),
          bottom: 40
        },
        tooltip: {
          trigger: "axis",
          formatter: (s) => {
            const l = [], u = new Date(s[0].value[0]);
            let h = true;
            for (const d of s) {
              const [, p] = d.value;
              let f = p;
              f != null && (f = Math.round(f * 1e3) / 1e3), f !== null && this.props.isFloatComma && (f = f.toString().replace(".", ",")), l.push(`<div style="display: flex; gap: 4px; align-items: center">
<div style="border-radius: 15px;width: 15px;height: 15px;background-color: ${h ? this.props.objColor || "#f5ba4d" : this.props.obj2Color || "#21b400"};"></div>
<div>${h ? this.props.title : this.props.title2} -</div>
<div style="flex-grow: 1"></div>
<div>${d.exact === false ? "i" : ""}${f}${this.unit}</div>
</div>`), h = false;
            }
            const c = document.createElement("div");
            return c.innerHTML = `<div>${u.toLocaleString()}.${u.getMilliseconds().toString().padStart(3, "0")}</div>${l.join(`
`)}`, c;
          },
          axisPointer: {
            animation: true
          }
        },
        xAxis: {
          type: "time",
          splitLine: {
            show: false
          },
          splitNumber: o,
          min: this.chart.min,
          max: this.chart.max,
          axisTick: {
            alignWithLabel: true
          },
          axisLabel: {
            formatter: (s) => {
              const l = new Date(s);
              return this.chart.withSeconds ? `${l.getHours().toString().padStart(2, "0")}:${l.getMinutes().toString().padStart(2, "0")}:${l.getSeconds().toString().padStart(2, "0")}` : this.chart.withTime ? `${l.getHours().toString().padStart(2, "0")}:${l.getMinutes().toString().padStart(2, "0")}
${l.getDate().toString().padStart(2, "0")}.${(l.getMonth() + 1).toString().padStart(2, "0")}` : `${l.getDate().toString().padStart(2, "0")}.${(l.getMonth() + 1).toString().padStart(2, "0")}
${l.getFullYear()}`;
            }
          }
        },
        yAxis: r,
        series: [
          n,
          a
        ]
      };
    }
    static getDerivedStateFromProps() {
      return null;
    }
    updateChart(t, e, n, r) {
      t && (this.start = t), e && (this.end = e), t || (t = this.start), e || (e = this.end), this.readTimeout && clearTimeout(this.readTimeout), this.readTimeout = setTimeout(async () => {
        this.readTimeout = null;
        const a = this.chart.max - this.chart.min;
        if (a !== this.chart.diff && (this.chart.diff = a, this.chart.withTime = this.chart.diff < 36e5 * 24 * 7, this.chart.withSeconds = this.chart.diff < 6e4 * 30), n || !this.chartValues) {
          const o = await this.readHistory(t, e, this.props.obj._id);
          let s;
          this.props.obj2 && (s = await this.readHistory(t, e, this.props.obj2._id)), this.echartsReact && typeof this.echartsReact.getEchartsInstance == "function" && this.echartsReact.getEchartsInstance().setOption({
            series: [
              {
                data: this.convertData(o, this.props.obj._id)
              },
              this.props.obj2 ? {
                data: this.convertData(s, this.props.obj2._id)
              } : void 0
            ],
            xAxis: {
              min: this.chart.min,
              max: this.chart.max
            }
          }), r == null ? void 0 : r();
        } else this.echartsReact && typeof this.echartsReact.getEchartsInstance == "function" && (this.echartsReact.getEchartsInstance().setOption({
          series: [
            {
              data: this.convertData(null, this.props.obj._id)
            },
            this.props.obj2 ? {
              data: this.convertData(null, this.props.obj2._id)
            } : void 0
          ],
          xAxis: {
            min: this.chart.min,
            max: this.chart.max
          }
        }), r == null ? void 0 : r());
      }, this.chartValues ? 400 : 0);
    }
    setNewRange(t) {
      this.chart.diff = this.chart.max - this.chart.min, this.chart.withTime = this.chart.diff < 36e5 * 24 * 7, this.chart.withSeconds = this.chart.diff < 6e4 * 30, this.state.relativeRange !== "absolute" ? (this.setState({
        relativeRange: "absolute"
      }), this.timeTimer && clearTimeout(this.timeTimer), this.timeTimer = null) : this.echartsReact && typeof this.echartsReact.getEchartsInstance == "function" && (this.echartsReact.getEchartsInstance().setOption({
        xAxis: {
          min: this.chart.min,
          max: this.chart.max
        }
      }), t && this.updateChart(this.chart.min, this.chart.max, true));
    }
    shiftTime() {
      const t = /* @__PURE__ */ new Date(), e = 6e4 - t.getSeconds() - (1e3 - t.getMilliseconds());
      t.getMilliseconds() && t.setMilliseconds(1e3), t.getSeconds() && t.setSeconds(60);
      const n = t.getTime();
      let r, a = this.state.relativeRange;
      a === "day" ? (t.setHours(0), t.setMinutes(0), r = t.getTime()) : a === "week" ? (t.setHours(0), t.setMinutes(0), t.getDay() ? t.setDate(t.getDate() - t.getDay() - 1) : t.setDate(t.getDate() - 6), r = t.getTime()) : a === "2weeks" ? (t.setHours(0), t.setMinutes(0), t.getDay() ? t.setDate(t.getDate() - t.getDay() - 8) : t.setDate(t.getDate() - 13), r = t.getTime()) : a === "month" ? (t.setHours(0), t.setMinutes(0), t.setDate(1), r = t.getTime()) : a === "year" ? (t.setHours(0), t.setMinutes(0), t.setDate(1), t.setMonth(0), r = t.getTime()) : a === "12months" ? (t.setHours(0), t.setMinutes(0), t.setFullYear(t.getFullYear() - 1), r = t.getTime()) : (a = parseInt(a, 10), r = n - a * 6e4), this.chart.min = r, this.chart.max = n, this.setState({
        max: n
      }, () => this.updateChart(this.chart.min, this.chart.max, true)), this.timeTimer = setTimeout(() => {
        this.timeTimer = null, this.shiftTime();
      }, e || 6e4);
    }
    setRelativeInterval(t, e, n) {
      if (e || (window.localStorage.setItem("App.relativeRange", t), this.setState({
        relativeRange: t
      })), t === "absolute") {
        this.timeTimer && clearTimeout(this.timeTimer), this.timeTimer = null, this.updateChart(this.chart.min, this.chart.max, true, n);
        return;
      }
      window.localStorage.removeItem("App.absoluteStart"), window.localStorage.removeItem("App.absoluteEnd");
      const r = /* @__PURE__ */ new Date();
      if (!this.timeTimer) {
        const a = 6e4 - r.getSeconds() - (1e3 - r.getMilliseconds());
        this.timeTimer = setTimeout(() => {
          this.timeTimer = null, this.shiftTime();
        }, a || 6e4);
      }
      r.getMilliseconds() && r.setMilliseconds(1e3), r.getSeconds() && r.setSeconds(60), this.chart.max = r.getTime(), t === "day" ? (r.setHours(0), r.setMinutes(0), this.chart.min = r.getTime()) : t === "week" ? (r.setHours(0), r.setMinutes(0), r.getDay() ? r.setDate(r.getDate() - r.getDay() - 1) : r.setDate(r.getDate() - 6), this.chart.min = r.getTime()) : t === "2weeks" ? (r.setHours(0), r.setMinutes(0), r.getDay() ? r.setDate(r.getDate() - r.getDay() - 8) : r.setDate(r.getDate() - 13), this.chart.min = r.getTime()) : t === "month" ? (r.setHours(0), r.setMinutes(0), r.setDate(1), this.chart.min = r.getTime()) : t === "year" ? (r.setHours(0), r.setMinutes(0), r.setDate(1), r.setMonth(0), this.chart.min = r.getTime()) : t === "12months" ? (r.setHours(0), r.setMinutes(0), r.setFullYear(r.getFullYear() - 1), this.chart.min = r.getTime()) : (t = parseInt(t, 10), this.chart.min = this.chart.max - t * 6e4), this.setState({
        max: this.chart.max
      }, () => this.updateChart(this.chart.min, this.chart.max, true, n));
    }
    installEventHandlers() {
      if (!this.echartsReact || typeof this.echartsReact.getEchartsInstance != "function") return;
      const t = this.echartsReact.getEchartsInstance().getZr();
      t._iobInstalled || (t._iobInstalled = true, t.on("mousedown", (e) => {
        console.log("mouse down"), this.mouseDown = true, this.chart.lastX = e.offsetX;
      }), t.on("mouseup", () => {
        console.log("mouse up"), this.mouseDown = false, this.setNewRange(true);
      }), t.on("mousewheel", (e) => {
        let n = this.chart.max - this.chart.min;
        const r = this.state.chartWidth - nt - E, o = (e.offsetX - E) / r, s = n, l = e.wheelDelta > 0 ? 1.1 : 0.9;
        n *= l;
        const u = s - n;
        this.chart.max += u * (1 - o), this.chart.min -= u * o, this.setNewRange();
      }), t.on("mousemove", (e) => {
        if (this.mouseDown) {
          const n = this.chart.lastX - (e.offsetX - E);
          this.chart.lastX = e.offsetX - E;
          const r = this.chart.max - this.chart.min, a = this.state.chartWidth - nt - E, o = Math.round(n * r / a);
          this.chart.min += o, this.chart.max += o, this.setNewRange();
        }
      }), t.on("touchstart", (e) => {
        e.preventDefault(), this.mouseDown = true;
        const n = e.touches || e.originalEvent.touches;
        n && (this.chart.lastX = n[n.length - 1].pageX, n.length > 1 ? this.chart.lastWidth = Math.abs(n[0].pageX - n[1].pageX) : this.chart.lastWidth = null);
      }), t.on("touchend", (e) => {
        e.preventDefault(), this.mouseDown = false, this.setNewRange(true);
      }), t.on("touchmove", (e) => {
        e.preventDefault();
        const n = e.touches || e.originalEvent.touches;
        if (!n) return;
        const r = n[n.length - 1].pageX - E;
        if (this.mouseDown) if (n.length > 1) {
          const a = Math.abs(n[0].pageX - n[1].pageX);
          if (this.chart.lastWidth !== null && a !== this.chart.lastWidth) {
            let o = this.chart.max - this.chart.min;
            const s = this.state.chartWidth - nt - E, l = a > this.chart.lastWidth ? 1.1 : 0.9, h = (n[0].pageX > n[1].pageX ? n[1].pageX - E + a / 2 : n[0].pageX - E + a / 2) / s, c = o;
            o *= l;
            const d = c - o;
            this.chart.max += d * (1 - h), this.chart.min -= d * h, this.setNewRange();
          }
          this.chart.lastWidth = a;
        } else {
          const a = this.chart.lastX - r, o = this.chart.max - this.chart.min, s = this.state.chartWidth - nt - E, l = Math.round(a * o / s);
          this.chart.min += l, this.chart.max += l, this.setNewRange();
        }
        this.chart.lastX = r;
      }));
    }
    renderChart() {
      return this.chartValues && this.chartValues[this.props.obj._id] ? M.jsx(Vn, {
        ref: (t) => {
          this.echartsReact = t;
        },
        echarts: Wn,
        option: this.getOption(),
        notMerge: true,
        lazyUpdate: true,
        theme: this.props.themeType === "dark" ? "dark" : "",
        style: {
          height: `${this.state.chartHeight}px`,
          width: "100%"
        },
        opts: {
          renderer: "svg"
        },
        onEvents: {
          rendered: () => this.installEventHandlers()
        }
      }) : M.jsx(Ir, {});
    }
    componentDidUpdate() {
      if (this.divRef.current) {
        const t = this.divRef.current.offsetWidth, e = this.divRef.current.offsetHeight;
        this.state.chartHeight !== e && setTimeout(() => this.setState({
          chartHeight: e,
          chartWidth: t
        }), 100);
      }
    }
    renderToolbar() {
      if (this.props.noToolbar) return null;
      const t = window.document.body.clientWidth > 600;
      return M.jsxs(kr, {
        style: {
          display: "flex",
          justifyContent: "space-between"
        },
        children: [
          M.jsxs(Pr, {
            variant: "standard",
            style: {
              minWidth: 200
            },
            children: [
              M.jsx(Rr, {
                children: this.props.t("relative")
              }),
              M.jsxs(Or, {
                variant: "standard",
                ref: this.rangeRef,
                value: this.state.relativeRange,
                onChange: (e) => this.setRelativeInterval(e.target.value),
                children: [
                  M.jsx(O, {
                    value: "absolute",
                    sx: {
                      color: "primary.main"
                    },
                    children: this.props.t("custom_range")
                  }),
                  M.jsx(O, {
                    value: 10,
                    children: this.props.t("last 10 minutes")
                  }),
                  M.jsx(O, {
                    value: 30,
                    children: this.props.t("last 30 minutes")
                  }),
                  M.jsx(O, {
                    value: 60,
                    children: this.props.t("last hour")
                  }),
                  M.jsx(O, {
                    value: "day",
                    children: this.props.t("this day")
                  }),
                  M.jsx(O, {
                    value: 1440,
                    children: this.props.t("last 24 hours")
                  }),
                  M.jsx(O, {
                    value: "week",
                    children: this.props.t("this week")
                  }),
                  M.jsx(O, {
                    value: 1440 * 7,
                    children: this.props.t("last week")
                  }),
                  M.jsx(O, {
                    value: "2weeks",
                    children: this.props.t("this 2 weeks")
                  }),
                  M.jsx(O, {
                    value: 1440 * 14,
                    children: this.props.t("last 2 weeks")
                  }),
                  M.jsx(O, {
                    value: "month",
                    children: this.props.t("this month")
                  }),
                  M.jsx(O, {
                    value: 720 * 60,
                    children: this.props.t("last 30 days")
                  }),
                  M.jsx(O, {
                    value: "year",
                    children: this.props.t("this year")
                  }),
                  M.jsx(O, {
                    value: "12months",
                    children: this.props.t("last 12 months")
                  })
                ]
              })
            ]
          }),
          t ? M.jsxs(Er, {
            variant: "extended",
            size: "small",
            color: this.state.splitLine ? "primary" : void 0,
            "aria-label": "show lines",
            onClick: () => {
              window.localStorage.setItem("App.splitLine", this.state.splitLine ? "false" : "true"), this.setState({
                splitLine: !this.state.splitLine
              });
            },
            children: [
              M.jsx(Es, {
                style: {
                  marginRight: 8
                }
              }),
              this.props.t("Show lines")
            ]
          }) : null
        ]
      });
    }
    render() {
      return M.jsxs(Br, {
        style: {
          height: "100%",
          maxHeight: "100%",
          maxWidth: "100%",
          overflow: "hidden",
          width: "100%"
        },
        children: [
          this.renderToolbar(),
          M.jsx(zr, {
            component: "div",
            ref: this.divRef,
            style: {
              width: "100%",
              overflow: "hidden"
            },
            sx: this.props.noToolbar ? zi.chartWithoutToolbar : zi.chartWithToolbar,
            children: this.renderChart()
          })
        ]
      });
    }
  }
  Ns = Fn()(Bs);
});
export {
  Ns as O,
  __tla,
  Os as a,
  ks as b,
  _o as c,
  fs as i,
  zo as m
};
