import { j as y, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { a as Hn, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { h as Os } from "./moment-BLMuvzoS.js";
import { G as Rt } from "./Generic-DDdmRdK-.js";
import { __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
let Rs;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })()
]).then(async () => {
  function q(j) {
    throw new Error('Could not dynamically require "' + j + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
  }
  var Fn = {
    exports: {}
  }, tt = {
    exports: {}
  }, Nn = tt.exports, Ws;
  function K() {
    return Ws || (Ws = 1, (function(j, h) {
      (function(l, n) {
        j.exports = n();
      })(Nn, (function() {
        var l;
        function n() {
          return l.apply(null, arguments);
        }
        function w(e) {
          l = e;
        }
        function M(e) {
          return e instanceof Array || Object.prototype.toString.call(e) === "[object Array]";
        }
        function p(e) {
          return e != null && Object.prototype.toString.call(e) === "[object Object]";
        }
        function u(e, t) {
          return Object.prototype.hasOwnProperty.call(e, t);
        }
        function c(e) {
          if (Object.getOwnPropertyNames) return Object.getOwnPropertyNames(e).length === 0;
          var t;
          for (t in e) if (u(e, t)) return false;
          return true;
        }
        function f(e) {
          return e === void 0;
        }
        function D(e) {
          return typeof e == "number" || Object.prototype.toString.call(e) === "[object Number]";
        }
        function H(e) {
          return e instanceof Date || Object.prototype.toString.call(e) === "[object Date]";
        }
        function C(e, t) {
          var s = [], r, a = e.length;
          for (r = 0; r < a; ++r) s.push(t(e[r], r));
          return s;
        }
        function I(e, t) {
          for (var s in t) u(t, s) && (e[s] = t[s]);
          return u(t, "toString") && (e.toString = t.toString), u(t, "valueOf") && (e.valueOf = t.valueOf), e;
        }
        function U(e, t, s, r) {
          return os(e, t, s, r, true).utc();
        }
        function Hs() {
          return {
            empty: false,
            unusedTokens: [],
            unusedInput: [],
            overflow: -2,
            charsLeftOver: 0,
            nullInput: false,
            invalidEra: null,
            invalidMonth: null,
            invalidFormat: false,
            userInvalidated: false,
            iso: false,
            parsedDateParts: [],
            era: null,
            meridiem: null,
            rfc2822: false,
            weekdayMismatch: false
          };
        }
        function k(e) {
          return e._pf == null && (e._pf = Hs()), e._pf;
        }
        var st;
        Array.prototype.some ? st = Array.prototype.some : st = function(e) {
          var t = Object(this), s = t.length >>> 0, r;
          for (r = 0; r < s; r++) if (r in t && e.call(this, t[r], r, t)) return true;
          return false;
        };
        function rt(e) {
          var t = null, s = false, r = e._d && !isNaN(e._d.getTime());
          if (r && (t = k(e), s = st.call(t.parsedDateParts, function(a) {
            return a != null;
          }), r = t.overflow < 0 && !t.empty && !t.invalidEra && !t.invalidMonth && !t.invalidWeekday && !t.weekdayMismatch && !t.nullInput && !t.invalidFormat && !t.userInvalidated && (!t.meridiem || t.meridiem && s), e._strict && (r = r && t.charsLeftOver === 0 && t.unusedTokens.length === 0 && t.bigHour === void 0)), Object.isFrozen == null || !Object.isFrozen(e)) e._isValid = r;
          else return r;
          return e._isValid;
        }
        function Re(e) {
          var t = U(NaN);
          return e != null ? I(k(t), e) : k(t).userInvalidated = true, t;
        }
        var Ht = n.momentProperties = [], at = false;
        function it(e, t) {
          var s, r, a, i = Ht.length;
          if (f(t._isAMomentObject) || (e._isAMomentObject = t._isAMomentObject), f(t._i) || (e._i = t._i), f(t._f) || (e._f = t._f), f(t._l) || (e._l = t._l), f(t._strict) || (e._strict = t._strict), f(t._tzm) || (e._tzm = t._tzm), f(t._isUTC) || (e._isUTC = t._isUTC), f(t._offset) || (e._offset = t._offset), f(t._pf) || (e._pf = k(t)), f(t._locale) || (e._locale = t._locale), i > 0) for (s = 0; s < i; s++) r = Ht[s], a = t[r], f(a) || (e[r] = a);
          return e;
        }
        function Ye(e) {
          it(this, e), this._d = new Date(e._d != null ? e._d.getTime() : NaN), this.isValid() || (this._d = /* @__PURE__ */ new Date(NaN)), at === false && (at = true, n.updateOffset(this), at = false);
        }
        function G(e) {
          return e instanceof Ye || e != null && e._isAMomentObject != null;
        }
        function Ft(e) {
          n.suppressDeprecationWarnings === false && typeof console < "u" && console.warn && console.warn("Deprecation warning: " + e);
        }
        function E(e, t) {
          var s = true;
          return I(function() {
            if (n.deprecationHandler != null && n.deprecationHandler(null, e), s) {
              var r = [], a, i, o, _ = arguments.length;
              for (i = 0; i < _; i++) {
                if (a = "", typeof arguments[i] == "object") {
                  a += `
[` + i + "] ";
                  for (o in arguments[0]) u(arguments[0], o) && (a += o + ": " + arguments[0][o] + ", ");
                  a = a.slice(0, -2);
                } else a = arguments[i];
                r.push(a);
              }
              Ft(e + `
Arguments: ` + Array.prototype.slice.call(r).join("") + `
` + new Error().stack), s = false;
            }
            return t.apply(this, arguments);
          }, t);
        }
        var Nt = {};
        function Ct(e, t) {
          n.deprecationHandler != null && n.deprecationHandler(e, t), Nt[e] || (Ft(t), Nt[e] = true);
        }
        n.suppressDeprecationWarnings = false, n.deprecationHandler = null;
        function J(e) {
          return typeof Function < "u" && e instanceof Function || Object.prototype.toString.call(e) === "[object Function]";
        }
        function Fs(e) {
          var t, s;
          for (s in e) u(e, s) && (t = e[s], J(t) ? this[s] = t : this["_" + s] = t);
          this._config = e, this._dayOfMonthOrdinalParseLenient = new RegExp((this._dayOfMonthOrdinalParse.source || this._ordinalParse.source) + "|" + /\d{1,2}/.source);
        }
        function nt(e, t) {
          var s = I({}, e), r;
          for (r in t) u(t, r) && (p(e[r]) && p(t[r]) ? (s[r] = {}, I(s[r], e[r]), I(s[r], t[r])) : t[r] != null ? s[r] = t[r] : delete s[r]);
          for (r in e) u(e, r) && !u(t, r) && p(e[r]) && (s[r] = I({}, s[r]));
          return s;
        }
        function ot(e) {
          e != null && this.set(e);
        }
        var lt;
        Object.keys ? lt = Object.keys : lt = function(e) {
          var t, s = [];
          for (t in e) u(e, t) && s.push(t);
          return s;
        };
        var Ns = {
          sameDay: "[Today at] LT",
          nextDay: "[Tomorrow at] LT",
          nextWeek: "dddd [at] LT",
          lastDay: "[Yesterday at] LT",
          lastWeek: "[Last] dddd [at] LT",
          sameElse: "L"
        };
        function Cs(e, t, s) {
          var r = this._calendar[e] || this._calendar.sameElse;
          return J(r) ? r.call(t, s) : r;
        }
        function Q(e, t, s) {
          var r = "" + Math.abs(e), a = t - r.length, i = e >= 0;
          return (i ? s ? "+" : "" : "-") + Math.pow(10, Math.max(0, a)).toString().substr(1) + r;
        }
        var dt = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|N{1,5}|YYYYYY|YYYYY|YYYY|YY|y{2,4}|yo?|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g, He = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g, ut = {}, me = {};
        function g(e, t, s, r) {
          var a = r;
          typeof r == "string" && (a = function() {
            return this[r]();
          }), e && (me[e] = a), t && (me[t[0]] = function() {
            return Q(a.apply(this, arguments), t[1], t[2]);
          }), s && (me[s] = function() {
            return this.localeData().ordinal(a.apply(this, arguments), e);
          });
        }
        function zs(e) {
          return e.match(/\[[\s\S]/) ? e.replace(/^\[|\]$/g, "") : e.replace(/\\/g, "");
        }
        function Is(e) {
          var t = e.match(dt), s, r;
          for (s = 0, r = t.length; s < r; s++) me[t[s]] ? t[s] = me[t[s]] : t[s] = zs(t[s]);
          return function(a) {
            var i = "", o;
            for (o = 0; o < r; o++) i += J(t[o]) ? t[o].call(a, e) : t[o];
            return i;
          };
        }
        function Fe(e, t) {
          return e.isValid() ? (t = zt(t, e.localeData()), ut[t] = ut[t] || Is(t), ut[t](e)) : e.localeData().invalidDate();
        }
        function zt(e, t) {
          var s = 5;
          function r(a) {
            return t.longDateFormat(a) || a;
          }
          for (He.lastIndex = 0; s >= 0 && He.test(e); ) e = e.replace(He, r), He.lastIndex = 0, s -= 1;
          return e;
        }
        var As = {
          LTS: "h:mm:ss A",
          LT: "h:mm A",
          L: "MM/DD/YYYY",
          LL: "MMMM D, YYYY",
          LLL: "MMMM D, YYYY h:mm A",
          LLLL: "dddd, MMMM D, YYYY h:mm A"
        };
        function Us(e) {
          var t = this._longDateFormat[e], s = this._longDateFormat[e.toUpperCase()];
          return t || !s ? t : (this._longDateFormat[e] = s.match(dt).map(function(r) {
            return r === "MMMM" || r === "MM" || r === "DD" || r === "dddd" ? r.slice(1) : r;
          }).join(""), this._longDateFormat[e]);
        }
        var Es = "Invalid date";
        function $s() {
          return this._invalidDate;
        }
        var Vs = "%d", Gs = /\d{1,2}/;
        function Bs(e) {
          return this._ordinal.replace("%d", e);
        }
        var Zs = {
          future: "in %s",
          past: "%s ago",
          s: "a few seconds",
          ss: "%d seconds",
          m: "a minute",
          mm: "%d minutes",
          h: "an hour",
          hh: "%d hours",
          d: "a day",
          dd: "%d days",
          w: "a week",
          ww: "%d weeks",
          M: "a month",
          MM: "%d months",
          y: "a year",
          yy: "%d years"
        };
        function qs(e, t, s, r) {
          var a = this._relativeTime[s];
          return J(a) ? a(e, t, s, r) : a.replace(/%d/i, e);
        }
        function Js(e, t) {
          var s = this._relativeTime[e > 0 ? "future" : "past"];
          return J(s) ? s(t) : s.replace(/%s/i, t);
        }
        var It = {
          D: "date",
          dates: "date",
          date: "date",
          d: "day",
          days: "day",
          day: "day",
          e: "weekday",
          weekdays: "weekday",
          weekday: "weekday",
          E: "isoWeekday",
          isoweekdays: "isoWeekday",
          isoweekday: "isoWeekday",
          DDD: "dayOfYear",
          dayofyears: "dayOfYear",
          dayofyear: "dayOfYear",
          h: "hour",
          hours: "hour",
          hour: "hour",
          ms: "millisecond",
          milliseconds: "millisecond",
          millisecond: "millisecond",
          m: "minute",
          minutes: "minute",
          minute: "minute",
          M: "month",
          months: "month",
          month: "month",
          Q: "quarter",
          quarters: "quarter",
          quarter: "quarter",
          s: "second",
          seconds: "second",
          second: "second",
          gg: "weekYear",
          weekyears: "weekYear",
          weekyear: "weekYear",
          GG: "isoWeekYear",
          isoweekyears: "isoWeekYear",
          isoweekyear: "isoWeekYear",
          w: "week",
          weeks: "week",
          week: "week",
          W: "isoWeek",
          isoweeks: "isoWeek",
          isoweek: "isoWeek",
          y: "year",
          years: "year",
          year: "year"
        };
        function $(e) {
          return typeof e == "string" ? It[e] || It[e.toLowerCase()] : void 0;
        }
        function ht(e) {
          var t = {}, s, r;
          for (r in e) u(e, r) && (s = $(r), s && (t[s] = e[r]));
          return t;
        }
        var Qs = {
          date: 9,
          day: 11,
          weekday: 11,
          isoWeekday: 11,
          dayOfYear: 4,
          hour: 13,
          millisecond: 16,
          minute: 14,
          month: 8,
          quarter: 7,
          second: 15,
          weekYear: 1,
          isoWeekYear: 1,
          week: 5,
          isoWeek: 5,
          year: 1
        };
        function Xs(e) {
          var t = [], s;
          for (s in e) u(e, s) && t.push({
            unit: s,
            priority: Qs[s]
          });
          return t.sort(function(r, a) {
            return r.priority - a.priority;
          }), t;
        }
        var At = /\d/, A = /\d\d/, Ut = /\d{3}/, ct = /\d{4}/, Ne = /[+-]?\d{6}/, b = /\d\d?/, Et = /\d\d\d\d?/, $t = /\d\d\d\d\d\d?/, Ce = /\d{1,3}/, ft = /\d{1,4}/, ze = /[+-]?\d{1,6}/, ye = /\d+/, Ie = /[+-]?\d+/, Ks = /Z|[+-]\d\d:?\d\d/gi, Ae = /Z|[+-]\d\d(?::?\d\d)?/gi, er = /[+-]?\d+(\.\d{1,3})?/, Se = /[0-9]{0,256}['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFF07\uFF10-\uFFEF]{1,256}|[\u0600-\u06FF\/]{1,256}(\s*?[\u0600-\u06FF]{1,256}){1,2}/i, we = /^[1-9]\d?/, _t = /^([1-9]\d|\d)/, Ue;
        Ue = {};
        function m(e, t, s) {
          Ue[e] = J(t) ? t : function(r, a) {
            return r && s ? s : t;
          };
        }
        function tr(e, t) {
          return u(Ue, e) ? Ue[e](t._strict, t._locale) : new RegExp(sr(e));
        }
        function sr(e) {
          return ee(e.replace("\\", "").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function(t, s, r, a, i) {
            return s || r || a || i;
          }));
        }
        function ee(e) {
          return e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
        }
        function V(e) {
          return e < 0 ? Math.ceil(e) || 0 : Math.floor(e);
        }
        function Y(e) {
          var t = +e, s = 0;
          return t !== 0 && isFinite(t) && (s = V(t)), s;
        }
        var mt = {};
        function T(e, t) {
          var s, r = t, a;
          for (typeof e == "string" && (e = [
            e
          ]), D(t) && (r = function(i, o) {
            o[t] = Y(i);
          }), a = e.length, s = 0; s < a; s++) mt[e[s]] = r;
        }
        function xe(e, t) {
          T(e, function(s, r, a, i) {
            a._w = a._w || {}, t(s, a._w, a, i);
          });
        }
        function rr(e, t, s) {
          t != null && u(mt, e) && mt[e](t, s._a, s, e);
        }
        function Ee(e) {
          return e % 4 === 0 && e % 100 !== 0 || e % 400 === 0;
        }
        var N = 0, te = 1, X = 2, R = 3, B = 4, se = 5, ce = 6, ar = 7, ir = 8;
        g("Y", 0, 0, function() {
          var e = this.year();
          return e <= 9999 ? Q(e, 4) : "+" + e;
        }), g(0, [
          "YY",
          2
        ], 0, function() {
          return this.year() % 100;
        }), g(0, [
          "YYYY",
          4
        ], 0, "year"), g(0, [
          "YYYYY",
          5
        ], 0, "year"), g(0, [
          "YYYYYY",
          6,
          true
        ], 0, "year"), m("Y", Ie), m("YY", b, A), m("YYYY", ft, ct), m("YYYYY", ze, Ne), m("YYYYYY", ze, Ne), T([
          "YYYYY",
          "YYYYYY"
        ], N), T("YYYY", function(e, t) {
          t[N] = e.length === 2 ? n.parseTwoDigitYear(e) : Y(e);
        }), T("YY", function(e, t) {
          t[N] = n.parseTwoDigitYear(e);
        }), T("Y", function(e, t) {
          t[N] = parseInt(e, 10);
        });
        function Le(e) {
          return Ee(e) ? 366 : 365;
        }
        n.parseTwoDigitYear = function(e) {
          return Y(e) + (Y(e) > 68 ? 1900 : 2e3);
        };
        var Vt = Me("FullYear", true);
        function nr() {
          return Ee(this.year());
        }
        function Me(e, t) {
          return function(s) {
            return s != null ? (Gt(this, e, s), n.updateOffset(this, t), this) : Te(this, e);
          };
        }
        function Te(e, t) {
          if (!e.isValid()) return NaN;
          var s = e._d, r = e._isUTC;
          switch (t) {
            case "Milliseconds":
              return r ? s.getUTCMilliseconds() : s.getMilliseconds();
            case "Seconds":
              return r ? s.getUTCSeconds() : s.getSeconds();
            case "Minutes":
              return r ? s.getUTCMinutes() : s.getMinutes();
            case "Hours":
              return r ? s.getUTCHours() : s.getHours();
            case "Date":
              return r ? s.getUTCDate() : s.getDate();
            case "Day":
              return r ? s.getUTCDay() : s.getDay();
            case "Month":
              return r ? s.getUTCMonth() : s.getMonth();
            case "FullYear":
              return r ? s.getUTCFullYear() : s.getFullYear();
            default:
              return NaN;
          }
        }
        function Gt(e, t, s) {
          var r, a, i, o, _;
          if (!(!e.isValid() || isNaN(s))) {
            switch (r = e._d, a = e._isUTC, t) {
              case "Milliseconds":
                return void (a ? r.setUTCMilliseconds(s) : r.setMilliseconds(s));
              case "Seconds":
                return void (a ? r.setUTCSeconds(s) : r.setSeconds(s));
              case "Minutes":
                return void (a ? r.setUTCMinutes(s) : r.setMinutes(s));
              case "Hours":
                return void (a ? r.setUTCHours(s) : r.setHours(s));
              case "Date":
                return void (a ? r.setUTCDate(s) : r.setDate(s));
              case "FullYear":
                break;
              default:
                return;
            }
            i = s, o = e.month(), _ = e.date(), _ = _ === 29 && o === 1 && !Ee(i) ? 28 : _, a ? r.setUTCFullYear(i, o, _) : r.setFullYear(i, o, _);
          }
        }
        function or(e) {
          return e = $(e), J(this[e]) ? this[e]() : this;
        }
        function lr(e, t) {
          if (typeof e == "object") {
            e = ht(e);
            var s = Xs(e), r, a = s.length;
            for (r = 0; r < a; r++) this[s[r].unit](e[s[r].unit]);
          } else if (e = $(e), J(this[e])) return this[e](t);
          return this;
        }
        function dr(e, t) {
          return (e % t + t) % t;
        }
        var P;
        Array.prototype.indexOf ? P = Array.prototype.indexOf : P = function(e) {
          var t;
          for (t = 0; t < this.length; ++t) if (this[t] === e) return t;
          return -1;
        };
        function yt(e, t) {
          if (isNaN(e) || isNaN(t)) return NaN;
          var s = dr(t, 12);
          return e += (t - s) / 12, s === 1 ? Ee(e) ? 29 : 28 : 31 - s % 7 % 2;
        }
        g("M", [
          "MM",
          2
        ], "Mo", function() {
          return this.month() + 1;
        }), g("MMM", 0, 0, function(e) {
          return this.localeData().monthsShort(this, e);
        }), g("MMMM", 0, 0, function(e) {
          return this.localeData().months(this, e);
        }), m("M", b, we), m("MM", b, A), m("MMM", function(e, t) {
          return t.monthsShortRegex(e);
        }), m("MMMM", function(e, t) {
          return t.monthsRegex(e);
        }), T([
          "M",
          "MM"
        ], function(e, t) {
          t[te] = Y(e) - 1;
        }), T([
          "MMM",
          "MMMM"
        ], function(e, t, s, r) {
          var a = s._locale.monthsParse(e, r, s._strict);
          a != null ? t[te] = a : k(s).invalidMonth = e;
        });
        var ur = "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), Bt = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"), Zt = /D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/, hr = Se, cr = Se;
        function fr(e, t) {
          return e ? M(this._months) ? this._months[e.month()] : this._months[(this._months.isFormat || Zt).test(t) ? "format" : "standalone"][e.month()] : M(this._months) ? this._months : this._months.standalone;
        }
        function _r(e, t) {
          return e ? M(this._monthsShort) ? this._monthsShort[e.month()] : this._monthsShort[Zt.test(t) ? "format" : "standalone"][e.month()] : M(this._monthsShort) ? this._monthsShort : this._monthsShort.standalone;
        }
        function mr(e, t, s) {
          var r, a, i, o = e.toLocaleLowerCase();
          if (!this._monthsParse) for (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = [], r = 0; r < 12; ++r) i = U([
            2e3,
            r
          ]), this._shortMonthsParse[r] = this.monthsShort(i, "").toLocaleLowerCase(), this._longMonthsParse[r] = this.months(i, "").toLocaleLowerCase();
          return s ? t === "MMM" ? (a = P.call(this._shortMonthsParse, o), a !== -1 ? a : null) : (a = P.call(this._longMonthsParse, o), a !== -1 ? a : null) : t === "MMM" ? (a = P.call(this._shortMonthsParse, o), a !== -1 ? a : (a = P.call(this._longMonthsParse, o), a !== -1 ? a : null)) : (a = P.call(this._longMonthsParse, o), a !== -1 ? a : (a = P.call(this._shortMonthsParse, o), a !== -1 ? a : null));
        }
        function yr(e, t, s) {
          var r, a, i;
          if (this._monthsParseExact) return mr.call(this, e, t, s);
          for (this._monthsParse || (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = []), r = 0; r < 12; r++) {
            if (a = U([
              2e3,
              r
            ]), s && !this._longMonthsParse[r] && (this._longMonthsParse[r] = new RegExp("^" + this.months(a, "").replace(".", "") + "$", "i"), this._shortMonthsParse[r] = new RegExp("^" + this.monthsShort(a, "").replace(".", "") + "$", "i")), !s && !this._monthsParse[r] && (i = "^" + this.months(a, "") + "|^" + this.monthsShort(a, ""), this._monthsParse[r] = new RegExp(i.replace(".", ""), "i")), s && t === "MMMM" && this._longMonthsParse[r].test(e)) return r;
            if (s && t === "MMM" && this._shortMonthsParse[r].test(e)) return r;
            if (!s && this._monthsParse[r].test(e)) return r;
          }
        }
        function qt(e, t) {
          if (!e.isValid()) return e;
          if (typeof t == "string") {
            if (/^\d+$/.test(t)) t = Y(t);
            else if (t = e.localeData().monthsParse(t), !D(t)) return e;
          }
          var s = t, r = e.date();
          return r = r < 29 ? r : Math.min(r, yt(e.year(), s)), e._isUTC ? e._d.setUTCMonth(s, r) : e._d.setMonth(s, r), e;
        }
        function Jt(e) {
          return e != null ? (qt(this, e), n.updateOffset(this, true), this) : Te(this, "Month");
        }
        function wr() {
          return yt(this.year(), this.month());
        }
        function Mr(e) {
          return this._monthsParseExact ? (u(this, "_monthsRegex") || Qt.call(this), e ? this._monthsShortStrictRegex : this._monthsShortRegex) : (u(this, "_monthsShortRegex") || (this._monthsShortRegex = hr), this._monthsShortStrictRegex && e ? this._monthsShortStrictRegex : this._monthsShortRegex);
        }
        function gr(e) {
          return this._monthsParseExact ? (u(this, "_monthsRegex") || Qt.call(this), e ? this._monthsStrictRegex : this._monthsRegex) : (u(this, "_monthsRegex") || (this._monthsRegex = cr), this._monthsStrictRegex && e ? this._monthsStrictRegex : this._monthsRegex);
        }
        function Qt() {
          function e(v, S) {
            return S.length - v.length;
          }
          var t = [], s = [], r = [], a, i, o, _;
          for (a = 0; a < 12; a++) i = U([
            2e3,
            a
          ]), o = ee(this.monthsShort(i, "")), _ = ee(this.months(i, "")), t.push(o), s.push(_), r.push(_), r.push(o);
          t.sort(e), s.sort(e), r.sort(e), this._monthsRegex = new RegExp("^(" + r.join("|") + ")", "i"), this._monthsShortRegex = this._monthsRegex, this._monthsStrictRegex = new RegExp("^(" + s.join("|") + ")", "i"), this._monthsShortStrictRegex = new RegExp("^(" + t.join("|") + ")", "i");
        }
        function pr(e, t, s, r, a, i, o) {
          var _;
          return e < 100 && e >= 0 ? (_ = new Date(e + 400, t, s, r, a, i, o), isFinite(_.getFullYear()) && _.setFullYear(e)) : _ = new Date(e, t, s, r, a, i, o), _;
        }
        function be(e) {
          var t, s;
          return e < 100 && e >= 0 ? (s = Array.prototype.slice.call(arguments), s[0] = e + 400, t = new Date(Date.UTC.apply(null, s)), isFinite(t.getUTCFullYear()) && t.setUTCFullYear(e)) : t = new Date(Date.UTC.apply(null, arguments)), t;
        }
        function $e(e, t, s) {
          var r = 7 + t - s, a = (7 + be(e, 0, r).getUTCDay() - t) % 7;
          return -a + r - 1;
        }
        function Xt(e, t, s, r, a) {
          var i = (7 + s - r) % 7, o = $e(e, r, a), _ = 1 + 7 * (t - 1) + i + o, v, S;
          return _ <= 0 ? (v = e - 1, S = Le(v) + _) : _ > Le(e) ? (v = e + 1, S = _ - Le(e)) : (v = e, S = _), {
            year: v,
            dayOfYear: S
          };
        }
        function Oe(e, t, s) {
          var r = $e(e.year(), t, s), a = Math.floor((e.dayOfYear() - r - 1) / 7) + 1, i, o;
          return a < 1 ? (o = e.year() - 1, i = a + re(o, t, s)) : a > re(e.year(), t, s) ? (i = a - re(e.year(), t, s), o = e.year() + 1) : (o = e.year(), i = a), {
            week: i,
            year: o
          };
        }
        function re(e, t, s) {
          var r = $e(e, t, s), a = $e(e + 1, t, s);
          return (Le(e) - r + a) / 7;
        }
        g("w", [
          "ww",
          2
        ], "wo", "week"), g("W", [
          "WW",
          2
        ], "Wo", "isoWeek"), m("w", b, we), m("ww", b, A), m("W", b, we), m("WW", b, A), xe([
          "w",
          "ww",
          "W",
          "WW"
        ], function(e, t, s, r) {
          t[r.substr(0, 1)] = Y(e);
        });
        function vr(e) {
          return Oe(e, this._week.dow, this._week.doy).week;
        }
        var kr = {
          dow: 0,
          doy: 6
        };
        function Dr() {
          return this._week.dow;
        }
        function Yr() {
          return this._week.doy;
        }
        function Sr(e) {
          var t = this.localeData().week(this);
          return e == null ? t : this.add((e - t) * 7, "d");
        }
        function xr(e) {
          var t = Oe(this, 1, 4).week;
          return e == null ? t : this.add((e - t) * 7, "d");
        }
        g("d", 0, "do", "day"), g("dd", 0, 0, function(e) {
          return this.localeData().weekdaysMin(this, e);
        }), g("ddd", 0, 0, function(e) {
          return this.localeData().weekdaysShort(this, e);
        }), g("dddd", 0, 0, function(e) {
          return this.localeData().weekdays(this, e);
        }), g("e", 0, 0, "weekday"), g("E", 0, 0, "isoWeekday"), m("d", b), m("e", b), m("E", b), m("dd", function(e, t) {
          return t.weekdaysMinRegex(e);
        }), m("ddd", function(e, t) {
          return t.weekdaysShortRegex(e);
        }), m("dddd", function(e, t) {
          return t.weekdaysRegex(e);
        }), xe([
          "dd",
          "ddd",
          "dddd"
        ], function(e, t, s, r) {
          var a = s._locale.weekdaysParse(e, r, s._strict);
          a != null ? t.d = a : k(s).invalidWeekday = e;
        }), xe([
          "d",
          "e",
          "E"
        ], function(e, t, s, r) {
          t[r] = Y(e);
        });
        function Lr(e, t) {
          return typeof e != "string" ? e : isNaN(e) ? (e = t.weekdaysParse(e), typeof e == "number" ? e : null) : parseInt(e, 10);
        }
        function Tr(e, t) {
          return typeof e == "string" ? t.weekdaysParse(e) % 7 || 7 : isNaN(e) ? null : e;
        }
        function wt(e, t) {
          return e.slice(t, 7).concat(e.slice(0, t));
        }
        var br = "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), Kt = "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"), Or = "Su_Mo_Tu_We_Th_Fr_Sa".split("_"), Wr = Se, jr = Se, Pr = Se;
        function Rr(e, t) {
          var s = M(this._weekdays) ? this._weekdays : this._weekdays[e && e !== true && this._weekdays.isFormat.test(t) ? "format" : "standalone"];
          return e === true ? wt(s, this._week.dow) : e ? s[e.day()] : s;
        }
        function Hr(e) {
          return e === true ? wt(this._weekdaysShort, this._week.dow) : e ? this._weekdaysShort[e.day()] : this._weekdaysShort;
        }
        function Fr(e) {
          return e === true ? wt(this._weekdaysMin, this._week.dow) : e ? this._weekdaysMin[e.day()] : this._weekdaysMin;
        }
        function Nr(e, t, s) {
          var r, a, i, o = e.toLocaleLowerCase();
          if (!this._weekdaysParse) for (this._weekdaysParse = [], this._shortWeekdaysParse = [], this._minWeekdaysParse = [], r = 0; r < 7; ++r) i = U([
            2e3,
            1
          ]).day(r), this._minWeekdaysParse[r] = this.weekdaysMin(i, "").toLocaleLowerCase(), this._shortWeekdaysParse[r] = this.weekdaysShort(i, "").toLocaleLowerCase(), this._weekdaysParse[r] = this.weekdays(i, "").toLocaleLowerCase();
          return s ? t === "dddd" ? (a = P.call(this._weekdaysParse, o), a !== -1 ? a : null) : t === "ddd" ? (a = P.call(this._shortWeekdaysParse, o), a !== -1 ? a : null) : (a = P.call(this._minWeekdaysParse, o), a !== -1 ? a : null) : t === "dddd" ? (a = P.call(this._weekdaysParse, o), a !== -1 || (a = P.call(this._shortWeekdaysParse, o), a !== -1) ? a : (a = P.call(this._minWeekdaysParse, o), a !== -1 ? a : null)) : t === "ddd" ? (a = P.call(this._shortWeekdaysParse, o), a !== -1 || (a = P.call(this._weekdaysParse, o), a !== -1) ? a : (a = P.call(this._minWeekdaysParse, o), a !== -1 ? a : null)) : (a = P.call(this._minWeekdaysParse, o), a !== -1 || (a = P.call(this._weekdaysParse, o), a !== -1) ? a : (a = P.call(this._shortWeekdaysParse, o), a !== -1 ? a : null));
        }
        function Cr(e, t, s) {
          var r, a, i;
          if (this._weekdaysParseExact) return Nr.call(this, e, t, s);
          for (this._weekdaysParse || (this._weekdaysParse = [], this._minWeekdaysParse = [], this._shortWeekdaysParse = [], this._fullWeekdaysParse = []), r = 0; r < 7; r++) {
            if (a = U([
              2e3,
              1
            ]).day(r), s && !this._fullWeekdaysParse[r] && (this._fullWeekdaysParse[r] = new RegExp("^" + this.weekdays(a, "").replace(".", "\\.?") + "$", "i"), this._shortWeekdaysParse[r] = new RegExp("^" + this.weekdaysShort(a, "").replace(".", "\\.?") + "$", "i"), this._minWeekdaysParse[r] = new RegExp("^" + this.weekdaysMin(a, "").replace(".", "\\.?") + "$", "i")), this._weekdaysParse[r] || (i = "^" + this.weekdays(a, "") + "|^" + this.weekdaysShort(a, "") + "|^" + this.weekdaysMin(a, ""), this._weekdaysParse[r] = new RegExp(i.replace(".", ""), "i")), s && t === "dddd" && this._fullWeekdaysParse[r].test(e)) return r;
            if (s && t === "ddd" && this._shortWeekdaysParse[r].test(e)) return r;
            if (s && t === "dd" && this._minWeekdaysParse[r].test(e)) return r;
            if (!s && this._weekdaysParse[r].test(e)) return r;
          }
        }
        function zr(e) {
          if (!this.isValid()) return e != null ? this : NaN;
          var t = Te(this, "Day");
          return e != null ? (e = Lr(e, this.localeData()), this.add(e - t, "d")) : t;
        }
        function Ir(e) {
          if (!this.isValid()) return e != null ? this : NaN;
          var t = (this.day() + 7 - this.localeData()._week.dow) % 7;
          return e == null ? t : this.add(e - t, "d");
        }
        function Ar(e) {
          if (!this.isValid()) return e != null ? this : NaN;
          if (e != null) {
            var t = Tr(e, this.localeData());
            return this.day(this.day() % 7 ? t : t - 7);
          } else return this.day() || 7;
        }
        function Ur(e) {
          return this._weekdaysParseExact ? (u(this, "_weekdaysRegex") || Mt.call(this), e ? this._weekdaysStrictRegex : this._weekdaysRegex) : (u(this, "_weekdaysRegex") || (this._weekdaysRegex = Wr), this._weekdaysStrictRegex && e ? this._weekdaysStrictRegex : this._weekdaysRegex);
        }
        function Er(e) {
          return this._weekdaysParseExact ? (u(this, "_weekdaysRegex") || Mt.call(this), e ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex) : (u(this, "_weekdaysShortRegex") || (this._weekdaysShortRegex = jr), this._weekdaysShortStrictRegex && e ? this._weekdaysShortStrictRegex : this._weekdaysShortRegex);
        }
        function $r(e) {
          return this._weekdaysParseExact ? (u(this, "_weekdaysRegex") || Mt.call(this), e ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex) : (u(this, "_weekdaysMinRegex") || (this._weekdaysMinRegex = Pr), this._weekdaysMinStrictRegex && e ? this._weekdaysMinStrictRegex : this._weekdaysMinRegex);
        }
        function Mt() {
          function e(z, le) {
            return le.length - z.length;
          }
          var t = [], s = [], r = [], a = [], i, o, _, v, S;
          for (i = 0; i < 7; i++) o = U([
            2e3,
            1
          ]).day(i), _ = ee(this.weekdaysMin(o, "")), v = ee(this.weekdaysShort(o, "")), S = ee(this.weekdays(o, "")), t.push(_), s.push(v), r.push(S), a.push(_), a.push(v), a.push(S);
          t.sort(e), s.sort(e), r.sort(e), a.sort(e), this._weekdaysRegex = new RegExp("^(" + a.join("|") + ")", "i"), this._weekdaysShortRegex = this._weekdaysRegex, this._weekdaysMinRegex = this._weekdaysRegex, this._weekdaysStrictRegex = new RegExp("^(" + r.join("|") + ")", "i"), this._weekdaysShortStrictRegex = new RegExp("^(" + s.join("|") + ")", "i"), this._weekdaysMinStrictRegex = new RegExp("^(" + t.join("|") + ")", "i");
        }
        function gt() {
          return this.hours() % 12 || 12;
        }
        function Vr() {
          return this.hours() || 24;
        }
        g("H", [
          "HH",
          2
        ], 0, "hour"), g("h", [
          "hh",
          2
        ], 0, gt), g("k", [
          "kk",
          2
        ], 0, Vr), g("hmm", 0, 0, function() {
          return "" + gt.apply(this) + Q(this.minutes(), 2);
        }), g("hmmss", 0, 0, function() {
          return "" + gt.apply(this) + Q(this.minutes(), 2) + Q(this.seconds(), 2);
        }), g("Hmm", 0, 0, function() {
          return "" + this.hours() + Q(this.minutes(), 2);
        }), g("Hmmss", 0, 0, function() {
          return "" + this.hours() + Q(this.minutes(), 2) + Q(this.seconds(), 2);
        });
        function es(e, t) {
          g(e, 0, 0, function() {
            return this.localeData().meridiem(this.hours(), this.minutes(), t);
          });
        }
        es("a", true), es("A", false);
        function ts(e, t) {
          return t._meridiemParse;
        }
        m("a", ts), m("A", ts), m("H", b, _t), m("h", b, we), m("k", b, we), m("HH", b, A), m("hh", b, A), m("kk", b, A), m("hmm", Et), m("hmmss", $t), m("Hmm", Et), m("Hmmss", $t), T([
          "H",
          "HH"
        ], R), T([
          "k",
          "kk"
        ], function(e, t, s) {
          var r = Y(e);
          t[R] = r === 24 ? 0 : r;
        }), T([
          "a",
          "A"
        ], function(e, t, s) {
          s._isPm = s._locale.isPM(e), s._meridiem = e;
        }), T([
          "h",
          "hh"
        ], function(e, t, s) {
          t[R] = Y(e), k(s).bigHour = true;
        }), T("hmm", function(e, t, s) {
          var r = e.length - 2;
          t[R] = Y(e.substr(0, r)), t[B] = Y(e.substr(r)), k(s).bigHour = true;
        }), T("hmmss", function(e, t, s) {
          var r = e.length - 4, a = e.length - 2;
          t[R] = Y(e.substr(0, r)), t[B] = Y(e.substr(r, 2)), t[se] = Y(e.substr(a)), k(s).bigHour = true;
        }), T("Hmm", function(e, t, s) {
          var r = e.length - 2;
          t[R] = Y(e.substr(0, r)), t[B] = Y(e.substr(r));
        }), T("Hmmss", function(e, t, s) {
          var r = e.length - 4, a = e.length - 2;
          t[R] = Y(e.substr(0, r)), t[B] = Y(e.substr(r, 2)), t[se] = Y(e.substr(a));
        });
        function Gr(e) {
          return (e + "").toLowerCase().charAt(0) === "p";
        }
        var Br = /[ap]\.?m?\.?/i, Zr = Me("Hours", true);
        function qr(e, t, s) {
          return e > 11 ? s ? "pm" : "PM" : s ? "am" : "AM";
        }
        var ss = {
          calendar: Ns,
          longDateFormat: As,
          invalidDate: Es,
          ordinal: Vs,
          dayOfMonthOrdinalParse: Gs,
          relativeTime: Zs,
          months: ur,
          monthsShort: Bt,
          week: kr,
          weekdays: br,
          weekdaysMin: Or,
          weekdaysShort: Kt,
          meridiemParse: Br
        }, W = {}, We = {}, je;
        function Jr(e, t) {
          var s, r = Math.min(e.length, t.length);
          for (s = 0; s < r; s += 1) if (e[s] !== t[s]) return s;
          return r;
        }
        function rs(e) {
          return e && e.toLowerCase().replace("_", "-");
        }
        function Qr(e) {
          for (var t = 0, s, r, a, i; t < e.length; ) {
            for (i = rs(e[t]).split("-"), s = i.length, r = rs(e[t + 1]), r = r ? r.split("-") : null; s > 0; ) {
              if (a = Ve(i.slice(0, s).join("-")), a) return a;
              if (r && r.length >= s && Jr(i, r) >= s - 1) break;
              s--;
            }
            t++;
          }
          return je;
        }
        function Xr(e) {
          return !!(e && e.match("^[^/\\\\]*$"));
        }
        function Ve(e) {
          var t = null, s;
          if (W[e] === void 0 && j && j.exports && Xr(e)) try {
            t = je._abbr, s = q, s("./locale/" + e), de(t);
          } catch {
            W[e] = null;
          }
          return W[e];
        }
        function de(e, t) {
          var s;
          return e && (f(t) ? s = ae(e) : s = pt(e, t), s ? je = s : typeof console < "u" && console.warn && console.warn("Locale " + e + " not found. Did you forget to load it?")), je._abbr;
        }
        function pt(e, t) {
          if (t !== null) {
            var s, r = ss;
            if (t.abbr = e, W[e] != null) Ct("defineLocaleOverride", "use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info."), r = W[e]._config;
            else if (t.parentLocale != null) if (W[t.parentLocale] != null) r = W[t.parentLocale]._config;
            else if (s = Ve(t.parentLocale), s != null) r = s._config;
            else return We[t.parentLocale] || (We[t.parentLocale] = []), We[t.parentLocale].push({
              name: e,
              config: t
            }), null;
            return W[e] = new ot(nt(r, t)), We[e] && We[e].forEach(function(a) {
              pt(a.name, a.config);
            }), de(e), W[e];
          } else return delete W[e], null;
        }
        function Kr(e, t) {
          if (t != null) {
            var s, r, a = ss;
            W[e] != null && W[e].parentLocale != null ? W[e].set(nt(W[e]._config, t)) : (r = Ve(e), r != null && (a = r._config), t = nt(a, t), r == null && (t.abbr = e), s = new ot(t), s.parentLocale = W[e], W[e] = s), de(e);
          } else W[e] != null && (W[e].parentLocale != null ? (W[e] = W[e].parentLocale, e === de() && de(e)) : W[e] != null && delete W[e]);
          return W[e];
        }
        function ae(e) {
          var t;
          if (e && e._locale && e._locale._abbr && (e = e._locale._abbr), !e) return je;
          if (!M(e)) {
            if (t = Ve(e), t) return t;
            e = [
              e
            ];
          }
          return Qr(e);
        }
        function ea() {
          return lt(W);
        }
        function vt(e) {
          var t, s = e._a;
          return s && k(e).overflow === -2 && (t = s[te] < 0 || s[te] > 11 ? te : s[X] < 1 || s[X] > yt(s[N], s[te]) ? X : s[R] < 0 || s[R] > 24 || s[R] === 24 && (s[B] !== 0 || s[se] !== 0 || s[ce] !== 0) ? R : s[B] < 0 || s[B] > 59 ? B : s[se] < 0 || s[se] > 59 ? se : s[ce] < 0 || s[ce] > 999 ? ce : -1, k(e)._overflowDayOfYear && (t < N || t > X) && (t = X), k(e)._overflowWeeks && t === -1 && (t = ar), k(e)._overflowWeekday && t === -1 && (t = ir), k(e).overflow = t), e;
        }
        var ta = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/, sa = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d|))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/, ra = /Z|[+-]\d\d(?::?\d\d)?/, Ge = [
          [
            "YYYYYY-MM-DD",
            /[+-]\d{6}-\d\d-\d\d/
          ],
          [
            "YYYY-MM-DD",
            /\d{4}-\d\d-\d\d/
          ],
          [
            "GGGG-[W]WW-E",
            /\d{4}-W\d\d-\d/
          ],
          [
            "GGGG-[W]WW",
            /\d{4}-W\d\d/,
            false
          ],
          [
            "YYYY-DDD",
            /\d{4}-\d{3}/
          ],
          [
            "YYYY-MM",
            /\d{4}-\d\d/,
            false
          ],
          [
            "YYYYYYMMDD",
            /[+-]\d{10}/
          ],
          [
            "YYYYMMDD",
            /\d{8}/
          ],
          [
            "GGGG[W]WWE",
            /\d{4}W\d{3}/
          ],
          [
            "GGGG[W]WW",
            /\d{4}W\d{2}/,
            false
          ],
          [
            "YYYYDDD",
            /\d{7}/
          ],
          [
            "YYYYMM",
            /\d{6}/,
            false
          ],
          [
            "YYYY",
            /\d{4}/,
            false
          ]
        ], kt = [
          [
            "HH:mm:ss.SSSS",
            /\d\d:\d\d:\d\d\.\d+/
          ],
          [
            "HH:mm:ss,SSSS",
            /\d\d:\d\d:\d\d,\d+/
          ],
          [
            "HH:mm:ss",
            /\d\d:\d\d:\d\d/
          ],
          [
            "HH:mm",
            /\d\d:\d\d/
          ],
          [
            "HHmmss.SSSS",
            /\d\d\d\d\d\d\.\d+/
          ],
          [
            "HHmmss,SSSS",
            /\d\d\d\d\d\d,\d+/
          ],
          [
            "HHmmss",
            /\d\d\d\d\d\d/
          ],
          [
            "HHmm",
            /\d\d\d\d/
          ],
          [
            "HH",
            /\d\d/
          ]
        ], aa = /^\/?Date\((-?\d+)/i, ia = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|([+-]\d{4}))$/, na = {
          UT: 0,
          GMT: 0,
          EDT: -240,
          EST: -300,
          CDT: -300,
          CST: -360,
          MDT: -360,
          MST: -420,
          PDT: -420,
          PST: -480
        };
        function as(e) {
          var t, s, r = e._i, a = ta.exec(r) || sa.exec(r), i, o, _, v, S = Ge.length, z = kt.length;
          if (a) {
            for (k(e).iso = true, t = 0, s = S; t < s; t++) if (Ge[t][1].exec(a[1])) {
              o = Ge[t][0], i = Ge[t][2] !== false;
              break;
            }
            if (o == null) {
              e._isValid = false;
              return;
            }
            if (a[3]) {
              for (t = 0, s = z; t < s; t++) if (kt[t][1].exec(a[3])) {
                _ = (a[2] || " ") + kt[t][0];
                break;
              }
              if (_ == null) {
                e._isValid = false;
                return;
              }
            }
            if (!i && _ != null) {
              e._isValid = false;
              return;
            }
            if (a[4]) if (ra.exec(a[4])) v = "Z";
            else {
              e._isValid = false;
              return;
            }
            e._f = o + (_ || "") + (v || ""), Yt(e);
          } else e._isValid = false;
        }
        function oa(e, t, s, r, a, i) {
          var o = [
            la(e),
            Bt.indexOf(t),
            parseInt(s, 10),
            parseInt(r, 10),
            parseInt(a, 10)
          ];
          return i && o.push(parseInt(i, 10)), o;
        }
        function la(e) {
          var t = parseInt(e, 10);
          return t <= 49 ? 2e3 + t : t <= 999 ? 1900 + t : t;
        }
        function da(e) {
          return e.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").replace(/^\s\s*/, "").replace(/\s\s*$/, "");
        }
        function ua(e, t, s) {
          if (e) {
            var r = Kt.indexOf(e), a = new Date(t[0], t[1], t[2]).getDay();
            if (r !== a) return k(s).weekdayMismatch = true, s._isValid = false, false;
          }
          return true;
        }
        function ha(e, t, s) {
          if (e) return na[e];
          if (t) return 0;
          var r = parseInt(s, 10), a = r % 100, i = (r - a) / 100;
          return i * 60 + a;
        }
        function is(e) {
          var t = ia.exec(da(e._i)), s;
          if (t) {
            if (s = oa(t[4], t[3], t[2], t[5], t[6], t[7]), !ua(t[1], s, e)) return;
            e._a = s, e._tzm = ha(t[8], t[9], t[10]), e._d = be.apply(null, e._a), e._d.setUTCMinutes(e._d.getUTCMinutes() - e._tzm), k(e).rfc2822 = true;
          } else e._isValid = false;
        }
        function ca(e) {
          var t = aa.exec(e._i);
          if (t !== null) {
            e._d = /* @__PURE__ */ new Date(+t[1]);
            return;
          }
          if (as(e), e._isValid === false) delete e._isValid;
          else return;
          if (is(e), e._isValid === false) delete e._isValid;
          else return;
          e._strict ? e._isValid = false : n.createFromInputFallback(e);
        }
        n.createFromInputFallback = E("value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.", function(e) {
          e._d = /* @__PURE__ */ new Date(e._i + (e._useUTC ? " UTC" : ""));
        });
        function ge(e, t, s) {
          return e ?? t ?? s;
        }
        function fa(e) {
          var t = new Date(n.now());
          return e._useUTC ? [
            t.getUTCFullYear(),
            t.getUTCMonth(),
            t.getUTCDate()
          ] : [
            t.getFullYear(),
            t.getMonth(),
            t.getDate()
          ];
        }
        function Dt(e) {
          var t, s, r = [], a, i, o;
          if (!e._d) {
            for (a = fa(e), e._w && e._a[X] == null && e._a[te] == null && _a(e), e._dayOfYear != null && (o = ge(e._a[N], a[N]), (e._dayOfYear > Le(o) || e._dayOfYear === 0) && (k(e)._overflowDayOfYear = true), s = be(o, 0, e._dayOfYear), e._a[te] = s.getUTCMonth(), e._a[X] = s.getUTCDate()), t = 0; t < 3 && e._a[t] == null; ++t) e._a[t] = r[t] = a[t];
            for (; t < 7; t++) e._a[t] = r[t] = e._a[t] == null ? t === 2 ? 1 : 0 : e._a[t];
            e._a[R] === 24 && e._a[B] === 0 && e._a[se] === 0 && e._a[ce] === 0 && (e._nextDay = true, e._a[R] = 0), e._d = (e._useUTC ? be : pr).apply(null, r), i = e._useUTC ? e._d.getUTCDay() : e._d.getDay(), e._tzm != null && e._d.setUTCMinutes(e._d.getUTCMinutes() - e._tzm), e._nextDay && (e._a[R] = 24), e._w && typeof e._w.d < "u" && e._w.d !== i && (k(e).weekdayMismatch = true);
          }
        }
        function _a(e) {
          var t, s, r, a, i, o, _, v, S;
          t = e._w, t.GG != null || t.W != null || t.E != null ? (i = 1, o = 4, s = ge(t.GG, e._a[N], Oe(O(), 1, 4).year), r = ge(t.W, 1), a = ge(t.E, 1), (a < 1 || a > 7) && (v = true)) : (i = e._locale._week.dow, o = e._locale._week.doy, S = Oe(O(), i, o), s = ge(t.gg, e._a[N], S.year), r = ge(t.w, S.week), t.d != null ? (a = t.d, (a < 0 || a > 6) && (v = true)) : t.e != null ? (a = t.e + i, (t.e < 0 || t.e > 6) && (v = true)) : a = i), r < 1 || r > re(s, i, o) ? k(e)._overflowWeeks = true : v != null ? k(e)._overflowWeekday = true : (_ = Xt(s, r, a, i, o), e._a[N] = _.year, e._dayOfYear = _.dayOfYear);
        }
        n.ISO_8601 = function() {
        }, n.RFC_2822 = function() {
        };
        function Yt(e) {
          if (e._f === n.ISO_8601) {
            as(e);
            return;
          }
          if (e._f === n.RFC_2822) {
            is(e);
            return;
          }
          e._a = [], k(e).empty = true;
          var t = "" + e._i, s, r, a, i, o, _ = t.length, v = 0, S, z;
          for (a = zt(e._f, e._locale).match(dt) || [], z = a.length, s = 0; s < z; s++) i = a[s], r = (t.match(tr(i, e)) || [])[0], r && (o = t.substr(0, t.indexOf(r)), o.length > 0 && k(e).unusedInput.push(o), t = t.slice(t.indexOf(r) + r.length), v += r.length), me[i] ? (r ? k(e).empty = false : k(e).unusedTokens.push(i), rr(i, r, e)) : e._strict && !r && k(e).unusedTokens.push(i);
          k(e).charsLeftOver = _ - v, t.length > 0 && k(e).unusedInput.push(t), e._a[R] <= 12 && k(e).bigHour === true && e._a[R] > 0 && (k(e).bigHour = void 0), k(e).parsedDateParts = e._a.slice(0), k(e).meridiem = e._meridiem, e._a[R] = ma(e._locale, e._a[R], e._meridiem), S = k(e).era, S !== null && (e._a[N] = e._locale.erasConvertYear(S, e._a[N])), Dt(e), vt(e);
        }
        function ma(e, t, s) {
          var r;
          return s == null ? t : e.meridiemHour != null ? e.meridiemHour(t, s) : (e.isPM != null && (r = e.isPM(s), r && t < 12 && (t += 12), !r && t === 12 && (t = 0)), t);
        }
        function ya(e) {
          var t, s, r, a, i, o, _ = false, v = e._f.length;
          if (v === 0) {
            k(e).invalidFormat = true, e._d = /* @__PURE__ */ new Date(NaN);
            return;
          }
          for (a = 0; a < v; a++) i = 0, o = false, t = it({}, e), e._useUTC != null && (t._useUTC = e._useUTC), t._f = e._f[a], Yt(t), rt(t) && (o = true), i += k(t).charsLeftOver, i += k(t).unusedTokens.length * 10, k(t).score = i, _ ? i < r && (r = i, s = t) : (r == null || i < r || o) && (r = i, s = t, o && (_ = true));
          I(e, s || t);
        }
        function wa(e) {
          if (!e._d) {
            var t = ht(e._i), s = t.day === void 0 ? t.date : t.day;
            e._a = C([
              t.year,
              t.month,
              s,
              t.hour,
              t.minute,
              t.second,
              t.millisecond
            ], function(r) {
              return r && parseInt(r, 10);
            }), Dt(e);
          }
        }
        function Ma(e) {
          var t = new Ye(vt(ns(e)));
          return t._nextDay && (t.add(1, "d"), t._nextDay = void 0), t;
        }
        function ns(e) {
          var t = e._i, s = e._f;
          return e._locale = e._locale || ae(e._l), t === null || s === void 0 && t === "" ? Re({
            nullInput: true
          }) : (typeof t == "string" && (e._i = t = e._locale.preparse(t)), G(t) ? new Ye(vt(t)) : (H(t) ? e._d = t : M(s) ? ya(e) : s ? Yt(e) : ga(e), rt(e) || (e._d = null), e));
        }
        function ga(e) {
          var t = e._i;
          f(t) ? e._d = new Date(n.now()) : H(t) ? e._d = new Date(t.valueOf()) : typeof t == "string" ? ca(e) : M(t) ? (e._a = C(t.slice(0), function(s) {
            return parseInt(s, 10);
          }), Dt(e)) : p(t) ? wa(e) : D(t) ? e._d = new Date(t) : n.createFromInputFallback(e);
        }
        function os(e, t, s, r, a) {
          var i = {};
          return (t === true || t === false) && (r = t, t = void 0), (s === true || s === false) && (r = s, s = void 0), (p(e) && c(e) || M(e) && e.length === 0) && (e = void 0), i._isAMomentObject = true, i._useUTC = i._isUTC = a, i._l = s, i._i = e, i._f = t, i._strict = r, Ma(i);
        }
        function O(e, t, s, r) {
          return os(e, t, s, r, false);
        }
        var pa = E("moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/", function() {
          var e = O.apply(null, arguments);
          return this.isValid() && e.isValid() ? e < this ? this : e : Re();
        }), va = E("moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/", function() {
          var e = O.apply(null, arguments);
          return this.isValid() && e.isValid() ? e > this ? this : e : Re();
        });
        function ls(e, t) {
          var s, r;
          if (t.length === 1 && M(t[0]) && (t = t[0]), !t.length) return O();
          for (s = t[0], r = 1; r < t.length; ++r) (!t[r].isValid() || t[r][e](s)) && (s = t[r]);
          return s;
        }
        function ka() {
          var e = [].slice.call(arguments, 0);
          return ls("isBefore", e);
        }
        function Da() {
          var e = [].slice.call(arguments, 0);
          return ls("isAfter", e);
        }
        var Ya = function() {
          return Date.now ? Date.now() : +/* @__PURE__ */ new Date();
        }, Pe = [
          "year",
          "quarter",
          "month",
          "week",
          "day",
          "hour",
          "minute",
          "second",
          "millisecond"
        ];
        function Sa(e) {
          var t, s = false, r, a = Pe.length;
          for (t in e) if (u(e, t) && !(P.call(Pe, t) !== -1 && (e[t] == null || !isNaN(e[t])))) return false;
          for (r = 0; r < a; ++r) if (e[Pe[r]]) {
            if (s) return false;
            parseFloat(e[Pe[r]]) !== Y(e[Pe[r]]) && (s = true);
          }
          return true;
        }
        function xa() {
          return this._isValid;
        }
        function La() {
          return Z(NaN);
        }
        function Be(e) {
          var t = ht(e), s = t.year || 0, r = t.quarter || 0, a = t.month || 0, i = t.week || t.isoWeek || 0, o = t.day || 0, _ = t.hour || 0, v = t.minute || 0, S = t.second || 0, z = t.millisecond || 0;
          this._isValid = Sa(t), this._milliseconds = +z + S * 1e3 + v * 6e4 + _ * 1e3 * 60 * 60, this._days = +o + i * 7, this._months = +a + r * 3 + s * 12, this._data = {}, this._locale = ae(), this._bubble();
        }
        function Ze(e) {
          return e instanceof Be;
        }
        function St(e) {
          return e < 0 ? Math.round(-1 * e) * -1 : Math.round(e);
        }
        function Ta(e, t, s) {
          var r = Math.min(e.length, t.length), a = Math.abs(e.length - t.length), i = 0, o;
          for (o = 0; o < r; o++) Y(e[o]) !== Y(t[o]) && i++;
          return i + a;
        }
        function ds(e, t) {
          g(e, 0, 0, function() {
            var s = this.utcOffset(), r = "+";
            return s < 0 && (s = -s, r = "-"), r + Q(~~(s / 60), 2) + t + Q(~~s % 60, 2);
          });
        }
        ds("Z", ":"), ds("ZZ", ""), m("Z", Ae), m("ZZ", Ae), T([
          "Z",
          "ZZ"
        ], function(e, t, s) {
          s._useUTC = true, s._tzm = xt(Ae, e);
        });
        var ba = /([\+\-]|\d\d)/gi;
        function xt(e, t) {
          var s = (t || "").match(e), r, a, i;
          return s === null ? null : (r = s[s.length - 1] || [], a = (r + "").match(ba) || [
            "-",
            0,
            0
          ], i = +(a[1] * 60) + Y(a[2]), i === 0 ? 0 : a[0] === "+" ? i : -i);
        }
        function Lt(e, t) {
          var s, r;
          return t._isUTC ? (s = t.clone(), r = (G(e) || H(e) ? e.valueOf() : O(e).valueOf()) - s.valueOf(), s._d.setTime(s._d.valueOf() + r), n.updateOffset(s, false), s) : O(e).local();
        }
        function Tt(e) {
          return -Math.round(e._d.getTimezoneOffset());
        }
        n.updateOffset = function() {
        };
        function Oa(e, t, s) {
          var r = this._offset || 0, a;
          if (!this.isValid()) return e != null ? this : NaN;
          if (e != null) {
            if (typeof e == "string") {
              if (e = xt(Ae, e), e === null) return this;
            } else Math.abs(e) < 16 && !s && (e = e * 60);
            return !this._isUTC && t && (a = Tt(this)), this._offset = e, this._isUTC = true, a != null && this.add(a, "m"), r !== e && (!t || this._changeInProgress ? fs(this, Z(e - r, "m"), 1, false) : this._changeInProgress || (this._changeInProgress = true, n.updateOffset(this, true), this._changeInProgress = null)), this;
          } else return this._isUTC ? r : Tt(this);
        }
        function Wa(e, t) {
          return e != null ? (typeof e != "string" && (e = -e), this.utcOffset(e, t), this) : -this.utcOffset();
        }
        function ja(e) {
          return this.utcOffset(0, e);
        }
        function Pa(e) {
          return this._isUTC && (this.utcOffset(0, e), this._isUTC = false, e && this.subtract(Tt(this), "m")), this;
        }
        function Ra() {
          if (this._tzm != null) this.utcOffset(this._tzm, false, true);
          else if (typeof this._i == "string") {
            var e = xt(Ks, this._i);
            e != null ? this.utcOffset(e) : this.utcOffset(0, true);
          }
          return this;
        }
        function Ha(e) {
          return this.isValid() ? (e = e ? O(e).utcOffset() : 0, (this.utcOffset() - e) % 60 === 0) : false;
        }
        function Fa() {
          return this.utcOffset() > this.clone().month(0).utcOffset() || this.utcOffset() > this.clone().month(5).utcOffset();
        }
        function Na() {
          if (!f(this._isDSTShifted)) return this._isDSTShifted;
          var e = {}, t;
          return it(e, this), e = ns(e), e._a ? (t = e._isUTC ? U(e._a) : O(e._a), this._isDSTShifted = this.isValid() && Ta(e._a, t.toArray()) > 0) : this._isDSTShifted = false, this._isDSTShifted;
        }
        function Ca() {
          return this.isValid() ? !this._isUTC : false;
        }
        function za() {
          return this.isValid() ? this._isUTC : false;
        }
        function us() {
          return this.isValid() ? this._isUTC && this._offset === 0 : false;
        }
        var Ia = /^(-|\+)?(?:(\d*)[. ])?(\d+):(\d+)(?::(\d+)(\.\d*)?)?$/, Aa = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;
        function Z(e, t) {
          var s = e, r = null, a, i, o;
          return Ze(e) ? s = {
            ms: e._milliseconds,
            d: e._days,
            M: e._months
          } : D(e) || !isNaN(+e) ? (s = {}, t ? s[t] = +e : s.milliseconds = +e) : (r = Ia.exec(e)) ? (a = r[1] === "-" ? -1 : 1, s = {
            y: 0,
            d: Y(r[X]) * a,
            h: Y(r[R]) * a,
            m: Y(r[B]) * a,
            s: Y(r[se]) * a,
            ms: Y(St(r[ce] * 1e3)) * a
          }) : (r = Aa.exec(e)) ? (a = r[1] === "-" ? -1 : 1, s = {
            y: fe(r[2], a),
            M: fe(r[3], a),
            w: fe(r[4], a),
            d: fe(r[5], a),
            h: fe(r[6], a),
            m: fe(r[7], a),
            s: fe(r[8], a)
          }) : s == null ? s = {} : typeof s == "object" && ("from" in s || "to" in s) && (o = Ua(O(s.from), O(s.to)), s = {}, s.ms = o.milliseconds, s.M = o.months), i = new Be(s), Ze(e) && u(e, "_locale") && (i._locale = e._locale), Ze(e) && u(e, "_isValid") && (i._isValid = e._isValid), i;
        }
        Z.fn = Be.prototype, Z.invalid = La;
        function fe(e, t) {
          var s = e && parseFloat(e.replace(",", "."));
          return (isNaN(s) ? 0 : s) * t;
        }
        function hs(e, t) {
          var s = {};
          return s.months = t.month() - e.month() + (t.year() - e.year()) * 12, e.clone().add(s.months, "M").isAfter(t) && --s.months, s.milliseconds = +t - +e.clone().add(s.months, "M"), s;
        }
        function Ua(e, t) {
          var s;
          return e.isValid() && t.isValid() ? (t = Lt(t, e), e.isBefore(t) ? s = hs(e, t) : (s = hs(t, e), s.milliseconds = -s.milliseconds, s.months = -s.months), s) : {
            milliseconds: 0,
            months: 0
          };
        }
        function cs(e, t) {
          return function(s, r) {
            var a, i;
            return r !== null && !isNaN(+r) && (Ct(t, "moment()." + t + "(period, number) is deprecated. Please use moment()." + t + "(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info."), i = s, s = r, r = i), a = Z(s, r), fs(this, a, e), this;
          };
        }
        function fs(e, t, s, r) {
          var a = t._milliseconds, i = St(t._days), o = St(t._months);
          e.isValid() && (r = r ?? true, o && qt(e, Te(e, "Month") + o * s), i && Gt(e, "Date", Te(e, "Date") + i * s), a && e._d.setTime(e._d.valueOf() + a * s), r && n.updateOffset(e, i || o));
        }
        var Ea = cs(1, "add"), $a = cs(-1, "subtract");
        function _s(e) {
          return typeof e == "string" || e instanceof String;
        }
        function Va(e) {
          return G(e) || H(e) || _s(e) || D(e) || Ba(e) || Ga(e) || e === null || e === void 0;
        }
        function Ga(e) {
          var t = p(e) && !c(e), s = false, r = [
            "years",
            "year",
            "y",
            "months",
            "month",
            "M",
            "days",
            "day",
            "d",
            "dates",
            "date",
            "D",
            "hours",
            "hour",
            "h",
            "minutes",
            "minute",
            "m",
            "seconds",
            "second",
            "s",
            "milliseconds",
            "millisecond",
            "ms"
          ], a, i, o = r.length;
          for (a = 0; a < o; a += 1) i = r[a], s = s || u(e, i);
          return t && s;
        }
        function Ba(e) {
          var t = M(e), s = false;
          return t && (s = e.filter(function(r) {
            return !D(r) && _s(e);
          }).length === 0), t && s;
        }
        function Za(e) {
          var t = p(e) && !c(e), s = false, r = [
            "sameDay",
            "nextDay",
            "lastDay",
            "nextWeek",
            "lastWeek",
            "sameElse"
          ], a, i;
          for (a = 0; a < r.length; a += 1) i = r[a], s = s || u(e, i);
          return t && s;
        }
        function qa(e, t) {
          var s = e.diff(t, "days", true);
          return s < -6 ? "sameElse" : s < -1 ? "lastWeek" : s < 0 ? "lastDay" : s < 1 ? "sameDay" : s < 2 ? "nextDay" : s < 7 ? "nextWeek" : "sameElse";
        }
        function Ja(e, t) {
          arguments.length === 1 && (arguments[0] ? Va(arguments[0]) ? (e = arguments[0], t = void 0) : Za(arguments[0]) && (t = arguments[0], e = void 0) : (e = void 0, t = void 0));
          var s = e || O(), r = Lt(s, this).startOf("day"), a = n.calendarFormat(this, r) || "sameElse", i = t && (J(t[a]) ? t[a].call(this, s) : t[a]);
          return this.format(i || this.localeData().calendar(a, this, O(s)));
        }
        function Qa() {
          return new Ye(this);
        }
        function Xa(e, t) {
          var s = G(e) ? e : O(e);
          return this.isValid() && s.isValid() ? (t = $(t) || "millisecond", t === "millisecond" ? this.valueOf() > s.valueOf() : s.valueOf() < this.clone().startOf(t).valueOf()) : false;
        }
        function Ka(e, t) {
          var s = G(e) ? e : O(e);
          return this.isValid() && s.isValid() ? (t = $(t) || "millisecond", t === "millisecond" ? this.valueOf() < s.valueOf() : this.clone().endOf(t).valueOf() < s.valueOf()) : false;
        }
        function ei(e, t, s, r) {
          var a = G(e) ? e : O(e), i = G(t) ? t : O(t);
          return this.isValid() && a.isValid() && i.isValid() ? (r = r || "()", (r[0] === "(" ? this.isAfter(a, s) : !this.isBefore(a, s)) && (r[1] === ")" ? this.isBefore(i, s) : !this.isAfter(i, s))) : false;
        }
        function ti(e, t) {
          var s = G(e) ? e : O(e), r;
          return this.isValid() && s.isValid() ? (t = $(t) || "millisecond", t === "millisecond" ? this.valueOf() === s.valueOf() : (r = s.valueOf(), this.clone().startOf(t).valueOf() <= r && r <= this.clone().endOf(t).valueOf())) : false;
        }
        function si(e, t) {
          return this.isSame(e, t) || this.isAfter(e, t);
        }
        function ri(e, t) {
          return this.isSame(e, t) || this.isBefore(e, t);
        }
        function ai(e, t, s) {
          var r, a, i;
          if (!this.isValid()) return NaN;
          if (r = Lt(e, this), !r.isValid()) return NaN;
          switch (a = (r.utcOffset() - this.utcOffset()) * 6e4, t = $(t), t) {
            case "year":
              i = qe(this, r) / 12;
              break;
            case "month":
              i = qe(this, r);
              break;
            case "quarter":
              i = qe(this, r) / 3;
              break;
            case "second":
              i = (this - r) / 1e3;
              break;
            case "minute":
              i = (this - r) / 6e4;
              break;
            case "hour":
              i = (this - r) / 36e5;
              break;
            case "day":
              i = (this - r - a) / 864e5;
              break;
            case "week":
              i = (this - r - a) / 6048e5;
              break;
            default:
              i = this - r;
          }
          return s ? i : V(i);
        }
        function qe(e, t) {
          if (e.date() < t.date()) return -qe(t, e);
          var s = (t.year() - e.year()) * 12 + (t.month() - e.month()), r = e.clone().add(s, "months"), a, i;
          return t - r < 0 ? (a = e.clone().add(s - 1, "months"), i = (t - r) / (r - a)) : (a = e.clone().add(s + 1, "months"), i = (t - r) / (a - r)), -(s + i) || 0;
        }
        n.defaultFormat = "YYYY-MM-DDTHH:mm:ssZ", n.defaultFormatUtc = "YYYY-MM-DDTHH:mm:ss[Z]";
        function ii() {
          return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ");
        }
        function ni(e) {
          if (!this.isValid()) return null;
          var t = e !== true, s = t ? this.clone().utc() : this;
          return s.year() < 0 || s.year() > 9999 ? Fe(s, t ? "YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYYYY-MM-DD[T]HH:mm:ss.SSSZ") : J(Date.prototype.toISOString) ? t ? this.toDate().toISOString() : new Date(this.valueOf() + this.utcOffset() * 60 * 1e3).toISOString().replace("Z", Fe(s, "Z")) : Fe(s, t ? "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]" : "YYYY-MM-DD[T]HH:mm:ss.SSSZ");
        }
        function oi() {
          if (!this.isValid()) return "moment.invalid(/* " + this._i + " */)";
          var e = "moment", t = "", s, r, a, i;
          return this.isLocal() || (e = this.utcOffset() === 0 ? "moment.utc" : "moment.parseZone", t = "Z"), s = "[" + e + '("]', r = 0 <= this.year() && this.year() <= 9999 ? "YYYY" : "YYYYYY", a = "-MM-DD[T]HH:mm:ss.SSS", i = t + '[")]', this.format(s + r + a + i);
        }
        function li(e) {
          e || (e = this.isUtc() ? n.defaultFormatUtc : n.defaultFormat);
          var t = Fe(this, e);
          return this.localeData().postformat(t);
        }
        function di(e, t) {
          return this.isValid() && (G(e) && e.isValid() || O(e).isValid()) ? Z({
            to: this,
            from: e
          }).locale(this.locale()).humanize(!t) : this.localeData().invalidDate();
        }
        function ui(e) {
          return this.from(O(), e);
        }
        function hi(e, t) {
          return this.isValid() && (G(e) && e.isValid() || O(e).isValid()) ? Z({
            from: this,
            to: e
          }).locale(this.locale()).humanize(!t) : this.localeData().invalidDate();
        }
        function ci(e) {
          return this.to(O(), e);
        }
        function ms(e) {
          var t;
          return e === void 0 ? this._locale._abbr : (t = ae(e), t != null && (this._locale = t), this);
        }
        var ys = E("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.", function(e) {
          return e === void 0 ? this.localeData() : this.locale(e);
        });
        function ws() {
          return this._locale;
        }
        var Je = 1e3, pe = 60 * Je, Qe = 60 * pe, Ms = (365 * 400 + 97) * 24 * Qe;
        function ve(e, t) {
          return (e % t + t) % t;
        }
        function gs(e, t, s) {
          return e < 100 && e >= 0 ? new Date(e + 400, t, s) - Ms : new Date(e, t, s).valueOf();
        }
        function ps(e, t, s) {
          return e < 100 && e >= 0 ? Date.UTC(e + 400, t, s) - Ms : Date.UTC(e, t, s);
        }
        function fi(e) {
          var t, s;
          if (e = $(e), e === void 0 || e === "millisecond" || !this.isValid()) return this;
          switch (s = this._isUTC ? ps : gs, e) {
            case "year":
              t = s(this.year(), 0, 1);
              break;
            case "quarter":
              t = s(this.year(), this.month() - this.month() % 3, 1);
              break;
            case "month":
              t = s(this.year(), this.month(), 1);
              break;
            case "week":
              t = s(this.year(), this.month(), this.date() - this.weekday());
              break;
            case "isoWeek":
              t = s(this.year(), this.month(), this.date() - (this.isoWeekday() - 1));
              break;
            case "day":
            case "date":
              t = s(this.year(), this.month(), this.date());
              break;
            case "hour":
              t = this._d.valueOf(), t -= ve(t + (this._isUTC ? 0 : this.utcOffset() * pe), Qe);
              break;
            case "minute":
              t = this._d.valueOf(), t -= ve(t, pe);
              break;
            case "second":
              t = this._d.valueOf(), t -= ve(t, Je);
              break;
          }
          return this._d.setTime(t), n.updateOffset(this, true), this;
        }
        function _i(e) {
          var t, s;
          if (e = $(e), e === void 0 || e === "millisecond" || !this.isValid()) return this;
          switch (s = this._isUTC ? ps : gs, e) {
            case "year":
              t = s(this.year() + 1, 0, 1) - 1;
              break;
            case "quarter":
              t = s(this.year(), this.month() - this.month() % 3 + 3, 1) - 1;
              break;
            case "month":
              t = s(this.year(), this.month() + 1, 1) - 1;
              break;
            case "week":
              t = s(this.year(), this.month(), this.date() - this.weekday() + 7) - 1;
              break;
            case "isoWeek":
              t = s(this.year(), this.month(), this.date() - (this.isoWeekday() - 1) + 7) - 1;
              break;
            case "day":
            case "date":
              t = s(this.year(), this.month(), this.date() + 1) - 1;
              break;
            case "hour":
              t = this._d.valueOf(), t += Qe - ve(t + (this._isUTC ? 0 : this.utcOffset() * pe), Qe) - 1;
              break;
            case "minute":
              t = this._d.valueOf(), t += pe - ve(t, pe) - 1;
              break;
            case "second":
              t = this._d.valueOf(), t += Je - ve(t, Je) - 1;
              break;
          }
          return this._d.setTime(t), n.updateOffset(this, true), this;
        }
        function mi() {
          return this._d.valueOf() - (this._offset || 0) * 6e4;
        }
        function yi() {
          return Math.floor(this.valueOf() / 1e3);
        }
        function wi() {
          return new Date(this.valueOf());
        }
        function Mi() {
          var e = this;
          return [
            e.year(),
            e.month(),
            e.date(),
            e.hour(),
            e.minute(),
            e.second(),
            e.millisecond()
          ];
        }
        function gi() {
          var e = this;
          return {
            years: e.year(),
            months: e.month(),
            date: e.date(),
            hours: e.hours(),
            minutes: e.minutes(),
            seconds: e.seconds(),
            milliseconds: e.milliseconds()
          };
        }
        function pi() {
          return this.isValid() ? this.toISOString() : null;
        }
        function vi() {
          return rt(this);
        }
        function ki() {
          return I({}, k(this));
        }
        function Di() {
          return k(this).overflow;
        }
        function Yi() {
          return {
            input: this._i,
            format: this._f,
            locale: this._locale,
            isUTC: this._isUTC,
            strict: this._strict
          };
        }
        g("N", 0, 0, "eraAbbr"), g("NN", 0, 0, "eraAbbr"), g("NNN", 0, 0, "eraAbbr"), g("NNNN", 0, 0, "eraName"), g("NNNNN", 0, 0, "eraNarrow"), g("y", [
          "y",
          1
        ], "yo", "eraYear"), g("y", [
          "yy",
          2
        ], 0, "eraYear"), g("y", [
          "yyy",
          3
        ], 0, "eraYear"), g("y", [
          "yyyy",
          4
        ], 0, "eraYear"), m("N", bt), m("NN", bt), m("NNN", bt), m("NNNN", Hi), m("NNNNN", Fi), T([
          "N",
          "NN",
          "NNN",
          "NNNN",
          "NNNNN"
        ], function(e, t, s, r) {
          var a = s._locale.erasParse(e, r, s._strict);
          a ? k(s).era = a : k(s).invalidEra = e;
        }), m("y", ye), m("yy", ye), m("yyy", ye), m("yyyy", ye), m("yo", Ni), T([
          "y",
          "yy",
          "yyy",
          "yyyy"
        ], N), T([
          "yo"
        ], function(e, t, s, r) {
          var a;
          s._locale._eraYearOrdinalRegex && (a = e.match(s._locale._eraYearOrdinalRegex)), s._locale.eraYearOrdinalParse ? t[N] = s._locale.eraYearOrdinalParse(e, a) : t[N] = parseInt(e, 10);
        });
        function Si(e, t) {
          var s, r, a, i = this._eras || ae("en")._eras;
          for (s = 0, r = i.length; s < r; ++s) {
            switch (typeof i[s].since) {
              case "string":
                a = n(i[s].since).startOf("day"), i[s].since = a.valueOf();
                break;
            }
            switch (typeof i[s].until) {
              case "undefined":
                i[s].until = 1 / 0;
                break;
              case "string":
                a = n(i[s].until).startOf("day").valueOf(), i[s].until = a.valueOf();
                break;
            }
          }
          return i;
        }
        function xi(e, t, s) {
          var r, a, i = this.eras(), o, _, v;
          for (e = e.toUpperCase(), r = 0, a = i.length; r < a; ++r) if (o = i[r].name.toUpperCase(), _ = i[r].abbr.toUpperCase(), v = i[r].narrow.toUpperCase(), s) switch (t) {
            case "N":
            case "NN":
            case "NNN":
              if (_ === e) return i[r];
              break;
            case "NNNN":
              if (o === e) return i[r];
              break;
            case "NNNNN":
              if (v === e) return i[r];
              break;
          }
          else if ([
            o,
            _,
            v
          ].indexOf(e) >= 0) return i[r];
        }
        function Li(e, t) {
          var s = e.since <= e.until ? 1 : -1;
          return t === void 0 ? n(e.since).year() : n(e.since).year() + (t - e.offset) * s;
        }
        function Ti() {
          var e, t, s, r = this.localeData().eras();
          for (e = 0, t = r.length; e < t; ++e) if (s = this.clone().startOf("day").valueOf(), r[e].since <= s && s <= r[e].until || r[e].until <= s && s <= r[e].since) return r[e].name;
          return "";
        }
        function bi() {
          var e, t, s, r = this.localeData().eras();
          for (e = 0, t = r.length; e < t; ++e) if (s = this.clone().startOf("day").valueOf(), r[e].since <= s && s <= r[e].until || r[e].until <= s && s <= r[e].since) return r[e].narrow;
          return "";
        }
        function Oi() {
          var e, t, s, r = this.localeData().eras();
          for (e = 0, t = r.length; e < t; ++e) if (s = this.clone().startOf("day").valueOf(), r[e].since <= s && s <= r[e].until || r[e].until <= s && s <= r[e].since) return r[e].abbr;
          return "";
        }
        function Wi() {
          var e, t, s, r, a = this.localeData().eras();
          for (e = 0, t = a.length; e < t; ++e) if (s = a[e].since <= a[e].until ? 1 : -1, r = this.clone().startOf("day").valueOf(), a[e].since <= r && r <= a[e].until || a[e].until <= r && r <= a[e].since) return (this.year() - n(a[e].since).year()) * s + a[e].offset;
          return this.year();
        }
        function ji(e) {
          return u(this, "_erasNameRegex") || Ot.call(this), e ? this._erasNameRegex : this._erasRegex;
        }
        function Pi(e) {
          return u(this, "_erasAbbrRegex") || Ot.call(this), e ? this._erasAbbrRegex : this._erasRegex;
        }
        function Ri(e) {
          return u(this, "_erasNarrowRegex") || Ot.call(this), e ? this._erasNarrowRegex : this._erasRegex;
        }
        function bt(e, t) {
          return t.erasAbbrRegex(e);
        }
        function Hi(e, t) {
          return t.erasNameRegex(e);
        }
        function Fi(e, t) {
          return t.erasNarrowRegex(e);
        }
        function Ni(e, t) {
          return t._eraYearOrdinalRegex || ye;
        }
        function Ot() {
          var e = [], t = [], s = [], r = [], a, i, o, _, v, S = this.eras();
          for (a = 0, i = S.length; a < i; ++a) o = ee(S[a].name), _ = ee(S[a].abbr), v = ee(S[a].narrow), t.push(o), e.push(_), s.push(v), r.push(o), r.push(_), r.push(v);
          this._erasRegex = new RegExp("^(" + r.join("|") + ")", "i"), this._erasNameRegex = new RegExp("^(" + t.join("|") + ")", "i"), this._erasAbbrRegex = new RegExp("^(" + e.join("|") + ")", "i"), this._erasNarrowRegex = new RegExp("^(" + s.join("|") + ")", "i");
        }
        g(0, [
          "gg",
          2
        ], 0, function() {
          return this.weekYear() % 100;
        }), g(0, [
          "GG",
          2
        ], 0, function() {
          return this.isoWeekYear() % 100;
        });
        function Xe(e, t) {
          g(0, [
            e,
            e.length
          ], 0, t);
        }
        Xe("gggg", "weekYear"), Xe("ggggg", "weekYear"), Xe("GGGG", "isoWeekYear"), Xe("GGGGG", "isoWeekYear"), m("G", Ie), m("g", Ie), m("GG", b, A), m("gg", b, A), m("GGGG", ft, ct), m("gggg", ft, ct), m("GGGGG", ze, Ne), m("ggggg", ze, Ne), xe([
          "gggg",
          "ggggg",
          "GGGG",
          "GGGGG"
        ], function(e, t, s, r) {
          t[r.substr(0, 2)] = Y(e);
        }), xe([
          "gg",
          "GG"
        ], function(e, t, s, r) {
          t[r] = n.parseTwoDigitYear(e);
        });
        function Ci(e) {
          return vs.call(this, e, this.week(), this.weekday() + this.localeData()._week.dow, this.localeData()._week.dow, this.localeData()._week.doy);
        }
        function zi(e) {
          return vs.call(this, e, this.isoWeek(), this.isoWeekday(), 1, 4);
        }
        function Ii() {
          return re(this.year(), 1, 4);
        }
        function Ai() {
          return re(this.isoWeekYear(), 1, 4);
        }
        function Ui() {
          var e = this.localeData()._week;
          return re(this.year(), e.dow, e.doy);
        }
        function Ei() {
          var e = this.localeData()._week;
          return re(this.weekYear(), e.dow, e.doy);
        }
        function vs(e, t, s, r, a) {
          var i;
          return e == null ? Oe(this, r, a).year : (i = re(e, r, a), t > i && (t = i), $i.call(this, e, t, s, r, a));
        }
        function $i(e, t, s, r, a) {
          var i = Xt(e, t, s, r, a), o = be(i.year, 0, i.dayOfYear);
          return this.year(o.getUTCFullYear()), this.month(o.getUTCMonth()), this.date(o.getUTCDate()), this;
        }
        g("Q", 0, "Qo", "quarter"), m("Q", At), T("Q", function(e, t) {
          t[te] = (Y(e) - 1) * 3;
        });
        function Vi(e) {
          return e == null ? Math.ceil((this.month() + 1) / 3) : this.month((e - 1) * 3 + this.month() % 3);
        }
        g("D", [
          "DD",
          2
        ], "Do", "date"), m("D", b, we), m("DD", b, A), m("Do", function(e, t) {
          return e ? t._dayOfMonthOrdinalParse || t._ordinalParse : t._dayOfMonthOrdinalParseLenient;
        }), T([
          "D",
          "DD"
        ], X), T("Do", function(e, t) {
          t[X] = Y(e.match(b)[0]);
        });
        var ks = Me("Date", true);
        g("DDD", [
          "DDDD",
          3
        ], "DDDo", "dayOfYear"), m("DDD", Ce), m("DDDD", Ut), T([
          "DDD",
          "DDDD"
        ], function(e, t, s) {
          s._dayOfYear = Y(e);
        });
        function Gi(e) {
          var t = Math.round((this.clone().startOf("day") - this.clone().startOf("year")) / 864e5) + 1;
          return e == null ? t : this.add(e - t, "d");
        }
        g("m", [
          "mm",
          2
        ], 0, "minute"), m("m", b, _t), m("mm", b, A), T([
          "m",
          "mm"
        ], B);
        var Bi = Me("Minutes", false);
        g("s", [
          "ss",
          2
        ], 0, "second"), m("s", b, _t), m("ss", b, A), T([
          "s",
          "ss"
        ], se);
        var Zi = Me("Seconds", false);
        g("S", 0, 0, function() {
          return ~~(this.millisecond() / 100);
        }), g(0, [
          "SS",
          2
        ], 0, function() {
          return ~~(this.millisecond() / 10);
        }), g(0, [
          "SSS",
          3
        ], 0, "millisecond"), g(0, [
          "SSSS",
          4
        ], 0, function() {
          return this.millisecond() * 10;
        }), g(0, [
          "SSSSS",
          5
        ], 0, function() {
          return this.millisecond() * 100;
        }), g(0, [
          "SSSSSS",
          6
        ], 0, function() {
          return this.millisecond() * 1e3;
        }), g(0, [
          "SSSSSSS",
          7
        ], 0, function() {
          return this.millisecond() * 1e4;
        }), g(0, [
          "SSSSSSSS",
          8
        ], 0, function() {
          return this.millisecond() * 1e5;
        }), g(0, [
          "SSSSSSSSS",
          9
        ], 0, function() {
          return this.millisecond() * 1e6;
        }), m("S", Ce, At), m("SS", Ce, A), m("SSS", Ce, Ut);
        var ue, Ds;
        for (ue = "SSSS"; ue.length <= 9; ue += "S") m(ue, ye);
        function qi(e, t) {
          t[ce] = Y(("0." + e) * 1e3);
        }
        for (ue = "S"; ue.length <= 9; ue += "S") T(ue, qi);
        Ds = Me("Milliseconds", false), g("z", 0, 0, "zoneAbbr"), g("zz", 0, 0, "zoneName");
        function Ji() {
          return this._isUTC ? "UTC" : "";
        }
        function Qi() {
          return this._isUTC ? "Coordinated Universal Time" : "";
        }
        var d = Ye.prototype;
        d.add = Ea, d.calendar = Ja, d.clone = Qa, d.diff = ai, d.endOf = _i, d.format = li, d.from = di, d.fromNow = ui, d.to = hi, d.toNow = ci, d.get = or, d.invalidAt = Di, d.isAfter = Xa, d.isBefore = Ka, d.isBetween = ei, d.isSame = ti, d.isSameOrAfter = si, d.isSameOrBefore = ri, d.isValid = vi, d.lang = ys, d.locale = ms, d.localeData = ws, d.max = va, d.min = pa, d.parsingFlags = ki, d.set = lr, d.startOf = fi, d.subtract = $a, d.toArray = Mi, d.toObject = gi, d.toDate = wi, d.toISOString = ni, d.inspect = oi, typeof Symbol < "u" && Symbol.for != null && (d[Symbol.for("nodejs.util.inspect.custom")] = function() {
          return "Moment<" + this.format() + ">";
        }), d.toJSON = pi, d.toString = ii, d.unix = yi, d.valueOf = mi, d.creationData = Yi, d.eraName = Ti, d.eraNarrow = bi, d.eraAbbr = Oi, d.eraYear = Wi, d.year = Vt, d.isLeapYear = nr, d.weekYear = Ci, d.isoWeekYear = zi, d.quarter = d.quarters = Vi, d.month = Jt, d.daysInMonth = wr, d.week = d.weeks = Sr, d.isoWeek = d.isoWeeks = xr, d.weeksInYear = Ui, d.weeksInWeekYear = Ei, d.isoWeeksInYear = Ii, d.isoWeeksInISOWeekYear = Ai, d.date = ks, d.day = d.days = zr, d.weekday = Ir, d.isoWeekday = Ar, d.dayOfYear = Gi, d.hour = d.hours = Zr, d.minute = d.minutes = Bi, d.second = d.seconds = Zi, d.millisecond = d.milliseconds = Ds, d.utcOffset = Oa, d.utc = ja, d.local = Pa, d.parseZone = Ra, d.hasAlignedHourOffset = Ha, d.isDST = Fa, d.isLocal = Ca, d.isUtcOffset = za, d.isUtc = us, d.isUTC = us, d.zoneAbbr = Ji, d.zoneName = Qi, d.dates = E("dates accessor is deprecated. Use date instead.", ks), d.months = E("months accessor is deprecated. Use month instead", Jt), d.years = E("years accessor is deprecated. Use year instead", Vt), d.zone = E("moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/", Wa), d.isDSTShifted = E("isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information", Na);
        function Xi(e) {
          return O(e * 1e3);
        }
        function Ki() {
          return O.apply(null, arguments).parseZone();
        }
        function Ys(e) {
          return e;
        }
        var L = ot.prototype;
        L.calendar = Cs, L.longDateFormat = Us, L.invalidDate = $s, L.ordinal = Bs, L.preparse = Ys, L.postformat = Ys, L.relativeTime = qs, L.pastFuture = Js, L.set = Fs, L.eras = Si, L.erasParse = xi, L.erasConvertYear = Li, L.erasAbbrRegex = Pi, L.erasNameRegex = ji, L.erasNarrowRegex = Ri, L.months = fr, L.monthsShort = _r, L.monthsParse = yr, L.monthsRegex = gr, L.monthsShortRegex = Mr, L.week = vr, L.firstDayOfYear = Yr, L.firstDayOfWeek = Dr, L.weekdays = Rr, L.weekdaysMin = Fr, L.weekdaysShort = Hr, L.weekdaysParse = Cr, L.weekdaysRegex = Ur, L.weekdaysShortRegex = Er, L.weekdaysMinRegex = $r, L.isPM = Gr, L.meridiem = qr;
        function Ke(e, t, s, r) {
          var a = ae(), i = U().set(r, t);
          return a[s](i, e);
        }
        function Ss(e, t, s) {
          if (D(e) && (t = e, e = void 0), e = e || "", t != null) return Ke(e, t, s, "month");
          var r, a = [];
          for (r = 0; r < 12; r++) a[r] = Ke(e, r, s, "month");
          return a;
        }
        function Wt(e, t, s, r) {
          typeof e == "boolean" ? (D(t) && (s = t, t = void 0), t = t || "") : (t = e, s = t, e = false, D(t) && (s = t, t = void 0), t = t || "");
          var a = ae(), i = e ? a._week.dow : 0, o, _ = [];
          if (s != null) return Ke(t, (s + i) % 7, r, "day");
          for (o = 0; o < 7; o++) _[o] = Ke(t, (o + i) % 7, r, "day");
          return _;
        }
        function en(e, t) {
          return Ss(e, t, "months");
        }
        function tn(e, t) {
          return Ss(e, t, "monthsShort");
        }
        function sn(e, t, s) {
          return Wt(e, t, s, "weekdays");
        }
        function rn(e, t, s) {
          return Wt(e, t, s, "weekdaysShort");
        }
        function an(e, t, s) {
          return Wt(e, t, s, "weekdaysMin");
        }
        de("en", {
          eras: [
            {
              since: "0001-01-01",
              until: 1 / 0,
              offset: 1,
              name: "Anno Domini",
              narrow: "AD",
              abbr: "AD"
            },
            {
              since: "0000-12-31",
              until: -1 / 0,
              offset: 1,
              name: "Before Christ",
              narrow: "BC",
              abbr: "BC"
            }
          ],
          dayOfMonthOrdinalParse: /\d{1,2}(th|st|nd|rd)/,
          ordinal: function(e) {
            var t = e % 10, s = Y(e % 100 / 10) === 1 ? "th" : t === 1 ? "st" : t === 2 ? "nd" : t === 3 ? "rd" : "th";
            return e + s;
          }
        }), n.lang = E("moment.lang is deprecated. Use moment.locale instead.", de), n.langData = E("moment.langData is deprecated. Use moment.localeData instead.", ae);
        var ie = Math.abs;
        function nn() {
          var e = this._data;
          return this._milliseconds = ie(this._milliseconds), this._days = ie(this._days), this._months = ie(this._months), e.milliseconds = ie(e.milliseconds), e.seconds = ie(e.seconds), e.minutes = ie(e.minutes), e.hours = ie(e.hours), e.months = ie(e.months), e.years = ie(e.years), this;
        }
        function xs(e, t, s, r) {
          var a = Z(t, s);
          return e._milliseconds += r * a._milliseconds, e._days += r * a._days, e._months += r * a._months, e._bubble();
        }
        function on(e, t) {
          return xs(this, e, t, 1);
        }
        function ln(e, t) {
          return xs(this, e, t, -1);
        }
        function Ls(e) {
          return e < 0 ? Math.floor(e) : Math.ceil(e);
        }
        function dn() {
          var e = this._milliseconds, t = this._days, s = this._months, r = this._data, a, i, o, _, v;
          return e >= 0 && t >= 0 && s >= 0 || e <= 0 && t <= 0 && s <= 0 || (e += Ls(jt(s) + t) * 864e5, t = 0, s = 0), r.milliseconds = e % 1e3, a = V(e / 1e3), r.seconds = a % 60, i = V(a / 60), r.minutes = i % 60, o = V(i / 60), r.hours = o % 24, t += V(o / 24), v = V(Ts(t)), s += v, t -= Ls(jt(v)), _ = V(s / 12), s %= 12, r.days = t, r.months = s, r.years = _, this;
        }
        function Ts(e) {
          return e * 4800 / 146097;
        }
        function jt(e) {
          return e * 146097 / 4800;
        }
        function un(e) {
          if (!this.isValid()) return NaN;
          var t, s, r = this._milliseconds;
          if (e = $(e), e === "month" || e === "quarter" || e === "year") switch (t = this._days + r / 864e5, s = this._months + Ts(t), e) {
            case "month":
              return s;
            case "quarter":
              return s / 3;
            case "year":
              return s / 12;
          }
          else switch (t = this._days + Math.round(jt(this._months)), e) {
            case "week":
              return t / 7 + r / 6048e5;
            case "day":
              return t + r / 864e5;
            case "hour":
              return t * 24 + r / 36e5;
            case "minute":
              return t * 1440 + r / 6e4;
            case "second":
              return t * 86400 + r / 1e3;
            case "millisecond":
              return Math.floor(t * 864e5) + r;
            default:
              throw new Error("Unknown unit " + e);
          }
        }
        function ne(e) {
          return function() {
            return this.as(e);
          };
        }
        var bs = ne("ms"), hn = ne("s"), cn = ne("m"), fn = ne("h"), _n = ne("d"), mn = ne("w"), yn = ne("M"), wn = ne("Q"), Mn = ne("y"), gn = bs;
        function pn() {
          return Z(this);
        }
        function vn(e) {
          return e = $(e), this.isValid() ? this[e + "s"]() : NaN;
        }
        function _e(e) {
          return function() {
            return this.isValid() ? this._data[e] : NaN;
          };
        }
        var kn = _e("milliseconds"), Dn = _e("seconds"), Yn = _e("minutes"), Sn = _e("hours"), xn = _e("days"), Ln = _e("months"), Tn = _e("years");
        function bn() {
          return V(this.days() / 7);
        }
        var oe = Math.round, ke = {
          ss: 44,
          s: 45,
          m: 45,
          h: 22,
          d: 26,
          w: null,
          M: 11
        };
        function On(e, t, s, r, a) {
          return a.relativeTime(t || 1, !!s, e, r);
        }
        function Wn(e, t, s, r) {
          var a = Z(e).abs(), i = oe(a.as("s")), o = oe(a.as("m")), _ = oe(a.as("h")), v = oe(a.as("d")), S = oe(a.as("M")), z = oe(a.as("w")), le = oe(a.as("y")), he = i <= s.ss && [
            "s",
            i
          ] || i < s.s && [
            "ss",
            i
          ] || o <= 1 && [
            "m"
          ] || o < s.m && [
            "mm",
            o
          ] || _ <= 1 && [
            "h"
          ] || _ < s.h && [
            "hh",
            _
          ] || v <= 1 && [
            "d"
          ] || v < s.d && [
            "dd",
            v
          ];
          return s.w != null && (he = he || z <= 1 && [
            "w"
          ] || z < s.w && [
            "ww",
            z
          ]), he = he || S <= 1 && [
            "M"
          ] || S < s.M && [
            "MM",
            S
          ] || le <= 1 && [
            "y"
          ] || [
            "yy",
            le
          ], he[2] = t, he[3] = +e > 0, he[4] = r, On.apply(null, he);
        }
        function jn(e) {
          return e === void 0 ? oe : typeof e == "function" ? (oe = e, true) : false;
        }
        function Pn(e, t) {
          return ke[e] === void 0 ? false : t === void 0 ? ke[e] : (ke[e] = t, e === "s" && (ke.ss = t - 1), true);
        }
        function Rn(e, t) {
          if (!this.isValid()) return this.localeData().invalidDate();
          var s = false, r = ke, a, i;
          return typeof e == "object" && (t = e, e = false), typeof e == "boolean" && (s = e), typeof t == "object" && (r = Object.assign({}, ke, t), t.s != null && t.ss == null && (r.ss = t.s - 1)), a = this.localeData(), i = Wn(this, !s, r, a), s && (i = a.pastFuture(+this, i)), a.postformat(i);
        }
        var Pt = Math.abs;
        function De(e) {
          return (e > 0) - (e < 0) || +e;
        }
        function et() {
          if (!this.isValid()) return this.localeData().invalidDate();
          var e = Pt(this._milliseconds) / 1e3, t = Pt(this._days), s = Pt(this._months), r, a, i, o, _ = this.asSeconds(), v, S, z, le;
          return _ ? (r = V(e / 60), a = V(r / 60), e %= 60, r %= 60, i = V(s / 12), s %= 12, o = e ? e.toFixed(3).replace(/\.?0+$/, "") : "", v = _ < 0 ? "-" : "", S = De(this._months) !== De(_) ? "-" : "", z = De(this._days) !== De(_) ? "-" : "", le = De(this._milliseconds) !== De(_) ? "-" : "", v + "P" + (i ? S + i + "Y" : "") + (s ? S + s + "M" : "") + (t ? z + t + "D" : "") + (a || r || e ? "T" : "") + (a ? le + a + "H" : "") + (r ? le + r + "M" : "") + (e ? le + o + "S" : "")) : "P0D";
        }
        var x = Be.prototype;
        x.isValid = xa, x.abs = nn, x.add = on, x.subtract = ln, x.as = un, x.asMilliseconds = bs, x.asSeconds = hn, x.asMinutes = cn, x.asHours = fn, x.asDays = _n, x.asWeeks = mn, x.asMonths = yn, x.asQuarters = wn, x.asYears = Mn, x.valueOf = gn, x._bubble = dn, x.clone = pn, x.get = vn, x.milliseconds = kn, x.seconds = Dn, x.minutes = Yn, x.hours = Sn, x.days = xn, x.weeks = bn, x.months = Ln, x.years = Tn, x.humanize = Rn, x.toISOString = et, x.toString = et, x.toJSON = et, x.locale = ms, x.localeData = ws, x.toIsoString = E("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)", et), x.lang = ys, g("X", 0, 0, "unix"), g("x", 0, 0, "valueOf"), m("x", Ie), m("X", er), T("X", function(e, t, s) {
          s._d = new Date(parseFloat(e) * 1e3);
        }), T("x", function(e, t, s) {
          s._d = new Date(Y(e));
        });
        return n.version = "2.30.1", w(O), n.fn = d, n.min = ka, n.max = Da, n.now = Ya, n.utc = U, n.unix = Xi, n.months = en, n.isDate = H, n.locale = de, n.invalid = Re, n.duration = Z, n.isMoment = G, n.weekdays = sn, n.parseZone = Ki, n.localeData = ae, n.isDuration = Ze, n.monthsShort = tn, n.weekdaysMin = an, n.defineLocale = pt, n.updateLocale = Kr, n.locales = ea, n.weekdaysShort = rn, n.normalizeUnits = $, n.relativeTimeRounding = jn, n.relativeTimeThreshold = Pn, n.calendarFormat = qa, n.prototype = d, n.HTML5_FMT = {
          DATETIME_LOCAL: "YYYY-MM-DDTHH:mm",
          DATETIME_LOCAL_SECONDS: "YYYY-MM-DDTHH:mm:ss",
          DATETIME_LOCAL_MS: "YYYY-MM-DDTHH:mm:ss.SSS",
          DATE: "YYYY-MM-DD",
          TIME: "HH:mm",
          TIME_SECONDS: "HH:mm:ss",
          TIME_MS: "HH:mm:ss.SSS",
          WEEK: "GGGG-[W]WW",
          MONTH: "YYYY-MM"
        }, n;
      }));
    })(tt)), tt.exports;
  }
  var Cn = Fn.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(Cn, (function(l) {
      function n(M, p, u, c) {
        var f = {
          m: [
            "eine Minute",
            "einer Minute"
          ],
          h: [
            "eine Stunde",
            "einer Stunde"
          ],
          d: [
            "ein Tag",
            "einem Tag"
          ],
          dd: [
            M + " Tage",
            M + " Tagen"
          ],
          w: [
            "eine Woche",
            "einer Woche"
          ],
          M: [
            "ein Monat",
            "einem Monat"
          ],
          MM: [
            M + " Monate",
            M + " Monaten"
          ],
          y: [
            "ein Jahr",
            "einem Jahr"
          ],
          yy: [
            M + " Jahre",
            M + " Jahren"
          ]
        };
        return p ? f[u][0] : f[u][1];
      }
      var w = l.defineLocale("de", {
        months: "Januar_Februar_M\xE4rz_April_Mai_Juni_Juli_August_September_Oktober_November_Dezember".split("_"),
        monthsShort: "Jan._Feb._M\xE4rz_Apr._Mai_Juni_Juli_Aug._Sep._Okt._Nov._Dez.".split("_"),
        monthsParseExact: true,
        weekdays: "Sonntag_Montag_Dienstag_Mittwoch_Donnerstag_Freitag_Samstag".split("_"),
        weekdaysShort: "So._Mo._Di._Mi._Do._Fr._Sa.".split("_"),
        weekdaysMin: "So_Mo_Di_Mi_Do_Fr_Sa".split("_"),
        weekdaysParseExact: true,
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "DD.MM.YYYY",
          LL: "D. MMMM YYYY",
          LLL: "D. MMMM YYYY HH:mm",
          LLLL: "dddd, D. MMMM YYYY HH:mm"
        },
        calendar: {
          sameDay: "[heute um] LT [Uhr]",
          sameElse: "L",
          nextDay: "[morgen um] LT [Uhr]",
          nextWeek: "dddd [um] LT [Uhr]",
          lastDay: "[gestern um] LT [Uhr]",
          lastWeek: "[letzten] dddd [um] LT [Uhr]"
        },
        relativeTime: {
          future: "in %s",
          past: "vor %s",
          s: "ein paar Sekunden",
          ss: "%d Sekunden",
          m: n,
          mm: "%d Minuten",
          h: n,
          hh: "%d Stunden",
          d: n,
          dd: n,
          w: n,
          ww: "%d Wochen",
          M: n,
          MM: n,
          y: n,
          yy: n
        },
        dayOfMonthOrdinalParse: /\d{1,2}\./,
        ordinal: "%d.",
        week: {
          dow: 1,
          doy: 4
        }
      });
      return w;
    }));
  })();
  var zn = {
    exports: {}
  }, In = zn.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(In, (function(l) {
      var n = "ene._feb._mar._abr._may._jun._jul._ago._sep._oct._nov._dic.".split("_"), w = "ene_feb_mar_abr_may_jun_jul_ago_sep_oct_nov_dic".split("_"), M = [
        /^ene/i,
        /^feb/i,
        /^mar/i,
        /^abr/i,
        /^may/i,
        /^jun/i,
        /^jul/i,
        /^ago/i,
        /^sep/i,
        /^oct/i,
        /^nov/i,
        /^dic/i
      ], p = /^(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|ene\.?|feb\.?|mar\.?|abr\.?|may\.?|jun\.?|jul\.?|ago\.?|sep\.?|oct\.?|nov\.?|dic\.?)/i, u = l.defineLocale("es", {
        months: "enero_febrero_marzo_abril_mayo_junio_julio_agosto_septiembre_octubre_noviembre_diciembre".split("_"),
        monthsShort: function(c, f) {
          return c ? /-MMM-/.test(f) ? w[c.month()] : n[c.month()] : n;
        },
        monthsRegex: p,
        monthsShortRegex: p,
        monthsStrictRegex: /^(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)/i,
        monthsShortStrictRegex: /^(ene\.?|feb\.?|mar\.?|abr\.?|may\.?|jun\.?|jul\.?|ago\.?|sep\.?|oct\.?|nov\.?|dic\.?)/i,
        monthsParse: M,
        longMonthsParse: M,
        shortMonthsParse: M,
        weekdays: "domingo_lunes_martes_mi\xE9rcoles_jueves_viernes_s\xE1bado".split("_"),
        weekdaysShort: "dom._lun._mar._mi\xE9._jue._vie._s\xE1b.".split("_"),
        weekdaysMin: "do_lu_ma_mi_ju_vi_s\xE1".split("_"),
        weekdaysParseExact: true,
        longDateFormat: {
          LT: "H:mm",
          LTS: "H:mm:ss",
          L: "DD/MM/YYYY",
          LL: "D [de] MMMM [de] YYYY",
          LLL: "D [de] MMMM [de] YYYY H:mm",
          LLLL: "dddd, D [de] MMMM [de] YYYY H:mm"
        },
        calendar: {
          sameDay: function() {
            return "[hoy a la" + (this.hours() !== 1 ? "s" : "") + "] LT";
          },
          nextDay: function() {
            return "[ma\xF1ana a la" + (this.hours() !== 1 ? "s" : "") + "] LT";
          },
          nextWeek: function() {
            return "dddd [a la" + (this.hours() !== 1 ? "s" : "") + "] LT";
          },
          lastDay: function() {
            return "[ayer a la" + (this.hours() !== 1 ? "s" : "") + "] LT";
          },
          lastWeek: function() {
            return "[el] dddd [pasado a la" + (this.hours() !== 1 ? "s" : "") + "] LT";
          },
          sameElse: "L"
        },
        relativeTime: {
          future: "en %s",
          past: "hace %s",
          s: "unos segundos",
          ss: "%d segundos",
          m: "un minuto",
          mm: "%d minutos",
          h: "una hora",
          hh: "%d horas",
          d: "un d\xEDa",
          dd: "%d d\xEDas",
          w: "una semana",
          ww: "%d semanas",
          M: "un mes",
          MM: "%d meses",
          y: "un a\xF1o",
          yy: "%d a\xF1os"
        },
        dayOfMonthOrdinalParse: /\d{1,2}º/,
        ordinal: "%d\xBA",
        week: {
          dow: 1,
          doy: 4
        },
        invalidDate: "Fecha inv\xE1lida"
      });
      return u;
    }));
  })();
  var An = {
    exports: {}
  }, Un = An.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(Un, (function(l) {
      var n = /^(janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre)/i, w = /(janv\.?|févr\.?|mars|avr\.?|mai|juin|juil\.?|août|sept\.?|oct\.?|nov\.?|déc\.?)/i, M = /(janv\.?|févr\.?|mars|avr\.?|mai|juin|juil\.?|août|sept\.?|oct\.?|nov\.?|déc\.?|janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre)/i, p = [
        /^janv/i,
        /^févr/i,
        /^mars/i,
        /^avr/i,
        /^mai/i,
        /^juin/i,
        /^juil/i,
        /^août/i,
        /^sept/i,
        /^oct/i,
        /^nov/i,
        /^déc/i
      ], u = l.defineLocale("fr", {
        months: "janvier_f\xE9vrier_mars_avril_mai_juin_juillet_ao\xFBt_septembre_octobre_novembre_d\xE9cembre".split("_"),
        monthsShort: "janv._f\xE9vr._mars_avr._mai_juin_juil._ao\xFBt_sept._oct._nov._d\xE9c.".split("_"),
        monthsRegex: M,
        monthsShortRegex: M,
        monthsStrictRegex: n,
        monthsShortStrictRegex: w,
        monthsParse: p,
        longMonthsParse: p,
        shortMonthsParse: p,
        weekdays: "dimanche_lundi_mardi_mercredi_jeudi_vendredi_samedi".split("_"),
        weekdaysShort: "dim._lun._mar._mer._jeu._ven._sam.".split("_"),
        weekdaysMin: "di_lu_ma_me_je_ve_sa".split("_"),
        weekdaysParseExact: true,
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "DD/MM/YYYY",
          LL: "D MMMM YYYY",
          LLL: "D MMMM YYYY HH:mm",
          LLLL: "dddd D MMMM YYYY HH:mm"
        },
        calendar: {
          sameDay: "[Aujourd\u2019hui \xE0] LT",
          nextDay: "[Demain \xE0] LT",
          nextWeek: "dddd [\xE0] LT",
          lastDay: "[Hier \xE0] LT",
          lastWeek: "dddd [dernier \xE0] LT",
          sameElse: "L"
        },
        relativeTime: {
          future: "dans %s",
          past: "il y a %s",
          s: "quelques secondes",
          ss: "%d secondes",
          m: "une minute",
          mm: "%d minutes",
          h: "une heure",
          hh: "%d heures",
          d: "un jour",
          dd: "%d jours",
          w: "une semaine",
          ww: "%d semaines",
          M: "un mois",
          MM: "%d mois",
          y: "un an",
          yy: "%d ans"
        },
        dayOfMonthOrdinalParse: /\d{1,2}(er|)/,
        ordinal: function(c, f) {
          switch (f) {
            case "D":
              return c + (c === 1 ? "er" : "");
            default:
            case "M":
            case "Q":
            case "DDD":
            case "d":
              return c + (c === 1 ? "er" : "e");
            case "w":
            case "W":
              return c + (c === 1 ? "re" : "e");
          }
        },
        week: {
          dow: 1,
          doy: 4
        }
      });
      return u;
    }));
  })();
  var En = {
    exports: {}
  }, $n = En.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })($n, (function(l) {
      var n = l.defineLocale("it", {
        months: "gennaio_febbraio_marzo_aprile_maggio_giugno_luglio_agosto_settembre_ottobre_novembre_dicembre".split("_"),
        monthsShort: "gen_feb_mar_apr_mag_giu_lug_ago_set_ott_nov_dic".split("_"),
        weekdays: "domenica_luned\xEC_marted\xEC_mercoled\xEC_gioved\xEC_venerd\xEC_sabato".split("_"),
        weekdaysShort: "dom_lun_mar_mer_gio_ven_sab".split("_"),
        weekdaysMin: "do_lu_ma_me_gi_ve_sa".split("_"),
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "DD/MM/YYYY",
          LL: "D MMMM YYYY",
          LLL: "D MMMM YYYY HH:mm",
          LLLL: "dddd D MMMM YYYY HH:mm"
        },
        calendar: {
          sameDay: function() {
            return "[Oggi a" + (this.hours() > 1 ? "lle " : this.hours() === 0 ? " " : "ll'") + "]LT";
          },
          nextDay: function() {
            return "[Domani a" + (this.hours() > 1 ? "lle " : this.hours() === 0 ? " " : "ll'") + "]LT";
          },
          nextWeek: function() {
            return "dddd [a" + (this.hours() > 1 ? "lle " : this.hours() === 0 ? " " : "ll'") + "]LT";
          },
          lastDay: function() {
            return "[Ieri a" + (this.hours() > 1 ? "lle " : this.hours() === 0 ? " " : "ll'") + "]LT";
          },
          lastWeek: function() {
            switch (this.day()) {
              case 0:
                return "[La scorsa] dddd [a" + (this.hours() > 1 ? "lle " : this.hours() === 0 ? " " : "ll'") + "]LT";
              default:
                return "[Lo scorso] dddd [a" + (this.hours() > 1 ? "lle " : this.hours() === 0 ? " " : "ll'") + "]LT";
            }
          },
          sameElse: "L"
        },
        relativeTime: {
          future: "tra %s",
          past: "%s fa",
          s: "alcuni secondi",
          ss: "%d secondi",
          m: "un minuto",
          mm: "%d minuti",
          h: "un'ora",
          hh: "%d ore",
          d: "un giorno",
          dd: "%d giorni",
          w: "una settimana",
          ww: "%d settimane",
          M: "un mese",
          MM: "%d mesi",
          y: "un anno",
          yy: "%d anni"
        },
        dayOfMonthOrdinalParse: /\d{1,2}º/,
        ordinal: "%d\xBA",
        week: {
          dow: 1,
          doy: 4
        }
      });
      return n;
    }));
  })();
  var Vn = {
    exports: {}
  }, Gn = Vn.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(Gn, (function(l) {
      var n = "jan._feb._mrt._apr._mei_jun._jul._aug._sep._okt._nov._dec.".split("_"), w = "jan_feb_mrt_apr_mei_jun_jul_aug_sep_okt_nov_dec".split("_"), M = [
        /^jan/i,
        /^feb/i,
        /^(maart|mrt\.?)$/i,
        /^apr/i,
        /^mei$/i,
        /^jun[i.]?$/i,
        /^jul[i.]?$/i,
        /^aug/i,
        /^sep/i,
        /^okt/i,
        /^nov/i,
        /^dec/i
      ], p = /^(januari|februari|maart|april|mei|ju[nl]i|augustus|september|oktober|november|december|jan\.?|feb\.?|mrt\.?|apr\.?|ju[nl]\.?|aug\.?|sep\.?|okt\.?|nov\.?|dec\.?)/i, u = l.defineLocale("nl", {
        months: "januari_februari_maart_april_mei_juni_juli_augustus_september_oktober_november_december".split("_"),
        monthsShort: function(c, f) {
          return c ? /-MMM-/.test(f) ? w[c.month()] : n[c.month()] : n;
        },
        monthsRegex: p,
        monthsShortRegex: p,
        monthsStrictRegex: /^(januari|februari|maart|april|mei|ju[nl]i|augustus|september|oktober|november|december)/i,
        monthsShortStrictRegex: /^(jan\.?|feb\.?|mrt\.?|apr\.?|mei|ju[nl]\.?|aug\.?|sep\.?|okt\.?|nov\.?|dec\.?)/i,
        monthsParse: M,
        longMonthsParse: M,
        shortMonthsParse: M,
        weekdays: "zondag_maandag_dinsdag_woensdag_donderdag_vrijdag_zaterdag".split("_"),
        weekdaysShort: "zo._ma._di._wo._do._vr._za.".split("_"),
        weekdaysMin: "zo_ma_di_wo_do_vr_za".split("_"),
        weekdaysParseExact: true,
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "DD-MM-YYYY",
          LL: "D MMMM YYYY",
          LLL: "D MMMM YYYY HH:mm",
          LLLL: "dddd D MMMM YYYY HH:mm"
        },
        calendar: {
          sameDay: "[vandaag om] LT",
          nextDay: "[morgen om] LT",
          nextWeek: "dddd [om] LT",
          lastDay: "[gisteren om] LT",
          lastWeek: "[afgelopen] dddd [om] LT",
          sameElse: "L"
        },
        relativeTime: {
          future: "over %s",
          past: "%s geleden",
          s: "een paar seconden",
          ss: "%d seconden",
          m: "\xE9\xE9n minuut",
          mm: "%d minuten",
          h: "\xE9\xE9n uur",
          hh: "%d uur",
          d: "\xE9\xE9n dag",
          dd: "%d dagen",
          w: "\xE9\xE9n week",
          ww: "%d weken",
          M: "\xE9\xE9n maand",
          MM: "%d maanden",
          y: "\xE9\xE9n jaar",
          yy: "%d jaar"
        },
        dayOfMonthOrdinalParse: /\d{1,2}(ste|de)/,
        ordinal: function(c) {
          return c + (c === 1 || c === 8 || c >= 20 ? "ste" : "de");
        },
        week: {
          dow: 1,
          doy: 4
        }
      });
      return u;
    }));
  })();
  var Bn = {
    exports: {}
  }, Zn = Bn.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(Zn, (function(l) {
      var n = "stycze\u0144_luty_marzec_kwiecie\u0144_maj_czerwiec_lipiec_sierpie\u0144_wrzesie\u0144_pa\u017Adziernik_listopad_grudzie\u0144".split("_"), w = "stycznia_lutego_marca_kwietnia_maja_czerwca_lipca_sierpnia_wrze\u015Bnia_pa\u017Adziernika_listopada_grudnia".split("_"), M = [
        /^sty/i,
        /^lut/i,
        /^mar/i,
        /^kwi/i,
        /^maj/i,
        /^cze/i,
        /^lip/i,
        /^sie/i,
        /^wrz/i,
        /^paź/i,
        /^lis/i,
        /^gru/i
      ];
      function p(f) {
        return f % 10 < 5 && f % 10 > 1 && ~~(f / 10) % 10 !== 1;
      }
      function u(f, D, H) {
        var C = f + " ";
        switch (H) {
          case "ss":
            return C + (p(f) ? "sekundy" : "sekund");
          case "m":
            return D ? "minuta" : "minut\u0119";
          case "mm":
            return C + (p(f) ? "minuty" : "minut");
          case "h":
            return D ? "godzina" : "godzin\u0119";
          case "hh":
            return C + (p(f) ? "godziny" : "godzin");
          case "ww":
            return C + (p(f) ? "tygodnie" : "tygodni");
          case "MM":
            return C + (p(f) ? "miesi\u0105ce" : "miesi\u0119cy");
          case "yy":
            return C + (p(f) ? "lata" : "lat");
        }
      }
      var c = l.defineLocale("pl", {
        months: function(f, D) {
          return f ? /D MMMM/.test(D) ? w[f.month()] : n[f.month()] : n;
        },
        monthsShort: "sty_lut_mar_kwi_maj_cze_lip_sie_wrz_pa\u017A_lis_gru".split("_"),
        monthsParse: M,
        longMonthsParse: M,
        shortMonthsParse: M,
        weekdays: "niedziela_poniedzia\u0142ek_wtorek_\u015Broda_czwartek_pi\u0105tek_sobota".split("_"),
        weekdaysShort: "ndz_pon_wt_\u015Br_czw_pt_sob".split("_"),
        weekdaysMin: "Nd_Pn_Wt_\u015Ar_Cz_Pt_So".split("_"),
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "DD.MM.YYYY",
          LL: "D MMMM YYYY",
          LLL: "D MMMM YYYY HH:mm",
          LLLL: "dddd, D MMMM YYYY HH:mm"
        },
        calendar: {
          sameDay: "[Dzi\u015B o] LT",
          nextDay: "[Jutro o] LT",
          nextWeek: function() {
            switch (this.day()) {
              case 0:
                return "[W niedziel\u0119 o] LT";
              case 2:
                return "[We wtorek o] LT";
              case 3:
                return "[W \u015Brod\u0119 o] LT";
              case 6:
                return "[W sobot\u0119 o] LT";
              default:
                return "[W] dddd [o] LT";
            }
          },
          lastDay: "[Wczoraj o] LT",
          lastWeek: function() {
            switch (this.day()) {
              case 0:
                return "[W zesz\u0142\u0105 niedziel\u0119 o] LT";
              case 3:
                return "[W zesz\u0142\u0105 \u015Brod\u0119 o] LT";
              case 6:
                return "[W zesz\u0142\u0105 sobot\u0119 o] LT";
              default:
                return "[W zesz\u0142y] dddd [o] LT";
            }
          },
          sameElse: "L"
        },
        relativeTime: {
          future: "za %s",
          past: "%s temu",
          s: "kilka sekund",
          ss: u,
          m: u,
          mm: u,
          h: u,
          hh: u,
          d: "1 dzie\u0144",
          dd: "%d dni",
          w: "tydzie\u0144",
          ww: u,
          M: "miesi\u0105c",
          MM: u,
          y: "rok",
          yy: u
        },
        dayOfMonthOrdinalParse: /\d{1,2}\./,
        ordinal: "%d.",
        week: {
          dow: 1,
          doy: 4
        }
      });
      return c;
    }));
  })();
  var qn = {
    exports: {}
  }, Jn = qn.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(Jn, (function(l) {
      var n = l.defineLocale("pt", {
        months: "janeiro_fevereiro_mar\xE7o_abril_maio_junho_julho_agosto_setembro_outubro_novembro_dezembro".split("_"),
        monthsShort: "jan_fev_mar_abr_mai_jun_jul_ago_set_out_nov_dez".split("_"),
        weekdays: "Domingo_Segunda-feira_Ter\xE7a-feira_Quarta-feira_Quinta-feira_Sexta-feira_S\xE1bado".split("_"),
        weekdaysShort: "Dom_Seg_Ter_Qua_Qui_Sex_S\xE1b".split("_"),
        weekdaysMin: "Do_2\xAA_3\xAA_4\xAA_5\xAA_6\xAA_S\xE1".split("_"),
        weekdaysParseExact: true,
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "DD/MM/YYYY",
          LL: "D [de] MMMM [de] YYYY",
          LLL: "D [de] MMMM [de] YYYY HH:mm",
          LLLL: "dddd, D [de] MMMM [de] YYYY HH:mm"
        },
        calendar: {
          sameDay: "[Hoje \xE0s] LT",
          nextDay: "[Amanh\xE3 \xE0s] LT",
          nextWeek: "dddd [\xE0s] LT",
          lastDay: "[Ontem \xE0s] LT",
          lastWeek: function() {
            return this.day() === 0 || this.day() === 6 ? "[\xDAltimo] dddd [\xE0s] LT" : "[\xDAltima] dddd [\xE0s] LT";
          },
          sameElse: "L"
        },
        relativeTime: {
          future: "em %s",
          past: "h\xE1 %s",
          s: "segundos",
          ss: "%d segundos",
          m: "um minuto",
          mm: "%d minutos",
          h: "uma hora",
          hh: "%d horas",
          d: "um dia",
          dd: "%d dias",
          w: "uma semana",
          ww: "%d semanas",
          M: "um m\xEAs",
          MM: "%d meses",
          y: "um ano",
          yy: "%d anos"
        },
        dayOfMonthOrdinalParse: /\d{1,2}º/,
        ordinal: "%d\xBA",
        week: {
          dow: 1,
          doy: 4
        }
      });
      return n;
    }));
  })();
  var Qn = {
    exports: {}
  }, Xn = Qn.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(Xn, (function(l) {
      function n(u, c) {
        var f = u.split("_");
        return c % 10 === 1 && c % 100 !== 11 ? f[0] : c % 10 >= 2 && c % 10 <= 4 && (c % 100 < 10 || c % 100 >= 20) ? f[1] : f[2];
      }
      function w(u, c, f) {
        var D = {
          ss: c ? "\u0441\u0435\u043A\u0443\u043D\u0434\u0430_\u0441\u0435\u043A\u0443\u043D\u0434\u044B_\u0441\u0435\u043A\u0443\u043D\u0434" : "\u0441\u0435\u043A\u0443\u043D\u0434\u0443_\u0441\u0435\u043A\u0443\u043D\u0434\u044B_\u0441\u0435\u043A\u0443\u043D\u0434",
          mm: c ? "\u043C\u0438\u043D\u0443\u0442\u0430_\u043C\u0438\u043D\u0443\u0442\u044B_\u043C\u0438\u043D\u0443\u0442" : "\u043C\u0438\u043D\u0443\u0442\u0443_\u043C\u0438\u043D\u0443\u0442\u044B_\u043C\u0438\u043D\u0443\u0442",
          hh: "\u0447\u0430\u0441_\u0447\u0430\u0441\u0430_\u0447\u0430\u0441\u043E\u0432",
          dd: "\u0434\u0435\u043D\u044C_\u0434\u043D\u044F_\u0434\u043D\u0435\u0439",
          ww: "\u043D\u0435\u0434\u0435\u043B\u044F_\u043D\u0435\u0434\u0435\u043B\u0438_\u043D\u0435\u0434\u0435\u043B\u044C",
          MM: "\u043C\u0435\u0441\u044F\u0446_\u043C\u0435\u0441\u044F\u0446\u0430_\u043C\u0435\u0441\u044F\u0446\u0435\u0432",
          yy: "\u0433\u043E\u0434_\u0433\u043E\u0434\u0430_\u043B\u0435\u0442"
        };
        return f === "m" ? c ? "\u043C\u0438\u043D\u0443\u0442\u0430" : "\u043C\u0438\u043D\u0443\u0442\u0443" : u + " " + n(D[f], +u);
      }
      var M = [
        /^янв/i,
        /^фев/i,
        /^мар/i,
        /^апр/i,
        /^ма[йя]/i,
        /^июн/i,
        /^июл/i,
        /^авг/i,
        /^сен/i,
        /^окт/i,
        /^ноя/i,
        /^дек/i
      ], p = l.defineLocale("ru", {
        months: {
          format: "\u044F\u043D\u0432\u0430\u0440\u044F_\u0444\u0435\u0432\u0440\u0430\u043B\u044F_\u043C\u0430\u0440\u0442\u0430_\u0430\u043F\u0440\u0435\u043B\u044F_\u043C\u0430\u044F_\u0438\u044E\u043D\u044F_\u0438\u044E\u043B\u044F_\u0430\u0432\u0433\u0443\u0441\u0442\u0430_\u0441\u0435\u043D\u0442\u044F\u0431\u0440\u044F_\u043E\u043A\u0442\u044F\u0431\u0440\u044F_\u043D\u043E\u044F\u0431\u0440\u044F_\u0434\u0435\u043A\u0430\u0431\u0440\u044F".split("_"),
          standalone: "\u044F\u043D\u0432\u0430\u0440\u044C_\u0444\u0435\u0432\u0440\u0430\u043B\u044C_\u043C\u0430\u0440\u0442_\u0430\u043F\u0440\u0435\u043B\u044C_\u043C\u0430\u0439_\u0438\u044E\u043D\u044C_\u0438\u044E\u043B\u044C_\u0430\u0432\u0433\u0443\u0441\u0442_\u0441\u0435\u043D\u0442\u044F\u0431\u0440\u044C_\u043E\u043A\u0442\u044F\u0431\u0440\u044C_\u043D\u043E\u044F\u0431\u0440\u044C_\u0434\u0435\u043A\u0430\u0431\u0440\u044C".split("_")
        },
        monthsShort: {
          format: "\u044F\u043D\u0432._\u0444\u0435\u0432\u0440._\u043C\u0430\u0440._\u0430\u043F\u0440._\u043C\u0430\u044F_\u0438\u044E\u043D\u044F_\u0438\u044E\u043B\u044F_\u0430\u0432\u0433._\u0441\u0435\u043D\u0442._\u043E\u043A\u0442._\u043D\u043E\u044F\u0431._\u0434\u0435\u043A.".split("_"),
          standalone: "\u044F\u043D\u0432._\u0444\u0435\u0432\u0440._\u043C\u0430\u0440\u0442_\u0430\u043F\u0440._\u043C\u0430\u0439_\u0438\u044E\u043D\u044C_\u0438\u044E\u043B\u044C_\u0430\u0432\u0433._\u0441\u0435\u043D\u0442._\u043E\u043A\u0442._\u043D\u043E\u044F\u0431._\u0434\u0435\u043A.".split("_")
        },
        weekdays: {
          standalone: "\u0432\u043E\u0441\u043A\u0440\u0435\u0441\u0435\u043D\u044C\u0435_\u043F\u043E\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u0438\u043A_\u0432\u0442\u043E\u0440\u043D\u0438\u043A_\u0441\u0440\u0435\u0434\u0430_\u0447\u0435\u0442\u0432\u0435\u0440\u0433_\u043F\u044F\u0442\u043D\u0438\u0446\u0430_\u0441\u0443\u0431\u0431\u043E\u0442\u0430".split("_"),
          format: "\u0432\u043E\u0441\u043A\u0440\u0435\u0441\u0435\u043D\u044C\u0435_\u043F\u043E\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u0438\u043A_\u0432\u0442\u043E\u0440\u043D\u0438\u043A_\u0441\u0440\u0435\u0434\u0443_\u0447\u0435\u0442\u0432\u0435\u0440\u0433_\u043F\u044F\u0442\u043D\u0438\u0446\u0443_\u0441\u0443\u0431\u0431\u043E\u0442\u0443".split("_"),
          isFormat: /\[ ?[Вв] ?(?:прошлую|следующую|эту)? ?] ?dddd/
        },
        weekdaysShort: "\u0432\u0441_\u043F\u043D_\u0432\u0442_\u0441\u0440_\u0447\u0442_\u043F\u0442_\u0441\u0431".split("_"),
        weekdaysMin: "\u0432\u0441_\u043F\u043D_\u0432\u0442_\u0441\u0440_\u0447\u0442_\u043F\u0442_\u0441\u0431".split("_"),
        monthsParse: M,
        longMonthsParse: M,
        shortMonthsParse: M,
        monthsRegex: /^(январ[ья]|янв\.?|феврал[ья]|февр?\.?|марта?|мар\.?|апрел[ья]|апр\.?|ма[йя]|июн[ья]|июн\.?|июл[ья]|июл\.?|августа?|авг\.?|сентябр[ья]|сент?\.?|октябр[ья]|окт\.?|ноябр[ья]|нояб?\.?|декабр[ья]|дек\.?)/i,
        monthsShortRegex: /^(январ[ья]|янв\.?|феврал[ья]|февр?\.?|марта?|мар\.?|апрел[ья]|апр\.?|ма[йя]|июн[ья]|июн\.?|июл[ья]|июл\.?|августа?|авг\.?|сентябр[ья]|сент?\.?|октябр[ья]|окт\.?|ноябр[ья]|нояб?\.?|декабр[ья]|дек\.?)/i,
        monthsStrictRegex: /^(январ[яь]|феврал[яь]|марта?|апрел[яь]|ма[яй]|июн[яь]|июл[яь]|августа?|сентябр[яь]|октябр[яь]|ноябр[яь]|декабр[яь])/i,
        monthsShortStrictRegex: /^(янв\.|февр?\.|мар[т.]|апр\.|ма[яй]|июн[ья.]|июл[ья.]|авг\.|сент?\.|окт\.|нояб?\.|дек\.)/i,
        longDateFormat: {
          LT: "H:mm",
          LTS: "H:mm:ss",
          L: "DD.MM.YYYY",
          LL: "D MMMM YYYY \u0433.",
          LLL: "D MMMM YYYY \u0433., H:mm",
          LLLL: "dddd, D MMMM YYYY \u0433., H:mm"
        },
        calendar: {
          sameDay: "[\u0421\u0435\u0433\u043E\u0434\u043D\u044F, \u0432] LT",
          nextDay: "[\u0417\u0430\u0432\u0442\u0440\u0430, \u0432] LT",
          lastDay: "[\u0412\u0447\u0435\u0440\u0430, \u0432] LT",
          nextWeek: function(u) {
            if (u.week() !== this.week()) switch (this.day()) {
              case 0:
                return "[\u0412 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0435] dddd, [\u0432] LT";
              case 1:
              case 2:
              case 4:
                return "[\u0412 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439] dddd, [\u0432] LT";
              case 3:
              case 5:
              case 6:
                return "[\u0412 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0443\u044E] dddd, [\u0432] LT";
            }
            else return this.day() === 2 ? "[\u0412\u043E] dddd, [\u0432] LT" : "[\u0412] dddd, [\u0432] LT";
          },
          lastWeek: function(u) {
            if (u.week() !== this.week()) switch (this.day()) {
              case 0:
                return "[\u0412 \u043F\u0440\u043E\u0448\u043B\u043E\u0435] dddd, [\u0432] LT";
              case 1:
              case 2:
              case 4:
                return "[\u0412 \u043F\u0440\u043E\u0448\u043B\u044B\u0439] dddd, [\u0432] LT";
              case 3:
              case 5:
              case 6:
                return "[\u0412 \u043F\u0440\u043E\u0448\u043B\u0443\u044E] dddd, [\u0432] LT";
            }
            else return this.day() === 2 ? "[\u0412\u043E] dddd, [\u0432] LT" : "[\u0412] dddd, [\u0432] LT";
          },
          sameElse: "L"
        },
        relativeTime: {
          future: "\u0447\u0435\u0440\u0435\u0437 %s",
          past: "%s \u043D\u0430\u0437\u0430\u0434",
          s: "\u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u0435\u043A\u0443\u043D\u0434",
          ss: w,
          m: w,
          mm: w,
          h: "\u0447\u0430\u0441",
          hh: w,
          d: "\u0434\u0435\u043D\u044C",
          dd: w,
          w: "\u043D\u0435\u0434\u0435\u043B\u044F",
          ww: w,
          M: "\u043C\u0435\u0441\u044F\u0446",
          MM: w,
          y: "\u0433\u043E\u0434",
          yy: w
        },
        meridiemParse: /ночи|утра|дня|вечера/i,
        isPM: function(u) {
          return /^(дня|вечера)$/.test(u);
        },
        meridiem: function(u, c, f) {
          return u < 4 ? "\u043D\u043E\u0447\u0438" : u < 12 ? "\u0443\u0442\u0440\u0430" : u < 17 ? "\u0434\u043D\u044F" : "\u0432\u0435\u0447\u0435\u0440\u0430";
        },
        dayOfMonthOrdinalParse: /\d{1,2}-(й|го|я)/,
        ordinal: function(u, c) {
          switch (c) {
            case "M":
            case "d":
            case "DDD":
              return u + "-\u0439";
            case "D":
              return u + "-\u0433\u043E";
            case "w":
            case "W":
              return u + "-\u044F";
            default:
              return u;
          }
        },
        week: {
          dow: 1,
          doy: 4
        }
      });
      return p;
    }));
  })();
  var Kn = {
    exports: {}
  }, eo = Kn.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(eo, (function(l) {
      function n(c, f) {
        var D = c.split("_");
        return f % 10 === 1 && f % 100 !== 11 ? D[0] : f % 10 >= 2 && f % 10 <= 4 && (f % 100 < 10 || f % 100 >= 20) ? D[1] : D[2];
      }
      function w(c, f, D) {
        var H = {
          ss: f ? "\u0441\u0435\u043A\u0443\u043D\u0434\u0430_\u0441\u0435\u043A\u0443\u043D\u0434\u0438_\u0441\u0435\u043A\u0443\u043D\u0434" : "\u0441\u0435\u043A\u0443\u043D\u0434\u0443_\u0441\u0435\u043A\u0443\u043D\u0434\u0438_\u0441\u0435\u043A\u0443\u043D\u0434",
          mm: f ? "\u0445\u0432\u0438\u043B\u0438\u043D\u0430_\u0445\u0432\u0438\u043B\u0438\u043D\u0438_\u0445\u0432\u0438\u043B\u0438\u043D" : "\u0445\u0432\u0438\u043B\u0438\u043D\u0443_\u0445\u0432\u0438\u043B\u0438\u043D\u0438_\u0445\u0432\u0438\u043B\u0438\u043D",
          hh: f ? "\u0433\u043E\u0434\u0438\u043D\u0430_\u0433\u043E\u0434\u0438\u043D\u0438_\u0433\u043E\u0434\u0438\u043D" : "\u0433\u043E\u0434\u0438\u043D\u0443_\u0433\u043E\u0434\u0438\u043D\u0438_\u0433\u043E\u0434\u0438\u043D",
          dd: "\u0434\u0435\u043D\u044C_\u0434\u043D\u0456_\u0434\u043D\u0456\u0432",
          MM: "\u043C\u0456\u0441\u044F\u0446\u044C_\u043C\u0456\u0441\u044F\u0446\u0456_\u043C\u0456\u0441\u044F\u0446\u0456\u0432",
          yy: "\u0440\u0456\u043A_\u0440\u043E\u043A\u0438_\u0440\u043E\u043A\u0456\u0432"
        };
        return D === "m" ? f ? "\u0445\u0432\u0438\u043B\u0438\u043D\u0430" : "\u0445\u0432\u0438\u043B\u0438\u043D\u0443" : D === "h" ? f ? "\u0433\u043E\u0434\u0438\u043D\u0430" : "\u0433\u043E\u0434\u0438\u043D\u0443" : c + " " + n(H[D], +c);
      }
      function M(c, f) {
        var D = {
          nominative: "\u043D\u0435\u0434\u0456\u043B\u044F_\u043F\u043E\u043D\u0435\u0434\u0456\u043B\u043E\u043A_\u0432\u0456\u0432\u0442\u043E\u0440\u043E\u043A_\u0441\u0435\u0440\u0435\u0434\u0430_\u0447\u0435\u0442\u0432\u0435\u0440_\u043F\u2019\u044F\u0442\u043D\u0438\u0446\u044F_\u0441\u0443\u0431\u043E\u0442\u0430".split("_"),
          accusative: "\u043D\u0435\u0434\u0456\u043B\u044E_\u043F\u043E\u043D\u0435\u0434\u0456\u043B\u043E\u043A_\u0432\u0456\u0432\u0442\u043E\u0440\u043E\u043A_\u0441\u0435\u0440\u0435\u0434\u0443_\u0447\u0435\u0442\u0432\u0435\u0440_\u043F\u2019\u044F\u0442\u043D\u0438\u0446\u044E_\u0441\u0443\u0431\u043E\u0442\u0443".split("_"),
          genitive: "\u043D\u0435\u0434\u0456\u043B\u0456_\u043F\u043E\u043D\u0435\u0434\u0456\u043B\u043A\u0430_\u0432\u0456\u0432\u0442\u043E\u0440\u043A\u0430_\u0441\u0435\u0440\u0435\u0434\u0438_\u0447\u0435\u0442\u0432\u0435\u0440\u0433\u0430_\u043F\u2019\u044F\u0442\u043D\u0438\u0446\u0456_\u0441\u0443\u0431\u043E\u0442\u0438".split("_")
        }, H;
        return c === true ? D.nominative.slice(1, 7).concat(D.nominative.slice(0, 1)) : c ? (H = /(\[[ВвУу]\]) ?dddd/.test(f) ? "accusative" : /\[?(?:минулої|наступної)? ?\] ?dddd/.test(f) ? "genitive" : "nominative", D[H][c.day()]) : D.nominative;
      }
      function p(c) {
        return function() {
          return c + "\u043E" + (this.hours() === 11 ? "\u0431" : "") + "] LT";
        };
      }
      var u = l.defineLocale("uk", {
        months: {
          format: "\u0441\u0456\u0447\u043D\u044F_\u043B\u044E\u0442\u043E\u0433\u043E_\u0431\u0435\u0440\u0435\u0437\u043D\u044F_\u043A\u0432\u0456\u0442\u043D\u044F_\u0442\u0440\u0430\u0432\u043D\u044F_\u0447\u0435\u0440\u0432\u043D\u044F_\u043B\u0438\u043F\u043D\u044F_\u0441\u0435\u0440\u043F\u043D\u044F_\u0432\u0435\u0440\u0435\u0441\u043D\u044F_\u0436\u043E\u0432\u0442\u043D\u044F_\u043B\u0438\u0441\u0442\u043E\u043F\u0430\u0434\u0430_\u0433\u0440\u0443\u0434\u043D\u044F".split("_"),
          standalone: "\u0441\u0456\u0447\u0435\u043D\u044C_\u043B\u044E\u0442\u0438\u0439_\u0431\u0435\u0440\u0435\u0437\u0435\u043D\u044C_\u043A\u0432\u0456\u0442\u0435\u043D\u044C_\u0442\u0440\u0430\u0432\u0435\u043D\u044C_\u0447\u0435\u0440\u0432\u0435\u043D\u044C_\u043B\u0438\u043F\u0435\u043D\u044C_\u0441\u0435\u0440\u043F\u0435\u043D\u044C_\u0432\u0435\u0440\u0435\u0441\u0435\u043D\u044C_\u0436\u043E\u0432\u0442\u0435\u043D\u044C_\u043B\u0438\u0441\u0442\u043E\u043F\u0430\u0434_\u0433\u0440\u0443\u0434\u0435\u043D\u044C".split("_")
        },
        monthsShort: "\u0441\u0456\u0447_\u043B\u044E\u0442_\u0431\u0435\u0440_\u043A\u0432\u0456\u0442_\u0442\u0440\u0430\u0432_\u0447\u0435\u0440\u0432_\u043B\u0438\u043F_\u0441\u0435\u0440\u043F_\u0432\u0435\u0440_\u0436\u043E\u0432\u0442_\u043B\u0438\u0441\u0442_\u0433\u0440\u0443\u0434".split("_"),
        weekdays: M,
        weekdaysShort: "\u043D\u0434_\u043F\u043D_\u0432\u0442_\u0441\u0440_\u0447\u0442_\u043F\u0442_\u0441\u0431".split("_"),
        weekdaysMin: "\u043D\u0434_\u043F\u043D_\u0432\u0442_\u0441\u0440_\u0447\u0442_\u043F\u0442_\u0441\u0431".split("_"),
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "DD.MM.YYYY",
          LL: "D MMMM YYYY \u0440.",
          LLL: "D MMMM YYYY \u0440., HH:mm",
          LLLL: "dddd, D MMMM YYYY \u0440., HH:mm"
        },
        calendar: {
          sameDay: p("[\u0421\u044C\u043E\u0433\u043E\u0434\u043D\u0456 "),
          nextDay: p("[\u0417\u0430\u0432\u0442\u0440\u0430 "),
          lastDay: p("[\u0412\u0447\u043E\u0440\u0430 "),
          nextWeek: p("[\u0423] dddd ["),
          lastWeek: function() {
            switch (this.day()) {
              case 0:
              case 3:
              case 5:
              case 6:
                return p("[\u041C\u0438\u043D\u0443\u043B\u043E\u0457] dddd [").call(this);
              case 1:
              case 2:
              case 4:
                return p("[\u041C\u0438\u043D\u0443\u043B\u043E\u0433\u043E] dddd [").call(this);
            }
          },
          sameElse: "L"
        },
        relativeTime: {
          future: "\u0437\u0430 %s",
          past: "%s \u0442\u043E\u043C\u0443",
          s: "\u0434\u0435\u043A\u0456\u043B\u044C\u043A\u0430 \u0441\u0435\u043A\u0443\u043D\u0434",
          ss: w,
          m: w,
          mm: w,
          h: "\u0433\u043E\u0434\u0438\u043D\u0443",
          hh: w,
          d: "\u0434\u0435\u043D\u044C",
          dd: w,
          M: "\u043C\u0456\u0441\u044F\u0446\u044C",
          MM: w,
          y: "\u0440\u0456\u043A",
          yy: w
        },
        meridiemParse: /ночі|ранку|дня|вечора/,
        isPM: function(c) {
          return /^(дня|вечора)$/.test(c);
        },
        meridiem: function(c, f, D) {
          return c < 4 ? "\u043D\u043E\u0447\u0456" : c < 12 ? "\u0440\u0430\u043D\u043A\u0443" : c < 17 ? "\u0434\u043D\u044F" : "\u0432\u0435\u0447\u043E\u0440\u0430";
        },
        dayOfMonthOrdinalParse: /\d{1,2}-(й|го)/,
        ordinal: function(c, f) {
          switch (f) {
            case "M":
            case "d":
            case "DDD":
            case "w":
            case "W":
              return c + "-\u0439";
            case "D":
              return c + "-\u0433\u043E";
            default:
              return c;
          }
        },
        week: {
          dow: 1,
          doy: 7
        }
      });
      return u;
    }));
  })();
  var to = {
    exports: {}
  }, so = to.exports;
  (function(j, h) {
    (function(l, n) {
      n(typeof q == "function" ? K() : l.moment);
    })(so, (function(l) {
      var n = l.defineLocale("zh-cn", {
        months: "\u4E00\u6708_\u4E8C\u6708_\u4E09\u6708_\u56DB\u6708_\u4E94\u6708_\u516D\u6708_\u4E03\u6708_\u516B\u6708_\u4E5D\u6708_\u5341\u6708_\u5341\u4E00\u6708_\u5341\u4E8C\u6708".split("_"),
        monthsShort: "1\u6708_2\u6708_3\u6708_4\u6708_5\u6708_6\u6708_7\u6708_8\u6708_9\u6708_10\u6708_11\u6708_12\u6708".split("_"),
        weekdays: "\u661F\u671F\u65E5_\u661F\u671F\u4E00_\u661F\u671F\u4E8C_\u661F\u671F\u4E09_\u661F\u671F\u56DB_\u661F\u671F\u4E94_\u661F\u671F\u516D".split("_"),
        weekdaysShort: "\u5468\u65E5_\u5468\u4E00_\u5468\u4E8C_\u5468\u4E09_\u5468\u56DB_\u5468\u4E94_\u5468\u516D".split("_"),
        weekdaysMin: "\u65E5_\u4E00_\u4E8C_\u4E09_\u56DB_\u4E94_\u516D".split("_"),
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "YYYY/MM/DD",
          LL: "YYYY\u5E74M\u6708D\u65E5",
          LLL: "YYYY\u5E74M\u6708D\u65E5Ah\u70B9mm\u5206",
          LLLL: "YYYY\u5E74M\u6708D\u65E5ddddAh\u70B9mm\u5206",
          l: "YYYY/M/D",
          ll: "YYYY\u5E74M\u6708D\u65E5",
          lll: "YYYY\u5E74M\u6708D\u65E5 HH:mm",
          llll: "YYYY\u5E74M\u6708D\u65E5dddd HH:mm"
        },
        meridiemParse: /凌晨|早上|上午|中午|下午|晚上/,
        meridiemHour: function(w, M) {
          return w === 12 && (w = 0), M === "\u51CC\u6668" || M === "\u65E9\u4E0A" || M === "\u4E0A\u5348" ? w : M === "\u4E0B\u5348" || M === "\u665A\u4E0A" ? w + 12 : w >= 11 ? w : w + 12;
        },
        meridiem: function(w, M, p) {
          var u = w * 100 + M;
          return u < 600 ? "\u51CC\u6668" : u < 900 ? "\u65E9\u4E0A" : u < 1130 ? "\u4E0A\u5348" : u < 1230 ? "\u4E2D\u5348" : u < 1800 ? "\u4E0B\u5348" : "\u665A\u4E0A";
        },
        calendar: {
          sameDay: "[\u4ECA\u5929]LT",
          nextDay: "[\u660E\u5929]LT",
          nextWeek: function(w) {
            return w.week() !== this.week() ? "[\u4E0B]dddLT" : "[\u672C]dddLT";
          },
          lastDay: "[\u6628\u5929]LT",
          lastWeek: function(w) {
            return this.week() !== w.week() ? "[\u4E0A]dddLT" : "[\u672C]dddLT";
          },
          sameElse: "L"
        },
        dayOfMonthOrdinalParse: /\d{1,2}(日|月|周)/,
        ordinal: function(w, M) {
          switch (M) {
            case "d":
            case "D":
            case "DDD":
              return w + "\u65E5";
            case "M":
              return w + "\u6708";
            case "w":
            case "W":
              return w + "\u5468";
            default:
              return w;
          }
        },
        relativeTime: {
          future: "%s\u540E",
          past: "%s\u524D",
          s: "\u51E0\u79D2",
          ss: "%d \u79D2",
          m: "1 \u5206\u949F",
          mm: "%d \u5206\u949F",
          h: "1 \u5C0F\u65F6",
          hh: "%d \u5C0F\u65F6",
          d: "1 \u5929",
          dd: "%d \u5929",
          w: "1 \u5468",
          ww: "%d \u5468",
          M: "1 \u4E2A\u6708",
          MM: "%d \u4E2A\u6708",
          y: "1 \u5E74",
          yy: "%d \u5E74"
        },
        week: {
          dow: 1,
          doy: 4
        }
      });
      return n;
    }));
  })();
  function js(j, h, l, n) {
    const w = (n - 90) * (Math.PI / 180);
    return {
      x: j + l * Math.cos(w),
      y: h + l * Math.sin(w)
    };
  }
  function Ps(j, h, l, n, w) {
    const M = js(j, h, l, n), p = js(j, h, l, w), u = w - n <= 180 ? "0" : "1";
    return [
      "M",
      M.x,
      M.y,
      "A",
      l,
      l,
      0,
      u,
      1,
      p.x,
      p.y
    ].join(" ");
  }
  function ro(j) {
    return y.jsxs("svg", {
      style: j.style,
      viewBox: "0 0 44 35",
      children: [
        y.jsx("rect", {
          fill: "#A1C8EC",
          height: "35",
          width: "44",
          y: "0.00283",
          x: "-0.01558"
        }),
        y.jsx("line", {
          stroke: "#7FABDA",
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeWidth: "2",
          fill: "none",
          y2: "14.71955",
          x2: "43.84278",
          y1: "14.71955",
          x1: "-0.01558"
        }),
        y.jsx("path", {
          fill: "#7FABDA",
          d: "m9.98442,15.00283l-6,0l0,-5c0,-1.657 1.343,-3 3,-3l0,0c1.657,0 3,1.343 3,3l0,5z"
        }),
        y.jsx("line", {
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          strokeWidth: "2",
          stroke: "#7FABDA",
          fill: "none",
          y2: "3.00283",
          x2: "8.98442",
          y1: "3.00283",
          x1: "4.98442"
        }),
        y.jsx("line", {
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          strokeWidth: "2",
          stroke: "#7FABDA",
          fill: "none",
          y2: "7.00283",
          x2: "6.98442",
          y1: "3.00283",
          x1: "6.98442"
        }),
        y.jsx("path", {
          fill: "#7FABDA",
          d: "m19.98442,15.00283l-6,0l0,-5c0,-1.657 1.343,-3 3,-3l0,0c1.657,0 3,1.343 3,3l0,5z"
        }),
        y.jsx("line", {
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          strokeWidth: "2",
          stroke: "#7FABDA",
          fill: "none",
          y2: "3.00283",
          x2: "18.98442",
          y1: "3.00283",
          x1: "14.98442"
        }),
        y.jsx("line", {
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          strokeWidth: "2",
          stroke: "#7FABDA",
          fill: "none",
          y2: "7.00283",
          x2: "16.98442",
          y1: "3.00283",
          x1: "16.98442"
        }),
        y.jsx("path", {
          fill: "#7FABDA",
          d: "m29.98442,15.00283l-6,0l0,-5c0,-1.657 1.343,-3 3,-3l0,0c1.657,0 3,1.343 3,3l0,5z"
        }),
        y.jsx("line", {
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          strokeWidth: "2",
          stroke: "#7FABDA",
          fill: "none",
          y2: "3.00283",
          x2: "28.98442",
          y1: "3.00283",
          x1: "24.98442"
        }),
        y.jsx("line", {
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          strokeWidth: "2",
          stroke: "#7FABDA",
          fill: "none",
          y2: "7.00283",
          x2: "26.98442",
          y1: "3.00283",
          x1: "26.98442"
        }),
        y.jsx("path", {
          fill: "#7FABDA",
          d: "m39.98442,15.00283l-6,0l0,-5c0,-1.657 1.343,-3 3,-3l0,0c1.657,0 3,1.343 3,3l0,5z"
        }),
        y.jsx("line", {
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          strokeWidth: "2",
          stroke: "#7FABDA",
          fill: "none",
          y2: "3.00283",
          x2: "38.98442",
          y1: "3.00283",
          x1: "34.98442"
        }),
        y.jsx("line", {
          strokeMiterlimit: "10",
          strokeLinejoin: "round",
          strokeLinecap: "round",
          strokeWidth: "2",
          stroke: "#7FABDA",
          fill: "none",
          y2: "7.00283",
          x2: "36.98442",
          y1: "3.00283",
          x1: "36.98442"
        }),
        y.jsx("path", {
          fill: "#6F98BC",
          d: "m16.98442,31.00283c0,-6.627 -5.373,-12 -12,-12c-1.787,0 -3.476,0.401 -5,1.102l0,14.898l16.283,0c0.448,-1.253 0.717,-2.592 0.717,-4z"
        }),
        y.jsx("path", {
          fill: "#7FABDA",
          d: "m12.98442,31.00283c0,-4.418 -3.582,-8 -8,-8c-1.893,0 -3.63,0.661 -5,1.76l0,10.24l11.918,0c0.685,-1.177 1.082,-2.54 1.082,-4z"
        }),
        y.jsx("path", {
          fill: "#568BB2",
          d: "m13.98442,19.00283c-1.586,0 -3.087,0.33 -4.471,0.891c4.381,1.788 7.471,6.085 7.471,11.109c0,1.408 -0.269,2.747 -0.717,4l9,0c0.448,-1.253 0.717,-2.592 0.717,-4c0,-6.627 -5.373,-12 -12,-12z"
        }),
        y.jsx("path", {
          fill: "#7FABDA",
          d: "m13.98442,23.00283c-0.024,0 -0.047,0.003 -0.071,0.003c1.904,2.124 3.071,4.921 3.071,7.997c0,1.408 -0.269,2.747 -0.717,4l4.636,0c0.685,-1.177 1.082,-2.54 1.082,-4c-0.001,-4.418 -3.583,-8 -8.001,-8z"
        }),
        y.jsx("path", {
          fill: "#6F98BC",
          d: "m22.98442,19.00283c-1.586,0 -3.087,0.33 -4.471,0.891c4.381,1.788 7.471,6.085 7.471,11.109c0,1.408 -0.269,2.747 -0.717,4l9,0c0.448,-1.253 0.717,-2.592 0.717,-4c0,-6.627 -5.373,-12 -12,-12z"
        }),
        y.jsx("path", {
          fill: "#7FABDA",
          d: "m22.98442,23.00283c-0.024,0 -0.047,0.003 -0.071,0.003c1.904,2.124 3.071,4.921 3.071,7.997c0,1.408 -0.269,2.747 -0.717,4l4.636,0c0.685,-1.177 1.082,-2.54 1.082,-4c-0.001,-4.418 -3.583,-8 -8.001,-8z"
        }),
        y.jsx("path", {
          fill: "#568BB2",
          d: "m31.98442,19.00283c-1.586,0 -3.087,0.33 -4.471,0.891c4.381,1.788 7.471,6.085 7.471,11.109c0,1.408 -0.269,2.747 -0.717,4l9,0c0.448,-1.253 0.717,-2.592 0.717,-4c0,-6.627 -5.373,-12 -12,-12z"
        }),
        y.jsx("path", {
          fill: "#7FABDA",
          d: "m31.98442,23.00283c-0.024,0 -0.047,0.003 -0.071,0.003c1.904,2.124 3.071,4.921 3.071,7.997c0,1.408 -0.269,2.747 -0.717,4l4.636,0c0.685,-1.177 1.082,-2.54 1.082,-4c-0.001,-4.418 -3.583,-8 -8.001,-8z"
        })
      ]
    });
  }
  const F = {
    rotatedItem: {
      animation: "vis-2-widgets-nils-fork-rotation 10000ms infinite"
    },
    body: {
      width: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    header: {
      width: "100%",
      height: "15%",
      display: "flex",
      justifyContent: "right",
      alignItems: "center"
    },
    grayLed: {
      borderRadius: "50%",
      backgroundColor: "#999",
      marginRight: "3%",
      marginTop: "4%"
    },
    divider: {
      width: "95%",
      height: "1%",
      borderBottom: "1px solid grey"
    },
    mainPart: {
      width: "90%",
      height: "69%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    centerText: {
      position: "absolute",
      height: "100%",
      width: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 2,
      textAlign: "center"
    },
    centerCircle: {
      position: "absolute",
      height: "100%",
      width: "100%",
      borderRadius: "50%",
      zIndex: 0,
      boxSizing: "border-box"
    },
    footer: {
      width: "100%",
      height: "14%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  };
  Rs = class extends Rt {
    refDiv = Hn.createRef();
    statusOID;
    _updateInterval = null;
    constructor(h) {
      super(h), this.state = {
        ...this.state,
        object: {
          common: {}
        }
      }, Os.locale(h.context.lang);
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2WasherDryer",
        visSet: "vis-2-widgets-nils-fork",
        visName: "WasherDryer",
        visWidgetLabel: "washer_dryer",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "brand",
                label: "brand_name"
              },
              {
                name: "brandColor",
                type: "color",
                label: "brand_color"
              },
              {
                name: "type",
                type: "select",
                label: "type",
                options: [
                  {
                    value: "washer",
                    label: "washer"
                  },
                  {
                    value: "dryer",
                    label: "dryer"
                  },
                  {
                    value: "both",
                    label: "washer_and_dryer"
                  },
                  {
                    value: "dish",
                    label: "dishwasher"
                  }
                ]
              },
              {
                name: "status-oid",
                type: "id",
                label: "status_id",
                onChange: async () => {
                }
              },
              {
                name: "start-time-oid",
                type: "id",
                label: "start_time_id"
              },
              {
                name: "end-time-oid",
                type: "id",
                label: "end_time_id"
              },
              {
                name: "dry-oid",
                type: "id",
                label: "wash_or_dry_id",
                tooltip: "wash_or_dry_tooltip",
                hidden: 'data.type !== "both"'
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_washer_dryer.png"
      };
    }
    getWidgetInfo() {
      return Rs.getWidgetInfo();
    }
    async propertiesUpdate() {
      if (this.statusOID === this.state.rxData["status-oid"]) return;
      if (this.statusOID = this.state.rxData["status-oid"], !this.statusOID || this.statusOID === "nothing_selected") {
        this.setState({
          object: {
            common: {}
          }
        });
        return;
      }
      let h = await this.props.context.socket.getObject(this.statusOID);
      if (h = {
        common: (h == null ? void 0 : h.common) || {},
        _id: h == null ? void 0 : h._id,
        native: {},
        type: "state"
      }, h.common.states && Array.isArray(h.common.states)) {
        const l = {};
        h.common.states.forEach((n) => l[n] = n), h.common.states = l;
      }
      JSON.stringify(this.state.object) !== JSON.stringify(h) && this.setState({
        object: h
      });
    }
    componentWillUnmount() {
      super.componentWillUnmount(), this._updateInterval && clearInterval(this._updateInterval), this._updateInterval = null;
    }
    async componentDidMount() {
      super.componentDidMount(), await this.propertiesUpdate();
    }
    async onRxDataChanged() {
      await this.propertiesUpdate();
    }
    renderWasher(h) {
      let l;
      return h.circle === "full" ? l = y.jsxs("div", {
        style: {
          position: "absolute",
          height: "100%",
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 2
        },
        children: [
          y.jsx("svg", {
            viewBox: "-83 -83 166 166",
            style: {
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%"
            },
            children: y.jsx("path", {
              d: Ps(0, 0, 75, 0, h.value),
              fill: "none",
              style: {
                stroke: h.color,
                strokeWidth: 15
              }
            })
          }),
          y.jsx("svg", {
            viewBox: "-83 -83 166 166",
            style: {
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%"
            },
            children: y.jsx("path", {
              d: Ps(0, 0, 75, h.value, 359.999),
              fill: "none",
              style: {
                stroke: h.backgroundColor,
                strokeWidth: "15px"
              }
            })
          })
        ]
      }) : h.circle === "short" && (l = y.jsxs(y.Fragment, {
        children: [
          y.jsx("div", {
            style: {
              ...F.centerCircle,
              border: `${h.wSize / 20}px solid ${h.backgroundColor}`
            }
          }),
          y.jsx("div", {
            style: {
              ...F.centerCircle,
              ...F.rotatedItem,
              zIndex: 1,
              borderTop: `${h.wSize / 25}px solid ${h.color}`,
              borderBottom: `${h.wSize / 25}px solid ${h.color}`,
              borderLeft: `${h.wSize / 25}px solid ${h.color}`,
              borderRight: `${h.wSize / 25}px solid transparent`
            }
          })
        ]
      })), y.jsxs("div", {
        style: h.style,
        children: [
          y.jsxs("div", {
            style: F.header,
            children: [
              y.jsx("div", {
                style: {
                  width: "30%",
                  height: "70%",
                  marginTop: "3%",
                  borderRadius: "8%",
                  border: "1px solid grey",
                  marginLeft: "3%",
                  overflow: "hidden",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: this.state.rxData.brandColor || void 0,
                  fontSize: (h.brandLen || 0) <= 3 ? Math.round(h.wSize / 10) : Math.round(h.wSize / (h.brandLen * 2.5))
                },
                children: this.state.rxData.brand
              }),
              y.jsx("div", {
                style: {
                  flexGrow: 1
                }
              }),
              y.jsx("div", {
                style: {
                  ...F.grayLed,
                  width: h.wSize / 10,
                  height: h.wSize / 10
                }
              }),
              y.jsx("div", {
                style: {
                  ...F.grayLed,
                  width: h.wSize / 10,
                  height: h.wSize / 10
                }
              }),
              y.jsx("div", {
                style: {
                  width: h.wSize / 10,
                  height: h.wSize / 10,
                  borderRadius: "50%",
                  backgroundColor: h.statusColor,
                  marginRight: "10%",
                  marginTop: "4%"
                }
              })
            ]
          }),
          y.jsx("div", {
            style: F.divider
          }),
          y.jsx("div", {
            style: F.mainPart,
            children: y.jsxs("div", {
              style: {
                width: h.wSize / 1.8,
                height: h.wSize / 1.8,
                border: `${h.wSize / 15}px solid grey`,
                borderRadius: "50%",
                position: "relative"
              },
              children: [
                l,
                y.jsx("div", {
                  style: {
                    ...F.centerText,
                    fontSize: h.fontSize
                  },
                  children: h.timeText || ""
                })
              ]
            })
          }),
          y.jsx("div", {
            style: F.divider
          }),
          y.jsx("div", {
            style: {
              ...F.footer,
              color: h.statusColor
            },
            children: Rt.t(h.status.toLowerCase()).replace("vis_2_widgets_nils_", "")
          })
        ]
      });
    }
    renderDishWasher(h) {
      return y.jsxs("div", {
        style: h.style,
        children: [
          y.jsxs("div", {
            style: F.header,
            children: [
              y.jsx("div", {
                style: {
                  width: h.wSize / 10,
                  height: h.wSize / 10,
                  borderRadius: "50%",
                  backgroundColor: h.statusColor,
                  marginLeft: "3%",
                  marginTop: "4%"
                }
              }),
              y.jsx("div", {
                style: {
                  flexGrow: 1
                }
              }),
              y.jsx("div", {
                style: {
                  width: "33%",
                  height: "70%",
                  marginTop: "3%",
                  borderRadius: "8%",
                  border: "1px solid grey",
                  overflow: "hidden",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: this.state.rxData.brandColor || void 0,
                  fontSize: h.brandLen <= 3 ? Math.round(h.wSize / 10) : Math.round(h.wSize / (h.brandLen * 2.5))
                },
                children: this.state.rxData.brand
              }),
              y.jsx("div", {
                style: {
                  width: "33%"
                }
              })
            ]
          }),
          y.jsx("div", {
            style: F.divider
          }),
          y.jsxs("div", {
            style: F.mainPart,
            children: [
              y.jsx(ro, {
                style: {
                  width: "100%",
                  height: "100%",
                  opacity: 0.5,
                  filter: h.running ? "" : "grayscale(1)"
                }
              }),
              y.jsx("div", {
                style: {
                  ...F.centerText,
                  fontSize: h.fontSize
                },
                children: h.timeText || ""
              })
            ]
          }),
          y.jsx("div", {
            style: F.divider
          }),
          y.jsx("div", {
            style: {
              ...F.footer,
              color: h.statusColor
            },
            children: Rt.t(h.status.toLowerCase()).replace("vis_2_widgets_nils_", "")
          })
        ]
      });
    }
    renderWidgetBody(h) {
      var _a, _b, _c, _d, _e;
      super.renderWidgetBody(h);
      const l = {
        circle: "short",
        wSize: 0,
        status: "inactive",
        value: 0,
        brandLen: 50
      }, n = ((_a = this.refDiv.current) == null ? void 0 : _a.clientWidth) || 0, w = ((_b = this.refDiv.current) == null ? void 0 : _b.clientHeight) || 0, M = 1.3;
      n && (n * M < w ? l.wSize = n : l.wSize = w / 1.3), l.style = {
        width: l.wSize,
        height: l.wSize * M,
        display: "flex",
        alignItems: "center",
        flexDirection: "column",
        margin: "auto",
        fontSize: Math.round(l.wSize / 10),
        borderRadius: Math.round(l.wSize / 30),
        boxShadow: "1px 1px 5px 1px rgba(0,0,0,0.79)"
      }, l.brandLen = ((_c = this.state.rxData.brand) == null ? void 0 : _c.length) || 0, l.status = "stop";
      const p = this.state.values[`${this.state.rxData["status-oid"]}.val`];
      if (p === true || p === "true" ? (l.running = true, l.status = "run") : p === "false" || p === false ? (l.running = false, l.status = "inactive") : ((_e = (_d = this.state.object) == null ? void 0 : _d.common) == null ? void 0 : _e.states) ? (l.status = (this.state.object.common.states[p] || p || "").toString().toLowerCase(), l.running = l.status.includes("run") || l.status.includes("active") && !l.status.includes("inactive")) : (l.status = p || "stop", l.running = l.status.includes("run") || l.status.includes("active") && !l.status.includes("inactive")), l.backgroundColor = "#264d72", l.color = "#3679be", l.running ? (l.statusColor = "#289f3c", (this.state.rxData.type === "dryer" || this.state.rxData.type === "both" && this.state.values[`${this.state.rxData["dry-oid"]}.val`]) && (l.backgroundColor = "#9f883f", l.color = "#945521", l.statusColor = "#b24a00")) : (l.backgroundColor = "#565656", l.color = "#a2a2a2", l.statusColor = "#a2a2a2"), l.running) {
        if (this.state.rxData["start-time-oid"] && this.state.rxData["end-time-oid"] && this.state.values[`${this.state.rxData["end-time-oid"]}.val`] && this.state.values[`${this.state.rxData["start-time-oid"]}.val`]) {
          const c = new Date(this.state.values[`${this.state.rxData["end-time-oid"]}.val`]), f = new Date(this.state.values[`${this.state.rxData["start-time-oid"]}.val`]), D = c.getTime() - f.getTime(), H = c.getTime() - Date.now();
          if (D > 0 && c.getTime() > Date.now()) {
            l.value = Math.round((D - H) / D * 360);
            const C = Math.floor(H / 1e3 / 60 / 60), I = Math.floor((H - C * 1e3 * 60 * 60) / 1e3 / 60);
            l.timeText = `${C}:${I.toString().padStart(2, "0")}`, l.circle = "full";
          } else if (c.getTime() > Date.now()) {
            const C = c.getTime() - Date.now(), I = Math.floor(C / 1e3 / 60 / 60), U = Math.floor((C - I * 1e3 * 60 * 60) / 1e3 / 60);
            l.timeText = `${I}:${U.toString().padStart(2, "0")}`;
          }
        } else if (this.state.rxData["end-time-oid"]) {
          const f = new Date(this.state.values[`${this.state.rxData["end-time-oid"]}.val`]).getTime() - Date.now();
          if (f > 0) {
            const D = Math.floor(f / 1e3 / 60 / 60), H = Math.floor((f - D * 1e3 * 60 * 60) / 1e3 / 60);
            l.timeText = `${D}:${H.toString().padStart(2, "0")}`;
          }
        }
        l.circle || (l.circle = "short"), l.fontSize = Math.round(l.wSize / 5);
      } else if (this.state.rxData["end-time-oid"] && this.state.values[`${this.state.rxData["end-time-oid"]}.val`]) {
        const c = new Date(this.state.values[`${this.state.rxData["end-time-oid"]}.val`]);
        Date.now() - c.getTime() > 0 && Date.now() - c.getTime() < 72e5 && (l.timeText = Os(c).fromNow()), l.fontSize = Math.round(l.wSize / 10);
      }
      l.timeText && !this._updateInterval ? this._updateInterval = setInterval(() => this.forceUpdate(), 3e4) : !l.timeText && this._updateInterval && (clearInterval(this._updateInterval), this._updateInterval = null);
      const u = y.jsxs("div", {
        style: {
          ...F.body,
          height: this.state.rxData.widgetTitle && !this.state.rxData.noCard && !h.widget.usedInWidget ? "calc(100% - 36px)" : "100%"
        },
        ref: this.refDiv,
        children: [
          y.jsx("style", {
            children: `
@keyframes vis-2-widgets-nils-fork-rotation {
    100% {
        transform: rotate(360deg);
    }
}
`
          }),
          l.wSize ? this.state.rxData.type === "dish" ? this.renderDishWasher(l) : this.renderWasher(l) : null
        ]
      });
      return this.state.rxData.noCard || h.widget.usedInWidget ? u : this.wrapContent(u);
    }
  };
});
export {
  __tla,
  Rs as default
};
