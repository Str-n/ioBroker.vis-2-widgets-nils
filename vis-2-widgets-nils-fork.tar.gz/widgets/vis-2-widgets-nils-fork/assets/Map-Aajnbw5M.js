import { o as e, t } from "./rolldown-runtime-C0FnF6B9.js";
import { B as n, D as r, E as i, F as a, I as o, S as s, g as c, j as l, k as u, y as d } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { H as f, I as p, L as m, P as h, dt as g, ft as _, it as ee, pt as v, st as te, tt as ne, u as re } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as y } from "./Generic-BOiMPpxz.js";
var ie = te(_(`path`, { d: `M7 14H5v5h5v-2H7zm-2-4h2V7h3V5H5zm12 7h-3v2h5v-5h-2zM14 5v2h3v3h2V5z` }), `Fullscreen`), b = t(((e3, t2) => {
  (function(n2, r2) {
    typeof e3 == `object` && t2 !== void 0 ? r2(e3) : typeof define == `function` && define.amd ? define([`exports`], r2) : (n2 = typeof globalThis < `u` ? globalThis : n2 || self, r2(n2.leaflet = {}));
  })(e3, (function(e4) {
    var t3 = `1.9.4`;
    function n2(e5) {
      for (var t4, n3 = 1, r3 = arguments.length, i3; n3 < r3; n3++) for (t4 in i3 = arguments[n3], i3) e5[t4] = i3[t4];
      return e5;
    }
    var r2 = Object.create || /* @__PURE__ */ (function() {
      function e5() {
      }
      return function(t4) {
        return e5.prototype = t4, new e5();
      };
    })();
    function i2(e5, t4) {
      var n3 = Array.prototype.slice;
      if (e5.bind) return e5.bind.apply(e5, n3.call(arguments, 1));
      var r3 = n3.call(arguments, 2);
      return function() {
        return e5.apply(t4, r3.length ? r3.concat(n3.call(arguments)) : arguments);
      };
    }
    var a2 = 0;
    function o2(e5) {
      return `_leaflet_id` in e5 || (e5._leaflet_id = ++a2), e5._leaflet_id;
    }
    function s2(e5, t4, n3) {
      var r3, i3, a3, o3 = function() {
        r3 = false, i3 && (i3 = (a3.apply(n3, i3), false));
      };
      return a3 = function() {
        r3 ? i3 = arguments : (e5.apply(n3, arguments), setTimeout(o3, t4), r3 = true);
      }, a3;
    }
    function c2(e5, t4, n3) {
      var r3 = t4[1], i3 = t4[0], a3 = r3 - i3;
      return e5 === r3 && n3 ? e5 : ((e5 - i3) % a3 + a3) % a3 + i3;
    }
    function l2() {
      return false;
    }
    function u2(e5, t4) {
      if (t4 === false) return e5;
      var n3 = 10 ** (t4 === void 0 ? 6 : t4);
      return Math.round(e5 * n3) / n3;
    }
    function d2(e5) {
      return e5.trim ? e5.trim() : e5.replace(/^\s+|\s+$/g, ``);
    }
    function f2(e5) {
      return d2(e5).split(/\s+/);
    }
    function p2(e5, t4) {
      for (var n3 in Object.prototype.hasOwnProperty.call(e5, `options`) || (e5.options = e5.options ? r2(e5.options) : {}), t4) e5.options[n3] = t4[n3];
      return e5.options;
    }
    function m2(e5, t4, n3) {
      var r3 = [];
      for (var i3 in e5) r3.push(encodeURIComponent(n3 ? i3.toUpperCase() : i3) + `=` + encodeURIComponent(e5[i3]));
      return (!t4 || t4.indexOf(`?`) === -1 ? `?` : `&`) + r3.join(`&`);
    }
    var h2 = /\{ *([\w_ -]+) *\}/g;
    function g2(e5, t4) {
      return e5.replace(h2, function(e6, n3) {
        var r3 = t4[n3];
        if (r3 === void 0) throw Error(`No value provided for variable ` + e6);
        return typeof r3 == `function` && (r3 = r3(t4)), r3;
      });
    }
    var _2 = Array.isArray || function(e5) {
      return Object.prototype.toString.call(e5) === `[object Array]`;
    };
    function ee2(e5, t4) {
      for (var n3 = 0; n3 < e5.length; n3++) if (e5[n3] === t4) return n3;
      return -1;
    }
    var v2 = `data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=`;
    function te2(e5) {
      return window[`webkit` + e5] || window[`moz` + e5] || window[`ms` + e5];
    }
    var ne2 = 0;
    function re2(e5) {
      var t4 = +/* @__PURE__ */ new Date(), n3 = Math.max(0, 16 - (t4 - ne2));
      return ne2 = t4 + n3, window.setTimeout(e5, n3);
    }
    var y2 = window.requestAnimationFrame || te2(`RequestAnimationFrame`) || re2, ie2 = window.cancelAnimationFrame || te2(`CancelAnimationFrame`) || te2(`CancelRequestAnimationFrame`) || function(e5) {
      window.clearTimeout(e5);
    };
    function b2(e5, t4, n3) {
      if (n3 && y2 === re2) e5.call(t4);
      else return y2.call(window, i2(e5, t4));
    }
    function x2(e5) {
      e5 && ie2.call(window, e5);
    }
    var ae2 = { __proto__: null, extend: n2, create: r2, bind: i2, get lastId() {
      return a2;
    }, stamp: o2, throttle: s2, wrapNum: c2, falseFn: l2, formatNum: u2, trim: d2, splitWords: f2, setOptions: p2, getParamString: m2, template: g2, isArray: _2, indexOf: ee2, emptyImageUrl: v2, requestFn: y2, cancelFn: ie2, requestAnimFrame: b2, cancelAnimFrame: x2 };
    function S2() {
    }
    S2.extend = function(e5) {
      var t4 = function() {
        p2(this), this.initialize && this.initialize.apply(this, arguments), this.callInitHooks();
      }, i3 = t4.__super__ = this.prototype, a3 = r2(i3);
      for (var o3 in a3.constructor = t4, t4.prototype = a3, this) Object.prototype.hasOwnProperty.call(this, o3) && o3 !== `prototype` && o3 !== `__super__` && (t4[o3] = this[o3]);
      return e5.statics && n2(t4, e5.statics), e5.includes && (oe2(e5.includes), n2.apply(null, [a3].concat(e5.includes))), n2(a3, e5), delete a3.statics, delete a3.includes, a3.options && (a3.options = i3.options ? r2(i3.options) : {}, n2(a3.options, e5.options)), a3._initHooks = [], a3.callInitHooks = function() {
        if (!this._initHooksCalled) {
          i3.callInitHooks && i3.callInitHooks.call(this), this._initHooksCalled = true;
          for (var e6 = 0, t5 = a3._initHooks.length; e6 < t5; e6++) a3._initHooks[e6].call(this);
        }
      }, t4;
    }, S2.include = function(e5) {
      var t4 = this.prototype.options;
      return n2(this.prototype, e5), e5.options && (this.prototype.options = t4, this.mergeOptions(e5.options)), this;
    }, S2.mergeOptions = function(e5) {
      return n2(this.prototype.options, e5), this;
    }, S2.addInitHook = function(e5) {
      var t4 = Array.prototype.slice.call(arguments, 1), n3 = typeof e5 == `function` ? e5 : function() {
        this[e5].apply(this, t4);
      };
      return this.prototype._initHooks = this.prototype._initHooks || [], this.prototype._initHooks.push(n3), this;
    };
    function oe2(e5) {
      if (!(typeof L > `u` || !L || !L.Mixin)) {
        e5 = _2(e5) ? e5 : [e5];
        for (var t4 = 0; t4 < e5.length; t4++) e5[t4] === L.Mixin.Events && console.warn(`Deprecated include of L.Mixin.Events: this property will be removed in future releases, please inherit from L.Evented instead.`, Error().stack);
      }
    }
    var C2 = { on: function(e5, t4, n3) {
      if (typeof e5 == `object`) for (var r3 in e5) this._on(r3, e5[r3], t4);
      else {
        e5 = f2(e5);
        for (var i3 = 0, a3 = e5.length; i3 < a3; i3++) this._on(e5[i3], t4, n3);
      }
      return this;
    }, off: function(e5, t4, n3) {
      if (!arguments.length) delete this._events;
      else if (typeof e5 == `object`) for (var r3 in e5) this._off(r3, e5[r3], t4);
      else {
        e5 = f2(e5);
        for (var i3 = arguments.length === 1, a3 = 0, o3 = e5.length; a3 < o3; a3++) i3 ? this._off(e5[a3]) : this._off(e5[a3], t4, n3);
      }
      return this;
    }, _on: function(e5, t4, n3, r3) {
      if (typeof t4 != `function`) {
        console.warn(`wrong listener type: ` + typeof t4);
        return;
      }
      if (this._listens(e5, t4, n3) === false) {
        n3 === this && (n3 = void 0);
        var i3 = { fn: t4, ctx: n3 };
        r3 && (i3.once = true), this._events = this._events || {}, this._events[e5] = this._events[e5] || [], this._events[e5].push(i3);
      }
    }, _off: function(e5, t4, n3) {
      var r3, i3, a3;
      if (this._events && (r3 = this._events[e5], r3)) {
        if (arguments.length === 1) {
          if (this._firingCount) for (i3 = 0, a3 = r3.length; i3 < a3; i3++) r3[i3].fn = l2;
          delete this._events[e5];
          return;
        }
        if (typeof t4 != `function`) {
          console.warn(`wrong listener type: ` + typeof t4);
          return;
        }
        var o3 = this._listens(e5, t4, n3);
        if (o3 !== false) {
          var s3 = r3[o3];
          this._firingCount && (s3.fn = l2, this._events[e5] = r3 = r3.slice()), r3.splice(o3, 1);
        }
      }
    }, fire: function(e5, t4, r3) {
      if (!this.listens(e5, r3)) return this;
      var i3 = n2({}, t4, { type: e5, target: this, sourceTarget: t4 && t4.sourceTarget || this });
      if (this._events) {
        var a3 = this._events[e5];
        if (a3) {
          this._firingCount = this._firingCount + 1 || 1;
          for (var o3 = 0, s3 = a3.length; o3 < s3; o3++) {
            var c3 = a3[o3], l3 = c3.fn;
            c3.once && this.off(e5, l3, c3.ctx), l3.call(c3.ctx || this, i3);
          }
          this._firingCount--;
        }
      }
      return r3 && this._propagateEvent(i3), this;
    }, listens: function(e5, t4, n3, r3) {
      typeof e5 != `string` && console.warn(`"string" type argument expected`);
      var i3 = t4;
      typeof t4 != `function` && (r3 = !!t4, i3 = void 0, n3 = void 0);
      var a3 = this._events && this._events[e5];
      if (a3 && a3.length && this._listens(e5, i3, n3) !== false) return true;
      if (r3) {
        for (var o3 in this._eventParents) if (this._eventParents[o3].listens(e5, t4, n3, r3)) return true;
      }
      return false;
    }, _listens: function(e5, t4, n3) {
      if (!this._events) return false;
      var r3 = this._events[e5] || [];
      if (!t4) return !!r3.length;
      n3 === this && (n3 = void 0);
      for (var i3 = 0, a3 = r3.length; i3 < a3; i3++) if (r3[i3].fn === t4 && r3[i3].ctx === n3) return i3;
      return false;
    }, once: function(e5, t4, n3) {
      if (typeof e5 == `object`) for (var r3 in e5) this._on(r3, e5[r3], t4, true);
      else {
        e5 = f2(e5);
        for (var i3 = 0, a3 = e5.length; i3 < a3; i3++) this._on(e5[i3], t4, n3, true);
      }
      return this;
    }, addEventParent: function(e5) {
      return this._eventParents = this._eventParents || {}, this._eventParents[o2(e5)] = e5, this;
    }, removeEventParent: function(e5) {
      return this._eventParents && delete this._eventParents[o2(e5)], this;
    }, _propagateEvent: function(e5) {
      for (var t4 in this._eventParents) this._eventParents[t4].fire(e5.type, n2({ layer: e5.target, propagatedFrom: e5.target }, e5), true);
    } };
    C2.addEventListener = C2.on, C2.removeEventListener = C2.clearAllEventListeners = C2.off, C2.addOneTimeEventListener = C2.once, C2.fireEvent = C2.fire, C2.hasEventListeners = C2.listens;
    var se2 = S2.extend(C2);
    function w2(e5, t4, n3) {
      this.x = n3 ? Math.round(e5) : e5, this.y = n3 ? Math.round(t4) : t4;
    }
    var ce2 = Math.trunc || function(e5) {
      return e5 > 0 ? Math.floor(e5) : Math.ceil(e5);
    };
    w2.prototype = { clone: function() {
      return new w2(this.x, this.y);
    }, add: function(e5) {
      return this.clone()._add(T2(e5));
    }, _add: function(e5) {
      return this.x += e5.x, this.y += e5.y, this;
    }, subtract: function(e5) {
      return this.clone()._subtract(T2(e5));
    }, _subtract: function(e5) {
      return this.x -= e5.x, this.y -= e5.y, this;
    }, divideBy: function(e5) {
      return this.clone()._divideBy(e5);
    }, _divideBy: function(e5) {
      return this.x /= e5, this.y /= e5, this;
    }, multiplyBy: function(e5) {
      return this.clone()._multiplyBy(e5);
    }, _multiplyBy: function(e5) {
      return this.x *= e5, this.y *= e5, this;
    }, scaleBy: function(e5) {
      return new w2(this.x * e5.x, this.y * e5.y);
    }, unscaleBy: function(e5) {
      return new w2(this.x / e5.x, this.y / e5.y);
    }, round: function() {
      return this.clone()._round();
    }, _round: function() {
      return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
    }, floor: function() {
      return this.clone()._floor();
    }, _floor: function() {
      return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this;
    }, ceil: function() {
      return this.clone()._ceil();
    }, _ceil: function() {
      return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this;
    }, trunc: function() {
      return this.clone()._trunc();
    }, _trunc: function() {
      return this.x = ce2(this.x), this.y = ce2(this.y), this;
    }, distanceTo: function(e5) {
      e5 = T2(e5);
      var t4 = e5.x - this.x, n3 = e5.y - this.y;
      return Math.sqrt(t4 * t4 + n3 * n3);
    }, equals: function(e5) {
      return e5 = T2(e5), e5.x === this.x && e5.y === this.y;
    }, contains: function(e5) {
      return e5 = T2(e5), Math.abs(e5.x) <= Math.abs(this.x) && Math.abs(e5.y) <= Math.abs(this.y);
    }, toString: function() {
      return `Point(` + u2(this.x) + `, ` + u2(this.y) + `)`;
    } };
    function T2(e5, t4, n3) {
      return e5 instanceof w2 ? e5 : _2(e5) ? new w2(e5[0], e5[1]) : e5 == null ? e5 : typeof e5 == `object` && `x` in e5 && `y` in e5 ? new w2(e5.x, e5.y) : new w2(e5, t4, n3);
    }
    function E2(e5, t4) {
      if (e5) for (var n3 = t4 ? [e5, t4] : e5, r3 = 0, i3 = n3.length; r3 < i3; r3++) this.extend(n3[r3]);
    }
    E2.prototype = { extend: function(e5) {
      var t4, n3;
      if (!e5) return this;
      if (e5 instanceof w2 || typeof e5[0] == `number` || `x` in e5) t4 = n3 = T2(e5);
      else if (e5 = D2(e5), t4 = e5.min, n3 = e5.max, !t4 || !n3) return this;
      return !this.min && !this.max ? (this.min = t4.clone(), this.max = n3.clone()) : (this.min.x = Math.min(t4.x, this.min.x), this.max.x = Math.max(n3.x, this.max.x), this.min.y = Math.min(t4.y, this.min.y), this.max.y = Math.max(n3.y, this.max.y)), this;
    }, getCenter: function(e5) {
      return T2((this.min.x + this.max.x) / 2, (this.min.y + this.max.y) / 2, e5);
    }, getBottomLeft: function() {
      return T2(this.min.x, this.max.y);
    }, getTopRight: function() {
      return T2(this.max.x, this.min.y);
    }, getTopLeft: function() {
      return this.min;
    }, getBottomRight: function() {
      return this.max;
    }, getSize: function() {
      return this.max.subtract(this.min);
    }, contains: function(e5) {
      var t4, n3;
      return e5 = typeof e5[0] == `number` || e5 instanceof w2 ? T2(e5) : D2(e5), e5 instanceof E2 ? (t4 = e5.min, n3 = e5.max) : t4 = n3 = e5, t4.x >= this.min.x && n3.x <= this.max.x && t4.y >= this.min.y && n3.y <= this.max.y;
    }, intersects: function(e5) {
      e5 = D2(e5);
      var t4 = this.min, n3 = this.max, r3 = e5.min, i3 = e5.max, a3 = i3.x >= t4.x && r3.x <= n3.x, o3 = i3.y >= t4.y && r3.y <= n3.y;
      return a3 && o3;
    }, overlaps: function(e5) {
      e5 = D2(e5);
      var t4 = this.min, n3 = this.max, r3 = e5.min, i3 = e5.max, a3 = i3.x > t4.x && r3.x < n3.x, o3 = i3.y > t4.y && r3.y < n3.y;
      return a3 && o3;
    }, isValid: function() {
      return !!(this.min && this.max);
    }, pad: function(e5) {
      var t4 = this.min, n3 = this.max, r3 = Math.abs(t4.x - n3.x) * e5, i3 = Math.abs(t4.y - n3.y) * e5;
      return D2(T2(t4.x - r3, t4.y - i3), T2(n3.x + r3, n3.y + i3));
    }, equals: function(e5) {
      return e5 ? (e5 = D2(e5), this.min.equals(e5.getTopLeft()) && this.max.equals(e5.getBottomRight())) : false;
    } };
    function D2(e5, t4) {
      return !e5 || e5 instanceof E2 ? e5 : new E2(e5, t4);
    }
    function O2(e5, t4) {
      if (e5) for (var n3 = t4 ? [e5, t4] : e5, r3 = 0, i3 = n3.length; r3 < i3; r3++) this.extend(n3[r3]);
    }
    O2.prototype = { extend: function(e5) {
      var t4 = this._southWest, n3 = this._northEast, r3, i3;
      if (e5 instanceof A2) r3 = e5, i3 = e5;
      else if (e5 instanceof O2) {
        if (r3 = e5._southWest, i3 = e5._northEast, !r3 || !i3) return this;
      } else return e5 ? this.extend(j2(e5) || k2(e5)) : this;
      return !t4 && !n3 ? (this._southWest = new A2(r3.lat, r3.lng), this._northEast = new A2(i3.lat, i3.lng)) : (t4.lat = Math.min(r3.lat, t4.lat), t4.lng = Math.min(r3.lng, t4.lng), n3.lat = Math.max(i3.lat, n3.lat), n3.lng = Math.max(i3.lng, n3.lng)), this;
    }, pad: function(e5) {
      var t4 = this._southWest, n3 = this._northEast, r3 = Math.abs(t4.lat - n3.lat) * e5, i3 = Math.abs(t4.lng - n3.lng) * e5;
      return new O2(new A2(t4.lat - r3, t4.lng - i3), new A2(n3.lat + r3, n3.lng + i3));
    }, getCenter: function() {
      return new A2((this._southWest.lat + this._northEast.lat) / 2, (this._southWest.lng + this._northEast.lng) / 2);
    }, getSouthWest: function() {
      return this._southWest;
    }, getNorthEast: function() {
      return this._northEast;
    }, getNorthWest: function() {
      return new A2(this.getNorth(), this.getWest());
    }, getSouthEast: function() {
      return new A2(this.getSouth(), this.getEast());
    }, getWest: function() {
      return this._southWest.lng;
    }, getSouth: function() {
      return this._southWest.lat;
    }, getEast: function() {
      return this._northEast.lng;
    }, getNorth: function() {
      return this._northEast.lat;
    }, contains: function(e5) {
      e5 = typeof e5[0] == `number` || e5 instanceof A2 || `lat` in e5 ? j2(e5) : k2(e5);
      var t4 = this._southWest, n3 = this._northEast, r3, i3;
      return e5 instanceof O2 ? (r3 = e5.getSouthWest(), i3 = e5.getNorthEast()) : r3 = i3 = e5, r3.lat >= t4.lat && i3.lat <= n3.lat && r3.lng >= t4.lng && i3.lng <= n3.lng;
    }, intersects: function(e5) {
      e5 = k2(e5);
      var t4 = this._southWest, n3 = this._northEast, r3 = e5.getSouthWest(), i3 = e5.getNorthEast(), a3 = i3.lat >= t4.lat && r3.lat <= n3.lat, o3 = i3.lng >= t4.lng && r3.lng <= n3.lng;
      return a3 && o3;
    }, overlaps: function(e5) {
      e5 = k2(e5);
      var t4 = this._southWest, n3 = this._northEast, r3 = e5.getSouthWest(), i3 = e5.getNorthEast(), a3 = i3.lat > t4.lat && r3.lat < n3.lat, o3 = i3.lng > t4.lng && r3.lng < n3.lng;
      return a3 && o3;
    }, toBBoxString: function() {
      return [this.getWest(), this.getSouth(), this.getEast(), this.getNorth()].join(`,`);
    }, equals: function(e5, t4) {
      return e5 ? (e5 = k2(e5), this._southWest.equals(e5.getSouthWest(), t4) && this._northEast.equals(e5.getNorthEast(), t4)) : false;
    }, isValid: function() {
      return !!(this._southWest && this._northEast);
    } };
    function k2(e5, t4) {
      return e5 instanceof O2 ? e5 : new O2(e5, t4);
    }
    function A2(e5, t4, n3) {
      if (isNaN(e5) || isNaN(t4)) throw Error(`Invalid LatLng object: (` + e5 + `, ` + t4 + `)`);
      this.lat = +e5, this.lng = +t4, n3 !== void 0 && (this.alt = +n3);
    }
    A2.prototype = { equals: function(e5, t4) {
      return e5 ? (e5 = j2(e5), Math.max(Math.abs(this.lat - e5.lat), Math.abs(this.lng - e5.lng)) <= (t4 === void 0 ? 1e-9 : t4)) : false;
    }, toString: function(e5) {
      return `LatLng(` + u2(this.lat, e5) + `, ` + u2(this.lng, e5) + `)`;
    }, distanceTo: function(e5) {
      return N2.distance(this, j2(e5));
    }, wrap: function() {
      return N2.wrapLatLng(this);
    }, toBounds: function(e5) {
      var t4 = 180 * e5 / 40075017, n3 = t4 / Math.cos(Math.PI / 180 * this.lat);
      return k2([this.lat - t4, this.lng - n3], [this.lat + t4, this.lng + n3]);
    }, clone: function() {
      return new A2(this.lat, this.lng, this.alt);
    } };
    function j2(e5, t4, n3) {
      return e5 instanceof A2 ? e5 : _2(e5) && typeof e5[0] != `object` ? e5.length === 3 ? new A2(e5[0], e5[1], e5[2]) : e5.length === 2 ? new A2(e5[0], e5[1]) : null : e5 == null ? e5 : typeof e5 == `object` && `lat` in e5 ? new A2(e5.lat, `lng` in e5 ? e5.lng : e5.lon, e5.alt) : t4 === void 0 ? null : new A2(e5, t4, n3);
    }
    var M2 = { latLngToPoint: function(e5, t4) {
      var n3 = this.projection.project(e5), r3 = this.scale(t4);
      return this.transformation._transform(n3, r3);
    }, pointToLatLng: function(e5, t4) {
      var n3 = this.scale(t4), r3 = this.transformation.untransform(e5, n3);
      return this.projection.unproject(r3);
    }, project: function(e5) {
      return this.projection.project(e5);
    }, unproject: function(e5) {
      return this.projection.unproject(e5);
    }, scale: function(e5) {
      return 256 * 2 ** e5;
    }, zoom: function(e5) {
      return Math.log(e5 / 256) / Math.LN2;
    }, getProjectedBounds: function(e5) {
      if (this.infinite) return null;
      var t4 = this.projection.bounds, n3 = this.scale(e5);
      return new E2(this.transformation.transform(t4.min, n3), this.transformation.transform(t4.max, n3));
    }, infinite: false, wrapLatLng: function(e5) {
      var t4 = this.wrapLng ? c2(e5.lng, this.wrapLng, true) : e5.lng, n3 = this.wrapLat ? c2(e5.lat, this.wrapLat, true) : e5.lat, r3 = e5.alt;
      return new A2(n3, t4, r3);
    }, wrapLatLngBounds: function(e5) {
      var t4 = e5.getCenter(), n3 = this.wrapLatLng(t4), r3 = t4.lat - n3.lat, i3 = t4.lng - n3.lng;
      if (r3 === 0 && i3 === 0) return e5;
      var a3 = e5.getSouthWest(), o3 = e5.getNorthEast();
      return new O2(new A2(a3.lat - r3, a3.lng - i3), new A2(o3.lat - r3, o3.lng - i3));
    } }, N2 = n2({}, M2, { wrapLng: [-180, 180], R: 6371e3, distance: function(e5, t4) {
      var n3 = Math.PI / 180, r3 = e5.lat * n3, i3 = t4.lat * n3, a3 = Math.sin((t4.lat - e5.lat) * n3 / 2), o3 = Math.sin((t4.lng - e5.lng) * n3 / 2), s3 = a3 * a3 + Math.cos(r3) * Math.cos(i3) * o3 * o3, c3 = 2 * Math.atan2(Math.sqrt(s3), Math.sqrt(1 - s3));
      return this.R * c3;
    } }), le2 = 6378137, ue2 = { R: le2, MAX_LATITUDE: 85.0511287798, project: function(e5) {
      var t4 = Math.PI / 180, n3 = this.MAX_LATITUDE, r3 = Math.max(Math.min(n3, e5.lat), -n3), i3 = Math.sin(r3 * t4);
      return new w2(this.R * e5.lng * t4, this.R * Math.log((1 + i3) / (1 - i3)) / 2);
    }, unproject: function(e5) {
      var t4 = 180 / Math.PI;
      return new A2((2 * Math.atan(Math.exp(e5.y / this.R)) - Math.PI / 2) * t4, e5.x * t4 / this.R);
    }, bounds: (function() {
      var e5 = le2 * Math.PI;
      return new E2([-e5, -e5], [e5, e5]);
    })() };
    function de2(e5, t4, n3, r3) {
      if (_2(e5)) {
        this._a = e5[0], this._b = e5[1], this._c = e5[2], this._d = e5[3];
        return;
      }
      this._a = e5, this._b = t4, this._c = n3, this._d = r3;
    }
    de2.prototype = { transform: function(e5, t4) {
      return this._transform(e5.clone(), t4);
    }, _transform: function(e5, t4) {
      return t4 || (t4 = 1), e5.x = t4 * (this._a * e5.x + this._b), e5.y = t4 * (this._c * e5.y + this._d), e5;
    }, untransform: function(e5, t4) {
      return t4 || (t4 = 1), new w2((e5.x / t4 - this._b) / this._a, (e5.y / t4 - this._d) / this._c);
    } };
    function fe2(e5, t4, n3, r3) {
      return new de2(e5, t4, n3, r3);
    }
    var pe2 = n2({}, N2, { code: `EPSG:3857`, projection: ue2, transformation: (function() {
      var e5 = 0.5 / (Math.PI * ue2.R);
      return fe2(e5, 0.5, -e5, 0.5);
    })() }), me2 = n2({}, pe2, { code: `EPSG:900913` });
    function he2(e5) {
      return document.createElementNS(`http://www.w3.org/2000/svg`, e5);
    }
    function ge2(e5, t4) {
      for (var n3 = ``, r3 = 0, i3, a3 = e5.length, o3, s3, c3; r3 < a3; r3++) {
        for (s3 = e5[r3], i3 = 0, o3 = s3.length; i3 < o3; i3++) c3 = s3[i3], n3 += (i3 ? `L` : `M`) + c3.x + ` ` + c3.y;
        n3 += t4 ? I.svg ? `z` : `x` : ``;
      }
      return n3 || `M0 0`;
    }
    var _e2 = document.documentElement.style, ve2 = `ActiveXObject` in window, ye2 = ve2 && !document.addEventListener, be2 = `msLaunchUri` in navigator && !(`documentMode` in document), xe2 = F(`webkit`), Se2 = F(`android`), Ce2 = F(`android 2`) || F(`android 3`), we2 = parseInt(/WebKit\/([0-9]+)|$/.exec(navigator.userAgent)[1], 10), Te2 = Se2 && F(`Google`) && we2 < 537 && !(`AudioNode` in window), Ee2 = !!window.opera, De2 = !be2 && F(`chrome`), Oe2 = F(`gecko`) && !xe2 && !Ee2 && !ve2, ke2 = !De2 && F(`safari`), P2 = F(`phantom`), Ae2 = `OTransition` in _e2, je2 = navigator.platform.indexOf(`Win`) === 0, Me2 = ve2 && `transition` in _e2, Ne2 = `WebKitCSSMatrix` in window && `m11` in new window.WebKitCSSMatrix() && !Ce2, Pe = `MozPerspective` in _e2, Fe = !window.L_DISABLE_3D && (Me2 || Ne2 || Pe) && !Ae2 && !P2, Ie = typeof orientation < `u` || F(`mobile`), Le = Ie && xe2, Re = Ie && Ne2, ze = !window.PointerEvent && window.MSPointerEvent, Be = !!(window.PointerEvent || ze), Ve = `ontouchstart` in window || !!window.TouchEvent, He = !window.L_NO_TOUCH && (Ve || Be), Ue = Ie && Ee2, We = Ie && Oe2, Ge = (window.devicePixelRatio || window.screen.deviceXDPI / window.screen.logicalXDPI) > 1, Ke = (function() {
      var e5 = false;
      try {
        var t4 = Object.defineProperty({}, "passive", { get: function() {
          e5 = true;
        } });
        window.addEventListener(`testPassiveEventSupport`, l2, t4), window.removeEventListener(`testPassiveEventSupport`, l2, t4);
      } catch {
      }
      return e5;
    })(), qe = (function() {
      return !!document.createElement(`canvas`).getContext;
    })(), Je = !!(document.createElementNS && he2(`svg`).createSVGRect), Ye = !!Je && (function() {
      var e5 = document.createElement(`div`);
      return e5.innerHTML = `<svg/>`, (e5.firstChild && e5.firstChild.namespaceURI) === `http://www.w3.org/2000/svg`;
    })(), Xe = !Je && (function() {
      try {
        var e5 = document.createElement(`div`);
        e5.innerHTML = `<v:shape adj="1"/>`;
        var t4 = e5.firstChild;
        return t4.style.behavior = `url(#default#VML)`, t4 && typeof t4.adj == `object`;
      } catch {
        return false;
      }
    })(), Ze = navigator.platform.indexOf(`Mac`) === 0, Qe = navigator.platform.indexOf(`Linux`) === 0;
    function F(e5) {
      return navigator.userAgent.toLowerCase().indexOf(e5) >= 0;
    }
    var I = { ie: ve2, ielt9: ye2, edge: be2, webkit: xe2, android: Se2, android23: Ce2, androidStock: Te2, opera: Ee2, chrome: De2, gecko: Oe2, safari: ke2, phantom: P2, opera12: Ae2, win: je2, ie3d: Me2, webkit3d: Ne2, gecko3d: Pe, any3d: Fe, mobile: Ie, mobileWebkit: Le, mobileWebkit3d: Re, msPointer: ze, pointer: Be, touch: He, touchNative: Ve, mobileOpera: Ue, mobileGecko: We, retina: Ge, passiveEvents: Ke, canvas: qe, svg: Je, vml: Xe, inlineSvg: Ye, mac: Ze, linux: Qe }, $e = I.msPointer ? `MSPointerDown` : `pointerdown`, et = I.msPointer ? `MSPointerMove` : `pointermove`, tt = I.msPointer ? `MSPointerUp` : `pointerup`, nt = I.msPointer ? `MSPointerCancel` : `pointercancel`, rt = { touchstart: $e, touchmove: et, touchend: tt, touchcancel: nt }, it = { touchstart: mt, touchmove: pt, touchend: pt, touchcancel: pt }, at = {}, ot = false;
    function st(e5, t4, n3) {
      return t4 === `touchstart` && ft(), it[t4] ? (n3 = it[t4].bind(this, n3), e5.addEventListener(rt[t4], n3, false), n3) : (console.warn(`wrong event specified:`, t4), l2);
    }
    function ct(e5, t4, n3) {
      if (!rt[t4]) {
        console.warn(`wrong event specified:`, t4);
        return;
      }
      e5.removeEventListener(rt[t4], n3, false);
    }
    function lt(e5) {
      at[e5.pointerId] = e5;
    }
    function ut(e5) {
      at[e5.pointerId] && (at[e5.pointerId] = e5);
    }
    function dt(e5) {
      delete at[e5.pointerId];
    }
    function ft() {
      ot || (ot = (document.addEventListener($e, lt, true), document.addEventListener(et, ut, true), document.addEventListener(tt, dt, true), document.addEventListener(nt, dt, true), true));
    }
    function pt(e5, t4) {
      if (t4.pointerType !== (t4.MSPOINTER_TYPE_MOUSE || `mouse`)) {
        for (var n3 in t4.touches = [], at) t4.touches.push(at[n3]);
        t4.changedTouches = [t4], e5(t4);
      }
    }
    function mt(e5, t4) {
      t4.MSPOINTER_TYPE_TOUCH && t4.pointerType === t4.MSPOINTER_TYPE_TOUCH && q(t4), pt(e5, t4);
    }
    function ht(e5) {
      var t4 = {}, n3, r3;
      for (r3 in e5) n3 = e5[r3], t4[r3] = n3 && n3.bind ? n3.bind(e5) : n3;
      return e5 = t4, t4.type = `dblclick`, t4.detail = 2, t4.isTrusted = false, t4._simulated = true, t4;
    }
    var gt = 200;
    function _t(e5, t4) {
      e5.addEventListener(`dblclick`, t4);
      var n3 = 0, r3;
      function i3(e6) {
        if (e6.detail !== 1) {
          r3 = e6.detail;
          return;
        }
        if (!(e6.pointerType === `mouse` || e6.sourceCapabilities && !e6.sourceCapabilities.firesTouchEvents)) {
          var i4 = tn(e6);
          if (!i4.some(function(e7) {
            return e7 instanceof HTMLLabelElement && e7.attributes.for;
          }) || i4.some(function(e7) {
            return e7 instanceof HTMLInputElement || e7 instanceof HTMLSelectElement;
          })) {
            var a3 = Date.now();
            a3 - n3 <= gt ? (r3++, r3 === 2 && t4(ht(e6))) : r3 = 1, n3 = a3;
          }
        }
      }
      return e5.addEventListener(`click`, i3), { dblclick: t4, simDblclick: i3 };
    }
    function vt(e5, t4) {
      e5.removeEventListener(`dblclick`, t4.dblclick), e5.removeEventListener(`click`, t4.simDblclick);
    }
    var yt = jt([`transform`, `webkitTransform`, `OTransform`, `MozTransform`, `msTransform`]), bt = jt([`webkitTransition`, `transition`, `OTransition`, `MozTransition`, `msTransition`]), xt = bt === `webkitTransition` || bt === `OTransition` ? bt + `End` : `transitionend`;
    function St(e5) {
      return typeof e5 == `string` ? document.getElementById(e5) : e5;
    }
    function Ct(e5, t4) {
      var n3 = e5.style[t4] || e5.currentStyle && e5.currentStyle[t4];
      if ((!n3 || n3 === `auto`) && document.defaultView) {
        var r3 = document.defaultView.getComputedStyle(e5, null);
        n3 = r3 ? r3[t4] : null;
      }
      return n3 === `auto` ? null : n3;
    }
    function R(e5, t4, n3) {
      var r3 = document.createElement(e5);
      return r3.className = t4 || ``, n3 && n3.appendChild(r3), r3;
    }
    function z(e5) {
      var t4 = e5.parentNode;
      t4 && t4.removeChild(e5);
    }
    function wt(e5) {
      for (; e5.firstChild; ) e5.removeChild(e5.firstChild);
    }
    function Tt(e5) {
      var t4 = e5.parentNode;
      t4 && t4.lastChild !== e5 && t4.appendChild(e5);
    }
    function Et(e5) {
      var t4 = e5.parentNode;
      t4 && t4.firstChild !== e5 && t4.insertBefore(e5, t4.firstChild);
    }
    function Dt(e5, t4) {
      if (e5.classList !== void 0) return e5.classList.contains(t4);
      var n3 = kt(e5);
      return n3.length > 0 && RegExp(`(^|\\s)` + t4 + `(\\s|$)`).test(n3);
    }
    function B(e5, t4) {
      if (e5.classList !== void 0) for (var n3 = f2(t4), r3 = 0, i3 = n3.length; r3 < i3; r3++) e5.classList.add(n3[r3]);
      else if (!Dt(e5, t4)) {
        var a3 = kt(e5);
        Ot(e5, (a3 ? a3 + ` ` : ``) + t4);
      }
    }
    function V(e5, t4) {
      e5.classList === void 0 ? Ot(e5, d2((` ` + kt(e5) + ` `).replace(` ` + t4 + ` `, ` `))) : e5.classList.remove(t4);
    }
    function Ot(e5, t4) {
      e5.className.baseVal === void 0 ? e5.className = t4 : e5.className.baseVal = t4;
    }
    function kt(e5) {
      return e5.correspondingElement && (e5 = e5.correspondingElement), e5.className.baseVal === void 0 ? e5.className : e5.className.baseVal;
    }
    function H(e5, t4) {
      `opacity` in e5.style ? e5.style.opacity = t4 : `filter` in e5.style && At(e5, t4);
    }
    function At(e5, t4) {
      var n3 = false, r3 = `DXImageTransform.Microsoft.Alpha`;
      try {
        n3 = e5.filters.item(r3);
      } catch {
        if (t4 === 1) return;
      }
      t4 = Math.round(t4 * 100), n3 ? (n3.Enabled = t4 !== 100, n3.Opacity = t4) : e5.style.filter += ` progid:` + r3 + `(opacity=` + t4 + `)`;
    }
    function jt(e5) {
      for (var t4 = document.documentElement.style, n3 = 0; n3 < e5.length; n3++) if (e5[n3] in t4) return e5[n3];
      return false;
    }
    function Mt(e5, t4, n3) {
      var r3 = t4 || new w2(0, 0);
      e5.style[yt] = (I.ie3d ? `translate(` + r3.x + `px,` + r3.y + `px)` : `translate3d(` + r3.x + `px,` + r3.y + `px,0)`) + (n3 ? ` scale(` + n3 + `)` : ``);
    }
    function U(e5, t4) {
      e5._leaflet_pos = t4, I.any3d ? Mt(e5, t4) : (e5.style.left = t4.x + `px`, e5.style.top = t4.y + `px`);
    }
    function Nt(e5) {
      return e5._leaflet_pos || new w2(0, 0);
    }
    var Pt, Ft, It;
    if (`onselectstart` in document) Pt = function() {
      W(window, `selectstart`, q);
    }, Ft = function() {
      K(window, `selectstart`, q);
    };
    else {
      var Lt = jt([`userSelect`, `WebkitUserSelect`, `OUserSelect`, `MozUserSelect`, `msUserSelect`]);
      Pt = function() {
        if (Lt) {
          var e5 = document.documentElement.style;
          It = e5[Lt], e5[Lt] = `none`;
        }
      }, Ft = function() {
        Lt && (document.documentElement.style[Lt] = It, It = void 0);
      };
    }
    function Rt() {
      W(window, `dragstart`, q);
    }
    function zt() {
      K(window, `dragstart`, q);
    }
    var Bt, Vt;
    function Ht(e5) {
      for (; e5.tabIndex === -1; ) e5 = e5.parentNode;
      e5.style && (Ut(), Bt = e5, Vt = e5.style.outlineStyle, e5.style.outlineStyle = `none`, W(window, `keydown`, Ut));
    }
    function Ut() {
      Bt && (Bt.style.outlineStyle = Vt, Bt = void 0, Vt = void 0, K(window, `keydown`, Ut));
    }
    function Wt(e5) {
      do
        e5 = e5.parentNode;
      while ((!e5.offsetWidth || !e5.offsetHeight) && e5 !== document.body);
      return e5;
    }
    function Gt(e5) {
      var t4 = e5.getBoundingClientRect();
      return { x: t4.width / e5.offsetWidth || 1, y: t4.height / e5.offsetHeight || 1, boundingClientRect: t4 };
    }
    var Kt = { __proto__: null, TRANSFORM: yt, TRANSITION: bt, TRANSITION_END: xt, get: St, getStyle: Ct, create: R, remove: z, empty: wt, toFront: Tt, toBack: Et, hasClass: Dt, addClass: B, removeClass: V, setClass: Ot, getClass: kt, setOpacity: H, testProp: jt, setTransform: Mt, setPosition: U, getPosition: Nt, get disableTextSelection() {
      return Pt;
    }, get enableTextSelection() {
      return Ft;
    }, disableImageDrag: Rt, enableImageDrag: zt, preventOutline: Ht, restoreOutline: Ut, getSizedParentNode: Wt, getScale: Gt };
    function W(e5, t4, n3, r3) {
      if (t4 && typeof t4 == `object`) for (var i3 in t4) Yt(e5, i3, t4[i3], n3);
      else {
        t4 = f2(t4);
        for (var a3 = 0, o3 = t4.length; a3 < o3; a3++) Yt(e5, t4[a3], n3, r3);
      }
      return this;
    }
    var G = `_leaflet_events`;
    function K(e5, t4, n3, r3) {
      if (arguments.length === 1) qt(e5), delete e5[G];
      else if (t4 && typeof t4 == `object`) for (var i3 in t4) Xt(e5, i3, t4[i3], n3);
      else if (t4 = f2(t4), arguments.length === 2) qt(e5, function(e6) {
        return ee2(t4, e6) !== -1;
      });
      else for (var a3 = 0, o3 = t4.length; a3 < o3; a3++) Xt(e5, t4[a3], n3, r3);
      return this;
    }
    function qt(e5, t4) {
      for (var n3 in e5[G]) {
        var r3 = n3.split(/\d/)[0];
        (!t4 || t4(r3)) && Xt(e5, r3, null, null, n3);
      }
    }
    var Jt = { mouseenter: `mouseover`, mouseleave: `mouseout`, wheel: !(`onwheel` in window) && `mousewheel` };
    function Yt(e5, t4, n3, r3) {
      var i3 = t4 + o2(n3) + (r3 ? `_` + o2(r3) : ``);
      if (e5[G] && e5[G][i3]) return this;
      var a3 = function(t5) {
        return n3.call(r3 || e5, t5 || window.event);
      }, s3 = a3;
      !I.touchNative && I.pointer && t4.indexOf(`touch`) === 0 ? a3 = st(e5, t4, a3) : I.touch && t4 === `dblclick` ? a3 = _t(e5, a3) : `addEventListener` in e5 ? t4 === `touchstart` || t4 === `touchmove` || t4 === `wheel` || t4 === `mousewheel` ? e5.addEventListener(Jt[t4] || t4, a3, I.passiveEvents ? { passive: false } : false) : t4 === `mouseenter` || t4 === `mouseleave` ? (a3 = function(t5) {
        t5 || (t5 = window.event), on(e5, t5) && s3(t5);
      }, e5.addEventListener(Jt[t4], a3, false)) : e5.addEventListener(t4, s3, false) : e5.attachEvent(`on` + t4, a3), e5[G] = e5[G] || {}, e5[G][i3] = a3;
    }
    function Xt(e5, t4, n3, r3, i3) {
      i3 || (i3 = t4 + o2(n3) + (r3 ? `_` + o2(r3) : ``));
      var a3 = e5[G] && e5[G][i3];
      if (!a3) return this;
      !I.touchNative && I.pointer && t4.indexOf(`touch`) === 0 ? ct(e5, t4, a3) : I.touch && t4 === `dblclick` ? vt(e5, a3) : `removeEventListener` in e5 ? e5.removeEventListener(Jt[t4] || t4, a3, false) : e5.detachEvent(`on` + t4, a3), e5[G][i3] = null;
    }
    function Zt(e5) {
      return e5.stopPropagation ? e5.stopPropagation() : e5.originalEvent ? e5.originalEvent._stopped = true : e5.cancelBubble = true, this;
    }
    function Qt(e5) {
      return Yt(e5, `wheel`, Zt), this;
    }
    function $t(e5) {
      return W(e5, `mousedown touchstart dblclick contextmenu`, Zt), e5._leaflet_disable_click = true, this;
    }
    function q(e5) {
      return e5.preventDefault ? e5.preventDefault() : e5.returnValue = false, this;
    }
    function en(e5) {
      return q(e5), Zt(e5), this;
    }
    function tn(e5) {
      if (e5.composedPath) return e5.composedPath();
      for (var t4 = [], n3 = e5.target; n3; ) t4.push(n3), n3 = n3.parentNode;
      return t4;
    }
    function nn(e5, t4) {
      if (!t4) return new w2(e5.clientX, e5.clientY);
      var n3 = Gt(t4), r3 = n3.boundingClientRect;
      return new w2((e5.clientX - r3.left) / n3.x - t4.clientLeft, (e5.clientY - r3.top) / n3.y - t4.clientTop);
    }
    var rn = I.linux && I.chrome ? window.devicePixelRatio : I.mac ? window.devicePixelRatio * 3 : window.devicePixelRatio > 0 ? 2 * window.devicePixelRatio : 1;
    function an(e5) {
      return I.edge ? e5.wheelDeltaY / 2 : e5.deltaY && e5.deltaMode === 0 ? -e5.deltaY / rn : e5.deltaY && e5.deltaMode === 1 ? -e5.deltaY * 20 : e5.deltaY && e5.deltaMode === 2 ? -e5.deltaY * 60 : e5.deltaX || e5.deltaZ ? 0 : e5.wheelDelta ? (e5.wheelDeltaY || e5.wheelDelta) / 2 : e5.detail && Math.abs(e5.detail) < 32765 ? -e5.detail * 20 : e5.detail ? e5.detail / -32765 * 60 : 0;
    }
    function on(e5, t4) {
      var n3 = t4.relatedTarget;
      if (!n3) return true;
      try {
        for (; n3 && n3 !== e5; ) n3 = n3.parentNode;
      } catch {
        return false;
      }
      return n3 !== e5;
    }
    var sn = { __proto__: null, on: W, off: K, stopPropagation: Zt, disableScrollPropagation: Qt, disableClickPropagation: $t, preventDefault: q, stop: en, getPropagationPath: tn, getMousePosition: nn, getWheelDelta: an, isExternalTarget: on, addListener: W, removeListener: K }, cn = se2.extend({ run: function(e5, t4, n3, r3) {
      this.stop(), this._el = e5, this._inProgress = true, this._duration = n3 || 0.25, this._easeOutPower = 1 / Math.max(r3 || 0.5, 0.2), this._startPos = Nt(e5), this._offset = t4.subtract(this._startPos), this._startTime = +/* @__PURE__ */ new Date(), this.fire(`start`), this._animate();
    }, stop: function() {
      this._inProgress && (this._step(true), this._complete());
    }, _animate: function() {
      this._animId = b2(this._animate, this), this._step();
    }, _step: function(e5) {
      var t4 = +/* @__PURE__ */ new Date() - this._startTime, n3 = this._duration * 1e3;
      t4 < n3 ? this._runFrame(this._easeOut(t4 / n3), e5) : (this._runFrame(1), this._complete());
    }, _runFrame: function(e5, t4) {
      var n3 = this._startPos.add(this._offset.multiplyBy(e5));
      t4 && n3._round(), U(this._el, n3), this.fire(`step`);
    }, _complete: function() {
      x2(this._animId), this._inProgress = false, this.fire(`end`);
    }, _easeOut: function(e5) {
      return 1 - (1 - e5) ** this._easeOutPower;
    } }), J = se2.extend({ options: { crs: pe2, center: void 0, zoom: void 0, minZoom: void 0, maxZoom: void 0, layers: [], maxBounds: void 0, renderer: void 0, zoomAnimation: true, zoomAnimationThreshold: 4, fadeAnimation: true, markerZoomAnimation: true, transform3DLimit: 8388608, zoomSnap: 1, zoomDelta: 1, trackResize: true }, initialize: function(e5, t4) {
      t4 = p2(this, t4), this._handlers = [], this._layers = {}, this._zoomBoundLayers = {}, this._sizeChanged = true, this._initContainer(e5), this._initLayout(), this._onResize = i2(this._onResize, this), this._initEvents(), t4.maxBounds && this.setMaxBounds(t4.maxBounds), t4.zoom !== void 0 && (this._zoom = this._limitZoom(t4.zoom)), t4.center && t4.zoom !== void 0 && this.setView(j2(t4.center), t4.zoom, { reset: true }), this.callInitHooks(), this._zoomAnimated = bt && I.any3d && !I.mobileOpera && this.options.zoomAnimation, this._zoomAnimated && (this._createAnimProxy(), W(this._proxy, xt, this._catchTransitionEnd, this)), this._addLayers(this.options.layers);
    }, setView: function(e5, t4, r3) {
      return t4 = t4 === void 0 ? this._zoom : this._limitZoom(t4), e5 = this._limitCenter(j2(e5), t4, this.options.maxBounds), r3 || (r3 = {}), this._stop(), this._loaded && !r3.reset && r3 !== true && (r3.animate !== void 0 && (r3.zoom = n2({ animate: r3.animate }, r3.zoom), r3.pan = n2({ animate: r3.animate, duration: r3.duration }, r3.pan)), this._zoom === t4 ? this._tryAnimatedPan(e5, r3.pan) : this._tryAnimatedZoom && this._tryAnimatedZoom(e5, t4, r3.zoom)) ? (clearTimeout(this._sizeTimer), this) : (this._resetView(e5, t4, r3.pan && r3.pan.noMoveStart), this);
    }, setZoom: function(e5, t4) {
      return this._loaded ? this.setView(this.getCenter(), e5, { zoom: t4 }) : (this._zoom = e5, this);
    }, zoomIn: function(e5, t4) {
      return e5 || (e5 = I.any3d ? this.options.zoomDelta : 1), this.setZoom(this._zoom + e5, t4);
    }, zoomOut: function(e5, t4) {
      return e5 || (e5 = I.any3d ? this.options.zoomDelta : 1), this.setZoom(this._zoom - e5, t4);
    }, setZoomAround: function(e5, t4, n3) {
      var r3 = this.getZoomScale(t4), i3 = this.getSize().divideBy(2), a3 = (e5 instanceof w2 ? e5 : this.latLngToContainerPoint(e5)).subtract(i3).multiplyBy(1 - 1 / r3), o3 = this.containerPointToLatLng(i3.add(a3));
      return this.setView(o3, t4, { zoom: n3 });
    }, _getBoundsCenterZoom: function(e5, t4) {
      t4 || (t4 = {}), e5 = e5.getBounds ? e5.getBounds() : k2(e5);
      var n3 = T2(t4.paddingTopLeft || t4.padding || [0, 0]), r3 = T2(t4.paddingBottomRight || t4.padding || [0, 0]), i3 = this.getBoundsZoom(e5, false, n3.add(r3));
      if (i3 = typeof t4.maxZoom == `number` ? Math.min(t4.maxZoom, i3) : i3, i3 === 1 / 0) return { center: e5.getCenter(), zoom: i3 };
      var a3 = r3.subtract(n3).divideBy(2), o3 = this.project(e5.getSouthWest(), i3), s3 = this.project(e5.getNorthEast(), i3);
      return { center: this.unproject(o3.add(s3).divideBy(2).add(a3), i3), zoom: i3 };
    }, fitBounds: function(e5, t4) {
      if (e5 = k2(e5), !e5.isValid()) throw Error(`Bounds are not valid.`);
      var n3 = this._getBoundsCenterZoom(e5, t4);
      return this.setView(n3.center, n3.zoom, t4);
    }, fitWorld: function(e5) {
      return this.fitBounds([[-90, -180], [90, 180]], e5);
    }, panTo: function(e5, t4) {
      return this.setView(e5, this._zoom, { pan: t4 });
    }, panBy: function(e5, t4) {
      if (e5 = T2(e5).round(), t4 || (t4 = {}), !e5.x && !e5.y) return this.fire(`moveend`);
      if (t4.animate !== true && !this.getSize().contains(e5)) return this._resetView(this.unproject(this.project(this.getCenter()).add(e5)), this.getZoom()), this;
      if (this._panAnim || (this._panAnim = new cn(), this._panAnim.on({ step: this._onPanTransitionStep, end: this._onPanTransitionEnd }, this)), t4.noMoveStart || this.fire(`movestart`), t4.animate !== false) {
        B(this._mapPane, `leaflet-pan-anim`);
        var n3 = this._getMapPanePos().subtract(e5).round();
        this._panAnim.run(this._mapPane, n3, t4.duration || 0.25, t4.easeLinearity);
      } else this._rawPanBy(e5), this.fire(`move`).fire(`moveend`);
      return this;
    }, flyTo: function(e5, t4, n3) {
      if (n3 || (n3 = {}), n3.animate === false || !I.any3d) return this.setView(e5, t4, n3);
      this._stop();
      var r3 = this.project(this.getCenter()), i3 = this.project(e5), a3 = this.getSize(), o3 = this._zoom;
      e5 = j2(e5), t4 = t4 === void 0 ? o3 : t4;
      var s3 = Math.max(a3.x, a3.y), c3 = s3 * this.getZoomScale(o3, t4), l3 = i3.distanceTo(r3) || 1, u3 = 1.42, d3 = u3 * u3;
      function f3(e6) {
        var t5 = e6 ? -1 : 1, n4 = e6 ? c3 : s3, r4 = (c3 * c3 - s3 * s3 + t5 * d3 * d3 * l3 * l3) / (2 * n4 * d3 * l3), i4 = Math.sqrt(r4 * r4 + 1) - r4;
        return i4 < 1e-9 ? -18 : Math.log(i4);
      }
      function p3(e6) {
        return (Math.exp(e6) - Math.exp(-e6)) / 2;
      }
      function m3(e6) {
        return (Math.exp(e6) + Math.exp(-e6)) / 2;
      }
      function h3(e6) {
        return p3(e6) / m3(e6);
      }
      var g3 = f3(0);
      function _3(e6) {
        return s3 * (m3(g3) / m3(g3 + u3 * e6));
      }
      function ee3(e6) {
        return s3 * (m3(g3) * h3(g3 + u3 * e6) - p3(g3)) / d3;
      }
      function v3(e6) {
        return 1 - (1 - e6) ** 1.5;
      }
      var te3 = Date.now(), ne3 = (f3(1) - g3) / u3, re3 = n3.duration ? 1e3 * n3.duration : 1e3 * ne3 * 0.8;
      function y3() {
        var n4 = (Date.now() - te3) / re3, a4 = v3(n4) * ne3;
        n4 <= 1 ? (this._flyToFrame = b2(y3, this), this._move(this.unproject(r3.add(i3.subtract(r3).multiplyBy(ee3(a4) / l3)), o3), this.getScaleZoom(s3 / _3(a4), o3), { flyTo: true })) : this._move(e5, t4)._moveEnd(true);
      }
      return this._moveStart(true, n3.noMoveStart), y3.call(this), this;
    }, flyToBounds: function(e5, t4) {
      var n3 = this._getBoundsCenterZoom(e5, t4);
      return this.flyTo(n3.center, n3.zoom, t4);
    }, setMaxBounds: function(e5) {
      return e5 = k2(e5), this.listens(`moveend`, this._panInsideMaxBounds) && this.off(`moveend`, this._panInsideMaxBounds), e5.isValid() ? (this.options.maxBounds = e5, this._loaded && this._panInsideMaxBounds(), this.on(`moveend`, this._panInsideMaxBounds)) : (this.options.maxBounds = null, this);
    }, setMinZoom: function(e5) {
      var t4 = this.options.minZoom;
      return this.options.minZoom = e5, this._loaded && t4 !== e5 && (this.fire(`zoomlevelschange`), this.getZoom() < this.options.minZoom) ? this.setZoom(e5) : this;
    }, setMaxZoom: function(e5) {
      var t4 = this.options.maxZoom;
      return this.options.maxZoom = e5, this._loaded && t4 !== e5 && (this.fire(`zoomlevelschange`), this.getZoom() > this.options.maxZoom) ? this.setZoom(e5) : this;
    }, panInsideBounds: function(e5, t4) {
      this._enforcingBounds = true;
      var n3 = this.getCenter(), r3 = this._limitCenter(n3, this._zoom, k2(e5));
      return n3.equals(r3) || this.panTo(r3, t4), this._enforcingBounds = false, this;
    }, panInside: function(e5, t4) {
      t4 || (t4 = {});
      var n3 = T2(t4.paddingTopLeft || t4.padding || [0, 0]), r3 = T2(t4.paddingBottomRight || t4.padding || [0, 0]), i3 = this.project(this.getCenter()), a3 = this.project(e5), o3 = this.getPixelBounds(), s3 = D2([o3.min.add(n3), o3.max.subtract(r3)]), c3 = s3.getSize();
      if (!s3.contains(a3)) {
        this._enforcingBounds = true;
        var l3 = a3.subtract(s3.getCenter()), u3 = s3.extend(a3).getSize().subtract(c3);
        i3.x += l3.x < 0 ? -u3.x : u3.x, i3.y += l3.y < 0 ? -u3.y : u3.y, this.panTo(this.unproject(i3), t4), this._enforcingBounds = false;
      }
      return this;
    }, invalidateSize: function(e5) {
      if (!this._loaded) return this;
      e5 = n2({ animate: false, pan: true }, e5 === true ? { animate: true } : e5);
      var t4 = this.getSize();
      this._sizeChanged = true, this._lastCenter = null;
      var r3 = this.getSize(), a3 = t4.divideBy(2).round(), o3 = r3.divideBy(2).round(), s3 = a3.subtract(o3);
      return !s3.x && !s3.y ? this : (e5.animate && e5.pan ? this.panBy(s3) : (e5.pan && this._rawPanBy(s3), this.fire(`move`), e5.debounceMoveend ? (clearTimeout(this._sizeTimer), this._sizeTimer = setTimeout(i2(this.fire, this, `moveend`), 200)) : this.fire(`moveend`)), this.fire(`resize`, { oldSize: t4, newSize: r3 }));
    }, stop: function() {
      return this.setZoom(this._limitZoom(this._zoom)), this.options.zoomSnap || this.fire(`viewreset`), this._stop();
    }, locate: function(e5) {
      if (e5 = this._locateOptions = n2({ timeout: 1e4, watch: false }, e5), !(`geolocation` in navigator)) return this._handleGeolocationError({ code: 0, message: `Geolocation not supported.` }), this;
      var t4 = i2(this._handleGeolocationResponse, this), r3 = i2(this._handleGeolocationError, this);
      return e5.watch ? this._locationWatchId = navigator.geolocation.watchPosition(t4, r3, e5) : navigator.geolocation.getCurrentPosition(t4, r3, e5), this;
    }, stopLocate: function() {
      return navigator.geolocation && navigator.geolocation.clearWatch && navigator.geolocation.clearWatch(this._locationWatchId), this._locateOptions && (this._locateOptions.setView = false), this;
    }, _handleGeolocationError: function(e5) {
      if (this._container._leaflet_id) {
        var t4 = e5.code, n3 = e5.message || (t4 === 1 ? `permission denied` : t4 === 2 ? `position unavailable` : `timeout`);
        this._locateOptions.setView && !this._loaded && this.fitWorld(), this.fire(`locationerror`, { code: t4, message: `Geolocation error: ` + n3 + `.` });
      }
    }, _handleGeolocationResponse: function(e5) {
      if (this._container._leaflet_id) {
        var t4 = e5.coords.latitude, n3 = e5.coords.longitude, r3 = new A2(t4, n3), i3 = r3.toBounds(e5.coords.accuracy * 2), a3 = this._locateOptions;
        if (a3.setView) {
          var o3 = this.getBoundsZoom(i3);
          this.setView(r3, a3.maxZoom ? Math.min(o3, a3.maxZoom) : o3);
        }
        var s3 = { latlng: r3, bounds: i3, timestamp: e5.timestamp };
        for (var c3 in e5.coords) typeof e5.coords[c3] == `number` && (s3[c3] = e5.coords[c3]);
        this.fire(`locationfound`, s3);
      }
    }, addHandler: function(e5, t4) {
      if (!t4) return this;
      var n3 = this[e5] = new t4(this);
      return this._handlers.push(n3), this.options[e5] && n3.enable(), this;
    }, remove: function() {
      if (this._initEvents(true), this.options.maxBounds && this.off(`moveend`, this._panInsideMaxBounds), this._containerId !== this._container._leaflet_id) throw Error(`Map container is being reused by another instance`);
      try {
        delete this._container._leaflet_id, delete this._containerId;
      } catch {
        this._container._leaflet_id = void 0, this._containerId = void 0;
      }
      for (var e5 in this._locationWatchId !== void 0 && this.stopLocate(), this._stop(), z(this._mapPane), this._clearControlPos && this._clearControlPos(), this._resizeRequest && (this._resizeRequest = (x2(this._resizeRequest), null)), this._clearHandlers(), this._loaded && this.fire(`unload`), this._layers) this._layers[e5].remove();
      for (e5 in this._panes) z(this._panes[e5]);
      return this._layers = [], this._panes = [], delete this._mapPane, delete this._renderer, this;
    }, createPane: function(e5, t4) {
      var n3 = R(`div`, `leaflet-pane` + (e5 ? ` leaflet-` + e5.replace(`Pane`, ``) + `-pane` : ``), t4 || this._mapPane);
      return e5 && (this._panes[e5] = n3), n3;
    }, getCenter: function() {
      return this._checkIfLoaded(), this._lastCenter && !this._moved() ? this._lastCenter.clone() : this.layerPointToLatLng(this._getCenterLayerPoint());
    }, getZoom: function() {
      return this._zoom;
    }, getBounds: function() {
      var e5 = this.getPixelBounds();
      return new O2(this.unproject(e5.getBottomLeft()), this.unproject(e5.getTopRight()));
    }, getMinZoom: function() {
      return this.options.minZoom === void 0 ? this._layersMinZoom || 0 : this.options.minZoom;
    }, getMaxZoom: function() {
      return this.options.maxZoom === void 0 ? this._layersMaxZoom === void 0 ? 1 / 0 : this._layersMaxZoom : this.options.maxZoom;
    }, getBoundsZoom: function(e5, t4, n3) {
      e5 = k2(e5), n3 = T2(n3 || [0, 0]);
      var r3 = this.getZoom() || 0, i3 = this.getMinZoom(), a3 = this.getMaxZoom(), o3 = e5.getNorthWest(), s3 = e5.getSouthEast(), c3 = this.getSize().subtract(n3), l3 = D2(this.project(s3, r3), this.project(o3, r3)).getSize(), u3 = I.any3d ? this.options.zoomSnap : 1, d3 = c3.x / l3.x, f3 = c3.y / l3.y, p3 = t4 ? Math.max(d3, f3) : Math.min(d3, f3);
      return r3 = this.getScaleZoom(p3, r3), u3 && (r3 = Math.round(r3 / (u3 / 100)) * (u3 / 100), r3 = t4 ? Math.ceil(r3 / u3) * u3 : Math.floor(r3 / u3) * u3), Math.max(i3, Math.min(a3, r3));
    }, getSize: function() {
      return (!this._size || this._sizeChanged) && (this._size = new w2(this._container.clientWidth || 0, this._container.clientHeight || 0), this._sizeChanged = false), this._size.clone();
    }, getPixelBounds: function(e5, t4) {
      var n3 = this._getTopLeftPoint(e5, t4);
      return new E2(n3, n3.add(this.getSize()));
    }, getPixelOrigin: function() {
      return this._checkIfLoaded(), this._pixelOrigin;
    }, getPixelWorldBounds: function(e5) {
      return this.options.crs.getProjectedBounds(e5 === void 0 ? this.getZoom() : e5);
    }, getPane: function(e5) {
      return typeof e5 == `string` ? this._panes[e5] : e5;
    }, getPanes: function() {
      return this._panes;
    }, getContainer: function() {
      return this._container;
    }, getZoomScale: function(e5, t4) {
      var n3 = this.options.crs;
      return t4 = t4 === void 0 ? this._zoom : t4, n3.scale(e5) / n3.scale(t4);
    }, getScaleZoom: function(e5, t4) {
      var n3 = this.options.crs;
      t4 = t4 === void 0 ? this._zoom : t4;
      var r3 = n3.zoom(e5 * n3.scale(t4));
      return isNaN(r3) ? 1 / 0 : r3;
    }, project: function(e5, t4) {
      return t4 = t4 === void 0 ? this._zoom : t4, this.options.crs.latLngToPoint(j2(e5), t4);
    }, unproject: function(e5, t4) {
      return t4 = t4 === void 0 ? this._zoom : t4, this.options.crs.pointToLatLng(T2(e5), t4);
    }, layerPointToLatLng: function(e5) {
      var t4 = T2(e5).add(this.getPixelOrigin());
      return this.unproject(t4);
    }, latLngToLayerPoint: function(e5) {
      return this.project(j2(e5))._round()._subtract(this.getPixelOrigin());
    }, wrapLatLng: function(e5) {
      return this.options.crs.wrapLatLng(j2(e5));
    }, wrapLatLngBounds: function(e5) {
      return this.options.crs.wrapLatLngBounds(k2(e5));
    }, distance: function(e5, t4) {
      return this.options.crs.distance(j2(e5), j2(t4));
    }, containerPointToLayerPoint: function(e5) {
      return T2(e5).subtract(this._getMapPanePos());
    }, layerPointToContainerPoint: function(e5) {
      return T2(e5).add(this._getMapPanePos());
    }, containerPointToLatLng: function(e5) {
      var t4 = this.containerPointToLayerPoint(T2(e5));
      return this.layerPointToLatLng(t4);
    }, latLngToContainerPoint: function(e5) {
      return this.layerPointToContainerPoint(this.latLngToLayerPoint(j2(e5)));
    }, mouseEventToContainerPoint: function(e5) {
      return nn(e5, this._container);
    }, mouseEventToLayerPoint: function(e5) {
      return this.containerPointToLayerPoint(this.mouseEventToContainerPoint(e5));
    }, mouseEventToLatLng: function(e5) {
      return this.layerPointToLatLng(this.mouseEventToLayerPoint(e5));
    }, _initContainer: function(e5) {
      var t4 = this._container = St(e5);
      if (!t4) throw Error(`Map container not found.`);
      if (t4._leaflet_id) throw Error(`Map container is already initialized.`);
      W(t4, `scroll`, this._onScroll, this), this._containerId = o2(t4);
    }, _initLayout: function() {
      var e5 = this._container;
      this._fadeAnimated = this.options.fadeAnimation && I.any3d, B(e5, `leaflet-container` + (I.touch ? ` leaflet-touch` : ``) + (I.retina ? ` leaflet-retina` : ``) + (I.ielt9 ? ` leaflet-oldie` : ``) + (I.safari ? ` leaflet-safari` : ``) + (this._fadeAnimated ? ` leaflet-fade-anim` : ``));
      var t4 = Ct(e5, `position`);
      t4 !== `absolute` && t4 !== `relative` && t4 !== `fixed` && t4 !== `sticky` && (e5.style.position = `relative`), this._initPanes(), this._initControlPos && this._initControlPos();
    }, _initPanes: function() {
      var e5 = this._panes = {};
      this._paneRenderers = {}, this._mapPane = this.createPane(`mapPane`, this._container), U(this._mapPane, new w2(0, 0)), this.createPane(`tilePane`), this.createPane(`overlayPane`), this.createPane(`shadowPane`), this.createPane(`markerPane`), this.createPane(`tooltipPane`), this.createPane(`popupPane`), this.options.markerZoomAnimation || (B(e5.markerPane, `leaflet-zoom-hide`), B(e5.shadowPane, `leaflet-zoom-hide`));
    }, _resetView: function(e5, t4, n3) {
      U(this._mapPane, new w2(0, 0));
      var r3 = !this._loaded;
      this._loaded = true, t4 = this._limitZoom(t4), this.fire(`viewprereset`);
      var i3 = this._zoom !== t4;
      this._moveStart(i3, n3)._move(e5, t4)._moveEnd(i3), this.fire(`viewreset`), r3 && this.fire(`load`);
    }, _moveStart: function(e5, t4) {
      return e5 && this.fire(`zoomstart`), t4 || this.fire(`movestart`), this;
    }, _move: function(e5, t4, n3, r3) {
      t4 === void 0 && (t4 = this._zoom);
      var i3 = this._zoom !== t4;
      return this._zoom = t4, this._lastCenter = e5, this._pixelOrigin = this._getNewPixelOrigin(e5), r3 ? n3 && n3.pinch && this.fire(`zoom`, n3) : ((i3 || n3 && n3.pinch) && this.fire(`zoom`, n3), this.fire(`move`, n3)), this;
    }, _moveEnd: function(e5) {
      return e5 && this.fire(`zoomend`), this.fire(`moveend`);
    }, _stop: function() {
      return x2(this._flyToFrame), this._panAnim && this._panAnim.stop(), this;
    }, _rawPanBy: function(e5) {
      U(this._mapPane, this._getMapPanePos().subtract(e5));
    }, _getZoomSpan: function() {
      return this.getMaxZoom() - this.getMinZoom();
    }, _panInsideMaxBounds: function() {
      this._enforcingBounds || this.panInsideBounds(this.options.maxBounds);
    }, _checkIfLoaded: function() {
      if (!this._loaded) throw Error(`Set map center and zoom first.`);
    }, _initEvents: function(e5) {
      this._targets = {}, this._targets[o2(this._container)] = this;
      var t4 = e5 ? K : W;
      t4(this._container, `click dblclick mousedown mouseup mouseover mouseout mousemove contextmenu keypress keydown keyup`, this._handleDOMEvent, this), this.options.trackResize && t4(window, `resize`, this._onResize, this), I.any3d && this.options.transform3DLimit && (e5 ? this.off : this.on).call(this, `moveend`, this._onMoveEnd);
    }, _onResize: function() {
      x2(this._resizeRequest), this._resizeRequest = b2(function() {
        this.invalidateSize({ debounceMoveend: true });
      }, this);
    }, _onScroll: function() {
      this._container.scrollTop = 0, this._container.scrollLeft = 0;
    }, _onMoveEnd: function() {
      var e5 = this._getMapPanePos();
      Math.max(Math.abs(e5.x), Math.abs(e5.y)) >= this.options.transform3DLimit && this._resetView(this.getCenter(), this.getZoom());
    }, _findEventTargets: function(e5, t4) {
      for (var n3 = [], r3, i3 = t4 === `mouseout` || t4 === `mouseover`, a3 = e5.target || e5.srcElement, s3 = false; a3; ) {
        if (r3 = this._targets[o2(a3)], r3 && (t4 === `click` || t4 === `preclick`) && this._draggableMoved(r3)) {
          s3 = true;
          break;
        }
        if (r3 && r3.listens(t4, true) && (i3 && !on(a3, e5) || (n3.push(r3), i3)) || a3 === this._container) break;
        a3 = a3.parentNode;
      }
      return !n3.length && !s3 && !i3 && this.listens(t4, true) && (n3 = [this]), n3;
    }, _isClickDisabled: function(e5) {
      for (; e5 && e5 !== this._container; ) {
        if (e5._leaflet_disable_click) return true;
        e5 = e5.parentNode;
      }
    }, _handleDOMEvent: function(e5) {
      var t4 = e5.target || e5.srcElement;
      if (!(!this._loaded || t4._leaflet_disable_events || e5.type === `click` && this._isClickDisabled(t4))) {
        var n3 = e5.type;
        n3 === `mousedown` && Ht(t4), this._fireDOMEvent(e5, n3);
      }
    }, _mouseEvents: [`click`, `dblclick`, `mouseover`, `mouseout`, `contextmenu`], _fireDOMEvent: function(e5, t4, r3) {
      if (e5.type === `click`) {
        var i3 = n2({}, e5);
        i3.type = `preclick`, this._fireDOMEvent(i3, i3.type, r3);
      }
      var a3 = this._findEventTargets(e5, t4);
      if (r3) {
        for (var o3 = [], s3 = 0; s3 < r3.length; s3++) r3[s3].listens(t4, true) && o3.push(r3[s3]);
        a3 = o3.concat(a3);
      }
      if (a3.length) {
        t4 === `contextmenu` && q(e5);
        var c3 = a3[0], l3 = { originalEvent: e5 };
        if (e5.type !== `keypress` && e5.type !== `keydown` && e5.type !== `keyup`) {
          var u3 = c3.getLatLng && (!c3._radius || c3._radius <= 10);
          l3.containerPoint = u3 ? this.latLngToContainerPoint(c3.getLatLng()) : this.mouseEventToContainerPoint(e5), l3.layerPoint = this.containerPointToLayerPoint(l3.containerPoint), l3.latlng = u3 ? c3.getLatLng() : this.layerPointToLatLng(l3.layerPoint);
        }
        for (s3 = 0; s3 < a3.length; s3++) if (a3[s3].fire(t4, l3, true), l3.originalEvent._stopped || a3[s3].options.bubblingMouseEvents === false && ee2(this._mouseEvents, t4) !== -1) return;
      }
    }, _draggableMoved: function(e5) {
      return e5 = e5.dragging && e5.dragging.enabled() ? e5 : this, e5.dragging && e5.dragging.moved() || this.boxZoom && this.boxZoom.moved();
    }, _clearHandlers: function() {
      for (var e5 = 0, t4 = this._handlers.length; e5 < t4; e5++) this._handlers[e5].disable();
    }, whenReady: function(e5, t4) {
      return this._loaded ? e5.call(t4 || this, { target: this }) : this.on(`load`, e5, t4), this;
    }, _getMapPanePos: function() {
      return Nt(this._mapPane) || new w2(0, 0);
    }, _moved: function() {
      var e5 = this._getMapPanePos();
      return e5 && !e5.equals([0, 0]);
    }, _getTopLeftPoint: function(e5, t4) {
      return (e5 && t4 !== void 0 ? this._getNewPixelOrigin(e5, t4) : this.getPixelOrigin()).subtract(this._getMapPanePos());
    }, _getNewPixelOrigin: function(e5, t4) {
      var n3 = this.getSize()._divideBy(2);
      return this.project(e5, t4)._subtract(n3)._add(this._getMapPanePos())._round();
    }, _latLngToNewLayerPoint: function(e5, t4, n3) {
      var r3 = this._getNewPixelOrigin(n3, t4);
      return this.project(e5, t4)._subtract(r3);
    }, _latLngBoundsToNewLayerBounds: function(e5, t4, n3) {
      var r3 = this._getNewPixelOrigin(n3, t4);
      return D2([this.project(e5.getSouthWest(), t4)._subtract(r3), this.project(e5.getNorthWest(), t4)._subtract(r3), this.project(e5.getSouthEast(), t4)._subtract(r3), this.project(e5.getNorthEast(), t4)._subtract(r3)]);
    }, _getCenterLayerPoint: function() {
      return this.containerPointToLayerPoint(this.getSize()._divideBy(2));
    }, _getCenterOffset: function(e5) {
      return this.latLngToLayerPoint(e5).subtract(this._getCenterLayerPoint());
    }, _limitCenter: function(e5, t4, n3) {
      if (!n3) return e5;
      var r3 = this.project(e5, t4), i3 = this.getSize().divideBy(2), a3 = new E2(r3.subtract(i3), r3.add(i3)), o3 = this._getBoundsOffset(a3, n3, t4);
      return Math.abs(o3.x) <= 1 && Math.abs(o3.y) <= 1 ? e5 : this.unproject(r3.add(o3), t4);
    }, _limitOffset: function(e5, t4) {
      if (!t4) return e5;
      var n3 = this.getPixelBounds(), r3 = new E2(n3.min.add(e5), n3.max.add(e5));
      return e5.add(this._getBoundsOffset(r3, t4));
    }, _getBoundsOffset: function(e5, t4, n3) {
      var r3 = D2(this.project(t4.getNorthEast(), n3), this.project(t4.getSouthWest(), n3)), i3 = r3.min.subtract(e5.min), a3 = r3.max.subtract(e5.max);
      return new w2(this._rebound(i3.x, -a3.x), this._rebound(i3.y, -a3.y));
    }, _rebound: function(e5, t4) {
      return e5 + t4 > 0 ? Math.round(e5 - t4) / 2 : Math.max(0, Math.ceil(e5)) - Math.max(0, Math.floor(t4));
    }, _limitZoom: function(e5) {
      var t4 = this.getMinZoom(), n3 = this.getMaxZoom(), r3 = I.any3d ? this.options.zoomSnap : 1;
      return r3 && (e5 = Math.round(e5 / r3) * r3), Math.max(t4, Math.min(n3, e5));
    }, _onPanTransitionStep: function() {
      this.fire(`move`);
    }, _onPanTransitionEnd: function() {
      V(this._mapPane, `leaflet-pan-anim`), this.fire(`moveend`);
    }, _tryAnimatedPan: function(e5, t4) {
      var n3 = this._getCenterOffset(e5)._trunc();
      return (t4 && t4.animate) !== true && !this.getSize().contains(n3) ? false : (this.panBy(n3, t4), true);
    }, _createAnimProxy: function() {
      var e5 = this._proxy = R(`div`, `leaflet-proxy leaflet-zoom-animated`);
      this._panes.mapPane.appendChild(e5), this.on(`zoomanim`, function(e6) {
        var t4 = yt, n3 = this._proxy.style[t4];
        Mt(this._proxy, this.project(e6.center, e6.zoom), this.getZoomScale(e6.zoom, 1)), n3 === this._proxy.style[t4] && this._animatingZoom && this._onZoomTransitionEnd();
      }, this), this.on(`load moveend`, this._animMoveEnd, this), this._on(`unload`, this._destroyAnimProxy, this);
    }, _destroyAnimProxy: function() {
      z(this._proxy), this.off(`load moveend`, this._animMoveEnd, this), delete this._proxy;
    }, _animMoveEnd: function() {
      var e5 = this.getCenter(), t4 = this.getZoom();
      Mt(this._proxy, this.project(e5, t4), this.getZoomScale(t4, 1));
    }, _catchTransitionEnd: function(e5) {
      this._animatingZoom && e5.propertyName.indexOf(`transform`) >= 0 && this._onZoomTransitionEnd();
    }, _nothingToAnimate: function() {
      return !this._container.getElementsByClassName(`leaflet-zoom-animated`).length;
    }, _tryAnimatedZoom: function(e5, t4, n3) {
      if (this._animatingZoom) return true;
      if (n3 || (n3 = {}), !this._zoomAnimated || n3.animate === false || this._nothingToAnimate() || Math.abs(t4 - this._zoom) > this.options.zoomAnimationThreshold) return false;
      var r3 = this.getZoomScale(t4), i3 = this._getCenterOffset(e5)._divideBy(1 - 1 / r3);
      return n3.animate !== true && !this.getSize().contains(i3) ? false : (b2(function() {
        this._moveStart(true, n3.noMoveStart || false)._animateZoom(e5, t4, true);
      }, this), true);
    }, _animateZoom: function(e5, t4, n3, r3) {
      this._mapPane && (n3 && (this._animatingZoom = true, this._animateToCenter = e5, this._animateToZoom = t4, B(this._mapPane, `leaflet-zoom-anim`)), this.fire(`zoomanim`, { center: e5, zoom: t4, noUpdate: r3 }), this._tempFireZoomEvent || (this._tempFireZoomEvent = this._zoom !== this._animateToZoom), this._move(this._animateToCenter, this._animateToZoom, void 0, true), setTimeout(i2(this._onZoomTransitionEnd, this), 250));
    }, _onZoomTransitionEnd: function() {
      this._animatingZoom && (this._mapPane && V(this._mapPane, `leaflet-zoom-anim`), this._animatingZoom = false, this._move(this._animateToCenter, this._animateToZoom, void 0, true), this._tempFireZoomEvent && this.fire(`zoom`), delete this._tempFireZoomEvent, this.fire(`move`), this._moveEnd(true));
    } });
    function ln(e5, t4) {
      return new J(e5, t4);
    }
    var Y = S2.extend({ options: { position: `topright` }, initialize: function(e5) {
      p2(this, e5);
    }, getPosition: function() {
      return this.options.position;
    }, setPosition: function(e5) {
      var t4 = this._map;
      return t4 && t4.removeControl(this), this.options.position = e5, t4 && t4.addControl(this), this;
    }, getContainer: function() {
      return this._container;
    }, addTo: function(e5) {
      this.remove(), this._map = e5;
      var t4 = this._container = this.onAdd(e5), n3 = this.getPosition(), r3 = e5._controlCorners[n3];
      return B(t4, `leaflet-control`), n3.indexOf(`bottom`) === -1 ? r3.appendChild(t4) : r3.insertBefore(t4, r3.firstChild), this._map.on(`unload`, this.remove, this), this;
    }, remove: function() {
      return this._map ? (z(this._container), this.onRemove && this.onRemove(this._map), this._map.off(`unload`, this.remove, this), this._map = null, this) : this;
    }, _refocusOnMap: function(e5) {
      this._map && e5 && e5.screenX > 0 && e5.screenY > 0 && this._map.getContainer().focus();
    } }), un = function(e5) {
      return new Y(e5);
    };
    J.include({ addControl: function(e5) {
      return e5.addTo(this), this;
    }, removeControl: function(e5) {
      return e5.remove(), this;
    }, _initControlPos: function() {
      var e5 = this._controlCorners = {}, t4 = `leaflet-`, n3 = this._controlContainer = R(`div`, t4 + `control-container`, this._container);
      function r3(r4, i3) {
        var a3 = t4 + r4 + ` ` + t4 + i3;
        e5[r4 + i3] = R(`div`, a3, n3);
      }
      r3(`top`, `left`), r3(`top`, `right`), r3(`bottom`, `left`), r3(`bottom`, `right`);
    }, _clearControlPos: function() {
      for (var e5 in this._controlCorners) z(this._controlCorners[e5]);
      z(this._controlContainer), delete this._controlCorners, delete this._controlContainer;
    } });
    var dn = Y.extend({ options: { collapsed: true, position: `topright`, autoZIndex: true, hideSingleBase: false, sortLayers: false, sortFunction: function(e5, t4, n3, r3) {
      return n3 < r3 ? -1 : +(r3 < n3);
    } }, initialize: function(e5, t4, n3) {
      for (var r3 in p2(this, n3), this._layerControlInputs = [], this._layers = [], this._lastZIndex = 0, this._handlingClick = false, this._preventClick = false, e5) this._addLayer(e5[r3], r3);
      for (r3 in t4) this._addLayer(t4[r3], r3, true);
    }, onAdd: function(e5) {
      this._initLayout(), this._update(), this._map = e5, e5.on(`zoomend`, this._checkDisabledLayers, this);
      for (var t4 = 0; t4 < this._layers.length; t4++) this._layers[t4].layer.on(`add remove`, this._onLayerChange, this);
      return this._container;
    }, addTo: function(e5) {
      return Y.prototype.addTo.call(this, e5), this._expandIfNotCollapsed();
    }, onRemove: function() {
      this._map.off(`zoomend`, this._checkDisabledLayers, this);
      for (var e5 = 0; e5 < this._layers.length; e5++) this._layers[e5].layer.off(`add remove`, this._onLayerChange, this);
    }, addBaseLayer: function(e5, t4) {
      return this._addLayer(e5, t4), this._map ? this._update() : this;
    }, addOverlay: function(e5, t4) {
      return this._addLayer(e5, t4, true), this._map ? this._update() : this;
    }, removeLayer: function(e5) {
      e5.off(`add remove`, this._onLayerChange, this);
      var t4 = this._getLayer(o2(e5));
      return t4 && this._layers.splice(this._layers.indexOf(t4), 1), this._map ? this._update() : this;
    }, expand: function() {
      B(this._container, `leaflet-control-layers-expanded`), this._section.style.height = null;
      var e5 = this._map.getSize().y - (this._container.offsetTop + 50);
      return e5 < this._section.clientHeight ? (B(this._section, `leaflet-control-layers-scrollbar`), this._section.style.height = e5 + `px`) : V(this._section, `leaflet-control-layers-scrollbar`), this._checkDisabledLayers(), this;
    }, collapse: function() {
      return V(this._container, `leaflet-control-layers-expanded`), this;
    }, _initLayout: function() {
      var e5 = `leaflet-control-layers`, t4 = this._container = R(`div`, e5), n3 = this.options.collapsed;
      t4.setAttribute(`aria-haspopup`, true), $t(t4), Qt(t4);
      var r3 = this._section = R(`section`, e5 + `-list`);
      n3 && (this._map.on(`click`, this.collapse, this), W(t4, { mouseenter: this._expandSafely, mouseleave: this.collapse }, this));
      var i3 = this._layersLink = R(`a`, e5 + `-toggle`, t4);
      i3.href = `#`, i3.title = `Layers`, i3.setAttribute(`role`, `button`), W(i3, { keydown: function(e6) {
        e6.keyCode === 13 && this._expandSafely();
      }, click: function(e6) {
        q(e6), this._expandSafely();
      } }, this), n3 || this.expand(), this._baseLayersList = R(`div`, e5 + `-base`, r3), this._separator = R(`div`, e5 + `-separator`, r3), this._overlaysList = R(`div`, e5 + `-overlays`, r3), t4.appendChild(r3);
    }, _getLayer: function(e5) {
      for (var t4 = 0; t4 < this._layers.length; t4++) if (this._layers[t4] && o2(this._layers[t4].layer) === e5) return this._layers[t4];
    }, _addLayer: function(e5, t4, n3) {
      this._map && e5.on(`add remove`, this._onLayerChange, this), this._layers.push({ layer: e5, name: t4, overlay: n3 }), this.options.sortLayers && this._layers.sort(i2(function(e6, t5) {
        return this.options.sortFunction(e6.layer, t5.layer, e6.name, t5.name);
      }, this)), this.options.autoZIndex && e5.setZIndex && (this._lastZIndex++, e5.setZIndex(this._lastZIndex)), this._expandIfNotCollapsed();
    }, _update: function() {
      if (!this._container) return this;
      wt(this._baseLayersList), wt(this._overlaysList), this._layerControlInputs = [];
      var e5, t4, n3, r3, i3 = 0;
      for (n3 = 0; n3 < this._layers.length; n3++) r3 = this._layers[n3], this._addItem(r3), t4 || (t4 = r3.overlay), e5 || (e5 = !r3.overlay), i3 += +!r3.overlay;
      return this.options.hideSingleBase && (e5 && (e5 = i3 > 1), this._baseLayersList.style.display = e5 ? `` : `none`), this._separator.style.display = t4 && e5 ? `` : `none`, this;
    }, _onLayerChange: function(e5) {
      this._handlingClick || this._update();
      var t4 = this._getLayer(o2(e5.target)), n3 = t4.overlay ? e5.type === `add` ? `overlayadd` : `overlayremove` : e5.type === `add` ? `baselayerchange` : null;
      n3 && this._map.fire(n3, t4);
    }, _createRadioElement: function(e5, t4) {
      var n3 = `<input type="radio" class="leaflet-control-layers-selector" name="` + e5 + `"` + (t4 ? ` checked="checked"` : ``) + `/>`, r3 = document.createElement(`div`);
      return r3.innerHTML = n3, r3.firstChild;
    }, _addItem: function(e5) {
      var t4 = document.createElement(`label`), n3 = this._map.hasLayer(e5.layer), r3;
      e5.overlay ? (r3 = document.createElement(`input`), r3.type = `checkbox`, r3.className = `leaflet-control-layers-selector`, r3.defaultChecked = n3) : r3 = this._createRadioElement(`leaflet-base-layers_` + o2(this), n3), this._layerControlInputs.push(r3), r3.layerId = o2(e5.layer), W(r3, `click`, this._onInputClick, this);
      var i3 = document.createElement(`span`);
      i3.innerHTML = ` ` + e5.name;
      var a3 = document.createElement(`span`);
      return t4.appendChild(a3), a3.appendChild(r3), a3.appendChild(i3), (e5.overlay ? this._overlaysList : this._baseLayersList).appendChild(t4), this._checkDisabledLayers(), t4;
    }, _onInputClick: function() {
      if (!this._preventClick) {
        var e5 = this._layerControlInputs, t4, n3, r3 = [], i3 = [];
        this._handlingClick = true;
        for (var a3 = e5.length - 1; a3 >= 0; a3--) t4 = e5[a3], n3 = this._getLayer(t4.layerId).layer, t4.checked ? r3.push(n3) : t4.checked || i3.push(n3);
        for (a3 = 0; a3 < i3.length; a3++) this._map.hasLayer(i3[a3]) && this._map.removeLayer(i3[a3]);
        for (a3 = 0; a3 < r3.length; a3++) this._map.hasLayer(r3[a3]) || this._map.addLayer(r3[a3]);
        this._handlingClick = false, this._refocusOnMap();
      }
    }, _checkDisabledLayers: function() {
      for (var e5 = this._layerControlInputs, t4, n3, r3 = this._map.getZoom(), i3 = e5.length - 1; i3 >= 0; i3--) t4 = e5[i3], n3 = this._getLayer(t4.layerId).layer, t4.disabled = n3.options.minZoom !== void 0 && r3 < n3.options.minZoom || n3.options.maxZoom !== void 0 && r3 > n3.options.maxZoom;
    }, _expandIfNotCollapsed: function() {
      return this._map && !this.options.collapsed && this.expand(), this;
    }, _expandSafely: function() {
      var e5 = this._section;
      this._preventClick = true, W(e5, `click`, q), this.expand();
      var t4 = this;
      setTimeout(function() {
        K(e5, `click`, q), t4._preventClick = false;
      });
    } }), fn = function(e5, t4, n3) {
      return new dn(e5, t4, n3);
    }, pn = Y.extend({ options: { position: `topleft`, zoomInText: `<span aria-hidden="true">+</span>`, zoomInTitle: `Zoom in`, zoomOutText: `<span aria-hidden="true">&#x2212;</span>`, zoomOutTitle: `Zoom out` }, onAdd: function(e5) {
      var t4 = `leaflet-control-zoom`, n3 = R(`div`, t4 + ` leaflet-bar`), r3 = this.options;
      return this._zoomInButton = this._createButton(r3.zoomInText, r3.zoomInTitle, t4 + `-in`, n3, this._zoomIn), this._zoomOutButton = this._createButton(r3.zoomOutText, r3.zoomOutTitle, t4 + `-out`, n3, this._zoomOut), this._updateDisabled(), e5.on(`zoomend zoomlevelschange`, this._updateDisabled, this), n3;
    }, onRemove: function(e5) {
      e5.off(`zoomend zoomlevelschange`, this._updateDisabled, this);
    }, disable: function() {
      return this._disabled = true, this._updateDisabled(), this;
    }, enable: function() {
      return this._disabled = false, this._updateDisabled(), this;
    }, _zoomIn: function(e5) {
      !this._disabled && this._map._zoom < this._map.getMaxZoom() && this._map.zoomIn(this._map.options.zoomDelta * (e5.shiftKey ? 3 : 1));
    }, _zoomOut: function(e5) {
      !this._disabled && this._map._zoom > this._map.getMinZoom() && this._map.zoomOut(this._map.options.zoomDelta * (e5.shiftKey ? 3 : 1));
    }, _createButton: function(e5, t4, n3, r3, i3) {
      var a3 = R(`a`, n3, r3);
      return a3.innerHTML = e5, a3.href = `#`, a3.title = t4, a3.setAttribute(`role`, `button`), a3.setAttribute(`aria-label`, t4), $t(a3), W(a3, `click`, en), W(a3, `click`, i3, this), W(a3, `click`, this._refocusOnMap, this), a3;
    }, _updateDisabled: function() {
      var e5 = this._map, t4 = `leaflet-disabled`;
      V(this._zoomInButton, t4), V(this._zoomOutButton, t4), this._zoomInButton.setAttribute(`aria-disabled`, `false`), this._zoomOutButton.setAttribute(`aria-disabled`, `false`), (this._disabled || e5._zoom === e5.getMinZoom()) && (B(this._zoomOutButton, t4), this._zoomOutButton.setAttribute(`aria-disabled`, `true`)), (this._disabled || e5._zoom === e5.getMaxZoom()) && (B(this._zoomInButton, t4), this._zoomInButton.setAttribute(`aria-disabled`, `true`));
    } });
    J.mergeOptions({ zoomControl: true }), J.addInitHook(function() {
      this.options.zoomControl && (this.zoomControl = new pn(), this.addControl(this.zoomControl));
    });
    var mn = function(e5) {
      return new pn(e5);
    }, hn = Y.extend({ options: { position: `bottomleft`, maxWidth: 100, metric: true, imperial: true }, onAdd: function(e5) {
      var t4 = `leaflet-control-scale`, n3 = R(`div`, t4), r3 = this.options;
      return this._addScales(r3, t4 + `-line`, n3), e5.on(r3.updateWhenIdle ? `moveend` : `move`, this._update, this), e5.whenReady(this._update, this), n3;
    }, onRemove: function(e5) {
      e5.off(this.options.updateWhenIdle ? `moveend` : `move`, this._update, this);
    }, _addScales: function(e5, t4, n3) {
      e5.metric && (this._mScale = R(`div`, t4, n3)), e5.imperial && (this._iScale = R(`div`, t4, n3));
    }, _update: function() {
      var e5 = this._map, t4 = e5.getSize().y / 2, n3 = e5.distance(e5.containerPointToLatLng([0, t4]), e5.containerPointToLatLng([this.options.maxWidth, t4]));
      this._updateScales(n3);
    }, _updateScales: function(e5) {
      this.options.metric && e5 && this._updateMetric(e5), this.options.imperial && e5 && this._updateImperial(e5);
    }, _updateMetric: function(e5) {
      var t4 = this._getRoundNum(e5), n3 = t4 < 1e3 ? t4 + ` m` : t4 / 1e3 + ` km`;
      this._updateScale(this._mScale, n3, t4 / e5);
    }, _updateImperial: function(e5) {
      var t4 = e5 * 3.2808399, n3, r3, i3;
      t4 > 5280 ? (n3 = t4 / 5280, r3 = this._getRoundNum(n3), this._updateScale(this._iScale, r3 + ` mi`, r3 / n3)) : (i3 = this._getRoundNum(t4), this._updateScale(this._iScale, i3 + ` ft`, i3 / t4));
    }, _updateScale: function(e5, t4, n3) {
      e5.style.width = Math.round(this.options.maxWidth * n3) + `px`, e5.innerHTML = t4;
    }, _getRoundNum: function(e5) {
      var t4 = 10 ** ((Math.floor(e5) + ``).length - 1), n3 = e5 / t4;
      return n3 = n3 >= 10 ? 10 : n3 >= 5 ? 5 : n3 >= 3 ? 3 : n3 >= 2 ? 2 : 1, t4 * n3;
    } }), gn = function(e5) {
      return new hn(e5);
    }, _n = Y.extend({ options: { position: `bottomright`, prefix: `<a href="https://leafletjs.com" title="A JavaScript library for interactive maps">` + (I.inlineSvg ? `<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="12" height="8" viewBox="0 0 12 8" class="leaflet-attribution-flag"><path fill="#4C7BE1" d="M0 0h12v4H0z"/><path fill="#FFD500" d="M0 4h12v3H0z"/><path fill="#E0BC00" d="M0 7h12v1H0z"/></svg> ` : ``) + `Leaflet</a>` }, initialize: function(e5) {
      p2(this, e5), this._attributions = {};
    }, onAdd: function(e5) {
      for (var t4 in e5.attributionControl = this, this._container = R(`div`, `leaflet-control-attribution`), $t(this._container), e5._layers) e5._layers[t4].getAttribution && this.addAttribution(e5._layers[t4].getAttribution());
      return this._update(), e5.on(`layeradd`, this._addAttribution, this), this._container;
    }, onRemove: function(e5) {
      e5.off(`layeradd`, this._addAttribution, this);
    }, _addAttribution: function(e5) {
      e5.layer.getAttribution && (this.addAttribution(e5.layer.getAttribution()), e5.layer.once(`remove`, function() {
        this.removeAttribution(e5.layer.getAttribution());
      }, this));
    }, setPrefix: function(e5) {
      return this.options.prefix = e5, this._update(), this;
    }, addAttribution: function(e5) {
      return e5 ? (this._attributions[e5] || (this._attributions[e5] = 0), this._attributions[e5]++, this._update(), this) : this;
    }, removeAttribution: function(e5) {
      return e5 && this._attributions[e5] && (this._attributions[e5]--, this._update()), this;
    }, _update: function() {
      if (this._map) {
        var e5 = [];
        for (var t4 in this._attributions) this._attributions[t4] && e5.push(t4);
        var n3 = [];
        this.options.prefix && n3.push(this.options.prefix), e5.length && n3.push(e5.join(`, `)), this._container.innerHTML = n3.join(` <span aria-hidden="true">|</span> `);
      }
    } });
    J.mergeOptions({ attributionControl: true }), J.addInitHook(function() {
      this.options.attributionControl && new _n().addTo(this);
    }), Y.Layers = dn, Y.Zoom = pn, Y.Scale = hn, Y.Attribution = _n, un.layers = fn, un.zoom = mn, un.scale = gn, un.attribution = function(e5) {
      return new _n(e5);
    };
    var X = S2.extend({ initialize: function(e5) {
      this._map = e5;
    }, enable: function() {
      return this._enabled ? this : (this._enabled = true, this.addHooks(), this);
    }, disable: function() {
      return this._enabled ? (this._enabled = false, this.removeHooks(), this) : this;
    }, enabled: function() {
      return !!this._enabled;
    } });
    X.addTo = function(e5, t4) {
      return e5.addHandler(t4, this), this;
    };
    var vn = { Events: C2 }, yn = I.touch ? `touchstart mousedown` : `mousedown`, bn = se2.extend({ options: { clickTolerance: 3 }, initialize: function(e5, t4, n3, r3) {
      p2(this, r3), this._element = e5, this._dragStartTarget = t4 || e5, this._preventOutline = n3;
    }, enable: function() {
      this._enabled || (this._enabled = (W(this._dragStartTarget, yn, this._onDown, this), true));
    }, disable: function() {
      this._enabled && (bn._dragging === this && this.finishDrag(true), K(this._dragStartTarget, yn, this._onDown, this), this._enabled = false, this._moved = false);
    }, _onDown: function(e5) {
      if (this._enabled && (this._moved = false, !Dt(this._element, `leaflet-zoom-anim`))) {
        if (e5.touches && e5.touches.length !== 1) {
          bn._dragging === this && this.finishDrag();
          return;
        }
        if (!(bn._dragging || e5.shiftKey || e5.which !== 1 && e5.button !== 1 && !e5.touches) && (bn._dragging = this, this._preventOutline && Ht(this._element), Rt(), Pt(), !this._moving)) {
          this.fire(`down`);
          var t4 = e5.touches ? e5.touches[0] : e5, n3 = Wt(this._element);
          this._startPoint = new w2(t4.clientX, t4.clientY), this._startPos = Nt(this._element), this._parentScale = Gt(n3);
          var r3 = e5.type === `mousedown`;
          W(document, r3 ? `mousemove` : `touchmove`, this._onMove, this), W(document, r3 ? `mouseup` : `touchend touchcancel`, this._onUp, this);
        }
      }
    }, _onMove: function(e5) {
      if (this._enabled) {
        if (e5.touches && e5.touches.length > 1) {
          this._moved = true;
          return;
        }
        var t4 = e5.touches && e5.touches.length === 1 ? e5.touches[0] : e5, n3 = new w2(t4.clientX, t4.clientY)._subtract(this._startPoint);
        (n3.x || n3.y) && (Math.abs(n3.x) + Math.abs(n3.y) < this.options.clickTolerance || (n3.x /= this._parentScale.x, n3.y /= this._parentScale.y, q(e5), this._moved || (this.fire(`dragstart`), this._moved = true, B(document.body, `leaflet-dragging`), this._lastTarget = e5.target || e5.srcElement, window.SVGElementInstance && this._lastTarget instanceof window.SVGElementInstance && (this._lastTarget = this._lastTarget.correspondingUseElement), B(this._lastTarget, `leaflet-drag-target`)), this._newPos = this._startPos.add(n3), this._moving = true, this._lastEvent = e5, this._updatePosition()));
      }
    }, _updatePosition: function() {
      var e5 = { originalEvent: this._lastEvent };
      this.fire(`predrag`, e5), U(this._element, this._newPos), this.fire(`drag`, e5);
    }, _onUp: function() {
      this._enabled && this.finishDrag();
    }, finishDrag: function(e5) {
      V(document.body, `leaflet-dragging`), this._lastTarget && (this._lastTarget = (V(this._lastTarget, `leaflet-drag-target`), null)), K(document, `mousemove touchmove`, this._onMove, this), K(document, `mouseup touchend touchcancel`, this._onUp, this), zt(), Ft();
      var t4 = this._moved && this._moving;
      this._moving = false, bn._dragging = false, t4 && this.fire(`dragend`, { noInertia: e5, distance: this._newPos.distanceTo(this._startPos) });
    } });
    function xn(e5, t4, n3) {
      for (var r3, i3 = [1, 4, 2, 8], a3 = 0, o3, s3, c3, l3, u3 = e5.length, d3, f3; a3 < u3; a3++) e5[a3]._code = Pn(e5[a3], t4);
      for (s3 = 0; s3 < 4; s3++) {
        for (d3 = i3[s3], r3 = [], a3 = 0, u3 = e5.length, o3 = u3 - 1; a3 < u3; o3 = a3++) c3 = e5[a3], l3 = e5[o3], c3._code & d3 ? l3._code & d3 || (f3 = Nn(l3, c3, d3, t4, n3), f3._code = Pn(f3, t4), r3.push(f3)) : (l3._code & d3 && (f3 = Nn(l3, c3, d3, t4, n3), f3._code = Pn(f3, t4), r3.push(f3)), r3.push(c3));
        e5 = r3;
      }
      return e5;
    }
    function Sn(e5, t4) {
      var n3, r3, i3, a3, o3, s3, c3, l3, u3;
      if (!e5 || e5.length === 0) throw Error(`latlngs not passed`);
      Z(e5) || (console.warn(`latlngs are not flat! Only the first ring will be used`), e5 = e5[0]);
      var d3 = j2([0, 0]), f3 = k2(e5);
      f3.getNorthWest().distanceTo(f3.getSouthWest()) * f3.getNorthEast().distanceTo(f3.getNorthWest()) < 1700 && (d3 = Cn(e5));
      var p3 = e5.length, m3 = [];
      for (n3 = 0; n3 < p3; n3++) {
        var h3 = j2(e5[n3]);
        m3.push(t4.project(j2([h3.lat - d3.lat, h3.lng - d3.lng])));
      }
      for (s3 = c3 = l3 = 0, n3 = 0, r3 = p3 - 1; n3 < p3; r3 = n3++) i3 = m3[n3], a3 = m3[r3], o3 = i3.y * a3.x - a3.y * i3.x, c3 += (i3.x + a3.x) * o3, l3 += (i3.y + a3.y) * o3, s3 += o3 * 3;
      u3 = s3 === 0 ? m3[0] : [c3 / s3, l3 / s3];
      var g3 = t4.unproject(T2(u3));
      return j2([g3.lat + d3.lat, g3.lng + d3.lng]);
    }
    function Cn(e5) {
      for (var t4 = 0, n3 = 0, r3 = 0, i3 = 0; i3 < e5.length; i3++) {
        var a3 = j2(e5[i3]);
        t4 += a3.lat, n3 += a3.lng, r3++;
      }
      return j2([t4 / r3, n3 / r3]);
    }
    var wn = { __proto__: null, clipPolygon: xn, polygonCenter: Sn, centroid: Cn };
    function Tn(e5, t4) {
      if (!t4 || !e5.length) return e5.slice();
      var n3 = t4 * t4;
      return e5 = An(e5, n3), e5 = On(e5, n3), e5;
    }
    function En(e5, t4, n3) {
      return Math.sqrt(In(e5, t4, n3, true));
    }
    function Dn(e5, t4, n3) {
      return In(e5, t4, n3);
    }
    function On(e5, t4) {
      var n3 = e5.length, r3 = new (typeof Uint8Array < `u` ? Uint8Array : Array)(n3);
      r3[0] = r3[n3 - 1] = 1, kn(e5, r3, t4, 0, n3 - 1);
      var i3, a3 = [];
      for (i3 = 0; i3 < n3; i3++) r3[i3] && a3.push(e5[i3]);
      return a3;
    }
    function kn(e5, t4, n3, r3, i3) {
      for (var a3 = 0, o3, s3 = r3 + 1, c3; s3 <= i3 - 1; s3++) c3 = In(e5[s3], e5[r3], e5[i3], true), c3 > a3 && (o3 = s3, a3 = c3);
      a3 > n3 && (t4[o3] = 1, kn(e5, t4, n3, r3, o3), kn(e5, t4, n3, o3, i3));
    }
    function An(e5, t4) {
      for (var n3 = [e5[0]], r3 = 1, i3 = 0, a3 = e5.length; r3 < a3; r3++) Fn(e5[r3], e5[i3]) > t4 && (n3.push(e5[r3]), i3 = r3);
      return i3 < a3 - 1 && n3.push(e5[a3 - 1]), n3;
    }
    var jn;
    function Mn(e5, t4, n3, r3, i3) {
      var a3 = r3 ? jn : Pn(e5, n3), o3 = Pn(t4, n3), s3, c3, l3;
      for (jn = o3; ; ) {
        if (!(a3 | o3)) return [e5, t4];
        if (a3 & o3) return false;
        s3 = a3 || o3, c3 = Nn(e5, t4, s3, n3, i3), l3 = Pn(c3, n3), s3 === a3 ? (e5 = c3, a3 = l3) : (t4 = c3, o3 = l3);
      }
    }
    function Nn(e5, t4, n3, r3, i3) {
      var a3 = t4.x - e5.x, o3 = t4.y - e5.y, s3 = r3.min, c3 = r3.max, l3, u3;
      return n3 & 8 ? (l3 = e5.x + a3 * (c3.y - e5.y) / o3, u3 = c3.y) : n3 & 4 ? (l3 = e5.x + a3 * (s3.y - e5.y) / o3, u3 = s3.y) : n3 & 2 ? (l3 = c3.x, u3 = e5.y + o3 * (c3.x - e5.x) / a3) : n3 & 1 && (l3 = s3.x, u3 = e5.y + o3 * (s3.x - e5.x) / a3), new w2(l3, u3, i3);
    }
    function Pn(e5, t4) {
      var n3 = 0;
      return e5.x < t4.min.x ? n3 |= 1 : e5.x > t4.max.x && (n3 |= 2), e5.y < t4.min.y ? n3 |= 4 : e5.y > t4.max.y && (n3 |= 8), n3;
    }
    function Fn(e5, t4) {
      var n3 = t4.x - e5.x, r3 = t4.y - e5.y;
      return n3 * n3 + r3 * r3;
    }
    function In(e5, t4, n3, r3) {
      var i3 = t4.x, a3 = t4.y, o3 = n3.x - i3, s3 = n3.y - a3, c3 = o3 * o3 + s3 * s3, l3;
      return c3 > 0 && (l3 = ((e5.x - i3) * o3 + (e5.y - a3) * s3) / c3, l3 > 1 ? (i3 = n3.x, a3 = n3.y) : l3 > 0 && (i3 += o3 * l3, a3 += s3 * l3)), o3 = e5.x - i3, s3 = e5.y - a3, r3 ? o3 * o3 + s3 * s3 : new w2(i3, a3);
    }
    function Z(e5) {
      return !_2(e5[0]) || typeof e5[0][0] != `object` && e5[0][0] !== void 0;
    }
    function Ln(e5) {
      return console.warn(`Deprecated use of _flat, please use L.LineUtil.isFlat instead.`), Z(e5);
    }
    function Rn(e5, t4) {
      var n3, r3, i3, a3, o3, s3, c3, l3;
      if (!e5 || e5.length === 0) throw Error(`latlngs not passed`);
      Z(e5) || (console.warn(`latlngs are not flat! Only the first ring will be used`), e5 = e5[0]);
      var u3 = j2([0, 0]), d3 = k2(e5);
      d3.getNorthWest().distanceTo(d3.getSouthWest()) * d3.getNorthEast().distanceTo(d3.getNorthWest()) < 1700 && (u3 = Cn(e5));
      var f3 = e5.length, p3 = [];
      for (n3 = 0; n3 < f3; n3++) {
        var m3 = j2(e5[n3]);
        p3.push(t4.project(j2([m3.lat - u3.lat, m3.lng - u3.lng])));
      }
      for (n3 = 0, r3 = 0; n3 < f3 - 1; n3++) r3 += p3[n3].distanceTo(p3[n3 + 1]) / 2;
      if (r3 === 0) l3 = p3[0];
      else for (n3 = 0, a3 = 0; n3 < f3 - 1; n3++) if (o3 = p3[n3], s3 = p3[n3 + 1], i3 = o3.distanceTo(s3), a3 += i3, a3 > r3) {
        c3 = (a3 - r3) / i3, l3 = [s3.x - c3 * (s3.x - o3.x), s3.y - c3 * (s3.y - o3.y)];
        break;
      }
      var h3 = t4.unproject(T2(l3));
      return j2([h3.lat + u3.lat, h3.lng + u3.lng]);
    }
    var zn = { __proto__: null, simplify: Tn, pointToSegmentDistance: En, closestPointOnSegment: Dn, clipSegment: Mn, _getEdgeIntersection: Nn, _getBitCode: Pn, _sqClosestPointOnSegment: In, isFlat: Z, _flat: Ln, polylineCenter: Rn }, Bn = { project: function(e5) {
      return new w2(e5.lng, e5.lat);
    }, unproject: function(e5) {
      return new A2(e5.y, e5.x);
    }, bounds: new E2([-180, -90], [180, 90]) }, Vn = { R: 6378137, R_MINOR: 6356752314245179e-9, bounds: new E2([-2003750834279e-5, -1549657073972e-5], [2003750834279e-5, 1876465623138e-5]), project: function(e5) {
      var t4 = Math.PI / 180, n3 = this.R, r3 = e5.lat * t4, i3 = this.R_MINOR / n3, a3 = Math.sqrt(1 - i3 * i3), o3 = a3 * Math.sin(r3), s3 = Math.tan(Math.PI / 4 - r3 / 2) / ((1 - o3) / (1 + o3)) ** (a3 / 2);
      return r3 = -n3 * Math.log(Math.max(s3, 1e-10)), new w2(e5.lng * t4 * n3, r3);
    }, unproject: function(e5) {
      for (var t4 = 180 / Math.PI, n3 = this.R, r3 = this.R_MINOR / n3, i3 = Math.sqrt(1 - r3 * r3), a3 = Math.exp(-e5.y / n3), o3 = Math.PI / 2 - 2 * Math.atan(a3), s3 = 0, c3 = 0.1, l3; s3 < 15 && Math.abs(c3) > 1e-7; s3++) l3 = i3 * Math.sin(o3), l3 = ((1 - l3) / (1 + l3)) ** (i3 / 2), c3 = Math.PI / 2 - 2 * Math.atan(a3 * l3) - o3, o3 += c3;
      return new A2(o3 * t4, e5.x * t4 / n3);
    } }, Hn = { __proto__: null, LonLat: Bn, Mercator: Vn, SphericalMercator: ue2 }, Un = n2({}, N2, { code: `EPSG:3395`, projection: Vn, transformation: (function() {
      var e5 = 0.5 / (Math.PI * Vn.R);
      return fe2(e5, 0.5, -e5, 0.5);
    })() }), Wn = n2({}, N2, { code: `EPSG:4326`, projection: Bn, transformation: fe2(1 / 180, 1, -1 / 180, 0.5) }), Gn = n2({}, M2, { projection: Bn, transformation: fe2(1, 0, -1, 0), scale: function(e5) {
      return 2 ** e5;
    }, zoom: function(e5) {
      return Math.log(e5) / Math.LN2;
    }, distance: function(e5, t4) {
      var n3 = t4.lng - e5.lng, r3 = t4.lat - e5.lat;
      return Math.sqrt(n3 * n3 + r3 * r3);
    }, infinite: true });
    M2.Earth = N2, M2.EPSG3395 = Un, M2.EPSG3857 = pe2, M2.EPSG900913 = me2, M2.EPSG4326 = Wn, M2.Simple = Gn;
    var Q = se2.extend({ options: { pane: `overlayPane`, attribution: null, bubblingMouseEvents: true }, addTo: function(e5) {
      return e5.addLayer(this), this;
    }, remove: function() {
      return this.removeFrom(this._map || this._mapToAdd);
    }, removeFrom: function(e5) {
      return e5 && e5.removeLayer(this), this;
    }, getPane: function(e5) {
      return this._map.getPane(e5 ? this.options[e5] || e5 : this.options.pane);
    }, addInteractiveTarget: function(e5) {
      return this._map._targets[o2(e5)] = this, this;
    }, removeInteractiveTarget: function(e5) {
      return delete this._map._targets[o2(e5)], this;
    }, getAttribution: function() {
      return this.options.attribution;
    }, _layerAdd: function(e5) {
      var t4 = e5.target;
      if (t4.hasLayer(this)) {
        if (this._map = t4, this._zoomAnimated = t4._zoomAnimated, this.getEvents) {
          var n3 = this.getEvents();
          t4.on(n3, this), this.once(`remove`, function() {
            t4.off(n3, this);
          }, this);
        }
        this.onAdd(t4), this.fire(`add`), t4.fire(`layeradd`, { layer: this });
      }
    } });
    J.include({ addLayer: function(e5) {
      if (!e5._layerAdd) throw Error(`The provided object is not a Layer.`);
      var t4 = o2(e5);
      return this._layers[t4] ? this : (this._layers[t4] = e5, e5._mapToAdd = this, e5.beforeAdd && e5.beforeAdd(this), this.whenReady(e5._layerAdd, e5), this);
    }, removeLayer: function(e5) {
      var t4 = o2(e5);
      return this._layers[t4] ? (this._loaded && e5.onRemove(this), delete this._layers[t4], this._loaded && (this.fire(`layerremove`, { layer: e5 }), e5.fire(`remove`)), e5._map = e5._mapToAdd = null, this) : this;
    }, hasLayer: function(e5) {
      return o2(e5) in this._layers;
    }, eachLayer: function(e5, t4) {
      for (var n3 in this._layers) e5.call(t4, this._layers[n3]);
      return this;
    }, _addLayers: function(e5) {
      e5 = e5 ? _2(e5) ? e5 : [e5] : [];
      for (var t4 = 0, n3 = e5.length; t4 < n3; t4++) this.addLayer(e5[t4]);
    }, _addZoomLimit: function(e5) {
      (!isNaN(e5.options.maxZoom) || !isNaN(e5.options.minZoom)) && (this._zoomBoundLayers[o2(e5)] = e5, this._updateZoomLevels());
    }, _removeZoomLimit: function(e5) {
      var t4 = o2(e5);
      this._zoomBoundLayers[t4] && (delete this._zoomBoundLayers[t4], this._updateZoomLevels());
    }, _updateZoomLevels: function() {
      var e5 = 1 / 0, t4 = -1 / 0, n3 = this._getZoomSpan();
      for (var r3 in this._zoomBoundLayers) {
        var i3 = this._zoomBoundLayers[r3].options;
        e5 = i3.minZoom === void 0 ? e5 : Math.min(e5, i3.minZoom), t4 = i3.maxZoom === void 0 ? t4 : Math.max(t4, i3.maxZoom);
      }
      this._layersMaxZoom = t4 === -1 / 0 ? void 0 : t4, this._layersMinZoom = e5 === 1 / 0 ? void 0 : e5, n3 !== this._getZoomSpan() && this.fire(`zoomlevelschange`), this.options.maxZoom === void 0 && this._layersMaxZoom && this.getZoom() > this._layersMaxZoom && this.setZoom(this._layersMaxZoom), this.options.minZoom === void 0 && this._layersMinZoom && this.getZoom() < this._layersMinZoom && this.setZoom(this._layersMinZoom);
    } });
    var Kn = Q.extend({ initialize: function(e5, t4) {
      p2(this, t4), this._layers = {};
      var n3, r3;
      if (e5) for (n3 = 0, r3 = e5.length; n3 < r3; n3++) this.addLayer(e5[n3]);
    }, addLayer: function(e5) {
      var t4 = this.getLayerId(e5);
      return this._layers[t4] = e5, this._map && this._map.addLayer(e5), this;
    }, removeLayer: function(e5) {
      var t4 = e5 in this._layers ? e5 : this.getLayerId(e5);
      return this._map && this._layers[t4] && this._map.removeLayer(this._layers[t4]), delete this._layers[t4], this;
    }, hasLayer: function(e5) {
      return (typeof e5 == `number` ? e5 : this.getLayerId(e5)) in this._layers;
    }, clearLayers: function() {
      return this.eachLayer(this.removeLayer, this);
    }, invoke: function(e5) {
      var t4 = Array.prototype.slice.call(arguments, 1), n3, r3;
      for (n3 in this._layers) r3 = this._layers[n3], r3[e5] && r3[e5].apply(r3, t4);
      return this;
    }, onAdd: function(e5) {
      this.eachLayer(e5.addLayer, e5);
    }, onRemove: function(e5) {
      this.eachLayer(e5.removeLayer, e5);
    }, eachLayer: function(e5, t4) {
      for (var n3 in this._layers) e5.call(t4, this._layers[n3]);
      return this;
    }, getLayer: function(e5) {
      return this._layers[e5];
    }, getLayers: function() {
      var e5 = [];
      return this.eachLayer(e5.push, e5), e5;
    }, setZIndex: function(e5) {
      return this.invoke(`setZIndex`, e5);
    }, getLayerId: function(e5) {
      return o2(e5);
    } }), qn = function(e5, t4) {
      return new Kn(e5, t4);
    }, Jn = Kn.extend({ addLayer: function(e5) {
      return this.hasLayer(e5) ? this : (e5.addEventParent(this), Kn.prototype.addLayer.call(this, e5), this.fire(`layeradd`, { layer: e5 }));
    }, removeLayer: function(e5) {
      return this.hasLayer(e5) ? (e5 in this._layers && (e5 = this._layers[e5]), e5.removeEventParent(this), Kn.prototype.removeLayer.call(this, e5), this.fire(`layerremove`, { layer: e5 })) : this;
    }, setStyle: function(e5) {
      return this.invoke(`setStyle`, e5);
    }, bringToFront: function() {
      return this.invoke(`bringToFront`);
    }, bringToBack: function() {
      return this.invoke(`bringToBack`);
    }, getBounds: function() {
      var e5 = new O2();
      for (var t4 in this._layers) {
        var n3 = this._layers[t4];
        e5.extend(n3.getBounds ? n3.getBounds() : n3.getLatLng());
      }
      return e5;
    } }), Yn = function(e5, t4) {
      return new Jn(e5, t4);
    }, Xn = S2.extend({ options: { popupAnchor: [0, 0], tooltipAnchor: [0, 0], crossOrigin: false }, initialize: function(e5) {
      p2(this, e5);
    }, createIcon: function(e5) {
      return this._createIcon(`icon`, e5);
    }, createShadow: function(e5) {
      return this._createIcon(`shadow`, e5);
    }, _createIcon: function(e5, t4) {
      var n3 = this._getIconUrl(e5);
      if (!n3) {
        if (e5 === `icon`) throw Error(`iconUrl not set in Icon options (see the docs).`);
        return null;
      }
      var r3 = this._createImg(n3, t4 && t4.tagName === `IMG` ? t4 : null);
      return this._setIconStyles(r3, e5), (this.options.crossOrigin || this.options.crossOrigin === ``) && (r3.crossOrigin = this.options.crossOrigin === true ? `` : this.options.crossOrigin), r3;
    }, _setIconStyles: function(e5, t4) {
      var n3 = this.options, r3 = n3[t4 + `Size`];
      typeof r3 == `number` && (r3 = [r3, r3]);
      var i3 = T2(r3), a3 = T2(t4 === `shadow` && n3.shadowAnchor || n3.iconAnchor || i3 && i3.divideBy(2, true));
      e5.className = `leaflet-marker-` + t4 + ` ` + (n3.className || ``), a3 && (e5.style.marginLeft = -a3.x + `px`, e5.style.marginTop = -a3.y + `px`), i3 && (e5.style.width = i3.x + `px`, e5.style.height = i3.y + `px`);
    }, _createImg: function(e5, t4) {
      return t4 || (t4 = document.createElement(`img`)), t4.src = e5, t4;
    }, _getIconUrl: function(e5) {
      return I.retina && this.options[e5 + `RetinaUrl`] || this.options[e5 + `Url`];
    } });
    function Zn(e5) {
      return new Xn(e5);
    }
    var Qn = Xn.extend({ options: { iconUrl: `marker-icon.png`, iconRetinaUrl: `marker-icon-2x.png`, shadowUrl: `marker-shadow.png`, iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], tooltipAnchor: [16, -28], shadowSize: [41, 41] }, _getIconUrl: function(e5) {
      return typeof Qn.imagePath != `string` && (Qn.imagePath = this._detectIconPath()), (this.options.imagePath || Qn.imagePath) + Xn.prototype._getIconUrl.call(this, e5);
    }, _stripUrl: function(e5) {
      var t4 = function(e6, t5, n3) {
        var r3 = t5.exec(e6);
        return r3 && r3[n3];
      };
      return e5 = t4(e5, /^url\((['"])?(.+)\1\)$/, 2), e5 && t4(e5, /^(.*)marker-icon\.png$/, 1);
    }, _detectIconPath: function() {
      var e5 = R(`div`, `leaflet-default-icon-path`, document.body), t4 = Ct(e5, `background-image`) || Ct(e5, `backgroundImage`);
      if (document.body.removeChild(e5), t4 = this._stripUrl(t4), t4) return t4;
      var n3 = document.querySelector(`link[href$="leaflet.css"]`);
      return n3 ? n3.href.substring(0, n3.href.length - 11 - 1) : ``;
    } }), $n = X.extend({ initialize: function(e5) {
      this._marker = e5;
    }, addHooks: function() {
      var e5 = this._marker._icon;
      this._draggable || (this._draggable = new bn(e5, e5, true)), this._draggable.on({ dragstart: this._onDragStart, predrag: this._onPreDrag, drag: this._onDrag, dragend: this._onDragEnd }, this).enable(), B(e5, `leaflet-marker-draggable`);
    }, removeHooks: function() {
      this._draggable.off({ dragstart: this._onDragStart, predrag: this._onPreDrag, drag: this._onDrag, dragend: this._onDragEnd }, this).disable(), this._marker._icon && V(this._marker._icon, `leaflet-marker-draggable`);
    }, moved: function() {
      return this._draggable && this._draggable._moved;
    }, _adjustPan: function(e5) {
      var t4 = this._marker, n3 = t4._map, r3 = this._marker.options.autoPanSpeed, i3 = this._marker.options.autoPanPadding, a3 = Nt(t4._icon), o3 = n3.getPixelBounds(), s3 = n3.getPixelOrigin(), c3 = D2(o3.min._subtract(s3).add(i3), o3.max._subtract(s3).subtract(i3));
      if (!c3.contains(a3)) {
        var l3 = T2((Math.max(c3.max.x, a3.x) - c3.max.x) / (o3.max.x - c3.max.x) - (Math.min(c3.min.x, a3.x) - c3.min.x) / (o3.min.x - c3.min.x), (Math.max(c3.max.y, a3.y) - c3.max.y) / (o3.max.y - c3.max.y) - (Math.min(c3.min.y, a3.y) - c3.min.y) / (o3.min.y - c3.min.y)).multiplyBy(r3);
        n3.panBy(l3, { animate: false }), this._draggable._newPos._add(l3), this._draggable._startPos._add(l3), U(t4._icon, this._draggable._newPos), this._onDrag(e5), this._panRequest = b2(this._adjustPan.bind(this, e5));
      }
    }, _onDragStart: function() {
      this._oldLatLng = this._marker.getLatLng(), this._marker.closePopup && this._marker.closePopup(), this._marker.fire(`movestart`).fire(`dragstart`);
    }, _onPreDrag: function(e5) {
      this._marker.options.autoPan && (x2(this._panRequest), this._panRequest = b2(this._adjustPan.bind(this, e5)));
    }, _onDrag: function(e5) {
      var t4 = this._marker, n3 = t4._shadow, r3 = Nt(t4._icon), i3 = t4._map.layerPointToLatLng(r3);
      n3 && U(n3, r3), t4._latlng = i3, e5.latlng = i3, e5.oldLatLng = this._oldLatLng, t4.fire(`move`, e5).fire(`drag`, e5);
    }, _onDragEnd: function(e5) {
      x2(this._panRequest), delete this._oldLatLng, this._marker.fire(`moveend`).fire(`dragend`, e5);
    } }), er = Q.extend({ options: { icon: new Qn(), interactive: true, keyboard: true, title: ``, alt: `Marker`, zIndexOffset: 0, opacity: 1, riseOnHover: false, riseOffset: 250, pane: `markerPane`, shadowPane: `shadowPane`, bubblingMouseEvents: false, autoPanOnFocus: true, draggable: false, autoPan: false, autoPanPadding: [50, 50], autoPanSpeed: 10 }, initialize: function(e5, t4) {
      p2(this, t4), this._latlng = j2(e5);
    }, onAdd: function(e5) {
      this._zoomAnimated = this._zoomAnimated && e5.options.markerZoomAnimation, this._zoomAnimated && e5.on(`zoomanim`, this._animateZoom, this), this._initIcon(), this.update();
    }, onRemove: function(e5) {
      this.dragging && this.dragging.enabled() && (this.options.draggable = true, this.dragging.removeHooks()), delete this.dragging, this._zoomAnimated && e5.off(`zoomanim`, this._animateZoom, this), this._removeIcon(), this._removeShadow();
    }, getEvents: function() {
      return { zoom: this.update, viewreset: this.update };
    }, getLatLng: function() {
      return this._latlng;
    }, setLatLng: function(e5) {
      var t4 = this._latlng;
      return this._latlng = j2(e5), this.update(), this.fire(`move`, { oldLatLng: t4, latlng: this._latlng });
    }, setZIndexOffset: function(e5) {
      return this.options.zIndexOffset = e5, this.update();
    }, getIcon: function() {
      return this.options.icon;
    }, setIcon: function(e5) {
      return this.options.icon = e5, this._map && (this._initIcon(), this.update()), this._popup && this.bindPopup(this._popup, this._popup.options), this;
    }, getElement: function() {
      return this._icon;
    }, update: function() {
      if (this._icon && this._map) {
        var e5 = this._map.latLngToLayerPoint(this._latlng).round();
        this._setPos(e5);
      }
      return this;
    }, _initIcon: function() {
      var e5 = this.options, t4 = `leaflet-zoom-` + (this._zoomAnimated ? `animated` : `hide`), n3 = e5.icon.createIcon(this._icon), r3 = false;
      n3 !== this._icon && (this._icon && this._removeIcon(), r3 = true, e5.title && (n3.title = e5.title), n3.tagName === `IMG` && (n3.alt = e5.alt || ``)), B(n3, t4), e5.keyboard && (n3.tabIndex = `0`, n3.setAttribute(`role`, `button`)), this._icon = n3, e5.riseOnHover && this.on({ mouseover: this._bringToFront, mouseout: this._resetZIndex }), this.options.autoPanOnFocus && W(n3, `focus`, this._panOnFocus, this);
      var i3 = e5.icon.createShadow(this._shadow), a3 = false;
      i3 !== this._shadow && (this._removeShadow(), a3 = true), i3 && (B(i3, t4), i3.alt = ``), this._shadow = i3, e5.opacity < 1 && this._updateOpacity(), r3 && this.getPane().appendChild(this._icon), this._initInteraction(), i3 && a3 && this.getPane(e5.shadowPane).appendChild(this._shadow);
    }, _removeIcon: function() {
      this.options.riseOnHover && this.off({ mouseover: this._bringToFront, mouseout: this._resetZIndex }), this.options.autoPanOnFocus && K(this._icon, `focus`, this._panOnFocus, this), z(this._icon), this.removeInteractiveTarget(this._icon), this._icon = null;
    }, _removeShadow: function() {
      this._shadow && z(this._shadow), this._shadow = null;
    }, _setPos: function(e5) {
      this._icon && U(this._icon, e5), this._shadow && U(this._shadow, e5), this._zIndex = e5.y + this.options.zIndexOffset, this._resetZIndex();
    }, _updateZIndex: function(e5) {
      this._icon && (this._icon.style.zIndex = this._zIndex + e5);
    }, _animateZoom: function(e5) {
      var t4 = this._map._latLngToNewLayerPoint(this._latlng, e5.zoom, e5.center).round();
      this._setPos(t4);
    }, _initInteraction: function() {
      if (this.options.interactive && (B(this._icon, `leaflet-interactive`), this.addInteractiveTarget(this._icon), $n)) {
        var e5 = this.options.draggable;
        this.dragging && (e5 = this.dragging.enabled(), this.dragging.disable()), this.dragging = new $n(this), e5 && this.dragging.enable();
      }
    }, setOpacity: function(e5) {
      return this.options.opacity = e5, this._map && this._updateOpacity(), this;
    }, _updateOpacity: function() {
      var e5 = this.options.opacity;
      this._icon && H(this._icon, e5), this._shadow && H(this._shadow, e5);
    }, _bringToFront: function() {
      this._updateZIndex(this.options.riseOffset);
    }, _resetZIndex: function() {
      this._updateZIndex(0);
    }, _panOnFocus: function() {
      var e5 = this._map;
      if (e5) {
        var t4 = this.options.icon.options, n3 = t4.iconSize ? T2(t4.iconSize) : T2(0, 0), r3 = t4.iconAnchor ? T2(t4.iconAnchor) : T2(0, 0);
        e5.panInside(this._latlng, { paddingTopLeft: r3, paddingBottomRight: n3.subtract(r3) });
      }
    }, _getPopupAnchor: function() {
      return this.options.icon.options.popupAnchor;
    }, _getTooltipAnchor: function() {
      return this.options.icon.options.tooltipAnchor;
    } });
    function tr(e5, t4) {
      return new er(e5, t4);
    }
    var nr = Q.extend({ options: { stroke: true, color: `#3388ff`, weight: 3, opacity: 1, lineCap: `round`, lineJoin: `round`, dashArray: null, dashOffset: null, fill: false, fillColor: null, fillOpacity: 0.2, fillRule: `evenodd`, interactive: true, bubblingMouseEvents: true }, beforeAdd: function(e5) {
      this._renderer = e5.getRenderer(this);
    }, onAdd: function() {
      this._renderer._initPath(this), this._reset(), this._renderer._addPath(this);
    }, onRemove: function() {
      this._renderer._removePath(this);
    }, redraw: function() {
      return this._map && this._renderer._updatePath(this), this;
    }, setStyle: function(e5) {
      return p2(this, e5), this._renderer && (this._renderer._updateStyle(this), this.options.stroke && e5 && Object.prototype.hasOwnProperty.call(e5, `weight`) && this._updateBounds()), this;
    }, bringToFront: function() {
      return this._renderer && this._renderer._bringToFront(this), this;
    }, bringToBack: function() {
      return this._renderer && this._renderer._bringToBack(this), this;
    }, getElement: function() {
      return this._path;
    }, _reset: function() {
      this._project(), this._update();
    }, _clickTolerance: function() {
      return (this.options.stroke ? this.options.weight / 2 : 0) + (this._renderer.options.tolerance || 0);
    } }), rr = nr.extend({ options: { fill: true, radius: 10 }, initialize: function(e5, t4) {
      p2(this, t4), this._latlng = j2(e5), this._radius = this.options.radius;
    }, setLatLng: function(e5) {
      var t4 = this._latlng;
      return this._latlng = j2(e5), this.redraw(), this.fire(`move`, { oldLatLng: t4, latlng: this._latlng });
    }, getLatLng: function() {
      return this._latlng;
    }, setRadius: function(e5) {
      return this.options.radius = this._radius = e5, this.redraw();
    }, getRadius: function() {
      return this._radius;
    }, setStyle: function(e5) {
      var t4 = e5 && e5.radius || this._radius;
      return nr.prototype.setStyle.call(this, e5), this.setRadius(t4), this;
    }, _project: function() {
      this._point = this._map.latLngToLayerPoint(this._latlng), this._updateBounds();
    }, _updateBounds: function() {
      var e5 = this._radius, t4 = this._radiusY || e5, n3 = this._clickTolerance(), r3 = [e5 + n3, t4 + n3];
      this._pxBounds = new E2(this._point.subtract(r3), this._point.add(r3));
    }, _update: function() {
      this._map && this._updatePath();
    }, _updatePath: function() {
      this._renderer._updateCircle(this);
    }, _empty: function() {
      return this._radius && !this._renderer._bounds.intersects(this._pxBounds);
    }, _containsPoint: function(e5) {
      return e5.distanceTo(this._point) <= this._radius + this._clickTolerance();
    } });
    function ir(e5, t4) {
      return new rr(e5, t4);
    }
    var ar = rr.extend({ initialize: function(e5, t4, r3) {
      if (typeof t4 == `number` && (t4 = n2({}, r3, { radius: t4 })), p2(this, t4), this._latlng = j2(e5), isNaN(this.options.radius)) throw Error(`Circle radius cannot be NaN`);
      this._mRadius = this.options.radius;
    }, setRadius: function(e5) {
      return this._mRadius = e5, this.redraw();
    }, getRadius: function() {
      return this._mRadius;
    }, getBounds: function() {
      var e5 = [this._radius, this._radiusY || this._radius];
      return new O2(this._map.layerPointToLatLng(this._point.subtract(e5)), this._map.layerPointToLatLng(this._point.add(e5)));
    }, setStyle: nr.prototype.setStyle, _project: function() {
      var e5 = this._latlng.lng, t4 = this._latlng.lat, n3 = this._map, r3 = n3.options.crs;
      if (r3.distance === N2.distance) {
        var i3 = Math.PI / 180, a3 = this._mRadius / N2.R / i3, o3 = n3.project([t4 + a3, e5]), s3 = n3.project([t4 - a3, e5]), c3 = o3.add(s3).divideBy(2), l3 = n3.unproject(c3).lat, u3 = Math.acos((Math.cos(a3 * i3) - Math.sin(t4 * i3) * Math.sin(l3 * i3)) / (Math.cos(t4 * i3) * Math.cos(l3 * i3))) / i3;
        (isNaN(u3) || u3 === 0) && (u3 = a3 / Math.cos(Math.PI / 180 * t4)), this._point = c3.subtract(n3.getPixelOrigin()), this._radius = isNaN(u3) ? 0 : c3.x - n3.project([l3, e5 - u3]).x, this._radiusY = c3.y - o3.y;
      } else {
        var d3 = r3.unproject(r3.project(this._latlng).subtract([this._mRadius, 0]));
        this._point = n3.latLngToLayerPoint(this._latlng), this._radius = this._point.x - n3.latLngToLayerPoint(d3).x;
      }
      this._updateBounds();
    } });
    function or(e5, t4, n3) {
      return new ar(e5, t4, n3);
    }
    var sr = nr.extend({ options: { smoothFactor: 1, noClip: false }, initialize: function(e5, t4) {
      p2(this, t4), this._setLatLngs(e5);
    }, getLatLngs: function() {
      return this._latlngs;
    }, setLatLngs: function(e5) {
      return this._setLatLngs(e5), this.redraw();
    }, isEmpty: function() {
      return !this._latlngs.length;
    }, closestLayerPoint: function(e5) {
      for (var t4 = 1 / 0, n3 = null, r3 = In, i3, a3, o3 = 0, s3 = this._parts.length; o3 < s3; o3++) for (var c3 = this._parts[o3], l3 = 1, u3 = c3.length; l3 < u3; l3++) {
        i3 = c3[l3 - 1], a3 = c3[l3];
        var d3 = r3(e5, i3, a3, true);
        d3 < t4 && (t4 = d3, n3 = r3(e5, i3, a3));
      }
      return n3 && (n3.distance = Math.sqrt(t4)), n3;
    }, getCenter: function() {
      if (!this._map) throw Error(`Must add layer to map before using getCenter()`);
      return Rn(this._defaultShape(), this._map.options.crs);
    }, getBounds: function() {
      return this._bounds;
    }, addLatLng: function(e5, t4) {
      return t4 || (t4 = this._defaultShape()), e5 = j2(e5), t4.push(e5), this._bounds.extend(e5), this.redraw();
    }, _setLatLngs: function(e5) {
      this._bounds = new O2(), this._latlngs = this._convertLatLngs(e5);
    }, _defaultShape: function() {
      return Z(this._latlngs) ? this._latlngs : this._latlngs[0];
    }, _convertLatLngs: function(e5) {
      for (var t4 = [], n3 = Z(e5), r3 = 0, i3 = e5.length; r3 < i3; r3++) n3 ? (t4[r3] = j2(e5[r3]), this._bounds.extend(t4[r3])) : t4[r3] = this._convertLatLngs(e5[r3]);
      return t4;
    }, _project: function() {
      var e5 = new E2();
      this._rings = [], this._projectLatlngs(this._latlngs, this._rings, e5), this._bounds.isValid() && e5.isValid() && (this._rawPxBounds = e5, this._updateBounds());
    }, _updateBounds: function() {
      var e5 = this._clickTolerance(), t4 = new w2(e5, e5);
      this._rawPxBounds && (this._pxBounds = new E2([this._rawPxBounds.min.subtract(t4), this._rawPxBounds.max.add(t4)]));
    }, _projectLatlngs: function(e5, t4, n3) {
      var r3 = e5[0] instanceof A2, i3 = e5.length, a3, o3;
      if (r3) {
        for (o3 = [], a3 = 0; a3 < i3; a3++) o3[a3] = this._map.latLngToLayerPoint(e5[a3]), n3.extend(o3[a3]);
        t4.push(o3);
      } else for (a3 = 0; a3 < i3; a3++) this._projectLatlngs(e5[a3], t4, n3);
    }, _clipPoints: function() {
      var e5 = this._renderer._bounds;
      if (this._parts = [], this._pxBounds && this._pxBounds.intersects(e5)) {
        if (this.options.noClip) {
          this._parts = this._rings;
          return;
        }
        for (var t4 = this._parts, n3 = 0, r3, i3 = 0, a3 = this._rings.length, o3, s3, c3; n3 < a3; n3++) for (c3 = this._rings[n3], r3 = 0, o3 = c3.length; r3 < o3 - 1; r3++) s3 = Mn(c3[r3], c3[r3 + 1], e5, r3, true), s3 && (t4[i3] = t4[i3] || [], t4[i3].push(s3[0]), (s3[1] !== c3[r3 + 1] || r3 === o3 - 2) && (t4[i3].push(s3[1]), i3++));
      }
    }, _simplifyPoints: function() {
      for (var e5 = this._parts, t4 = this.options.smoothFactor, n3 = 0, r3 = e5.length; n3 < r3; n3++) e5[n3] = Tn(e5[n3], t4);
    }, _update: function() {
      this._map && (this._clipPoints(), this._simplifyPoints(), this._updatePath());
    }, _updatePath: function() {
      this._renderer._updatePoly(this);
    }, _containsPoint: function(e5, t4) {
      var n3, r3, i3, a3, o3, s3, c3 = this._clickTolerance();
      if (!this._pxBounds || !this._pxBounds.contains(e5)) return false;
      for (n3 = 0, a3 = this._parts.length; n3 < a3; n3++) for (s3 = this._parts[n3], r3 = 0, o3 = s3.length, i3 = o3 - 1; r3 < o3; i3 = r3++) if ((t4 || r3 !== 0) && En(e5, s3[i3], s3[r3]) <= c3) return true;
      return false;
    } });
    function cr(e5, t4) {
      return new sr(e5, t4);
    }
    sr._flat = Ln;
    var lr = sr.extend({ options: { fill: true }, isEmpty: function() {
      return !this._latlngs.length || !this._latlngs[0].length;
    }, getCenter: function() {
      if (!this._map) throw Error(`Must add layer to map before using getCenter()`);
      return Sn(this._defaultShape(), this._map.options.crs);
    }, _convertLatLngs: function(e5) {
      var t4 = sr.prototype._convertLatLngs.call(this, e5), n3 = t4.length;
      return n3 >= 2 && t4[0] instanceof A2 && t4[0].equals(t4[n3 - 1]) && t4.pop(), t4;
    }, _setLatLngs: function(e5) {
      sr.prototype._setLatLngs.call(this, e5), Z(this._latlngs) && (this._latlngs = [this._latlngs]);
    }, _defaultShape: function() {
      return Z(this._latlngs[0]) ? this._latlngs[0] : this._latlngs[0][0];
    }, _clipPoints: function() {
      var e5 = this._renderer._bounds, t4 = this.options.weight, n3 = new w2(t4, t4);
      if (e5 = new E2(e5.min.subtract(n3), e5.max.add(n3)), this._parts = [], this._pxBounds && this._pxBounds.intersects(e5)) {
        if (this.options.noClip) {
          this._parts = this._rings;
          return;
        }
        for (var r3 = 0, i3 = this._rings.length, a3; r3 < i3; r3++) a3 = xn(this._rings[r3], e5, true), a3.length && this._parts.push(a3);
      }
    }, _updatePath: function() {
      this._renderer._updatePoly(this, true);
    }, _containsPoint: function(e5) {
      var t4 = false, n3, r3, i3, a3, o3, s3, c3, l3;
      if (!this._pxBounds || !this._pxBounds.contains(e5)) return false;
      for (a3 = 0, c3 = this._parts.length; a3 < c3; a3++) for (n3 = this._parts[a3], o3 = 0, l3 = n3.length, s3 = l3 - 1; o3 < l3; s3 = o3++) r3 = n3[o3], i3 = n3[s3], r3.y > e5.y != i3.y > e5.y && e5.x < (i3.x - r3.x) * (e5.y - r3.y) / (i3.y - r3.y) + r3.x && (t4 = !t4);
      return t4 || sr.prototype._containsPoint.call(this, e5, true);
    } });
    function ur(e5, t4) {
      return new lr(e5, t4);
    }
    var dr = Jn.extend({ initialize: function(e5, t4) {
      p2(this, t4), this._layers = {}, e5 && this.addData(e5);
    }, addData: function(e5) {
      var t4 = _2(e5) ? e5 : e5.features, n3, r3, i3;
      if (t4) {
        for (n3 = 0, r3 = t4.length; n3 < r3; n3++) i3 = t4[n3], (i3.geometries || i3.geometry || i3.features || i3.coordinates) && this.addData(i3);
        return this;
      }
      var a3 = this.options;
      if (a3.filter && !a3.filter(e5)) return this;
      var o3 = fr(e5, a3);
      return o3 ? (o3.feature = yr(e5), o3.defaultOptions = o3.options, this.resetStyle(o3), a3.onEachFeature && a3.onEachFeature(e5, o3), this.addLayer(o3)) : this;
    }, resetStyle: function(e5) {
      return e5 === void 0 ? this.eachLayer(this.resetStyle, this) : (e5.options = n2({}, e5.defaultOptions), this._setLayerStyle(e5, this.options.style), this);
    }, setStyle: function(e5) {
      return this.eachLayer(function(t4) {
        this._setLayerStyle(t4, e5);
      }, this);
    }, _setLayerStyle: function(e5, t4) {
      e5.setStyle && (typeof t4 == `function` && (t4 = t4(e5.feature)), e5.setStyle(t4));
    } });
    function fr(e5, t4) {
      var n3 = e5.type === `Feature` ? e5.geometry : e5, r3 = n3 ? n3.coordinates : null, i3 = [], a3 = t4 && t4.pointToLayer, o3 = t4 && t4.coordsToLatLng || mr, s3, c3, l3, u3;
      if (!r3 && !n3) return null;
      switch (n3.type) {
        case `Point`:
          return s3 = o3(r3), pr(a3, e5, s3, t4);
        case `MultiPoint`:
          for (l3 = 0, u3 = r3.length; l3 < u3; l3++) s3 = o3(r3[l3]), i3.push(pr(a3, e5, s3, t4));
          return new Jn(i3);
        case `LineString`:
        case `MultiLineString`:
          return c3 = hr(r3, n3.type === `LineString` ? 0 : 1, o3), new sr(c3, t4);
        case `Polygon`:
        case `MultiPolygon`:
          return c3 = hr(r3, n3.type === `Polygon` ? 1 : 2, o3), new lr(c3, t4);
        case `GeometryCollection`:
          for (l3 = 0, u3 = n3.geometries.length; l3 < u3; l3++) {
            var d3 = fr({ geometry: n3.geometries[l3], type: `Feature`, properties: e5.properties }, t4);
            d3 && i3.push(d3);
          }
          return new Jn(i3);
        case `FeatureCollection`:
          for (l3 = 0, u3 = n3.features.length; l3 < u3; l3++) {
            var f3 = fr(n3.features[l3], t4);
            f3 && i3.push(f3);
          }
          return new Jn(i3);
        default:
          throw Error(`Invalid GeoJSON object.`);
      }
    }
    function pr(e5, t4, n3, r3) {
      return e5 ? e5(t4, n3) : new er(n3, r3 && r3.markersInheritOptions && r3);
    }
    function mr(e5) {
      return new A2(e5[1], e5[0], e5[2]);
    }
    function hr(e5, t4, n3) {
      for (var r3 = [], i3 = 0, a3 = e5.length, o3; i3 < a3; i3++) o3 = t4 ? hr(e5[i3], t4 - 1, n3) : (n3 || mr)(e5[i3]), r3.push(o3);
      return r3;
    }
    function gr(e5, t4) {
      return e5 = j2(e5), e5.alt === void 0 ? [u2(e5.lng, t4), u2(e5.lat, t4)] : [u2(e5.lng, t4), u2(e5.lat, t4), u2(e5.alt, t4)];
    }
    function _r(e5, t4, n3, r3) {
      for (var i3 = [], a3 = 0, o3 = e5.length; a3 < o3; a3++) i3.push(t4 ? _r(e5[a3], Z(e5[a3]) ? 0 : t4 - 1, n3, r3) : gr(e5[a3], r3));
      return !t4 && n3 && i3.length > 0 && i3.push(i3[0].slice()), i3;
    }
    function vr(e5, t4) {
      return e5.feature ? n2({}, e5.feature, { geometry: t4 }) : yr(t4);
    }
    function yr(e5) {
      return e5.type === `Feature` || e5.type === `FeatureCollection` ? e5 : { type: `Feature`, properties: {}, geometry: e5 };
    }
    var br = { toGeoJSON: function(e5) {
      return vr(this, { type: `Point`, coordinates: gr(this.getLatLng(), e5) });
    } };
    er.include(br), ar.include(br), rr.include(br), sr.include({ toGeoJSON: function(e5) {
      var t4 = !Z(this._latlngs), n3 = _r(this._latlngs, +!!t4, false, e5);
      return vr(this, { type: (t4 ? `Multi` : ``) + `LineString`, coordinates: n3 });
    } }), lr.include({ toGeoJSON: function(e5) {
      var t4 = !Z(this._latlngs), n3 = t4 && !Z(this._latlngs[0]), r3 = _r(this._latlngs, n3 ? 2 : +!!t4, true, e5);
      return t4 || (r3 = [r3]), vr(this, { type: (n3 ? `Multi` : ``) + `Polygon`, coordinates: r3 });
    } }), Kn.include({ toMultiPoint: function(e5) {
      var t4 = [];
      return this.eachLayer(function(n3) {
        t4.push(n3.toGeoJSON(e5).geometry.coordinates);
      }), vr(this, { type: `MultiPoint`, coordinates: t4 });
    }, toGeoJSON: function(e5) {
      var t4 = this.feature && this.feature.geometry && this.feature.geometry.type;
      if (t4 === `MultiPoint`) return this.toMultiPoint(e5);
      var n3 = t4 === `GeometryCollection`, r3 = [];
      return this.eachLayer(function(t5) {
        if (t5.toGeoJSON) {
          var i3 = t5.toGeoJSON(e5);
          if (n3) r3.push(i3.geometry);
          else {
            var a3 = yr(i3);
            a3.type === `FeatureCollection` ? r3.push.apply(r3, a3.features) : r3.push(a3);
          }
        }
      }), n3 ? vr(this, { geometries: r3, type: `GeometryCollection` }) : { type: `FeatureCollection`, features: r3 };
    } });
    function xr(e5, t4) {
      return new dr(e5, t4);
    }
    var Sr = xr, Cr = Q.extend({ options: { opacity: 1, alt: ``, interactive: false, crossOrigin: false, errorOverlayUrl: ``, zIndex: 1, className: `` }, initialize: function(e5, t4, n3) {
      this._url = e5, this._bounds = k2(t4), p2(this, n3);
    }, onAdd: function() {
      this._image || (this._initImage(), this.options.opacity < 1 && this._updateOpacity()), this.options.interactive && (B(this._image, `leaflet-interactive`), this.addInteractiveTarget(this._image)), this.getPane().appendChild(this._image), this._reset();
    }, onRemove: function() {
      z(this._image), this.options.interactive && this.removeInteractiveTarget(this._image);
    }, setOpacity: function(e5) {
      return this.options.opacity = e5, this._image && this._updateOpacity(), this;
    }, setStyle: function(e5) {
      return e5.opacity && this.setOpacity(e5.opacity), this;
    }, bringToFront: function() {
      return this._map && Tt(this._image), this;
    }, bringToBack: function() {
      return this._map && Et(this._image), this;
    }, setUrl: function(e5) {
      return this._url = e5, this._image && (this._image.src = e5), this;
    }, setBounds: function(e5) {
      return this._bounds = k2(e5), this._map && this._reset(), this;
    }, getEvents: function() {
      var e5 = { zoom: this._reset, viewreset: this._reset };
      return this._zoomAnimated && (e5.zoomanim = this._animateZoom), e5;
    }, setZIndex: function(e5) {
      return this.options.zIndex = e5, this._updateZIndex(), this;
    }, getBounds: function() {
      return this._bounds;
    }, getElement: function() {
      return this._image;
    }, _initImage: function() {
      var e5 = this._url.tagName === `IMG`, t4 = this._image = e5 ? this._url : R(`img`);
      if (B(t4, `leaflet-image-layer`), this._zoomAnimated && B(t4, `leaflet-zoom-animated`), this.options.className && B(t4, this.options.className), t4.onselectstart = l2, t4.onmousemove = l2, t4.onload = i2(this.fire, this, `load`), t4.onerror = i2(this._overlayOnError, this, `error`), (this.options.crossOrigin || this.options.crossOrigin === ``) && (t4.crossOrigin = this.options.crossOrigin === true ? `` : this.options.crossOrigin), this.options.zIndex && this._updateZIndex(), e5) {
        this._url = t4.src;
        return;
      }
      t4.src = this._url, t4.alt = this.options.alt;
    }, _animateZoom: function(e5) {
      var t4 = this._map.getZoomScale(e5.zoom), n3 = this._map._latLngBoundsToNewLayerBounds(this._bounds, e5.zoom, e5.center).min;
      Mt(this._image, n3, t4);
    }, _reset: function() {
      var e5 = this._image, t4 = new E2(this._map.latLngToLayerPoint(this._bounds.getNorthWest()), this._map.latLngToLayerPoint(this._bounds.getSouthEast())), n3 = t4.getSize();
      U(e5, t4.min), e5.style.width = n3.x + `px`, e5.style.height = n3.y + `px`;
    }, _updateOpacity: function() {
      H(this._image, this.options.opacity);
    }, _updateZIndex: function() {
      this._image && this.options.zIndex !== void 0 && this.options.zIndex !== null && (this._image.style.zIndex = this.options.zIndex);
    }, _overlayOnError: function() {
      this.fire(`error`);
      var e5 = this.options.errorOverlayUrl;
      e5 && this._url !== e5 && (this._url = e5, this._image.src = e5);
    }, getCenter: function() {
      return this._bounds.getCenter();
    } }), wr = function(e5, t4, n3) {
      return new Cr(e5, t4, n3);
    }, Tr = Cr.extend({ options: { autoplay: true, loop: true, keepAspectRatio: true, muted: false, playsInline: true }, _initImage: function() {
      var e5 = this._url.tagName === `VIDEO`, t4 = this._image = e5 ? this._url : R(`video`);
      if (B(t4, `leaflet-image-layer`), this._zoomAnimated && B(t4, `leaflet-zoom-animated`), this.options.className && B(t4, this.options.className), t4.onselectstart = l2, t4.onmousemove = l2, t4.onloadeddata = i2(this.fire, this, `load`), e5) {
        for (var n3 = t4.getElementsByTagName(`source`), r3 = [], a3 = 0; a3 < n3.length; a3++) r3.push(n3[a3].src);
        this._url = n3.length > 0 ? r3 : [t4.src];
        return;
      }
      _2(this._url) || (this._url = [this._url]), !this.options.keepAspectRatio && Object.prototype.hasOwnProperty.call(t4.style, `objectFit`) && (t4.style.objectFit = `fill`), t4.autoplay = !!this.options.autoplay, t4.loop = !!this.options.loop, t4.muted = !!this.options.muted, t4.playsInline = !!this.options.playsInline;
      for (var o3 = 0; o3 < this._url.length; o3++) {
        var s3 = R(`source`);
        s3.src = this._url[o3], t4.appendChild(s3);
      }
    } });
    function Er(e5, t4, n3) {
      return new Tr(e5, t4, n3);
    }
    var Dr = Cr.extend({ _initImage: function() {
      var e5 = this._image = this._url;
      B(e5, `leaflet-image-layer`), this._zoomAnimated && B(e5, `leaflet-zoom-animated`), this.options.className && B(e5, this.options.className), e5.onselectstart = l2, e5.onmousemove = l2;
    } });
    function Or(e5, t4, n3) {
      return new Dr(e5, t4, n3);
    }
    var $ = Q.extend({ options: { interactive: false, offset: [0, 0], className: ``, pane: void 0, content: `` }, initialize: function(e5, t4) {
      e5 && (e5 instanceof A2 || _2(e5)) ? (this._latlng = j2(e5), p2(this, t4)) : (p2(this, e5), this._source = t4), this.options.content && (this._content = this.options.content);
    }, openOn: function(e5) {
      return e5 = arguments.length ? e5 : this._source._map, e5.hasLayer(this) || e5.addLayer(this), this;
    }, close: function() {
      return this._map && this._map.removeLayer(this), this;
    }, toggle: function(e5) {
      return this._map ? this.close() : (arguments.length ? this._source = e5 : e5 = this._source, this._prepareOpen(), this.openOn(e5._map)), this;
    }, onAdd: function(e5) {
      this._zoomAnimated = e5._zoomAnimated, this._container || this._initLayout(), e5._fadeAnimated && H(this._container, 0), clearTimeout(this._removeTimeout), this.getPane().appendChild(this._container), this.update(), e5._fadeAnimated && H(this._container, 1), this.bringToFront(), this.options.interactive && (B(this._container, `leaflet-interactive`), this.addInteractiveTarget(this._container));
    }, onRemove: function(e5) {
      e5._fadeAnimated ? (H(this._container, 0), this._removeTimeout = setTimeout(i2(z, void 0, this._container), 200)) : z(this._container), this.options.interactive && (V(this._container, `leaflet-interactive`), this.removeInteractiveTarget(this._container));
    }, getLatLng: function() {
      return this._latlng;
    }, setLatLng: function(e5) {
      return this._latlng = j2(e5), this._map && (this._updatePosition(), this._adjustPan()), this;
    }, getContent: function() {
      return this._content;
    }, setContent: function(e5) {
      return this._content = e5, this.update(), this;
    }, getElement: function() {
      return this._container;
    }, update: function() {
      this._map && (this._container.style.visibility = `hidden`, this._updateContent(), this._updateLayout(), this._updatePosition(), this._container.style.visibility = ``, this._adjustPan());
    }, getEvents: function() {
      var e5 = { zoom: this._updatePosition, viewreset: this._updatePosition };
      return this._zoomAnimated && (e5.zoomanim = this._animateZoom), e5;
    }, isOpen: function() {
      return !!this._map && this._map.hasLayer(this);
    }, bringToFront: function() {
      return this._map && Tt(this._container), this;
    }, bringToBack: function() {
      return this._map && Et(this._container), this;
    }, _prepareOpen: function(e5) {
      var t4 = this._source;
      if (!t4._map) return false;
      if (t4 instanceof Jn) {
        t4 = null;
        var n3 = this._source._layers;
        for (var r3 in n3) if (n3[r3]._map) {
          t4 = n3[r3];
          break;
        }
        if (!t4) return false;
        this._source = t4;
      }
      if (!e5) {
        if (t4.getCenter) e5 = t4.getCenter();
        else if (t4.getLatLng) e5 = t4.getLatLng();
        else if (t4.getBounds) e5 = t4.getBounds().getCenter();
        else throw Error(`Unable to get source layer LatLng.`);
      }
      return this.setLatLng(e5), this._map && this.update(), true;
    }, _updateContent: function() {
      if (this._content) {
        var e5 = this._contentNode, t4 = typeof this._content == `function` ? this._content(this._source || this) : this._content;
        if (typeof t4 == `string`) e5.innerHTML = t4;
        else {
          for (; e5.hasChildNodes(); ) e5.removeChild(e5.firstChild);
          e5.appendChild(t4);
        }
        this.fire(`contentupdate`);
      }
    }, _updatePosition: function() {
      if (this._map) {
        var e5 = this._map.latLngToLayerPoint(this._latlng), t4 = T2(this.options.offset), n3 = this._getAnchor();
        this._zoomAnimated ? U(this._container, e5.add(n3)) : t4 = t4.add(e5).add(n3);
        var r3 = this._containerBottom = -t4.y, i3 = this._containerLeft = -Math.round(this._containerWidth / 2) + t4.x;
        this._container.style.bottom = r3 + `px`, this._container.style.left = i3 + `px`;
      }
    }, _getAnchor: function() {
      return [0, 0];
    } });
    J.include({ _initOverlay: function(e5, t4, n3, r3) {
      var i3 = t4;
      return i3 instanceof e5 || (i3 = new e5(r3).setContent(t4)), n3 && i3.setLatLng(n3), i3;
    } }), Q.include({ _initOverlay: function(e5, t4, n3, r3) {
      var i3 = n3;
      return i3 instanceof e5 ? (p2(i3, r3), i3._source = this) : (i3 = t4 && !r3 ? t4 : new e5(r3, this), i3.setContent(n3)), i3;
    } });
    var kr = $.extend({ options: { pane: `popupPane`, offset: [0, 7], maxWidth: 300, minWidth: 50, maxHeight: null, autoPan: true, autoPanPaddingTopLeft: null, autoPanPaddingBottomRight: null, autoPanPadding: [5, 5], keepInView: false, closeButton: true, autoClose: true, closeOnEscapeKey: true, className: `` }, openOn: function(e5) {
      return e5 = arguments.length ? e5 : this._source._map, !e5.hasLayer(this) && e5._popup && e5._popup.options.autoClose && e5.removeLayer(e5._popup), e5._popup = this, $.prototype.openOn.call(this, e5);
    }, onAdd: function(e5) {
      $.prototype.onAdd.call(this, e5), e5.fire(`popupopen`, { popup: this }), this._source && (this._source.fire(`popupopen`, { popup: this }, true), this._source instanceof nr || this._source.on(`preclick`, Zt));
    }, onRemove: function(e5) {
      $.prototype.onRemove.call(this, e5), e5.fire(`popupclose`, { popup: this }), this._source && (this._source.fire(`popupclose`, { popup: this }, true), this._source instanceof nr || this._source.off(`preclick`, Zt));
    }, getEvents: function() {
      var e5 = $.prototype.getEvents.call(this);
      return (this.options.closeOnClick === void 0 ? this._map.options.closePopupOnClick : this.options.closeOnClick) && (e5.preclick = this.close), this.options.keepInView && (e5.moveend = this._adjustPan), e5;
    }, _initLayout: function() {
      var e5 = `leaflet-popup`, t4 = this._container = R(`div`, e5 + ` ` + (this.options.className || ``) + ` leaflet-zoom-animated`), n3 = this._wrapper = R(`div`, e5 + `-content-wrapper`, t4);
      if (this._contentNode = R(`div`, e5 + `-content`, n3), $t(t4), Qt(this._contentNode), W(t4, `contextmenu`, Zt), this._tipContainer = R(`div`, e5 + `-tip-container`, t4), this._tip = R(`div`, e5 + `-tip`, this._tipContainer), this.options.closeButton) {
        var r3 = this._closeButton = R(`a`, e5 + `-close-button`, t4);
        r3.setAttribute(`role`, `button`), r3.setAttribute(`aria-label`, `Close popup`), r3.href = `#close`, r3.innerHTML = `<span aria-hidden="true">&#215;</span>`, W(r3, `click`, function(e6) {
          q(e6), this.close();
        }, this);
      }
    }, _updateLayout: function() {
      var e5 = this._contentNode, t4 = e5.style;
      t4.width = ``, t4.whiteSpace = `nowrap`;
      var n3 = e5.offsetWidth;
      n3 = Math.min(n3, this.options.maxWidth), n3 = Math.max(n3, this.options.minWidth), t4.width = n3 + 1 + `px`, t4.whiteSpace = ``, t4.height = ``;
      var r3 = e5.offsetHeight, i3 = this.options.maxHeight, a3 = `leaflet-popup-scrolled`;
      i3 && r3 > i3 ? (t4.height = i3 + `px`, B(e5, a3)) : V(e5, a3), this._containerWidth = this._container.offsetWidth;
    }, _animateZoom: function(e5) {
      var t4 = this._map._latLngToNewLayerPoint(this._latlng, e5.zoom, e5.center), n3 = this._getAnchor();
      U(this._container, t4.add(n3));
    }, _adjustPan: function() {
      if (this.options.autoPan) {
        if (this._map._panAnim && this._map._panAnim.stop(), this._autopanning) {
          this._autopanning = false;
          return;
        }
        var e5 = this._map, t4 = parseInt(Ct(this._container, `marginBottom`), 10) || 0, n3 = this._container.offsetHeight + t4, r3 = this._containerWidth, i3 = new w2(this._containerLeft, -n3 - this._containerBottom);
        i3._add(Nt(this._container));
        var a3 = e5.layerPointToContainerPoint(i3), o3 = T2(this.options.autoPanPadding), s3 = T2(this.options.autoPanPaddingTopLeft || o3), c3 = T2(this.options.autoPanPaddingBottomRight || o3), l3 = e5.getSize(), u3 = 0, d3 = 0;
        a3.x + r3 + c3.x > l3.x && (u3 = a3.x + r3 - l3.x + c3.x), a3.x - u3 - s3.x < 0 && (u3 = a3.x - s3.x), a3.y + n3 + c3.y > l3.y && (d3 = a3.y + n3 - l3.y + c3.y), a3.y - d3 - s3.y < 0 && (d3 = a3.y - s3.y), (u3 || d3) && (this.options.keepInView && (this._autopanning = true), e5.fire(`autopanstart`).panBy([u3, d3]));
      }
    }, _getAnchor: function() {
      return T2(this._source && this._source._getPopupAnchor ? this._source._getPopupAnchor() : [0, 0]);
    } }), Ar = function(e5, t4) {
      return new kr(e5, t4);
    };
    J.mergeOptions({ closePopupOnClick: true }), J.include({ openPopup: function(e5, t4, n3) {
      return this._initOverlay(kr, e5, t4, n3).openOn(this), this;
    }, closePopup: function(e5) {
      return e5 = arguments.length ? e5 : this._popup, e5 && e5.close(), this;
    } }), Q.include({ bindPopup: function(e5, t4) {
      return this._popup = this._initOverlay(kr, this._popup, e5, t4), this._popupHandlersAdded || (this._popupHandlersAdded = (this.on({ click: this._openPopup, keypress: this._onKeyPress, remove: this.closePopup, move: this._movePopup }), true)), this;
    }, unbindPopup: function() {
      return this._popup && (this._popup = (this.off({ click: this._openPopup, keypress: this._onKeyPress, remove: this.closePopup, move: this._movePopup }), this._popupHandlersAdded = false, null)), this;
    }, openPopup: function(e5) {
      return this._popup && (this instanceof Jn || (this._popup._source = this), this._popup._prepareOpen(e5 || this._latlng) && this._popup.openOn(this._map)), this;
    }, closePopup: function() {
      return this._popup && this._popup.close(), this;
    }, togglePopup: function() {
      return this._popup && this._popup.toggle(this), this;
    }, isPopupOpen: function() {
      return this._popup ? this._popup.isOpen() : false;
    }, setPopupContent: function(e5) {
      return this._popup && this._popup.setContent(e5), this;
    }, getPopup: function() {
      return this._popup;
    }, _openPopup: function(e5) {
      if (this._popup && this._map) {
        en(e5);
        var t4 = e5.layer || e5.target;
        if (this._popup._source === t4 && !(t4 instanceof nr)) {
          this._map.hasLayer(this._popup) ? this.closePopup() : this.openPopup(e5.latlng);
          return;
        }
        this._popup._source = t4, this.openPopup(e5.latlng);
      }
    }, _movePopup: function(e5) {
      this._popup.setLatLng(e5.latlng);
    }, _onKeyPress: function(e5) {
      e5.originalEvent.keyCode === 13 && this._openPopup(e5);
    } });
    var jr = $.extend({ options: { pane: `tooltipPane`, offset: [0, 0], direction: `auto`, permanent: false, sticky: false, opacity: 0.9 }, onAdd: function(e5) {
      $.prototype.onAdd.call(this, e5), this.setOpacity(this.options.opacity), e5.fire(`tooltipopen`, { tooltip: this }), this._source && (this.addEventParent(this._source), this._source.fire(`tooltipopen`, { tooltip: this }, true));
    }, onRemove: function(e5) {
      $.prototype.onRemove.call(this, e5), e5.fire(`tooltipclose`, { tooltip: this }), this._source && (this.removeEventParent(this._source), this._source.fire(`tooltipclose`, { tooltip: this }, true));
    }, getEvents: function() {
      var e5 = $.prototype.getEvents.call(this);
      return this.options.permanent || (e5.preclick = this.close), e5;
    }, _initLayout: function() {
      var e5 = `leaflet-tooltip ` + (this.options.className || ``) + ` leaflet-zoom-` + (this._zoomAnimated ? `animated` : `hide`);
      this._contentNode = this._container = R(`div`, e5), this._container.setAttribute(`role`, `tooltip`), this._container.setAttribute(`id`, `leaflet-tooltip-` + o2(this));
    }, _updateLayout: function() {
    }, _adjustPan: function() {
    }, _setPosition: function(e5) {
      var t4, n3, r3 = this._map, i3 = this._container, a3 = r3.latLngToContainerPoint(r3.getCenter()), o3 = r3.layerPointToContainerPoint(e5), s3 = this.options.direction, c3 = i3.offsetWidth, l3 = i3.offsetHeight, u3 = T2(this.options.offset), d3 = this._getAnchor();
      s3 === `top` ? (t4 = c3 / 2, n3 = l3) : s3 === `bottom` ? (t4 = c3 / 2, n3 = 0) : s3 === `center` ? (t4 = c3 / 2, n3 = l3 / 2) : s3 === `right` ? (t4 = 0, n3 = l3 / 2) : s3 === `left` ? (t4 = c3, n3 = l3 / 2) : o3.x < a3.x ? (s3 = `right`, t4 = 0, n3 = l3 / 2) : (s3 = `left`, t4 = c3 + (u3.x + d3.x) * 2, n3 = l3 / 2), e5 = e5.subtract(T2(t4, n3, true)).add(u3).add(d3), V(i3, `leaflet-tooltip-right`), V(i3, `leaflet-tooltip-left`), V(i3, `leaflet-tooltip-top`), V(i3, `leaflet-tooltip-bottom`), B(i3, `leaflet-tooltip-` + s3), U(i3, e5);
    }, _updatePosition: function() {
      var e5 = this._map.latLngToLayerPoint(this._latlng);
      this._setPosition(e5);
    }, setOpacity: function(e5) {
      this.options.opacity = e5, this._container && H(this._container, e5);
    }, _animateZoom: function(e5) {
      var t4 = this._map._latLngToNewLayerPoint(this._latlng, e5.zoom, e5.center);
      this._setPosition(t4);
    }, _getAnchor: function() {
      return T2(this._source && this._source._getTooltipAnchor && !this.options.sticky ? this._source._getTooltipAnchor() : [0, 0]);
    } }), Mr = function(e5, t4) {
      return new jr(e5, t4);
    };
    J.include({ openTooltip: function(e5, t4, n3) {
      return this._initOverlay(jr, e5, t4, n3).openOn(this), this;
    }, closeTooltip: function(e5) {
      return e5.close(), this;
    } }), Q.include({ bindTooltip: function(e5, t4) {
      return this._tooltip && this.isTooltipOpen() && this.unbindTooltip(), this._tooltip = this._initOverlay(jr, this._tooltip, e5, t4), this._initTooltipInteractions(), this._tooltip.options.permanent && this._map && this._map.hasLayer(this) && this.openTooltip(), this;
    }, unbindTooltip: function() {
      return this._tooltip && (this._tooltip = (this._initTooltipInteractions(true), this.closeTooltip(), null)), this;
    }, _initTooltipInteractions: function(e5) {
      if (e5 || !this._tooltipHandlersAdded) {
        var t4 = e5 ? `off` : `on`, n3 = { remove: this.closeTooltip, move: this._moveTooltip };
        this._tooltip.options.permanent ? n3.add = this._openTooltip : (n3.mouseover = this._openTooltip, n3.mouseout = this.closeTooltip, n3.click = this._openTooltip, this._map ? this._addFocusListeners() : n3.add = this._addFocusListeners), this._tooltip.options.sticky && (n3.mousemove = this._moveTooltip), this[t4](n3), this._tooltipHandlersAdded = !e5;
      }
    }, openTooltip: function(e5) {
      return this._tooltip && (this instanceof Jn || (this._tooltip._source = this), this._tooltip._prepareOpen(e5) && (this._tooltip.openOn(this._map), this.getElement ? this._setAriaDescribedByOnLayer(this) : this.eachLayer && this.eachLayer(this._setAriaDescribedByOnLayer, this))), this;
    }, closeTooltip: function() {
      if (this._tooltip) return this._tooltip.close();
    }, toggleTooltip: function() {
      return this._tooltip && this._tooltip.toggle(this), this;
    }, isTooltipOpen: function() {
      return this._tooltip.isOpen();
    }, setTooltipContent: function(e5) {
      return this._tooltip && this._tooltip.setContent(e5), this;
    }, getTooltip: function() {
      return this._tooltip;
    }, _addFocusListeners: function() {
      this.getElement ? this._addFocusListenersOnLayer(this) : this.eachLayer && this.eachLayer(this._addFocusListenersOnLayer, this);
    }, _addFocusListenersOnLayer: function(e5) {
      var t4 = typeof e5.getElement == `function` && e5.getElement();
      t4 && (W(t4, `focus`, function() {
        this._tooltip._source = e5, this.openTooltip();
      }, this), W(t4, `blur`, this.closeTooltip, this));
    }, _setAriaDescribedByOnLayer: function(e5) {
      var t4 = typeof e5.getElement == `function` && e5.getElement();
      t4 && t4.setAttribute(`aria-describedby`, this._tooltip._container.id);
    }, _openTooltip: function(e5) {
      if (this._tooltip && this._map) {
        if (this._map.dragging && this._map.dragging.moving() && !this._openOnceFlag) {
          this._openOnceFlag = true;
          var t4 = this;
          this._map.once(`moveend`, function() {
            t4._openOnceFlag = false, t4._openTooltip(e5);
          });
          return;
        }
        this._tooltip._source = e5.layer || e5.target, this.openTooltip(this._tooltip.options.sticky ? e5.latlng : void 0);
      }
    }, _moveTooltip: function(e5) {
      var t4 = e5.latlng, n3, r3;
      this._tooltip.options.sticky && e5.originalEvent && (n3 = this._map.mouseEventToContainerPoint(e5.originalEvent), r3 = this._map.containerPointToLayerPoint(n3), t4 = this._map.layerPointToLatLng(r3)), this._tooltip.setLatLng(t4);
    } });
    var Nr = Xn.extend({ options: { iconSize: [12, 12], html: false, bgPos: null, className: `leaflet-div-icon` }, createIcon: function(e5) {
      var t4 = e5 && e5.tagName === `DIV` ? e5 : document.createElement(`div`), n3 = this.options;
      if (n3.html instanceof Element ? (wt(t4), t4.appendChild(n3.html)) : t4.innerHTML = n3.html === false ? `` : n3.html, n3.bgPos) {
        var r3 = T2(n3.bgPos);
        t4.style.backgroundPosition = -r3.x + `px ` + -r3.y + `px`;
      }
      return this._setIconStyles(t4, `icon`), t4;
    }, createShadow: function() {
      return null;
    } });
    function Pr(e5) {
      return new Nr(e5);
    }
    Xn.Default = Qn;
    var Fr = Q.extend({ options: { tileSize: 256, opacity: 1, updateWhenIdle: I.mobile, updateWhenZooming: true, updateInterval: 200, zIndex: 1, bounds: null, minZoom: 0, maxZoom: void 0, maxNativeZoom: void 0, minNativeZoom: void 0, noWrap: false, pane: `tilePane`, className: ``, keepBuffer: 2 }, initialize: function(e5) {
      p2(this, e5);
    }, onAdd: function() {
      this._initContainer(), this._levels = {}, this._tiles = {}, this._resetView();
    }, beforeAdd: function(e5) {
      e5._addZoomLimit(this);
    }, onRemove: function(e5) {
      this._removeAllTiles(), z(this._container), e5._removeZoomLimit(this), this._container = null, this._tileZoom = void 0;
    }, bringToFront: function() {
      return this._map && (Tt(this._container), this._setAutoZIndex(Math.max)), this;
    }, bringToBack: function() {
      return this._map && (Et(this._container), this._setAutoZIndex(Math.min)), this;
    }, getContainer: function() {
      return this._container;
    }, setOpacity: function(e5) {
      return this.options.opacity = e5, this._updateOpacity(), this;
    }, setZIndex: function(e5) {
      return this.options.zIndex = e5, this._updateZIndex(), this;
    }, isLoading: function() {
      return this._loading;
    }, redraw: function() {
      if (this._map) {
        this._removeAllTiles();
        var e5 = this._clampZoom(this._map.getZoom());
        e5 !== this._tileZoom && (this._tileZoom = e5, this._updateLevels()), this._update();
      }
      return this;
    }, getEvents: function() {
      var e5 = { viewprereset: this._invalidateAll, viewreset: this._resetView, zoom: this._resetView, moveend: this._onMoveEnd };
      return this.options.updateWhenIdle || (this._onMove || (this._onMove = s2(this._onMoveEnd, this.options.updateInterval, this)), e5.move = this._onMove), this._zoomAnimated && (e5.zoomanim = this._animateZoom), e5;
    }, createTile: function() {
      return document.createElement(`div`);
    }, getTileSize: function() {
      var e5 = this.options.tileSize;
      return e5 instanceof w2 ? e5 : new w2(e5, e5);
    }, _updateZIndex: function() {
      this._container && this.options.zIndex !== void 0 && this.options.zIndex !== null && (this._container.style.zIndex = this.options.zIndex);
    }, _setAutoZIndex: function(e5) {
      for (var t4 = this.getPane().children, n3 = -e5(-1 / 0, 1 / 0), r3 = 0, i3 = t4.length, a3; r3 < i3; r3++) a3 = t4[r3].style.zIndex, t4[r3] !== this._container && a3 && (n3 = e5(n3, +a3));
      isFinite(n3) && (this.options.zIndex = n3 + e5(-1, 1), this._updateZIndex());
    }, _updateOpacity: function() {
      if (this._map && !I.ielt9) {
        H(this._container, this.options.opacity);
        var e5 = +/* @__PURE__ */ new Date(), t4 = false, n3 = false;
        for (var r3 in this._tiles) {
          var i3 = this._tiles[r3];
          if (i3.current && i3.loaded) {
            var a3 = Math.min(1, (e5 - i3.loaded) / 200);
            H(i3.el, a3), a3 < 1 ? t4 = true : (i3.active ? n3 = true : this._onOpaqueTile(i3), i3.active = true);
          }
        }
        n3 && !this._noPrune && this._pruneTiles(), t4 && (x2(this._fadeFrame), this._fadeFrame = b2(this._updateOpacity, this));
      }
    }, _onOpaqueTile: l2, _initContainer: function() {
      this._container || (this._container = R(`div`, `leaflet-layer ` + (this.options.className || ``)), this._updateZIndex(), this.options.opacity < 1 && this._updateOpacity(), this.getPane().appendChild(this._container));
    }, _updateLevels: function() {
      var e5 = this._tileZoom, t4 = this.options.maxZoom;
      if (e5 !== void 0) {
        for (var n3 in this._levels) n3 = Number(n3), this._levels[n3].el.children.length || n3 === e5 ? (this._levels[n3].el.style.zIndex = t4 - Math.abs(e5 - n3), this._onUpdateLevel(n3)) : (z(this._levels[n3].el), this._removeTilesAtZoom(n3), this._onRemoveLevel(n3), delete this._levels[n3]);
        var r3 = this._levels[e5], i3 = this._map;
        return r3 || (r3 = this._levels[e5] = {}, r3.el = R(`div`, `leaflet-tile-container leaflet-zoom-animated`, this._container), r3.el.style.zIndex = t4, r3.origin = i3.project(i3.unproject(i3.getPixelOrigin()), e5).round(), r3.zoom = e5, this._setZoomTransform(r3, i3.getCenter(), i3.getZoom()), r3.el.offsetWidth, this._onCreateLevel(r3)), this._level = r3, r3;
      }
    }, _onUpdateLevel: l2, _onRemoveLevel: l2, _onCreateLevel: l2, _pruneTiles: function() {
      if (this._map) {
        var e5, t4, n3 = this._map.getZoom();
        if (n3 > this.options.maxZoom || n3 < this.options.minZoom) {
          this._removeAllTiles();
          return;
        }
        for (e5 in this._tiles) t4 = this._tiles[e5], t4.retain = t4.current;
        for (e5 in this._tiles) if (t4 = this._tiles[e5], t4.current && !t4.active) {
          var r3 = t4.coords;
          this._retainParent(r3.x, r3.y, r3.z, r3.z - 5) || this._retainChildren(r3.x, r3.y, r3.z, r3.z + 2);
        }
        for (e5 in this._tiles) this._tiles[e5].retain || this._removeTile(e5);
      }
    }, _removeTilesAtZoom: function(e5) {
      for (var t4 in this._tiles) this._tiles[t4].coords.z === e5 && this._removeTile(t4);
    }, _removeAllTiles: function() {
      for (var e5 in this._tiles) this._removeTile(e5);
    }, _invalidateAll: function() {
      for (var e5 in this._levels) z(this._levels[e5].el), this._onRemoveLevel(Number(e5)), delete this._levels[e5];
      this._removeAllTiles(), this._tileZoom = void 0;
    }, _retainParent: function(e5, t4, n3, r3) {
      var i3 = Math.floor(e5 / 2), a3 = Math.floor(t4 / 2), o3 = n3 - 1, s3 = new w2(+i3, +a3);
      s3.z = +o3;
      var c3 = this._tileCoordsToKey(s3), l3 = this._tiles[c3];
      return l3 && l3.active ? (l3.retain = true, true) : (l3 && l3.loaded && (l3.retain = true), o3 > r3 && this._retainParent(i3, a3, o3, r3));
    }, _retainChildren: function(e5, t4, n3, r3) {
      for (var i3 = 2 * e5; i3 < 2 * e5 + 2; i3++) for (var a3 = 2 * t4; a3 < 2 * t4 + 2; a3++) {
        var o3 = new w2(i3, a3);
        o3.z = n3 + 1;
        var s3 = this._tileCoordsToKey(o3), c3 = this._tiles[s3];
        if (c3 && c3.active) {
          c3.retain = true;
          continue;
        }
        c3 && c3.loaded && (c3.retain = true), n3 + 1 < r3 && this._retainChildren(i3, a3, n3 + 1, r3);
      }
    }, _resetView: function(e5) {
      var t4 = e5 && (e5.pinch || e5.flyTo);
      this._setView(this._map.getCenter(), this._map.getZoom(), t4, t4);
    }, _animateZoom: function(e5) {
      this._setView(e5.center, e5.zoom, true, e5.noUpdate);
    }, _clampZoom: function(e5) {
      var t4 = this.options;
      return t4.minNativeZoom !== void 0 && e5 < t4.minNativeZoom ? t4.minNativeZoom : t4.maxNativeZoom !== void 0 && t4.maxNativeZoom < e5 ? t4.maxNativeZoom : e5;
    }, _setView: function(e5, t4, n3, r3) {
      var i3 = Math.round(t4);
      i3 = this.options.maxZoom !== void 0 && i3 > this.options.maxZoom || this.options.minZoom !== void 0 && i3 < this.options.minZoom ? void 0 : this._clampZoom(i3);
      var a3 = this.options.updateWhenZooming && i3 !== this._tileZoom;
      (!r3 || a3) && (this._tileZoom = i3, this._abortLoading && this._abortLoading(), this._updateLevels(), this._resetGrid(), i3 !== void 0 && this._update(e5), n3 || this._pruneTiles(), this._noPrune = !!n3), this._setZoomTransforms(e5, t4);
    }, _setZoomTransforms: function(e5, t4) {
      for (var n3 in this._levels) this._setZoomTransform(this._levels[n3], e5, t4);
    }, _setZoomTransform: function(e5, t4, n3) {
      var r3 = this._map.getZoomScale(n3, e5.zoom), i3 = e5.origin.multiplyBy(r3).subtract(this._map._getNewPixelOrigin(t4, n3)).round();
      I.any3d ? Mt(e5.el, i3, r3) : U(e5.el, i3);
    }, _resetGrid: function() {
      var e5 = this._map, t4 = e5.options.crs, n3 = this._tileSize = this.getTileSize(), r3 = this._tileZoom, i3 = this._map.getPixelWorldBounds(this._tileZoom);
      i3 && (this._globalTileRange = this._pxBoundsToTileRange(i3)), this._wrapX = t4.wrapLng && !this.options.noWrap && [Math.floor(e5.project([0, t4.wrapLng[0]], r3).x / n3.x), Math.ceil(e5.project([0, t4.wrapLng[1]], r3).x / n3.y)], this._wrapY = t4.wrapLat && !this.options.noWrap && [Math.floor(e5.project([t4.wrapLat[0], 0], r3).y / n3.x), Math.ceil(e5.project([t4.wrapLat[1], 0], r3).y / n3.y)];
    }, _onMoveEnd: function() {
      this._map && !this._map._animatingZoom && this._update();
    }, _getTiledPixelBounds: function(e5) {
      var t4 = this._map, n3 = t4._animatingZoom ? Math.max(t4._animateToZoom, t4.getZoom()) : t4.getZoom(), r3 = t4.getZoomScale(n3, this._tileZoom), i3 = t4.project(e5, this._tileZoom).floor(), a3 = t4.getSize().divideBy(r3 * 2);
      return new E2(i3.subtract(a3), i3.add(a3));
    }, _update: function(e5) {
      var t4 = this._map;
      if (t4) {
        var n3 = this._clampZoom(t4.getZoom());
        if (e5 === void 0 && (e5 = t4.getCenter()), this._tileZoom !== void 0) {
          var r3 = this._getTiledPixelBounds(e5), i3 = this._pxBoundsToTileRange(r3), a3 = i3.getCenter(), o3 = [], s3 = this.options.keepBuffer, c3 = new E2(i3.getBottomLeft().subtract([s3, -s3]), i3.getTopRight().add([s3, -s3]));
          if (!(isFinite(i3.min.x) && isFinite(i3.min.y) && isFinite(i3.max.x) && isFinite(i3.max.y))) throw Error(`Attempted to load an infinite number of tiles`);
          for (var l3 in this._tiles) {
            var u3 = this._tiles[l3].coords;
            (u3.z !== this._tileZoom || !c3.contains(new w2(u3.x, u3.y))) && (this._tiles[l3].current = false);
          }
          if (Math.abs(n3 - this._tileZoom) > 1) {
            this._setView(e5, n3);
            return;
          }
          for (var d3 = i3.min.y; d3 <= i3.max.y; d3++) for (var f3 = i3.min.x; f3 <= i3.max.x; f3++) {
            var p3 = new w2(f3, d3);
            if (p3.z = this._tileZoom, this._isValidTile(p3)) {
              var m3 = this._tiles[this._tileCoordsToKey(p3)];
              m3 ? m3.current = true : o3.push(p3);
            }
          }
          if (o3.sort(function(e6, t5) {
            return e6.distanceTo(a3) - t5.distanceTo(a3);
          }), o3.length !== 0) {
            this._loading || (this._loading = true, this.fire(`loading`));
            var h3 = document.createDocumentFragment();
            for (f3 = 0; f3 < o3.length; f3++) this._addTile(o3[f3], h3);
            this._level.el.appendChild(h3);
          }
        }
      }
    }, _isValidTile: function(e5) {
      var t4 = this._map.options.crs;
      if (!t4.infinite) {
        var n3 = this._globalTileRange;
        if (!t4.wrapLng && (e5.x < n3.min.x || e5.x > n3.max.x) || !t4.wrapLat && (e5.y < n3.min.y || e5.y > n3.max.y)) return false;
      }
      if (!this.options.bounds) return true;
      var r3 = this._tileCoordsToBounds(e5);
      return k2(this.options.bounds).overlaps(r3);
    }, _keyToBounds: function(e5) {
      return this._tileCoordsToBounds(this._keyToTileCoords(e5));
    }, _tileCoordsToNwSe: function(e5) {
      var t4 = this._map, n3 = this.getTileSize(), r3 = e5.scaleBy(n3), i3 = r3.add(n3);
      return [t4.unproject(r3, e5.z), t4.unproject(i3, e5.z)];
    }, _tileCoordsToBounds: function(e5) {
      var t4 = this._tileCoordsToNwSe(e5), n3 = new O2(t4[0], t4[1]);
      return this.options.noWrap || (n3 = this._map.wrapLatLngBounds(n3)), n3;
    }, _tileCoordsToKey: function(e5) {
      return e5.x + `:` + e5.y + `:` + e5.z;
    }, _keyToTileCoords: function(e5) {
      var t4 = e5.split(`:`), n3 = new w2(+t4[0], +t4[1]);
      return n3.z = +t4[2], n3;
    }, _removeTile: function(e5) {
      var t4 = this._tiles[e5];
      t4 && (z(t4.el), delete this._tiles[e5], this.fire(`tileunload`, { tile: t4.el, coords: this._keyToTileCoords(e5) }));
    }, _initTile: function(e5) {
      B(e5, `leaflet-tile`);
      var t4 = this.getTileSize();
      e5.style.width = t4.x + `px`, e5.style.height = t4.y + `px`, e5.onselectstart = l2, e5.onmousemove = l2, I.ielt9 && this.options.opacity < 1 && H(e5, this.options.opacity);
    }, _addTile: function(e5, t4) {
      var n3 = this._getTilePos(e5), r3 = this._tileCoordsToKey(e5), a3 = this.createTile(this._wrapCoords(e5), i2(this._tileReady, this, e5));
      this._initTile(a3), this.createTile.length < 2 && b2(i2(this._tileReady, this, e5, null, a3)), U(a3, n3), this._tiles[r3] = { el: a3, coords: e5, current: true }, t4.appendChild(a3), this.fire(`tileloadstart`, { tile: a3, coords: e5 });
    }, _tileReady: function(e5, t4, n3) {
      t4 && this.fire(`tileerror`, { error: t4, tile: n3, coords: e5 });
      var r3 = this._tileCoordsToKey(e5);
      n3 = this._tiles[r3], n3 && (n3.loaded = +/* @__PURE__ */ new Date(), this._map._fadeAnimated ? (H(n3.el, 0), x2(this._fadeFrame), this._fadeFrame = b2(this._updateOpacity, this)) : (n3.active = true, this._pruneTiles()), t4 || (B(n3.el, `leaflet-tile-loaded`), this.fire(`tileload`, { tile: n3.el, coords: e5 })), this._noTilesToLoad() && (this._loading = false, this.fire(`load`), I.ielt9 || !this._map._fadeAnimated ? b2(this._pruneTiles, this) : setTimeout(i2(this._pruneTiles, this), 250)));
    }, _getTilePos: function(e5) {
      return e5.scaleBy(this.getTileSize()).subtract(this._level.origin);
    }, _wrapCoords: function(e5) {
      var t4 = new w2(this._wrapX ? c2(e5.x, this._wrapX) : e5.x, this._wrapY ? c2(e5.y, this._wrapY) : e5.y);
      return t4.z = e5.z, t4;
    }, _pxBoundsToTileRange: function(e5) {
      var t4 = this.getTileSize();
      return new E2(e5.min.unscaleBy(t4).floor(), e5.max.unscaleBy(t4).ceil().subtract([1, 1]));
    }, _noTilesToLoad: function() {
      for (var e5 in this._tiles) if (!this._tiles[e5].loaded) return false;
      return true;
    } });
    function Ir(e5) {
      return new Fr(e5);
    }
    var Lr = Fr.extend({ options: { minZoom: 0, maxZoom: 18, subdomains: `abc`, errorTileUrl: ``, zoomOffset: 0, tms: false, zoomReverse: false, detectRetina: false, crossOrigin: false, referrerPolicy: false }, initialize: function(e5, t4) {
      this._url = e5, t4 = p2(this, t4), t4.detectRetina && I.retina && t4.maxZoom > 0 ? (t4.tileSize = Math.floor(t4.tileSize / 2), t4.zoomReverse ? (t4.zoomOffset--, t4.minZoom = Math.min(t4.maxZoom, t4.minZoom + 1)) : (t4.zoomOffset++, t4.maxZoom = Math.max(t4.minZoom, t4.maxZoom - 1)), t4.minZoom = Math.max(0, t4.minZoom)) : t4.zoomReverse ? t4.minZoom = Math.min(t4.maxZoom, t4.minZoom) : t4.maxZoom = Math.max(t4.minZoom, t4.maxZoom), typeof t4.subdomains == `string` && (t4.subdomains = t4.subdomains.split(``)), this.on(`tileunload`, this._onTileRemove);
    }, setUrl: function(e5, t4) {
      return this._url === e5 && t4 === void 0 && (t4 = true), this._url = e5, t4 || this.redraw(), this;
    }, createTile: function(e5, t4) {
      var n3 = document.createElement(`img`);
      return W(n3, `load`, i2(this._tileOnLoad, this, t4, n3)), W(n3, `error`, i2(this._tileOnError, this, t4, n3)), (this.options.crossOrigin || this.options.crossOrigin === ``) && (n3.crossOrigin = this.options.crossOrigin === true ? `` : this.options.crossOrigin), typeof this.options.referrerPolicy == `string` && (n3.referrerPolicy = this.options.referrerPolicy), n3.alt = ``, n3.src = this.getTileUrl(e5), n3;
    }, getTileUrl: function(e5) {
      var t4 = { r: I.retina ? `@2x` : ``, s: this._getSubdomain(e5), x: e5.x, y: e5.y, z: this._getZoomForUrl() };
      if (this._map && !this._map.options.crs.infinite) {
        var r3 = this._globalTileRange.max.y - e5.y;
        this.options.tms && (t4.y = r3), t4[`-y`] = r3;
      }
      return g2(this._url, n2(t4, this.options));
    }, _tileOnLoad: function(e5, t4) {
      I.ielt9 ? setTimeout(i2(e5, this, null, t4), 0) : e5(null, t4);
    }, _tileOnError: function(e5, t4, n3) {
      var r3 = this.options.errorTileUrl;
      r3 && t4.getAttribute(`src`) !== r3 && (t4.src = r3), e5(n3, t4);
    }, _onTileRemove: function(e5) {
      e5.tile.onload = null;
    }, _getZoomForUrl: function() {
      var e5 = this._tileZoom, t4 = this.options.maxZoom, n3 = this.options.zoomReverse, r3 = this.options.zoomOffset;
      return n3 && (e5 = t4 - e5), e5 + r3;
    }, _getSubdomain: function(e5) {
      var t4 = Math.abs(e5.x + e5.y) % this.options.subdomains.length;
      return this.options.subdomains[t4];
    }, _abortLoading: function() {
      var e5, t4;
      for (e5 in this._tiles) if (this._tiles[e5].coords.z !== this._tileZoom && (t4 = this._tiles[e5].el, t4.onload = l2, t4.onerror = l2, !t4.complete)) {
        t4.src = v2;
        var n3 = this._tiles[e5].coords;
        z(t4), delete this._tiles[e5], this.fire(`tileabort`, { tile: t4, coords: n3 });
      }
    }, _removeTile: function(e5) {
      var t4 = this._tiles[e5];
      if (t4) return t4.el.setAttribute(`src`, v2), Fr.prototype._removeTile.call(this, e5);
    }, _tileReady: function(e5, t4, n3) {
      if (!(!this._map || n3 && n3.getAttribute(`src`) === v2)) return Fr.prototype._tileReady.call(this, e5, t4, n3);
    } });
    function Rr(e5, t4) {
      return new Lr(e5, t4);
    }
    var zr = Lr.extend({ defaultWmsParams: { service: `WMS`, request: `GetMap`, layers: ``, styles: ``, format: `image/jpeg`, transparent: false, version: `1.1.1` }, options: { crs: null, uppercase: false }, initialize: function(e5, t4) {
      this._url = e5;
      var r3 = n2({}, this.defaultWmsParams);
      for (var i3 in t4) i3 in this.options || (r3[i3] = t4[i3]);
      t4 = p2(this, t4);
      var a3 = t4.detectRetina && I.retina ? 2 : 1, o3 = this.getTileSize();
      r3.width = o3.x * a3, r3.height = o3.y * a3, this.wmsParams = r3;
    }, onAdd: function(e5) {
      this._crs = this.options.crs || e5.options.crs, this._wmsVersion = parseFloat(this.wmsParams.version);
      var t4 = this._wmsVersion >= 1.3 ? `crs` : `srs`;
      this.wmsParams[t4] = this._crs.code, Lr.prototype.onAdd.call(this, e5);
    }, getTileUrl: function(e5) {
      var t4 = this._tileCoordsToNwSe(e5), n3 = this._crs, r3 = D2(n3.project(t4[0]), n3.project(t4[1])), i3 = r3.min, a3 = r3.max, o3 = (this._wmsVersion >= 1.3 && this._crs === Wn ? [i3.y, i3.x, a3.y, a3.x] : [i3.x, i3.y, a3.x, a3.y]).join(`,`), s3 = Lr.prototype.getTileUrl.call(this, e5);
      return s3 + m2(this.wmsParams, s3, this.options.uppercase) + (this.options.uppercase ? `&BBOX=` : `&bbox=`) + o3;
    }, setParams: function(e5, t4) {
      return n2(this.wmsParams, e5), t4 || this.redraw(), this;
    } });
    function Br(e5, t4) {
      return new zr(e5, t4);
    }
    Lr.WMS = zr, Rr.wms = Br;
    var Vr = Q.extend({ options: { padding: 0.1 }, initialize: function(e5) {
      p2(this, e5), o2(this), this._layers = this._layers || {};
    }, onAdd: function() {
      this._container || (this._initContainer(), B(this._container, `leaflet-zoom-animated`)), this.getPane().appendChild(this._container), this._update(), this.on(`update`, this._updatePaths, this);
    }, onRemove: function() {
      this.off(`update`, this._updatePaths, this), this._destroyContainer();
    }, getEvents: function() {
      var e5 = { viewreset: this._reset, zoom: this._onZoom, moveend: this._update, zoomend: this._onZoomEnd };
      return this._zoomAnimated && (e5.zoomanim = this._onAnimZoom), e5;
    }, _onAnimZoom: function(e5) {
      this._updateTransform(e5.center, e5.zoom);
    }, _onZoom: function() {
      this._updateTransform(this._map.getCenter(), this._map.getZoom());
    }, _updateTransform: function(e5, t4) {
      var n3 = this._map.getZoomScale(t4, this._zoom), r3 = this._map.getSize().multiplyBy(0.5 + this.options.padding), i3 = this._map.project(this._center, t4), a3 = r3.multiplyBy(-n3).add(i3).subtract(this._map._getNewPixelOrigin(e5, t4));
      I.any3d ? Mt(this._container, a3, n3) : U(this._container, a3);
    }, _reset: function() {
      for (var e5 in this._update(), this._updateTransform(this._center, this._zoom), this._layers) this._layers[e5]._reset();
    }, _onZoomEnd: function() {
      for (var e5 in this._layers) this._layers[e5]._project();
    }, _updatePaths: function() {
      for (var e5 in this._layers) this._layers[e5]._update();
    }, _update: function() {
      var e5 = this.options.padding, t4 = this._map.getSize(), n3 = this._map.containerPointToLayerPoint(t4.multiplyBy(-e5)).round();
      this._bounds = new E2(n3, n3.add(t4.multiplyBy(1 + e5 * 2)).round()), this._center = this._map.getCenter(), this._zoom = this._map.getZoom();
    } }), Hr = Vr.extend({ options: { tolerance: 0 }, getEvents: function() {
      var e5 = Vr.prototype.getEvents.call(this);
      return e5.viewprereset = this._onViewPreReset, e5;
    }, _onViewPreReset: function() {
      this._postponeUpdatePaths = true;
    }, onAdd: function() {
      Vr.prototype.onAdd.call(this), this._draw();
    }, _initContainer: function() {
      var e5 = this._container = document.createElement(`canvas`);
      W(e5, `mousemove`, this._onMouseMove, this), W(e5, `click dblclick mousedown mouseup contextmenu`, this._onClick, this), W(e5, `mouseout`, this._handleMouseOut, this), e5._leaflet_disable_events = true, this._ctx = e5.getContext(`2d`);
    }, _destroyContainer: function() {
      x2(this._redrawRequest), delete this._ctx, z(this._container), K(this._container), delete this._container;
    }, _updatePaths: function() {
      if (!this._postponeUpdatePaths) {
        var e5;
        for (var t4 in this._redrawBounds = null, this._layers) e5 = this._layers[t4], e5._update();
        this._redraw();
      }
    }, _update: function() {
      if (!(this._map._animatingZoom && this._bounds)) {
        Vr.prototype._update.call(this);
        var e5 = this._bounds, t4 = this._container, n3 = e5.getSize(), r3 = I.retina ? 2 : 1;
        U(t4, e5.min), t4.width = r3 * n3.x, t4.height = r3 * n3.y, t4.style.width = n3.x + `px`, t4.style.height = n3.y + `px`, I.retina && this._ctx.scale(2, 2), this._ctx.translate(-e5.min.x, -e5.min.y), this.fire(`update`);
      }
    }, _reset: function() {
      Vr.prototype._reset.call(this), this._postponeUpdatePaths && (this._postponeUpdatePaths = false, this._updatePaths());
    }, _initPath: function(e5) {
      this._updateDashArray(e5), this._layers[o2(e5)] = e5;
      var t4 = e5._order = { layer: e5, prev: this._drawLast, next: null };
      this._drawLast && (this._drawLast.next = t4), this._drawLast = t4, this._drawFirst = this._drawFirst || this._drawLast;
    }, _addPath: function(e5) {
      this._requestRedraw(e5);
    }, _removePath: function(e5) {
      var t4 = e5._order, n3 = t4.next, r3 = t4.prev;
      n3 ? n3.prev = r3 : this._drawLast = r3, r3 ? r3.next = n3 : this._drawFirst = n3, delete e5._order, delete this._layers[o2(e5)], this._requestRedraw(e5);
    }, _updatePath: function(e5) {
      this._extendRedrawBounds(e5), e5._project(), e5._update(), this._requestRedraw(e5);
    }, _updateStyle: function(e5) {
      this._updateDashArray(e5), this._requestRedraw(e5);
    }, _updateDashArray: function(e5) {
      if (typeof e5.options.dashArray == `string`) {
        for (var t4 = e5.options.dashArray.split(/[, ]+/), n3 = [], r3, i3 = 0; i3 < t4.length; i3++) {
          if (r3 = Number(t4[i3]), isNaN(r3)) return;
          n3.push(r3);
        }
        e5.options._dashArray = n3;
      } else e5.options._dashArray = e5.options.dashArray;
    }, _requestRedraw: function(e5) {
      this._map && (this._extendRedrawBounds(e5), this._redrawRequest = this._redrawRequest || b2(this._redraw, this));
    }, _extendRedrawBounds: function(e5) {
      if (e5._pxBounds) {
        var t4 = (e5.options.weight || 0) + 1;
        this._redrawBounds = this._redrawBounds || new E2(), this._redrawBounds.extend(e5._pxBounds.min.subtract([t4, t4])), this._redrawBounds.extend(e5._pxBounds.max.add([t4, t4]));
      }
    }, _redraw: function() {
      this._redrawRequest = null, this._redrawBounds && (this._redrawBounds.min._floor(), this._redrawBounds.max._ceil()), this._clear(), this._draw(), this._redrawBounds = null;
    }, _clear: function() {
      var e5 = this._redrawBounds;
      if (e5) {
        var t4 = e5.getSize();
        this._ctx.clearRect(e5.min.x, e5.min.y, t4.x, t4.y);
      } else this._ctx.save(), this._ctx.setTransform(1, 0, 0, 1, 0, 0), this._ctx.clearRect(0, 0, this._container.width, this._container.height), this._ctx.restore();
    }, _draw: function() {
      var e5, t4 = this._redrawBounds;
      if (this._ctx.save(), t4) {
        var n3 = t4.getSize();
        this._ctx.beginPath(), this._ctx.rect(t4.min.x, t4.min.y, n3.x, n3.y), this._ctx.clip();
      }
      this._drawing = true;
      for (var r3 = this._drawFirst; r3; r3 = r3.next) e5 = r3.layer, (!t4 || e5._pxBounds && e5._pxBounds.intersects(t4)) && e5._updatePath();
      this._drawing = false, this._ctx.restore();
    }, _updatePoly: function(e5, t4) {
      if (this._drawing) {
        var n3, r3, i3, a3, o3 = e5._parts, s3 = o3.length, c3 = this._ctx;
        if (s3) {
          for (c3.beginPath(), n3 = 0; n3 < s3; n3++) {
            for (r3 = 0, i3 = o3[n3].length; r3 < i3; r3++) a3 = o3[n3][r3], c3[r3 ? `lineTo` : `moveTo`](a3.x, a3.y);
            t4 && c3.closePath();
          }
          this._fillStroke(c3, e5);
        }
      }
    }, _updateCircle: function(e5) {
      if (this._drawing && !e5._empty()) {
        var t4 = e5._point, n3 = this._ctx, r3 = Math.max(Math.round(e5._radius), 1), i3 = (Math.max(Math.round(e5._radiusY), 1) || r3) / r3;
        i3 !== 1 && (n3.save(), n3.scale(1, i3)), n3.beginPath(), n3.arc(t4.x, t4.y / i3, r3, 0, Math.PI * 2, false), i3 !== 1 && n3.restore(), this._fillStroke(n3, e5);
      }
    }, _fillStroke: function(e5, t4) {
      var n3 = t4.options;
      n3.fill && (e5.globalAlpha = n3.fillOpacity, e5.fillStyle = n3.fillColor || n3.color, e5.fill(n3.fillRule || `evenodd`)), n3.stroke && n3.weight !== 0 && (e5.setLineDash && e5.setLineDash(t4.options && t4.options._dashArray || []), e5.globalAlpha = n3.opacity, e5.lineWidth = n3.weight, e5.strokeStyle = n3.color, e5.lineCap = n3.lineCap, e5.lineJoin = n3.lineJoin, e5.stroke());
    }, _onClick: function(e5) {
      for (var t4 = this._map.mouseEventToLayerPoint(e5), n3, r3, i3 = this._drawFirst; i3; i3 = i3.next) n3 = i3.layer, n3.options.interactive && n3._containsPoint(t4) && (e5.type !== `click` && e5.type !== `preclick` || !this._map._draggableMoved(n3)) && (r3 = n3);
      this._fireEvent(r3 ? [r3] : false, e5);
    }, _onMouseMove: function(e5) {
      if (!(!this._map || this._map.dragging.moving() || this._map._animatingZoom)) {
        var t4 = this._map.mouseEventToLayerPoint(e5);
        this._handleMouseHover(e5, t4);
      }
    }, _handleMouseOut: function(e5) {
      var t4 = this._hoveredLayer;
      t4 && (V(this._container, `leaflet-interactive`), this._fireEvent([t4], e5, `mouseout`), this._hoveredLayer = null, this._mouseHoverThrottled = false);
    }, _handleMouseHover: function(e5, t4) {
      if (!this._mouseHoverThrottled) {
        for (var n3, r3, a3 = this._drawFirst; a3; a3 = a3.next) n3 = a3.layer, n3.options.interactive && n3._containsPoint(t4) && (r3 = n3);
        r3 !== this._hoveredLayer && (this._handleMouseOut(e5), r3 && (B(this._container, `leaflet-interactive`), this._fireEvent([r3], e5, `mouseover`), this._hoveredLayer = r3)), this._fireEvent(this._hoveredLayer ? [this._hoveredLayer] : false, e5), this._mouseHoverThrottled = true, setTimeout(i2(function() {
          this._mouseHoverThrottled = false;
        }, this), 32);
      }
    }, _fireEvent: function(e5, t4, n3) {
      this._map._fireDOMEvent(t4, n3 || t4.type, e5);
    }, _bringToFront: function(e5) {
      var t4 = e5._order;
      if (t4) {
        var n3 = t4.next, r3 = t4.prev;
        if (n3) n3.prev = r3;
        else return;
        r3 ? r3.next = n3 : n3 && (this._drawFirst = n3), t4.prev = this._drawLast, this._drawLast.next = t4, t4.next = null, this._drawLast = t4, this._requestRedraw(e5);
      }
    }, _bringToBack: function(e5) {
      var t4 = e5._order;
      if (t4) {
        var n3 = t4.next, r3 = t4.prev;
        if (r3) r3.next = n3;
        else return;
        n3 ? n3.prev = r3 : r3 && (this._drawLast = r3), t4.prev = null, t4.next = this._drawFirst, this._drawFirst.prev = t4, this._drawFirst = t4, this._requestRedraw(e5);
      }
    } });
    function Ur(e5) {
      return I.canvas ? new Hr(e5) : null;
    }
    var Wr = (function() {
      try {
        return document.namespaces.add(`lvml`, `urn:schemas-microsoft-com:vml`), function(e5) {
          return document.createElement(`<lvml:` + e5 + ` class="lvml">`);
        };
      } catch {
      }
      return function(e5) {
        return document.createElement(`<` + e5 + ` xmlns="urn:schemas-microsoft.com:vml" class="lvml">`);
      };
    })(), Gr = { _initContainer: function() {
      this._container = R(`div`, `leaflet-vml-container`);
    }, _update: function() {
      this._map._animatingZoom || (Vr.prototype._update.call(this), this.fire(`update`));
    }, _initPath: function(e5) {
      var t4 = e5._container = Wr(`shape`);
      B(t4, `leaflet-vml-shape ` + (this.options.className || ``)), t4.coordsize = `1 1`, e5._path = Wr(`path`), t4.appendChild(e5._path), this._updateStyle(e5), this._layers[o2(e5)] = e5;
    }, _addPath: function(e5) {
      var t4 = e5._container;
      this._container.appendChild(t4), e5.options.interactive && e5.addInteractiveTarget(t4);
    }, _removePath: function(e5) {
      var t4 = e5._container;
      z(t4), e5.removeInteractiveTarget(t4), delete this._layers[o2(e5)];
    }, _updateStyle: function(e5) {
      var t4 = e5._stroke, n3 = e5._fill, r3 = e5.options, i3 = e5._container;
      i3.stroked = !!r3.stroke, i3.filled = !!r3.fill, r3.stroke ? (t4 || (t4 = e5._stroke = Wr(`stroke`)), i3.appendChild(t4), t4.weight = r3.weight + `px`, t4.color = r3.color, t4.opacity = r3.opacity, r3.dashArray ? t4.dashStyle = _2(r3.dashArray) ? r3.dashArray.join(` `) : r3.dashArray.replace(/( *, *)/g, ` `) : t4.dashStyle = ``, t4.endcap = r3.lineCap.replace(`butt`, `flat`), t4.joinstyle = r3.lineJoin) : t4 && (i3.removeChild(t4), e5._stroke = null), r3.fill ? (n3 || (n3 = e5._fill = Wr(`fill`)), i3.appendChild(n3), n3.color = r3.fillColor || r3.color, n3.opacity = r3.fillOpacity) : n3 && (i3.removeChild(n3), e5._fill = null);
    }, _updateCircle: function(e5) {
      var t4 = e5._point.round(), n3 = Math.round(e5._radius), r3 = Math.round(e5._radiusY || n3);
      this._setPath(e5, e5._empty() ? `M0 0` : `AL ` + t4.x + `,` + t4.y + ` ` + n3 + `,` + r3 + ` 0,23592600`);
    }, _setPath: function(e5, t4) {
      e5._path.v = t4;
    }, _bringToFront: function(e5) {
      Tt(e5._container);
    }, _bringToBack: function(e5) {
      Et(e5._container);
    } }, Kr = I.vml ? Wr : he2, qr = Vr.extend({ _initContainer: function() {
      this._container = Kr(`svg`), this._container.setAttribute(`pointer-events`, `none`), this._rootGroup = Kr(`g`), this._container.appendChild(this._rootGroup);
    }, _destroyContainer: function() {
      z(this._container), K(this._container), delete this._container, delete this._rootGroup, delete this._svgSize;
    }, _update: function() {
      if (!(this._map._animatingZoom && this._bounds)) {
        Vr.prototype._update.call(this);
        var e5 = this._bounds, t4 = e5.getSize(), n3 = this._container;
        (!this._svgSize || !this._svgSize.equals(t4)) && (this._svgSize = t4, n3.setAttribute(`width`, t4.x), n3.setAttribute(`height`, t4.y)), U(n3, e5.min), n3.setAttribute(`viewBox`, [e5.min.x, e5.min.y, t4.x, t4.y].join(` `)), this.fire(`update`);
      }
    }, _initPath: function(e5) {
      var t4 = e5._path = Kr(`path`);
      e5.options.className && B(t4, e5.options.className), e5.options.interactive && B(t4, `leaflet-interactive`), this._updateStyle(e5), this._layers[o2(e5)] = e5;
    }, _addPath: function(e5) {
      this._rootGroup || this._initContainer(), this._rootGroup.appendChild(e5._path), e5.addInteractiveTarget(e5._path);
    }, _removePath: function(e5) {
      z(e5._path), e5.removeInteractiveTarget(e5._path), delete this._layers[o2(e5)];
    }, _updatePath: function(e5) {
      e5._project(), e5._update();
    }, _updateStyle: function(e5) {
      var t4 = e5._path, n3 = e5.options;
      t4 && (n3.stroke ? (t4.setAttribute(`stroke`, n3.color), t4.setAttribute(`stroke-opacity`, n3.opacity), t4.setAttribute(`stroke-width`, n3.weight), t4.setAttribute(`stroke-linecap`, n3.lineCap), t4.setAttribute(`stroke-linejoin`, n3.lineJoin), n3.dashArray ? t4.setAttribute(`stroke-dasharray`, n3.dashArray) : t4.removeAttribute(`stroke-dasharray`), n3.dashOffset ? t4.setAttribute(`stroke-dashoffset`, n3.dashOffset) : t4.removeAttribute(`stroke-dashoffset`)) : t4.setAttribute(`stroke`, `none`), n3.fill ? (t4.setAttribute(`fill`, n3.fillColor || n3.color), t4.setAttribute(`fill-opacity`, n3.fillOpacity), t4.setAttribute(`fill-rule`, n3.fillRule || `evenodd`)) : t4.setAttribute(`fill`, `none`));
    }, _updatePoly: function(e5, t4) {
      this._setPath(e5, ge2(e5._parts, t4));
    }, _updateCircle: function(e5) {
      var t4 = e5._point, n3 = Math.max(Math.round(e5._radius), 1), r3 = Math.max(Math.round(e5._radiusY), 1) || n3, i3 = `a` + n3 + `,` + r3 + ` 0 1,0 `, a3 = e5._empty() ? `M0 0` : `M` + (t4.x - n3) + `,` + t4.y + i3 + n3 * 2 + `,0 ` + i3 + -n3 * 2 + `,0 `;
      this._setPath(e5, a3);
    }, _setPath: function(e5, t4) {
      e5._path.setAttribute(`d`, t4);
    }, _bringToFront: function(e5) {
      Tt(e5._path);
    }, _bringToBack: function(e5) {
      Et(e5._path);
    } });
    I.vml && qr.include(Gr);
    function Jr(e5) {
      return I.svg || I.vml ? new qr(e5) : null;
    }
    J.include({ getRenderer: function(e5) {
      var t4 = e5.options.renderer || this._getPaneRenderer(e5.options.pane) || this.options.renderer || this._renderer;
      return t4 || (t4 = this._renderer = this._createRenderer()), this.hasLayer(t4) || this.addLayer(t4), t4;
    }, _getPaneRenderer: function(e5) {
      if (e5 === `overlayPane` || e5 === void 0) return false;
      var t4 = this._paneRenderers[e5];
      return t4 === void 0 && (t4 = this._createRenderer({ pane: e5 }), this._paneRenderers[e5] = t4), t4;
    }, _createRenderer: function(e5) {
      return this.options.preferCanvas && Ur(e5) || Jr(e5);
    } });
    var Yr = lr.extend({ initialize: function(e5, t4) {
      lr.prototype.initialize.call(this, this._boundsToLatLngs(e5), t4);
    }, setBounds: function(e5) {
      return this.setLatLngs(this._boundsToLatLngs(e5));
    }, _boundsToLatLngs: function(e5) {
      return e5 = k2(e5), [e5.getSouthWest(), e5.getNorthWest(), e5.getNorthEast(), e5.getSouthEast()];
    } });
    function Xr(e5, t4) {
      return new Yr(e5, t4);
    }
    qr.create = Kr, qr.pointsToPath = ge2, dr.geometryToLayer = fr, dr.coordsToLatLng = mr, dr.coordsToLatLngs = hr, dr.latLngToCoords = gr, dr.latLngsToCoords = _r, dr.getFeature = vr, dr.asFeature = yr, J.mergeOptions({ boxZoom: true });
    var Zr = X.extend({ initialize: function(e5) {
      this._map = e5, this._container = e5._container, this._pane = e5._panes.overlayPane, this._resetStateTimeout = 0, e5.on(`unload`, this._destroy, this);
    }, addHooks: function() {
      W(this._container, `mousedown`, this._onMouseDown, this);
    }, removeHooks: function() {
      K(this._container, `mousedown`, this._onMouseDown, this);
    }, moved: function() {
      return this._moved;
    }, _destroy: function() {
      z(this._pane), delete this._pane;
    }, _resetState: function() {
      this._resetStateTimeout = 0, this._moved = false;
    }, _clearDeferredResetState: function() {
      this._resetStateTimeout !== 0 && (clearTimeout(this._resetStateTimeout), this._resetStateTimeout = 0);
    }, _onMouseDown: function(e5) {
      if (!e5.shiftKey || e5.which !== 1 && e5.button !== 1) return false;
      this._clearDeferredResetState(), this._resetState(), Pt(), Rt(), this._startPoint = this._map.mouseEventToContainerPoint(e5), W(document, { contextmenu: en, mousemove: this._onMouseMove, mouseup: this._onMouseUp, keydown: this._onKeyDown }, this);
    }, _onMouseMove: function(e5) {
      this._moved || (this._moved = true, this._box = R(`div`, `leaflet-zoom-box`, this._container), B(this._container, `leaflet-crosshair`), this._map.fire(`boxzoomstart`)), this._point = this._map.mouseEventToContainerPoint(e5);
      var t4 = new E2(this._point, this._startPoint), n3 = t4.getSize();
      U(this._box, t4.min), this._box.style.width = n3.x + `px`, this._box.style.height = n3.y + `px`;
    }, _finish: function() {
      this._moved && (z(this._box), V(this._container, `leaflet-crosshair`)), Ft(), zt(), K(document, { contextmenu: en, mousemove: this._onMouseMove, mouseup: this._onMouseUp, keydown: this._onKeyDown }, this);
    }, _onMouseUp: function(e5) {
      if ((e5.which === 1 || e5.button === 1) && (this._finish(), this._moved)) {
        this._clearDeferredResetState(), this._resetStateTimeout = setTimeout(i2(this._resetState, this), 0);
        var t4 = new O2(this._map.containerPointToLatLng(this._startPoint), this._map.containerPointToLatLng(this._point));
        this._map.fitBounds(t4).fire(`boxzoomend`, { boxZoomBounds: t4 });
      }
    }, _onKeyDown: function(e5) {
      e5.keyCode === 27 && (this._finish(), this._clearDeferredResetState(), this._resetState());
    } });
    J.addInitHook(`addHandler`, `boxZoom`, Zr), J.mergeOptions({ doubleClickZoom: true });
    var Qr = X.extend({ addHooks: function() {
      this._map.on(`dblclick`, this._onDoubleClick, this);
    }, removeHooks: function() {
      this._map.off(`dblclick`, this._onDoubleClick, this);
    }, _onDoubleClick: function(e5) {
      var t4 = this._map, n3 = t4.getZoom(), r3 = t4.options.zoomDelta, i3 = e5.originalEvent.shiftKey ? n3 - r3 : n3 + r3;
      t4.options.doubleClickZoom === `center` ? t4.setZoom(i3) : t4.setZoomAround(e5.containerPoint, i3);
    } });
    J.addInitHook(`addHandler`, `doubleClickZoom`, Qr), J.mergeOptions({ dragging: true, inertia: true, inertiaDeceleration: 3400, inertiaMaxSpeed: 1 / 0, easeLinearity: 0.2, worldCopyJump: false, maxBoundsViscosity: 0 });
    var $r = X.extend({ addHooks: function() {
      if (!this._draggable) {
        var e5 = this._map;
        this._draggable = new bn(e5._mapPane, e5._container), this._draggable.on({ dragstart: this._onDragStart, drag: this._onDrag, dragend: this._onDragEnd }, this), this._draggable.on(`predrag`, this._onPreDragLimit, this), e5.options.worldCopyJump && (this._draggable.on(`predrag`, this._onPreDragWrap, this), e5.on(`zoomend`, this._onZoomEnd, this), e5.whenReady(this._onZoomEnd, this));
      }
      B(this._map._container, `leaflet-grab leaflet-touch-drag`), this._draggable.enable(), this._positions = [], this._times = [];
    }, removeHooks: function() {
      V(this._map._container, `leaflet-grab`), V(this._map._container, `leaflet-touch-drag`), this._draggable.disable();
    }, moved: function() {
      return this._draggable && this._draggable._moved;
    }, moving: function() {
      return this._draggable && this._draggable._moving;
    }, _onDragStart: function() {
      var e5 = this._map;
      if (e5._stop(), this._map.options.maxBounds && this._map.options.maxBoundsViscosity) {
        var t4 = k2(this._map.options.maxBounds);
        this._offsetLimit = D2(this._map.latLngToContainerPoint(t4.getNorthWest()).multiplyBy(-1), this._map.latLngToContainerPoint(t4.getSouthEast()).multiplyBy(-1).add(this._map.getSize())), this._viscosity = Math.min(1, Math.max(0, this._map.options.maxBoundsViscosity));
      } else this._offsetLimit = null;
      e5.fire(`movestart`).fire(`dragstart`), e5.options.inertia && (this._positions = [], this._times = []);
    }, _onDrag: function(e5) {
      if (this._map.options.inertia) {
        var t4 = this._lastTime = +/* @__PURE__ */ new Date(), n3 = this._lastPos = this._draggable._absPos || this._draggable._newPos;
        this._positions.push(n3), this._times.push(t4), this._prunePositions(t4);
      }
      this._map.fire(`move`, e5).fire(`drag`, e5);
    }, _prunePositions: function(e5) {
      for (; this._positions.length > 1 && e5 - this._times[0] > 50; ) this._positions.shift(), this._times.shift();
    }, _onZoomEnd: function() {
      var e5 = this._map.getSize().divideBy(2), t4 = this._map.latLngToLayerPoint([0, 0]);
      this._initialWorldOffset = t4.subtract(e5).x, this._worldWidth = this._map.getPixelWorldBounds().getSize().x;
    }, _viscousLimit: function(e5, t4) {
      return e5 - (e5 - t4) * this._viscosity;
    }, _onPreDragLimit: function() {
      if (this._viscosity && this._offsetLimit) {
        var e5 = this._draggable._newPos.subtract(this._draggable._startPos), t4 = this._offsetLimit;
        e5.x < t4.min.x && (e5.x = this._viscousLimit(e5.x, t4.min.x)), e5.y < t4.min.y && (e5.y = this._viscousLimit(e5.y, t4.min.y)), e5.x > t4.max.x && (e5.x = this._viscousLimit(e5.x, t4.max.x)), e5.y > t4.max.y && (e5.y = this._viscousLimit(e5.y, t4.max.y)), this._draggable._newPos = this._draggable._startPos.add(e5);
      }
    }, _onPreDragWrap: function() {
      var e5 = this._worldWidth, t4 = Math.round(e5 / 2), n3 = this._initialWorldOffset, r3 = this._draggable._newPos.x, i3 = (r3 - t4 + n3) % e5 + t4 - n3, a3 = (r3 + t4 + n3) % e5 - t4 - n3, o3 = Math.abs(i3 + n3) < Math.abs(a3 + n3) ? i3 : a3;
      this._draggable._absPos = this._draggable._newPos.clone(), this._draggable._newPos.x = o3;
    }, _onDragEnd: function(e5) {
      var t4 = this._map, n3 = t4.options, r3 = !n3.inertia || e5.noInertia || this._times.length < 2;
      if (t4.fire(`dragend`, e5), r3) t4.fire(`moveend`);
      else {
        this._prunePositions(+/* @__PURE__ */ new Date());
        var i3 = this._lastPos.subtract(this._positions[0]), a3 = (this._lastTime - this._times[0]) / 1e3, o3 = n3.easeLinearity, s3 = i3.multiplyBy(o3 / a3), c3 = s3.distanceTo([0, 0]), l3 = Math.min(n3.inertiaMaxSpeed, c3), u3 = s3.multiplyBy(l3 / c3), d3 = l3 / (n3.inertiaDeceleration * o3), f3 = u3.multiplyBy(-d3 / 2).round();
        !f3.x && !f3.y ? t4.fire(`moveend`) : (f3 = t4._limitOffset(f3, t4.options.maxBounds), b2(function() {
          t4.panBy(f3, { duration: d3, easeLinearity: o3, noMoveStart: true, animate: true });
        }));
      }
    } });
    J.addInitHook(`addHandler`, `dragging`, $r), J.mergeOptions({ keyboard: true, keyboardPanDelta: 80 });
    var ei = X.extend({ keyCodes: { left: [37], right: [39], down: [40], up: [38], zoomIn: [187, 107, 61, 171], zoomOut: [189, 109, 54, 173] }, initialize: function(e5) {
      this._map = e5, this._setPanDelta(e5.options.keyboardPanDelta), this._setZoomDelta(e5.options.zoomDelta);
    }, addHooks: function() {
      var e5 = this._map._container;
      e5.tabIndex <= 0 && (e5.tabIndex = `0`), W(e5, { focus: this._onFocus, blur: this._onBlur, mousedown: this._onMouseDown }, this), this._map.on({ focus: this._addHooks, blur: this._removeHooks }, this);
    }, removeHooks: function() {
      this._removeHooks(), K(this._map._container, { focus: this._onFocus, blur: this._onBlur, mousedown: this._onMouseDown }, this), this._map.off({ focus: this._addHooks, blur: this._removeHooks }, this);
    }, _onMouseDown: function() {
      if (!this._focused) {
        var e5 = document.body, t4 = document.documentElement, n3 = e5.scrollTop || t4.scrollTop, r3 = e5.scrollLeft || t4.scrollLeft;
        this._map._container.focus(), window.scrollTo(r3, n3);
      }
    }, _onFocus: function() {
      this._focused = true, this._map.fire(`focus`);
    }, _onBlur: function() {
      this._focused = false, this._map.fire(`blur`);
    }, _setPanDelta: function(e5) {
      for (var t4 = this._panKeys = {}, n3 = this.keyCodes, r3 = 0, i3 = n3.left.length; r3 < i3; r3++) t4[n3.left[r3]] = [-1 * e5, 0];
      for (r3 = 0, i3 = n3.right.length; r3 < i3; r3++) t4[n3.right[r3]] = [e5, 0];
      for (r3 = 0, i3 = n3.down.length; r3 < i3; r3++) t4[n3.down[r3]] = [0, e5];
      for (r3 = 0, i3 = n3.up.length; r3 < i3; r3++) t4[n3.up[r3]] = [0, -1 * e5];
    }, _setZoomDelta: function(e5) {
      for (var t4 = this._zoomKeys = {}, n3 = this.keyCodes, r3 = 0, i3 = n3.zoomIn.length; r3 < i3; r3++) t4[n3.zoomIn[r3]] = e5;
      for (r3 = 0, i3 = n3.zoomOut.length; r3 < i3; r3++) t4[n3.zoomOut[r3]] = -e5;
    }, _addHooks: function() {
      W(document, `keydown`, this._onKeyDown, this);
    }, _removeHooks: function() {
      K(document, `keydown`, this._onKeyDown, this);
    }, _onKeyDown: function(e5) {
      if (!(e5.altKey || e5.ctrlKey || e5.metaKey)) {
        var t4 = e5.keyCode, n3 = this._map, r3;
        if (t4 in this._panKeys) {
          if (!n3._panAnim || !n3._panAnim._inProgress) {
            if (r3 = this._panKeys[t4], e5.shiftKey && (r3 = T2(r3).multiplyBy(3)), n3.options.maxBounds && (r3 = n3._limitOffset(T2(r3), n3.options.maxBounds)), n3.options.worldCopyJump) {
              var i3 = n3.wrapLatLng(n3.unproject(n3.project(n3.getCenter()).add(r3)));
              n3.panTo(i3);
            } else n3.panBy(r3);
          }
        } else if (t4 in this._zoomKeys) n3.setZoom(n3.getZoom() + (e5.shiftKey ? 3 : 1) * this._zoomKeys[t4]);
        else if (t4 === 27 && n3._popup && n3._popup.options.closeOnEscapeKey) n3.closePopup();
        else return;
        en(e5);
      }
    } });
    J.addInitHook(`addHandler`, `keyboard`, ei), J.mergeOptions({ scrollWheelZoom: true, wheelDebounceTime: 40, wheelPxPerZoomLevel: 60 });
    var ti = X.extend({ addHooks: function() {
      W(this._map._container, `wheel`, this._onWheelScroll, this), this._delta = 0;
    }, removeHooks: function() {
      K(this._map._container, `wheel`, this._onWheelScroll, this);
    }, _onWheelScroll: function(e5) {
      var t4 = an(e5), n3 = this._map.options.wheelDebounceTime;
      this._delta += t4, this._lastMousePos = this._map.mouseEventToContainerPoint(e5), this._startTime || (this._startTime = +/* @__PURE__ */ new Date());
      var r3 = Math.max(n3 - (+/* @__PURE__ */ new Date() - this._startTime), 0);
      clearTimeout(this._timer), this._timer = setTimeout(i2(this._performZoom, this), r3), en(e5);
    }, _performZoom: function() {
      var e5 = this._map, t4 = e5.getZoom(), n3 = this._map.options.zoomSnap || 0;
      e5._stop();
      var r3 = this._delta / (this._map.options.wheelPxPerZoomLevel * 4), i3 = 4 * Math.log(2 / (1 + Math.exp(-Math.abs(r3)))) / Math.LN2, a3 = n3 ? Math.ceil(i3 / n3) * n3 : i3, o3 = e5._limitZoom(t4 + (this._delta > 0 ? a3 : -a3)) - t4;
      this._delta = 0, this._startTime = null, o3 && (e5.options.scrollWheelZoom === `center` ? e5.setZoom(t4 + o3) : e5.setZoomAround(this._lastMousePos, t4 + o3));
    } });
    J.addInitHook(`addHandler`, `scrollWheelZoom`, ti);
    var ni = 600;
    J.mergeOptions({ tapHold: I.touchNative && I.safari && I.mobile, tapTolerance: 15 });
    var ri = X.extend({ addHooks: function() {
      W(this._map._container, `touchstart`, this._onDown, this);
    }, removeHooks: function() {
      K(this._map._container, `touchstart`, this._onDown, this);
    }, _onDown: function(e5) {
      if (clearTimeout(this._holdTimeout), e5.touches.length === 1) {
        var t4 = e5.touches[0];
        this._startPos = this._newPos = new w2(t4.clientX, t4.clientY), this._holdTimeout = setTimeout(i2(function() {
          this._cancel(), this._isTapValid() && (W(document, `touchend`, q), W(document, `touchend touchcancel`, this._cancelClickPrevent), this._simulateEvent(`contextmenu`, t4));
        }, this), ni), W(document, `touchend touchcancel contextmenu`, this._cancel, this), W(document, `touchmove`, this._onMove, this);
      }
    }, _cancelClickPrevent: function e5() {
      K(document, `touchend`, q), K(document, `touchend touchcancel`, e5);
    }, _cancel: function() {
      clearTimeout(this._holdTimeout), K(document, `touchend touchcancel contextmenu`, this._cancel, this), K(document, `touchmove`, this._onMove, this);
    }, _onMove: function(e5) {
      var t4 = e5.touches[0];
      this._newPos = new w2(t4.clientX, t4.clientY);
    }, _isTapValid: function() {
      return this._newPos.distanceTo(this._startPos) <= this._map.options.tapTolerance;
    }, _simulateEvent: function(e5, t4) {
      var n3 = new MouseEvent(e5, { bubbles: true, cancelable: true, view: window, screenX: t4.screenX, screenY: t4.screenY, clientX: t4.clientX, clientY: t4.clientY });
      n3._simulated = true, t4.target.dispatchEvent(n3);
    } });
    J.addInitHook(`addHandler`, `tapHold`, ri), J.mergeOptions({ touchZoom: I.touch, bounceAtZoomLimits: true });
    var ii = X.extend({ addHooks: function() {
      B(this._map._container, `leaflet-touch-zoom`), W(this._map._container, `touchstart`, this._onTouchStart, this);
    }, removeHooks: function() {
      V(this._map._container, `leaflet-touch-zoom`), K(this._map._container, `touchstart`, this._onTouchStart, this);
    }, _onTouchStart: function(e5) {
      var t4 = this._map;
      if (!(!e5.touches || e5.touches.length !== 2 || t4._animatingZoom || this._zooming)) {
        var n3 = t4.mouseEventToContainerPoint(e5.touches[0]), r3 = t4.mouseEventToContainerPoint(e5.touches[1]);
        this._centerPoint = t4.getSize()._divideBy(2), this._startLatLng = t4.containerPointToLatLng(this._centerPoint), t4.options.touchZoom !== `center` && (this._pinchStartLatLng = t4.containerPointToLatLng(n3.add(r3)._divideBy(2))), this._startDist = n3.distanceTo(r3), this._startZoom = t4.getZoom(), this._moved = false, this._zooming = true, t4._stop(), W(document, `touchmove`, this._onTouchMove, this), W(document, `touchend touchcancel`, this._onTouchEnd, this), q(e5);
      }
    }, _onTouchMove: function(e5) {
      if (e5.touches && e5.touches.length === 2 && this._zooming) {
        var t4 = this._map, n3 = t4.mouseEventToContainerPoint(e5.touches[0]), r3 = t4.mouseEventToContainerPoint(e5.touches[1]), a3 = n3.distanceTo(r3) / this._startDist;
        if (this._zoom = t4.getScaleZoom(a3, this._startZoom), !t4.options.bounceAtZoomLimits && (this._zoom < t4.getMinZoom() && a3 < 1 || this._zoom > t4.getMaxZoom() && a3 > 1) && (this._zoom = t4._limitZoom(this._zoom)), t4.options.touchZoom === `center`) {
          if (this._center = this._startLatLng, a3 === 1) return;
        } else {
          var o3 = n3._add(r3)._divideBy(2)._subtract(this._centerPoint);
          if (a3 === 1 && o3.x === 0 && o3.y === 0) return;
          this._center = t4.unproject(t4.project(this._pinchStartLatLng, this._zoom).subtract(o3), this._zoom);
        }
        this._moved || (this._moved = (t4._moveStart(true, false), true)), x2(this._animRequest);
        var s3 = i2(t4._move, t4, this._center, this._zoom, { pinch: true, round: false }, void 0);
        this._animRequest = b2(s3, this, true), q(e5);
      }
    }, _onTouchEnd: function() {
      if (!this._moved || !this._zooming) {
        this._zooming = false;
        return;
      }
      this._zooming = false, x2(this._animRequest), K(document, `touchmove`, this._onTouchMove, this), K(document, `touchend touchcancel`, this._onTouchEnd, this), this._map.options.zoomAnimation ? this._map._animateZoom(this._center, this._map._limitZoom(this._zoom), true, this._map.options.zoomSnap) : this._map._resetView(this._center, this._map._limitZoom(this._zoom));
    } });
    J.addInitHook(`addHandler`, `touchZoom`, ii), J.BoxZoom = Zr, J.DoubleClickZoom = Qr, J.Drag = $r, J.Keyboard = ei, J.ScrollWheelZoom = ti, J.TapHold = ri, J.TouchZoom = ii, e4.Bounds = E2, e4.Browser = I, e4.CRS = M2, e4.Canvas = Hr, e4.Circle = ar, e4.CircleMarker = rr, e4.Class = S2, e4.Control = Y, e4.DivIcon = Nr, e4.DivOverlay = $, e4.DomEvent = sn, e4.DomUtil = Kt, e4.Draggable = bn, e4.Evented = se2, e4.FeatureGroup = Jn, e4.GeoJSON = dr, e4.GridLayer = Fr, e4.Handler = X, e4.Icon = Xn, e4.ImageOverlay = Cr, e4.LatLng = A2, e4.LatLngBounds = O2, e4.Layer = Q, e4.LayerGroup = Kn, e4.LineUtil = zn, e4.Map = J, e4.Marker = er, e4.Mixin = vn, e4.Path = nr, e4.Point = w2, e4.PolyUtil = wn, e4.Polygon = lr, e4.Polyline = sr, e4.Popup = kr, e4.PosAnimation = cn, e4.Projection = Hn, e4.Rectangle = Yr, e4.Renderer = Vr, e4.SVG = qr, e4.SVGOverlay = Dr, e4.TileLayer = Lr, e4.Tooltip = jr, e4.Transformation = de2, e4.Util = ae2, e4.VideoOverlay = Tr, e4.bind = i2, e4.bounds = D2, e4.canvas = Ur, e4.circle = or, e4.circleMarker = ir, e4.control = un, e4.divIcon = Pr, e4.extend = n2, e4.featureGroup = Yn, e4.geoJSON = xr, e4.geoJson = Sr, e4.gridLayer = Ir, e4.icon = Zn, e4.imageOverlay = wr, e4.latLng = j2, e4.latLngBounds = k2, e4.layerGroup = qn, e4.map = ln, e4.marker = tr, e4.point = T2, e4.polygon = ur, e4.polyline = cr, e4.popup = Ar, e4.rectangle = Xr, e4.setOptions = p2, e4.stamp = o2, e4.svg = Jr, e4.svgOverlay = Or, e4.tileLayer = Rr, e4.tooltip = Mr, e4.transformation = fe2, e4.version = t3, e4.videoOverlay = Er;
    var ai = window.L;
    e4.noConflict = function() {
      return window.L = ai, this;
    }, window.L = e4;
  }));
}));
n();
var x = e(b(), 1), ae = { exports: {} };
ae.exports, (function(e3, t2) {
  typeof define == `function` && define.amd ? define([`leaflet`], t2) : typeof modules == `object` && ae.exports ? ae.exports = t2(x.default || x) : t2(L);
})(void 0, (e3) => (e3.TileLayer.Provider = e3.TileLayer.extend({ initialize(t2, n2) {
  let r2 = e3.TileLayer.Provider.providers, i2 = t2.split(`.`), a2 = i2[0], o2 = i2[1];
  if (!r2[a2]) throw Error(`No such provider (${a2})`);
  let s2 = { url: r2[a2].url, options: r2[a2].options };
  if (o2 && `variants` in r2[a2]) {
    if (!(o2 in r2[a2].variants)) throw Error(`No such variant of ${a2} (${o2})`);
    let t3 = r2[a2].variants[o2], n3;
    n3 = typeof t3 == `string` ? { variant: t3 } : t3.options, s2 = { url: t3.url || s2.url, options: e3.Util.extend({}, s2.options, n3) };
  }
  let c2 = (e4) => e4.includes(`{attribution.`) ? e4.replace(/\{attribution.(\w*)}/g, (e5, t3) => c2(r2[t3].options.attribution)) : e4;
  s2.options.attribution = c2(s2.options.attribution);
  let l2 = e3.Util.extend({}, s2.options, n2);
  e3.TileLayer.prototype.initialize.call(this, s2.url, l2);
} }), e3.TileLayer.Provider.providers = { OpenStreetMap: { url: `https://tile.openstreetmap.org/{z}/{x}/{y}.png`, options: { maxZoom: 19, attribution: `&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors` }, variants: { Mapnik: {}, DE: { url: `https://{s}.tile.openstreetmap.de/{z}/{x}/{y}.png`, options: { maxZoom: 18 } }, CH: { url: `https://tile.osm.ch/switzerland/{z}/{x}/{y}.png`, options: { maxZoom: 18, bounds: [[45, 5], [48, 11]] } }, France: { url: `https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png`, options: { maxZoom: 20, attribution: `&copy; OpenStreetMap France | {attribution.OpenStreetMap}` } }, HOT: { url: `https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png`, options: { attribution: `{attribution.OpenStreetMap}, Tiles style by <a href="https://www.hotosm.org/" target="_blank">Humanitarian OpenStreetMap Team</a> hosted by <a href="https://openstreetmap.fr/" target="_blank">OpenStreetMap France</a>` } }, BZH: { url: `https://tile.openstreetmap.bzh/br/{z}/{x}/{y}.png`, options: { attribution: `{attribution.OpenStreetMap}, Tiles courtesy of <a href="http://www.openstreetmap.bzh/" target="_blank">Breton OpenStreetMap Team</a>`, bounds: [[46.2, -5.5], [50, 0.7]] } } } }, MapTilesAPI: { url: `https://maptiles.p.rapidapi.com/{variant}/{z}/{x}/{y}.png?rapidapi-key={apikey}`, options: { attribution: `&copy; <a href="http://www.maptilesapi.com/">MapTiles API</a>, {attribution.OpenStreetMap}`, variant: `en/map/v1`, apikey: `<insert your api key here>`, maxZoom: 19 }, variants: { OSMEnglish: { options: { variant: `en/map/v1` } }, OSMFrancais: { options: { variant: `fr/map/v1` } }, OSMEspagnol: { options: { variant: `es/map/v1` } } } }, OpenSeaMap: { url: `https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png`, options: { attribution: `Map data: &copy; <a href="http://www.openseamap.org">OpenSeaMap</a> contributors` } }, OPNVKarte: { url: `https://tileserver.memomaps.de/tilegen/{z}/{x}/{y}.png`, options: { maxZoom: 18, attribution: `Map <a href="https://memomaps.de/">memomaps.de</a> <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, map data {attribution.OpenStreetMap}` } }, OpenTopoMap: { url: `https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png`, options: { maxZoom: 17, attribution: `Map data: {attribution.OpenStreetMap}, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)` } }, OpenRailwayMap: { url: `https://{s}.tiles.openrailwaymap.org/standard/{z}/{x}/{y}.png`, options: { maxZoom: 19, attribution: `Map data: {attribution.OpenStreetMap} | Map style: &copy; <a href="https://www.OpenRailwayMap.org">OpenRailwayMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)` } }, OpenFireMap: { url: `http://openfiremap.org/hytiles/{z}/{x}/{y}.png`, options: { maxZoom: 19, attribution: `Map data: {attribution.OpenStreetMap} | Map style: &copy; <a href="http://www.openfiremap.org">OpenFireMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)` } }, SafeCast: { url: `https://s3.amazonaws.com/te512.safecast.org/{z}/{x}/{y}.png`, options: { maxZoom: 16, attribution: `Map data: {attribution.OpenStreetMap} | Map style: &copy; <a href="https://blog.safecast.org/about/">SafeCast</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)` } }, Stadia: { url: `https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png`, options: { maxZoom: 20, attribution: `&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors` }, variants: { AlidadeSmooth: { url: `https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png` }, AlidadeSmoothDark: { url: `https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png` }, OSMBright: { url: `https://tiles.stadiamaps.com/tiles/osm_bright/{z}/{x}/{y}{r}.png` }, Outdoors: { url: `https://tiles.stadiamaps.com/tiles/outdoors/{z}/{x}/{y}{r}.png` } } }, Thunderforest: { url: `https://{s}.tile.thunderforest.com/{variant}/{z}/{x}/{y}.png?apikey={apikey}`, options: { attribution: `&copy; <a href="http://www.thunderforest.com/">Thunderforest</a>, {attribution.OpenStreetMap}`, variant: `cycle`, apikey: `<insert your api key here>`, maxZoom: 22 }, variants: { OpenCycleMap: `cycle`, Transport: { options: { variant: `transport` } }, TransportDark: { options: { variant: `transport-dark` } }, SpinalMap: { options: { variant: `spinal-map` } }, Landscape: `landscape`, Outdoors: `outdoors`, Pioneer: `pioneer`, MobileAtlas: `mobile-atlas`, Neighbourhood: `neighbourhood` } }, CyclOSM: { url: `https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png`, options: { maxZoom: 20, attribution: `<a href="https://github.com/cyclosm/cyclosm-cartocss-style/releases" title="CyclOSM - Open Bicycle render">CyclOSM</a> | Map data: {attribution.OpenStreetMap}` } }, Jawg: { url: `https://{s}.tile.jawg.io/{variant}/{z}/{x}/{y}{r}.png?access-token={accessToken}`, options: { attribution: `<a href="http://jawg.io" title="Tiles Courtesy of Jawg Maps" target="_blank">&copy; <b>Jawg</b>Maps</a> {attribution.OpenStreetMap}`, minZoom: 0, maxZoom: 22, subdomains: `abcd`, variant: `jawg-terrain`, accessToken: `<insert your access token here>` }, variants: { Streets: `jawg-streets`, Terrain: `jawg-terrain`, Sunny: `jawg-sunny`, Dark: `jawg-dark`, Light: `jawg-light`, Matrix: `jawg-matrix` } }, MapBox: { url: `https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}{r}?access_token={accessToken}`, options: { attribution: `&copy; <a href="https://www.mapbox.com/about/maps/" target="_blank">Mapbox</a> {attribution.OpenStreetMap} <a href="https://www.mapbox.com/map-feedback/" target="_blank">Improve this map</a>`, tileSize: 512, maxZoom: 18, zoomOffset: -1, id: `mapbox/streets-v11`, accessToken: `<insert your access token here>` } }, MapTiler: { url: `https://api.maptiler.com/maps/{variant}/{z}/{x}/{y}{r}.{ext}?key={key}`, options: { attribution: `<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> <a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>`, variant: `streets`, ext: `png`, key: `<insert your MapTiler Cloud API key here>`, tileSize: 512, zoomOffset: -1, minZoom: 0, maxZoom: 21 }, variants: { Streets: `streets`, Basic: `basic`, Bright: `bright`, Pastel: `pastel`, Positron: `positron`, Hybrid: { options: { variant: `hybrid`, ext: `jpg` } }, Toner: `toner`, Topo: `topo`, Voyager: `voyager` } }, Stamen: { url: `https://stamen-tiles-{s}.a.ssl.fastly.net/{variant}/{z}/{x}/{y}{r}.{ext}`, options: { attribution: `Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data {attribution.OpenStreetMap}`, subdomains: `abcd`, minZoom: 0, maxZoom: 20, variant: `toner`, ext: `png` }, variants: { Toner: `toner`, TonerBackground: `toner-background`, TonerHybrid: `toner-hybrid`, TonerLines: `toner-lines`, TonerLabels: `toner-labels`, TonerLite: `toner-lite`, Watercolor: { url: `https://stamen-tiles-{s}.a.ssl.fastly.net/{variant}/{z}/{x}/{y}.{ext}`, options: { variant: `watercolor`, ext: `jpg`, minZoom: 1, maxZoom: 16 } }, Terrain: { options: { variant: `terrain`, minZoom: 0, maxZoom: 18 } }, TerrainBackground: { options: { variant: `terrain-background`, minZoom: 0, maxZoom: 18 } }, TerrainLabels: { options: { variant: `terrain-labels`, minZoom: 0, maxZoom: 18 } }, TopOSMRelief: { url: `https://stamen-tiles-{s}.a.ssl.fastly.net/{variant}/{z}/{x}/{y}.{ext}`, options: { variant: `toposm-color-relief`, ext: `jpg`, bounds: [[22, -132], [51, -56]] } }, TopOSMFeatures: { options: { variant: `toposm-features`, bounds: [[22, -132], [51, -56]], opacity: 0.9 } } } }, TomTom: { url: `https://{s}.api.tomtom.com/map/1/tile/{variant}/{style}/{z}/{x}/{y}.{ext}?key={apikey}`, options: { variant: `basic`, maxZoom: 22, attribution: `<a href="https://tomtom.com" target="_blank">&copy;  1992 - ${(/* @__PURE__ */ new Date()).getFullYear()} TomTom.</a> `, subdomains: `abcd`, style: `main`, ext: `png`, apikey: `<insert your API key here>` }, variants: { Basic: `basic`, Hybrid: `hybrid`, Labels: `labels` } }, Esri: { url: `https://server.arcgisonline.com/ArcGIS/rest/services/{variant}/MapServer/tile/{z}/{y}/{x}`, options: { variant: `World_Street_Map`, attribution: `Tiles &copy; Esri` }, variants: { WorldStreetMap: { options: { attribution: `{attribution.Esri} &mdash; Source: Esri, DeLorme, NAVTEQ, USGS, Intermap, iPC, NRCAN, Esri Japan, METI, Esri China (Hong Kong), Esri (Thailand), TomTom, 2012` } }, DeLorme: { options: { variant: `Specialty/DeLorme_World_Base_Map`, minZoom: 1, maxZoom: 11, attribution: `{attribution.Esri} &mdash; Copyright: &copy;2012 DeLorme` } }, WorldTopoMap: { options: { variant: `World_Topo_Map`, attribution: `{attribution.Esri} &mdash; Esri, DeLorme, NAVTEQ, TomTom, Intermap, iPC, USGS, FAO, NPS, NRCAN, GeoBase, Kadaster NL, Ordnance Survey, Esri Japan, METI, Esri China (Hong Kong), and the GIS User Community` } }, WorldImagery: { options: { variant: `World_Imagery`, attribution: `{attribution.Esri} &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community` } }, WorldTerrain: { options: { variant: `World_Terrain_Base`, maxZoom: 13, attribution: `{attribution.Esri} &mdash; Source: USGS, Esri, TANA, DeLorme, and NPS` } }, WorldShadedRelief: { options: { variant: `World_Shaded_Relief`, maxZoom: 13, attribution: `{attribution.Esri} &mdash; Source: Esri` } }, WorldPhysical: { options: { variant: `World_Physical_Map`, maxZoom: 8, attribution: `{attribution.Esri} &mdash; Source: US National Park Service` } }, OceanBasemap: { options: { variant: `Ocean_Basemap`, maxZoom: 13, attribution: `{attribution.Esri} &mdash; Sources: GEBCO, NOAA, CHS, OSU, UNH, CSUMB, National Geographic, DeLorme, NAVTEQ, and Esri` } }, NatGeoWorldMap: { options: { variant: `NatGeo_World_Map`, maxZoom: 16, attribution: `{attribution.Esri} &mdash; National Geographic, Esri, DeLorme, NAVTEQ, UNEP-WCMC, USGS, NASA, ESA, METI, NRCAN, GEBCO, NOAA, iPC` } }, WorldGrayCanvas: { options: { variant: `Canvas/World_Light_Gray_Base`, maxZoom: 16, attribution: `{attribution.Esri} &mdash; Esri, DeLorme, NAVTEQ` } } } }, OpenWeatherMap: { url: `http://{s}.tile.openweathermap.org/map/{variant}/{z}/{x}/{y}.png?appid={apiKey}`, options: { maxZoom: 19, attribution: `Map data &copy; <a href="http://openweathermap.org">OpenWeatherMap</a>`, apiKey: `<insert your api key here>`, opacity: 0.5 }, variants: { Clouds: `clouds`, CloudsClassic: `clouds_cls`, Precipitation: `precipitation`, PrecipitationClassic: `precipitation_cls`, Rain: `rain`, RainClassic: `rain_cls`, Pressure: `pressure`, PressureContour: `pressure_cntr`, Wind: `wind`, Temperature: `temp`, Snow: `snow` } }, HERE: { url: `https://{s}.{base}.maps.api.here.com/maptile/2.1/{type}/{mapID}/{variant}/{z}/{x}/{y}/{size}/{format}?app_id={app_id}&app_code={app_code}&lg={language}`, options: { attribution: `Map &copy; 1987-${(/* @__PURE__ */ new Date()).getFullYear()} <a href="http://developer.here.com">HERE</a>`, subdomains: `1234`, mapID: `newest`, app_id: `<insert your app_id here>`, app_code: `<insert your app_code here>`, base: `base`, variant: `normal.day`, maxZoom: 20, type: `maptile`, language: `eng`, format: `png8`, size: `256` }, variants: { normalDay: `normal.day`, normalDayCustom: `normal.day.custom`, normalDayGrey: `normal.day.grey`, normalDayMobile: `normal.day.mobile`, normalDayGreyMobile: `normal.day.grey.mobile`, normalDayTransit: `normal.day.transit`, normalDayTransitMobile: `normal.day.transit.mobile`, normalDayTraffic: { options: { variant: `normal.traffic.day`, base: `traffic`, type: `traffictile` } }, normalNight: `normal.night`, normalNightMobile: `normal.night.mobile`, normalNightGrey: `normal.night.grey`, normalNightGreyMobile: `normal.night.grey.mobile`, normalNightTransit: `normal.night.transit`, normalNightTransitMobile: `normal.night.transit.mobile`, reducedDay: `reduced.day`, reducedNight: `reduced.night`, basicMap: { options: { type: `basetile` } }, mapLabels: { options: { type: `labeltile`, format: `png` } }, trafficFlow: { options: { base: `traffic`, type: `flowtile` } }, carnavDayGrey: `carnav.day.grey`, hybridDay: { options: { base: `aerial`, variant: `hybrid.day` } }, hybridDayMobile: { options: { base: `aerial`, variant: `hybrid.day.mobile` } }, hybridDayTransit: { options: { base: `aerial`, variant: `hybrid.day.transit` } }, hybridDayGrey: { options: { base: `aerial`, variant: `hybrid.grey.day` } }, hybridDayTraffic: { options: { variant: `hybrid.traffic.day`, base: `traffic`, type: `traffictile` } }, pedestrianDay: `pedestrian.day`, pedestrianNight: `pedestrian.night`, satelliteDay: { options: { base: `aerial`, variant: `satellite.day` } }, terrainDay: { options: { base: `aerial`, variant: `terrain.day` } }, terrainDayMobile: { options: { base: `aerial`, variant: `terrain.day.mobile` } } } }, HEREv3: { url: `https://{s}.{base}.maps.ls.hereapi.com/maptile/2.1/{type}/{mapID}/{variant}/{z}/{x}/{y}/{size}/{format}?apiKey={apiKey}&lg={language}`, options: { attribution: `Map &copy; 1987-${(/* @__PURE__ */ new Date()).getFullYear()} <a href="http://developer.here.com">HERE</a>`, subdomains: `1234`, mapID: `newest`, apiKey: `<insert your apiKey here>`, base: `base`, variant: `normal.day`, maxZoom: 20, type: `maptile`, language: `eng`, format: `png8`, size: `256` }, variants: { normalDay: `normal.day`, normalDayCustom: `normal.day.custom`, normalDayGrey: `normal.day.grey`, normalDayMobile: `normal.day.mobile`, normalDayGreyMobile: `normal.day.grey.mobile`, normalDayTransit: `normal.day.transit`, normalDayTransitMobile: `normal.day.transit.mobile`, normalNight: `normal.night`, normalNightMobile: `normal.night.mobile`, normalNightGrey: `normal.night.grey`, normalNightGreyMobile: `normal.night.grey.mobile`, normalNightTransit: `normal.night.transit`, normalNightTransitMobile: `normal.night.transit.mobile`, reducedDay: `reduced.day`, reducedNight: `reduced.night`, basicMap: { options: { type: `basetile` } }, mapLabels: { options: { type: `labeltile`, format: `png` } }, trafficFlow: { options: { base: `traffic`, type: `flowtile` } }, carnavDayGrey: `carnav.day.grey`, hybridDay: { options: { base: `aerial`, variant: `hybrid.day` } }, hybridDayMobile: { options: { base: `aerial`, variant: `hybrid.day.mobile` } }, hybridDayTransit: { options: { base: `aerial`, variant: `hybrid.day.transit` } }, hybridDayGrey: { options: { base: `aerial`, variant: `hybrid.grey.day` } }, pedestrianDay: `pedestrian.day`, pedestrianNight: `pedestrian.night`, satelliteDay: { options: { base: `aerial`, variant: `satellite.day` } }, terrainDay: { options: { base: `aerial`, variant: `terrain.day` } }, terrainDayMobile: { options: { base: `aerial`, variant: `terrain.day.mobile` } } } }, FreeMapSK: { url: `https://{s}.freemap.sk/T/{z}/{x}/{y}.jpeg`, options: { minZoom: 8, maxZoom: 16, subdomains: `abcd`, bounds: [[47.204642, 15.996093], [49.830896, 22.576904]], attribution: `{attribution.OpenStreetMap}, visualization CC-By-SA 2.0 <a href="http://freemap.sk">Freemap.sk</a>` } }, MtbMap: { url: `http://tile.mtbmap.cz/mtbmap_tiles/{z}/{x}/{y}.png`, options: { attribution: `{attribution.OpenStreetMap} &amp; USGS` } }, CartoDB: { url: `https://{s}.basemaps.cartocdn.com/{variant}/{z}/{x}/{y}{r}.png`, options: { attribution: `{attribution.OpenStreetMap} &copy; <a href="https://carto.com/attributions">CARTO</a>`, subdomains: `abcd`, maxZoom: 20, variant: `light_all` }, variants: { Positron: `light_all`, PositronNoLabels: `light_nolabels`, PositronOnlyLabels: `light_only_labels`, DarkMatter: `dark_all`, DarkMatterNoLabels: `dark_nolabels`, DarkMatterOnlyLabels: `dark_only_labels`, Voyager: `rastertiles/voyager`, VoyagerNoLabels: `rastertiles/voyager_nolabels`, VoyagerOnlyLabels: `rastertiles/voyager_only_labels`, VoyagerLabelsUnder: `rastertiles/voyager_labels_under` } }, HikeBike: { url: `https://tiles.wmflabs.org/{variant}/{z}/{x}/{y}.png`, options: { maxZoom: 19, attribution: `{attribution.OpenStreetMap}`, variant: `hikebike` }, variants: { HikeBike: {}, HillShading: { options: { maxZoom: 15, variant: `hillshading` } } } }, BasemapAT: { url: `https://maps{s}.wien.gv.at/basemap/{variant}/{type}/google3857/{z}/{y}/{x}.{format}`, options: { maxZoom: 19, attribution: `Datenquelle: <a href="https://www.basemap.at">basemap.at</a>`, subdomains: [``, `1`, `2`, `3`, `4`], type: `normal`, format: `png`, bounds: [[46.35877, 8.782379], [49.037872, 17.189532]], variant: `geolandbasemap` }, variants: { basemap: { options: { maxZoom: 20, variant: `geolandbasemap` } }, grau: `bmapgrau`, overlay: `bmapoverlay`, terrain: { options: { variant: `bmapgelaende`, type: `grau`, format: `jpeg` } }, surface: { options: { variant: `bmapoberflaeche`, type: `grau`, format: `jpeg` } }, highdpi: { options: { variant: `bmaphidpi`, format: `jpeg` } }, orthofoto: { options: { maxZoom: 20, variant: `bmaporthofoto30cm`, format: `jpeg` } } } }, nlmaps: { url: `https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0/{variant}/EPSG:3857/{z}/{x}/{y}.png`, options: { minZoom: 6, maxZoom: 19, bounds: [[50.5, 3.25], [54, 7.6]], attribution: `Kaartgegevens &copy; <a href="https://www.kadaster.nl">Kadaster</a>` }, variants: { standaard: `standaard`, pastel: `pastel`, grijs: `grijs`, water: `water`, luchtfoto: { url: `https://service.pdok.nl/hwh/luchtfotorgb/wmts/v1_0/Actueel_ortho25/EPSG:3857/{z}/{x}/{y}.jpeg` } } }, NASAGIBS: { url: `https://map1.vis.earthdata.nasa.gov/wmts-webmerc/{variant}/default/{time}/{tilematrixset}{maxZoom}/{z}/{y}/{x}.{format}`, options: { attribution: `Imagery provided by services from the Global Imagery Browse Services (GIBS), operated by the NASA/GSFC/Earth Science Data and Information System (<a href="https://earthdata.nasa.gov">ESDIS</a>) with funding provided by NASA/HQ.`, bounds: [[-85.0511287776, -179.999999975], [85.0511287776, 179.999999975]], minZoom: 1, maxZoom: 9, format: `jpg`, time: ``, tilematrixset: `GoogleMapsCompatible_Level` }, variants: { ModisTerraTrueColorCR: `MODIS_Terra_CorrectedReflectance_TrueColor`, ModisTerraBands367CR: `MODIS_Terra_CorrectedReflectance_Bands367`, ViirsEarthAtNight2012: { options: { variant: `VIIRS_CityLights_2012`, maxZoom: 8 } }, ModisTerraLSTDay: { options: { variant: `MODIS_Terra_Land_Surface_Temp_Day`, format: `png`, maxZoom: 7, opacity: 0.75 } }, ModisTerraSnowCover: { options: { variant: `MODIS_Terra_NDSI_Snow_Cover`, format: `png`, maxZoom: 8, opacity: 0.75 } }, ModisTerraAOD: { options: { variant: `MODIS_Terra_Aerosol`, format: `png`, maxZoom: 6, opacity: 0.75 } }, ModisTerraChlorophyll: { options: { variant: `MODIS_Terra_Chlorophyll_A`, format: `png`, maxZoom: 7, opacity: 0.75 } } } }, NLS: { url: `https://nls-{s}.tileserver.com/nls/{z}/{x}/{y}.jpg`, options: { attribution: `<a href="http://geo.nls.uk/maps/">National Library of Scotland Historic Maps</a>`, bounds: [[49.6, -12], [61.7, 3]], minZoom: 1, maxZoom: 18, subdomains: `0123` } }, JusticeMap: { url: `https://www.justicemap.org/tile/{size}/{variant}/{z}/{x}/{y}.png`, options: { attribution: `<a href="http://www.justicemap.org/terms.php">Justice Map</a>`, size: `county`, bounds: [[14, -180], [72, -56]] }, variants: { income: `income`, americanIndian: `indian`, asian: `asian`, black: `black`, hispanic: `hispanic`, multi: `multi`, nonWhite: `nonwhite`, white: `white`, plurality: `plural` } }, GeoportailFrance: { url: `https://wxs.ign.fr/{apikey}/geoportail/wmts?REQUEST=GetTile&SERVICE=WMTS&VERSION=1.0.0&STYLE={style}&TILEMATRIXSET=PM&FORMAT={format}&LAYER={variant}&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}`, options: { attribution: `<a target="_blank" href="https://www.geoportail.gouv.fr/">Geoportail France</a>`, bounds: [[-75, -180], [81, 180]], minZoom: 2, maxZoom: 18, apikey: `choisirgeoportail`, format: `image/png`, style: `normal`, variant: `GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2` }, variants: { plan: `GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2`, parcels: { options: { variant: `CADASTRALPARCELS.PARCELLAIRE_EXPRESS`, style: `PCI vecteur`, maxZoom: 20 } }, orthos: { options: { maxZoom: 19, format: `image/jpeg`, variant: `ORTHOIMAGERY.ORTHOPHOTOS` } } } }, OneMapSG: { url: `https://maps-{s}.onemap.sg/v3/{variant}/{z}/{x}/{y}.png`, options: { variant: `Default`, minZoom: 11, maxZoom: 18, bounds: [[1.56073, 104.11475], [1.16, 103.502]], attribution: `<img src="https://docs.onemap.sg/maps/images/oneMap64-01.png" alt="attribution" style="height:20px;width:20px;"/> New OneMap | Map data &copy; contributors, <a href="http://SLA.gov.sg">Singapore Land Authority</a>` }, variants: { Default: `Default`, Night: `Night`, Original: `Original`, Grey: `Grey`, LandLot: `LandLot` } }, USGS: { url: `https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}`, options: { maxZoom: 20, attribution: `Tiles courtesy of the <a href="https://usgs.gov/">U.S. Geological Survey</a>` }, variants: { USTopo: {}, USImagery: { url: `https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}` }, USImageryTopo: { url: `https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryTopo/MapServer/tile/{z}/{y}/{x}` } } }, WaymarkedTrails: { url: `https://tile.waymarkedtrails.org/{variant}/{z}/{x}/{y}.png`, options: { maxZoom: 18, attribution: `Map data: {attribution.OpenStreetMap} | Map style: &copy; <a href="https://waymarkedtrails.org">waymarkedtrails.org</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)` }, variants: { hiking: `hiking`, cycling: `cycling`, mtb: `mtb`, slopes: `slopes`, riding: `riding`, skating: `skating` } }, OpenAIP: { url: `https://{s}.tile.maps.openaip.net/geowebcache/service/tms/1.0.0/openaip_basemap@EPSG%3A900913@png/{z}/{x}/{y}.{ext}`, options: { attribution: `<a href="https://www.openaip.net/">openAIP Data</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-NC-SA</a>)`, ext: `png`, minZoom: 4, maxZoom: 14, tms: true, detectRetina: true, subdomains: `12` } }, OpenSnowMap: { url: `https://tiles.opensnowmap.org/{variant}/{z}/{x}/{y}.png`, options: { minZoom: 9, maxZoom: 18, attribution: `Map data: {attribution.OpenStreetMap} & ODbL, &copy; <a href="https://www.opensnowmap.org/iframes/data.html">www.opensnowmap.org</a> <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>` }, variants: { pistes: `pistes` } }, AzureMaps: { url: `https://atlas.microsoft.com/map/tile?api-version={apiVersion}&tilesetId={variant}&x={x}&y={y}&zoom={z}&language={language}&subscription-key={subscriptionKey}`, options: { attribution: `See https://docs.microsoft.com/en-us/rest/api/maps/render-v2/get-map-tile for details.`, apiVersion: `2.0`, variant: `microsoft.imagery`, subscriptionKey: `<insert your subscription key here>`, language: `en-US` }, variants: { MicrosoftImagery: `microsoft.imagery`, MicrosoftBaseDarkGrey: `microsoft.base.darkgrey`, MicrosoftBaseRoad: `microsoft.base.road`, MicrosoftBaseHybridRoad: `microsoft.base.hybrid.road`, MicrosoftTerraMain: `microsoft.terra.main`, MicrosoftWeatherInfraredMain: { url: `https://atlas.microsoft.com/map/tile?api-version={apiVersion}&tilesetId={variant}&x={x}&y={y}&zoom={z}&timeStamp={timeStamp}&language={language}&subscription-key={subscriptionKey}`, options: { timeStamp: `2021-05-08T09:03:00Z`, attribution: `See https://docs.microsoft.com/en-us/rest/api/maps/render-v2/get-map-tile#uri-parameters for details.`, variant: `microsoft.weather.infrared.main` } }, MicrosoftWeatherRadarMain: { url: `https://atlas.microsoft.com/map/tile?api-version={apiVersion}&tilesetId={variant}&x={x}&y={y}&zoom={z}&timeStamp={timeStamp}&language={language}&subscription-key={subscriptionKey}`, options: { timeStamp: `2021-05-08T09:03:00Z`, attribution: `See https://docs.microsoft.com/en-us/rest/api/maps/render-v2/get-map-tile#uri-parameters for details.`, variant: `microsoft.weather.radar.main` } } } }, SwissFederalGeoportal: { url: `https://wmts.geo.admin.ch/1.0.0/{variant}/default/current/3857/{z}/{x}/{y}.jpeg`, options: { attribution: `&copy; <a href="https://www.swisstopo.admin.ch/">swisstopo</a>`, minZoom: 2, maxZoom: 18, bounds: [[45.398181, 5.140242], [48.230651, 11.47757]] }, variants: { NationalMapColor: `ch.swisstopo.pixelkarte-farbe`, NationalMapGrey: `ch.swisstopo.pixelkarte-grau`, SWISSIMAGE: { options: { variant: `ch.swisstopo.swissimage`, maxZoom: 19 } } } } }, e3.tileLayer.provider = function(t2, n2) {
  return new e3.TileLayer.Provider(t2, n2);
}, e3)), (ae.exports == null ? {} : ae.exports).default || ae.exports;
function S(e3, t2) {
  let n2 = a(t2);
  u(function() {
    t2 !== n2.current && e3.attributionControl != null && (n2.current != null && e3.attributionControl.removeAttribution(n2.current), t2 != null && e3.attributionControl.addAttribution(t2)), n2.current = t2;
  }, [e3, t2]);
}
function oe(e3, t2, n2) {
  t2.center !== n2.center && e3.setLatLng(t2.center), t2.radius != null && t2.radius !== n2.radius && e3.setRadius(t2.radius);
}
n();
function C(e3) {
  return Object.freeze({ __version: 1, map: e3 });
}
function se(e3, t2) {
  return Object.freeze({ ...e3, ...t2 });
}
var w = d(null);
function ce() {
  let e3 = i(w);
  if (e3 == null) throw Error(`No context provided: useLeafletContext() can only be used in a descendant of <MapContainer>`);
  return e3;
}
n(), ee();
function T(e3) {
  function t2(t3, n2) {
    let { instance: r2, context: i2 } = e3(t3).current;
    l(n2, () => r2);
    let { children: a2 } = t3;
    return a2 == null ? null : c.createElement(w, { value: i2 }, a2);
  }
  return s(t2);
}
function E(e3) {
  function t2(t3, n2) {
    let [r2, i2] = o(false), { instance: a2 } = e3(t3, i2).current;
    l(n2, () => a2), u(function() {
      r2 && a2.update();
    }, [a2, r2, t3.children]);
    let s2 = a2._contentNode;
    return s2 ? ne(t3.children, s2) : null;
  }
  return s(t2);
}
function D(e3) {
  function t2(t3, n2) {
    let { instance: r2 } = e3(t3).current;
    return l(n2, () => r2), null;
  }
  return s(t2);
}
n();
function O(e3) {
  return function(t2) {
    let n2 = ce(), r2 = e3(t2, n2), { instance: i2 } = r2.current, o2 = a(t2.position), { position: s2 } = t2;
    return u(function() {
      return i2.addTo(n2.map), function() {
        i2.remove();
      };
    }, [n2.map, i2]), u(function() {
      s2 != null && s2 !== o2.current && (i2.setPosition(s2), o2.current = s2);
    }, [i2, s2]), r2;
  };
}
n();
function k(e3, t2) {
  let n2 = a(void 0);
  u(function() {
    return t2 != null && e3.instance.on(t2), n2.current = t2, function() {
      n2.current != null && e3.instance.off(n2.current), n2.current = null;
    };
  }, [e3, t2]);
}
function A(e3, t2) {
  let n2 = e3.pane ?? t2.pane;
  return n2 ? { ...e3, pane: n2 } : e3;
}
function j(e3, t2) {
  return function(n2, r2) {
    let i2 = ce(), a2 = e3(A(n2, i2), i2);
    return S(i2.map, n2.attribution), k(a2.current, n2.eventHandlers), t2(a2.current, i2, n2, r2), a2;
  };
}
n();
function M(e3, t2, n2) {
  return Object.freeze({ instance: e3, context: t2, container: n2 });
}
function N(e3, t2) {
  return t2 == null ? function(t3, n2) {
    let r2 = a(void 0);
    return r2.current || (r2.current = e3(t3, n2)), r2;
  } : function(n2, r2) {
    let i2 = a(void 0);
    i2.current || (i2.current = e3(n2, r2));
    let o2 = a(n2), { instance: s2 } = i2.current;
    return u(function() {
      o2.current !== n2 && (t2(s2, n2, o2.current), o2.current = n2);
    }, [s2, n2, t2]), i2;
  };
}
n();
function le(e3, t2) {
  u(function() {
    return (t2.layerContainer ?? t2.map).addLayer(e3.instance), function() {
      var _a;
      (_a = t2.layerContainer) == null ? void 0 : _a.removeLayer(e3.instance), t2.map.removeLayer(e3.instance);
    };
  }, [t2, e3]);
}
function ue(e3) {
  return function(t2) {
    let n2 = ce(), r2 = e3(A(t2, n2), n2);
    return S(n2.map, t2.attribution), k(r2.current, t2.eventHandlers), le(r2.current, n2), r2;
  };
}
n();
function de(e3, t2) {
  let n2 = a(void 0);
  u(function() {
    if (t2.pathOptions !== n2.current) {
      let r2 = t2.pathOptions ?? {};
      e3.instance.setStyle(r2), n2.current = r2;
    }
  }, [e3, t2]);
}
function fe(e3) {
  return function(t2) {
    let n2 = ce(), r2 = e3(A(t2, n2), n2);
    return k(r2.current, t2.eventHandlers), le(r2.current, n2), de(r2.current, t2), r2;
  };
}
function pe(e3) {
  function t2(t3, n2) {
    return M(e3(t3), n2);
  }
  return D(O(N(t2)));
}
function me(e3, t2) {
  return T(ue(N(e3, t2)));
}
function he(e3, t2) {
  return E(j(N(e3), t2));
}
function ge(e3, t2) {
  return T(fe(N(e3, t2)));
}
function _e(e3, t2) {
  return D(ue(N(e3, t2)));
}
function ve(e3, t2, n2) {
  let { opacity: r2, zIndex: i2 } = t2;
  r2 != null && r2 !== n2.opacity && e3.setOpacity(r2), i2 != null && i2 !== n2.zIndex && e3.setZIndex(i2);
}
n();
function ye() {
  return ce().map;
}
var be = ge(function({ center: e3, children: t2, ...n2 }, r2) {
  let i2 = new x.Circle(e3, n2);
  return M(i2, se(r2, { overlayContainer: i2 }));
}, oe);
n();
function xe({ bounds: e3, boundsOptions: t2, center: n2, children: i2, className: s2, id: d2, placeholder: f2, style: p2, whenReady: m2, zoom: h2, ...g2 }, _2) {
  let [ee2] = o({ className: s2, id: d2, style: p2 }), [v2, te2] = o(null), ne2 = a(void 0);
  l(_2, () => (v2 == null ? void 0 : v2.map) ?? null, [v2]);
  let re2 = r((r2) => {
    if (r2 !== null && !ne2.current) {
      let i3 = new x.Map(r2, g2);
      ne2.current = i3, n2 != null && h2 != null ? i3.setView(n2, h2) : e3 != null && i3.fitBounds(e3, t2), m2 != null && i3.whenReady(m2), te2(C(i3));
    }
  }, []);
  u(() => () => {
    v2 == null ? void 0 : v2.map.remove();
  }, [v2]);
  let y2 = v2 ? c.createElement(w, { value: v2 }, i2) : f2 ?? null;
  return c.createElement(`div`, { ...ee2, ref: re2 }, y2);
}
var Se = s(xe), Ce = me(function({ position: e3, ...t2 }, n2) {
  let r2 = new x.Marker(e3, t2);
  return M(r2, se(n2, { overlayContainer: r2 }));
}, function(e3, t2, n2) {
  t2.position !== n2.position && e3.setLatLng(t2.position), t2.icon != null && t2.icon !== n2.icon && e3.setIcon(t2.icon), t2.zIndexOffset != null && t2.zIndexOffset !== n2.zIndexOffset && e3.setZIndexOffset(t2.zIndexOffset), t2.opacity != null && t2.opacity !== n2.opacity && e3.setOpacity(t2.opacity), e3.dragging != null && t2.draggable !== n2.draggable && (t2.draggable === true ? e3.dragging.enable() : e3.dragging.disable());
}), we = ge(function({ positions: e3, ...t2 }, n2) {
  let r2 = new x.Polyline(e3, t2);
  return M(r2, se(n2, { overlayContainer: r2 }));
}, function(e3, t2, n2) {
  t2.positions !== n2.positions && e3.setLatLngs(t2.positions);
});
n();
var Te = he(function(e3, t2) {
  return M(new x.Popup(e3, t2.overlayContainer), t2);
}, function(e3, t2, { position: n2 }, r2) {
  u(function() {
    let { instance: i2 } = e3;
    function a2(e4) {
      e4.popup === i2 && (i2.update(), r2(true));
    }
    function o2(e4) {
      e4.popup === i2 && r2(false);
    }
    return t2.map.on({ popupopen: a2, popupclose: o2 }), t2.overlayContainer == null ? (n2 != null && i2.setLatLng(n2), i2.openOn(t2.map)) : t2.overlayContainer.bindPopup(i2), function() {
      var _a;
      t2.map.off({ popupopen: a2, popupclose: o2 }), (_a = t2.overlayContainer) == null ? void 0 : _a.unbindPopup(), t2.map.removeLayer(i2);
    };
  }, [e3, t2, r2, n2]);
}), Ee = _e(function({ url: e3, ...t2 }, n2) {
  return M(new x.TileLayer(e3, A(t2, n2)), n2);
}, function(e3, t2, n2) {
  ve(e3, t2, n2);
  let { url: r2 } = t2;
  r2 != null && r2 !== n2.url && e3.setUrl(r2);
}), De = pe(function(e3) {
  return new x.Control.Zoom(e3);
});
n(), delete x.default.Icon.Default.prototype._getIconUrl, x.default.Icon.Default.mergeOptions({ iconRetinaUrl: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAABSCAMAAAAhFXfZAAAC91BMVEVMaXEzeak2f7I4g7g3g7cua5gzeKg8hJo3grY4g7c3grU0gLI2frE0daAubJc2gbQwd6QzeKk2gLMtd5sxdKIua5g1frA2f7IydaM0e6w2fq41fK01eqo3grgubJgta5cxdKI1f7AydaQydaMxc6EubJgvbJkwcZ4ubZkwcJwubZgubJcydqUydKIxapgubJctbJcubZcubJcvbJYubJcvbZkubJctbJctbZcubJg2f7AubJcrbZcubJcubJcua5g3grY0fq8ubJcubJdEkdEwhsw6i88vhswuhcsuhMtBjMgthMsrg8srgss6is8qgcs8i9A9iMYtg8spgcoogMo7hcMngMonf8olfso4gr8kfck5iM8jfMk4iM8he8k1fro7itAgesk2hs8eecgzfLcofssdeMg0hc4cd8g2hcsxeLQbdsgZdcgxeLImfcszhM0vda4xgckzhM4xg84wf8Yxgs4udKsvfcQucqhUndROmdM1fK0wcZ8vb5w0eqpQm9MzeKhXoNVcpdYydKNWn9VZotVKltJFjsIwcJ1Rms9OlslLmtH///8+kc9epdYzd6dbo9VHkMM2f7FHmNBClM8ydqVcpNY9hro3gLM9hLczealQmcw3fa46f7A8gLMxc6I3eagyc6FIldJMl9JSnNRSntNNl9JPnNJFi75UnM9ZodVKksg8kM45jc09e6ZHltFBk883gbRBh7pDk9EwcaBzn784g7dKkcY2i81Om9M7j85Llc81is09g7Q4grY/j9A0eqxKmdFFltBEjcXf6fFImdBCiLxJl9FGlNFBi78yiMxVndEvbpo6js74+vx+psPP3+o/ks5HkcpGmNCjwdZCkNDM3ehYoNJEls+lxNkxh8xHks0+jdC1zd5Lg6r+/v/H2ufz9/o3jM3t8/edvdM/k89Th61OiLBSjbZklbaTt9BfptdjmL1AicBHj8hGk9FAgK1dkLNTjLRekrdClc/k7fM0icy0y9tgp9c4jc2NtM9Dlc8zicxeXZn3AAAAQ3RSTlMAHDdTb4yPA+LtnEQmC4L2EmHqB7XA0d0sr478x4/Yd5i1zOfyPkf1sLVq4Nh3FvjxopQ2/STNuFzUwFIwxKaejILpIBEV9wAABhVJREFUeF6s1NdyFEcYBeBeoQIhRAkLlRDGrhIgY3BJL8CVeKzuyXFzzjkn5ZxzzuScg3PO8cKzu70JkO0LfxdTU//pM9vTu7Xgf6KqOVTb9X7toRrVEfBf1HTVjZccrT/2by1VV928Yty9ZbVuucdz90frG8DBjl9pVApbOstvmMuvVgaNXSfAAd6pGxpy6yxf5ph43pS/4f3uoaGm2rdu72S9xzOvMymkZFq/ptDrk90mhW7e4zl7HLzhxGWPR20xmSxJ/VqldG5m9XhaVOA1DadsNh3Pu5L2N6QtPO/32JpqQBVVk20oy/Pi2s23WEvyfHbe1thadVQttvm7Llf65gGmXK67XtupyoM7HQhmXdLS8oGWJNeOJ3C5fG5XCEJnkez3/oFdsvgJ4l2ANZwhrJKk/7OSXa+3Vw2WJMlKnGkobouYk6T0TyX30klOUnTD9HJ5qpckL3EW/w4XF3Xd0FGywXUrstrclVsqz5Pd/sXFYyDnPdrLcQODmGOK47IZb4CmibmMn+MYRzFZ5jg33ZL/EJrWcszHmANy3ARBK/IXtciJy8VsitPSdE3uuHxzougojcUdr8/32atnz/ev3f/K5wtpxUTpcaI45zusVDpYtZi+jg0oU9b3x74h7+n9ABvYEZeKaVq0sh0AtLKsFtqNBdeT0MrSzwwlq9+x6xAO4tgOtSzbCjrNQQiNvQUbUEubvzBUeGw26yDCsRHCoLkTHDa7IdOLIThs/gHvChszh2CimE8peRs47cxANI0lYNB5y1DljpOF0IhzBDPOZnDOqYYbeGKECbPzWnXludPphw5c2YBq5zlwXphIbO4VDCZ0gnPfUO1TwZoYwAs2ExPCedAu9DAjfQUjzITQb3jNj0KG2Sgt6BHaQUdYzWz+XmBktOHwanXjaSTcwwziBcuMOtwBmqPrTOxFQR/DRKKPqyur0aiW6cULYsx6tBm0jXpR/AUWR6HRq9WVW6MRhIq5jLyjbaCTDCijyYJNpCajdyobP/eTw0iexBAKkJ3gA5KcQb2zBXsIBckn+xVv8jkZSaEFHE+jFEleAEfayRU0MouNoBmB/L50Ai/HSLIHxcrpCvnhSQAuakKp2C/YbCylJjXRVy/z3+Kv/RrNcCo+WUzlVEhzKffnTQnxeN9fWF88fiNCUdSTsaufaChKWInHeysygfpIqagoakW+vV20J8uyl6TyNKEZWV4oRSPyCkWpgOLSbkCObT8o2r6tlG58HQquf6O0v50tB7JM7F4EORd2dx/K0w/KHsVkLPaoYrwgP/y7krr3SSMA4zj+OBgmjYkxcdIJQyQRKgg2viX9Hddi9UBb29LrKR7CVVEEEXWojUkXNyfTNDE14W9gbHJNuhjDettN3ZvbOvdOqCD3Jp/9l+/wJE+9PkYGjx/fqkys3S2rMozM/o2106rfMUINo6hVqz+eu/hd1c4xTg0TAfy5kV+4UG6+IthHTU9woWmxuKNbTfuCSfovBCxq7EtHqvYL4Sm6F8GVxsSXHMQ07TOi1DKtZxjWaaIyi4CXWjxPccUw8WVbMYY5wxC1mzEyXMJWkllpRloi+Kkoq69sxBTlElF6aAxYUbjXNlhlDZilDnM4U5SlN5biRsRHnbx3mbeWjEh4mEyiuJDl5XcWVmX5GvNkFgLWZM5qwsop4/AWfLhU1cR7k1VVvcYCWRkOI6Xy5gmnphCYIkvzuNYzHzosq2oNk2RtSs8khfUOfHIDgR6ysYBaMpl4uEgk2U/oJTs9AaTSwma7dT69geAE2ZpEjUsn2ieJNHeKfrI3EcAGJ2ZaNgVuC8EBctCLc57P5u5led6IOBkIYkuQMrmmjChs4VkfOerHqSBkPzZlhe06RslZ3zMjk2sscqKwY0RcjKK+LWbzd7KiHhkncs/siFJ+V5eXxD34B8nVuJEpGJNmxN2gH3vSvp7J70tF+D1Ej8qUJD1TkErAND2GZwTFg/LubvmgiBG3SOvdlsqFQrkEzJCL1rstlnVFROixZoDDSuXQFHESwVGlcuQcMb/b42NgjLowh5MTDFE3vNB5qStRIErdCQEh6pLPR92anSUb/wAIhldAaDMpGgAAAABJRU5ErkJggg==`, iconUrl: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAApCAYAAADAk4LOAAAFgUlEQVR4Aa1XA5BjWRTN2oW17d3YaZtr2962HUzbDNpjszW24mRt28p47v7zq/bXZtrp/lWnXr337j3nPCe85NcypgSFdugCpW5YoDAMRaIMqRi6aKq5E3YqDQO3qAwjVWrD8Ncq/RBpykd8oZUb/kaJutow8r1aP9II0WmLKLIsJyv1w/kqw9Ch2MYdB++12Onxee/QMwvf4/Dk/Lfp/i4nxTXtOoQ4pW5Aj7wpici1A9erdAN2OH64x8OSP9j3Ft3b7aWkTg/Fm91siTra0f9on5sQr9INejH6CUUUpavjFNq1B+Oadhxmnfa8RfEmN8VNAsQhPqF55xHkMzz3jSmChWU6f7/XZKNH+9+hBLOHYozuKQPxyMPUKkrX/K0uWnfFaJGS1QPRtZsOPtr3NsW0uyh6NNCOkU3Yz+bXbT3I8G3xE5EXLXtCXbbqwCO9zPQYPRTZ5vIDXD7U+w7rFDEoUUf7ibHIR4y6bLVPXrz8JVZEql13trxwue/uDivd3fkWRbS6/IA2bID4uk0UpF1N8qLlbBlXs4Ee7HLTfV1j54APvODnSfOWBqtKVvjgLKzF5YdEk5ewRkGlK0i33Eofffc7HT56jD7/6U+qH3Cx7SBLNntH5YIPvODnyfIXZYRVDPqgHtLs5ABHD3YzLuespb7t79FY34DjMwrVrcTuwlT55YMPvOBnRrJ4VXTdNnYug5ucHLBjEpt30701A3Ts+HEa73u6dT3FNWwflY86eMHPk+Yu+i6pzUpRrW7SNDg5JHR4KapmM5Wv2E8Tfcb1HoqqHMHU+uWDD7zg54mz5/2BSnizi9T1Dg4QQXLToGNCkb6tb1NU+QAlGr1++eADrzhn/u8Q2YZhQVlZ5+CAOtqfbhmaUCS1ezNFVm2imDbPmPng5wmz+gwh+oHDce0eUtQ6OGDIyR0uUhUsoO3vfDmmgOezH0mZN59x7MBi++WDL1g/eEiU3avlidO671bkLfwbw5XV2P8Pzo0ydy4t2/0eu33xYSOMOD8hTf4CrBtGMSoXfPLchX+J0ruSePw3LZeK0juPJbYzrhkH0io7B3k164hiGvawhOKMLkrQLyVpZg8rHFW7E2uHOL888IBPlNZ1FPzstSJM694fWr6RwpvcJK60+0HCILTBzZLFNdtAzJaohze60T8qBzyh5ZuOg5e7uwQppofEmf2++DYvmySqGBuKaicF1blQjhuHdvCIMvp8whTTfZzI7RldpwtSzL+F1+wkdZ2TBOW2gIF88PBTzD/gpeREAMEbxnJcaJHNHrpzji0gQCS6hdkEeYt9DF/2qPcEC8RM28Hwmr3sdNyht00byAut2k3gufWNtgtOEOFGUwcXWNDbdNbpgBGxEvKkOQsxivJx33iow0Vw5S6SVTrpVq11ysA2Rp7gTfPfktc6zhtXBBC+adRLshf6sG2RfHPZ5EAc4sVZ83yCN00Fk/4kggu40ZTvIEm5g24qtU4KjBrx/BTTH8ifVASAG7gKrnWxJDcU7x8X6Ecczhm3o6YicvsLXWfh3Ch1W0k8x0nXF+0fFxgt4phz8QvypiwCCFKMqXCnqXExjq10beH+UUA7+nG6mdG/Pu0f3LgFcGrl2s0kNNjpmoJ9o4B29CMO8dMT4Q5ox8uitF6fqsrJOr8qnwNbRzv6hSnG5wP+64C7h9lp30hKNtKdWjtdkbuPA19nJ7Tz3zR/ibgARbhb4AlhavcBebmTHcFl2fvYEnW0ox9xMxKBS8btJ+KiEbq9zA4RthQXDhPa0T9TEe69gWupwc6uBUphquXgf+/FrIjweHQS4/pduMe5ERUMHUd9xv8ZR98CxkS4F2n3EUrUZ10EYNw7BWm9x1GiPssi3GgiGRDKWRYZfXlON+dfNbM+GgIwYdwAAAAASUVORK5CYII=`, shadowUrl: `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAQAAAACach9AAACMUlEQVR4Ae3ShY7jQBAE0Aoz/f9/HTMzhg1zrdKUrJbdx+Kd2nD8VNudfsL/Th///dyQN2TH6f3y/BGpC379rV+S+qqetBOxImNQXL8JCAr2V4iMQXHGNJxeCfZXhSRBcQMfvkOWUdtfzlLgAENmZDcmo2TVmt8OSM2eXxBp3DjHSMFutqS7SbmemzBiR+xpKCNUIRkdkkYxhAkyGoBvyQFEJEefwSmmvBfJuJ6aKqKWnAkvGZOaZXTUgFqYULWNSHUckZuR1HIIimUExutRxwzOLROIG4vKmCKQt364mIlhSyzAf1m9lHZHJZrlAOMMztRRiKimp/rpdJDc9Awry5xTZCte7FHtuS8wJgeYGrex28xNTd086Dik7vUMscQOa8y4DoGtCCSkAKlNwpgNtphjrC6MIHUkR6YWxxs6Sc5xqn222mmCRFzIt8lEdKx+ikCtg91qS2WpwVfBelJCiQJwvzixfI9cxZQWgiSJelKnwBElKYtDOb2MFbhmUigbReQBV0Cg4+qMXSxXSyGUn4UbF8l+7qdSGnTC0XLCmahIgUHLhLOhpVCtw4CzYXvLQWQbJNmxoCsOKAxSgBJno75avolkRw8iIAFcsdc02e9iyCd8tHwmeSSoKTowIgvscSGZUOA7PuCN5b2BX9mQM7S0wYhMNU74zgsPBj3HU7wguAfnxxjFQGBE6pwN+GjME9zHY7zGp8wVxMShYX9NXvEWD3HbwJf4giO4CFIQxXScH1/TM+04kkBiAAAAAElFTkSuQmCC` });
var Oe = { mapContainer: { width: `100%`, height: `100%` }, dialogTitle: { display: `flex`, justifyContent: `space-between`, alignItems: `center` } };
function ke(e3) {
  let t2 = ye(), [n2, r2] = c.useState(``), [i2, a2] = c.useState(``), [o2, s2] = c.useState(``);
  if (JSON.stringify(e3.rxData) !== n2 && e3.markers.filter((e4) => e4.latitude && e4.longitude).length || JSON.stringify(e3.rxStyle) !== i2 || JSON.stringify(e3.markers) !== o2) {
    let n3 = 0, i3 = 0;
    e3.markers.forEach((e4) => {
      n3 += e4.latitude || 0, i3 += e4.longitude || 0;
    }), n3 /= e3.markers.length, i3 /= e3.markers.length, t2.setView([n3, i3], parseInt(e3.rxData.defaultZoom) || 18), e3.markers.every((e4) => t2.getBounds().contains([e4.latitude || 0, e4.longitude || 0])) || t2.fitBounds(e3.markers.map((e4) => [e4.latitude || 0, e4.longitude || 0])), r2(JSON.stringify(e3.rxData)), a2(JSON.stringify(e3.rxStyle)), s2(JSON.stringify(e3.markers));
  }
  return null;
}
var P = { default: { url: `https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png`, attribution: `&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors`, title: `openstreetmap.de` }, darkmatter: { url: `https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png`, attribution: `<a href="https://carto.com/attributions">CARTO</a>`, title: `Dark matter` }, stadiaosmbright: { url: `https://tiles.stadiamaps.com/tiles/osm_bright/{z}/{x}/{y}{r}.png`, attribution: `&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors`, title: `Stadia OSM Bright` }, esriworldimagery: { url: `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}`, attribution: `Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community`, title: `Esri World Imagery` } };
async function Ae(e3, t2) {
  let n2 = e3.split(`.`);
  n2.pop();
  let r2 = n2.join(`.`);
  return await t2.getObject(r2) ?? null;
}
function je(e3) {
  return typeof e3 == `object` ? e3[y.getLanguage()] || e3.en : e3;
}
async function Me(e3, t2, n2, r2) {
  var _a, _b, _c, _d, _e2, _f;
  if (t2[e3.name]) {
    let i2 = await r2.getObject(t2[e3.name]), a2 = false, o2 = null, s2 = null;
    ((_a = i2 == null ? void 0 : i2.common) == null ? void 0 : _a.color) ? (t2[`color${e3.index}`] = i2.common.color, a2 = true) : i2 && (o2 = await Ae(t2[e3.name], r2), o2 && (o2.type === `channel` || o2.type === `device`) && (((_b = o2.common) == null ? void 0 : _b.color) ? (t2[`name${e3.index}`] = o2.common.color, a2 = true) : (s2 = await Ae(t2[e3.name], r2), ((_c = s2 == null ? void 0 : s2.common) == null ? void 0 : _c.color) && (t2[`name${e3.index}`] = s2.common.color, a2 = true)))), ((_d = i2 == null ? void 0 : i2.common) == null ? void 0 : _d.name) ? (a2 = true, t2[`name${e3.index}`] = je(i2.common.name)) : i2 && (o2 || (o2 = await Ae(t2[e3.name], r2)), o2 && (o2.type === `channel` || o2.type === `device`) && (((_e2 = o2.common) == null ? void 0 : _e2.name) ? (t2[`name${e3.index}`] = je(o2.common.name), a2 = true) : (s2 || (s2 = await Ae(t2[e3.name], r2)), ((_f = s2 == null ? void 0 : s2.common) == null ? void 0 : _f.name) && (t2[`name${e3.index}`] = je(s2.common.name), a2 = true)))), a2 && n2(t2);
  }
}
var Ne = class e2 extends y {
  fillDataTimer = null;
  constructor(e3) {
    super(e3), this.state = { ...this.state, dialog: false, history: [], objects: [] };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Map`, visSet: `vis-2-widgets-nils-fork`, visName: `Map`, visWidgetLabel: `map`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `widgetTitle`, label: `name` }, { name: `markersCount`, label: `markers_count`, type: `number`, default: 1 }, { name: `theme`, label: `theme`, type: `select`, options: Object.keys(P).map((e3) => ({ value: e3, label: P[e3].title })), default: `default`, noTranslation: true }, { name: `themeUrl`, label: `theme_url`, hidden: (e3) => e3.theme && e3.theme !== "default" }, { name: `themeAttribution`, label: `theme_attribution`, hidden: (e3) => e3.theme && e3.theme !== "default" }, { name: `defaultZoom`, label: `default_zoom`, default: 12, type: `slider`, min: 1, max: 25 }, { name: `noUserInteractions`, label: `no_user_interactions`, default: false, type: `checkbox` }, { name: `hideZoomButtons`, label: `hide_zoom`, default: false, type: `checkbox`, hidden: `data["noUserInteractions"]` }, { name: `hideFullScreenButton`, label: `hide_full`, default: false, type: `checkbox` }] }, { name: `markers`, label: `markers`, indexFrom: 1, indexTo: `markersCount`, fields: [{ name: `position`, type: `id`, label: `position`, onChange: Me, tooltip: `position_help` }, { name: `longitude`, hidden: (e3, t2) => !!e3[`position${t2}`], type: `id`, label: `longitude`, onChange: Me }, { name: `latitude`, hidden: (e3, t2) => !!e3[`position${t2}`], type: `id`, label: `latitude` }, { name: `radius`, type: `id`, label: `radius`, tooltip: `radius_tooltip` }, { name: `name`, label: `name` }, { name: `color`, type: `color`, label: `color` }, { name: `icon`, type: `image`, label: `icon` }, { name: `useHistory`, type: `checkbox`, label: `use_history`, default: true }] }], visDefaultStyle: { width: `100%`, height: 240, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_map.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  async propertiesUpdate() {
    var _a, _b, _c, _d, _e2, _f, _g;
    let e3 = ((_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory) || `history.0`, t2 = { instance: ((_d = (_c = this.props.context.systemConfig) == null ? void 0 : _c.common) == null ? void 0 : _d.defaultHistory) || `history.0`, from: false, ack: false, q: false, addID: false, end: (/* @__PURE__ */ new Date()).getTime(), count: 100 }, n2 = [];
    for (let r3 = 1; r3 <= this.state.rxData.markersCount; r3++) {
      let i3 = y.getHistoryInstance(this.state.objects[r3], e3);
      if (this.state.rxData[`position${r3}`] && this.state.rxData[`useHistory${r3}`] && i3) {
        t2.instance = i3;
        let e4 = await this.props.context.socket.getHistory(this.state.rxData[`position${r3}`], t2);
        n2[r3] = e4.filter((e5) => e5.val).sort((e5, t3) => e5.ts > t3.ts ? 1 : -1).map((e5) => ({ val: e5.val, ts: e5.ts }));
      }
    }
    this.setState({ history: n2 });
    let r2 = [], i2 = [];
    for (let e4 = 1; e4 <= this.state.rxData.markersCount; e4++) this.state.rxData[`position${e4}`] && this.state.rxData[`position${e4}`] !== `nothing_selected` && i2.push(this.state.rxData[`oid${e4}`]);
    let a2 = i2.length && await this.props.context.socket.getObjectsById(i2) || {};
    for (let e4 = 1; e4 <= this.state.rxData.markersCount; e4++) if (this.state.rxData[`position${e4}`] && this.state.rxData[`position${e4}`] !== `nothing_selected`) {
      let t3 = a2[this.state.rxData[`position${e4}`]];
      if (!t3) {
        r2[e4] = { common: {}, _id: this.state.rxData[`position${e4}`] };
        continue;
      }
      if (t3.common || (t3.common = {}), !this.state.rxData[`icon${e4}`] && !t3.common.icon && (t3.type === `state` || t3.type === `channel`)) {
        let n3 = this.state.rxData[`position${e4}`].split(`.`), r3 = await this.props.context.socket.getObject(n3.slice(0, -1).join(`.`));
        if (!((_e2 = r3 == null ? void 0 : r3.common) == null ? void 0 : _e2.icon) && (t3.type === `state` || t3.type === `channel`)) {
          let e5 = await this.props.context.socket.getObject(n3.slice(0, -2).join(`.`));
          ((_f = e5 == null ? void 0 : e5.common) == null ? void 0 : _f.icon) && (t3.common.icon = e5.common.icon, (e5.type === `instance` || e5.type === `adapter`) && (t3.common.icon = `../${e5.common.name}.admin/${t3.common.icon}`));
        } else ((_g = r3 == null ? void 0 : r3.common) == null ? void 0 : _g.icon) && (t3.common.icon = r3.common.icon, (r3.type === `instance` || r3.type === `adapter`) && (t3.common.icon = `../${r3.common.name}.admin/${t3.common.icon}`));
      }
      r2[e4] = { common: t3.common, _id: t3._id };
    }
    JSON.stringify(r2) !== JSON.stringify(this.state.objects) && this.setState({ objects: r2 });
  }
  async componentDidMount() {
    super.componentDidMount(), await this.propertiesUpdate(), this.fillDataTimer = setTimeout(() => {
      this.fillDataTimer = null, this.setState({ forceShowMap: true });
    }, 2e3);
  }
  componentWillUnmount() {
    this.fillDataTimer && (this.fillDataTimer = (clearTimeout(this.fillDataTimer), null));
  }
  async onRxDataChanged() {
    await this.propertiesUpdate();
  }
  async onStateUpdated() {
    await this.propertiesUpdate();
  }
  renderMap() {
    var _a, _b, _c;
    let e3 = [];
    for (let t3 = 1; t3 <= this.state.rxData.markersCount; t3++) {
      let n3 = this.getPropertyValue(`position${t3}`), r3;
      r3 = window.isFinite(this.state.rxData[`radius${t3}`]) ? parseFloat(this.state.rxData[`radius${t3}`]) : parseFloat(this.getPropertyValue(`radius${t3}`)) || 0;
      let i2 = n3 == null ? void 0 : n3.toString().split(`;`), a2, o2;
      (i2 == null ? void 0 : i2.length) === 2 ? (a2 = parseFloat(i2[0]) || 0, o2 = parseFloat(i2[1]) || 0) : (a2 = parseFloat(this.getPropertyValue(`longitude${t3}`)) || 0, o2 = parseFloat(this.getPropertyValue(`latitude${t3}`)) || 0);
      let s2 = { i: t3, longitude: a2, latitude: o2, radius: r3, name: this.state.rxData[`name${t3}`], color: this.state.rxData[`color${t3}`], icon: this.state.rxData[`icon${t3}`] || ((_b = (_a = this.state.objects[t3]) == null ? void 0 : _a.common) == null ? void 0 : _b.icon) };
      ((_c = s2.icon) == null ? void 0 : _c.startsWith(`_PRJ_NAME`)) && (s2.icon = s2.icon.replace(`_PRJ_NAME`, `${this.props.context.adapterName}.${this.props.context.instance}/${this.props.context.projectName}/`)), (s2.longitude || s2.latitude) && e3.push(s2);
    }
    if (!e3.length) return null;
    this.fillDataTimer && (this.fillDataTimer = (clearTimeout(this.fillDataTimer), null));
    let t2, n2;
    this.state.rxData.theme && P[this.state.rxData.theme] ? (t2 = P[this.state.rxData.theme].url, n2 = P[this.state.rxData.theme].attribution) : this.state.rxData.themeUrl && (t2 = this.state.rxData.themeUrl, n2 = this.state.rxData.themeAttribution), t2 || (t2 = P.default.url), n2 || (n2 = P.default.attribution);
    let r2 = this.state.rxData.noUserInteractions ? { doubleClickZoom: false, closePopupOnClick: false, dragging: false, zoomSnap: 1, zoomDelta: 1, trackResize: false, touchZoom: false, scrollWheelZoom: false } : {};
    return v(g, { children: [_(`style`, { children: `.leaflet-control-attribution {
    display: none !important;
}
/*.leaflet-div-icon {
    border-radius: 50%;
}*/` }), v(Se, { style: Oe.mapContainer, scrollWheelZoom: true, zoom: parseFloat(this.state.rxData.defaultZoom) || 18, center: [0, 0], zoomControl: false, ...r2, children: [_(Ee, { attribution: n2, url: t2 }), !this.state.rxData.hideZoomButtons && !this.state.rxData.noUserInteractions ? _(De, { position: `bottomright` }) : null, e3.map((e4, t3) => {
      var _a2;
      let n3 = ((_a2 = this.state.history[e4.i]) == null ? void 0 : _a2.map((e5) => {
        let t4 = e5.val.split(`;`);
        return [parseFloat(t4[1] || `0`), parseFloat(t4[0] || `0`)];
      })) || [];
      n3.push([e4.latitude, e4.longitude]);
      let r3 = e4.icon ? new x.default.Icon({ iconUrl: e4.icon, iconRetinaUrl: e4.icon, iconAnchor: new x.default.Point(16, 16), popupAnchor: new x.default.Point(0, -16), shadowUrl: void 0, shadowSize: void 0, shadowAnchor: void 0, iconSize: new x.default.Point(32, 32), className: `leaflet-div-icon` }) : new x.default.Icon.Default();
      return v(c.Fragment, { children: [_(Ce, { position: [e4.latitude, e4.longitude], icon: r3, title: e4.name, eventHandlers: { click: () => {
        window.document.querySelectorAll(`.leaflet-popup-close-button`).forEach((e5) => e5.addEventListener(`click`, (e6) => e6.preventDefault()));
      } }, children: _(Te, { children: e4.name }) }), this.state.history[e4.i] ? n3.map((t4, r4) => r4 < n3.length - 1 && _(we, { pathOptions: { color: e4.color || `blue`, opacity: r4 + 1 / n3.length }, positions: [t4, n3[r4 + 1]] }, r4)) : null, e4.radius ? _(be, { center: [e4.latitude, e4.longitude], pathOptions: { color: e4.color || `blue` }, radius: e4.radius }) : null] }, t3);
    }), _(ke, { markers: e3, rxData: this.state.rxData, rxStyle: this.state.rxStyle })] }, `${t2}_${!!this.state.rxData.noUserInteractions}`)] });
  }
  renderDialog() {
    return v(h, { open: !!this.state.dialog, fullScreen: true, onClose: () => this.setState({ dialog: false }), children: [v(m, { style: Oe.dialogTitle, children: [this.state.rxData.widgetTitle, _(f, { onClick: () => this.setState({ dialog: false }), children: _(re, {}) })] }), _(p, { children: this.renderMap() })] });
  }
  renderWidgetBody(e3) {
    super.renderWidgetBody(e3);
    let t2 = v(g, { children: [this.renderDialog(), this.renderMap()] }), n2 = this.state.rxData.hideFullScreenButton ? null : _(f, { onClick: () => this.setState({ dialog: true }), children: _(ie, { style: { color: (this.state.rxData.noCard || e3.widget.usedInWidget) && (!this.state.rxData.theme || this.state.rxData.theme === "default" || this.state.rxData.theme === `stadiaosmbright`) ? `#111` : void 0 } }) });
    return this.state.rxData.noCard || e3.widget.usedInWidget ? v(`div`, { style: { width: `100%`, height: `100%` }, children: [_(`div`, { style: { position: `absolute`, top: 0, right: 0, zIndex: 500 }, children: n2 }), t2] }) : this.wrapContent(t2, this.state.rxData.widgetTitle ? n2 : v(`div`, { style: { display: `flex`, width: `100%` }, children: [_(`div`, { style: { flex: 1 } }), n2] }), { boxSizing: `border-box`, paddingBottom: 10, height: `100%` });
  }
};
export {
  Ne as default
};
