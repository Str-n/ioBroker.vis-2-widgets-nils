import { g as _, __tla as __tla_0 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
import { _ as e, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react_mf_2_dom__loadShare__.js-DD62h7KS.js";
let o;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })()
]).then(async () => {
  o = _(e);
});
export {
  __tla,
  o as r
};
