import { B as e, g as t } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { H as n, O as r, Q as i, ft as a, k as o, pt as s, st as c } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as l } from "./Generic-BOiMPpxz.js";
var u = c(a(`path`, { d: `M8 19c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2s-2 .9-2 2v10c0 1.1.9 2 2 2m6-12v10c0 1.1.9 2 2 2s2-.9 2-2V7c0-1.1-.9-2-2-2s-2 .9-2 2` }), `PauseRounded`), d = c(a(`path`, { d: `M8 6.82v10.36c0 .79.87 1.27 1.54.84l8.14-5.18c.62-.39.62-1.29 0-1.69L9.54 5.98C8.87 5.55 8 6.03 8 6.82` }), `PlayArrowRounded`), f = c(a(`path`, { d: `M7 7h10v1.79c0 .45.54.67.85.35l2.79-2.79c.2-.2.2-.51 0-.71l-2.79-2.79c-.31-.31-.85-.09-.85.36V5H6c-.55 0-1 .45-1 1v4c0 .55.45 1 1 1s1-.45 1-1zm10 10H7v-1.79c0-.45-.54-.67-.85-.35l-2.79 2.79c-.2.2-.2.51 0 .71l2.79 2.79c.31.31.85.09.85-.36V19h11c.55 0 1-.45 1-1v-4c0-.55-.45-1-1-1s-1 .45-1 1zm-4-2.75V9.81c0-.45-.36-.81-.81-.81q-.195 0-.36.09l-1.49.74c-.21.1-.34.32-.34.55 0 .34.28.62.62.62h.88v3.25c0 .41.34.75.75.75s.75-.34.75-.75` }), `RepeatOneRounded`), p = c(a(`path`, { d: `M7 7h10v1.79c0 .45.54.67.85.35l2.79-2.79c.2-.2.2-.51 0-.71l-2.79-2.79c-.31-.31-.85-.09-.85.36V5H6c-.55 0-1 .45-1 1v4c0 .55.45 1 1 1s1-.45 1-1zm10 10H7v-1.79c0-.45-.54-.67-.85-.35l-2.79 2.79c-.2.2-.2.51 0 .71l2.79 2.79c.31.31.85.09.85-.36V19h11c.55 0 1-.45 1-1v-4c0-.55-.45-1-1-1s-1 .45-1 1z` }), `RepeatRounded`), m = c(a(`path`, { d: `M10.59 9.17 6.12 4.7a.996.996 0 0 0-1.41 0c-.39.39-.39 1.02 0 1.41l4.46 4.46zm4.76-4.32 1.19 1.19L4.7 17.88c-.39.39-.39 1.02 0 1.41s1.02.39 1.41 0L17.96 7.46l1.19 1.19c.31.31.85.09.85-.36V4.5c0-.28-.22-.5-.5-.5h-3.79c-.45 0-.67.54-.36.85m-.52 8.56-1.41 1.41 3.13 3.13-1.2 1.2c-.31.31-.09.85.36.85h3.79c.28 0 .5-.22.5-.5v-3.79c0-.45-.54-.67-.85-.35l-1.19 1.19z` }), `ShuffleRounded`), h = c(a(`path`, { d: `m7.58 16.89 5.77-4.07c.56-.4.56-1.24 0-1.63L7.58 7.11C6.91 6.65 6 7.12 6 7.93v8.14c0 .81.91 1.28 1.58.82M16 7v10c0 .55.45 1 1 1s1-.45 1-1V7c0-.55-.45-1-1-1s-1 .45-1 1` }), `SkipNextRounded`), g = c(a(`path`, { d: `M7 6c.55 0 1 .45 1 1v10c0 .55-.45 1-1 1s-1-.45-1-1V7c0-.55.45-1 1-1m3.66 6.82 5.77 4.07c.66.47 1.58-.01 1.58-.82V7.93c0-.81-.91-1.28-1.58-.82l-5.77 4.07c-.57.4-.57 1.24 0 1.64` }), `SkipPreviousRounded`), _ = c(a(`path`, { d: `M7 9v6h4l5 5V4l-5 5z` }), `VolumeMute`), v = c(a(`path`, { d: `M3 9v6h4l5 5V4L7 9zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02M14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77` }), `VolumeUp`);
e();
var y = { aliceblue: [240, 248, 255], antiquewhite: [250, 235, 215], aqua: [0, 255, 255], aquamarine: [127, 255, 212], azure: [240, 255, 255], beige: [245, 245, 220], bisque: [255, 228, 196], black: [0, 0, 0], blanchedalmond: [255, 235, 205], blue: [0, 0, 255], blueviolet: [138, 43, 226], brown: [165, 42, 42], burlywood: [222, 184, 135], cadetblue: [95, 158, 160], chartreuse: [127, 255, 0], chocolate: [210, 105, 30], coral: [255, 127, 80], cornflowerblue: [100, 149, 237], cornsilk: [255, 248, 220], crimson: [220, 20, 60], cyan: [0, 255, 255], darkblue: [0, 0, 139], darkcyan: [0, 139, 139], darkgoldenrod: [184, 134, 11], darkgray: [169, 169, 169], darkgreen: [0, 100, 0], darkgrey: [169, 169, 169], darkkhaki: [189, 183, 107], darkmagenta: [139, 0, 139], darkolivegreen: [85, 107, 47], darkorange: [255, 140, 0], darkorchid: [153, 50, 204], darkred: [139, 0, 0], darksalmon: [233, 150, 122], darkseagreen: [143, 188, 143], darkslateblue: [72, 61, 139], darkslategray: [47, 79, 79], darkslategrey: [47, 79, 79], darkturquoise: [0, 206, 209], darkviolet: [148, 0, 211], deeppink: [255, 20, 147], deepskyblue: [0, 191, 255], dimgray: [105, 105, 105], dimgrey: [105, 105, 105], dodgerblue: [30, 144, 255], firebrick: [178, 34, 34], floralwhite: [255, 250, 240], forestgreen: [34, 139, 34], fuchsia: [255, 0, 255], gainsboro: [220, 220, 220], ghostwhite: [248, 248, 255], gold: [255, 215, 0], goldenrod: [218, 165, 32], gray: [128, 128, 128], green: [0, 128, 0], greenyellow: [173, 255, 47], grey: [128, 128, 128], honeydew: [240, 255, 240], hotpink: [255, 105, 180], indianred: [205, 92, 92], indigo: [75, 0, 130], ivory: [255, 255, 240], khaki: [240, 230, 140], lavender: [230, 230, 250], lavenderblush: [255, 240, 245], lawngreen: [124, 252, 0], lemonchiffon: [255, 250, 205], lightblue: [173, 216, 230], lightcoral: [240, 128, 128], lightcyan: [224, 255, 255], lightgoldenrodyellow: [250, 250, 210], lightgray: [211, 211, 211], lightgreen: [144, 238, 144], lightgrey: [211, 211, 211], lightpink: [255, 182, 193], lightsalmon: [255, 160, 122], lightseagreen: [32, 178, 170], lightskyblue: [135, 206, 250], lightslategray: [119, 136, 153], lightslategrey: [119, 136, 153], lightsteelblue: [176, 196, 222], lightyellow: [255, 255, 224], lime: [0, 255, 0], limegreen: [50, 205, 50], linen: [250, 240, 230], magenta: [255, 0, 255], maroon: [128, 0, 0], mediumaquamarine: [102, 205, 170], mediumblue: [0, 0, 205], mediumorchid: [186, 85, 211], mediumpurple: [147, 112, 219], mediumseagreen: [60, 179, 113], mediumslateblue: [123, 104, 238], mediumspringgreen: [0, 250, 154], mediumturquoise: [72, 209, 204], mediumvioletred: [199, 21, 133], midnightblue: [25, 25, 112], mintcream: [245, 255, 250], mistyrose: [255, 228, 225], moccasin: [255, 228, 181], navajowhite: [255, 222, 173], navy: [0, 0, 128], oldlace: [253, 245, 230], olive: [128, 128, 0], olivedrab: [107, 142, 35], orange: [255, 165, 0], orangered: [255, 69, 0], orchid: [218, 112, 214], palegoldenrod: [238, 232, 170], palegreen: [152, 251, 152], paleturquoise: [175, 238, 238], palevioletred: [219, 112, 147], papayawhip: [255, 239, 213], peachpuff: [255, 218, 185], peru: [205, 133, 63], pink: [255, 192, 203], plum: [221, 160, 221], powderblue: [176, 224, 230], purple: [128, 0, 128], rebeccapurple: [102, 51, 153], red: [255, 0, 0], rosybrown: [188, 143, 143], royalblue: [65, 105, 225], saddlebrown: [139, 69, 19], salmon: [250, 128, 114], sandybrown: [244, 164, 96], seagreen: [46, 139, 87], seashell: [255, 245, 238], sienna: [160, 82, 45], silver: [192, 192, 192], skyblue: [135, 206, 235], slateblue: [106, 90, 205], slategray: [112, 128, 144], slategrey: [112, 128, 144], snow: [255, 250, 250], springgreen: [0, 255, 127], steelblue: [70, 130, 180], tan: [210, 180, 140], teal: [0, 128, 128], thistle: [216, 191, 216], tomato: [255, 99, 71], turquoise: [64, 224, 208], violet: [238, 130, 238], wheat: [245, 222, 179], white: [255, 255, 255], whitesmoke: [245, 245, 245], yellow: [255, 255, 0], yellowgreen: [154, 205, 50] };
for (let e3 in y) Object.freeze(y[e3]);
var b = Object.freeze(y), x = /* @__PURE__ */ Object.create(null);
for (let e3 in b) Object.hasOwn(b, e3) && (x[b[e3]] = e3);
var S = { to: {}, get: {} };
S.get = function(e3) {
  let t2 = e3.slice(0, 3).toLowerCase(), n2, r2;
  switch (t2) {
    case `hsl`:
      n2 = S.get.hsl(e3), r2 = `hsl`;
      break;
    case `hwb`:
      n2 = S.get.hwb(e3), r2 = `hwb`;
      break;
    default:
      n2 = S.get.rgb(e3), r2 = `rgb`;
  }
  return n2 ? { model: r2, value: n2 } : null;
}, S.get.rgb = function(e3) {
  if (!e3) return null;
  let t2 = /^#([a-f\d]{3,4})$/i, n2 = /^#([a-f\d]{6})([a-f\d]{2})?$/i, r2 = /^rgba?\(\s*([+-]?(?:\d*\.)?\d+(?:e\d+)?)(?=[\s,])\s*(?:,\s*)?([+-]?(?:\d*\.)?\d+(?:e\d+)?)(?=[\s,])\s*(?:,\s*)?([+-]?(?:\d*\.)?\d+(?:e\d+)?)\s*(?:[\s,|/]\s*([+-]?(?:\d*\.)?\d+(?:e\d+)?)(%?)\s*)?\)$/i, i2 = /^rgba?\(\s*([+-]?[\d.]+)%\s*,?\s*([+-]?[\d.]+)%\s*,?\s*([+-]?[\d.]+)%\s*(?:[\s,|/]\s*([+-]?[\d.]+)(%?)\s*)?\)$/i, a2 = /^(\w+)$/, o2 = [0, 0, 0, 1], s2, c2, l2;
  if (s2 = e3.match(n2)) {
    for (l2 = s2[2], s2 = s2[1], c2 = 0; c2 < 3; c2++) {
      let e4 = c2 * 2;
      o2[c2] = Number.parseInt(s2.slice(e4, e4 + 2), 16);
    }
    l2 && (o2[3] = Number.parseInt(l2, 16) / 255);
  } else if (s2 = e3.match(t2)) {
    for (s2 = s2[1], l2 = s2[3], c2 = 0; c2 < 3; c2++) o2[c2] = Number.parseInt(s2[c2] + s2[c2], 16);
    l2 && (o2[3] = Number.parseInt(l2 + l2, 16) / 255);
  } else if (s2 = e3.match(r2)) {
    for (c2 = 0; c2 < 3; c2++) o2[c2] = Number.parseFloat(s2[c2 + 1]);
    s2[4] && (o2[3] = s2[5] ? Number.parseFloat(s2[4]) * 0.01 : Number.parseFloat(s2[4]));
  } else if (s2 = e3.match(i2)) {
    for (c2 = 0; c2 < 3; c2++) o2[c2] = Math.round(Number.parseFloat(s2[c2 + 1]) * 2.55);
    s2[4] && (o2[3] = s2[5] ? Number.parseFloat(s2[4]) * 0.01 : Number.parseFloat(s2[4]));
  } else if (s2 = e3.toLowerCase().match(a2)) return s2[1] === `transparent` ? [0, 0, 0, 0] : Object.hasOwn(b, s2[1]) ? (o2 = b[s2[1]].slice(), o2[3] = 1, o2) : null;
  else return null;
  for (c2 = 0; c2 < 3; c2++) o2[c2] = C(o2[c2], 0, 255);
  return o2[3] = C(o2[3], 0, 1), o2;
}, S.get.hsl = function(e3) {
  if (!e3) return null;
  let t2 = e3.match(/^hsla?\(\s*([+-]?(?:\d{0,3}\.)?\d+)(?:deg)?\s*,?\s*([+-]?[\d.]+)%\s*,?\s*([+-]?[\d.]+)%\s*(?:[,|/]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:e[+-]?\d+)?)\s*)?\)$/i);
  if (t2) {
    let e4 = Number.parseFloat(t2[4]);
    return [(Number.parseFloat(t2[1]) % 360 + 360) % 360, C(Number.parseFloat(t2[2]), 0, 100), C(Number.parseFloat(t2[3]), 0, 100), C(Number.isNaN(e4) ? 1 : e4, 0, 1)];
  }
  return null;
}, S.get.hwb = function(e3) {
  if (!e3) return null;
  let t2 = e3.match(/^hwb\(\s*([+-]?\d{0,3}(?:\.\d+)?)(?:deg)?\s*[\s,]\s*([+-]?[\d.]+)%\s*[\s,]\s*([+-]?[\d.]+)%\s*(?:[\s,]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:e[+-]?\d+)?)\s*)?\)$/i);
  if (t2) {
    let e4 = Number.parseFloat(t2[4]);
    return [(Number.parseFloat(t2[1]) % 360 + 360) % 360, C(Number.parseFloat(t2[2]), 0, 100), C(Number.parseFloat(t2[3]), 0, 100), C(Number.isNaN(e4) ? 1 : e4, 0, 1)];
  }
  return null;
}, S.to.hex = function(...e3) {
  return `#` + w(e3[0]) + w(e3[1]) + w(e3[2]) + (e3[3] < 1 ? w(Math.round(e3[3] * 255)) : ``);
}, S.to.rgb = function(...e3) {
  return e3.length < 4 || e3[3] === 1 ? `rgb(` + Math.round(e3[0]) + `, ` + Math.round(e3[1]) + `, ` + Math.round(e3[2]) + `)` : `rgba(` + Math.round(e3[0]) + `, ` + Math.round(e3[1]) + `, ` + Math.round(e3[2]) + `, ` + e3[3] + `)`;
}, S.to.rgb.percent = function(...e3) {
  let t2 = Math.round(e3[0] / 255 * 100), n2 = Math.round(e3[1] / 255 * 100), r2 = Math.round(e3[2] / 255 * 100);
  return e3.length < 4 || e3[3] === 1 ? `rgb(` + t2 + `%, ` + n2 + `%, ` + r2 + `%)` : `rgba(` + t2 + `%, ` + n2 + `%, ` + r2 + `%, ` + e3[3] + `)`;
}, S.to.hsl = function(...e3) {
  return e3.length < 4 || e3[3] === 1 ? `hsl(` + e3[0] + `, ` + e3[1] + `%, ` + e3[2] + `%)` : `hsla(` + e3[0] + `, ` + e3[1] + `%, ` + e3[2] + `%, ` + e3[3] + `)`;
}, S.to.hwb = function(...e3) {
  let t2 = ``;
  return e3.length >= 4 && e3[3] !== 1 && (t2 = `, ` + e3[3]), `hwb(` + e3[0] + `, ` + e3[1] + `%, ` + e3[2] + `%` + t2 + `)`;
}, S.to.keyword = function(...e3) {
  return x[e3.slice(0, 3)];
};
function C(e3, t2, n2) {
  return Math.min(Math.max(t2, e3), n2);
}
function w(e3) {
  let t2 = Math.round(e3).toString(16).toUpperCase();
  return t2.length < 2 ? `0` + t2 : t2;
}
var T = {};
for (let e3 of Object.keys(b)) T[b[e3]] = e3;
var E = { rgb: { channels: 3, labels: `rgb` }, hsl: { channels: 3, labels: `hsl` }, hsv: { channels: 3, labels: `hsv` }, hwb: { channels: 3, labels: `hwb` }, cmyk: { channels: 4, labels: `cmyk` }, xyz: { channels: 3, labels: `xyz` }, lab: { channels: 3, labels: `lab` }, oklab: { channels: 3, labels: [`okl`, `oka`, `okb`] }, lch: { channels: 3, labels: `lch` }, oklch: { channels: 3, labels: [`okl`, `okc`, `okh`] }, hex: { channels: 1, labels: [`hex`] }, keyword: { channels: 1, labels: [`keyword`] }, ansi16: { channels: 1, labels: [`ansi16`] }, ansi256: { channels: 1, labels: [`ansi256`] }, hcg: { channels: 3, labels: [`h`, `c`, `g`] }, apple: { channels: 3, labels: [`r16`, `g16`, `b16`] }, gray: { channels: 1, labels: [`gray`] } }, D = (6 / 29) ** 3;
function O(e3) {
  let t2 = e3 > 31308e-7 ? 1.055 * e3 ** (1 / 2.4) - 0.055 : e3 * 12.92;
  return Math.min(Math.max(0, t2), 1);
}
function k(e3) {
  return e3 > 0.04045 ? ((e3 + 0.055) / 1.055) ** 2.4 : e3 / 12.92;
}
for (let e3 of Object.keys(E)) {
  if (!(`channels` in E[e3])) throw Error(`missing channels property: ` + e3);
  if (!(`labels` in E[e3])) throw Error(`missing channel labels property: ` + e3);
  if (E[e3].labels.length !== E[e3].channels) throw Error(`channel and label counts mismatch: ` + e3);
  let { channels: t2, labels: n2 } = E[e3];
  delete E[e3].channels, delete E[e3].labels, Object.defineProperty(E[e3], "channels", { value: t2 }), Object.defineProperty(E[e3], "labels", { value: n2 });
}
E.rgb.hsl = function(e3) {
  let t2 = e3[0] / 255, n2 = e3[1] / 255, r2 = e3[2] / 255, i2 = Math.min(t2, n2, r2), a2 = Math.max(t2, n2, r2), o2 = a2 - i2, s2, c2;
  switch (a2) {
    case i2:
      s2 = 0;
      break;
    case t2:
      s2 = (n2 - r2) / o2;
      break;
    case n2:
      s2 = 2 + (r2 - t2) / o2;
      break;
    case r2:
      s2 = 4 + (t2 - n2) / o2;
  }
  s2 = Math.min(s2 * 60, 360), s2 < 0 && (s2 += 360);
  let l2 = (i2 + a2) / 2;
  return c2 = a2 === i2 ? 0 : l2 <= 0.5 ? o2 / (a2 + i2) : o2 / (2 - a2 - i2), [s2, c2 * 100, l2 * 100];
}, E.rgb.hsv = function(e3) {
  let t2, n2, r2, i2, a2, o2 = e3[0] / 255, s2 = e3[1] / 255, c2 = e3[2] / 255, l2 = Math.max(o2, s2, c2), u2 = l2 - Math.min(o2, s2, c2), d2 = function(e4) {
    return (l2 - e4) / 6 / u2 + 1 / 2;
  };
  if (u2 === 0) i2 = 0, a2 = 0;
  else {
    switch (a2 = u2 / l2, t2 = d2(o2), n2 = d2(s2), r2 = d2(c2), l2) {
      case o2:
        i2 = r2 - n2;
        break;
      case s2:
        i2 = 1 / 3 + t2 - r2;
        break;
      case c2:
        i2 = 2 / 3 + n2 - t2;
    }
    i2 < 0 ? i2 += 1 : i2 > 1 && --i2;
  }
  return [i2 * 360, a2 * 100, l2 * 100];
}, E.rgb.hwb = function(e3) {
  let t2 = e3[0], n2 = e3[1], r2 = e3[2], i2 = E.rgb.hsl(e3)[0], a2 = 1 / 255 * Math.min(t2, Math.min(n2, r2));
  return r2 = 1 - 1 / 255 * Math.max(t2, Math.max(n2, r2)), [i2, a2 * 100, r2 * 100];
}, E.rgb.oklab = function(e3) {
  let t2 = k(e3[0] / 255), n2 = k(e3[1] / 255), r2 = k(e3[2] / 255), i2 = Math.cbrt(0.4122214708 * t2 + 0.5363325363 * n2 + 0.0514459929 * r2), a2 = Math.cbrt(0.2119034982 * t2 + 0.6806995451 * n2 + 0.1073969566 * r2), o2 = Math.cbrt(0.0883024619 * t2 + 0.2817188376 * n2 + 0.6299787005 * r2), s2 = 0.2104542553 * i2 + 0.793617785 * a2 - 0.0040720468 * o2, c2 = 1.9779984951 * i2 - 2.428592205 * a2 + 0.4505937099 * o2, l2 = 0.0259040371 * i2 + 0.7827717662 * a2 - 0.808675766 * o2;
  return [s2 * 100, c2 * 100, l2 * 100];
}, E.rgb.cmyk = function(e3) {
  let t2 = e3[0] / 255, n2 = e3[1] / 255, r2 = e3[2] / 255, i2 = Math.min(1 - t2, 1 - n2, 1 - r2), a2 = (1 - t2 - i2) / (1 - i2) || 0, o2 = (1 - n2 - i2) / (1 - i2) || 0, s2 = (1 - r2 - i2) / (1 - i2) || 0;
  return [a2 * 100, o2 * 100, s2 * 100, i2 * 100];
};
function A(e3, t2) {
  return (e3[0] - t2[0]) ** 2 + (e3[1] - t2[1]) ** 2 + (e3[2] - t2[2]) ** 2;
}
E.rgb.keyword = function(e3) {
  let t2 = T[e3];
  if (t2) return t2;
  let n2 = 1 / 0, r2;
  for (let t3 of Object.keys(b)) {
    let i2 = b[t3], a2 = A(e3, i2);
    a2 < n2 && (n2 = a2, r2 = t3);
  }
  return r2;
}, E.keyword.rgb = function(e3) {
  return [...b[e3]];
}, E.rgb.xyz = function(e3) {
  let t2 = k(e3[0] / 255), n2 = k(e3[1] / 255), r2 = k(e3[2] / 255), i2 = t2 * 0.4124564 + n2 * 0.3575761 + r2 * 0.1804375, a2 = t2 * 0.2126729 + n2 * 0.7151522 + r2 * 0.072175, o2 = t2 * 0.0193339 + n2 * 0.119192 + r2 * 0.9503041;
  return [i2 * 100, a2 * 100, o2 * 100];
}, E.rgb.lab = function(e3) {
  let t2 = E.rgb.xyz(e3), n2 = t2[0], r2 = t2[1], i2 = t2[2];
  return n2 /= 95.047, r2 /= 100, i2 /= 108.883, n2 = n2 > D ? n2 ** (1 / 3) : 7.787 * n2 + 16 / 116, r2 = r2 > D ? r2 ** (1 / 3) : 7.787 * r2 + 16 / 116, i2 = i2 > D ? i2 ** (1 / 3) : 7.787 * i2 + 16 / 116, [116 * r2 - 16, 500 * (n2 - r2), 200 * (r2 - i2)];
}, E.hsl.rgb = function(e3) {
  let t2 = e3[0] / 360, n2 = e3[1] / 100, r2 = e3[2] / 100, i2, a2;
  if (n2 === 0) return a2 = r2 * 255, [a2, a2, a2];
  let o2 = r2 < 0.5 ? r2 * (1 + n2) : r2 + n2 - r2 * n2, s2 = 2 * r2 - o2, c2 = [0, 0, 0];
  for (let e4 = 0; e4 < 3; e4++) i2 = t2 + 1 / 3 * -(e4 - 1), i2 < 0 && i2++, i2 > 1 && i2--, a2 = 6 * i2 < 1 ? s2 + (o2 - s2) * 6 * i2 : 2 * i2 < 1 ? o2 : 3 * i2 < 2 ? s2 + (o2 - s2) * (2 / 3 - i2) * 6 : s2, c2[e4] = a2 * 255;
  return c2;
}, E.hsl.hsv = function(e3) {
  let t2 = e3[0], n2 = e3[1] / 100, r2 = e3[2] / 100, i2 = n2, a2 = Math.max(r2, 0.01);
  r2 *= 2, n2 *= r2 <= 1 ? r2 : 2 - r2, i2 *= a2 <= 1 ? a2 : 2 - a2;
  let o2 = (r2 + n2) / 2;
  return [t2, (r2 === 0 ? 2 * i2 / (a2 + i2) : 2 * n2 / (r2 + n2)) * 100, o2 * 100];
}, E.hsv.rgb = function(e3) {
  let t2 = e3[0] / 60, n2 = e3[1] / 100, r2 = e3[2] / 100, i2 = Math.floor(t2) % 6, a2 = t2 - Math.floor(t2), o2 = 255 * r2 * (1 - n2), s2 = 255 * r2 * (1 - n2 * a2), c2 = 255 * r2 * (1 - n2 * (1 - a2));
  switch (r2 *= 255, i2) {
    case 0:
      return [r2, c2, o2];
    case 1:
      return [s2, r2, o2];
    case 2:
      return [o2, r2, c2];
    case 3:
      return [o2, s2, r2];
    case 4:
      return [c2, o2, r2];
    case 5:
      return [r2, o2, s2];
  }
}, E.hsv.hsl = function(e3) {
  let t2 = e3[0], n2 = e3[1] / 100, r2 = e3[2] / 100, i2 = Math.max(r2, 0.01), a2, o2;
  o2 = (2 - n2) * r2;
  let s2 = (2 - n2) * i2;
  return a2 = n2 * i2, a2 /= s2 <= 1 ? s2 : 2 - s2, a2 || (a2 = 0), o2 /= 2, [t2, a2 * 100, o2 * 100];
}, E.hwb.rgb = function(e3) {
  let t2 = e3[0] / 360, n2 = e3[1] / 100, r2 = e3[2] / 100, i2 = n2 + r2, a2;
  i2 > 1 && (n2 /= i2, r2 /= i2);
  let o2 = Math.floor(6 * t2), s2 = 1 - r2;
  a2 = 6 * t2 - o2, o2 & 1 && (a2 = 1 - a2);
  let c2 = n2 + a2 * (s2 - n2), l2, u2, d2;
  switch (o2) {
    default:
    case 6:
    case 0:
      l2 = s2, u2 = c2, d2 = n2;
      break;
    case 1:
      l2 = c2, u2 = s2, d2 = n2;
      break;
    case 2:
      l2 = n2, u2 = s2, d2 = c2;
      break;
    case 3:
      l2 = n2, u2 = c2, d2 = s2;
      break;
    case 4:
      l2 = c2, u2 = n2, d2 = s2;
      break;
    case 5:
      l2 = s2, u2 = n2, d2 = c2;
  }
  return [l2 * 255, u2 * 255, d2 * 255];
}, E.cmyk.rgb = function(e3) {
  let t2 = e3[0] / 100, n2 = e3[1] / 100, r2 = e3[2] / 100, i2 = e3[3] / 100, a2 = 1 - Math.min(1, t2 * (1 - i2) + i2), o2 = 1 - Math.min(1, n2 * (1 - i2) + i2), s2 = 1 - Math.min(1, r2 * (1 - i2) + i2);
  return [a2 * 255, o2 * 255, s2 * 255];
}, E.xyz.rgb = function(e3) {
  let t2 = e3[0] / 100, n2 = e3[1] / 100, r2 = e3[2] / 100, i2, a2, o2;
  return i2 = t2 * 3.2404542 + n2 * -1.5371385 + r2 * -0.4985314, a2 = t2 * -0.969266 + n2 * 1.8760108 + r2 * 0.041556, o2 = t2 * 0.0556434 + n2 * -0.2040259 + r2 * 1.0572252, i2 = O(i2), a2 = O(a2), o2 = O(o2), [i2 * 255, a2 * 255, o2 * 255];
}, E.xyz.lab = function(e3) {
  let t2 = e3[0], n2 = e3[1], r2 = e3[2];
  return t2 /= 95.047, n2 /= 100, r2 /= 108.883, t2 = t2 > D ? t2 ** (1 / 3) : 7.787 * t2 + 16 / 116, n2 = n2 > D ? n2 ** (1 / 3) : 7.787 * n2 + 16 / 116, r2 = r2 > D ? r2 ** (1 / 3) : 7.787 * r2 + 16 / 116, [116 * n2 - 16, 500 * (t2 - n2), 200 * (n2 - r2)];
}, E.xyz.oklab = function(e3) {
  let t2 = e3[0] / 100, n2 = e3[1] / 100, r2 = e3[2] / 100, i2 = Math.cbrt(0.8189330101 * t2 + 0.3618667424 * n2 - 0.1288597137 * r2), a2 = Math.cbrt(0.0329845436 * t2 + 0.9293118715 * n2 + 0.0361456387 * r2), o2 = Math.cbrt(0.0482003018 * t2 + 0.2643662691 * n2 + 0.633851707 * r2), s2 = 0.2104542553 * i2 + 0.793617785 * a2 - 0.0040720468 * o2, c2 = 1.9779984951 * i2 - 2.428592205 * a2 + 0.4505937099 * o2, l2 = 0.0259040371 * i2 + 0.7827717662 * a2 - 0.808675766 * o2;
  return [s2 * 100, c2 * 100, l2 * 100];
}, E.oklab.oklch = function(e3) {
  return E.lab.lch(e3);
}, E.oklab.xyz = function(e3) {
  let t2 = e3[0] / 100, n2 = e3[1] / 100, r2 = e3[2] / 100, i2 = (0.999999998 * t2 + 0.396337792 * n2 + 0.215803758 * r2) ** 3, a2 = (1.000000008 * t2 - 0.105561342 * n2 - 0.063854175 * r2) ** 3, o2 = (1.000000055 * t2 - 0.089484182 * n2 - 1.291485538 * r2) ** 3, s2 = 1.227013851 * i2 - 0.55779998 * a2 + 0.281256149 * o2, c2 = -0.040580178 * i2 + 1.11225687 * a2 - 0.071676679 * o2, l2 = -0.076381285 * i2 - 0.421481978 * a2 + 1.58616322 * o2;
  return [s2 * 100, c2 * 100, l2 * 100];
}, E.oklab.rgb = function(e3) {
  let t2 = e3[0] / 100, n2 = e3[1] / 100, r2 = e3[2] / 100, i2 = (t2 + 0.3963377774 * n2 + 0.2158037573 * r2) ** 3, a2 = (t2 - 0.1055613458 * n2 - 0.0638541728 * r2) ** 3, o2 = (t2 - 0.0894841775 * n2 - 1.291485548 * r2) ** 3, s2 = O(4.0767416621 * i2 - 3.3077115913 * a2 + 0.2309699292 * o2), c2 = O(-1.2684380046 * i2 + 2.6097574011 * a2 - 0.3413193965 * o2), l2 = O(-0.0041960863 * i2 - 0.7034186147 * a2 + 1.707614701 * o2);
  return [s2 * 255, c2 * 255, l2 * 255];
}, E.oklch.oklab = function(e3) {
  return E.lch.lab(e3);
}, E.lab.xyz = function(e3) {
  let t2 = e3[0], n2 = e3[1], r2 = e3[2], i2, a2, o2;
  a2 = (t2 + 16) / 116, i2 = n2 / 500 + a2, o2 = a2 - r2 / 200;
  let s2 = a2 ** 3, c2 = i2 ** 3, l2 = o2 ** 3;
  return a2 = s2 > D ? s2 : (a2 - 16 / 116) / 7.787, i2 = c2 > D ? c2 : (i2 - 16 / 116) / 7.787, o2 = l2 > D ? l2 : (o2 - 16 / 116) / 7.787, i2 *= 95.047, a2 *= 100, o2 *= 108.883, [i2, a2, o2];
}, E.lab.lch = function(e3) {
  let t2 = e3[0], n2 = e3[1], r2 = e3[2], i2;
  return i2 = Math.atan2(r2, n2) * 360 / 2 / Math.PI, i2 < 0 && (i2 += 360), [t2, Math.sqrt(n2 * n2 + r2 * r2), i2];
}, E.lch.lab = function(e3) {
  let t2 = e3[0], n2 = e3[1], r2 = e3[2] / 360 * 2 * Math.PI;
  return [t2, n2 * Math.cos(r2), n2 * Math.sin(r2)];
}, E.rgb.ansi16 = function(e3, t2 = null) {
  let [n2, r2, i2] = e3, a2 = t2 === null ? E.rgb.hsv(e3)[2] : t2;
  if (a2 = Math.round(a2 / 50), a2 === 0) return 30;
  let o2 = 30 + (Math.round(i2 / 255) << 2 | Math.round(r2 / 255) << 1 | Math.round(n2 / 255));
  return a2 === 2 && (o2 += 60), o2;
}, E.hsv.ansi16 = function(e3) {
  return E.rgb.ansi16(E.hsv.rgb(e3), e3[2]);
}, E.rgb.ansi256 = function(e3) {
  let t2 = e3[0], n2 = e3[1], r2 = e3[2];
  return t2 >> 4 == n2 >> 4 && n2 >> 4 == r2 >> 4 ? t2 < 8 ? 16 : t2 > 248 ? 231 : Math.round((t2 - 8) / 247 * 24) + 232 : 16 + 36 * Math.round(t2 / 255 * 5) + 6 * Math.round(n2 / 255 * 5) + Math.round(r2 / 255 * 5);
}, E.ansi16.rgb = function(e3) {
  e3 = e3[0];
  let t2 = e3 % 10;
  if (t2 === 0 || t2 === 7) return e3 > 50 && (t2 += 3.5), t2 = t2 / 10.5 * 255, [t2, t2, t2];
  let n2 = (Math.trunc(e3 > 50) + 1) * 0.5;
  return [(t2 & 1) * n2 * 255, (t2 >> 1 & 1) * n2 * 255, (t2 >> 2 & 1) * n2 * 255];
}, E.ansi256.rgb = function(e3) {
  if (e3 = e3[0], e3 >= 232) {
    let t3 = (e3 - 232) * 10 + 8;
    return [t3, t3, t3];
  }
  e3 -= 16;
  let t2;
  return [Math.floor(e3 / 36) / 5 * 255, Math.floor((t2 = e3 % 36) / 6) / 5 * 255, t2 % 6 / 5 * 255];
}, E.rgb.hex = function(e3) {
  let t2 = (((Math.round(e3[0]) & 255) << 16) + ((Math.round(e3[1]) & 255) << 8) + (Math.round(e3[2]) & 255)).toString(16).toUpperCase();
  return `000000`.slice(t2.length) + t2;
}, E.hex.rgb = function(e3) {
  let t2 = e3.toString(16).match(/[a-f\d]{6}|[a-f\d]{3}/i);
  if (!t2) return [0, 0, 0];
  let n2 = t2[0];
  t2[0].length === 3 && (n2 = [...n2].map((e4) => e4 + e4).join(``));
  let r2 = Number.parseInt(n2, 16);
  return [r2 >> 16 & 255, r2 >> 8 & 255, r2 & 255];
}, E.rgb.hcg = function(e3) {
  let t2 = e3[0] / 255, n2 = e3[1] / 255, r2 = e3[2] / 255, i2 = Math.max(Math.max(t2, n2), r2), a2 = Math.min(Math.min(t2, n2), r2), o2 = i2 - a2, s2, c2 = o2 < 1 ? a2 / (1 - o2) : 0;
  return s2 = o2 <= 0 ? 0 : i2 === t2 ? (n2 - r2) / o2 % 6 : i2 === n2 ? 2 + (r2 - t2) / o2 : 4 + (t2 - n2) / o2, s2 /= 6, s2 %= 1, [s2 * 360, o2 * 100, c2 * 100];
}, E.hsl.hcg = function(e3) {
  let t2 = e3[1] / 100, n2 = e3[2] / 100, r2 = n2 < 0.5 ? 2 * t2 * n2 : 2 * t2 * (1 - n2), i2 = 0;
  return r2 < 1 && (i2 = (n2 - 0.5 * r2) / (1 - r2)), [e3[0], r2 * 100, i2 * 100];
}, E.hsv.hcg = function(e3) {
  let t2 = e3[1] / 100, n2 = e3[2] / 100, r2 = t2 * n2, i2 = 0;
  return r2 < 1 && (i2 = (n2 - r2) / (1 - r2)), [e3[0], r2 * 100, i2 * 100];
}, E.hcg.rgb = function(e3) {
  let t2 = e3[0] / 360, n2 = e3[1] / 100, r2 = e3[2] / 100;
  if (n2 === 0) return [r2 * 255, r2 * 255, r2 * 255];
  let i2 = [0, 0, 0], a2 = t2 % 1 * 6, o2 = a2 % 1, s2 = 1 - o2, c2 = 0;
  switch (Math.floor(a2)) {
    case 0:
      i2[0] = 1, i2[1] = o2, i2[2] = 0;
      break;
    case 1:
      i2[0] = s2, i2[1] = 1, i2[2] = 0;
      break;
    case 2:
      i2[0] = 0, i2[1] = 1, i2[2] = o2;
      break;
    case 3:
      i2[0] = 0, i2[1] = s2, i2[2] = 1;
      break;
    case 4:
      i2[0] = o2, i2[1] = 0, i2[2] = 1;
      break;
    default:
      i2[0] = 1, i2[1] = 0, i2[2] = s2;
  }
  return c2 = (1 - n2) * r2, [(n2 * i2[0] + c2) * 255, (n2 * i2[1] + c2) * 255, (n2 * i2[2] + c2) * 255];
}, E.hcg.hsv = function(e3) {
  let t2 = e3[1] / 100, n2 = t2 + e3[2] / 100 * (1 - t2), r2 = 0;
  return n2 > 0 && (r2 = t2 / n2), [e3[0], r2 * 100, n2 * 100];
}, E.hcg.hsl = function(e3) {
  let t2 = e3[1] / 100, n2 = e3[2] / 100 * (1 - t2) + 0.5 * t2, r2 = 0;
  return n2 > 0 && n2 < 0.5 ? r2 = t2 / (2 * n2) : n2 >= 0.5 && n2 < 1 && (r2 = t2 / (2 * (1 - n2))), [e3[0], r2 * 100, n2 * 100];
}, E.hcg.hwb = function(e3) {
  let t2 = e3[1] / 100, n2 = t2 + e3[2] / 100 * (1 - t2);
  return [e3[0], (n2 - t2) * 100, (1 - n2) * 100];
}, E.hwb.hcg = function(e3) {
  let t2 = e3[1] / 100, n2 = 1 - e3[2] / 100, r2 = n2 - t2, i2 = 0;
  return r2 < 1 && (i2 = (n2 - r2) / (1 - r2)), [e3[0], r2 * 100, i2 * 100];
}, E.apple.rgb = function(e3) {
  return [e3[0] / 65535 * 255, e3[1] / 65535 * 255, e3[2] / 65535 * 255];
}, E.rgb.apple = function(e3) {
  return [e3[0] / 255 * 65535, e3[1] / 255 * 65535, e3[2] / 255 * 65535];
}, E.gray.rgb = function(e3) {
  return [e3[0] / 100 * 255, e3[0] / 100 * 255, e3[0] / 100 * 255];
}, E.gray.hsl = function(e3) {
  return [0, 0, e3[0]];
}, E.gray.hsv = E.gray.hsl, E.gray.hwb = function(e3) {
  return [0, 100, e3[0]];
}, E.gray.cmyk = function(e3) {
  return [0, 0, 0, e3[0]];
}, E.gray.lab = function(e3) {
  return [e3[0], 0, 0];
}, E.gray.hex = function(e3) {
  let t2 = Math.round(e3[0] / 100 * 255) & 255, n2 = ((t2 << 16) + (t2 << 8) + t2).toString(16).toUpperCase();
  return `000000`.slice(n2.length) + n2;
}, E.rgb.gray = function(e3) {
  return [(e3[0] + e3[1] + e3[2]) / 3 / 255 * 100];
};
function j() {
  let e3 = {}, t2 = Object.keys(E);
  for (let { length: n2 } = t2, r2 = 0; r2 < n2; r2++) e3[t2[r2]] = { distance: -1, parent: null };
  return e3;
}
function M(e3) {
  let t2 = j(), n2 = [e3];
  for (t2[e3].distance = 0; n2.length > 0; ) {
    let e4 = n2.pop(), r2 = Object.keys(E[e4]);
    for (let { length: i2 } = r2, a2 = 0; a2 < i2; a2++) {
      let i3 = r2[a2], o2 = t2[i3];
      o2.distance === -1 && (o2.distance = t2[e4].distance + 1, o2.parent = e4, n2.unshift(i3));
    }
  }
  return t2;
}
function N(e3, t2) {
  return function(n2) {
    return t2(e3(n2));
  };
}
function P(e3, t2) {
  let n2 = [t2[e3].parent, e3], r2 = E[t2[e3].parent][e3], i2 = t2[e3].parent;
  for (; t2[i2].parent; ) n2.unshift(t2[i2].parent), r2 = N(E[t2[i2].parent][i2], r2), i2 = t2[i2].parent;
  return r2.conversion = n2, r2;
}
function F(e3) {
  let t2 = M(e3), n2 = {}, r2 = Object.keys(t2);
  for (let { length: e4 } = r2, i2 = 0; i2 < e4; i2++) {
    let e5 = r2[i2];
    t2[e5].parent !== null && (n2[e5] = P(e5, t2));
  }
  return n2;
}
var I = {}, L = Object.keys(E);
function R(e3) {
  let t2 = function(...t3) {
    let n2 = t3[0];
    return n2 == null ? n2 : (n2.length > 1 && (t3 = n2), e3(t3));
  };
  return `conversion` in e3 && (t2.conversion = e3.conversion), t2;
}
function z(e3) {
  let t2 = function(...t3) {
    let n2 = t3[0];
    if (n2 == null) return n2;
    n2.length > 1 && (t3 = n2);
    let r2 = e3(t3);
    if (typeof r2 == `object`) for (let { length: e4 } = r2, t4 = 0; t4 < e4; t4++) r2[t4] = Math.round(r2[t4]);
    return r2;
  };
  return `conversion` in e3 && (t2.conversion = e3.conversion), t2;
}
for (let e3 of L) {
  I[e3] = {}, Object.defineProperty(I[e3], "channels", { value: E[e3].channels }), Object.defineProperty(I[e3], "labels", { value: E[e3].labels });
  let t2 = F(e3), n2 = Object.keys(t2);
  for (let r2 of n2) {
    let n3 = t2[r2];
    I[e3][r2] = z(n3), I[e3][r2].raw = R(n3);
  }
}
var B = [`keyword`, `gray`, `hex`], V = {};
for (let e3 of Object.keys(I)) V[[...I[e3].labels].sort().join(``)] = e3;
var H = {};
function U(e3, t2) {
  if (!(this instanceof U)) return new U(e3, t2);
  if (t2 && t2 in B && (t2 = null), t2 && !(t2 in I)) throw Error(`Unknown model: ` + t2);
  let n2, r2;
  if (e3 == null) this.model = `rgb`, this.color = [0, 0, 0], this.valpha = 1;
  else if (e3 instanceof U) this.model = e3.model, this.color = [...e3.color], this.valpha = e3.valpha;
  else if (typeof e3 == `string`) {
    let t3 = S.get(e3);
    if (t3 === null) throw Error(`Unable to parse color from string: ` + e3);
    this.model = t3.model, r2 = I[this.model].channels, this.color = t3.value.slice(0, r2), this.valpha = typeof t3.value[r2] == `number` ? t3.value[r2] : 1;
  } else if (e3.length > 0) {
    this.model = t2 || `rgb`, r2 = I[this.model].channels;
    let n3 = Array.prototype.slice.call(e3, 0, r2);
    this.color = K(n3, r2), this.valpha = typeof e3[r2] == `number` ? e3[r2] : 1;
  } else if (typeof e3 == `number`) this.model = `rgb`, this.color = [e3 >> 16 & 255, e3 >> 8 & 255, e3 & 255], this.valpha = 1;
  else {
    this.valpha = 1;
    let t3 = Object.keys(e3);
    `alpha` in e3 && (t3.splice(t3.indexOf(`alpha`), 1), this.valpha = typeof e3.alpha == `number` ? e3.alpha : 0);
    let r3 = t3.sort().join(``);
    if (!(r3 in V)) throw Error(`Unable to parse color from object: ` + JSON.stringify(e3));
    this.model = V[r3];
    let { labels: i2 } = I[this.model], a2 = [];
    for (n2 = 0; n2 < i2.length; n2++) a2.push(e3[i2[n2]]);
    this.color = K(a2);
  }
  if (H[this.model]) for (r2 = I[this.model].channels, n2 = 0; n2 < r2; n2++) {
    let e4 = H[this.model][n2];
    e4 && (this.color[n2] = e4(this.color[n2]));
  }
  this.valpha = Math.max(0, Math.min(1, this.valpha)), Object.freeze && Object.freeze(this);
}
U.prototype = { toString() {
  return this.string();
}, toJSON() {
  return this[this.model]();
}, string(e3) {
  let t2 = this.model in S.to ? this : this.rgb();
  t2 = t2.round(typeof e3 == `number` ? e3 : 1);
  let n2 = t2.valpha === 1 ? t2.color : [...t2.color, this.valpha];
  return S.to[t2.model](...n2);
}, percentString(e3) {
  let t2 = this.rgb().round(typeof e3 == `number` ? e3 : 1), n2 = t2.valpha === 1 ? t2.color : [...t2.color, this.valpha];
  return S.to.rgb.percent(...n2);
}, array() {
  return this.valpha === 1 ? [...this.color] : [...this.color, this.valpha];
}, object() {
  let e3 = {}, { channels: t2 } = I[this.model], { labels: n2 } = I[this.model];
  for (let r2 = 0; r2 < t2; r2++) e3[n2[r2]] = this.color[r2];
  return this.valpha !== 1 && (e3.alpha = this.valpha), e3;
}, unitArray() {
  let e3 = this.rgb().color;
  return e3[0] /= 255, e3[1] /= 255, e3[2] /= 255, this.valpha !== 1 && e3.push(this.valpha), e3;
}, unitObject() {
  let e3 = this.rgb().object();
  return e3.r /= 255, e3.g /= 255, e3.b /= 255, this.valpha !== 1 && (e3.alpha = this.valpha), e3;
}, round(e3) {
  return e3 = Math.max(e3 || 0, 0), new U([...this.color.map(te(e3)), this.valpha], this.model);
}, alpha(e3) {
  return e3 === void 0 ? this.valpha : new U([...this.color, Math.max(0, Math.min(1, e3))], this.model);
}, red: W(`rgb`, 0, G(255)), green: W(`rgb`, 1, G(255)), blue: W(`rgb`, 2, G(255)), hue: W([`hsl`, `hsv`, `hsl`, `hwb`, `hcg`], 0, (e3) => (e3 % 360 + 360) % 360), saturationl: W(`hsl`, 1, G(100)), lightness: W(`hsl`, 2, G(100)), saturationv: W(`hsv`, 1, G(100)), value: W(`hsv`, 2, G(100)), chroma: W(`hcg`, 1, G(100)), gray: W(`hcg`, 2, G(100)), white: W(`hwb`, 1, G(100)), wblack: W(`hwb`, 2, G(100)), cyan: W(`cmyk`, 0, G(100)), magenta: W(`cmyk`, 1, G(100)), yellow: W(`cmyk`, 2, G(100)), black: W(`cmyk`, 3, G(100)), x: W(`xyz`, 0, G(95.047)), y: W(`xyz`, 1, G(100)), z: W(`xyz`, 2, G(108.833)), l: W(`lab`, 0, G(100)), a: W(`lab`, 1), b: W(`lab`, 2), keyword(e3) {
  return e3 === void 0 ? I[this.model].keyword(this.color) : new U(e3);
}, hex(e3) {
  return e3 === void 0 ? S.to.hex(...this.rgb().round().color) : new U(e3);
}, hexa(e3) {
  if (e3 !== void 0) return new U(e3);
  let t2 = this.rgb().round().color, n2 = Math.round(this.valpha * 255).toString(16).toUpperCase();
  return n2.length === 1 && (n2 = `0` + n2), S.to.hex(...t2) + n2;
}, rgbNumber() {
  let e3 = this.rgb().color;
  return (e3[0] & 255) << 16 | (e3[1] & 255) << 8 | e3[2] & 255;
}, luminosity() {
  let e3 = this.rgb().color, t2 = [];
  for (let [n2, r2] of e3.entries()) {
    let e4 = r2 / 255;
    t2[n2] = e4 <= 0.04045 ? e4 / 12.92 : ((e4 + 0.055) / 1.055) ** 2.4;
  }
  return 0.2126 * t2[0] + 0.7152 * t2[1] + 0.0722 * t2[2];
}, contrast(e3) {
  let t2 = this.luminosity(), n2 = e3.luminosity();
  return t2 > n2 ? (t2 + 0.05) / (n2 + 0.05) : (n2 + 0.05) / (t2 + 0.05);
}, level(e3) {
  let t2 = this.contrast(e3);
  return t2 >= 7 ? `AAA` : t2 >= 4.5 ? `AA` : ``;
}, isDark() {
  let e3 = this.rgb().color;
  return (e3[0] * 2126 + e3[1] * 7152 + e3[2] * 722) / 1e4 < 128;
}, isLight() {
  return !this.isDark();
}, negate() {
  let e3 = this.rgb();
  for (let t2 = 0; t2 < 3; t2++) e3.color[t2] = 255 - e3.color[t2];
  return e3;
}, lighten(e3) {
  let t2 = this.hsl();
  return t2.color[2] += t2.color[2] * e3, t2;
}, darken(e3) {
  let t2 = this.hsl();
  return t2.color[2] -= t2.color[2] * e3, t2;
}, saturate(e3) {
  let t2 = this.hsl();
  return t2.color[1] += t2.color[1] * e3, t2;
}, desaturate(e3) {
  let t2 = this.hsl();
  return t2.color[1] -= t2.color[1] * e3, t2;
}, whiten(e3) {
  let t2 = this.hwb();
  return t2.color[1] += t2.color[1] * e3, t2;
}, blacken(e3) {
  let t2 = this.hwb();
  return t2.color[2] += t2.color[2] * e3, t2;
}, grayscale() {
  let e3 = this.rgb().color, t2 = e3[0] * 0.3 + e3[1] * 0.59 + e3[2] * 0.11;
  return U.rgb(t2, t2, t2);
}, fade(e3) {
  return this.alpha(this.valpha - this.valpha * e3);
}, opaquer(e3) {
  return this.alpha(this.valpha + this.valpha * e3);
}, rotate(e3) {
  let t2 = this.hsl(), n2 = t2.color[0];
  return n2 = (n2 + e3) % 360, n2 = n2 < 0 ? 360 + n2 : n2, t2.color[0] = n2, t2;
}, mix(e3, t2) {
  if (!e3 || !e3.rgb) throw Error(`Argument to "mix" was not a Color instance, but rather an instance of ` + typeof e3);
  let n2 = e3.rgb(), r2 = this.rgb(), i2 = t2 === void 0 ? 0.5 : t2, a2 = 2 * i2 - 1, o2 = n2.alpha() - r2.alpha(), s2 = ((a2 * o2 === -1 ? a2 : (a2 + o2) / (1 + a2 * o2)) + 1) / 2, c2 = 1 - s2;
  return U.rgb(s2 * n2.red() + c2 * r2.red(), s2 * n2.green() + c2 * r2.green(), s2 * n2.blue() + c2 * r2.blue(), n2.alpha() * i2 + r2.alpha() * (1 - i2));
} };
for (let e3 of Object.keys(I)) {
  if (B.includes(e3)) continue;
  let { channels: t2 } = I[e3];
  U.prototype[e3] = function(...t3) {
    return this.model === e3 ? new U(this) : t3.length > 0 ? new U(t3, e3) : new U([...ne(I[this.model][e3].raw(this.color)), this.valpha], e3);
  }, U[e3] = function(...n2) {
    let r2 = n2[0];
    return typeof r2 == `number` && (r2 = K(n2, t2)), new U(r2, e3);
  };
}
function ee(e3, t2) {
  return Number(e3.toFixed(t2));
}
function te(e3) {
  return function(t2) {
    return ee(t2, e3);
  };
}
function W(e3, t2, n2) {
  e3 = Array.isArray(e3) ? e3 : [e3];
  for (let r2 of e3) (H[r2] || (H[r2] = []))[t2] = n2;
  return e3 = e3[0], function(r2) {
    let i2;
    return r2 === void 0 ? (i2 = this[e3]().color[t2], n2 && (i2 = n2(i2)), i2) : (n2 && (r2 = n2(r2)), i2 = this[e3](), i2.color[t2] = r2, i2);
  };
}
function G(e3) {
  return function(t2) {
    return Math.max(0, Math.min(e3, t2));
  };
}
function ne(e3) {
  return Array.isArray(e3) ? e3 : [e3];
}
function K(e3, t2) {
  for (let n2 = 0; n2 < t2; n2++) typeof e3[n2] != `number` && (e3[n2] = 0);
  return e3;
}
function q() {
  return q = Object.assign ? Object.assign.bind() : function(e3) {
    for (var t2 = 1; t2 < arguments.length; t2++) {
      var n2 = arguments[t2];
      for (var r2 in n2) ({}).hasOwnProperty.call(n2, r2) && (e3[r2] = n2[r2]);
    }
    return e3;
  }, q.apply(null, arguments);
}
var J = function(e3, t2) {
  return e3 < t2 ? -1 : +(e3 > t2);
}, Y = function(e3) {
  return e3.reduce(function(e4, t2) {
    return e4 + t2;
  }, 0);
}, re = (function() {
  function e3(e4) {
    this.colors = e4;
  }
  var t2 = e3.prototype;
  return t2.palette = function() {
    return this.colors;
  }, t2.map = function(e4) {
    return e4;
  }, e3;
})(), ie = (function() {
  function e3(e4, t3, n3) {
    return (e4 << 10) + (t3 << 5) + n3;
  }
  function t2(e4) {
    var t3 = [], n3 = false;
    function r3() {
      t3.sort(e4), n3 = true;
    }
    return { push: function(e5) {
      t3.push(e5), n3 = false;
    }, peek: function(e5) {
      return n3 || r3(), e5 === void 0 && (e5 = t3.length - 1), t3[e5];
    }, pop: function() {
      return n3 || r3(), t3.pop();
    }, size: function() {
      return t3.length;
    }, map: function(e5) {
      return t3.map(e5);
    }, debug: function() {
      return n3 || r3(), t3;
    } };
  }
  function n2(e4, t3, n3, r3, i3, a2, o2) {
    var s2 = this;
    s2.r1 = e4, s2.r2 = t3, s2.g1 = n3, s2.g2 = r3, s2.b1 = i3, s2.b2 = a2, s2.histo = o2;
  }
  function r2() {
    this.vboxes = new t2(function(e4, t3) {
      return J(e4.vbox.count() * e4.vbox.volume(), t3.vbox.count() * t3.vbox.volume());
    });
  }
  function i2(t3, n3) {
    if (n3.count()) {
      var r3 = n3.r2 - n3.r1 + 1, i3 = n3.g2 - n3.g1 + 1, a2 = Math.max.apply(null, [r3, i3, n3.b2 - n3.b1 + 1]);
      if (n3.count() == 1) return [n3.copy()];
      var o2, s2, c2, l2, u2 = 0, d2 = [], f2 = [];
      if (a2 == r3) for (o2 = n3.r1; o2 <= n3.r2; o2++) {
        for (l2 = 0, s2 = n3.g1; s2 <= n3.g2; s2++) for (c2 = n3.b1; c2 <= n3.b2; c2++) l2 += t3[e3(o2, s2, c2)] || 0;
        d2[o2] = u2 += l2;
      }
      else if (a2 == i3) for (o2 = n3.g1; o2 <= n3.g2; o2++) {
        for (l2 = 0, s2 = n3.r1; s2 <= n3.r2; s2++) for (c2 = n3.b1; c2 <= n3.b2; c2++) l2 += t3[e3(s2, o2, c2)] || 0;
        d2[o2] = u2 += l2;
      }
      else for (o2 = n3.b1; o2 <= n3.b2; o2++) {
        for (l2 = 0, s2 = n3.r1; s2 <= n3.r2; s2++) for (c2 = n3.g1; c2 <= n3.g2; c2++) l2 += t3[e3(s2, c2, o2)] || 0;
        d2[o2] = u2 += l2;
      }
      return d2.forEach(function(e4, t4) {
        f2[t4] = u2 - e4;
      }), (function(e4) {
        var t4, r4, i4, a3, s3, c3 = e4 + `1`, l3 = e4 + `2`, p2 = 0;
        for (o2 = n3[c3]; o2 <= n3[l3]; o2++) if (d2[o2] > u2 / 2) {
          for (i4 = n3.copy(), a3 = n3.copy(), s3 = (t4 = o2 - n3[c3]) <= (r4 = n3[l3] - o2) ? Math.min(n3[l3] - 1, ~~(o2 + r4 / 2)) : Math.max(n3[c3], ~~(o2 - 1 - t4 / 2)); !d2[s3]; ) s3++;
          for (p2 = f2[s3]; !p2 && d2[s3 - 1]; ) p2 = f2[--s3];
          return i4[l3] = s3, a3[c3] = i4[l3] + 1, [i4, a3];
        }
      })(a2 == r3 ? `r` : a2 == i3 ? `g` : `b`);
    }
  }
  return n2.prototype = { volume: function(e4) {
    var t3 = this;
    return t3._volume && !e4 || (t3._volume = (t3.r2 - t3.r1 + 1) * (t3.g2 - t3.g1 + 1) * (t3.b2 - t3.b1 + 1)), t3._volume;
  }, count: function(t3) {
    var n3 = this, r3 = n3.histo;
    if (!n3._count_set || t3) {
      var i3, a2, o2, s2 = 0;
      for (i3 = n3.r1; i3 <= n3.r2; i3++) for (a2 = n3.g1; a2 <= n3.g2; a2++) for (o2 = n3.b1; o2 <= n3.b2; o2++) s2 += r3[e3(i3, a2, o2)] || 0;
      n3._count = s2, n3._count_set = true;
    }
    return n3._count;
  }, copy: function() {
    var e4 = this;
    return new n2(e4.r1, e4.r2, e4.g1, e4.g2, e4.b1, e4.b2, e4.histo);
  }, avg: function(t3) {
    var n3 = this, r3 = n3.histo;
    if (!n3._avg || t3) {
      var i3, a2, o2, s2, c2 = 0, l2 = 0, u2 = 0, d2 = 0;
      if (n3.r1 === n3.r2 && n3.g1 === n3.g2 && n3.b1 === n3.b2) n3._avg = [n3.r1 << 3, n3.g1 << 3, n3.b1 << 3];
      else {
        for (a2 = n3.r1; a2 <= n3.r2; a2++) for (o2 = n3.g1; o2 <= n3.g2; o2++) for (s2 = n3.b1; s2 <= n3.b2; s2++) c2 += i3 = r3[e3(a2, o2, s2)] || 0, l2 += i3 * (a2 + 0.5) * 8, u2 += i3 * (o2 + 0.5) * 8, d2 += i3 * (s2 + 0.5) * 8;
        n3._avg = c2 ? [~~(l2 / c2), ~~(u2 / c2), ~~(d2 / c2)] : [~~(8 * (n3.r1 + n3.r2 + 1) / 2), ~~(8 * (n3.g1 + n3.g2 + 1) / 2), ~~(8 * (n3.b1 + n3.b2 + 1) / 2)];
      }
    }
    return n3._avg;
  }, contains: function(e4) {
    var t3 = this, n3 = e4[0] >> 3;
    return gval = e4[1] >> 3, bval = e4[2] >> 3, n3 >= t3.r1 && n3 <= t3.r2 && gval >= t3.g1 && gval <= t3.g2 && bval >= t3.b1 && bval <= t3.b2;
  } }, r2.prototype = { push: function(e4) {
    this.vboxes.push({ vbox: e4, color: e4.avg() });
  }, palette: function() {
    return this.vboxes.map(function(e4) {
      return e4.color;
    });
  }, size: function() {
    return this.vboxes.size();
  }, map: function(e4) {
    for (var t3 = this.vboxes, n3 = 0; n3 < t3.size(); n3++) if (t3.peek(n3).vbox.contains(e4)) return t3.peek(n3).color;
    return this.nearest(e4);
  }, nearest: function(e4) {
    for (var t3, n3, r3, i3 = this.vboxes, a2 = 0; a2 < i3.size(); a2++) ((n3 = Math.sqrt((e4[0] - i3.peek(a2).color[0]) ** 2 + (e4[1] - i3.peek(a2).color[1]) ** 2 + (e4[2] - i3.peek(a2).color[2]) ** 2)) < t3 || t3 === void 0) && (t3 = n3, r3 = i3.peek(a2).color);
    return r3;
  }, forcebw: function() {
    var e4 = this.vboxes;
    e4.sort(function(e5, t4) {
      return J(Y(e5.color), Y(t4.color));
    });
    var t3 = e4[0].color;
    t3[0] < 5 && t3[1] < 5 && t3[2] < 5 && (e4[0].color = [0, 0, 0]);
    var n3 = e4.length - 1, r3 = e4[n3].color;
    r3[0] > 251 && r3[1] > 251 && r3[2] > 251 && (e4[n3].color = [255, 255, 255]);
  } }, { quantize: function(a2, o2) {
    if (!Number.isInteger(o2) || o2 < 1 || o2 > 256) throw Error(`Invalid maximum color count. It must be an integer between 1 and 256.`);
    if (!a2.length || o2 < 2 || o2 > 256 || !a2.length || o2 < 2 || o2 > 256) return false;
    for (var s2 = [], c2 = /* @__PURE__ */ new Set(), l2 = 0; l2 < a2.length; l2++) {
      var u2 = a2[l2], d2 = u2.join(`,`);
      c2.has(d2) || (c2.add(d2), s2.push(u2));
    }
    if (s2.length <= o2) return new re(s2);
    var f2 = (function(t3) {
      var n3, r3 = Array(32768);
      return t3.forEach(function(t4) {
        n3 = e3(t4[0] >> 3, t4[1] >> 3, t4[2] >> 3), r3[n3] = (r3[n3] || 0) + 1;
      }), r3;
    })(a2);
    f2.forEach(function() {
    });
    var p2 = (function(e4, t3) {
      var r3, i3, a3, o3 = 1e6, s3 = 0, c3 = 1e6, l3 = 0, u3 = 1e6, d3 = 0;
      return e4.forEach(function(e5) {
        (r3 = e5[0] >> 3) < o3 ? o3 = r3 : r3 > s3 && (s3 = r3), (i3 = e5[1] >> 3) < c3 ? c3 = i3 : i3 > l3 && (l3 = i3), (a3 = e5[2] >> 3) < u3 ? u3 = a3 : a3 > d3 && (d3 = a3);
      }), new n2(o3, s3, c3, l3, u3, d3, t3);
    })(a2, f2), m2 = new t2(function(e4, t3) {
      return J(e4.count(), t3.count());
    });
    function h2(e4, t3) {
      for (var n3, r3 = e4.size(), a3 = 0; a3 < 1e3; ) {
        if (r3 >= t3 || a3++ > 1e3) return;
        if ((n3 = e4.pop()).count()) {
          var o3 = i2(f2, n3), s3 = o3[0], c3 = o3[1];
          if (!s3) return;
          e4.push(s3), c3 && (e4.push(c3), r3++);
        } else e4.push(n3), a3++;
      }
    }
    m2.push(p2), h2(m2, 0.75 * o2);
    for (var g2 = new t2(function(e4, t3) {
      return J(e4.count() * e4.volume(), t3.count() * t3.volume());
    }); m2.size(); ) g2.push(m2.pop());
    h2(g2, o2);
    for (var _2 = new r2(); g2.size(); ) _2.push(g2.pop());
    return _2;
  } };
})().quantize, X = function(e3, t2, n2, r2) {
  for (var i2, a2, o2, s2, c2, l2 = r2 || {}, u2 = l2.ignoreWhite, d2 = u2 === void 0 || u2, f2 = l2.whiteThreshold, p2 = f2 === void 0 ? 250 : f2, m2 = l2.alphaThreshold, h2 = m2 === void 0 ? 125 : m2, g2 = l2.minSaturation, _2 = g2 === void 0 ? 0 : g2, v2 = e3, y2 = [], b2 = 0; b2 < t2; b2 += n2) if (a2 = v2[0 + (i2 = 4 * b2)], o2 = v2[i2 + 1], s2 = v2[i2 + 2], !((c2 = v2[i2 + 3]) !== void 0 && c2 < h2 || d2 && a2 > p2 && o2 > p2 && s2 > p2)) {
    if (_2 > 0) {
      var x2 = Math.max(a2, o2, s2);
      if (x2 === 0 || (x2 - Math.min(a2, o2, s2)) / x2 < _2) continue;
    }
    y2.push([a2, o2, s2]);
  }
  return y2;
}, ae = function(e3) {
  var t2 = e3.colorCount, n2 = e3.quality;
  if (t2 !== void 0 && Number.isInteger(t2)) {
    if (t2 === 1) throw Error(`colorCount should be between 2 and 20. To get one color, call getColor() instead of getPalette()`);
    t2 = Math.max(t2, 2), t2 = Math.min(t2, 20);
  } else t2 = 10;
  return (n2 === void 0 || !Number.isInteger(n2) || n2 < 1) && (n2 = 10), { colorCount: t2, quality: n2, ignoreWhite: e3.ignoreWhite === void 0 || !!e3.ignoreWhite, whiteThreshold: typeof e3.whiteThreshold == `number` ? e3.whiteThreshold : 250, alphaThreshold: typeof e3.alphaThreshold == `number` ? e3.alphaThreshold : 125, minSaturation: typeof e3.minSaturation == `number` ? Math.max(0, Math.min(1, e3.minSaturation)) : 0 };
}, Z = function() {
};
Z.prototype.getColor = function(e3, t2) {
  if (typeof t2 == `object` && t2) {
    var n2 = this.getPalette(e3, q({ colorCount: 5 }, t2));
    return n2 === null ? null : n2[0];
  }
  var r2 = this.getPalette(e3, 5, t2);
  return r2 === null ? null : r2[0];
}, Z.prototype.getPalette = function(e3, t2, n2) {
  var r2, i2, a2, o2 = { ignoreWhite: (r2 = ae(typeof t2 == `object` && t2 ? { colorCount: t2.colorCount, quality: t2.quality, ignoreWhite: t2.ignoreWhite, whiteThreshold: t2.whiteThreshold, alphaThreshold: t2.alphaThreshold, minSaturation: t2.minSaturation } : { colorCount: t2, quality: n2 })).ignoreWhite, whiteThreshold: r2.whiteThreshold, alphaThreshold: r2.alphaThreshold, minSaturation: r2.minSaturation };
  if (!e3) throw Error(`sourceImage is required`);
  if (e3 instanceof HTMLImageElement) {
    if (!e3.complete) throw Error(`Image has not finished loading. Wait for the "load" event before calling getColor/getPalette.`);
    if (!e3.naturalWidth) throw Error(`Image has no dimensions. It may not have loaded successfully.`);
  }
  try {
    var s2 = (function(e4) {
      if (e4 instanceof HTMLImageElement) {
        var t3 = document.createElement(`canvas`), n3 = t3.getContext(`2d`), r3 = t3.width = e4.naturalWidth, i3 = t3.height = e4.naturalHeight;
        return n3.drawImage(e4, 0, 0, r3, i3), { imageData: n3.getImageData(0, 0, r3, i3), pixelCount: r3 * i3 };
      }
      if (e4 instanceof HTMLCanvasElement) {
        var a3 = e4.getContext(`2d`), o3 = e4.width, s3 = e4.height;
        return { imageData: a3.getImageData(0, 0, o3, s3), pixelCount: o3 * s3 };
      }
      if (typeof ImageData < `u` && e4 instanceof ImageData) return { imageData: e4, pixelCount: e4.width * e4.height };
      if (typeof ImageBitmap < `u` && e4 instanceof ImageBitmap) {
        var c3 = document.createElement(`canvas`), l3 = c3.getContext(`2d`);
        return c3.width = e4.width, c3.height = e4.height, l3.drawImage(e4, 0, 0), { imageData: l3.getImageData(0, 0, e4.width, e4.height), pixelCount: e4.width * e4.height };
      }
      throw Error(`Unsupported source type. Expected HTMLImageElement, HTMLCanvasElement, ImageData, or ImageBitmap.`);
    })(e3);
    i2 = s2.imageData, a2 = s2.pixelCount;
  } catch (e4) {
    throw e4.name === `SecurityError` ? Error(`Image is tainted by cross-origin data. Add crossorigin="anonymous" to the <img> tag and ensure the server sends appropriate CORS headers.`, { cause: e4 }) : e4;
  }
  var c2 = X(i2.data, a2, r2.quality, o2);
  c2.length === 0 && (c2 = X(i2.data, a2, r2.quality, q({}, o2, { ignoreWhite: false }))), c2.length === 0 && (c2 = X(i2.data, a2, r2.quality, q({}, o2, { ignoreWhite: false, alphaThreshold: 0 })));
  var l2 = ie(c2, r2.colorCount), u2 = l2 ? l2.palette() : null;
  if (u2) return u2;
  var d2 = (function(e4, t3, n3) {
    for (var r3 = e4, i3 = 0, a3 = 0, o3 = 0, s3 = 0, c3 = 0; c3 < t3; c3 += n3) {
      var l3 = 4 * c3;
      i3 += r3[l3], a3 += r3[l3 + 1], o3 += r3[l3 + 2], s3++;
    }
    return s3 === 0 ? null : [Math.round(i3 / s3), Math.round(a3 / s3), Math.round(o3 / s3)];
  })(i2.data, a2, r2.quality);
  return d2 ? [d2] : null;
}, Z.prototype.getColorFromUrl = function(e3, t2, n2) {
  var r2 = this, i2 = document.createElement(`img`);
  i2.addEventListener(`load`, function() {
    var a2 = r2.getPalette(i2, 5, n2);
    t2(a2 ? a2[0] : null, e3);
  }), i2.src = e3;
}, Z.prototype.getImageData = function(e3, t2) {
  var n2 = new XMLHttpRequest();
  n2.open(`GET`, e3, true), n2.responseType = `arraybuffer`, n2.onload = function() {
    if (this.status == 200) {
      for (var e4 = new Uint8Array(this.response), n3 = Array(e4.length), r2 = 0; r2 < e4.length; r2++) n3[r2] = String.fromCharCode(e4[r2]);
      var i2 = n3.join(``);
      t2(`data:image/png;base64,` + window.btoa(i2));
    }
  }, n2.send();
}, Z.prototype.getColorAsync = function(e3, t2, n2) {
  var r2 = this;
  this.getImageData(e3, function(e4) {
    var i2 = document.createElement(`img`);
    i2.addEventListener(`load`, function() {
      var e5 = r2.getPalette(i2, 5, n2);
      t2(e5 ? e5[0] : null, this);
    }), i2.src = e4;
  });
};
var Q = { content: { display: `flex`, flex: 1, flexDirection: `column`, justifyContent: `center`, width: `100%`, height: `100%`, boxSizing: `border-box`, position: `relative` }, volume: { display: `flex`, alignItems: `center`, gap: 10 }, seek: { display: `flex`, alignItems: `center`, gap: 10 }, buttons: { display: `flex` }, mode: { display: `flex` }, title: { fontSize: `140%`, minHeight: 29.6 }, artist: { minHeight: 21.6 }, zIndex: { zIndex: 1 }, player: { display: `flex`, flexDirection: `column`, justifyContent: `center` }, volumeSlider: (e3) => ({ color: e3.palette.mode === `dark` ? `#fff` : `rgba(0,0,0,0.87)`, "& .MuiSlider-track": { border: `none` }, "& .MuiSlider-thumb": { width: 24, height: 24, backgroundColor: `#fff`, "&:before": { boxShadow: `0 4px 8px rgba(0,0,0,0.4)` }, "&:hover, &.Mui-focusVisible, &.Mui-active": { boxShadow: `none` } } }) }, oe = [`title`, `artist`, `cover`, `state`, `duration`, `elapsed`, `prev`, `next`, `volume`, `mute`, `repeat`, `shuffle`], $ = async (e3, t2, n2, r2) => {
  if (t2[e3.name]) {
    let i2 = await r2.getObject(t2[e3.name]);
    if (i2 && i2.common) {
      let i3 = t2[e3.name].split(`.`);
      i3.pop();
      let a2 = await r2.getObjectViewSystem(`state`, `${i3.join(`.`)}.`, `${i3.join(`.`)}.\u9999`);
      if (a2) {
        let r3 = [...oe];
        Object.values(a2).forEach((n3) => {
          var _a, _b, _c;
          let i4 = (_c = (_b = (_a = n3 == null ? void 0 : n3.common) == null ? void 0 : _a.role) == null ? void 0 : _b.match(/^(media\.mode|media|button|level)\.(.*)$/)) == null ? void 0 : _c[2];
          i4 && r3.includes(i4) && (!t2[i4] || t2[i4] === `nothing_selected`) && e3.name !== i4 && (r3.splice(r3.indexOf(i4), 1), t2[i4] = n3._id);
        }), n2(t2);
      }
    }
  }
}, se = class e2 extends l {
  coverRef = t.createRef();
  setVolumeTimer = null;
  constructor(e3) {
    super(e3), this.state = { ...this.state, volume: 0, volumeObject: null };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Player`, visSet: `vis-2-widgets-nils-fork`, visName: `Player`, visWidgetLabel: `player`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard` }, { name: `title`, onChange: $, type: `id`, label: `title` }, { name: `artist`, onChange: $, type: `id`, label: `artist` }, { name: `cover`, onChange: $, type: `id`, label: `cover` }, { name: `color`, type: `color`, label: `color` }, { name: `state`, onChange: $, type: `id`, label: `state` }, { name: `duration`, onChange: $, type: `id`, label: `duration` }, { name: `elapsed`, onChange: $, type: `id`, label: `elapsed` }, { name: `prev`, onChange: $, type: `id`, label: `prev` }, { name: `next`, onChange: $, type: `id`, label: `next` }, { name: `volume`, onChange: $, type: `id`, label: `volume` }, { name: `mute`, onChange: $, type: `id`, label: `mute` }, { name: `repeat`, onChange: $, type: `id`, label: `repeat` }, { name: `shuffle`, onChange: $, type: `id`, label: `shuffle` }] }], visDefaultStyle: { width: `100%`, height: 240, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_player.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  async propertiesUpdate() {
    try {
      let e3 = await this.props.context.socket.getObject(this.state.rxData.volume);
      if (e3) {
        let t2 = await this.props.context.socket.getState(this.state.rxData.volume);
        this.setState({ volumeObject: e3, volume: (t2 == null ? void 0 : t2.val) || 0 });
      }
    } catch {
    }
  }
  async componentDidMount() {
    super.componentDidMount(), await this.propertiesUpdate();
  }
  componentWillUnmount() {
    this.setVolumeTimer && (this.setVolumeTimer = (clearTimeout(this.setVolumeTimer), null)), super.componentWillUnmount();
  }
  async onRxDataChanged(e3) {
    e3.volume !== this.state.rxData.volume && await this.propertiesUpdate();
  }
  onStateUpdated(e3, t2) {
    e3 === this.state.rxData.volume && this.setState({ volume: (t2 == null ? void 0 : t2.val) || 0 });
  }
  static getTimeString = (e3) => e3 == null ? `-:-` : `${Math.floor(e3 / 60)}:${Math.floor(e3 % 60).toString().padStart(2, `0`)}`;
  getColor() {
    return (this.state.rxData.color ? U(this.state.rxData.color).rgb().array() : null) || this.state.coverColor;
  }
  wrapContent(e3, t2, n2, i2, c2) {
    let l2 = this.getColor(), u2;
    l2 && (u2 = (l2[0] + l2[1] + l2[2]) / 3 < 128 ? `white` : `black`);
    let d2 = this.getPropertyValue(`cover`);
    return (d2 == null ? void 0 : d2.startsWith(`/`)) && (d2 = `..${d2}`), s(r, { style: { width: `calc(100% - 8px)`, height: `calc(100% - 8px)`, margin: 4, position: `relative`, backgroundImage: `none`, backgroundColor: l2 ? `rgb(${l2.join(`, `)}` : void 0, color: u2 }, onClick: c2, className: `playerContent`, children: [a(`style`, { children: u2 ? `
                .playerContent button:not(.MuiIconButton-colorPrimary) .MuiSvgIcon-root {
                    color: ${u2};
                }
            ` : null }), d2 ? a(`div`, { style: { position: `absolute`, width: `100%`, height: `100%`, top: 0, left: 0 }, children: s(`div`, { style: { position: `relative`, width: `100%`, height: `100%` }, children: [a(`img`, { src: d2, alt: `cover`, crossOrigin: `anonymous`, ref: this.coverRef, style: { maxWidth: 0, maxHeight: 0, position: `absolute` }, onLoad: () => {
      let e4 = this.coverRef.current, t3 = new Z().getColor(e4);
      this.setState({ coverColor: t3 });
    } }), a(`div`, { style: { width: `70%`, height: `100%`, backgroundImage: `url(${d2})`, backgroundSize: `cover`, backgroundPosition: `center`, backgroundRepeat: `no-repeat`, position: `absolute`, right: 0 } }), a(`div`, { style: { position: `absolute`, width: `70%`, height: `100%`, right: 0, backgroundImage: l2 ? `linear-gradient(to right, rgb(${l2.join(`, `)}), rgba(${l2.join(`, `)}, 0))` : void 0 } })] }) }) : null, s(o, { style: { display: `flex`, flexDirection: `column`, alignItems: `center`, height: `100%`, position: `relative`, ...n2 }, children: [this.state.rxData.widgetTitle ? s(`div`, { style: { display: `flex`, justifyContent: `space-between`, width: `100%`, alignItems: `center` }, children: [a(`div`, { style: { fontSize: 24, paddingTop: 0, paddingBottom: 4, ...i2 }, children: this.state.rxData.widgetTitle }), t2 || null] }) : t2 || null, e3] })] });
  }
  renderWidgetBody(t2) {
    var _a, _b, _c, _d;
    super.renderWidgetBody(t2);
    let r2 = null;
    this.state.rxData.repeat && (r2 = parseInt(this.getPropertyValue(`repeat`)) === 1 ? a(f, {}) : (parseInt(this.getPropertyValue(`repeat`)), a(p, {})));
    let o2 = this.getColor(), c2;
    o2 && (c2 = (o2[0] + o2[1] + o2[2]) / 3 < 128 ? `white` : `black`);
    let l2 = this.getPropertyValue(`state`), y2 = this.getPropertyValue(`title`), b2 = this.getPropertyValue(`artist`);
    !y2 && this.props.editMode && (y2 = `---`), !b2 && this.props.editMode && (b2 = `---`);
    let x2 = s(`div`, { style: Q.content, children: [a(`div`, { style: Q.zIndex, children: s(`div`, { style: Q.player, children: [this.state.rxData.title && this.state.rxData.title !== `nothing_selected` ? a(`div`, { style: Q.title, children: y2 }) : null, this.state.rxData.artist && this.state.rxData.artist !== `nothing_selected` ? a(`div`, { style: Q.artist, children: b2 }) : null, this.state.rxData.shuffle && this.state.rxData.shuffle !== `nothing_selected` || this.state.rxData.repeat && this.state.rxData.repeat !== `nothing_selected` ? s(`div`, { style: Q.mode, children: [this.state.rxData.repeat && this.state.rxData.volume !== `nothing_selected` ? a(n, { color: this.getPropertyValue(`repeat`) ? `primary` : void 0, onClick: () => {
      let e3;
      e3 = parseInt(this.getPropertyValue(`repeat`)) === 1 ? 2 : parseInt(this.getPropertyValue(`repeat`)) === 2 ? 0 : 1, this.props.context.setValue(this.state.rxData.repeat, e3);
    }, children: r2 }) : null, this.state.rxData.shuffle && this.state.rxData.shuffle !== `nothing_selected` ? a(n, { color: this.getPropertyValue(`shuffle`) ? `primary` : void 0, onClick: () => this.props.context.setValue(this.state.rxData.shuffle, !this.getPropertyValue(`shuffle`)), children: a(m, {}) }) : null] }) : null, s(`div`, { style: Q.buttons, children: [this.state.rxData.prev && this.state.rxData.prev !== `nothing_selected` ? a(n, { onClick: () => this.props.context.setValue(this.state.rxData.prev, true), children: a(g, { fontSize: `large` }) }) : null, a(n, { onClick: () => {
      let e3 = this.getPropertyValue(`state`);
      typeof e3 == `string` ? this.props.context.setValue(this.state.rxData.state, e3 === `play` ? `pause` : `play`) : this.props.context.setValue(this.state.rxData.state, !e3);
    }, children: a(l2 === `play` || l2 === true ? u : d, { fontSize: `large` }) }), this.state.rxData.next && this.state.rxData.volume !== `nothing_selected` ? a(n, { onClick: () => this.props.context.setValue(this.state.rxData.next, true), children: a(h, { fontSize: `large` }) }) : null] })] }) }), s(`div`, { style: Q.seek, children: [this.state.rxData.elapsed && this.state.rxData.elapsed !== `nothing_selected` ? e2.getTimeString(this.getPropertyValue(`elapsed`)) : null, this.state.rxData.duration && this.state.rxData.duration !== `nothing_selected` ? a(i, { style: { color: c2 }, sx: (e3) => ({ color: e3.palette.mode === `dark` ? `#fff` : `rgba(0,0,0,0.87)`, height: 4, "& .MuiSlider-thumb": { width: 8, height: 8, transition: `0.3s cubic-bezier(.47,1.64,.41,.8)`, "&:before": { boxShadow: `0 2px 12px 0 rgba(0,0,0,0.4)` }, "&.Mui-active": { width: 20, height: 20 }, "&:hover, &.Mui-focusVisible": { boxShadow: `0px 0px 0px 8px ${e3.palette.mode === `dark` || c2 === `white` ? `rgb(255 255 255 / 16%)` : `rgb(0 0 0 / 16%)`}` } }, "& .MuiSlider-rail": { opacity: 0.28 } }), size: `small`, min: 0, max: this.getPropertyValue(`duration`) || 0, value: this.getPropertyValue(`elapsed`) || 0, valueLabelDisplay: `auto`, valueLabelFormat: e2.getTimeString, slotProps: { input: { readOnly: true } } }) : null, this.state.rxData.duration && this.state.rxData.duration !== `nothing_selected` ? e2.getTimeString(this.getPropertyValue(`duration`)) : null] }), this.state.rxData.volume && this.state.rxData.volume !== `nothing_selected` || this.state.rxData.mute && this.state.rxData.mute !== `nothing_selected` ? s(`div`, { style: Q.volume, children: [this.state.rxData.mute ? a(n, { onClick: () => this.props.context.setValue(this.state.rxData.mute, !this.getPropertyValue(`mute`)), children: this.getPropertyValue(`mute`) ? a(_, {}) : a(v, {}) }) : null, this.state.rxData.volume && this.state.rxData.volume !== `nothing_selected` ? a(i, { sx: Q.volumeSlider, style: { color: c2 }, min: ((_b = (_a = this.state.volumeObject) == null ? void 0 : _a.common) == null ? void 0 : _b.min) || 0, max: ((_d = (_c = this.state.volumeObject) == null ? void 0 : _c.common) == null ? void 0 : _d.max) || 100, value: this.state.volume, valueLabelDisplay: `auto`, onChange: (e3, t3) => {
      this.setState({ volume: t3 }, () => {
        this.setVolumeTimer && clearTimeout(this.setVolumeTimer), this.setVolumeTimer = setTimeout(() => {
          this.setVolumeTimer = null, this.props.context.setValue(this.state.rxData.volume, this.state.volume);
        }, 200);
      });
    } }) : null] }) : null] });
    return this.state.rxData.noCard || t2.widget.usedInWidget ? a(`div`, { style: { width: `100%`, height: `100%` }, children: x2 }) : this.wrapContent(x2, null, { boxSizing: `border-box`, paddingBottom: 10 });
  }
};
export {
  se as default
};
