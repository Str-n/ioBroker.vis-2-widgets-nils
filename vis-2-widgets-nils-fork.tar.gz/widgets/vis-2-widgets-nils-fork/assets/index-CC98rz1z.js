import { i as pt, k as ht, u as U, v as l, w as Re, x as Ge, y as De, z as We, A as Ie, s as gt, c as Ne, B as Te, C as ee, j as yt, D as St, E as _e, __tla as __tla_0 } from "./getColorSchemeSelector-S_MR5UAK.js";
import { n as Ns, F as Os, G as zs, H as Bs, I as Fs, J as Ks, K as Us, L as qs, M as Hs, N as Xs, O as Js, P as Qs, Q as Ys, R as Zs, S as er, T as tr, U as or, V as sr, W as rr, X as nr, Y as ar, t as ir, Z as cr, _ as lr, $ as dr, d as mr, a0 as ur, o as fr, a1 as pr, g as hr, a2 as gr, q as yr, a3 as Sr, a4 as Cr, a5 as br, a6 as xr, a7 as vr, a8 as kr, a9 as Tr, aa as _r, ab as $r, ac as Mr, ad as wr, ae as Pr, af as Er, m as jr, l as Ar, ag as Vr, ah as Lr, ai as Rr, aj as Gr, ak as Dr, al as Wr, am as Ir, an as Nr, ao as Or, ap as zr, aq as Br, f as Fr, h as Kr, p as Ur, e as qr, b as Hr, ar as Xr, as as Jr, at as Qr, au as Yr, av as Zr, aw as en, ax as tn, ay as on, az as sn, a as rn, aA as nn, __tla as __tla_1 } from "./getColorSchemeSelector-S_MR5UAK.js";
import { s as Oe, w as Ct, T as ze, d as $e, i as bt, h as xt, E as vt, e as kt, f as Tt, j as _t, S as $t, k as Mt, D as wt, g as F, a as q, l as Pt, C as Et, p as jt, b as Be, __tla as __tla_2 } from "./createStyled-Cx7xtW-G.js";
import { c as cn, m as ln, n as dn, __tla as __tla_3 } from "./createStyled-Cx7xtW-G.js";
import { g as ne, e as ae, c as Me, m as j, k as we, f as B, l as te, d as At, h as Vt, i as ie, t as Lt, r as Rt, __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__prop_mf_2_types__loadShare__.js-DP_PH0VJ.js";
import { j as C, __tla as __tla_6 } from "./jsx-runtime-DTPVEbuR.js";
import { u as Fe, T as Gt, __tla as __tla_7 } from "./ThemeProvider-DYUu-ed1.js";
import { h as Ke, j as Ue, b as Dt, u as qe, R as Wt, d as It, e as He, s as Xe, a as Je, __tla as __tla_8 } from "./useMediaQuery-BTLcJJwa.js";
import { g as un, k as fn, l as pn, m as hn, t as gn, n as yn, c as Sn, __tla as __tla_9 } from "./useMediaQuery-BTLcJJwa.js";
import "./hoist-non-react-statics.cjs-DmFh29GN.js";
import { c as ce } from "./clsx-B-dksMZM.js";
import { c as Qe, d as Nt, f as Ot, __tla as __tla_10 } from "./capitalize-g-ksEjkR.js";
import "./extends-CF3RwP-h.js";
import { __tla as __tla_11 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
let ks, js, qt, Cs, Ls, gs, Xt, yo, go, vo, Po, Vs, zo, Ho, ts, Bt, tt, Ds, Co, uo, fo, bo, xo, po, ot, jo, Ao, Vo, Lo, As, bs, Rs, xs, ho, ko, To, hs, Eo, Ro, Do, Ms, ws, So, Ps, _o, st, Es, ps, wo, rt, Gs, Wo, Go, Mo, nt, Io, ys, Ss, _s, vs, Ts, $s, $o;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_9;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_10;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_11;
    } catch {
    }
  })()
]).then(async () => {
  ps = {};
  var Pe = function(t, o) {
    var r = arguments;
    if (o == null || !xt.call(o, "css")) return Me.apply(void 0, r);
    var n = r.length, a = new Array(n);
    a[0] = vt, a[1] = kt(t, o);
    for (var s = 2; s < n; s++) a[s] = r[s];
    return Me.apply(null, a);
  };
  (function(e) {
    var t;
    t || (t = e.JSX || (e.JSX = {}));
  })(Pe || (Pe = {}));
  var zt = Ct(function(e, t) {
    var o = e.styles, r = Oe([
      o
    ], void 0, ne(ze)), n = ae();
    return $e(function() {
      var a = t.key + "-global", s = new t.sheet.constructor({
        key: a,
        nonce: t.sheet.nonce,
        container: t.sheet.container,
        speedy: t.sheet.isSpeedy
      }), i = false, c = document.querySelector('style[data-emotion="' + a + " " + r.name + '"]');
      return t.sheet.tags.length && (s.before = t.sheet.tags[0]), c !== null && (i = true, c.setAttribute("data-emotion", a), s.hydrate([
        c
      ])), n.current = [
        s,
        i
      ], function() {
        s.flush();
      };
    }, [
      t
    ]), $e(function() {
      var a = n.current, s = a[0], i = a[1];
      if (i) {
        a[1] = false;
        return;
      }
      if (r.next !== void 0 && bt(t, r.next, true), s.tags.length) {
        var c = s.tags[s.tags.length - 1].nextElementSibling;
        s.before = c, s.flush();
      }
      t.insert("", r, s, false);
    }, [
      t,
      r.name
    ]), null;
  });
  Bt = function() {
    for (var e = arguments.length, t = new Array(e), o = 0; o < e; o++) t[o] = arguments[o];
    return Oe(t);
  };
  hs = function() {
    var e = Bt.apply(void 0, arguments), t = "animation-" + e.name;
    return {
      name: t,
      styles: "@keyframes " + t + "{" + e.styles + "}",
      anim: 1,
      toString: function() {
        return "_EMO_" + this.name + "_" + this.styles + "_EMO_";
      }
    };
  };
  const oe = /* @__PURE__ */ new Map(), Ft = (e, t) => {
    const o = _t(e);
    return o.sheet = new t({
      key: o.key,
      nonce: o.sheet.nonce,
      container: o.sheet.container,
      speedy: o.sheet.isSpeedy,
      prepend: o.sheet.prepend,
      insertionPoint: o.sheet.insertionPoint
    }), o;
  };
  let L;
  if (typeof document == "object" && (L = document.querySelector('[name="emotion-insertion-point"]'), !L)) {
    L = document.createElement("meta"), L.setAttribute("name", "emotion-insertion-point"), L.setAttribute("content", "");
    const e = document.querySelector("head");
    e && e.prepend(L);
  }
  function Kt(e, t) {
    if (e || t) {
      class o extends $t {
        insert(a, s) {
          return this.key && this.key.endsWith("global") && (this.before = L), super.insert(a, s);
        }
      }
      const r = Ft({
        key: "css",
        insertionPoint: e ? L : void 0
      }, o);
      if (t) {
        const n = r.insert;
        r.insert = (...a) => (a[1].styles.match(/^@layer\s+[^{]*$/) || (a[1].styles = `@layer mui {${a[1].styles}}`), n(...a));
      }
      return r;
    }
  }
  gs = function(e) {
    const { injectFirst: t, enableCssLayer: o, children: r } = e, n = j(() => {
      const a = `${t}-${o}`;
      if (typeof document == "object" && oe.has(a)) return oe.get(a);
      const s = Kt(t, o);
      return oe.set(a, s), s;
    }, [
      t,
      o
    ]);
    return n ? C.jsx(Tt, {
      value: n,
      children: r
    }) : r;
  };
  function Ut(e) {
    return e == null || Object.keys(e).length === 0;
  }
  function Ye(e) {
    const { styles: t, defaultTheme: o = {} } = e, r = typeof t == "function" ? (n) => t(Ut(n) ? o : n) : t;
    return C.jsx(zt, {
      styles: r
    });
  }
  function se(e) {
    const t = Mt(e);
    return e !== t && t.styles ? (t.styles.match(/^@layer\s+[^{]*$/) || (t.styles = `@layer global{${t.styles}}`), t) : e;
  }
  qt = function({ styles: e, themeId: t, defaultTheme: o = {} }) {
    const r = Ke(o), n = t && r[t] || r;
    let a = typeof e == "function" ? e(n) : e;
    return n.modularCssLayers && (Array.isArray(a) ? a = a.map((s) => se(typeof s == "function" ? s(n) : s)) : a = se(a)), C.jsx(Ye, {
      styles: a
    });
  };
  function Ht(e) {
    const t = Ue(), o = Dt() || "", { modularCssLayers: r } = e;
    let n = "mui.global, mui.components, mui.theme, mui.custom, mui.sx";
    return !r || t !== null ? n = "" : typeof r == "string" ? n = r.replace(/mui(?!\.)/g, n) : n = `@layer ${n};`, qe(() => {
      var _a, _b;
      const a = document.querySelector("head");
      if (!a) return;
      const s = a.firstChild;
      if (n) {
        if (s && ((_a = s.hasAttribute) == null ? void 0 : _a.call(s, "data-mui-layer-order")) && s.getAttribute("data-mui-layer-order") === o) return;
        const i = document.createElement("style");
        i.setAttribute("data-mui-layer-order", o), i.textContent = n, a.prepend(i);
      } else (_b = a.querySelector(`style[data-mui-layer-order="${o}"]`)) == null ? void 0 : _b.remove();
    }, [
      n,
      o
    ]), n ? C.jsx(qt, {
      styles: n
    }) : null;
  }
  const Ee = {};
  function je(e, t, o, r = false) {
    return j(() => {
      const n = e && t[e] || t;
      if (typeof o == "function") {
        const a = o(n), s = e ? {
          ...t,
          [e]: a
        } : a;
        return r ? () => s : s;
      }
      return e ? {
        ...t,
        [e]: o
      } : {
        ...t,
        ...o
      };
    }, [
      e,
      t,
      o,
      r
    ]);
  }
  Xt = function(e) {
    const { children: t, theme: o, themeId: r } = e, n = Ue(Ee), a = Fe() || Ee, s = je(r, n, o), i = je(r, a, o, true), c = (r ? s[r] : s).direction === "rtl", d = Ht(s);
    return C.jsx(Gt, {
      theme: i,
      children: C.jsx(ze.Provider, {
        value: s,
        children: C.jsx(Wt, {
          value: c,
          children: C.jsxs(wt, {
            value: r ? s[r].components : s.components,
            children: [
              d,
              t
            ]
          })
        })
      })
    });
  };
  const le = "mode", de = "color-scheme", Ze = "data-color-scheme";
  function Jt(e) {
    const { defaultMode: t = "system", defaultLightColorScheme: o = "light", defaultDarkColorScheme: r = "dark", modeStorageKey: n = le, colorSchemeStorageKey: a = de, attribute: s = Ze, colorSchemeNode: i = "document.documentElement", nonce: c } = e || {};
    let d = "", u = s;
    if (s === "class" && (u = ".%s"), s === "data" && (u = "[data-%s]"), u.startsWith(".")) {
      const h = u.substring(1);
      d += `${i}.classList.remove('${h}'.replace('%s', light), '${h}'.replace('%s', dark));
      ${i}.classList.add('${h}'.replace('%s', colorScheme));`;
    }
    const y = u.match(/\[([^\]]+)\]/);
    if (y) {
      const [h, S] = y[1].split("=");
      S || (d += `${i}.removeAttribute('${h}'.replace('%s', light));
      ${i}.removeAttribute('${h}'.replace('%s', dark));`), d += `
      ${i}.setAttribute('${h}'.replace('%s', colorScheme), ${S ? `${S}.replace('%s', colorScheme)` : '""'});`;
    } else d += `${i}.setAttribute('${u}', colorScheme);`;
    return C.jsx("script", {
      suppressHydrationWarning: true,
      nonce: typeof window > "u" ? c : "",
      dangerouslySetInnerHTML: {
        __html: `(function() {
try {
  let colorScheme = '';
  const mode = localStorage.getItem('${n}') || '${t}';
  const dark = localStorage.getItem('${a}-dark') || '${r}';
  const light = localStorage.getItem('${a}-light') || '${o}';
  if (mode === 'system') {
    // handle system mode
    const mql = window.matchMedia('(prefers-color-scheme: dark)');
    if (mql.matches) {
      colorScheme = dark
    } else {
      colorScheme = light
    }
  }
  if (mode === 'light') {
    colorScheme = light;
  }
  if (mode === 'dark') {
    colorScheme = dark;
  }
  if (colorScheme) {
    ${d}
  }
} catch(e){}})();`
      }
    }, "mui-color-scheme-init");
  }
  function Qt() {
  }
  const Yt = ({ key: e, storageWindow: t }) => (!t && typeof window < "u" && (t = window), {
    get(o) {
      if (typeof window > "u") return;
      if (!t) return o;
      let r;
      try {
        r = t.localStorage.getItem(e);
      } catch {
      }
      return r || o;
    },
    set: (o) => {
      if (t) try {
        t.localStorage.setItem(e, o);
      } catch {
      }
    },
    subscribe: (o) => {
      if (!t) return Qt;
      const r = (n) => {
        const a = n.newValue;
        n.key === e && o(a);
      };
      return t.addEventListener("storage", r), () => {
        t.removeEventListener("storage", r);
      };
    }
  });
  function re() {
  }
  function Ae(e) {
    if (typeof window < "u" && typeof window.matchMedia == "function" && e === "system") return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  function et(e, t) {
    if (e.mode === "light" || e.mode === "system" && e.systemMode === "light") return t("light");
    if (e.mode === "dark" || e.mode === "system" && e.systemMode === "dark") return t("dark");
  }
  function Zt(e) {
    return et(e, (t) => {
      if (t === "light") return e.lightColorScheme;
      if (t === "dark") return e.darkColorScheme;
    });
  }
  function eo(e) {
    const { defaultMode: t = "light", defaultLightColorScheme: o, defaultDarkColorScheme: r, supportedColorSchemes: n = [], modeStorageKey: a = le, colorSchemeStorageKey: s = de, storageWindow: i = typeof window > "u" ? void 0 : window, storageManager: c = Yt, noSsr: d = false } = e, u = n.join(","), y = n.length > 1, h = j(() => c == null ? void 0 : c({
      key: a,
      storageWindow: i
    }), [
      c,
      a,
      i
    ]), S = j(() => c == null ? void 0 : c({
      key: `${s}-light`,
      storageWindow: i
    }), [
      c,
      s,
      i
    ]), x = j(() => c == null ? void 0 : c({
      key: `${s}-dark`,
      storageWindow: i
    }), [
      c,
      s,
      i
    ]), [T, M] = we(() => {
      const f = (h == null ? void 0 : h.get(t)) || t, m = (S == null ? void 0 : S.get(o)) || o, p = (x == null ? void 0 : x.get(r)) || r;
      return {
        mode: f,
        systemMode: Ae(f),
        lightColorScheme: m,
        darkColorScheme: p
      };
    }), [_, R] = we(d || !y);
    B(() => {
      R(true);
    }, []);
    const G = Zt(T), D = te((f) => {
      M((m) => {
        if (f === m.mode) return m;
        const p = f ?? t;
        return h == null ? void 0 : h.set(p), {
          ...m,
          mode: p,
          systemMode: Ae(p)
        };
      });
    }, [
      h,
      t
    ]), A = te((f) => {
      f ? typeof f == "string" ? f && !u.includes(f) ? console.error(`\`${f}\` does not exist in \`theme.colorSchemes\`.`) : M((m) => {
        const p = {
          ...m
        };
        return et(m, (g) => {
          g === "light" && (S == null ? void 0 : S.set(f), p.lightColorScheme = f), g === "dark" && (x == null ? void 0 : x.set(f), p.darkColorScheme = f);
        }), p;
      }) : M((m) => {
        const p = {
          ...m
        }, g = f.light === null ? o : f.light, W = f.dark === null ? r : f.dark;
        return g && (u.includes(g) ? (p.lightColorScheme = g, S == null ? void 0 : S.set(g)) : console.error(`\`${g}\` does not exist in \`theme.colorSchemes\`.`)), W && (u.includes(W) ? (p.darkColorScheme = W, x == null ? void 0 : x.set(W)) : console.error(`\`${W}\` does not exist in \`theme.colorSchemes\`.`)), p;
      }) : M((m) => (S == null ? void 0 : S.set(o), x == null ? void 0 : x.set(r), {
        ...m,
        lightColorScheme: o,
        darkColorScheme: r
      }));
    }, [
      u,
      S,
      x,
      o,
      r
    ]), N = te((f) => {
      T.mode === "system" && M((m) => {
        const p = (f == null ? void 0 : f.matches) ? "dark" : "light";
        return m.systemMode === p ? m : {
          ...m,
          systemMode: p
        };
      });
    }, [
      T.mode
    ]), K = ae(N);
    return K.current = N, B(() => {
      if (typeof window.matchMedia != "function" || !y) return;
      const f = (...p) => K.current(...p), m = window.matchMedia("(prefers-color-scheme: dark)");
      return m.addListener(f), f(m), () => {
        m.removeListener(f);
      };
    }, [
      y
    ]), B(() => {
      if (y) {
        const f = (h == null ? void 0 : h.subscribe((g) => {
          (!g || [
            "light",
            "dark",
            "system"
          ].includes(g)) && D(g || t);
        })) || re, m = (S == null ? void 0 : S.subscribe((g) => {
          (!g || u.match(g)) && A({
            light: g
          });
        })) || re, p = (x == null ? void 0 : x.subscribe((g) => {
          (!g || u.match(g)) && A({
            dark: g
          });
        })) || re;
        return () => {
          f(), m(), p();
        };
      }
    }, [
      A,
      D,
      u,
      t,
      i,
      y,
      h,
      S,
      x
    ]), {
      ...T,
      mode: _ ? T.mode : void 0,
      systemMode: _ ? T.systemMode : void 0,
      colorScheme: _ ? G : void 0,
      setMode: D,
      setColorScheme: A
    };
  }
  const to = "*{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}";
  ys = function(e) {
    const { themeId: t, theme: o = {}, modeStorageKey: r = le, colorSchemeStorageKey: n = de, disableTransitionOnChange: a = false, defaultColorScheme: s, resolveTheme: i } = e, c = {
      allColorSchemes: [],
      colorScheme: void 0,
      darkColorScheme: void 0,
      lightColorScheme: void 0,
      mode: void 0,
      setColorScheme: () => {
      },
      setMode: () => {
      },
      systemMode: void 0
    }, d = Vt(void 0), u = () => ne(d) || c, y = {}, h = {};
    function S(_) {
      var _a, _b, _c, _d;
      const { children: R, theme: G, modeStorageKey: D = r, colorSchemeStorageKey: A = n, disableTransitionOnChange: N = a, storageManager: K, storageWindow: f = typeof window > "u" ? void 0 : window, documentNode: m = typeof document > "u" ? void 0 : document, colorSchemeNode: p = typeof document > "u" ? void 0 : document.documentElement, disableNestedContext: g = false, disableStyleSheetGeneration: W = false, defaultMode: at = "system", noSsr: it } = _, H = ae(false), ct = Fe(), X = ne(d), J = !!X && !g, me = j(() => G || (typeof o == "function" ? o() : o), [
        G
      ]), ue = me[t], P = ue || me, { colorSchemes: V = y, components: fe = h, cssVarPrefix: Q } = P, pe = Object.keys(V).filter((v) => !!V[v]).join(","), I = j(() => pe.split(","), [
        pe
      ]), he = typeof s == "string" ? s : s.light, ge = typeof s == "string" ? s : s.dark, lt = V[he] && V[ge] ? at : ((_b = (_a = V[P.defaultColorScheme]) == null ? void 0 : _a.palette) == null ? void 0 : _b.mode) || ((_c = P.palette) == null ? void 0 : _c.mode), { mode: dt, setMode: ye, systemMode: Se, lightColorScheme: Ce, darkColorScheme: be, colorScheme: mt, setColorScheme: xe } = eo({
        supportedColorSchemes: I,
        defaultLightColorScheme: he,
        defaultDarkColorScheme: ge,
        modeStorageKey: D,
        colorSchemeStorageKey: A,
        defaultMode: lt,
        storageManager: K,
        storageWindow: f,
        noSsr: it
      });
      let Y = dt, $ = mt;
      J && (Y = X.mode, $ = X.colorScheme);
      const Z = j(() => {
        var _a2;
        const v = $ || P.defaultColorScheme, b = ((_a2 = P.generateThemeVars) == null ? void 0 : _a2.call(P)) || P.vars, k = {
          ...P,
          components: fe,
          colorSchemes: V,
          cssVarPrefix: Q,
          vars: b
        };
        if (typeof k.generateSpacing == "function" && (k.spacing = k.generateSpacing()), v) {
          const E = V[v];
          E && typeof E == "object" && Object.keys(E).forEach((w) => {
            E[w] && typeof E[w] == "object" ? k[w] = {
              ...k[w],
              ...E[w]
            } : k[w] = E[w];
          });
        }
        return i ? i(k) : k;
      }, [
        P,
        $,
        fe,
        V,
        Q
      ]), O = P.colorSchemeSelector;
      qe(() => {
        if ($ && p && O && O !== "media") {
          const v = O;
          let b = O;
          if (v === "class" && (b = ".%s"), v === "data" && (b = "[data-%s]"), (v == null ? void 0 : v.startsWith("data-")) && !v.includes("%s") && (b = `[${v}="%s"]`), b.startsWith(".")) p.classList.remove(...I.map((k) => b.substring(1).replace("%s", k))), p.classList.add(b.substring(1).replace("%s", $));
          else {
            const k = b.replace("%s", $).match(/\[([^\]]+)\]/);
            if (k) {
              const [E, w] = k[1].split("=");
              w || I.forEach((ft) => {
                p.removeAttribute(E.replace($, ft));
              }), p.setAttribute(E, w ? w.replace(/"|'/g, "") : "");
            } else p.setAttribute(b, $);
          }
        }
      }, [
        $,
        O,
        p,
        I
      ]), B(() => {
        let v;
        if (N && H.current && m) {
          const b = m.createElement("style");
          b.appendChild(m.createTextNode(to)), m.head.appendChild(b), window.getComputedStyle(m.body), v = setTimeout(() => {
            m.head.removeChild(b);
          }, 1);
        }
        return () => {
          clearTimeout(v);
        };
      }, [
        $,
        N,
        m
      ]), B(() => (H.current = true, () => {
        H.current = false;
      }), []);
      const ut = j(() => ({
        allColorSchemes: I,
        colorScheme: $,
        darkColorScheme: be,
        lightColorScheme: Ce,
        mode: Y,
        setColorScheme: xe,
        setMode: ye,
        systemMode: Se
      }), [
        I,
        $,
        be,
        Ce,
        Y,
        xe,
        ye,
        Se,
        Z.colorSchemeSelector
      ]);
      let ve = true;
      (W || P.cssVariables === false || J && (ct == null ? void 0 : ct.cssVarPrefix) === Q) && (ve = false);
      const ke = C.jsxs(At, {
        children: [
          C.jsx(Xt, {
            themeId: ue ? t : void 0,
            theme: Z,
            children: R
          }),
          ve && C.jsx(Ye, {
            styles: ((_d = Z.generateStyleSheets) == null ? void 0 : _d.call(Z)) || []
          })
        ]
      });
      return J ? ke : C.jsx(d.Provider, {
        value: ut,
        children: ke
      });
    }
    const x = typeof s == "string" ? s : s.light, T = typeof s == "string" ? s : s.dark;
    return {
      CssVarsProvider: S,
      useColorScheme: u,
      getInitColorSchemeScript: (_) => Jt({
        colorSchemeStorageKey: n,
        defaultLightColorScheme: x,
        defaultDarkColorScheme: T,
        modeStorageKey: r,
        ..._
      })
    };
  };
  Ss = function({ colorSchemeSelector: e = `[${Ze}="%s"]`, ...t }) {
    const o = t, r = pt(o, {
      ...t,
      prefix: t.cssVarPrefix,
      colorSchemeSelector: e
    });
    return o.vars = r.vars, o.generateThemeVars = r.generateThemeVars, o.generateStyleSheets = r.generateStyleSheets, o.colorSchemeSelector = e, o.getColorSchemeSelector = ht(e), o;
  };
  Cs = It();
  bs = function(e) {
    return F("MuiGrid", e);
  };
  let oo, so, ro, z, no, ao, io, co, lo, mo, Ve, No, Oo;
  oo = [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10
  ];
  so = [
    "column-reverse",
    "column",
    "row-reverse",
    "row"
  ];
  ro = [
    "nowrap",
    "wrap-reverse",
    "wrap"
  ];
  z = [
    "auto",
    "grow",
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12
  ];
  xs = q("MuiGrid", [
    "root",
    "container",
    "item",
    ...oo.map((e) => `spacing-xs-${e}`),
    ...so.map((e) => `direction-xs-${e}`),
    ...ro.map((e) => `wrap-xs-${e}`),
    ...z.map((e) => `grid-xs-${e}`),
    ...z.map((e) => `grid-sm-${e}`),
    ...z.map((e) => `grid-md-${e}`),
    ...z.map((e) => `grid-lg-${e}`),
    ...z.map((e) => `grid-xl-${e}`)
  ]);
  no = l({
    prop: "displayPrint",
    cssProperty: false,
    transform: (e) => ({
      "@media print": {
        display: e
      }
    })
  });
  ao = l({
    prop: "display"
  });
  io = l({
    prop: "overflow"
  });
  co = l({
    prop: "textOverflow"
  });
  lo = l({
    prop: "visibility"
  });
  mo = l({
    prop: "whiteSpace"
  });
  tt = U(no, ao, io, co, lo, mo);
  uo = l({
    prop: "flexBasis"
  });
  fo = l({
    prop: "flexDirection"
  });
  po = l({
    prop: "flexWrap"
  });
  ho = l({
    prop: "justifyContent"
  });
  go = l({
    prop: "alignItems"
  });
  yo = l({
    prop: "alignContent"
  });
  So = l({
    prop: "order"
  });
  Co = l({
    prop: "flex"
  });
  bo = l({
    prop: "flexGrow"
  });
  xo = l({
    prop: "flexShrink"
  });
  vo = l({
    prop: "alignSelf"
  });
  ko = l({
    prop: "justifyItems"
  });
  To = l({
    prop: "justifySelf"
  });
  ot = U(uo, fo, po, ho, go, yo, So, Co, bo, xo, vo, ko, To);
  _o = l({
    prop: "position"
  });
  $o = l({
    prop: "zIndex",
    themeKey: "zIndex"
  });
  Mo = l({
    prop: "top"
  });
  wo = l({
    prop: "right"
  });
  Po = l({
    prop: "bottom"
  });
  Eo = l({
    prop: "left"
  });
  st = U(_o, $o, Mo, wo, Po, Eo);
  rt = l({
    prop: "boxShadow",
    themeKey: "shadows"
  });
  jo = l({
    prop: "fontFamily",
    themeKey: "typography"
  });
  Ao = l({
    prop: "fontSize",
    themeKey: "typography"
  });
  Vo = l({
    prop: "fontStyle",
    themeKey: "typography"
  });
  Lo = l({
    prop: "fontWeight",
    themeKey: "typography"
  });
  Ro = l({
    prop: "letterSpacing"
  });
  Go = l({
    prop: "textTransform"
  });
  Do = l({
    prop: "lineHeight"
  });
  Wo = l({
    prop: "textAlign"
  });
  Io = l({
    prop: "typography",
    cssProperty: false,
    themeKey: "typography"
  });
  nt = U(Io, jo, Ao, Vo, Lo, Ro, Do, Wo, Go);
  Ve = {
    borders: Ie.filterProps,
    display: tt.filterProps,
    flexbox: ot.filterProps,
    grid: We.filterProps,
    positions: st.filterProps,
    palette: De.filterProps,
    shadows: rt.filterProps,
    sizing: Ge.filterProps,
    spacing: Re.filterProps,
    typography: nt.filterProps
  };
  No = {
    borders: Ie,
    display: tt,
    flexbox: ot,
    grid: We,
    positions: st,
    palette: De,
    shadows: rt,
    sizing: Ge,
    spacing: Re,
    typography: nt
  };
  Oo = Object.keys(Ve).reduce((e, t) => (Ve[t].forEach((o) => {
    e[o] = No[t];
  }), e), {});
  vs = function(e, t, o) {
    const r = {
      [e]: t,
      theme: o
    }, n = Oo[e];
    return n ? n(r) : {
      [e]: t
    };
  };
  zo = function(e = {}) {
    const { themeId: t, defaultTheme: o, defaultClassName: r = "MuiBox-root", generateClassName: n } = e, a = Pt("div", {
      shouldForwardProp: (i) => i !== "theme" && i !== "sx" && i !== "as"
    })(gt);
    return ie(function(c, d) {
      const u = Ke(o), { className: y, component: h = "div", ...S } = He(c);
      return C.jsx(a, {
        as: h,
        ref: d,
        className: ce(y, n ? n(r) : r),
        theme: t && u[t] || u,
        ...S
      });
    });
  };
  let Bo, Le;
  Bo = q("MuiBox", [
    "root"
  ]);
  ks = zo({
    defaultClassName: Bo.root,
    generateClassName: Et.generate
  });
  Le = {
    theme: void 0
  };
  Ts = function(e) {
    let t, o;
    return function(n) {
      let a = t;
      return (a === void 0 || n.theme !== o) && (Le.theme = n.theme, a = jt(e(Le)), t = a, o = n.theme), a;
    };
  };
  _s = function(e = "") {
    function t(...r) {
      if (!r.length) return "";
      const n = r[0];
      return typeof n == "string" && !n.match(/(#|\(|\)|(-?(\d*\.)?\d+)(px|em|%|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc))|^(-?(\d*\.)?\d+)$|(\d+ \d+ \d+)/) ? `, var(--${e ? `${e}-` : ""}${n}${t(...r.slice(1))})` : `, ${n}`;
    }
    return (r, ...n) => `var(--${e ? `${e}-` : ""}${r}${t(...n)})`;
  };
  let Fo, Ko, Uo, qo;
  $s = "6.5.0";
  Ms = 6;
  ws = 5;
  Ps = 0;
  Es = void 0;
  Fo = Ne();
  Ko = Xe("div", {
    name: "MuiContainer",
    slot: "Root",
    overridesResolver: (e, t) => {
      const { ownerState: o } = e;
      return [
        t.root,
        t[`maxWidth${Qe(String(o.maxWidth))}`],
        o.fixed && t.fixed,
        o.disableGutters && t.disableGutters
      ];
    }
  });
  Uo = (e) => Je({
    props: e,
    name: "MuiContainer",
    defaultTheme: Fo
  });
  qo = (e, t) => {
    const o = (c) => F(t, c), { classes: r, fixed: n, disableGutters: a, maxWidth: s } = e, i = {
      root: [
        "root",
        s && `maxWidth${Qe(String(s))}`,
        n && "fixed",
        a && "disableGutters"
      ]
    };
    return Be(i, o, r);
  };
  Ho = function(e = {}) {
    const { createStyledComponent: t = Ko, useThemeProps: o = Uo, componentName: r = "MuiContainer" } = e, n = t(({ theme: s, ownerState: i }) => ({
      width: "100%",
      marginLeft: "auto",
      boxSizing: "border-box",
      marginRight: "auto",
      ...!i.disableGutters && {
        paddingLeft: s.spacing(2),
        paddingRight: s.spacing(2),
        [s.breakpoints.up("sm")]: {
          paddingLeft: s.spacing(3),
          paddingRight: s.spacing(3)
        }
      }
    }), ({ theme: s, ownerState: i }) => i.fixed && Object.keys(s.breakpoints.values).reduce((c, d) => {
      const u = d, y = s.breakpoints.values[u];
      return y !== 0 && (c[s.breakpoints.up(u)] = {
        maxWidth: `${y}${s.breakpoints.unit}`
      }), c;
    }, {}), ({ theme: s, ownerState: i }) => ({
      ...i.maxWidth === "xs" && {
        [s.breakpoints.up("xs")]: {
          maxWidth: Math.max(s.breakpoints.values.xs, 444)
        }
      },
      ...i.maxWidth && i.maxWidth !== "xs" && {
        [s.breakpoints.up(i.maxWidth)]: {
          maxWidth: `${s.breakpoints.values[i.maxWidth]}${s.breakpoints.unit}`
        }
      }
    }));
    return ie(function(i, c) {
      const d = o(i), { className: u, component: y = "div", disableGutters: h = false, fixed: S = false, maxWidth: x = "lg", classes: T, ...M } = d, _ = {
        ...d,
        component: y,
        disableGutters: h,
        fixed: S,
        maxWidth: x
      }, R = qo(_, r);
      return C.jsx(n, {
        as: y,
        ownerState: _,
        className: ce(R.root, u),
        ref: c,
        ...M
      });
    });
  };
  js = Ho();
  As = function(e) {
    return F("MuiContainer", e);
  };
  let Xo, Jo;
  Vs = q("MuiContainer", [
    "root",
    "disableGutters",
    "fixed",
    "maxWidthXs",
    "maxWidthSm",
    "maxWidthMd",
    "maxWidthLg",
    "maxWidthXl"
  ]);
  Xo = Ne();
  Jo = Xe("div", {
    name: "MuiStack",
    slot: "Root",
    overridesResolver: (e, t) => t.root
  });
  function Qo(e) {
    return Je({
      props: e,
      name: "MuiStack",
      defaultTheme: Xo
    });
  }
  function Yo(e, t) {
    const o = Lt.toArray(e).filter(Boolean);
    return o.reduce((r, n, a) => (r.push(n), a < o.length - 1 && r.push(Rt(t, {
      key: `separator-${a}`
    })), r), []);
  }
  const Zo = (e) => ({
    row: "Left",
    "row-reverse": "Right",
    column: "Top",
    "column-reverse": "Bottom"
  })[e], es = ({ ownerState: e, theme: t }) => {
    let o = {
      display: "flex",
      flexDirection: "column",
      ...Te({
        theme: t
      }, ee({
        values: e.direction,
        breakpoints: t.breakpoints.values
      }), (r) => ({
        flexDirection: r
      }))
    };
    if (e.spacing) {
      const r = yt(t), n = Object.keys(t.breakpoints.values).reduce((c, d) => ((typeof e.spacing == "object" && e.spacing[d] != null || typeof e.direction == "object" && e.direction[d] != null) && (c[d] = true), c), {}), a = ee({
        values: e.direction,
        base: n
      }), s = ee({
        values: e.spacing,
        base: n
      });
      typeof a == "object" && Object.keys(a).forEach((c, d, u) => {
        if (!a[c]) {
          const h = d > 0 ? a[u[d - 1]] : "column";
          a[c] = h;
        }
      }), o = Nt(o, Te({
        theme: t
      }, s, (c, d) => e.useFlexGap ? {
        gap: _e(r, c)
      } : {
        "& > :not(style):not(style)": {
          margin: 0
        },
        "& > :not(style) ~ :not(style)": {
          [`margin${Zo(d ? a[d] : e.direction)}`]: _e(r, c)
        }
      }));
    }
    return o = St(t.breakpoints, o), o;
  };
  ts = function(e = {}) {
    const { createStyledComponent: t = Jo, useThemeProps: o = Qo, componentName: r = "MuiStack" } = e, n = () => Be({
      root: [
        "root"
      ]
    }, (c) => F(r, c), {}), a = t(es);
    return ie(function(c, d) {
      const u = o(c), y = He(u), { component: h = "div", direction: S = "column", spacing: x = 0, divider: T, children: M, className: _, useFlexGap: R = false, ...G } = y, D = {
        direction: S,
        spacing: x,
        useFlexGap: R
      }, A = n();
      return C.jsx(a, {
        as: h,
        ownerState: D,
        ref: d,
        className: ce(A.root, _),
        ...G,
        children: T ? Yo(M, T) : M
      });
    });
  };
  Ls = ts();
  Rs = function(e) {
    return F("MuiStack", e);
  };
  Gs = q("MuiStack", [
    "root"
  ]);
  Ds = function() {
    throw new Error(Ot(19));
  };
});
export {
  ks as Box,
  js as Container,
  qt as GlobalStyles,
  Cs as Grid,
  Wt as RtlProvider,
  Ls as Stack,
  gs as StyledEngineProvider,
  Xt as ThemeProvider,
  __tla,
  yo as alignContent,
  go as alignItems,
  vo as alignSelf,
  Ns as alpha,
  Os as backgroundColor,
  zs as bgcolor,
  Bs as blend,
  Fs as border,
  Ks as borderBottom,
  Us as borderBottomColor,
  qs as borderColor,
  Hs as borderLeft,
  Xs as borderLeftColor,
  Js as borderRadius,
  Qs as borderRight,
  Ys as borderRightColor,
  Zs as borderTop,
  er as borderTopColor,
  tr as borderTransform,
  Ie as borders,
  Po as bottom,
  or as boxSizing,
  sr as breakpoints,
  rr as color,
  nr as colorChannel,
  ar as columnGap,
  U as compose,
  Vs as containerClasses,
  zo as createBox,
  ir as createBreakpoints,
  Ho as createContainer,
  It as createGrid,
  cr as createSpacing,
  ts as createStack,
  cn as createStyled,
  Ne as createTheme,
  yt as createUnarySpacing,
  lr as createUnaryUnit,
  Bt as css,
  dr as cssContainerQueries,
  mr as darken,
  ur as decomposeColor,
  tt as display,
  fr as emphasize,
  Ds as experimental_sx,
  Co as flex,
  uo as flexBasis,
  fo as flexDirection,
  bo as flexGrow,
  xo as flexShrink,
  po as flexWrap,
  ot as flexbox,
  jo as fontFamily,
  Ao as fontSize,
  Vo as fontStyle,
  Lo as fontWeight,
  pr as gap,
  As as getContainerUtilityClass,
  hr as getContrastRatio,
  bs as getGridUtilityClass,
  gr as getLuminance,
  yr as getPath,
  Rs as getStackUtilityClass,
  Sr as getStyleFromPropValue,
  Cr as getStyleValue,
  un as getThemeProps,
  _e as getValue,
  We as grid,
  br as gridArea,
  xr as gridAutoColumns,
  vr as gridAutoFlow,
  kr as gridAutoRows,
  xs as gridClasses,
  Tr as gridColumn,
  _r as gridRow,
  $r as gridTemplateAreas,
  Mr as gridTemplateColumns,
  wr as gridTemplateRows,
  Te as handleBreakpoints,
  Pr as height,
  Er as hexToRgb,
  jr as hslToRgb,
  ho as justifyContent,
  ko as justifyItems,
  To as justifySelf,
  hs as keyframes,
  Eo as left,
  Ro as letterSpacing,
  Ar as lighten,
  Do as lineHeight,
  Ms as major,
  Vr as margin,
  Lr as marginKeys,
  Rr as maxHeight,
  Gr as maxWidth,
  St as mergeBreakpointsInOrder,
  Dr as minHeight,
  Wr as minWidth,
  ws as minor,
  So as order,
  Ir as outline,
  Nr as outlineColor,
  Or as padding,
  zr as paddingKeys,
  De as palette,
  Br as paletteTransform,
  Ps as patch,
  _o as position,
  st as positions,
  Es as prerelease,
  Fr as private_safeAlpha,
  Kr as private_safeColorChannel,
  Ur as private_safeDarken,
  qr as private_safeEmphasize,
  Hr as private_safeLighten,
  Xr as recomposeColor,
  ps as responsivePropType,
  Jr as rgbToHex,
  wo as right,
  Qr as rowGap,
  rt as shadows,
  Yr as shape,
  ln as shouldForwardProp,
  Zr as sizeHeight,
  en as sizeWidth,
  Ge as sizing,
  tn as sizingTransform,
  Re as spacing,
  Gs as stackClasses,
  l as style,
  Xe as styled,
  dn as systemDefaultTheme,
  Wo as textAlign,
  Go as textTransform,
  Mo as top,
  nt as typography,
  Io as typographyVariant,
  ys as unstable_createCssVarsProvider,
  Ss as unstable_createCssVarsTheme,
  _s as unstable_createGetCssVar,
  on as unstable_createStyleFunctionSx,
  sn as unstable_cssVarsParser,
  rn as unstable_defaultSxConfig,
  He as unstable_extendSxProp,
  fn as unstable_generateDirectionClasses,
  pn as unstable_generateSizeClassNames,
  hn as unstable_generateSpacingClassNames,
  vs as unstable_getThemeValue,
  Ts as unstable_memoTheme,
  pt as unstable_prepareCssVars,
  ee as unstable_resolveBreakpointValues,
  gt as unstable_styleFunctionSx,
  gn as unstable_traverseBreakpoints,
  yn as useMediaQuery,
  Sn as useRtl,
  Ke as useTheme,
  Je as useThemeProps,
  Ue as useThemeWithoutDefault,
  $s as version,
  nn as width,
  $o as zIndex
};
