import { __tla as __tla_0 } from "./dist-BgxWXJ5y.js";
import { t as e } from "./vite-preload-helper-HclGiUj8.js";
let r, n;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  let t;
  t = {
    react: async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => (e2.H(), e2.V)), [], import.meta.url),
    "react/jsx-dev-runtime": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__prebuild__react_mf_1_jsx_mf_2_dev_mf_2_runtime__prebuild__-A5A_f5qa.js").then(async (m) => {
      await m.__tla;
      return m;
    }), [], import.meta.url),
    "react/jsx-runtime": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => e2.mt), [], import.meta.url),
    "react-dom": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => (e2.ot(), e2.at)), [], import.meta.url),
    "react-dom/client": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__prebuild__react_mf_2_dom_mf_1_client__prebuild__-Dfnucv7A.js").then(async (m) => {
      await m.__tla;
      return m;
    }), [], import.meta.url),
    "@emotion/react": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => e2.s), [], import.meta.url),
    "@mui/private-theming": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => e2.ut), [], import.meta.url),
    "@mui/system": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => e2.lt), [], import.meta.url),
    "@mui/material": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => e2.$), [], import.meta.url),
    "@iobroker/gui-components": async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => e2.s), [], import.meta.url),
    moment: async () => await e(() => import("./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare__moment__loadShare__.js-DmY8-Wzg.js").then(async (m) => {
      await m.__tla;
      return m;
    }).then((e2) => e2.n), [], import.meta.url)
  };
  n = {
    react: {
      name: `react`,
      version: `19.2.8`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n.react.loaded = true;
        let { react: e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "react/jsx-dev-runtime": {
      name: `react/jsx-dev-runtime`,
      version: `19.2.8`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`react/jsx-dev-runtime`].loaded = true;
        let { "react/jsx-dev-runtime": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "react/jsx-runtime": {
      name: `react/jsx-runtime`,
      version: `19.2.8`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`react/jsx-runtime`].loaded = true;
        let { "react/jsx-runtime": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "react-dom": {
      name: `react-dom`,
      version: `19.2.8`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`react-dom`].loaded = true;
        let { "react-dom": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "react-dom/client": {
      name: `react-dom/client`,
      version: `19.2.8`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`react-dom/client`].loaded = true;
        let { "react-dom/client": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "@emotion/react": {
      name: `@emotion/react`,
      version: `11.14.0`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`@emotion/react`].loaded = true;
        let { "@emotion/react": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "@mui/private-theming": {
      name: `@mui/private-theming`,
      version: `9.4.0`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`@mui/private-theming`].loaded = true;
        let { "@mui/private-theming": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "@mui/system": {
      name: `@mui/system`,
      version: `9.4.0`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`@mui/system`].loaded = true;
        let { "@mui/system": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "@mui/material": {
      name: `@mui/material`,
      version: `9.4.0`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`@mui/material`].loaded = true;
        let { "@mui/material": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    "@iobroker/gui-components": {
      name: `@iobroker/gui-components`,
      version: `10.2.1`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n[`@iobroker/gui-components`].loaded = true;
        let { "@iobroker/gui-components": e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    },
    moment: {
      name: `moment`,
      version: `2.30.1`,
      scope: [
        `default`
      ],
      loaded: false,
      materialize: true,
      eager: false,
      from: `vis2nilsForkWidgets`,
      canLiveRebind: true,
      async get() {
        n.moment.loaded = true;
        let { moment: e2 } = t, r2 = {
          ...await e2()
        };
        return r2.__esModule !== true && Object.defineProperty(r2, "__esModule", {
          value: true,
          enumerable: false
        }), function() {
          return r2;
        };
      },
      shareConfig: {
        singleton: true,
        requiredVersion: `*`,
        strictVersion: false,
        eager: false
      }
    }
  };
  r = [];
});
export {
  __tla,
  r as usedRemotes,
  n as usedShared
};
