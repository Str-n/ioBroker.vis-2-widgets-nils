let Ue, Fe, v, Y, o_, f_, S, c, J, d, I, w, x, T, s_, W, um, h, De, He, Le, Ke, Me, qe, Ee, Ye, Ze;
let __tla = (async () => {
  const t = "__mf_init____mf__virtual/__mfe_internal__vis2nilsForkWidgets__mf_v__runtimeInit__mf_v__.js__";
  let m = globalThis[t];
  if (!m) {
    let _, f;
    const s = new Promise((a, r) => {
      _ = a, f = r;
    });
    m = globalThis[t] = {
      initPromise: s,
      initResolve: _,
      initReject: f
    }, typeof window > "u" && _({
      loadRemote: function() {
        return Promise.resolve(void 0);
      },
      loadShare: function() {
        return Promise.resolve(void 0);
      }
    });
  }
  const o = m.initPromise, i = o.then((_) => _.loadShare("@mui/system", {
    customShareInfo: {
      shareConfig: {
        singleton: true,
        strictVersion: false,
        requiredVersion: "*"
      }
    }
  })), e = await i.then((_) => typeof _ == "function" ? _() : _);
  e.__esModule ? e.default : e.default;
  let n, l, g, u, p, b, C, y, P, k, R, V, z, B, G, j, A, F, U, D, H, L, K, M, q, E, N, Q, O, X, Z, $, __, e_, m_, t_, a_, r_, i_, n_, l_, d_, g_, u_, p_, h_, c_, b_, C_, y_, x_, S_, T_, v_, P_, k_, w_, R_, V_, z_, B_, G_, j_, A_, F_, W_, I_, U_, D_, H_, L_, K_, M_, q_, E_, N_, Q_, O_, J_, X_, Y_, Z_, $_, _e, ee, me, fe, te, se, ae, re, oe, ie, ne, le, de, ge, ue, pe, he, ce, be, Ce, ye, xe, Se, Te, ve, Pe, ke, we, Re, Ve, ze, Be, Ge, je, Ae, We, Ie, Ne, Qe, Oe, Je, Xe, $e, _m, em, mm, fm, tm, sm, am, rm, om, im, nm, lm, dm, gm, pm, hm;
  ({ Box: n, Container: l, GlobalStyles: d, Grid: g, RtlProvider: u, Stack: p, StyledEngineProvider: h, ThemeProvider: c, borders: b, breakpoints: C, compose: y, createBox: x, createBreakpoints: S, createContainer: T, createSpacing: v, createStyled: P, createTheme: k, css: w, cssContainerQueries: R, display: V, experimental_sx: z, flexbox: B, getPath: G, getStyleValue: j, getThemeProps: A, grid: F, handleBreakpoints: W, keyframes: I, mergeBreakpointsInOrder: U, palette: D, positions: H, responsivePropType: L, shadows: K, shape: M, sizing: q, spacing: E, style: N, styled: Q, typography: O, unstable_createCssVarsProvider: J, unstable_createCssVarsTheme: X, unstable_createGetCssVar: Y, unstable_createStyleFunctionSx: Z, unstable_cssVarsParser: $, unstable_defaultSxConfig: __, unstable_extendSxProp: e_, unstable_getThemeValue: m_, unstable_memoTheme: f_, unstable_prepareCssVars: t_, unstable_resolveBreakpointValues: s_, unstable_styleFunctionSx: a_, useMediaQuery: r_, useTheme: o_, useThemeProps: i_, useThemeWithoutDefault: n_, border: l_, borderBottom: d_, borderBottomColor: g_, borderColor: u_, borderLeft: p_, borderLeftColor: h_, borderRadius: c_, borderRight: b_, borderRightColor: C_, borderTop: y_, borderTopColor: x_, borderTransform: S_, outline: T_, outlineColor: v_, alignContent: P_, alignItems: k_, alignSelf: w_, flex: R_, flexBasis: V_, flexDirection: z_, flexGrow: B_, flexShrink: G_, flexWrap: j_, justifyContent: A_, justifyItems: F_, justifySelf: W_, order: I_, columnGap: U_, gap: D_, gridArea: H_, gridAutoColumns: L_, gridAutoFlow: K_, gridAutoRows: M_, gridColumn: q_, gridRow: E_, gridTemplateAreas: N_, gridTemplateColumns: Q_, gridTemplateRows: O_, rowGap: J_, backgroundColor: X_, bgcolor: Y_, color: Z_, paletteTransform: $_, bottom: _e, left: ee, position: me, right: fe, top: te, zIndex: se, boxSizing: ae, height: re, maxHeight: oe, maxWidth: ie, minHeight: ne, minWidth: le, sizeHeight: de, sizeWidth: ge, sizingTransform: ue, width: pe, createUnarySpacing: he, createUnaryUnit: ce, getStyleFromPropValue: be, getValue: Ce, margin: ye, marginKeys: xe, padding: Se, paddingKeys: Te, fontFamily: ve, fontSize: Pe, fontStyle: ke, fontWeight: we, letterSpacing: Re, lineHeight: Ve, textAlign: ze, textTransform: Be, typographyVariant: Ge, shouldForwardProp: je, systemDefaultTheme: Ae, alpha: Fe, blend: We, colorChannel: Ie, darken: Ue, decomposeColor: De, emphasize: He, getContrastRatio: Le, getLuminance: Ke, hexToRgb: Me, hslToRgb: qe, lighten: Ee, private_safeAlpha: Ne, private_safeColorChannel: Qe, private_safeDarken: Oe, private_safeEmphasize: Je, private_safeLighten: Xe, recomposeColor: Ye, rgbToHex: Ze, useRtl: $e, major: _m, minor: em, patch: mm, prerelease: fm, version: tm, containerClasses: sm, getContainerUtilityClass: am, createGrid: rm, gridClasses: om, unstable_generateDirectionClasses: im, unstable_generateSizeClassNames: nm, unstable_generateSpacingClassNames: lm, unstable_traverseBreakpoints: dm, getGridUtilityClass: gm, createStack: um, stackClasses: pm, getStackUtilityClass: hm } = e);
})();
export {
  Ue as _,
  __tla,
  Fe as a,
  v as b,
  Y as c,
  o_ as d,
  f_ as e,
  S as f,
  c as g,
  J as h,
  d as i,
  I as j,
  w as k,
  x as l,
  T as m,
  s_ as n,
  W as o,
  um as p,
  h as q,
  De as r,
  He as s,
  Le as t,
  Ke as u,
  Me as v,
  qe as w,
  Ee as x,
  Ye as y,
  Ze as z
};
