import { j as a, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { a as b, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { a as g, b as v, c as y, d as j, _ as m, g as D, f as _, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { q as d, p as u, _ as S, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CgDCyMuJ.js";
import { C as w, __tla as __tla_4 } from "./index-DBUuV2Mq.js";
import { _ as O, __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-Buo0KxVv.js";
import { G as r } from "./Generic-DDdmRdK-.js";
import { __tla as __tla_6 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
let f;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })()
]).then(async () => {
  const l = {
    text: {
      textTransform: "none"
    },
    button: {
      display: "block",
      width: "100%",
      height: "100%",
      overflow: "hidden",
      textOverflow: "ellipsis",
      padding: 0
    },
    buttonInactive: {
      opacity: 0.6
    },
    topButton: {
      display: "flex",
      alignItems: "center"
    },
    iconButton: {
      width: "50%",
      height: 40,
      display: "flex",
      textAlign: "left",
      alignItems: "center"
    },
    iconButtonCenter: {
      width: "100%",
      height: 40,
      display: "flex",
      textAlign: "center",
      justifyContent: "center"
    },
    rightButton: (p) => ({
      width: "50%",
      textAlign: "right",
      position: "relative",
      mt: "-20px",
      mb: "-20px",
      left: "20px",
      display: "flex",
      justifyContent: "right",
      color: p.palette.mode === "light" ? "#000" : "#fff",
      "&>div": {
        margin: "auto",
        "&>div": {
          transform: "translate(-50%, -50%) !important",
          top: "50% !important"
        }
      }
    }),
    buttonDiv: {
      display: "inline-block",
      width: 120,
      height: 80,
      textAlign: "center"
    },
    iconCustom: {
      maxWidth: 40,
      maxHeight: 40
    },
    newValueLight: {
      animation: "vis-2-widgets-nils-fork-newValueAnimationLight 2s ease-in-out"
    },
    newValueDark: {
      animation: "vis-2-widgets-nils-fork-newValueAnimationDark 2s ease-in-out"
    }
  };
  f = class extends r {
    refDiv = b.createRef();
    updateTimeout = null;
    updateTimer1 = null;
    lastRxData = null;
    controlTimer = null;
    constructor(i) {
      super(i), this.state = {
        ...this.state,
        showDimmerDialog: null,
        object: {
          common: {},
          _id: "",
          type: ""
        },
        controlValue: null
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2SimpleState",
        visSet: "vis-2-widgets-nils-fork",
        visName: "SimpleState",
        visWidgetLabel: "simple_state",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                noBinding: false
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "data.noCard === true"
              },
              {
                name: "values_count",
                type: "number",
                hidden: "!data.withStates",
                default: 2,
                label: "values_count"
              },
              {
                name: "oid",
                type: "id",
                label: "oid",
                onChange: async (i, e, t, n) => {
                  var _a;
                  if (e.oid) {
                    const s = await n.getObject(e.oid);
                    if ((_a = s == null ? void 0 : s.common) == null ? void 0 : _a.states) {
                      if (Array.isArray(s.common.states)) {
                        const c = {};
                        s.common.states.forEach((o) => c[o] = o), s.common.states = c;
                      }
                      e.values_count = Object.keys(s.common.states).length, e.withStates = true, e.withNumber = false, Object.keys(s.common.states).forEach((c, o) => e[`value${o + 1}`] = s.common.states[c]), t(e);
                    } else (s == null ? void 0 : s.common) && (e.withNumber = s.common.type === "number", e.withStates = false, e.values_count = 0, t(e));
                  }
                }
              },
              {
                name: "noIcon",
                type: "checkbox",
                label: "no_icon",
                noBinding: false
              },
              {
                name: "icon",
                type: "image",
                hidden: "data.noIcon === true || !!data.iconSmall",
                label: "icon"
              },
              {
                name: "iconSmall",
                type: "icon64",
                label: "small_icon",
                hidden: "data.noIcon === true || !!data.icon"
              },
              {
                name: "iconEnabled",
                hidden: "data.noIcon === true || !!data.iconEnabledSmall",
                type: "image",
                label: "icon_active"
              },
              {
                name: "iconEnabledSmall",
                type: "icon64",
                label: "small_icon_active",
                hidden: "data.noIcon === true || !!data.iconEnabled"
              },
              {
                name: "iconSize",
                label: "icon_size",
                type: "slider",
                tooltip: "icon_size_tooltip",
                min: 0,
                max: 300,
                hidden: "data.noIcon === true || (!data.icon && !data.iconSmall && !data.iconEnabled && !data.iconEnabledSmall)"
              },
              {
                name: "color",
                type: "color",
                label: "color"
              },
              {
                name: "colorEnabled",
                type: "color",
                label: "color_active"
              },
              {
                name: "title",
                label: "title"
              },
              {
                name: "circleSize",
                label: "circle_size",
                type: "slider",
                min: 0,
                max: 200,
                default: 0,
                hidden: "!data.withNumber"
              },
              {
                name: "readOnly",
                type: "checkbox",
                label: "read_only",
                noBinding: false
              },
              {
                name: "unit",
                label: "unit"
              },
              {
                name: "timeout",
                label: "controlTimeout",
                tooltip: "In milliseconds",
                type: "number",
                min: 0,
                max: 2e3,
                hidden: "data.readOnly === true"
              },
              {
                name: "step",
                label: "step",
                type: "number",
                tooltip: "only_for_slider",
                hidden: "data.readOnly === true"
              }
            ]
          },
          {
            name: "values",
            indexFrom: 1,
            indexTo: "values_count",
            label: "values",
            fields: [
              {
                name: "value",
                label: "value"
              },
              {
                name: "icon",
                type: "image",
                label: "icon",
                hidden: (i, e) => !!i[`iconSmall${e}`]
              },
              {
                name: "iconSmall",
                type: "icon64",
                label: "small_icon",
                hidden: (i, e) => !!i[`icon${e}`]
              },
              {
                name: "color",
                type: "color",
                label: "color"
              },
              {
                name: "title",
                label: "title"
              },
              {
                name: "iconSize",
                label: "icon_size",
                type: "slider",
                min: 0,
                max: 300,
                hidden: (i, e) => !i[`icon${e}`]
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_simple_state.png"
      };
    }
    getWidgetInfo() {
      return f.getWidgetInfo();
    }
    async propertiesUpdate() {
      var _a, _b;
      const i = JSON.stringify(this.state.rxData);
      if (this.lastRxData === i) return;
      if (this.lastRxData = i, !this.state.rxData.oid || this.state.rxData.oid === "nothing_selected") {
        this.setState({
          object: {
            common: {},
            _id: "",
            type: ""
          }
        });
        return;
      }
      const e = await this.props.context.socket.getObject(this.state.rxData.oid);
      let t;
      if (e ? t = {
        common: e.common,
        _id: e._id,
        type: e.type
      } : t = {
        common: {},
        _id: "",
        type: ""
      }, t.common || (t.common = {}), t.common.type === "number" && (t.common.max === void 0 && (t.common.max = 100), t.common.min === void 0 && (t.common.min = 0)), t.common.states && Array.isArray(t.common.states)) {
        const n = {};
        t.common.states.forEach((s) => n[s] = s), t.common.states = n;
      }
      if (!t.common.icon && (t.type === "state" || t.type === "channel")) {
        const n = this.state.rxData.oid.split("."), s = await this.props.context.socket.getObject(n.slice(0, -1).join("."));
        if (!((_a = s == null ? void 0 : s.common) == null ? void 0 : _a.icon) && (t.type === "state" || t.type === "channel")) {
          const c = await this.props.context.socket.getObject(n.slice(0, -2).join("."));
          ((_b = c == null ? void 0 : c.common) == null ? void 0 : _b.icon) && (t.common.icon = c.common.icon, (c.type === "instance" || c.type === "adapter") && (t.common.icon = `../${c.common.name}.admin/${t.common.icon}`));
        } else t.common.icon = s.common.icon, (s.type === "instance" || s.type === "adapter") && (t.common.icon = `../${s.common.name}.admin/${t.common.icon}`);
      }
      t.common.name && typeof t.common.name == "object" && (t.common.name = t.common.name[r.getLanguage()] || t.common.name.en), JSON.stringify(this.state.object) !== JSON.stringify(t) && this.setState({
        object: t
      });
    }
    async componentDidMount() {
      super.componentDidMount(), await this.propertiesUpdate();
    }
    async onRxDataChanged() {
      await this.propertiesUpdate();
    }
    getValueData() {
      var _a;
      const i = this.state.values[`${this.state.rxData.oid}.val`], e = ((_a = this.state.object.common) == null ? void 0 : _a.states)[i];
      for (let t = 1; t <= this.state.rxData.values_count; t++) if (this.state.rxData[`value${t}`] === e) return {
        color: this.state.rxData[`color${t}`],
        icon: this.state.rxData[`icon${t}`] || this.state.rxData[`iconSmall${t}`],
        title: this.state.rxData[`title${t}`]
      };
      return null;
    }
    isOn(i) {
      return i || (i = this.state.values), this.state.object.common.type === "number" ? i[`${this.state.object._id}.val`] !== this.state.object.common.min : !!i[`${this.state.object._id}.val`];
    }
    getStateIcon(i) {
      var _a;
      let e = "";
      if (this.state.rxData.noIcon) return null;
      this.state.object.common.states && (e = (_a = this.getValueData()) == null ? void 0 : _a.icon), e || this.isOn() && (e = this.state.rxData.iconEnabled || this.state.rxData.iconEnabledSmall), e || (e = this.state.rxData.icon || this.state.rxData.iconSmall), e || (e = this.state.object.common.icon), i ?? (i = this.isOn());
      const t = this.getColor(i);
      if (e) {
        let n = 40, s = l.iconCustom;
        return this.state.rxData.iconSize && (n = parseFloat(this.state.rxData.iconSize), s = void 0), a.jsx(O, {
          src: e,
          style: {
            ...s,
            width: n,
            height: n,
            color: t
          }
        });
      }
      return i ? a.jsx(d, {
        color: "primary",
        style: {
          color: t
        }
      }) : a.jsx(u, {
        style: {
          color: t
        }
      });
    }
    getColor(i) {
      var _a;
      return this.state.object.common.states ? (_a = this.getValueData()) == null ? void 0 : _a.color : (i = i !== void 0 ? i : this.isOn(), i ? this.state.rxData.colorEnabled || this.state.object.common.color : this.state.rxData.color || this.state.object.common.color);
    }
    changeSwitch = () => {
      if (this.state.object.common.type === "number" || this.state.object.common.states) this.setState({
        showDimmerDialog: true
      });
      else {
        const i = JSON.parse(JSON.stringify(this.state.values)), e = `${this.state.object._id}.val`;
        this.state.object.common.type === "number" ? i[e] = i[e] === this.state.object.common.max ? this.state.object.common.min : this.state.object.common.max : i[e] = !i[e], this.setState({
          values: i
        }), this.props.context.setValue(this.state.rxData.oid, i[e]);
      }
    };
    setOnOff(i) {
      const e = JSON.parse(JSON.stringify(this.state.values)), t = `${this.state.object._id}.val`;
      e[t] = i ? this.state.object.common.max : this.state.object.common.min, this.setState({
        values: e
      }), this.props.context.setValue(this.state.rxData.oid, e[t]);
    }
    controlSpecificState(i) {
      const e = JSON.parse(JSON.stringify(this.state.values)), t = `${this.state.object._id}.val`;
      e[t] = i, this.setState({
        values: e
      }), this.props.context.setValue(this.state.rxData.oid, e[t]);
    }
    onStateUpdated(i) {
      this.state.controlValue && this.state.rxData.oid === i && this.setState({
        controlValue: {
          value: this.state.controlValue.value,
          changed: true
        }
      });
    }
    finishChanging() {
      if (this.state.controlValue) {
        const i = {
          controlValue: null
        };
        if (!this.state.controlValue.changed) {
          const e = JSON.parse(JSON.stringify(this.state.values));
          e[`${this.state.rxData.oid}.val`] = this.state.controlValue.value, i.values = e;
        }
        this.setState(i);
      }
    }
    renderDimmerDialog() {
      if (this.state.showDimmerDialog) {
        const i = this.state.object.common.min === 0 && (this.state.object.common.max === 100 || this.state.object.common.max === 1);
        return a.jsxs(g, {
          fullWidth: true,
          maxWidth: "sm",
          open: true,
          onClose: () => this.setState({
            showDimmerDialog: null
          }),
          children: [
            a.jsxs(v, {
              children: [
                this.state.rxData.title || r.getText(this.state.object.common.name),
                a.jsx(y, {
                  style: {
                    float: "right"
                  },
                  onClick: () => this.setState({
                    showDimmerDialog: null
                  }),
                  children: a.jsx(S, {})
                })
              ]
            }),
            a.jsx(j, {
              children: this.state.object.common.states ? a.jsx("div", {
                style: {
                  width: "100%",
                  textAlign: "center"
                },
                children: Object.keys(this.state.object.common.states).map((e, t) => a.jsx(m, {
                  style: this.state.values[`${this.state.object._id}.val`] !== e ? l.buttonInactive : void 0,
                  color: this.state.values[`${this.state.object._id}.val`] === e ? "primary" : "grey",
                  onClick: () => this.controlSpecificState(e),
                  children: this.state.object.common.states[e]
                }, `${e}_${t}`))
              }) : a.jsxs(a.Fragment, {
                children: [
                  a.jsxs("div", {
                    style: {
                      width: "100%",
                      marginBottom: 20
                    },
                    children: [
                      a.jsx(m, {
                        style: {
                          ...this.state.values[`${this.state.object._id}.val`] === this.state.object.common.min ? void 0 : l.buttonInactive,
                          width: "50%"
                        },
                        color: "grey",
                        onClick: () => this.setOnOff(false),
                        startIcon: i ? a.jsx(u, {}) : null,
                        children: i ? r.t("OFF").replace("vis_2_widgets_nils_", "") : this.state.object.common.min + (this.state.rxData.unit || this.state.object.common.unit || "")
                      }),
                      a.jsx(m, {
                        style: {
                          width: "50%",
                          ...this.state.values[`${this.state.object._id}.val`] === this.state.object.common.max ? void 0 : l.buttonInactive
                        },
                        color: "primary",
                        onClick: () => this.setOnOff(true),
                        startIcon: i ? a.jsx(d, {
                          color: "primary"
                        }) : null,
                        children: i ? r.t("ON").replace("vis_2_widgets_nils_", "") : this.state.object.common.max + (this.state.rxData.unit || this.state.object.common.unit || "")
                      })
                    ]
                  }),
                  a.jsx("div", {
                    style: {
                      width: "100%"
                    },
                    children: a.jsx(D, {
                      size: "small",
                      value: this.state.controlValue ? this.state.controlValue.value : this.state.values[`${this.state.object._id}.val`],
                      valueLabelFormat: (e) => {
                        var _a, _b;
                        return ((_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.isFloatComma) ? e.toString().replace(".", ",") : e.toString();
                      },
                      step: parseFloat(this.state.rxData.step) || 1,
                      valueLabelDisplay: "auto",
                      min: this.state.object.common.min,
                      max: this.state.object.common.max,
                      onChangeCommitted: () => this.finishChanging(),
                      onChange: (e, t) => {
                        var _a;
                        this.setState({
                          controlValue: {
                            value: t,
                            changed: !!((_a = this.state.controlValue) == null ? void 0 : _a.changed)
                          }
                        }, () => {
                          this.controlTimer && (clearTimeout(this.controlTimer), this.controlTimer = null), this.state.rxData.timeout ? this.controlTimer = setTimeout((n) => {
                            this.controlTimer = null, this.props.context.setValue(this.state.rxData.oid, n);
                          }, parseInt(this.state.rxData.timeout, 10) || 0, t) : this.props.context.setValue(this.state.rxData.oid, t);
                        });
                      }
                    })
                  })
                ]
              })
            })
          ]
        });
      }
      return null;
    }
    renderCircular() {
      var _a, _b, _c, _d, _e;
      const i = this.state.values[`${this.state.object._id}.val`], e = this.state.object;
      if (i == null) return null;
      if (e.common.min !== void 0 && i < e.common.min || e.common.max !== void 0 && i > e.common.max) return i + (this.state.rxData.unit || ((_a = this.state.object.common) == null ? void 0 : _a.unit) || "");
      let t = this.state.rxData.circleSize;
      return t || (t = ((_b = this.refDiv.current) == null ? void 0 : _b.offsetHeight) || 0, t > (((_c = this.refDiv.current) == null ? void 0 : _c.offsetWidth) || 0) && (t = ((_d = this.refDiv.current) == null ? void 0 : _d.offsetWidth) || 0)), t = t || 80, t < 60 ? null : (this.refDiv.current || (this.updateTimer1 || (this.updateTimer1 = setTimeout(() => {
        this.updateTimer1 = null, this.forceUpdate();
      }, 50))), a.jsx(w, {
        minValue: e.common.min,
        maxValue: e.common.max,
        size: t * 1.1,
        arcColor: this.props.context.theme.palette.primary.main,
        arcBackgroundColor: this.props.context.themeType === "dark" ? "#DDD" : "#222",
        startAngle: 0,
        endAngle: 360,
        handle1: {
          value: i
        },
        children: a.jsx("div", {
          style: {
            ...this.props.context.themeType === "dark" ? l.newValueDark : l.newValueLight,
            fontSize: Math.round(t / 8),
            fontWeight: "bold"
          },
          children: i + (this.state.rxData.unit || ((_e = this.state.object.common) == null ? void 0 : _e.unit) || "")
        }, `_${i}`)
      }));
    }
    renderWidgetBody(i) {
      var _a;
      super.renderWidgetBody(i);
      const e = JSON.stringify(this.state.rxData);
      this.lastRxData !== e && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
        this.updateTimeout = null, await this.propertiesUpdate();
      }, 50)));
      const t = this.isOn(), n = this.getStateIcon(t), s = this.getColor(t), c = this.state.object.common.states && ((_a = this.getValueData()) == null ? void 0 : _a.title);
      let o;
      this.state.object._id && (this.state.object.common.type === "number" || this.state.object.common.states) && (o = this.state.values[`${this.state.object._id}.val`], this.state.object.common.states && this.state.object.common.states[o] !== void 0 ? o = this.state.object.common.states[o] : o = this.formatValue(o));
      const x = this.state.rxData.noCard !== true && this.state.rxData.noCard !== "true" && !i.widget.usedInWidget && this.state.rxData.widgetTitle ? "calc(100% - 36px)" : "100%";
      !this.state.object.common.states && this.isOn() ? i.className = `${i.className} vis-on`.trim() : i.className = `${i.className} vis-off`.trim();
      const h = a.jsxs(a.Fragment, {
        children: [
          a.jsx("style", {
            children: `
@keyframes vis-2-widgets-nils-fork-newValueAnimationLight {
    0% {
        color: #00bd00;
    }
    80% {
        color: #008000;
    }
    100% {
        color: #000;
    }
}
@keyframes vis-2-widgets-nils-fork-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: #ffffff;
    }
}            
`
          }),
          this.renderDimmerDialog(),
          a.jsx("div", {
            style: {
              width: "100%",
              height: x
            },
            ref: this.refDiv,
            children: a.jsx("div", {
              style: {
                ...l.buttonDiv,
                width: "100%",
                height: "100%"
              },
              children: a.jsxs(m, {
                onClick: () => this.changeSwitch(),
                disabled: this.state.rxData.readOnly === true || this.state.rxData.readOnly === "true",
                color: !this.state.object.common.states && this.isOn() ? "primary" : "grey",
                style: {
                  ...l.button,
                  ...this.isOn() ? void 0 : l.buttonInactive
                },
                children: [
                  a.jsxs("div", {
                    style: l.topButton,
                    children: [
                      n ? a.jsx("div", {
                        style: {
                          ...!this.state.object.common.states && o !== void 0 && o !== null ? l.iconButton : l.iconButtonCenter,
                          height: this.state.rxData.iconSize ? "unset" : void 0
                        },
                        children: n
                      }) : null,
                      !this.state.object.common.states && o !== void 0 && o !== null ? a.jsx(_, {
                        component: "div",
                        sx: l.rightButton,
                        style: n ? {} : {
                          width: "100%",
                          left: 0,
                          justifyContent: "center"
                        },
                        children: this.renderCircular()
                      }) : null
                    ]
                  }),
                  a.jsx("div", {
                    style: {
                      ...l.text,
                      color: s
                    },
                    children: this.state.rxData.title || r.getText(this.state.object.common.name)
                  }),
                  this.state.object.common.states && o !== void 0 && o !== null ? a.jsx("div", {
                    style: {
                      ...l.value,
                      ...s ? void 0 : this.props.context.themeType === "dark" ? l.newValueDark : l.newValueLight,
                      color: s
                    },
                    children: c || o
                  }, `${c || o}`) : null
                ]
              })
            })
          })
        ]
      });
      return this.state.rxData.noCard === true || this.state.rxData.noCard === "true" || i.widget.usedInWidget ? h : this.wrapContent(h, null);
    }
  };
});
export {
  __tla,
  f as default
};
