import { B as e } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as t, E as n, H as r, I as i, L as a, P as o, Q as s, T as c, ft as l, n as u, pt as d, st as f, u as p } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { n as m, t as h } from "./ElectricBolt-jdviczbv.js";
import { t as g } from "./PowerSettingsNew-BNxDRF4G.js";
import { t as _ } from "./Thermostat-XvI2VZ3I.js";
import { t as v } from "./ObjectChart-mIZVGQw1.js";
import { t as y } from "./Generic-BOiMPpxz.js";
import { t as b } from "./dist-nezUW2fm.js";
var x = f(l(`path`, { d: `M22 11h-4.17l3.24-3.24-1.41-1.42L15 11h-2V9l4.66-4.66-1.42-1.41L13 6.17V2h-2v4.17L7.76 2.93 6.34 4.34 11 9v2H9L4.34 6.34 2.93 7.76 6.17 11H2v2h4.17l-3.24 3.24 1.41 1.42L9 13h2v2l-4.66 4.66 1.42 1.41L11 17.83V22h2v-4.17l3.24 3.24 1.42-1.41L13 15v-2h2l4.66 4.66 1.41-1.42L17.83 13H22z` }), `AcUnit`), S = f(l(`path`, { d: `M14.5 17c0 1.65-1.35 3-3 3s-3-1.35-3-3h2c0 .55.45 1 1 1s1-.45 1-1-.45-1-1-1H2v-2h9.5c1.65 0 3 1.35 3 3M19 6.5C19 4.57 17.43 3 15.5 3S12 4.57 12 6.5h2c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5S16.33 8 15.5 8H2v2h13.5c1.93 0 3.5-1.57 3.5-3.5m-.5 4.5H2v2h16.5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5v2c1.93 0 3.5-1.57 3.5-3.5S20.43 11 18.5 11` }), `Air`), C = f(l(`path`, { d: `m15.65 4.86-.07-.07c-.57-.62-.82-1.41-.67-2.2L15 2h-1.89l-.06.43c-.2 1.36.27 2.71 1.3 3.72l.07.06c.57.62.82 1.41.67 2.2l-.11.59h1.91l.06-.43c.21-1.36-.27-2.71-1.3-3.71m4 0-.07-.07c-.57-.62-.82-1.41-.67-2.2L19 2h-1.89l-.06.43c-.2 1.36.27 2.71 1.3 3.72l.07.06c.57.62.82 1.41.67 2.2l-.11.59h1.91l.06-.43c.21-1.36-.27-2.71-1.3-3.71M9.12 5l-7.18 6.79c-.6.56-.94 1.35-.94 2.18V20c0 1.66 1.34 3 3 3h13.75c.69 0 1.25-.56 1.25-1.25s-.56-1.25-1.25-1.25H12v-1h7.75c.69 0 1.25-.56 1.25-1.25S20.44 17 19.75 17H12v-1h8.75c.69 0 1.25-.56 1.25-1.25s-.56-1.25-1.25-1.25H12v-1h6.75c.69 0 1.25-.56 1.25-1.25S19.44 10 18.75 10H8.86c.64-1.11 1.48-2.58 1.49-2.61.09-.16.14-.33.14-.53 0-.26-.09-.5-.26-.7C10.22 6.12 9.12 5 9.12 5` }), `Dry`), w = f(l(`path`, { d: `M12 16c-1.95 0-2.1 1-3.34 1-1.19 0-1.42-1-3.33-1-1.95 0-2.09 1-3.33 1v2c1.9 0 2.17-1 3.35-1 1.19 0 1.42 1 3.33 1 1.95 0 2.08-1 3.32-1s1.37 1 3.32 1c1.91 0 2.14-1 3.33-1 1.18 0 1.45 1 3.35 1v-2c-1.24 0-1.38-1-3.33-1-1.91 0-2.14 1-3.33 1-1.24 0-1.39-1-3.34-1m8.34-4.66-1.37 1.37c-.19.18-.45.29-.71.29H17V9.65l1.32.97L19.5 9 12 3.5 4.5 9l1.18 1.61L7 9.65V13H5.74c-.27 0-.52-.11-.71-.29l-1.37-1.37-1.41 1.41 1.37 1.37c.56.56 1.33.88 2.12.88h12.51c.8 0 1.56-.32 2.12-.88l1.37-1.37zM13 13h-2v-2h2z` }), `Houseboat`), T = f(l(`path`, { d: `M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2m0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2m0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2` }), `MoreVert`), E = f(l(`path`, { d: `M23 5.5V20c0 2.2-1.8 4-4 4h-7.3c-1.08 0-2.1-.43-2.85-1.19L1 14.83s1.26-1.23 1.3-1.25c.22-.19.49-.29.79-.29.22 0 .42.06.6.16.04.01 4.31 2.46 4.31 2.46V4c0-.83.67-1.5 1.5-1.5S11 3.17 11 4v7h1V1.5c0-.83.67-1.5 1.5-1.5S15 .67 15 1.5V11h1V2.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5V11h1V5.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5` }), `PanTool`), D = f(l(`path`, { d: `M17 12h2L12 2 5.05 12H7l-3.9 6h6.92v4h3.96v-4H21z` }), `Park`), O = f(l(`path`, { d: `M11 12V6c0-1.66-1.34-3-3-3S5 4.34 5 6v6c-1.21.91-2 2.37-2 4 0 1.12.38 2.14 1 2.97V19h.02c.91 1.21 2.35 2 3.98 2s3.06-.79 3.98-2H12v-.03c.62-.83 1-1.85 1-2.97 0-1.63-.79-3.09-2-4m-6 4c0-.94.45-1.84 1.2-2.4L7 13V6c0-.55.45-1 1-1s1 .45 1 1v7l.8.6c.75.57 1.2 1.46 1.2 2.4zM18.62 4h-1.61l-3.38 9h1.56l.81-2.3h3.63l.8 2.3H22zm-2.15 5.39 1.31-3.72h.08l1.31 3.72z` }), `ThermostatAuto`), k = f(l(`path`, { d: `m6.76 4.84-1.8-1.79-1.41 1.41 1.79 1.79zM4 10.5H1v2h3zm9-9.95h-2V3.5h2zm7.45 3.91-1.41-1.41-1.79 1.79 1.41 1.41zm-3.21 13.7 1.79 1.8 1.41-1.41-1.8-1.79zM20 10.5v2h3v-2zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6m-1 16.95h2V19.5h-2zm-7.45-3.91 1.41 1.41 1.79-1.8-1.41-1.41z` }), `WbSunny`);
e();
var A = { AUTO: l(O, { style: { width: 24, height: 24 } }), MANUAL: l(E, { style: { width: 24, height: 24 } }), VACATION: l(w, { style: { width: 24, height: 24 } }), COOL: l(x, { style: { width: 24, height: 24 } }), COOLING: l(x, { style: { width: 24, height: 24 } }), DRY: l(C, { style: { width: 24, height: 24 } }), ECO: l(D, { style: { width: 24, height: 24 } }), FAN_ONLY: l(S, { style: { width: 24, height: 24 } }), HEAT: l(k, { style: { width: 24, height: 24 } }), HEATING: l(k, { style: { width: 24, height: 24 } }), OFF: l(g, { style: { width: 24, height: 24 } }) }, j = { thermostatCircleDiv: { width: `100%`, display: `flex`, flexDirection: `column`, justifyContent: `flex-end`, "& svg circle": { cursor: `pointer` }, "&>div": { margin: `auto`, "&>div": { top: `35% !important` } } }, moreButton: { position: `absolute`, top: 4, right: 4 }, thermostatButtonsDiv: { textAlign: `center`, display: `flex`, justifyContent: `center`, width: `100%`, position: `absolute`, bottom: 8, left: 0 }, thermostatNewValueLight: { animation: `vis-2-widgets-nils-fork-newValueAnimationLight 2s ease-in-out` }, thermostatNewValueDark: { animation: `vis-2-widgets-nils-fork-newValueAnimationDark 2s ease-in-out` }, thermostatDesiredTemp: { fontWeight: `bold`, display: `flex`, alignItems: `center`, width: `100%`, left: 0, transform: `none` }, tooltip: { pointerEvents: `none` } };
function M(e3) {
  var _a;
  let t2 = (_a = e3 == null ? void 0 : e3.common) == null ? void 0 : _a.states;
  if (Array.isArray(t2)) {
    let e4 = {};
    t2.forEach((t3) => e4[t3] = t3), t2 = e4;
  }
  let n2 = [];
  return t2 && Object.keys(t2).forEach((e4) => {
    let r2 = { value: e4, label: t2[e4] };
    r2.icon = A[(t2[e4] || ``).toUpperCase()], n2.push(r2);
  }), n2.length ? n2 : null;
}
var N = class e2 extends y {
  lastRxData = ``;
  customStyle = {};
  updateTimeout = null;
  constructor(e3) {
    super(e3), this.state = { ...this.state, showDialog: false, dialogTab: 0, size: 0, horizontal: false };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Thermostat`, visSet: `vis-2-widgets-nils-fork`, visWidgetLabel: `thermostat`, visName: `Thermostat`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox`, hidden: `!!data.externalDialog` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard || !!data.externalDialog` }, { name: `oid-temp-set`, type: `id`, label: `temperature_oid`, onChange: async (e3, t2, n2, r2) => {
      var _a;
      if (t2[e3.name] && ((_a = await r2.getObject(t2[e3.name])) == null ? void 0 : _a.common)) {
        let i2 = t2[e3.name].split(`.`);
        i2.pop();
        let a2 = await r2.getObjectViewSystem(`state`, `${i2.join(`.`)}.`, `${i2.join(`.`)}.\u9999`);
        if (a2) {
          let e4 = false, r3 = Object.values(a2);
          for (let n3 of r3) {
            let r4 = n3.common.role;
            if (r4 && r4.includes(`value.temperature`)) t2[`oid-temp-actual`] = n3._id, e4 = true;
            else if (r4 == null ? void 0 : r4.includes(`power`)) t2[`oid-power`] = n3._id, e4 = true;
            else if (r4 == null ? void 0 : r4.includes(`boost`)) t2[`oid-boost`] = n3._id, e4 = true;
            else if (r4 == null ? void 0 : r4.includes(`party`)) t2[`oid-party`] = n3._id, e4 = true;
            else if (r4 == null ? void 0 : r4.includes(`mode`)) {
              let r5 = M(n3);
              if (r5) {
                for (let n4 = 0; n4 < r5.length; n4++) {
                  let i3 = r5[n4];
                  (!t2[`title${n4 + 1}`] || n4 + 1 > t2.count) && (e4 = true, t2[`title${n4 + 1}`] = i3.label), (!t2[`value${n4 + 1}`] || n4 + 1 > t2.count) && (t2[`value${n4 + 1}`] = i3.value, e4 = true);
                }
                t2.count !== r5.length && (e4 = true, t2.count = r5.length);
              }
              t2[`oid-mode`] = n3._id, e4 = true;
            }
          }
          e4 && n2(t2);
        }
      }
    } }, { name: `oid-temp-actual`, type: `id`, label: `actual_oid` }, { name: `oid-humidity`, type: `id`, label: `humidity_oid` }, { name: `unit`, label: `unit` }, { name: `oid-power`, type: `id`, label: `power_oid` }, { name: `oid-mode`, type: `id`, label: `mode_oid`, onChange: async (e3, t2, n2, r2) => {
      if (t2[e3.name]) {
        let i2 = await r2.getObject(t2[e3.name]), a2 = (i2 == null ? void 0 : i2.type) === `state` ? M(i2) : null;
        if (a2) {
          let e4 = false;
          a2.forEach((n3, r3) => {
            (!t2[`title${r3 + 1}`] || r3 + 1 > t2.count) && (e4 = true, t2[`title${r3 + 1}`] = n3.label), (!t2[`value${r3 + 1}`] || r3 + 1 > t2.count) && (t2[`value${r3 + 1}`] = n3.value, e4 = true);
          }), t2.count !== a2.length && (e4 = true, t2.count = a2.length), e4 && n2(t2);
        }
      }
    } }, { name: `oid-boost`, type: `id`, label: `mode_boost` }, { name: `oid-party`, type: `id`, label: `mode_party` }, { name: `step`, type: `select`, disabled: `!data["oid-temp-set"]`, label: `step`, noTranslation: true, options: [`0.5`, `1`], default: `1` }, { name: `timeout`, label: `controlTimeout`, tooltip: `timeout_tooltip`, type: `slider`, min: 0, max: 2e3, default: 500 }, { name: `externalDialog`, label: `use_as_dialog`, type: `checkbox`, tooltip: `use_as_dialog_tooltip` }, { name: `count`, type: `slider`, min: 1, max: 9, label: `modes_count`, default: 2, hidden: `!data["oid-mode"]` }] }, { name: `modes`, label: `group_modes`, indexFrom: 1, indexTo: `count`, hidden: `!data["oid-mode"]`, fields: [{ name: `hide`, type: `checkbox`, label: `hide`, noBinding: false }, { name: `title`, label: `title`, hidden: `data["hide" + index] === true` }, { name: `tooltip`, label: `tooltip`, hidden: `data["hide" + index] === true || !!data["title" + index]` }, { name: `icon`, type: `image`, label: `icon`, hidden: `data["hide" + index] === true || !!data["iconSmall" + index]` }, { name: `iconSmall`, type: `icon64`, label: `small_icon`, hidden: `data["hide" + index] === true || !!data["icon" + index]` }, { name: `color`, type: `color`, label: `color`, hidden: `data["hide" + index] === true` }, { name: `noText`, type: `checkbox`, label: `no_text`, noBinding: false, hidden: `data["hide" + index] === true || data["noIcon" + index] === true` }, { name: `noIcon`, type: `checkbox`, label: `no_icon`, noBinding: false, hidden: `data["hide" + index] === true || data["noText" + index] === true || !data["title" + index]` }, { name: `value`, type: `text`, label: `value`, hidden: `data["hide" + index] === true` }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_thermostat.png` };
  }
  async thermostatReadObjects() {
    var _a, _b, _c, _d;
    let e3 = JSON.stringify(this.state.rxData);
    if (this.lastRxData === e3) return;
    let t2 = {};
    this.lastRxData = e3;
    let n2 = [];
    this.state.rxData[`oid-mode`] && this.state.rxData[`oid-mode`] !== `nothing_selected` && n2.push(this.state.rxData[`oid-mode`]), this.state.rxData[`oid-temp-set`] && this.state.rxData[`oid-temp-set`] !== `nothing_selected` && n2.push(this.state.rxData[`oid-temp-set`]), this.state.rxData[`oid-temp-actual`] && this.state.rxData[`oid-temp-actual`] !== `nothing_selected` && n2.push(this.state.rxData[`oid-temp-actual`]), this.state.rxData[`oid-humidity`] && this.state.rxData[`oid-humidity`] !== `nothing_selected` && n2.push(this.state.rxData[`oid-humidity`]);
    let r2 = n2.length ? await this.props.context.socket.getObjectsById(n2) : {};
    if (this.state.rxData[`oid-mode`] && this.state.rxData[`oid-mode`] !== `nothing_selected`) {
      let e4 = r2[this.state.rxData[`oid-mode`]];
      if (e4) {
        t2.modeObject = { common: e4.common, _id: e4._id };
        let n3 = M(e4);
        t2.modes = [];
        let r3 = parseInt(this.state.rxData.count, 10) || 10;
        n3 == null ? void 0 : n3.forEach((e5, n4) => {
          if (this.state.rxData[`hide${n4 + 1}`] === true || this.state.rxData[`hide${n4 + 1}`] === `true` || n4 >= r3) return;
          let i3 = this.state.rxData[`noIcon${n4 + 1}`] !== true && this.state.rxData[`noIcon${n4 + 1}`] !== `true` ? this.state.rxData[`icon${n4 + 1}`] || this.state.rxData[`iconSmall${n4 + 1}`] || !!A[(e5.label || ``).toUpperCase()] : void 0, a3 = { value: this.state.rxData[`value${n4 + 1}`] || e5.value, tooltip: this.state.rxData[`tooltip${n4 + 1}`] || e5.label, icon: i3, original: e5.label, label: i3 && (this.state.rxData[`noText${n4 + 1}`] === true || this.state.rxData[`noText${n4 + 1}`] === `true`) ? null : this.state.rxData[`title${n4 + 1}`] || e5.label, color: this.state.rxData[`color${n4 + 1}`] };
          a3.label && this.state.rxData[`noText${n4 + 1}`] !== true && this.state.rxData[`noText${n4 + 1}`] !== `true` && a3.icon === true && !this.state.rxData[`title${n4 + 1}`] && (a3.label = null), t2.modes.push(a3);
        });
        for (let e5 = (n3 == null ? void 0 : n3.length) || 0; e5 < r3; e5++) {
          if (this.state.rxData[`hide${e5 + 1}`] === true || this.state.rxData[`hide${e5 + 1}`] === `true`) continue;
          let n4 = this.state.rxData[`noIcon${e5 + 1}`] !== true && this.state.rxData[`noIcon${e5 + 1}`] !== `true` ? this.state.rxData[`icon${e5 + 1}`] || this.state.rxData[`iconSmall${e5 + 1}`] || !!A[(this.state.rxData[`title${e5 + 1}`] || ``).toUpperCase()] : void 0;
          t2.modes.push({ tooltip: this.state.rxData[`tooltip${e5 + 1}`], icon: n4, original: this.state.rxData[`title${e5 + 1}`], label: n4 && (this.state.rxData[`noText${e5 + 1}`] === true || this.state.rxData[`noText${e5 + 1}`] === `true`) ? null : this.state.rxData[`title${e5 + 1}`], value: this.state.rxData[`value${e5 + 1}`], color: this.state.rxData[`color${e5 + 1}`] });
        }
      } else t2.modes = null;
    } else t2.modes = null;
    if (this.state.rxData[`oid-temp-set`] && this.state.rxData[`oid-temp-set`] !== `nothing_selected`) {
      let e4 = r2[this.state.rxData[`oid-temp-set`]];
      t2.min = ((_a = e4 == null ? void 0 : e4.common) == null ? void 0 : _a.min) === void 0 ? 12 : e4.common.min, t2.max = ((_b = e4 == null ? void 0 : e4.common) == null ? void 0 : _b.max) === void 0 ? 30 : e4.common.max, t2.tempObject = { common: e4.common, _id: e4._id };
    } else t2.tempObject = null, t2.max = null, t2.min = null;
    if (this.state.rxData[`oid-temp-actual`] && this.state.rxData[`oid-temp-actual`] !== `nothing_selected`) {
      let e4 = r2[this.state.rxData[`oid-temp-actual`]];
      t2.tempStateObject = { common: e4.common, _id: e4._id };
    } else t2.tempStateObject = null;
    if (this.state.rxData[`oid-humidity`] && this.state.rxData[`oid-humidity`] !== `nothing_selected`) {
      let e4 = r2[this.state.rxData[`oid-humidity`]];
      t2.humidityObject = e4 ? { common: e4.common, _id: e4._id } : null;
    } else t2.humidityObject = null;
    let i2 = (_d = (_c = this.props.context.systemConfig) == null ? void 0 : _c.common) == null ? void 0 : _d.defaultHistory, a2 = y.getHistoryInstance(t2.tempObject, i2), o2 = y.getHistoryInstance(t2.tempStateObject, i2);
    t2.isChart = !!a2 || !!o2, Object.keys(t2).find((e4) => JSON.stringify(this.state[e4]) !== JSON.stringify(t2[e4])) && this.setState(t2);
  }
  async componentDidMount() {
    super.componentDidMount(), await this.thermostatReadObjects();
  }
  async onRxDataChanged() {
    await this.thermostatReadObjects();
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  formatValue(e3, t2) {
    var _a;
    return typeof e3 == `number` && (e3 = t2 === 0 ? Math.round(e3) : Math.round(e3 * 100) / 100, ((_a = this.props.context.systemConfig) == null ? void 0 : _a.common) && this.props.context.systemConfig.common.isFloatComma && (e3 = e3.toString().replace(`.`, `,`))), e3 == null ? `` : e3.toString();
  }
  renderChartDialog() {
    var _a, _b, _c, _d;
    return this.state.showDialog ? d(o, { sx: { "& .MuiDialog-paper": { height: `100%` } }, maxWidth: `lg`, fullWidth: true, open: true, onClose: () => this.setState({ showDialog: false }), children: [d(a, { children: [this.state.rxData.widgetTitle, l(r, { style: { float: `right` }, onClick: () => this.setState({ showDialog: false }), children: l(p, {}) })] }), l(i, { children: this.state.dialogTab === 1 && l(`div`, { style: { height: `100%` }, children: l(v, { t: (e3) => y.t(e3), lang: y.getLanguage(), socket: this.props.context.socket, obj: this.state.tempStateObject || this.state.tempObject, obj2: this.state.tempStateObject ? this.state.tempObject : null, objLineType: this.state.tempStateObject ? `line` : `step`, obj2LineType: `step`, themeType: this.props.context.themeType, historyInstance: y.getHistoryInstance(this.state.tempStateObject || this.state.tempObject, ((_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory) || `history.0`), historyInstance2: y.getHistoryInstance(this.state.tempStateObject, ((_d = (_c = this.props.context.systemConfig) == null ? void 0 : _c.common) == null ? void 0 : _d.defaultHistory) || `history.0`), noToolbar: false, systemConfig: this.props.context.systemConfig, dateFormat: this.props.context.systemConfig.common.dateFormat }) }) })] }) : null;
  }
  componentDidUpdate(e3, t2) {
    var _a;
    if (super.componentDidUpdate(e3, t2), (_a = this.refService) == null ? void 0 : _a.current) {
      let e4 = this.refService.current.clientWidth, t3 = this.refService.current.clientHeight, n2 = e4, r2 = this.props.context.views[this.props.view].widgets[this.props.id];
      !this.state.rxData.noCard && !r2.usedInWidget && (t3 -= 32, e4 -= 32);
      let i2 = this.state.rxData.widgetTitle && !this.state.rxData.noCard && !r2.usedInWidget, a2 = this.thermIsWithModeButtons() || this.thermIsWithPowerButton();
      i2 && a2 ? t3 -= 64 : i2 ? t3 -= 36 : a2 && (t3 -= 28), t3 < 0 && (t3 = 0), n2 = e4 > t3 ? t3 : e4, n2 < 80 && (n2 = 0), n2 !== this.state.size && this.setState({ size: n2 });
    }
  }
  thermIsWithPowerButton() {
    return !!this.state.rxData[`oid-power`] && this.state.rxData[`oid-power`] !== `nothing_selected`;
  }
  thermIsWithModeButtons() {
    var _a;
    return (((_a = this.state.modes) == null ? void 0 : _a.length) || this.state.rxData[`oid-party`] || this.state.rxData[`oid-boost`]) && (!this.state.rxData[`oid-power`] || this.state.values[`${this.state.rxData[`oid-power`]}.val`]);
  }
  onCommand(e3) {
    let t2 = super.onCommand(e3);
    if (t2 === false) {
      if (e3 === `openDialog`) return this.setState({ dialog: true }), true;
      if (e3 === `closeDialog`) return this.setState({ dialog: false }), true;
    }
    return t2;
  }
  renderWidgetBody(e3) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q;
    super.renderWidgetBody(e3), this.customStyle = {}, this.state.rxStyle && (this.state.rxStyle[`font-weight`] && (this.customStyle.fontWeight = this.state.rxStyle[`font-weight`]), this.state.rxStyle[`font-size`] && (this.customStyle.fontSize = this.state.rxStyle[`font-size`]), this.state.rxStyle[`font-family`] && (this.customStyle.fontFamily = this.state.rxStyle[`font-family`]), this.state.rxStyle[`font-style`] && (this.customStyle.fontStyle = this.state.rxStyle[`font-style`]), this.state.rxStyle[`word-spacing`] && (this.customStyle.wordSpacing = this.state.rxStyle[`word-spacing`]), this.state.rxStyle[`letter-spacing`] && (this.customStyle.letterSpacing = this.state.rxStyle[`letter-spacing`]));
    let f2 = !this.state.rxData.noCard && !e3.widget.usedInWidget, v2 = this.state.rxData.widgetTitle && f2, x2 = JSON.stringify(this.state.rxData);
    this.lastRxData !== x2 && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
      this.updateTimeout = null, await this.thermostatReadObjects();
    }, 50)));
    let S2 = this.state.values[`${this.state.rxData[`oid-temp-set`]}.val`];
    S2 === void 0 && (S2 = null), S2 !== null && (this.state.min === null || this.state.min === void 0 || S2 < this.state.min) ? S2 = this.state.min : S2 !== null && (this.state.max === null || this.state.max === void 0 || S2 > this.state.max) && (S2 = this.state.max), S2 === null && this.state.min !== null && this.state.min !== void 0 && this.state.max !== null && this.state.max !== void 0 && (S2 = (this.state.max - this.state.min) / 2 + this.state.min);
    let C2 = this.state.values[`${this.state.rxData[`oid-temp-actual`]}.val`];
    C2 === void 0 && (C2 = null);
    let w2 = this.state.values[`${this.state.rxData[`oid-humidity`]}.val`], E2 = Math.round(this.state.size / 25);
    E2 < 8 && (E2 = 8);
    let D2 = this.state.isChart ? l(r, { style: { ...v2 ? void 0 : j.moreButton, right: this.state.rxData.externalDialog || v2 ? void 0 : 4, left: this.state.rxData.externalDialog ? 16 : void 0, top: this.state.rxData.externalDialog ? 16 : v2 ? void 0 : 4, zIndex: 2 }, onClick: () => this.setState({ showDialog: true }), children: l(T, {}) }) : null;
    C2 = C2 === null ? null : this.formatValue(C2);
    let O2 = this.thermIsWithModeButtons(), k2 = this.thermIsWithPowerButton(), M2 = ((_e = (_d = (_c = (_b = (_a = this.props.customSettings) == null ? void 0 : _a.viewStyle) == null ? void 0 : _b.overrides) == null ? void 0 : _c.palette) == null ? void 0 : _d.primary) == null ? void 0 : _e.main) || ((_f = this.props.context.theme) == null ? void 0 : _f.palette.primary.main) || `#448aff`, N2 = [];
    if (O2) {
      if (((_g = this.state.modes) == null ? void 0 : _g.length) && (N2 = this.state.modes.map((e4, n2) => {
        let i2 = e4.icon === true ? A[(e4.original || ``).toUpperCase()] : e4.icon ? l(u, { src: e4.icon, style: { width: 24, height: 24 } }) : null, a2 = this.state.values[`${this.state.rxData[`oid-mode`]}.val`];
        return a2 = a2 == null ? `null` : a2.toString(), i2 && !e4.label ? l(c, { title: e4.tooltip, slotProps: { popper: { sx: j.tooltip } }, children: l(r, { color: a2 === e4.value ? `primary` : `inherit`, style: a2 === e4.value || !e4.color ? void 0 : { color: e4.color }, onClick: () => {
          var _a2, _b2, _c2, _d2;
          let t2 = e4.value;
          ((_b2 = (_a2 = this.state.modeObject) == null ? void 0 : _a2.common) == null ? void 0 : _b2.type) === `number` ? t2 = parseFloat(t2) : ((_d2 = (_c2 = this.state.modeObject) == null ? void 0 : _c2.common) == null ? void 0 : _d2.type) === `boolean` && (t2 = t2 === `true` || t2 === true || t2 === `1` || t2 === 1);
          let n3 = JSON.parse(JSON.stringify(this.state.values));
          n3[`${this.state.rxData[`oid-mode`]}.val`] = t2, this.setState({ values: n3 }), this.props.context.setValue(this.state.rxData[`oid-mode`], t2);
        }, children: i2 }) }, `${n2}_${e4.value}`) : l(t, { color: a2 === e4.value ? `primary` : `inherit`, onClick: () => {
          var _a2, _b2, _c2, _d2;
          let t2 = e4.value;
          ((_b2 = (_a2 = this.state.modeObject) == null ? void 0 : _a2.common) == null ? void 0 : _b2.type) === `number` ? t2 = parseFloat(t2) : ((_d2 = (_c2 = this.state.modeObject) == null ? void 0 : _c2.common) == null ? void 0 : _d2.type) === `boolean` && (t2 = t2 === `true` || t2 === true || t2 === `1` || t2 === 1);
          let n3 = JSON.parse(JSON.stringify(this.state.values));
          n3[`${this.state.rxData[`oid-mode`]}.val`] = t2, this.setState({ values: n3 }), this.props.context.setValue(this.state.rxData[`oid-mode`], t2);
        }, startIcon: i2, children: e4.label }, `${n2}_${e4.value}`);
      })), this.state.rxData[`oid-party`]) {
        let e4 = this.state.values[`${this.state.rxData[`oid-party`]}.val`];
        e4 = e4 == null ? false : e4 === `1` || e4 === `true` || e4 === true, N2.push(l(t, { color: e4 ? `primary` : `inherit`, onClick: () => {
          let e5 = this.state.values[`${this.state.rxData[`oid-party`]}.val`];
          e5 = e5 == null ? false : e5 === `1` || e5 === `true` || e5 === true;
          let t2 = JSON.parse(JSON.stringify(this.state.values));
          t2[`${this.state.rxData[`oid-party`]}.val`] = !e5, this.setState({ values: t2 }), this.props.context.setValue(this.state.rxData[`oid-party`], !e5);
        }, startIcon: l(m, {}), children: y.t(`Party`) }, `party`));
      }
      if (this.state.rxData[`oid-boost`]) {
        let e4 = this.state.values[`${this.state.rxData[`oid-boost`]}.val`];
        e4 = e4 == null ? false : e4 === `1` || e4 === `true` || e4 === true, N2.push(l(t, { color: e4 ? `primary` : `inherit`, onClick: () => {
          let e5 = this.state.values[`${this.state.rxData[`oid-boost`]}.val`];
          e5 = e5 == null ? false : e5 === `1` || e5 === `true` || e5 === true;
          let t2 = JSON.parse(JSON.stringify(this.state.values));
          t2[`${this.state.rxData[`oid-boost`]}.val`] = !e5, this.setState({ values: t2 }), this.props.context.setValue(this.state.rxData[`oid-boost`], !e5);
        }, startIcon: l(h, {}), children: y.t(`Boost`) }, `boost`));
      }
    }
    k2 && N2.push(l(c, { title: y.t(`power`).replace(`vis_2_widgets_nils_`, ``), slotProps: { popper: { sx: j.tooltip } }, children: l(r, { color: this.state.values[`${this.state.rxData[`oid-power`]}.val`] ? `primary` : `inherit`, onClick: () => {
      let e4 = JSON.parse(JSON.stringify(this.state.values)), t2 = `${this.state.rxData[`oid-power`]}.val`;
      e4[t2] = !e4[t2], this.setState({ values: e4 }), this.props.context.setValue(this.state.rxData[`oid-power`], e4[t2]);
    }, children: l(g, {}) }) }, `power`));
    let P = d(n, { component: `div`, sx: j.thermostatCircleDiv, style: { height: v2 ? `calc(100% - 36px)` : `100%` }, children: [l(`style`, { children: `
@keyframes vis-2-widgets-nils-fork-newValueAnimationLight {
    0% {
        color: #00bd00;
    },
    80% {
        color: #008000;
    },
    100% {
        color: #000;
    }
}

@keyframes vis-2-widgets-nils-fork-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: #ffffff;
    }
}                          
                            ` }), v2 ? null : D2, this.state.size && this.state.tempObject ? d(b, { minValue: this.state.min === null || this.state.min === void 0 ? 12 : this.state.min, maxValue: this.state.max === null || this.state.max === void 0 ? 30 : this.state.max, size: this.state.size, arcColor: M2, arcBackgroundColor: this.props.context.themeType === `dark` ? `#DDD` : `#222`, startAngle: 40, handleSize: E2, endAngle: 320, handle1: { value: S2, onChange: (e4) => {
      let t2 = JSON.parse(JSON.stringify(this.state.values));
      this.state.rxData.step === `0.5` ? t2[`${this.state.rxData[`oid-temp-set`]}.val`] = Math.round(e4 * 2) / 2 : t2[`${this.state.rxData[`oid-temp-set`]}.val`] = Math.round(e4), this.setState({ values: t2 });
    } }, onControlFinished: () => this.props.context.setValue(this.state.rxData[`oid-temp-set`], this.state.values[`${this.state.rxData[`oid-temp-set`]}.val`]), children: [S2 === null ? null : l(c, { title: y.t(`desired_temperature`), slotProps: { popper: { sx: j.tooltip } }, children: d(`div`, { style: { ...j.thermostatDesiredTemp, fontSize: Math.round(this.state.size / 6), ...this.customStyle }, children: [l(_, { style: { width: this.state.size / 8, height: this.state.size / 8 } }), d(`div`, { style: { display: `flex`, alignItems: `top`, ...this.customStyle }, children: [this.formatValue(S2), l(`span`, { style: { fontSize: Math.round(this.state.size / 12), fontWeight: `normal` }, children: this.state.rxData.unit || ((_i = (_h = this.state.tempObject) == null ? void 0 : _h.common) == null ? void 0 : _i.unit) })] })] }) }), C2 === null ? null : l(c, { title: y.t(`actual_temperature`), slotProps: { popper: { sx: j.tooltip } }, children: d(`div`, { style: { ...this.props.context.themeType === `dark` ? j.thermostatNewValueDark : j.thermostatNewValueLight, fontSize: Math.round(this.state.size * 0.6 / 6), opacity: 0.7, ...this.customStyle }, children: [C2, this.state.rxData.unit || ((_k = (_j = this.state.tempStateObject) == null ? void 0 : _j.common) == null ? void 0 : _k.unit)] }, `${C2}valText`) })] }) : this.state.tempObject ? d(`div`, { style: { width: `100%` }, children: [l(s, { style: { width: `calc(100% - 50px)`, display: `inline-block` }, min: this.state.min === null || this.state.min === void 0 ? 12 : this.state.min, max: this.state.max === null || this.state.max === void 0 ? 30 : this.state.max, step: this.state.step || 0.5, value: S2, valueLabelDisplay: `auto`, onChange: (e4, t2) => {
      let n2 = JSON.parse(JSON.stringify(this.state.values));
      this.state.rxData.step === `0.5` ? n2[`${this.state.rxData[`oid-temp-set`]}.val`] = Math.round(t2 * 2) / 2 : n2[`${this.state.rxData[`oid-temp-set`]}.val`] = Math.round(t2), this.setState({ values: n2 });
    }, onChangeCommitted: () => this.props.context.setValue(this.state.rxData[`oid-temp-set`], this.state.values[`${this.state.rxData[`oid-temp-set`]}.val`]) }), d(`div`, { style: { textAlign: `center`, display: `inline-block`, flexDirection: `column`, width: 50 }, children: [S2 === null ? null : l(c, { title: y.t(`desired_temperature`), slotProps: { popper: { sx: j.tooltip } }, children: d(`div`, { style: { ...j.thermostatDesiredTemp, fontSize: 12, ...this.customStyle }, children: [l(_, { style: { width: 24, height: 24 } }), d(`div`, { style: { display: `flex`, alignItems: `top`, ...this.customStyle }, children: [this.formatValue(S2), l(`span`, { style: { fontSize: 10, fontWeight: `normal` }, children: this.state.rxData.unit || ((_m = (_l = this.state.tempObject) == null ? void 0 : _l.common) == null ? void 0 : _m.unit) })] })] }) }), C2 === null ? null : l(c, { title: y.t(`actual_temperature`), slotProps: { popper: { sx: j.tooltip } }, children: d(`div`, { style: { ...this.props.context.themeType === `dark` ? j.thermostatNewValueDark : j.thermostatNewValueLight, fontSize: 10, opacity: 0.7, ...this.customStyle }, children: [C2, this.state.rxData.unit || ((_o = (_n = this.state.tempStateObject) == null ? void 0 : _n.common) == null ? void 0 : _o.unit)] }, `${C2}valText`) })] })] }) : null, this.state.rxData[`oid-humidity`] && this.state.rxData[`oid-humidity`] !== `nothing_selected` ? l(c, { title: y.t(`humidity`), slotProps: { popper: { sx: j.tooltip } }, children: l(`div`, { style: { textAlign: `center`, opacity: 0.7, ...this.customStyle }, children: w2 == null ? y.t(`humidity`) : `${this.formatValue(w2)}${((_q = (_p = this.state.humidityObject) == null ? void 0 : _p.common) == null ? void 0 : _q.unit) || `%`}` }) }) : null, l(`div`, { style: { ...j.thermostatButtonsDiv, bottom: 8 }, children: N2 }), this.renderChartDialog()] });
    return this.state.rxData.externalDialog && !this.props.editMode ? this.state.dialog ? d(o, { open: true, onClose: () => this.setState({ dialog: false }), children: [d(a, { children: [this.state.rxData.widgetTitle, l(r, { style: { float: `right`, zIndex: 2 }, onClick: () => this.setState({ dialog: false }), children: l(p, {}) })] }), l(i, { style: { minWidth: 150, minHeight: 150 }, children: P })] }) : null : f2 ? this.wrapContent(P, v2 ? D2 : null, { textAlign: `center` }) : P;
  }
};
export {
  N as default
};
