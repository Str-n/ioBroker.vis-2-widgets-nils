let b, P_, v_, s, re, O_;
let __tla = (async () => {
  const f = "__mf_init____mf__virtual/__mfe_internal__vis2nilsForkWidgets__mf_v__runtimeInit__mf_v__.js__";
  let m = globalThis[f];
  if (!m) {
    let _, o;
    const n = new Promise((t, i) => {
      _ = t, o = i;
    });
    m = globalThis[f] = {
      initPromise: n,
      initResolve: _,
      initReject: o
    }, typeof window > "u" && _({
      loadRemote: function() {
        return Promise.resolve(void 0);
      },
      loadShare: function() {
        return Promise.resolve(void 0);
      }
    });
  }
  const r = m.initPromise, a = r.then((_) => _.loadShare("@iobroker/adapter-react-v5", {
    customShareInfo: {
      shareConfig: {
        singleton: true,
        strictVersion: false,
        requiredVersion: "*"
      }
    }
  })), e = await a.then((_) => typeof _ == "function" ? _() : _);
  e.__esModule ? e.default : e.default;
  let l, c, d, I, u, S, C, g, p, T, D, h, O, R, v, P, x, E, F, M, w, y, A, B, V, L, W, j, N, G, U, k, H, q, z, J, K, X, Q, Y, Z, $, __, e_, m_, o_, f_, n_, t_, i_, r_, a_, l_, c_, s_, d_, I_, u_, S_, C_, g_, p_, T_, D_, h_, R_, b_, x_, E_, F_, M_, w_, y_, A_, B_, V_, L_, W_, j_, N_, G_, U_, k_, H_, q_, z_, J_, K_, X_, Q_, Y_, Z_, $_, _e, ee, me, oe, fe, ne, te, ie, ae, le, ce, se, de, Ie, ue, Se, Ce, ge, pe, Te, De, he, Oe, Re, be, ve, Pe, xe, Ee, Fe;
  ({ Theme: l, GenericApp: c, I18n: s, printPrompt: d, ColorPicker: I, ComplexCron: u, copy: S, CustomModal: C, FileBrowser: g, FileBrowserClass: p, EXTENSIONS: T, FileViewer: D, FileViewerClass: h, getSystemIcon: O, getSelectIdIcon: R, Icon: b, IconPicker: v, IconSelector: P, Image: x, DeviceTypeSelector: E, DeviceTypeIcon: F, STATES_NAME_ICONS: M, extendDeviceTypeTranslation: w, Cleaner: y, DoorClosed: A, DoorOpened: B, FireOff: V, FireOn: L, FloodOff: W, FloodOn: j, Gate: N, HeatValve: G, Home: U, Humidity: k, IconHome: H, Jalousie: q, Material: z, MotionOff: J, MotionOn: K, PushButton: X, RepairExpert: Q, RGB: Y, Socket: Z, Thermometer: $, ThermometerSimple: __, Thermostat: e_, Valve: m_, WindowClosed: o_, WindowOpened: f_, WindowTilted: n_, Loader: t_, Logo: i_, MDUtils: r_, ObjectBrowserClass: a_, ObjectBrowser: l_, getSelectIdIconFromObjects: c_, ITEM_IMAGES: s_, InfoBox: d_, Router: I_, SaveCloseButtons: u_, Schedule: S_, SelectWithIcon: C_, TabContainer: g_, TabContent: p_, TabHeader: T_, TableResize: D_, TextWithIcon: h_, ToggleThemeMenu: O_, TreeTable: R_, UploadImage: b_, Utils: v_, withWidth: P_, cron2state: x_, SimpleCron: E_, convertCronToText: F_, LoaderVendor: M_, LoaderPT: w_, LoaderMV: y_, LoaderNW: A_, IconAdapter: B_, IconAlias: V_, IconButtonImage: L_, IconChannel: W_, IconClearFilter: j_, IconClosed: N_, IconCopy: G_, IconDevice: U_, IconDocument: k_, IconDocumentReadOnly: H_, IconExpert: q_, IconFx: z_, IconInstance: J_, IconLogout: K_, IconNoIcon: X_, IconOpen: Q_, IconState: Y_, IconVacuum: Z_, DialogComplexCron: $_, ComplexCronDialog: _e, DialogConfirm: ee, Confirm: me, DialogCron: oe, Cron: fe, DialogError: ne, Error: te, DialogMessage: ie, Message: re, DialogSelectID: ae, SelectID: le, DialogSelectFile: ce, SelectFile: se, DialogSimpleCron: de, SimpleCronDialog: Ie, DialogTextInput: ue, TextInput: Se, Connection: Ce, PROGRESS: ge, ERRORS: pe, PERMISSION_ERROR: Te, AdminConnection: De, dictionary: he, LegacyConnection: Oe, pattern2RegEx: Re, getAttrInObject: be, setAttrInObject: ve, iobUriToString: Pe, iobUriParse: xe, iobUriRead: Ee, moduleFederationShared: Fe } = e);
})();
export {
  b as _,
  __tla,
  P_ as a,
  v_ as b,
  s as c,
  re as d,
  O_ as e
};
