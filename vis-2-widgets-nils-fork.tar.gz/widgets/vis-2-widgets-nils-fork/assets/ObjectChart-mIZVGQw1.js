import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { B as t, T as n, x as r } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { B as i, E as a, G as o, W as s, X as c, Y as l, Z as u, a as d, ft as f, o as p, pt as m, w as h, z as g } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { $ as _, $t as v, A as y, An as b, B as x, Bn as S, Bt as C, C as ee, Cn as te, Ct as ne, Dn as re, Dt as w, Et as T, F as E, Fn as ie, Ft as ae, G as oe, Gt as se, H as ce, Hn as D, Ht as le, I as ue, In as de, It as fe, J as pe, K as me, Kt as he, L as ge, Ln as _e, Lt as ve, M as ye, Mn as O, Mt as be, N as xe, Nn as k, Nt as Se, On as A, Ot as j, P as Ce, Pn as we, Pt as Te, Q as Ee, Qt as De, R as Oe, Rn as ke, Rt as Ae, S as je, Sn as M, St as Me, Tt as N, U as Ne, Un as P, Ut as Pe, V as Fe, Vn as Ie, Vt as Le, W as Re, Wt as ze, X as Be, Y as Ve, Z as He, Zt as Ue, _ as We, _n as F, _t as Ge, a as Ke, an as qe, at as Je, b as Ye, bt as Xe, c as Ze, cn as Qe, ct as $e, d as et, dn as I, dt as tt, en as nt, et as rt, f as it, fn as L, ft as at, g as ot, gt as st, h as ct, hn as R, ht as lt, i as ut, in as dt, it as ft, j as pt, jt as mt, kn as z, kt as ht, l as gt, ln as _t, lt as vt, m as yt, mn as B, mt as bt, n as xt, nn as St, o as Ct, on as wt, p as Tt, pn as Et, pt as Dt, q as Ot, r as kt, rn as At, rt as V, s as jt, sn as Mt, st as Nt, t as Pt, tn as Ft, tt as It, u as Lt, un as Rt, ut as zt, v as Bt, vn as Vt, vt as Ht, wn as H, wt as U, x as Ut, xn as W, y as Wt, yn as Gt, yt as Kt, z as qt, zt as Jt } from "./installSVGRenderer-DpsPSOBw.js";
P();
function Yt(e2) {
  for (var t2 = [], n2 = 0; n2 < e2.length; n2++) {
    var r2 = e2[n2];
    if (!r2.defaultAttr.ignore) {
      var i2 = r2.label, a2 = i2.getComputedTransform(), o2 = i2.getBoundingRect(), s2 = !a2 || a2[1] < 1e-5 && a2[2] < 1e-5, c2 = i2.style.margin || 0, l2 = o2.clone();
      l2.applyTransform(a2), l2.x -= c2 / 2, l2.y -= c2 / 2, l2.width += c2, l2.height += c2;
      var u2 = s2 ? new Ge(o2, a2) : null;
      t2.push({ label: i2, labelLine: r2.labelLine, rect: l2, localRect: o2, obb: u2, priority: r2.priority, defaultAttr: r2.defaultAttr, layoutOption: r2.computedLayoutOption, axisAligned: s2, transform: a2 });
    }
  }
  return t2;
}
function Xt(e2) {
  var t2 = [];
  e2.sort(function(e3, t3) {
    return t3.priority - e3.priority;
  });
  var n2 = new Ue(0, 0, 0, 0);
  function r2(e3) {
    if (!e3.ignore) {
      var t3 = e3.ensureState(`emphasis`);
      t3.ignore ?? (t3.ignore = false);
    }
    e3.ignore = true;
  }
  for (var i2 = 0; i2 < e2.length; i2++) {
    var a2 = e2[i2], o2 = a2.axisAligned, s2 = a2.localRect, c2 = a2.transform, l2 = a2.label, u2 = a2.labelLine;
    n2.copy(a2.rect), n2.width -= 0.1, n2.height -= 0.1, n2.x += 0.05, n2.y += 0.05;
    for (var d2 = a2.obb, f2 = false, p2 = 0; p2 < t2.length; p2++) {
      var m2 = t2[p2];
      if (n2.intersect(m2.rect)) {
        if (o2 && m2.axisAligned) {
          f2 = true;
          break;
        }
        if (m2.obb || (m2.obb = new Ge(m2.localRect, m2.transform)), d2 || (d2 = new Ge(s2, c2)), d2.intersect(m2.obb)) {
          f2 = true;
          break;
        }
      }
    }
    f2 ? (r2(l2), u2 && r2(u2)) : (l2.attr(`ignore`, a2.defaultAttr.ignore), u2 && u2.attr(`ignore`, a2.defaultAttr.labelGuideIgnore), t2.push(a2));
  }
}
var Zt = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.type = `grid`, t2.dependencies = [`xAxis`, `yAxis`], t2.layoutMode = `box`, t2.defaultOption = { show: false, z: 0, left: `10%`, top: 60, right: `10%`, bottom: 70, containLabel: false, backgroundColor: `rgba(0,0,0,0)`, borderWidth: 1, borderColor: `#ccc` }, t2;
})(ce);
P();
var Qt = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.getCoordSysModel = function() {
    return this.getReferringComponents(`grid`, j).models[0];
  }, t2.type = `cartesian2dAxis`, t2;
})(ce);
we(Qt, jt);
var $t = { show: true, z: 0, inverse: false, name: ``, nameLocation: `end`, nameRotate: null, nameTruncate: { maxWidth: null, ellipsis: `...`, placeholder: `.` }, nameTextStyle: {}, nameGap: 15, silent: false, triggerEvent: false, tooltip: { show: false }, axisPointer: {}, axisLine: { show: true, onZero: true, onZeroAxisIndex: null, lineStyle: { color: `#6E7079`, width: 1, type: `solid` }, symbol: [`none`, `none`], symbolSize: [10, 15] }, axisTick: { show: true, inside: false, length: 5, lineStyle: { width: 1 } }, axisLabel: { show: true, inside: false, rotate: 0, showMinLabel: null, showMaxLabel: null, margin: 8, fontSize: 12 }, splitLine: { show: true, showMinLine: true, showMaxLine: true, lineStyle: { color: [`#E0E6F1`], width: 1, type: `solid` } }, splitArea: { show: false, areaStyle: { color: [`rgba(250,250,250,0.2)`, `rgba(210,219,238,0.2)`] } } }, en = k({ boundaryGap: true, deduplication: null, splitLine: { show: false }, axisTick: { alignWithLabel: false, interval: `auto` }, axisLabel: { interval: `auto` } }, $t), tn = k({ boundaryGap: [0, 0], axisLine: { show: `auto` }, axisTick: { show: `auto` }, splitNumber: 5, minorTick: { show: false, splitNumber: 5, length: 3, lineStyle: {} }, minorSplitLine: { show: false, lineStyle: { color: `#F4F7FD`, width: 1 } } }, $t), nn = { category: en, value: tn, time: k({ splitNumber: 6, axisLabel: { showMinLabel: false, showMaxLabel: false, rich: { primary: { fontWeight: `bold` } } }, splitLine: { show: false } }, tn), log: R({ logBase: 10 }, tn) }, rn = { value: 1, category: 1, time: 1, log: 1 };
P();
function an(e2, t2, n2, r2) {
  F(rn, function(i2, a2) {
    var o2 = k(k({}, nn[a2], true), r2, true), s2 = (function(e3) {
      D(n3, e3);
      function n3() {
        var n4 = e3 !== null && e3.apply(this, arguments) || this;
        return n4.type = t2 + `Axis.` + a2, n4;
      }
      return n3.prototype.mergeDefaultAndTheme = function(e4, t3) {
        var n4 = Re(this), r3 = n4 ? oe(e4) : {}, i3 = t3.getTheme();
        k(e4, i3.get(a2 + `Axis`)), k(e4, this.getDefaultOption()), e4.type = on(e4), n4 && Ot(e4, r3, n4);
      }, n3.prototype.optionUpdated = function() {
        this.option.type === `category` && (this.__ordinalMeta = Ut.createByAxisModel(this));
      }, n3.prototype.getCategories = function(e4) {
        var t3 = this.option;
        if (t3.type === `category`) return e4 ? t3.data : this.__ordinalMeta.categories;
      }, n3.prototype.getOrdinalMeta = function() {
        return this.__ordinalMeta;
      }, n3.type = t2 + `Axis.` + a2, n3.defaultOption = o2, n3;
    })(n2);
    e2.registerComponentModel(s2);
  }), e2.registerSubTypeDefaulter(t2 + `Axis`, on);
}
function on(e2) {
  return e2.type || (e2.data ? `category` : `value`);
}
var sn = (function() {
  function e2(e3) {
    this.type = `cartesian`, this._dimList = [], this._axes = {}, this.name = e3 || ``;
  }
  return e2.prototype.getAxis = function(e3) {
    return this._axes[e3];
  }, e2.prototype.getAxes = function() {
    return O(this._dimList, function(e3) {
      return this._axes[e3];
    }, this);
  }, e2.prototype.getAxesByScale = function(e3) {
    return e3 = e3.toLowerCase(), Gt(this.getAxes(), function(t2) {
      return t2.scale.type === e3;
    });
  }, e2.prototype.addAxis = function(e3) {
    var t2 = e3.dim;
    this._axes[t2] = e3, this._dimList.push(t2);
  }, e2;
})();
P();
var cn = [`x`, `y`];
function ln(e2) {
  return e2.type === `interval` || e2.type === `time`;
}
var un = (function(e2) {
  D(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3.type = `cartesian2d`, t3.dimensions = cn, t3;
  }
  return t2.prototype.calcAffineTransform = function() {
    this._transform = this._invTransform = null;
    var e3 = this.getAxis(`x`).scale, t3 = this.getAxis(`y`).scale;
    if (ln(e3) && ln(t3)) {
      var n2 = e3.getExtent(), r2 = t3.getExtent(), i2 = this.dataToPoint([n2[0], r2[0]]), a2 = this.dataToPoint([n2[1], r2[1]]), o2 = n2[1] - n2[0], s2 = r2[1] - r2[0];
      if (o2 && s2) {
        var c2 = (a2[0] - i2[0]) / o2, l2 = (a2[1] - i2[1]) / s2, u2 = i2[0] - n2[0] * c2, d2 = i2[1] - r2[0] * l2, f2 = this._transform = [c2, 0, 0, l2, u2, d2];
        this._invTransform = nt([], f2);
      }
    }
  }, t2.prototype.getBaseAxis = function() {
    return this.getAxesByScale(`ordinal`)[0] || this.getAxesByScale(`time`)[0] || this.getAxis(`x`);
  }, t2.prototype.containPoint = function(e3) {
    var t3 = this.getAxis(`x`), n2 = this.getAxis(`y`);
    return t3.contain(t3.toLocalCoord(e3[0])) && n2.contain(n2.toLocalCoord(e3[1]));
  }, t2.prototype.containData = function(e3) {
    return this.getAxis(`x`).containData(e3[0]) && this.getAxis(`y`).containData(e3[1]);
  }, t2.prototype.containZone = function(e3, t3) {
    var n2 = this.dataToPoint(e3), r2 = this.dataToPoint(t3), i2 = this.getArea(), a2 = new Ue(n2[0], n2[1], r2[0] - n2[0], r2[1] - n2[1]);
    return i2.intersect(a2);
  }, t2.prototype.dataToPoint = function(e3, t3, n2) {
    n2 || (n2 = []);
    var r2 = e3[0], i2 = e3[1];
    if (this._transform && r2 != null && isFinite(r2) && i2 != null && isFinite(i2)) return Rt(n2, e3, this._transform);
    var a2 = this.getAxis(`x`), o2 = this.getAxis(`y`);
    return n2[0] = a2.toGlobalCoord(a2.dataToCoord(r2, t3)), n2[1] = o2.toGlobalCoord(o2.dataToCoord(i2, t3)), n2;
  }, t2.prototype.clampData = function(e3, t3) {
    var n2 = this.getAxis(`x`).scale, r2 = this.getAxis(`y`).scale, i2 = n2.getExtent(), a2 = r2.getExtent(), o2 = n2.parse(e3[0]), s2 = r2.parse(e3[1]);
    return t3 || (t3 = []), t3[0] = Math.min(Math.max(Math.min(i2[0], i2[1]), o2), Math.max(i2[0], i2[1])), t3[1] = Math.min(Math.max(Math.min(a2[0], a2[1]), s2), Math.max(a2[0], a2[1])), t3;
  }, t2.prototype.pointToData = function(e3, t3) {
    var n2 = [];
    if (this._invTransform) return Rt(n2, e3, this._invTransform);
    var r2 = this.getAxis(`x`), i2 = this.getAxis(`y`);
    return n2[0] = r2.coordToData(r2.toLocalCoord(e3[0]), t3), n2[1] = i2.coordToData(i2.toLocalCoord(e3[1]), t3), n2;
  }, t2.prototype.getOtherAxis = function(e3) {
    return this.getAxis(e3.dim === `x` ? `y` : `x`);
  }, t2.prototype.getArea = function(e3) {
    e3 || (e3 = 0);
    var t3 = this.getAxis(`x`).getGlobalExtent(), n2 = this.getAxis(`y`).getGlobalExtent(), r2 = Math.min(t3[0], t3[1]) - e3, i2 = Math.min(n2[0], n2[1]) - e3, a2 = Math.max(t3[0], t3[1]) - r2 + e3, o2 = Math.max(n2[0], n2[1]) - i2 + e3;
    return new Ue(r2, i2, a2, o2);
  }, t2;
})(sn);
P();
var dn = (function(e2) {
  D(t2, e2);
  function t2(t3, n2, r2, i2, a2) {
    var o2 = e2.call(this, t3, n2, r2) || this;
    return o2.index = 0, o2.type = i2 || `value`, o2.position = a2 || `bottom`, o2;
  }
  return t2.prototype.isHorizontal = function() {
    var e3 = this.position;
    return e3 === `top` || e3 === `bottom`;
  }, t2.prototype.getGlobalExtent = function(e3) {
    var t3 = this.getExtent();
    return t3[0] = this.toGlobalCoord(t3[0]), t3[1] = this.toGlobalCoord(t3[1]), e3 && t3[0] > t3[1] && t3.reverse(), t3;
  }, t2.prototype.pointToData = function(e3, t3) {
    return this.coordToData(this.toLocalCoord(e3[this.dim === `x` ? 0 : 1]), t3);
  }, t2.prototype.setCategorySortInfo = function(e3) {
    if (this.type !== `category`) return false;
    this.model.option.categorySortInfo = e3, this.scale.setSortInfo(e3);
  }, t2;
})(Ke);
function fn(e2, t2, n2) {
  n2 || (n2 = {});
  var r2 = e2.coordinateSystem, i2 = t2.axis, a2 = {}, o2 = i2.getAxesOnZeroOf()[0], s2 = i2.position, c2 = o2 ? `onZero` : s2, l2 = i2.dim, u2 = r2.getRect(), d2 = [u2.x, u2.x + u2.width, u2.y, u2.y + u2.height], f2 = { left: 0, right: 1, top: 0, bottom: 1, onZero: 2 }, p2 = t2.get(`offset`) || 0, m2 = l2 === `x` ? [d2[2] - p2, d2[3] + p2] : [d2[0] - p2, d2[1] + p2];
  if (o2) {
    var h2 = o2.toGlobalCoord(o2.dataToCoord(0));
    m2[f2.onZero] = Math.max(Math.min(h2, m2[1]), m2[0]);
  }
  a2.position = [l2 === `y` ? m2[f2[c2]] : d2[0], l2 === `x` ? m2[f2[c2]] : d2[3]], a2.rotation = Math.PI / 2 * (l2 === `x` ? 0 : 1), a2.labelDirection = a2.tickDirection = a2.nameDirection = { top: -1, bottom: 1, left: -1, right: 1 }[s2], a2.labelOffset = o2 ? m2[f2[s2]] - m2[f2.onZero] : 0, t2.get([`axisTick`, `inside`]) && (a2.tickDirection = -a2.tickDirection), de(n2.labelInside, t2.get([`axisLabel`, `inside`])) && (a2.labelDirection = -a2.labelDirection);
  var g2 = t2.get([`axisLabel`, `rotate`]);
  return a2.labelRotate = c2 === `top` ? -g2 : g2, a2.z2 = 1, a2;
}
function pn(e2) {
  return e2.get(`coordinateSystem`) === `cartesian2d`;
}
function mn(e2) {
  var t2 = { xAxisModel: null, yAxisModel: null };
  return F(t2, function(n2, r2) {
    var i2 = r2.replace(/Model$/, ``);
    t2[r2] = e2.getReferringComponents(i2, j).models[0];
  }), t2;
}
var hn = Math.log;
function gn(e2, t2, n2) {
  var r2 = Bt.prototype, i2 = r2.getTicks.call(n2), a2 = r2.getTicks.call(n2, true), o2 = i2.length - 1, s2 = r2.getInterval.call(n2), c2 = it(e2, t2), l2 = c2.extent, u2 = c2.fixMin, d2 = c2.fixMax;
  if (e2.type === `log`) {
    var f2 = hn(e2.base);
    l2 = [hn(l2[0]) / f2, hn(l2[1]) / f2];
  }
  e2.setExtent(l2[0], l2[1]), e2.calcNiceExtent({ splitNumber: o2, fixMin: u2, fixMax: d2 });
  var p2 = r2.getExtent.call(e2);
  u2 && (l2[0] = p2[0]), d2 && (l2[1] = p2[1]);
  var m2 = r2.getInterval.call(e2), h2 = l2[0], g2 = l2[1];
  if (u2 && d2) m2 = (g2 - h2) / o2;
  else if (u2) for (g2 = l2[0] + m2 * o2; g2 < l2[1] && isFinite(g2) && isFinite(l2[1]); ) m2 = Wt(m2), g2 = l2[0] + m2 * o2;
  else if (d2) for (h2 = l2[1] - m2 * o2; h2 > l2[0] && isFinite(h2) && isFinite(l2[0]); ) m2 = Wt(m2), h2 = l2[1] - m2 * o2;
  else {
    e2.getTicks().length - 1 > o2 && (m2 = Wt(m2));
    var _2 = m2 * o2;
    g2 = Math.ceil(l2[1] / m2) * m2, h2 = ze(g2 - _2), h2 < 0 && l2[0] >= 0 ? (h2 = 0, g2 = ze(_2)) : g2 > 0 && l2[1] <= 0 && (g2 = 0, h2 = -ze(_2));
  }
  var v2 = (i2[0].value - a2[0].value) / s2, y2 = (i2[o2].value - a2[o2].value) / s2;
  r2.setExtent.call(e2, h2 + m2 * v2, g2 + m2 * y2), r2.setInterval.call(e2, m2), (v2 || y2) && r2.setNiceExtent.call(e2, h2 + m2, g2 - m2);
}
var _n = (function() {
  function e2(e3, t2, n2) {
    this.type = `grid`, this._coordsMap = {}, this._coordsList = [], this._axesMap = {}, this._axesList = [], this.axisPointerEnabled = true, this.dimensions = cn, this._initCartesian(e3, t2, n2), this.model = e3;
  }
  return e2.prototype.getRect = function() {
    return this._rect;
  }, e2.prototype.update = function(e3, t2) {
    var n2 = this._axesMap;
    this._updateScale(e3, this.model);
    function r2(e4) {
      var t3, n3 = b(e4), r3 = n3.length;
      if (r3) {
        for (var i3 = [], a2 = r3 - 1; a2 >= 0; a2--) {
          var o2 = e4[+n3[a2]], s2 = o2.model, c2 = o2.scale;
          Ye(c2) && s2.get(`alignTicks`) && s2.get(`interval`) == null ? i3.push(o2) : (yt(c2, s2), Ye(c2) && (t3 = o2));
        }
        i3.length && (t3 || (t3 = i3.pop(), yt(t3.scale, t3.model)), F(i3, function(e5) {
          gn(e5.scale, e5.model, t3.scale);
        }));
      }
    }
    r2(n2.x), r2(n2.y);
    var i2 = {};
    F(n2.x, function(e4) {
      yn(n2, `y`, e4, i2);
    }), F(n2.y, function(e4) {
      yn(n2, `x`, e4, i2);
    }), this.resize(this.model, t2);
  }, e2.prototype.resize = function(e3, t2, n2) {
    var r2 = e3.getBoxLayoutParams(), i2 = !n2 && e3.get(`containLabel`), a2 = me(r2, { width: t2.getWidth(), height: t2.getHeight() });
    this._rect = a2;
    var o2 = this._axesList;
    s2(), i2 && (F(o2, function(e4) {
      if (!e4.model.get([`axisLabel`, `inside`])) {
        var t3 = gt(e4);
        if (t3) {
          var n3 = e4.isHorizontal() ? `height` : `width`, r3 = e4.model.get([`axisLabel`, `margin`]);
          a2[n3] -= t3[n3] + r3, e4.position === `top` ? a2.y += t3.height + r3 : e4.position === `left` && (a2.x += t3.width + r3);
        }
      }
    }), s2()), F(this._coordsList, function(e4) {
      e4.calcAffineTransform();
    });
    function s2() {
      F(o2, function(e4) {
        var t3 = e4.isHorizontal(), n3 = t3 ? [0, a2.width] : [0, a2.height], r3 = +!!e4.inverse;
        e4.setExtent(n3[r3], n3[1 - r3]), xn(e4, t3 ? a2.x : a2.y);
      });
    }
  }, e2.prototype.getAxis = function(e3, t2) {
    var n2 = this._axesMap[e3];
    if (n2 != null) return n2[t2 || 0];
  }, e2.prototype.getAxes = function() {
    return this._axesList.slice();
  }, e2.prototype.getCartesian = function(e3, t2) {
    if (e3 != null && t2 != null) {
      var n2 = `x` + e3 + `y` + t2;
      return this._coordsMap[n2];
    }
    A(e3) && (t2 = e3.yAxisIndex, e3 = e3.xAxisIndex);
    for (var r2 = 0, i2 = this._coordsList; r2 < i2.length; r2++) if (i2[r2].getAxis(`x`).index === e3 || i2[r2].getAxis(`y`).index === t2) return i2[r2];
  }, e2.prototype.getCartesians = function() {
    return this._coordsList.slice();
  }, e2.prototype.convertToPixel = function(e3, t2, n2) {
    var r2 = this._findConvertTarget(t2);
    return r2.cartesian ? r2.cartesian.dataToPoint(n2) : r2.axis ? r2.axis.toGlobalCoord(r2.axis.dataToCoord(n2)) : null;
  }, e2.prototype.convertFromPixel = function(e3, t2, n2) {
    var r2 = this._findConvertTarget(t2);
    return r2.cartesian ? r2.cartesian.pointToData(n2) : r2.axis ? r2.axis.coordToData(r2.axis.toLocalCoord(n2)) : null;
  }, e2.prototype._findConvertTarget = function(e3) {
    var t2 = e3.seriesModel, n2 = e3.xAxisModel || t2 && t2.getReferringComponents(`xAxis`, j).models[0], r2 = e3.yAxisModel || t2 && t2.getReferringComponents(`yAxis`, j).models[0], i2 = e3.gridModel, a2 = this._coordsList, o2, s2;
    return t2 ? (o2 = t2.coordinateSystem, W(a2, o2) < 0 && (o2 = null)) : n2 && r2 ? o2 = this.getCartesian(n2.componentIndex, r2.componentIndex) : n2 ? s2 = this.getAxis(`x`, n2.componentIndex) : r2 ? s2 = this.getAxis(`y`, r2.componentIndex) : i2 && i2.coordinateSystem === this && (o2 = this._coordsList[0]), { cartesian: o2, axis: s2 };
  }, e2.prototype.containPoint = function(e3) {
    var t2 = this._coordsList[0];
    if (t2) return t2.containPoint(e3);
  }, e2.prototype._initCartesian = function(e3, t2, n2) {
    var r2 = this, i2 = this, a2 = { left: false, right: false, top: false, bottom: false }, o2 = { x: {}, y: {} }, s2 = { x: 0, y: 0 };
    if (t2.eachComponent(`xAxis`, c2(`x`), this), t2.eachComponent(`yAxis`, c2(`y`), this), !s2.x || !s2.y) {
      this._axesMap = {}, this._axesList = [];
      return;
    }
    this._axesMap = o2, F(o2.x, function(t3, n3) {
      F(o2.y, function(i3, a3) {
        var o3 = `x` + n3 + `y` + a3, s3 = new un(o3);
        s3.master = r2, s3.model = e3, r2._coordsMap[o3] = s3, r2._coordsList.push(s3), s3.addAxis(t3), s3.addAxis(i3);
      });
    });
    function c2(t3) {
      return function(n3, r3) {
        if (vn(n3, e3)) {
          var c3 = n3.get(`position`);
          t3 === `x` ? c3 !== `top` && c3 !== `bottom` && (c3 = a2.bottom ? `top` : `bottom`) : c3 !== `left` && c3 !== `right` && (c3 = a2.left ? `right` : `left`), a2[c3] = true;
          var l2 = new dn(t3, Ze(n3), [0, 0], n3.get(`type`), c3);
          l2.onBand = l2.type === `category` && n3.get(`boundaryGap`), l2.inverse = n3.get(`inverse`), n3.axis = l2, l2.model = n3, l2.grid = i2, l2.index = r3, i2._axesList.push(l2), o2[t3][r3] = l2, s2[t3]++;
        }
      };
    }
  }, e2.prototype._updateScale = function(e3, t2) {
    F(this._axesList, function(e4) {
      if (e4.scale.setExtent(1 / 0, -1 / 0), e4.type === `category`) {
        var t3 = e4.model.get(`categorySortInfo`);
        e4.scale.setSortInfo(t3);
      }
    }), e3.eachSeries(function(e4) {
      if (pn(e4)) {
        var r2 = mn(e4), i2 = r2.xAxisModel, a2 = r2.yAxisModel;
        if (!vn(i2, t2) || !vn(a2, t2)) return;
        var o2 = this.getCartesian(i2.componentIndex, a2.componentIndex), s2 = e4.getData(), c2 = o2.getAxis(`x`), l2 = o2.getAxis(`y`);
        n2(s2, c2), n2(s2, l2);
      }
    }, this);
    function n2(e4, t3) {
      F(et(e4, t3.dim), function(n3) {
        t3.scale.unionExtentFromData(e4, n3);
      });
    }
  }, e2.prototype.getTooltipAxes = function(e3) {
    var t2 = [], n2 = [];
    return F(this.getCartesians(), function(r2) {
      var i2 = e3 != null && e3 !== `auto` ? r2.getAxis(e3) : r2.getBaseAxis(), a2 = r2.getOtherAxis(i2);
      W(t2, i2) < 0 && t2.push(i2), W(n2, a2) < 0 && n2.push(a2);
    }), { baseAxes: t2, otherAxes: n2 };
  }, e2.create = function(t2, n2) {
    var r2 = [];
    return t2.eachComponent(`grid`, function(i2, a2) {
      var o2 = new e2(i2, t2, n2);
      o2.name = `grid_` + a2, o2.resize(i2, n2, true), i2.coordinateSystem = o2, r2.push(o2);
    }), t2.eachSeries(function(e3) {
      if (pn(e3)) {
        var t3 = mn(e3), n3 = t3.xAxisModel, r3 = t3.yAxisModel;
        e3.coordinateSystem = n3.getCoordSysModel().coordinateSystem.getCartesian(n3.componentIndex, r3.componentIndex);
      }
    }), r2;
  }, e2.dimensions = cn, e2;
})();
function vn(e2, t2) {
  return e2.getCoordSysModel() === t2;
}
function yn(e2, t2, n2, r2) {
  n2.getAxesOnZeroOf = function() {
    return a2 ? [a2] : [];
  };
  var i2 = e2[t2], a2, o2 = n2.model, s2 = o2.get([`axisLine`, `onZero`]), c2 = o2.get([`axisLine`, `onZeroAxisIndex`]);
  if (!s2) return;
  if (c2 != null) bn(i2[c2]) && (a2 = i2[c2]);
  else for (var l2 in i2) if (i2.hasOwnProperty(l2) && bn(i2[l2]) && !r2[u2(i2[l2])]) {
    a2 = i2[l2];
    break;
  }
  a2 && (r2[u2(a2)] = true);
  function u2(e3) {
    return e3.dim + `_` + e3.index;
  }
}
function bn(e2) {
  return e2 && e2.type !== `category` && e2.type !== `time` && Tt(e2);
}
function xn(e2, t2) {
  var n2 = e2.getExtent(), r2 = n2[0] + n2[1];
  e2.toGlobalCoord = e2.dim === `x` ? function(e3) {
    return e3 + t2;
  } : function(e3) {
    return r2 - e3 + t2;
  }, e2.toLocalCoord = e2.dim === `x` ? function(e3) {
    return e3 - t2;
  } : function(e3) {
    return r2 - e3 + t2;
  };
}
var G = Math.PI, K = (function() {
  function e2(e3, t2) {
    this.group = new se(), this.opt = t2, this.axisModel = e3, R(t2, { labelOffset: 0, nameDirection: 1, tickDirection: 1, labelDirection: 1, silent: true, handleAutoShown: function() {
      return true;
    } });
    var n2 = new se({ x: t2.position[0], y: t2.position[1], rotation: t2.rotation });
    n2.updateTransform(), this._transformGroup = n2;
  }
  return e2.prototype.hasBuilder = function(e3) {
    return !!Sn[e3];
  }, e2.prototype.add = function(e3) {
    Sn[e3](this.opt, this.axisModel, this.group, this._transformGroup);
  }, e2.prototype.getGroup = function() {
    return this.group;
  }, e2.innerTextLayout = function(e3, t2, n2) {
    var r2 = Pe(t2 - e3), i2, a2;
    return C(r2) ? (a2 = n2 > 0 ? `top` : `bottom`, i2 = `center`) : C(r2 - G) ? (a2 = n2 > 0 ? `bottom` : `top`, i2 = `center`) : (a2 = `middle`, i2 = r2 > 0 && r2 < G ? n2 > 0 ? `right` : `left` : n2 > 0 ? `left` : `right`), { rotation: r2, textAlign: i2, textVerticalAlign: a2 };
  }, e2.makeAxisEventDataBase = function(e3) {
    var t2 = { componentType: e3.mainType, componentIndex: e3.componentIndex };
    return t2[e3.mainType + `Index`] = e3.componentIndex, t2;
  }, e2.isLabelSilent = function(e3) {
    var t2 = e3.get(`tooltip`);
    return e3.get(`silent`) || !(e3.get(`triggerEvent`) || t2 && t2.show);
  }, e2;
})(), Sn = { axisLine: function(e2, t2, n2, r2) {
  var i2 = t2.get([`axisLine`, `show`]);
  if (i2 === `auto` && e2.handleAutoShown && (i2 = e2.handleAutoShown(`axisLine`)), i2) {
    var a2 = t2.axis.getExtent(), o2 = r2.transform, s2 = [a2[0], 0], c2 = [a2[1], 0], l2 = s2[0] > c2[0];
    o2 && (Rt(s2, s2, o2), Rt(c2, c2, o2));
    var u2 = Vt({ lineCap: `round` }, t2.getModel([`axisLine`, `lineStyle`]).getLineStyle()), d2 = new Ht({ shape: { x1: s2[0], y1: s2[1], x2: c2[0], y2: c2[1] }, style: u2, strokeContainThreshold: e2.strokeContainThreshold || 5, silent: true, z2: 1 });
    bt(d2.shape, d2.style.lineWidth), d2.anid = `line`, n2.add(d2);
    var f2 = t2.get([`axisLine`, `symbol`]);
    if (f2 != null) {
      var p2 = t2.get([`axisLine`, `symbolSize`]);
      z(f2) && (f2 = [f2, f2]), (z(p2) || re(p2)) && (p2 = [p2, p2]);
      var m2 = pt(t2.get([`axisLine`, `symbolOffset`]) || 0, p2), h2 = p2[0], g2 = p2[1];
      F([{ rotate: e2.rotation + Math.PI / 2, offset: m2[0], r: 0 }, { rotate: e2.rotation - Math.PI / 2, offset: m2[1], r: Math.sqrt((s2[0] - c2[0]) * (s2[0] - c2[0]) + (s2[1] - c2[1]) * (s2[1] - c2[1])) }], function(t3, r3) {
        if (f2[r3] !== `none` && f2[r3] != null) {
          var i3 = y(f2[r3], -h2 / 2, -g2 / 2, h2, g2, u2.stroke, true), a3 = t3.r + t3.offset, o3 = l2 ? c2 : s2;
          i3.attr({ rotation: t3.rotate, x: o3[0] + a3 * Math.cos(e2.rotation), y: o3[1] - a3 * Math.sin(e2.rotation), silent: true, z2: 11 }), n2.add(i3);
        }
      });
    }
  }
}, axisTickLabel: function(e2, t2, n2, r2) {
  var i2 = On(n2, r2, t2, e2), a2 = An(n2, r2, t2, e2);
  wn(t2, a2, i2), kn(n2, r2, t2, e2.tickDirection), t2.get([`axisLabel`, `hideOverlap`]) && Xt(Yt(O(a2, function(e3) {
    return { label: e3, priority: e3.z2, defaultAttr: { ignore: e3.ignore } };
  })));
}, axisName: function(e2, t2, n2, r2) {
  var i2 = de(e2.axisName, t2.get(`name`));
  if (i2) {
    var a2 = t2.get(`nameLocation`), o2 = e2.nameDirection, s2 = t2.getModel(`nameTextStyle`), c2 = t2.get(`nameGap`) || 0, l2 = t2.axis.getExtent(), u2 = l2[0] > l2[1] ? -1 : 1, d2 = [a2 === `start` ? l2[0] - u2 * c2 : a2 === `end` ? l2[1] + u2 * c2 : (l2[0] + l2[1]) / 2, En(a2) ? e2.labelOffset + o2 * c2 : 0], f2, p2 = t2.get(`nameRotate`);
    p2 != null && (p2 = p2 * G / 180);
    var m2;
    En(a2) ? f2 = K.innerTextLayout(e2.rotation, p2 ?? e2.rotation, o2) : (f2 = Cn(e2.rotation, a2, p2 || 0, l2), m2 = e2.axisNameAvailableWidth, m2 != null && (m2 = Math.abs(m2 / Math.sin(f2.rotation)), !isFinite(m2) && (m2 = null)));
    var h2 = s2.getFont(), g2 = t2.get(`nameTruncate`, true) || {}, _2 = g2.ellipsis, v2 = de(e2.nameTruncateMaxWidth, g2.maxWidth, m2), y2 = new N({ x: d2[0], y: d2[1], rotation: f2.rotation, silent: K.isLabelSilent(t2), style: ft(s2, { text: i2, font: h2, overflow: `truncate`, width: v2, ellipsis: _2, fill: s2.getTextColor() || t2.get([`axisLine`, `lineStyle`, `color`]), align: s2.get(`align`) || f2.textAlign, verticalAlign: s2.get(`verticalAlign`) || f2.textVerticalAlign }), z2: 1 });
    if (Dt({ el: y2, componentModel: t2, itemName: i2 }), y2.__fullText = i2, y2.anid = `name`, t2.get(`triggerEvent`)) {
      var b2 = K.makeAxisEventDataBase(t2);
      b2.targetType = `axisName`, b2.name = i2, U(y2).eventData = b2;
    }
    r2.add(y2), y2.updateTransform(), n2.add(y2), y2.decomposeTransform();
  }
} };
function Cn(e2, t2, n2, r2) {
  var i2 = Pe(n2 - e2), a2, o2, s2 = r2[0] > r2[1], c2 = t2 === `start` && !s2 || t2 !== `start` && s2;
  return C(i2 - G / 2) ? (o2 = c2 ? `bottom` : `top`, a2 = `center`) : C(i2 - G * 1.5) ? (o2 = c2 ? `top` : `bottom`, a2 = `center`) : (o2 = `middle`, a2 = i2 < G * 1.5 && i2 > G / 2 ? c2 ? `left` : `right` : c2 ? `right` : `left`), { rotation: i2, textAlign: a2, textVerticalAlign: o2 };
}
function wn(e2, t2, n2) {
  if (!ct(e2.axis)) {
    var r2 = e2.get([`axisLabel`, `showMinLabel`]), i2 = e2.get([`axisLabel`, `showMaxLabel`]);
    t2 || (t2 = []), n2 || (n2 = []);
    var a2 = t2[0], o2 = t2[1], s2 = t2[t2.length - 1], c2 = t2[t2.length - 2], l2 = n2[0], u2 = n2[1], d2 = n2[n2.length - 1], f2 = n2[n2.length - 2];
    r2 === false ? (q(a2), q(l2)) : Tn(a2, o2) && (r2 ? (q(o2), q(u2)) : (q(a2), q(l2))), i2 === false ? (q(s2), q(d2)) : Tn(c2, s2) && (i2 ? (q(c2), q(f2)) : (q(s2), q(d2)));
  }
}
function q(e2) {
  e2 && (e2.ignore = true);
}
function Tn(e2, t2) {
  var n2 = e2 && e2.getBoundingRect().clone(), r2 = t2 && t2.getBoundingRect().clone();
  if (n2 && r2) {
    var i2 = v([]);
    return St(i2, i2, -e2.rotation), n2.applyTransform(Ft([], i2, e2.getLocalTransform())), r2.applyTransform(Ft([], i2, t2.getLocalTransform())), n2.intersect(r2);
  }
}
function En(e2) {
  return e2 === `middle` || e2 === `center`;
}
function Dn(e2, t2, n2, r2, i2) {
  for (var a2 = [], o2 = [], s2 = [], c2 = 0; c2 < e2.length; c2++) {
    var l2 = e2[c2].coord;
    o2[0] = l2, o2[1] = 0, s2[0] = l2, s2[1] = n2, t2 && (Rt(o2, o2, t2), Rt(s2, s2, t2));
    var u2 = new Ht({ shape: { x1: o2[0], y1: o2[1], x2: s2[0], y2: s2[1] }, style: r2, z2: 2, autoBatch: true, silent: true });
    bt(u2.shape, u2.style.lineWidth), u2.anid = i2 + `_` + e2[c2].tickValue, a2.push(u2);
  }
  return a2;
}
function On(e2, t2, n2, r2) {
  var i2 = n2.axis, a2 = n2.getModel(`axisTick`), o2 = a2.get(`show`);
  if (o2 === `auto` && r2.handleAutoShown && (o2 = r2.handleAutoShown(`axisTick`)), o2 && !i2.scale.isBlank()) {
    for (var s2 = a2.getModel(`lineStyle`), c2 = r2.tickDirection * a2.get(`length`), l2 = Dn(i2.getTicksCoords(), t2.transform, c2, R(s2.getLineStyle(), { stroke: n2.get([`axisLine`, `lineStyle`, `color`]) }), `ticks`), u2 = 0; u2 < l2.length; u2++) e2.add(l2[u2]);
    return l2;
  }
}
function kn(e2, t2, n2, r2) {
  var i2 = n2.axis, a2 = n2.getModel(`minorTick`);
  if (a2.get(`show`) && !i2.scale.isBlank()) {
    var o2 = i2.getMinorTicksCoords();
    if (o2.length) for (var s2 = a2.getModel(`lineStyle`), c2 = r2 * a2.get(`length`), l2 = R(s2.getLineStyle(), R(n2.getModel(`axisTick`).getLineStyle(), { stroke: n2.get([`axisLine`, `lineStyle`, `color`]) })), u2 = 0; u2 < o2.length; u2++) for (var d2 = Dn(o2[u2], t2.transform, c2, l2, `minorticks_` + u2), f2 = 0; f2 < d2.length; f2++) e2.add(d2[f2]);
  }
}
function An(e2, t2, n2, r2) {
  var i2 = n2.axis;
  if (de(r2.axisLabelShow, n2.get([`axisLabel`, `show`])) && !i2.scale.isBlank()) {
    var a2 = n2.getModel(`axisLabel`), o2 = a2.get(`margin`), s2 = i2.getViewLabels(), c2 = (de(r2.labelRotate, a2.get(`rotate`)) || 0) * G / 180, l2 = K.innerTextLayout(r2.rotation, c2, r2.labelDirection), u2 = n2.getCategories && n2.getCategories(true), d2 = [], f2 = K.isLabelSilent(n2), p2 = n2.get(`triggerEvent`);
    return F(s2, function(c3, m2) {
      var h2 = i2.scale.type === `ordinal` ? i2.scale.getRawOrdinalNumber(c3.tickValue) : c3.tickValue, g2 = c3.formattedLabel, _2 = c3.rawLabel, v2 = a2;
      if (u2 && u2[h2]) {
        var y2 = u2[h2];
        A(y2) && y2.textStyle && (v2 = new V(y2.textStyle, a2, n2.ecModel));
      }
      var b2 = v2.getTextColor() || n2.get([`axisLine`, `lineStyle`, `color`]), x2 = i2.dataToCoord(h2), S2 = v2.getShallow(`align`, true) || l2.textAlign, C2 = _e(v2.getShallow(`alignMinLabel`, true), S2), ee2 = _e(v2.getShallow(`alignMaxLabel`, true), S2), te2 = v2.getShallow(`verticalAlign`, true) || v2.getShallow(`baseline`, true) || l2.textVerticalAlign, ne2 = _e(v2.getShallow(`verticalAlignMinLabel`, true), te2), re2 = _e(v2.getShallow(`verticalAlignMaxLabel`, true), te2), w2 = new N({ x: x2, y: r2.labelOffset + r2.labelDirection * o2, rotation: l2.rotation, silent: f2, z2: 10 + (c3.level || 0), style: ft(v2, { text: g2, align: m2 === 0 ? C2 : m2 === s2.length - 1 ? ee2 : S2, verticalAlign: m2 === 0 ? ne2 : m2 === s2.length - 1 ? re2 : te2, fill: H(b2) ? b2(i2.type === `category` ? _2 : i2.type === `value` ? h2 + `` : h2, m2) : b2 }) });
      if (w2.anid = `label_` + h2, Dt({ el: w2, componentModel: n2, itemName: g2, formatterParamsExtra: { isTruncated: function() {
        return w2.isTruncated;
      }, value: _2, tickIndex: m2 } }), p2) {
        var T2 = K.makeAxisEventDataBase(n2);
        T2.targetType = `axisLabel`, T2.value = _2, T2.tickIndex = m2, i2.type === `category` && (T2.dataIndex = h2), U(w2).eventData = T2;
      }
      t2.add(w2), w2.updateTransform(), d2.push(w2), e2.add(w2), w2.decomposeTransform();
    }), d2;
  }
}
function jn(e2, t2) {
  var n2 = { axesInfo: {}, seriesInvolved: false, coordSysAxesInfo: {}, coordSysMap: {} };
  return Mn(n2, e2, t2), n2.seriesInvolved && Pn(n2, e2), n2;
}
function Mn(e2, t2, n2) {
  var r2 = t2.getComponent(`tooltip`), i2 = t2.getComponent(`axisPointer`), a2 = i2.get(`link`, true) || [], o2 = [];
  F(n2.getCoordinateSystems(), function(n3) {
    if (!n3.axisPointerEnabled) return;
    var s2 = Vn(n3.model), c2 = e2.coordSysAxesInfo[s2] = {};
    e2.coordSysMap[s2] = n3;
    var l2 = n3.model.getModel(`tooltip`, r2);
    if (F(n3.getAxes(), B(p2, false, null)), n3.getTooltipAxes && r2 && l2.get(`show`)) {
      var u2 = l2.get(`trigger`) === `axis`, d2 = l2.get([`axisPointer`, `type`]) === `cross`, f2 = n3.getTooltipAxes(l2.get([`axisPointer`, `axis`]));
      (u2 || d2) && F(f2.baseAxes, B(p2, !d2 || `cross`, u2)), d2 && F(f2.otherAxes, B(p2, `cross`, false));
    }
    function p2(r3, s3, u3) {
      var d3 = u3.model.getModel(`axisPointer`, i2), f3 = d3.get(`show`);
      if (f3 && (f3 !== `auto` || r3 || Bn(d3))) {
        s3 ?? (s3 = d3.get(`triggerTooltip`)), d3 = r3 ? Nn(u3, l2, i2, t2, r3, s3) : d3;
        var p3 = d3.get(`snap`), m2 = d3.get(`triggerEmphasis`), h2 = Vn(u3.model), g2 = s3 || p3 || u3.type === `category`, _2 = e2.axesInfo[h2] = { key: h2, axis: u3, coordSys: n3, axisPointerModel: d3, triggerTooltip: s3, triggerEmphasis: m2, involveSeries: g2, snap: p3, useHandle: Bn(d3), seriesModels: [], linkGroup: null };
        c2[h2] = _2, e2.seriesInvolved = e2.seriesInvolved || g2;
        var v2 = Fn(a2, u3);
        if (v2 != null) {
          var y2 = o2[v2] || (o2[v2] = { axesInfo: {} });
          y2.axesInfo[h2] = _2, y2.mapper = a2[v2].mapper, _2.linkGroup = y2;
        }
      }
    }
  });
}
function Nn(e2, t2, n2, r2, i2, a2) {
  var o2 = t2.getModel(`axisPointer`), s2 = [`type`, `snap`, `lineStyle`, `shadowStyle`, `label`, `animation`, `animationDurationUpdate`, `animationEasingUpdate`, `z`], c2 = {};
  F(s2, function(e3) {
    c2[e3] = L(o2.get(e3));
  }), c2.snap = e2.type !== `category` && !!a2, o2.get(`type`) === `cross` && (c2.type = `line`);
  var l2 = c2.label || (c2.label = {});
  if (l2.show ?? (l2.show = false), i2 === `cross` && (l2.show = o2.get([`label`, `show`]) ?? true, !a2)) {
    var u2 = c2.lineStyle = o2.get(`crossStyle`);
    u2 && R(l2, u2.textStyle);
  }
  return e2.model.getModel(`axisPointer`, new V(c2, n2, r2));
}
function Pn(e2, t2) {
  t2.eachSeries(function(t3) {
    var n2 = t3.coordinateSystem, r2 = t3.get([`tooltip`, `trigger`], true), i2 = t3.get([`tooltip`, `show`], true);
    n2 && r2 !== `none` && r2 !== false && r2 !== `item` && i2 !== false && t3.get([`axisPointer`, `show`], true) !== false && F(e2.coordSysAxesInfo[Vn(n2.model)], function(e3) {
      var r3 = e3.axis;
      n2.getAxis(r3.dim) === r3 && (e3.seriesModels.push(t3), e3.seriesDataCount ?? (e3.seriesDataCount = 0), e3.seriesDataCount += t3.getData().count());
    });
  });
}
function Fn(e2, t2) {
  for (var n2 = t2.model, r2 = t2.dim, i2 = 0; i2 < e2.length; i2++) {
    var a2 = e2[i2] || {};
    if (In(a2[r2 + `AxisId`], n2.id) || In(a2[r2 + `AxisIndex`], n2.componentIndex) || In(a2[r2 + `AxisName`], n2.name)) return i2;
  }
}
function In(e2, t2) {
  return e2 === `all` || M(e2) && W(e2, t2) >= 0 || e2 === t2;
}
function Ln(e2) {
  var t2 = Rn(e2);
  if (t2) {
    var n2 = t2.axisPointerModel, r2 = t2.axis.scale, i2 = n2.option, a2 = n2.get(`status`), o2 = n2.get(`value`);
    o2 != null && (o2 = r2.parse(o2));
    var s2 = Bn(n2);
    a2 ?? (i2.status = s2 ? `show` : `hide`);
    var c2 = r2.getExtent().slice();
    c2[0] > c2[1] && c2.reverse(), (o2 == null || o2 > c2[1]) && (o2 = c2[1]), o2 < c2[0] && (o2 = c2[0]), i2.value = o2, s2 && (i2.status = t2.axis.scale.isBlank() ? `hide` : `show`);
  }
}
function Rn(e2) {
  var t2 = (e2.ecModel.getComponent(`axisPointer`) || {}).coordSysAxesInfo;
  return t2 && t2.axesInfo[Vn(e2)];
}
function zn(e2) {
  var t2 = Rn(e2);
  return t2 && t2.axisPointerModel;
}
function Bn(e2) {
  return !!e2.get([`handle`, `show`]);
}
function Vn(e2) {
  return e2.type + `||` + e2.id;
}
P();
var Hn = {}, Un = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.prototype.render = function(t3, n2, r2, i2) {
    this.axisPointerClass && Ln(t3), e2.prototype.render.apply(this, arguments), this._doUpdateAxisPointerClass(t3, r2, true);
  }, t2.prototype.updateAxisPointer = function(e3, t3, n2, r2) {
    this._doUpdateAxisPointerClass(e3, n2, false);
  }, t2.prototype.remove = function(e3, t3) {
    var n2 = this._axisPointer;
    n2 && n2.remove(t3);
  }, t2.prototype.dispose = function(t3, n2) {
    this._disposeAxisPointer(n2), e2.prototype.dispose.apply(this, arguments);
  }, t2.prototype._doUpdateAxisPointerClass = function(e3, n2, r2) {
    var i2 = t2.getAxisPointerClass(this.axisPointerClass);
    if (i2) {
      var a2 = zn(e3);
      a2 ? (this._axisPointer || (this._axisPointer = new i2())).render(e3, a2, n2, r2) : this._disposeAxisPointer(n2);
    }
  }, t2.prototype._disposeAxisPointer = function(e3) {
    this._axisPointer && this._axisPointer.dispose(e3), this._axisPointer = null;
  }, t2.registerAxisPointerClass = function(e3, t3) {
    Hn[e3] = t3;
  }, t2.getAxisPointerClass = function(e3) {
    return e3 && Hn[e3];
  }, t2.type = `axis`, t2;
})(E), Wn = mt();
function Gn(e2, t2, n2, r2) {
  var i2 = n2.axis;
  if (!i2.scale.isBlank()) {
    var a2 = n2.getModel(`splitArea`), o2 = a2.getModel(`areaStyle`), s2 = o2.get(`color`), c2 = r2.coordinateSystem.getRect(), l2 = i2.getTicksCoords({ tickModel: a2, clamp: true });
    if (l2.length) {
      var u2 = s2.length, d2 = Wn(e2).splitAreaColors, f2 = Et(), p2 = 0;
      if (d2) for (var m2 = 0; m2 < l2.length; m2++) {
        var h2 = d2.get(l2[m2].tickValue);
        if (h2 != null) {
          p2 = (h2 + (u2 - 1) * m2) % u2;
          break;
        }
      }
      var g2 = i2.toGlobalCoord(l2[0].coord), _2 = o2.getAreaStyle();
      s2 = M(s2) ? s2 : [s2];
      for (var m2 = 1; m2 < l2.length; m2++) {
        var v2 = i2.toGlobalCoord(l2[m2].coord), y2 = void 0, b2 = void 0, x2 = void 0, S2 = void 0;
        i2.isHorizontal() ? (y2 = g2, b2 = c2.y, x2 = v2 - y2, S2 = c2.height, g2 = y2 + x2) : (y2 = c2.x, b2 = g2, x2 = c2.width, S2 = v2 - b2, g2 = b2 + S2);
        var C2 = l2[m2 - 1].tickValue;
        C2 != null && f2.set(C2, p2), t2.add(new T({ anid: C2 == null ? null : `area_` + C2, shape: { x: y2, y: b2, width: x2, height: S2 }, style: R({ fill: s2[p2] }, _2), autoBatch: true, silent: true })), p2 = (p2 + 1) % u2;
      }
      Wn(e2).splitAreaColors = f2;
    }
  }
}
function Kn(e2) {
  Wn(e2).splitAreaColors = null;
}
P();
var qn = [`axisLine`, `axisTickLabel`, `axisName`], Jn = [`splitArea`, `splitLine`, `minorSplitLine`], Yn = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2.axisPointerClass = `CartesianAxisPointer`, n2;
  }
  return t2.prototype.render = function(t3, n2, r2, i2) {
    this.group.removeAll();
    var a2 = this._axisGroup;
    if (this._axisGroup = new se(), this.group.add(this._axisGroup), t3.get(`show`)) {
      var o2 = t3.getCoordSysModel(), s2 = fn(o2, t3), c2 = new K(t3, Vt({ handleAutoShown: function(e3) {
        for (var n3 = o2.coordinateSystem.getCartesians(), r3 = 0; r3 < n3.length; r3++) if (Ye(n3[r3].getOtherAxis(t3.axis).scale)) return true;
        return false;
      } }, s2));
      F(qn, c2.add, c2), this._axisGroup.add(c2.getGroup()), F(Jn, function(e3) {
        t3.get([e3, `show`]) && Xn[e3](this, this._axisGroup, t3, o2);
      }, this), i2 && i2.type === `changeAxisOrder` && i2.isInitSort || at(a2, this._axisGroup, t3), e2.prototype.render.call(this, t3, n2, r2, i2);
    }
  }, t2.prototype.remove = function() {
    Kn(this);
  }, t2.type = `cartesianAxis`, t2;
})(Un), Xn = { splitLine: function(e2, t2, n2, r2) {
  var i2 = n2.axis;
  if (!i2.scale.isBlank()) {
    var a2 = n2.getModel(`splitLine`), o2 = a2.getModel(`lineStyle`), s2 = o2.get(`color`), c2 = a2.get(`showMinLine`) !== false, l2 = a2.get(`showMaxLine`) !== false;
    s2 = M(s2) ? s2 : [s2];
    for (var u2 = r2.coordinateSystem.getRect(), d2 = i2.isHorizontal(), f2 = 0, p2 = i2.getTicksCoords({ tickModel: a2 }), m2 = [], h2 = [], g2 = o2.getLineStyle(), _2 = 0; _2 < p2.length; _2++) {
      var v2 = i2.toGlobalCoord(p2[_2].coord);
      if (!(_2 === 0 && !c2 || _2 === p2.length - 1 && !l2)) {
        var y2 = p2[_2].tickValue;
        d2 ? (m2[0] = v2, m2[1] = u2.y, h2[0] = v2, h2[1] = u2.y + u2.height) : (m2[0] = u2.x, m2[1] = v2, h2[0] = u2.x + u2.width, h2[1] = v2);
        var b2 = f2++ % s2.length, x2 = new Ht({ anid: y2 == null ? null : `line_` + y2, autoBatch: true, shape: { x1: m2[0], y1: m2[1], x2: h2[0], y2: h2[1] }, style: R({ stroke: s2[b2] }, g2), silent: true });
        bt(x2.shape, g2.lineWidth), t2.add(x2);
      }
    }
  }
}, minorSplitLine: function(e2, t2, n2, r2) {
  var i2 = n2.axis, a2 = n2.getModel(`minorSplitLine`).getModel(`lineStyle`), o2 = r2.coordinateSystem.getRect(), s2 = i2.isHorizontal(), c2 = i2.getMinorTicksCoords();
  if (c2.length) for (var l2 = [], u2 = [], d2 = a2.getLineStyle(), f2 = 0; f2 < c2.length; f2++) for (var p2 = 0; p2 < c2[f2].length; p2++) {
    var m2 = i2.toGlobalCoord(c2[f2][p2].coord);
    s2 ? (l2[0] = m2, l2[1] = o2.y, u2[0] = m2, u2[1] = o2.y + o2.height) : (l2[0] = o2.x, l2[1] = m2, u2[0] = o2.x + o2.width, u2[1] = m2);
    var h2 = new Ht({ anid: `minor_line_` + c2[f2][p2].tickValue, autoBatch: true, shape: { x1: l2[0], y1: l2[1], x2: u2[0], y2: u2[1] }, style: d2, silent: true });
    bt(h2.shape, d2.lineWidth), t2.add(h2);
  }
}, splitArea: function(e2, t2, n2, r2) {
  Gn(e2, t2, n2, r2);
} }, Zn = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.type = `xAxis`, t2;
})(Yn), Qn = (function(e2) {
  D(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3.type = Zn.type, t3;
  }
  return t2.type = `yAxis`, t2;
})(Yn);
P();
var $n = (function(e2) {
  D(t2, e2);
  function t2() {
    var t3 = e2 !== null && e2.apply(this, arguments) || this;
    return t3.type = `grid`, t3;
  }
  return t2.prototype.render = function(e3, t3) {
    this.group.removeAll(), e3.get(`show`) && this.group.add(new T({ shape: e3.coordinateSystem.getRect(), style: R({ fill: e3.get(`backgroundColor`) }, e3.getItemStyle()), silent: true, z2: -1 }));
  }, t2.type = `grid`, t2;
})(E), er = { offset: 0 };
function tr(e2) {
  e2.registerComponentView($n), e2.registerComponentModel(Zt), e2.registerCoordinateSystem(`cartesian2d`, _n), an(e2, `x`, Qt, er), an(e2, `y`, Qt, er), e2.registerComponentView(Zn), e2.registerComponentView(Qn), e2.registerPreprocessor(function(e3) {
    e3.xAxis && e3.yAxis && !e3.grid && (e3.grid = {});
  });
}
var nr = `\0_ec_interaction_mutex`;
function rr(e2, t2, n2) {
  var r2 = ar(e2);
  r2[t2] = n2;
}
function ir(e2, t2, n2) {
  var r2 = ar(e2);
  r2[t2] === n2 && (r2[t2] = null);
}
function ar(e2) {
  return e2[nr] || (e2[nr] = {});
}
ee({ type: `takeGlobalCursor`, event: `globalCursorTaken`, update: `update` }, ie);
var or = { axisPointer: 1, tooltip: 1, brush: 1 };
function sr(e2, t2, n2) {
  var r2 = t2.getComponentByElement(e2.topTarget), i2 = r2 && r2.coordinateSystem;
  return r2 && r2 !== n2 && !or.hasOwnProperty(r2.mainType) && i2 && i2.model !== n2;
}
function cr(e2, t2, n2, r2, i2, a2) {
  e2 || (e2 = 0);
  var o2 = n2[1] - n2[0];
  if (i2 != null && (i2 = ur(i2, [0, o2])), a2 != null && (a2 = Math.max(a2, i2 ?? 0)), r2 === `all`) {
    var s2 = Math.abs(t2[1] - t2[0]);
    s2 = ur(s2, [0, o2]), i2 = a2 = ur(s2, [i2, a2]), r2 = 0;
  }
  t2[0] = ur(t2[0], n2), t2[1] = ur(t2[1], n2);
  var c2 = lr(t2, r2);
  t2[r2] += e2;
  var l2 = i2 || 0, u2 = n2.slice();
  c2.sign < 0 ? u2[0] += l2 : u2[1] -= l2, t2[r2] = ur(t2[r2], u2);
  var d2 = lr(t2, r2);
  return i2 != null && (d2.sign !== c2.sign || d2.span < i2) && (t2[1 - r2] = t2[r2] + c2.sign * i2), d2 = lr(t2, r2), a2 != null && d2.span > a2 && (t2[1 - r2] = t2[r2] + d2.sign * a2), t2;
}
function lr(e2, t2) {
  var n2 = e2[t2] - e2[1 - t2];
  return { span: Math.abs(n2), sign: n2 > 0 ? -1 : n2 < 0 ? 1 : t2 ? -1 : 1 };
}
function ur(e2, t2) {
  return Math.min(t2[1] == null ? 1 / 0 : t2[1], Math.max(t2[0] == null ? -1 / 0 : t2[0], e2));
}
P();
var dr = true, fr = Math.min, pr = Math.max, mr = Math.pow, hr = 1e4, gr = 6, _r = 6, vr = `globalPan`, yr = { w: [0, 0], e: [0, 1], n: [1, 0], s: [1, 1] }, br = { w: `ew`, e: `ew`, n: `ns`, s: `ns`, ne: `nesw`, sw: `nesw`, nw: `nwse`, se: `nwse` }, xr = { brushStyle: { lineWidth: 2, stroke: `rgba(210,219,238,0.3)`, fill: `#D2DBEE` }, transformable: true, brushMode: `single`, removeOnClick: false }, Sr = 0, Cr = (function(e2) {
  D(t2, e2);
  function t2(t3) {
    var n2 = e2.call(this) || this;
    return n2._track = [], n2._covers = [], n2._handlers = {}, n2._zr = t3, n2.group = new se(), n2._uid = `brushController_` + Sr++, F(ei, function(e3, t4) {
      this._handlers[t4] = I(e3, this);
    }, n2), n2;
  }
  return t2.prototype.enableBrush = function(e3) {
    return this._brushType && this._doDisableBrush(), e3.brushType && this._doEnableBrush(e3), this;
  }, t2.prototype._doEnableBrush = function(e3) {
    var t3 = this._zr;
    this._enableGlobalPan || rr(t3, vr, this._uid), F(this._handlers, function(e4, n2) {
      t3.on(n2, e4);
    }), this._brushType = e3.brushType, this._brushOption = k(L(xr), e3, true);
  }, t2.prototype._doDisableBrush = function() {
    var e3 = this._zr;
    ir(e3, vr, this._uid), F(this._handlers, function(t3, n2) {
      e3.off(n2, t3);
    }), this._brushType = this._brushOption = null;
  }, t2.prototype.setPanels = function(e3) {
    if (e3 && e3.length) {
      var t3 = this._panels = {};
      F(e3, function(e4) {
        t3[e4.panelId] = L(e4);
      });
    } else this._panels = null;
    return this;
  }, t2.prototype.mount = function(e3) {
    e3 || (e3 = {}), this._enableGlobalPan = e3.enableGlobalPan;
    var t3 = this.group;
    return this._zr.add(t3), t3.attr({ x: e3.x || 0, y: e3.y || 0, rotation: e3.rotation || 0, scaleX: e3.scaleX || 1, scaleY: e3.scaleY || 1 }), this._transform = t3.getLocalTransform(), this;
  }, t2.prototype.updateCovers = function(e3) {
    e3 = O(e3, function(e4) {
      return k(L(xr), e4, true);
    });
    var t3 = `\0-brush-index-`, n2 = this._covers, r2 = this._covers = [], i2 = this, a2 = this._creatingCover;
    return new je(n2, e3, s2, o2).add(c2).update(c2).remove(l2).execute(), this;
    function o2(e4, n3) {
      return (e4.id == null ? t3 + n3 : e4.id) + `-` + e4.brushType;
    }
    function s2(e4, t4) {
      return o2(e4.__brushOption, t4);
    }
    function c2(t4, o3) {
      var s3 = e3[t4];
      o3 != null && n2[o3] === a2 ? r2[t4] = n2[o3] : Or(i2, r2[t4] = o3 == null ? Tr(i2, wr(i2, s3)) : (n2[o3].__brushOption = s3, n2[o3]));
    }
    function l2(e4) {
      n2[e4] !== a2 && i2.group.remove(n2[e4]);
    }
  }, t2.prototype.unmount = function() {
    return this.enableBrush(false), Mr(this), this._zr.remove(this.group), this;
  }, t2.prototype.dispose = function() {
    this.unmount(), this.off();
  }, t2;
})(_t);
function wr(e2, t2) {
  var n2 = ri[t2.brushType].createCover(e2, t2);
  return n2.__brushOption = t2, Dr(n2, t2), e2.group.add(n2), n2;
}
function Tr(e2, t2) {
  var n2 = kr(t2);
  return n2.endCreating && (n2.endCreating(e2, t2), Dr(t2, t2.__brushOption)), t2;
}
function Er(e2, t2) {
  var n2 = t2.__brushOption;
  kr(t2).updateCoverShape(e2, t2, n2.range, n2);
}
function Dr(e2, t2) {
  var n2 = t2.z;
  n2 ?? (n2 = hr), e2.traverse(function(e3) {
    e3.z = n2, e3.z2 = n2;
  });
}
function Or(e2, t2) {
  kr(t2).updateCommon(e2, t2), Er(e2, t2);
}
function kr(e2) {
  return ri[e2.__brushOption.brushType];
}
function Ar(e2, t2, n2) {
  var r2 = e2._panels;
  if (!r2) return dr;
  var i2, a2 = e2._transform;
  return F(r2, function(e3) {
    e3.isTargetByCursor(t2, n2, a2) && (i2 = e3);
  }), i2;
}
function jr(e2, t2) {
  var n2 = e2._panels;
  if (!n2) return dr;
  var r2 = t2.__brushOption.panelId;
  return r2 == null ? dr : n2[r2];
}
function Mr(e2) {
  var t2 = e2._covers, n2 = t2.length;
  return F(t2, function(t3) {
    e2.group.remove(t3);
  }, e2), t2.length = 0, !!n2;
}
function Nr(e2, t2) {
  var n2 = O(e2._covers, function(e3) {
    var t3 = e3.__brushOption, n3 = L(t3.range);
    return { brushType: t3.brushType, panelId: t3.panelId, range: n3 };
  });
  e2.trigger(`brush`, { areas: n2, isEnd: !!t2.isEnd, removeOnClick: !!t2.removeOnClick });
}
function Pr(e2) {
  var t2 = e2._track;
  if (!t2.length) return false;
  var n2 = t2[t2.length - 1], r2 = t2[0], i2 = n2[0] - r2[0], a2 = n2[1] - r2[1];
  return mr(i2 * i2 + a2 * a2, 0.5) > gr;
}
function Fr(e2) {
  var t2 = e2.length - 1;
  return t2 < 0 && (t2 = 0), [e2[0], e2[t2]];
}
function Ir(e2, t2, n2, r2) {
  var i2 = new se();
  return i2.add(new T({ name: `main`, style: zr(n2), silent: true, draggable: true, cursor: `move`, drift: B(Wr, e2, t2, i2, [`n`, `s`, `w`, `e`]), ondragend: B(Nr, t2, { isEnd: true }) })), F(r2, function(n3) {
    i2.add(new T({ name: n3.join(``), style: { opacity: 0 }, draggable: true, silent: true, invisible: true, drift: B(Wr, e2, t2, i2, n3), ondragend: B(Nr, t2, { isEnd: true }) }));
  }), i2;
}
function Lr(e2, t2, n2, r2) {
  var i2 = r2.brushStyle.lineWidth || 0, a2 = pr(i2, _r), o2 = n2[0][0], s2 = n2[1][0], c2 = o2 - i2 / 2, l2 = s2 - i2 / 2, u2 = n2[0][1], d2 = n2[1][1], f2 = u2 - a2 + i2 / 2, p2 = d2 - a2 + i2 / 2, m2 = u2 - o2, h2 = d2 - s2, g2 = m2 + i2, _2 = h2 + i2;
  J(e2, t2, `main`, o2, s2, m2, h2), r2.transformable && (J(e2, t2, `w`, c2, l2, a2, _2), J(e2, t2, `e`, f2, l2, a2, _2), J(e2, t2, `n`, c2, l2, g2, a2), J(e2, t2, `s`, c2, p2, g2, a2), J(e2, t2, `nw`, c2, l2, a2, a2), J(e2, t2, `ne`, f2, l2, a2, a2), J(e2, t2, `sw`, c2, p2, a2, a2), J(e2, t2, `se`, f2, p2, a2, a2));
}
function Rr(e2, t2) {
  var n2 = t2.__brushOption, r2 = n2.transformable, i2 = t2.childAt(0);
  i2.useStyle(zr(n2)), i2.attr({ silent: !r2, cursor: r2 ? `move` : `default` }), F([[`w`], [`e`], [`n`], [`s`], [`s`, `e`], [`s`, `w`], [`n`, `e`], [`n`, `w`]], function(n3) {
    var i3 = t2.childOfName(n3.join(``)), a2 = n3.length === 1 ? Hr(e2, n3[0]) : Ur(e2, n3);
    i3 && i3.attr({ silent: !r2, invisible: !r2, cursor: r2 ? br[a2] + `-resize` : null });
  });
}
function J(e2, t2, n2, r2, i2, a2, o2) {
  var s2 = t2.childOfName(n2);
  s2 && s2.setShape(Jr(qr(e2, t2, [[r2, i2], [r2 + a2, i2 + o2]])));
}
function zr(e2) {
  return R({ strokeNoScale: true }, e2.brushStyle);
}
function Br(e2, t2, n2, r2) {
  var i2 = [fr(e2, n2), fr(t2, r2)], a2 = [pr(e2, n2), pr(t2, r2)];
  return [[i2[0], a2[0]], [i2[1], a2[1]]];
}
function Vr(e2) {
  return zt(e2.group);
}
function Hr(e2, t2) {
  return { left: `w`, right: `e`, top: `n`, bottom: `s` }[lt({ w: `left`, e: `right`, n: `top`, s: `bottom` }[t2], Vr(e2))];
}
function Ur(e2, t2) {
  var n2 = [Hr(e2, t2[0]), Hr(e2, t2[1])];
  return (n2[0] === `e` || n2[0] === `w`) && n2.reverse(), n2.join(``);
}
function Wr(e2, t2, n2, r2, i2, a2) {
  var o2 = n2.__brushOption, s2 = e2.toRectRange(o2.range), c2 = Kr(t2, i2, a2);
  F(r2, function(e3) {
    var t3 = yr[e3];
    s2[t3[0]][t3[1]] += c2[t3[0]];
  }), o2.range = e2.fromRectRange(Br(s2[0][0], s2[1][0], s2[0][1], s2[1][1])), Or(t2, n2), Nr(t2, { isEnd: false });
}
function Gr(e2, t2, n2, r2) {
  var i2 = t2.__brushOption.range, a2 = Kr(e2, n2, r2);
  F(i2, function(e3) {
    e3[0] += a2[0], e3[1] += a2[1];
  }), Or(e2, t2), Nr(e2, { isEnd: false });
}
function Kr(e2, t2, n2) {
  var r2 = e2.group, i2 = r2.transformCoordToLocal(t2, n2), a2 = r2.transformCoordToLocal(0, 0);
  return [i2[0] - a2[0], i2[1] - a2[1]];
}
function qr(e2, t2, n2) {
  var r2 = jr(e2, t2);
  return r2 && r2 !== dr ? r2.clipPath(n2, e2._transform) : L(n2);
}
function Jr(e2) {
  var t2 = fr(e2[0][0], e2[1][0]), n2 = fr(e2[0][1], e2[1][1]), r2 = pr(e2[0][0], e2[1][0]), i2 = pr(e2[0][1], e2[1][1]);
  return { x: t2, y: n2, width: r2 - t2, height: i2 - n2 };
}
function Yr(e2, t2, n2) {
  if (e2._brushType && !ni(e2, t2.offsetX, t2.offsetY)) {
    var r2 = e2._zr, i2 = e2._covers, a2 = Ar(e2, t2, n2);
    if (!e2._dragging) for (var o2 = 0; o2 < i2.length; o2++) {
      var s2 = i2[o2].__brushOption;
      if (a2 && (a2 === dr || s2.panelId === a2.panelId) && ri[s2.brushType].contain(i2[o2], n2[0], n2[1])) return;
    }
    a2 && r2.setCursorStyle(`crosshair`);
  }
}
function Xr(e2) {
  var t2 = e2.event;
  t2.preventDefault && t2.preventDefault();
}
function Zr(e2, t2, n2) {
  return e2.childOfName(`main`).contain(t2, n2);
}
function Qr(e2, t2, n2, r2) {
  var i2 = e2._creatingCover, a2 = e2._creatingPanel, o2 = e2._brushOption, s2;
  if (e2._track.push(n2.slice()), Pr(e2) || i2) {
    if (a2 && !i2) {
      o2.brushMode === `single` && Mr(e2);
      var c2 = L(o2);
      c2.brushType = $r(c2.brushType, a2), c2.panelId = a2 === dr ? null : a2.panelId, i2 = e2._creatingCover = wr(e2, c2), e2._covers.push(i2);
    }
    if (i2) {
      var l2 = ri[$r(e2._brushType, a2)], u2 = i2.__brushOption;
      u2.range = l2.getCreatingRange(qr(e2, i2, e2._track)), r2 && (Tr(e2, i2), l2.updateCommon(e2, i2)), Er(e2, i2), s2 = { isEnd: r2 };
    }
  } else r2 && o2.brushMode === `single` && o2.removeOnClick && Ar(e2, t2, n2) && Mr(e2) && (s2 = { isEnd: r2, removeOnClick: true });
  return s2;
}
function $r(e2, t2) {
  return e2 === `auto` ? t2.defaultBrushType : e2;
}
var ei = { mousedown: function(e2) {
  if (this._dragging) ti(this, e2);
  else if (!e2.target || !e2.target.draggable) {
    Xr(e2);
    var t2 = this.group.transformCoordToLocal(e2.offsetX, e2.offsetY);
    this._creatingCover = null, (this._creatingPanel = Ar(this, e2, t2)) && (this._dragging = true, this._track = [t2.slice()]);
  }
}, mousemove: function(e2) {
  var t2 = e2.offsetX, n2 = e2.offsetY, r2 = this.group.transformCoordToLocal(t2, n2);
  if (Yr(this, e2, r2), this._dragging) {
    Xr(e2);
    var i2 = Qr(this, e2, r2, false);
    i2 && Nr(this, i2);
  }
}, mouseup: function(e2) {
  ti(this, e2);
} };
function ti(e2, t2) {
  if (e2._dragging) {
    Xr(t2);
    var n2 = t2.offsetX, r2 = t2.offsetY, i2 = Qr(e2, t2, e2.group.transformCoordToLocal(n2, r2), true);
    e2._dragging = false, e2._track = [], e2._creatingCover = null, i2 && Nr(e2, i2);
  }
}
function ni(e2, t2, n2) {
  var r2 = e2._zr;
  return t2 < 0 || t2 > r2.getWidth() || n2 < 0 || n2 > r2.getHeight();
}
var ri = { lineX: ii(0), lineY: ii(1), rect: { createCover: function(e2, t2) {
  function n2(e3) {
    return e3;
  }
  return Ir({ toRectRange: n2, fromRectRange: n2 }, e2, t2, [[`w`], [`e`], [`n`], [`s`], [`s`, `e`], [`s`, `w`], [`n`, `e`], [`n`, `w`]]);
}, getCreatingRange: function(e2) {
  var t2 = Fr(e2);
  return Br(t2[1][0], t2[1][1], t2[0][0], t2[0][1]);
}, updateCoverShape: function(e2, t2, n2, r2) {
  Lr(e2, t2, n2, r2);
}, updateCommon: Rr, contain: Zr }, polygon: { createCover: function(e2, t2) {
  var n2 = new se();
  return n2.add(new Kt({ name: `main`, style: zr(t2), silent: true })), n2;
}, getCreatingRange: function(e2) {
  return e2;
}, endCreating: function(e2, t2) {
  t2.remove(t2.childAt(0)), t2.add(new Xe({ name: `main`, draggable: true, drift: B(Gr, e2, t2), ondragend: B(Nr, e2, { isEnd: true }) }));
}, updateCoverShape: function(e2, t2, n2, r2) {
  t2.childAt(0).setShape({ points: qr(e2, t2, n2) });
}, updateCommon: Rr, contain: Zr } };
function ii(e2) {
  return { createCover: function(t2, n2) {
    return Ir({ toRectRange: function(t3) {
      var n3 = [t3, [0, 100]];
      return e2 && n3.reverse(), n3;
    }, fromRectRange: function(t3) {
      return t3[e2];
    } }, t2, n2, [[[`w`], [`e`]], [[`n`], [`s`]]][e2]);
  }, getCreatingRange: function(t2) {
    var n2 = Fr(t2);
    return [fr(n2[0][e2], n2[1][e2]), pr(n2[0][e2], n2[1][e2])];
  }, updateCoverShape: function(t2, n2, r2, i2) {
    var a2, o2 = jr(t2, n2);
    if (o2 !== dr && o2.getLinearBrushOtherExtent) a2 = o2.getLinearBrushOtherExtent(e2);
    else {
      var s2 = t2._zr;
      a2 = [0, [s2.getWidth(), s2.getHeight()][1 - e2]];
    }
    var c2 = [r2, a2];
    e2 && c2.reverse(), Lr(t2, n2, c2, i2);
  }, updateCommon: Rr, contain: Zr };
}
function ai(e2) {
  return e2 = ci(e2), function(t2) {
    return $e(t2, e2);
  };
}
function oi(e2, t2) {
  return e2 = ci(e2), function(n2) {
    var r2 = t2 ?? n2, i2 = r2 ? e2.width : e2.height, a2 = r2 ? e2.x : e2.y;
    return [a2, a2 + (i2 || 0)];
  };
}
function si(e2, t2, n2) {
  var r2 = ci(e2);
  return function(e3, i2) {
    return r2.contain(i2[0], i2[1]) && !sr(e3, t2, n2);
  };
}
function ci(e2) {
  return Ue.create(e2);
}
var li = mt(), ui = L, di = I, fi = (function() {
  function e2() {
    this._dragging = false, this.animationThreshold = 15;
  }
  return e2.prototype.render = function(e3, t2, n2, r2) {
    var i2 = t2.get(`value`), a2 = t2.get(`status`);
    if (this._axisModel = e3, this._axisPointerModel = t2, this._api = n2, r2 || this._lastValue !== i2 || this._lastStatus !== a2) {
      this._lastValue = i2, this._lastStatus = a2;
      var o2 = this._group, s2 = this._handle;
      if (!a2 || a2 === `hide`) {
        o2 && o2.hide(), s2 && s2.hide();
        return;
      }
      o2 && o2.show(), s2 && s2.show();
      var c2 = {};
      this.makeElOption(c2, i2, e3, t2, n2);
      var l2 = c2.graphicKey;
      l2 !== this._lastGraphicKey && this.clear(n2), this._lastGraphicKey = l2;
      var u2 = this._moveAnimation = this.determineAnimation(e3, t2);
      if (!o2) o2 = this._group = new se(), this.createPointerEl(o2, c2, e3, t2), this.createLabelEl(o2, c2, e3, t2), n2.getZr().add(o2);
      else {
        var d2 = B(pi, t2, u2);
        this.updatePointerEl(o2, c2, d2), this.updateLabelEl(o2, c2, d2, t2);
      }
      _i(o2, t2, true), this._renderHandle(i2);
    }
  }, e2.prototype.remove = function(e3) {
    this.clear(e3);
  }, e2.prototype.dispose = function(e3) {
    this.clear(e3);
  }, e2.prototype.determineAnimation = function(e3, t2) {
    var n2 = t2.get(`animation`), r2 = e3.axis, i2 = r2.type === `category`, a2 = t2.get(`snap`);
    if (!a2 && !i2) return false;
    if (n2 === `auto` || n2 == null) {
      var o2 = this.animationThreshold;
      if (i2 && r2.getBandWidth() > o2) return true;
      if (a2) {
        var s2 = Rn(e3).seriesDataCount, c2 = r2.getExtent();
        return Math.abs(c2[0] - c2[1]) / s2 > o2;
      }
      return false;
    }
    return n2 === true;
  }, e2.prototype.makeElOption = function(e3, t2, n2, r2, i2) {
  }, e2.prototype.createPointerEl = function(e3, t2, n2, r2) {
    var i2 = t2.pointer;
    if (i2) {
      var a2 = li(e3).pointerEl = new tt[i2.type](ui(t2.pointer));
      e3.add(a2);
    }
  }, e2.prototype.createLabelEl = function(e3, t2, n2, r2) {
    if (t2.label) {
      var i2 = li(e3).labelEl = new N(ui(t2.label));
      e3.add(i2), hi(i2, r2);
    }
  }, e2.prototype.updatePointerEl = function(e3, t2, n2) {
    var r2 = li(e3).pointerEl;
    r2 && t2.pointer && (r2.setStyle(t2.pointer.style), n2(r2, { shape: t2.pointer.shape }));
  }, e2.prototype.updateLabelEl = function(e3, t2, n2, r2) {
    var i2 = li(e3).labelEl;
    i2 && (i2.setStyle(t2.label.style), n2(i2, { x: t2.label.x, y: t2.label.y }), hi(i2, r2));
  }, e2.prototype._renderHandle = function(e3) {
    if (!this._dragging && this.updateHandleTransform) {
      var t2 = this._axisPointerModel, n2 = this._api.getZr(), r2 = this._handle, i2 = t2.getModel(`handle`), a2 = t2.get(`status`);
      if (!i2.get(`show`) || !a2 || a2 === `hide`) {
        r2 && n2.remove(r2), this._handle = null;
        return;
      }
      var o2;
      this._handle || (o2 = true, r2 = this._handle = vt(i2.get(`icon`), { cursor: `move`, draggable: true, onmousemove: function(e4) {
        wt(e4.event);
      }, onmousedown: di(this._onHandleDragMove, this, 0, 0), drift: di(this._onHandleDragMove, this), ondragend: di(this._onHandleDragEnd, this) }), n2.add(r2)), _i(r2, t2, false), r2.setStyle(i2.getItemStyle(null, [`color`, `borderColor`, `borderWidth`, `opacity`, `shadowColor`, `shadowBlur`, `shadowOffsetX`, `shadowOffsetY`]));
      var s2 = i2.get(`size`);
      M(s2) || (s2 = [s2, s2]), r2.scaleX = s2[0] / 2, r2.scaleY = s2[1] / 2, Ce(this, `_doDispatchAxisPointer`, i2.get(`throttle`) || 0, `fixRate`), this._moveHandleToValue(e3, o2);
    }
  }, e2.prototype._moveHandleToValue = function(e3, t2) {
    pi(this._axisPointerModel, !t2 && this._moveAnimation, this._handle, gi(this.getHandleTransform(e3, this._axisModel, this._axisPointerModel)));
  }, e2.prototype._onHandleDragMove = function(e3, t2) {
    var n2 = this._handle;
    if (n2) {
      this._dragging = true;
      var r2 = this.updateHandleTransform(gi(n2), [e3, t2], this._axisModel, this._axisPointerModel);
      this._payloadInfo = r2, n2.stopAnimation(), n2.attr(gi(r2)), li(n2).lastProp = null, this._doDispatchAxisPointer();
    }
  }, e2.prototype._doDispatchAxisPointer = function() {
    if (this._handle) {
      var e3 = this._payloadInfo, t2 = this._axisModel;
      this._api.dispatchAction({ type: `updateAxisPointer`, x: e3.cursorPoint[0], y: e3.cursorPoint[1], tooltipOption: e3.tooltipOption, axesInfo: [{ axisDim: t2.axis.dim, axisIndex: t2.componentIndex }] });
    }
  }, e2.prototype._onHandleDragEnd = function() {
    if (this._dragging = false, this._handle) {
      var e3 = this._axisPointerModel.get(`value`);
      this._moveHandleToValue(e3), this._api.dispatchAction({ type: `hideTip` });
    }
  }, e2.prototype.clear = function(e3) {
    this._lastValue = null, this._lastStatus = null;
    var t2 = e3.getZr(), n2 = this._group, r2 = this._handle;
    t2 && n2 && (this._lastGraphicKey = null, n2 && t2.remove(n2), r2 && t2.remove(r2), this._group = null, this._handle = null, this._payloadInfo = null), xe(this, `_doDispatchAxisPointer`);
  }, e2.prototype.doClear = function() {
  }, e2.prototype.buildLabel = function(e3, t2, n2) {
    return n2 || (n2 = 0), { x: e3[n2], y: e3[1 - n2], width: t2[n2], height: t2[1 - n2] };
  }, e2;
})();
function pi(e2, t2, n2, r2) {
  mi(li(n2).lastProp, r2) || (li(n2).lastProp = r2, t2 ? st(n2, r2, e2) : (n2.stopAnimation(), n2.attr(r2)));
}
function mi(e2, t2) {
  if (A(e2) && A(t2)) {
    var n2 = true;
    return F(t2, function(t3, r2) {
      n2 && (n2 = mi(e2[r2], t3));
    }), !!n2;
  }
  return e2 === t2;
}
function hi(e2, t2) {
  e2[t2.get([`label`, `show`]) ? `show` : `hide`]();
}
function gi(e2) {
  return { x: e2.x || 0, y: e2.y || 0, rotation: e2.rotation || 0 };
}
function _i(e2, t2, n2) {
  var r2 = t2.get(`z`), i2 = t2.get(`zlevel`);
  e2 && e2.traverse(function(e3) {
    e3.type !== `group` && (r2 != null && (e3.z = r2), i2 != null && (e3.zlevel = i2), e3.silent = n2);
  });
}
function vi(e2) {
  var t2 = e2.get(`type`), n2 = e2.getModel(t2 + `Style`), r2;
  return t2 === `line` ? (r2 = n2.getLineStyle(), r2.fill = null) : t2 === `shadow` && (r2 = n2.getAreaStyle(), r2.stroke = null), r2;
}
function yi(e2, t2, n2, r2, i2) {
  var a2 = xi(n2.get(`value`), t2.axis, t2.ecModel, n2.get(`seriesDataIndices`), { precision: n2.get([`label`, `precision`]), formatter: n2.get([`label`, `formatter`]) }), o2 = n2.getModel(`label`), s2 = He(o2.get(`padding`) || 0), c2 = o2.getFont(), l2 = he(a2, c2), u2 = i2.position, d2 = l2.width + s2[1] + s2[3], f2 = l2.height + s2[0] + s2[2], p2 = i2.align;
  p2 === `right` && (u2[0] -= d2), p2 === `center` && (u2[0] -= d2 / 2);
  var m2 = i2.verticalAlign;
  m2 === `bottom` && (u2[1] -= f2), m2 === `middle` && (u2[1] -= f2 / 2), bi(u2, d2, f2, r2);
  var h2 = o2.get(`backgroundColor`);
  (!h2 || h2 === `auto`) && (h2 = t2.get([`axisLine`, `lineStyle`, `color`])), e2.label = { x: u2[0], y: u2[1], style: ft(o2, { text: a2, font: c2, fill: o2.getTextColor(), padding: s2, backgroundColor: h2 }), z2: 10 };
}
function bi(e2, t2, n2, r2) {
  var i2 = r2.getWidth(), a2 = r2.getHeight();
  e2[0] = Math.min(e2[0] + t2, i2) - t2, e2[1] = Math.min(e2[1] + n2, a2) - n2, e2[0] = Math.max(e2[0], 0), e2[1] = Math.max(e2[1], 0);
}
function xi(e2, t2, n2, r2, i2) {
  e2 = t2.scale.parse(e2);
  var a2 = t2.scale.getLabel({ value: e2 }, { precision: i2.precision }), o2 = i2.formatter;
  if (o2) {
    var s2 = { value: Lt(t2, { value: e2 }), axisDimension: t2.dim, axisIndex: t2.index, seriesData: [] };
    F(r2, function(e3) {
      var t3 = n2.getSeriesByIndex(e3.seriesIndex), r3 = e3.dataIndexInside, i3 = t3 && t3.getDataParams(r3);
      i3 && s2.seriesData.push(i3);
    }), z(o2) ? a2 = o2.replace(`{value}`, a2) : H(o2) && (a2 = o2(s2));
  }
  return a2;
}
function Si(e2, t2, n2) {
  var r2 = De();
  return St(r2, r2, n2.rotation), At(r2, r2, n2.position), Nt([e2.dataToCoord(t2), (n2.labelOffset || 0) + (n2.labelDirection || 1) * (n2.labelMargin || 0)], r2);
}
function Ci(e2, t2, n2, r2, i2, a2) {
  var o2 = K.innerTextLayout(n2.rotation, 0, n2.labelDirection);
  n2.labelMargin = i2.get([`label`, `margin`]), yi(t2, r2, i2, a2, { position: Si(r2.axis, e2, n2), align: o2.textAlign, verticalAlign: o2.textVerticalAlign });
}
function wi(e2, t2, n2) {
  return n2 || (n2 = 0), { x1: e2[n2], y1: e2[1 - n2], x2: t2[n2], y2: t2[1 - n2] };
}
function Ti(e2, t2, n2) {
  return n2 || (n2 = 0), { x: e2[n2], y: e2[1 - n2], width: t2[n2], height: t2[1 - n2] };
}
P();
var Ei = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.makeElOption = function(e3, t3, n2, r2, i2) {
    var a2 = n2.axis, o2 = a2.grid, s2 = r2.get(`type`), c2 = Di(o2, a2).getOtherAxis(a2).getGlobalExtent(), l2 = a2.toGlobalCoord(a2.dataToCoord(t3, true));
    if (s2 && s2 !== `none`) {
      var u2 = vi(r2), d2 = Oi[s2](a2, l2, c2);
      d2.style = u2, e3.graphicKey = d2.type, e3.pointer = d2;
    }
    Ci(t3, e3, fn(o2.model, n2), n2, r2, i2);
  }, t2.prototype.getHandleTransform = function(e3, t3, n2) {
    var r2 = fn(t3.axis.grid.model, t3, { labelInside: false });
    r2.labelMargin = n2.get([`handle`, `margin`]);
    var i2 = Si(t3.axis, e3, r2);
    return { x: i2[0], y: i2[1], rotation: r2.rotation + (r2.labelDirection < 0 ? Math.PI : 0) };
  }, t2.prototype.updateHandleTransform = function(e3, t3, n2, r2) {
    var i2 = n2.axis, a2 = i2.grid, o2 = i2.getGlobalExtent(true), s2 = Di(a2, i2).getOtherAxis(i2).getGlobalExtent(), c2 = i2.dim === `x` ? 0 : 1, l2 = [e3.x, e3.y];
    l2[c2] += t3[c2], l2[c2] = Math.min(o2[1], l2[c2]), l2[c2] = Math.max(o2[0], l2[c2]);
    var u2 = (s2[1] + s2[0]) / 2, d2 = [u2, u2];
    return d2[c2] = l2[c2], { x: l2[0], y: l2[1], rotation: e3.rotation, cursorPoint: d2, tooltipOption: [{ verticalAlign: `middle` }, { align: `center` }][c2] };
  }, t2;
})(fi);
function Di(e2, t2) {
  var n2 = {};
  return n2[t2.dim + `AxisIndex`] = t2.index, e2.getCartesian(n2);
}
var Oi = { line: function(e2, t2, n2) {
  return { type: `Line`, subPixelOptimize: true, shape: wi([t2, n2[0]], [t2, n2[1]], ki(e2)) };
}, shadow: function(e2, t2, n2) {
  var r2 = Math.max(1, e2.getBandWidth()), i2 = n2[1] - n2[0];
  return { type: `Rect`, shape: Ti([t2 - r2 / 2, n2[0]], [r2, i2], ki(e2)) };
} };
function ki(e2) {
  return e2.dim === `x` ? 0 : 1;
}
P();
var Ai = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.type = `axisPointer`, t2.defaultOption = { show: `auto`, z: 50, type: `line`, snap: false, triggerTooltip: true, triggerEmphasis: true, value: null, status: null, link: [], animation: null, animationDurationUpdate: 200, lineStyle: { color: `#B9BEC9`, width: 1, type: `dashed` }, shadowStyle: { color: `rgba(210,219,238,0.2)` }, label: { show: true, formatter: null, precision: `auto`, margin: 3, color: `#fff`, padding: [5, 7, 5, 7], backgroundColor: `auto`, borderColor: null, borderWidth: 0, borderRadius: 3 }, handle: { show: false, icon: `M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7v-1.2h6.6z M13.3,22H6.7v-1.2h6.6z M13.3,19.6H6.7v-1.2h6.6z`, size: 45, margin: 50, color: `#333`, shadowBlur: 3, shadowColor: `#aaa`, shadowOffsetX: 0, shadowOffsetY: 2, throttle: 40 } }, t2;
})(ce), Y = mt(), ji = F;
function Mi(e2, t2, n2) {
  if (!S.node) {
    var r2 = t2.getZr();
    Y(r2).records || (Y(r2).records = {}), Ni(r2, t2);
    var i2 = Y(r2).records[e2] || (Y(r2).records[e2] = {});
    i2.handler = n2;
  }
}
function Ni(e2, t2) {
  if (Y(e2).initialized) return;
  Y(e2).initialized = true, n2(`click`, B(Ii, `click`)), n2(`mousemove`, B(Ii, `mousemove`)), n2(`globalout`, Fi);
  function n2(n3, r2) {
    e2.on(n3, function(n4) {
      var i2 = Li(t2);
      ji(Y(e2).records, function(e3) {
        e3 && r2(e3, n4, i2.dispatchAction);
      }), Pi(i2.pendings, t2);
    });
  }
}
function Pi(e2, t2) {
  var n2 = e2.showTip.length, r2 = e2.hideTip.length, i2;
  n2 ? i2 = e2.showTip[n2 - 1] : r2 && (i2 = e2.hideTip[r2 - 1]), i2 && (i2.dispatchAction = null, t2.dispatchAction(i2));
}
function Fi(e2, t2, n2) {
  e2.handler(`leave`, null, n2);
}
function Ii(e2, t2, n2, r2) {
  t2.handler(e2, n2, r2);
}
function Li(e2) {
  var t2 = { showTip: [], hideTip: [] }, n2 = function(r2) {
    var i2 = t2[r2.type];
    i2 ? i2.push(r2) : (r2.dispatchAction = n2, e2.dispatchAction(r2));
  };
  return { dispatchAction: n2, pendings: t2 };
}
function Ri(e2, t2) {
  if (!S.node) {
    var n2 = t2.getZr();
    (Y(n2).records || {})[e2] && (Y(n2).records[e2] = null);
  }
}
P();
var zi = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.prototype.render = function(e3, t3, n2) {
    var r2 = t3.getComponent(`tooltip`), i2 = e3.get(`triggerOn`) || r2 && r2.get(`triggerOn`) || `mousemove|click`;
    Mi(`axisPointer`, n2, function(e4, t4, n3) {
      i2 !== `none` && (e4 === `leave` || i2.indexOf(e4) >= 0) && n3({ type: `updateAxisPointer`, currTrigger: e4, x: t4 && t4.offsetX, y: t4 && t4.offsetY });
    });
  }, t2.prototype.remove = function(e3, t3) {
    Ri(`axisPointer`, t3);
  }, t2.prototype.dispose = function(e3, t3) {
    Ri(`axisPointer`, t3);
  }, t2.type = `axisPointer`, t2;
})(E);
function Bi(e2, t2) {
  var n2 = [], r2 = e2.seriesIndex, i2;
  if (r2 == null || !(i2 = t2.getSeriesByIndex(r2))) return { point: [] };
  var a2 = i2.getData(), o2 = ae(a2, e2);
  if (o2 == null || o2 < 0 || M(o2)) return { point: [] };
  var s2 = a2.getItemGraphicEl(o2), c2 = i2.coordinateSystem;
  if (i2.getTooltipPosition) n2 = i2.getTooltipPosition(o2) || [];
  else if (c2 && c2.dataToPoint) {
    if (e2.isStacked) {
      var l2 = c2.getBaseAxis(), u2 = c2.getOtherAxis(l2).dim, d2 = l2.dim, f2 = +(u2 === `x` || u2 === `radius`), p2 = a2.mapDimension(d2), m2 = [];
      m2[f2] = a2.get(p2, o2), m2[1 - f2] = a2.get(a2.getCalculationInfo(`stackResultDimension`), o2), n2 = c2.dataToPoint(m2) || [];
    } else n2 = c2.dataToPoint(a2.getValues(O(c2.dimensions, function(e3) {
      return a2.mapDimension(e3);
    }), o2)) || [];
  } else if (s2) {
    var h2 = s2.getBoundingRect().clone();
    h2.applyTransform(s2.transform), n2 = [h2.x + h2.width / 2, h2.y + h2.height / 2];
  }
  return { point: n2, el: s2 };
}
var Vi = mt();
function Hi(e2, t2, n2) {
  var r2 = e2.currTrigger, i2 = [e2.x, e2.y], a2 = e2, o2 = e2.dispatchAction || I(n2.dispatchAction, n2), s2 = t2.getComponent(`axisPointer`).coordSysAxesInfo;
  if (s2) {
    Qi(i2) && (i2 = Bi({ seriesIndex: a2.seriesIndex, dataIndex: a2.dataIndex }, t2).point);
    var c2 = Qi(i2), l2 = a2.axesInfo, u2 = s2.axesInfo, d2 = r2 === `leave` || Qi(i2), f2 = {}, p2 = {}, m2 = { list: [], map: {} }, h2 = { showPointer: B(Gi, p2), showTooltip: B(Ki, m2) };
    F(s2.coordSysMap, function(e3, t3) {
      var n3 = c2 || e3.containPoint(i2);
      F(s2.coordSysAxesInfo[t3], function(e4, t4) {
        var r3 = e4.axis, a3 = Xi(l2, e4);
        if (!d2 && n3 && (!l2 || a3)) {
          var o3 = a3 && a3.value;
          o3 == null && !c2 && (o3 = r3.pointToData(i2)), o3 != null && Ui(e4, o3, h2, false, f2);
        }
      });
    });
    var g2 = {};
    return F(u2, function(e3, t3) {
      var n3 = e3.linkGroup;
      n3 && !p2[t3] && F(n3.axesInfo, function(t4, r3) {
        var i3 = p2[r3];
        if (t4 !== e3 && i3) {
          var a3 = i3.value;
          n3.mapper && (a3 = e3.axis.scale.parse(n3.mapper(a3, Zi(t4), Zi(e3)))), g2[e3.key] = a3;
        }
      });
    }), F(g2, function(e3, t3) {
      Ui(u2[t3], e3, h2, true, f2);
    }), qi(p2, u2, f2), Ji(m2, i2, e2, o2), Yi(u2, o2, n2), f2;
  }
}
function Ui(e2, t2, n2, r2, i2) {
  var a2 = e2.axis;
  if (!a2.scale.isBlank() && a2.containData(t2)) {
    if (!e2.involveSeries) {
      n2.showPointer(e2, t2);
      return;
    }
    var o2 = Wi(t2, e2), s2 = o2.payloadBatch, c2 = o2.snapToValue;
    s2[0] && i2.seriesIndex == null && Vt(i2, s2[0]), !r2 && e2.snap && a2.containData(c2) && c2 != null && (t2 = c2), n2.showPointer(e2, t2, s2), n2.showTooltip(e2, o2, c2);
  }
}
function Wi(e2, t2) {
  var n2 = t2.axis, r2 = n2.dim, i2 = e2, a2 = [], o2 = Number.MAX_VALUE, s2 = -1;
  return F(t2.seriesModels, function(t3, c2) {
    var l2 = t3.getData().mapDimensionsAll(r2), u2, d2;
    if (t3.getAxisTooltipData) {
      var f2 = t3.getAxisTooltipData(l2, e2, n2);
      d2 = f2.dataIndices, u2 = f2.nestestValue;
    } else {
      if (d2 = t3.getData().indicesOfNearest(l2[0], e2, n2.type === `category` ? 0.5 : null), !d2.length) return;
      u2 = t3.getData().get(l2[0], d2[0]);
    }
    if (u2 != null && isFinite(u2)) {
      var p2 = e2 - u2, m2 = Math.abs(p2);
      m2 <= o2 && ((m2 < o2 || p2 >= 0 && s2 < 0) && (o2 = m2, s2 = p2, i2 = u2, a2.length = 0), F(d2, function(e3) {
        a2.push({ seriesIndex: t3.seriesIndex, dataIndexInside: e3, dataIndex: t3.getData().getRawIndex(e3) });
      }));
    }
  }), { payloadBatch: a2, snapToValue: i2 };
}
function Gi(e2, t2, n2, r2) {
  e2[t2.key] = { value: n2, payloadBatch: r2 };
}
function Ki(e2, t2, n2, r2) {
  var i2 = n2.payloadBatch, a2 = t2.axis, o2 = a2.model, s2 = t2.axisPointerModel;
  if (t2.triggerTooltip && i2.length) {
    var c2 = t2.coordSys.model, l2 = Vn(c2), u2 = e2.map[l2];
    u2 || (u2 = e2.map[l2] = { coordSysId: c2.id, coordSysIndex: c2.componentIndex, coordSysType: c2.type, coordSysMainType: c2.mainType, dataByAxis: [] }, e2.list.push(u2)), u2.dataByAxis.push({ axisDim: a2.dim, axisIndex: o2.componentIndex, axisType: o2.type, axisId: o2.id, value: r2, valueLabelOpt: { precision: s2.get([`label`, `precision`]), formatter: s2.get([`label`, `formatter`]) }, seriesDataIndices: i2.slice() });
  }
}
function qi(e2, t2, n2) {
  var r2 = n2.axesInfo = [];
  F(t2, function(t3, n3) {
    var i2 = t3.axisPointerModel.option, a2 = e2[n3];
    a2 ? (!t3.useHandle && (i2.status = `show`), i2.value = a2.value, i2.seriesDataIndices = (a2.payloadBatch || []).slice()) : !t3.useHandle && (i2.status = `hide`), i2.status === `show` && r2.push({ axisDim: t3.axis.dim, axisIndex: t3.axis.model.componentIndex, value: i2.value });
  });
}
function Ji(e2, t2, n2, r2) {
  if (Qi(t2) || !e2.list.length) {
    r2({ type: `hideTip` });
    return;
  }
  var i2 = ((e2.list[0].dataByAxis[0] || {}).seriesDataIndices || [])[0] || {};
  r2({ type: `showTip`, escapeConnect: true, x: t2[0], y: t2[1], tooltipOption: n2.tooltipOption, position: n2.position, dataIndexInside: i2.dataIndexInside, dataIndex: i2.dataIndex, seriesIndex: i2.seriesIndex, dataByCoordSys: e2.list });
}
function Yi(e2, t2, n2) {
  var r2 = n2.getZr(), i2 = `axisPointerLastHighlights`, a2 = Vi(r2)[i2] || {}, o2 = Vi(r2)[i2] = {};
  F(e2, function(e3, t3) {
    var n3 = e3.axisPointerModel.option;
    n3.status === `show` && e3.triggerEmphasis && F(n3.seriesDataIndices, function(e4) {
      var t4 = e4.seriesIndex + ` | ` + e4.dataIndex;
      o2[t4] = e4;
    });
  });
  var s2 = [], c2 = [];
  F(a2, function(e3, t3) {
    !o2[t3] && c2.push(e3);
  }), F(o2, function(e3, t3) {
    !a2[t3] && s2.push(e3);
  }), c2.length && n2.dispatchAction({ type: `downplay`, escapeConnect: true, notBlur: true, batch: c2 }), s2.length && n2.dispatchAction({ type: `highlight`, escapeConnect: true, notBlur: true, batch: s2 });
}
function Xi(e2, t2) {
  for (var n2 = 0; n2 < (e2 || []).length; n2++) {
    var r2 = e2[n2];
    if (t2.axis.dim === r2.axisDim && t2.axis.model.componentIndex === r2.axisIndex) return r2;
  }
}
function Zi(e2) {
  var t2 = e2.axis.model, n2 = {}, r2 = n2.axisDim = e2.axis.dim;
  return n2.axisIndex = n2[r2 + `AxisIndex`] = t2.componentIndex, n2.axisName = n2[r2 + `AxisName`] = t2.name, n2.axisId = n2[r2 + `AxisId`] = t2.id, n2;
}
function Qi(e2) {
  return !e2 || e2[0] == null || isNaN(e2[0]) || e2[1] == null || isNaN(e2[1]);
}
function $i(e2) {
  Un.registerAxisPointerClass(`CartesianAxisPointer`, Ei), e2.registerComponentModel(Ai), e2.registerComponentView(zi), e2.registerPreprocessor(function(e3) {
    if (e3) {
      (!e3.axisPointer || e3.axisPointer.length === 0) && (e3.axisPointer = {});
      var t2 = e3.axisPointer.link;
      t2 && !M(t2) && (e3.axisPointer.link = [t2]);
    }
  }), e2.registerProcessor(e2.PRIORITY.PROCESSOR.STATISTIC, function(e3, t2) {
    e3.getComponent(`axisPointer`).coordSysAxesInfo = jn(e3, t2);
  }), e2.registerAction({ type: `updateAxisPointer`, event: `updateAxisPointer`, update: `:updateAxisPointer` }, Hi);
}
function ea(e2) {
  Ct(tr), Ct($i);
}
var ta = [`x`, `y`, `radius`, `angle`, `single`], na = [`cartesian2d`, `polar`, `singleAxis`];
function ra(e2) {
  var t2 = e2.get(`coordinateSystem`);
  return W(na, t2) >= 0;
}
function ia(e2) {
  return e2 + `Axis`;
}
function aa(e2, t2) {
  var n2 = Et(), r2 = [], i2 = Et();
  e2.eachComponent({ mainType: `dataZoom`, query: t2 }, function(e3) {
    i2.get(e3.uid) || s2(e3);
  });
  var a2;
  do
    a2 = false, e2.eachComponent(`dataZoom`, o2);
  while (a2);
  function o2(e3) {
    !i2.get(e3.uid) && c2(e3) && (s2(e3), a2 = true);
  }
  function s2(e3) {
    i2.set(e3.uid, true), r2.push(e3), l2(e3);
  }
  function c2(e3) {
    var t3 = false;
    return e3.eachTargetAxis(function(e4, r3) {
      var i3 = n2.get(e4);
      i3 && i3[r3] && (t3 = true);
    }), t3;
  }
  function l2(e3) {
    e3.eachTargetAxis(function(e4, t3) {
      (n2.get(e4) || n2.set(e4, []))[t3] = true;
    });
  }
  return r2;
}
P();
var oa = (function() {
  function e2() {
    this.indexList = [], this.indexMap = [];
  }
  return e2.prototype.add = function(e3) {
    this.indexMap[e3] || (this.indexList.push(e3), this.indexMap[e3] = true);
  }, e2;
})(), sa = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2._autoThrottle = true, n2._noTarget = true, n2._rangePropMode = [`percent`, `percent`], n2;
  }
  return t2.prototype.init = function(e3, t3, n2) {
    var r2 = ca(e3);
    this.settledOption = r2, this.mergeDefaultAndTheme(e3, n2), this._doInit(r2);
  }, t2.prototype.mergeOption = function(e3) {
    var t3 = ca(e3);
    k(this.option, e3, true), k(this.settledOption, t3, true), this._doInit(t3);
  }, t2.prototype._doInit = function(e3) {
    var t3 = this.option;
    this._setDefaultThrottle(e3), this._updateRangeUse(e3);
    var n2 = this.settledOption;
    F([[`start`, `startValue`], [`end`, `endValue`]], function(e4, r2) {
      this._rangePropMode[r2] === `value` && (t3[e4[0]] = n2[e4[0]] = null);
    }, this), this._resetTarget();
  }, t2.prototype._resetTarget = function() {
    var e3 = this.get(`orient`, true), t3 = this._targetAxisInfoMap = Et();
    this._fillSpecifiedTargetAxis(t3) ? this._orient = e3 || this._makeAutoOrientByTargetAxis() : (this._orient = e3 || `horizontal`, this._fillAutoTargetAxisByOrient(t3, this._orient)), this._noTarget = true, t3.each(function(e4) {
      e4.indexList.length && (this._noTarget = false);
    }, this);
  }, t2.prototype._fillSpecifiedTargetAxis = function(e3) {
    var t3 = false;
    return F(ta, function(n2) {
      var r2 = this.getReferringComponents(ia(n2), w);
      if (r2.specified) {
        t3 = true;
        var i2 = new oa();
        F(r2.models, function(e4) {
          i2.add(e4.componentIndex);
        }), e3.set(n2, i2);
      }
    }, this), t3;
  }, t2.prototype._fillAutoTargetAxisByOrient = function(e3, t3) {
    var n2 = this.ecModel, r2 = true;
    if (r2) {
      var i2 = t3 === `vertical` ? `y` : `x`, a2 = n2.findComponents({ mainType: i2 + `Axis` });
      o2(a2, i2);
    }
    if (r2) {
      var a2 = n2.findComponents({ mainType: `singleAxis`, filter: function(e4) {
        return e4.get(`orient`, true) === t3;
      } });
      o2(a2, `single`);
    }
    function o2(t4, n3) {
      var i3 = t4[0];
      if (i3) {
        var a3 = new oa();
        if (a3.add(i3.componentIndex), e3.set(n3, a3), r2 = false, n3 === `x` || n3 === `y`) {
          var o3 = i3.getReferringComponents(`grid`, j).models[0];
          o3 && F(t4, function(e4) {
            i3.componentIndex !== e4.componentIndex && o3 === e4.getReferringComponents(`grid`, j).models[0] && a3.add(e4.componentIndex);
          });
        }
      }
    }
    r2 && F(ta, function(t4) {
      if (r2) {
        var i3 = n2.findComponents({ mainType: ia(t4), filter: function(e4) {
          return e4.get(`type`, true) === `category`;
        } });
        if (i3[0]) {
          var a3 = new oa();
          a3.add(i3[0].componentIndex), e3.set(t4, a3), r2 = false;
        }
      }
    }, this);
  }, t2.prototype._makeAutoOrientByTargetAxis = function() {
    var e3;
    return this.eachTargetAxis(function(t3) {
      !e3 && (e3 = t3);
    }, this), e3 === `y` ? `vertical` : `horizontal`;
  }, t2.prototype._setDefaultThrottle = function(e3) {
    if (e3.hasOwnProperty(`throttle`) && (this._autoThrottle = false), this._autoThrottle) {
      var t3 = this.ecModel.option;
      this.option.throttle = t3.animation && t3.animationDurationUpdate > 0 ? 100 : 20;
    }
  }, t2.prototype._updateRangeUse = function(e3) {
    var t3 = this._rangePropMode, n2 = this.get(`rangeMode`);
    F([[`start`, `startValue`], [`end`, `endValue`]], function(r2, i2) {
      var a2 = e3[r2[0]] != null, o2 = e3[r2[1]] != null;
      a2 && !o2 ? t3[i2] = `percent` : !a2 && o2 ? t3[i2] = `value` : n2 ? t3[i2] = n2[i2] : a2 && (t3[i2] = `percent`);
    });
  }, t2.prototype.noTarget = function() {
    return this._noTarget;
  }, t2.prototype.getFirstTargetAxisModel = function() {
    var e3;
    return this.eachTargetAxis(function(t3, n2) {
      e3 ?? (e3 = this.ecModel.getComponent(ia(t3), n2));
    }, this), e3;
  }, t2.prototype.eachTargetAxis = function(e3, t3) {
    this._targetAxisInfoMap.each(function(n2, r2) {
      F(n2.indexList, function(n3) {
        e3.call(t3, r2, n3);
      });
    });
  }, t2.prototype.getAxisProxy = function(e3, t3) {
    var n2 = this.getAxisModel(e3, t3);
    if (n2) return n2.__dzAxisProxy;
  }, t2.prototype.getAxisModel = function(e3, t3) {
    var n2 = this._targetAxisInfoMap.get(e3);
    if (n2 && n2.indexMap[t3]) return this.ecModel.getComponent(ia(e3), t3);
  }, t2.prototype.setRawRange = function(e3) {
    var t3 = this.option, n2 = this.settledOption;
    F([[`start`, `startValue`], [`end`, `endValue`]], function(r2) {
      (e3[r2[0]] != null || e3[r2[1]] != null) && (t3[r2[0]] = n2[r2[0]] = e3[r2[0]], t3[r2[1]] = n2[r2[1]] = e3[r2[1]]);
    }, this), this._updateRangeUse(e3);
  }, t2.prototype.setCalculatedRange = function(e3) {
    var t3 = this.option;
    F([`start`, `startValue`, `end`, `endValue`], function(n2) {
      t3[n2] = e3[n2];
    });
  }, t2.prototype.getPercentRange = function() {
    var e3 = this.findRepresentativeAxisProxy();
    if (e3) return e3.getDataPercentWindow();
  }, t2.prototype.getValueRange = function(e3, t3) {
    if (e3 == null && t3 == null) {
      var n2 = this.findRepresentativeAxisProxy();
      if (n2) return n2.getDataValueWindow();
    } else return this.getAxisProxy(e3, t3).getDataValueWindow();
  }, t2.prototype.findRepresentativeAxisProxy = function(e3) {
    if (e3) return e3.__dzAxisProxy;
    for (var t3, n2 = this._targetAxisInfoMap.keys(), r2 = 0; r2 < n2.length; r2++) for (var i2 = n2[r2], a2 = this._targetAxisInfoMap.get(i2), o2 = 0; o2 < a2.indexList.length; o2++) {
      var s2 = this.getAxisProxy(i2, a2.indexList[o2]);
      if (s2.hostedBy(this)) return s2;
      t3 || (t3 = s2);
    }
    return t3;
  }, t2.prototype.getRangePropMode = function() {
    return this._rangePropMode.slice();
  }, t2.prototype.getOrient = function() {
    return this._orient;
  }, t2.type = `dataZoom`, t2.dependencies = [`xAxis`, `yAxis`, `radiusAxis`, `angleAxis`, `singleAxis`, `series`, `toolbox`], t2.defaultOption = { z: 4, filterMode: `filter`, start: 0, end: 100 }, t2;
})(ce);
function ca(e2) {
  var t2 = {};
  return F([`start`, `end`, `startValue`, `endValue`, `throttle`], function(n2) {
    e2.hasOwnProperty(n2) && (t2[n2] = e2[n2]);
  }), t2;
}
P();
var la = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.type = `dataZoom.select`, t2;
})(sa);
P();
var ua = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.prototype.render = function(e3, t3, n2, r2) {
    this.dataZoomModel = e3, this.ecModel = t3, this.api = n2;
  }, t2.type = `dataZoom`, t2;
})(E);
P();
var da = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.type = `dataZoom.select`, t2;
})(ua), fa = F, pa = Ae, ma = (function() {
  function e2(e3, t2, n2, r2) {
    this._dimName = e3, this._axisIndex = t2, this.ecModel = r2, this._dataZoomModel = n2;
  }
  return e2.prototype.hostedBy = function(e3) {
    return this._dataZoomModel === e3;
  }, e2.prototype.getDataValueWindow = function() {
    return this._valueWindow.slice();
  }, e2.prototype.getDataPercentWindow = function() {
    return this._percentWindow.slice();
  }, e2.prototype.getTargetSeriesModels = function() {
    var e3 = [];
    return this.ecModel.eachSeries(function(t2) {
      if (ra(t2)) {
        var n2 = ia(this._dimName), r2 = t2.getReferringComponents(n2, j).models[0];
        r2 && this._axisIndex === r2.componentIndex && e3.push(t2);
      }
    }, this), e3;
  }, e2.prototype.getAxisModel = function() {
    return this.ecModel.getComponent(this._dimName + `Axis`, this._axisIndex);
  }, e2.prototype.getMinMaxSpan = function() {
    return L(this._minMaxSpan);
  }, e2.prototype.calculateDataWindow = function(e3) {
    var t2 = this._dataExtent, n2 = this.getAxisModel().axis.scale, r2 = this._dataZoomModel.getRangePropMode(), i2 = [0, 100], a2 = [], o2 = [], s2;
    fa([`start`, `end`], function(c3, l3) {
      var u2 = e3[c3], d2 = e3[c3 + `Value`];
      r2[l3] === `percent` ? (u2 ?? (u2 = i2[l3]), d2 = n2.parse(Le(u2, i2, t2))) : (s2 = true, d2 = d2 == null ? t2[l3] : n2.parse(d2), u2 = Le(d2, t2, i2)), o2[l3] = d2 == null || isNaN(d2) ? t2[l3] : d2, a2[l3] = u2 == null || isNaN(u2) ? i2[l3] : u2;
    }), pa(o2), pa(a2);
    var c2 = this._minMaxSpan;
    s2 ? l2(o2, a2, t2, i2, false) : l2(a2, o2, i2, t2, true);
    function l2(e4, t3, r3, i3, a3) {
      var o3 = a3 ? `Span` : `ValueSpan`;
      cr(0, e4, r3, `all`, c2[`min` + o3], c2[`max` + o3]);
      for (var s3 = 0; s3 < 2; s3++) t3[s3] = Le(e4[s3], r3, i3, true), a3 && (t3[s3] = n2.parse(t3[s3]));
    }
    return { valueWindow: o2, percentWindow: a2 };
  }, e2.prototype.reset = function(e3) {
    if (e3 === this._dataZoomModel) {
      var t2 = this.getTargetSeriesModels();
      this._dataExtent = ha(this, this._dimName, t2), this._updateMinMaxSpan();
      var n2 = this.calculateDataWindow(e3.settledOption);
      this._valueWindow = n2.valueWindow, this._percentWindow = n2.percentWindow, this._setAxisModel();
    }
  }, e2.prototype.filterData = function(e3, t2) {
    if (e3 !== this._dataZoomModel) return;
    var n2 = this._dimName, r2 = this.getTargetSeriesModels(), i2 = e3.get(`filterMode`), a2 = this._valueWindow;
    if (i2 === `none`) return;
    fa(r2, function(e4) {
      var t3 = e4.getData(), r3 = t3.mapDimensionsAll(n2);
      if (r3.length) {
        if (i2 === `weakFilter`) {
          var s2 = t3.getStore(), c2 = O(r3, function(e5) {
            return t3.getDimensionIndex(e5);
          }, t3);
          t3.filterSelf(function(e5) {
            for (var t4, n3, i3, o3 = 0; o3 < r3.length; o3++) {
              var l2 = s2.get(c2[o3], e5), u2 = !isNaN(l2), d2 = l2 < a2[0], f2 = l2 > a2[1];
              if (u2 && !d2 && !f2) return true;
              u2 && (i3 = true), d2 && (t4 = true), f2 && (n3 = true);
            }
            return i3 && t4 && n3;
          });
        } else fa(r3, function(n3) {
          if (i2 === `empty`) e4.setData(t3 = t3.map(n3, function(e5) {
            return o2(e5) ? e5 : NaN;
          }));
          else {
            var r4 = {};
            r4[n3] = a2, t3.selectRange(r4);
          }
        });
        fa(r3, function(e5) {
          t3.setApproximateExtent(a2, e5);
        });
      }
    });
    function o2(e4) {
      return e4 >= a2[0] && e4 <= a2[1];
    }
  }, e2.prototype._updateMinMaxSpan = function() {
    var e3 = this._minMaxSpan = {}, t2 = this._dataZoomModel, n2 = this._dataExtent;
    fa([`min`, `max`], function(r2) {
      var i2 = t2.get(r2 + `Span`), a2 = t2.get(r2 + `ValueSpan`);
      a2 != null && (a2 = this.getAxisModel().axis.scale.parse(a2)), a2 == null ? i2 != null && (a2 = Le(i2, [0, 100], n2, true) - n2[0]) : i2 = Le(n2[0] + a2, n2, [0, 100], true), e3[r2 + `Span`] = i2, e3[r2 + `ValueSpan`] = a2;
    }, this);
  }, e2.prototype._setAxisModel = function() {
    var e3 = this.getAxisModel(), t2 = this._percentWindow, n2 = this._valueWindow;
    if (t2) {
      var r2 = Jt(n2, [0, 500]);
      r2 = Math.min(r2, 20);
      var i2 = e3.axis.scale.rawExtentInfo;
      t2[0] !== 0 && i2.setDeterminedMinMax(`min`, +n2[0].toFixed(r2)), t2[1] !== 100 && i2.setDeterminedMinMax(`max`, +n2[1].toFixed(r2)), i2.freeze();
    }
  }, e2;
})();
function ha(e2, t2, n2) {
  var r2 = [1 / 0, -1 / 0];
  fa(n2, function(e3) {
    ot(r2, e3.getData(), t2);
  });
  var i2 = e2.getAxisModel(), a2 = We(i2.axis.scale, i2, r2).calculate();
  return [a2.min, a2.max];
}
var ga = { getTargetSeries: function(e2) {
  function t2(t3) {
    e2.eachComponent(`dataZoom`, function(n3) {
      n3.eachTargetAxis(function(r3, i2) {
        t3(r3, i2, e2.getComponent(ia(r3), i2), n3);
      });
    });
  }
  t2(function(e3, t3, n3, r3) {
    n3.__dzAxisProxy = null;
  });
  var n2 = [];
  t2(function(t3, r3, i2, a2) {
    i2.__dzAxisProxy || (i2.__dzAxisProxy = new ma(t3, r3, a2, e2), n2.push(i2.__dzAxisProxy));
  });
  var r2 = Et();
  return F(n2, function(e3) {
    F(e3.getTargetSeriesModels(), function(e4) {
      r2.set(e4.uid, e4);
    });
  }), r2;
}, overallReset: function(e2, t2) {
  e2.eachComponent(`dataZoom`, function(e3) {
    e3.eachTargetAxis(function(t3, n2) {
      e3.getAxisProxy(t3, n2).reset(e3);
    }), e3.eachTargetAxis(function(n2, r2) {
      e3.getAxisProxy(n2, r2).filterData(e3, t2);
    });
  }), e2.eachComponent(`dataZoom`, function(e3) {
    var t3 = e3.findRepresentativeAxisProxy();
    if (t3) {
      var n2 = t3.getDataPercentWindow(), r2 = t3.getDataValueWindow();
      e3.setCalculatedRange({ start: n2[0], end: n2[1], startValue: r2[0], endValue: r2[1] });
    }
  });
} };
function _a(e2) {
  e2.registerAction(`dataZoom`, function(e3, t2) {
    var n2 = aa(t2, e3);
    F(n2, function(t3) {
      t3.setRawRange({ start: e3.start, end: e3.end, startValue: e3.startValue, endValue: e3.endValue });
    });
  });
}
var va = false;
function ya(e2) {
  va || (va = true, e2.registerProcessor(e2.PRIORITY.PROCESSOR.FILTER, ga), _a(e2), e2.registerSubTypeDefaulter(`dataZoom`, function() {
    return `slider`;
  }));
}
function ba(e2) {
  e2.registerComponentModel(la), e2.registerComponentView(da), ya(e2);
}
var X = /* @__PURE__ */ (function() {
  function e2() {
  }
  return e2;
})(), xa = {};
function Sa(e2, t2) {
  xa[e2] = t2;
}
function Ca(e2) {
  return xa[e2];
}
P();
var wa = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.prototype.optionUpdated = function() {
    e2.prototype.optionUpdated.apply(this, arguments);
    var t3 = this.ecModel;
    F(this.option.feature, function(e3, n2) {
      var r2 = Ca(n2);
      r2 && (r2.getDefaultOption && (r2.defaultOption = r2.getDefaultOption(t3)), k(e3, r2.defaultOption));
    });
  }, t2.type = `toolbox`, t2.layoutMode = { type: `box`, ignoreSize: true }, t2.defaultOption = { show: true, z: 6, orient: `horizontal`, left: `right`, top: `top`, backgroundColor: `transparent`, borderColor: `#ccc`, borderRadius: 0, borderWidth: 0, padding: 5, itemSize: 15, itemGap: 8, showTitle: true, iconStyle: { borderColor: `#666`, color: `none` }, emphasis: { iconStyle: { borderColor: `#3E98C5` } }, tooltip: { show: false, position: `bottom` } }, t2;
})(ce);
function Ta(e2, t2, n2) {
  var r2 = t2.getBoxLayoutParams(), i2 = t2.get(`padding`), a2 = { width: n2.getWidth(), height: n2.getHeight() }, o2 = me(r2, a2, i2);
  Ne(t2.get(`orient`), e2, t2.get(`itemGap`), o2.width, o2.height), pe(e2, r2, a2, i2);
}
function Ea(e2, t2) {
  var n2 = He(t2.get(`padding`)), r2 = t2.getItemStyle([`color`, `opacity`]);
  return r2.fill = t2.get(`backgroundColor`), e2 = new T({ shape: { x: e2.x - n2[3], y: e2.y - n2[0], width: e2.width + n2[1] + n2[3], height: e2.height + n2[0] + n2[2], r: t2.get(`borderRadius`) }, style: r2, silent: true, z2: -1 }), e2;
}
P();
var Da = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.render = function(e3, t3, n2, r2) {
    var i2 = this.group;
    if (i2.removeAll(), !e3.get(`show`)) return;
    var a2 = +e3.get(`itemSize`), o2 = e3.get(`orient`) === `vertical`, s2 = e3.get(`feature`) || {}, c2 = this._features || (this._features = {}), l2 = [];
    F(s2, function(e4, t4) {
      l2.push(t4);
    }), new je(this._featureNames || [], l2).add(u2).update(u2).remove(B(u2, null)).execute(), this._featureNames = l2;
    function u2(i3, a3) {
      var o3 = l2[i3], u3 = l2[a3], f2 = s2[o3], p2 = new V(f2, e3, e3.ecModel), m2;
      if (r2 && r2.newTitle != null && r2.featureName === o3 && (f2.title = r2.newTitle), o3 && !u3) {
        if (Oa(o3)) m2 = { onclick: p2.option.onclick, featureName: o3 };
        else {
          var h2 = Ca(o3);
          if (!h2) return;
          m2 = new h2();
        }
        c2[o3] = m2;
      } else if (m2 = c2[u3], !m2) return;
      m2.uid = It(`toolbox-feature`), m2.model = p2, m2.ecModel = t3, m2.api = n2;
      var g2 = m2 instanceof X;
      if (!o3 && u3) {
        g2 && m2.dispose && m2.dispose(t3, n2);
        return;
      }
      if (!p2.get(`show`) || g2 && m2.unusable) {
        g2 && m2.remove && m2.remove(t3, n2);
        return;
      }
      d2(p2, m2, o3), p2.setIconStatus = function(e4, t4) {
        var n3 = this.option, r3 = this.iconPaths;
        n3.iconStatus = n3.iconStatus || {}, n3.iconStatus[e4] = t4, r3[e4] && (t4 === `emphasis` ? Me : ne)(r3[e4]);
      }, m2 instanceof X && m2.render && m2.render(p2, t3, n2, r2);
    }
    function d2(r3, s3, c3) {
      var l3 = r3.getModel(`iconStyle`), u3 = r3.getModel([`emphasis`, `iconStyle`]), d3 = s3 instanceof X && s3.getIcons ? s3.getIcons() : r3.get(`icon`), f2 = r3.get(`title`) || {}, p2, m2;
      z(d3) ? (p2 = {}, p2[c3] = d3) : p2 = d3, z(f2) ? (m2 = {}, m2[c3] = f2) : m2 = f2;
      var h2 = r3.iconPaths = {};
      F(p2, function(c4, d4) {
        var f3 = vt(c4, {}, { x: -a2 / 2, y: -a2 / 2, width: a2, height: a2 });
        f3.setStyle(l3.getItemStyle());
        var p3 = f3.ensureState(`emphasis`);
        p3.style = u3.getItemStyle();
        var g2 = new N({ style: { text: m2[d4], align: u3.get(`textAlign`), borderRadius: u3.get(`textBorderRadius`), padding: u3.get(`textPadding`), fill: null, font: Je({ fontStyle: u3.get(`textFontStyle`), fontFamily: u3.get(`textFontFamily`), fontSize: u3.get(`textFontSize`), fontWeight: u3.get(`textFontWeight`) }, t3) }, ignore: true });
        f3.setTextContent(g2), Dt({ el: f3, componentModel: e3, itemName: d4, formatterParamsExtra: { title: m2[d4] } }), f3.__title = m2[d4], f3.on(`mouseover`, function() {
          var t4 = u3.getItemStyle(), r4 = o2 ? e3.get(`right`) == null && e3.get(`left`) !== `right` ? `right` : `left` : e3.get(`bottom`) == null && e3.get(`top`) !== `bottom` ? `bottom` : `top`;
          g2.setStyle({ fill: u3.get(`textFill`) || t4.fill || t4.stroke || `#000`, backgroundColor: u3.get(`textBackgroundColor`) }), f3.setTextConfig({ position: u3.get(`textPosition`) || r4 }), g2.ignore = !e3.get(`showTitle`), n2.enterEmphasis(this);
        }).on(`mouseout`, function() {
          r3.get([`iconStatus`, d4]) !== `emphasis` && n2.leaveEmphasis(this), g2.hide();
        }), (r3.get([`iconStatus`, d4]) === `emphasis` ? Me : ne)(f3), i2.add(f3), f3.on(`click`, I(s3.onclick, s3, t3, n2, d4)), h2[d4] = f3;
      });
    }
    Ta(i2, e3, n2), i2.add(Ea(i2.getBoundingRect(), e3)), o2 || i2.eachChild(function(e4) {
      var t4 = e4.__title, r3 = e4.ensureState(`emphasis`), o3 = r3.textConfig || (r3.textConfig = {}), s3 = e4.getTextContent(), c3 = s3 && s3.ensureState(`emphasis`);
      if (c3 && !H(c3) && t4) {
        var l3 = c3.style || (c3.style = {}), u3 = he(t4, N.makeFont(l3)), d3 = e4.x + i2.x, f2 = e4.y + i2.y + a2, p2 = false;
        f2 + u3.height > n2.getHeight() && (o3.position = `top`, p2 = true);
        var m2 = p2 ? -5 - u3.height : a2 + 10;
        d3 + u3.width / 2 > n2.getWidth() ? (o3.position = [`100%`, m2], l3.align = `right`) : d3 - u3.width / 2 < 0 && (o3.position = [0, m2], l3.align = `left`);
      }
    });
  }, t2.prototype.updateView = function(e3, t3, n2, r2) {
    F(this._features, function(e4) {
      e4 instanceof X && e4.updateView && e4.updateView(e4.model, t3, n2, r2);
    });
  }, t2.prototype.remove = function(e3, t3) {
    F(this._features, function(n2) {
      n2 instanceof X && n2.remove && n2.remove(e3, t3);
    }), this.group.removeAll();
  }, t2.prototype.dispose = function(e3, t3) {
    F(this._features, function(n2) {
      n2 instanceof X && n2.dispose && n2.dispose(e3, t3);
    });
  }, t2.type = `toolbox`, t2;
})(E);
function Oa(e2) {
  return e2.indexOf(`my`) === 0;
}
P();
var ka = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.onclick = function(e3, t3) {
    var n2 = this.model, r2 = n2.get(`name`) || e3.get(`title.0.text`) || `echarts`, i2 = t3.getZr().painter.getType() === `svg`, a2 = i2 ? `svg` : n2.get(`type`, true) || `png`, o2 = t3.getConnectedDataURL({ type: a2, backgroundColor: n2.get(`backgroundColor`, true) || e3.get(`backgroundColor`) || `#fff`, connectedBackgroundColor: n2.get(`connectedBackgroundColor`), excludeComponents: n2.get(`excludeComponents`), pixelRatio: n2.get(`pixelRatio`) }), s2 = S.browser;
    if (typeof MouseEvent == `function` && (s2.newEdge || !s2.ie && !s2.edge)) {
      var c2 = document.createElement(`a`);
      c2.download = r2 + `.` + a2, c2.target = `_blank`, c2.href = o2;
      var l2 = new MouseEvent(`click`, { view: document.defaultView, bubbles: true, cancelable: false });
      c2.dispatchEvent(l2);
    } else if (window.navigator.msSaveOrOpenBlob || i2) {
      var u2 = o2.split(`,`), d2 = u2[0].indexOf(`base64`) > -1, f2 = i2 ? decodeURIComponent(u2[1]) : u2[1];
      d2 && (f2 = window.atob(f2));
      var p2 = r2 + `.` + a2;
      if (window.navigator.msSaveOrOpenBlob) {
        for (var m2 = f2.length, h2 = new Uint8Array(m2); m2--; ) h2[m2] = f2.charCodeAt(m2);
        var g2 = new Blob([h2]);
        window.navigator.msSaveOrOpenBlob(g2, p2);
      } else {
        var _2 = document.createElement(`iframe`);
        document.body.appendChild(_2);
        var v2 = _2.contentWindow, y2 = v2.document;
        y2.open(`image/svg+xml`, `replace`), y2.write(f2), y2.close(), v2.focus(), y2.execCommand(`SaveAs`, true, p2), document.body.removeChild(_2);
      }
    } else {
      var b2 = n2.get(`lang`), x2 = `<body style="margin:0;"><img src="` + o2 + `" style="max-width:100%;" title="` + (b2 && b2[0] || ``) + `" /></body>`, C2 = window.open();
      C2.document.write(x2), C2.document.title = r2;
    }
  }, t2.getDefaultOption = function(e3) {
    return { show: true, icon: `M4.7,22.9L29.3,45.5L54.7,23.4M4.6,43.6L4.6,58L53.8,58L53.8,43.6M29.2,45.1L29.2,0`, title: e3.getLocaleModel().get([`toolbox`, `saveAsImage`, `title`]), type: `png`, connectedBackgroundColor: `#fff`, name: ``, excludeComponents: [`toolbox`], lang: e3.getLocaleModel().get([`toolbox`, `saveAsImage`, `lang`]) };
  }, t2;
})(X);
P();
var Aa = `__ec_magicType_stack__`, ja = [[`line`, `bar`], [`stack`]], Ma = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.getIcons = function() {
    var e3 = this.model, t3 = e3.get(`icon`), n2 = {};
    return F(e3.get(`type`), function(e4) {
      t3[e4] && (n2[e4] = t3[e4]);
    }), n2;
  }, t2.getDefaultOption = function(e3) {
    return { show: true, type: [], icon: { line: `M4.1,28.9h7.1l9.3-22l7.4,38l9.7-19.7l3,12.8h14.9M4.1,58h51.4`, bar: `M6.7,22.9h10V48h-10V22.9zM24.9,13h10v35h-10V13zM43.2,2h10v46h-10V2zM3.1,58h53.7`, stack: `M8.2,38.4l-8.4,4.1l30.6,15.3L60,42.5l-8.1-4.1l-21.5,11L8.2,38.4z M51.9,30l-8.1,4.2l-13.4,6.9l-13.9-6.9L8.2,30l-8.4,4.2l8.4,4.2l22.2,11l21.5-11l8.1-4.2L51.9,30z M51.9,21.7l-8.1,4.2L35.7,30l-5.3,2.8L24.9,30l-8.4-4.1l-8.3-4.2l-8.4,4.2L8.2,30l8.3,4.2l13.9,6.9l13.4-6.9l8.1-4.2l8.1-4.1L51.9,21.7zM30.4,2.2L-0.2,17.5l8.4,4.1l8.3,4.2l8.4,4.2l5.5,2.7l5.3-2.7l8.1-4.2l8.1-4.2l8.1-4.1L30.4,2.2z` }, title: e3.getLocaleModel().get([`toolbox`, `magicType`, `title`]), option: {}, seriesIndex: {} };
  }, t2.prototype.onclick = function(e3, t3, n2) {
    var r2 = this.model, i2 = r2.get([`seriesIndex`, n2]);
    if (Na[n2]) {
      var a2 = { series: [] };
      F(ja, function(e4) {
        W(e4, n2) >= 0 && F(e4, function(e5) {
          r2.setIconStatus(e5, `normal`);
        });
      }), r2.setIconStatus(n2, `emphasis`), e3.eachComponent({ mainType: `series`, query: i2 == null ? null : { seriesIndex: i2 } }, function(e4) {
        var t4 = e4.subType, i3 = e4.id, o3 = Na[n2](t4, i3, e4, r2);
        o3 && (R(o3, e4.option), a2.series.push(o3));
        var s3 = e4.coordinateSystem;
        if (s3 && s3.type === `cartesian2d` && (n2 === `line` || n2 === `bar`)) {
          var c2 = s3.getAxesByScale(`ordinal`)[0];
          if (c2) {
            var l2 = c2.dim + `Axis`, u2 = e4.getReferringComponents(l2, j).models[0].componentIndex;
            a2[l2] = a2[l2] || [];
            for (var d2 = 0; d2 <= u2; d2++) a2[l2][u2] = a2[l2][u2] || {};
            a2[l2][u2].boundaryGap = n2 === `bar`;
          }
        }
      });
      var o2, s2 = n2;
      n2 === `stack` && (o2 = k({ stack: r2.option.title.tiled, tiled: r2.option.title.stack }, r2.option.title), r2.get([`iconStatus`, n2]) !== `emphasis` && (s2 = `tiled`)), t3.dispatchAction({ type: `changeMagicType`, currentType: s2, newOption: a2, newTitle: o2, featureName: `magicType` });
    }
  }, t2;
})(X), Na = { line: function(e2, t2, n2, r2) {
  if (e2 === `bar`) return k({ id: t2, type: `line`, data: n2.get(`data`), stack: n2.get(`stack`), markPoint: n2.get(`markPoint`), markLine: n2.get(`markLine`) }, r2.get([`option`, `line`]) || {}, true);
}, bar: function(e2, t2, n2, r2) {
  if (e2 === `line`) return k({ id: t2, type: `bar`, data: n2.get(`data`), stack: n2.get(`stack`), markPoint: n2.get(`markPoint`), markLine: n2.get(`markLine`) }, r2.get([`option`, `bar`]) || {}, true);
}, stack: function(e2, t2, n2, r2) {
  var i2 = n2.get(`stack`) === Aa;
  if (e2 === `line` || e2 === `bar`) return r2.setIconStatus(`stack`, i2 ? `normal` : `emphasis`), k({ id: t2, stack: i2 ? `` : Aa }, r2.get([`option`, `stack`]) || {}, true);
} };
ee({ type: `changeMagicType`, event: `magicTypeChanged`, update: `prepareAndUpdate` }, function(e2, t2) {
  t2.mergeOption(e2.newOption);
}), P();
var Pa = Array(60).join(`-`), Fa = `	`;
function Ia(e2) {
  var t2 = {}, n2 = [], r2 = [];
  return e2.eachRawSeries(function(e3) {
    var i2 = e3.coordinateSystem;
    if (i2 && (i2.type === `cartesian2d` || i2.type === `polar`)) {
      var a2 = i2.getBaseAxis();
      if (a2.type === `category`) {
        var o2 = a2.dim + `_` + a2.index;
        t2[o2] || (t2[o2] = { categoryAxis: a2, valueAxis: i2.getOtherAxis(a2), series: [] }, r2.push({ axisDim: a2.dim, axisIndex: a2.index })), t2[o2].series.push(e3);
      } else n2.push(e3);
    } else n2.push(e3);
  }), { seriesGroupByCategoryAxis: t2, other: n2, meta: r2 };
}
function La(e2) {
  var t2 = [];
  return F(e2, function(e3, n2) {
    var r2 = e3.categoryAxis, i2 = e3.valueAxis.dim, a2 = [` `].concat(O(e3.series, function(e4) {
      return e4.name;
    })), o2 = [r2.model.getCategories()];
    F(e3.series, function(e4) {
      var t3 = e4.getRawData();
      o2.push(e4.getRawData().mapArray(t3.mapDimension(i2), function(e5) {
        return e5;
      }));
    });
    for (var s2 = [a2.join(Fa)], c2 = 0; c2 < o2[0].length; c2++) {
      for (var l2 = [], u2 = 0; u2 < o2.length; u2++) l2.push(o2[u2][c2]);
      s2.push(l2.join(Fa));
    }
    t2.push(s2.join(`
`));
  }), t2.join(`

` + Pa + `

`);
}
function Ra(e2) {
  return O(e2, function(e3) {
    var t2 = e3.getRawData(), n2 = [e3.name], r2 = [];
    return t2.each(t2.dimensions, function() {
      for (var e4 = arguments.length, i2 = arguments[e4 - 1], a2 = t2.getName(i2), o2 = 0; o2 < e4 - 1; o2++) r2[o2] = arguments[o2];
      n2.push((a2 ? a2 + Fa : ``) + r2.join(Fa));
    }), n2.join(`
`);
  }).join(`

` + Pa + `

`);
}
function za(e2) {
  var t2 = Ia(e2);
  return { value: Gt([La(t2.seriesGroupByCategoryAxis), Ra(t2.other)], function(e3) {
    return !!e3.replace(/[\n\t\s]/g, ``);
  }).join(`

` + Pa + `

`), meta: t2.meta };
}
function Ba(e2) {
  return e2.replace(/^\s\s*/, ``).replace(/\s\s*$/, ``);
}
function Va(e2) {
  if (e2.slice(0, e2.indexOf(`
`)).indexOf(Fa) >= 0) return true;
}
var Ha = RegExp(`[` + Fa + `]+`, `g`);
function Ua(e2) {
  for (var t2 = e2.split(/\n+/g), n2 = Ba(t2.shift()).split(Ha), r2 = [], i2 = O(n2, function(e3) {
    return { name: e3, data: [] };
  }), a2 = 0; a2 < t2.length; a2++) {
    var o2 = Ba(t2[a2]).split(Ha);
    r2.push(o2.shift());
    for (var s2 = 0; s2 < o2.length; s2++) i2[s2] && (i2[s2].data[a2] = o2[s2]);
  }
  return { series: i2, categories: r2 };
}
function Wa(e2) {
  for (var t2 = e2.split(/\n+/g), n2 = Ba(t2.shift()), r2 = [], i2 = 0; i2 < t2.length; i2++) {
    var a2 = Ba(t2[i2]);
    if (a2) {
      var o2 = a2.split(Ha), s2 = ``, c2 = void 0, l2 = false;
      isNaN(o2[0]) ? (l2 = true, s2 = o2[0], o2 = o2.slice(1), r2[i2] = { name: s2, value: [] }, c2 = r2[i2].value) : c2 = r2[i2] = [];
      for (var u2 = 0; u2 < o2.length; u2++) c2.push(+o2[u2]);
      c2.length === 1 && (l2 ? r2[i2].value = c2[0] : r2[i2] = c2[0]);
    }
  }
  return { name: n2, data: r2 };
}
function Ga(e2, t2) {
  var n2 = e2.split(RegExp(`
*` + Pa + `
*`, `g`)), r2 = { series: [] };
  return F(n2, function(e3, n3) {
    if (Va(e3)) {
      var i2 = Ua(e3), a2 = t2[n3], o2 = a2.axisDim + `Axis`;
      a2 && (r2[o2] = r2[o2] || [], r2[o2][a2.axisIndex] = { data: i2.categories }, r2.series = r2.series.concat(i2.series));
    } else {
      var i2 = Wa(e3);
      r2.series.push(i2);
    }
  }), r2;
}
var Ka = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.onclick = function(e3, t3) {
    setTimeout(function() {
      t3.dispatchAction({ type: `hideTip` });
    });
    var n2 = t3.getDom(), r2 = this.model;
    this._dom && n2.removeChild(this._dom);
    var i2 = document.createElement(`div`);
    i2.style.cssText = `position:absolute;top:0;bottom:0;left:0;right:0;padding:5px`, i2.style.backgroundColor = r2.get(`backgroundColor`) || `#fff`;
    var a2 = document.createElement(`h4`), o2 = r2.get(`lang`) || [];
    a2.innerHTML = o2[0] || r2.get(`title`), a2.style.cssText = `margin:10px 20px`, a2.style.color = r2.get(`textColor`);
    var s2 = document.createElement(`div`), c2 = document.createElement(`textarea`);
    s2.style.cssText = `overflow:auto`;
    var l2 = r2.get(`optionToContent`), u2 = r2.get(`contentToOption`), d2 = za(e3);
    if (H(l2)) {
      var f2 = l2(t3.getOption());
      z(f2) ? s2.innerHTML = f2 : te(f2) && s2.appendChild(f2);
    } else {
      c2.readOnly = r2.get(`readOnly`);
      var p2 = c2.style;
      p2.cssText = `display:block;width:100%;height:100%;font-family:monospace;font-size:14px;line-height:1.6rem;resize:none;box-sizing:border-box;outline:none`, p2.color = r2.get(`textColor`), p2.borderColor = r2.get(`textareaBorderColor`), p2.backgroundColor = r2.get(`textareaColor`), c2.value = d2.value, s2.appendChild(c2);
    }
    var m2 = d2.meta, h2 = document.createElement(`div`);
    h2.style.cssText = `position:absolute;bottom:5px;left:0;right:0`;
    var g2 = `float:right;margin-right:20px;border:none;cursor:pointer;padding:2px 5px;font-size:12px;border-radius:3px`, _2 = document.createElement(`div`), v2 = document.createElement(`div`);
    g2 += `;background-color:` + r2.get(`buttonColor`), g2 += `;color:` + r2.get(`buttonTextColor`);
    var y2 = this;
    function b2() {
      n2.removeChild(i2), y2._dom = null;
    }
    dt(_2, `click`, b2), dt(v2, `click`, function() {
      if (u2 == null && l2 != null || u2 != null && l2 == null) {
        b2();
        return;
      }
      var e4;
      try {
        e4 = H(u2) ? u2(s2, t3.getOption()) : Ga(c2.value, m2);
      } catch (e5) {
        throw b2(), Error(`Data view format error ` + e5);
      }
      e4 && t3.dispatchAction({ type: `changeDataView`, newOption: e4 }), b2();
    }), _2.innerHTML = o2[1], v2.innerHTML = o2[2], v2.style.cssText = _2.style.cssText = g2, !r2.get(`readOnly`) && h2.appendChild(v2), h2.appendChild(_2), i2.appendChild(a2), i2.appendChild(s2), i2.appendChild(h2), s2.style.height = n2.clientHeight - 80 + `px`, n2.appendChild(i2), this._dom = i2;
  }, t2.prototype.remove = function(e3, t3) {
    this._dom && t3.getDom().removeChild(this._dom);
  }, t2.prototype.dispose = function(e3, t3) {
    this.remove(e3, t3);
  }, t2.getDefaultOption = function(e3) {
    return { show: true, readOnly: false, optionToContent: null, contentToOption: null, icon: `M17.5,17.3H33 M17.5,17.3H33 M45.4,29.5h-28 M11.5,2v56H51V14.8L38.4,2H11.5z M38.4,2.2v12.7H51 M45.4,41.7h-28`, title: e3.getLocaleModel().get([`toolbox`, `dataView`, `title`]), lang: e3.getLocaleModel().get([`toolbox`, `dataView`, `lang`]), backgroundColor: `#fff`, textColor: `#000`, textareaColor: `#fff`, textareaBorderColor: `#333`, buttonColor: `#c23531`, buttonTextColor: `#fff` };
  }, t2;
})(X);
function qa(e2, t2) {
  return O(e2, function(e3, n2) {
    var r2 = t2 && t2[n2];
    if (A(r2) && !M(r2)) {
      (!A(e3) || M(e3)) && (e3 = { value: e3 });
      var i2 = r2.name != null && e3.name == null;
      return e3 = R(e3, r2), i2 && delete e3.name, e3;
    }
    return e3;
  });
}
ee({ type: `changeDataView`, event: `dataViewChanged`, update: `prepareAndUpdate` }, function(e2, t2) {
  var n2 = [];
  F(e2.newOption.series, function(e3) {
    var r2 = t2.getSeriesByName(e3.name)[0];
    if (!r2) n2.push(Vt({ type: `scatter` }, e3));
    else {
      var i2 = r2.get(`data`);
      n2.push({ name: e3.name, data: qa(e3.data, i2) });
    }
  }), t2.mergeOption(R({ series: n2 }, e2.newOption));
});
var Ja = F, Ya = mt();
function Xa(e2, t2) {
  var n2 = eo(e2);
  Ja(t2, function(t3, r2) {
    for (var i2 = n2.length - 1; i2 >= 0 && !n2[i2][r2]; i2--) ;
    if (i2 < 0) {
      var a2 = e2.queryComponents({ mainType: `dataZoom`, subType: `select`, id: r2 })[0];
      if (a2) {
        var o2 = a2.getPercentRange();
        n2[0][r2] = { dataZoomId: r2, start: o2[0], end: o2[1] };
      }
    }
  }), n2.push(t2);
}
function Za(e2) {
  var t2 = eo(e2), n2 = t2[t2.length - 1];
  t2.length > 1 && t2.pop();
  var r2 = {};
  return Ja(n2, function(e3, n3) {
    for (var i2 = t2.length - 1; i2 >= 0; i2--) if (e3 = t2[i2][n3], e3) {
      r2[n3] = e3;
      break;
    }
  }), r2;
}
function Qa(e2) {
  Ya(e2).snapshots = null;
}
function $a(e2) {
  return eo(e2).length;
}
function eo(e2) {
  var t2 = Ya(e2);
  return t2.snapshots || (t2.snapshots = [{}]), t2.snapshots;
}
P();
var to = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.onclick = function(e3, t3) {
    Qa(e3), t3.dispatchAction({ type: `restore`, from: this.uid });
  }, t2.getDefaultOption = function(e3) {
    return { show: true, icon: `M3.8,33.4 M47,18.9h9.8V8.7 M56.3,20.1 C52.1,9,40.5,0.6,26.8,2.1C12.6,3.7,1.6,16.2,2.1,30.6 M13,41.1H3.1v10.2 M3.7,39.9c4.2,11.1,15.8,19.5,29.5,18 c14.2-1.6,25.2-14.1,24.7-28.5`, title: e3.getLocaleModel().get([`toolbox`, `restore`, `title`]) };
  }, t2;
})(X);
ee({ type: `restore`, event: `restore`, update: `prepareAndUpdate` }, function(e2, t2) {
  t2.resetOption(`recreate`);
});
var no = [`grid`, `xAxis`, `yAxis`, `geo`, `graph`, `polar`, `radiusAxis`, `angleAxis`, `bmap`], ro = (function() {
  function e2(e3, t2, n2) {
    var r2 = this;
    this._targetInfoList = [];
    var i2 = ao(t2, e3);
    F(oo, function(e4, t3) {
      (!n2 || !n2.include || W(n2.include, t3) >= 0) && e4(i2, r2._targetInfoList);
    });
  }
  return e2.prototype.setOutputRanges = function(e3, t2) {
    return this.matchOutputRanges(e3, t2, function(e4, t3, n2) {
      if ((e4.coordRanges || (e4.coordRanges = [])).push(t3), !e4.coordRange) {
        e4.coordRange = t3;
        var r2 = lo[e4.brushType](0, n2, t3);
        e4.__rangeOffset = { offset: fo[e4.brushType](r2.values, e4.range, [1, 1]), xyMinMax: r2.xyMinMax };
      }
    }), e3;
  }, e2.prototype.matchOutputRanges = function(e3, t2, n2) {
    F(e3, function(e4) {
      var r2 = this.findTargetInfo(e4, t2);
      r2 && r2 !== true && F(r2.coordSyses, function(r3) {
        n2(e4, lo[e4.brushType](1, r3, e4.range, true).values, r3, t2);
      });
    }, this);
  }, e2.prototype.setInputRanges = function(e3, t2) {
    F(e3, function(e4) {
      var n2 = this.findTargetInfo(e4, t2);
      if (e4.range = e4.range || [], n2 && n2 !== true) {
        e4.panelId = n2.panelId;
        var r2 = lo[e4.brushType](0, n2.coordSys, e4.coordRange), i2 = e4.__rangeOffset;
        e4.range = i2 ? fo[e4.brushType](r2.values, i2.offset, mo(r2.xyMinMax, i2.xyMinMax)) : r2.values;
      }
    }, this);
  }, e2.prototype.makePanelOpts = function(e3, t2) {
    return O(this._targetInfoList, function(n2) {
      var r2 = n2.getPanelRect();
      return { panelId: n2.panelId, defaultBrushType: t2 ? t2(n2) : null, clipPath: ai(r2), isTargetByCursor: si(r2, e3, n2.coordSysModel), getLinearBrushOtherExtent: oi(r2) };
    });
  }, e2.prototype.controlSeries = function(e3, t2, n2) {
    var r2 = this.findTargetInfo(e3, n2);
    return r2 === true || r2 && W(r2.coordSyses, t2.coordinateSystem) >= 0;
  }, e2.prototype.findTargetInfo = function(e3, t2) {
    for (var n2 = this._targetInfoList, r2 = ao(t2, e3), i2 = 0; i2 < n2.length; i2++) {
      var a2 = n2[i2], o2 = e3.panelId;
      if (o2) {
        if (a2.panelId === o2) return a2;
      } else for (var s2 = 0; s2 < so.length; s2++) if (so[s2](r2, a2)) return a2;
    }
    return true;
  }, e2;
})();
function io(e2) {
  return e2[0] > e2[1] && e2.reverse(), e2;
}
function ao(e2, t2) {
  return Se(e2, t2, { includeMainTypes: no });
}
var oo = { grid: function(e2, t2) {
  var n2 = e2.xAxisModels, r2 = e2.yAxisModels, i2 = e2.gridModels, a2 = Et(), o2 = {}, s2 = {};
  (n2 || r2 || i2) && (F(n2, function(e3) {
    var t3 = e3.axis.grid.model;
    a2.set(t3.id, t3), o2[t3.id] = true;
  }), F(r2, function(e3) {
    var t3 = e3.axis.grid.model;
    a2.set(t3.id, t3), s2[t3.id] = true;
  }), F(i2, function(e3) {
    a2.set(e3.id, e3), o2[e3.id] = true, s2[e3.id] = true;
  }), a2.each(function(e3) {
    var i3 = e3.coordinateSystem, a3 = [];
    F(i3.getCartesians(), function(e4, t3) {
      (W(n2, e4.getAxis(`x`).model) >= 0 || W(r2, e4.getAxis(`y`).model) >= 0) && a3.push(e4);
    }), t2.push({ panelId: `grid--` + e3.id, gridModel: e3, coordSysModel: e3, coordSys: a3[0], coordSyses: a3, getPanelRect: co.grid, xAxisDeclared: o2[e3.id], yAxisDeclared: s2[e3.id] });
  }));
}, geo: function(e2, t2) {
  F(e2.geoModels, function(e3) {
    var n2 = e3.coordinateSystem;
    t2.push({ panelId: `geo--` + e3.id, geoModel: e3, coordSysModel: e3, coordSys: n2, coordSyses: [n2], getPanelRect: co.geo });
  });
} }, so = [function(e2, t2) {
  var n2 = e2.xAxisModel, r2 = e2.yAxisModel, i2 = e2.gridModel;
  return !i2 && n2 && (i2 = n2.axis.grid.model), !i2 && r2 && (i2 = r2.axis.grid.model), i2 && i2 === t2.gridModel;
}, function(e2, t2) {
  var n2 = e2.geoModel;
  return n2 && n2 === t2.geoModel;
}], co = { grid: function() {
  return this.coordSys.master.getRect().clone();
}, geo: function() {
  var e2 = this.coordSys, t2 = e2.getBoundingRect().clone();
  return t2.applyTransform(zt(e2)), t2;
} }, lo = { lineX: B(uo, 0), lineY: B(uo, 1), rect: function(e2, t2, n2, r2) {
  var i2 = e2 ? t2.pointToData([n2[0][0], n2[1][0]], r2) : t2.dataToPoint([n2[0][0], n2[1][0]], r2), a2 = e2 ? t2.pointToData([n2[0][1], n2[1][1]], r2) : t2.dataToPoint([n2[0][1], n2[1][1]], r2), o2 = [io([i2[0], a2[0]]), io([i2[1], a2[1]])];
  return { values: o2, xyMinMax: o2 };
}, polygon: function(e2, t2, n2, r2) {
  var i2 = [[1 / 0, -1 / 0], [1 / 0, -1 / 0]];
  return { values: O(n2, function(n3) {
    var a2 = e2 ? t2.pointToData(n3, r2) : t2.dataToPoint(n3, r2);
    return i2[0][0] = Math.min(i2[0][0], a2[0]), i2[1][0] = Math.min(i2[1][0], a2[1]), i2[0][1] = Math.max(i2[0][1], a2[0]), i2[1][1] = Math.max(i2[1][1], a2[1]), a2;
  }), xyMinMax: i2 };
} };
function uo(e2, t2, n2, r2) {
  var i2 = n2.getAxis([`x`, `y`][e2]), a2 = io(O([0, 1], function(e3) {
    return t2 ? i2.coordToData(i2.toLocalCoord(r2[e3]), true) : i2.toGlobalCoord(i2.dataToCoord(r2[e3]));
  })), o2 = [];
  return o2[e2] = a2, o2[1 - e2] = [NaN, NaN], { values: a2, xyMinMax: o2 };
}
var fo = { lineX: B(po, 0), lineY: B(po, 1), rect: function(e2, t2, n2) {
  return [[e2[0][0] - n2[0] * t2[0][0], e2[0][1] - n2[0] * t2[0][1]], [e2[1][0] - n2[1] * t2[1][0], e2[1][1] - n2[1] * t2[1][1]]];
}, polygon: function(e2, t2, n2) {
  return O(e2, function(e3, r2) {
    return [e3[0] - n2[0] * t2[r2][0], e3[1] - n2[1] * t2[r2][1]];
  });
} };
function po(e2, t2, n2, r2) {
  return [t2[0] - r2[e2] * n2[0], t2[1] - r2[e2] * n2[1]];
}
function mo(e2, t2) {
  var n2 = ho(e2), r2 = ho(t2), i2 = [n2[0] / r2[0], n2[1] / r2[1]];
  return isNaN(i2[0]) && (i2[0] = 1), isNaN(i2[1]) && (i2[1] = 1), i2;
}
function ho(e2) {
  return e2 ? [e2[0][1] - e2[0][0], e2[1][1] - e2[1][0]] : [NaN, NaN];
}
P();
var go = F, _o = be(`toolbox-dataZoom_`), vo = (function(e2) {
  D(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.render = function(e3, t3, n2, r2) {
    this._brushController || (this._brushController = new Cr(n2.getZr()), this._brushController.on(`brush`, I(this._onBrush, this)).mount()), So(e3, t3, this, r2, n2), xo(e3, t3);
  }, t2.prototype.onclick = function(e3, t3, n2) {
    yo[n2].call(this);
  }, t2.prototype.remove = function(e3, t3) {
    this._brushController && this._brushController.unmount();
  }, t2.prototype.dispose = function(e3, t3) {
    this._brushController && this._brushController.dispose();
  }, t2.prototype._onBrush = function(e3) {
    var t3 = e3.areas;
    if (!e3.isEnd || !t3.length) return;
    var n2 = {}, r2 = this.ecModel;
    this._brushController.updateCovers([]), new ro(bo(this.model), r2, { include: [`grid`] }).matchOutputRanges(t3, r2, function(e4, t4, n3) {
      if (n3.type === `cartesian2d`) {
        var r3 = e4.brushType;
        r3 === `rect` ? (i2(`x`, n3, t4[0]), i2(`y`, n3, t4[1])) : i2({ lineX: `x`, lineY: `y` }[r3], n3, t4);
      }
    }), Xa(r2, n2), this._dispatchZoomAction(n2);
    function i2(e4, t4, i3) {
      var o2 = t4.getAxis(e4), s2 = o2.model, c2 = a2(e4, s2, r2), l2 = c2.findRepresentativeAxisProxy(s2).getMinMaxSpan();
      (l2.minValueSpan != null || l2.maxValueSpan != null) && (i3 = cr(0, i3.slice(), o2.scale.getExtent(), 0, l2.minValueSpan, l2.maxValueSpan)), c2 && (n2[c2.id] = { dataZoomId: c2.id, startValue: i3[0], endValue: i3[1] });
    }
    function a2(e4, t4, n3) {
      var r3;
      return n3.eachComponent({ mainType: `dataZoom`, subType: `select` }, function(n4) {
        n4.getAxisModel(e4, t4.componentIndex) && (r3 = n4);
      }), r3;
    }
  }, t2.prototype._dispatchZoomAction = function(e3) {
    var t3 = [];
    go(e3, function(e4, n2) {
      t3.push(L(e4));
    }), t3.length && this.api.dispatchAction({ type: `dataZoom`, from: this.uid, batch: t3 });
  }, t2.getDefaultOption = function(e3) {
    return { show: true, filterMode: `filter`, icon: { zoom: `M0,13.5h26.9 M13.5,26.9V0 M32.1,13.5H58V58H13.5 V32.1`, back: `M22,1.4L9.9,13.5l12.3,12.3 M10.3,13.5H54.9v44.6 H10.3v-26` }, title: e3.getLocaleModel().get([`toolbox`, `dataZoom`, `title`]), brushStyle: { borderWidth: 0, color: `rgba(210,219,238,0.2)` } };
  }, t2;
})(X), yo = { zoom: function() {
  var e2 = !this._isZoomActive;
  this.api.dispatchAction({ type: `takeGlobalCursor`, key: `dataZoomSelect`, dataZoomSelectActive: e2 });
}, back: function() {
  this._dispatchZoomAction(Za(this.ecModel));
} };
function bo(e2) {
  var t2 = { xAxisIndex: e2.get(`xAxisIndex`, true), yAxisIndex: e2.get(`yAxisIndex`, true), xAxisId: e2.get(`xAxisId`, true), yAxisId: e2.get(`yAxisId`, true) };
  return t2.xAxisIndex == null && t2.xAxisId == null && (t2.xAxisIndex = `all`), t2.yAxisIndex == null && t2.yAxisId == null && (t2.yAxisIndex = `all`), t2;
}
function xo(e2, t2) {
  e2.setIconStatus(`back`, $a(t2) > 1 ? `emphasis` : `normal`);
}
function So(e2, t2, n2, r2, i2) {
  var a2 = n2._isZoomActive;
  r2 && r2.type === `takeGlobalCursor` && (a2 = r2.key === `dataZoomSelect` && r2.dataZoomSelectActive), n2._isZoomActive = a2, e2.setIconStatus(`zoom`, a2 ? `emphasis` : `normal`);
  var o2 = new ro(bo(e2), t2, { include: [`grid`] }).makePanelOpts(i2, function(e3) {
    return e3.xAxisDeclared && !e3.yAxisDeclared ? `lineX` : !e3.xAxisDeclared && e3.yAxisDeclared ? `lineY` : `rect`;
  });
  n2._brushController.setPanels(o2).enableBrush(a2 && o2.length ? { brushType: `auto`, brushStyle: e2.getModel(`brushStyle`).getItemStyle() } : false);
}
Fe(`dataZoom`, function(e2) {
  var t2 = e2.getComponent(`toolbox`, 0), n2 = [`feature`, `dataZoom`];
  if (!t2 || t2.get(n2) == null) return;
  var r2 = t2.getModel(n2), i2 = [], a2 = bo(r2), o2 = Se(e2, a2);
  go(o2.xAxisModels, function(e3) {
    return s2(e3, `xAxis`, `xAxisIndex`);
  }), go(o2.yAxisModels, function(e3) {
    return s2(e3, `yAxis`, `yAxisIndex`);
  });
  function s2(e3, t3, n3) {
    var a3 = e3.componentIndex, o3 = { type: `select`, $fromToolbox: true, filterMode: r2.get(`filterMode`, true) || `filter`, id: _o + t3 + a3 };
    o3[n3] = a3, i2.push(o3);
  }
  return i2;
});
function Co(e2) {
  e2.registerComponentModel(wa), e2.registerComponentView(Da), Sa(`saveAsImage`, ka), Sa(`magicType`, Ma), Sa(`dataView`, Ka), Sa(`dataZoom`, vo), Sa(`restore`, to), Ct(ba);
}
P();
var wo = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.type = `tooltip`, t2.dependencies = [`axisPointer`], t2.defaultOption = { z: 60, show: true, showContent: true, trigger: `item`, triggerOn: `mousemove|click`, alwaysShowContent: false, displayMode: `single`, renderMode: `auto`, confine: null, showDelay: 0, hideDelay: 100, transitionDuration: 0.4, enterable: false, backgroundColor: `#fff`, shadowBlur: 10, shadowColor: `rgba(0, 0, 0, .2)`, shadowOffsetX: 1, shadowOffsetY: 2, borderRadius: 4, borderWidth: 1, padding: null, extraCssText: ``, axisPointer: { type: `line`, axis: `auto`, animation: `auto`, animationDurationUpdate: 200, animationEasingUpdate: `exponentialOut`, crossStyle: { color: `#999`, width: 1, type: `dashed`, textStyle: {} } }, textStyle: { color: `#666`, fontSize: 14 } }, t2;
})(ce);
function To(e2) {
  var t2 = e2.get(`confine`);
  return t2 == null ? e2.get(`renderMode`) === `richText` : !!t2;
}
function Eo(e2) {
  if (S.domSupported) {
    for (var t2 = document.documentElement.style, n2 = 0, r2 = e2.length; n2 < r2; n2++) if (e2[n2] in t2) return e2[n2];
  }
}
var Do = Eo([`transform`, `webkitTransform`, `OTransform`, `MozTransform`, `msTransform`]), Oo = Eo([`webkitTransition`, `transition`, `OTransition`, `MozTransition`, `msTransition`]);
function ko(e2, t2) {
  if (!e2) return t2;
  t2 = Ee(t2, true);
  var n2 = e2.indexOf(t2);
  return e2 = n2 === -1 ? t2 : `-` + e2.slice(0, n2) + `-` + t2, e2.toLowerCase();
}
function Ao(e2, t2) {
  var n2 = e2.currentStyle || document.defaultView && document.defaultView.getComputedStyle(e2);
  return n2 ? t2 ? n2[t2] : n2 : null;
}
var jo = ko(Oo, `transition`), Mo = ko(Do, `transform`), No = `position:absolute;display:block;border-style:solid;white-space:nowrap;z-index:9999999;` + (S.transform3dSupported ? `will-change:transform;` : ``);
function Po(e2) {
  return e2 = e2 === `left` ? `right` : e2 === `right` ? `left` : e2 === `top` ? `bottom` : `top`, e2;
}
function Fo(e2, t2, n2) {
  if (!z(n2) || n2 === `inside`) return ``;
  var r2 = e2.get(`backgroundColor`), i2 = e2.get(`borderWidth`);
  t2 = Ve(t2);
  var a2 = Po(n2), o2 = Math.max(Math.round(i2) * 1.5, 6), s2 = ``, c2 = Mo + `:`, l2;
  W([`left`, `right`], a2) > -1 ? (s2 += `top:50%`, c2 += `translateY(-50%) rotate(` + (l2 = a2 === `left` ? -225 : -45) + `deg)`) : (s2 += `left:50%`, c2 += `translateX(-50%) rotate(` + (l2 = a2 === `top` ? 225 : 45) + `deg)`);
  var u2 = l2 * Math.PI / 180, d2 = o2 + i2, f2 = d2 * Math.abs(Math.cos(u2)) + d2 * Math.abs(Math.sin(u2)), p2 = Math.round(((f2 - Math.SQRT2 * i2) / 2 + Math.SQRT2 * i2 - (f2 - d2) / 2) * 100) / 100;
  s2 += `;` + a2 + `:-` + p2 + `px`;
  var m2 = t2 + ` solid ` + i2 + `px;`;
  return `<div style="` + [`position:absolute;width:` + o2 + `px;height:` + o2 + `px;z-index:-1;`, s2 + `;` + c2 + `;`, `border-bottom:` + m2, `border-right:` + m2, `background-color:` + r2 + `;`].join(``) + `"></div>`;
}
function Io(e2, t2) {
  var n2 = `cubic-bezier(0.23,1,0.32,1)`, r2 = ` ` + e2 / 2 + `s ` + n2, i2 = `opacity` + r2 + `,visibility` + r2;
  return t2 || (r2 = ` ` + e2 + `s ` + n2, i2 += S.transformSupported ? `,` + Mo + r2 : `,left` + r2 + `,top` + r2), jo + `:` + i2;
}
function Lo(e2, t2, n2) {
  var r2 = e2.toFixed(0) + `px`, i2 = t2.toFixed(0) + `px`;
  if (!S.transformSupported) return n2 ? `top:` + i2 + `;left:` + r2 + `;` : [[`top`, i2], [`left`, r2]];
  var a2 = S.transform3dSupported, o2 = `translate` + (a2 ? `3d` : ``) + `(` + r2 + `,` + i2 + (a2 ? `,0` : ``) + `)`;
  return n2 ? `top:0;left:0;` + Mo + `:` + o2 + `;` : [[`top`, 0], [`left`, 0], [Do, o2]];
}
function Ro(e2) {
  var t2 = [], n2 = e2.get(`fontSize`), r2 = e2.getTextColor();
  r2 && t2.push(`color:` + r2), t2.push(`font:` + e2.getFont());
  var i2 = _e(e2.get(`lineHeight`), Math.round(n2 * 3 / 2));
  n2 && t2.push(`line-height:` + i2 + `px`);
  var a2 = e2.get(`textShadowColor`), o2 = e2.get(`textShadowBlur`) || 0, s2 = e2.get(`textShadowOffsetX`) || 0, c2 = e2.get(`textShadowOffsetY`) || 0;
  return a2 && o2 && t2.push(`text-shadow:` + s2 + `px ` + c2 + `px ` + o2 + `px ` + a2), F([`decoration`, `align`], function(n3) {
    var r3 = e2.get(n3);
    r3 && t2.push(`text-` + n3 + `:` + r3);
  }), t2.join(`;`);
}
function zo(e2, t2, n2) {
  var r2 = [], i2 = e2.get(`transitionDuration`), a2 = e2.get(`backgroundColor`), o2 = e2.get(`shadowBlur`), s2 = e2.get(`shadowColor`), c2 = e2.get(`shadowOffsetX`), l2 = e2.get(`shadowOffsetY`), u2 = e2.getModel(`textStyle`), d2 = qt(e2, `html`), f2 = c2 + `px ` + l2 + `px ` + o2 + `px ` + s2;
  return r2.push(`box-shadow:` + f2), t2 && i2 && r2.push(Io(i2, n2)), a2 && r2.push(`background-color:` + a2), F([`width`, `color`, `radius`], function(t3) {
    var n3 = `border-` + t3, i3 = Ee(n3), a3 = e2.get(i3);
    a3 != null && r2.push(n3 + `:` + a3 + (t3 === `color` ? `` : `px`));
  }), r2.push(Ro(u2)), d2 != null && r2.push(`padding:` + He(d2).join(`px `) + `px`), r2.join(`;`) + `;`;
}
function Bo(e2, t2, n2, r2, i2) {
  var a2 = t2 && t2.painter;
  if (n2) {
    var o2 = a2 && a2.getViewportRoot();
    o2 && Qe(e2, o2, n2, r2, i2);
  } else {
    e2[0] = r2, e2[1] = i2;
    var s2 = a2 && a2.getViewportRootOffset();
    s2 && (e2[0] += s2.offsetLeft, e2[1] += s2.offsetTop);
  }
  e2[2] = e2[0] / t2.getWidth(), e2[3] = e2[1] / t2.getHeight();
}
var Vo = (function() {
  function e2(e3, t2) {
    if (this._show = false, this._styleCoord = [0, 0, 0, 0], this._enterable = true, this._alwaysShowContent = false, this._firstShow = true, this._longHide = true, S.wxa) return null;
    var n2 = document.createElement(`div`);
    n2.domBelongToZr = true, this.el = n2;
    var r2 = this._zr = e3.getZr(), i2 = t2.appendTo, a2 = i2 && (z(i2) ? document.querySelector(i2) : te(i2) ? i2 : H(i2) && i2(e3.getDom()));
    Bo(this._styleCoord, r2, a2, e3.getWidth() / 2, e3.getHeight() / 2), (a2 || e3.getDom()).appendChild(n2), this._api = e3, this._container = a2;
    var o2 = this;
    n2.onmouseenter = function() {
      o2._enterable && (clearTimeout(o2._hideTimeout), o2._show = true), o2._inContent = true;
    }, n2.onmousemove = function(e4) {
      if (e4 || (e4 = window.event), !o2._enterable) {
        var t3 = r2.handler, n3 = r2.painter.getViewportRoot();
        qe(n3, e4, true), t3.dispatch(`mousemove`, e4);
      }
    }, n2.onmouseleave = function() {
      o2._inContent = false, o2._enterable && o2._show && o2.hideLater(o2._hideDelay);
    };
  }
  return e2.prototype.update = function(e3) {
    if (!this._container) {
      var t2 = this._api.getDom(), n2 = Ao(t2, `position`), r2 = t2.style;
      r2.position !== `absolute` && n2 !== `absolute` && (r2.position = `relative`);
    }
    var i2 = e3.get(`alwaysShowContent`);
    i2 && this._moveIfResized(), this._alwaysShowContent = i2, this.el.className = e3.get(`className`) || ``;
  }, e2.prototype.show = function(e3, t2) {
    clearTimeout(this._hideTimeout), clearTimeout(this._longHideTimeout);
    var n2 = this.el, r2 = n2.style, i2 = this._styleCoord;
    n2.innerHTML ? r2.cssText = No + zo(e3, !this._firstShow, this._longHide) + Lo(i2[0], i2[1], true) + (`border-color:` + Ve(t2) + `;`) + (e3.get(`extraCssText`) || ``) + (`;pointer-events:` + (this._enterable ? `auto` : `none`)) : r2.display = `none`, this._show = true, this._firstShow = false, this._longHide = false;
  }, e2.prototype.setContent = function(e3, t2, n2, r2, i2) {
    var a2 = this.el;
    if (e3 == null) {
      a2.innerHTML = ``;
      return;
    }
    var o2 = ``;
    if (z(i2) && n2.get(`trigger`) === `item` && !To(n2) && (o2 = Fo(n2, r2, i2)), z(e3)) a2.innerHTML = e3 + o2;
    else if (e3) {
      a2.innerHTML = ``, M(e3) || (e3 = [e3]);
      for (var s2 = 0; s2 < e3.length; s2++) te(e3[s2]) && e3[s2].parentNode !== a2 && a2.appendChild(e3[s2]);
      if (o2 && a2.childNodes.length) {
        var c2 = document.createElement(`div`);
        c2.innerHTML = o2, a2.appendChild(c2);
      }
    }
  }, e2.prototype.setEnterable = function(e3) {
    this._enterable = e3;
  }, e2.prototype.getSize = function() {
    var e3 = this.el;
    return e3 ? [e3.offsetWidth, e3.offsetHeight] : [0, 0];
  }, e2.prototype.moveTo = function(e3, t2) {
    if (this.el) {
      var n2 = this._styleCoord;
      if (Bo(n2, this._zr, this._container, e3, t2), n2[0] != null && n2[1] != null) {
        var r2 = this.el.style, i2 = Lo(n2[0], n2[1]);
        F(i2, function(e4) {
          r2[e4[0]] = e4[1];
        });
      }
    }
  }, e2.prototype._moveIfResized = function() {
    var e3 = this._styleCoord[2], t2 = this._styleCoord[3];
    this.moveTo(e3 * this._zr.getWidth(), t2 * this._zr.getHeight());
  }, e2.prototype.hide = function() {
    var e3 = this, t2 = this.el.style;
    t2.visibility = `hidden`, t2.opacity = `0`, S.transform3dSupported && (t2.willChange = ``), this._show = false, this._longHideTimeout = setTimeout(function() {
      return e3._longHide = true;
    }, 500);
  }, e2.prototype.hideLater = function(e3) {
    this._show && !(this._inContent && this._enterable) && !this._alwaysShowContent && (e3 ? (this._hideDelay = e3, this._show = false, this._hideTimeout = setTimeout(I(this.hide, this), e3)) : this.hide());
  }, e2.prototype.isShow = function() {
    return this._show;
  }, e2.prototype.dispose = function() {
    clearTimeout(this._hideTimeout), clearTimeout(this._longHideTimeout);
    var e3 = this.el.parentNode;
    e3 && e3.removeChild(this.el), this.el = this._container = null;
  }, e2;
})(), Ho = (function() {
  function e2(e3) {
    this._show = false, this._styleCoord = [0, 0, 0, 0], this._alwaysShowContent = false, this._enterable = true, this._zr = e3.getZr(), Wo(this._styleCoord, this._zr, e3.getWidth() / 2, e3.getHeight() / 2);
  }
  return e2.prototype.update = function(e3) {
    var t2 = e3.get(`alwaysShowContent`);
    t2 && this._moveIfResized(), this._alwaysShowContent = t2;
  }, e2.prototype.show = function() {
    this._hideTimeout && clearTimeout(this._hideTimeout), this.el.show(), this._show = true;
  }, e2.prototype.setContent = function(e3, t2, n2, r2, i2) {
    var a2 = this;
    A(e3) && ve(``), this.el && this._zr.remove(this.el);
    var o2 = n2.getModel(`textStyle`);
    this.el = new N({ style: { rich: t2.richTextStyles, text: e3, lineHeight: 22, borderWidth: 1, borderColor: r2, textShadowColor: o2.get(`textShadowColor`), fill: n2.get([`textStyle`, `color`]), padding: qt(n2, `richText`), verticalAlign: `top`, align: `left` }, z: n2.get(`z`) }), F([`backgroundColor`, `borderRadius`, `shadowColor`, `shadowBlur`, `shadowOffsetX`, `shadowOffsetY`], function(e4) {
      a2.el.style[e4] = n2.get(e4);
    }), F([`textShadowBlur`, `textShadowOffsetX`, `textShadowOffsetY`], function(e4) {
      a2.el.style[e4] = o2.get(e4) || 0;
    }), this._zr.add(this.el);
    var s2 = this;
    this.el.on(`mouseover`, function() {
      s2._enterable && (clearTimeout(s2._hideTimeout), s2._show = true), s2._inContent = true;
    }), this.el.on(`mouseout`, function() {
      s2._enterable && s2._show && s2.hideLater(s2._hideDelay), s2._inContent = false;
    });
  }, e2.prototype.setEnterable = function(e3) {
    this._enterable = e3;
  }, e2.prototype.getSize = function() {
    var e3 = this.el, t2 = this.el.getBoundingRect(), n2 = Uo(e3.style);
    return [t2.width + n2.left + n2.right, t2.height + n2.top + n2.bottom];
  }, e2.prototype.moveTo = function(e3, t2) {
    var n2 = this.el;
    if (n2) {
      var r2 = this._styleCoord;
      Wo(r2, this._zr, e3, t2), e3 = r2[0], t2 = r2[1];
      var i2 = n2.style, a2 = Z(i2.borderWidth || 0), o2 = Uo(i2);
      n2.x = e3 + a2 + o2.left, n2.y = t2 + a2 + o2.top, n2.markRedraw();
    }
  }, e2.prototype._moveIfResized = function() {
    var e3 = this._styleCoord[2], t2 = this._styleCoord[3];
    this.moveTo(e3 * this._zr.getWidth(), t2 * this._zr.getHeight());
  }, e2.prototype.hide = function() {
    this.el && this.el.hide(), this._show = false;
  }, e2.prototype.hideLater = function(e3) {
    this._show && !(this._inContent && this._enterable) && !this._alwaysShowContent && (e3 ? (this._hideDelay = e3, this._show = false, this._hideTimeout = setTimeout(I(this.hide, this), e3)) : this.hide());
  }, e2.prototype.isShow = function() {
    return this._show;
  }, e2.prototype.dispose = function() {
    this._zr.remove(this.el);
  }, e2;
})();
function Z(e2) {
  return Math.max(0, e2);
}
function Uo(e2) {
  var t2 = Z(e2.shadowBlur || 0), n2 = Z(e2.shadowOffsetX || 0), r2 = Z(e2.shadowOffsetY || 0);
  return { left: Z(t2 - n2), right: Z(t2 + n2), top: Z(t2 - r2), bottom: Z(t2 + r2) };
}
function Wo(e2, t2, n2, r2) {
  e2[0] = n2, e2[1] = r2, e2[2] = e2[0] / t2.getWidth(), e2[3] = e2[1] / t2.getHeight();
}
P();
var Go = new T({ shape: { x: -1, y: -1, width: 2, height: 2 } }), Ko = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.prototype.init = function(e3, t3) {
    if (!S.node && t3.getDom()) {
      var n2 = e3.getComponent(`tooltip`), r2 = this._renderMode = ht(n2.get(`renderMode`));
      this._tooltipContent = r2 === `richText` ? new Ho(t3) : new Vo(t3, { appendTo: n2.get(`appendToBody`, true) ? `body` : n2.get(`appendTo`, true) });
    }
  }, t2.prototype.render = function(e3, t3, n2) {
    if (!S.node && n2.getDom()) {
      this.group.removeAll(), this._tooltipModel = e3, this._ecModel = t3, this._api = n2;
      var r2 = this._tooltipContent;
      r2.update(e3), r2.setEnterable(e3.get(`enterable`)), this._initGlobalListener(), this._keepShow(), this._renderMode !== `richText` && e3.get(`transitionDuration`) ? Ce(this, `_updatePosition`, 50, `fixRate`) : xe(this, `_updatePosition`);
    }
  }, t2.prototype._initGlobalListener = function() {
    var e3 = this._tooltipModel.get(`triggerOn`);
    Mi(`itemTooltip`, this._api, I(function(t3, n2, r2) {
      e3 !== `none` && (e3.indexOf(t3) >= 0 ? this._tryShow(n2, r2) : t3 === `leave` && this._hide(r2));
    }, this));
  }, t2.prototype._keepShow = function() {
    var e3 = this._tooltipModel, t3 = this._ecModel, n2 = this._api, r2 = e3.get(`triggerOn`);
    if (this._lastX != null && this._lastY != null && r2 !== `none` && r2 !== `click`) {
      var i2 = this;
      clearTimeout(this._refreshUpdateTimeout), this._refreshUpdateTimeout = setTimeout(function() {
        !n2.isDisposed() && i2.manuallyShowTip(e3, t3, n2, { x: i2._lastX, y: i2._lastY, dataByCoordSys: i2._lastDataByCoordSys });
      });
    }
  }, t2.prototype.manuallyShowTip = function(e3, t3, n2, r2) {
    if (r2.from !== this.uid && !S.node && n2.getDom()) {
      var i2 = Jo(r2, n2);
      this._ticket = ``;
      var a2 = r2.dataByCoordSys, o2 = $o(r2, t3, n2);
      if (o2) {
        var s2 = o2.el.getBoundingRect().clone();
        s2.applyTransform(o2.el.transform), this._tryShow({ offsetX: s2.x + s2.width / 2, offsetY: s2.y + s2.height / 2, target: o2.el, position: r2.position, positionDefault: `bottom` }, i2);
      } else if (r2.tooltip && r2.x != null && r2.y != null) {
        var c2 = Go;
        c2.x = r2.x, c2.y = r2.y, c2.update(), U(c2).tooltipConfig = { name: null, option: r2.tooltip }, this._tryShow({ offsetX: r2.x, offsetY: r2.y, target: c2 }, i2);
      } else if (a2) this._tryShow({ offsetX: r2.x, offsetY: r2.y, position: r2.position, dataByCoordSys: a2, tooltipOption: r2.tooltipOption }, i2);
      else if (r2.seriesIndex != null) {
        if (this._manuallyAxisShowTip(e3, t3, n2, r2)) return;
        var l2 = Bi(r2, t3), u2 = l2.point[0], d2 = l2.point[1];
        u2 != null && d2 != null && this._tryShow({ offsetX: u2, offsetY: d2, target: l2.el, position: r2.position, positionDefault: `bottom` }, i2);
      } else r2.x != null && r2.y != null && (n2.dispatchAction({ type: `updateAxisPointer`, x: r2.x, y: r2.y }), this._tryShow({ offsetX: r2.x, offsetY: r2.y, position: r2.position, target: n2.getZr().findHover(r2.x, r2.y).target }, i2));
    }
  }, t2.prototype.manuallyHideTip = function(e3, t3, n2, r2) {
    var i2 = this._tooltipContent;
    this._tooltipModel && i2.hideLater(this._tooltipModel.get(`hideDelay`)), this._lastX = this._lastY = this._lastDataByCoordSys = null, r2.from !== this.uid && this._hide(Jo(r2, n2));
  }, t2.prototype._manuallyAxisShowTip = function(e3, t3, n2, r2) {
    var i2 = r2.seriesIndex, a2 = r2.dataIndex, o2 = t3.getComponent(`axisPointer`).coordSysAxesInfo;
    if (i2 != null && a2 != null && o2 != null) {
      var s2 = t3.getSeriesByIndex(i2);
      if (s2 && qo([s2.getData().getItemModel(a2), s2, (s2.coordinateSystem || {}).model], this._tooltipModel).get(`trigger`) === `axis`) return n2.dispatchAction({ type: `updateAxisPointer`, seriesIndex: i2, dataIndex: a2, position: r2.position }), true;
    }
  }, t2.prototype._tryShow = function(e3, t3) {
    var n2 = e3.target;
    if (this._tooltipModel) {
      this._lastX = e3.offsetX, this._lastY = e3.offsetY;
      var r2 = e3.dataByCoordSys;
      if (r2 && r2.length) this._showAxisTooltip(r2, e3);
      else if (n2) {
        if (U(n2).ssrType === `legend`) return;
        this._lastDataByCoordSys = null;
        var i2, a2;
        ye(n2, function(e4) {
          if (U(e4).dataIndex != null) return i2 = e4, true;
          if (U(e4).tooltipConfig != null) return a2 = e4, true;
        }, true), i2 ? this._showSeriesItemTooltip(e3, i2, t3) : a2 ? this._showComponentItemTooltip(e3, a2, t3) : this._hide(t3);
      } else this._lastDataByCoordSys = null, this._hide(t3);
    }
  }, t2.prototype._showOrMove = function(e3, t3) {
    var n2 = e3.get(`showDelay`);
    t3 = I(t3, this), clearTimeout(this._showTimout), n2 > 0 ? this._showTimout = setTimeout(t3, n2) : t3();
  }, t2.prototype._showAxisTooltip = function(e3, t3) {
    var n2 = this._ecModel, r2 = this._tooltipModel, i2 = [t3.offsetX, t3.offsetY], a2 = qo([t3.tooltipOption], r2), o2 = this._renderMode, s2 = [], c2 = Oe(`section`, { blocks: [], noHeader: true }), l2 = [], u2 = new ue();
    F(e3, function(e4) {
      F(e4.dataByAxis, function(e5) {
        var t4 = n2.getComponent(e5.axisDim + `Axis`, e5.axisIndex), i3 = e5.value;
        if (t4 && i3 != null) {
          var a3 = xi(i3, t4.axis, n2, e5.seriesDataIndices, e5.valueLabelOpt), d3 = Oe(`section`, { header: a3, noHeader: !ke(a3), sortBlocks: true, blocks: [] });
          c2.blocks.push(d3), F(e5.seriesDataIndices, function(c3) {
            var f3 = n2.getSeriesByIndex(c3.seriesIndex), p3 = c3.dataIndexInside, m3 = f3.getDataParams(p3);
            if (!(m3.dataIndex < 0)) {
              m3.axisDim = e5.axisDim, m3.axisIndex = e5.axisIndex, m3.axisType = e5.axisType, m3.axisId = e5.axisId, m3.axisValue = Lt(t4.axis, { value: i3 }), m3.axisValueLabel = a3, m3.marker = u2.makeTooltipMarker(`item`, Ve(m3.color), o2);
              var h3 = x(f3.formatTooltip(p3, true, null)), g2 = h3.frag;
              if (g2) {
                var _2 = qo([f3], r2).get(`valueFormatter`);
                d3.blocks.push(_2 ? Vt({ valueFormatter: _2 }, g2) : g2);
              }
              h3.text && l2.push(h3.text), s2.push(m3);
            }
          });
        }
      });
    }), c2.blocks.reverse(), l2.reverse();
    var d2 = t3.position, f2 = a2.get(`order`), p2 = ge(c2, u2, o2, f2, n2.get(`useUTC`), a2.get(`textStyle`));
    p2 && l2.unshift(p2);
    var m2 = o2 === `richText` ? `

` : `<br/>`, h2 = l2.join(m2);
    this._showOrMove(a2, function() {
      this._updateContentNotChangedOnAxis(e3, s2) ? this._updatePosition(a2, d2, i2[0], i2[1], this._tooltipContent, s2) : this._showTooltipContent(a2, h2, s2, Math.random() + ``, i2[0], i2[1], d2, null, u2);
    });
  }, t2.prototype._showSeriesItemTooltip = function(e3, t3, n2) {
    var r2 = this._ecModel, i2 = U(t3), a2 = i2.seriesIndex, o2 = r2.getSeriesByIndex(a2), s2 = i2.dataModel || o2, c2 = i2.dataIndex, l2 = i2.dataType, u2 = s2.getData(l2), d2 = this._renderMode, f2 = e3.positionDefault, p2 = qo([u2.getItemModel(c2), s2, o2 && (o2.coordinateSystem || {}).model], this._tooltipModel, f2 ? { position: f2 } : null), m2 = p2.get(`trigger`);
    if (m2 == null || m2 === `item`) {
      var h2 = s2.getDataParams(c2, l2), g2 = new ue();
      h2.marker = g2.makeTooltipMarker(`item`, Ve(h2.color), d2);
      var _2 = x(s2.formatTooltip(c2, false, l2)), v2 = p2.get(`order`), y2 = p2.get(`valueFormatter`), b2 = _2.frag, S2 = b2 ? ge(y2 ? Vt({ valueFormatter: y2 }, b2) : b2, g2, d2, v2, r2.get(`useUTC`), p2.get(`textStyle`)) : _2.text, C2 = `item_` + s2.name + `_` + c2;
      this._showOrMove(p2, function() {
        this._showTooltipContent(p2, S2, h2, C2, e3.offsetX, e3.offsetY, e3.position, e3.target, g2);
      }), n2({ type: `showTip`, dataIndexInside: c2, dataIndex: u2.getRawIndex(c2), seriesIndex: a2, from: this.uid });
    }
  }, t2.prototype._showComponentItemTooltip = function(e3, t3, n2) {
    var r2 = this._renderMode === `html`, i2 = U(t3), a2 = i2.tooltipConfig.option || {}, o2 = a2.encodeHTMLContent;
    if (z(a2)) {
      var s2 = a2;
      a2 = { content: s2, formatter: s2 }, o2 = true;
    }
    o2 && r2 && a2.content && (a2 = L(a2), a2.content = Mt(a2.content));
    var c2 = [a2], l2 = this._ecModel.getComponent(i2.componentMainType, i2.componentIndex);
    l2 && c2.push(l2), c2.push({ formatter: a2.content });
    var u2 = e3.positionDefault, d2 = qo(c2, this._tooltipModel, u2 ? { position: u2 } : null), f2 = d2.get(`content`), p2 = Math.random() + ``, m2 = new ue();
    this._showOrMove(d2, function() {
      var n3 = L(d2.get(`formatterParams`) || {});
      this._showTooltipContent(d2, f2, n3, p2, e3.offsetX, e3.offsetY, e3.position, t3, m2);
    }), n2({ type: `showTip`, from: this.uid });
  }, t2.prototype._showTooltipContent = function(e3, t3, n2, r2, i2, a2, o2, s2, c2) {
    if (this._ticket = ``, e3.get(`showContent`) && e3.get(`show`)) {
      var l2 = this._tooltipContent;
      l2.setEnterable(e3.get(`enterable`));
      var u2 = e3.get(`formatter`);
      o2 || (o2 = e3.get(`position`));
      var d2 = t3, f2 = this._getNearestPoint([i2, a2], n2, e3.get(`trigger`), e3.get(`borderColor`)).color;
      if (u2) {
        if (z(u2)) {
          var p2 = e3.ecModel.get(`useUTC`), m2 = M(n2) ? n2[0] : n2, h2 = m2 && m2.axisType && m2.axisType.indexOf(`time`) >= 0;
          d2 = u2, h2 && (d2 = rt(m2.axisValue, d2, p2)), d2 = Be(d2, n2, true);
        } else if (H(u2)) {
          var g2 = I(function(t4, r3) {
            t4 === this._ticket && (l2.setContent(r3, c2, e3, f2, o2), this._updatePosition(e3, o2, i2, a2, l2, n2, s2));
          }, this);
          this._ticket = r2, d2 = u2(n2, r2, g2);
        } else d2 = u2;
      }
      l2.setContent(d2, c2, e3, f2, o2), l2.show(e3, f2), this._updatePosition(e3, o2, i2, a2, l2, n2, s2);
    }
  }, t2.prototype._getNearestPoint = function(e3, t3, n2, r2) {
    if (n2 === `axis` || M(t3)) return { color: r2 || (this._renderMode === `html` ? `#fff` : `none`) };
    if (!M(t3)) return { color: r2 || t3.color || t3.borderColor };
  }, t2.prototype._updatePosition = function(e3, t3, n2, r2, i2, a2, o2) {
    var s2 = this._api.getWidth(), c2 = this._api.getHeight();
    t3 || (t3 = e3.get(`position`));
    var l2 = i2.getSize(), u2 = e3.get(`align`), d2 = e3.get(`verticalAlign`), f2 = o2 && o2.getBoundingRect().clone();
    if (o2 && f2.applyTransform(o2.transform), H(t3) && (t3 = t3([n2, r2], a2, i2.el, f2, { viewSize: [s2, c2], contentSize: l2.slice() })), M(t3)) n2 = le(t3[0], s2), r2 = le(t3[1], c2);
    else if (A(t3)) {
      var p2 = t3;
      p2.width = l2[0], p2.height = l2[1];
      var m2 = me(p2, { width: s2, height: c2 });
      n2 = m2.x, r2 = m2.y, u2 = null, d2 = null;
    } else if (z(t3) && o2) {
      var h2 = Zo(t3, f2, l2, e3.get(`borderWidth`));
      n2 = h2[0], r2 = h2[1];
    } else {
      var h2 = Yo(n2, r2, i2, s2, c2, u2 ? null : 20, d2 ? null : 20);
      n2 = h2[0], r2 = h2[1];
    }
    if (u2 && (n2 -= Qo(u2) ? l2[0] / 2 : u2 === `right` ? l2[0] : 0), d2 && (r2 -= Qo(d2) ? l2[1] / 2 : d2 === `bottom` ? l2[1] : 0), To(e3)) {
      var h2 = Xo(n2, r2, i2, s2, c2);
      n2 = h2[0], r2 = h2[1];
    }
    i2.moveTo(n2, r2);
  }, t2.prototype._updateContentNotChangedOnAxis = function(e3, t3) {
    var n2 = this._lastDataByCoordSys, r2 = this._cbParamsList, i2 = !!n2 && n2.length === e3.length;
    return i2 && F(n2, function(n3, a2) {
      var o2 = n3.dataByAxis || [], s2 = (e3[a2] || {}).dataByAxis || [];
      i2 && (i2 = o2.length === s2.length), i2 && F(o2, function(e4, n4) {
        var a3 = s2[n4] || {}, o3 = e4.seriesDataIndices || [], c2 = a3.seriesDataIndices || [];
        i2 = i2 && e4.value === a3.value && e4.axisType === a3.axisType && e4.axisId === a3.axisId && o3.length === c2.length, i2 && F(o3, function(e5, t4) {
          var n5 = c2[t4];
          i2 = i2 && e5.seriesIndex === n5.seriesIndex && e5.dataIndex === n5.dataIndex;
        }), r2 && F(e4.seriesDataIndices, function(e5) {
          var n5 = e5.seriesIndex, a4 = t3[n5], o4 = r2[n5];
          a4 && o4 && o4.data !== a4.data && (i2 = false);
        });
      });
    }), this._lastDataByCoordSys = e3, this._cbParamsList = t3, !!i2;
  }, t2.prototype._hide = function(e3) {
    this._lastDataByCoordSys = null, e3({ type: `hideTip`, from: this.uid });
  }, t2.prototype.dispose = function(e3, t3) {
    !S.node && t3.getDom() && (xe(this, `_updatePosition`), this._tooltipContent.dispose(), Ri(`itemTooltip`, t3));
  }, t2.type = `tooltip`, t2;
})(E);
function qo(e2, t2, n2) {
  var r2 = t2.ecModel, i2;
  n2 ? (i2 = new V(n2, r2, r2), i2 = new V(t2.option, i2, r2)) : i2 = t2;
  for (var a2 = e2.length - 1; a2 >= 0; a2--) {
    var o2 = e2[a2];
    o2 && (o2 instanceof V && (o2 = o2.get(`tooltip`, true)), z(o2) && (o2 = { formatter: o2 }), o2 && (i2 = new V(o2, i2, r2)));
  }
  return i2;
}
function Jo(e2, t2) {
  return e2.dispatchAction || I(t2.dispatchAction, t2);
}
function Yo(e2, t2, n2, r2, i2, a2, o2) {
  var s2 = n2.getSize(), c2 = s2[0], l2 = s2[1];
  return a2 != null && (e2 + c2 + a2 + 2 > r2 ? e2 -= c2 + a2 : e2 += a2), o2 != null && (t2 + l2 + o2 > i2 ? t2 -= l2 + o2 : t2 += o2), [e2, t2];
}
function Xo(e2, t2, n2, r2, i2) {
  var a2 = n2.getSize(), o2 = a2[0], s2 = a2[1];
  return e2 = Math.min(e2 + o2, r2) - o2, t2 = Math.min(t2 + s2, i2) - s2, e2 = Math.max(e2, 0), t2 = Math.max(t2, 0), [e2, t2];
}
function Zo(e2, t2, n2, r2) {
  var i2 = n2[0], a2 = n2[1], o2 = Math.ceil(Math.SQRT2 * r2) + 8, s2 = 0, c2 = 0, l2 = t2.width, u2 = t2.height;
  switch (e2) {
    case `inside`:
      s2 = t2.x + l2 / 2 - i2 / 2, c2 = t2.y + u2 / 2 - a2 / 2;
      break;
    case `top`:
      s2 = t2.x + l2 / 2 - i2 / 2, c2 = t2.y - a2 - o2;
      break;
    case `bottom`:
      s2 = t2.x + l2 / 2 - i2 / 2, c2 = t2.y + u2 + o2;
      break;
    case `left`:
      s2 = t2.x - i2 - o2, c2 = t2.y + u2 / 2 - a2 / 2;
      break;
    case `right`:
      s2 = t2.x + l2 + o2, c2 = t2.y + u2 / 2 - a2 / 2;
  }
  return [s2, c2];
}
function Qo(e2) {
  return e2 === `center` || e2 === `middle`;
}
function $o(e2, t2, n2) {
  var r2 = Te(e2).queryOptionMap, i2 = r2.keys()[0];
  if (i2 && i2 !== `series`) {
    var a2 = fe(t2, i2, r2.get(i2), { useDefault: false, enableAll: false, enableNone: false }).models[0];
    if (a2) {
      var o2 = n2.getViewOfComponentModel(a2), s2;
      if (o2.group.traverse(function(t3) {
        var n3 = U(t3).tooltipConfig;
        if (n3 && n3.name === e2.name) return s2 = t3, true;
      }), s2) return { componentMainType: i2, componentIndex: a2.componentIndex, el: s2 };
    }
  }
}
function es(e2) {
  Ct($i), e2.registerComponentModel(wo), e2.registerComponentView(Ko), e2.registerAction({ type: `showTip`, event: `showTip`, update: `tooltip:manuallyShowTip` }, ie), e2.registerAction({ type: `hideTip`, event: `hideTip`, update: `tooltip:manuallyHideTip` }, ie);
}
P();
var ts = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2.layoutMode = { type: `box`, ignoreSize: true }, n2;
  }
  return t2.type = `title`, t2.defaultOption = { z: 6, show: true, text: ``, target: `blank`, subtext: ``, subtarget: `blank`, left: 0, top: 0, backgroundColor: `rgba(0,0,0,0)`, borderColor: `#ccc`, borderWidth: 0, padding: 5, itemGap: 10, textStyle: { fontSize: 18, fontWeight: `bold`, color: `#464646` }, subtextStyle: { fontSize: 12, color: `#6E7079` } }, t2;
})(ce), ns = (function(e2) {
  D(t2, e2);
  function t2() {
    var n2 = e2 !== null && e2.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.prototype.render = function(e3, t3, n2) {
    if (this.group.removeAll(), e3.get(`show`)) {
      var r2 = this.group, i2 = e3.getModel(`textStyle`), a2 = e3.getModel(`subtextStyle`), o2 = e3.get(`textAlign`), s2 = _e(e3.get(`textBaseline`), e3.get(`textVerticalAlign`)), c2 = new N({ style: ft(i2, { text: e3.get(`text`), fill: i2.getTextColor() }, { disableBox: true }), z2: 10 }), l2 = c2.getBoundingRect(), u2 = e3.get(`subtext`), d2 = new N({ style: ft(a2, { text: u2, fill: a2.getTextColor(), y: l2.height + e3.get(`itemGap`), verticalAlign: `top` }, { disableBox: true }), z2: 10 }), f2 = e3.get(`link`), p2 = e3.get(`sublink`), m2 = e3.get(`triggerEvent`, true);
      c2.silent = !f2 && !m2, d2.silent = !p2 && !m2, f2 && c2.on(`click`, function() {
        _(f2, `_` + e3.get(`target`));
      }), p2 && d2.on(`click`, function() {
        _(p2, `_` + e3.get(`subtarget`));
      }), U(c2).eventData = U(d2).eventData = m2 ? { componentType: `title`, componentIndex: e3.componentIndex } : null, r2.add(c2), u2 && r2.add(d2);
      var h2 = r2.getBoundingRect(), g2 = e3.getBoxLayoutParams();
      g2.width = h2.width, g2.height = h2.height;
      var v2 = me(g2, { width: n2.getWidth(), height: n2.getHeight() }, e3.get(`padding`));
      o2 || (o2 = e3.get(`left`) || e3.get(`right`), o2 === `middle` && (o2 = `center`), o2 === `right` ? v2.x += v2.width : o2 === `center` && (v2.x += v2.width / 2)), s2 || (s2 = e3.get(`top`) || e3.get(`bottom`), s2 === `center` && (s2 = `middle`), s2 === `bottom` ? v2.y += v2.height : s2 === `middle` && (v2.y += v2.height / 2), s2 || (s2 = `top`)), r2.x = v2.x, r2.y = v2.y, r2.markRedraw();
      var y2 = { align: o2, verticalAlign: s2 };
      c2.setStyle(y2), d2.setStyle(y2), h2 = r2.getBoundingRect();
      var b2 = v2.margin, x2 = e3.getItemStyle([`color`, `opacity`]);
      x2.fill = e3.get(`backgroundColor`);
      var S2 = new T({ shape: { x: h2.x - b2[3], y: h2.y - b2[0], width: h2.width + b2[1] + b2[3], height: h2.height + b2[0] + b2[2], r: e3.get(`borderRadius`) }, style: x2, subPixelOptimize: true, silent: true });
      r2.add(S2);
    }
  }, t2.type = `title`, t2;
})(E);
function rs(e2) {
  e2.registerComponentModel(ts), e2.registerComponentView(ns);
}
t();
var is = e(Ie(), 1);
Ct([xt, Co, rs, es, ea, kt, Pt]);
function as(e2) {
  return f(`svg`, { viewBox: `0 0 512 512`, width: e2.width || 20, height: e2.height || e2.width || 20, xmlns: `http://www.w3.org/2000/svg`, style: e2.style, children: f(`path`, { fill: `currentColor`, d: `M496 384H64V80c0-8.84-7.16-16-16-16H16C7.16 64 0 71.16 0 80v336c0 17.67 14.33 32 32 32h464c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16zM464 96H345.94c-21.38 0-32.09 25.85-16.97 40.97l32.4 32.4L288 242.75l-73.37-73.37c-12.5-12.5-32.76-12.5-45.25 0l-68.69 68.69c-6.25 6.25-6.25 16.38 0 22.63l22.62 22.62c6.25 6.25 16.38 6.25 22.63 0L192 237.25l73.37 73.37c12.5 12.5 32.76 12.5 45.25 0l96-96 32.4 32.4c15.12 15.12 40.97 4.41 40.97-16.97V112c.01-8.84-7.15-16-15.99-16z` }) });
}
var os = { chartWithToolbar: (e2) => {
  var _a2;
  return { height: `calc(100% - ${parseFloat(((_a2 = e2 == null ? void 0 : e2.mixins) == null ? void 0 : _a2.toolbar.minHeight) || `48`) + 8}px)` };
}, chartWithoutToolbar: { height: `100%` }, customRange: (e2) => {
  var _a2;
  return { color: ((_a2 = e2 == null ? void 0 : e2.palette) == null ? void 0 : _a2.primary.main) || `#00bcd4` };
} }, Q = 80, $ = 25, ss = class extends n {
  readTimeout = null;
  timeTimer = null;
  start;
  end;
  echartsReact = null;
  rangeRef = r();
  maxYLenTimeout = null;
  maxYLenTimeout2 = null;
  timerResize = null;
  mouseDown = false;
  chart = {};
  divRef = r();
  unit;
  unit2;
  minY;
  maxY;
  minX;
  maxX;
  chartValues = null;
  constructor(e2) {
    var _a2, _b, _c, _d;
    if (super(e2), this.props.from) this.start = this.props.from;
    else {
      let e3 = /* @__PURE__ */ new Date();
      e3.setHours(e3.getHours() - 168), this.start = e3.getTime();
    }
    this.end = this.props.end ? this.props.end : Date.now();
    let t2 = window.localStorage.getItem(`App.relativeRange`) || `30`, n2 = parseInt(window.localStorage.getItem(`App.absoluteStart`), 10) || 0, r2 = parseInt(window.localStorage.getItem(`App.absoluteEnd`), 10) || 0;
    (!n2 || !r2) && (!t2 || t2 === `absolute`) && (t2 = `30`), r2 && n2 && (t2 = `absolute`), this.state = { chartHeight: 300, chartWidth: 500, relativeRange: t2, splitLine: window.localStorage.getItem(`App.splitLine`) === `true`, max: r2, maxYLen: 0, maxYLen2: 0 }, this.unit = this.props.unit ? ` ${this.props.unit}` : ((_b = (_a2 = this.props.obj) == null ? void 0 : _a2.common) == null ? void 0 : _b.unit) ? ` ${this.props.obj.common.unit}` : ``, this.unit2 = this.props.unit2 ? ` ${this.props.unit2}` : ((_d = (_c = this.props.obj2) == null ? void 0 : _c.common) == null ? void 0 : _d.unit) ? ` ${this.props.obj2.common.unit}` : ``;
  }
  componentDidMount() {
    var _a2;
    let e2 = [];
    this.props.obj._id && this.props.obj._id !== `nothing_selected` && e2.push(this.props.obj._id), ((_a2 = this.props.obj2) == null ? void 0 : _a2._id) && this.props.obj2._id !== `nothing_selected` && e2.push(this.props.obj2._id), e2.length && this.props.socket.subscribeState(e2, this.onChange), window.addEventListener(`resize`, this.onResize), this.setRelativeInterval(this.state.relativeRange, true, () => this.forceUpdate());
  }
  componentWillUnmount() {
    var _a2;
    this.readTimeout && (this.readTimeout = (clearTimeout(this.readTimeout), null)), this.timeTimer && clearTimeout(this.timeTimer), this.timeTimer = null, this.maxYLenTimeout && clearTimeout(this.maxYLenTimeout), this.maxYLenTimeout = null, this.maxYLenTimeout2 && clearTimeout(this.maxYLenTimeout2), this.maxYLenTimeout2 = null;
    let e2 = [];
    this.props.obj._id && this.props.obj._id !== `nothing_selected` && e2.push(this.props.obj._id), ((_a2 = this.props.obj2) == null ? void 0 : _a2._id) && this.props.obj2._id !== `nothing_selected` && e2.push(this.props.obj2._id), e2.length && this.props.socket.unsubscribeState(e2, this.onChange), window.removeEventListener(`resize`, this.onResize);
  }
  onResize = () => {
    this.timerResize && clearTimeout(this.timerResize), this.timerResize = setTimeout(() => {
      this.timerResize = null, this.componentDidUpdate();
    });
  };
  onChange = (e2, t2) => {
    var _a2, _b, _c;
    (e2 === this.props.obj._id || e2 === ((_a2 = this.props.obj2) == null ? void 0 : _a2._id)) && t2 && (!this.state.max || t2.ts - this.state.max < 12e4) && ((_c = (_b = this.chartValues) == null ? void 0 : _b[e2]) == null ? void 0 : _c.push({ val: t2.val, ts: t2.ts }), t2.ts >= this.chart.min && t2.ts <= this.chart.max + 3e5 && this.updateChart());
  };
  async readHistory(e2, t2, n2) {
    var _a2;
    let r2 = { instance: n2 === ((_a2 = this.props.obj2) == null ? void 0 : _a2._id) ? this.props.historyInstance2 : this.props.historyInstance, start: e2, end: t2, from: false, ack: false, q: false, addId: false, aggregate: `none`, returnNewestEntries: true };
    !n2 && t2 - e2 > 18e5 && !(this.props.obj.common.type === `boolean` || this.props.obj.common.type === `number` && this.props.obj.common.states) && (r2.aggregate = `minmax`);
    let i2 = await this.props.socket.getHistory(n2, r2), a2 = [], o2 = null, s2 = null;
    for (let e3 = 0; e3 < i2.length; e3++) !a2.length || a2[a2.length - 1].ts < i2[e3].ts ? a2.push(i2[e3]) : a2[a2.length - 1].ts === i2[e3].ts && a2[a2.length - 1].val !== i2[e3].ts && console.error(`Strange data!`), (o2 === null || i2[e3].val < o2) && (o2 = i2[e3].val), (s2 === null || i2[e3].val > s2) && (s2 = i2[e3].val);
    return a2.sort((e3, t3) => e3.ts > t3.ts ? 1 : e3.ts < t3.ts ? -1 : 0), n2 || (n2 = this.props.obj._id), this.chartValues || (this.chartValues = {}), this.minY || (this.minY = {}), this.maxY || (this.maxY = {}), this.minX || (this.minX = {}), this.maxX || (this.maxX = {}), this.chartValues[n2] = a2, this.minY[n2] = o2, this.maxY[n2] = s2, this.minX[n2] = o2, this.maxX[n2] = s2, this.minY[n2] < 10 ? this.minY[n2] = Math.round(this.minY[n2] * 10) / 10 : this.minY[n2] = Math.ceil(this.minY[n2]), this.maxY[n2] < 10 ? this.maxY[n2] = Math.round(this.maxY[n2] * 10) / 10 : this.maxY[n2] = Math.ceil(this.maxY[n2]), a2;
  }
  convertData(e2, t2) {
    e2 || (e2 = this.chartValues[t2]);
    let n2 = [];
    if (!(e2 == null ? void 0 : e2.length)) return n2;
    for (let t3 = 0; t3 < e2.length; t3++) {
      let r2 = { value: [e2[t3].ts, e2[t3].val] };
      e2[t3].i && (r2.exact = false), n2.push(r2);
    }
    return t2 === this.props.obj._id && !this.chart.min && (this.chart.min = e2[0].ts, this.chart.max = e2[e2.length - 1].ts), n2;
  }
  static getColor(e2, t2) {
    let n2, r2, i2;
    if (e2.startsWith(`#`)) n2 = parseInt(e2.substring(1, 3), 16), r2 = parseInt(e2.substring(3, 5), 16), i2 = parseInt(e2.substring(5, 7), 16);
    else if (e2.startsWith(`rgb(`)) {
      let t3 = e2.replace(`rgb(`, ``).replace(`)`, ``).split(`,`);
      n2 = parseInt(t3[0], 10), r2 = parseInt(t3[1], 10), i2 = parseInt(t3[2], 10);
    } else if (e2.startsWith(`rgba(`)) {
      let t3 = e2.replace(`rgba(`, ``).replace(`)`, ``).split(`,`);
      n2 = parseInt(t3[0], 10), r2 = parseInt(t3[1], 10), i2 = parseInt(t3[2], 10);
    }
    return `rgba(${n2},${r2},${i2},${t2})`;
  }
  getOption() {
    var _a2, _b, _c, _d, _e2, _f, _g, _h, _i2, _j, _k, _l;
    let e2;
    if (this.minY[this.props.obj._id] !== null && this.minY[this.props.obj._id] !== void 0 && (e2 = (this.minY[this.props.obj._id].toString() + this.unit).length * 9 + 12), this.maxY[this.props.obj._id] !== null && this.maxY[this.props.obj._id] !== void 0) {
      let t3 = (this.maxY[this.props.obj._id].toString() + this.unit).length * 9 + 12;
      t3 > e2 && (e2 = t3);
    }
    if (this.state.maxYLen) {
      let t3 = this.state.maxYLen * 9 + 12;
      t3 > e2 && (e2 = t3);
    }
    let t2;
    if (this.props.obj2) {
      if (this.minY[this.props.obj2._id] !== null && this.minY[this.props.obj2._id] !== void 0 && (t2 = (this.minY[this.props.obj2._id].toString() + this.unit2).length * 9 + 12), this.maxY[this.props.obj2._id] !== null && this.maxY[this.props.obj2._id] !== void 0) {
        let e3 = (this.maxY[this.props.obj2._id].toString() + this.unit2).length * 9 + 12;
        e3 > t2 && (t2 = e3);
      }
      if (this.state.maxYLen2) {
        let e3 = this.state.maxYLen2 * 9 + 12;
        e3 > t2 && (t2 = e3);
      }
    }
    let n2 = { xAxisIndex: 0, type: `line`, step: this.props.objLineType === `step` ? `start` : void 0, showSymbol: false, hoverAnimation: true, animation: false, data: this.convertData(null, this.props.obj._id), areaStyle: { color: this.props.objBackgroundColor || `rgba(243,177,31,0.14)` }, lineStyle: { color: this.props.objColor || `#f5ba4d` } }, r2 = [{ type: `value`, boundaryGap: [0, `100%`], splitLine: { show: this.props.noToolbar || !!this.state.splitLine }, splitNumber: Math.round(this.state.chartHeight / 50), name: this.props.title || void 0, nameTextStyle: { align: `left` }, axisLabel: { formatter: (e3) => {
      let t3;
      return e3 = Math.round(e3 * 10) / 10, t3 = this.props.isFloatComma ? e3.toString().replace(`,`, `.`) + this.unit : e3 + this.unit, this.state.maxYLen < t3.length && (this.maxYLenTimeout && clearTimeout(this.maxYLenTimeout), this.maxYLenTimeout = setTimeout((e4) => this.setState({ maxYLen: e4 }), 200, t3.length)), t3;
    }, showMaxLabel: true, showMinLabel: true }, axisTick: { alignWithLabel: true } }], i2;
    if (this.props.obj2 && (i2 = { xAxisIndex: 0, type: `line`, yAxisIndex: 1, step: this.props.obj2LineType === `step` || !this.props.obj2LineType ? `start` : void 0, showSymbol: false, hoverAnimation: true, animation: false, data: this.convertData(null, this.props.obj2._id), areaStyle: { color: this.props.obj2BackgroundColor || `rgba(141,243,31,0.14)` }, lineStyle: { color: this.props.obj2Color || `#21b400` } }, r2.push({ type: `value`, alignTicks: true, boundaryGap: [0, `100%`], name: this.props.title2 || void 0, nameTextStyle: { align: `right` }, splitLine: { show: this.props.noToolbar || !!this.state.splitLine }, splitNumber: Math.round(this.state.chartHeight / 50), axisLabel: { formatter: (e3) => {
      let t3;
      return e3 = Math.round(e3 * 10) / 10, t3 = this.props.isFloatComma ? e3.toString().replace(`,`, `.`) + this.unit2 : e3 + this.unit2, this.state.maxYLen2 < t3.length && (this.maxYLenTimeout2 && clearTimeout(this.maxYLenTimeout2), this.maxYLenTimeout2 = setTimeout((e4) => this.setState({ maxYLen2: e4 }), 200, t3.length)), t3;
    }, showMaxLabel: true, showMinLabel: true }, axisTick: { alignWithLabel: true } })), ((_b = (_a2 = this.props.obj) == null ? void 0 : _a2.common) == null ? void 0 : _b.type) === `boolean`) n2.step = `end`, r2[0].axisLabel.showMaxLabel = false, r2[0].axisLabel.formatter = (e3) => e3 === 1 ? `TRUE` : `FALSE`, r2[0].max = 1.5, r2[0].interval = 1, e2 = 50;
    else if (((_d = (_c = this.props.obj) == null ? void 0 : _c.common) == null ? void 0 : _d.type) === `number` && this.props.obj.common.states) {
      n2.step = `end`, r2[0].axisLabel.showMaxLabel = false, r2[0].axisLabel.formatter = (e3) => this.props.obj.common.states[e3] === void 0 ? e3 : this.props.obj.common.states[e3];
      let t3 = Object.keys(this.props.obj.common.states);
      t3.sort(), r2[0].max = parseFloat(t3[t3.length - 1]) + 0.5, r2[0].interval = 1;
      let i3 = ``;
      for (let e3 = 0; e3 < t3.length; e3++) typeof this.props.obj.common.states[t3[e3]] == `string` && this.props.obj.common.states[t3[e3]].length > i3.length && (i3 = this.props.obj.common.states[t3[e3]]);
      e2 = (i3.length * 9 || 50) + 12;
    } else ((_f = (_e2 = this.props.obj) == null ? void 0 : _e2.common) == null ? void 0 : _f.type) === `number` && (this.props.obj.common.min !== void 0 && this.props.obj.common.max !== void 0 ? (r2[0].max = this.props.obj.common.max, r2[0].min = this.props.obj.common.min) : this.props.obj.common.unit === `%` && (r2[0].max = 100, r2[0].min = 0));
    if (((_h = (_g = this.props.obj2) == null ? void 0 : _g.common) == null ? void 0 : _h.type) === `boolean`) n2.step = `end`, r2[1].axisLabel.showMaxLabel = false, r2[1].axisLabel.formatter = (e3) => e3 === 1 ? `TRUE` : `FALSE`, r2[1].max = 1.5, r2[1].interval = 1, t2 = 50;
    else if (((_j = (_i2 = this.props.obj2) == null ? void 0 : _i2.common) == null ? void 0 : _j.type) === `number` && this.props.obj2.common.states) {
      n2.step = `end`, r2[1].axisLabel.showMaxLabel = false, r2[1].axisLabel.formatter = (e4) => this.props.obj2.common.states[e4] === void 0 ? e4 : this.props.obj2.common.states[e4];
      let e3 = Object.keys(this.props.obj2.common.states);
      e3.sort(), r2[1].max = parseFloat(e3[e3.length - 1]) + 0.5, r2[1].interval = 1;
      let i3 = ``;
      for (let t3 = 0; t3 < e3.length; t3++) typeof this.props.obj2.common.states[e3[t3]] == `string` && this.props.obj2.common.states[e3[t3]].length > i3.length && (i3 = this.props.obj2.common.states[e3[t3]]);
      t2 = (i3.length * 9 || 50) + 12;
    } else ((_l = (_k = this.props.obj2) == null ? void 0 : _k.common) == null ? void 0 : _l.type) === `number` && (this.props.obj2.common.min !== void 0 && this.props.obj2.common.max !== void 0 ? (r2[1].max = this.props.obj2.common.max, r2[1].min = this.props.obj2.common.min) : this.props.obj2.common.unit === `%` && (r2[1].max = 100, r2[1].min = 0));
    let a2 = this.chart.withSeconds ? Math.round((this.state.chartWidth - $ - Q) / 100) : Math.round((this.state.chartWidth - $ - Q) / 60);
    return { backgroundColor: `transparent`, title: { text: this.props.noToolbar ? `` : this.props.chartTitle === void 0 ? d.getObjectNameFromObj(this.props.obj, this.props.lang) : this.props.chartTitle, padding: [10, 0, 0, e2 ? e2 + 10 : 90] }, grid: { left: e2 || Q, top: r2[0].name || r2[1] && r2[1].name ? 38 : 8, right: t2 || (this.props.noToolbar ? 5 : $), bottom: 40 }, tooltip: { trigger: `axis`, formatter: (e3) => {
      let t3 = [], n3 = new Date(e3[0].value[0]), r3 = true;
      for (let n4 of e3) {
        let [, e4] = n4.value, i4 = e4;
        i4 != null && (i4 = Math.round(i4 * 1e3) / 1e3), i4 !== null && this.props.isFloatComma && (i4 = i4.toString().replace(`.`, `,`)), t3.push(`<div style="display: flex; gap: 4px; align-items: center">
<div style="border-radius: 15px;width: 15px;height: 15px;background-color: ${r3 ? this.props.objColor || `#f5ba4d` : this.props.obj2Color || `#21b400`};"></div>
<div>${r3 ? this.props.title : this.props.title2} -</div>
<div style="flex-grow: 1"></div>
<div>${n4.exact === false ? `i` : ``}${i4}${this.unit}</div>
</div>`), r3 = false;
      }
      let i3 = document.createElement(`div`);
      return i3.innerHTML = `<div>${n3.toLocaleString()}.${n3.getMilliseconds().toString().padStart(3, `0`)}</div>${t3.join(`
`)}`, i3;
    }, axisPointer: { animation: true } }, xAxis: { type: `time`, splitLine: { show: false }, splitNumber: a2, min: this.chart.min, max: this.chart.max, axisTick: { alignWithLabel: true }, axisLabel: { formatter: (e3) => {
      let t3 = new Date(e3);
      return this.chart.withSeconds ? `${t3.getHours().toString().padStart(2, `0`)}:${t3.getMinutes().toString().padStart(2, `0`)}:${t3.getSeconds().toString().padStart(2, `0`)}` : this.chart.withTime ? `${t3.getHours().toString().padStart(2, `0`)}:${t3.getMinutes().toString().padStart(2, `0`)}
${t3.getDate().toString().padStart(2, `0`)}.${(t3.getMonth() + 1).toString().padStart(2, `0`)}` : `${t3.getDate().toString().padStart(2, `0`)}.${(t3.getMonth() + 1).toString().padStart(2, `0`)}
${t3.getFullYear()}`;
    } } }, yAxis: r2, series: [n2, i2] };
  }
  static getDerivedStateFromProps() {
    return null;
  }
  updateChart(e2, t2, n2, r2) {
    e2 && (this.start = e2), t2 && (this.end = t2), e2 || (e2 = this.start), t2 || (t2 = this.end), this.readTimeout && clearTimeout(this.readTimeout), this.readTimeout = setTimeout(async () => {
      this.readTimeout = null;
      let i2 = this.chart.max - this.chart.min;
      if (i2 !== this.chart.diff && (this.chart.diff = i2, this.chart.withTime = this.chart.diff < 6048e5, this.chart.withSeconds = this.chart.diff < 18e5), n2 || !this.chartValues) {
        let n3 = await this.readHistory(e2, t2, this.props.obj._id), i3;
        this.props.obj2 && (i3 = await this.readHistory(e2, t2, this.props.obj2._id)), this.echartsReact && typeof this.echartsReact.getEchartsInstance == `function` && this.echartsReact.getEchartsInstance().setOption({ series: [{ data: this.convertData(n3, this.props.obj._id) }, this.props.obj2 ? { data: this.convertData(i3, this.props.obj2._id) } : void 0], xAxis: { min: this.chart.min, max: this.chart.max } }), r2 == null ? void 0 : r2();
      } else this.echartsReact && typeof this.echartsReact.getEchartsInstance == `function` && (this.echartsReact.getEchartsInstance().setOption({ series: [{ data: this.convertData(null, this.props.obj._id) }, this.props.obj2 ? { data: this.convertData(null, this.props.obj2._id) } : void 0], xAxis: { min: this.chart.min, max: this.chart.max } }), r2 == null ? void 0 : r2());
    }, this.chartValues ? 400 : 0);
  }
  setNewRange(e2) {
    this.chart.diff = this.chart.max - this.chart.min, this.chart.withTime = this.chart.diff < 6048e5, this.chart.withSeconds = this.chart.diff < 18e5, this.state.relativeRange === `absolute` ? this.echartsReact && typeof this.echartsReact.getEchartsInstance == `function` && (this.echartsReact.getEchartsInstance().setOption({ xAxis: { min: this.chart.min, max: this.chart.max } }), e2 && this.updateChart(this.chart.min, this.chart.max, true)) : (this.setState({ relativeRange: `absolute` }), this.timeTimer && clearTimeout(this.timeTimer), this.timeTimer = null);
  }
  shiftTime() {
    let e2 = /* @__PURE__ */ new Date(), t2 = 6e4 - e2.getSeconds() - (1e3 - e2.getMilliseconds());
    e2.getMilliseconds() && e2.setMilliseconds(1e3), e2.getSeconds() && e2.setSeconds(60);
    let n2 = e2.getTime(), r2, i2 = this.state.relativeRange;
    i2 === `day` ? (e2.setHours(0), e2.setMinutes(0), r2 = e2.getTime()) : i2 === `week` ? (e2.setHours(0), e2.setMinutes(0), e2.getDay() ? e2.setDate(e2.getDate() - e2.getDay() - 1) : e2.setDate(e2.getDate() - 6), r2 = e2.getTime()) : i2 === `2weeks` ? (e2.setHours(0), e2.setMinutes(0), e2.getDay() ? e2.setDate(e2.getDate() - e2.getDay() - 8) : e2.setDate(e2.getDate() - 13), r2 = e2.getTime()) : i2 === `month` ? (e2.setHours(0), e2.setMinutes(0), e2.setDate(1), r2 = e2.getTime()) : i2 === `year` ? (e2.setHours(0), e2.setMinutes(0), e2.setDate(1), e2.setMonth(0), r2 = e2.getTime()) : i2 === `12months` ? (e2.setHours(0), e2.setMinutes(0), e2.setFullYear(e2.getFullYear() - 1), r2 = e2.getTime()) : (i2 = parseInt(i2, 10), r2 = n2 - i2 * 6e4), this.chart.min = r2, this.chart.max = n2, this.setState({ max: n2 }, () => this.updateChart(this.chart.min, this.chart.max, true)), this.timeTimer = setTimeout(() => {
      this.timeTimer = null, this.shiftTime();
    }, t2 || 6e4);
  }
  setRelativeInterval(e2, t2, n2) {
    if (t2 || (window.localStorage.setItem(`App.relativeRange`, e2), this.setState({ relativeRange: e2 })), e2 === `absolute`) {
      this.timeTimer && clearTimeout(this.timeTimer), this.timeTimer = null, this.updateChart(this.chart.min, this.chart.max, true, n2);
      return;
    }
    window.localStorage.removeItem(`App.absoluteStart`), window.localStorage.removeItem(`App.absoluteEnd`);
    let r2 = /* @__PURE__ */ new Date();
    if (!this.timeTimer) {
      let e3 = 6e4 - r2.getSeconds() - (1e3 - r2.getMilliseconds());
      this.timeTimer = setTimeout(() => {
        this.timeTimer = null, this.shiftTime();
      }, e3 || 6e4);
    }
    r2.getMilliseconds() && r2.setMilliseconds(1e3), r2.getSeconds() && r2.setSeconds(60), this.chart.max = r2.getTime(), e2 === `day` ? (r2.setHours(0), r2.setMinutes(0), this.chart.min = r2.getTime()) : e2 === `week` ? (r2.setHours(0), r2.setMinutes(0), r2.getDay() ? r2.setDate(r2.getDate() - r2.getDay() - 1) : r2.setDate(r2.getDate() - 6), this.chart.min = r2.getTime()) : e2 === `2weeks` ? (r2.setHours(0), r2.setMinutes(0), r2.getDay() ? r2.setDate(r2.getDate() - r2.getDay() - 8) : r2.setDate(r2.getDate() - 13), this.chart.min = r2.getTime()) : e2 === `month` ? (r2.setHours(0), r2.setMinutes(0), r2.setDate(1), this.chart.min = r2.getTime()) : e2 === `year` ? (r2.setHours(0), r2.setMinutes(0), r2.setDate(1), r2.setMonth(0), this.chart.min = r2.getTime()) : e2 === `12months` ? (r2.setHours(0), r2.setMinutes(0), r2.setFullYear(r2.getFullYear() - 1), this.chart.min = r2.getTime()) : (e2 = parseInt(e2, 10), this.chart.min = this.chart.max - e2 * 6e4), this.setState({ max: this.chart.max }, () => this.updateChart(this.chart.min, this.chart.max, true, n2));
  }
  installEventHandlers() {
    if (!this.echartsReact || typeof this.echartsReact.getEchartsInstance != `function`) return;
    let e2 = this.echartsReact.getEchartsInstance().getZr();
    e2._iobInstalled || (e2._iobInstalled = true, e2.on(`mousedown`, (e3) => {
      console.log(`mouse down`), this.mouseDown = true, this.chart.lastX = e3.offsetX;
    }), e2.on(`mouseup`, () => {
      console.log(`mouse up`), this.mouseDown = false, this.setNewRange(true);
    }), e2.on(`mousewheel`, (e3) => {
      let t2 = this.chart.max - this.chart.min, n2 = this.state.chartWidth - $ - Q, r2 = (e3.offsetX - Q) / n2, i2 = t2, a2 = e3.wheelDelta > 0 ? 1.1 : 0.9;
      t2 *= a2;
      let o2 = i2 - t2;
      this.chart.max += o2 * (1 - r2), this.chart.min -= o2 * r2, this.setNewRange();
    }), e2.on(`mousemove`, (e3) => {
      if (this.mouseDown) {
        let t2 = this.chart.lastX - (e3.offsetX - Q);
        this.chart.lastX = e3.offsetX - Q;
        let n2 = this.chart.max - this.chart.min, r2 = this.state.chartWidth - $ - Q, i2 = Math.round(t2 * n2 / r2);
        this.chart.min += i2, this.chart.max += i2, this.setNewRange();
      }
    }), e2.on(`touchstart`, (e3) => {
      e3.preventDefault(), this.mouseDown = true;
      let t2 = e3.touches || e3.originalEvent.touches;
      t2 && (this.chart.lastX = t2[t2.length - 1].pageX, t2.length > 1 ? this.chart.lastWidth = Math.abs(t2[0].pageX - t2[1].pageX) : this.chart.lastWidth = null);
    }), e2.on(`touchend`, (e3) => {
      e3.preventDefault(), this.mouseDown = false, this.setNewRange(true);
    }), e2.on(`touchmove`, (e3) => {
      e3.preventDefault();
      let t2 = e3.touches || e3.originalEvent.touches;
      if (!t2) return;
      let n2 = t2[t2.length - 1].pageX - Q;
      if (this.mouseDown) {
        if (t2.length > 1) {
          let e4 = Math.abs(t2[0].pageX - t2[1].pageX);
          if (this.chart.lastWidth !== null && e4 !== this.chart.lastWidth) {
            let n3 = this.chart.max - this.chart.min, r2 = this.state.chartWidth - $ - Q, i2 = e4 > this.chart.lastWidth ? 1.1 : 0.9, a2 = (t2[0].pageX > t2[1].pageX ? t2[1].pageX - Q + e4 / 2 : t2[0].pageX - Q + e4 / 2) / r2, o2 = n3;
            n3 *= i2;
            let s2 = o2 - n3;
            this.chart.max += s2 * (1 - a2), this.chart.min -= s2 * a2, this.setNewRange();
          }
          this.chart.lastWidth = e4;
        } else {
          let e4 = this.chart.lastX - n2, t3 = this.chart.max - this.chart.min, r2 = this.state.chartWidth - $ - Q, i2 = Math.round(e4 * t3 / r2);
          this.chart.min += i2, this.chart.max += i2, this.setNewRange();
        }
      }
      this.chart.lastX = n2;
    }));
  }
  renderChart() {
    return this.chartValues && this.chartValues[this.props.obj._id] ? f(is.default, { ref: (e2) => {
      this.echartsReact = e2;
    }, echarts: ut, option: this.getOption(), notMerge: true, lazyUpdate: true, theme: this.props.themeType === `dark` ? `dark` : ``, style: { height: `${this.state.chartHeight}px`, width: `100%` }, opts: { renderer: `svg` }, onEvents: { rendered: () => this.installEventHandlers() } }) : f(o, {});
  }
  componentDidUpdate() {
    if (this.divRef.current) {
      let e2 = this.divRef.current.offsetWidth, t2 = this.divRef.current.offsetHeight;
      this.state.chartHeight !== t2 && setTimeout(() => this.setState({ chartHeight: t2, chartWidth: e2 }), 100);
    }
  }
  renderToolbar() {
    if (this.props.noToolbar) return null;
    let e2 = window.document.body.clientWidth > 600;
    return m(h, { style: { display: `flex`, justifyContent: `space-between` }, children: [m(i, { variant: `standard`, style: { minWidth: 200 }, children: [f(s, { children: this.props.t(`relative`) }), m(u, { variant: `standard`, ref: this.rangeRef, value: this.state.relativeRange, onChange: (e3) => this.setRelativeInterval(e3.target.value), children: [f(l, { value: `absolute`, sx: { color: `primary.main` }, children: this.props.t(`custom_range`) }), f(l, { value: 10, children: this.props.t(`last 10 minutes`) }), f(l, { value: 30, children: this.props.t(`last 30 minutes`) }), f(l, { value: 60, children: this.props.t(`last hour`) }), f(l, { value: `day`, children: this.props.t(`this day`) }), f(l, { value: 1440, children: this.props.t(`last 24 hours`) }), f(l, { value: `week`, children: this.props.t(`this week`) }), f(l, { value: 10080, children: this.props.t(`last week`) }), f(l, { value: `2weeks`, children: this.props.t(`this 2 weeks`) }), f(l, { value: 20160, children: this.props.t(`last 2 weeks`) }), f(l, { value: `month`, children: this.props.t(`this month`) }), f(l, { value: 43200, children: this.props.t(`last 30 days`) }), f(l, { value: `year`, children: this.props.t(`this year`) }), f(l, { value: `12months`, children: this.props.t(`last 12 months`) })] })] }), e2 ? m(g, { variant: `extended`, size: `small`, color: this.state.splitLine ? `primary` : void 0, "aria-label": `show lines`, onClick: () => {
      window.localStorage.setItem(`App.splitLine`, this.state.splitLine ? `false` : `true`), this.setState({ splitLine: !this.state.splitLine });
    }, children: [f(as, { style: { marginRight: 8 } }), this.props.t(`Show lines`)] }) : null] });
  }
  render() {
    return m(c, { style: { height: `100%`, maxHeight: `100%`, maxWidth: `100%`, overflow: `hidden`, width: `100%` }, children: [this.renderToolbar(), f(a, { component: `div`, ref: this.divRef, style: { width: `100%`, overflow: `hidden` }, sx: this.props.noToolbar ? os.chartWithoutToolbar : os.chartWithToolbar, children: this.renderChart() })] });
  }
}, cs = p()(ss);
export {
  Ea as a,
  Co as i,
  rs as n,
  ea as o,
  es as r,
  cs as t
};
