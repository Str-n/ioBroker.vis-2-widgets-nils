import { a as __toCommonJS, o as __toESM, t as __commonJSMin } from "./rolldown-runtime-C0FnF6B9.js";
import { B as init__virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare__react__loadShare__, F as __mf_37, I as __mf_38, k as __mf_28, z as _virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare__react__loadShare___exports } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { ft as __mf_1, pt as __mf_2, st as createSvgIcon } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
var Lock_default = createSvgIcon(__mf_1(`path`, { d: `M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2m-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2m3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1z` }), `Lock`), LockOpen_default = createSvgIcon(__mf_1(`path`, { d: `M12 17c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2m6-9h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6h1.9c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2m0 12H6V10h12z` }), `LockOpen`), MeetingRoom_default = createSvgIcon(__mf_1(`path`, { d: `M14 6v15H3v-2h2V3h9v1h5v15h2v2h-4V6zm-4 5v2h2v-2z` }), `MeetingRoom`), require_lottie = __commonJSMin(((exports, module) => {
  typeof document < `u` && typeof navigator < `u` && (function(e, t) {
    typeof exports == `object` && module !== void 0 ? module.exports = t() : typeof define == `function` && define.amd ? define(t) : (e = typeof globalThis < `u` ? globalThis : e || self, e.lottie = t());
  })(exports, (function() {
    var svgNS = `http://www.w3.org/2000/svg`, locationHref = ``, _useWebWorker = false, initialDefaultFrame = -999999, setWebWorker = function(e) {
      _useWebWorker = !!e;
    }, getWebWorker = function() {
      return _useWebWorker;
    }, setLocationHref = function(e) {
      locationHref = e;
    }, getLocationHref = function() {
      return locationHref;
    };
    function createTag(e) {
      return document.createElement(e);
    }
    function extendPrototype(e, t) {
      var n, r = e.length, i;
      for (n = 0; n < r; n += 1) for (var a in i = e[n].prototype, i) Object.prototype.hasOwnProperty.call(i, a) && (t.prototype[a] = i[a]);
    }
    function getDescriptor(e, t) {
      return Object.getOwnPropertyDescriptor(e, t);
    }
    function createProxyFunction(e) {
      function t() {
      }
      return t.prototype = e, t;
    }
    var audioControllerFactory = (function() {
      function e(e2) {
        this.audios = [], this.audioFactory = e2, this._volume = 1, this._isMuted = false;
      }
      return e.prototype = { addAudio: function(e2) {
        this.audios.push(e2);
      }, pause: function() {
        var e2, t = this.audios.length;
        for (e2 = 0; e2 < t; e2 += 1) this.audios[e2].pause();
      }, resume: function() {
        var e2, t = this.audios.length;
        for (e2 = 0; e2 < t; e2 += 1) this.audios[e2].resume();
      }, setRate: function(e2) {
        var t, n = this.audios.length;
        for (t = 0; t < n; t += 1) this.audios[t].setRate(e2);
      }, createAudio: function(e2) {
        return this.audioFactory ? this.audioFactory(e2) : window.Howl ? new window.Howl({ src: [e2] }) : { isPlaying: false, play: function() {
          this.isPlaying = true;
        }, seek: function() {
          this.isPlaying = false;
        }, playing: function() {
        }, rate: function() {
        }, setVolume: function() {
        } };
      }, setAudioFactory: function(e2) {
        this.audioFactory = e2;
      }, setVolume: function(e2) {
        this._volume = e2, this._updateVolume();
      }, mute: function() {
        this._isMuted = true, this._updateVolume();
      }, unmute: function() {
        this._isMuted = false, this._updateVolume();
      }, getVolume: function() {
        return this._volume;
      }, _updateVolume: function() {
        var e2, t = this.audios.length;
        for (e2 = 0; e2 < t; e2 += 1) this.audios[e2].volume(this._volume * +!this._isMuted);
      } }, function() {
        return new e();
      };
    })(), createTypedArray = /* @__PURE__ */ (function() {
      function e(e2, t2) {
        var n = 0, r = [], i;
        switch (e2) {
          case `int16`:
          case `uint8c`:
            i = 1;
            break;
          default:
            i = 1.1;
        }
        for (n = 0; n < t2; n += 1) r.push(i);
        return r;
      }
      function t(t2, n) {
        return t2 === `float32` ? new Float32Array(n) : t2 === `int16` ? new Int16Array(n) : t2 === `uint8c` ? new Uint8ClampedArray(n) : e(t2, n);
      }
      return typeof Uint8ClampedArray == `function` && typeof Float32Array == `function` ? t : e;
    })();
    function createSizedArray(e) {
      return Array.apply(null, { length: e });
    }
    function _typeof$6(e) {
      "@babel/helpers - typeof";
      return _typeof$6 = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e2) {
        return typeof e2;
      } : function(e2) {
        return e2 && typeof Symbol == `function` && e2.constructor === Symbol && e2 !== Symbol.prototype ? `symbol` : typeof e2;
      }, _typeof$6(e);
    }
    var subframeEnabled = true, expressionsPlugin = null, expressionsInterfaces = null, idPrefix$1 = ``, isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent), _shouldRoundValues = false, bmPow = Math.pow, bmSqrt = Math.sqrt, bmFloor = Math.floor, bmMax = Math.max, bmMin = Math.min, BMMath = {};
    (function() {
      var e = `abs.acos.acosh.asin.asinh.atan.atanh.atan2.ceil.cbrt.expm1.clz32.cos.cosh.exp.floor.fround.hypot.imul.log.log1p.log2.log10.max.min.pow.random.round.sign.sin.sinh.sqrt.tan.tanh.trunc.E.LN10.LN2.LOG10E.LOG2E.PI.SQRT1_2.SQRT2`.split(`.`), t, n = e.length;
      for (t = 0; t < n; t += 1) BMMath[e[t]] = Math[e[t]];
    })();
    function ProjectInterface$1() {
      return {};
    }
    BMMath.random = Math.random, BMMath.abs = function(e) {
      if (_typeof$6(e) === `object` && e.length) {
        var t = createSizedArray(e.length), n, r = e.length;
        for (n = 0; n < r; n += 1) t[n] = Math.abs(e[n]);
        return t;
      }
      return Math.abs(e);
    };
    var defaultCurveSegments = 150, degToRads = Math.PI / 180, roundCorner = 0.5519;
    function roundValues(e) {
      _shouldRoundValues = !!e;
    }
    function bmRnd(e) {
      return _shouldRoundValues ? Math.round(e) : e;
    }
    function styleDiv(e) {
      e.style.position = `absolute`, e.style.top = 0, e.style.left = 0, e.style.display = `block`, e.style.transformOrigin = `0 0`, e.style.webkitTransformOrigin = `0 0`, e.style.backfaceVisibility = `visible`, e.style.webkitBackfaceVisibility = `visible`, e.style.transformStyle = `preserve-3d`, e.style.webkitTransformStyle = `preserve-3d`, e.style.mozTransformStyle = `preserve-3d`;
    }
    function BMEnterFrameEvent(e, t, n, r) {
      this.type = e, this.currentTime = t, this.totalTime = n, this.direction = r < 0 ? -1 : 1;
    }
    function BMCompleteEvent(e, t) {
      this.type = e, this.direction = t < 0 ? -1 : 1;
    }
    function BMCompleteLoopEvent(e, t, n, r) {
      this.type = e, this.currentLoop = n, this.totalLoops = t, this.direction = r < 0 ? -1 : 1;
    }
    function BMSegmentStartEvent(e, t, n) {
      this.type = e, this.firstFrame = t, this.totalFrames = n;
    }
    function BMDestroyEvent(e, t) {
      this.type = e, this.target = t;
    }
    function BMRenderFrameErrorEvent(e, t) {
      this.type = `renderFrameError`, this.nativeError = e, this.currentTime = t;
    }
    function BMConfigErrorEvent(e) {
      this.type = `configError`, this.nativeError = e;
    }
    function BMAnimationConfigErrorEvent(e, t) {
      this.type = e, this.nativeError = t;
    }
    var createElementID = /* @__PURE__ */ (function() {
      var e = 0;
      return function() {
        return e += 1, idPrefix$1 + `__lottie_element_` + e;
      };
    })();
    function HSVtoRGB(e, t, n) {
      var r, i, a, o = Math.floor(e * 6), s = e * 6 - o, c = n * (1 - t), l = n * (1 - s * t), u = n * (1 - (1 - s) * t);
      switch (o % 6) {
        case 0:
          r = n, i = u, a = c;
          break;
        case 1:
          r = l, i = n, a = c;
          break;
        case 2:
          r = c, i = n, a = u;
          break;
        case 3:
          r = c, i = l, a = n;
          break;
        case 4:
          r = u, i = c, a = n;
          break;
        case 5:
          r = n, i = c, a = l;
      }
      return [r, i, a];
    }
    function RGBtoHSV(e, t, n) {
      var r = Math.max(e, t, n), i = Math.min(e, t, n), a = r - i, o, s = r === 0 ? 0 : a / r, c = r / 255;
      switch (r) {
        case i:
          o = 0;
          break;
        case e:
          o = t - n + a * (t < n ? 6 : 0), o /= 6 * a;
          break;
        case t:
          o = n - e + a * 2, o /= 6 * a;
          break;
        case n:
          o = e - t + a * 4, o /= 6 * a;
      }
      return [o, s, c];
    }
    function addSaturationToRGB(e, t) {
      var n = RGBtoHSV(e[0] * 255, e[1] * 255, e[2] * 255);
      return n[1] += t, n[1] > 1 ? n[1] = 1 : n[1] <= 0 && (n[1] = 0), HSVtoRGB(n[0], n[1], n[2]);
    }
    function addBrightnessToRGB(e, t) {
      var n = RGBtoHSV(e[0] * 255, e[1] * 255, e[2] * 255);
      return n[2] += t, n[2] > 1 ? n[2] = 1 : n[2] < 0 && (n[2] = 0), HSVtoRGB(n[0], n[1], n[2]);
    }
    function addHueToRGB(e, t) {
      var n = RGBtoHSV(e[0] * 255, e[1] * 255, e[2] * 255);
      return n[0] += t / 360, n[0] > 1 ? --n[0] : n[0] < 0 && (n[0] += 1), HSVtoRGB(n[0], n[1], n[2]);
    }
    var rgbToHex = (function() {
      for (var e = [], t = 0, n; t < 256; t += 1) n = t.toString(16), e[t] = n.length === 1 ? `0` + n : n;
      return function(t2, n2, r) {
        return t2 < 0 && (t2 = 0), n2 < 0 && (n2 = 0), r < 0 && (r = 0), `#` + e[t2] + e[n2] + e[r];
      };
    })(), setSubframeEnabled = function(e) {
      subframeEnabled = !!e;
    }, getSubframeEnabled = function() {
      return subframeEnabled;
    }, setExpressionsPlugin = function(e) {
      expressionsPlugin = e;
    }, getExpressionsPlugin = function() {
      return expressionsPlugin;
    }, setExpressionInterfaces = function(e) {
      expressionsInterfaces = e;
    }, getExpressionInterfaces = function() {
      return expressionsInterfaces;
    }, setDefaultCurveSegments = function(e) {
      defaultCurveSegments = e;
    }, getDefaultCurveSegments = function() {
      return defaultCurveSegments;
    }, setIdPrefix = function(e) {
      idPrefix$1 = e;
    }, getIdPrefix = function() {
      return idPrefix$1;
    };
    function createNS(e) {
      return document.createElementNS(svgNS, e);
    }
    function _typeof$5(e) {
      "@babel/helpers - typeof";
      return _typeof$5 = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e2) {
        return typeof e2;
      } : function(e2) {
        return e2 && typeof Symbol == `function` && e2.constructor === Symbol && e2 !== Symbol.prototype ? `symbol` : typeof e2;
      }, _typeof$5(e);
    }
    var dataManager = /* @__PURE__ */ (function() {
      var e = 1, t = [], n, r, i = { onmessage: function() {
      }, postMessage: function(e2) {
        n({ data: e2 });
      } }, a = { postMessage: function(e2) {
        i.onmessage({ data: e2 });
      } };
      function o(e2) {
        if (window.Worker && window.Blob && getWebWorker()) {
          var t2 = new Blob([`var _workerSelf = self; self.onmessage = `, e2.toString()], { type: `text/javascript` }), r2 = URL.createObjectURL(t2);
          return new Worker(r2);
        }
        return n = e2, i;
      }
      function s() {
        r || (r = o(function(e2) {
          function t2() {
            function e3(t4, n4) {
              var o3, s3, c3 = t4.length, l3, u3, d3, f2;
              for (s3 = 0; s3 < c3; s3 += 1) if (o3 = t4[s3], `ks` in o3 && !o3.completed) {
                if (o3.completed = true, o3.hasMask) {
                  var m2 = o3.masksProperties;
                  for (u3 = m2.length, l3 = 0; l3 < u3; l3 += 1) if (m2[l3].pt.k.i) a2(m2[l3].pt.k);
                  else for (f2 = m2[l3].pt.k.length, d3 = 0; d3 < f2; d3 += 1) m2[l3].pt.k[d3].s && a2(m2[l3].pt.k[d3].s[0]), m2[l3].pt.k[d3].e && a2(m2[l3].pt.k[d3].e[0]);
                }
                o3.ty === 0 ? (o3.layers = r2(o3.refId, n4), e3(o3.layers, n4)) : o3.ty === 4 ? i2(o3.shapes) : o3.ty === 5 && p(o3);
              }
            }
            function t3(t4, n4) {
              if (t4) {
                var i3 = 0, a3 = t4.length;
                for (i3 = 0; i3 < a3; i3 += 1) t4[i3].t === 1 && (t4[i3].data.layers = r2(t4[i3].data.refId, n4), e3(t4[i3].data.layers, n4));
              }
            }
            function n3(e4, t4) {
              for (var n4 = 0, r3 = t4.length; n4 < r3; ) {
                if (t4[n4].id === e4) return t4[n4];
                n4 += 1;
              }
              return null;
            }
            function r2(e4, t4) {
              var r3 = n3(e4, t4);
              return r3 ? r3.layers.__used ? JSON.parse(JSON.stringify(r3.layers)) : (r3.layers.__used = true, r3.layers) : null;
            }
            function i2(e4) {
              var t4, n4 = e4.length, r3, o3;
              for (t4 = n4 - 1; t4 >= 0; --t4) if (e4[t4].ty === `sh`) {
                if (e4[t4].ks.k.i) a2(e4[t4].ks.k);
                else for (o3 = e4[t4].ks.k.length, r3 = 0; r3 < o3; r3 += 1) e4[t4].ks.k[r3].s && a2(e4[t4].ks.k[r3].s[0]), e4[t4].ks.k[r3].e && a2(e4[t4].ks.k[r3].e[0]);
              } else e4[t4].ty === `gr` && i2(e4[t4].it);
            }
            function a2(e4) {
              var t4, n4 = e4.i.length;
              for (t4 = 0; t4 < n4; t4 += 1) e4.i[t4][0] += e4.v[t4][0], e4.i[t4][1] += e4.v[t4][1], e4.o[t4][0] += e4.v[t4][0], e4.o[t4][1] += e4.v[t4][1];
            }
            function o2(e4, t4) {
              var n4 = t4 ? t4.split(`.`) : [100, 100, 100];
              return e4[0] > n4[0] ? true : n4[0] > e4[0] ? false : e4[1] > n4[1] ? true : n4[1] > e4[1] ? false : e4[2] > n4[2] ? true : n4[2] > e4[2] ? false : null;
            }
            var s2 = /* @__PURE__ */ (function() {
              var e4 = [4, 4, 14];
              function t4(e5) {
                var t5 = e5.t.d;
                e5.t.d = { k: [{ s: t5, t: 0 }] };
              }
              function n4(e5) {
                var n5, r3 = e5.length;
                for (n5 = 0; n5 < r3; n5 += 1) e5[n5].ty === 5 && t4(e5[n5]);
              }
              return function(t5) {
                if (o2(e4, t5.v) && (n4(t5.layers), t5.assets)) {
                  var r3, i3 = t5.assets.length;
                  for (r3 = 0; r3 < i3; r3 += 1) t5.assets[r3].layers && n4(t5.assets[r3].layers);
                }
              };
            })(), c2 = /* @__PURE__ */ (function() {
              var e4 = [4, 7, 99];
              return function(t4) {
                if (t4.chars && !o2(e4, t4.v)) {
                  var n4, r3 = t4.chars.length;
                  for (n4 = 0; n4 < r3; n4 += 1) {
                    var a3 = t4.chars[n4];
                    a3.data && a3.data.shapes && (i2(a3.data.shapes), a3.data.ip = 0, a3.data.op = 99999, a3.data.st = 0, a3.data.sr = 1, a3.data.ks = { p: { k: [0, 0], a: 0 }, s: { k: [100, 100], a: 0 }, a: { k: [0, 0], a: 0 }, r: { k: 0, a: 0 }, o: { k: 100, a: 0 } }, t4.chars[n4].t || (a3.data.shapes.push({ ty: `no` }), a3.data.shapes[0].it.push({ p: { k: [0, 0], a: 0 }, s: { k: [100, 100], a: 0 }, a: { k: [0, 0], a: 0 }, r: { k: 0, a: 0 }, o: { k: 100, a: 0 }, sk: { k: 0, a: 0 }, sa: { k: 0, a: 0 }, ty: `tr` })));
                  }
                }
              };
            })(), l2 = /* @__PURE__ */ (function() {
              var e4 = [5, 7, 15];
              function t4(e5) {
                var t5 = e5.t.p;
                typeof t5.a == `number` && (t5.a = { a: 0, k: t5.a }), typeof t5.p == `number` && (t5.p = { a: 0, k: t5.p }), typeof t5.r == `number` && (t5.r = { a: 0, k: t5.r });
              }
              function n4(e5) {
                var n5, r3 = e5.length;
                for (n5 = 0; n5 < r3; n5 += 1) e5[n5].ty === 5 && t4(e5[n5]);
              }
              return function(t5) {
                if (o2(e4, t5.v) && (n4(t5.layers), t5.assets)) {
                  var r3, i3 = t5.assets.length;
                  for (r3 = 0; r3 < i3; r3 += 1) t5.assets[r3].layers && n4(t5.assets[r3].layers);
                }
              };
            })(), u2 = /* @__PURE__ */ (function() {
              var e4 = [4, 1, 9];
              function t4(e5) {
                var n5, r3 = e5.length, i3, a3;
                for (n5 = 0; n5 < r3; n5 += 1) if (e5[n5].ty === `gr`) t4(e5[n5].it);
                else if (e5[n5].ty === `fl` || e5[n5].ty === `st`) {
                  if (e5[n5].c.k && e5[n5].c.k[0].i) for (a3 = e5[n5].c.k.length, i3 = 0; i3 < a3; i3 += 1) e5[n5].c.k[i3].s && (e5[n5].c.k[i3].s[0] /= 255, e5[n5].c.k[i3].s[1] /= 255, e5[n5].c.k[i3].s[2] /= 255, e5[n5].c.k[i3].s[3] /= 255), e5[n5].c.k[i3].e && (e5[n5].c.k[i3].e[0] /= 255, e5[n5].c.k[i3].e[1] /= 255, e5[n5].c.k[i3].e[2] /= 255, e5[n5].c.k[i3].e[3] /= 255);
                  else e5[n5].c.k[0] /= 255, e5[n5].c.k[1] /= 255, e5[n5].c.k[2] /= 255, e5[n5].c.k[3] /= 255;
                }
              }
              function n4(e5) {
                var n5, r3 = e5.length;
                for (n5 = 0; n5 < r3; n5 += 1) e5[n5].ty === 4 && t4(e5[n5].shapes);
              }
              return function(t5) {
                if (o2(e4, t5.v) && (n4(t5.layers), t5.assets)) {
                  var r3, i3 = t5.assets.length;
                  for (r3 = 0; r3 < i3; r3 += 1) t5.assets[r3].layers && n4(t5.assets[r3].layers);
                }
              };
            })(), d2 = /* @__PURE__ */ (function() {
              var e4 = [4, 4, 18];
              function t4(e5) {
                var n5, r3 = e5.length, i3, a3;
                for (n5 = r3 - 1; n5 >= 0; --n5) if (e5[n5].ty === `sh`) {
                  if (e5[n5].ks.k.i) e5[n5].ks.k.c = e5[n5].closed;
                  else for (a3 = e5[n5].ks.k.length, i3 = 0; i3 < a3; i3 += 1) e5[n5].ks.k[i3].s && (e5[n5].ks.k[i3].s[0].c = e5[n5].closed), e5[n5].ks.k[i3].e && (e5[n5].ks.k[i3].e[0].c = e5[n5].closed);
                } else e5[n5].ty === `gr` && t4(e5[n5].it);
              }
              function n4(e5) {
                var n5, r3, i3 = e5.length, a3, o3, s3, c3;
                for (r3 = 0; r3 < i3; r3 += 1) {
                  if (n5 = e5[r3], n5.hasMask) {
                    var l3 = n5.masksProperties;
                    for (o3 = l3.length, a3 = 0; a3 < o3; a3 += 1) if (l3[a3].pt.k.i) l3[a3].pt.k.c = l3[a3].cl;
                    else for (c3 = l3[a3].pt.k.length, s3 = 0; s3 < c3; s3 += 1) l3[a3].pt.k[s3].s && (l3[a3].pt.k[s3].s[0].c = l3[a3].cl), l3[a3].pt.k[s3].e && (l3[a3].pt.k[s3].e[0].c = l3[a3].cl);
                  }
                  n5.ty === 4 && t4(n5.shapes);
                }
              }
              return function(t5) {
                if (o2(e4, t5.v) && (n4(t5.layers), t5.assets)) {
                  var r3, i3 = t5.assets.length;
                  for (r3 = 0; r3 < i3; r3 += 1) t5.assets[r3].layers && n4(t5.assets[r3].layers);
                }
              };
            })();
            function f(n4) {
              n4.__complete || (n4.__complete = (u2(n4), s2(n4), c2(n4), l2(n4), d2(n4), e3(n4.layers, n4.assets), t3(n4.chars, n4.assets), true));
            }
            function p(e4) {
              e4.t.a.length === 0 && `m` in e4.t.p;
            }
            var m = {};
            return m.completeData = f, m.checkColors = u2, m.checkChars = c2, m.checkPathProperties = l2, m.checkShapes = d2, m.completeLayers = e3, m;
          }
          if (a.dataManager || (a.dataManager = t2()), a.assetLoader || (a.assetLoader = /* @__PURE__ */ (function() {
            function e3(e4) {
              var t4 = e4.getResponseHeader(`content-type`);
              return t4 && e4.responseType === `json` && t4.indexOf(`json`) !== -1 || e4.response && _typeof$5(e4.response) === `object` ? e4.response : e4.response && typeof e4.response == `string` ? JSON.parse(e4.response) : e4.responseText ? JSON.parse(e4.responseText) : null;
            }
            function t3(t4, n3, r2, i2) {
              var a2, o2 = new XMLHttpRequest();
              try {
                o2.responseType = `json`;
              } catch {
              }
              o2.onreadystatechange = function() {
                if (o2.readyState === 4) {
                  if (o2.status === 200) a2 = e3(o2), r2(a2);
                  else try {
                    a2 = e3(o2), r2(a2);
                  } catch (e4) {
                    i2 && i2(e4);
                  }
                }
              };
              try {
                o2.open([`G`, `E`, `T`].join(``), t4, true);
              } catch {
                o2.open([`G`, `E`, `T`].join(``), n3 + `/` + t4, true);
              }
              o2.send();
            }
            return { load: t3 };
          })()), e2.data.type === `loadAnimation`) a.assetLoader.load(e2.data.path, e2.data.fullPath, function(t3) {
            a.dataManager.completeData(t3), a.postMessage({ id: e2.data.id, payload: t3, status: `success` });
          }, function() {
            a.postMessage({ id: e2.data.id, status: `error` });
          });
          else if (e2.data.type === `complete`) {
            var n2 = e2.data.animation;
            a.dataManager.completeData(n2), a.postMessage({ id: e2.data.id, payload: n2, status: `success` });
          } else e2.data.type === `loadData` && a.assetLoader.load(e2.data.path, e2.data.fullPath, function(t3) {
            a.postMessage({ id: e2.data.id, payload: t3, status: `success` });
          }, function() {
            a.postMessage({ id: e2.data.id, status: `error` });
          });
        }), r.onmessage = function(e2) {
          var n2 = e2.data, r2 = n2.id, i2 = t[r2];
          t[r2] = null, n2.status === `success` ? i2.onComplete(n2.payload) : i2.onError && i2.onError();
        });
      }
      function c(n2, r2) {
        e += 1;
        var i2 = `processId_` + e;
        return t[i2] = { onComplete: n2, onError: r2 }, i2;
      }
      function l(e2, t2, n2) {
        s();
        var i2 = c(t2, n2);
        r.postMessage({ type: `loadAnimation`, path: e2, fullPath: window.location.origin + window.location.pathname, id: i2 });
      }
      function u(e2, t2, n2) {
        s();
        var i2 = c(t2, n2);
        r.postMessage({ type: `loadData`, path: e2, fullPath: window.location.origin + window.location.pathname, id: i2 });
      }
      function d(e2, t2, n2) {
        s();
        var i2 = c(t2, n2);
        r.postMessage({ type: `complete`, animation: e2, id: i2 });
      }
      return { loadAnimation: l, loadData: u, completeAnimation: d };
    })(), ImagePreloader = (function() {
      var e = (function() {
        var e2 = createTag(`canvas`);
        e2.width = 1, e2.height = 1;
        var t2 = e2.getContext(`2d`);
        return t2.fillStyle = `rgba(0,0,0,0)`, t2.fillRect(0, 0, 1, 1), e2;
      })();
      function t() {
        this.loadedAssets += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null);
      }
      function n() {
        this.loadedFootagesCount += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null);
      }
      function r(e2, t2, n2) {
        var r2 = ``;
        if (e2.e) r2 = e2.p;
        else if (t2) {
          var i2 = e2.p;
          i2.indexOf(`images/`) !== -1 && (i2 = i2.split(`/`)[1]), r2 = t2 + i2;
        } else r2 = n2, r2 += e2.u ? e2.u : ``, r2 += e2.p;
        return r2;
      }
      function i(e2) {
        var t2 = 0, n2 = setInterval(function() {
          (e2.getBBox().width || t2 > 500) && (this._imageLoaded(), clearInterval(n2)), t2 += 1;
        }.bind(this), 50);
      }
      function a(t2) {
        var n2 = r(t2, this.assetsPath, this.path), i2 = createNS(`image`);
        isSafari ? this.testImageLoaded(i2) : i2.addEventListener(`load`, this._imageLoaded, false), i2.addEventListener(`error`, function() {
          a2.img = e, this._imageLoaded();
        }.bind(this), false), i2.setAttributeNS(`http://www.w3.org/1999/xlink`, `href`, n2), this._elementHelper.append ? this._elementHelper.append(i2) : this._elementHelper.appendChild(i2);
        var a2 = { img: i2, assetData: t2 };
        return a2;
      }
      function o(t2) {
        var n2 = r(t2, this.assetsPath, this.path), i2 = createTag(`img`);
        i2.crossOrigin = `anonymous`, i2.addEventListener(`load`, this._imageLoaded, false), i2.addEventListener(`error`, function() {
          a2.img = e, this._imageLoaded();
        }.bind(this), false), i2.src = n2;
        var a2 = { img: i2, assetData: t2 };
        return a2;
      }
      function s(e2) {
        var t2 = { assetData: e2 }, n2 = r(e2, this.assetsPath, this.path);
        return dataManager.loadData(n2, function(e3) {
          t2.img = e3, this._footageLoaded();
        }.bind(this), function() {
          t2.img = {}, this._footageLoaded();
        }.bind(this)), t2;
      }
      function c(e2, t2) {
        this.imagesLoadedCb = t2;
        var n2, r2 = e2.length;
        for (n2 = 0; n2 < r2; n2 += 1) e2[n2].layers || (!e2[n2].t || e2[n2].t === `seq` ? (this.totalImages += 1, this.images.push(this._createImageData(e2[n2]))) : e2[n2].t === 3 && (this.totalFootages += 1, this.images.push(this.createFootageData(e2[n2]))));
      }
      function l(e2) {
        this.path = e2 || ``;
      }
      function u(e2) {
        this.assetsPath = e2 || ``;
      }
      function d(e2) {
        for (var t2 = 0, n2 = this.images.length; t2 < n2; ) {
          if (this.images[t2].assetData === e2) return this.images[t2].img;
          t2 += 1;
        }
        return null;
      }
      function f() {
        this.imagesLoadedCb = null, this.images.length = 0;
      }
      function p() {
        return this.totalImages === this.loadedAssets;
      }
      function m() {
        return this.totalFootages === this.loadedFootagesCount;
      }
      function g(e2, t2) {
        e2 === `svg` ? (this._elementHelper = t2, this._createImageData = this.createImageData.bind(this)) : this._createImageData = this.createImgData.bind(this);
      }
      function _() {
        this._imageLoaded = t.bind(this), this._footageLoaded = n.bind(this), this.testImageLoaded = i.bind(this), this.createFootageData = s.bind(this), this.assetsPath = ``, this.path = ``, this.totalImages = 0, this.totalFootages = 0, this.loadedAssets = 0, this.loadedFootagesCount = 0, this.imagesLoadedCb = null, this.images = [];
      }
      return _.prototype = { loadAssets: c, setAssetsPath: u, setPath: l, loadedImages: p, loadedFootages: m, destroy: f, getAsset: d, createImgData: o, createImageData: a, imageLoaded: t, footageLoaded: n, setCacheType: g }, _;
    })();
    function BaseEvent() {
    }
    BaseEvent.prototype = { triggerEvent: function(e, t) {
      if (this._cbs[e]) for (var n = this._cbs[e], r = 0; r < n.length; r += 1) n[r](t);
    }, addEventListener: function(e, t) {
      return this._cbs[e] || (this._cbs[e] = []), this._cbs[e].push(t), function() {
        this.removeEventListener(e, t);
      }.bind(this);
    }, removeEventListener: function(e, t) {
      if (!t) this._cbs[e] = null;
      else if (this._cbs[e]) {
        for (var n = 0, r = this._cbs[e].length; n < r; ) this._cbs[e][n] === t && (this._cbs[e].splice(n, 1), --n, --r), n += 1;
        this._cbs[e].length || (this._cbs[e] = null);
      }
    } };
    var markerParser = /* @__PURE__ */ (function() {
      function e(e2) {
        for (var t = e2.split(`\r
`), n = {}, r, i = 0, a = 0; a < t.length; a += 1) r = t[a].split(`:`), r.length === 2 && (n[r[0]] = r[1].trim(), i += 1);
        if (i === 0) throw Error();
        return n;
      }
      return function(t) {
        for (var n = [], r = 0; r < t.length; r += 1) {
          var i = t[r], a = { time: i.tm, duration: i.dr };
          try {
            a.payload = JSON.parse(t[r].cm);
          } catch {
            try {
              a.payload = e(t[r].cm);
            } catch {
              a.payload = { name: t[r].cm };
            }
          }
          n.push(a);
        }
        return n;
      };
    })(), ProjectInterface = /* @__PURE__ */ (function() {
      function e(e2) {
        this.compositions.push(e2);
      }
      return function() {
        function t(e2) {
          for (var t2 = 0, n = this.compositions.length; t2 < n; ) {
            if (this.compositions[t2].data && this.compositions[t2].data.nm === e2) return this.compositions[t2].prepareFrame && this.compositions[t2].data.xt && this.compositions[t2].prepareFrame(this.currentFrame), this.compositions[t2].compInterface;
            t2 += 1;
          }
          return null;
        }
        return t.compositions = [], t.currentFrame = 0, t.registerComposition = e, t;
      };
    })(), renderers = {}, registerRenderer = function(e, t) {
      renderers[e] = t;
    };
    function getRenderer(e) {
      return renderers[e];
    }
    function getRegisteredRenderer() {
      if (renderers.canvas) return `canvas`;
      for (var e in renderers) if (renderers[e]) return e;
      return ``;
    }
    function _typeof$4(e) {
      "@babel/helpers - typeof";
      return _typeof$4 = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e2) {
        return typeof e2;
      } : function(e2) {
        return e2 && typeof Symbol == `function` && e2.constructor === Symbol && e2 !== Symbol.prototype ? `symbol` : typeof e2;
      }, _typeof$4(e);
    }
    var AnimationItem = function() {
      this._cbs = [], this.name = ``, this.path = ``, this.isLoaded = false, this.currentFrame = 0, this.currentRawFrame = 0, this.firstFrame = 0, this.totalFrames = 0, this.frameRate = 0, this.frameMult = 0, this.playSpeed = 1, this.playDirection = 1, this.playCount = 0, this.animationData = {}, this.assets = [], this.isPaused = true, this.autoplay = false, this.loop = true, this.renderer = null, this.animationID = createElementID(), this.assetsPath = ``, this.timeCompleted = 0, this.segmentPos = 0, this.isSubframeEnabled = getSubframeEnabled(), this.segments = [], this._idle = true, this._completedLoop = false, this.projectInterface = ProjectInterface(), this.imagePreloader = new ImagePreloader(), this.audioController = audioControllerFactory(), this.markers = [], this.configAnimation = this.configAnimation.bind(this), this.onSetupError = this.onSetupError.bind(this), this.onSegmentComplete = this.onSegmentComplete.bind(this), this.drawnFrameEvent = new BMEnterFrameEvent(`drawnFrame`, 0, 0, 0), this.expressionsPlugin = getExpressionsPlugin();
    };
    extendPrototype([BaseEvent], AnimationItem), AnimationItem.prototype.setParams = function(e) {
      (e.wrapper || e.container) && (this.wrapper = e.wrapper || e.container);
      var t = `svg`;
      e.animType ? t = e.animType : e.renderer && (t = e.renderer);
      var n = getRenderer(t);
      this.renderer = new n(this, e.rendererSettings), this.imagePreloader.setCacheType(t, this.renderer.globalData.defs), this.renderer.setProjectInterface(this.projectInterface), this.animType = t, this.loop = e.loop === `` || e.loop === null || e.loop === void 0 || e.loop === true || e.loop !== false && parseInt(e.loop, 10), this.autoplay = `autoplay` in e ? e.autoplay : true, this.name = e.name ? e.name : ``, this.autoloadSegments = !Object.prototype.hasOwnProperty.call(e, `autoloadSegments`) || e.autoloadSegments, this.assetsPath = e.assetsPath, this.initialSegment = e.initialSegment, e.audioFactory && this.audioController.setAudioFactory(e.audioFactory), e.animationData ? this.setupAnimation(e.animationData) : e.path && (this.path = e.path.lastIndexOf(`\\`) === -1 ? e.path.substr(0, e.path.lastIndexOf(`/`) + 1) : e.path.substr(0, e.path.lastIndexOf(`\\`) + 1), this.fileName = e.path.substr(e.path.lastIndexOf(`/`) + 1), this.fileName = this.fileName.substr(0, this.fileName.lastIndexOf(`.json`)), dataManager.loadAnimation(e.path, this.configAnimation, this.onSetupError));
    }, AnimationItem.prototype.onSetupError = function() {
      this.trigger(`data_failed`);
    }, AnimationItem.prototype.setupAnimation = function(e) {
      dataManager.completeAnimation(e, this.configAnimation);
    }, AnimationItem.prototype.setData = function(e, t) {
      t && _typeof$4(t) !== `object` && (t = JSON.parse(t));
      var n = { wrapper: e, animationData: t }, r = e.attributes;
      n.path = r.getNamedItem(`data-animation-path`) ? r.getNamedItem(`data-animation-path`).value : r.getNamedItem(`data-bm-path`) ? r.getNamedItem(`data-bm-path`).value : r.getNamedItem(`bm-path`) ? r.getNamedItem(`bm-path`).value : ``, n.animType = r.getNamedItem(`data-anim-type`) ? r.getNamedItem(`data-anim-type`).value : r.getNamedItem(`data-bm-type`) ? r.getNamedItem(`data-bm-type`).value : r.getNamedItem(`bm-type`) ? r.getNamedItem(`bm-type`).value : r.getNamedItem(`data-bm-renderer`) ? r.getNamedItem(`data-bm-renderer`).value : r.getNamedItem(`bm-renderer`) ? r.getNamedItem(`bm-renderer`).value : getRegisteredRenderer() || `canvas`;
      var i = r.getNamedItem(`data-anim-loop`) ? r.getNamedItem(`data-anim-loop`).value : r.getNamedItem(`data-bm-loop`) ? r.getNamedItem(`data-bm-loop`).value : r.getNamedItem(`bm-loop`) ? r.getNamedItem(`bm-loop`).value : ``;
      i === `false` ? n.loop = false : i === `true` ? n.loop = true : i !== `` && (n.loop = parseInt(i, 10)), n.autoplay = (r.getNamedItem(`data-anim-autoplay`) ? r.getNamedItem(`data-anim-autoplay`).value : r.getNamedItem(`data-bm-autoplay`) ? r.getNamedItem(`data-bm-autoplay`).value : !r.getNamedItem(`bm-autoplay`) || r.getNamedItem(`bm-autoplay`).value) !== `false`, n.name = r.getNamedItem(`data-name`) ? r.getNamedItem(`data-name`).value : r.getNamedItem(`data-bm-name`) ? r.getNamedItem(`data-bm-name`).value : r.getNamedItem(`bm-name`) ? r.getNamedItem(`bm-name`).value : ``, (r.getNamedItem(`data-anim-prerender`) ? r.getNamedItem(`data-anim-prerender`).value : r.getNamedItem(`data-bm-prerender`) ? r.getNamedItem(`data-bm-prerender`).value : r.getNamedItem(`bm-prerender`) ? r.getNamedItem(`bm-prerender`).value : ``) === `false` && (n.prerender = false), n.path ? this.setParams(n) : this.trigger(`destroy`);
    }, AnimationItem.prototype.includeLayers = function(e) {
      e.op > this.animationData.op && (this.animationData.op = e.op, this.totalFrames = Math.floor(e.op - this.animationData.ip));
      var t = this.animationData.layers, n, r = t.length, i = e.layers, a, o = i.length;
      for (a = 0; a < o; a += 1) for (n = 0; n < r; ) {
        if (t[n].id === i[a].id) {
          t[n] = i[a];
          break;
        }
        n += 1;
      }
      if ((e.chars || e.fonts) && (this.renderer.globalData.fontManager.addChars(e.chars), this.renderer.globalData.fontManager.addFonts(e.fonts, this.renderer.globalData.defs)), e.assets) for (r = e.assets.length, n = 0; n < r; n += 1) this.animationData.assets.push(e.assets[n]);
      this.animationData.__complete = false, dataManager.completeAnimation(this.animationData, this.onSegmentComplete);
    }, AnimationItem.prototype.onSegmentComplete = function(e) {
      this.animationData = e;
      var t = getExpressionsPlugin();
      t && t.initExpressions(this), this.loadNextSegment();
    }, AnimationItem.prototype.loadNextSegment = function() {
      var e = this.animationData.segments;
      if (!e || e.length === 0 || !this.autoloadSegments) {
        this.trigger(`data_ready`), this.timeCompleted = this.totalFrames;
        return;
      }
      var t = e.shift();
      this.timeCompleted = t.time * this.frameRate;
      var n = this.path + this.fileName + `_` + this.segmentPos + `.json`;
      this.segmentPos += 1, dataManager.loadData(n, this.includeLayers.bind(this), function() {
        this.trigger(`data_failed`);
      }.bind(this));
    }, AnimationItem.prototype.loadSegments = function() {
      this.animationData.segments || (this.timeCompleted = this.totalFrames), this.loadNextSegment();
    }, AnimationItem.prototype.imagesLoaded = function() {
      this.trigger(`loaded_images`), this.checkLoaded();
    }, AnimationItem.prototype.preloadImages = function() {
      this.imagePreloader.setAssetsPath(this.assetsPath), this.imagePreloader.setPath(this.path), this.imagePreloader.loadAssets(this.animationData.assets, this.imagesLoaded.bind(this));
    }, AnimationItem.prototype.configAnimation = function(e) {
      if (this.renderer) try {
        this.animationData = e, this.initialSegment ? (this.totalFrames = Math.floor(this.initialSegment[1] - this.initialSegment[0]), this.firstFrame = Math.round(this.initialSegment[0])) : (this.totalFrames = Math.floor(this.animationData.op - this.animationData.ip), this.firstFrame = Math.round(this.animationData.ip)), this.renderer.configAnimation(e), e.assets || (e.assets = []), this.assets = this.animationData.assets, this.frameRate = this.animationData.fr, this.frameMult = this.animationData.fr / 1e3, this.renderer.searchExtraCompositions(e.assets), this.markers = markerParser(e.markers || []), this.trigger(`config_ready`), this.preloadImages(), this.loadSegments(), this.updaFrameModifier(), this.waitForFontsLoaded(), this.isPaused && this.audioController.pause();
      } catch (e2) {
        this.triggerConfigError(e2);
      }
    }, AnimationItem.prototype.waitForFontsLoaded = function() {
      this.renderer && (this.renderer.globalData.fontManager.isLoaded ? this.checkLoaded() : setTimeout(this.waitForFontsLoaded.bind(this), 20));
    }, AnimationItem.prototype.checkLoaded = function() {
      if (!this.isLoaded && this.renderer.globalData.fontManager.isLoaded && (this.imagePreloader.loadedImages() || this.renderer.rendererType !== `canvas`) && this.imagePreloader.loadedFootages()) {
        this.isLoaded = true;
        var e = getExpressionsPlugin();
        e && e.initExpressions(this), this.renderer.initItems(), setTimeout(function() {
          this.trigger(`DOMLoaded`);
        }.bind(this), 0), this.gotoFrame(), this.autoplay && this.play();
      }
    }, AnimationItem.prototype.resize = function(e, t) {
      var n = typeof e == `number` ? e : void 0, r = typeof t == `number` ? t : void 0;
      this.renderer.updateContainerSize(n, r);
    }, AnimationItem.prototype.setSubframe = function(e) {
      this.isSubframeEnabled = !!e;
    }, AnimationItem.prototype.gotoFrame = function() {
      this.currentFrame = this.isSubframeEnabled ? this.currentRawFrame : ~~this.currentRawFrame, this.timeCompleted !== this.totalFrames && this.currentFrame > this.timeCompleted && (this.currentFrame = this.timeCompleted), this.trigger(`enterFrame`), this.renderFrame(), this.trigger(`drawnFrame`);
    }, AnimationItem.prototype.renderFrame = function() {
      if (this.isLoaded !== false && this.renderer) try {
        this.expressionsPlugin && this.expressionsPlugin.resetFrame(), this.renderer.renderFrame(this.currentFrame + this.firstFrame);
      } catch (e) {
        this.triggerRenderFrameError(e);
      }
    }, AnimationItem.prototype.play = function(e) {
      e && this.name !== e || this.isPaused === true && (this.isPaused = false, this.trigger(`_play`), this.audioController.resume(), this._idle && (this._idle = false, this.trigger(`_active`)));
    }, AnimationItem.prototype.pause = function(e) {
      e && this.name !== e || this.isPaused === false && (this.isPaused = true, this.trigger(`_pause`), this._idle = true, this.trigger(`_idle`), this.audioController.pause());
    }, AnimationItem.prototype.togglePause = function(e) {
      e && this.name !== e || (this.isPaused === true ? this.play() : this.pause());
    }, AnimationItem.prototype.stop = function(e) {
      e && this.name !== e || (this.pause(), this.playCount = 0, this._completedLoop = false, this.setCurrentRawFrameValue(0));
    }, AnimationItem.prototype.getMarkerData = function(e) {
      for (var t, n = 0; n < this.markers.length; n += 1) if (t = this.markers[n], t.payload && t.payload.name === e) return t;
      return null;
    }, AnimationItem.prototype.goToAndStop = function(e, t, n) {
      if (!(n && this.name !== n)) {
        var r = Number(e);
        if (isNaN(r)) {
          var i = this.getMarkerData(e);
          i && this.goToAndStop(i.time, true);
        } else t ? this.setCurrentRawFrameValue(e) : this.setCurrentRawFrameValue(e * this.frameModifier);
        this.pause();
      }
    }, AnimationItem.prototype.goToAndPlay = function(e, t, n) {
      if (!(n && this.name !== n)) {
        var r = Number(e);
        if (isNaN(r)) {
          var i = this.getMarkerData(e);
          i && (i.duration ? this.playSegments([i.time, i.time + i.duration], true) : this.goToAndStop(i.time, true));
        } else this.goToAndStop(r, t, n);
        this.play();
      }
    }, AnimationItem.prototype.advanceTime = function(e) {
      if (this.isPaused !== true && this.isLoaded !== false) {
        var t = this.currentRawFrame + e * this.frameModifier, n = false;
        t >= this.totalFrames - 1 && this.frameModifier > 0 ? !this.loop || this.playCount === this.loop ? this.checkSegments(t > this.totalFrames ? t % this.totalFrames : 0) || (n = true, t = this.totalFrames - 1) : t >= this.totalFrames ? (this.playCount += 1, this.checkSegments(t % this.totalFrames) || (this.setCurrentRawFrameValue(t % this.totalFrames), this._completedLoop = true, this.trigger(`loopComplete`))) : this.setCurrentRawFrameValue(t) : t < 0 ? this.checkSegments(t % this.totalFrames) || (this.loop && !(this.playCount-- <= 0 && this.loop !== true) ? (this.setCurrentRawFrameValue(this.totalFrames + t % this.totalFrames), this._completedLoop ? this.trigger(`loopComplete`) : this._completedLoop = true) : (n = true, t = 0)) : this.setCurrentRawFrameValue(t), n && (this.setCurrentRawFrameValue(t), this.pause(), this.trigger(`complete`));
      }
    }, AnimationItem.prototype.adjustSegment = function(e, t) {
      this.playCount = 0, e[1] < e[0] ? (this.frameModifier > 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(-1)), this.totalFrames = e[0] - e[1], this.timeCompleted = this.totalFrames, this.firstFrame = e[1], this.setCurrentRawFrameValue(this.totalFrames - 1e-3 - t)) : e[1] > e[0] && (this.frameModifier < 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(1)), this.totalFrames = e[1] - e[0], this.timeCompleted = this.totalFrames, this.firstFrame = e[0], this.setCurrentRawFrameValue(1e-3 + t)), this.trigger(`segmentStart`);
    }, AnimationItem.prototype.setSegment = function(e, t) {
      var n = -1;
      this.isPaused && (this.currentRawFrame + this.firstFrame < e ? n = e : this.currentRawFrame + this.firstFrame > t && (n = t - e)), this.firstFrame = e, this.totalFrames = t - e, this.timeCompleted = this.totalFrames, n !== -1 && this.goToAndStop(n, true);
    }, AnimationItem.prototype.playSegments = function(e, t) {
      if (t && (this.segments.length = 0), _typeof$4(e[0]) === `object`) {
        var n, r = e.length;
        for (n = 0; n < r; n += 1) this.segments.push(e[n]);
      } else this.segments.push(e);
      this.segments.length && t && this.adjustSegment(this.segments.shift(), 0), this.isPaused && this.play();
    }, AnimationItem.prototype.resetSegments = function(e) {
      this.segments.length = 0, this.segments.push([this.animationData.ip, this.animationData.op]), e && this.checkSegments(0);
    }, AnimationItem.prototype.checkSegments = function(e) {
      return this.segments.length ? (this.adjustSegment(this.segments.shift(), e), true) : false;
    }, AnimationItem.prototype.destroy = function(e) {
      e && this.name !== e || !this.renderer || (this.renderer.destroy(), this.imagePreloader.destroy(), this.trigger(`destroy`), this._cbs = null, this.onEnterFrame = null, this.onLoopComplete = null, this.onComplete = null, this.onSegmentStart = null, this.onDestroy = null, this.renderer = null, this.expressionsPlugin = null, this.imagePreloader = null, this.projectInterface = null);
    }, AnimationItem.prototype.setCurrentRawFrameValue = function(e) {
      this.currentRawFrame = e, this.gotoFrame();
    }, AnimationItem.prototype.setSpeed = function(e) {
      this.playSpeed = e, this.updaFrameModifier();
    }, AnimationItem.prototype.setDirection = function(e) {
      this.playDirection = e < 0 ? -1 : 1, this.updaFrameModifier();
    }, AnimationItem.prototype.setLoop = function(e) {
      this.loop = e;
    }, AnimationItem.prototype.setVolume = function(e, t) {
      t && this.name !== t || this.audioController.setVolume(e);
    }, AnimationItem.prototype.getVolume = function() {
      return this.audioController.getVolume();
    }, AnimationItem.prototype.mute = function(e) {
      e && this.name !== e || this.audioController.mute();
    }, AnimationItem.prototype.unmute = function(e) {
      e && this.name !== e || this.audioController.unmute();
    }, AnimationItem.prototype.updaFrameModifier = function() {
      this.frameModifier = this.frameMult * this.playSpeed * this.playDirection, this.audioController.setRate(this.playSpeed * this.playDirection);
    }, AnimationItem.prototype.getPath = function() {
      return this.path;
    }, AnimationItem.prototype.getAssetsPath = function(e) {
      var t = ``;
      if (e.e) t = e.p;
      else if (this.assetsPath) {
        var n = e.p;
        n.indexOf(`images/`) !== -1 && (n = n.split(`/`)[1]), t = this.assetsPath + n;
      } else t = this.path, t += e.u ? e.u : ``, t += e.p;
      return t;
    }, AnimationItem.prototype.getAssetData = function(e) {
      for (var t = 0, n = this.assets.length; t < n; ) {
        if (e === this.assets[t].id) return this.assets[t];
        t += 1;
      }
      return null;
    }, AnimationItem.prototype.hide = function() {
      this.renderer.hide();
    }, AnimationItem.prototype.show = function() {
      this.renderer.show();
    }, AnimationItem.prototype.getDuration = function(e) {
      return e ? this.totalFrames : this.totalFrames / this.frameRate;
    }, AnimationItem.prototype.updateDocumentData = function(e, t, n) {
      try {
        this.renderer.getElementByPath(e).updateDocumentData(t, n);
      } catch {
      }
    }, AnimationItem.prototype.trigger = function(e) {
      if (this._cbs && this._cbs[e]) switch (e) {
        case `enterFrame`:
          this.triggerEvent(e, new BMEnterFrameEvent(e, this.currentFrame, this.totalFrames, this.frameModifier));
          break;
        case `drawnFrame`:
          this.drawnFrameEvent.currentTime = this.currentFrame, this.drawnFrameEvent.totalTime = this.totalFrames, this.drawnFrameEvent.direction = this.frameModifier, this.triggerEvent(e, this.drawnFrameEvent);
          break;
        case `loopComplete`:
          this.triggerEvent(e, new BMCompleteLoopEvent(e, this.loop, this.playCount, this.frameMult));
          break;
        case `complete`:
          this.triggerEvent(e, new BMCompleteEvent(e, this.frameMult));
          break;
        case `segmentStart`:
          this.triggerEvent(e, new BMSegmentStartEvent(e, this.firstFrame, this.totalFrames));
          break;
        case `destroy`:
          this.triggerEvent(e, new BMDestroyEvent(e, this));
          break;
        default:
          this.triggerEvent(e);
      }
      e === `enterFrame` && this.onEnterFrame && this.onEnterFrame.call(this, new BMEnterFrameEvent(e, this.currentFrame, this.totalFrames, this.frameMult)), e === `loopComplete` && this.onLoopComplete && this.onLoopComplete.call(this, new BMCompleteLoopEvent(e, this.loop, this.playCount, this.frameMult)), e === `complete` && this.onComplete && this.onComplete.call(this, new BMCompleteEvent(e, this.frameMult)), e === `segmentStart` && this.onSegmentStart && this.onSegmentStart.call(this, new BMSegmentStartEvent(e, this.firstFrame, this.totalFrames)), e === `destroy` && this.onDestroy && this.onDestroy.call(this, new BMDestroyEvent(e, this));
    }, AnimationItem.prototype.triggerRenderFrameError = function(e) {
      var t = new BMRenderFrameErrorEvent(e, this.currentFrame);
      this.triggerEvent(`error`, t), this.onError && this.onError.call(this, t);
    }, AnimationItem.prototype.triggerConfigError = function(e) {
      var t = new BMConfigErrorEvent(e, this.currentFrame);
      this.triggerEvent(`error`, t), this.onError && this.onError.call(this, t);
    };
    var animationManager = (function() {
      var e = {}, t = [], n = 0, r = 0, i = 0, a = true, o = false;
      function s(e2) {
        for (var n2 = 0, i2 = e2.target; n2 < r; ) t[n2].animation === i2 && (t.splice(n2, 1), --n2, --r, i2.isPaused || d()), n2 += 1;
      }
      function c(e2, n2) {
        if (!e2) return null;
        for (var i2 = 0; i2 < r; ) {
          if (t[i2].elem === e2 && t[i2].elem !== null) return t[i2].animation;
          i2 += 1;
        }
        var a2 = new AnimationItem();
        return f(a2, e2), a2.setData(e2, n2), a2;
      }
      function l() {
        var e2, n2 = t.length, r2 = [];
        for (e2 = 0; e2 < n2; e2 += 1) r2.push(t[e2].animation);
        return r2;
      }
      function u() {
        i += 1, k();
      }
      function d() {
        --i;
      }
      function f(e2, n2) {
        e2.addEventListener(`destroy`, s), e2.addEventListener(`_active`, u), e2.addEventListener(`_idle`, d), t.push({ elem: n2, animation: e2 }), r += 1;
      }
      function p(e2) {
        var t2 = new AnimationItem();
        return f(t2, null), t2.setParams(e2), t2;
      }
      function m(e2, n2) {
        for (var i2 = 0; i2 < r; i2 += 1) t[i2].animation.setSpeed(e2, n2);
      }
      function g(e2, n2) {
        for (var i2 = 0; i2 < r; i2 += 1) t[i2].animation.setDirection(e2, n2);
      }
      function _(e2) {
        for (var n2 = 0; n2 < r; n2 += 1) t[n2].animation.play(e2);
      }
      function y(e2) {
        for (var s2 = e2 - n, c2 = 0; c2 < r; c2 += 1) t[c2].animation.advanceTime(s2);
        n = e2, i && !o ? window.requestAnimationFrame(y) : a = true;
      }
      function b(e2) {
        n = e2, window.requestAnimationFrame(y);
      }
      function x(e2) {
        for (var n2 = 0; n2 < r; n2 += 1) t[n2].animation.pause(e2);
      }
      function S(e2, n2, i2) {
        for (var a2 = 0; a2 < r; a2 += 1) t[a2].animation.goToAndStop(e2, n2, i2);
      }
      function C(e2) {
        for (var n2 = 0; n2 < r; n2 += 1) t[n2].animation.stop(e2);
      }
      function T(e2) {
        for (var n2 = 0; n2 < r; n2 += 1) t[n2].animation.togglePause(e2);
      }
      function E(e2) {
        for (var n2 = r - 1; n2 >= 0; --n2) t[n2].animation.destroy(e2);
      }
      function D(e2, t2, n2) {
        var r2 = [].concat([].slice.call(document.getElementsByClassName(`lottie`)), [].slice.call(document.getElementsByClassName(`bodymovin`))), i2, a2 = r2.length;
        for (i2 = 0; i2 < a2; i2 += 1) n2 && r2[i2].setAttribute(`data-bm-type`, n2), c(r2[i2], e2);
        if (t2 && a2 === 0) {
          n2 || (n2 = `svg`);
          var o2 = document.getElementsByTagName(`body`)[0];
          o2.innerText = ``;
          var s2 = createTag(`div`);
          s2.style.width = `100%`, s2.style.height = `100%`, s2.setAttribute(`data-bm-type`, n2), o2.appendChild(s2), c(s2, e2);
        }
      }
      function O() {
        for (var e2 = 0; e2 < r; e2 += 1) t[e2].animation.resize();
      }
      function k() {
        !o && i && (a && (a = (window.requestAnimationFrame(b), false)));
      }
      function A() {
        o = true;
      }
      function j() {
        o = false, k();
      }
      function M(e2, n2) {
        for (var i2 = 0; i2 < r; i2 += 1) t[i2].animation.setVolume(e2, n2);
      }
      function N(e2) {
        for (var n2 = 0; n2 < r; n2 += 1) t[n2].animation.mute(e2);
      }
      function P(e2) {
        for (var n2 = 0; n2 < r; n2 += 1) t[n2].animation.unmute(e2);
      }
      return e.registerAnimation = c, e.loadAnimation = p, e.setSpeed = m, e.setDirection = g, e.play = _, e.pause = x, e.stop = C, e.togglePause = T, e.searchAnimations = D, e.resize = O, e.goToAndStop = S, e.destroy = E, e.freeze = A, e.unfreeze = j, e.setVolume = M, e.mute = N, e.unmute = P, e.getRegisteredAnimations = l, e;
    })(), BezierFactory = (function() {
      var e = {};
      e.getBezierEasing = n;
      var t = {};
      function n(e2, n2, r2, i2, a2) {
        var o2 = a2 || (`bez_` + e2 + `_` + n2 + `_` + r2 + `_` + i2).replace(/\./g, `p`);
        if (t[o2]) return t[o2];
        var s2 = new y([e2, n2, r2, i2]);
        return t[o2] = s2, s2;
      }
      var r = 4, i = 1e-3, a = 1e-7, o = 10, s = 11, c = 1 / (s - 1), l = typeof Float32Array == `function`;
      function u(e2, t2) {
        return 1 - 3 * t2 + 3 * e2;
      }
      function d(e2, t2) {
        return 3 * t2 - 6 * e2;
      }
      function f(e2) {
        return 3 * e2;
      }
      function p(e2, t2, n2) {
        return ((u(t2, n2) * e2 + d(t2, n2)) * e2 + f(t2)) * e2;
      }
      function m(e2, t2, n2) {
        return 3 * u(t2, n2) * e2 * e2 + 2 * d(t2, n2) * e2 + f(t2);
      }
      function g(e2, t2, n2, r2, i2) {
        var s2, c2, l2 = 0;
        do
          c2 = t2 + (n2 - t2) / 2, s2 = p(c2, r2, i2) - e2, s2 > 0 ? n2 = c2 : t2 = c2;
        while (Math.abs(s2) > a && ++l2 < o);
        return c2;
      }
      function _(e2, t2, n2, i2) {
        for (var a2 = 0; a2 < r; ++a2) {
          var o2 = m(t2, n2, i2);
          if (o2 === 0) return t2;
          var s2 = p(t2, n2, i2) - e2;
          t2 -= s2 / o2;
        }
        return t2;
      }
      function y(e2) {
        this._p = e2, this._mSampleValues = l ? new Float32Array(s) : Array(s), this._precomputed = false, this.get = this.get.bind(this);
      }
      return y.prototype = { get: function(e2) {
        var t2 = this._p[0], n2 = this._p[1], r2 = this._p[2], i2 = this._p[3];
        return this._precomputed || this._precompute(), t2 === n2 && r2 === i2 ? e2 : e2 === 0 ? 0 : e2 === 1 ? 1 : p(this._getTForX(e2), n2, i2);
      }, _precompute: function() {
        var e2 = this._p[0], t2 = this._p[1], n2 = this._p[2], r2 = this._p[3];
        this._precomputed = true, (e2 !== t2 || n2 !== r2) && this._calcSampleValues();
      }, _calcSampleValues: function() {
        for (var e2 = this._p[0], t2 = this._p[2], n2 = 0; n2 < s; ++n2) this._mSampleValues[n2] = p(n2 * c, e2, t2);
      }, _getTForX: function(e2) {
        for (var t2 = this._p[0], n2 = this._p[2], r2 = this._mSampleValues, a2 = 0, o2 = 1, l2 = s - 1; o2 !== l2 && r2[o2] <= e2; ++o2) a2 += c;
        --o2;
        var u2 = (e2 - r2[o2]) / (r2[o2 + 1] - r2[o2]), d2 = a2 + u2 * c, f2 = m(d2, t2, n2);
        return f2 >= i ? _(e2, d2, t2, n2) : f2 === 0 ? d2 : g(e2, a2, a2 + c, t2, n2);
      } }, e;
    })(), pooling = /* @__PURE__ */ (function() {
      function e(e2) {
        return e2.concat(createSizedArray(e2.length));
      }
      return { double: e };
    })(), poolFactory = /* @__PURE__ */ (function() {
      return function(e, t, n) {
        var r = 0, i = e, a = createSizedArray(i), o = { newElement: s, release: c };
        function s() {
          var e2;
          return r ? (--r, e2 = a[r]) : e2 = t(), e2;
        }
        function c(e2) {
          r === i && (a = pooling.double(a), i *= 2), n && n(e2), a[r] = e2, r += 1;
        }
        return o;
      };
    })(), bezierLengthPool = (function() {
      function e() {
        return { addedLength: 0, percents: createTypedArray(`float32`, getDefaultCurveSegments()), lengths: createTypedArray(`float32`, getDefaultCurveSegments()) };
      }
      return poolFactory(8, e);
    })(), segmentsLengthPool = (function() {
      function e() {
        return { lengths: [], totalLength: 0 };
      }
      function t(e2) {
        var t2, n = e2.lengths.length;
        for (t2 = 0; t2 < n; t2 += 1) bezierLengthPool.release(e2.lengths[t2]);
        e2.lengths.length = 0;
      }
      return poolFactory(8, e, t);
    })();
    function bezFunction() {
      var e = Math;
      function t(e2, t2, n2, r2, i2, a2) {
        var o2 = e2 * r2 + t2 * i2 + n2 * a2 - i2 * r2 - a2 * e2 - n2 * t2;
        return o2 > -1e-3 && o2 < 1e-3;
      }
      function n(n2, r2, i2, a2, o2, s2, c2, l2, u2) {
        if (i2 === 0 && s2 === 0 && u2 === 0) return t(n2, r2, a2, o2, c2, l2);
        var d2 = e.sqrt(e.pow(a2 - n2, 2) + e.pow(o2 - r2, 2) + e.pow(s2 - i2, 2)), f = e.sqrt(e.pow(c2 - n2, 2) + e.pow(l2 - r2, 2) + e.pow(u2 - i2, 2)), p = e.sqrt(e.pow(c2 - a2, 2) + e.pow(l2 - o2, 2) + e.pow(u2 - s2, 2)), m = d2 > f ? d2 > p ? d2 - f - p : p - f - d2 : p > f ? p - f - d2 : f - d2 - p;
        return m > -1e-4 && m < 1e-4;
      }
      var r = /* @__PURE__ */ (function() {
        return function(e2, t2, n2, r2) {
          var i2 = getDefaultCurveSegments(), a2, o2, s2, c2, l2, u2 = 0, d2, f = [], p = [], m = bezierLengthPool.newElement();
          for (s2 = n2.length, a2 = 0; a2 < i2; a2 += 1) {
            for (l2 = a2 / (i2 - 1), d2 = 0, o2 = 0; o2 < s2; o2 += 1) c2 = bmPow(1 - l2, 3) * e2[o2] + 3 * bmPow(1 - l2, 2) * l2 * n2[o2] + 3 * (1 - l2) * bmPow(l2, 2) * r2[o2] + bmPow(l2, 3) * t2[o2], f[o2] = c2, p[o2] !== null && (d2 += bmPow(f[o2] - p[o2], 2)), p[o2] = f[o2];
            d2 && (d2 = bmSqrt(d2), u2 += d2), m.percents[a2] = l2, m.lengths[a2] = u2;
          }
          return m.addedLength = u2, m;
        };
      })();
      function i(e2) {
        var t2 = segmentsLengthPool.newElement(), n2 = e2.c, i2 = e2.v, a2 = e2.o, o2 = e2.i, s2, c2 = e2._length, l2 = t2.lengths, u2 = 0;
        for (s2 = 0; s2 < c2 - 1; s2 += 1) l2[s2] = r(i2[s2], i2[s2 + 1], a2[s2], o2[s2 + 1]), u2 += l2[s2].addedLength;
        return n2 && c2 && (l2[s2] = r(i2[s2], i2[0], a2[s2], o2[0]), u2 += l2[s2].addedLength), t2.totalLength = u2, t2;
      }
      function a(e2) {
        this.segmentLength = 0, this.points = Array(e2);
      }
      function o(e2, t2) {
        this.partialLength = e2, this.point = t2;
      }
      var s = /* @__PURE__ */ (function() {
        var e2 = {};
        return function(n2, r2, i2, s2) {
          var c2 = (n2[0] + `_` + n2[1] + `_` + r2[0] + `_` + r2[1] + `_` + i2[0] + `_` + i2[1] + `_` + s2[0] + `_` + s2[1]).replace(/\./g, `p`);
          if (!e2[c2]) {
            var l2 = getDefaultCurveSegments(), u2, d2, f, p, m, g = 0, _, y, b = null;
            n2.length === 2 && (n2[0] !== r2[0] || n2[1] !== r2[1]) && t(n2[0], n2[1], r2[0], r2[1], n2[0] + i2[0], n2[1] + i2[1]) && t(n2[0], n2[1], r2[0], r2[1], r2[0] + s2[0], r2[1] + s2[1]) && (l2 = 2);
            var x = new a(l2);
            for (f = i2.length, u2 = 0; u2 < l2; u2 += 1) {
              for (y = createSizedArray(f), m = u2 / (l2 - 1), _ = 0, d2 = 0; d2 < f; d2 += 1) p = bmPow(1 - m, 3) * n2[d2] + 3 * bmPow(1 - m, 2) * m * (n2[d2] + i2[d2]) + 3 * (1 - m) * bmPow(m, 2) * (r2[d2] + s2[d2]) + bmPow(m, 3) * r2[d2], y[d2] = p, b !== null && (_ += bmPow(y[d2] - b[d2], 2));
              _ = bmSqrt(_), g += _, x.points[u2] = new o(_, y), b = y;
            }
            x.segmentLength = g, e2[c2] = x;
          }
          return e2[c2];
        };
      })();
      function c(e2, t2) {
        var n2 = t2.percents, r2 = t2.lengths, i2 = n2.length, a2 = bmFloor((i2 - 1) * e2), o2 = e2 * t2.addedLength, s2 = 0;
        if (a2 === i2 - 1 || a2 === 0 || o2 === r2[a2]) return n2[a2];
        for (var c2 = r2[a2] > o2 ? -1 : 1, l2 = true; l2; ) if (r2[a2] <= o2 && r2[a2 + 1] > o2 ? (s2 = (o2 - r2[a2]) / (r2[a2 + 1] - r2[a2]), l2 = false) : a2 += c2, a2 < 0 || a2 >= i2 - 1) {
          if (a2 === i2 - 1) return n2[a2];
          l2 = false;
        }
        return n2[a2] + (n2[a2 + 1] - n2[a2]) * s2;
      }
      function l(t2, n2, r2, i2, a2, o2) {
        var s2 = c(a2, o2), l2 = 1 - s2;
        return [e.round((l2 * l2 * l2 * t2[0] + (s2 * l2 * l2 + l2 * s2 * l2 + l2 * l2 * s2) * r2[0] + (s2 * s2 * l2 + l2 * s2 * s2 + s2 * l2 * s2) * i2[0] + s2 * s2 * s2 * n2[0]) * 1e3) / 1e3, e.round((l2 * l2 * l2 * t2[1] + (s2 * l2 * l2 + l2 * s2 * l2 + l2 * l2 * s2) * r2[1] + (s2 * s2 * l2 + l2 * s2 * s2 + s2 * l2 * s2) * i2[1] + s2 * s2 * s2 * n2[1]) * 1e3) / 1e3];
      }
      var u = createTypedArray(`float32`, 8);
      function d(t2, n2, r2, i2, a2, o2, s2) {
        a2 < 0 ? a2 = 0 : a2 > 1 && (a2 = 1);
        var l2 = c(a2, s2);
        o2 = o2 > 1 ? 1 : o2;
        var d2 = c(o2, s2), f, p = t2.length, m = 1 - l2, g = 1 - d2, _ = m * m * m, y = l2 * m * m * 3, b = l2 * l2 * m * 3, x = l2 * l2 * l2, S = m * m * g, C = l2 * m * g + m * l2 * g + m * m * d2, T = l2 * l2 * g + m * l2 * d2 + l2 * m * d2, E = l2 * l2 * d2, D = m * g * g, O = l2 * g * g + m * d2 * g + m * g * d2, k = l2 * d2 * g + m * d2 * d2 + l2 * g * d2, A = l2 * d2 * d2, j = g * g * g, M = d2 * g * g + g * d2 * g + g * g * d2, N = d2 * d2 * g + g * d2 * d2 + d2 * g * d2, P = d2 * d2 * d2;
        for (f = 0; f < p; f += 1) u[f * 4] = e.round((_ * t2[f] + y * r2[f] + b * i2[f] + x * n2[f]) * 1e3) / 1e3, u[f * 4 + 1] = e.round((S * t2[f] + C * r2[f] + T * i2[f] + E * n2[f]) * 1e3) / 1e3, u[f * 4 + 2] = e.round((D * t2[f] + O * r2[f] + k * i2[f] + A * n2[f]) * 1e3) / 1e3, u[f * 4 + 3] = e.round((j * t2[f] + M * r2[f] + N * i2[f] + P * n2[f]) * 1e3) / 1e3;
        return u;
      }
      return { getSegmentsLength: i, getNewSegment: d, getPointInSegment: l, buildBezierData: s, pointOnLine2D: t, pointOnLine3D: n };
    }
    var bez = bezFunction(), initFrame = initialDefaultFrame, mathAbs = Math.abs;
    function interpolateValue(e, t) {
      var n = this.offsetTime, r;
      this.propType === `multidimensional` && (r = createTypedArray(`float32`, this.pv.length));
      for (var i = t.lastIndex, a = i, o = this.keyframes.length - 1, s = true, c, l, u; s; ) {
        if (c = this.keyframes[a], l = this.keyframes[a + 1], a === o - 1 && e >= l.t - n) {
          c.h && (c = l), i = 0;
          break;
        }
        if (l.t - n > e) {
          i = a;
          break;
        }
        a < o - 1 ? a += 1 : (i = 0, s = false);
      }
      u = this.keyframesMetadata[a] || {};
      var d, f, p, m, g, _, y = l.t - n, b = c.t - n, x;
      if (c.to) {
        u.bezierData || (u.bezierData = bez.buildBezierData(c.s, l.s || c.e, c.to, c.ti));
        var S = u.bezierData;
        if (e >= y || e < b) {
          var C = e >= y ? S.points.length - 1 : 0;
          for (f = S.points[C].point.length, d = 0; d < f; d += 1) r[d] = S.points[C].point[d];
        } else {
          u.__fnct ? _ = u.__fnct : (_ = BezierFactory.getBezierEasing(c.o.x, c.o.y, c.i.x, c.i.y, c.n).get, u.__fnct = _), p = _((e - b) / (y - b));
          var T = S.segmentLength * p, E, D = t.lastFrame < e && t._lastKeyframeIndex === a ? t._lastAddedLength : 0;
          for (g = t.lastFrame < e && t._lastKeyframeIndex === a ? t._lastPoint : 0, s = true, m = S.points.length; s; ) {
            if (D += S.points[g].partialLength, T === 0 || p === 0 || g === S.points.length - 1) {
              for (f = S.points[g].point.length, d = 0; d < f; d += 1) r[d] = S.points[g].point[d];
              break;
            }
            if (T >= D && T < D + S.points[g + 1].partialLength) {
              for (E = (T - D) / S.points[g + 1].partialLength, f = S.points[g].point.length, d = 0; d < f; d += 1) r[d] = S.points[g].point[d] + (S.points[g + 1].point[d] - S.points[g].point[d]) * E;
              break;
            }
            g < m - 1 ? g += 1 : s = false;
          }
          t._lastPoint = g, t._lastAddedLength = D - S.points[g].partialLength, t._lastKeyframeIndex = a;
        }
      } else {
        var O, k, A, j, M;
        if (o = c.s.length, x = l.s || c.e, this.sh && c.h !== 1) {
          if (e >= y) r[0] = x[0], r[1] = x[1], r[2] = x[2];
          else if (e <= b) r[0] = c.s[0], r[1] = c.s[1], r[2] = c.s[2];
          else {
            var N = createQuaternion(c.s), P = createQuaternion(x), F = (e - b) / (y - b);
            quaternionToEuler(r, slerp(N, P, F));
          }
        } else for (a = 0; a < o; a += 1) c.h !== 1 && (e >= y ? p = 1 : e < b ? p = 0 : (c.o.x.constructor === Array ? (u.__fnct || (u.__fnct = []), u.__fnct[a] ? _ = u.__fnct[a] : (O = c.o.x[a] === void 0 ? c.o.x[0] : c.o.x[a], k = c.o.y[a] === void 0 ? c.o.y[0] : c.o.y[a], A = c.i.x[a] === void 0 ? c.i.x[0] : c.i.x[a], j = c.i.y[a] === void 0 ? c.i.y[0] : c.i.y[a], _ = BezierFactory.getBezierEasing(O, k, A, j).get, u.__fnct[a] = _)) : u.__fnct ? _ = u.__fnct : (O = c.o.x, k = c.o.y, A = c.i.x, j = c.i.y, _ = BezierFactory.getBezierEasing(O, k, A, j).get, c.keyframeMetadata = _), p = _((e - b) / (y - b)))), x = l.s || c.e, M = c.h === 1 ? c.s[a] : c.s[a] + (x[a] - c.s[a]) * p, this.propType === `multidimensional` ? r[a] = M : r = M;
      }
      return t.lastIndex = i, r;
    }
    function slerp(e, t, n) {
      var r = [], i = e[0], a = e[1], o = e[2], s = e[3], c = t[0], l = t[1], u = t[2], d = t[3], f, p = i * c + a * l + o * u + s * d, m, g, _;
      return p < 0 && (p = -p, c = -c, l = -l, u = -u, d = -d), 1 - p > 1e-6 ? (f = Math.acos(p), m = Math.sin(f), g = Math.sin((1 - n) * f) / m, _ = Math.sin(n * f) / m) : (g = 1 - n, _ = n), r[0] = g * i + _ * c, r[1] = g * a + _ * l, r[2] = g * o + _ * u, r[3] = g * s + _ * d, r;
    }
    function quaternionToEuler(e, t) {
      var n = t[0], r = t[1], i = t[2], a = t[3], o = Math.atan2(2 * r * a - 2 * n * i, 1 - 2 * r * r - 2 * i * i), s = Math.asin(2 * n * r + 2 * i * a), c = Math.atan2(2 * n * a - 2 * r * i, 1 - 2 * n * n - 2 * i * i);
      e[0] = o / degToRads, e[1] = s / degToRads, e[2] = c / degToRads;
    }
    function createQuaternion(e) {
      var t = e[0] * degToRads, n = e[1] * degToRads, r = e[2] * degToRads, i = Math.cos(t / 2), a = Math.cos(n / 2), o = Math.cos(r / 2), s = Math.sin(t / 2), c = Math.sin(n / 2), l = Math.sin(r / 2), u = i * a * o - s * c * l;
      return [s * c * o + i * a * l, s * a * o + i * c * l, i * c * o - s * a * l, u];
    }
    function getValueAtCurrentTime() {
      var e = this.comp.renderedFrame - this.offsetTime, t = this.keyframes[0].t - this.offsetTime, n = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
      if (!(e === this._caching.lastFrame || this._caching.lastFrame !== initFrame && (this._caching.lastFrame >= n && e >= n || this._caching.lastFrame < t && e < t))) {
        this._caching.lastFrame >= e && (this._caching._lastKeyframeIndex = -1, this._caching.lastIndex = 0);
        var r = this.interpolateValue(e, this._caching);
        this.pv = r;
      }
      return this._caching.lastFrame = e, this.pv;
    }
    function setVValue(e) {
      var t;
      if (this.propType === `unidimensional`) t = e * this.mult, mathAbs(this.v - t) > 1e-5 && (this.v = t, this._mdf = true);
      else for (var n = 0, r = this.v.length; n < r; ) t = e[n] * this.mult, mathAbs(this.v[n] - t) > 1e-5 && (this.v[n] = t, this._mdf = true), n += 1;
    }
    function processEffectsSequence() {
      if (this.elem.globalData.frameId !== this.frameId && this.effectsSequence.length) {
        if (this.lock) {
          this.setVValue(this.pv);
          return;
        }
        this.lock = true, this._mdf = this._isFirstFrame;
        var e, t = this.effectsSequence.length, n = this.kf ? this.pv : this.data.k;
        for (e = 0; e < t; e += 1) n = this.effectsSequence[e](n);
        this.setVValue(n), this._isFirstFrame = false, this.lock = false, this.frameId = this.elem.globalData.frameId;
      }
    }
    function addEffect(e) {
      this.effectsSequence.push(e), this.container.addDynamicProperty(this);
    }
    function ValueProperty(e, t, n, r) {
      this.propType = `unidimensional`, this.mult = n || 1, this.data = t, this.v = n ? t.k * n : t.k, this.pv = t.k, this._mdf = false, this.elem = e, this.container = r, this.comp = e.comp, this.k = false, this.kf = false, this.vel = 0, this.effectsSequence = [], this._isFirstFrame = true, this.getValue = processEffectsSequence, this.setVValue = setVValue, this.addEffect = addEffect;
    }
    function MultiDimensionalProperty(e, t, n, r) {
      this.propType = `multidimensional`, this.mult = n || 1, this.data = t, this._mdf = false, this.elem = e, this.container = r, this.comp = e.comp, this.k = false, this.kf = false, this.frameId = -1;
      var i, a = t.k.length;
      for (this.v = createTypedArray(`float32`, a), this.pv = createTypedArray(`float32`, a), this.vel = createTypedArray(`float32`, a), i = 0; i < a; i += 1) this.v[i] = t.k[i] * this.mult, this.pv[i] = t.k[i];
      this._isFirstFrame = true, this.effectsSequence = [], this.getValue = processEffectsSequence, this.setVValue = setVValue, this.addEffect = addEffect;
    }
    function KeyframedValueProperty(e, t, n, r) {
      this.propType = `unidimensional`, this.keyframes = t.k, this.keyframesMetadata = [], this.offsetTime = e.data.st, this.frameId = -1, this._caching = { lastFrame: initFrame, lastIndex: 0, value: 0, _lastKeyframeIndex: -1 }, this.k = true, this.kf = true, this.data = t, this.mult = n || 1, this.elem = e, this.container = r, this.comp = e.comp, this.v = initFrame, this.pv = initFrame, this._isFirstFrame = true, this.getValue = processEffectsSequence, this.setVValue = setVValue, this.interpolateValue = interpolateValue, this.effectsSequence = [getValueAtCurrentTime.bind(this)], this.addEffect = addEffect;
    }
    function KeyframedMultidimensionalProperty(e, t, n, r) {
      this.propType = `multidimensional`;
      var i, a = t.k.length, o, s, c, l;
      for (i = 0; i < a - 1; i += 1) t.k[i].to && t.k[i].s && t.k[i + 1] && t.k[i + 1].s && (o = t.k[i].s, s = t.k[i + 1].s, c = t.k[i].to, l = t.k[i].ti, (o.length === 2 && (o[0] !== s[0] || o[1] !== s[1]) && bez.pointOnLine2D(o[0], o[1], s[0], s[1], o[0] + c[0], o[1] + c[1]) && bez.pointOnLine2D(o[0], o[1], s[0], s[1], s[0] + l[0], s[1] + l[1]) || o.length === 3 && (o[0] !== s[0] || o[1] !== s[1] || o[2] !== s[2]) && bez.pointOnLine3D(o[0], o[1], o[2], s[0], s[1], s[2], o[0] + c[0], o[1] + c[1], o[2] + c[2]) && bez.pointOnLine3D(o[0], o[1], o[2], s[0], s[1], s[2], s[0] + l[0], s[1] + l[1], s[2] + l[2])) && (t.k[i].to = null, t.k[i].ti = null), o[0] === s[0] && o[1] === s[1] && c[0] === 0 && c[1] === 0 && l[0] === 0 && l[1] === 0 && (o.length === 2 || o[2] === s[2] && c[2] === 0 && l[2] === 0) && (t.k[i].to = null, t.k[i].ti = null));
      this.effectsSequence = [getValueAtCurrentTime.bind(this)], this.data = t, this.keyframes = t.k, this.keyframesMetadata = [], this.offsetTime = e.data.st, this.k = true, this.kf = true, this._isFirstFrame = true, this.mult = n || 1, this.elem = e, this.container = r, this.comp = e.comp, this.getValue = processEffectsSequence, this.setVValue = setVValue, this.interpolateValue = interpolateValue, this.frameId = -1;
      var u = t.k[0].s.length;
      for (this.v = createTypedArray(`float32`, u), this.pv = createTypedArray(`float32`, u), i = 0; i < u; i += 1) this.v[i] = initFrame, this.pv[i] = initFrame;
      this._caching = { lastFrame: initFrame, lastIndex: 0, value: createTypedArray(`float32`, u) }, this.addEffect = addEffect;
    }
    var PropertyFactory = /* @__PURE__ */ (function() {
      function e(e2, t, n, r, i) {
        t.sid && (t = e2.globalData.slotManager.getProp(t));
        var a;
        if (!t.k.length) a = new ValueProperty(e2, t, r, i);
        else if (typeof t.k[0] == `number`) a = new MultiDimensionalProperty(e2, t, r, i);
        else switch (n) {
          case 0:
            a = new KeyframedValueProperty(e2, t, r, i);
            break;
          case 1:
            a = new KeyframedMultidimensionalProperty(e2, t, r, i);
        }
        return a.effectsSequence.length && i.addDynamicProperty(a), a;
      }
      return { getProp: e };
    })();
    function DynamicPropertyContainer() {
    }
    DynamicPropertyContainer.prototype = { addDynamicProperty: function(e) {
      this.dynamicProperties.indexOf(e) === -1 && (this.dynamicProperties.push(e), this.container.addDynamicProperty(this), this._isAnimated = true);
    }, iterateDynamicProperties: function() {
      this._mdf = false;
      var e, t = this.dynamicProperties.length;
      for (e = 0; e < t; e += 1) this.dynamicProperties[e].getValue(), this.dynamicProperties[e]._mdf && (this._mdf = true);
    }, initDynamicPropertyContainer: function(e) {
      this.container = e, this.dynamicProperties = [], this._mdf = false, this._isAnimated = false;
    } };
    var pointPool = (function() {
      function e() {
        return createTypedArray(`float32`, 2);
      }
      return poolFactory(8, e);
    })();
    function ShapePath() {
      this.c = false, this._length = 0, this._maxLength = 8, this.v = createSizedArray(this._maxLength), this.o = createSizedArray(this._maxLength), this.i = createSizedArray(this._maxLength);
    }
    ShapePath.prototype.setPathData = function(e, t) {
      this.c = e, this.setLength(t);
      for (var n = 0; n < t; ) this.v[n] = pointPool.newElement(), this.o[n] = pointPool.newElement(), this.i[n] = pointPool.newElement(), n += 1;
    }, ShapePath.prototype.setLength = function(e) {
      for (; this._maxLength < e; ) this.doubleArrayLength();
      this._length = e;
    }, ShapePath.prototype.doubleArrayLength = function() {
      this.v = this.v.concat(createSizedArray(this._maxLength)), this.i = this.i.concat(createSizedArray(this._maxLength)), this.o = this.o.concat(createSizedArray(this._maxLength)), this._maxLength *= 2;
    }, ShapePath.prototype.setXYAt = function(e, t, n, r, i) {
      var a;
      switch (this._length = Math.max(this._length, r + 1), this._length >= this._maxLength && this.doubleArrayLength(), n) {
        case `v`:
          a = this.v;
          break;
        case `i`:
          a = this.i;
          break;
        case `o`:
          a = this.o;
          break;
        default:
          a = [];
      }
      (!a[r] || a[r] && !i) && (a[r] = pointPool.newElement()), a[r][0] = e, a[r][1] = t;
    }, ShapePath.prototype.setTripleAt = function(e, t, n, r, i, a, o, s) {
      this.setXYAt(e, t, `v`, o, s), this.setXYAt(n, r, `o`, o, s), this.setXYAt(i, a, `i`, o, s);
    }, ShapePath.prototype.reverse = function() {
      var e = new ShapePath();
      e.setPathData(this.c, this._length);
      var t = this.v, n = this.o, r = this.i, i = 0;
      this.c && (e.setTripleAt(t[0][0], t[0][1], r[0][0], r[0][1], n[0][0], n[0][1], 0, false), i = 1);
      for (var a = this._length - 1, o = this._length, s = i; s < o; s += 1) e.setTripleAt(t[a][0], t[a][1], r[a][0], r[a][1], n[a][0], n[a][1], s, false), --a;
      return e;
    }, ShapePath.prototype.length = function() {
      return this._length;
    };
    var shapePool = (function() {
      function e() {
        return new ShapePath();
      }
      function t(e2) {
        for (var t2 = e2._length, n2 = 0; n2 < t2; n2 += 1) pointPool.release(e2.v[n2]), pointPool.release(e2.i[n2]), pointPool.release(e2.o[n2]), e2.v[n2] = null, e2.i[n2] = null, e2.o[n2] = null;
        e2._length = 0, e2.c = false;
      }
      function n(e2) {
        var t2 = r.newElement(), n2, i = e2._length === void 0 ? e2.v.length : e2._length;
        for (t2.setLength(i), t2.c = e2.c, n2 = 0; n2 < i; n2 += 1) t2.setTripleAt(e2.v[n2][0], e2.v[n2][1], e2.o[n2][0], e2.o[n2][1], e2.i[n2][0], e2.i[n2][1], n2);
        return t2;
      }
      var r = poolFactory(4, e, t);
      return r.clone = n, r;
    })();
    function ShapeCollection() {
      this._length = 0, this._maxLength = 4, this.shapes = createSizedArray(this._maxLength);
    }
    ShapeCollection.prototype.addShape = function(e) {
      this._length === this._maxLength && (this.shapes = this.shapes.concat(createSizedArray(this._maxLength)), this._maxLength *= 2), this.shapes[this._length] = e, this._length += 1;
    }, ShapeCollection.prototype.releaseShapes = function() {
      for (var e = 0; e < this._length; e += 1) shapePool.release(this.shapes[e]);
      this._length = 0;
    };
    var shapeCollectionPool = (function() {
      var e = { newShapeCollection: i, release: a }, t = 0, n = 4, r = createSizedArray(n);
      function i() {
        var e2;
        return t ? (--t, e2 = r[t]) : e2 = new ShapeCollection(), e2;
      }
      function a(e2) {
        var i2, a2 = e2._length;
        for (i2 = 0; i2 < a2; i2 += 1) shapePool.release(e2.shapes[i2]);
        e2._length = 0, t === n && (r = pooling.double(r), n *= 2), r[t] = e2, t += 1;
      }
      return e;
    })(), ShapePropertyFactory = (function() {
      var e = -999999;
      function t(e2, t2, n2) {
        var r2 = n2.lastIndex, i2, a2, o2, s2, c2, l2, u2, d2, f2, p2 = this.keyframes;
        if (e2 < p2[0].t - this.offsetTime) i2 = p2[0].s[0], o2 = true, r2 = 0;
        else if (e2 >= p2[p2.length - 1].t - this.offsetTime) i2 = p2[p2.length - 1].s ? p2[p2.length - 1].s[0] : p2[p2.length - 2].e[0], o2 = true;
        else {
          for (var m2 = r2, g2 = p2.length - 1, _2 = true, y, b, x; _2 && (y = p2[m2], b = p2[m2 + 1], !(b.t - this.offsetTime > e2)); ) m2 < g2 - 1 ? m2 += 1 : _2 = false;
          if (x = this.keyframesMetadata[m2] || {}, o2 = y.h === 1, r2 = m2, !o2) {
            if (e2 >= b.t - this.offsetTime) d2 = 1;
            else if (e2 < y.t - this.offsetTime) d2 = 0;
            else {
              var S;
              x.__fnct ? S = x.__fnct : (S = BezierFactory.getBezierEasing(y.o.x, y.o.y, y.i.x, y.i.y).get, x.__fnct = S), d2 = S((e2 - (y.t - this.offsetTime)) / (b.t - this.offsetTime - (y.t - this.offsetTime)));
            }
            a2 = b.s ? b.s[0] : y.e[0];
          }
          i2 = y.s[0];
        }
        for (l2 = t2._length, u2 = i2.i[0].length, n2.lastIndex = r2, s2 = 0; s2 < l2; s2 += 1) for (c2 = 0; c2 < u2; c2 += 1) f2 = o2 ? i2.i[s2][c2] : i2.i[s2][c2] + (a2.i[s2][c2] - i2.i[s2][c2]) * d2, t2.i[s2][c2] = f2, f2 = o2 ? i2.o[s2][c2] : i2.o[s2][c2] + (a2.o[s2][c2] - i2.o[s2][c2]) * d2, t2.o[s2][c2] = f2, f2 = o2 ? i2.v[s2][c2] : i2.v[s2][c2] + (a2.v[s2][c2] - i2.v[s2][c2]) * d2, t2.v[s2][c2] = f2;
      }
      function n() {
        var t2 = this.comp.renderedFrame - this.offsetTime, n2 = this.keyframes[0].t - this.offsetTime, r2 = this.keyframes[this.keyframes.length - 1].t - this.offsetTime, i2 = this._caching.lastFrame;
        return i2 !== e && (i2 < n2 && t2 < n2 || i2 > r2 && t2 > r2) || (this._caching.lastIndex = i2 < t2 ? this._caching.lastIndex : 0, this.interpolateShape(t2, this.pv, this._caching)), this._caching.lastFrame = t2, this.pv;
      }
      function r() {
        this.paths = this.localShapeCollection;
      }
      function i(e2, t2) {
        if (e2._length !== t2._length || e2.c !== t2.c) return false;
        var n2, r2 = e2._length;
        for (n2 = 0; n2 < r2; n2 += 1) if (e2.v[n2][0] !== t2.v[n2][0] || e2.v[n2][1] !== t2.v[n2][1] || e2.o[n2][0] !== t2.o[n2][0] || e2.o[n2][1] !== t2.o[n2][1] || e2.i[n2][0] !== t2.i[n2][0] || e2.i[n2][1] !== t2.i[n2][1]) return false;
        return true;
      }
      function a(e2) {
        i(this.v, e2) || (this.v = shapePool.clone(e2), this.localShapeCollection.releaseShapes(), this.localShapeCollection.addShape(this.v), this._mdf = true, this.paths = this.localShapeCollection);
      }
      function o() {
        if (this.elem.globalData.frameId !== this.frameId) {
          if (!this.effectsSequence.length) {
            this._mdf = false;
            return;
          }
          if (this.lock) {
            this.setVValue(this.pv);
            return;
          }
          this.lock = true, this._mdf = false;
          var e2 = this.kf ? this.pv : this.data.ks ? this.data.ks.k : this.data.pt.k, t2, n2 = this.effectsSequence.length;
          for (t2 = 0; t2 < n2; t2 += 1) e2 = this.effectsSequence[t2](e2);
          this.setVValue(e2), this.lock = false, this.frameId = this.elem.globalData.frameId;
        }
      }
      function s(e2, t2, n2) {
        this.propType = `shape`, this.comp = e2.comp, this.container = e2, this.elem = e2, this.data = t2, this.k = false, this.kf = false, this._mdf = false;
        var i2 = n2 === 3 ? t2.pt.k : t2.ks.k;
        this.v = shapePool.clone(i2), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.reset = r, this.effectsSequence = [];
      }
      function c(e2) {
        this.effectsSequence.push(e2), this.container.addDynamicProperty(this);
      }
      s.prototype.interpolateShape = t, s.prototype.getValue = o, s.prototype.setVValue = a, s.prototype.addEffect = c;
      function l(t2, i2, a2) {
        this.propType = `shape`, this.comp = t2.comp, this.elem = t2, this.container = t2, this.offsetTime = t2.data.st, this.keyframes = a2 === 3 ? i2.pt.k : i2.ks.k, this.keyframesMetadata = [], this.k = true, this.kf = true;
        var o2 = this.keyframes[0].s[0].i.length;
        this.v = shapePool.newElement(), this.v.setPathData(this.keyframes[0].s[0].c, o2), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.lastFrame = e, this.reset = r, this._caching = { lastFrame: e, lastIndex: 0 }, this.effectsSequence = [n.bind(this)];
      }
      l.prototype.getValue = o, l.prototype.interpolateShape = t, l.prototype.setVValue = a, l.prototype.addEffect = c;
      var u = (function() {
        var e2 = roundCorner;
        function t2(e3, t3) {
          this.v = shapePool.newElement(), this.v.setPathData(true, 4), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.localShapeCollection.addShape(this.v), this.d = t3.d, this.elem = e3, this.comp = e3.comp, this.frameId = -1, this.initDynamicPropertyContainer(e3), this.p = PropertyFactory.getProp(e3, t3.p, 1, 0, this), this.s = PropertyFactory.getProp(e3, t3.s, 1, 0, this), this.dynamicProperties.length ? this.k = true : (this.k = false, this.convertEllToPath());
        }
        return t2.prototype = { reset: r, getValue: function() {
          this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertEllToPath());
        }, convertEllToPath: function() {
          var t3 = this.p.v[0], n2 = this.p.v[1], r2 = this.s.v[0] / 2, i2 = this.s.v[1] / 2, a2 = this.d !== 3, o2 = this.v;
          o2.v[0][0] = t3, o2.v[0][1] = n2 - i2, o2.v[1][0] = a2 ? t3 + r2 : t3 - r2, o2.v[1][1] = n2, o2.v[2][0] = t3, o2.v[2][1] = n2 + i2, o2.v[3][0] = a2 ? t3 - r2 : t3 + r2, o2.v[3][1] = n2, o2.i[0][0] = a2 ? t3 - r2 * e2 : t3 + r2 * e2, o2.i[0][1] = n2 - i2, o2.i[1][0] = a2 ? t3 + r2 : t3 - r2, o2.i[1][1] = n2 - i2 * e2, o2.i[2][0] = a2 ? t3 + r2 * e2 : t3 - r2 * e2, o2.i[2][1] = n2 + i2, o2.i[3][0] = a2 ? t3 - r2 : t3 + r2, o2.i[3][1] = n2 + i2 * e2, o2.o[0][0] = a2 ? t3 + r2 * e2 : t3 - r2 * e2, o2.o[0][1] = n2 - i2, o2.o[1][0] = a2 ? t3 + r2 : t3 - r2, o2.o[1][1] = n2 + i2 * e2, o2.o[2][0] = a2 ? t3 - r2 * e2 : t3 + r2 * e2, o2.o[2][1] = n2 + i2, o2.o[3][0] = a2 ? t3 - r2 : t3 + r2, o2.o[3][1] = n2 - i2 * e2;
        } }, extendPrototype([DynamicPropertyContainer], t2), t2;
      })(), d = (function() {
        function e2(e3, t2) {
          this.v = shapePool.newElement(), this.v.setPathData(true, 0), this.elem = e3, this.comp = e3.comp, this.data = t2, this.frameId = -1, this.d = t2.d, this.initDynamicPropertyContainer(e3), t2.sy === 1 ? (this.ir = PropertyFactory.getProp(e3, t2.ir, 0, 0, this), this.is = PropertyFactory.getProp(e3, t2.is, 0, 0.01, this), this.convertToPath = this.convertStarToPath) : this.convertToPath = this.convertPolygonToPath, this.pt = PropertyFactory.getProp(e3, t2.pt, 0, 0, this), this.p = PropertyFactory.getProp(e3, t2.p, 1, 0, this), this.r = PropertyFactory.getProp(e3, t2.r, 0, degToRads, this), this.or = PropertyFactory.getProp(e3, t2.or, 0, 0, this), this.os = PropertyFactory.getProp(e3, t2.os, 0, 0.01, this), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.dynamicProperties.length ? this.k = true : (this.k = false, this.convertToPath());
        }
        return e2.prototype = { reset: r, getValue: function() {
          this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertToPath());
        }, convertStarToPath: function() {
          var e3 = Math.floor(this.pt.v) * 2, t2 = Math.PI * 2 / e3, n2 = true, r2 = this.or.v, i2 = this.ir.v, a2 = this.os.v, o2 = this.is.v, s2 = 2 * Math.PI * r2 / (e3 * 2), c2 = 2 * Math.PI * i2 / (e3 * 2), l2, u2, d2, f2, p2 = -Math.PI / 2;
          p2 += this.r.v;
          var m2 = this.data.d === 3 ? -1 : 1;
          for (this.v._length = 0, l2 = 0; l2 < e3; l2 += 1) {
            u2 = n2 ? r2 : i2, d2 = n2 ? a2 : o2, f2 = n2 ? s2 : c2;
            var g2 = u2 * Math.cos(p2), _2 = u2 * Math.sin(p2), y = g2 === 0 && _2 === 0 ? 0 : _2 / Math.sqrt(g2 * g2 + _2 * _2), b = g2 === 0 && _2 === 0 ? 0 : -g2 / Math.sqrt(g2 * g2 + _2 * _2);
            g2 += +this.p.v[0], _2 += +this.p.v[1], this.v.setTripleAt(g2, _2, g2 - y * f2 * d2 * m2, _2 - b * f2 * d2 * m2, g2 + y * f2 * d2 * m2, _2 + b * f2 * d2 * m2, l2, true), n2 = !n2, p2 += t2 * m2;
          }
        }, convertPolygonToPath: function() {
          var e3 = Math.floor(this.pt.v), t2 = Math.PI * 2 / e3, n2 = this.or.v, r2 = this.os.v, i2 = 2 * Math.PI * n2 / (e3 * 4), a2, o2 = -Math.PI * 0.5, s2 = this.data.d === 3 ? -1 : 1;
          for (o2 += this.r.v, this.v._length = 0, a2 = 0; a2 < e3; a2 += 1) {
            var c2 = n2 * Math.cos(o2), l2 = n2 * Math.sin(o2), u2 = c2 === 0 && l2 === 0 ? 0 : l2 / Math.sqrt(c2 * c2 + l2 * l2), d2 = c2 === 0 && l2 === 0 ? 0 : -c2 / Math.sqrt(c2 * c2 + l2 * l2);
            c2 += +this.p.v[0], l2 += +this.p.v[1], this.v.setTripleAt(c2, l2, c2 - u2 * i2 * r2 * s2, l2 - d2 * i2 * r2 * s2, c2 + u2 * i2 * r2 * s2, l2 + d2 * i2 * r2 * s2, a2, true), o2 += t2 * s2;
          }
          this.paths.length = 0, this.paths[0] = this.v;
        } }, extendPrototype([DynamicPropertyContainer], e2), e2;
      })(), f = (function() {
        function e2(e3, t2) {
          this.v = shapePool.newElement(), this.v.c = true, this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.elem = e3, this.comp = e3.comp, this.frameId = -1, this.d = t2.d, this.initDynamicPropertyContainer(e3), this.p = PropertyFactory.getProp(e3, t2.p, 1, 0, this), this.s = PropertyFactory.getProp(e3, t2.s, 1, 0, this), this.r = PropertyFactory.getProp(e3, t2.r, 0, 0, this), this.dynamicProperties.length ? this.k = true : (this.k = false, this.convertRectToPath());
        }
        return e2.prototype = { convertRectToPath: function() {
          var e3 = this.p.v[0], t2 = this.p.v[1], n2 = this.s.v[0] / 2, r2 = this.s.v[1] / 2, i2 = bmMin(n2, r2, this.r.v), a2 = i2 * (1 - roundCorner);
          this.v._length = 0, this.d === 2 || this.d === 1 ? (this.v.setTripleAt(e3 + n2, t2 - r2 + i2, e3 + n2, t2 - r2 + i2, e3 + n2, t2 - r2 + a2, 0, true), this.v.setTripleAt(e3 + n2, t2 + r2 - i2, e3 + n2, t2 + r2 - a2, e3 + n2, t2 + r2 - i2, 1, true), i2 === 0 ? (this.v.setTripleAt(e3 - n2, t2 + r2, e3 - n2 + a2, t2 + r2, e3 - n2, t2 + r2, 2), this.v.setTripleAt(e3 - n2, t2 - r2, e3 - n2, t2 - r2 + a2, e3 - n2, t2 - r2, 3)) : (this.v.setTripleAt(e3 + n2 - i2, t2 + r2, e3 + n2 - i2, t2 + r2, e3 + n2 - a2, t2 + r2, 2, true), this.v.setTripleAt(e3 - n2 + i2, t2 + r2, e3 - n2 + a2, t2 + r2, e3 - n2 + i2, t2 + r2, 3, true), this.v.setTripleAt(e3 - n2, t2 + r2 - i2, e3 - n2, t2 + r2 - i2, e3 - n2, t2 + r2 - a2, 4, true), this.v.setTripleAt(e3 - n2, t2 - r2 + i2, e3 - n2, t2 - r2 + a2, e3 - n2, t2 - r2 + i2, 5, true), this.v.setTripleAt(e3 - n2 + i2, t2 - r2, e3 - n2 + i2, t2 - r2, e3 - n2 + a2, t2 - r2, 6, true), this.v.setTripleAt(e3 + n2 - i2, t2 - r2, e3 + n2 - a2, t2 - r2, e3 + n2 - i2, t2 - r2, 7, true))) : (this.v.setTripleAt(e3 + n2, t2 - r2 + i2, e3 + n2, t2 - r2 + a2, e3 + n2, t2 - r2 + i2, 0, true), i2 === 0 ? (this.v.setTripleAt(e3 - n2, t2 - r2, e3 - n2 + a2, t2 - r2, e3 - n2, t2 - r2, 1, true), this.v.setTripleAt(e3 - n2, t2 + r2, e3 - n2, t2 + r2 - a2, e3 - n2, t2 + r2, 2, true), this.v.setTripleAt(e3 + n2, t2 + r2, e3 + n2 - a2, t2 + r2, e3 + n2, t2 + r2, 3, true)) : (this.v.setTripleAt(e3 + n2 - i2, t2 - r2, e3 + n2 - i2, t2 - r2, e3 + n2 - a2, t2 - r2, 1, true), this.v.setTripleAt(e3 - n2 + i2, t2 - r2, e3 - n2 + a2, t2 - r2, e3 - n2 + i2, t2 - r2, 2, true), this.v.setTripleAt(e3 - n2, t2 - r2 + i2, e3 - n2, t2 - r2 + i2, e3 - n2, t2 - r2 + a2, 3, true), this.v.setTripleAt(e3 - n2, t2 + r2 - i2, e3 - n2, t2 + r2 - a2, e3 - n2, t2 + r2 - i2, 4, true), this.v.setTripleAt(e3 - n2 + i2, t2 + r2, e3 - n2 + i2, t2 + r2, e3 - n2 + a2, t2 + r2, 5, true), this.v.setTripleAt(e3 + n2 - i2, t2 + r2, e3 + n2 - a2, t2 + r2, e3 + n2 - i2, t2 + r2, 6, true), this.v.setTripleAt(e3 + n2, t2 + r2 - i2, e3 + n2, t2 + r2 - i2, e3 + n2, t2 + r2 - a2, 7, true)));
        }, getValue: function() {
          this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertRectToPath());
        }, reset: r }, extendPrototype([DynamicPropertyContainer], e2), e2;
      })();
      function p(e2, t2, n2) {
        var r2;
        return n2 === 3 || n2 === 4 ? r2 = (n2 === 3 ? t2.pt : t2.ks).k.length ? new l(e2, t2, n2) : new s(e2, t2, n2) : n2 === 5 ? r2 = new f(e2, t2) : n2 === 6 ? r2 = new u(e2, t2) : n2 === 7 && (r2 = new d(e2, t2)), r2.k && e2.addDynamicProperty(r2), r2;
      }
      function m() {
        return s;
      }
      function g() {
        return l;
      }
      var _ = {};
      return _.getShapeProp = p, _.getConstructorFunction = m, _.getKeyframedConstructorFunction = g, _;
    })(), Matrix = /* @__PURE__ */ (function() {
      var e = Math.cos, t = Math.sin, n = Math.tan, r = Math.round;
      function i() {
        return this.props[0] = 1, this.props[1] = 0, this.props[2] = 0, this.props[3] = 0, this.props[4] = 0, this.props[5] = 1, this.props[6] = 0, this.props[7] = 0, this.props[8] = 0, this.props[9] = 0, this.props[10] = 1, this.props[11] = 0, this.props[12] = 0, this.props[13] = 0, this.props[14] = 0, this.props[15] = 1, this;
      }
      function a(n2) {
        if (n2 === 0) return this;
        var r2 = e(n2), i2 = t(n2);
        return this._t(r2, -i2, 0, 0, i2, r2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
      }
      function o(n2) {
        if (n2 === 0) return this;
        var r2 = e(n2), i2 = t(n2);
        return this._t(1, 0, 0, 0, 0, r2, -i2, 0, 0, i2, r2, 0, 0, 0, 0, 1);
      }
      function s(n2) {
        if (n2 === 0) return this;
        var r2 = e(n2), i2 = t(n2);
        return this._t(r2, 0, i2, 0, 0, 1, 0, 0, -i2, 0, r2, 0, 0, 0, 0, 1);
      }
      function c(n2) {
        if (n2 === 0) return this;
        var r2 = e(n2), i2 = t(n2);
        return this._t(r2, -i2, 0, 0, i2, r2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
      }
      function l(e2, t2) {
        return this._t(1, t2, e2, 1, 0, 0);
      }
      function u(e2, t2) {
        return this.shear(n(e2), n(t2));
      }
      function d(r2, i2) {
        var a2 = e(i2), o2 = t(i2);
        return this._t(a2, o2, 0, 0, -o2, a2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(1, 0, 0, 0, n(r2), 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(a2, -o2, 0, 0, o2, a2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
      }
      function f(e2, t2, n2) {
        return !n2 && n2 !== 0 && (n2 = 1), e2 === 1 && t2 === 1 && n2 === 1 ? this : this._t(e2, 0, 0, 0, 0, t2, 0, 0, 0, 0, n2, 0, 0, 0, 0, 1);
      }
      function p(e2, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2, f2, p2, m2, g2) {
        return this.props[0] = e2, this.props[1] = t2, this.props[2] = n2, this.props[3] = r2, this.props[4] = i2, this.props[5] = a2, this.props[6] = o2, this.props[7] = s2, this.props[8] = c2, this.props[9] = l2, this.props[10] = u2, this.props[11] = d2, this.props[12] = f2, this.props[13] = p2, this.props[14] = m2, this.props[15] = g2, this;
      }
      function m(e2, t2, n2) {
        return n2 || (n2 = 0), e2 !== 0 || t2 !== 0 || n2 !== 0 ? this._t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, e2, t2, n2, 1) : this;
      }
      function g(e2, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2, f2, p2, m2, g2) {
        var _2 = this.props;
        if (e2 === 1 && t2 === 0 && n2 === 0 && r2 === 0 && i2 === 0 && a2 === 1 && o2 === 0 && s2 === 0 && c2 === 0 && l2 === 0 && u2 === 1 && d2 === 0) return _2[12] = _2[12] * e2 + _2[15] * f2, _2[13] = _2[13] * a2 + _2[15] * p2, _2[14] = _2[14] * u2 + _2[15] * m2, _2[15] *= g2, this._identityCalculated = false, this;
        var y2 = _2[0], b2 = _2[1], x2 = _2[2], S2 = _2[3], C2 = _2[4], T2 = _2[5], E2 = _2[6], D2 = _2[7], O2 = _2[8], k2 = _2[9], A2 = _2[10], j2 = _2[11], M2 = _2[12], N2 = _2[13], P2 = _2[14], F2 = _2[15];
        return _2[0] = y2 * e2 + b2 * i2 + x2 * c2 + S2 * f2, _2[1] = y2 * t2 + b2 * a2 + x2 * l2 + S2 * p2, _2[2] = y2 * n2 + b2 * o2 + x2 * u2 + S2 * m2, _2[3] = y2 * r2 + b2 * s2 + x2 * d2 + S2 * g2, _2[4] = C2 * e2 + T2 * i2 + E2 * c2 + D2 * f2, _2[5] = C2 * t2 + T2 * a2 + E2 * l2 + D2 * p2, _2[6] = C2 * n2 + T2 * o2 + E2 * u2 + D2 * m2, _2[7] = C2 * r2 + T2 * s2 + E2 * d2 + D2 * g2, _2[8] = O2 * e2 + k2 * i2 + A2 * c2 + j2 * f2, _2[9] = O2 * t2 + k2 * a2 + A2 * l2 + j2 * p2, _2[10] = O2 * n2 + k2 * o2 + A2 * u2 + j2 * m2, _2[11] = O2 * r2 + k2 * s2 + A2 * d2 + j2 * g2, _2[12] = M2 * e2 + N2 * i2 + P2 * c2 + F2 * f2, _2[13] = M2 * t2 + N2 * a2 + P2 * l2 + F2 * p2, _2[14] = M2 * n2 + N2 * o2 + P2 * u2 + F2 * m2, _2[15] = M2 * r2 + N2 * s2 + P2 * d2 + F2 * g2, this._identityCalculated = false, this;
      }
      function _(e2) {
        var t2 = e2.props;
        return this.transform(t2[0], t2[1], t2[2], t2[3], t2[4], t2[5], t2[6], t2[7], t2[8], t2[9], t2[10], t2[11], t2[12], t2[13], t2[14], t2[15]);
      }
      function y() {
        return this._identityCalculated || (this._identityCalculated = (this._identity = this.props[0] === 1 && this.props[1] === 0 && this.props[2] === 0 && this.props[3] === 0 && this.props[4] === 0 && this.props[5] === 1 && this.props[6] === 0 && this.props[7] === 0 && this.props[8] === 0 && this.props[9] === 0 && this.props[10] === 1 && this.props[11] === 0 && this.props[12] === 0 && this.props[13] === 0 && this.props[14] === 0 && this.props[15] === 1, true)), this._identity;
      }
      function b(e2) {
        for (var t2 = 0; t2 < 16; ) {
          if (e2.props[t2] !== this.props[t2]) return false;
          t2 += 1;
        }
        return true;
      }
      function x(e2) {
        for (var t2 = 0; t2 < 16; t2 += 1) e2.props[t2] = this.props[t2];
        return e2;
      }
      function S(e2) {
        for (var t2 = 0; t2 < 16; t2 += 1) this.props[t2] = e2[t2];
      }
      function C(e2, t2, n2) {
        return { x: e2 * this.props[0] + t2 * this.props[4] + n2 * this.props[8] + this.props[12], y: e2 * this.props[1] + t2 * this.props[5] + n2 * this.props[9] + this.props[13], z: e2 * this.props[2] + t2 * this.props[6] + n2 * this.props[10] + this.props[14] };
      }
      function T(e2, t2, n2) {
        return e2 * this.props[0] + t2 * this.props[4] + n2 * this.props[8] + this.props[12];
      }
      function E(e2, t2, n2) {
        return e2 * this.props[1] + t2 * this.props[5] + n2 * this.props[9] + this.props[13];
      }
      function D(e2, t2, n2) {
        return e2 * this.props[2] + t2 * this.props[6] + n2 * this.props[10] + this.props[14];
      }
      function O() {
        var e2 = this.props[0] * this.props[5] - this.props[1] * this.props[4], t2 = this.props[5] / e2, n2 = -this.props[1] / e2, r2 = -this.props[4] / e2, i2 = this.props[0] / e2, a2 = (this.props[4] * this.props[13] - this.props[5] * this.props[12]) / e2, o2 = -(this.props[0] * this.props[13] - this.props[1] * this.props[12]) / e2, s2 = new Matrix();
        return s2.props[0] = t2, s2.props[1] = n2, s2.props[4] = r2, s2.props[5] = i2, s2.props[12] = a2, s2.props[13] = o2, s2;
      }
      function k(e2) {
        return this.getInverseMatrix().applyToPointArray(e2[0], e2[1], e2[2] || 0);
      }
      function A(e2) {
        var t2, n2 = e2.length, r2 = [];
        for (t2 = 0; t2 < n2; t2 += 1) r2[t2] = k(e2[t2]);
        return r2;
      }
      function j(e2, t2, n2) {
        var r2 = createTypedArray(`float32`, 6);
        if (this.isIdentity()) r2[0] = e2[0], r2[1] = e2[1], r2[2] = t2[0], r2[3] = t2[1], r2[4] = n2[0], r2[5] = n2[1];
        else {
          var i2 = this.props[0], a2 = this.props[1], o2 = this.props[4], s2 = this.props[5], c2 = this.props[12], l2 = this.props[13];
          r2[0] = e2[0] * i2 + e2[1] * o2 + c2, r2[1] = e2[0] * a2 + e2[1] * s2 + l2, r2[2] = t2[0] * i2 + t2[1] * o2 + c2, r2[3] = t2[0] * a2 + t2[1] * s2 + l2, r2[4] = n2[0] * i2 + n2[1] * o2 + c2, r2[5] = n2[0] * a2 + n2[1] * s2 + l2;
        }
        return r2;
      }
      function M(e2, t2, n2) {
        return this.isIdentity() ? [e2, t2, n2] : [e2 * this.props[0] + t2 * this.props[4] + n2 * this.props[8] + this.props[12], e2 * this.props[1] + t2 * this.props[5] + n2 * this.props[9] + this.props[13], e2 * this.props[2] + t2 * this.props[6] + n2 * this.props[10] + this.props[14]];
      }
      function N(e2, t2) {
        if (this.isIdentity()) return e2 + `,` + t2;
        var n2 = this.props;
        return Math.round((e2 * n2[0] + t2 * n2[4] + n2[12]) * 100) / 100 + `,` + Math.round((e2 * n2[1] + t2 * n2[5] + n2[13]) * 100) / 100;
      }
      function P() {
        for (var e2 = 0, t2 = this.props, n2 = `matrix3d(`, i2 = 1e4; e2 < 16; ) n2 += r(t2[e2] * i2) / i2, n2 += e2 === 15 ? `)` : `,`, e2 += 1;
        return n2;
      }
      function F(e2) {
        var t2 = 1e4;
        return e2 < 1e-6 && e2 > 0 || e2 > -1e-6 && e2 < 0 ? r(e2 * t2) / t2 : e2;
      }
      function I() {
        var e2 = this.props, t2 = F(e2[0]), n2 = F(e2[1]), r2 = F(e2[4]), i2 = F(e2[5]), a2 = F(e2[12]), o2 = F(e2[13]);
        return `matrix(` + t2 + `,` + n2 + `,` + r2 + `,` + i2 + `,` + a2 + `,` + o2 + `)`;
      }
      return function() {
        this.reset = i, this.rotate = a, this.rotateX = o, this.rotateY = s, this.rotateZ = c, this.skew = u, this.skewFromAxis = d, this.shear = l, this.scale = f, this.setTransform = p, this.translate = m, this.transform = g, this.multiply = _, this.applyToPoint = C, this.applyToX = T, this.applyToY = E, this.applyToZ = D, this.applyToPointArray = M, this.applyToTriplePoints = j, this.applyToPointStringified = N, this.toCSS = P, this.to2dCSS = I, this.clone = x, this.cloneFromProps = S, this.equals = b, this.inversePoints = A, this.inversePoint = k, this.getInverseMatrix = O, this._t = this.transform, this.isIdentity = y, this._identity = true, this._identityCalculated = false, this.props = createTypedArray(`float32`, 16), this.reset();
      };
    })();
    function _typeof$3(e) {
      "@babel/helpers - typeof";
      return _typeof$3 = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e2) {
        return typeof e2;
      } : function(e2) {
        return e2 && typeof Symbol == `function` && e2.constructor === Symbol && e2 !== Symbol.prototype ? `symbol` : typeof e2;
      }, _typeof$3(e);
    }
    var lottie = {}, standalone = `__[STANDALONE]__`, animationData = `__[ANIMATIONDATA]__`, renderer = ``;
    function setLocation(e) {
      setLocationHref(e);
    }
    function searchAnimations() {
      standalone === true ? animationManager.searchAnimations(animationData, standalone, renderer) : animationManager.searchAnimations();
    }
    function setSubframeRendering(e) {
      setSubframeEnabled(e);
    }
    function setPrefix(e) {
      setIdPrefix(e);
    }
    function loadAnimation(e) {
      return standalone === true && (e.animationData = JSON.parse(animationData)), animationManager.loadAnimation(e);
    }
    function setQuality(e) {
      if (typeof e == `string`) switch (e) {
        case `high`:
          setDefaultCurveSegments(200);
          break;
        default:
        case `medium`:
          setDefaultCurveSegments(50);
          break;
        case `low`:
          setDefaultCurveSegments(10);
      }
      else !isNaN(e) && e > 1 && setDefaultCurveSegments(e);
      getDefaultCurveSegments() >= 50 ? roundValues(false) : roundValues(true);
    }
    function inBrowser() {
      return typeof navigator < `u`;
    }
    function installPlugin(e, t) {
      e === `expressions` && setExpressionsPlugin(t);
    }
    function getFactory(e) {
      switch (e) {
        case `propertyFactory`:
          return PropertyFactory;
        case `shapePropertyFactory`:
          return ShapePropertyFactory;
        case `matrix`:
          return Matrix;
        default:
          return null;
      }
    }
    lottie.play = animationManager.play, lottie.pause = animationManager.pause, lottie.setLocationHref = setLocation, lottie.togglePause = animationManager.togglePause, lottie.setSpeed = animationManager.setSpeed, lottie.setDirection = animationManager.setDirection, lottie.stop = animationManager.stop, lottie.searchAnimations = searchAnimations, lottie.registerAnimation = animationManager.registerAnimation, lottie.loadAnimation = loadAnimation, lottie.setSubframeRendering = setSubframeRendering, lottie.resize = animationManager.resize, lottie.goToAndStop = animationManager.goToAndStop, lottie.destroy = animationManager.destroy, lottie.setQuality = setQuality, lottie.inBrowser = inBrowser, lottie.installPlugin = installPlugin, lottie.freeze = animationManager.freeze, lottie.unfreeze = animationManager.unfreeze, lottie.setVolume = animationManager.setVolume, lottie.mute = animationManager.mute, lottie.unmute = animationManager.unmute, lottie.getRegisteredAnimations = animationManager.getRegisteredAnimations, lottie.useWebWorker = setWebWorker, lottie.setIDPrefix = setPrefix, lottie.__getFactory = getFactory, lottie.version = `5.13.0`;
    function checkReady() {
      document.readyState === `complete` && (clearInterval(readyStateCheckInterval), searchAnimations());
    }
    function getQueryVariable(e) {
      for (var t = queryString.split(`&`), n = 0; n < t.length; n += 1) {
        var r = t[n].split(`=`);
        if (decodeURIComponent(r[0]) == e) return decodeURIComponent(r[1]);
      }
      return null;
    }
    var queryString = ``;
    if (standalone) {
      var scripts = document.getElementsByTagName(`script`), myScript = scripts[scripts.length - 1] || { src: `` };
      queryString = myScript.src ? myScript.src.replace(/^[^\?]+\??/, ``) : ``, renderer = getQueryVariable(`renderer`);
    }
    var readyStateCheckInterval = setInterval(checkReady, 100);
    try {
      ((exports === void 0 ? `undefined` : _typeof$3(exports)) !== `object` || module === void 0) && !(typeof define == `function` && define.amd) && (window.bodymovin = lottie);
    } catch {
    }
    var ShapeModifiers = (function() {
      var e = {}, t = {};
      e.registerModifier = n, e.getModifier = r;
      function n(e2, n2) {
        t[e2] || (t[e2] = n2);
      }
      function r(e2, n2, r2) {
        return new t[e2](n2, r2);
      }
      return e;
    })();
    function ShapeModifier() {
    }
    ShapeModifier.prototype.initModifierProperties = function() {
    }, ShapeModifier.prototype.addShapeToModifier = function() {
    }, ShapeModifier.prototype.addShape = function(e) {
      if (!this.closed) {
        e.sh.container.addDynamicProperty(e.sh);
        var t = { shape: e.sh, data: e, localShapeCollection: shapeCollectionPool.newShapeCollection() };
        this.shapes.push(t), this.addShapeToModifier(t), this._isAnimated && e.setAsAnimated();
      }
    }, ShapeModifier.prototype.init = function(e, t) {
      this.shapes = [], this.elem = e, this.initDynamicPropertyContainer(e), this.initModifierProperties(e, t), this.frameId = initialDefaultFrame, this.closed = false, this.k = false, this.dynamicProperties.length ? this.k = true : this.getValue(true);
    }, ShapeModifier.prototype.processKeys = function() {
      this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties());
    }, extendPrototype([DynamicPropertyContainer], ShapeModifier);
    function TrimModifier() {
    }
    extendPrototype([ShapeModifier], TrimModifier), TrimModifier.prototype.initModifierProperties = function(e, t) {
      this.s = PropertyFactory.getProp(e, t.s, 0, 0.01, this), this.e = PropertyFactory.getProp(e, t.e, 0, 0.01, this), this.o = PropertyFactory.getProp(e, t.o, 0, 0, this), this.sValue = 0, this.eValue = 0, this.getValue = this.processKeys, this.m = t.m, this._isAnimated = !!this.s.effectsSequence.length || !!this.e.effectsSequence.length || !!this.o.effectsSequence.length;
    }, TrimModifier.prototype.addShapeToModifier = function(e) {
      e.pathsData = [];
    }, TrimModifier.prototype.calculateShapeEdges = function(e, t, n, r, i) {
      var a = [];
      t <= 1 ? a.push({ s: e, e: t }) : e >= 1 ? a.push({ s: e - 1, e: t - 1 }) : (a.push({ s: e, e: 1 }), a.push({ s: 0, e: t - 1 }));
      var o = [], s, c = a.length, l;
      for (s = 0; s < c; s += 1) if (l = a[s], !(l.e * i < r || l.s * i > r + n)) {
        var u = l.s * i <= r ? 0 : (l.s * i - r) / n, d = l.e * i >= r + n ? 1 : (l.e * i - r) / n;
        o.push([u, d]);
      }
      return o.length || o.push([0, 0]), o;
    }, TrimModifier.prototype.releasePathsData = function(e) {
      var t, n = e.length;
      for (t = 0; t < n; t += 1) segmentsLengthPool.release(e[t]);
      return e.length = 0, e;
    }, TrimModifier.prototype.processShapes = function(e) {
      var t, n;
      if (this._mdf || e) {
        var r = this.o.v % 360 / 360;
        if (r < 0 && (r += 1), t = this.s.v > 1 ? 1 + r : this.s.v < 0 ? 0 + r : this.s.v + r, n = this.e.v > 1 ? 1 + r : this.e.v < 0 ? 0 + r : this.e.v + r, t > n) {
          var i = t;
          t = n, n = i;
        }
        t = Math.round(t * 1e4) * 1e-4, n = Math.round(n * 1e4) * 1e-4, this.sValue = t, this.eValue = n;
      } else t = this.sValue, n = this.eValue;
      var a, o, s = this.shapes.length, c, l, u, d, f, p = 0;
      if (n === t) for (o = 0; o < s; o += 1) this.shapes[o].localShapeCollection.releaseShapes(), this.shapes[o].shape._mdf = true, this.shapes[o].shape.paths = this.shapes[o].localShapeCollection, this._mdf && (this.shapes[o].pathsData.length = 0);
      else if (!(n === 1 && t === 0 || n === 0 && t === 1)) {
        var m = [], g, _;
        for (o = 0; o < s; o += 1) if (g = this.shapes[o], !g.shape._mdf && !this._mdf && !e && this.m !== 2) g.shape.paths = g.localShapeCollection;
        else {
          if (a = g.shape.paths, l = a._length, f = 0, !g.shape._mdf && g.pathsData.length) f = g.totalShapeLength;
          else {
            for (u = this.releasePathsData(g.pathsData), c = 0; c < l; c += 1) d = bez.getSegmentsLength(a.shapes[c]), u.push(d), f += d.totalLength;
            g.totalShapeLength = f, g.pathsData = u;
          }
          p += f, g.shape._mdf = true;
        }
        var y = t, b = n, x = 0, S;
        for (o = s - 1; o >= 0; --o) if (g = this.shapes[o], g.shape._mdf) {
          for (_ = g.localShapeCollection, _.releaseShapes(), this.m === 2 && s > 1 ? (S = this.calculateShapeEdges(t, n, g.totalShapeLength, x, p), x += g.totalShapeLength) : S = [[y, b]], l = S.length, c = 0; c < l; c += 1) {
            y = S[c][0], b = S[c][1], m.length = 0, b <= 1 ? m.push({ s: g.totalShapeLength * y, e: g.totalShapeLength * b }) : y >= 1 ? m.push({ s: g.totalShapeLength * (y - 1), e: g.totalShapeLength * (b - 1) }) : (m.push({ s: g.totalShapeLength * y, e: g.totalShapeLength }), m.push({ s: 0, e: g.totalShapeLength * (b - 1) }));
            var C = this.addShapes(g, m[0]);
            if (m[0].s !== m[0].e) {
              if (m.length > 1) {
                if (g.shape.paths.shapes[g.shape.paths._length - 1].c) {
                  var T = C.pop();
                  this.addPaths(C, _), C = this.addShapes(g, m[1], T);
                } else this.addPaths(C, _), C = this.addShapes(g, m[1]);
              }
              this.addPaths(C, _);
            }
          }
          g.shape.paths = _;
        }
      } else if (this._mdf) for (o = 0; o < s; o += 1) this.shapes[o].pathsData.length = 0, this.shapes[o].shape._mdf = true;
    }, TrimModifier.prototype.addPaths = function(e, t) {
      var n, r = e.length;
      for (n = 0; n < r; n += 1) t.addShape(e[n]);
    }, TrimModifier.prototype.addSegment = function(e, t, n, r, i, a, o) {
      i.setXYAt(t[0], t[1], `o`, a), i.setXYAt(n[0], n[1], `i`, a + 1), o && i.setXYAt(e[0], e[1], `v`, a), i.setXYAt(r[0], r[1], `v`, a + 1);
    }, TrimModifier.prototype.addSegmentFromArray = function(e, t, n, r) {
      t.setXYAt(e[1], e[5], `o`, n), t.setXYAt(e[2], e[6], `i`, n + 1), r && t.setXYAt(e[0], e[4], `v`, n), t.setXYAt(e[3], e[7], `v`, n + 1);
    }, TrimModifier.prototype.addShapes = function(e, t, n) {
      var r = e.pathsData, i = e.shape.paths.shapes, a, o = e.shape.paths._length, s, c, l = 0, u, d, f, p, m = [], g, _ = true;
      for (n ? (d = n._length, g = n._length) : (n = shapePool.newElement(), d = 0, g = 0), m.push(n), a = 0; a < o; a += 1) {
        for (f = r[a].lengths, n.c = i[a].c, c = i[a].c ? f.length : f.length + 1, s = 1; s < c; s += 1) if (u = f[s - 1], l + u.addedLength < t.s) l += u.addedLength, n.c = false;
        else if (l > t.e) {
          n.c = false;
          break;
        } else t.s <= l && t.e >= l + u.addedLength ? (this.addSegment(i[a].v[s - 1], i[a].o[s - 1], i[a].i[s], i[a].v[s], n, d, _), _ = false) : (p = bez.getNewSegment(i[a].v[s - 1], i[a].v[s], i[a].o[s - 1], i[a].i[s], (t.s - l) / u.addedLength, (t.e - l) / u.addedLength, f[s - 1]), this.addSegmentFromArray(p, n, d, _), _ = false, n.c = false), l += u.addedLength, d += 1;
        if (i[a].c && f.length) {
          if (u = f[s - 1], l <= t.e) {
            var y = f[s - 1].addedLength;
            t.s <= l && t.e >= l + y ? (this.addSegment(i[a].v[s - 1], i[a].o[s - 1], i[a].i[0], i[a].v[0], n, d, _), _ = false) : (p = bez.getNewSegment(i[a].v[s - 1], i[a].v[0], i[a].o[s - 1], i[a].i[0], (t.s - l) / y, (t.e - l) / y, f[s - 1]), this.addSegmentFromArray(p, n, d, _), _ = false, n.c = false);
          } else n.c = false;
          l += u.addedLength, d += 1;
        }
        if (n._length && (n.setXYAt(n.v[g][0], n.v[g][1], `i`, g), n.setXYAt(n.v[n._length - 1][0], n.v[n._length - 1][1], `o`, n._length - 1)), l > t.e) break;
        a < o - 1 && (n = shapePool.newElement(), _ = true, m.push(n), d = 0);
      }
      return m;
    };
    function PuckerAndBloatModifier() {
    }
    extendPrototype([ShapeModifier], PuckerAndBloatModifier), PuckerAndBloatModifier.prototype.initModifierProperties = function(e, t) {
      this.getValue = this.processKeys, this.amount = PropertyFactory.getProp(e, t.a, 0, null, this), this._isAnimated = !!this.amount.effectsSequence.length;
    }, PuckerAndBloatModifier.prototype.processPath = function(e, t) {
      var n = t / 100, r = [0, 0], i = e._length, a = 0;
      for (a = 0; a < i; a += 1) r[0] += e.v[a][0], r[1] += e.v[a][1];
      r[0] /= i, r[1] /= i;
      var o = shapePool.newElement();
      o.c = e.c;
      var s, c, l, u, d, f;
      for (a = 0; a < i; a += 1) s = e.v[a][0] + (r[0] - e.v[a][0]) * n, c = e.v[a][1] + (r[1] - e.v[a][1]) * n, l = e.o[a][0] + (r[0] - e.o[a][0]) * -n, u = e.o[a][1] + (r[1] - e.o[a][1]) * -n, d = e.i[a][0] + (r[0] - e.i[a][0]) * -n, f = e.i[a][1] + (r[1] - e.i[a][1]) * -n, o.setTripleAt(s, c, l, u, d, f, a);
      return o;
    }, PuckerAndBloatModifier.prototype.processShapes = function(e) {
      var t, n, r = this.shapes.length, i, a, o = this.amount.v;
      if (o !== 0) {
        var s, c;
        for (n = 0; n < r; n += 1) {
          if (s = this.shapes[n], c = s.localShapeCollection, s.shape._mdf || this._mdf || e) for (c.releaseShapes(), s.shape._mdf = true, t = s.shape.paths.shapes, a = s.shape.paths._length, i = 0; i < a; i += 1) c.addShape(this.processPath(t[i], o));
          s.shape.paths = s.localShapeCollection;
        }
      }
      this.dynamicProperties.length || (this._mdf = false);
    };
    var TransformPropertyFactory = (function() {
      var e = [0, 0];
      function t(e2) {
        var t2 = this._mdf;
        this.iterateDynamicProperties(), this._mdf = this._mdf || t2, this.a && e2.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.s && e2.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && e2.skewFromAxis(-this.sk.v, this.sa.v), this.r ? e2.rotate(-this.r.v) : e2.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.data.p.s ? this.data.p.z ? e2.translate(this.px.v, this.py.v, -this.pz.v) : e2.translate(this.px.v, this.py.v, 0) : e2.translate(this.p.v[0], this.p.v[1], -this.p.v[2]);
      }
      function n(t2) {
        if (this.elem.globalData.frameId !== this.frameId) {
          if (this._isDirty && (this._isDirty = (this.precalculateMatrix(), false)), this.iterateDynamicProperties(), this._mdf || t2) {
            var n2;
            if (this.v.cloneFromProps(this.pre.props), this.appliedTransformations < 1 && this.v.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations < 2 && this.v.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && this.appliedTransformations < 3 && this.v.skewFromAxis(-this.sk.v, this.sa.v), this.r && this.appliedTransformations < 4 ? this.v.rotate(-this.r.v) : !this.r && this.appliedTransformations < 4 && this.v.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.autoOriented) {
              var r2, i2;
              if (n2 = this.elem.globalData.frameRate, this.p && this.p.keyframes && this.p.getValueAtTime) this.p._caching.lastFrame + this.p.offsetTime <= this.p.keyframes[0].t ? (r2 = this.p.getValueAtTime((this.p.keyframes[0].t + 0.01) / n2, 0), i2 = this.p.getValueAtTime(this.p.keyframes[0].t / n2, 0)) : this.p._caching.lastFrame + this.p.offsetTime >= this.p.keyframes[this.p.keyframes.length - 1].t ? (r2 = this.p.getValueAtTime(this.p.keyframes[this.p.keyframes.length - 1].t / n2, 0), i2 = this.p.getValueAtTime((this.p.keyframes[this.p.keyframes.length - 1].t - 0.05) / n2, 0)) : (r2 = this.p.pv, i2 = this.p.getValueAtTime((this.p._caching.lastFrame + this.p.offsetTime - 0.01) / n2, this.p.offsetTime));
              else if (this.px && this.px.keyframes && this.py.keyframes && this.px.getValueAtTime && this.py.getValueAtTime) {
                r2 = [], i2 = [];
                var a2 = this.px, o2 = this.py;
                a2._caching.lastFrame + a2.offsetTime <= a2.keyframes[0].t ? (r2[0] = a2.getValueAtTime((a2.keyframes[0].t + 0.01) / n2, 0), r2[1] = o2.getValueAtTime((o2.keyframes[0].t + 0.01) / n2, 0), i2[0] = a2.getValueAtTime(a2.keyframes[0].t / n2, 0), i2[1] = o2.getValueAtTime(o2.keyframes[0].t / n2, 0)) : a2._caching.lastFrame + a2.offsetTime >= a2.keyframes[a2.keyframes.length - 1].t ? (r2[0] = a2.getValueAtTime(a2.keyframes[a2.keyframes.length - 1].t / n2, 0), r2[1] = o2.getValueAtTime(o2.keyframes[o2.keyframes.length - 1].t / n2, 0), i2[0] = a2.getValueAtTime((a2.keyframes[a2.keyframes.length - 1].t - 0.01) / n2, 0), i2[1] = o2.getValueAtTime((o2.keyframes[o2.keyframes.length - 1].t - 0.01) / n2, 0)) : (r2 = [a2.pv, o2.pv], i2[0] = a2.getValueAtTime((a2._caching.lastFrame + a2.offsetTime - 0.01) / n2, a2.offsetTime), i2[1] = o2.getValueAtTime((o2._caching.lastFrame + o2.offsetTime - 0.01) / n2, o2.offsetTime));
              } else i2 = e, r2 = i2;
              this.v.rotate(-Math.atan2(r2[1] - i2[1], r2[0] - i2[0]));
            }
            this.data.p && this.data.p.s ? this.data.p.z ? this.v.translate(this.px.v, this.py.v, -this.pz.v) : this.v.translate(this.px.v, this.py.v, 0) : this.v.translate(this.p.v[0], this.p.v[1], -this.p.v[2]);
          }
          this.frameId = this.elem.globalData.frameId;
        }
      }
      function r() {
        if (this.appliedTransformations = 0, this.pre.reset(), !this.a.effectsSequence.length) this.pre.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations = 1;
        else return;
        if (!this.s.effectsSequence.length) this.pre.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.appliedTransformations = 2;
        else return;
        if (this.sk) {
          if (!this.sk.effectsSequence.length && !this.sa.effectsSequence.length) this.pre.skewFromAxis(-this.sk.v, this.sa.v), this.appliedTransformations = 3;
          else return;
        }
        this.r ? this.r.effectsSequence.length || (this.pre.rotate(-this.r.v), this.appliedTransformations = 4) : !this.rz.effectsSequence.length && !this.ry.effectsSequence.length && !this.rx.effectsSequence.length && !this.or.effectsSequence.length && (this.pre.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.appliedTransformations = 4);
      }
      function i() {
      }
      function a(e2) {
        this._addDynamicProperty(e2), this.elem.addDynamicProperty(e2), this._isDirty = true;
      }
      function o(e2, t2, n2) {
        if (this.elem = e2, this.frameId = -1, this.propType = `transform`, this.data = t2, this.v = new Matrix(), this.pre = new Matrix(), this.appliedTransformations = 0, this.initDynamicPropertyContainer(n2 || e2), t2.p && t2.p.s ? (this.px = PropertyFactory.getProp(e2, t2.p.x, 0, 0, this), this.py = PropertyFactory.getProp(e2, t2.p.y, 0, 0, this), t2.p.z && (this.pz = PropertyFactory.getProp(e2, t2.p.z, 0, 0, this))) : this.p = PropertyFactory.getProp(e2, t2.p || { k: [0, 0, 0] }, 1, 0, this), t2.rx) {
          if (this.rx = PropertyFactory.getProp(e2, t2.rx, 0, degToRads, this), this.ry = PropertyFactory.getProp(e2, t2.ry, 0, degToRads, this), this.rz = PropertyFactory.getProp(e2, t2.rz, 0, degToRads, this), t2.or.k[0].ti) {
            var r2, i2 = t2.or.k.length;
            for (r2 = 0; r2 < i2; r2 += 1) t2.or.k[r2].to = null, t2.or.k[r2].ti = null;
          }
          this.or = PropertyFactory.getProp(e2, t2.or, 1, degToRads, this), this.or.sh = true;
        } else this.r = PropertyFactory.getProp(e2, t2.r || { k: 0 }, 0, degToRads, this);
        t2.sk && (this.sk = PropertyFactory.getProp(e2, t2.sk, 0, degToRads, this), this.sa = PropertyFactory.getProp(e2, t2.sa, 0, degToRads, this)), this.a = PropertyFactory.getProp(e2, t2.a || { k: [0, 0, 0] }, 1, 0, this), this.s = PropertyFactory.getProp(e2, t2.s || { k: [100, 100, 100] }, 1, 0.01, this), this.o = t2.o ? PropertyFactory.getProp(e2, t2.o, 0, 0.01, e2) : { _mdf: false, v: 1 }, this._isDirty = true, this.dynamicProperties.length || this.getValue(true);
      }
      o.prototype = { applyToMatrix: t, getValue: n, precalculateMatrix: r, autoOrient: i }, extendPrototype([DynamicPropertyContainer], o), o.prototype.addDynamicProperty = a, o.prototype._addDynamicProperty = DynamicPropertyContainer.prototype.addDynamicProperty;
      function s(e2, t2, n2) {
        return new o(e2, t2, n2);
      }
      return { getTransformProperty: s };
    })();
    function RepeaterModifier() {
    }
    extendPrototype([ShapeModifier], RepeaterModifier), RepeaterModifier.prototype.initModifierProperties = function(e, t) {
      this.getValue = this.processKeys, this.c = PropertyFactory.getProp(e, t.c, 0, null, this), this.o = PropertyFactory.getProp(e, t.o, 0, null, this), this.tr = TransformPropertyFactory.getTransformProperty(e, t.tr, this), this.so = PropertyFactory.getProp(e, t.tr.so, 0, 0.01, this), this.eo = PropertyFactory.getProp(e, t.tr.eo, 0, 0.01, this), this.data = t, this.dynamicProperties.length || this.getValue(true), this._isAnimated = !!this.dynamicProperties.length, this.pMatrix = new Matrix(), this.rMatrix = new Matrix(), this.sMatrix = new Matrix(), this.tMatrix = new Matrix(), this.matrix = new Matrix();
    }, RepeaterModifier.prototype.applyTransforms = function(e, t, n, r, i, a) {
      var o = a ? -1 : 1, s = r.s.v[0] + (1 - r.s.v[0]) * (1 - i), c = r.s.v[1] + (1 - r.s.v[1]) * (1 - i);
      e.translate(r.p.v[0] * o * i, r.p.v[1] * o * i, r.p.v[2]), t.translate(-r.a.v[0], -r.a.v[1], r.a.v[2]), t.rotate(-r.r.v * o * i), t.translate(r.a.v[0], r.a.v[1], r.a.v[2]), n.translate(-r.a.v[0], -r.a.v[1], r.a.v[2]), n.scale(a ? 1 / s : s, a ? 1 / c : c), n.translate(r.a.v[0], r.a.v[1], r.a.v[2]);
    }, RepeaterModifier.prototype.init = function(e, t, n, r) {
      for (this.elem = e, this.arr = t, this.pos = n, this.elemsData = r, this._currentCopies = 0, this._elements = [], this._groups = [], this.frameId = -1, this.initDynamicPropertyContainer(e), this.initModifierProperties(e, t[n]); n > 0; ) --n, this._elements.unshift(t[n]);
      this.dynamicProperties.length ? this.k = true : this.getValue(true);
    }, RepeaterModifier.prototype.resetElements = function(e) {
      var t, n = e.length;
      for (t = 0; t < n; t += 1) e[t]._processed = false, e[t].ty === `gr` && this.resetElements(e[t].it);
    }, RepeaterModifier.prototype.cloneElements = function(e) {
      var t = JSON.parse(JSON.stringify(e));
      return this.resetElements(t), t;
    }, RepeaterModifier.prototype.changeGroupRender = function(e, t) {
      var n, r = e.length;
      for (n = 0; n < r; n += 1) e[n]._render = t, e[n].ty === `gr` && this.changeGroupRender(e[n].it, t);
    }, RepeaterModifier.prototype.processShapes = function(e) {
      var t, n, r, i, a, o = false;
      if (this._mdf || e) {
        var s = Math.ceil(this.c.v);
        if (this._groups.length < s) {
          for (; this._groups.length < s; ) {
            var c = { it: this.cloneElements(this._elements), ty: `gr` };
            c.it.push({ a: { a: 0, ix: 1, k: [0, 0] }, nm: `Transform`, o: { a: 0, ix: 7, k: 100 }, p: { a: 0, ix: 2, k: [0, 0] }, r: { a: 1, ix: 6, k: [{ s: 0, e: 0, t: 0 }, { s: 0, e: 0, t: 1 }] }, s: { a: 0, ix: 3, k: [100, 100] }, sa: { a: 0, ix: 5, k: 0 }, sk: { a: 0, ix: 4, k: 0 }, ty: `tr` }), this.arr.splice(0, 0, c), this._groups.splice(0, 0, c), this._currentCopies += 1;
          }
          this.elem.reloadShapes(), o = true;
        }
        a = 0;
        var l;
        for (r = 0; r <= this._groups.length - 1; r += 1) {
          if (l = a < s, this._groups[r]._render = l, this.changeGroupRender(this._groups[r].it, l), !l) {
            var u = this.elemsData[r].it, d = u[u.length - 1];
            d.transform.op.v === 0 ? d.transform.op._mdf = false : (d.transform.op._mdf = true, d.transform.op.v = 0);
          }
          a += 1;
        }
        this._currentCopies = s;
        var f = this.o.v, p = f % 1, m = f > 0 ? Math.floor(f) : Math.ceil(f), g = this.pMatrix.props, _ = this.rMatrix.props, y = this.sMatrix.props;
        this.pMatrix.reset(), this.rMatrix.reset(), this.sMatrix.reset(), this.tMatrix.reset(), this.matrix.reset();
        var b = 0;
        if (f > 0) {
          for (; b < m; ) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, false), b += 1;
          p && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, p, false), b += p);
        } else if (f < 0) {
          for (; b > m; ) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, true), --b;
          p && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, -p, true), b -= p);
        }
        r = this.data.m === 1 ? 0 : this._currentCopies - 1, i = this.data.m === 1 ? 1 : -1, a = this._currentCopies;
        for (var x, S; a; ) {
          if (t = this.elemsData[r].it, n = t[t.length - 1].transform.mProps.v.props, S = n.length, t[t.length - 1].transform.mProps._mdf = true, t[t.length - 1].transform.op._mdf = true, t[t.length - 1].transform.op.v = this._currentCopies === 1 ? this.so.v : this.so.v + (this.eo.v - this.so.v) * (r / (this._currentCopies - 1)), b !== 0) {
            for ((r !== 0 && i === 1 || r !== this._currentCopies - 1 && i === -1) && this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, false), this.matrix.transform(_[0], _[1], _[2], _[3], _[4], _[5], _[6], _[7], _[8], _[9], _[10], _[11], _[12], _[13], _[14], _[15]), this.matrix.transform(y[0], y[1], y[2], y[3], y[4], y[5], y[6], y[7], y[8], y[9], y[10], y[11], y[12], y[13], y[14], y[15]), this.matrix.transform(g[0], g[1], g[2], g[3], g[4], g[5], g[6], g[7], g[8], g[9], g[10], g[11], g[12], g[13], g[14], g[15]), x = 0; x < S; x += 1) n[x] = this.matrix.props[x];
            this.matrix.reset();
          } else for (this.matrix.reset(), x = 0; x < S; x += 1) n[x] = this.matrix.props[x];
          b += 1, --a, r += i;
        }
      } else for (a = this._currentCopies, r = 0, i = 1; a; ) t = this.elemsData[r].it, n = t[t.length - 1].transform.mProps.v.props, t[t.length - 1].transform.mProps._mdf = false, t[t.length - 1].transform.op._mdf = false, --a, r += i;
      return o;
    }, RepeaterModifier.prototype.addShape = function() {
    };
    function RoundCornersModifier() {
    }
    extendPrototype([ShapeModifier], RoundCornersModifier), RoundCornersModifier.prototype.initModifierProperties = function(e, t) {
      this.getValue = this.processKeys, this.rd = PropertyFactory.getProp(e, t.r, 0, null, this), this._isAnimated = !!this.rd.effectsSequence.length;
    }, RoundCornersModifier.prototype.processPath = function(e, t) {
      var n = shapePool.newElement();
      n.c = e.c;
      var r, i = e._length, a, o, s, c, l, u, d = 0, f, p, m, g, _, y;
      for (r = 0; r < i; r += 1) a = e.v[r], s = e.o[r], o = e.i[r], a[0] === s[0] && a[1] === s[1] && a[0] === o[0] && a[1] === o[1] ? (r === 0 || r === i - 1) && !e.c ? (n.setTripleAt(a[0], a[1], s[0], s[1], o[0], o[1], d), d += 1) : (c = r === 0 ? e.v[i - 1] : e.v[r - 1], l = Math.sqrt((a[0] - c[0]) ** 2 + (a[1] - c[1]) ** 2), u = l ? Math.min(l / 2, t) / l : 0, _ = a[0] + (c[0] - a[0]) * u, f = _, y = a[1] - (a[1] - c[1]) * u, p = y, m = f - (f - a[0]) * roundCorner, g = p - (p - a[1]) * roundCorner, n.setTripleAt(f, p, m, g, _, y, d), d += 1, c = r === i - 1 ? e.v[0] : e.v[r + 1], l = Math.sqrt((a[0] - c[0]) ** 2 + (a[1] - c[1]) ** 2), u = l ? Math.min(l / 2, t) / l : 0, m = a[0] + (c[0] - a[0]) * u, f = m, g = a[1] + (c[1] - a[1]) * u, p = g, _ = f - (f - a[0]) * roundCorner, y = p - (p - a[1]) * roundCorner, n.setTripleAt(f, p, m, g, _, y, d), d += 1) : (n.setTripleAt(e.v[r][0], e.v[r][1], e.o[r][0], e.o[r][1], e.i[r][0], e.i[r][1], d), d += 1);
      return n;
    }, RoundCornersModifier.prototype.processShapes = function(e) {
      var t, n, r = this.shapes.length, i, a, o = this.rd.v;
      if (o !== 0) {
        var s, c;
        for (n = 0; n < r; n += 1) {
          if (s = this.shapes[n], c = s.localShapeCollection, s.shape._mdf || this._mdf || e) for (c.releaseShapes(), s.shape._mdf = true, t = s.shape.paths.shapes, a = s.shape.paths._length, i = 0; i < a; i += 1) c.addShape(this.processPath(t[i], o));
          s.shape.paths = s.localShapeCollection;
        }
      }
      this.dynamicProperties.length || (this._mdf = false);
    };
    function floatEqual(e, t) {
      return Math.abs(e - t) * 1e5 <= Math.min(Math.abs(e), Math.abs(t));
    }
    function floatZero(e) {
      return Math.abs(e) <= 1e-5;
    }
    function lerp(e, t, n) {
      return e * (1 - n) + t * n;
    }
    function lerpPoint(e, t, n) {
      return [lerp(e[0], t[0], n), lerp(e[1], t[1], n)];
    }
    function quadRoots(e, t, n) {
      if (e === 0) return [];
      var r = t * t - 4 * e * n;
      if (r < 0) return [];
      var i = -t / (2 * e);
      if (r === 0) return [i];
      var a = Math.sqrt(r) / (2 * e);
      return [i - a, i + a];
    }
    function polynomialCoefficients(e, t, n, r) {
      return [-e + 3 * t - 3 * n + r, 3 * e - 6 * t + 3 * n, -3 * e + 3 * t, e];
    }
    function singlePoint(e) {
      return new PolynomialBezier(e, e, e, e, false);
    }
    function PolynomialBezier(e, t, n, r, i) {
      i && pointEqual(e, t) && (t = lerpPoint(e, r, 1 / 3)), i && pointEqual(n, r) && (n = lerpPoint(e, r, 2 / 3));
      var a = polynomialCoefficients(e[0], t[0], n[0], r[0]), o = polynomialCoefficients(e[1], t[1], n[1], r[1]);
      this.a = [a[0], o[0]], this.b = [a[1], o[1]], this.c = [a[2], o[2]], this.d = [a[3], o[3]], this.points = [e, t, n, r];
    }
    PolynomialBezier.prototype.point = function(e) {
      return [((this.a[0] * e + this.b[0]) * e + this.c[0]) * e + this.d[0], ((this.a[1] * e + this.b[1]) * e + this.c[1]) * e + this.d[1]];
    }, PolynomialBezier.prototype.derivative = function(e) {
      return [(3 * e * this.a[0] + 2 * this.b[0]) * e + this.c[0], (3 * e * this.a[1] + 2 * this.b[1]) * e + this.c[1]];
    }, PolynomialBezier.prototype.tangentAngle = function(e) {
      var t = this.derivative(e);
      return Math.atan2(t[1], t[0]);
    }, PolynomialBezier.prototype.normalAngle = function(e) {
      var t = this.derivative(e);
      return Math.atan2(t[0], t[1]);
    }, PolynomialBezier.prototype.inflectionPoints = function() {
      var e = this.a[1] * this.b[0] - this.a[0] * this.b[1];
      if (floatZero(e)) return [];
      var t = -0.5 * (this.a[1] * this.c[0] - this.a[0] * this.c[1]) / e, n = t * t - 1 / 3 * (this.b[1] * this.c[0] - this.b[0] * this.c[1]) / e;
      if (n < 0) return [];
      var r = Math.sqrt(n);
      return floatZero(r) ? r > 0 && r < 1 ? [t] : [] : [t - r, t + r].filter(function(e2) {
        return e2 > 0 && e2 < 1;
      });
    }, PolynomialBezier.prototype.split = function(e) {
      if (e <= 0) return [singlePoint(this.points[0]), this];
      if (e >= 1) return [this, singlePoint(this.points[this.points.length - 1])];
      var t = lerpPoint(this.points[0], this.points[1], e), n = lerpPoint(this.points[1], this.points[2], e), r = lerpPoint(this.points[2], this.points[3], e), i = lerpPoint(t, n, e), a = lerpPoint(n, r, e), o = lerpPoint(i, a, e);
      return [new PolynomialBezier(this.points[0], t, i, o, true), new PolynomialBezier(o, a, r, this.points[3], true)];
    };
    function extrema(e, t) {
      var n = e.points[0][t], r = e.points[e.points.length - 1][t];
      if (n > r) {
        var i = r;
        r = n, n = i;
      }
      for (var a = quadRoots(3 * e.a[t], 2 * e.b[t], e.c[t]), o = 0; o < a.length; o += 1) if (a[o] > 0 && a[o] < 1) {
        var s = e.point(a[o])[t];
        s < n ? n = s : s > r && (r = s);
      }
      return { min: n, max: r };
    }
    PolynomialBezier.prototype.bounds = function() {
      return { x: extrema(this, 0), y: extrema(this, 1) };
    }, PolynomialBezier.prototype.boundingBox = function() {
      var e = this.bounds();
      return { left: e.x.min, right: e.x.max, top: e.y.min, bottom: e.y.max, width: e.x.max - e.x.min, height: e.y.max - e.y.min, cx: (e.x.max + e.x.min) / 2, cy: (e.y.max + e.y.min) / 2 };
    };
    function intersectData(e, t, n) {
      var r = e.boundingBox();
      return { cx: r.cx, cy: r.cy, width: r.width, height: r.height, bez: e, t: (t + n) / 2, t1: t, t2: n };
    }
    function splitData(e) {
      var t = e.bez.split(0.5);
      return [intersectData(t[0], e.t1, e.t), intersectData(t[1], e.t, e.t2)];
    }
    function boxIntersect(e, t) {
      return Math.abs(e.cx - t.cx) * 2 < e.width + t.width && Math.abs(e.cy - t.cy) * 2 < e.height + t.height;
    }
    function intersectsImpl(e, t, n, r, i, a) {
      if (boxIntersect(e, t)) {
        if (n >= a || e.width <= r && e.height <= r && t.width <= r && t.height <= r) {
          i.push([e.t, t.t]);
          return;
        }
        var o = splitData(e), s = splitData(t);
        intersectsImpl(o[0], s[0], n + 1, r, i, a), intersectsImpl(o[0], s[1], n + 1, r, i, a), intersectsImpl(o[1], s[0], n + 1, r, i, a), intersectsImpl(o[1], s[1], n + 1, r, i, a);
      }
    }
    PolynomialBezier.prototype.intersections = function(e, t, n) {
      t === void 0 && (t = 2), n === void 0 && (n = 7);
      var r = [];
      return intersectsImpl(intersectData(this, 0, 1), intersectData(e, 0, 1), 0, t, r, n), r;
    }, PolynomialBezier.shapeSegment = function(e, t) {
      var n = (t + 1) % e.length();
      return new PolynomialBezier(e.v[t], e.o[t], e.i[n], e.v[n], true);
    }, PolynomialBezier.shapeSegmentInverted = function(e, t) {
      var n = (t + 1) % e.length();
      return new PolynomialBezier(e.v[n], e.i[n], e.o[t], e.v[t], true);
    };
    function crossProduct(e, t) {
      return [e[1] * t[2] - e[2] * t[1], e[2] * t[0] - e[0] * t[2], e[0] * t[1] - e[1] * t[0]];
    }
    function lineIntersection(e, t, n, r) {
      var i = [e[0], e[1], 1], a = [t[0], t[1], 1], o = [n[0], n[1], 1], s = [r[0], r[1], 1], c = crossProduct(crossProduct(i, a), crossProduct(o, s));
      return floatZero(c[2]) ? null : [c[0] / c[2], c[1] / c[2]];
    }
    function polarOffset(e, t, n) {
      return [e[0] + Math.cos(t) * n, e[1] - Math.sin(t) * n];
    }
    function pointDistance(e, t) {
      return Math.hypot(e[0] - t[0], e[1] - t[1]);
    }
    function pointEqual(e, t) {
      return floatEqual(e[0], t[0]) && floatEqual(e[1], t[1]);
    }
    function ZigZagModifier() {
    }
    extendPrototype([ShapeModifier], ZigZagModifier), ZigZagModifier.prototype.initModifierProperties = function(e, t) {
      this.getValue = this.processKeys, this.amplitude = PropertyFactory.getProp(e, t.s, 0, null, this), this.frequency = PropertyFactory.getProp(e, t.r, 0, null, this), this.pointsType = PropertyFactory.getProp(e, t.pt, 0, null, this), this._isAnimated = this.amplitude.effectsSequence.length !== 0 || this.frequency.effectsSequence.length !== 0 || this.pointsType.effectsSequence.length !== 0;
    };
    function setPoint(e, t, n, r, i, a, o) {
      var s = n - Math.PI / 2, c = n + Math.PI / 2, l = t[0] + Math.cos(n) * r * i, u = t[1] - Math.sin(n) * r * i;
      e.setTripleAt(l, u, l + Math.cos(s) * a, u - Math.sin(s) * a, l + Math.cos(c) * o, u - Math.sin(c) * o, e.length());
    }
    function getPerpendicularVector(e, t) {
      var n = [t[0] - e[0], t[1] - e[1]], r = -Math.PI * 0.5;
      return [Math.cos(r) * n[0] - Math.sin(r) * n[1], Math.sin(r) * n[0] + Math.cos(r) * n[1]];
    }
    function getProjectingAngle(e, t) {
      var n = t === 0 ? e.length() - 1 : t - 1, r = (t + 1) % e.length(), i = e.v[n], a = e.v[r], o = getPerpendicularVector(i, a);
      return Math.atan2(0, 1) - Math.atan2(o[1], o[0]);
    }
    function zigZagCorner(e, t, n, r, i, a, o) {
      var s = getProjectingAngle(t, n), c = t.v[n % t._length], l = t.v[n === 0 ? t._length - 1 : n - 1], u = t.v[(n + 1) % t._length], d = a === 2 ? Math.sqrt((c[0] - l[0]) ** 2 + (c[1] - l[1]) ** 2) : 0, f = a === 2 ? Math.sqrt((c[0] - u[0]) ** 2 + (c[1] - u[1]) ** 2) : 0;
      setPoint(e, t.v[n % t._length], s, o, r, f / ((i + 1) * 2), d / ((i + 1) * 2), a);
    }
    function zigZagSegment(e, t, n, r, i, a) {
      for (var o = 0; o < r; o += 1) {
        var s = (o + 1) / (r + 1), c = i === 2 ? Math.sqrt((t.points[3][0] - t.points[0][0]) ** 2 + (t.points[3][1] - t.points[0][1]) ** 2) : 0, l = t.normalAngle(s);
        setPoint(e, t.point(s), l, a, n, c / ((r + 1) * 2), c / ((r + 1) * 2), i), a = -a;
      }
      return a;
    }
    ZigZagModifier.prototype.processPath = function(e, t, n, r) {
      var i = e._length, a = shapePool.newElement();
      if (a.c = e.c, e.c || --i, i === 0) return a;
      var o = -1, s = PolynomialBezier.shapeSegment(e, 0);
      zigZagCorner(a, e, 0, t, n, r, o);
      for (var c = 0; c < i; c += 1) o = zigZagSegment(a, s, t, n, r, -o), s = c === i - 1 && !e.c ? null : PolynomialBezier.shapeSegment(e, (c + 1) % i), zigZagCorner(a, e, c + 1, t, n, r, o);
      return a;
    }, ZigZagModifier.prototype.processShapes = function(e) {
      var t, n, r = this.shapes.length, i, a, o = this.amplitude.v, s = Math.max(0, Math.round(this.frequency.v)), c = this.pointsType.v;
      if (o !== 0) {
        var l, u;
        for (n = 0; n < r; n += 1) {
          if (l = this.shapes[n], u = l.localShapeCollection, l.shape._mdf || this._mdf || e) for (u.releaseShapes(), l.shape._mdf = true, t = l.shape.paths.shapes, a = l.shape.paths._length, i = 0; i < a; i += 1) u.addShape(this.processPath(t[i], o, s, c));
          l.shape.paths = l.localShapeCollection;
        }
      }
      this.dynamicProperties.length || (this._mdf = false);
    };
    function linearOffset(e, t, n) {
      var r = Math.atan2(t[0] - e[0], t[1] - e[1]);
      return [polarOffset(e, r, n), polarOffset(t, r, n)];
    }
    function offsetSegment(e, t) {
      var n, r, i, a, o, s, c = linearOffset(e.points[0], e.points[1], t);
      n = c[0], r = c[1], c = linearOffset(e.points[1], e.points[2], t), i = c[0], a = c[1], c = linearOffset(e.points[2], e.points[3], t), o = c[0], s = c[1];
      var l = lineIntersection(n, r, i, a);
      l === null && (l = r);
      var u = lineIntersection(o, s, i, a);
      return u === null && (u = o), new PolynomialBezier(n, l, u, s);
    }
    function joinLines(e, t, n, r, i) {
      var a = t.points[3], o = n.points[0];
      if (r === 3 || pointEqual(a, o)) return a;
      if (r === 2) {
        var s = -t.tangentAngle(1), c = -n.tangentAngle(0) + Math.PI, l = lineIntersection(a, polarOffset(a, s + Math.PI / 2, 100), o, polarOffset(o, s + Math.PI / 2, 100)), u = l ? pointDistance(l, a) : pointDistance(a, o) / 2, d = polarOffset(a, s, 2 * u * roundCorner);
        return e.setXYAt(d[0], d[1], `o`, e.length() - 1), d = polarOffset(o, c, 2 * u * roundCorner), e.setTripleAt(o[0], o[1], o[0], o[1], d[0], d[1], e.length()), o;
      }
      var f = lineIntersection(pointEqual(a, t.points[2]) ? t.points[0] : t.points[2], a, o, pointEqual(o, n.points[1]) ? n.points[3] : n.points[1]);
      return f && pointDistance(f, a) < i ? (e.setTripleAt(f[0], f[1], f[0], f[1], f[0], f[1], e.length()), f) : a;
    }
    function getIntersection(e, t) {
      var n = e.intersections(t);
      return n.length && floatEqual(n[0][0], 1) && n.shift(), n.length ? n[0] : null;
    }
    function pruneSegmentIntersection(e, t) {
      var n = e.slice(), r = t.slice(), i = getIntersection(e[e.length - 1], t[0]);
      return i && (n[e.length - 1] = e[e.length - 1].split(i[0])[0], r[0] = t[0].split(i[1])[1]), e.length > 1 && t.length > 1 && (i = getIntersection(e[0], t[t.length - 1]), i) ? [[e[0].split(i[0])[0]], [t[t.length - 1].split(i[1])[1]]] : [n, r];
    }
    function pruneIntersections(e) {
      for (var t, n = 1; n < e.length; n += 1) t = pruneSegmentIntersection(e[n - 1], e[n]), e[n - 1] = t[0], e[n] = t[1];
      return e.length > 1 && (t = pruneSegmentIntersection(e[e.length - 1], e[0]), e[e.length - 1] = t[0], e[0] = t[1]), e;
    }
    function offsetSegmentSplit(e, t) {
      var n = e.inflectionPoints(), r, i, a, o;
      if (n.length === 0) return [offsetSegment(e, t)];
      if (n.length === 1 || floatEqual(n[1], 1)) return a = e.split(n[0]), r = a[0], i = a[1], [offsetSegment(r, t), offsetSegment(i, t)];
      a = e.split(n[0]), r = a[0];
      var s = (n[1] - n[0]) / (1 - n[0]);
      return a = a[1].split(s), o = a[0], i = a[1], [offsetSegment(r, t), offsetSegment(o, t), offsetSegment(i, t)];
    }
    function OffsetPathModifier() {
    }
    extendPrototype([ShapeModifier], OffsetPathModifier), OffsetPathModifier.prototype.initModifierProperties = function(e, t) {
      this.getValue = this.processKeys, this.amount = PropertyFactory.getProp(e, t.a, 0, null, this), this.miterLimit = PropertyFactory.getProp(e, t.ml, 0, null, this), this.lineJoin = t.lj, this._isAnimated = this.amount.effectsSequence.length !== 0;
    }, OffsetPathModifier.prototype.processPath = function(e, t, n, r) {
      var i = shapePool.newElement();
      i.c = e.c;
      var a = e.length();
      e.c || --a;
      var o, s, c, l = [];
      for (o = 0; o < a; o += 1) c = PolynomialBezier.shapeSegment(e, o), l.push(offsetSegmentSplit(c, t));
      if (!e.c) for (o = a - 1; o >= 0; --o) c = PolynomialBezier.shapeSegmentInverted(e, o), l.push(offsetSegmentSplit(c, t));
      l = pruneIntersections(l);
      var u = null, d = null;
      for (o = 0; o < l.length; o += 1) {
        var f = l[o];
        for (d && (u = joinLines(i, d, f[0], n, r)), d = f[f.length - 1], s = 0; s < f.length; s += 1) c = f[s], u && pointEqual(c.points[0], u) ? i.setXYAt(c.points[1][0], c.points[1][1], `o`, i.length() - 1) : i.setTripleAt(c.points[0][0], c.points[0][1], c.points[1][0], c.points[1][1], c.points[0][0], c.points[0][1], i.length()), i.setTripleAt(c.points[3][0], c.points[3][1], c.points[3][0], c.points[3][1], c.points[2][0], c.points[2][1], i.length()), u = c.points[3];
      }
      return l.length && joinLines(i, d, l[0][0], n, r), i;
    }, OffsetPathModifier.prototype.processShapes = function(e) {
      var t, n, r = this.shapes.length, i, a, o = this.amount.v, s = this.miterLimit.v, c = this.lineJoin;
      if (o !== 0) {
        var l, u;
        for (n = 0; n < r; n += 1) {
          if (l = this.shapes[n], u = l.localShapeCollection, l.shape._mdf || this._mdf || e) for (u.releaseShapes(), l.shape._mdf = true, t = l.shape.paths.shapes, a = l.shape.paths._length, i = 0; i < a; i += 1) u.addShape(this.processPath(t[i], o, c, s));
          l.shape.paths = l.localShapeCollection;
        }
      }
      this.dynamicProperties.length || (this._mdf = false);
    };
    function getFontProperties(e) {
      for (var t = e.fStyle ? e.fStyle.split(` `) : [], n = `normal`, r = `normal`, i = t.length, a, o = 0; o < i; o += 1) switch (a = t[o].toLowerCase(), a) {
        case `italic`:
          r = `italic`;
          break;
        case `bold`:
          n = `700`;
          break;
        case `black`:
          n = `900`;
          break;
        case `medium`:
          n = `500`;
          break;
        case `regular`:
        case `normal`:
          n = `400`;
          break;
        case `light`:
        case `thin`:
          n = `200`;
      }
      return { style: r, weight: e.fWeight || n };
    }
    var FontManager = (function() {
      var e = 5e3, t = { w: 0, size: 0, shapes: [], data: { shapes: [] } }, n = [];
      n = n.concat([2304, 2305, 2306, 2307, 2362, 2363, 2364, 2364, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2387, 2388, 2389, 2390, 2391, 2402, 2403]);
      var r = 127988, i = 917631, a = 917601, o = 917626, s = 65039, c = 8205, l = 127462, u = 127487, d = [`d83cdffb`, `d83cdffc`, `d83cdffd`, `d83cdffe`, `d83cdfff`];
      function f(e2) {
        var t2 = e2.split(`,`), n2, r2 = t2.length, i2 = [];
        for (n2 = 0; n2 < r2; n2 += 1) t2[n2] !== `sans-serif` && t2[n2] !== `monospace` && i2.push(t2[n2]);
        return i2.join(`,`);
      }
      function p(e2, t2) {
        var n2 = createTag(`span`);
        n2.setAttribute(`aria-hidden`, true), n2.style.fontFamily = t2;
        var r2 = createTag(`span`);
        r2.innerText = `giItT1WQy@!-/#`, n2.style.position = `absolute`, n2.style.left = `-10000px`, n2.style.top = `-10000px`, n2.style.fontSize = `300px`, n2.style.fontVariant = `normal`, n2.style.fontStyle = `normal`, n2.style.fontWeight = `normal`, n2.style.letterSpacing = `0`, n2.appendChild(r2), document.body.appendChild(n2);
        var i2 = r2.offsetWidth;
        return r2.style.fontFamily = f(e2) + `, ` + t2, { node: r2, w: i2, parent: n2 };
      }
      function m() {
        var e2, t2 = this.fonts.length, n2, r2, i2 = t2;
        for (e2 = 0; e2 < t2; e2 += 1) this.fonts[e2].loaded ? --i2 : this.fonts[e2].fOrigin === `n` || this.fonts[e2].origin === 0 ? this.fonts[e2].loaded = true : (n2 = this.fonts[e2].monoCase.node, r2 = this.fonts[e2].monoCase.w, n2.offsetWidth === r2 ? (n2 = this.fonts[e2].sansCase.node, r2 = this.fonts[e2].sansCase.w, n2.offsetWidth !== r2 && (--i2, this.fonts[e2].loaded = true)) : (--i2, this.fonts[e2].loaded = true), this.fonts[e2].loaded && (this.fonts[e2].sansCase.parent.parentNode.removeChild(this.fonts[e2].sansCase.parent), this.fonts[e2].monoCase.parent.parentNode.removeChild(this.fonts[e2].monoCase.parent)));
        i2 !== 0 && Date.now() - this.initTime < 5e3 ? setTimeout(this.checkLoadedFontsBinded, 20) : setTimeout(this.setIsLoadedBinded, 10);
      }
      function g(e2, t2) {
        var n2 = document.body && t2 ? `svg` : `canvas`, r2, i2 = getFontProperties(e2);
        if (n2 === `svg`) {
          var a2 = createNS(`text`);
          a2.style.fontSize = `100px`, a2.setAttribute(`font-family`, e2.fFamily), a2.setAttribute(`font-style`, i2.style), a2.setAttribute(`font-weight`, i2.weight), a2.textContent = `1`, e2.fClass ? (a2.style.fontFamily = `inherit`, a2.setAttribute(`class`, e2.fClass)) : a2.style.fontFamily = e2.fFamily, t2.appendChild(a2), r2 = a2;
        } else {
          var o2 = new OffscreenCanvas(500, 500).getContext(`2d`);
          o2.font = i2.style + ` ` + i2.weight + ` 100px ` + e2.fFamily, r2 = o2;
        }
        function s2(e3) {
          return n2 === `svg` ? (r2.textContent = e3, r2.getComputedTextLength()) : r2.measureText(e3).width;
        }
        return { measureText: s2 };
      }
      function _(e2, t2) {
        if (!e2) {
          this.isLoaded = true;
          return;
        }
        if (this.chars) {
          this.isLoaded = true, this.fonts = e2.list;
          return;
        }
        if (!document.body) {
          this.isLoaded = true, e2.list.forEach(function(e3) {
            e3.helper = g(e3), e3.cache = {};
          }), this.fonts = e2.list;
          return;
        }
        var n2 = e2.list, r2, i2 = n2.length, a2 = i2;
        for (r2 = 0; r2 < i2; r2 += 1) {
          var o2 = true, s2, c2;
          if (n2[r2].loaded = false, n2[r2].monoCase = p(n2[r2].fFamily, `monospace`), n2[r2].sansCase = p(n2[r2].fFamily, `sans-serif`), !n2[r2].fPath) n2[r2].loaded = true, --a2;
          else if (n2[r2].fOrigin === `p` || n2[r2].origin === 3) {
            if (s2 = document.querySelectorAll(`style[f-forigin="p"][f-family="` + n2[r2].fFamily + `"], style[f-origin="3"][f-family="` + n2[r2].fFamily + `"]`), s2.length > 0 && (o2 = false), o2) {
              var l2 = createTag(`style`);
              l2.setAttribute(`f-forigin`, n2[r2].fOrigin), l2.setAttribute(`f-origin`, n2[r2].origin), l2.setAttribute(`f-family`, n2[r2].fFamily), l2.type = `text/css`, l2.innerText = `@font-face {font-family: ` + n2[r2].fFamily + `; font-style: normal; src: url('` + n2[r2].fPath + `');}`, t2.appendChild(l2);
            }
          } else if (n2[r2].fOrigin === `g` || n2[r2].origin === 1) {
            for (s2 = document.querySelectorAll(`link[f-forigin="g"], link[f-origin="1"]`), c2 = 0; c2 < s2.length; c2 += 1) s2[c2].href.indexOf(n2[r2].fPath) !== -1 && (o2 = false);
            if (o2) {
              var u2 = createTag(`link`);
              u2.setAttribute(`f-forigin`, n2[r2].fOrigin), u2.setAttribute(`f-origin`, n2[r2].origin), u2.type = `text/css`, u2.rel = `stylesheet`, u2.href = n2[r2].fPath, document.body.appendChild(u2);
            }
          } else if (n2[r2].fOrigin === `t` || n2[r2].origin === 2) {
            for (s2 = document.querySelectorAll(`script[f-forigin="t"], script[f-origin="2"]`), c2 = 0; c2 < s2.length; c2 += 1) n2[r2].fPath === s2[c2].src && (o2 = false);
            if (o2) {
              var d2 = createTag(`link`);
              d2.setAttribute(`f-forigin`, n2[r2].fOrigin), d2.setAttribute(`f-origin`, n2[r2].origin), d2.setAttribute(`rel`, `stylesheet`), d2.setAttribute(`href`, n2[r2].fPath), t2.appendChild(d2);
            }
          }
          n2[r2].helper = g(n2[r2], t2), n2[r2].cache = {}, this.fonts.push(n2[r2]);
        }
        a2 === 0 ? this.isLoaded = true : setTimeout(this.checkLoadedFonts.bind(this), 100);
      }
      function y(e2) {
        if (e2) {
          this.chars || (this.chars = []);
          var t2, n2 = e2.length, r2, i2 = this.chars.length, a2;
          for (t2 = 0; t2 < n2; t2 += 1) {
            for (r2 = 0, a2 = false; r2 < i2; ) this.chars[r2].style === e2[t2].style && this.chars[r2].fFamily === e2[t2].fFamily && this.chars[r2].ch === e2[t2].ch && (a2 = true), r2 += 1;
            a2 || (this.chars.push(e2[t2]), i2 += 1);
          }
        }
      }
      function b(e2, n2, r2) {
        for (var i2 = 0, a2 = this.chars.length; i2 < a2; ) {
          if (this.chars[i2].ch === e2 && this.chars[i2].style === n2 && this.chars[i2].fFamily === r2) return this.chars[i2];
          i2 += 1;
        }
        return (typeof e2 == `string` && e2.charCodeAt(0) !== 13 || !e2) && console && console.warn && !this._warned && (this._warned = true, console.warn(`Missing character from exported characters list: `, e2, n2, r2)), t;
      }
      function x(e2, t2, n2) {
        var r2 = this.getFontByName(t2), i2 = e2;
        if (!r2.cache[i2]) {
          var a2 = r2.helper;
          if (e2 === ` `) {
            var o2 = a2.measureText(`|` + e2 + `|`), s2 = a2.measureText(`||`);
            r2.cache[i2] = (o2 - s2) / 100;
          } else r2.cache[i2] = a2.measureText(e2) / 100;
        }
        return r2.cache[i2] * n2;
      }
      function S(e2) {
        for (var t2 = 0, n2 = this.fonts.length; t2 < n2; ) {
          if (this.fonts[t2].fName === e2) return this.fonts[t2];
          t2 += 1;
        }
        return this.fonts[0];
      }
      function C(e2) {
        var t2 = 0, n2 = e2.charCodeAt(0);
        if (n2 >= 55296 && n2 <= 56319) {
          var r2 = e2.charCodeAt(1);
          r2 >= 56320 && r2 <= 57343 && (t2 = (n2 - 55296) * 1024 + r2 - 56320 + 65536);
        }
        return t2;
      }
      function T(e2, t2) {
        var n2 = e2.toString(16) + t2.toString(16);
        return d.indexOf(n2) !== -1;
      }
      function E(e2) {
        return e2 === c;
      }
      function D(e2) {
        return e2 === s;
      }
      function O(e2) {
        var t2 = C(e2);
        return t2 >= l && t2 <= u;
      }
      function k(e2) {
        return O(e2.substr(0, 2)) && O(e2.substr(2, 2));
      }
      function A(e2) {
        return n.indexOf(e2) !== -1;
      }
      function j(e2, t2) {
        var n2 = C(e2.substr(t2, 2));
        if (n2 !== r) return false;
        var s2 = 0;
        for (t2 += 2; s2 < 5; ) {
          if (n2 = C(e2.substr(t2, 2)), n2 < a || n2 > o) return false;
          s2 += 1, t2 += 2;
        }
        return C(e2.substr(t2, 2)) === i;
      }
      function M() {
        this.isLoaded = true;
      }
      var N = function() {
        this.fonts = [], this.chars = null, this.typekitLoaded = 0, this.isLoaded = false, this._warned = false, this.initTime = Date.now(), this.setIsLoadedBinded = this.setIsLoaded.bind(this), this.checkLoadedFontsBinded = this.checkLoadedFonts.bind(this);
      };
      return N.isModifier = T, N.isZeroWidthJoiner = E, N.isFlagEmoji = k, N.isRegionalCode = O, N.isCombinedCharacter = A, N.isRegionalFlag = j, N.isVariationSelector = D, N.BLACK_FLAG_CODE_POINT = r, N.prototype = { addChars: y, addFonts: _, getCharData: b, getFontByName: S, measureText: x, checkLoadedFonts: m, setIsLoaded: M }, N;
    })();
    function SlotManager(e) {
      this.animationData = e;
    }
    SlotManager.prototype.getProp = function(e) {
      return this.animationData.slots && this.animationData.slots[e.sid] ? Object.assign(e, this.animationData.slots[e.sid].p) : e;
    };
    function slotFactory(e) {
      return new SlotManager(e);
    }
    function RenderableElement() {
    }
    RenderableElement.prototype = { initRenderable: function() {
      this.isInRange = false, this.hidden = false, this.isTransparent = false, this.renderableComponents = [];
    }, addRenderableComponent: function(e) {
      this.renderableComponents.indexOf(e) === -1 && this.renderableComponents.push(e);
    }, removeRenderableComponent: function(e) {
      this.renderableComponents.indexOf(e) !== -1 && this.renderableComponents.splice(this.renderableComponents.indexOf(e), 1);
    }, prepareRenderableFrame: function(e) {
      this.checkLayerLimits(e);
    }, checkTransparency: function() {
      this.finalTransform.mProp.o.v <= 0 ? !this.isTransparent && this.globalData.renderConfig.hideOnTransparent && (this.isTransparent = true, this.hide()) : this.isTransparent && (this.isTransparent = false, this.show());
    }, checkLayerLimits: function(e) {
      this.data.ip - this.data.st <= e && this.data.op - this.data.st > e ? this.isInRange !== true && (this.globalData._mdf = true, this._mdf = true, this.isInRange = true, this.show()) : this.isInRange !== false && (this.globalData._mdf = true, this.isInRange = false, this.hide());
    }, renderRenderable: function() {
      var e, t = this.renderableComponents.length;
      for (e = 0; e < t; e += 1) this.renderableComponents[e].renderFrame(this._isFirstFrame);
    }, sourceRectAtTime: function() {
      return { top: 0, left: 0, width: 100, height: 100 };
    }, getLayerSize: function() {
      return this.data.ty === 5 ? { w: this.data.textData.width, h: this.data.textData.height } : { w: this.data.width, h: this.data.height };
    } };
    var getBlendMode = /* @__PURE__ */ (function() {
      var e = { 0: `source-over`, 1: `multiply`, 2: `screen`, 3: `overlay`, 4: `darken`, 5: `lighten`, 6: `color-dodge`, 7: `color-burn`, 8: `hard-light`, 9: `soft-light`, 10: `difference`, 11: `exclusion`, 12: `hue`, 13: `saturation`, 14: `color`, 15: `luminosity` };
      return function(t) {
        return e[t] || ``;
      };
    })();
    function SliderEffect(e, t, n) {
      this.p = PropertyFactory.getProp(t, e.v, 0, 0, n);
    }
    function AngleEffect(e, t, n) {
      this.p = PropertyFactory.getProp(t, e.v, 0, 0, n);
    }
    function ColorEffect(e, t, n) {
      this.p = PropertyFactory.getProp(t, e.v, 1, 0, n);
    }
    function PointEffect(e, t, n) {
      this.p = PropertyFactory.getProp(t, e.v, 1, 0, n);
    }
    function LayerIndexEffect(e, t, n) {
      this.p = PropertyFactory.getProp(t, e.v, 0, 0, n);
    }
    function MaskIndexEffect(e, t, n) {
      this.p = PropertyFactory.getProp(t, e.v, 0, 0, n);
    }
    function CheckboxEffect(e, t, n) {
      this.p = PropertyFactory.getProp(t, e.v, 0, 0, n);
    }
    function NoValueEffect() {
      this.p = {};
    }
    function EffectsManager(e, t) {
      var n = e.ef || [];
      this.effectElements = [];
      var r, i = n.length, a;
      for (r = 0; r < i; r += 1) a = new GroupEffect(n[r], t), this.effectElements.push(a);
    }
    function GroupEffect(e, t) {
      this.init(e, t);
    }
    extendPrototype([DynamicPropertyContainer], GroupEffect), GroupEffect.prototype.getValue = GroupEffect.prototype.iterateDynamicProperties, GroupEffect.prototype.init = function(e, t) {
      this.data = e, this.effectElements = [], this.initDynamicPropertyContainer(t);
      var n, r = this.data.ef.length, i, a = this.data.ef;
      for (n = 0; n < r; n += 1) {
        switch (i = null, a[n].ty) {
          case 0:
            i = new SliderEffect(a[n], t, this);
            break;
          case 1:
            i = new AngleEffect(a[n], t, this);
            break;
          case 2:
            i = new ColorEffect(a[n], t, this);
            break;
          case 3:
            i = new PointEffect(a[n], t, this);
            break;
          case 4:
          case 7:
            i = new CheckboxEffect(a[n], t, this);
            break;
          case 10:
            i = new LayerIndexEffect(a[n], t, this);
            break;
          case 11:
            i = new MaskIndexEffect(a[n], t, this);
            break;
          case 5:
            i = new EffectsManager(a[n], t, this);
            break;
          default:
            i = new NoValueEffect(a[n], t, this);
        }
        i && this.effectElements.push(i);
      }
    };
    function BaseElement() {
    }
    BaseElement.prototype = { checkMasks: function() {
      if (!this.data.hasMask) return false;
      for (var e = 0, t = this.data.masksProperties.length; e < t; ) {
        if (this.data.masksProperties[e].mode !== `n` && this.data.masksProperties[e].cl !== false) return true;
        e += 1;
      }
      return false;
    }, initExpressions: function() {
      var e = getExpressionInterfaces();
      if (e) {
        var t = e(`layer`), n = e(`effects`), r = e(`shape`), i = e(`text`), a = e(`comp`);
        this.layerInterface = t(this), this.data.hasMask && this.maskManager && this.layerInterface.registerMaskInterface(this.maskManager);
        var o = n.createEffectsInterface(this, this.layerInterface);
        this.layerInterface.registerEffectsInterface(o), this.data.ty === 0 || this.data.xt ? this.compInterface = a(this) : this.data.ty === 4 ? (this.layerInterface.shapeInterface = r(this.shapesData, this.itemsData, this.layerInterface), this.layerInterface.content = this.layerInterface.shapeInterface) : this.data.ty === 5 && (this.layerInterface.textInterface = i(this), this.layerInterface.text = this.layerInterface.textInterface);
      }
    }, setBlendMode: function() {
      var e = getBlendMode(this.data.bm), t = this.baseElement || this.layerElement;
      t.style[`mix-blend-mode`] = e;
    }, initBaseData: function(e, t, n) {
      this.globalData = t, this.comp = n, this.data = e, this.layerId = createElementID(), this.data.sr || (this.data.sr = 1), this.effectsManager = new EffectsManager(this.data, this, this.dynamicProperties);
    }, getType: function() {
      return this.type;
    }, sourceRectAtTime: function() {
    } };
    function FrameElement() {
    }
    FrameElement.prototype = { initFrame: function() {
      this._isFirstFrame = false, this.dynamicProperties = [], this._mdf = false;
    }, prepareProperties: function(e, t) {
      var n, r = this.dynamicProperties.length;
      for (n = 0; n < r; n += 1) (t || this._isParent && this.dynamicProperties[n].propType === `transform`) && (this.dynamicProperties[n].getValue(), this.dynamicProperties[n]._mdf && (this.globalData._mdf = true, this._mdf = true));
    }, addDynamicProperty: function(e) {
      this.dynamicProperties.indexOf(e) === -1 && this.dynamicProperties.push(e);
    } };
    function FootageElement(e, t, n) {
      this.initFrame(), this.initRenderable(), this.assetData = t.getAssetData(e.refId), this.footageData = t.imageLoader.getAsset(this.assetData), this.initBaseData(e, t, n);
    }
    FootageElement.prototype.prepareFrame = function() {
    }, extendPrototype([RenderableElement, BaseElement, FrameElement], FootageElement), FootageElement.prototype.getBaseElement = function() {
      return null;
    }, FootageElement.prototype.renderFrame = function() {
    }, FootageElement.prototype.destroy = function() {
    }, FootageElement.prototype.initExpressions = function() {
      var e = getExpressionInterfaces();
      if (e) {
        var t = e(`footage`);
        this.layerInterface = t(this);
      }
    }, FootageElement.prototype.getFootageData = function() {
      return this.footageData;
    };
    function AudioElement(e, t, n) {
      this.initFrame(), this.initRenderable(), this.assetData = t.getAssetData(e.refId), this.initBaseData(e, t, n), this._isPlaying = false, this._canPlay = false;
      var r = this.globalData.getAssetsPath(this.assetData);
      this.audio = this.globalData.audioController.createAudio(r), this._currentTime = 0, this.globalData.audioController.addAudio(this), this._volumeMultiplier = 1, this._volume = 1, this._previousVolume = null, this.tm = e.tm ? PropertyFactory.getProp(this, e.tm, 0, t.frameRate, this) : { _placeholder: true }, this.lv = PropertyFactory.getProp(this, e.au && e.au.lv ? e.au.lv : { k: [100] }, 1, 0.01, this);
    }
    AudioElement.prototype.prepareFrame = function(e) {
      if (this.prepareRenderableFrame(e, true), this.prepareProperties(e, true), this.tm._placeholder) this._currentTime = e / this.data.sr;
      else {
        var t = this.tm.v;
        this._currentTime = t;
      }
      this._volume = this.lv.v[0];
      var n = this._volume * this._volumeMultiplier;
      this._previousVolume !== n && (this._previousVolume = n, this.audio.volume(n));
    }, extendPrototype([RenderableElement, BaseElement, FrameElement], AudioElement), AudioElement.prototype.renderFrame = function() {
      this.isInRange && this._canPlay && (this._isPlaying ? (!this.audio.playing() || Math.abs(this._currentTime / this.globalData.frameRate - this.audio.seek()) > 0.1) && this.audio.seek(this._currentTime / this.globalData.frameRate) : (this.audio.play(), this.audio.seek(this._currentTime / this.globalData.frameRate), this._isPlaying = true));
    }, AudioElement.prototype.show = function() {
    }, AudioElement.prototype.hide = function() {
      this.audio.pause(), this._isPlaying = false;
    }, AudioElement.prototype.pause = function() {
      this.audio.pause(), this._isPlaying = false, this._canPlay = false;
    }, AudioElement.prototype.resume = function() {
      this._canPlay = true;
    }, AudioElement.prototype.setRate = function(e) {
      this.audio.rate(e);
    }, AudioElement.prototype.volume = function(e) {
      this._volumeMultiplier = e, this._previousVolume = e * this._volume, this.audio.volume(this._previousVolume);
    }, AudioElement.prototype.getBaseElement = function() {
      return null;
    }, AudioElement.prototype.destroy = function() {
    }, AudioElement.prototype.sourceRectAtTime = function() {
    }, AudioElement.prototype.initExpressions = function() {
    };
    function BaseRenderer() {
    }
    BaseRenderer.prototype.checkLayers = function(e) {
      var t, n = this.layers.length, r;
      for (this.completeLayers = true, t = n - 1; t >= 0; --t) this.elements[t] || (r = this.layers[t], r.ip - r.st <= e - this.layers[t].st && r.op - r.st > e - this.layers[t].st && this.buildItem(t)), this.completeLayers = this.elements[t] ? this.completeLayers : false;
      this.checkPendingElements();
    }, BaseRenderer.prototype.createItem = function(e) {
      switch (e.ty) {
        case 2:
          return this.createImage(e);
        case 0:
          return this.createComp(e);
        case 1:
          return this.createSolid(e);
        case 3:
          return this.createNull(e);
        case 4:
          return this.createShape(e);
        case 5:
          return this.createText(e);
        case 6:
          return this.createAudio(e);
        case 13:
          return this.createCamera(e);
        case 15:
          return this.createFootage(e);
        default:
          return this.createNull(e);
      }
    }, BaseRenderer.prototype.createCamera = function() {
      throw Error(`You're using a 3d camera. Try the html renderer.`);
    }, BaseRenderer.prototype.createAudio = function(e) {
      return new AudioElement(e, this.globalData, this);
    }, BaseRenderer.prototype.createFootage = function(e) {
      return new FootageElement(e, this.globalData, this);
    }, BaseRenderer.prototype.buildAllItems = function() {
      var e, t = this.layers.length;
      for (e = 0; e < t; e += 1) this.buildItem(e);
      this.checkPendingElements();
    }, BaseRenderer.prototype.includeLayers = function(e) {
      this.completeLayers = false;
      var t, n = e.length, r, i = this.layers.length;
      for (t = 0; t < n; t += 1) for (r = 0; r < i; ) {
        if (this.layers[r].id === e[t].id) {
          this.layers[r] = e[t];
          break;
        }
        r += 1;
      }
    }, BaseRenderer.prototype.setProjectInterface = function(e) {
      this.globalData.projectInterface = e;
    }, BaseRenderer.prototype.initItems = function() {
      this.globalData.progressiveLoad || this.buildAllItems();
    }, BaseRenderer.prototype.buildElementParenting = function(e, t, n) {
      for (var r = this.elements, i = this.layers, a = 0, o = i.length; a < o; ) i[a].ind == t && (!r[a] || r[a] === true ? (this.buildItem(a), this.addPendingElement(e)) : (n.push(r[a]), r[a].setAsParent(), i[a].parent === void 0 ? e.setHierarchy(n) : this.buildElementParenting(e, i[a].parent, n))), a += 1;
    }, BaseRenderer.prototype.addPendingElement = function(e) {
      this.pendingElements.push(e);
    }, BaseRenderer.prototype.searchExtraCompositions = function(e) {
      var t, n = e.length;
      for (t = 0; t < n; t += 1) if (e[t].xt) {
        var r = this.createComp(e[t]);
        r.initExpressions(), this.globalData.projectInterface.registerComposition(r);
      }
    }, BaseRenderer.prototype.getElementById = function(e) {
      var t, n = this.elements.length;
      for (t = 0; t < n; t += 1) if (this.elements[t].data.ind === e) return this.elements[t];
      return null;
    }, BaseRenderer.prototype.getElementByPath = function(e) {
      var t = e.shift(), n;
      if (typeof t == `number`) n = this.elements[t];
      else {
        var r, i = this.elements.length;
        for (r = 0; r < i; r += 1) if (this.elements[r].data.nm === t) {
          n = this.elements[r];
          break;
        }
      }
      return e.length === 0 ? n : n.getElementByPath(e);
    }, BaseRenderer.prototype.setupGlobalData = function(e, t) {
      this.globalData.fontManager = new FontManager(), this.globalData.slotManager = slotFactory(e), this.globalData.fontManager.addChars(e.chars), this.globalData.fontManager.addFonts(e.fonts, t), this.globalData.getAssetData = this.animationItem.getAssetData.bind(this.animationItem), this.globalData.getAssetsPath = this.animationItem.getAssetsPath.bind(this.animationItem), this.globalData.imageLoader = this.animationItem.imagePreloader, this.globalData.audioController = this.animationItem.audioController, this.globalData.frameId = 0, this.globalData.frameRate = e.fr, this.globalData.nm = e.nm, this.globalData.compSize = { w: e.w, h: e.h };
    };
    var effectTypes = { TRANSFORM_EFFECT: `transformEFfect` };
    function TransformElement() {
    }
    TransformElement.prototype = { initTransform: function() {
      var e = new Matrix();
      this.finalTransform = { mProp: this.data.ks ? TransformPropertyFactory.getTransformProperty(this, this.data.ks, this) : { o: 0 }, _matMdf: false, _localMatMdf: false, _opMdf: false, mat: e, localMat: e, localOpacity: 1 }, this.data.ao && (this.finalTransform.mProp.autoOriented = true), this.data.ty;
    }, renderTransform: function() {
      if (this.finalTransform._opMdf = this.finalTransform.mProp.o._mdf || this._isFirstFrame, this.finalTransform._matMdf = this.finalTransform.mProp._mdf || this._isFirstFrame, this.hierarchy) {
        var e, t = this.finalTransform.mat, n = 0, r = this.hierarchy.length;
        if (!this.finalTransform._matMdf) for (; n < r; ) {
          if (this.hierarchy[n].finalTransform.mProp._mdf) {
            this.finalTransform._matMdf = true;
            break;
          }
          n += 1;
        }
        if (this.finalTransform._matMdf) for (e = this.finalTransform.mProp.v.props, t.cloneFromProps(e), n = 0; n < r; n += 1) t.multiply(this.hierarchy[n].finalTransform.mProp.v);
      }
      (!this.localTransforms || this.finalTransform._matMdf) && (this.finalTransform._localMatMdf = this.finalTransform._matMdf), this.finalTransform._opMdf && (this.finalTransform.localOpacity = this.finalTransform.mProp.o.v);
    }, renderLocalTransform: function() {
      if (this.localTransforms) {
        var e = 0, t = this.localTransforms.length;
        if (this.finalTransform._localMatMdf = this.finalTransform._matMdf, !this.finalTransform._localMatMdf || !this.finalTransform._opMdf) for (; e < t; ) this.localTransforms[e]._mdf && (this.finalTransform._localMatMdf = true), this.localTransforms[e]._opMdf && !this.finalTransform._opMdf && (this.finalTransform.localOpacity = this.finalTransform.mProp.o.v, this.finalTransform._opMdf = true), e += 1;
        if (this.finalTransform._localMatMdf) {
          var n = this.finalTransform.localMat;
          for (this.localTransforms[0].matrix.clone(n), e = 1; e < t; e += 1) {
            var r = this.localTransforms[e].matrix;
            n.multiply(r);
          }
          n.multiply(this.finalTransform.mat);
        }
        if (this.finalTransform._opMdf) {
          var i = this.finalTransform.localOpacity;
          for (e = 0; e < t; e += 1) i *= this.localTransforms[e].opacity * 0.01;
          this.finalTransform.localOpacity = i;
        }
      }
    }, searchEffectTransforms: function() {
      if (this.renderableEffectsManager) {
        var e = this.renderableEffectsManager.getEffects(effectTypes.TRANSFORM_EFFECT);
        if (e.length) {
          this.localTransforms = [], this.finalTransform.localMat = new Matrix();
          var t = 0, n = e.length;
          for (t = 0; t < n; t += 1) this.localTransforms.push(e[t]);
        }
      }
    }, globalToLocal: function(e) {
      var t = [];
      t.push(this.finalTransform);
      for (var n = true, r = this.comp; n; ) r.finalTransform ? (r.data.hasMask && t.splice(0, 0, r.finalTransform), r = r.comp) : n = false;
      var i, a = t.length, o;
      for (i = 0; i < a; i += 1) o = t[i].mat.applyToPointArray(0, 0, 0), e = [e[0] - o[0], e[1] - o[1], 0];
      return e;
    }, mHelper: new Matrix() };
    function MaskElement(e, t, n) {
      this.data = e, this.element = t, this.globalData = n, this.storedData = [], this.masksProperties = this.data.masksProperties || [], this.maskElement = null;
      var r = this.globalData.defs, i, a = this.masksProperties ? this.masksProperties.length : 0;
      this.viewData = createSizedArray(a), this.solidPath = ``;
      var o, s = this.masksProperties, c = 0, l = [], u, d, f = createElementID(), p, m, g, _, y = `clipPath`, b = `clip-path`;
      for (i = 0; i < a; i += 1) if ((s[i].mode !== `a` && s[i].mode !== `n` || s[i].inv || s[i].o.k !== 100 || s[i].o.x) && (y = `mask`, b = `mask`), (s[i].mode === `s` || s[i].mode === `i`) && c === 0 ? (p = createNS(`rect`), p.setAttribute(`fill`, `#ffffff`), p.setAttribute(`width`, this.element.comp.data.w || 0), p.setAttribute(`height`, this.element.comp.data.h || 0), l.push(p)) : p = null, o = createNS(`path`), s[i].mode === `n`) this.viewData[i] = { op: PropertyFactory.getProp(this.element, s[i].o, 0, 0.01, this.element), prop: ShapePropertyFactory.getShapeProp(this.element, s[i], 3), elem: o, lastPath: `` }, r.appendChild(o);
      else {
        c += 1, o.setAttribute(`fill`, s[i].mode === `s` ? `#000000` : `#ffffff`), o.setAttribute(`clip-rule`, `nonzero`);
        var x;
        if (s[i].x.k === 0 ? (g = null, _ = null) : (y = `mask`, b = `mask`, _ = PropertyFactory.getProp(this.element, s[i].x, 0, null, this.element), x = createElementID(), m = createNS(`filter`), m.setAttribute(`id`, x), g = createNS(`feMorphology`), g.setAttribute(`operator`, `erode`), g.setAttribute(`in`, `SourceGraphic`), g.setAttribute(`radius`, `0`), m.appendChild(g), r.appendChild(m), o.setAttribute(`stroke`, s[i].mode === `s` ? `#000000` : `#ffffff`)), this.storedData[i] = { elem: o, x: _, expan: g, lastPath: ``, lastOperator: ``, filterId: x, lastRadius: 0 }, s[i].mode === `i`) {
          d = l.length;
          var S = createNS(`g`);
          for (u = 0; u < d; u += 1) S.appendChild(l[u]);
          var C = createNS(`mask`);
          C.setAttribute(`mask-type`, `alpha`), C.setAttribute(`id`, f + `_` + c), C.appendChild(o), r.appendChild(C), S.setAttribute(`mask`, `url(` + getLocationHref() + `#` + f + `_` + c + `)`), l.length = 0, l.push(S);
        } else l.push(o);
        s[i].inv && !this.solidPath && (this.solidPath = this.createLayerSolidPath()), this.viewData[i] = { elem: o, lastPath: ``, op: PropertyFactory.getProp(this.element, s[i].o, 0, 0.01, this.element), prop: ShapePropertyFactory.getShapeProp(this.element, s[i], 3), invRect: p }, this.viewData[i].prop.k || this.drawPath(s[i], this.viewData[i].prop.v, this.viewData[i]);
      }
      for (this.maskElement = createNS(y), a = l.length, i = 0; i < a; i += 1) this.maskElement.appendChild(l[i]);
      c > 0 && (this.maskElement.setAttribute(`id`, f), this.element.maskedElement.setAttribute(b, `url(` + getLocationHref() + `#` + f + `)`), r.appendChild(this.maskElement)), this.viewData.length && this.element.addRenderableComponent(this);
    }
    MaskElement.prototype.getMaskProperty = function(e) {
      return this.viewData[e].prop;
    }, MaskElement.prototype.renderFrame = function(e) {
      var t = this.element.finalTransform.mat, n, r = this.masksProperties.length;
      for (n = 0; n < r; n += 1) if ((this.viewData[n].prop._mdf || e) && this.drawPath(this.masksProperties[n], this.viewData[n].prop.v, this.viewData[n]), (this.viewData[n].op._mdf || e) && this.viewData[n].elem.setAttribute(`fill-opacity`, this.viewData[n].op.v), this.masksProperties[n].mode !== `n` && (this.viewData[n].invRect && (this.element.finalTransform.mProp._mdf || e) && this.viewData[n].invRect.setAttribute(`transform`, t.getInverseMatrix().to2dCSS()), this.storedData[n].x && (this.storedData[n].x._mdf || e))) {
        var i = this.storedData[n].expan;
        this.storedData[n].x.v < 0 ? (this.storedData[n].lastOperator !== `erode` && (this.storedData[n].lastOperator = `erode`, this.storedData[n].elem.setAttribute(`filter`, `url(` + getLocationHref() + `#` + this.storedData[n].filterId + `)`)), i.setAttribute(`radius`, -this.storedData[n].x.v)) : (this.storedData[n].lastOperator !== `dilate` && (this.storedData[n].lastOperator = `dilate`, this.storedData[n].elem.setAttribute(`filter`, null)), this.storedData[n].elem.setAttribute(`stroke-width`, this.storedData[n].x.v * 2));
      }
    }, MaskElement.prototype.getMaskelement = function() {
      return this.maskElement;
    }, MaskElement.prototype.createLayerSolidPath = function() {
      var e = `M0,0 `;
      return e += ` h` + this.globalData.compSize.w, e += ` v` + this.globalData.compSize.h, e += ` h-` + this.globalData.compSize.w, e += ` v-` + this.globalData.compSize.h + ` `, e;
    }, MaskElement.prototype.drawPath = function(e, t, n) {
      var r = ` M` + t.v[0][0] + `,` + t.v[0][1], i, a = t._length;
      for (i = 1; i < a; i += 1) r += ` C` + t.o[i - 1][0] + `,` + t.o[i - 1][1] + ` ` + t.i[i][0] + `,` + t.i[i][1] + ` ` + t.v[i][0] + `,` + t.v[i][1];
      if (t.c && a > 1 && (r += ` C` + t.o[i - 1][0] + `,` + t.o[i - 1][1] + ` ` + t.i[0][0] + `,` + t.i[0][1] + ` ` + t.v[0][0] + `,` + t.v[0][1]), n.lastPath !== r) {
        var o = ``;
        n.elem && (t.c && (o = e.inv ? this.solidPath + r : r), n.elem.setAttribute(`d`, o)), n.lastPath = r;
      }
    }, MaskElement.prototype.destroy = function() {
      this.element = null, this.globalData = null, this.maskElement = null, this.data = null, this.masksProperties = null;
    };
    var filtersFactory = (function() {
      var e = {};
      e.createFilter = t, e.createAlphaToLuminanceFilter = n;
      function t(e2, t2) {
        var n2 = createNS(`filter`);
        return n2.setAttribute(`id`, e2), t2 !== true && (n2.setAttribute(`filterUnits`, `objectBoundingBox`), n2.setAttribute(`x`, `0%`), n2.setAttribute(`y`, `0%`), n2.setAttribute(`width`, `100%`), n2.setAttribute(`height`, `100%`)), n2;
      }
      function n() {
        var e2 = createNS(`feColorMatrix`);
        return e2.setAttribute(`type`, `matrix`), e2.setAttribute(`color-interpolation-filters`, `sRGB`), e2.setAttribute(`values`, `0 0 0 1 0  0 0 0 1 0  0 0 0 1 0  0 0 0 1 1`), e2;
      }
      return e;
    })(), featureSupport = (function() {
      var e = { maskType: true, svgLumaHidden: true, offscreenCanvas: typeof OffscreenCanvas < `u` };
      return (/MSIE 10/i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge\/\d./i.test(navigator.userAgent)) && (e.maskType = false), /firefox/i.test(navigator.userAgent) && (e.svgLumaHidden = false), e;
    })(), registeredEffects$1 = {}, idPrefix = `filter_result_`;
    function SVGEffects(e) {
      var t, n = `SourceGraphic`, r = e.data.ef ? e.data.ef.length : 0, i = createElementID(), a = filtersFactory.createFilter(i, true), o = 0;
      this.filters = [];
      var s;
      for (t = 0; t < r; t += 1) {
        s = null;
        var c = e.data.ef[t].ty;
        if (registeredEffects$1[c]) {
          var l = registeredEffects$1[c].effect;
          s = new l(a, e.effectsManager.effectElements[t], e, idPrefix + o, n), n = idPrefix + o, registeredEffects$1[c].countsAsEffect && (o += 1);
        }
        s && this.filters.push(s);
      }
      o && (e.globalData.defs.appendChild(a), e.layerElement.setAttribute(`filter`, `url(` + getLocationHref() + `#` + i + `)`)), this.filters.length && e.addRenderableComponent(this);
    }
    SVGEffects.prototype.renderFrame = function(e) {
      var t, n = this.filters.length;
      for (t = 0; t < n; t += 1) this.filters[t].renderFrame(e);
    }, SVGEffects.prototype.getEffects = function(e) {
      var t, n = this.filters.length, r = [];
      for (t = 0; t < n; t += 1) this.filters[t].type === e && r.push(this.filters[t]);
      return r;
    };
    function registerEffect$1(e, t, n) {
      registeredEffects$1[e] = { effect: t, countsAsEffect: n };
    }
    function SVGBaseElement() {
    }
    SVGBaseElement.prototype = { initRendererElement: function() {
      this.layerElement = createNS(`g`);
    }, createContainerElements: function() {
      this.matteElement = createNS(`g`), this.transformedElement = this.layerElement, this.maskedElement = this.layerElement, this._sizeChanged = false;
      var e = null;
      if (this.data.td) {
        this.matteMasks = {};
        var t = createNS(`g`);
        t.setAttribute(`id`, this.layerId), t.appendChild(this.layerElement), e = t, this.globalData.defs.appendChild(t);
      } else this.data.tt ? (this.matteElement.appendChild(this.layerElement), e = this.matteElement, this.baseElement = this.matteElement) : this.baseElement = this.layerElement;
      if (this.data.ln && this.layerElement.setAttribute(`id`, this.data.ln), this.data.cl && this.layerElement.setAttribute(`class`, this.data.cl), this.data.ty === 0 && !this.data.hd) {
        var n = createNS(`clipPath`), r = createNS(`path`);
        r.setAttribute(`d`, `M0,0 L` + this.data.w + `,0 L` + this.data.w + `,` + this.data.h + ` L0,` + this.data.h + `z`);
        var i = createElementID();
        if (n.setAttribute(`id`, i), n.appendChild(r), this.globalData.defs.appendChild(n), this.checkMasks()) {
          var a = createNS(`g`);
          a.setAttribute(`clip-path`, `url(` + getLocationHref() + `#` + i + `)`), a.appendChild(this.layerElement), this.transformedElement = a, e ? e.appendChild(this.transformedElement) : this.baseElement = this.transformedElement;
        } else this.layerElement.setAttribute(`clip-path`, `url(` + getLocationHref() + `#` + i + `)`);
      }
      this.data.bm !== 0 && this.setBlendMode();
    }, renderElement: function() {
      this.finalTransform._localMatMdf && this.transformedElement.setAttribute(`transform`, this.finalTransform.localMat.to2dCSS()), this.finalTransform._opMdf && this.transformedElement.setAttribute(`opacity`, this.finalTransform.localOpacity);
    }, destroyBaseElement: function() {
      this.layerElement = null, this.matteElement = null, this.maskManager.destroy();
    }, getBaseElement: function() {
      return this.data.hd ? null : this.baseElement;
    }, createRenderableComponents: function() {
      this.maskManager = new MaskElement(this.data, this, this.globalData), this.renderableEffectsManager = new SVGEffects(this), this.searchEffectTransforms();
    }, getMatte: function(e) {
      if (this.matteMasks || (this.matteMasks = {}), !this.matteMasks[e]) {
        var t = this.layerId + `_` + e, n, r, i, a;
        if (e === 1 || e === 3) {
          var o = createNS(`mask`);
          o.setAttribute(`id`, t), o.setAttribute(`mask-type`, e === 3 ? `luminance` : `alpha`), i = createNS(`use`), i.setAttributeNS(`http://www.w3.org/1999/xlink`, `href`, `#` + this.layerId), o.appendChild(i), this.globalData.defs.appendChild(o), !featureSupport.maskType && e === 1 && (o.setAttribute(`mask-type`, `luminance`), n = createElementID(), r = filtersFactory.createFilter(n), this.globalData.defs.appendChild(r), r.appendChild(filtersFactory.createAlphaToLuminanceFilter()), a = createNS(`g`), a.appendChild(i), o.appendChild(a), a.setAttribute(`filter`, `url(` + getLocationHref() + `#` + n + `)`));
        } else if (e === 2) {
          var s = createNS(`mask`);
          s.setAttribute(`id`, t), s.setAttribute(`mask-type`, `alpha`);
          var c = createNS(`g`);
          s.appendChild(c), n = createElementID(), r = filtersFactory.createFilter(n);
          var l = createNS(`feComponentTransfer`);
          l.setAttribute(`in`, `SourceGraphic`), r.appendChild(l);
          var u = createNS(`feFuncA`);
          u.setAttribute(`type`, `table`), u.setAttribute(`tableValues`, `1.0 0.0`), l.appendChild(u), this.globalData.defs.appendChild(r);
          var d = createNS(`rect`);
          d.setAttribute(`width`, this.comp.data.w), d.setAttribute(`height`, this.comp.data.h), d.setAttribute(`x`, `0`), d.setAttribute(`y`, `0`), d.setAttribute(`fill`, `#ffffff`), d.setAttribute(`opacity`, `0`), c.setAttribute(`filter`, `url(` + getLocationHref() + `#` + n + `)`), c.appendChild(d), i = createNS(`use`), i.setAttributeNS(`http://www.w3.org/1999/xlink`, `href`, `#` + this.layerId), c.appendChild(i), featureSupport.maskType || (s.setAttribute(`mask-type`, `luminance`), r.appendChild(filtersFactory.createAlphaToLuminanceFilter()), a = createNS(`g`), c.appendChild(d), a.appendChild(this.layerElement), c.appendChild(a)), this.globalData.defs.appendChild(s);
        }
        this.matteMasks[e] = t;
      }
      return this.matteMasks[e];
    }, setMatte: function(e) {
      this.matteElement && this.matteElement.setAttribute(`mask`, `url(` + getLocationHref() + `#` + e + `)`);
    } };
    function HierarchyElement() {
    }
    HierarchyElement.prototype = { initHierarchy: function() {
      this.hierarchy = [], this._isParent = false, this.checkParenting();
    }, setHierarchy: function(e) {
      this.hierarchy = e;
    }, setAsParent: function() {
      this._isParent = true;
    }, checkParenting: function() {
      this.data.parent !== void 0 && this.comp.buildElementParenting(this, this.data.parent, []);
    } };
    function RenderableDOMElement() {
    }
    (function() {
      extendPrototype([RenderableElement, createProxyFunction({ initElement: function(e, t, n) {
        this.initFrame(), this.initBaseData(e, t, n), this.initTransform(e, t, n), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide();
      }, hide: function() {
        if (!this.hidden && (!this.isInRange || this.isTransparent)) {
          var e = this.baseElement || this.layerElement;
          e.style.display = `none`, this.hidden = true;
        }
      }, show: function() {
        if (this.isInRange && !this.isTransparent) {
          if (!this.data.hd) {
            var e = this.baseElement || this.layerElement;
            e.style.display = `block`;
          }
          this.hidden = false, this._isFirstFrame = true;
        }
      }, renderFrame: function() {
        this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderLocalTransform(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = false));
      }, renderInnerContent: function() {
      }, prepareFrame: function(e) {
        this._mdf = false, this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange), this.checkTransparency();
      }, destroy: function() {
        this.innerElem = null, this.destroyBaseElement();
      } })], RenderableDOMElement);
    })();
    function IImageElement(e, t, n) {
      this.assetData = t.getAssetData(e.refId), this.assetData && this.assetData.sid && (this.assetData = t.slotManager.getProp(this.assetData)), this.initElement(e, t, n), this.sourceRect = { top: 0, left: 0, width: this.assetData.w, height: this.assetData.h };
    }
    extendPrototype([BaseElement, TransformElement, SVGBaseElement, HierarchyElement, FrameElement, RenderableDOMElement], IImageElement), IImageElement.prototype.createContent = function() {
      var e = this.globalData.getAssetsPath(this.assetData);
      this.innerElem = createNS(`image`), this.innerElem.setAttribute(`width`, this.assetData.w + `px`), this.innerElem.setAttribute(`height`, this.assetData.h + `px`), this.innerElem.setAttribute(`preserveAspectRatio`, this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio), this.innerElem.setAttributeNS(`http://www.w3.org/1999/xlink`, `href`, e), this.layerElement.appendChild(this.innerElem);
    }, IImageElement.prototype.sourceRectAtTime = function() {
      return this.sourceRect;
    };
    function ProcessedElement(e, t) {
      this.elem = e, this.pos = t;
    }
    function IShapeElement() {
    }
    IShapeElement.prototype = { addShapeToModifiers: function(e) {
      var t, n = this.shapeModifiers.length;
      for (t = 0; t < n; t += 1) this.shapeModifiers[t].addShape(e);
    }, isShapeInAnimatedModifiers: function(e) {
      for (var t = 0, n = this.shapeModifiers.length; t < n; ) if (this.shapeModifiers[t].isAnimatedWithShape(e)) return true;
      return false;
    }, renderModifiers: function() {
      if (this.shapeModifiers.length) {
        var e, t = this.shapes.length;
        for (e = 0; e < t; e += 1) this.shapes[e].sh.reset();
        t = this.shapeModifiers.length;
        var n;
        for (e = t - 1; e >= 0 && (n = this.shapeModifiers[e].processShapes(this._isFirstFrame), !n); --e) ;
      }
    }, searchProcessedElement: function(e) {
      for (var t = this.processedElements, n = 0, r = t.length; n < r; ) {
        if (t[n].elem === e) return t[n].pos;
        n += 1;
      }
      return 0;
    }, addProcessedElement: function(e, t) {
      for (var n = this.processedElements, r = n.length; r; ) if (--r, n[r].elem === e) {
        n[r].pos = t;
        return;
      }
      n.push(new ProcessedElement(e, t));
    }, prepareFrame: function(e) {
      this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange);
    } };
    var lineCapEnum = { 1: `butt`, 2: `round`, 3: `square` }, lineJoinEnum = { 1: `miter`, 2: `round`, 3: `bevel` };
    function SVGShapeData(e, t, n) {
      this.caches = [], this.styles = [], this.transformers = e, this.lStr = ``, this.sh = n, this.lvl = t, this._isAnimated = !!n.k;
      for (var r = 0, i = e.length; r < i; ) {
        if (e[r].mProps.dynamicProperties.length) {
          this._isAnimated = true;
          break;
        }
        r += 1;
      }
    }
    SVGShapeData.prototype.setAsAnimated = function() {
      this._isAnimated = true;
    };
    function SVGStyleData(e, t) {
      this.data = e, this.type = e.ty, this.d = ``, this.lvl = t, this._mdf = false, this.closed = e.hd === true, this.pElem = createNS(`path`), this.msElem = null;
    }
    SVGStyleData.prototype.reset = function() {
      this.d = ``, this._mdf = false;
    };
    function DashProperty(e, t, n, r) {
      this.elem = e, this.frameId = -1, this.dataProps = createSizedArray(t.length), this.renderer = n, this.k = false, this.dashStr = ``, this.dashArray = createTypedArray(`float32`, t.length ? t.length - 1 : 0), this.dashoffset = createTypedArray(`float32`, 1), this.initDynamicPropertyContainer(r);
      var i, a = t.length || 0, o;
      for (i = 0; i < a; i += 1) o = PropertyFactory.getProp(e, t[i].v, 0, 0, this), this.k = o.k || this.k, this.dataProps[i] = { n: t[i].n, p: o };
      this.k || this.getValue(true), this._isAnimated = this.k;
    }
    DashProperty.prototype.getValue = function(e) {
      if ((this.elem.globalData.frameId !== this.frameId || e) && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf = this._mdf || e, this._mdf)) {
        var t = 0, n = this.dataProps.length;
        for (this.renderer === `svg` && (this.dashStr = ``), t = 0; t < n; t += 1) this.dataProps[t].n === `o` ? this.dashoffset[0] = this.dataProps[t].p.v : this.renderer === `svg` ? this.dashStr += ` ` + this.dataProps[t].p.v : this.dashArray[t] = this.dataProps[t].p.v;
      }
    }, extendPrototype([DynamicPropertyContainer], DashProperty);
    function SVGStrokeStyleData(e, t, n) {
      this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(e, t.o, 0, 0.01, this), this.w = PropertyFactory.getProp(e, t.w, 0, null, this), this.d = new DashProperty(e, t.d || {}, `svg`, this), this.c = PropertyFactory.getProp(e, t.c, 1, 255, this), this.style = n, this._isAnimated = !!this._isAnimated;
    }
    extendPrototype([DynamicPropertyContainer], SVGStrokeStyleData);
    function SVGFillStyleData(e, t, n) {
      this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(e, t.o, 0, 0.01, this), this.c = PropertyFactory.getProp(e, t.c, 1, 255, this), this.style = n;
    }
    extendPrototype([DynamicPropertyContainer], SVGFillStyleData);
    function SVGNoStyleData(e, t, n) {
      this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.style = n;
    }
    extendPrototype([DynamicPropertyContainer], SVGNoStyleData);
    function GradientProperty(e, t, n) {
      this.data = t, this.c = createTypedArray(`uint8c`, t.p * 4);
      var r = t.k.k[0].s ? t.k.k[0].s.length - t.p * 4 : t.k.k.length - t.p * 4;
      this.o = createTypedArray(`float32`, r), this._cmdf = false, this._omdf = false, this._collapsable = this.checkCollapsable(), this._hasOpacity = r, this.initDynamicPropertyContainer(n), this.prop = PropertyFactory.getProp(e, t.k, 1, null, this), this.k = this.prop.k, this.getValue(true);
    }
    GradientProperty.prototype.comparePoints = function(e, t) {
      for (var n = 0, r = this.o.length / 2, i; n < r; ) {
        if (i = Math.abs(e[n * 4] - e[t * 4 + n * 2]), i > 0.01) return false;
        n += 1;
      }
      return true;
    }, GradientProperty.prototype.checkCollapsable = function() {
      if (this.o.length / 2 != this.c.length / 4) return false;
      if (this.data.k.k[0].s) for (var e = 0, t = this.data.k.k.length; e < t; ) {
        if (!this.comparePoints(this.data.k.k[e].s, this.data.p)) return false;
        e += 1;
      }
      else if (!this.comparePoints(this.data.k.k, this.data.p)) return false;
      return true;
    }, GradientProperty.prototype.getValue = function(e) {
      if (this.prop.getValue(), this._mdf = false, this._cmdf = false, this._omdf = false, this.prop._mdf || e) {
        var t, n = this.data.p * 4, r, i;
        for (t = 0; t < n; t += 1) r = t % 4 == 0 ? 100 : 255, i = Math.round(this.prop.v[t] * r), this.c[t] !== i && (this.c[t] = i, this._cmdf = !e);
        if (this.o.length) for (n = this.prop.v.length, t = this.data.p * 4; t < n; t += 1) r = t % 2 == 0 ? 100 : 1, i = t % 2 == 0 ? Math.round(this.prop.v[t] * 100) : this.prop.v[t], this.o[t - this.data.p * 4] !== i && (this.o[t - this.data.p * 4] = i, this._omdf = !e);
        this._mdf = !e;
      }
    }, extendPrototype([DynamicPropertyContainer], GradientProperty);
    function SVGGradientFillStyleData(e, t, n) {
      this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.initGradientData(e, t, n);
    }
    SVGGradientFillStyleData.prototype.initGradientData = function(e, t, n) {
      this.o = PropertyFactory.getProp(e, t.o, 0, 0.01, this), this.s = PropertyFactory.getProp(e, t.s, 1, null, this), this.e = PropertyFactory.getProp(e, t.e, 1, null, this), this.h = PropertyFactory.getProp(e, t.h || { k: 0 }, 0, 0.01, this), this.a = PropertyFactory.getProp(e, t.a || { k: 0 }, 0, degToRads, this), this.g = new GradientProperty(e, t.g, this), this.style = n, this.stops = [], this.setGradientData(n.pElem, t), this.setGradientOpacity(t, n), this._isAnimated = !!this._isAnimated;
    }, SVGGradientFillStyleData.prototype.setGradientData = function(e, t) {
      var n = createElementID(), r = createNS(t.t === 1 ? `linearGradient` : `radialGradient`);
      r.setAttribute(`id`, n), r.setAttribute(`spreadMethod`, `pad`), r.setAttribute(`gradientUnits`, `userSpaceOnUse`);
      var i = [], a, o, s = t.g.p * 4;
      for (o = 0; o < s; o += 4) a = createNS(`stop`), r.appendChild(a), i.push(a);
      e.setAttribute(t.ty === `gf` ? `fill` : `stroke`, `url(` + getLocationHref() + `#` + n + `)`), this.gf = r, this.cst = i;
    }, SVGGradientFillStyleData.prototype.setGradientOpacity = function(e, t) {
      if (this.g._hasOpacity && !this.g._collapsable) {
        var n, r, i, a = createNS(`mask`), o = createNS(`path`);
        a.appendChild(o);
        var s = createElementID(), c = createElementID();
        a.setAttribute(`id`, c);
        var l = createNS(e.t === 1 ? `linearGradient` : `radialGradient`);
        l.setAttribute(`id`, s), l.setAttribute(`spreadMethod`, `pad`), l.setAttribute(`gradientUnits`, `userSpaceOnUse`), i = e.g.k.k[0].s ? e.g.k.k[0].s.length : e.g.k.k.length;
        var u = this.stops;
        for (r = e.g.p * 4; r < i; r += 2) n = createNS(`stop`), n.setAttribute(`stop-color`, `rgb(255,255,255)`), l.appendChild(n), u.push(n);
        o.setAttribute(e.ty === `gf` ? `fill` : `stroke`, `url(` + getLocationHref() + `#` + s + `)`), e.ty === `gs` && (o.setAttribute(`stroke-linecap`, lineCapEnum[e.lc || 2]), o.setAttribute(`stroke-linejoin`, lineJoinEnum[e.lj || 2]), e.lj === 1 && o.setAttribute(`stroke-miterlimit`, e.ml)), this.of = l, this.ms = a, this.ost = u, this.maskId = c, t.msElem = o;
      }
    }, extendPrototype([DynamicPropertyContainer], SVGGradientFillStyleData);
    function SVGGradientStrokeStyleData(e, t, n) {
      this.initDynamicPropertyContainer(e), this.getValue = this.iterateDynamicProperties, this.w = PropertyFactory.getProp(e, t.w, 0, null, this), this.d = new DashProperty(e, t.d || {}, `svg`, this), this.initGradientData(e, t, n), this._isAnimated = !!this._isAnimated;
    }
    extendPrototype([SVGGradientFillStyleData, DynamicPropertyContainer], SVGGradientStrokeStyleData);
    function ShapeGroupData() {
      this.it = [], this.prevViewData = [], this.gr = createNS(`g`);
    }
    function SVGTransformData(e, t, n) {
      this.transform = { mProps: e, op: t, container: n }, this.elements = [], this._isAnimated = this.transform.mProps.dynamicProperties.length || this.transform.op.effectsSequence.length;
    }
    var buildShapeString = function(e, t, n, r) {
      if (t === 0) return ``;
      var i = e.o, a = e.i, o = e.v, s, c = ` M` + r.applyToPointStringified(o[0][0], o[0][1]);
      for (s = 1; s < t; s += 1) c += ` C` + r.applyToPointStringified(i[s - 1][0], i[s - 1][1]) + ` ` + r.applyToPointStringified(a[s][0], a[s][1]) + ` ` + r.applyToPointStringified(o[s][0], o[s][1]);
      return n && t && (c += ` C` + r.applyToPointStringified(i[s - 1][0], i[s - 1][1]) + ` ` + r.applyToPointStringified(a[0][0], a[0][1]) + ` ` + r.applyToPointStringified(o[0][0], o[0][1]), c += `z`), c;
    }, SVGElementsRenderer = (function() {
      var e = new Matrix(), t = new Matrix(), n = { createRenderFunction: r };
      function r(e2) {
        switch (e2.ty) {
          case `fl`:
            return s;
          case `gf`:
            return l;
          case `gs`:
            return c;
          case `st`:
            return u;
          case `sh`:
          case `el`:
          case `rc`:
          case `sr`:
            return o;
          case `tr`:
            return i;
          case `no`:
            return a;
          default:
            return null;
        }
      }
      function i(e2, t2, n2) {
        (n2 || t2.transform.op._mdf) && t2.transform.container.setAttribute(`opacity`, t2.transform.op.v), (n2 || t2.transform.mProps._mdf) && t2.transform.container.setAttribute(`transform`, t2.transform.mProps.v.to2dCSS());
      }
      function a() {
      }
      function o(n2, r2, i2) {
        var a2, o2, s2, c2, l2, u2, d = r2.styles.length, f = r2.lvl, p, m, g, _;
        for (u2 = 0; u2 < d; u2 += 1) {
          if (c2 = r2.sh._mdf || i2, r2.styles[u2].lvl < f) {
            for (m = t.reset(), g = f - r2.styles[u2].lvl, _ = r2.transformers.length - 1; !c2 && g > 0; ) c2 = r2.transformers[_].mProps._mdf || c2, --g, --_;
            if (c2) for (g = f - r2.styles[u2].lvl, _ = r2.transformers.length - 1; g > 0; ) m.multiply(r2.transformers[_].mProps.v), --g, --_;
          } else m = e;
          if (p = r2.sh.paths, o2 = p._length, c2) {
            for (s2 = ``, a2 = 0; a2 < o2; a2 += 1) l2 = p.shapes[a2], l2 && l2._length && (s2 += buildShapeString(l2, l2._length, l2.c, m));
            r2.caches[u2] = s2;
          } else s2 = r2.caches[u2];
          r2.styles[u2].d += n2.hd === true ? `` : s2, r2.styles[u2]._mdf = c2 || r2.styles[u2]._mdf;
        }
      }
      function s(e2, t2, n2) {
        var r2 = t2.style;
        (t2.c._mdf || n2) && r2.pElem.setAttribute(`fill`, `rgb(` + bmFloor(t2.c.v[0]) + `,` + bmFloor(t2.c.v[1]) + `,` + bmFloor(t2.c.v[2]) + `)`), (t2.o._mdf || n2) && r2.pElem.setAttribute(`fill-opacity`, t2.o.v);
      }
      function c(e2, t2, n2) {
        l(e2, t2, n2), u(e2, t2, n2);
      }
      function l(e2, t2, n2) {
        var r2 = t2.gf, i2 = t2.g._hasOpacity, a2 = t2.s.v, o2 = t2.e.v;
        if (t2.o._mdf || n2) {
          var s2 = e2.ty === `gf` ? `fill-opacity` : `stroke-opacity`;
          t2.style.pElem.setAttribute(s2, t2.o.v);
        }
        if (t2.s._mdf || n2) {
          var c2 = e2.t === 1 ? `x1` : `cx`, l2 = c2 === `x1` ? `y1` : `cy`;
          r2.setAttribute(c2, a2[0]), r2.setAttribute(l2, a2[1]), i2 && !t2.g._collapsable && (t2.of.setAttribute(c2, a2[0]), t2.of.setAttribute(l2, a2[1]));
        }
        var u2, d, f, p;
        if (t2.g._cmdf || n2) {
          u2 = t2.cst;
          var m = t2.g.c;
          for (f = u2.length, d = 0; d < f; d += 1) p = u2[d], p.setAttribute(`offset`, m[d * 4] + `%`), p.setAttribute(`stop-color`, `rgb(` + m[d * 4 + 1] + `,` + m[d * 4 + 2] + `,` + m[d * 4 + 3] + `)`);
        }
        if (i2 && (t2.g._omdf || n2)) {
          var g = t2.g.o;
          for (u2 = t2.g._collapsable ? t2.cst : t2.ost, f = u2.length, d = 0; d < f; d += 1) p = u2[d], t2.g._collapsable || p.setAttribute(`offset`, g[d * 2] + `%`), p.setAttribute(`stop-opacity`, g[d * 2 + 1]);
        }
        if (e2.t === 1) (t2.e._mdf || n2) && (r2.setAttribute(`x2`, o2[0]), r2.setAttribute(`y2`, o2[1]), i2 && !t2.g._collapsable && (t2.of.setAttribute(`x2`, o2[0]), t2.of.setAttribute(`y2`, o2[1])));
        else {
          var _;
          if ((t2.s._mdf || t2.e._mdf || n2) && (_ = Math.sqrt((a2[0] - o2[0]) ** 2 + (a2[1] - o2[1]) ** 2), r2.setAttribute(`r`, _), i2 && !t2.g._collapsable && t2.of.setAttribute(`r`, _)), t2.s._mdf || t2.e._mdf || t2.h._mdf || t2.a._mdf || n2) {
            _ || (_ = Math.sqrt((a2[0] - o2[0]) ** 2 + (a2[1] - o2[1]) ** 2));
            var y = Math.atan2(o2[1] - a2[1], o2[0] - a2[0]), b = t2.h.v;
            b >= 1 ? b = 0.99 : b <= -1 && (b = -0.99);
            var x = _ * b, S = Math.cos(y + t2.a.v) * x + a2[0], C = Math.sin(y + t2.a.v) * x + a2[1];
            r2.setAttribute(`fx`, S), r2.setAttribute(`fy`, C), i2 && !t2.g._collapsable && (t2.of.setAttribute(`fx`, S), t2.of.setAttribute(`fy`, C));
          }
        }
      }
      function u(e2, t2, n2) {
        var r2 = t2.style, i2 = t2.d;
        i2 && (i2._mdf || n2) && i2.dashStr && (r2.pElem.setAttribute(`stroke-dasharray`, i2.dashStr), r2.pElem.setAttribute(`stroke-dashoffset`, i2.dashoffset[0])), t2.c && (t2.c._mdf || n2) && r2.pElem.setAttribute(`stroke`, `rgb(` + bmFloor(t2.c.v[0]) + `,` + bmFloor(t2.c.v[1]) + `,` + bmFloor(t2.c.v[2]) + `)`), (t2.o._mdf || n2) && r2.pElem.setAttribute(`stroke-opacity`, t2.o.v), (t2.w._mdf || n2) && (r2.pElem.setAttribute(`stroke-width`, t2.w.v), r2.msElem && r2.msElem.setAttribute(`stroke-width`, t2.w.v));
      }
      return n;
    })();
    function SVGShapeElement(e, t, n) {
      this.shapes = [], this.shapesData = e.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.initElement(e, t, n), this.prevViewData = [];
    }
    extendPrototype([BaseElement, TransformElement, SVGBaseElement, IShapeElement, HierarchyElement, FrameElement, RenderableDOMElement], SVGShapeElement), SVGShapeElement.prototype.initSecondaryElement = function() {
    }, SVGShapeElement.prototype.identityMatrix = new Matrix(), SVGShapeElement.prototype.buildExpressionInterface = function() {
    }, SVGShapeElement.prototype.createContent = function() {
      this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], true), this.filterUniqueShapes();
    }, SVGShapeElement.prototype.filterUniqueShapes = function() {
      var e, t = this.shapes.length, n, r, i = this.stylesList.length, a, o = [], s = false;
      for (r = 0; r < i; r += 1) {
        for (a = this.stylesList[r], s = false, o.length = 0, e = 0; e < t; e += 1) n = this.shapes[e], n.styles.indexOf(a) !== -1 && (o.push(n), s = n._isAnimated || s);
        o.length > 1 && s && this.setShapesAsAnimated(o);
      }
    }, SVGShapeElement.prototype.setShapesAsAnimated = function(e) {
      var t, n = e.length;
      for (t = 0; t < n; t += 1) e[t].setAsAnimated();
    }, SVGShapeElement.prototype.createStyleElement = function(e, t) {
      var n, r = new SVGStyleData(e, t), i = r.pElem;
      return e.ty === `st` ? n = new SVGStrokeStyleData(this, e, r) : e.ty === `fl` ? n = new SVGFillStyleData(this, e, r) : e.ty === `gf` || e.ty === `gs` ? (n = new (e.ty === `gf` ? SVGGradientFillStyleData : SVGGradientStrokeStyleData)(this, e, r), this.globalData.defs.appendChild(n.gf), n.maskId && (this.globalData.defs.appendChild(n.ms), this.globalData.defs.appendChild(n.of), i.setAttribute(`mask`, `url(` + getLocationHref() + `#` + n.maskId + `)`))) : e.ty === `no` && (n = new SVGNoStyleData(this, e, r)), (e.ty === `st` || e.ty === `gs`) && (i.setAttribute(`stroke-linecap`, lineCapEnum[e.lc || 2]), i.setAttribute(`stroke-linejoin`, lineJoinEnum[e.lj || 2]), i.setAttribute(`fill-opacity`, `0`), e.lj === 1 && i.setAttribute(`stroke-miterlimit`, e.ml)), e.r === 2 && i.setAttribute(`fill-rule`, `evenodd`), e.ln && i.setAttribute(`id`, e.ln), e.cl && i.setAttribute(`class`, e.cl), e.bm && (i.style[`mix-blend-mode`] = getBlendMode(e.bm)), this.stylesList.push(r), this.addToAnimatedContents(e, n), n;
    }, SVGShapeElement.prototype.createGroupElement = function(e) {
      var t = new ShapeGroupData();
      return e.ln && t.gr.setAttribute(`id`, e.ln), e.cl && t.gr.setAttribute(`class`, e.cl), e.bm && (t.gr.style[`mix-blend-mode`] = getBlendMode(e.bm)), t;
    }, SVGShapeElement.prototype.createTransformElement = function(e, t) {
      var n = TransformPropertyFactory.getTransformProperty(this, e, this), r = new SVGTransformData(n, n.o, t);
      return this.addToAnimatedContents(e, r), r;
    }, SVGShapeElement.prototype.createShapeElement = function(e, t, n) {
      var r = 4;
      e.ty === `rc` ? r = 5 : e.ty === `el` ? r = 6 : e.ty === `sr` && (r = 7);
      var i = new SVGShapeData(t, n, ShapePropertyFactory.getShapeProp(this, e, r, this));
      return this.shapes.push(i), this.addShapeToModifiers(i), this.addToAnimatedContents(e, i), i;
    }, SVGShapeElement.prototype.addToAnimatedContents = function(e, t) {
      for (var n = 0, r = this.animatedContents.length; n < r; ) {
        if (this.animatedContents[n].element === t) return;
        n += 1;
      }
      this.animatedContents.push({ fn: SVGElementsRenderer.createRenderFunction(e), element: t, data: e });
    }, SVGShapeElement.prototype.setElementStyles = function(e) {
      var t = e.styles, n, r = this.stylesList.length;
      for (n = 0; n < r; n += 1) t.indexOf(this.stylesList[n]) === -1 && !this.stylesList[n].closed && t.push(this.stylesList[n]);
    }, SVGShapeElement.prototype.reloadShapes = function() {
      this._isFirstFrame = true;
      var e, t = this.itemsData.length;
      for (e = 0; e < t; e += 1) this.prevViewData[e] = this.itemsData[e];
      for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], true), this.filterUniqueShapes(), t = this.dynamicProperties.length, e = 0; e < t; e += 1) this.dynamicProperties[e].getValue();
      this.renderModifiers();
    }, SVGShapeElement.prototype.searchShapes = function(e, t, n, r, i, a, o) {
      var s = [].concat(a), c, l = e.length - 1, u, d, f = [], p = [], m, g, _;
      for (c = l; c >= 0; --c) {
        if (_ = this.searchProcessedElement(e[c]), _ ? t[c] = n[_ - 1] : e[c]._render = o, e[c].ty === `fl` || e[c].ty === `st` || e[c].ty === `gf` || e[c].ty === `gs` || e[c].ty === `no`) _ ? t[c].style.closed = e[c].hd : t[c] = this.createStyleElement(e[c], i), e[c]._render && t[c].style.pElem.parentNode !== r && r.appendChild(t[c].style.pElem), f.push(t[c].style);
        else if (e[c].ty === `gr`) {
          if (!_) t[c] = this.createGroupElement(e[c]);
          else for (d = t[c].it.length, u = 0; u < d; u += 1) t[c].prevViewData[u] = t[c].it[u];
          this.searchShapes(e[c].it, t[c].it, t[c].prevViewData, t[c].gr, i + 1, s, o), e[c]._render && t[c].gr.parentNode !== r && r.appendChild(t[c].gr);
        } else e[c].ty === `tr` ? (_ || (t[c] = this.createTransformElement(e[c], r)), m = t[c].transform, s.push(m)) : e[c].ty === `sh` || e[c].ty === `rc` || e[c].ty === `el` || e[c].ty === `sr` ? (_ || (t[c] = this.createShapeElement(e[c], s, i)), this.setElementStyles(t[c])) : e[c].ty === `tm` || e[c].ty === `rd` || e[c].ty === `ms` || e[c].ty === `pb` || e[c].ty === `zz` || e[c].ty === `op` ? (_ ? (g = t[c], g.closed = false) : (g = ShapeModifiers.getModifier(e[c].ty), g.init(this, e[c]), t[c] = g, this.shapeModifiers.push(g)), p.push(g)) : e[c].ty === `rp` && (_ ? (g = t[c], g.closed = true) : (g = ShapeModifiers.getModifier(e[c].ty), t[c] = g, g.init(this, e, c, t), this.shapeModifiers.push(g), o = false), p.push(g));
        this.addProcessedElement(e[c], c + 1);
      }
      for (l = f.length, c = 0; c < l; c += 1) f[c].closed = true;
      for (l = p.length, c = 0; c < l; c += 1) p[c].closed = true;
    }, SVGShapeElement.prototype.renderInnerContent = function() {
      this.renderModifiers();
      var e, t = this.stylesList.length;
      for (e = 0; e < t; e += 1) this.stylesList[e].reset();
      for (this.renderShape(), e = 0; e < t; e += 1) (this.stylesList[e]._mdf || this._isFirstFrame) && (this.stylesList[e].msElem && (this.stylesList[e].msElem.setAttribute(`d`, this.stylesList[e].d), this.stylesList[e].d = `M0 0` + this.stylesList[e].d), this.stylesList[e].pElem.setAttribute(`d`, this.stylesList[e].d || `M0 0`));
    }, SVGShapeElement.prototype.renderShape = function() {
      var e, t = this.animatedContents.length, n;
      for (e = 0; e < t; e += 1) n = this.animatedContents[e], (this._isFirstFrame || n.element._isAnimated) && n.data !== true && n.fn(n.data, n.element, this._isFirstFrame);
    }, SVGShapeElement.prototype.destroy = function() {
      this.destroyBaseElement(), this.shapesData = null, this.itemsData = null;
    };
    function LetterProps(e, t, n, r, i, a) {
      this.o = e, this.sw = t, this.sc = n, this.fc = r, this.m = i, this.p = a, this._mdf = { o: true, sw: !!t, sc: !!n, fc: !!r, m: true, p: true };
    }
    LetterProps.prototype.update = function(e, t, n, r, i, a) {
      this._mdf.o = false, this._mdf.sw = false, this._mdf.sc = false, this._mdf.fc = false, this._mdf.m = false, this._mdf.p = false;
      var o = false;
      return this.o !== e && (this.o = e, this._mdf.o = true, o = true), this.sw !== t && (this.sw = t, this._mdf.sw = true, o = true), this.sc !== n && (this.sc = n, this._mdf.sc = true, o = true), this.fc !== r && (this.fc = r, this._mdf.fc = true, o = true), this.m !== i && (this.m = i, this._mdf.m = true, o = true), a.length && (this.p[0] !== a[0] || this.p[1] !== a[1] || this.p[4] !== a[4] || this.p[5] !== a[5] || this.p[12] !== a[12] || this.p[13] !== a[13]) && (this.p = a, this._mdf.p = true, o = true), o;
    };
    function TextProperty(e, t) {
      this._frameId = initialDefaultFrame, this.pv = ``, this.v = ``, this.kf = false, this._isFirstFrame = true, this._mdf = false, t.d && t.d.sid && (t.d = e.globalData.slotManager.getProp(t.d)), this.data = t, this.elem = e, this.comp = this.elem.comp, this.keysIndex = 0, this.canResize = false, this.minimumFontSize = 1, this.effectsSequence = [], this.currentData = { ascent: 0, boxWidth: this.defaultBoxWidth, f: ``, fStyle: ``, fWeight: ``, fc: ``, j: ``, justifyOffset: ``, l: [], lh: 0, lineWidths: [], ls: ``, of: ``, s: ``, sc: ``, sw: 0, t: 0, tr: 0, sz: 0, ps: null, fillColorAnim: false, strokeColorAnim: false, strokeWidthAnim: false, yOffset: 0, finalSize: 0, finalText: [], finalLineHeight: 0, __complete: false }, this.copyData(this.currentData, this.data.d.k[0].s), this.searchProperty() || this.completeTextData(this.currentData);
    }
    TextProperty.prototype.defaultBoxWidth = [0, 0], TextProperty.prototype.copyData = function(e, t) {
      for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
      return e;
    }, TextProperty.prototype.setCurrentData = function(e) {
      e.__complete || this.completeTextData(e), this.currentData = e, this.currentData.boxWidth = this.currentData.boxWidth || this.defaultBoxWidth, this._mdf = true;
    }, TextProperty.prototype.searchProperty = function() {
      return this.searchKeyframes();
    }, TextProperty.prototype.searchKeyframes = function() {
      return this.kf = this.data.d.k.length > 1, this.kf && this.addEffect(this.getKeyframeValue.bind(this)), this.kf;
    }, TextProperty.prototype.addEffect = function(e) {
      this.effectsSequence.push(e), this.elem.addDynamicProperty(this);
    }, TextProperty.prototype.getValue = function(e) {
      if (this.elem.globalData.frameId !== this.frameId && this.effectsSequence.length || e) {
        this.currentData.t = this.data.d.k[this.keysIndex].s.t;
        var t = this.currentData, n = this.keysIndex;
        if (this.lock) {
          this.setCurrentData(this.currentData);
          return;
        }
        this.lock = true, this._mdf = false;
        var r, i = this.effectsSequence.length, a = e || this.data.d.k[this.keysIndex].s;
        for (r = 0; r < i; r += 1) a = n === this.keysIndex ? this.effectsSequence[r](this.currentData, a.t) : this.effectsSequence[r](a, a.t);
        t !== a && this.setCurrentData(a), this.v = this.currentData, this.pv = this.v, this.lock = false, this.frameId = this.elem.globalData.frameId;
      }
    }, TextProperty.prototype.getKeyframeValue = function() {
      for (var e = this.data.d.k, t = this.elem.comp.renderedFrame, n = 0, r = e.length; n <= r - 1 && !(n === r - 1 || e[n + 1].t > t); ) n += 1;
      return this.keysIndex !== n && (this.keysIndex = n), this.data.d.k[this.keysIndex].s;
    }, TextProperty.prototype.buildFinalText = function(e) {
      for (var t = [], n = 0, r = e.length, i, a, o = false, s = false, c = ``; n < r; ) o = s, s = false, i = e.charCodeAt(n), c = e.charAt(n), FontManager.isCombinedCharacter(i) ? o = true : i >= 55296 && i <= 56319 ? FontManager.isRegionalFlag(e, n) ? c = e.substr(n, 14) : (a = e.charCodeAt(n + 1), a >= 56320 && a <= 57343 && (FontManager.isModifier(i, a) ? (c = e.substr(n, 2), o = true) : c = FontManager.isFlagEmoji(e.substr(n, 4)) ? e.substr(n, 4) : e.substr(n, 2))) : i > 56319 ? (a = e.charCodeAt(n + 1), FontManager.isVariationSelector(i) && (o = true)) : FontManager.isZeroWidthJoiner(i) && (o = true, s = true), o ? (t[t.length - 1] += c, o = false) : t.push(c), n += c.length;
      return t;
    }, TextProperty.prototype.completeTextData = function(e) {
      e.__complete = true;
      var t = this.elem.globalData.fontManager, n = this.data, r = [], i, a, o, s = 0, c, l = n.m.g, u = 0, d = 0, f = 0, p = [], m = 0, g = 0, _, y, b = t.getFontByName(e.f), x, S = 0, C = getFontProperties(b);
      e.fWeight = C.weight, e.fStyle = C.style, e.finalSize = e.s, e.finalText = this.buildFinalText(e.t), a = e.finalText.length, e.finalLineHeight = e.lh;
      var T = e.tr / 1e3 * e.finalSize, E;
      if (e.sz) for (var D = true, O = e.sz[0], k = e.sz[1], A, j; D; ) {
        j = this.buildFinalText(e.t), A = 0, m = 0, a = j.length, T = e.tr / 1e3 * e.finalSize;
        var M = -1;
        for (i = 0; i < a; i += 1) E = j[i].charCodeAt(0), o = false, j[i] === ` ` ? M = i : (E === 13 || E === 3) && (m = 0, o = true, A += e.finalLineHeight || e.finalSize * 1.2), t.chars ? (x = t.getCharData(j[i], b.fStyle, b.fFamily), S = o ? 0 : x.w * e.finalSize / 100) : S = t.measureText(j[i], e.f, e.finalSize), m + S > O && j[i] !== ` ` ? (M === -1 ? a += 1 : i = M, A += e.finalLineHeight || e.finalSize * 1.2, j.splice(i, +(M === i), `\r`), M = -1, m = 0) : (m += S, m += T);
        A += b.ascent * e.finalSize / 100, this.canResize && e.finalSize > this.minimumFontSize && k < A ? (--e.finalSize, e.finalLineHeight = e.finalSize * e.lh / e.s) : (e.finalText = j, a = e.finalText.length, D = false);
      }
      m = -T, S = 0;
      var N = 0, P;
      for (i = 0; i < a; i += 1) if (o = false, P = e.finalText[i], E = P.charCodeAt(0), E === 13 || E === 3 ? (N = 0, p.push(m), g = m > g ? m : g, m = -2 * T, c = ``, o = true, f += 1) : c = P, t.chars ? (x = t.getCharData(P, b.fStyle, t.getFontByName(e.f).fFamily), S = o ? 0 : x.w * e.finalSize / 100) : S = t.measureText(c, e.f, e.finalSize), P === ` ` ? N += S + T : (m += S + T + N, N = 0), r.push({ l: S, an: S, add: u, n: o, anIndexes: [], val: c, line: f, animatorJustifyOffset: 0 }), l == 2) {
        if (u += S, c === `` || c === ` ` || i === a - 1) {
          for ((c === `` || c === ` `) && (u -= S); d <= i; ) r[d].an = u, r[d].ind = s, r[d].extra = S, d += 1;
          s += 1, u = 0;
        }
      } else if (l == 3) {
        if (u += S, c === `` || i === a - 1) {
          for (c === `` && (u -= S); d <= i; ) r[d].an = u, r[d].ind = s, r[d].extra = S, d += 1;
          u = 0, s += 1;
        }
      } else r[s].ind = s, r[s].extra = 0, s += 1;
      if (e.l = r, g = m > g ? m : g, p.push(m), e.sz) e.boxWidth = e.sz[0], e.justifyOffset = 0;
      else switch (e.boxWidth = g, e.j) {
        case 1:
          e.justifyOffset = -e.boxWidth;
          break;
        case 2:
          e.justifyOffset = -e.boxWidth / 2;
          break;
        default:
          e.justifyOffset = 0;
      }
      e.lineWidths = p;
      var F = n.a, I, L;
      y = F.length;
      var R, z, B = [];
      for (_ = 0; _ < y; _ += 1) {
        for (I = F[_], I.a.sc && (e.strokeColorAnim = true), I.a.sw && (e.strokeWidthAnim = true), (I.a.fc || I.a.fh || I.a.fs || I.a.fb) && (e.fillColorAnim = true), z = 0, R = I.s.b, i = 0; i < a; i += 1) L = r[i], L.anIndexes[_] = z, (R == 1 && L.val !== `` || R == 2 && L.val !== `` && L.val !== ` ` || R == 3 && (L.n || L.val == ` ` || i == a - 1) || R == 4 && (L.n || i == a - 1)) && (I.s.rn === 1 && B.push(z), z += 1);
        n.a[_].s.totalChars = z;
        var V = -1, H;
        if (I.s.rn === 1) for (i = 0; i < a; i += 1) L = r[i], V != L.anIndexes[_] && (V = L.anIndexes[_], H = B.splice(Math.floor(Math.random() * B.length), 1)[0]), L.anIndexes[_] = H;
      }
      e.yOffset = e.finalLineHeight || e.finalSize * 1.2, e.ls = e.ls || 0, e.ascent = b.ascent * e.finalSize / 100;
    }, TextProperty.prototype.updateDocumentData = function(e, t) {
      t = t === void 0 ? this.keysIndex : t;
      var n = this.copyData({}, this.data.d.k[t].s);
      n = this.copyData(n, e), this.data.d.k[t].s = n, this.recalculate(t), this.setCurrentData(n), this.elem.addDynamicProperty(this);
    }, TextProperty.prototype.recalculate = function(e) {
      var t = this.data.d.k[e].s;
      t.__complete = false, this.keysIndex = 0, this._isFirstFrame = true, this.getValue(t);
    }, TextProperty.prototype.canResizeFont = function(e) {
      this.canResize = e, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this);
    }, TextProperty.prototype.setMinimumFontSize = function(e) {
      this.minimumFontSize = Math.floor(e) || 1, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this);
    };
    var TextSelectorProp = (function() {
      var e = Math.max, t = Math.min, n = Math.floor;
      function r(e2, t2) {
        this._currentTextLength = -1, this.k = false, this.data = t2, this.elem = e2, this.comp = e2.comp, this.finalS = 0, this.finalE = 0, this.initDynamicPropertyContainer(e2), this.s = PropertyFactory.getProp(e2, t2.s || { k: 0 }, 0, 0, this), this.e = `e` in t2 ? PropertyFactory.getProp(e2, t2.e, 0, 0, this) : { v: 100 }, this.o = PropertyFactory.getProp(e2, t2.o || { k: 0 }, 0, 0, this), this.xe = PropertyFactory.getProp(e2, t2.xe || { k: 0 }, 0, 0, this), this.ne = PropertyFactory.getProp(e2, t2.ne || { k: 0 }, 0, 0, this), this.sm = PropertyFactory.getProp(e2, t2.sm || { k: 100 }, 0, 0, this), this.a = PropertyFactory.getProp(e2, t2.a, 0, 0.01, this), this.dynamicProperties.length || this.getValue();
      }
      r.prototype = { getMult: function(r2) {
        this._currentTextLength !== this.elem.textProperty.currentData.l.length && this.getValue();
        var i2 = 0, a = 0, o = 1, s = 1;
        this.ne.v > 0 ? i2 = this.ne.v / 100 : a = -this.ne.v / 100, this.xe.v > 0 ? o = 1 - this.xe.v / 100 : s = 1 + this.xe.v / 100;
        var c = BezierFactory.getBezierEasing(i2, a, o, s).get, l = 0, u = this.finalS, d = this.finalE, f = this.data.sh;
        if (f === 2) l = d === u ? +(r2 >= d) : e(0, t(0.5 / (d - u) + (r2 - u) / (d - u), 1)), l = c(l);
        else if (f === 3) l = d === u ? r2 >= d ? 0 : 1 : 1 - e(0, t(0.5 / (d - u) + (r2 - u) / (d - u), 1)), l = c(l);
        else if (f === 4) d === u ? l = 0 : (l = e(0, t(0.5 / (d - u) + (r2 - u) / (d - u), 1)), l < 0.5 ? l *= 2 : l = 1 - 2 * (l - 0.5)), l = c(l);
        else if (f === 5) {
          if (d === u) l = 0;
          else {
            var p = d - u;
            r2 = t(e(0, r2 + 0.5 - u), d - u);
            var m = -p / 2 + r2, g = p / 2;
            l = Math.sqrt(1 - m * m / (g * g));
          }
          l = c(l);
        } else f === 6 ? (d === u ? l = 0 : (r2 = t(e(0, r2 + 0.5 - u), d - u), l = (1 + Math.cos(Math.PI + Math.PI * 2 * r2 / (d - u))) / 2), l = c(l)) : (r2 >= n(u) && (l = r2 - u < 0 ? e(0, t(t(d, 1) - (u - r2), 1)) : e(0, t(d - r2, 1))), l = c(l));
        if (this.sm.v !== 100) {
          var _ = this.sm.v * 0.01;
          _ === 0 && (_ = 1e-8);
          var y = 0.5 - _ * 0.5;
          l < y ? l = 0 : (l = (l - y) / _, l > 1 && (l = 1));
        }
        return l * this.a.v;
      }, getValue: function(e2) {
        this.iterateDynamicProperties(), this._mdf = e2 || this._mdf, this._currentTextLength = this.elem.textProperty.currentData.l.length || 0, e2 && this.data.r === 2 && (this.e.v = this._currentTextLength);
        var t2 = this.data.r === 2 ? 1 : 100 / this.data.totalChars, n2 = this.o.v / t2, r2 = this.s.v / t2 + n2, i2 = this.e.v / t2 + n2;
        if (r2 > i2) {
          var a = r2;
          r2 = i2, i2 = a;
        }
        this.finalS = r2, this.finalE = i2;
      } }, extendPrototype([DynamicPropertyContainer], r);
      function i(e2, t2, n2) {
        return new r(e2, t2, n2);
      }
      return { getTextSelectorProp: i };
    })();
    function TextAnimatorDataProperty(e, t, n) {
      var r = { propType: false }, i = PropertyFactory.getProp, a = t.a;
      this.a = { r: a.r ? i(e, a.r, 0, degToRads, n) : r, rx: a.rx ? i(e, a.rx, 0, degToRads, n) : r, ry: a.ry ? i(e, a.ry, 0, degToRads, n) : r, sk: a.sk ? i(e, a.sk, 0, degToRads, n) : r, sa: a.sa ? i(e, a.sa, 0, degToRads, n) : r, s: a.s ? i(e, a.s, 1, 0.01, n) : r, a: a.a ? i(e, a.a, 1, 0, n) : r, o: a.o ? i(e, a.o, 0, 0.01, n) : r, p: a.p ? i(e, a.p, 1, 0, n) : r, sw: a.sw ? i(e, a.sw, 0, 0, n) : r, sc: a.sc ? i(e, a.sc, 1, 0, n) : r, fc: a.fc ? i(e, a.fc, 1, 0, n) : r, fh: a.fh ? i(e, a.fh, 0, 0, n) : r, fs: a.fs ? i(e, a.fs, 0, 0.01, n) : r, fb: a.fb ? i(e, a.fb, 0, 0.01, n) : r, t: a.t ? i(e, a.t, 0, 0, n) : r }, this.s = TextSelectorProp.getTextSelectorProp(e, t.s, n), this.s.t = t.s.t;
    }
    function TextAnimatorProperty(e, t, n) {
      this._isFirstFrame = true, this._hasMaskedPath = false, this._frameId = -1, this._textData = e, this._renderType = t, this._elem = n, this._animatorsData = createSizedArray(this._textData.a.length), this._pathData = {}, this._moreOptions = { alignment: {} }, this.renderedLetters = [], this.lettersChangedFlag = false, this.initDynamicPropertyContainer(n);
    }
    TextAnimatorProperty.prototype.searchProperties = function() {
      var e, t = this._textData.a.length, n, r = PropertyFactory.getProp;
      for (e = 0; e < t; e += 1) n = this._textData.a[e], this._animatorsData[e] = new TextAnimatorDataProperty(this._elem, n, this);
      this._textData.p && `m` in this._textData.p ? (this._pathData = { a: r(this._elem, this._textData.p.a, 0, 0, this), f: r(this._elem, this._textData.p.f, 0, 0, this), l: r(this._elem, this._textData.p.l, 0, 0, this), r: r(this._elem, this._textData.p.r, 0, 0, this), p: r(this._elem, this._textData.p.p, 0, 0, this), m: this._elem.maskManager.getMaskProperty(this._textData.p.m) }, this._hasMaskedPath = true) : this._hasMaskedPath = false, this._moreOptions.alignment = r(this._elem, this._textData.m.a, 1, 0, this);
    }, TextAnimatorProperty.prototype.getMeasures = function(e, t) {
      if (this.lettersChangedFlag = t, this._mdf || this._isFirstFrame || t || this._hasMaskedPath && this._pathData.m._mdf) {
        this._isFirstFrame = false;
        var n = this._moreOptions.alignment.v, r = this._animatorsData, i = this._textData, a = this.mHelper, o = this._renderType, s = this.renderedLetters.length, c, l, u, d, f = e.l, p, m, g, _, y, b, x, S, C, T, E, D, O, k, A;
        if (this._hasMaskedPath) {
          if (A = this._pathData.m, !this._pathData.n || this._pathData._mdf) {
            var j = A.v;
            this._pathData.r.v && (j = j.reverse()), p = { tLength: 0, segments: [] }, d = j._length - 1;
            var M;
            for (D = 0, u = 0; u < d; u += 1) M = bez.buildBezierData(j.v[u], j.v[u + 1], [j.o[u][0] - j.v[u][0], j.o[u][1] - j.v[u][1]], [j.i[u + 1][0] - j.v[u + 1][0], j.i[u + 1][1] - j.v[u + 1][1]]), p.tLength += M.segmentLength, p.segments.push(M), D += M.segmentLength;
            u = d, A.v.c && (M = bez.buildBezierData(j.v[u], j.v[0], [j.o[u][0] - j.v[u][0], j.o[u][1] - j.v[u][1]], [j.i[0][0] - j.v[0][0], j.i[0][1] - j.v[0][1]]), p.tLength += M.segmentLength, p.segments.push(M), D += M.segmentLength), this._pathData.pi = p;
          }
          if (p = this._pathData.pi, m = this._pathData.f.v, x = 0, b = 1, _ = 0, y = true, T = p.segments, m < 0 && A.v.c) for (p.tLength < Math.abs(m) && (m = -Math.abs(m) % p.tLength), x = T.length - 1, C = T[x].points, b = C.length - 1; m < 0; ) m += C[b].partialLength, --b, b < 0 && (--x, C = T[x].points, b = C.length - 1);
          C = T[x].points, S = C[b - 1], g = C[b], E = g.partialLength;
        }
        d = f.length, c = 0, l = 0;
        var N = e.finalSize * 1.2 * 0.714, P = true, F, I, L, R = r.length, z, B, V = -1, H, ee, te, ne = m, re = x, ie = b, ae = -1, U, W, G, K, q, J, oe, Y, X = ``, se = this.defaultPropsArray, ce;
        if (e.j === 2 || e.j === 1) {
          var Z = 0, le = 0, ue = e.j === 2 ? -0.5 : -1, Q = 0, de = true;
          for (u = 0; u < d; u += 1) if (f[u].n) {
            for (Z && (Z += le); Q < u; ) f[Q].animatorJustifyOffset = Z, Q += 1;
            Z = 0, de = true;
          } else {
            for (L = 0; L < R; L += 1) F = r[L].a, F.t.propType && (de && e.j === 2 && (le += F.t.v * ue), I = r[L].s, B = I.getMult(f[u].anIndexes[L], i.a[L].s.totalChars), B.length ? Z += F.t.v * B[0] * ue : Z += F.t.v * B * ue);
            de = false;
          }
          for (Z && (Z += le); Q < u; ) f[Q].animatorJustifyOffset = Z, Q += 1;
        }
        for (u = 0; u < d; u += 1) {
          if (a.reset(), U = 1, f[u].n) c = 0, l += e.yOffset, l += +!!P, m = ne, P = false, this._hasMaskedPath && (x = re, b = ie, C = T[x].points, S = C[b - 1], g = C[b], E = g.partialLength, _ = 0), X = ``, Y = ``, J = ``, ce = ``, se = this.defaultPropsArray;
          else {
            if (this._hasMaskedPath) {
              if (ae !== f[u].line) {
                switch (e.j) {
                  case 1:
                    m += D - e.lineWidths[f[u].line];
                    break;
                  case 2:
                    m += (D - e.lineWidths[f[u].line]) / 2;
                }
                ae = f[u].line;
              }
              V !== f[u].ind && (f[V] && (m += f[V].extra), m += f[u].an / 2, V = f[u].ind), m += n[0] * f[u].an * 5e-3;
              var $ = 0;
              for (L = 0; L < R; L += 1) F = r[L].a, F.p.propType && (I = r[L].s, B = I.getMult(f[u].anIndexes[L], i.a[L].s.totalChars), B.length ? $ += F.p.v[0] * B[0] : $ += F.p.v[0] * B), F.a.propType && (I = r[L].s, B = I.getMult(f[u].anIndexes[L], i.a[L].s.totalChars), B.length ? $ += F.a.v[0] * B[0] : $ += F.a.v[0] * B);
              for (y = true, this._pathData.a.v && (m = f[0].an * 0.5 + (D - this._pathData.f.v - f[0].an * 0.5 - f[f.length - 1].an * 0.5) * V / (d - 1), m += this._pathData.f.v); y; ) _ + E >= m + $ || !C ? (O = (m + $ - _) / g.partialLength, ee = S.point[0] + (g.point[0] - S.point[0]) * O, te = S.point[1] + (g.point[1] - S.point[1]) * O, a.translate(-n[0] * f[u].an * 5e-3, -(n[1] * N) * 0.01), y = false) : C && (_ += g.partialLength, b += 1, b >= C.length && (b = 0, x += 1, T[x] ? C = T[x].points : A.v.c ? (b = 0, x = 0, C = T[x].points) : (_ -= g.partialLength, C = null)), C && (S = g, g = C[b], E = g.partialLength));
              H = f[u].an / 2 - f[u].add, a.translate(-H, 0, 0);
            } else H = f[u].an / 2 - f[u].add, a.translate(-H, 0, 0), a.translate(-n[0] * f[u].an * 5e-3, -n[1] * N * 0.01, 0);
            for (L = 0; L < R; L += 1) F = r[L].a, F.t.propType && (I = r[L].s, B = I.getMult(f[u].anIndexes[L], i.a[L].s.totalChars), (c !== 0 || e.j !== 0) && (this._hasMaskedPath ? B.length ? m += F.t.v * B[0] : m += F.t.v * B : B.length ? c += F.t.v * B[0] : c += F.t.v * B));
            for (e.strokeWidthAnim && (G = e.sw || 0), e.strokeColorAnim && (W = e.sc ? [e.sc[0], e.sc[1], e.sc[2]] : [0, 0, 0]), e.fillColorAnim && e.fc && (K = [e.fc[0], e.fc[1], e.fc[2]]), L = 0; L < R; L += 1) F = r[L].a, F.a.propType && (I = r[L].s, B = I.getMult(f[u].anIndexes[L], i.a[L].s.totalChars), B.length ? a.translate(-F.a.v[0] * B[0], -F.a.v[1] * B[1], F.a.v[2] * B[2]) : a.translate(-F.a.v[0] * B, -F.a.v[1] * B, F.a.v[2] * B));
            for (L = 0; L < R; L += 1) F = r[L].a, F.s.propType && (I = r[L].s, B = I.getMult(f[u].anIndexes[L], i.a[L].s.totalChars), B.length ? a.scale(1 + (F.s.v[0] - 1) * B[0], 1 + (F.s.v[1] - 1) * B[1], 1) : a.scale(1 + (F.s.v[0] - 1) * B, 1 + (F.s.v[1] - 1) * B, 1));
            for (L = 0; L < R; L += 1) {
              if (F = r[L].a, I = r[L].s, B = I.getMult(f[u].anIndexes[L], i.a[L].s.totalChars), F.sk.propType && (B.length ? a.skewFromAxis(-F.sk.v * B[0], F.sa.v * B[1]) : a.skewFromAxis(-F.sk.v * B, F.sa.v * B)), F.r.propType && (B.length ? a.rotateZ(-F.r.v * B[2]) : a.rotateZ(-F.r.v * B)), F.ry.propType && (B.length ? a.rotateY(F.ry.v * B[1]) : a.rotateY(F.ry.v * B)), F.rx.propType && (B.length ? a.rotateX(F.rx.v * B[0]) : a.rotateX(F.rx.v * B)), F.o.propType && (B.length ? U += (F.o.v * B[0] - U) * B[0] : U += (F.o.v * B - U) * B), e.strokeWidthAnim && F.sw.propType && (B.length ? G += F.sw.v * B[0] : G += F.sw.v * B), e.strokeColorAnim && F.sc.propType) for (q = 0; q < 3; q += 1) B.length ? W[q] += (F.sc.v[q] - W[q]) * B[0] : W[q] += (F.sc.v[q] - W[q]) * B;
              if (e.fillColorAnim && e.fc) {
                if (F.fc.propType) for (q = 0; q < 3; q += 1) B.length ? K[q] += (F.fc.v[q] - K[q]) * B[0] : K[q] += (F.fc.v[q] - K[q]) * B;
                F.fh.propType && (K = B.length ? addHueToRGB(K, F.fh.v * B[0]) : addHueToRGB(K, F.fh.v * B)), F.fs.propType && (K = B.length ? addSaturationToRGB(K, F.fs.v * B[0]) : addSaturationToRGB(K, F.fs.v * B)), F.fb.propType && (K = B.length ? addBrightnessToRGB(K, F.fb.v * B[0]) : addBrightnessToRGB(K, F.fb.v * B));
              }
            }
            for (L = 0; L < R; L += 1) F = r[L].a, F.p.propType && (I = r[L].s, B = I.getMult(f[u].anIndexes[L], i.a[L].s.totalChars), this._hasMaskedPath ? B.length ? a.translate(0, F.p.v[1] * B[0], -F.p.v[2] * B[1]) : a.translate(0, F.p.v[1] * B, -F.p.v[2] * B) : B.length ? a.translate(F.p.v[0] * B[0], F.p.v[1] * B[1], -F.p.v[2] * B[2]) : a.translate(F.p.v[0] * B, F.p.v[1] * B, -F.p.v[2] * B));
            if (e.strokeWidthAnim && (J = G < 0 ? 0 : G), e.strokeColorAnim && (oe = `rgb(` + Math.round(W[0] * 255) + `,` + Math.round(W[1] * 255) + `,` + Math.round(W[2] * 255) + `)`), e.fillColorAnim && e.fc && (Y = `rgb(` + Math.round(K[0] * 255) + `,` + Math.round(K[1] * 255) + `,` + Math.round(K[2] * 255) + `)`), this._hasMaskedPath) {
              if (a.translate(0, -e.ls), a.translate(0, n[1] * N * 0.01 + l, 0), this._pathData.p.v) {
                k = (g.point[1] - S.point[1]) / (g.point[0] - S.point[0]);
                var fe = Math.atan(k) * 180 / Math.PI;
                g.point[0] < S.point[0] && (fe += 180), a.rotate(-fe * Math.PI / 180);
              }
              a.translate(ee, te, 0), m -= n[0] * f[u].an * 5e-3, f[u + 1] && V !== f[u + 1].ind && (m += f[u].an / 2, m += e.tr * 1e-3 * e.finalSize);
            } else {
              switch (a.translate(c, l, 0), e.ps && a.translate(e.ps[0], e.ps[1] + e.ascent, 0), e.j) {
                case 1:
                  a.translate(f[u].animatorJustifyOffset + e.justifyOffset + (e.boxWidth - e.lineWidths[f[u].line]), 0, 0);
                  break;
                case 2:
                  a.translate(f[u].animatorJustifyOffset + e.justifyOffset + (e.boxWidth - e.lineWidths[f[u].line]) / 2, 0, 0);
              }
              a.translate(0, -e.ls), a.translate(H, 0, 0), a.translate(n[0] * f[u].an * 5e-3, n[1] * N * 0.01, 0), c += f[u].l + e.tr * 1e-3 * e.finalSize;
            }
            o === `html` ? X = a.toCSS() : o === `svg` ? X = a.to2dCSS() : se = [a.props[0], a.props[1], a.props[2], a.props[3], a.props[4], a.props[5], a.props[6], a.props[7], a.props[8], a.props[9], a.props[10], a.props[11], a.props[12], a.props[13], a.props[14], a.props[15]], ce = U;
          }
          s <= u ? (z = new LetterProps(ce, J, oe, Y, X, se), this.renderedLetters.push(z), s += 1, this.lettersChangedFlag = true) : (z = this.renderedLetters[u], this.lettersChangedFlag = z.update(ce, J, oe, Y, X, se) || this.lettersChangedFlag);
        }
      }
    }, TextAnimatorProperty.prototype.getValue = function() {
      this._elem.globalData.frameId !== this._frameId && (this._frameId = this._elem.globalData.frameId, this.iterateDynamicProperties());
    }, TextAnimatorProperty.prototype.mHelper = new Matrix(), TextAnimatorProperty.prototype.defaultPropsArray = [], extendPrototype([DynamicPropertyContainer], TextAnimatorProperty);
    function ITextElement() {
    }
    ITextElement.prototype.initElement = function(e, t, n) {
      this.lettersChangedFlag = true, this.initFrame(), this.initBaseData(e, t, n), this.textProperty = new TextProperty(this, e.t, this.dynamicProperties), this.textAnimator = new TextAnimatorProperty(e.t, this.renderType, this), this.initTransform(e, t, n), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide(), this.textAnimator.searchProperties(this.dynamicProperties);
    }, ITextElement.prototype.prepareFrame = function(e) {
      this._mdf = false, this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange);
    }, ITextElement.prototype.createPathShape = function(e, t) {
      var n, r = t.length, i, a = ``;
      for (n = 0; n < r; n += 1) t[n].ty === `sh` && (i = t[n].ks.k, a += buildShapeString(i, i.i.length, true, e));
      return a;
    }, ITextElement.prototype.updateDocumentData = function(e, t) {
      this.textProperty.updateDocumentData(e, t);
    }, ITextElement.prototype.canResizeFont = function(e) {
      this.textProperty.canResizeFont(e);
    }, ITextElement.prototype.setMinimumFontSize = function(e) {
      this.textProperty.setMinimumFontSize(e);
    }, ITextElement.prototype.applyTextPropertiesToMatrix = function(e, t, n, r, i) {
      switch (e.ps && t.translate(e.ps[0], e.ps[1] + e.ascent, 0), t.translate(0, -e.ls, 0), e.j) {
        case 1:
          t.translate(e.justifyOffset + (e.boxWidth - e.lineWidths[n]), 0, 0);
          break;
        case 2:
          t.translate(e.justifyOffset + (e.boxWidth - e.lineWidths[n]) / 2, 0, 0);
      }
      t.translate(r, i, 0);
    }, ITextElement.prototype.buildColor = function(e) {
      return `rgb(` + Math.round(e[0] * 255) + `,` + Math.round(e[1] * 255) + `,` + Math.round(e[2] * 255) + `)`;
    }, ITextElement.prototype.emptyProp = new LetterProps(), ITextElement.prototype.destroy = function() {
    }, ITextElement.prototype.validateText = function() {
      (this.textProperty._mdf || this.textProperty._isFirstFrame) && (this.buildNewText(), this.textProperty._isFirstFrame = false, this.textProperty._mdf = false);
    };
    var emptyShapeData = { shapes: [] };
    function SVGTextLottieElement(e, t, n) {
      this.textSpans = [], this.renderType = `svg`, this.initElement(e, t, n);
    }
    extendPrototype([BaseElement, TransformElement, SVGBaseElement, HierarchyElement, FrameElement, RenderableDOMElement, ITextElement], SVGTextLottieElement), SVGTextLottieElement.prototype.createContent = function() {
      this.data.singleShape && !this.globalData.fontManager.chars && (this.textContainer = createNS(`text`));
    }, SVGTextLottieElement.prototype.buildTextContents = function(e) {
      for (var t = 0, n = e.length, r = [], i = ``; t < n; ) e[t] === `\r` || e[t] === `` ? (r.push(i), i = ``) : i += e[t], t += 1;
      return r.push(i), r;
    }, SVGTextLottieElement.prototype.buildShapeData = function(e, t) {
      if (e.shapes && e.shapes.length) {
        var n = e.shapes[0];
        if (n.it) {
          var r = n.it[n.it.length - 1];
          r.s && (r.s.k[0] = t, r.s.k[1] = t);
        }
      }
      return e;
    }, SVGTextLottieElement.prototype.buildNewText = function() {
      this.addDynamicProperty(this);
      var e, t, n = this.textProperty.currentData;
      this.renderedLetters = createSizedArray(n ? n.l.length : 0), n.fc ? this.layerElement.setAttribute(`fill`, this.buildColor(n.fc)) : this.layerElement.setAttribute(`fill`, `rgba(0,0,0,0)`), n.sc && (this.layerElement.setAttribute(`stroke`, this.buildColor(n.sc)), this.layerElement.setAttribute(`stroke-width`, n.sw)), this.layerElement.setAttribute(`font-size`, n.finalSize);
      var r = this.globalData.fontManager.getFontByName(n.f);
      if (r.fClass) this.layerElement.setAttribute(`class`, r.fClass);
      else {
        this.layerElement.setAttribute(`font-family`, r.fFamily);
        var i = n.fWeight, a = n.fStyle;
        this.layerElement.setAttribute(`font-style`, a), this.layerElement.setAttribute(`font-weight`, i);
      }
      this.layerElement.setAttribute(`aria-label`, n.t);
      var o = n.l || [], s = !!this.globalData.fontManager.chars;
      t = o.length;
      var c, l = this.mHelper, u = ``, d = this.data.singleShape, f = 0, p = 0, m = true, g = n.tr * 1e-3 * n.finalSize;
      if (d && !s && !n.sz) {
        var _ = this.textContainer, y = `start`;
        switch (n.j) {
          case 1:
            y = `end`;
            break;
          case 2:
            y = `middle`;
            break;
          default:
            y = `start`;
        }
        _.setAttribute(`text-anchor`, y), _.setAttribute(`letter-spacing`, g);
        var b = this.buildTextContents(n.finalText);
        for (t = b.length, p = n.ps ? n.ps[1] + n.ascent : 0, e = 0; e < t; e += 1) c = this.textSpans[e].span || createNS(`tspan`), c.textContent = b[e], c.setAttribute(`x`, 0), c.setAttribute(`y`, p), c.style.display = `inherit`, _.appendChild(c), this.textSpans[e] || (this.textSpans[e] = { span: null, glyph: null }), this.textSpans[e].span = c, p += n.finalLineHeight;
        this.layerElement.appendChild(_);
      } else {
        var x = this.textSpans.length, S;
        for (e = 0; e < t; e += 1) {
          if (this.textSpans[e] || (this.textSpans[e] = { span: null, childSpan: null, glyph: null }), !s || !d || e === 0) {
            if (c = x > e ? this.textSpans[e].span : createNS(s ? `g` : `text`), x <= e) {
              if (c.setAttribute(`stroke-linecap`, `butt`), c.setAttribute(`stroke-linejoin`, `round`), c.setAttribute(`stroke-miterlimit`, `4`), this.textSpans[e].span = c, s) {
                var C = createNS(`g`);
                c.appendChild(C), this.textSpans[e].childSpan = C;
              }
              this.textSpans[e].span = c, this.layerElement.appendChild(c);
            }
            c.style.display = `inherit`;
          }
          if (l.reset(), d && (o[e].n && (f = -g, p += n.yOffset, p += +!!m, m = false), this.applyTextPropertiesToMatrix(n, l, o[e].line, f, p), f += o[e].l || 0, f += g), s) {
            S = this.globalData.fontManager.getCharData(n.finalText[e], r.fStyle, this.globalData.fontManager.getFontByName(n.f).fFamily);
            var T;
            if (S.t === 1) T = new SVGCompElement(S.data, this.globalData, this);
            else {
              var E = emptyShapeData;
              S.data && S.data.shapes && (E = this.buildShapeData(S.data, n.finalSize)), T = new SVGShapeElement(E, this.globalData, this);
            }
            if (this.textSpans[e].glyph) {
              var D = this.textSpans[e].glyph;
              this.textSpans[e].childSpan.removeChild(D.layerElement), D.destroy();
            }
            this.textSpans[e].glyph = T, T._debug = true, T.prepareFrame(0), T.renderFrame(), this.textSpans[e].childSpan.appendChild(T.layerElement), S.t === 1 && this.textSpans[e].childSpan.setAttribute(`transform`, `scale(` + n.finalSize / 100 + `,` + n.finalSize / 100 + `)`);
          } else d && c.setAttribute(`transform`, `translate(` + l.props[12] + `,` + l.props[13] + `)`), c.textContent = o[e].val, c.setAttributeNS(`http://www.w3.org/XML/1998/namespace`, `xml:space`, `preserve`);
        }
        d && c && c.setAttribute(`d`, u);
      }
      for (; e < this.textSpans.length; ) this.textSpans[e].span.style.display = `none`, e += 1;
      this._sizeChanged = true;
    }, SVGTextLottieElement.prototype.sourceRectAtTime = function() {
      if (this.prepareFrame(this.comp.renderedFrame - this.data.st), this.renderInnerContent(), this._sizeChanged) {
        this._sizeChanged = false;
        var e = this.layerElement.getBBox();
        this.bbox = { top: e.y, left: e.x, width: e.width, height: e.height };
      }
      return this.bbox;
    }, SVGTextLottieElement.prototype.getValue = function() {
      var e, t = this.textSpans.length, n;
      for (this.renderedFrame = this.comp.renderedFrame, e = 0; e < t; e += 1) n = this.textSpans[e].glyph, n && (n.prepareFrame(this.comp.renderedFrame - this.data.st), n._mdf && (this._mdf = true));
    }, SVGTextLottieElement.prototype.renderInnerContent = function() {
      if (this.validateText(), (!this.data.singleShape || this._mdf) && (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag)) {
        this._sizeChanged = true;
        var e, t, n = this.textAnimator.renderedLetters, r = this.textProperty.currentData.l;
        t = r.length;
        var i, a, o;
        for (e = 0; e < t; e += 1) r[e].n || (i = n[e], a = this.textSpans[e].span, o = this.textSpans[e].glyph, o && o.renderFrame(), i._mdf.m && a.setAttribute(`transform`, i.m), i._mdf.o && a.setAttribute(`opacity`, i.o), i._mdf.sw && a.setAttribute(`stroke-width`, i.sw), i._mdf.sc && a.setAttribute(`stroke`, i.sc), i._mdf.fc && a.setAttribute(`fill`, i.fc));
      }
    };
    function ISolidElement(e, t, n) {
      this.initElement(e, t, n);
    }
    extendPrototype([IImageElement], ISolidElement), ISolidElement.prototype.createContent = function() {
      var e = createNS(`rect`);
      e.setAttribute(`width`, this.data.sw), e.setAttribute(`height`, this.data.sh), e.setAttribute(`fill`, this.data.sc), this.layerElement.appendChild(e);
    };
    function NullElement(e, t, n) {
      this.initFrame(), this.initBaseData(e, t, n), this.initFrame(), this.initTransform(e, t, n), this.initHierarchy();
    }
    NullElement.prototype.prepareFrame = function(e) {
      this.prepareProperties(e, true);
    }, NullElement.prototype.renderFrame = function() {
    }, NullElement.prototype.getBaseElement = function() {
      return null;
    }, NullElement.prototype.destroy = function() {
    }, NullElement.prototype.sourceRectAtTime = function() {
    }, NullElement.prototype.hide = function() {
    }, extendPrototype([BaseElement, TransformElement, HierarchyElement, FrameElement], NullElement);
    function SVGRendererBase() {
    }
    extendPrototype([BaseRenderer], SVGRendererBase), SVGRendererBase.prototype.createNull = function(e) {
      return new NullElement(e, this.globalData, this);
    }, SVGRendererBase.prototype.createShape = function(e) {
      return new SVGShapeElement(e, this.globalData, this);
    }, SVGRendererBase.prototype.createText = function(e) {
      return new SVGTextLottieElement(e, this.globalData, this);
    }, SVGRendererBase.prototype.createImage = function(e) {
      return new IImageElement(e, this.globalData, this);
    }, SVGRendererBase.prototype.createSolid = function(e) {
      return new ISolidElement(e, this.globalData, this);
    }, SVGRendererBase.prototype.configAnimation = function(e) {
      this.svgElement.setAttribute(`xmlns`, `http://www.w3.org/2000/svg`), this.svgElement.setAttribute(`xmlns:xlink`, `http://www.w3.org/1999/xlink`), this.renderConfig.viewBoxSize ? this.svgElement.setAttribute(`viewBox`, this.renderConfig.viewBoxSize) : this.svgElement.setAttribute(`viewBox`, `0 0 ` + e.w + ` ` + e.h), this.renderConfig.viewBoxOnly || (this.svgElement.setAttribute(`width`, e.w), this.svgElement.setAttribute(`height`, e.h), this.svgElement.style.width = `100%`, this.svgElement.style.height = `100%`, this.svgElement.style.transform = `translate3d(0,0,0)`, this.svgElement.style.contentVisibility = this.renderConfig.contentVisibility), this.renderConfig.width && this.svgElement.setAttribute(`width`, this.renderConfig.width), this.renderConfig.height && this.svgElement.setAttribute(`height`, this.renderConfig.height), this.renderConfig.className && this.svgElement.setAttribute(`class`, this.renderConfig.className), this.renderConfig.id && this.svgElement.setAttribute(`id`, this.renderConfig.id), this.renderConfig.focusable !== void 0 && this.svgElement.setAttribute(`focusable`, this.renderConfig.focusable), this.svgElement.setAttribute(`preserveAspectRatio`, this.renderConfig.preserveAspectRatio), this.animationItem.wrapper.appendChild(this.svgElement);
      var t = this.globalData.defs;
      this.setupGlobalData(e, t), this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.data = e;
      var n = createNS(`clipPath`), r = createNS(`rect`);
      r.setAttribute(`width`, e.w), r.setAttribute(`height`, e.h), r.setAttribute(`x`, 0), r.setAttribute(`y`, 0);
      var i = createElementID();
      n.setAttribute(`id`, i), n.appendChild(r), this.layerElement.setAttribute(`clip-path`, `url(` + getLocationHref() + `#` + i + `)`), t.appendChild(n), this.layers = e.layers, this.elements = createSizedArray(e.layers.length);
    }, SVGRendererBase.prototype.destroy = function() {
      this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ``), this.layerElement = null, this.globalData.defs = null;
      var e, t = this.layers ? this.layers.length : 0;
      for (e = 0; e < t; e += 1) this.elements[e] && this.elements[e].destroy && this.elements[e].destroy();
      this.elements.length = 0, this.destroyed = true, this.animationItem = null;
    }, SVGRendererBase.prototype.updateContainerSize = function() {
    }, SVGRendererBase.prototype.findIndexByInd = function(e) {
      var t = 0, n = this.layers.length;
      for (t = 0; t < n; t += 1) if (this.layers[t].ind === e) return t;
      return -1;
    }, SVGRendererBase.prototype.buildItem = function(e) {
      var t = this.elements;
      if (!(t[e] || this.layers[e].ty === 99)) {
        t[e] = true;
        var n = this.createItem(this.layers[e]);
        if (t[e] = n, getExpressionsPlugin() && (this.layers[e].ty === 0 && this.globalData.projectInterface.registerComposition(n), n.initExpressions()), this.appendElementInPos(n, e), this.layers[e].tt) {
          var r = `tp` in this.layers[e] ? this.findIndexByInd(this.layers[e].tp) : e - 1;
          if (r === -1) return;
          if (!this.elements[r] || this.elements[r] === true) this.buildItem(r), this.addPendingElement(n);
          else {
            var i = t[r].getMatte(this.layers[e].tt);
            n.setMatte(i);
          }
        }
      }
    }, SVGRendererBase.prototype.checkPendingElements = function() {
      for (; this.pendingElements.length; ) {
        var e = this.pendingElements.pop();
        if (e.checkParenting(), e.data.tt) for (var t = 0, n = this.elements.length; t < n; ) {
          if (this.elements[t] === e) {
            var r = `tp` in e.data ? this.findIndexByInd(e.data.tp) : t - 1, i = this.elements[r].getMatte(this.layers[t].tt);
            e.setMatte(i);
            break;
          }
          t += 1;
        }
      }
    }, SVGRendererBase.prototype.renderFrame = function(e) {
      if (!(this.renderedFrame === e || this.destroyed)) {
        e === null ? e = this.renderedFrame : this.renderedFrame = e, this.globalData.frameNum = e, this.globalData.frameId += 1, this.globalData.projectInterface.currentFrame = e, this.globalData._mdf = false;
        var t, n = this.layers.length;
        for (this.completeLayers || this.checkLayers(e), t = n - 1; t >= 0; --t) (this.completeLayers || this.elements[t]) && this.elements[t].prepareFrame(e - this.layers[t].st);
        if (this.globalData._mdf) for (t = 0; t < n; t += 1) (this.completeLayers || this.elements[t]) && this.elements[t].renderFrame();
      }
    }, SVGRendererBase.prototype.appendElementInPos = function(e, t) {
      var n = e.getBaseElement();
      if (n) {
        for (var r = 0, i; r < t; ) this.elements[r] && this.elements[r] !== true && this.elements[r].getBaseElement() && (i = this.elements[r].getBaseElement()), r += 1;
        i ? this.layerElement.insertBefore(n, i) : this.layerElement.appendChild(n);
      }
    }, SVGRendererBase.prototype.hide = function() {
      this.layerElement.style.display = `none`;
    }, SVGRendererBase.prototype.show = function() {
      this.layerElement.style.display = `block`;
    };
    function ICompElement() {
    }
    extendPrototype([BaseElement, TransformElement, HierarchyElement, FrameElement, RenderableDOMElement], ICompElement), ICompElement.prototype.initElement = function(e, t, n) {
      this.initFrame(), this.initBaseData(e, t, n), this.initTransform(e, t, n), this.initRenderable(), this.initHierarchy(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), (this.data.xt || !t.progressiveLoad) && this.buildAllItems(), this.hide();
    }, ICompElement.prototype.prepareFrame = function(e) {
      if (this._mdf = false, this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange), this.isInRange || this.data.xt) {
        if (this.tm._placeholder) this.renderedFrame = e / this.data.sr;
        else {
          var t = this.tm.v;
          t === this.data.op && (t = this.data.op - 1), this.renderedFrame = t;
        }
        var n, r = this.elements.length;
        for (this.completeLayers || this.checkLayers(this.renderedFrame), n = r - 1; n >= 0; --n) (this.completeLayers || this.elements[n]) && (this.elements[n].prepareFrame(this.renderedFrame - this.layers[n].st), this.elements[n]._mdf && (this._mdf = true));
      }
    }, ICompElement.prototype.renderInnerContent = function() {
      var e, t = this.layers.length;
      for (e = 0; e < t; e += 1) (this.completeLayers || this.elements[e]) && this.elements[e].renderFrame();
    }, ICompElement.prototype.setElements = function(e) {
      this.elements = e;
    }, ICompElement.prototype.getElements = function() {
      return this.elements;
    }, ICompElement.prototype.destroyElements = function() {
      var e, t = this.layers.length;
      for (e = 0; e < t; e += 1) this.elements[e] && this.elements[e].destroy();
    }, ICompElement.prototype.destroy = function() {
      this.destroyElements(), this.destroyBaseElement();
    };
    function SVGCompElement(e, t, n) {
      this.layers = e.layers, this.supports3d = true, this.completeLayers = false, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(e, t, n), this.tm = e.tm ? PropertyFactory.getProp(this, e.tm, 0, t.frameRate, this) : { _placeholder: true };
    }
    extendPrototype([SVGRendererBase, ICompElement, SVGBaseElement], SVGCompElement), SVGCompElement.prototype.createComp = function(e) {
      return new SVGCompElement(e, this.globalData, this);
    };
    function SVGRenderer(e, t) {
      this.animationItem = e, this.layers = null, this.renderedFrame = -1, this.svgElement = createNS(`svg`);
      var n = ``;
      if (t && t.title) {
        var r = createNS(`title`), i = createElementID();
        r.setAttribute(`id`, i), r.textContent = t.title, this.svgElement.appendChild(r), n += i;
      }
      if (t && t.description) {
        var a = createNS(`desc`), o = createElementID();
        a.setAttribute(`id`, o), a.textContent = t.description, this.svgElement.appendChild(a), n += ` ` + o;
      }
      n && this.svgElement.setAttribute(`aria-labelledby`, n);
      var s = createNS(`defs`);
      this.svgElement.appendChild(s);
      var c = createNS(`g`);
      this.svgElement.appendChild(c), this.layerElement = c, this.renderConfig = { preserveAspectRatio: t && t.preserveAspectRatio || `xMidYMid meet`, imagePreserveAspectRatio: t && t.imagePreserveAspectRatio || `xMidYMid slice`, contentVisibility: t && t.contentVisibility || `visible`, progressiveLoad: t && t.progressiveLoad || false, hideOnTransparent: !(t && t.hideOnTransparent === false), viewBoxOnly: t && t.viewBoxOnly || false, viewBoxSize: t && t.viewBoxSize || false, className: t && t.className || ``, id: t && t.id || ``, focusable: t && t.focusable, filterSize: { width: t && t.filterSize && t.filterSize.width || `100%`, height: t && t.filterSize && t.filterSize.height || `100%`, x: t && t.filterSize && t.filterSize.x || `0%`, y: t && t.filterSize && t.filterSize.y || `0%` }, width: t && t.width, height: t && t.height, runExpressions: !t || t.runExpressions === void 0 || t.runExpressions }, this.globalData = { _mdf: false, frameNum: -1, defs: s, renderConfig: this.renderConfig }, this.elements = [], this.pendingElements = [], this.destroyed = false, this.rendererType = `svg`;
    }
    extendPrototype([SVGRendererBase], SVGRenderer), SVGRenderer.prototype.createComp = function(e) {
      return new SVGCompElement(e, this.globalData, this);
    };
    function ShapeTransformManager() {
      this.sequences = {}, this.sequenceList = [], this.transform_key_count = 0;
    }
    ShapeTransformManager.prototype = { addTransformSequence: function(e) {
      var t, n = e.length, r = `_`;
      for (t = 0; t < n; t += 1) r += e[t].transform.key + `_`;
      var i = this.sequences[r];
      return i || (i = { transforms: [].concat(e), finalTransform: new Matrix(), _mdf: false }, this.sequences[r] = i, this.sequenceList.push(i)), i;
    }, processSequence: function(e, t) {
      for (var n = 0, r = e.transforms.length, i = t; n < r && !t; ) {
        if (e.transforms[n].transform.mProps._mdf) {
          i = true;
          break;
        }
        n += 1;
      }
      if (i) for (e.finalTransform.reset(), n = r - 1; n >= 0; --n) e.finalTransform.multiply(e.transforms[n].transform.mProps.v);
      e._mdf = i;
    }, processSequences: function(e) {
      var t, n = this.sequenceList.length;
      for (t = 0; t < n; t += 1) this.processSequence(this.sequenceList[t], e);
    }, getNewKey: function() {
      return this.transform_key_count += 1, `_` + this.transform_key_count;
    } };
    var lumaLoader = function() {
      var e = `__lottie_element_luma_buffer`, t = null, n = null, r = null;
      function i() {
        var t2 = createNS(`svg`), n2 = createNS(`filter`), r2 = createNS(`feColorMatrix`);
        return n2.setAttribute(`id`, e), r2.setAttribute(`type`, `matrix`), r2.setAttribute(`color-interpolation-filters`, `sRGB`), r2.setAttribute(`values`, `0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0, 0.3, 0.3, 0.3, 0, 0`), n2.appendChild(r2), t2.appendChild(n2), t2.setAttribute(`id`, e + `_svg`), featureSupport.svgLumaHidden && (t2.style.display = `none`), t2;
      }
      function a() {
        t || (r = i(), document.body.appendChild(r), t = createTag(`canvas`), n = t.getContext(`2d`), n.filter = `url(#` + e + `)`, n.fillStyle = `rgba(0,0,0,0)`, n.fillRect(0, 0, 1, 1));
      }
      function o(r2) {
        return t || a(), t.width = r2.width, t.height = r2.height, n.filter = `url(#` + e + `)`, t;
      }
      return { load: a, get: o };
    };
    function createCanvas(e, t) {
      if (featureSupport.offscreenCanvas) return new OffscreenCanvas(e, t);
      var n = createTag(`canvas`);
      return n.width = e, n.height = t, n;
    }
    var assetLoader = (function() {
      return { loadLumaCanvas: lumaLoader.load, getLumaCanvas: lumaLoader.get, createCanvas };
    })(), registeredEffects = {};
    function CVEffects(e) {
      var t, n = e.data.ef ? e.data.ef.length : 0;
      this.filters = [];
      var r;
      for (t = 0; t < n; t += 1) {
        r = null;
        var i = e.data.ef[t].ty;
        if (registeredEffects[i]) {
          var a = registeredEffects[i].effect;
          r = new a(e.effectsManager.effectElements[t], e);
        }
        r && this.filters.push(r);
      }
      this.filters.length && e.addRenderableComponent(this);
    }
    CVEffects.prototype.renderFrame = function(e) {
      var t, n = this.filters.length;
      for (t = 0; t < n; t += 1) this.filters[t].renderFrame(e);
    }, CVEffects.prototype.getEffects = function(e) {
      var t, n = this.filters.length, r = [];
      for (t = 0; t < n; t += 1) this.filters[t].type === e && r.push(this.filters[t]);
      return r;
    };
    function registerEffect(e, t) {
      registeredEffects[e] = { effect: t };
    }
    function CVMaskElement(e, t) {
      this.data = e, this.element = t, this.masksProperties = this.data.masksProperties || [], this.viewData = createSizedArray(this.masksProperties.length);
      var n, r = this.masksProperties.length, i = false;
      for (n = 0; n < r; n += 1) this.masksProperties[n].mode !== `n` && (i = true), this.viewData[n] = ShapePropertyFactory.getShapeProp(this.element, this.masksProperties[n], 3);
      this.hasMasks = i, i && this.element.addRenderableComponent(this);
    }
    CVMaskElement.prototype.renderFrame = function() {
      if (this.hasMasks) {
        var e = this.element.finalTransform.mat, t = this.element.canvasContext, n, r = this.masksProperties.length, i, a, o;
        for (t.beginPath(), n = 0; n < r; n += 1) if (this.masksProperties[n].mode !== `n`) {
          this.masksProperties[n].inv && (t.moveTo(0, 0), t.lineTo(this.element.globalData.compSize.w, 0), t.lineTo(this.element.globalData.compSize.w, this.element.globalData.compSize.h), t.lineTo(0, this.element.globalData.compSize.h), t.lineTo(0, 0)), o = this.viewData[n].v, i = e.applyToPointArray(o.v[0][0], o.v[0][1], 0), t.moveTo(i[0], i[1]);
          var s, c = o._length;
          for (s = 1; s < c; s += 1) a = e.applyToTriplePoints(o.o[s - 1], o.i[s], o.v[s]), t.bezierCurveTo(a[0], a[1], a[2], a[3], a[4], a[5]);
          a = e.applyToTriplePoints(o.o[s - 1], o.i[0], o.v[0]), t.bezierCurveTo(a[0], a[1], a[2], a[3], a[4], a[5]);
        }
        this.element.globalData.renderer.save(true), t.clip();
      }
    }, CVMaskElement.prototype.getMaskProperty = MaskElement.prototype.getMaskProperty, CVMaskElement.prototype.destroy = function() {
      this.element = null;
    };
    function CVBaseElement() {
    }
    var operationsMap = { 1: `source-in`, 2: `source-out`, 3: `source-in`, 4: `source-out` };
    CVBaseElement.prototype = { createElements: function() {
    }, initRendererElement: function() {
    }, createContainerElements: function() {
      if (this.data.tt >= 1) {
        this.buffers = [];
        var e = this.globalData.canvasContext, t = assetLoader.createCanvas(e.canvas.width, e.canvas.height);
        this.buffers.push(t);
        var n = assetLoader.createCanvas(e.canvas.width, e.canvas.height);
        this.buffers.push(n), this.data.tt >= 3 && !document._isProxy && assetLoader.loadLumaCanvas();
      }
      this.canvasContext = this.globalData.canvasContext, this.transformCanvas = this.globalData.transformCanvas, this.renderableEffectsManager = new CVEffects(this), this.searchEffectTransforms();
    }, createContent: function() {
    }, setBlendMode: function() {
      var e = this.globalData;
      if (e.blendMode !== this.data.bm) {
        e.blendMode = this.data.bm;
        var t = getBlendMode(this.data.bm);
        e.canvasContext.globalCompositeOperation = t;
      }
    }, createRenderableComponents: function() {
      this.maskManager = new CVMaskElement(this.data, this), this.transformEffects = this.renderableEffectsManager.getEffects(effectTypes.TRANSFORM_EFFECT);
    }, hideElement: function() {
      !this.hidden && (!this.isInRange || this.isTransparent) && (this.hidden = true);
    }, showElement: function() {
      this.isInRange && !this.isTransparent && (this.hidden = false, this._isFirstFrame = true, this.maskManager._isFirstFrame = true);
    }, clearCanvas: function(e) {
      e.clearRect(this.transformCanvas.tx, this.transformCanvas.ty, this.transformCanvas.w * this.transformCanvas.sx, this.transformCanvas.h * this.transformCanvas.sy);
    }, prepareLayer: function() {
      if (this.data.tt >= 1) {
        var e = this.buffers[0].getContext(`2d`);
        this.clearCanvas(e), e.drawImage(this.canvasContext.canvas, 0, 0), this.currentTransform = this.canvasContext.getTransform(), this.canvasContext.setTransform(1, 0, 0, 1, 0, 0), this.clearCanvas(this.canvasContext), this.canvasContext.setTransform(this.currentTransform);
      }
    }, exitLayer: function() {
      if (this.data.tt >= 1) {
        var e = this.buffers[1], t = e.getContext(`2d`);
        if (this.clearCanvas(t), t.drawImage(this.canvasContext.canvas, 0, 0), this.canvasContext.setTransform(1, 0, 0, 1, 0, 0), this.clearCanvas(this.canvasContext), this.canvasContext.setTransform(this.currentTransform), this.comp.getElementById(`tp` in this.data ? this.data.tp : this.data.ind - 1).renderFrame(true), this.canvasContext.setTransform(1, 0, 0, 1, 0, 0), this.data.tt >= 3 && !document._isProxy) {
          var n = assetLoader.getLumaCanvas(this.canvasContext.canvas);
          n.getContext(`2d`).drawImage(this.canvasContext.canvas, 0, 0), this.clearCanvas(this.canvasContext), this.canvasContext.drawImage(n, 0, 0);
        }
        this.canvasContext.globalCompositeOperation = operationsMap[this.data.tt], this.canvasContext.drawImage(e, 0, 0), this.canvasContext.globalCompositeOperation = `destination-over`, this.canvasContext.drawImage(this.buffers[0], 0, 0), this.canvasContext.setTransform(this.currentTransform), this.canvasContext.globalCompositeOperation = `source-over`;
      }
    }, renderFrame: function(e) {
      if (!(this.hidden || this.data.hd) && (this.data.td !== 1 || e)) {
        this.renderTransform(), this.renderRenderable(), this.renderLocalTransform(), this.setBlendMode();
        var t = this.data.ty === 0;
        this.prepareLayer(), this.globalData.renderer.save(t), this.globalData.renderer.ctxTransform(this.finalTransform.localMat.props), this.globalData.renderer.ctxOpacity(this.finalTransform.localOpacity), this.renderInnerContent(), this.globalData.renderer.restore(t), this.exitLayer(), this.maskManager.hasMasks && this.globalData.renderer.restore(true), this._isFirstFrame && (this._isFirstFrame = false);
      }
    }, destroy: function() {
      this.canvasContext = null, this.data = null, this.globalData = null, this.maskManager.destroy();
    }, mHelper: new Matrix() }, CVBaseElement.prototype.hide = CVBaseElement.prototype.hideElement, CVBaseElement.prototype.show = CVBaseElement.prototype.showElement;
    function CVShapeData(e, t, n, r) {
      this.styledShapes = [], this.tr = [0, 0, 0, 0, 0, 0];
      var i = 4;
      t.ty === `rc` ? i = 5 : t.ty === `el` ? i = 6 : t.ty === `sr` && (i = 7), this.sh = ShapePropertyFactory.getShapeProp(e, t, i, e);
      var a, o = n.length, s;
      for (a = 0; a < o; a += 1) n[a].closed || (s = { transforms: r.addTransformSequence(n[a].transforms), trNodes: [] }, this.styledShapes.push(s), n[a].elements.push(s));
    }
    CVShapeData.prototype.setAsAnimated = SVGShapeData.prototype.setAsAnimated;
    function CVShapeElement(e, t, n) {
      this.shapes = [], this.shapesData = e.shapes, this.stylesList = [], this.itemsData = [], this.prevViewData = [], this.shapeModifiers = [], this.processedElements = [], this.transformsManager = new ShapeTransformManager(), this.initElement(e, t, n);
    }
    extendPrototype([BaseElement, TransformElement, CVBaseElement, IShapeElement, HierarchyElement, FrameElement, RenderableElement], CVShapeElement), CVShapeElement.prototype.initElement = RenderableDOMElement.prototype.initElement, CVShapeElement.prototype.transformHelper = { opacity: 1, _opMdf: false }, CVShapeElement.prototype.dashResetter = [], CVShapeElement.prototype.createContent = function() {
      this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, true, []);
    }, CVShapeElement.prototype.createStyleElement = function(e, t) {
      var n = { data: e, type: e.ty, preTransforms: this.transformsManager.addTransformSequence(t), transforms: [], elements: [], closed: e.hd === true }, r = {};
      return e.ty === `fl` || e.ty === `st` ? (r.c = PropertyFactory.getProp(this, e.c, 1, 255, this), r.c.k || (n.co = `rgb(` + bmFloor(r.c.v[0]) + `,` + bmFloor(r.c.v[1]) + `,` + bmFloor(r.c.v[2]) + `)`)) : (e.ty === `gf` || e.ty === `gs`) && (r.s = PropertyFactory.getProp(this, e.s, 1, null, this), r.e = PropertyFactory.getProp(this, e.e, 1, null, this), r.h = PropertyFactory.getProp(this, e.h || { k: 0 }, 0, 0.01, this), r.a = PropertyFactory.getProp(this, e.a || { k: 0 }, 0, degToRads, this), r.g = new GradientProperty(this, e.g, this)), r.o = PropertyFactory.getProp(this, e.o, 0, 0.01, this), e.ty === `st` || e.ty === `gs` ? (n.lc = lineCapEnum[e.lc || 2], n.lj = lineJoinEnum[e.lj || 2], e.lj == 1 && (n.ml = e.ml), r.w = PropertyFactory.getProp(this, e.w, 0, null, this), r.w.k || (n.wi = r.w.v), e.d && (r.d = new DashProperty(this, e.d, `canvas`, this), r.d.k || (n.da = r.d.dashArray, n.do = r.d.dashoffset[0]))) : n.r = e.r === 2 ? `evenodd` : `nonzero`, this.stylesList.push(n), r.style = n, r;
    }, CVShapeElement.prototype.createGroupElement = function() {
      return { it: [], prevViewData: [] };
    }, CVShapeElement.prototype.createTransformElement = function(e) {
      return { transform: { opacity: 1, _opMdf: false, key: this.transformsManager.getNewKey(), op: PropertyFactory.getProp(this, e.o, 0, 0.01, this), mProps: TransformPropertyFactory.getTransformProperty(this, e, this) } };
    }, CVShapeElement.prototype.createShapeElement = function(e) {
      var t = new CVShapeData(this, e, this.stylesList, this.transformsManager);
      return this.shapes.push(t), this.addShapeToModifiers(t), t;
    }, CVShapeElement.prototype.reloadShapes = function() {
      this._isFirstFrame = true;
      var e, t = this.itemsData.length;
      for (e = 0; e < t; e += 1) this.prevViewData[e] = this.itemsData[e];
      for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, true, []), t = this.dynamicProperties.length, e = 0; e < t; e += 1) this.dynamicProperties[e].getValue();
      this.renderModifiers(), this.transformsManager.processSequences(this._isFirstFrame);
    }, CVShapeElement.prototype.addTransformToStyleList = function(e) {
      var t, n = this.stylesList.length;
      for (t = 0; t < n; t += 1) this.stylesList[t].closed || this.stylesList[t].transforms.push(e);
    }, CVShapeElement.prototype.removeTransformFromStyleList = function() {
      var e, t = this.stylesList.length;
      for (e = 0; e < t; e += 1) this.stylesList[e].closed || this.stylesList[e].transforms.pop();
    }, CVShapeElement.prototype.closeStyles = function(e) {
      var t, n = e.length;
      for (t = 0; t < n; t += 1) e[t].closed = true;
    }, CVShapeElement.prototype.searchShapes = function(e, t, n, r, i) {
      var a, o = e.length - 1, s, c, l = [], u = [], d, f, p, m = [].concat(i);
      for (a = o; a >= 0; --a) {
        if (d = this.searchProcessedElement(e[a]), d ? t[a] = n[d - 1] : e[a]._shouldRender = r, e[a].ty === `fl` || e[a].ty === `st` || e[a].ty === `gf` || e[a].ty === `gs`) d ? t[a].style.closed = false : t[a] = this.createStyleElement(e[a], m), l.push(t[a].style);
        else if (e[a].ty === `gr`) {
          if (!d) t[a] = this.createGroupElement(e[a]);
          else for (c = t[a].it.length, s = 0; s < c; s += 1) t[a].prevViewData[s] = t[a].it[s];
          this.searchShapes(e[a].it, t[a].it, t[a].prevViewData, r, m);
        } else e[a].ty === `tr` ? (d || (p = this.createTransformElement(e[a]), t[a] = p), m.push(t[a]), this.addTransformToStyleList(t[a])) : e[a].ty === `sh` || e[a].ty === `rc` || e[a].ty === `el` || e[a].ty === `sr` ? d || (t[a] = this.createShapeElement(e[a])) : e[a].ty === `tm` || e[a].ty === `rd` || e[a].ty === `pb` || e[a].ty === `zz` || e[a].ty === `op` ? (d ? (f = t[a], f.closed = false) : (f = ShapeModifiers.getModifier(e[a].ty), f.init(this, e[a]), t[a] = f, this.shapeModifiers.push(f)), u.push(f)) : e[a].ty === `rp` && (d ? (f = t[a], f.closed = true) : (f = ShapeModifiers.getModifier(e[a].ty), t[a] = f, f.init(this, e, a, t), this.shapeModifiers.push(f), r = false), u.push(f));
        this.addProcessedElement(e[a], a + 1);
      }
      for (this.removeTransformFromStyleList(), this.closeStyles(l), o = u.length, a = 0; a < o; a += 1) u[a].closed = true;
    }, CVShapeElement.prototype.renderInnerContent = function() {
      this.transformHelper.opacity = 1, this.transformHelper._opMdf = false, this.renderModifiers(), this.transformsManager.processSequences(this._isFirstFrame), this.renderShape(this.transformHelper, this.shapesData, this.itemsData, true);
    }, CVShapeElement.prototype.renderShapeTransform = function(e, t) {
      (e._opMdf || t.op._mdf || this._isFirstFrame) && (t.opacity = e.opacity, t.opacity *= t.op.v, t._opMdf = true);
    }, CVShapeElement.prototype.drawLayer = function() {
      var e, t = this.stylesList.length, n, r, i, a, o, s, c = this.globalData.renderer, l = this.globalData.canvasContext, u, d;
      for (e = 0; e < t; e += 1) if (d = this.stylesList[e], u = d.type, (u !== `st` && u !== `gs` || d.wi !== 0) && d.data._shouldRender && d.coOp !== 0 && this.globalData.currentGlobalAlpha !== 0) {
        for (c.save(), o = d.elements, u === `st` || u === `gs` ? (c.ctxStrokeStyle(u === `st` ? d.co : d.grd), c.ctxLineWidth(d.wi), c.ctxLineCap(d.lc), c.ctxLineJoin(d.lj), c.ctxMiterLimit(d.ml || 0)) : c.ctxFillStyle(u === `fl` ? d.co : d.grd), c.ctxOpacity(d.coOp), u !== `st` && u !== `gs` && l.beginPath(), c.ctxTransform(d.preTransforms.finalTransform.props), r = o.length, n = 0; n < r; n += 1) {
          for ((u === `st` || u === `gs`) && (l.beginPath(), d.da && (l.setLineDash(d.da), l.lineDashOffset = d.do)), s = o[n].trNodes, a = s.length, i = 0; i < a; i += 1) s[i].t === `m` ? l.moveTo(s[i].p[0], s[i].p[1]) : s[i].t === `c` ? l.bezierCurveTo(s[i].pts[0], s[i].pts[1], s[i].pts[2], s[i].pts[3], s[i].pts[4], s[i].pts[5]) : l.closePath();
          (u === `st` || u === `gs`) && (c.ctxStroke(), d.da && l.setLineDash(this.dashResetter));
        }
        u !== `st` && u !== `gs` && this.globalData.renderer.ctxFill(d.r), c.restore();
      }
    }, CVShapeElement.prototype.renderShape = function(e, t, n, r) {
      var i, a = t.length - 1, o = e;
      for (i = a; i >= 0; --i) t[i].ty === `tr` ? (o = n[i].transform, this.renderShapeTransform(e, o)) : t[i].ty === `sh` || t[i].ty === `el` || t[i].ty === `rc` || t[i].ty === `sr` ? this.renderPath(t[i], n[i]) : t[i].ty === `fl` ? this.renderFill(t[i], n[i], o) : t[i].ty === `st` ? this.renderStroke(t[i], n[i], o) : t[i].ty === `gf` || t[i].ty === `gs` ? this.renderGradientFill(t[i], n[i], o) : t[i].ty === `gr` ? this.renderShape(o, t[i].it, n[i].it) : t[i].ty;
      r && this.drawLayer();
    }, CVShapeElement.prototype.renderStyledShape = function(e, t) {
      if (this._isFirstFrame || t._mdf || e.transforms._mdf) {
        var n = e.trNodes, r = t.paths, i, a, o, s = r._length;
        n.length = 0;
        var c = e.transforms.finalTransform;
        for (o = 0; o < s; o += 1) {
          var l = r.shapes[o];
          if (l && l.v) {
            for (a = l._length, i = 1; i < a; i += 1) i === 1 && n.push({ t: `m`, p: c.applyToPointArray(l.v[0][0], l.v[0][1], 0) }), n.push({ t: `c`, pts: c.applyToTriplePoints(l.o[i - 1], l.i[i], l.v[i]) });
            a === 1 && n.push({ t: `m`, p: c.applyToPointArray(l.v[0][0], l.v[0][1], 0) }), l.c && a && (n.push({ t: `c`, pts: c.applyToTriplePoints(l.o[i - 1], l.i[0], l.v[0]) }), n.push({ t: `z` }));
          }
        }
        e.trNodes = n;
      }
    }, CVShapeElement.prototype.renderPath = function(e, t) {
      if (e.hd !== true && e._shouldRender) {
        var n, r = t.styledShapes.length;
        for (n = 0; n < r; n += 1) this.renderStyledShape(t.styledShapes[n], t.sh);
      }
    }, CVShapeElement.prototype.renderFill = function(e, t, n) {
      var r = t.style;
      (t.c._mdf || this._isFirstFrame) && (r.co = `rgb(` + bmFloor(t.c.v[0]) + `,` + bmFloor(t.c.v[1]) + `,` + bmFloor(t.c.v[2]) + `)`), (t.o._mdf || n._opMdf || this._isFirstFrame) && (r.coOp = t.o.v * n.opacity);
    }, CVShapeElement.prototype.renderGradientFill = function(e, t, n) {
      var r = t.style, i;
      if (!r.grd || t.g._mdf || t.s._mdf || t.e._mdf || e.t !== 1 && (t.h._mdf || t.a._mdf)) {
        var a = this.globalData.canvasContext, o = t.s.v, s = t.e.v;
        if (e.t === 1) i = a.createLinearGradient(o[0], o[1], s[0], s[1]);
        else {
          var c = Math.sqrt((o[0] - s[0]) ** 2 + (o[1] - s[1]) ** 2), l = Math.atan2(s[1] - o[1], s[0] - o[0]), u = t.h.v;
          u >= 1 ? u = 0.99 : u <= -1 && (u = -0.99);
          var d = c * u, f = Math.cos(l + t.a.v) * d + o[0], p = Math.sin(l + t.a.v) * d + o[1];
          i = a.createRadialGradient(f, p, 0, o[0], o[1], c);
        }
        var m, g = e.g.p, _ = t.g.c, y = 1;
        for (m = 0; m < g; m += 1) t.g._hasOpacity && t.g._collapsable && (y = t.g.o[m * 2 + 1]), i.addColorStop(_[m * 4] / 100, `rgba(` + _[m * 4 + 1] + `,` + _[m * 4 + 2] + `,` + _[m * 4 + 3] + `,` + y + `)`);
        r.grd = i;
      }
      r.coOp = t.o.v * n.opacity;
    }, CVShapeElement.prototype.renderStroke = function(e, t, n) {
      var r = t.style, i = t.d;
      i && (i._mdf || this._isFirstFrame) && (r.da = i.dashArray, r.do = i.dashoffset[0]), (t.c._mdf || this._isFirstFrame) && (r.co = `rgb(` + bmFloor(t.c.v[0]) + `,` + bmFloor(t.c.v[1]) + `,` + bmFloor(t.c.v[2]) + `)`), (t.o._mdf || n._opMdf || this._isFirstFrame) && (r.coOp = t.o.v * n.opacity), (t.w._mdf || this._isFirstFrame) && (r.wi = t.w.v);
    }, CVShapeElement.prototype.destroy = function() {
      this.shapesData = null, this.globalData = null, this.canvasContext = null, this.stylesList.length = 0, this.itemsData.length = 0;
    };
    function CVTextElement(e, t, n) {
      this.textSpans = [], this.yOffset = 0, this.fillColorAnim = false, this.strokeColorAnim = false, this.strokeWidthAnim = false, this.stroke = false, this.fill = false, this.justifyOffset = 0, this.currentRender = null, this.renderType = `canvas`, this.values = { fill: `rgba(0,0,0,0)`, stroke: `rgba(0,0,0,0)`, sWidth: 0, fValue: `` }, this.initElement(e, t, n);
    }
    extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement, ITextElement], CVTextElement), CVTextElement.prototype.tHelper = createTag(`canvas`).getContext(`2d`), CVTextElement.prototype.buildNewText = function() {
      var e = this.textProperty.currentData;
      this.renderedLetters = createSizedArray(e.l ? e.l.length : 0);
      var t = false;
      e.fc ? (t = true, this.values.fill = this.buildColor(e.fc)) : this.values.fill = `rgba(0,0,0,0)`, this.fill = t;
      var n = false;
      e.sc && (n = true, this.values.stroke = this.buildColor(e.sc), this.values.sWidth = e.sw);
      var r = this.globalData.fontManager.getFontByName(e.f), i, a, o = e.l, s = this.mHelper;
      this.stroke = n, this.values.fValue = e.finalSize + `px ` + this.globalData.fontManager.getFontByName(e.f).fFamily, a = e.finalText.length;
      var c, l, u, d, f, p, m, g, _, y, b = this.data.singleShape, x = e.tr * 1e-3 * e.finalSize, S = 0, C = 0, T = true, E = 0;
      for (i = 0; i < a; i += 1) {
        c = this.globalData.fontManager.getCharData(e.finalText[i], r.fStyle, this.globalData.fontManager.getFontByName(e.f).fFamily), l = c && c.data || {}, s.reset(), b && o[i].n && (S = -x, C += e.yOffset, C += +!!T, T = false), f = l.shapes ? l.shapes[0].it : [], m = f.length, s.scale(e.finalSize / 100, e.finalSize / 100), b && this.applyTextPropertiesToMatrix(e, s, o[i].line, S, C), _ = createSizedArray(m - 1);
        var D = 0;
        for (p = 0; p < m; p += 1) if (f[p].ty === `sh`) {
          for (d = f[p].ks.k.i.length, g = f[p].ks.k, y = [], u = 1; u < d; u += 1) u === 1 && y.push(s.applyToX(g.v[0][0], g.v[0][1], 0), s.applyToY(g.v[0][0], g.v[0][1], 0)), y.push(s.applyToX(g.o[u - 1][0], g.o[u - 1][1], 0), s.applyToY(g.o[u - 1][0], g.o[u - 1][1], 0), s.applyToX(g.i[u][0], g.i[u][1], 0), s.applyToY(g.i[u][0], g.i[u][1], 0), s.applyToX(g.v[u][0], g.v[u][1], 0), s.applyToY(g.v[u][0], g.v[u][1], 0));
          y.push(s.applyToX(g.o[u - 1][0], g.o[u - 1][1], 0), s.applyToY(g.o[u - 1][0], g.o[u - 1][1], 0), s.applyToX(g.i[0][0], g.i[0][1], 0), s.applyToY(g.i[0][0], g.i[0][1], 0), s.applyToX(g.v[0][0], g.v[0][1], 0), s.applyToY(g.v[0][0], g.v[0][1], 0)), _[D] = y, D += 1;
        }
        b && (S += o[i].l, S += x), this.textSpans[E] ? this.textSpans[E].elem = _ : this.textSpans[E] = { elem: _ }, E += 1;
      }
    }, CVTextElement.prototype.renderInnerContent = function() {
      this.validateText();
      var e = this.canvasContext;
      e.font = this.values.fValue, this.globalData.renderer.ctxLineCap(`butt`), this.globalData.renderer.ctxLineJoin(`miter`), this.globalData.renderer.ctxMiterLimit(4), this.data.singleShape || this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag);
      var t, n, r, i, a, o, s = this.textAnimator.renderedLetters, c = this.textProperty.currentData.l;
      n = c.length;
      var l, u = null, d = null, f = null, p, m, g = this.globalData.renderer;
      for (t = 0; t < n; t += 1) if (!c[t].n) {
        if (l = s[t], l && (g.save(), g.ctxTransform(l.p), g.ctxOpacity(l.o)), this.fill) {
          for (l && l.fc ? u !== l.fc && (g.ctxFillStyle(l.fc), u = l.fc) : u !== this.values.fill && (u = this.values.fill, g.ctxFillStyle(this.values.fill)), p = this.textSpans[t].elem, i = p.length, this.globalData.canvasContext.beginPath(), r = 0; r < i; r += 1) for (m = p[r], o = m.length, this.globalData.canvasContext.moveTo(m[0], m[1]), a = 2; a < o; a += 6) this.globalData.canvasContext.bezierCurveTo(m[a], m[a + 1], m[a + 2], m[a + 3], m[a + 4], m[a + 5]);
          this.globalData.canvasContext.closePath(), g.ctxFill();
        }
        if (this.stroke) {
          for (l && l.sw ? f !== l.sw && (f = l.sw, g.ctxLineWidth(l.sw)) : f !== this.values.sWidth && (f = this.values.sWidth, g.ctxLineWidth(this.values.sWidth)), l && l.sc ? d !== l.sc && (d = l.sc, g.ctxStrokeStyle(l.sc)) : d !== this.values.stroke && (d = this.values.stroke, g.ctxStrokeStyle(this.values.stroke)), p = this.textSpans[t].elem, i = p.length, this.globalData.canvasContext.beginPath(), r = 0; r < i; r += 1) for (m = p[r], o = m.length, this.globalData.canvasContext.moveTo(m[0], m[1]), a = 2; a < o; a += 6) this.globalData.canvasContext.bezierCurveTo(m[a], m[a + 1], m[a + 2], m[a + 3], m[a + 4], m[a + 5]);
          this.globalData.canvasContext.closePath(), g.ctxStroke();
        }
        l && this.globalData.renderer.restore();
      }
    };
    function CVImageElement(e, t, n) {
      this.assetData = t.getAssetData(e.refId), this.img = t.imageLoader.getAsset(this.assetData), this.initElement(e, t, n);
    }
    extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement], CVImageElement), CVImageElement.prototype.initElement = SVGShapeElement.prototype.initElement, CVImageElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame, CVImageElement.prototype.createContent = function() {
      if (this.img.width && (this.assetData.w !== this.img.width || this.assetData.h !== this.img.height)) {
        var e = createTag(`canvas`);
        e.width = this.assetData.w, e.height = this.assetData.h;
        var t = e.getContext(`2d`), n = this.img.width, r = this.img.height, i = n / r, a = this.assetData.w / this.assetData.h, o, s, c = this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio;
        i > a && c === `xMidYMid slice` || i < a && c !== `xMidYMid slice` ? (s = r, o = s * a) : (o = n, s = o / a), t.drawImage(this.img, (n - o) / 2, (r - s) / 2, o, s, 0, 0, this.assetData.w, this.assetData.h), this.img = e;
      }
    }, CVImageElement.prototype.renderInnerContent = function() {
      this.canvasContext.drawImage(this.img, 0, 0);
    }, CVImageElement.prototype.destroy = function() {
      this.img = null;
    };
    function CVSolidElement(e, t, n) {
      this.initElement(e, t, n);
    }
    extendPrototype([BaseElement, TransformElement, CVBaseElement, HierarchyElement, FrameElement, RenderableElement], CVSolidElement), CVSolidElement.prototype.initElement = SVGShapeElement.prototype.initElement, CVSolidElement.prototype.prepareFrame = IImageElement.prototype.prepareFrame, CVSolidElement.prototype.renderInnerContent = function() {
      this.globalData.renderer.ctxFillStyle(this.data.sc), this.globalData.renderer.ctxFillRect(0, 0, this.data.sw, this.data.sh);
    };
    function CanvasRendererBase() {
    }
    extendPrototype([BaseRenderer], CanvasRendererBase), CanvasRendererBase.prototype.createShape = function(e) {
      return new CVShapeElement(e, this.globalData, this);
    }, CanvasRendererBase.prototype.createText = function(e) {
      return new CVTextElement(e, this.globalData, this);
    }, CanvasRendererBase.prototype.createImage = function(e) {
      return new CVImageElement(e, this.globalData, this);
    }, CanvasRendererBase.prototype.createSolid = function(e) {
      return new CVSolidElement(e, this.globalData, this);
    }, CanvasRendererBase.prototype.createNull = SVGRenderer.prototype.createNull, CanvasRendererBase.prototype.ctxTransform = function(e) {
      (e[0] !== 1 || e[1] !== 0 || e[4] !== 0 || e[5] !== 1 || e[12] !== 0 || e[13] !== 0) && this.canvasContext.transform(e[0], e[1], e[4], e[5], e[12], e[13]);
    }, CanvasRendererBase.prototype.ctxOpacity = function(e) {
      this.canvasContext.globalAlpha *= e < 0 ? 0 : e;
    }, CanvasRendererBase.prototype.ctxFillStyle = function(e) {
      this.canvasContext.fillStyle = e;
    }, CanvasRendererBase.prototype.ctxStrokeStyle = function(e) {
      this.canvasContext.strokeStyle = e;
    }, CanvasRendererBase.prototype.ctxLineWidth = function(e) {
      this.canvasContext.lineWidth = e;
    }, CanvasRendererBase.prototype.ctxLineCap = function(e) {
      this.canvasContext.lineCap = e;
    }, CanvasRendererBase.prototype.ctxLineJoin = function(e) {
      this.canvasContext.lineJoin = e;
    }, CanvasRendererBase.prototype.ctxMiterLimit = function(e) {
      this.canvasContext.miterLimit = e;
    }, CanvasRendererBase.prototype.ctxFill = function(e) {
      this.canvasContext.fill(e);
    }, CanvasRendererBase.prototype.ctxFillRect = function(e, t, n, r) {
      this.canvasContext.fillRect(e, t, n, r);
    }, CanvasRendererBase.prototype.ctxStroke = function() {
      this.canvasContext.stroke();
    }, CanvasRendererBase.prototype.reset = function() {
      if (!this.renderConfig.clearCanvas) {
        this.canvasContext.restore();
        return;
      }
      this.contextData.reset();
    }, CanvasRendererBase.prototype.save = function() {
      this.canvasContext.save();
    }, CanvasRendererBase.prototype.restore = function(e) {
      if (!this.renderConfig.clearCanvas) {
        this.canvasContext.restore();
        return;
      }
      e && (this.globalData.blendMode = `source-over`), this.contextData.restore(e);
    }, CanvasRendererBase.prototype.configAnimation = function(e) {
      if (this.animationItem.wrapper) {
        this.animationItem.container = createTag(`canvas`);
        var t = this.animationItem.container.style;
        t.width = `100%`, t.height = `100%`;
        var n = `0px 0px 0px`;
        t.transformOrigin = n, t.mozTransformOrigin = n, t.webkitTransformOrigin = n, t[`-webkit-transform`] = n, t.contentVisibility = this.renderConfig.contentVisibility, this.animationItem.wrapper.appendChild(this.animationItem.container), this.canvasContext = this.animationItem.container.getContext(`2d`), this.renderConfig.className && this.animationItem.container.setAttribute(`class`, this.renderConfig.className), this.renderConfig.id && this.animationItem.container.setAttribute(`id`, this.renderConfig.id);
      } else this.canvasContext = this.renderConfig.context;
      this.contextData.setContext(this.canvasContext), this.data = e, this.layers = e.layers, this.transformCanvas = { w: e.w, h: e.h, sx: 0, sy: 0, tx: 0, ty: 0 }, this.setupGlobalData(e, document.body), this.globalData.canvasContext = this.canvasContext, this.globalData.renderer = this, this.globalData.isDashed = false, this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.globalData.transformCanvas = this.transformCanvas, this.elements = createSizedArray(e.layers.length), this.updateContainerSize();
    }, CanvasRendererBase.prototype.updateContainerSize = function(e, t) {
      this.reset();
      var n, r;
      e ? (n = e, r = t, this.canvasContext.canvas.width = n, this.canvasContext.canvas.height = r) : (this.animationItem.wrapper && this.animationItem.container ? (n = this.animationItem.wrapper.offsetWidth, r = this.animationItem.wrapper.offsetHeight) : (n = this.canvasContext.canvas.width, r = this.canvasContext.canvas.height), this.canvasContext.canvas.width = n * this.renderConfig.dpr, this.canvasContext.canvas.height = r * this.renderConfig.dpr);
      var i, a;
      if (this.renderConfig.preserveAspectRatio.indexOf(`meet`) !== -1 || this.renderConfig.preserveAspectRatio.indexOf(`slice`) !== -1) {
        var o = this.renderConfig.preserveAspectRatio.split(` `), s = o[1] || `meet`, c = o[0] || `xMidYMid`, l = c.substr(0, 4), u = c.substr(4);
        i = n / r, a = this.transformCanvas.w / this.transformCanvas.h, a > i && s === `meet` || a < i && s === `slice` ? (this.transformCanvas.sx = n / (this.transformCanvas.w / this.renderConfig.dpr), this.transformCanvas.sy = n / (this.transformCanvas.w / this.renderConfig.dpr)) : (this.transformCanvas.sx = r / (this.transformCanvas.h / this.renderConfig.dpr), this.transformCanvas.sy = r / (this.transformCanvas.h / this.renderConfig.dpr)), l === `xMid` && (a < i && s === `meet` || a > i && s === `slice`) ? this.transformCanvas.tx = (n - this.transformCanvas.w * (r / this.transformCanvas.h)) / 2 * this.renderConfig.dpr : l === `xMax` && (a < i && s === `meet` || a > i && s === `slice`) ? this.transformCanvas.tx = (n - this.transformCanvas.w * (r / this.transformCanvas.h)) * this.renderConfig.dpr : this.transformCanvas.tx = 0, u === `YMid` && (a > i && s === `meet` || a < i && s === `slice`) ? this.transformCanvas.ty = (r - this.transformCanvas.h * (n / this.transformCanvas.w)) / 2 * this.renderConfig.dpr : u === `YMax` && (a > i && s === `meet` || a < i && s === `slice`) ? this.transformCanvas.ty = (r - this.transformCanvas.h * (n / this.transformCanvas.w)) * this.renderConfig.dpr : this.transformCanvas.ty = 0;
      } else this.renderConfig.preserveAspectRatio === `none` ? (this.transformCanvas.sx = n / (this.transformCanvas.w / this.renderConfig.dpr), this.transformCanvas.sy = r / (this.transformCanvas.h / this.renderConfig.dpr), this.transformCanvas.tx = 0, this.transformCanvas.ty = 0) : (this.transformCanvas.sx = this.renderConfig.dpr, this.transformCanvas.sy = this.renderConfig.dpr, this.transformCanvas.tx = 0, this.transformCanvas.ty = 0);
      this.transformCanvas.props = [this.transformCanvas.sx, 0, 0, 0, 0, this.transformCanvas.sy, 0, 0, 0, 0, 1, 0, this.transformCanvas.tx, this.transformCanvas.ty, 0, 1], this.ctxTransform(this.transformCanvas.props), this.canvasContext.beginPath(), this.canvasContext.rect(0, 0, this.transformCanvas.w, this.transformCanvas.h), this.canvasContext.closePath(), this.canvasContext.clip(), this.renderFrame(this.renderedFrame, true);
    }, CanvasRendererBase.prototype.destroy = function() {
      this.renderConfig.clearCanvas && this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ``);
      for (var e = (this.layers ? this.layers.length : 0) - 1; e >= 0; --e) this.elements[e] && this.elements[e].destroy && this.elements[e].destroy();
      this.elements.length = 0, this.globalData.canvasContext = null, this.animationItem.container = null, this.destroyed = true;
    }, CanvasRendererBase.prototype.renderFrame = function(e, t) {
      if (!(this.renderedFrame === e && this.renderConfig.clearCanvas === true && !t || this.destroyed || e === -1)) {
        this.renderedFrame = e, this.globalData.frameNum = e - this.animationItem._isFirstFrame, this.globalData.frameId += 1, this.globalData._mdf = !this.renderConfig.clearCanvas || t, this.globalData.projectInterface.currentFrame = e;
        var n, r = this.layers.length;
        for (this.completeLayers || this.checkLayers(e), n = r - 1; n >= 0; --n) (this.completeLayers || this.elements[n]) && this.elements[n].prepareFrame(e - this.layers[n].st);
        if (this.globalData._mdf) {
          for (this.renderConfig.clearCanvas === true ? this.canvasContext.clearRect(0, 0, this.transformCanvas.w, this.transformCanvas.h) : this.save(), n = r - 1; n >= 0; --n) (this.completeLayers || this.elements[n]) && this.elements[n].renderFrame();
          this.renderConfig.clearCanvas !== true && this.restore();
        }
      }
    }, CanvasRendererBase.prototype.buildItem = function(e) {
      var t = this.elements;
      if (!(t[e] || this.layers[e].ty === 99)) {
        var n = this.createItem(this.layers[e], this, this.globalData);
        t[e] = n, n.initExpressions();
      }
    }, CanvasRendererBase.prototype.checkPendingElements = function() {
      for (; this.pendingElements.length; ) this.pendingElements.pop().checkParenting();
    }, CanvasRendererBase.prototype.hide = function() {
      this.animationItem.container.style.display = `none`;
    }, CanvasRendererBase.prototype.show = function() {
      this.animationItem.container.style.display = `block`;
    };
    function CanvasContext() {
      this.opacity = -1, this.transform = createTypedArray(`float32`, 16), this.fillStyle = ``, this.strokeStyle = ``, this.lineWidth = ``, this.lineCap = ``, this.lineJoin = ``, this.miterLimit = ``, this.id = Math.random();
    }
    function CVContextData() {
      this.stack = [], this.cArrPos = 0, this.cTr = new Matrix();
      var e, t = 15;
      for (e = 0; e < t; e += 1) {
        var n = new CanvasContext();
        this.stack[e] = n;
      }
      this._length = t, this.nativeContext = null, this.transformMat = new Matrix(), this.currentOpacity = 1, this.currentFillStyle = ``, this.appliedFillStyle = ``, this.currentStrokeStyle = ``, this.appliedStrokeStyle = ``, this.currentLineWidth = ``, this.appliedLineWidth = ``, this.currentLineCap = ``, this.appliedLineCap = ``, this.currentLineJoin = ``, this.appliedLineJoin = ``, this.appliedMiterLimit = ``, this.currentMiterLimit = ``;
    }
    CVContextData.prototype.duplicate = function() {
      var e = this._length * 2, t = 0;
      for (t = this._length; t < e; t += 1) this.stack[t] = new CanvasContext();
      this._length = e;
    }, CVContextData.prototype.reset = function() {
      this.cArrPos = 0, this.cTr.reset(), this.stack[this.cArrPos].opacity = 1;
    }, CVContextData.prototype.restore = function(e) {
      --this.cArrPos;
      var t = this.stack[this.cArrPos], n = t.transform, r, i = this.cTr.props;
      for (r = 0; r < 16; r += 1) i[r] = n[r];
      if (e) {
        this.nativeContext.restore();
        var a = this.stack[this.cArrPos + 1];
        this.appliedFillStyle = a.fillStyle, this.appliedStrokeStyle = a.strokeStyle, this.appliedLineWidth = a.lineWidth, this.appliedLineCap = a.lineCap, this.appliedLineJoin = a.lineJoin, this.appliedMiterLimit = a.miterLimit;
      }
      this.nativeContext.setTransform(n[0], n[1], n[4], n[5], n[12], n[13]), (e || t.opacity !== -1 && this.currentOpacity !== t.opacity) && (this.nativeContext.globalAlpha = t.opacity, this.currentOpacity = t.opacity), this.currentFillStyle = t.fillStyle, this.currentStrokeStyle = t.strokeStyle, this.currentLineWidth = t.lineWidth, this.currentLineCap = t.lineCap, this.currentLineJoin = t.lineJoin, this.currentMiterLimit = t.miterLimit;
    }, CVContextData.prototype.save = function(e) {
      e && this.nativeContext.save();
      var t = this.cTr.props;
      this._length <= this.cArrPos && this.duplicate();
      for (var n = this.stack[this.cArrPos], r = 0; r < 16; r += 1) n.transform[r] = t[r];
      this.cArrPos += 1;
      var i = this.stack[this.cArrPos];
      i.opacity = n.opacity, i.fillStyle = n.fillStyle, i.strokeStyle = n.strokeStyle, i.lineWidth = n.lineWidth, i.lineCap = n.lineCap, i.lineJoin = n.lineJoin, i.miterLimit = n.miterLimit;
    }, CVContextData.prototype.setOpacity = function(e) {
      this.stack[this.cArrPos].opacity = e;
    }, CVContextData.prototype.setContext = function(e) {
      this.nativeContext = e;
    }, CVContextData.prototype.fillStyle = function(e) {
      this.stack[this.cArrPos].fillStyle !== e && (this.currentFillStyle = e, this.stack[this.cArrPos].fillStyle = e);
    }, CVContextData.prototype.strokeStyle = function(e) {
      this.stack[this.cArrPos].strokeStyle !== e && (this.currentStrokeStyle = e, this.stack[this.cArrPos].strokeStyle = e);
    }, CVContextData.prototype.lineWidth = function(e) {
      this.stack[this.cArrPos].lineWidth !== e && (this.currentLineWidth = e, this.stack[this.cArrPos].lineWidth = e);
    }, CVContextData.prototype.lineCap = function(e) {
      this.stack[this.cArrPos].lineCap !== e && (this.currentLineCap = e, this.stack[this.cArrPos].lineCap = e);
    }, CVContextData.prototype.lineJoin = function(e) {
      this.stack[this.cArrPos].lineJoin !== e && (this.currentLineJoin = e, this.stack[this.cArrPos].lineJoin = e);
    }, CVContextData.prototype.miterLimit = function(e) {
      this.stack[this.cArrPos].miterLimit !== e && (this.currentMiterLimit = e, this.stack[this.cArrPos].miterLimit = e);
    }, CVContextData.prototype.transform = function(e) {
      this.transformMat.cloneFromProps(e);
      var t = this.cTr;
      this.transformMat.multiply(t), t.cloneFromProps(this.transformMat.props);
      var n = t.props;
      this.nativeContext.setTransform(n[0], n[1], n[4], n[5], n[12], n[13]);
    }, CVContextData.prototype.opacity = function(e) {
      var t = this.stack[this.cArrPos].opacity;
      t *= e < 0 ? 0 : e, this.stack[this.cArrPos].opacity !== t && (this.currentOpacity !== e && (this.nativeContext.globalAlpha = e, this.currentOpacity = e), this.stack[this.cArrPos].opacity = t);
    }, CVContextData.prototype.fill = function(e) {
      this.appliedFillStyle !== this.currentFillStyle && (this.appliedFillStyle = this.currentFillStyle, this.nativeContext.fillStyle = this.appliedFillStyle), this.nativeContext.fill(e);
    }, CVContextData.prototype.fillRect = function(e, t, n, r) {
      this.appliedFillStyle !== this.currentFillStyle && (this.appliedFillStyle = this.currentFillStyle, this.nativeContext.fillStyle = this.appliedFillStyle), this.nativeContext.fillRect(e, t, n, r);
    }, CVContextData.prototype.stroke = function() {
      this.appliedStrokeStyle !== this.currentStrokeStyle && (this.appliedStrokeStyle = this.currentStrokeStyle, this.nativeContext.strokeStyle = this.appliedStrokeStyle), this.appliedLineWidth !== this.currentLineWidth && (this.appliedLineWidth = this.currentLineWidth, this.nativeContext.lineWidth = this.appliedLineWidth), this.appliedLineCap !== this.currentLineCap && (this.appliedLineCap = this.currentLineCap, this.nativeContext.lineCap = this.appliedLineCap), this.appliedLineJoin !== this.currentLineJoin && (this.appliedLineJoin = this.currentLineJoin, this.nativeContext.lineJoin = this.appliedLineJoin), this.appliedMiterLimit !== this.currentMiterLimit && (this.appliedMiterLimit = this.currentMiterLimit, this.nativeContext.miterLimit = this.appliedMiterLimit), this.nativeContext.stroke();
    };
    function CVCompElement(e, t, n) {
      this.completeLayers = false, this.layers = e.layers, this.pendingElements = [], this.elements = createSizedArray(this.layers.length), this.initElement(e, t, n), this.tm = e.tm ? PropertyFactory.getProp(this, e.tm, 0, t.frameRate, this) : { _placeholder: true };
    }
    extendPrototype([CanvasRendererBase, ICompElement, CVBaseElement], CVCompElement), CVCompElement.prototype.renderInnerContent = function() {
      var e = this.canvasContext;
      e.beginPath(), e.moveTo(0, 0), e.lineTo(this.data.w, 0), e.lineTo(this.data.w, this.data.h), e.lineTo(0, this.data.h), e.lineTo(0, 0), e.clip();
      for (var t = this.layers.length - 1; t >= 0; --t) (this.completeLayers || this.elements[t]) && this.elements[t].renderFrame();
    }, CVCompElement.prototype.destroy = function() {
      for (var e = this.layers.length - 1; e >= 0; --e) this.elements[e] && this.elements[e].destroy();
      this.layers = null, this.elements = null;
    }, CVCompElement.prototype.createComp = function(e) {
      return new CVCompElement(e, this.globalData, this);
    };
    function CanvasRenderer(e, t) {
      this.animationItem = e, this.renderConfig = { clearCanvas: t && t.clearCanvas !== void 0 ? t.clearCanvas : true, context: t && t.context || null, progressiveLoad: t && t.progressiveLoad || false, preserveAspectRatio: t && t.preserveAspectRatio || `xMidYMid meet`, imagePreserveAspectRatio: t && t.imagePreserveAspectRatio || `xMidYMid slice`, contentVisibility: t && t.contentVisibility || `visible`, className: t && t.className || ``, id: t && t.id || ``, runExpressions: !t || t.runExpressions === void 0 || t.runExpressions }, this.renderConfig.dpr = t && t.dpr || 1, this.animationItem.wrapper && (this.renderConfig.dpr = t && t.dpr || window.devicePixelRatio || 1), this.renderedFrame = -1, this.globalData = { frameNum: -1, _mdf: false, renderConfig: this.renderConfig, currentGlobalAlpha: -1 }, this.contextData = new CVContextData(), this.elements = [], this.pendingElements = [], this.transformMat = new Matrix(), this.completeLayers = false, this.rendererType = `canvas`, this.renderConfig.clearCanvas && (this.ctxTransform = this.contextData.transform.bind(this.contextData), this.ctxOpacity = this.contextData.opacity.bind(this.contextData), this.ctxFillStyle = this.contextData.fillStyle.bind(this.contextData), this.ctxStrokeStyle = this.contextData.strokeStyle.bind(this.contextData), this.ctxLineWidth = this.contextData.lineWidth.bind(this.contextData), this.ctxLineCap = this.contextData.lineCap.bind(this.contextData), this.ctxLineJoin = this.contextData.lineJoin.bind(this.contextData), this.ctxMiterLimit = this.contextData.miterLimit.bind(this.contextData), this.ctxFill = this.contextData.fill.bind(this.contextData), this.ctxFillRect = this.contextData.fillRect.bind(this.contextData), this.ctxStroke = this.contextData.stroke.bind(this.contextData), this.save = this.contextData.save.bind(this.contextData));
    }
    extendPrototype([CanvasRendererBase], CanvasRenderer), CanvasRenderer.prototype.createComp = function(e) {
      return new CVCompElement(e, this.globalData, this);
    };
    function HBaseElement() {
    }
    HBaseElement.prototype = { checkBlendMode: function() {
    }, initRendererElement: function() {
      this.baseElement = createTag(this.data.tg || `div`), this.data.hasMask ? (this.svgElement = createNS(`svg`), this.layerElement = createNS(`g`), this.maskedElement = this.layerElement, this.svgElement.appendChild(this.layerElement), this.baseElement.appendChild(this.svgElement)) : this.layerElement = this.baseElement, styleDiv(this.baseElement);
    }, createContainerElements: function() {
      this.renderableEffectsManager = new CVEffects(this), this.transformedElement = this.baseElement, this.maskedElement = this.layerElement, this.data.ln && this.layerElement.setAttribute(`id`, this.data.ln), this.data.cl && this.layerElement.setAttribute(`class`, this.data.cl), this.data.bm !== 0 && this.setBlendMode();
    }, renderElement: function() {
      var e = this.transformedElement ? this.transformedElement.style : {};
      if (this.finalTransform._matMdf) {
        var t = this.finalTransform.mat.toCSS();
        e.transform = t, e.webkitTransform = t;
      }
      this.finalTransform._opMdf && (e.opacity = this.finalTransform.mProp.o.v);
    }, renderFrame: function() {
      this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = false));
    }, destroy: function() {
      this.layerElement = null, this.transformedElement = null, this.matteElement && (this.matteElement = null), this.maskManager && (this.maskManager = (this.maskManager.destroy(), null));
    }, createRenderableComponents: function() {
      this.maskManager = new MaskElement(this.data, this, this.globalData);
    }, addEffects: function() {
    }, setMatte: function() {
    } }, HBaseElement.prototype.getBaseElement = SVGBaseElement.prototype.getBaseElement, HBaseElement.prototype.destroyBaseElement = HBaseElement.prototype.destroy, HBaseElement.prototype.buildElementParenting = BaseRenderer.prototype.buildElementParenting;
    function HSolidElement(e, t, n) {
      this.initElement(e, t, n);
    }
    extendPrototype([BaseElement, TransformElement, HBaseElement, HierarchyElement, FrameElement, RenderableDOMElement], HSolidElement), HSolidElement.prototype.createContent = function() {
      var e;
      this.data.hasMask ? (e = createNS(`rect`), e.setAttribute(`width`, this.data.sw), e.setAttribute(`height`, this.data.sh), e.setAttribute(`fill`, this.data.sc), this.svgElement.setAttribute(`width`, this.data.sw), this.svgElement.setAttribute(`height`, this.data.sh)) : (e = createTag(`div`), e.style.width = this.data.sw + `px`, e.style.height = this.data.sh + `px`, e.style.backgroundColor = this.data.sc), this.layerElement.appendChild(e);
    };
    function HShapeElement(e, t, n) {
      this.shapes = [], this.shapesData = e.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.shapesContainer = createNS(`g`), this.initElement(e, t, n), this.prevViewData = [], this.currentBBox = { x: 999999, y: -999999, h: 0, w: 0 };
    }
    extendPrototype([BaseElement, TransformElement, HSolidElement, SVGShapeElement, HBaseElement, HierarchyElement, FrameElement, RenderableElement], HShapeElement), HShapeElement.prototype._renderShapeFrame = HShapeElement.prototype.renderInnerContent, HShapeElement.prototype.createContent = function() {
      var e;
      if (this.baseElement.style.fontSize = 0, this.data.hasMask) this.layerElement.appendChild(this.shapesContainer), e = this.svgElement;
      else {
        e = createNS(`svg`);
        var t = this.comp.data ? this.comp.data : this.globalData.compSize;
        e.setAttribute(`width`, t.w), e.setAttribute(`height`, t.h), e.appendChild(this.shapesContainer), this.layerElement.appendChild(e);
      }
      this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.shapesContainer, 0, [], true), this.filterUniqueShapes(), this.shapeCont = e;
    }, HShapeElement.prototype.getTransformedPoint = function(e, t) {
      var n, r = e.length;
      for (n = 0; n < r; n += 1) t = e[n].mProps.v.applyToPointArray(t[0], t[1], 0);
      return t;
    }, HShapeElement.prototype.calculateShapeBoundingBox = function(e, t) {
      var n = e.sh.v, r = e.transformers, i, a = n._length, o, s, c, l;
      if (!(a <= 1)) {
        for (i = 0; i < a - 1; i += 1) o = this.getTransformedPoint(r, n.v[i]), s = this.getTransformedPoint(r, n.o[i]), c = this.getTransformedPoint(r, n.i[i + 1]), l = this.getTransformedPoint(r, n.v[i + 1]), this.checkBounds(o, s, c, l, t);
        n.c && (o = this.getTransformedPoint(r, n.v[i]), s = this.getTransformedPoint(r, n.o[i]), c = this.getTransformedPoint(r, n.i[0]), l = this.getTransformedPoint(r, n.v[0]), this.checkBounds(o, s, c, l, t));
      }
    }, HShapeElement.prototype.checkBounds = function(e, t, n, r, i) {
      this.getBoundsOfCurve(e, t, n, r);
      var a = this.shapeBoundingBox;
      i.x = bmMin(a.left, i.x), i.xMax = bmMax(a.right, i.xMax), i.y = bmMin(a.top, i.y), i.yMax = bmMax(a.bottom, i.yMax);
    }, HShapeElement.prototype.shapeBoundingBox = { left: 0, right: 0, top: 0, bottom: 0 }, HShapeElement.prototype.tempBoundingBox = { x: 0, xMax: 0, y: 0, yMax: 0, width: 0, height: 0 }, HShapeElement.prototype.getBoundsOfCurve = function(e, t, n, r) {
      for (var i = [[e[0], r[0]], [e[1], r[1]]], a, o, s, c, l, u, d, f = 0; f < 2; ++f) o = 6 * e[f] - 12 * t[f] + 6 * n[f], a = -3 * e[f] + 9 * t[f] - 9 * n[f] + 3 * r[f], s = 3 * t[f] - 3 * e[f], o |= 0, a |= 0, s |= 0, a === 0 && o === 0 || (a === 0 ? (c = -s / o, c > 0 && c < 1 && i[f].push(this.calculateF(c, e, t, n, r, f))) : (l = o * o - 4 * s * a, l >= 0 && (u = (-o + bmSqrt(l)) / (2 * a), u > 0 && u < 1 && i[f].push(this.calculateF(u, e, t, n, r, f)), d = (-o - bmSqrt(l)) / (2 * a), d > 0 && d < 1 && i[f].push(this.calculateF(d, e, t, n, r, f)))));
      this.shapeBoundingBox.left = bmMin.apply(null, i[0]), this.shapeBoundingBox.top = bmMin.apply(null, i[1]), this.shapeBoundingBox.right = bmMax.apply(null, i[0]), this.shapeBoundingBox.bottom = bmMax.apply(null, i[1]);
    }, HShapeElement.prototype.calculateF = function(e, t, n, r, i, a) {
      return bmPow(1 - e, 3) * t[a] + 3 * bmPow(1 - e, 2) * e * n[a] + 3 * (1 - e) * bmPow(e, 2) * r[a] + bmPow(e, 3) * i[a];
    }, HShapeElement.prototype.calculateBoundingBox = function(e, t) {
      var n, r = e.length;
      for (n = 0; n < r; n += 1) e[n] && e[n].sh ? this.calculateShapeBoundingBox(e[n], t) : e[n] && e[n].it ? this.calculateBoundingBox(e[n].it, t) : e[n] && e[n].style && e[n].w && this.expandStrokeBoundingBox(e[n].w, t);
    }, HShapeElement.prototype.expandStrokeBoundingBox = function(e, t) {
      var n = 0;
      if (e.keyframes) {
        for (var r = 0; r < e.keyframes.length; r += 1) {
          var i = e.keyframes[r].s;
          i > n && (n = i);
        }
        n *= e.mult;
      } else n = e.v * e.mult;
      t.x -= n, t.xMax += n, t.y -= n, t.yMax += n;
    }, HShapeElement.prototype.currentBoxContains = function(e) {
      return this.currentBBox.x <= e.x && this.currentBBox.y <= e.y && this.currentBBox.width + this.currentBBox.x >= e.x + e.width && this.currentBBox.height + this.currentBBox.y >= e.y + e.height;
    }, HShapeElement.prototype.renderInnerContent = function() {
      if (this._renderShapeFrame(), !this.hidden && (this._isFirstFrame || this._mdf)) {
        var e = this.tempBoundingBox, t = 999999;
        if (e.x = t, e.xMax = -t, e.y = t, e.yMax = -t, this.calculateBoundingBox(this.itemsData, e), e.width = e.xMax < e.x ? 0 : e.xMax - e.x, e.height = e.yMax < e.y ? 0 : e.yMax - e.y, this.currentBoxContains(e)) return;
        var n = false;
        if (this.currentBBox.w !== e.width && (this.currentBBox.w = e.width, this.shapeCont.setAttribute(`width`, e.width), n = true), this.currentBBox.h !== e.height && (this.currentBBox.h = e.height, this.shapeCont.setAttribute(`height`, e.height), n = true), n || this.currentBBox.x !== e.x || this.currentBBox.y !== e.y) {
          this.currentBBox.w = e.width, this.currentBBox.h = e.height, this.currentBBox.x = e.x, this.currentBBox.y = e.y, this.shapeCont.setAttribute(`viewBox`, this.currentBBox.x + ` ` + this.currentBBox.y + ` ` + this.currentBBox.w + ` ` + this.currentBBox.h);
          var r = this.shapeCont.style, i = `translate(` + this.currentBBox.x + `px,` + this.currentBBox.y + `px)`;
          r.transform = i, r.webkitTransform = i;
        }
      }
    };
    function HTextElement(e, t, n) {
      this.textSpans = [], this.textPaths = [], this.currentBBox = { x: 999999, y: -999999, h: 0, w: 0 }, this.renderType = `svg`, this.isMasked = false, this.initElement(e, t, n);
    }
    extendPrototype([BaseElement, TransformElement, HBaseElement, HierarchyElement, FrameElement, RenderableDOMElement, ITextElement], HTextElement), HTextElement.prototype.createContent = function() {
      if (this.isMasked = this.checkMasks(), this.isMasked) {
        this.renderType = `svg`, this.compW = this.comp.data.w, this.compH = this.comp.data.h, this.svgElement.setAttribute(`width`, this.compW), this.svgElement.setAttribute(`height`, this.compH);
        var e = createNS(`g`);
        this.maskedElement.appendChild(e), this.innerElem = e;
      } else this.renderType = `html`, this.innerElem = this.layerElement;
      this.checkParenting();
    }, HTextElement.prototype.buildNewText = function() {
      var e = this.textProperty.currentData;
      this.renderedLetters = createSizedArray(e.l ? e.l.length : 0);
      var t = this.innerElem.style, n = e.fc ? this.buildColor(e.fc) : `rgba(0,0,0,0)`;
      t.fill = n, t.color = n, e.sc && (t.stroke = this.buildColor(e.sc), t.strokeWidth = e.sw + `px`);
      var r = this.globalData.fontManager.getFontByName(e.f);
      if (!this.globalData.fontManager.chars) {
        if (t.fontSize = e.finalSize + `px`, t.lineHeight = e.finalSize + `px`, r.fClass) this.innerElem.className = r.fClass;
        else {
          t.fontFamily = r.fFamily;
          var i = e.fWeight;
          t.fontStyle = e.fStyle, t.fontWeight = i;
        }
      }
      var a, o, s = e.l;
      o = s.length;
      var c, l, u, d = this.mHelper, f, p = ``, m = 0;
      for (a = 0; a < o; a += 1) {
        if (this.globalData.fontManager.chars ? (this.textPaths[m] ? c = this.textPaths[m] : (c = createNS(`path`), c.setAttribute(`stroke-linecap`, lineCapEnum[1]), c.setAttribute(`stroke-linejoin`, lineJoinEnum[2]), c.setAttribute(`stroke-miterlimit`, `4`)), this.isMasked || (this.textSpans[m] ? (l = this.textSpans[m], u = l.children[0]) : (l = createTag(`div`), l.style.lineHeight = 0, u = createNS(`svg`), u.appendChild(c), styleDiv(l)))) : this.isMasked ? c = this.textPaths[m] ? this.textPaths[m] : createNS(`text`) : this.textSpans[m] ? (l = this.textSpans[m], c = this.textPaths[m]) : (l = createTag(`span`), styleDiv(l), c = createTag(`span`), styleDiv(c), l.appendChild(c)), this.globalData.fontManager.chars) {
          var g = this.globalData.fontManager.getCharData(e.finalText[a], r.fStyle, this.globalData.fontManager.getFontByName(e.f).fFamily), _ = g ? g.data : null;
          if (d.reset(), _ && _.shapes && _.shapes.length && (f = _.shapes[0].it, d.scale(e.finalSize / 100, e.finalSize / 100), p = this.createPathShape(d, f), c.setAttribute(`d`, p)), this.isMasked) this.innerElem.appendChild(c);
          else {
            if (this.innerElem.appendChild(l), _ && _.shapes) {
              document.body.appendChild(u);
              var y = u.getBBox();
              u.setAttribute(`width`, y.width + 2), u.setAttribute(`height`, y.height + 2), u.setAttribute(`viewBox`, y.x - 1 + ` ` + (y.y - 1) + ` ` + (y.width + 2) + ` ` + (y.height + 2));
              var b = u.style, x = `translate(` + (y.x - 1) + `px,` + (y.y - 1) + `px)`;
              b.transform = x, b.webkitTransform = x, s[a].yOffset = y.y - 1;
            } else u.setAttribute(`width`, 1), u.setAttribute(`height`, 1);
            l.appendChild(u);
          }
        } else if (c.textContent = s[a].val, c.setAttributeNS(`http://www.w3.org/XML/1998/namespace`, `xml:space`, `preserve`), this.isMasked) this.innerElem.appendChild(c);
        else {
          this.innerElem.appendChild(l);
          var S = c.style, C = `translate3d(0,` + -e.finalSize / 1.2 + `px,0)`;
          S.transform = C, S.webkitTransform = C;
        }
        this.isMasked ? this.textSpans[m] = c : this.textSpans[m] = l, this.textSpans[m].style.display = `block`, this.textPaths[m] = c, m += 1;
      }
      for (; m < this.textSpans.length; ) this.textSpans[m].style.display = `none`, m += 1;
    }, HTextElement.prototype.renderInnerContent = function() {
      this.validateText();
      var e;
      if (this.data.singleShape) {
        if (!this._isFirstFrame && !this.lettersChangedFlag) return;
        if (this.isMasked && this.finalTransform._matMdf) {
          this.svgElement.setAttribute(`viewBox`, -this.finalTransform.mProp.p.v[0] + ` ` + -this.finalTransform.mProp.p.v[1] + ` ` + this.compW + ` ` + this.compH), e = this.svgElement.style;
          var t = `translate(` + -this.finalTransform.mProp.p.v[0] + `px,` + -this.finalTransform.mProp.p.v[1] + `px)`;
          e.transform = t, e.webkitTransform = t;
        }
      }
      if (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag) {
        var n, r, i = 0, a = this.textAnimator.renderedLetters, o = this.textProperty.currentData.l;
        r = o.length;
        var s, c, l;
        for (n = 0; n < r; n += 1) o[n].n ? i += 1 : (c = this.textSpans[n], l = this.textPaths[n], s = a[i], i += 1, s._mdf.m && (this.isMasked ? c.setAttribute(`transform`, s.m) : (c.style.webkitTransform = s.m, c.style.transform = s.m)), c.style.opacity = s.o, s.sw && s._mdf.sw && l.setAttribute(`stroke-width`, s.sw), s.sc && s._mdf.sc && l.setAttribute(`stroke`, s.sc), s.fc && s._mdf.fc && (l.setAttribute(`fill`, s.fc), l.style.color = s.fc));
        if (this.innerElem.getBBox && !this.hidden && (this._isFirstFrame || this._mdf)) {
          var u = this.innerElem.getBBox();
          this.currentBBox.w !== u.width && (this.currentBBox.w = u.width, this.svgElement.setAttribute(`width`, u.width)), this.currentBBox.h !== u.height && (this.currentBBox.h = u.height, this.svgElement.setAttribute(`height`, u.height));
          var d = 1;
          if (this.currentBBox.w !== u.width + d * 2 || this.currentBBox.h !== u.height + d * 2 || this.currentBBox.x !== u.x - d || this.currentBBox.y !== u.y - d) {
            this.currentBBox.w = u.width + d * 2, this.currentBBox.h = u.height + d * 2, this.currentBBox.x = u.x - d, this.currentBBox.y = u.y - d, this.svgElement.setAttribute(`viewBox`, this.currentBBox.x + ` ` + this.currentBBox.y + ` ` + this.currentBBox.w + ` ` + this.currentBBox.h), e = this.svgElement.style;
            var f = `translate(` + this.currentBBox.x + `px,` + this.currentBBox.y + `px)`;
            e.transform = f, e.webkitTransform = f;
          }
        }
      }
    };
    function HCameraElement(e, t, n) {
      this.initFrame(), this.initBaseData(e, t, n), this.initHierarchy();
      var r = PropertyFactory.getProp;
      if (this.pe = r(this, e.pe, 0, 0, this), e.ks.p.s ? (this.px = r(this, e.ks.p.x, 1, 0, this), this.py = r(this, e.ks.p.y, 1, 0, this), this.pz = r(this, e.ks.p.z, 1, 0, this)) : this.p = r(this, e.ks.p, 1, 0, this), e.ks.a && (this.a = r(this, e.ks.a, 1, 0, this)), e.ks.or.k.length && e.ks.or.k[0].to) {
        var i, a = e.ks.or.k.length;
        for (i = 0; i < a; i += 1) e.ks.or.k[i].to = null, e.ks.or.k[i].ti = null;
      }
      this.or = r(this, e.ks.or, 1, degToRads, this), this.or.sh = true, this.rx = r(this, e.ks.rx, 0, degToRads, this), this.ry = r(this, e.ks.ry, 0, degToRads, this), this.rz = r(this, e.ks.rz, 0, degToRads, this), this.mat = new Matrix(), this._prevMat = new Matrix(), this._isFirstFrame = true, this.finalTransform = { mProp: this };
    }
    extendPrototype([BaseElement, FrameElement, HierarchyElement], HCameraElement), HCameraElement.prototype.setup = function() {
      var e, t = this.comp.threeDElements.length, n, r, i;
      for (e = 0; e < t; e += 1) if (n = this.comp.threeDElements[e], n.type === `3d`) {
        r = n.perspectiveElem.style, i = n.container.style;
        var a = this.pe.v + `px`, o = `0px 0px 0px`, s = `matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)`;
        r.perspective = a, r.webkitPerspective = a, i.transformOrigin = o, i.mozTransformOrigin = o, i.webkitTransformOrigin = o, r.transform = s, r.webkitTransform = s;
      }
    }, HCameraElement.prototype.createElements = function() {
    }, HCameraElement.prototype.hide = function() {
    }, HCameraElement.prototype.renderFrame = function() {
      var e = this._isFirstFrame, t, n;
      if (this.hierarchy) for (n = this.hierarchy.length, t = 0; t < n; t += 1) e = this.hierarchy[t].finalTransform.mProp._mdf || e;
      if (e || this.pe._mdf || this.p && this.p._mdf || this.px && (this.px._mdf || this.py._mdf || this.pz._mdf) || this.rx._mdf || this.ry._mdf || this.rz._mdf || this.or._mdf || this.a && this.a._mdf) {
        if (this.mat.reset(), this.hierarchy) for (n = this.hierarchy.length - 1, t = n; t >= 0; --t) {
          var r = this.hierarchy[t].finalTransform.mProp;
          this.mat.translate(-r.p.v[0], -r.p.v[1], r.p.v[2]), this.mat.rotateX(-r.or.v[0]).rotateY(-r.or.v[1]).rotateZ(r.or.v[2]), this.mat.rotateX(-r.rx.v).rotateY(-r.ry.v).rotateZ(r.rz.v), this.mat.scale(1 / r.s.v[0], 1 / r.s.v[1], 1 / r.s.v[2]), this.mat.translate(r.a.v[0], r.a.v[1], r.a.v[2]);
        }
        if (this.p ? this.mat.translate(-this.p.v[0], -this.p.v[1], this.p.v[2]) : this.mat.translate(-this.px.v, -this.py.v, this.pz.v), this.a) {
          var i = this.p ? [this.p.v[0] - this.a.v[0], this.p.v[1] - this.a.v[1], this.p.v[2] - this.a.v[2]] : [this.px.v - this.a.v[0], this.py.v - this.a.v[1], this.pz.v - this.a.v[2]], a = Math.sqrt(i[0] ** 2 + i[1] ** 2 + i[2] ** 2), o = [i[0] / a, i[1] / a, i[2] / a], s = Math.sqrt(o[2] * o[2] + o[0] * o[0]), c = Math.atan2(o[1], s), l = Math.atan2(o[0], -o[2]);
          this.mat.rotateY(l).rotateX(-c);
        }
        this.mat.rotateX(-this.rx.v).rotateY(-this.ry.v).rotateZ(this.rz.v), this.mat.rotateX(-this.or.v[0]).rotateY(-this.or.v[1]).rotateZ(this.or.v[2]), this.mat.translate(this.globalData.compSize.w / 2, this.globalData.compSize.h / 2, 0), this.mat.translate(0, 0, this.pe.v);
        var u = !this._prevMat.equals(this.mat);
        if ((u || this.pe._mdf) && this.comp.threeDElements) {
          n = this.comp.threeDElements.length;
          var d, f, p;
          for (t = 0; t < n; t += 1) if (d = this.comp.threeDElements[t], d.type === `3d`) {
            if (u) {
              var m = this.mat.toCSS();
              p = d.container.style, p.transform = m, p.webkitTransform = m;
            }
            this.pe._mdf && (f = d.perspectiveElem.style, f.perspective = this.pe.v + `px`, f.webkitPerspective = this.pe.v + `px`);
          }
          this.mat.clone(this._prevMat);
        }
      }
      this._isFirstFrame = false;
    }, HCameraElement.prototype.prepareFrame = function(e) {
      this.prepareProperties(e, true);
    }, HCameraElement.prototype.destroy = function() {
    }, HCameraElement.prototype.getBaseElement = function() {
      return null;
    };
    function HImageElement(e, t, n) {
      this.assetData = t.getAssetData(e.refId), this.initElement(e, t, n);
    }
    extendPrototype([BaseElement, TransformElement, HBaseElement, HSolidElement, HierarchyElement, FrameElement, RenderableElement], HImageElement), HImageElement.prototype.createContent = function() {
      var e = this.globalData.getAssetsPath(this.assetData), t = new Image();
      this.data.hasMask ? (this.imageElem = createNS(`image`), this.imageElem.setAttribute(`width`, this.assetData.w + `px`), this.imageElem.setAttribute(`height`, this.assetData.h + `px`), this.imageElem.setAttributeNS(`http://www.w3.org/1999/xlink`, `href`, e), this.layerElement.appendChild(this.imageElem), this.baseElement.setAttribute(`width`, this.assetData.w), this.baseElement.setAttribute(`height`, this.assetData.h)) : this.layerElement.appendChild(t), t.crossOrigin = `anonymous`, t.src = e, this.data.ln && this.baseElement.setAttribute(`id`, this.data.ln);
    };
    function HybridRendererBase(e, t) {
      this.animationItem = e, this.layers = null, this.renderedFrame = -1, this.renderConfig = { className: t && t.className || ``, imagePreserveAspectRatio: t && t.imagePreserveAspectRatio || `xMidYMid slice`, hideOnTransparent: !(t && t.hideOnTransparent === false), filterSize: { width: t && t.filterSize && t.filterSize.width || `400%`, height: t && t.filterSize && t.filterSize.height || `400%`, x: t && t.filterSize && t.filterSize.x || `-100%`, y: t && t.filterSize && t.filterSize.y || `-100%` } }, this.globalData = { _mdf: false, frameNum: -1, renderConfig: this.renderConfig }, this.pendingElements = [], this.elements = [], this.threeDElements = [], this.destroyed = false, this.camera = null, this.supports3d = true, this.rendererType = `html`;
    }
    extendPrototype([BaseRenderer], HybridRendererBase), HybridRendererBase.prototype.buildItem = SVGRenderer.prototype.buildItem, HybridRendererBase.prototype.checkPendingElements = function() {
      for (; this.pendingElements.length; ) this.pendingElements.pop().checkParenting();
    }, HybridRendererBase.prototype.appendElementInPos = function(e, t) {
      var n = e.getBaseElement();
      if (n) {
        var r = this.layers[t];
        if (!r.ddd || !this.supports3d) {
          if (this.threeDElements) this.addTo3dContainer(n, t);
          else {
            for (var i = 0, a, o, s; i < t; ) this.elements[i] && this.elements[i] !== true && this.elements[i].getBaseElement && (o = this.elements[i], s = this.layers[i].ddd ? this.getThreeDContainerByPos(i) : o.getBaseElement(), a = s || a), i += 1;
            a ? (!r.ddd || !this.supports3d) && this.layerElement.insertBefore(n, a) : (!r.ddd || !this.supports3d) && this.layerElement.appendChild(n);
          }
        } else this.addTo3dContainer(n, t);
      }
    }, HybridRendererBase.prototype.createShape = function(e) {
      return this.supports3d ? new HShapeElement(e, this.globalData, this) : new SVGShapeElement(e, this.globalData, this);
    }, HybridRendererBase.prototype.createText = function(e) {
      return this.supports3d ? new HTextElement(e, this.globalData, this) : new SVGTextLottieElement(e, this.globalData, this);
    }, HybridRendererBase.prototype.createCamera = function(e) {
      return this.camera = new HCameraElement(e, this.globalData, this), this.camera;
    }, HybridRendererBase.prototype.createImage = function(e) {
      return this.supports3d ? new HImageElement(e, this.globalData, this) : new IImageElement(e, this.globalData, this);
    }, HybridRendererBase.prototype.createSolid = function(e) {
      return this.supports3d ? new HSolidElement(e, this.globalData, this) : new ISolidElement(e, this.globalData, this);
    }, HybridRendererBase.prototype.createNull = SVGRenderer.prototype.createNull, HybridRendererBase.prototype.getThreeDContainerByPos = function(e) {
      for (var t = 0, n = this.threeDElements.length; t < n; ) {
        if (this.threeDElements[t].startPos <= e && this.threeDElements[t].endPos >= e) return this.threeDElements[t].perspectiveElem;
        t += 1;
      }
      return null;
    }, HybridRendererBase.prototype.createThreeDContainer = function(e, t) {
      var n = createTag(`div`), r, i;
      styleDiv(n);
      var a = createTag(`div`);
      if (styleDiv(a), t === `3d`) {
        r = n.style, r.width = this.globalData.compSize.w + `px`, r.height = this.globalData.compSize.h + `px`;
        var o = `50% 50%`;
        r.webkitTransformOrigin = o, r.mozTransformOrigin = o, r.transformOrigin = o, i = a.style;
        var s = `matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)`;
        i.transform = s, i.webkitTransform = s;
      }
      n.appendChild(a);
      var c = { container: a, perspectiveElem: n, startPos: e, endPos: e, type: t };
      return this.threeDElements.push(c), c;
    }, HybridRendererBase.prototype.build3dContainers = function() {
      var e, t = this.layers.length, n, r = ``;
      for (e = 0; e < t; e += 1) this.layers[e].ddd && this.layers[e].ty !== 3 ? (r !== `3d` && (r = `3d`, n = this.createThreeDContainer(e, `3d`)), n.endPos = Math.max(n.endPos, e)) : (r !== `2d` && (r = `2d`, n = this.createThreeDContainer(e, `2d`)), n.endPos = Math.max(n.endPos, e));
      for (t = this.threeDElements.length, e = t - 1; e >= 0; --e) this.resizerElem.appendChild(this.threeDElements[e].perspectiveElem);
    }, HybridRendererBase.prototype.addTo3dContainer = function(e, t) {
      for (var n = 0, r = this.threeDElements.length; n < r; ) {
        if (t <= this.threeDElements[n].endPos) {
          for (var i = this.threeDElements[n].startPos, a; i < t; ) this.elements[i] && this.elements[i].getBaseElement && (a = this.elements[i].getBaseElement()), i += 1;
          a ? this.threeDElements[n].container.insertBefore(e, a) : this.threeDElements[n].container.appendChild(e);
          break;
        }
        n += 1;
      }
    }, HybridRendererBase.prototype.configAnimation = function(e) {
      var t = createTag(`div`), n = this.animationItem.wrapper, r = t.style;
      r.width = e.w + `px`, r.height = e.h + `px`, this.resizerElem = t, styleDiv(t), r.transformStyle = `flat`, r.mozTransformStyle = `flat`, r.webkitTransformStyle = `flat`, this.renderConfig.className && t.setAttribute(`class`, this.renderConfig.className), n.appendChild(t), r.overflow = `hidden`;
      var i = createNS(`svg`);
      i.setAttribute(`width`, `1`), i.setAttribute(`height`, `1`), styleDiv(i), this.resizerElem.appendChild(i);
      var a = createNS(`defs`);
      i.appendChild(a), this.data = e, this.setupGlobalData(e, i), this.globalData.defs = a, this.layers = e.layers, this.layerElement = this.resizerElem, this.build3dContainers(), this.updateContainerSize();
    }, HybridRendererBase.prototype.destroy = function() {
      this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ``), this.animationItem.container = null, this.globalData.defs = null;
      var e, t = this.layers ? this.layers.length : 0;
      for (e = 0; e < t; e += 1) this.elements[e] && this.elements[e].destroy && this.elements[e].destroy();
      this.elements.length = 0, this.destroyed = true, this.animationItem = null;
    }, HybridRendererBase.prototype.updateContainerSize = function() {
      var e = this.animationItem.wrapper.offsetWidth, t = this.animationItem.wrapper.offsetHeight, n = e / t, r = this.globalData.compSize.w / this.globalData.compSize.h, i, a, o, s;
      r > n ? (i = e / this.globalData.compSize.w, a = e / this.globalData.compSize.w, o = 0, s = (t - this.globalData.compSize.h * (e / this.globalData.compSize.w)) / 2) : (i = t / this.globalData.compSize.h, a = t / this.globalData.compSize.h, o = (e - this.globalData.compSize.w * (t / this.globalData.compSize.h)) / 2, s = 0);
      var c = this.resizerElem.style;
      c.webkitTransform = `matrix3d(` + i + `,0,0,0,0,` + a + `,0,0,0,0,1,0,` + o + `,` + s + `,0,1)`, c.transform = c.webkitTransform;
    }, HybridRendererBase.prototype.renderFrame = SVGRenderer.prototype.renderFrame, HybridRendererBase.prototype.hide = function() {
      this.resizerElem.style.display = `none`;
    }, HybridRendererBase.prototype.show = function() {
      this.resizerElem.style.display = `block`;
    }, HybridRendererBase.prototype.initItems = function() {
      if (this.buildAllItems(), this.camera) this.camera.setup();
      else {
        var e = this.globalData.compSize.w, t = this.globalData.compSize.h, n, r = this.threeDElements.length;
        for (n = 0; n < r; n += 1) {
          var i = this.threeDElements[n].perspectiveElem.style;
          i.webkitPerspective = Math.sqrt(e ** 2 + t ** 2) + `px`, i.perspective = i.webkitPerspective;
        }
      }
    }, HybridRendererBase.prototype.searchExtraCompositions = function(e) {
      var t, n = e.length, r = createTag(`div`);
      for (t = 0; t < n; t += 1) if (e[t].xt) {
        var i = this.createComp(e[t], r, this.globalData.comp, null);
        i.initExpressions(), this.globalData.projectInterface.registerComposition(i);
      }
    };
    function HCompElement(e, t, n) {
      this.layers = e.layers, this.supports3d = !e.hasMask, this.completeLayers = false, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(e, t, n), this.tm = e.tm ? PropertyFactory.getProp(this, e.tm, 0, t.frameRate, this) : { _placeholder: true };
    }
    extendPrototype([HybridRendererBase, ICompElement, HBaseElement], HCompElement), HCompElement.prototype._createBaseContainerElements = HCompElement.prototype.createContainerElements, HCompElement.prototype.createContainerElements = function() {
      this._createBaseContainerElements(), this.data.hasMask ? (this.svgElement.setAttribute(`width`, this.data.w), this.svgElement.setAttribute(`height`, this.data.h), this.transformedElement = this.baseElement) : this.transformedElement = this.layerElement;
    }, HCompElement.prototype.addTo3dContainer = function(e, t) {
      for (var n = 0, r; n < t; ) this.elements[n] && this.elements[n].getBaseElement && (r = this.elements[n].getBaseElement()), n += 1;
      r ? this.layerElement.insertBefore(e, r) : this.layerElement.appendChild(e);
    }, HCompElement.prototype.createComp = function(e) {
      return this.supports3d ? new HCompElement(e, this.globalData, this) : new SVGCompElement(e, this.globalData, this);
    };
    function HybridRenderer(e, t) {
      this.animationItem = e, this.layers = null, this.renderedFrame = -1, this.renderConfig = { className: t && t.className || ``, imagePreserveAspectRatio: t && t.imagePreserveAspectRatio || `xMidYMid slice`, hideOnTransparent: !(t && t.hideOnTransparent === false), filterSize: { width: t && t.filterSize && t.filterSize.width || `400%`, height: t && t.filterSize && t.filterSize.height || `400%`, x: t && t.filterSize && t.filterSize.x || `-100%`, y: t && t.filterSize && t.filterSize.y || `-100%` }, runExpressions: !t || t.runExpressions === void 0 || t.runExpressions }, this.globalData = { _mdf: false, frameNum: -1, renderConfig: this.renderConfig }, this.pendingElements = [], this.elements = [], this.threeDElements = [], this.destroyed = false, this.camera = null, this.supports3d = true, this.rendererType = `html`;
    }
    extendPrototype([HybridRendererBase], HybridRenderer), HybridRenderer.prototype.createComp = function(e) {
      return this.supports3d ? new HCompElement(e, this.globalData, this) : new SVGCompElement(e, this.globalData, this);
    };
    var CompExpressionInterface = /* @__PURE__ */ (function() {
      return function(e) {
        function t(t2) {
          for (var n = 0, r = e.layers.length; n < r; ) {
            if (e.layers[n].nm === t2 || e.layers[n].ind === t2) return e.elements[n].layerInterface;
            n += 1;
          }
          return null;
        }
        return Object.defineProperty(t, "_name", { value: e.data.nm }), t.layer = t, t.pixelAspect = 1, t.height = e.data.h || e.globalData.compSize.h, t.width = e.data.w || e.globalData.compSize.w, t.pixelAspect = 1, t.frameDuration = 1 / e.globalData.frameRate, t.displayStartTime = 0, t.numLayers = e.layers.length, t;
      };
    })();
    function _typeof$2(e) {
      "@babel/helpers - typeof";
      return _typeof$2 = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e2) {
        return typeof e2;
      } : function(e2) {
        return e2 && typeof Symbol == `function` && e2.constructor === Symbol && e2 !== Symbol.prototype ? `symbol` : typeof e2;
      }, _typeof$2(e);
    }
    function seedRandom(e, t) {
      var n = this, r = 256, i = 6, a = 52, o = `random`, s = t.pow(r, i), c = t.pow(2, a), l = c * 2, u = r - 1, d;
      function f(n2, a2, u2) {
        var d2 = [];
        a2 = a2 === true ? { entropy: true } : a2 || {};
        var f2 = _(g(a2.entropy ? [n2, b(e)] : n2 === null ? y() : n2, 3), d2), x = new p(d2), S = function() {
          for (var e2 = x.g(i), t2 = s, n3 = 0; e2 < c; ) e2 = (e2 + n3) * r, t2 *= r, n3 = x.g(1);
          for (; e2 >= l; ) e2 /= 2, t2 /= 2, n3 >>>= 1;
          return (e2 + n3) / t2;
        };
        return S.int32 = function() {
          return x.g(4) | 0;
        }, S.quick = function() {
          return x.g(4) / 4294967296;
        }, S.double = S, _(b(x.S), e), (a2.pass || u2 || function(e2, n3, r2, i2) {
          return i2 && (i2.S && m(i2, x), e2.state = function() {
            return m(x, {});
          }), r2 ? (t[o] = e2, n3) : e2;
        })(S, f2, `global` in a2 ? a2.global : this == t, a2.state);
      }
      t[`seed` + o] = f;
      function p(e2) {
        var t2, n2 = e2.length, i2 = this, a2 = 0, o2 = i2.i = i2.j = 0, s2 = i2.S = [];
        for (n2 || (e2 = [n2++]); a2 < r; ) s2[a2] = a2++;
        for (a2 = 0; a2 < r; a2++) s2[a2] = s2[o2 = u & o2 + e2[a2 % n2] + (t2 = s2[a2])], s2[o2] = t2;
        i2.g = function(e3) {
          for (var t3, n3 = 0, a3 = i2.i, o3 = i2.j, s3 = i2.S; e3--; ) t3 = s3[a3 = u & a3 + 1], n3 = n3 * r + s3[u & (s3[a3] = s3[o3 = u & o3 + t3]) + (s3[o3] = t3)];
          return i2.i = a3, i2.j = o3, n3;
        };
      }
      function m(e2, t2) {
        return t2.i = e2.i, t2.j = e2.j, t2.S = e2.S.slice(), t2;
      }
      function g(e2, t2) {
        var n2 = [], r2 = _typeof$2(e2), i2;
        if (t2 && r2 == `object`) for (i2 in e2) try {
          n2.push(g(e2[i2], t2 - 1));
        } catch {
        }
        return n2.length ? n2 : r2 == `string` ? e2 : e2 + `\0`;
      }
      function _(e2, t2) {
        for (var n2 = e2 + ``, r2, i2 = 0; i2 < n2.length; ) t2[u & i2] = u & (r2 ^= t2[u & i2] * 19) + n2.charCodeAt(i2++);
        return b(t2);
      }
      function y() {
        try {
          if (d) return b(d.randomBytes(r));
          var t2 = new Uint8Array(r);
          return (n.crypto || n.msCrypto).getRandomValues(t2), b(t2);
        } catch {
          var i2 = n.navigator, a2 = i2 && i2.plugins;
          return [+/* @__PURE__ */ new Date(), n, a2, n.screen, b(e)];
        }
      }
      function b(e2) {
        return String.fromCharCode.apply(0, e2);
      }
      _(t.random(), e);
    }
    function initialize$2(e) {
      seedRandom([], e);
    }
    var propTypes = { SHAPE: `shape` };
    function _typeof$1(e) {
      "@babel/helpers - typeof";
      return _typeof$1 = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e2) {
        return typeof e2;
      } : function(e2) {
        return e2 && typeof Symbol == `function` && e2.constructor === Symbol && e2 !== Symbol.prototype ? `symbol` : typeof e2;
      }, _typeof$1(e);
    }
    var ExpressionManager = (function() {
      var ob = {}, Math = BMMath, window = null, document = null, XMLHttpRequest = null, fetch = null, frames = null, _lottieGlobal = {};
      initialize$2(BMMath);
      function resetFrame() {
        _lottieGlobal = {};
      }
      function $bm_isInstanceOfArray(e) {
        return e.constructor === Array || e.constructor === Float32Array;
      }
      function isNumerable(e, t) {
        return e === `number` || t instanceof Number || e === `boolean` || e === `string`;
      }
      function $bm_neg(e) {
        var t = _typeof$1(e);
        if (t === `number` || e instanceof Number || t === `boolean`) return -e;
        if ($bm_isInstanceOfArray(e)) {
          var n, r = e.length, i = [];
          for (n = 0; n < r; n += 1) i[n] = -e[n];
          return i;
        }
        return e.propType ? e.v : -e;
      }
      var easeInBez = BezierFactory.getBezierEasing(0.333, 0, 0.833, 0.833, `easeIn`).get, easeOutBez = BezierFactory.getBezierEasing(0.167, 0.167, 0.667, 1, `easeOut`).get, easeInOutBez = BezierFactory.getBezierEasing(0.33, 0, 0.667, 1, `easeInOut`).get;
      function sum(e, t) {
        var n = _typeof$1(e), r = _typeof$1(t);
        if (isNumerable(n, e) && isNumerable(r, t) || n === `string` || r === `string`) return e + t;
        if ($bm_isInstanceOfArray(e) && isNumerable(r, t)) return e = e.slice(0), e[0] += t, e;
        if (isNumerable(n, e) && $bm_isInstanceOfArray(t)) return t = t.slice(0), t[0] = e + t[0], t;
        if ($bm_isInstanceOfArray(e) && $bm_isInstanceOfArray(t)) {
          for (var i = 0, a = e.length, o = t.length, s = []; i < a || i < o; ) (typeof e[i] == `number` || e[i] instanceof Number) && (typeof t[i] == `number` || t[i] instanceof Number) ? s[i] = e[i] + t[i] : s[i] = t[i] === void 0 ? e[i] : e[i] || t[i], i += 1;
          return s;
        }
        return 0;
      }
      var add = sum;
      function sub(e, t) {
        var n = _typeof$1(e), r = _typeof$1(t);
        if (isNumerable(n, e) && isNumerable(r, t)) return n === `string` && (e = parseInt(e, 10)), r === `string` && (t = parseInt(t, 10)), e - t;
        if ($bm_isInstanceOfArray(e) && isNumerable(r, t)) return e = e.slice(0), e[0] -= t, e;
        if (isNumerable(n, e) && $bm_isInstanceOfArray(t)) return t = t.slice(0), t[0] = e - t[0], t;
        if ($bm_isInstanceOfArray(e) && $bm_isInstanceOfArray(t)) {
          for (var i = 0, a = e.length, o = t.length, s = []; i < a || i < o; ) (typeof e[i] == `number` || e[i] instanceof Number) && (typeof t[i] == `number` || t[i] instanceof Number) ? s[i] = e[i] - t[i] : s[i] = t[i] === void 0 ? e[i] : e[i] || t[i], i += 1;
          return s;
        }
        return 0;
      }
      function mul(e, t) {
        var n = _typeof$1(e), r = _typeof$1(t), i;
        if (isNumerable(n, e) && isNumerable(r, t)) return e * t;
        var a, o;
        if ($bm_isInstanceOfArray(e) && isNumerable(r, t)) {
          for (o = e.length, i = createTypedArray(`float32`, o), a = 0; a < o; a += 1) i[a] = e[a] * t;
          return i;
        }
        if (isNumerable(n, e) && $bm_isInstanceOfArray(t)) {
          for (o = t.length, i = createTypedArray(`float32`, o), a = 0; a < o; a += 1) i[a] = e * t[a];
          return i;
        }
        return 0;
      }
      function div(e, t) {
        var n = _typeof$1(e), r = _typeof$1(t), i;
        if (isNumerable(n, e) && isNumerable(r, t)) return e / t;
        var a, o;
        if ($bm_isInstanceOfArray(e) && isNumerable(r, t)) {
          for (o = e.length, i = createTypedArray(`float32`, o), a = 0; a < o; a += 1) i[a] = e[a] / t;
          return i;
        }
        if (isNumerable(n, e) && $bm_isInstanceOfArray(t)) {
          for (o = t.length, i = createTypedArray(`float32`, o), a = 0; a < o; a += 1) i[a] = e / t[a];
          return i;
        }
        return 0;
      }
      function mod(e, t) {
        return typeof e == `string` && (e = parseInt(e, 10)), typeof t == `string` && (t = parseInt(t, 10)), e % t;
      }
      var $bm_sum = sum, $bm_sub = sub, $bm_mul = mul, $bm_div = div, $bm_mod = mod;
      function clamp(e, t, n) {
        if (t > n) {
          var r = n;
          n = t, t = r;
        }
        return Math.min(Math.max(e, t), n);
      }
      function radiansToDegrees(e) {
        return e / degToRads;
      }
      var radians_to_degrees = radiansToDegrees;
      function degreesToRadians(e) {
        return e * degToRads;
      }
      var degrees_to_radians = radiansToDegrees, helperLengthArray = [0, 0, 0, 0, 0, 0];
      function length(e, t) {
        if (typeof e == `number` || e instanceof Number) return t || (t = 0), Math.abs(e - t);
        t || (t = helperLengthArray);
        var n, r = Math.min(e.length, t.length), i = 0;
        for (n = 0; n < r; n += 1) i += Math.pow(t[n] - e[n], 2);
        return Math.sqrt(i);
      }
      function normalize(e) {
        return div(e, length(e));
      }
      function rgbToHsl(e) {
        var t = e[0], n = e[1], r = e[2], i = Math.max(t, n, r), a = Math.min(t, n, r), o, s, c = (i + a) / 2;
        if (i === a) o = 0, s = 0;
        else {
          var l = i - a;
          switch (s = c > 0.5 ? l / (2 - i - a) : l / (i + a), i) {
            case t:
              o = (n - r) / l + (n < r ? 6 : 0);
              break;
            case n:
              o = (r - t) / l + 2;
              break;
            case r:
              o = (t - n) / l + 4;
          }
          o /= 6;
        }
        return [o, s, c, e[3]];
      }
      function hue2rgb(e, t, n) {
        return n < 0 && (n += 1), n > 1 && --n, n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e;
      }
      function hslToRgb(e) {
        var t = e[0], n = e[1], r = e[2], i, a, o;
        if (n === 0) i = r, o = r, a = r;
        else {
          var s = r < 0.5 ? r * (1 + n) : r + n - r * n, c = 2 * r - s;
          i = hue2rgb(c, s, t + 1 / 3), a = hue2rgb(c, s, t), o = hue2rgb(c, s, t - 1 / 3);
        }
        return [i, a, o, e[3]];
      }
      function linear(e, t, n, r, i) {
        if ((r === void 0 || i === void 0) && (r = t, i = n, t = 0, n = 1), n < t) {
          var a = n;
          n = t, t = a;
        }
        if (e <= t) return r;
        if (e >= n) return i;
        var o = n === t ? 0 : (e - t) / (n - t);
        if (!r.length) return r + (i - r) * o;
        var s, c = r.length, l = createTypedArray(`float32`, c);
        for (s = 0; s < c; s += 1) l[s] = r[s] + (i[s] - r[s]) * o;
        return l;
      }
      function random(e, t) {
        if (t === void 0 && (e === void 0 ? (e = 0, t = 1) : (t = e, e = void 0)), t.length) {
          var n, r = t.length;
          e || (e = createTypedArray(`float32`, r));
          var i = createTypedArray(`float32`, r), a = BMMath.random();
          for (n = 0; n < r; n += 1) i[n] = e[n] + a * (t[n] - e[n]);
          return i;
        }
        e === void 0 && (e = 0);
        var o = BMMath.random();
        return e + o * (t - e);
      }
      function createPath(e, t, n, r) {
        var i, a = e.length, o = shapePool.newElement();
        o.setPathData(!!r, a);
        var s = [0, 0], c, l;
        for (i = 0; i < a; i += 1) c = t && t[i] ? t[i] : s, l = n && n[i] ? n[i] : s, o.setTripleAt(e[i][0], e[i][1], l[0] + e[i][0], l[1] + e[i][1], c[0] + e[i][0], c[1] + e[i][1], i, true);
        return o;
      }
      function initiateExpression(elem, data, property) {
        function noOp(e) {
          return e;
        }
        if (!elem.globalData.renderConfig.runExpressions) return noOp;
        var val = data.x, needsVelocity = /velocity(?![\w\d])/.test(val), _needsRandom = val.indexOf(`random`) !== -1, elemType = elem.data.ty, transform, $bm_transform, content, effect, thisProperty = property;
        thisProperty._name = elem.data.nm, thisProperty.valueAtTime = thisProperty.getValueAtTime, Object.defineProperty(thisProperty, "value", { get: function() {
          return thisProperty.v;
        } }), elem.comp.frameDuration = 1 / elem.comp.globalData.frameRate, elem.comp.displayStartTime = 0;
        var inPoint = elem.data.ip / elem.comp.globalData.frameRate, outPoint = elem.data.op / elem.comp.globalData.frameRate, width = elem.data.sw ? elem.data.sw : 0, height = elem.data.sh ? elem.data.sh : 0, name = elem.data.nm, loopIn, loop_in, loopOut, loop_out, smooth, toWorld, fromWorld, fromComp, toComp, fromCompToSurface, position, rotation, anchorPoint, scale, thisLayer, thisComp, mask, valueAtTime, velocityAtTime, scoped_bm_rt, expression_function = eval(`[function _expression_function(){` + val + `;scoped_bm_rt=$bm_rt}]`)[0], numKeys = property.kf ? data.k.length : 0, active = !this.data || this.data.hd !== true, wiggle = function(e, t) {
          var n, r, i = this.pv.length ? this.pv.length : 1, a = createTypedArray(`float32`, i);
          e = 5;
          var o = Math.floor(time * e);
          for (n = 0, r = 0; n < o; ) {
            for (r = 0; r < i; r += 1) a[r] += -t + t * 2 * BMMath.random();
            n += 1;
          }
          var s = time * e, c = s - Math.floor(s), l = createTypedArray(`float32`, i);
          if (i > 1) {
            for (r = 0; r < i; r += 1) l[r] = this.pv[r] + a[r] + (-t + t * 2 * BMMath.random()) * c;
            return l;
          }
          return this.pv + a[0] + (-t + t * 2 * BMMath.random()) * c;
        }.bind(this);
        thisProperty.loopIn && (loopIn = thisProperty.loopIn.bind(thisProperty), loop_in = loopIn), thisProperty.loopOut && (loopOut = thisProperty.loopOut.bind(thisProperty), loop_out = loopOut), thisProperty.smooth && (smooth = thisProperty.smooth.bind(thisProperty));
        function loopInDuration(e, t) {
          return loopIn(e, t, true);
        }
        function loopOutDuration(e, t) {
          return loopOut(e, t, true);
        }
        this.getValueAtTime && (valueAtTime = this.getValueAtTime.bind(this)), this.getVelocityAtTime && (velocityAtTime = this.getVelocityAtTime.bind(this));
        var comp = elem.comp.globalData.projectInterface.bind(elem.comp.globalData.projectInterface);
        function lookAt(e, t) {
          var n = [t[0] - e[0], t[1] - e[1], t[2] - e[2]], r = Math.atan2(n[0], Math.sqrt(n[1] * n[1] + n[2] * n[2])) / degToRads;
          return [-Math.atan2(n[1], n[2]) / degToRads, r, 0];
        }
        function easeOut(e, t, n, r, i) {
          return applyEase(easeOutBez, e, t, n, r, i);
        }
        function easeIn(e, t, n, r, i) {
          return applyEase(easeInBez, e, t, n, r, i);
        }
        function ease(e, t, n, r, i) {
          return applyEase(easeInOutBez, e, t, n, r, i);
        }
        function applyEase(e, t, n, r, i, a) {
          i === void 0 ? (i = n, a = r) : t = (t - n) / (r - n), t > 1 ? t = 1 : t < 0 && (t = 0);
          var o = e(t);
          if ($bm_isInstanceOfArray(i)) {
            var s, c = i.length, l = createTypedArray(`float32`, c);
            for (s = 0; s < c; s += 1) l[s] = (a[s] - i[s]) * o + i[s];
            return l;
          }
          return (a - i) * o + i;
        }
        function nearestKey(e) {
          var t, n = data.k.length, r, i;
          if (!data.k.length || typeof data.k[0] == `number`) r = 0, i = 0;
          else if (r = -1, e *= elem.comp.globalData.frameRate, e < data.k[0].t) r = 1, i = data.k[0].t;
          else {
            for (t = 0; t < n - 1; t += 1) if (e === data.k[t].t) {
              r = t + 1, i = data.k[t].t;
              break;
            } else if (e > data.k[t].t && e < data.k[t + 1].t) {
              e - data.k[t].t > data.k[t + 1].t - e ? (r = t + 2, i = data.k[t + 1].t) : (r = t + 1, i = data.k[t].t);
              break;
            }
            r === -1 && (r = t + 1, i = data.k[t].t);
          }
          var a = {};
          return a.index = r, a.time = i / elem.comp.globalData.frameRate, a;
        }
        function key(e) {
          var t, n, r;
          if (!data.k.length || typeof data.k[0] == `number`) throw Error(`The property has no keyframe at index ` + e);
          --e, t = { time: data.k[e].t / elem.comp.globalData.frameRate, value: [] };
          var i = Object.prototype.hasOwnProperty.call(data.k[e], `s`) ? data.k[e].s : data.k[e - 1].e;
          for (r = i.length, n = 0; n < r; n += 1) t[n] = i[n], t.value[n] = i[n];
          return t;
        }
        function framesToTime(e, t) {
          return t || (t = elem.comp.globalData.frameRate), e / t;
        }
        function timeToFrames(e, t) {
          return !e && e !== 0 && (e = time), t || (t = elem.comp.globalData.frameRate), e * t;
        }
        function seedRandom(e) {
          BMMath.seedrandom(randSeed + e);
        }
        function sourceRectAtTime() {
          return elem.sourceRectAtTime();
        }
        function substring(e, t) {
          return typeof value == `string` ? t === void 0 ? value.substring(e) : value.substring(e, t) : ``;
        }
        function substr(e, t) {
          return typeof value == `string` ? t === void 0 ? value.substr(e) : value.substr(e, t) : ``;
        }
        function posterizeTime(e) {
          time = e === 0 ? 0 : Math.floor(time * e) / e, value = valueAtTime(time);
        }
        var time, velocity, value, text, textIndex, textTotal, selectorValue, index = elem.data.ind, hasParent = !!(elem.hierarchy && elem.hierarchy.length), parent, randSeed = Math.floor(Math.random() * 1e6), globalData = elem.globalData;
        function executeExpression(e) {
          return value = e, this.frameExpressionId === elem.globalData.frameId && this.propType !== `textSelector` ? value : (this.propType === `textSelector` && (textIndex = this.textIndex, textTotal = this.textTotal, selectorValue = this.selectorValue), thisLayer || (text = elem.layerInterface.text, thisLayer = elem.layerInterface, thisComp = elem.comp.compInterface, toWorld = thisLayer.toWorld.bind(thisLayer), fromWorld = thisLayer.fromWorld.bind(thisLayer), fromComp = thisLayer.fromComp.bind(thisLayer), toComp = thisLayer.toComp.bind(thisLayer), mask = thisLayer.mask ? thisLayer.mask.bind(thisLayer) : null, fromCompToSurface = fromComp), transform || (transform = elem.layerInterface(`ADBE Transform Group`), $bm_transform = transform, transform && (anchorPoint = transform.anchorPoint)), elemType === 4 && !content && (content = thisLayer(`ADBE Root Vectors Group`)), effect || (effect = thisLayer(4)), hasParent = !!(elem.hierarchy && elem.hierarchy.length), hasParent && !parent && (parent = elem.hierarchy[0].layerInterface), time = this.comp.renderedFrame / this.comp.globalData.frameRate, _needsRandom && seedRandom(randSeed + time), needsVelocity && (velocity = velocityAtTime(time)), expression_function(), this.frameExpressionId = elem.globalData.frameId, scoped_bm_rt = scoped_bm_rt.propType === propTypes.SHAPE ? scoped_bm_rt.v : scoped_bm_rt, scoped_bm_rt);
        }
        return executeExpression.__preventDeadCodeRemoval = [$bm_transform, anchorPoint, time, velocity, inPoint, outPoint, width, height, name, loop_in, loop_out, smooth, toComp, fromCompToSurface, toWorld, fromWorld, mask, position, rotation, scale, thisComp, numKeys, active, wiggle, loopInDuration, loopOutDuration, comp, lookAt, easeOut, easeIn, ease, nearestKey, key, text, textIndex, textTotal, selectorValue, framesToTime, timeToFrames, sourceRectAtTime, substring, substr, posterizeTime, index, globalData], executeExpression;
      }
      return ob.initiateExpression = initiateExpression, ob.__preventDeadCodeRemoval = [window, document, XMLHttpRequest, fetch, frames, $bm_neg, add, $bm_sum, $bm_sub, $bm_mul, $bm_div, $bm_mod, clamp, radians_to_degrees, degreesToRadians, degrees_to_radians, normalize, rgbToHsl, hslToRgb, linear, random, createPath, _lottieGlobal], ob.resetFrame = resetFrame, ob;
    })(), Expressions = (function() {
      var e = {};
      e.initExpressions = t, e.resetFrame = ExpressionManager.resetFrame;
      function t(e2) {
        var t2 = 0, n = [];
        function r() {
          t2 += 1;
        }
        function i() {
          --t2, t2 === 0 && o();
        }
        function a(e3) {
          n.indexOf(e3) === -1 && n.push(e3);
        }
        function o() {
          var e3, t3 = n.length;
          for (e3 = 0; e3 < t3; e3 += 1) n[e3].release();
          n.length = 0;
        }
        e2.renderer.compInterface = CompExpressionInterface(e2.renderer), e2.renderer.globalData.projectInterface.registerComposition(e2.renderer), e2.renderer.globalData.pushExpression = r, e2.renderer.globalData.popExpression = i, e2.renderer.globalData.registerExpressionProperty = a;
      }
      return e;
    })(), MaskManagerInterface = (function() {
      function e(e2, t) {
        this._mask = e2, this._data = t;
      }
      return Object.defineProperty(e.prototype, "maskPath", { get: function() {
        return this._mask.prop.k && this._mask.prop.getValue(), this._mask.prop;
      } }), Object.defineProperty(e.prototype, "maskOpacity", { get: function() {
        return this._mask.op.k && this._mask.op.getValue(), this._mask.op.v * 100;
      } }), function(t) {
        var n = createSizedArray(t.viewData.length), r, i = t.viewData.length;
        for (r = 0; r < i; r += 1) n[r] = new e(t.viewData[r], t.masksProperties[r]);
        return function(e2) {
          for (r = 0; r < i; ) {
            if (t.masksProperties[r].nm === e2) return n[r];
            r += 1;
          }
          return null;
        };
      };
    })(), ExpressionPropertyInterface = /* @__PURE__ */ (function() {
      var e = { pv: 0, v: 0, mult: 1 }, t = { pv: [0, 0, 0], v: [0, 0, 0], mult: 1 };
      function n(e2, t2, n2) {
        Object.defineProperty(e2, "velocity", { get: function() {
          return t2.getVelocityAtTime(t2.comp.currentFrame);
        } }), e2.numKeys = t2.keyframes ? t2.keyframes.length : 0, e2.key = function(r2) {
          if (!e2.numKeys) return 0;
          var i2 = ``;
          i2 = `s` in t2.keyframes[r2 - 1] ? t2.keyframes[r2 - 1].s : `e` in t2.keyframes[r2 - 2] ? t2.keyframes[r2 - 2].e : t2.keyframes[r2 - 2].s;
          var a2 = n2 === `unidimensional` ? new Number(i2) : Object.assign({}, i2);
          return a2.time = t2.keyframes[r2 - 1].t / t2.elem.comp.globalData.frameRate, a2.value = n2 === `unidimensional` ? i2[0] : i2, a2;
        }, e2.valueAtTime = t2.getValueAtTime, e2.speedAtTime = t2.getSpeedAtTime, e2.velocityAtTime = t2.getVelocityAtTime, e2.propertyGroup = t2.propertyGroup;
      }
      function r(t2) {
        (!t2 || !(`pv` in t2)) && (t2 = e);
        var r2 = 1 / t2.mult, i2 = t2.pv * r2, a2 = new Number(i2);
        return a2.value = i2, n(a2, t2, `unidimensional`), function() {
          return t2.k && t2.getValue(), i2 = t2.v * r2, a2.value !== i2 && (a2 = new Number(i2), a2.value = i2, a2[0] = i2, n(a2, t2, `unidimensional`)), a2;
        };
      }
      function i(e2) {
        (!e2 || !(`pv` in e2)) && (e2 = t);
        var r2 = 1 / e2.mult, i2 = e2.data && e2.data.l || e2.pv.length, a2 = createTypedArray(`float32`, i2), o = createTypedArray(`float32`, i2);
        return a2.value = o, n(a2, e2, `multidimensional`), function() {
          e2.k && e2.getValue();
          for (var t2 = 0; t2 < i2; t2 += 1) o[t2] = e2.v[t2] * r2, a2[t2] = o[t2];
          return a2;
        };
      }
      function a() {
        return e;
      }
      return function(e2) {
        return e2 ? e2.propType === `unidimensional` ? r(e2) : i(e2) : a;
      };
    })(), TransformExpressionInterface = /* @__PURE__ */ (function() {
      return function(e) {
        function t(e2) {
          switch (e2) {
            case `scale`:
            case `Scale`:
            case `ADBE Scale`:
            case 6:
              return t.scale;
            case `rotation`:
            case `Rotation`:
            case `ADBE Rotation`:
            case `ADBE Rotate Z`:
            case 10:
              return t.rotation;
            case `ADBE Rotate X`:
              return t.xRotation;
            case `ADBE Rotate Y`:
              return t.yRotation;
            case `position`:
            case `Position`:
            case `ADBE Position`:
            case 2:
              return t.position;
            case `ADBE Position_0`:
              return t.xPosition;
            case `ADBE Position_1`:
              return t.yPosition;
            case `ADBE Position_2`:
              return t.zPosition;
            case `anchorPoint`:
            case `AnchorPoint`:
            case `Anchor Point`:
            case `ADBE AnchorPoint`:
            case 1:
              return t.anchorPoint;
            case `opacity`:
            case `Opacity`:
            case 11:
              return t.opacity;
            default:
              return null;
          }
        }
        Object.defineProperty(t, "rotation", { get: ExpressionPropertyInterface(e.r || e.rz) }), Object.defineProperty(t, "zRotation", { get: ExpressionPropertyInterface(e.rz || e.r) }), Object.defineProperty(t, "xRotation", { get: ExpressionPropertyInterface(e.rx) }), Object.defineProperty(t, "yRotation", { get: ExpressionPropertyInterface(e.ry) }), Object.defineProperty(t, "scale", { get: ExpressionPropertyInterface(e.s) });
        var n, r, i, a;
        return e.p ? a = ExpressionPropertyInterface(e.p) : (n = ExpressionPropertyInterface(e.px), r = ExpressionPropertyInterface(e.py), e.pz && (i = ExpressionPropertyInterface(e.pz))), Object.defineProperty(t, "position", { get: function() {
          return e.p ? a() : [n(), r(), i ? i() : 0];
        } }), Object.defineProperty(t, "xPosition", { get: ExpressionPropertyInterface(e.px) }), Object.defineProperty(t, "yPosition", { get: ExpressionPropertyInterface(e.py) }), Object.defineProperty(t, "zPosition", { get: ExpressionPropertyInterface(e.pz) }), Object.defineProperty(t, "anchorPoint", { get: ExpressionPropertyInterface(e.a) }), Object.defineProperty(t, "opacity", { get: ExpressionPropertyInterface(e.o) }), Object.defineProperty(t, "skew", { get: ExpressionPropertyInterface(e.sk) }), Object.defineProperty(t, "skewAxis", { get: ExpressionPropertyInterface(e.sa) }), Object.defineProperty(t, "orientation", { get: ExpressionPropertyInterface(e.or) }), t;
      };
    })(), LayerExpressionInterface = /* @__PURE__ */ (function() {
      function e(e2) {
        var t2 = new Matrix();
        return e2 === void 0 ? this._elem.finalTransform.mProp.applyToMatrix(t2) : this._elem.finalTransform.mProp.getValueAtTime(e2).clone(t2), t2;
      }
      function t(e2, t2) {
        var n2 = this.getMatrix(t2);
        return n2.props[12] = 0, n2.props[13] = 0, n2.props[14] = 0, this.applyPoint(n2, e2);
      }
      function n(e2, t2) {
        var n2 = this.getMatrix(t2);
        return this.applyPoint(n2, e2);
      }
      function r(e2, t2) {
        var n2 = this.getMatrix(t2);
        return n2.props[12] = 0, n2.props[13] = 0, n2.props[14] = 0, this.invertPoint(n2, e2);
      }
      function i(e2, t2) {
        var n2 = this.getMatrix(t2);
        return this.invertPoint(n2, e2);
      }
      function a(e2, t2) {
        if (this._elem.hierarchy && this._elem.hierarchy.length) {
          var n2, r2 = this._elem.hierarchy.length;
          for (n2 = 0; n2 < r2; n2 += 1) this._elem.hierarchy[n2].finalTransform.mProp.applyToMatrix(e2);
        }
        return e2.applyToPointArray(t2[0], t2[1], t2[2] || 0);
      }
      function o(e2, t2) {
        if (this._elem.hierarchy && this._elem.hierarchy.length) {
          var n2, r2 = this._elem.hierarchy.length;
          for (n2 = 0; n2 < r2; n2 += 1) this._elem.hierarchy[n2].finalTransform.mProp.applyToMatrix(e2);
        }
        return e2.inversePoint(t2);
      }
      function s(e2) {
        var t2 = new Matrix();
        if (t2.reset(), this._elem.finalTransform.mProp.applyToMatrix(t2), this._elem.hierarchy && this._elem.hierarchy.length) {
          var n2, r2 = this._elem.hierarchy.length;
          for (n2 = 0; n2 < r2; n2 += 1) this._elem.hierarchy[n2].finalTransform.mProp.applyToMatrix(t2);
          return t2.inversePoint(e2);
        }
        return t2.inversePoint(e2);
      }
      function c() {
        return [1, 1, 1, 1];
      }
      return function(l) {
        var u;
        function d(e2) {
          p.mask = new MaskManagerInterface(e2, l);
        }
        function f(e2) {
          p.effect = e2;
        }
        function p(e2) {
          switch (e2) {
            case `ADBE Root Vectors Group`:
            case `Contents`:
            case 2:
              return p.shapeInterface;
            case 1:
            case 6:
            case `Transform`:
            case `transform`:
            case `ADBE Transform Group`:
              return u;
            case 4:
            case `ADBE Effect Parade`:
            case `effects`:
            case `Effects`:
              return p.effect;
            case `ADBE Text Properties`:
              return p.textInterface;
            default:
              return null;
          }
        }
        p.getMatrix = e, p.invertPoint = o, p.applyPoint = a, p.toWorld = n, p.toWorldVec = t, p.fromWorld = i, p.fromWorldVec = r, p.toComp = n, p.fromComp = s, p.sampleImage = c, p.sourceRectAtTime = l.sourceRectAtTime.bind(l), p._elem = l, u = TransformExpressionInterface(l.finalTransform.mProp);
        var m = getDescriptor(u, `anchorPoint`);
        return Object.defineProperties(p, { hasParent: { get: function() {
          return l.hierarchy.length;
        } }, parent: { get: function() {
          return l.hierarchy[0].layerInterface;
        } }, rotation: getDescriptor(u, `rotation`), scale: getDescriptor(u, `scale`), position: getDescriptor(u, `position`), opacity: getDescriptor(u, `opacity`), anchorPoint: m, anchor_point: m, transform: { get: function() {
          return u;
        } }, active: { get: function() {
          return l.isInRange;
        } } }), p.startTime = l.data.st, p.index = l.data.ind, p.source = l.data.refId, p.height = l.data.ty === 0 ? l.data.h : 100, p.width = l.data.ty === 0 ? l.data.w : 100, p.inPoint = l.data.ip / l.comp.globalData.frameRate, p.outPoint = l.data.op / l.comp.globalData.frameRate, p._name = l.data.nm, p.registerMaskInterface = d, p.registerEffectsInterface = f, p;
      };
    })(), propertyGroupFactory = /* @__PURE__ */ (function() {
      return function(e, t) {
        return function(n) {
          return n = n === void 0 ? 1 : n, n <= 0 ? e : t(n - 1);
        };
      };
    })(), PropertyInterface = /* @__PURE__ */ (function() {
      return function(e, t) {
        var n = { _name: e };
        function r(e2) {
          return e2 = e2 === void 0 ? 1 : e2, e2 <= 0 ? n : t(e2 - 1);
        }
        return r;
      };
    })(), EffectsExpressionInterface = /* @__PURE__ */ (function() {
      var e = { createEffectsInterface: t };
      function t(e2, t2) {
        if (e2.effectsManager) {
          var r2 = [], i = e2.data.ef, a, o = e2.effectsManager.effectElements.length;
          for (a = 0; a < o; a += 1) r2.push(n(i[a], e2.effectsManager.effectElements[a], t2, e2));
          var s = e2.data.ef || [], c = function(e3) {
            for (a = 0, o = s.length; a < o; ) {
              if (e3 === s[a].nm || e3 === s[a].mn || e3 === s[a].ix) return r2[a];
              a += 1;
            }
            return null;
          };
          return Object.defineProperty(c, "numProperties", { get: function() {
            return s.length;
          } }), c;
        }
        return null;
      }
      function n(e2, t2, i, a) {
        function o(t3) {
          for (var n2 = e2.ef, r2 = 0, i2 = n2.length; r2 < i2; ) {
            if (t3 === n2[r2].nm || t3 === n2[r2].mn || t3 === n2[r2].ix) return n2[r2].ty === 5 ? c[r2] : c[r2]();
            r2 += 1;
          }
          throw Error();
        }
        var s = propertyGroupFactory(o, i), c = [], l, u = e2.ef.length;
        for (l = 0; l < u; l += 1) e2.ef[l].ty === 5 ? c.push(n(e2.ef[l], t2.effectElements[l], t2.effectElements[l].propertyGroup, a)) : c.push(r(t2.effectElements[l], e2.ef[l].ty, a, s));
        return e2.mn === `ADBE Color Control` && Object.defineProperty(o, "color", { get: function() {
          return c[0]();
        } }), Object.defineProperties(o, { numProperties: { get: function() {
          return e2.np;
        } }, _name: { value: e2.nm }, propertyGroup: { value: s } }), o.enabled = e2.en !== 0, o.active = o.enabled, o;
      }
      function r(e2, t2, n2, r2) {
        var i = ExpressionPropertyInterface(e2.p);
        function a() {
          return t2 === 10 ? n2.comp.compInterface(e2.p.v) : i();
        }
        return e2.p.setGroupProperty && e2.p.setGroupProperty(PropertyInterface(``, r2)), a;
      }
      return e;
    })(), ShapePathInterface = /* @__PURE__ */ (function() {
      return function(e, t, n) {
        var r = t.sh;
        function i(e2) {
          return e2 === `Shape` || e2 === `shape` || e2 === `Path` || e2 === `path` || e2 === `ADBE Vector Shape` || e2 === 2 ? i.path : null;
        }
        var a = propertyGroupFactory(i, n);
        return r.setGroupProperty(PropertyInterface(`Path`, a)), Object.defineProperties(i, { path: { get: function() {
          return r.k && r.getValue(), r;
        } }, shape: { get: function() {
          return r.k && r.getValue(), r;
        } }, _name: { value: e.nm }, ix: { value: e.ix }, propertyIndex: { value: e.ix }, mn: { value: e.mn }, propertyGroup: { value: n } }), i;
      };
    })(), ShapeExpressionInterface = /* @__PURE__ */ (function() {
      function e(e2, t2, c2) {
        var m = [], g, _ = e2 ? e2.length : 0;
        for (g = 0; g < _; g += 1) e2[g].ty === `gr` ? m.push(n(e2[g], t2[g], c2)) : e2[g].ty === `fl` ? m.push(r(e2[g], t2[g], c2)) : e2[g].ty === `st` ? m.push(o(e2[g], t2[g], c2)) : e2[g].ty === `tm` ? m.push(s(e2[g], t2[g], c2)) : e2[g].ty === `tr` || (e2[g].ty === `el` ? m.push(l(e2[g], t2[g], c2)) : e2[g].ty === `sr` ? m.push(u(e2[g], t2[g], c2)) : e2[g].ty === `sh` ? m.push(ShapePathInterface(e2[g], t2[g], c2)) : e2[g].ty === `rc` ? m.push(d(e2[g], t2[g], c2)) : e2[g].ty === `rd` ? m.push(f(e2[g], t2[g], c2)) : e2[g].ty === `rp` ? m.push(p(e2[g], t2[g], c2)) : e2[g].ty === `gf` ? m.push(i(e2[g], t2[g], c2)) : m.push(a(e2[g], t2[g], c2)));
        return m;
      }
      function t(t2, n2, r2) {
        var i2, a2 = function(e2) {
          for (var t3 = 0, n3 = i2.length; t3 < n3; ) {
            if (i2[t3]._name === e2 || i2[t3].mn === e2 || i2[t3].propertyIndex === e2 || i2[t3].ix === e2 || i2[t3].ind === e2) return i2[t3];
            t3 += 1;
          }
          return typeof e2 == `number` ? i2[e2 - 1] : null;
        };
        return a2.propertyGroup = propertyGroupFactory(a2, r2), i2 = e(t2.it, n2.it, a2.propertyGroup), a2.numProperties = i2.length, a2.transform = c(t2.it[t2.it.length - 1], n2.it[n2.it.length - 1], a2.propertyGroup), a2.propertyIndex = t2.cix, a2._name = t2.nm, a2;
      }
      function n(e2, n2, r2) {
        var i2 = function(e3) {
          switch (e3) {
            case `ADBE Vectors Group`:
            case `Contents`:
            case 2:
              return i2.content;
            default:
              return i2.transform;
          }
        };
        i2.propertyGroup = propertyGroupFactory(i2, r2);
        var a2 = t(e2, n2, i2.propertyGroup), o2 = c(e2.it[e2.it.length - 1], n2.it[n2.it.length - 1], i2.propertyGroup);
        return i2.content = a2, i2.transform = o2, Object.defineProperty(i2, "_name", { get: function() {
          return e2.nm;
        } }), i2.numProperties = e2.np, i2.propertyIndex = e2.ix, i2.nm = e2.nm, i2.mn = e2.mn, i2;
      }
      function r(e2, t2, n2) {
        function r2(e3) {
          return e3 === `Color` || e3 === `color` ? r2.color : e3 === `Opacity` || e3 === `opacity` ? r2.opacity : null;
        }
        return Object.defineProperties(r2, { color: { get: ExpressionPropertyInterface(t2.c) }, opacity: { get: ExpressionPropertyInterface(t2.o) }, _name: { value: e2.nm }, mn: { value: e2.mn } }), t2.c.setGroupProperty(PropertyInterface(`Color`, n2)), t2.o.setGroupProperty(PropertyInterface(`Opacity`, n2)), r2;
      }
      function i(e2, t2, n2) {
        function r2(e3) {
          return e3 === `Start Point` || e3 === `start point` ? r2.startPoint : e3 === `End Point` || e3 === `end point` ? r2.endPoint : e3 === `Opacity` || e3 === `opacity` ? r2.opacity : null;
        }
        return Object.defineProperties(r2, { startPoint: { get: ExpressionPropertyInterface(t2.s) }, endPoint: { get: ExpressionPropertyInterface(t2.e) }, opacity: { get: ExpressionPropertyInterface(t2.o) }, type: { get: function() {
          return `a`;
        } }, _name: { value: e2.nm }, mn: { value: e2.mn } }), t2.s.setGroupProperty(PropertyInterface(`Start Point`, n2)), t2.e.setGroupProperty(PropertyInterface(`End Point`, n2)), t2.o.setGroupProperty(PropertyInterface(`Opacity`, n2)), r2;
      }
      function a() {
        function e2() {
          return null;
        }
        return e2;
      }
      function o(e2, t2, n2) {
        var r2 = propertyGroupFactory(l2, n2), i2 = propertyGroupFactory(c2, r2);
        function a2(n3) {
          Object.defineProperty(c2, e2.d[n3].nm, { get: ExpressionPropertyInterface(t2.d.dataProps[n3].p) });
        }
        var o2, s2 = e2.d ? e2.d.length : 0, c2 = {};
        for (o2 = 0; o2 < s2; o2 += 1) a2(o2), t2.d.dataProps[o2].p.setGroupProperty(i2);
        function l2(e3) {
          return e3 === `Color` || e3 === `color` ? l2.color : e3 === `Opacity` || e3 === `opacity` ? l2.opacity : e3 === `Stroke Width` || e3 === `stroke width` ? l2.strokeWidth : null;
        }
        return Object.defineProperties(l2, { color: { get: ExpressionPropertyInterface(t2.c) }, opacity: { get: ExpressionPropertyInterface(t2.o) }, strokeWidth: { get: ExpressionPropertyInterface(t2.w) }, dash: { get: function() {
          return c2;
        } }, _name: { value: e2.nm }, mn: { value: e2.mn } }), t2.c.setGroupProperty(PropertyInterface(`Color`, r2)), t2.o.setGroupProperty(PropertyInterface(`Opacity`, r2)), t2.w.setGroupProperty(PropertyInterface(`Stroke Width`, r2)), l2;
      }
      function s(e2, t2, n2) {
        function r2(t3) {
          return t3 === e2.e.ix || t3 === `End` || t3 === `end` ? r2.end : t3 === e2.s.ix ? r2.start : t3 === e2.o.ix ? r2.offset : null;
        }
        var i2 = propertyGroupFactory(r2, n2);
        return r2.propertyIndex = e2.ix, t2.s.setGroupProperty(PropertyInterface(`Start`, i2)), t2.e.setGroupProperty(PropertyInterface(`End`, i2)), t2.o.setGroupProperty(PropertyInterface(`Offset`, i2)), r2.propertyIndex = e2.ix, r2.propertyGroup = n2, Object.defineProperties(r2, { start: { get: ExpressionPropertyInterface(t2.s) }, end: { get: ExpressionPropertyInterface(t2.e) }, offset: { get: ExpressionPropertyInterface(t2.o) }, _name: { value: e2.nm } }), r2.mn = e2.mn, r2;
      }
      function c(e2, t2, n2) {
        function r2(t3) {
          return e2.a.ix === t3 || t3 === `Anchor Point` ? r2.anchorPoint : e2.o.ix === t3 || t3 === `Opacity` ? r2.opacity : e2.p.ix === t3 || t3 === `Position` ? r2.position : e2.r.ix === t3 || t3 === `Rotation` || t3 === `ADBE Vector Rotation` ? r2.rotation : e2.s.ix === t3 || t3 === `Scale` ? r2.scale : e2.sk && e2.sk.ix === t3 || t3 === `Skew` ? r2.skew : e2.sa && e2.sa.ix === t3 || t3 === `Skew Axis` ? r2.skewAxis : null;
        }
        var i2 = propertyGroupFactory(r2, n2);
        return t2.transform.mProps.o.setGroupProperty(PropertyInterface(`Opacity`, i2)), t2.transform.mProps.p.setGroupProperty(PropertyInterface(`Position`, i2)), t2.transform.mProps.a.setGroupProperty(PropertyInterface(`Anchor Point`, i2)), t2.transform.mProps.s.setGroupProperty(PropertyInterface(`Scale`, i2)), t2.transform.mProps.r.setGroupProperty(PropertyInterface(`Rotation`, i2)), t2.transform.mProps.sk && (t2.transform.mProps.sk.setGroupProperty(PropertyInterface(`Skew`, i2)), t2.transform.mProps.sa.setGroupProperty(PropertyInterface(`Skew Angle`, i2))), t2.transform.op.setGroupProperty(PropertyInterface(`Opacity`, i2)), Object.defineProperties(r2, { opacity: { get: ExpressionPropertyInterface(t2.transform.mProps.o) }, position: { get: ExpressionPropertyInterface(t2.transform.mProps.p) }, anchorPoint: { get: ExpressionPropertyInterface(t2.transform.mProps.a) }, scale: { get: ExpressionPropertyInterface(t2.transform.mProps.s) }, rotation: { get: ExpressionPropertyInterface(t2.transform.mProps.r) }, skew: { get: ExpressionPropertyInterface(t2.transform.mProps.sk) }, skewAxis: { get: ExpressionPropertyInterface(t2.transform.mProps.sa) }, _name: { value: e2.nm } }), r2.ty = `tr`, r2.mn = e2.mn, r2.propertyGroup = n2, r2;
      }
      function l(e2, t2, n2) {
        function r2(t3) {
          return e2.p.ix === t3 ? r2.position : e2.s.ix === t3 ? r2.size : null;
        }
        var i2 = propertyGroupFactory(r2, n2);
        r2.propertyIndex = e2.ix;
        var a2 = t2.sh.ty === `tm` ? t2.sh.prop : t2.sh;
        return a2.s.setGroupProperty(PropertyInterface(`Size`, i2)), a2.p.setGroupProperty(PropertyInterface(`Position`, i2)), Object.defineProperties(r2, { size: { get: ExpressionPropertyInterface(a2.s) }, position: { get: ExpressionPropertyInterface(a2.p) }, _name: { value: e2.nm } }), r2.mn = e2.mn, r2;
      }
      function u(e2, t2, n2) {
        function r2(t3) {
          return e2.p.ix === t3 ? r2.position : e2.r.ix === t3 ? r2.rotation : e2.pt.ix === t3 ? r2.points : e2.or.ix === t3 || t3 === `ADBE Vector Star Outer Radius` ? r2.outerRadius : e2.os.ix === t3 ? r2.outerRoundness : e2.ir && (e2.ir.ix === t3 || t3 === `ADBE Vector Star Inner Radius`) ? r2.innerRadius : e2.is && e2.is.ix === t3 ? r2.innerRoundness : null;
        }
        var i2 = propertyGroupFactory(r2, n2), a2 = t2.sh.ty === `tm` ? t2.sh.prop : t2.sh;
        return r2.propertyIndex = e2.ix, a2.or.setGroupProperty(PropertyInterface(`Outer Radius`, i2)), a2.os.setGroupProperty(PropertyInterface(`Outer Roundness`, i2)), a2.pt.setGroupProperty(PropertyInterface(`Points`, i2)), a2.p.setGroupProperty(PropertyInterface(`Position`, i2)), a2.r.setGroupProperty(PropertyInterface(`Rotation`, i2)), e2.ir && (a2.ir.setGroupProperty(PropertyInterface(`Inner Radius`, i2)), a2.is.setGroupProperty(PropertyInterface(`Inner Roundness`, i2))), Object.defineProperties(r2, { position: { get: ExpressionPropertyInterface(a2.p) }, rotation: { get: ExpressionPropertyInterface(a2.r) }, points: { get: ExpressionPropertyInterface(a2.pt) }, outerRadius: { get: ExpressionPropertyInterface(a2.or) }, outerRoundness: { get: ExpressionPropertyInterface(a2.os) }, innerRadius: { get: ExpressionPropertyInterface(a2.ir) }, innerRoundness: { get: ExpressionPropertyInterface(a2.is) }, _name: { value: e2.nm } }), r2.mn = e2.mn, r2;
      }
      function d(e2, t2, n2) {
        function r2(t3) {
          return e2.p.ix === t3 ? r2.position : e2.r.ix === t3 ? r2.roundness : e2.s.ix === t3 || t3 === `Size` || t3 === `ADBE Vector Rect Size` ? r2.size : null;
        }
        var i2 = propertyGroupFactory(r2, n2), a2 = t2.sh.ty === `tm` ? t2.sh.prop : t2.sh;
        return r2.propertyIndex = e2.ix, a2.p.setGroupProperty(PropertyInterface(`Position`, i2)), a2.s.setGroupProperty(PropertyInterface(`Size`, i2)), a2.r.setGroupProperty(PropertyInterface(`Rotation`, i2)), Object.defineProperties(r2, { position: { get: ExpressionPropertyInterface(a2.p) }, roundness: { get: ExpressionPropertyInterface(a2.r) }, size: { get: ExpressionPropertyInterface(a2.s) }, _name: { value: e2.nm } }), r2.mn = e2.mn, r2;
      }
      function f(e2, t2, n2) {
        function r2(t3) {
          return e2.r.ix === t3 || t3 === `Round Corners 1` ? r2.radius : null;
        }
        var i2 = propertyGroupFactory(r2, n2), a2 = t2;
        return r2.propertyIndex = e2.ix, a2.rd.setGroupProperty(PropertyInterface(`Radius`, i2)), Object.defineProperties(r2, { radius: { get: ExpressionPropertyInterface(a2.rd) }, _name: { value: e2.nm } }), r2.mn = e2.mn, r2;
      }
      function p(e2, t2, n2) {
        function r2(t3) {
          return e2.c.ix === t3 || t3 === `Copies` ? r2.copies : e2.o.ix === t3 || t3 === `Offset` ? r2.offset : null;
        }
        var i2 = propertyGroupFactory(r2, n2), a2 = t2;
        return r2.propertyIndex = e2.ix, a2.c.setGroupProperty(PropertyInterface(`Copies`, i2)), a2.o.setGroupProperty(PropertyInterface(`Offset`, i2)), Object.defineProperties(r2, { copies: { get: ExpressionPropertyInterface(a2.c) }, offset: { get: ExpressionPropertyInterface(a2.o) }, _name: { value: e2.nm } }), r2.mn = e2.mn, r2;
      }
      return function(t2, n2, r2) {
        var i2;
        function a2(e2) {
          if (typeof e2 == `number`) return e2 = e2 === void 0 ? 1 : e2, e2 === 0 ? r2 : i2[e2 - 1];
          for (var t3 = 0, n3 = i2.length; t3 < n3; ) {
            if (i2[t3]._name === e2) return i2[t3];
            t3 += 1;
          }
          return null;
        }
        function o2() {
          return r2;
        }
        return a2.propertyGroup = propertyGroupFactory(a2, o2), i2 = e(t2, n2, a2.propertyGroup), a2.numProperties = i2.length, a2._name = `Contents`, a2;
      };
    })(), TextExpressionInterface = /* @__PURE__ */ (function() {
      return function(e) {
        var t;
        function n(e2) {
          switch (e2) {
            case `ADBE Text Document`:
              return n.sourceText;
            default:
              return null;
          }
        }
        return Object.defineProperty(n, "sourceText", { get: function() {
          e.textProperty.getValue();
          var n2 = e.textProperty.currentData.t;
          return (!t || n2 !== t.value) && (t = new String(n2), t.value = n2 || new String(n2), Object.defineProperty(t, "style", { get: function() {
            return { fillColor: e.textProperty.currentData.fc };
          } })), t;
        } }), n;
      };
    })();
    function _typeof(e) {
      "@babel/helpers - typeof";
      return _typeof = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e2) {
        return typeof e2;
      } : function(e2) {
        return e2 && typeof Symbol == `function` && e2.constructor === Symbol && e2 !== Symbol.prototype ? `symbol` : typeof e2;
      }, _typeof(e);
    }
    var FootageInterface = /* @__PURE__ */ (function() {
      var e = function(e2) {
        var t2 = ``, n = e2.getFootageData();
        function r() {
          return t2 = ``, n = e2.getFootageData(), i;
        }
        function i(e3) {
          if (n[e3]) return t2 = e3, n = n[e3], _typeof(n) === `object` ? i : n;
          var r2 = e3.indexOf(t2);
          if (r2 !== -1) {
            var a = parseInt(e3.substr(r2 + t2.length), 10);
            return n = n[a], _typeof(n) === `object` ? i : n;
          }
          return ``;
        }
        return r;
      }, t = function(t2) {
        function n(e2) {
          return e2 === `Outline` ? n.outlineInterface() : null;
        }
        return n._name = `Outline`, n.outlineInterface = e(t2), n;
      };
      return function(e2) {
        function n(e3) {
          return e3 === `Data` ? n.dataInterface : null;
        }
        return n._name = `Data`, n.dataInterface = t(e2), n;
      };
    })(), interfaces = { layer: LayerExpressionInterface, effects: EffectsExpressionInterface, comp: CompExpressionInterface, shape: ShapeExpressionInterface, text: TextExpressionInterface, footage: FootageInterface };
    function getInterface(e) {
      return interfaces[e] || null;
    }
    var expressionHelpers = /* @__PURE__ */ (function() {
      function e(e2, t2, n2) {
        t2.x && (n2.k = true, n2.x = true, n2.initiateExpression = ExpressionManager.initiateExpression, n2.effectsSequence.push(n2.initiateExpression(e2, t2, n2).bind(n2)));
      }
      function t(e2) {
        return e2 *= this.elem.globalData.frameRate, e2 -= this.offsetTime, e2 !== this._cachingAtTime.lastFrame && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastFrame < e2 ? this._cachingAtTime.lastIndex : 0, this._cachingAtTime.value = this.interpolateValue(e2, this._cachingAtTime), this._cachingAtTime.lastFrame = e2), this._cachingAtTime.value;
      }
      function n(e2) {
        var t2 = -0.01, n2 = this.getValueAtTime(e2), r2 = this.getValueAtTime(e2 + t2), i2 = 0;
        if (n2.length) {
          for (var a2 = 0; a2 < n2.length; a2 += 1) i2 += (r2[a2] - n2[a2]) ** 2;
          i2 = Math.sqrt(i2) * 100;
        } else i2 = 0;
        return i2;
      }
      function r(e2) {
        if (this.vel !== void 0) return this.vel;
        var t2 = -1e-3, n2 = this.getValueAtTime(e2), r2 = this.getValueAtTime(e2 + t2), i2;
        if (n2.length) {
          i2 = createTypedArray(`float32`, n2.length);
          for (var a2 = 0; a2 < n2.length; a2 += 1) i2[a2] = (r2[a2] - n2[a2]) / t2;
        } else i2 = (r2 - n2) / t2;
        return i2;
      }
      function i() {
        return this.pv;
      }
      function a(e2) {
        this.propertyGroup = e2;
      }
      return { searchExpressions: e, getSpeedAtTime: n, getVelocityAtTime: r, getValueAtTime: t, getStaticValueAtTime: i, setGroupProperty: a };
    })();
    function addPropertyDecorator() {
      function e(e2, t2, n2) {
        if (!this.k || !this.keyframes) return this.pv;
        e2 = e2 ? e2.toLowerCase() : ``;
        var r2 = this.comp.renderedFrame, i2 = this.keyframes, a2 = i2[i2.length - 1].t;
        if (r2 <= a2) return this.pv;
        var o2, s2;
        n2 ? (o2 = t2 ? Math.abs(a2 - this.elem.comp.globalData.frameRate * t2) : Math.max(0, a2 - this.elem.data.ip), s2 = a2 - o2) : ((!t2 || t2 > i2.length - 1) && (t2 = i2.length - 1), s2 = i2[i2.length - 1 - t2].t, o2 = a2 - s2);
        var c2, l2, u2;
        if (e2 === `pingpong`) {
          if (Math.floor((r2 - s2) / o2) % 2 != 0) return this.getValueAtTime((o2 - (r2 - s2) % o2 + s2) / this.comp.globalData.frameRate, 0);
        } else if (e2 === `offset`) {
          var d2 = this.getValueAtTime(s2 / this.comp.globalData.frameRate, 0), f = this.getValueAtTime(a2 / this.comp.globalData.frameRate, 0), p = this.getValueAtTime(((r2 - s2) % o2 + s2) / this.comp.globalData.frameRate, 0), m = Math.floor((r2 - s2) / o2);
          if (this.pv.length) {
            for (u2 = Array(d2.length), l2 = u2.length, c2 = 0; c2 < l2; c2 += 1) u2[c2] = (f[c2] - d2[c2]) * m + p[c2];
            return u2;
          }
          return (f - d2) * m + p;
        } else if (e2 === `continue`) {
          var g = this.getValueAtTime(a2 / this.comp.globalData.frameRate, 0), _ = this.getValueAtTime((a2 - 1e-3) / this.comp.globalData.frameRate, 0);
          if (this.pv.length) {
            for (u2 = Array(g.length), l2 = u2.length, c2 = 0; c2 < l2; c2 += 1) u2[c2] = g[c2] + (g[c2] - _[c2]) * ((r2 - a2) / this.comp.globalData.frameRate) / 5e-4;
            return u2;
          }
          return g + (g - _) * ((r2 - a2) / 1e-3);
        }
        return this.getValueAtTime(((r2 - s2) % o2 + s2) / this.comp.globalData.frameRate, 0);
      }
      function t(e2, t2, n2) {
        if (!this.k) return this.pv;
        e2 = e2 ? e2.toLowerCase() : ``;
        var r2 = this.comp.renderedFrame, i2 = this.keyframes, a2 = i2[0].t;
        if (r2 >= a2) return this.pv;
        var o2, s2;
        n2 ? (o2 = t2 ? Math.abs(this.elem.comp.globalData.frameRate * t2) : Math.max(0, this.elem.data.op - a2), s2 = a2 + o2) : ((!t2 || t2 > i2.length - 1) && (t2 = i2.length - 1), s2 = i2[t2].t, o2 = s2 - a2);
        var c2, l2, u2;
        if (e2 === `pingpong`) {
          if (Math.floor((a2 - r2) / o2) % 2 == 0) return this.getValueAtTime(((a2 - r2) % o2 + a2) / this.comp.globalData.frameRate, 0);
        } else if (e2 === `offset`) {
          var d2 = this.getValueAtTime(a2 / this.comp.globalData.frameRate, 0), f = this.getValueAtTime(s2 / this.comp.globalData.frameRate, 0), p = this.getValueAtTime((o2 - (a2 - r2) % o2 + a2) / this.comp.globalData.frameRate, 0), m = Math.floor((a2 - r2) / o2) + 1;
          if (this.pv.length) {
            for (u2 = Array(d2.length), l2 = u2.length, c2 = 0; c2 < l2; c2 += 1) u2[c2] = p[c2] - (f[c2] - d2[c2]) * m;
            return u2;
          }
          return p - (f - d2) * m;
        } else if (e2 === `continue`) {
          var g = this.getValueAtTime(a2 / this.comp.globalData.frameRate, 0), _ = this.getValueAtTime((a2 + 1e-3) / this.comp.globalData.frameRate, 0);
          if (this.pv.length) {
            for (u2 = Array(g.length), l2 = u2.length, c2 = 0; c2 < l2; c2 += 1) u2[c2] = g[c2] + (g[c2] - _[c2]) * (a2 - r2) / 1e-3;
            return u2;
          }
          return g + (g - _) * (a2 - r2) / 1e-3;
        }
        return this.getValueAtTime((o2 - ((a2 - r2) % o2 + a2)) / this.comp.globalData.frameRate, 0);
      }
      function n(e2, t2) {
        if (!this.k || (e2 = (e2 || 0.4) * 0.5, t2 = Math.floor(t2 || 5), t2 <= 1)) return this.pv;
        for (var n2 = this.comp.renderedFrame / this.comp.globalData.frameRate, r2 = n2 - e2, i2 = n2 + e2, a2 = t2 > 1 ? (i2 - r2) / (t2 - 1) : 1, o2 = 0, s2 = 0, c2 = this.pv.length ? createTypedArray(`float32`, this.pv.length) : 0, l2; o2 < t2; ) {
          if (l2 = this.getValueAtTime(r2 + o2 * a2), this.pv.length) for (s2 = 0; s2 < this.pv.length; s2 += 1) c2[s2] += l2[s2];
          else c2 += l2;
          o2 += 1;
        }
        if (this.pv.length) for (s2 = 0; s2 < this.pv.length; s2 += 1) c2[s2] /= t2;
        else c2 /= t2;
        return c2;
      }
      function r(e2) {
        this._transformCachingAtTime || (this._transformCachingAtTime = { v: new Matrix() });
        var t2 = this._transformCachingAtTime.v;
        if (t2.cloneFromProps(this.pre.props), this.appliedTransformations < 1) {
          var n2 = this.a.getValueAtTime(e2);
          t2.translate(-n2[0] * this.a.mult, -n2[1] * this.a.mult, n2[2] * this.a.mult);
        }
        if (this.appliedTransformations < 2) {
          var r2 = this.s.getValueAtTime(e2);
          t2.scale(r2[0] * this.s.mult, r2[1] * this.s.mult, r2[2] * this.s.mult);
        }
        if (this.sk && this.appliedTransformations < 3) {
          var i2 = this.sk.getValueAtTime(e2), a2 = this.sa.getValueAtTime(e2);
          t2.skewFromAxis(-i2 * this.sk.mult, a2 * this.sa.mult);
        }
        if (this.r && this.appliedTransformations < 4) {
          var o2 = this.r.getValueAtTime(e2);
          t2.rotate(-o2 * this.r.mult);
        } else if (!this.r && this.appliedTransformations < 4) {
          var s2 = this.rz.getValueAtTime(e2), c2 = this.ry.getValueAtTime(e2), l2 = this.rx.getValueAtTime(e2), u2 = this.or.getValueAtTime(e2);
          t2.rotateZ(-s2 * this.rz.mult).rotateY(c2 * this.ry.mult).rotateX(l2 * this.rx.mult).rotateZ(-u2[2] * this.or.mult).rotateY(u2[1] * this.or.mult).rotateX(u2[0] * this.or.mult);
        }
        if (this.data.p && this.data.p.s) {
          var d2 = this.px.getValueAtTime(e2), f = this.py.getValueAtTime(e2);
          if (this.data.p.z) {
            var p = this.pz.getValueAtTime(e2);
            t2.translate(d2 * this.px.mult, f * this.py.mult, -p * this.pz.mult);
          } else t2.translate(d2 * this.px.mult, f * this.py.mult, 0);
        } else {
          var m = this.p.getValueAtTime(e2);
          t2.translate(m[0] * this.p.mult, m[1] * this.p.mult, -m[2] * this.p.mult);
        }
        return t2;
      }
      function i() {
        return this.v.clone(new Matrix());
      }
      var a = TransformPropertyFactory.getTransformProperty;
      TransformPropertyFactory.getTransformProperty = function(e2, t2, n2) {
        var o2 = a(e2, t2, n2);
        return o2.getValueAtTime = o2.dynamicProperties.length ? r.bind(o2) : i.bind(o2), o2.setGroupProperty = expressionHelpers.setGroupProperty, o2;
      };
      var o = PropertyFactory.getProp;
      PropertyFactory.getProp = function(r2, i2, a2, s2, c2) {
        var l2 = o(r2, i2, a2, s2, c2);
        l2.getValueAtTime = l2.kf ? expressionHelpers.getValueAtTime.bind(l2) : expressionHelpers.getStaticValueAtTime.bind(l2), l2.setGroupProperty = expressionHelpers.setGroupProperty, l2.loopOut = e, l2.loopIn = t, l2.smooth = n, l2.getVelocityAtTime = expressionHelpers.getVelocityAtTime.bind(l2), l2.getSpeedAtTime = expressionHelpers.getSpeedAtTime.bind(l2), l2.numKeys = i2.a === 1 ? i2.k.length : 0, l2.propertyIndex = i2.ix;
        var u2 = 0;
        return a2 !== 0 && (u2 = createTypedArray(`float32`, i2.a === 1 ? i2.k[0].s.length : i2.k.length)), l2._cachingAtTime = { lastFrame: initialDefaultFrame, lastIndex: 0, value: u2 }, expressionHelpers.searchExpressions(r2, i2, l2), l2.k && c2.addDynamicProperty(l2), l2;
      };
      function s(e2) {
        return this._cachingAtTime || (this._cachingAtTime = { shapeValue: shapePool.clone(this.pv), lastIndex: 0, lastTime: initialDefaultFrame }), e2 *= this.elem.globalData.frameRate, e2 -= this.offsetTime, e2 !== this._cachingAtTime.lastTime && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastTime < e2 ? this._caching.lastIndex : 0, this._cachingAtTime.lastTime = e2, this.interpolateShape(e2, this._cachingAtTime.shapeValue, this._cachingAtTime)), this._cachingAtTime.shapeValue;
      }
      var c = ShapePropertyFactory.getConstructorFunction(), l = ShapePropertyFactory.getKeyframedConstructorFunction();
      function u() {
      }
      u.prototype = { vertices: function(e2, t2) {
        this.k && this.getValue();
        var n2 = this.v;
        t2 !== void 0 && (n2 = this.getValueAtTime(t2, 0));
        var r2, i2 = n2._length, a2 = n2[e2], o2 = n2.v, s2 = createSizedArray(i2);
        for (r2 = 0; r2 < i2; r2 += 1) e2 === `i` || e2 === `o` ? s2[r2] = [a2[r2][0] - o2[r2][0], a2[r2][1] - o2[r2][1]] : s2[r2] = [a2[r2][0], a2[r2][1]];
        return s2;
      }, points: function(e2) {
        return this.vertices(`v`, e2);
      }, inTangents: function(e2) {
        return this.vertices(`i`, e2);
      }, outTangents: function(e2) {
        return this.vertices(`o`, e2);
      }, isClosed: function() {
        return this.v.c;
      }, pointOnPath: function(e2, t2) {
        var n2 = this.v;
        t2 !== void 0 && (n2 = this.getValueAtTime(t2, 0)), this._segmentsLength || (this._segmentsLength = bez.getSegmentsLength(n2));
        for (var r2 = this._segmentsLength, i2 = r2.lengths, a2 = r2.totalLength * e2, o2 = 0, s2 = i2.length, c2 = 0, l2; o2 < s2; ) {
          if (c2 + i2[o2].addedLength > a2) {
            var u2 = o2, d2 = n2.c && o2 === s2 - 1 ? 0 : o2 + 1, f = (a2 - c2) / i2[o2].addedLength;
            l2 = bez.getPointInSegment(n2.v[u2], n2.v[d2], n2.o[u2], n2.i[d2], f, i2[o2]);
            break;
          }
          c2 += i2[o2].addedLength, o2 += 1;
        }
        return l2 || (l2 = n2.c ? [n2.v[0][0], n2.v[0][1]] : [n2.v[n2._length - 1][0], n2.v[n2._length - 1][1]]), l2;
      }, vectorOnPath: function(e2, t2, n2) {
        e2 == 1 ? e2 = this.v.c : e2 == 0 && (e2 = 0.999);
        var r2 = this.pointOnPath(e2, t2), i2 = this.pointOnPath(e2 + 1e-3, t2), a2 = i2[0] - r2[0], o2 = i2[1] - r2[1], s2 = Math.sqrt(a2 ** 2 + o2 ** 2);
        return s2 === 0 ? [0, 0] : n2 === `tangent` ? [a2 / s2, o2 / s2] : [-o2 / s2, a2 / s2];
      }, tangentOnPath: function(e2, t2) {
        return this.vectorOnPath(e2, t2, `tangent`);
      }, normalOnPath: function(e2, t2) {
        return this.vectorOnPath(e2, t2, `normal`);
      }, setGroupProperty: expressionHelpers.setGroupProperty, getValueAtTime: expressionHelpers.getStaticValueAtTime }, extendPrototype([u], c), extendPrototype([u], l), l.prototype.getValueAtTime = s, l.prototype.initiateExpression = ExpressionManager.initiateExpression;
      var d = ShapePropertyFactory.getShapeProp;
      ShapePropertyFactory.getShapeProp = function(e2, t2, n2, r2, i2) {
        var a2 = d(e2, t2, n2, r2, i2);
        return a2.propertyIndex = t2.ix, a2.lock = false, n2 === 3 ? expressionHelpers.searchExpressions(e2, t2.pt, a2) : n2 === 4 && expressionHelpers.searchExpressions(e2, t2.ks, a2), a2.k && e2.addDynamicProperty(a2), a2;
      };
    }
    function initialize$1() {
      addPropertyDecorator();
    }
    function addDecorator() {
      function e() {
        return this.data.d.x ? (this.calculateExpression = ExpressionManager.initiateExpression.bind(this)(this.elem, this.data.d, this), this.addEffect(this.getExpressionValue.bind(this)), true) : null;
      }
      TextProperty.prototype.getExpressionValue = function(e2, t) {
        var n = this.calculateExpression(t);
        if (e2.t !== n) {
          var r = {};
          return this.copyData(r, e2), r.t = n.toString(), r.__complete = false, r;
        }
        return e2;
      }, TextProperty.prototype.searchProperty = function() {
        var e2 = this.searchKeyframes(), t = this.searchExpressions();
        return this.kf = e2 || t, this.kf;
      }, TextProperty.prototype.searchExpressions = e;
    }
    function initialize() {
      addDecorator();
    }
    function SVGComposableEffect() {
    }
    SVGComposableEffect.prototype = { createMergeNode: function(e, t) {
      var n = createNS(`feMerge`);
      n.setAttribute(`result`, e);
      for (var r, i = 0; i < t.length; i += 1) r = createNS(`feMergeNode`), r.setAttribute(`in`, t[i]), n.appendChild(r), n.appendChild(r);
      return n;
    } };
    var linearFilterValue = `0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0`;
    function SVGTintFilter(e, t, n, r, i) {
      this.filterManager = t;
      var a = createNS(`feColorMatrix`);
      a.setAttribute(`type`, `matrix`), a.setAttribute(`color-interpolation-filters`, `linearRGB`), a.setAttribute(`values`, linearFilterValue + ` 1 0`), this.linearFilter = a, a.setAttribute(`result`, r + `_tint_1`), e.appendChild(a), a = createNS(`feColorMatrix`), a.setAttribute(`type`, `matrix`), a.setAttribute(`color-interpolation-filters`, `sRGB`), a.setAttribute(`values`, `1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0`), a.setAttribute(`result`, r + `_tint_2`), e.appendChild(a), this.matrixFilter = a;
      var o = this.createMergeNode(r, [i, r + `_tint_1`, r + `_tint_2`]);
      e.appendChild(o);
    }
    extendPrototype([SVGComposableEffect], SVGTintFilter), SVGTintFilter.prototype.renderFrame = function(e) {
      if (e || this.filterManager._mdf) {
        var t = this.filterManager.effectElements[0].p.v, n = this.filterManager.effectElements[1].p.v, r = this.filterManager.effectElements[2].p.v / 100;
        this.linearFilter.setAttribute(`values`, linearFilterValue + ` ` + r + ` 0`), this.matrixFilter.setAttribute(`values`, n[0] - t[0] + ` 0 0 0 ` + t[0] + ` ` + (n[1] - t[1]) + ` 0 0 0 ` + t[1] + ` ` + (n[2] - t[2]) + ` 0 0 0 ` + t[2] + ` 0 0 0 1 0`);
      }
    };
    function SVGFillFilter(e, t, n, r) {
      this.filterManager = t;
      var i = createNS(`feColorMatrix`);
      i.setAttribute(`type`, `matrix`), i.setAttribute(`color-interpolation-filters`, `sRGB`), i.setAttribute(`values`, `1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0`), i.setAttribute(`result`, r), e.appendChild(i), this.matrixFilter = i;
    }
    SVGFillFilter.prototype.renderFrame = function(e) {
      if (e || this.filterManager._mdf) {
        var t = this.filterManager.effectElements[2].p.v, n = this.filterManager.effectElements[6].p.v;
        this.matrixFilter.setAttribute(`values`, `0 0 0 0 ` + t[0] + ` 0 0 0 0 ` + t[1] + ` 0 0 0 0 ` + t[2] + ` 0 0 0 ` + n + ` 0`);
      }
    };
    function SVGStrokeEffect(e, t, n) {
      this.initialized = false, this.filterManager = t, this.elem = n, this.paths = [];
    }
    SVGStrokeEffect.prototype.initialize = function() {
      var e = this.elem.layerElement.children || this.elem.layerElement.childNodes, t, n, r, i;
      for (this.filterManager.effectElements[1].p.v === 1 ? (i = this.elem.maskManager.masksProperties.length, r = 0) : (r = this.filterManager.effectElements[0].p.v - 1, i = r + 1), n = createNS(`g`), n.setAttribute(`fill`, `none`), n.setAttribute(`stroke-linecap`, `round`), n.setAttribute(`stroke-dashoffset`, 1); r < i; r += 1) t = createNS(`path`), n.appendChild(t), this.paths.push({ p: t, m: r });
      if (this.filterManager.effectElements[10].p.v === 3) {
        var a = createNS(`mask`), o = createElementID();
        a.setAttribute(`id`, o), a.setAttribute(`mask-type`, `alpha`), a.appendChild(n), this.elem.globalData.defs.appendChild(a);
        var s = createNS(`g`);
        for (s.setAttribute(`mask`, `url(` + getLocationHref() + `#` + o + `)`); e[0]; ) s.appendChild(e[0]);
        this.elem.layerElement.appendChild(s), this.masker = a, n.setAttribute(`stroke`, `#fff`);
      } else if (this.filterManager.effectElements[10].p.v === 1 || this.filterManager.effectElements[10].p.v === 2) {
        if (this.filterManager.effectElements[10].p.v === 2) for (e = this.elem.layerElement.children || this.elem.layerElement.childNodes; e.length; ) this.elem.layerElement.removeChild(e[0]);
        this.elem.layerElement.appendChild(n), this.elem.layerElement.removeAttribute(`mask`), n.setAttribute(`stroke`, `#fff`);
      }
      this.initialized = true, this.pathMasker = n;
    }, SVGStrokeEffect.prototype.renderFrame = function(e) {
      this.initialized || this.initialize();
      var t, n = this.paths.length, r, i;
      for (t = 0; t < n; t += 1) if (this.paths[t].m !== -1 && (r = this.elem.maskManager.viewData[this.paths[t].m], i = this.paths[t].p, (e || this.filterManager._mdf || r.prop._mdf) && i.setAttribute(`d`, r.lastPath), e || this.filterManager.effectElements[9].p._mdf || this.filterManager.effectElements[4].p._mdf || this.filterManager.effectElements[7].p._mdf || this.filterManager.effectElements[8].p._mdf || r.prop._mdf)) {
        var a;
        if (this.filterManager.effectElements[7].p.v !== 0 || this.filterManager.effectElements[8].p.v !== 100) {
          var o = Math.min(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v) * 0.01, s = Math.max(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v) * 0.01, c = i.getTotalLength();
          a = `0 0 0 ` + c * o + ` `;
          for (var l = c * (s - o), u = 1 + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * 0.01, d = Math.floor(l / u), f = 0; f < d; f += 1) a += `1 ` + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * 0.01 + ` `;
          a += `0 ` + c * 10 + ` 0 0`;
        } else a = `1 ` + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * 0.01;
        i.setAttribute(`stroke-dasharray`, a);
      }
      if ((e || this.filterManager.effectElements[4].p._mdf) && this.pathMasker.setAttribute(`stroke-width`, this.filterManager.effectElements[4].p.v * 2), (e || this.filterManager.effectElements[6].p._mdf) && this.pathMasker.setAttribute(`opacity`, this.filterManager.effectElements[6].p.v), (this.filterManager.effectElements[10].p.v === 1 || this.filterManager.effectElements[10].p.v === 2) && (e || this.filterManager.effectElements[3].p._mdf)) {
        var p = this.filterManager.effectElements[3].p.v;
        this.pathMasker.setAttribute(`stroke`, `rgb(` + bmFloor(p[0] * 255) + `,` + bmFloor(p[1] * 255) + `,` + bmFloor(p[2] * 255) + `)`);
      }
    };
    function SVGTritoneFilter(e, t, n, r) {
      this.filterManager = t;
      var i = createNS(`feColorMatrix`);
      i.setAttribute(`type`, `matrix`), i.setAttribute(`color-interpolation-filters`, `linearRGB`), i.setAttribute(`values`, `0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0`), e.appendChild(i);
      var a = createNS(`feComponentTransfer`);
      a.setAttribute(`color-interpolation-filters`, `sRGB`), a.setAttribute(`result`, r), this.matrixFilter = a;
      var o = createNS(`feFuncR`);
      o.setAttribute(`type`, `table`), a.appendChild(o), this.feFuncR = o;
      var s = createNS(`feFuncG`);
      s.setAttribute(`type`, `table`), a.appendChild(s), this.feFuncG = s;
      var c = createNS(`feFuncB`);
      c.setAttribute(`type`, `table`), a.appendChild(c), this.feFuncB = c, e.appendChild(a);
    }
    SVGTritoneFilter.prototype.renderFrame = function(e) {
      if (e || this.filterManager._mdf) {
        var t = this.filterManager.effectElements[0].p.v, n = this.filterManager.effectElements[1].p.v, r = this.filterManager.effectElements[2].p.v, i = r[0] + ` ` + n[0] + ` ` + t[0], a = r[1] + ` ` + n[1] + ` ` + t[1], o = r[2] + ` ` + n[2] + ` ` + t[2];
        this.feFuncR.setAttribute(`tableValues`, i), this.feFuncG.setAttribute(`tableValues`, a), this.feFuncB.setAttribute(`tableValues`, o);
      }
    };
    function SVGProLevelsFilter(e, t, n, r) {
      this.filterManager = t;
      var i = this.filterManager.effectElements, a = createNS(`feComponentTransfer`);
      (i[10].p.k || i[10].p.v !== 0 || i[11].p.k || i[11].p.v !== 1 || i[12].p.k || i[12].p.v !== 1 || i[13].p.k || i[13].p.v !== 0 || i[14].p.k || i[14].p.v !== 1) && (this.feFuncR = this.createFeFunc(`feFuncR`, a)), (i[17].p.k || i[17].p.v !== 0 || i[18].p.k || i[18].p.v !== 1 || i[19].p.k || i[19].p.v !== 1 || i[20].p.k || i[20].p.v !== 0 || i[21].p.k || i[21].p.v !== 1) && (this.feFuncG = this.createFeFunc(`feFuncG`, a)), (i[24].p.k || i[24].p.v !== 0 || i[25].p.k || i[25].p.v !== 1 || i[26].p.k || i[26].p.v !== 1 || i[27].p.k || i[27].p.v !== 0 || i[28].p.k || i[28].p.v !== 1) && (this.feFuncB = this.createFeFunc(`feFuncB`, a)), (i[31].p.k || i[31].p.v !== 0 || i[32].p.k || i[32].p.v !== 1 || i[33].p.k || i[33].p.v !== 1 || i[34].p.k || i[34].p.v !== 0 || i[35].p.k || i[35].p.v !== 1) && (this.feFuncA = this.createFeFunc(`feFuncA`, a)), (this.feFuncR || this.feFuncG || this.feFuncB || this.feFuncA) && (a.setAttribute(`color-interpolation-filters`, `sRGB`), e.appendChild(a)), (i[3].p.k || i[3].p.v !== 0 || i[4].p.k || i[4].p.v !== 1 || i[5].p.k || i[5].p.v !== 1 || i[6].p.k || i[6].p.v !== 0 || i[7].p.k || i[7].p.v !== 1) && (a = createNS(`feComponentTransfer`), a.setAttribute(`color-interpolation-filters`, `sRGB`), a.setAttribute(`result`, r), e.appendChild(a), this.feFuncRComposed = this.createFeFunc(`feFuncR`, a), this.feFuncGComposed = this.createFeFunc(`feFuncG`, a), this.feFuncBComposed = this.createFeFunc(`feFuncB`, a));
    }
    SVGProLevelsFilter.prototype.createFeFunc = function(e, t) {
      var n = createNS(e);
      return n.setAttribute(`type`, `table`), t.appendChild(n), n;
    }, SVGProLevelsFilter.prototype.getTableValue = function(e, t, n, r, i) {
      for (var a = 0, o = 256, s, c = Math.min(e, t), l = Math.max(e, t), u = Array.call(null, { length: o }), d, f = 0, p = i - r, m = t - e; a <= 256; ) s = a / 256, d = s <= c ? m < 0 ? i : r : s >= l ? m < 0 ? r : i : r + p * ((s - e) / m) ** (1 / n), u[f] = d, f += 1, a += 256 / (o - 1);
      return u.join(` `);
    }, SVGProLevelsFilter.prototype.renderFrame = function(e) {
      if (e || this.filterManager._mdf) {
        var t, n = this.filterManager.effectElements;
        this.feFuncRComposed && (e || n[3].p._mdf || n[4].p._mdf || n[5].p._mdf || n[6].p._mdf || n[7].p._mdf) && (t = this.getTableValue(n[3].p.v, n[4].p.v, n[5].p.v, n[6].p.v, n[7].p.v), this.feFuncRComposed.setAttribute(`tableValues`, t), this.feFuncGComposed.setAttribute(`tableValues`, t), this.feFuncBComposed.setAttribute(`tableValues`, t)), this.feFuncR && (e || n[10].p._mdf || n[11].p._mdf || n[12].p._mdf || n[13].p._mdf || n[14].p._mdf) && (t = this.getTableValue(n[10].p.v, n[11].p.v, n[12].p.v, n[13].p.v, n[14].p.v), this.feFuncR.setAttribute(`tableValues`, t)), this.feFuncG && (e || n[17].p._mdf || n[18].p._mdf || n[19].p._mdf || n[20].p._mdf || n[21].p._mdf) && (t = this.getTableValue(n[17].p.v, n[18].p.v, n[19].p.v, n[20].p.v, n[21].p.v), this.feFuncG.setAttribute(`tableValues`, t)), this.feFuncB && (e || n[24].p._mdf || n[25].p._mdf || n[26].p._mdf || n[27].p._mdf || n[28].p._mdf) && (t = this.getTableValue(n[24].p.v, n[25].p.v, n[26].p.v, n[27].p.v, n[28].p.v), this.feFuncB.setAttribute(`tableValues`, t)), this.feFuncA && (e || n[31].p._mdf || n[32].p._mdf || n[33].p._mdf || n[34].p._mdf || n[35].p._mdf) && (t = this.getTableValue(n[31].p.v, n[32].p.v, n[33].p.v, n[34].p.v, n[35].p.v), this.feFuncA.setAttribute(`tableValues`, t));
      }
    };
    function SVGDropShadowEffect(e, t, n, r, i) {
      var a = t.container.globalData.renderConfig.filterSize, o = t.data.fs || a;
      e.setAttribute(`x`, o.x || a.x), e.setAttribute(`y`, o.y || a.y), e.setAttribute(`width`, o.width || a.width), e.setAttribute(`height`, o.height || a.height), this.filterManager = t;
      var s = createNS(`feGaussianBlur`);
      s.setAttribute(`in`, `SourceAlpha`), s.setAttribute(`result`, r + `_drop_shadow_1`), s.setAttribute(`stdDeviation`, `0`), this.feGaussianBlur = s, e.appendChild(s);
      var c = createNS(`feOffset`);
      c.setAttribute(`dx`, `25`), c.setAttribute(`dy`, `0`), c.setAttribute(`in`, r + `_drop_shadow_1`), c.setAttribute(`result`, r + `_drop_shadow_2`), this.feOffset = c, e.appendChild(c);
      var l = createNS(`feFlood`);
      l.setAttribute(`flood-color`, `#00ff00`), l.setAttribute(`flood-opacity`, `1`), l.setAttribute(`result`, r + `_drop_shadow_3`), this.feFlood = l, e.appendChild(l);
      var u = createNS(`feComposite`);
      u.setAttribute(`in`, r + `_drop_shadow_3`), u.setAttribute(`in2`, r + `_drop_shadow_2`), u.setAttribute(`operator`, `in`), u.setAttribute(`result`, r + `_drop_shadow_4`), e.appendChild(u);
      var d = this.createMergeNode(r, [r + `_drop_shadow_4`, i]);
      e.appendChild(d);
    }
    extendPrototype([SVGComposableEffect], SVGDropShadowEffect), SVGDropShadowEffect.prototype.renderFrame = function(e) {
      if (e || this.filterManager._mdf) {
        if ((e || this.filterManager.effectElements[4].p._mdf) && this.feGaussianBlur.setAttribute(`stdDeviation`, this.filterManager.effectElements[4].p.v / 4), e || this.filterManager.effectElements[0].p._mdf) {
          var t = this.filterManager.effectElements[0].p.v;
          this.feFlood.setAttribute(`flood-color`, rgbToHex(Math.round(t[0] * 255), Math.round(t[1] * 255), Math.round(t[2] * 255)));
        }
        if ((e || this.filterManager.effectElements[1].p._mdf) && this.feFlood.setAttribute(`flood-opacity`, this.filterManager.effectElements[1].p.v / 255), e || this.filterManager.effectElements[2].p._mdf || this.filterManager.effectElements[3].p._mdf) {
          var n = this.filterManager.effectElements[3].p.v, r = (this.filterManager.effectElements[2].p.v - 90) * degToRads, i = n * Math.cos(r), a = n * Math.sin(r);
          this.feOffset.setAttribute(`dx`, i), this.feOffset.setAttribute(`dy`, a);
        }
      }
    };
    var _svgMatteSymbols = [];
    function SVGMatte3Effect(e, t, n) {
      this.initialized = false, this.filterManager = t, this.filterElem = e, this.elem = n, n.matteElement = createNS(`g`), n.matteElement.appendChild(n.layerElement), n.matteElement.appendChild(n.transformedElement), n.baseElement = n.matteElement;
    }
    SVGMatte3Effect.prototype.findSymbol = function(e) {
      for (var t = 0, n = _svgMatteSymbols.length; t < n; ) {
        if (_svgMatteSymbols[t] === e) return _svgMatteSymbols[t];
        t += 1;
      }
      return null;
    }, SVGMatte3Effect.prototype.replaceInParent = function(e, t) {
      var n = e.layerElement.parentNode;
      if (n) {
        for (var r = n.children, i = 0, a = r.length; i < a && r[i] !== e.layerElement; ) i += 1;
        var o;
        i <= a - 2 && (o = r[i + 1]);
        var s = createNS(`use`);
        s.setAttribute(`href`, `#` + t), o ? n.insertBefore(s, o) : n.appendChild(s);
      }
    }, SVGMatte3Effect.prototype.setElementAsMask = function(e, t) {
      if (!this.findSymbol(t)) {
        var n = createElementID(), r = createNS(`mask`);
        r.setAttribute(`id`, t.layerId), r.setAttribute(`mask-type`, `alpha`), _svgMatteSymbols.push(t);
        var i = e.globalData.defs;
        i.appendChild(r);
        var a = createNS(`symbol`);
        a.setAttribute(`id`, n), this.replaceInParent(t, n), a.appendChild(t.layerElement), i.appendChild(a);
        var o = createNS(`use`);
        o.setAttribute(`href`, `#` + n), r.appendChild(o), t.data.hd = false, t.show();
      }
      e.setMatte(t.layerId);
    }, SVGMatte3Effect.prototype.initialize = function() {
      for (var e = this.filterManager.effectElements[0].p.v, t = this.elem.comp.elements, n = 0, r = t.length; n < r; ) t[n] && t[n].data.ind === e && this.setElementAsMask(this.elem, t[n]), n += 1;
      this.initialized = true;
    }, SVGMatte3Effect.prototype.renderFrame = function() {
      this.initialized || this.initialize();
    };
    function SVGGaussianBlurEffect(e, t, n, r) {
      e.setAttribute(`x`, `-100%`), e.setAttribute(`y`, `-100%`), e.setAttribute(`width`, `300%`), e.setAttribute(`height`, `300%`), this.filterManager = t;
      var i = createNS(`feGaussianBlur`);
      i.setAttribute(`result`, r), e.appendChild(i), this.feGaussianBlur = i;
    }
    SVGGaussianBlurEffect.prototype.renderFrame = function(e) {
      if (e || this.filterManager._mdf) {
        var t = this.filterManager.effectElements[0].p.v * 0.3, n = this.filterManager.effectElements[1].p.v, r = n == 3 ? 0 : t, i = n == 2 ? 0 : t;
        this.feGaussianBlur.setAttribute(`stdDeviation`, r + ` ` + i);
        var a = this.filterManager.effectElements[2].p.v == 1 ? `wrap` : `duplicate`;
        this.feGaussianBlur.setAttribute(`edgeMode`, a);
      }
    };
    function TransformEffect() {
    }
    TransformEffect.prototype.init = function(e) {
      this.effectsManager = e, this.type = effectTypes.TRANSFORM_EFFECT, this.matrix = new Matrix(), this.opacity = -1, this._mdf = false, this._opMdf = false;
    }, TransformEffect.prototype.renderFrame = function(e) {
      if (this._opMdf = false, this._mdf = false, e || this.effectsManager._mdf) {
        var t = this.effectsManager.effectElements, n = t[0].p.v, r = t[1].p.v, i = t[2].p.v === 1, a = t[3].p.v, o = i ? a : t[4].p.v, s = t[5].p.v, c = t[6].p.v, l = t[7].p.v;
        this.matrix.reset(), this.matrix.translate(-n[0], -n[1], n[2]), this.matrix.scale(o * 0.01, a * 0.01, 1), this.matrix.rotate(-l * degToRads), this.matrix.skewFromAxis(-s * degToRads, (c + 90) * degToRads), this.matrix.translate(r[0], r[1], 0), this._mdf = true, this.opacity !== t[8].p.v && (this.opacity = t[8].p.v, this._opMdf = true);
      }
    };
    function SVGTransformEffect(e, t) {
      this.init(t);
    }
    extendPrototype([TransformEffect], SVGTransformEffect);
    function CVTransformEffect(e) {
      this.init(e);
    }
    return extendPrototype([TransformEffect], CVTransformEffect), registerRenderer(`canvas`, CanvasRenderer), registerRenderer(`html`, HybridRenderer), registerRenderer(`svg`, SVGRenderer), ShapeModifiers.registerModifier(`tm`, TrimModifier), ShapeModifiers.registerModifier(`pb`, PuckerAndBloatModifier), ShapeModifiers.registerModifier(`rp`, RepeaterModifier), ShapeModifiers.registerModifier(`rd`, RoundCornersModifier), ShapeModifiers.registerModifier(`zz`, ZigZagModifier), ShapeModifiers.registerModifier(`op`, OffsetPathModifier), setExpressionsPlugin(Expressions), setExpressionInterfaces(getInterface), initialize$1(), initialize(), registerEffect$1(20, SVGTintFilter, true), registerEffect$1(21, SVGFillFilter, true), registerEffect$1(22, SVGStrokeEffect, false), registerEffect$1(23, SVGTritoneFilter, true), registerEffect$1(24, SVGProLevelsFilter, true), registerEffect$1(25, SVGDropShadowEffect, true), registerEffect$1(28, SVGMatte3Effect, false), registerEffect$1(29, SVGGaussianBlurEffect, true), registerEffect$1(35, SVGTransformEffect, false), registerEffect(35, CVTransformEffect), lottie;
  }));
})), require_index_umd = __commonJSMin(((e, t) => {
  (function(n, r) {
    typeof e == `object` && t !== void 0 ? r(e, require_lottie(), (init__virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare__react__loadShare__(), __toCommonJS(_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare__react__loadShare___exports))) : typeof define == `function` && define.amd ? define([`exports`, `lottie-web`, `react`], r) : (n = typeof globalThis < `u` ? globalThis : n || self, r(n[`lottie-react`] = {}, n.Lottie, n.React));
  })(e, (function(e2, t2, n) {
    function r(e3) {
      return e3 && typeof e3 == `object` && `default` in e3 ? e3 : { default: e3 };
    }
    var i = r(t2), a = r(n);
    function o(e3, t3) {
      (t3 == null || t3 > e3.length) && (t3 = e3.length);
      for (var n2 = 0, r2 = Array(t3); n2 < t3; n2++) r2[n2] = e3[n2];
      return r2;
    }
    function s(e3) {
      if (Array.isArray(e3)) return e3;
    }
    function c(e3, t3, n2) {
      return (t3 = y(t3)) in e3 ? Object.defineProperty(e3, t3, { value: n2, enumerable: true, configurable: true, writable: true }) : e3[t3] = n2, e3;
    }
    function l(e3, t3) {
      var n2 = e3 == null ? null : typeof Symbol < `u` && e3[Symbol.iterator] || e3[`@@iterator`];
      if (n2 != null) {
        var r2, i2, a2, o2, s2 = [], c2 = true, l2 = false;
        try {
          if (a2 = (n2 = n2.call(e3)).next, t3 === 0) {
            if (Object(n2) !== n2) return;
            c2 = false;
          } else for (; !(c2 = (r2 = a2.call(n2)).done) && (s2.push(r2.value), s2.length !== t3); c2 = true) ;
        } catch (e4) {
          l2 = true, i2 = e4;
        } finally {
          try {
            if (!c2 && n2.return != null && (o2 = n2.return(), Object(o2) !== o2)) return;
          } finally {
            if (l2) throw i2;
          }
        }
        return s2;
      }
    }
    function u() {
      throw TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
    }
    function d(e3, t3) {
      var n2 = Object.keys(e3);
      if (Object.getOwnPropertySymbols) {
        var r2 = Object.getOwnPropertySymbols(e3);
        t3 && (r2 = r2.filter(function(t4) {
          return Object.getOwnPropertyDescriptor(e3, t4).enumerable;
        })), n2.push.apply(n2, r2);
      }
      return n2;
    }
    function f(e3) {
      for (var t3 = 1; t3 < arguments.length; t3++) {
        var n2 = arguments[t3] == null ? {} : arguments[t3];
        t3 % 2 ? d(Object(n2), true).forEach(function(t4) {
          c(e3, t4, n2[t4]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e3, Object.getOwnPropertyDescriptors(n2)) : d(Object(n2)).forEach(function(t4) {
          Object.defineProperty(e3, t4, Object.getOwnPropertyDescriptor(n2, t4));
        });
      }
      return e3;
    }
    function p(e3, t3) {
      if (e3 == null) return {};
      var n2, r2, i2 = m(e3, t3);
      if (Object.getOwnPropertySymbols) {
        var a2 = Object.getOwnPropertySymbols(e3);
        for (r2 = 0; r2 < a2.length; r2++) n2 = a2[r2], t3.includes(n2) || {}.propertyIsEnumerable.call(e3, n2) && (i2[n2] = e3[n2]);
      }
      return i2;
    }
    function m(e3, t3) {
      if (e3 == null) return {};
      var n2 = {};
      for (var r2 in e3) if ({}.hasOwnProperty.call(e3, r2)) {
        if (t3.includes(r2)) continue;
        n2[r2] = e3[r2];
      }
      return n2;
    }
    function g(e3, t3) {
      return s(e3) || l(e3, t3) || b(e3, t3) || u();
    }
    function _(e3, t3) {
      if (typeof e3 != `object` || !e3) return e3;
      var n2 = e3[Symbol.toPrimitive];
      if (n2 !== void 0) {
        var r2 = n2.call(e3, t3 || `default`);
        if (typeof r2 != `object`) return r2;
        throw TypeError(`@@toPrimitive must return a primitive value.`);
      }
      return (t3 === `string` ? String : Number)(e3);
    }
    function y(e3) {
      var t3 = _(e3, `string`);
      return typeof t3 == `symbol` ? t3 : t3 + ``;
    }
    function b(e3, t3) {
      if (e3) {
        if (typeof e3 == `string`) return o(e3, t3);
        var n2 = {}.toString.call(e3).slice(8, -1);
        return n2 === `Object` && e3.constructor && (n2 = e3.constructor.name), n2 === `Map` || n2 === `Set` ? Array.from(e3) : n2 === `Arguments` || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2) ? o(e3, t3) : void 0;
      }
    }
    var x = [`animationData`, `loop`, `autoplay`, `initialSegment`, `onComplete`, `onLoopComplete`, `onEnterFrame`, `onSegmentStart`, `onConfigReady`, `onDataReady`, `onDataFailed`, `onLoadedImages`, `onDOMLoaded`, `onDestroy`, `lottieRef`, `renderer`, `name`, `assetsPath`, `rendererSettings`], S = function(e3, t3) {
      var r2 = e3.animationData, o2 = e3.loop, s2 = e3.autoplay, c2 = e3.initialSegment, l2 = e3.onComplete, u2 = e3.onLoopComplete, d2 = e3.onEnterFrame, m2 = e3.onSegmentStart, _2 = e3.onConfigReady, y2 = e3.onDataReady, b2 = e3.onDataFailed, S2 = e3.onLoadedImages, C2 = e3.onDOMLoaded, T2 = e3.onDestroy;
      e3.lottieRef, e3.renderer, e3.name, e3.assetsPath, e3.rendererSettings;
      var E2 = p(e3, x), D2 = g(n.useState(false), 2), O2 = D2[0], k = D2[1], A = n.useRef(), j = n.useRef(null), M = function() {
        var e4;
        (e4 = A.current) == null || e4.play();
      }, N = function() {
        var e4;
        (e4 = A.current) == null || e4.stop();
      }, P = function() {
        var e4;
        (e4 = A.current) == null || e4.pause();
      }, F = function(e4) {
        var t4;
        (t4 = A.current) == null || t4.setSpeed(e4);
      }, I = function(e4, t4) {
        var n2;
        (n2 = A.current) == null || n2.goToAndPlay(e4, t4);
      }, L = function(e4, t4) {
        var n2;
        (n2 = A.current) == null || n2.goToAndStop(e4, t4);
      }, R = function(e4) {
        var t4;
        (t4 = A.current) == null || t4.setDirection(e4);
      }, z = function(e4, t4) {
        var n2;
        (n2 = A.current) == null || n2.playSegments(e4, t4);
      }, B = function(e4) {
        var t4;
        (t4 = A.current) == null || t4.setSubframe(e4);
      }, V = function(e4) {
        var _a;
        var t4;
        return (_a = A.current) == null ? void 0 : _a.getDuration(e4);
      }, H = function() {
        var e4;
        (e4 = A.current) == null || e4.destroy(), A.current = void 0;
      }, ee = function() {
        var t4 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, n2;
        if (j.current) {
          (n2 = A.current) == null || n2.destroy();
          var r3 = f(f(f({}, e3), t4), {}, { container: j.current });
          return A.current = i.default.loadAnimation(r3), k(!!A.current), function() {
            var e4;
            (e4 = A.current) == null || e4.destroy(), A.current = void 0;
          };
        }
      };
      return n.useEffect(function() {
        var e4 = ee();
        return function() {
          return e4 == null ? void 0 : e4();
        };
      }, [r2, o2]), n.useEffect(function() {
        A.current && (A.current.autoplay = !!s2);
      }, [s2]), n.useEffect(function() {
        if (A.current) {
          if (!c2) {
            A.current.resetSegments(true);
            return;
          }
          Array.isArray(c2) && c2.length && ((A.current.currentRawFrame < c2[0] || A.current.currentRawFrame > c2[1]) && (A.current.currentRawFrame = c2[0]), A.current.setSegment(c2[0], c2[1]));
        }
      }, [c2]), n.useEffect(function() {
        var e4 = [{ name: `complete`, handler: l2 }, { name: `loopComplete`, handler: u2 }, { name: `enterFrame`, handler: d2 }, { name: `segmentStart`, handler: m2 }, { name: `config_ready`, handler: _2 }, { name: `data_ready`, handler: y2 }, { name: `data_failed`, handler: b2 }, { name: `loaded_images`, handler: S2 }, { name: `DOMLoaded`, handler: C2 }, { name: `destroy`, handler: T2 }].filter(function(e5) {
          return e5.handler != null;
        });
        if (e4.length) {
          var t4 = e4.map(function(e5) {
            var t5;
            return (t5 = A.current) == null || t5.addEventListener(e5.name, e5.handler), function() {
              var t6;
              (t6 = A.current) == null || t6.removeEventListener(e5.name, e5.handler);
            };
          });
          return function() {
            t4.forEach(function(e5) {
              return e5();
            });
          };
        }
      }, [l2, u2, d2, m2, _2, y2, b2, S2, C2, T2]), { View: a.default.createElement(`div`, f({ style: t3, ref: j }, E2)), play: M, stop: N, pause: P, setSpeed: F, goToAndStop: L, goToAndPlay: I, setDirection: R, playSegments: z, setSubframe: B, getDuration: V, destroy: H, animationContainerRef: j, animationLoaded: O2, animationItem: A.current };
    };
    function C(e3) {
      var t3 = e3.getBoundingClientRect(), n2 = t3.top, r2 = t3.height;
      return (window.innerHeight - n2) / (window.innerHeight + r2);
    }
    function T(e3, t3, n2) {
      var r2 = e3.getBoundingClientRect(), i2 = r2.top, a2 = r2.left, o2 = r2.width, s2 = r2.height;
      return { x: (t3 - a2) / o2, y: (n2 - i2) / s2 };
    }
    var E = function(e3) {
      var t3 = e3.wrapperRef, r2 = e3.animationItem, i2 = e3.mode, a2 = e3.actions;
      n.useEffect(function() {
        var e4 = t3.current;
        if (e4 && r2 && a2.length) {
          r2.stop();
          var n2 = function() {
            var t4 = null, n3 = function() {
              var n4 = C(e4), i3 = a2.find(function(e5) {
                var t5 = e5.visibility;
                return t5 && n4 >= t5[0] && n4 <= t5[1];
              });
              if (i3) {
                if (i3.type === `seek` && i3.visibility && i3.frames.length === 2) {
                  var o3 = i3.frames[0] + Math.ceil((n4 - i3.visibility[0]) / (i3.visibility[1] - i3.visibility[0]) * i3.frames[1]);
                  r2.goToAndStop(o3 - r2.firstFrame - 1, true);
                }
                i3.type === `loop` && (t4 === null ? (r2.playSegments(i3.frames, true), t4 = i3.frames) : t4 === i3.frames ? r2.isPaused && (r2.playSegments(i3.frames, true), t4 = i3.frames) : (r2.playSegments(i3.frames, true), t4 = i3.frames)), i3.type === `play` && r2.isPaused && (r2.resetSegments(true), r2.play()), i3.type === `stop` && r2.goToAndStop(i3.frames[0] - r2.firstFrame - 1, true);
              }
            };
            return document.addEventListener(`scroll`, n3), function() {
              document.removeEventListener(`scroll`, n3);
            };
          }, o2 = function() {
            var t4 = function(t5, n4) {
              var i4 = t5, o3 = n4;
              if (i4 !== -1 && o3 !== -1) {
                var s2 = T(e4, i4, o3);
                i4 = s2.x, o3 = s2.y;
              }
              var c2 = a2.find(function(e5) {
                var t6 = e5.position;
                return t6 && Array.isArray(t6.x) && Array.isArray(t6.y) ? i4 >= t6.x[0] && i4 <= t6.x[1] && o3 >= t6.y[0] && o3 <= t6.y[1] : t6 && !Number.isNaN(t6.x) && !Number.isNaN(t6.y) ? i4 === t6.x && o3 === t6.y : false;
              });
              if (c2) {
                if (c2.type === `seek` && c2.position && Array.isArray(c2.position.x) && Array.isArray(c2.position.y) && c2.frames.length === 2) {
                  var l2 = (i4 - c2.position.x[0]) / (c2.position.x[1] - c2.position.x[0]), u2 = (o3 - c2.position.y[0]) / (c2.position.y[1] - c2.position.y[0]);
                  r2.playSegments(c2.frames, true), r2.goToAndStop(Math.ceil((l2 + u2) / 2 * (c2.frames[1] - c2.frames[0])), true);
                }
                c2.type === `loop` && r2.playSegments(c2.frames, true), c2.type === `play` && (r2.isPaused && r2.resetSegments(false), r2.playSegments(c2.frames)), c2.type === `stop` && r2.goToAndStop(c2.frames[0], true);
              }
            }, n3 = function(e5) {
              t4(e5.clientX, e5.clientY);
            }, i3 = function() {
              t4(-1, -1);
            };
            return e4.addEventListener(`mousemove`, n3), e4.addEventListener(`mouseout`, i3), function() {
              e4.removeEventListener(`mousemove`, n3), e4.removeEventListener(`mouseout`, i3);
            };
          };
          switch (i2) {
            case `scroll`:
              return n2();
            case `cursor`:
              return o2();
          }
        }
      }, [i2, r2]);
    }, D = function(e3) {
      var t3 = e3.actions, n2 = e3.mode, r2 = e3.lottieObj, i2 = r2.animationItem, a2 = r2.View, o2 = r2.animationContainerRef;
      return E({ actions: t3, animationItem: i2, mode: n2, wrapperRef: o2 }), a2;
    }, O = [`style`, `interactivity`];
    Object.defineProperty(e2, "LottiePlayer", { enumerable: true, get: function() {
      return i.default;
    } }), e2.default = function(e3) {
      var _a;
      var t3, r2, i2, a2 = e3.style, o2 = e3.interactivity, s2 = S(p(e3, O), a2), c2 = s2.View, l2 = s2.play, u2 = s2.stop, d2 = s2.pause, f2 = s2.setSpeed, m2 = s2.goToAndStop, g2 = s2.goToAndPlay, _2 = s2.setDirection, y2 = s2.playSegments, b2 = s2.setSubframe, x2 = s2.getDuration, C2 = s2.destroy, T2 = s2.animationContainerRef, E2 = s2.animationLoaded, k = s2.animationItem;
      return n.useEffect(function() {
        e3.lottieRef && (e3.lottieRef.current = { play: l2, stop: u2, pause: d2, setSpeed: f2, goToAndPlay: g2, goToAndStop: m2, setDirection: _2, playSegments: y2, setSubframe: b2, getDuration: x2, destroy: C2, animationContainerRef: T2, animationLoaded: E2, animationItem: k });
      }, [(_a = e3.lottieRef) == null ? void 0 : _a.current]), D({ lottieObj: { View: c2, play: l2, stop: u2, pause: d2, setSpeed: f2, goToAndStop: m2, goToAndPlay: g2, setDirection: _2, playSegments: y2, setSubframe: b2, getDuration: x2, destroy: C2, animationContainerRef: T2, animationLoaded: E2, animationItem: k }, actions: (o2 == null ? void 0 : o2.actions) ?? [], mode: (o2 == null ? void 0 : o2.mode) ?? `scroll` });
    }, e2.useLottie = S, e2.useLottieInteractivity = D, Object.defineProperty(e2, "__esModule", { value: true });
  }));
}));
init__virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare__react__loadShare__();
var import_index_umd = __toESM(require_index_umd(), 1), v = `5.5.8`, fr = 29.9700012207031, ip = 0, op = 47.0000019143492, w = 800, h = 800, nm = `Comp 1`, ddd = 0, assets = [], layers = [{ ddd: 0, ind: 1, ty: 4, nm: `Door Face 2`, sr: 1, ks: { o: { a: 0, k: 100, ix: 11 }, r: { a: 0, k: 0, ix: 10 }, p: { a: 0, k: [237.844, 395.617, 0], ix: 2 }, a: { a: 0, k: [-162.156, -4.383, 0], ix: 1 }, s: { a: 0, k: [100, 100, 100], ix: 6 } }, ao: 0, shapes: [{ ty: `gr`, it: [{ ty: `gr`, it: [{ d: 1, ty: `el`, s: { a: 0, k: [31.414, 31.414], ix: 2 }, p: { a: 0, k: [0, 0], ix: 3 }, nm: `Ellipse Path 1`, mn: `ADBE Vector Shape - Ellipse`, hd: false }, { ty: `st`, c: { a: 0, k: [0.10196078431372549, 0.596078431372549, 0.8274509803921568, 1], ix: 3 }, o: { a: 0, k: 100, ix: 4 }, w: { a: 0, k: 6, ix: 5 }, lc: 1, lj: 1, ml: 4, bm: 0, nm: `Stroke 1`, mn: `ADBE Vector Graphic - Stroke`, hd: false }, { ty: `tm`, s: { a: 1, k: [{ i: { x: [0.833], y: [0.833] }, o: { x: [0.167], y: [0.167] }, t: 0, s: [100] }, { t: 10.0000004073083, s: [0] }], ix: 1 }, e: { a: 0, k: 100, ix: 2 }, o: { a: 0, k: 0, ix: 3 }, m: 1, ix: 3, nm: `Trim Paths 1`, mn: `ADBE Vector Filter - Trim`, hd: false }, { ty: `tr`, p: { a: 0, k: [123.707, -0.293], ix: 2 }, a: { a: 0, k: [0, 0], ix: 1 }, s: { a: 0, k: [100, 100], ix: 3 }, r: { a: 0, k: 0, ix: 6 }, o: { a: 0, k: 100, ix: 7 }, sk: { a: 0, k: 0, ix: 4 }, sa: { a: 0, k: 0, ix: 5 }, nm: `Transform` }], nm: `Ellipse 2`, np: 3, cix: 2, bm: 0, ix: 1, mn: `ADBE Vector Group`, hd: false }, { ty: `gr`, it: [{ d: 1, ty: `el`, s: { a: 0, k: [31.414, 31.414], ix: 2 }, p: { a: 0, k: [0, 0], ix: 3 }, nm: `Ellipse Path 1`, mn: `ADBE Vector Shape - Ellipse`, hd: false }, { ty: `st`, c: { a: 0, k: [0.753998160362, 0.753998160362, 0.753998160362, 1], ix: 3 }, o: { a: 0, k: 100, ix: 4 }, w: { a: 0, k: 6, ix: 5 }, lc: 1, lj: 1, ml: 4, bm: 0, nm: `Stroke 1`, mn: `ADBE Vector Graphic - Stroke`, hd: false }, { ty: `fl`, c: { a: 0, k: [0.866666674614, 0.866666674614, 0.866666674614, 1], ix: 4 }, o: { a: 0, k: 100, ix: 5 }, r: 1, bm: 0, nm: `Fill 1`, mn: `ADBE Vector Graphic - Fill`, hd: false }, { ty: `tr`, p: { a: 0, k: [123.707, -0.293], ix: 2 }, a: { a: 0, k: [0, 0], ix: 1 }, s: { a: 0, k: [100, 100], ix: 3 }, r: { a: 0, k: 0, ix: 6 }, o: { a: 0, k: 100, ix: 7 }, sk: { a: 0, k: 0, ix: 4 }, sa: { a: 0, k: 0, ix: 5 }, nm: `Transform` }], nm: `Ellipse 1`, np: 3, cix: 2, bm: 0, ix: 2, mn: `ADBE Vector Group`, hd: false }, { ty: `tr`, p: { a: 1, k: [{ i: { x: 0.833, y: 0.833 }, o: { x: 0.167, y: 0.167 }, t: 10, s: [123.707, -0.293], to: [-11.667, 0], ti: [11.667, 0] }, { t: 25.0000010182709, s: [53.707, -0.293] }], ix: 2 }, a: { a: 0, k: [123.707, -0.293], ix: 1 }, s: { a: 0, k: [100, 100], ix: 3 }, r: { a: 0, k: 0, ix: 6 }, o: { a: 0, k: 100, ix: 7 }, sk: { a: 0, k: 0, ix: 4 }, sa: { a: 0, k: 0, ix: 5 }, nm: `Transform` }], nm: `Group 1`, np: 2, cix: 2, bm: 0, ix: 1, mn: `ADBE Vector Group`, hd: false }, { ty: `gr`, it: [{ ind: 0, ty: `sh`, ix: 1, ks: { a: 1, k: [{ i: { x: 0.833, y: 0.833 }, o: { x: 0.167, y: 0.167 }, t: 10, s: [{ i: [[0, -7.18], [0, 0], [7.18, 0], [0, 0], [0, 7.18], [0, 0], [-7.18, 0], [0, 0]], o: [[0, 0], [0, 7.18], [0, 0], [-7.18, 0], [0, 0], [0, -7.18], [0, 0], [7.18, 0]], v: [[159.367, -271.094], [159.367, 271.094], [146.367, 284.094], [-146.367, 284.094], [-159.367, 271.094], [-159.367, -271.094], [-146.367, -284.094], [146.367, -284.094]], c: true }] }, { t: 25.0000010182709, s: [{ i: [[0, -7.18], [0, 0], [7.18, 0], [0, 0], [0, 7.18], [0, 0], [-7.18, 0], [0, 0]], o: [[0, 0], [0, 7.18], [0, 0], [-7.18, 0], [0, 0], [0, -7.18], [0, 0], [7.18, 0]], v: [[89.367, -343.094], [87.367, 341.094], [74.367, 354.094], [-146.367, 284.094], [-159.367, 271.094], [-159.367, -271.094], [-146.367, -284.094], [76.367, -356.094]], c: true }] }], ix: 2 }, nm: `Path 1`, mn: `ADBE Vector Shape - Group`, hd: false }, { ty: `tm`, s: { a: 1, k: [{ i: { x: [0.833], y: [0.833] }, o: { x: [0.167], y: [0.167] }, t: 25, s: [100] }, { t: 35.0000014255792, s: [0] }], ix: 1 }, e: { a: 0, k: 100, ix: 2 }, o: { a: 0, k: 9, ix: 3 }, m: 1, ix: 2, nm: `Trim Paths 1`, mn: `ADBE Vector Filter - Trim`, hd: false }, { ty: `st`, c: { a: 0, k: [0.10196078431372549, 0.596078431372549, 0.8274509803921568, 1], ix: 3 }, o: { a: 0, k: 100, ix: 4 }, w: { a: 0, k: 11, ix: 5 }, lc: 2, lj: 2, bm: 0, nm: `Stroke 1`, mn: `ADBE Vector Graphic - Stroke`, hd: false }, { ty: `fl`, c: { a: 0, k: [0.929411768913, 0.929411768913, 0.929411768913, 1], ix: 4 }, o: { a: 0, k: 100, ix: 5 }, r: 1, bm: 0, nm: `Fill 1`, mn: `ADBE Vector Graphic - Fill`, hd: false }, { ty: `tr`, p: { a: 0, k: [-2.789, -4.383], ix: 2 }, a: { a: 0, k: [0, 0], ix: 1 }, s: { a: 0, k: [100, 100], ix: 3 }, r: { a: 0, k: 0, ix: 6 }, o: { a: 0, k: 100, ix: 7 }, sk: { a: 0, k: 0, ix: 4 }, sa: { a: 0, k: 0, ix: 5 }, nm: `Transform` }], nm: `Rectangle 2`, np: 4, cix: 2, bm: 0, ix: 2, mn: `ADBE Vector Group`, hd: false }, { ty: `gr`, it: [{ ind: 0, ty: `sh`, ix: 1, ks: { a: 1, k: [{ i: { x: 0.833, y: 0.833 }, o: { x: 0.167, y: 0.167 }, t: 10, s: [{ i: [[0, -7.18], [0, 0], [7.18, 0], [0, 0], [0, 7.18], [0, 0], [-7.18, 0], [0, 0]], o: [[0, 0], [0, 7.18], [0, 0], [-7.18, 0], [0, 0], [0, -7.18], [0, 0], [7.18, 0]], v: [[159.367, -271.094], [159.367, 271.094], [146.367, 284.094], [-146.367, 284.094], [-159.367, 271.094], [-159.367, -271.094], [-146.367, -284.094], [146.367, -284.094]], c: true }] }, { t: 25.0000010182709, s: [{ i: [[0, -7.18], [0, 0], [7.18, 0], [0, 0], [0, 7.18], [0, 0], [-7.18, 0], [0, 0]], o: [[0, 0], [0, 7.18], [0, 0], [-7.18, 0], [0, 0], [0, -7.18], [0, 0], [7.18, 0]], v: [[89.367, -343.094], [87.367, 341.094], [74.367, 354.094], [-146.367, 284.094], [-159.367, 271.094], [-159.367, -271.094], [-146.367, -284.094], [76.367, -356.094]], c: true }] }], ix: 2 }, nm: `Path 1`, mn: `ADBE Vector Shape - Group`, hd: false }, { ty: `tm`, s: { a: 0, k: 100, ix: 1 }, e: { a: 0, k: 0, ix: 2 }, o: { a: 0, k: 9, ix: 3 }, m: 1, ix: 2, nm: `Trim Paths 1`, mn: `ADBE Vector Filter - Trim`, hd: false }, { ty: `st`, c: { a: 0, k: [0.85724568367, 0.85724568367, 0.85724568367, 1], ix: 3 }, o: { a: 0, k: 100, ix: 4 }, w: { a: 0, k: 11, ix: 5 }, lc: 2, lj: 2, bm: 0, nm: `Stroke 1`, mn: `ADBE Vector Graphic - Stroke`, hd: false }, { ty: `fl`, c: { a: 0, k: [0.929411768913, 0.929411768913, 0.929411768913, 1], ix: 4 }, o: { a: 0, k: 100, ix: 5 }, r: 1, bm: 0, nm: `Fill 1`, mn: `ADBE Vector Graphic - Fill`, hd: false }, { ty: `tr`, p: { a: 0, k: [-2.789, -4.383], ix: 2 }, a: { a: 0, k: [0, 0], ix: 1 }, s: { a: 0, k: [100, 100], ix: 3 }, r: { a: 0, k: 0, ix: 6 }, o: { a: 0, k: 100, ix: 7 }, sk: { a: 0, k: 0, ix: 4 }, sa: { a: 0, k: 0, ix: 5 }, nm: `Transform` }], nm: `Rectangle 3`, np: 4, cix: 2, bm: 0, ix: 3, mn: `ADBE Vector Group`, hd: false }], ip: 0, op: 180.00000733155, st: 0, bm: 0 }, { ddd: 0, ind: 2, ty: 4, nm: `Door Frame`, sr: 1, ks: { o: { a: 0, k: 100, ix: 11 }, r: { a: 0, k: 0, ix: 10 }, p: { a: 0, k: [400, 400, 0], ix: 2 }, a: { a: 0, k: [0, 0, 0], ix: 1 }, s: { a: 0, k: [100, 100, 100], ix: 6 } }, ao: 0, shapes: [{ ty: `gr`, it: [{ ty: `rc`, d: 1, s: { a: 0, k: [318.734, 568.188], ix: 2 }, p: { a: 0, k: [0, 0], ix: 3 }, r: { a: 0, k: 13, ix: 4 }, nm: `Rectangle Path 1`, mn: `ADBE Vector Shape - Rect`, hd: false }, { ty: `tm`, s: { a: 0, k: 0, ix: 1 }, e: { a: 1, k: [{ i: { x: [0.833], y: [0.603] }, o: { x: [0.167], y: [0.167] }, t: 35, s: [0] }, { t: 45.0000018328876, s: [42] }], ix: 2 }, o: { a: 0, k: -16, ix: 3 }, m: 1, ix: 2, nm: `Trim Paths 1`, mn: `ADBE Vector Filter - Trim`, hd: false }, { ty: `st`, c: { a: 0, k: [0.10196078431372549, 0.596078431372549, 0.8274509803921568, 1], ix: 3 }, o: { a: 0, k: 100, ix: 4 }, w: { a: 0, k: 11, ix: 5 }, lc: 2, lj: 2, bm: 0, nm: `Stroke 1`, mn: `ADBE Vector Graphic - Stroke`, hd: false }, { ty: `fl`, c: { a: 0, k: [0.929411768913, 0.929411768913, 0.929411768913, 1], ix: 4 }, o: { a: 0, k: 100, ix: 5 }, r: 1, bm: 0, nm: `Fill 1`, mn: `ADBE Vector Graphic - Fill`, hd: false }, { ty: `tr`, p: { a: 0, k: [-2.789, -4.383], ix: 2 }, a: { a: 0, k: [0, 0], ix: 1 }, s: { a: 0, k: [100, 100], ix: 3 }, r: { a: 0, k: 0, ix: 6 }, o: { a: 0, k: 100, ix: 7 }, sk: { a: 0, k: 0, ix: 4 }, sa: { a: 0, k: 0, ix: 5 }, nm: `Transform` }], nm: `Rectangle 2`, np: 4, cix: 2, bm: 0, ix: 1, mn: `ADBE Vector Group`, hd: false }, { ty: `gr`, it: [{ ty: `rc`, d: 1, s: { a: 0, k: [318.734, 568.188], ix: 2 }, p: { a: 0, k: [0, 0], ix: 3 }, r: { a: 0, k: 13, ix: 4 }, nm: `Rectangle Path 1`, mn: `ADBE Vector Shape - Rect`, hd: false }, { ty: `st`, c: { a: 0, k: [0.858823537827, 0.858823537827, 0.858823537827, 1], ix: 3 }, o: { a: 0, k: 100, ix: 4 }, w: { a: 0, k: 11, ix: 5 }, lc: 2, lj: 2, bm: 0, nm: `Stroke 1`, mn: `ADBE Vector Graphic - Stroke`, hd: false }, { ty: `fl`, c: { a: 0, k: [0.929411768913, 0.929411768913, 0.929411768913, 1], ix: 4 }, o: { a: 0, k: 100, ix: 5 }, r: 1, bm: 0, nm: `Fill 1`, mn: `ADBE Vector Graphic - Fill`, hd: false }, { ty: `tr`, p: { a: 0, k: [-2.789, -4.383], ix: 2 }, a: { a: 0, k: [0, 0], ix: 1 }, s: { a: 0, k: [100, 100], ix: 3 }, r: { a: 0, k: 0, ix: 6 }, o: { a: 0, k: 100, ix: 7 }, sk: { a: 0, k: 0, ix: 4 }, sa: { a: 0, k: 0, ix: 5 }, nm: `Transform` }], nm: `Rectangle 1`, np: 3, cix: 2, bm: 0, ix: 2, mn: `ADBE Vector Group`, hd: false }], ip: 0, op: 180.00000733155, st: 0, bm: 0 }], markers = [], animationDoor_default = { v, fr, ip: 0, op, w: 800, h: 800, nm, ddd: 0, assets, layers, markers }, DoorAnimation = (e) => {
  let [t, n] = __mf_38(false), r = __mf_37(null);
  return __mf_28(() => {
    n(e.open), r.current && (e.open ? (r.current.setDirection(1), r.current.goToAndStop(0, true), r.current.playSegments([0, 24], true)) : (r.current.setDirection(-1), r.current.goToAndStop(24, true), r.current.playSegments([24, 0], true)));
  }, [e.open]), __mf_1(import_index_umd.default, { animationData: animationDoor_default, onClick: () => n(!t), lottieRef: r, autoPlay: false, loop: false, style: { height: e.size || 120 } });
};
init__virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare__react__loadShare__();
function LockIcon(e) {
  return __mf_2(`svg`, { style: e.style, viewBox: `0 0 89 131`, xmlns: `http://www.w3.org/2000/svg`, children: [__mf_1(`path`, { className: e.className, opacity: `0.7`, fill: `currentColor`, d: `m46.37384,13.39542c16.2147,0.19436 29.4056,13.28938 29.6233,29.59748l0.2069,15.4986c0.0331,2.4851 -1.9545,4.5265 -4.4396,4.5597l0,0c-2.485,0.0332 -4.5265,-1.9545 -4.5596,-4.4395l-0.2069,-15.4987c-0.1548,-11.5969 -9.6815,-20.8726 -21.2784,-20.71781l-2.9998,0.04004c-11.5969,0.15479 -20.8726,9.68147 -20.71781,21.27837l0.20687,15.4987c0.03317,2.485 -1.95448,4.5264 -4.43954,4.5596l0,0c-2.48506,0.0332 -4.52649,-1.9545 -4.55966,-4.4395l-0.20687,-15.4986c-0.21767,-16.3082 12.61901,-29.7506 28.82271,-30.37767l0.7742,-0.0201l2.9998,-0.04004l0.7744,-0.00057z` }), __mf_1(`path`, { fill: `currentColor`, d: `m79,60c5.5228,0 10,4.47715 10,10l0,45.2002c-0.0001,8.8365 -7.1635,16 -16,16l-57,0c-8.83649,0 -15.99989,-7.1635 -16,-16l0,-45.2002c0,-5.52285 4.47715,-10 10,-10l69,0zm-34.5,22.25c-4.9152,0.0002 -8.9004,3.9852 -8.9004,8.9004c0.0002,3.2933 1.7911,6.166 4.4502,7.7051l0,11.4297c0.0001,2.7031 2.1915,4.8941 4.8945,4.8945c2.7034,0 4.8955,-2.1912 4.8955,-4.8945l0,-12.0157c2.1613,-1.6237 3.5595,-4.2078 3.5596,-7.1191c0,-4.9152 -3.9842,-8.9002 -8.8994,-8.9004z` })] });
}
export {
  Lock_default as a,
  LockOpen_default as i,
  DoorAnimation as n,
  MeetingRoom_default as r,
  LockIcon as t
};
