import { p as N, n as re, f as O, R as T, k as v, g as M, h as oe, i as ie, t as ce, r as ae, l as ue, m as k, __tla as __tla_0 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__prop_mf_2_types__loadShare__.js-DP_PH0VJ.js";
import { j as z, __tla as __tla_2 } from "./jsx-runtime-DTPVEbuR.js";
import { c as fe } from "./clsx-B-dksMZM.js";
import { c as Q, a as le, __tla as __tla_3 } from "./getColorSchemeSelector-S_MR5UAK.js";
import { i as me, __tla as __tla_4 } from "./capitalize-g-ksEjkR.js";
import { T as de, r as pe, c as ye, b as ge, g as he, __tla as __tla_5 } from "./createStyled-Cx7xtW-G.js";
let tt, je, et, nt, st, Pe, Ye, D, A, Se, I, Ie, ze, Qe, rt, ke, S, be;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  Se = function(e, t) {
    var _a, _b, _c;
    return N(e) && t.indexOf(e.type.muiName ?? ((_c = (_b = (_a = e.type) == null ? void 0 : _a._payload) == null ? void 0 : _b.value) == null ? void 0 : _c.muiName)) !== -1;
  };
  be = typeof window < "u" ? re : O;
  let E = 0;
  function _e(e) {
    const [t, n] = v(e), s = e || t;
    return O(() => {
      t == null && (E += 1, n(`mui-${E}`));
    }, [
      t
    ]), s;
  }
  const xe = {
    ...T
  }, C = xe.useId;
  et = function(e) {
    if (C !== void 0) {
      const t = C();
      return e ?? t;
    }
    return _e(e);
  };
  function we(e) {
    return Object.keys(e).length === 0;
  }
  I = function(e = null) {
    const t = M(de);
    return !t || we(t) ? e : t;
  };
  const L = oe();
  tt = function({ value: e, ...t }) {
    return z.jsx(L.Provider, {
      value: e ?? true,
      ...t
    });
  };
  let $e;
  nt = () => M(L) ?? false;
  $e = Q();
  A = function(e = $e) {
    return I(e);
  };
  const Ge = (e) => {
    var _a;
    const t = {
      systemProps: {},
      otherProps: {}
    }, n = ((_a = e == null ? void 0 : e.theme) == null ? void 0 : _a.unstable_sxConfig) ?? le;
    return Object.keys(e).forEach((s) => {
      n[s] ? t.systemProps[s] = e[s] : t.otherProps[s] = e[s];
    }), t;
  };
  Pe = function(e) {
    const { sx: t, ...n } = e, { systemProps: s, otherProps: o } = Ge(n);
    let r;
    return Array.isArray(t) ? r = [
      s,
      ...t
    ] : typeof t == "function" ? r = (...a) => {
      const c = t(...a);
      return me(c) ? {
        ...s,
        ...c
      } : s;
    } : r = {
      ...s,
      ...t
    }, {
      ...o,
      sx: r
    };
  };
  D = function(e) {
    const { theme: t, name: n, props: s } = e;
    return !t || !t.components || !t.components[n] || !t.components[n].defaultProps ? s : pe(t.components[n].defaultProps, s);
  };
  je = function({ props: e, name: t, defaultTheme: n, themeId: s }) {
    let o = A(n);
    return s && (o = o[s] || o), D({
      theme: o,
      name: t,
      props: e
    });
  };
  let Ee;
  ke = ye();
  Ee = (e, t) => e.filter((n) => t.includes(n));
  S = (e, t, n) => {
    const s = e.keys[0];
    Array.isArray(t) ? t.forEach((o, r) => {
      n((a, c) => {
        r <= e.keys.length - 1 && (r === 0 ? Object.assign(a, c) : a[e.up(e.keys[r])] = c);
      }, o);
    }) : t && typeof t == "object" ? (Object.keys(t).length > e.keys.length ? e.keys : Ee(e.keys, Object.keys(t))).forEach((r) => {
      if (e.keys.includes(r)) {
        const a = t[r];
        a !== void 0 && n((c, l) => {
          s === r ? Object.assign(c, l) : c[e.up(r)] = l;
        }, a);
      }
    }) : (typeof t == "number" || typeof t == "string") && n((o, r) => {
      Object.assign(o, r);
    }, t);
  };
  function b(e) {
    return `--Grid-${e}Spacing`;
  }
  function _(e) {
    return `--Grid-parent-${e}Spacing`;
  }
  let R, h, Ce, Re, Ne, Oe, Te, ve, Me;
  R = "--Grid-columns";
  h = "--Grid-parent-columns";
  Ce = ({ theme: e, ownerState: t }) => {
    const n = {};
    return S(e.breakpoints, t.size, (s, o) => {
      let r = {};
      o === "grow" && (r = {
        flexBasis: 0,
        flexGrow: 1,
        maxWidth: "100%"
      }), o === "auto" && (r = {
        flexBasis: "auto",
        flexGrow: 0,
        flexShrink: 0,
        maxWidth: "none",
        width: "auto"
      }), typeof o == "number" && (r = {
        flexGrow: 0,
        flexBasis: "auto",
        width: `calc(100% * ${o} / var(${h}) - (var(${h}) - ${o}) * (var(${_("column")}) / var(${h})))`
      }), s(n, r);
    }), n;
  };
  Re = ({ theme: e, ownerState: t }) => {
    const n = {};
    return S(e.breakpoints, t.offset, (s, o) => {
      let r = {};
      o === "auto" && (r = {
        marginLeft: "auto"
      }), typeof o == "number" && (r = {
        marginLeft: o === 0 ? "0px" : `calc(100% * ${o} / var(${h}) + var(${_("column")}) * ${o} / var(${h}))`
      }), s(n, r);
    }), n;
  };
  Ne = ({ theme: e, ownerState: t }) => {
    if (!t.container) return {};
    const n = {
      [R]: 12
    };
    return S(e.breakpoints, t.columns, (s, o) => {
      const r = o ?? 12;
      s(n, {
        [R]: r,
        "> *": {
          [h]: r
        }
      });
    }), n;
  };
  Oe = ({ theme: e, ownerState: t }) => {
    if (!t.container) return {};
    const n = {};
    return S(e.breakpoints, t.rowSpacing, (s, o) => {
      var _a;
      const r = typeof o == "string" ? o : (_a = e.spacing) == null ? void 0 : _a.call(e, o);
      s(n, {
        [b("row")]: r,
        "> *": {
          [_("row")]: r
        }
      });
    }), n;
  };
  Te = ({ theme: e, ownerState: t }) => {
    if (!t.container) return {};
    const n = {};
    return S(e.breakpoints, t.columnSpacing, (s, o) => {
      var _a;
      const r = typeof o == "string" ? o : (_a = e.spacing) == null ? void 0 : _a.call(e, o);
      s(n, {
        [b("column")]: r,
        "> *": {
          [_("column")]: r
        }
      });
    }), n;
  };
  ve = ({ theme: e, ownerState: t }) => {
    if (!t.container) return {};
    const n = {};
    return S(e.breakpoints, t.direction, (s, o) => {
      s(n, {
        flexDirection: o
      });
    }), n;
  };
  Me = ({ ownerState: e }) => ({
    minWidth: 0,
    boxSizing: "border-box",
    ...e.container && {
      display: "flex",
      flexWrap: "wrap",
      ...e.wrap && e.wrap !== "wrap" && {
        flexWrap: e.wrap
      },
      gap: `var(${b("row")}) var(${b("column")})`
    }
  });
  ze = (e) => {
    const t = [];
    return Object.entries(e).forEach(([n, s]) => {
      s !== false && s !== void 0 && t.push(`grid-${n}-${String(s)}`);
    }), t;
  };
  Qe = (e, t = "xs") => {
    function n(s) {
      return s === void 0 ? false : typeof s == "string" && !Number.isNaN(Number(s)) || typeof s == "number" && s > 0;
    }
    if (n(e)) return [
      `spacing-${t}-${String(e)}`
    ];
    if (typeof e == "object" && !Array.isArray(e)) {
      const s = [];
      return Object.entries(e).forEach(([o, r]) => {
        n(r) && s.push(`spacing-${o}-${String(r)}`);
      }), s;
    }
    return [];
  };
  Ie = (e) => e === void 0 ? [] : typeof e == "object" ? Object.entries(e).map(([t, n]) => `direction-${t}-${n}`) : [
    `direction-xs-${String(e)}`
  ];
  function Le(e, t) {
    e.item !== void 0 && delete e.item, e.zeroMinWidth !== void 0 && delete e.zeroMinWidth, t.keys.forEach((n) => {
      e[n] !== void 0 && delete e[n];
    });
  }
  const Ae = Q(), De = ke("div", {
    name: "MuiGrid",
    slot: "Root",
    overridesResolver: (e, t) => t.root
  });
  function Ue(e) {
    return je({
      props: e,
      name: "MuiGrid",
      defaultTheme: Ae
    });
  }
  st = function(e = {}) {
    const { createStyledComponent: t = De, useThemeProps: n = Ue, useTheme: s = A, componentName: o = "MuiGrid" } = e, r = (m, i) => {
      const { container: u, direction: d, spacing: p, wrap: f, size: x } = m, w = {
        root: [
          "root",
          u && "container",
          f !== "wrap" && `wrap-xs-${String(f)}`,
          ...Ie(d),
          ...ze(x),
          ...u ? Qe(p, i.breakpoints.keys[0]) : []
        ]
      };
      return ge(w, ($) => he(o, $), {});
    };
    function a(m, i, u = () => true) {
      const d = {};
      return m === null || (Array.isArray(m) ? m.forEach((p, f) => {
        p !== null && u(p) && i.keys[f] && (d[i.keys[f]] = p);
      }) : typeof m == "object" ? Object.keys(m).forEach((p) => {
        const f = m[p];
        f != null && u(f) && (d[p] = f);
      }) : d[i.keys[0]] = m), d;
    }
    const c = t(Ne, Te, Oe, Ce, ve, Me, Re), l = ie(function(i, u) {
      const d = s(), p = n(i), f = Pe(p);
      Le(f, d.breakpoints);
      const { className: x, children: w, columns: $ = 12, container: P = false, component: W = "div", direction: B = "row", wrap: K = "wrap", size: Y = {}, offset: F = {}, spacing: G = 0, rowSpacing: H = G, columnSpacing: J = G, unstable_level: g = 0, ...X } = f, Z = a(Y, d.breakpoints, (y) => y !== false), V = a(F, d.breakpoints), q = i.columns ?? (g ? void 0 : $), ee = i.spacing ?? (g ? void 0 : G), te = i.rowSpacing ?? i.spacing ?? (g ? void 0 : H), ne = i.columnSpacing ?? i.spacing ?? (g ? void 0 : J), j = {
        ...f,
        level: g,
        columns: q,
        container: P,
        direction: B,
        wrap: K,
        spacing: ee,
        rowSpacing: te,
        columnSpacing: ne,
        size: Z,
        offset: V
      }, se = r(j, d);
      return z.jsx(c, {
        ref: u,
        as: W,
        ownerState: j,
        className: fe(se.root, x),
        ...X,
        children: ce.map(w, (y) => {
          var _a;
          return N(y) && Se(y, [
            "Grid"
          ]) && P && y.props.container ? ae(y, {
            unstable_level: ((_a = y.props) == null ? void 0 : _a.unstable_level) ?? g + 1
          }) : y;
        })
      });
    });
    return l.muiName = "Grid", l;
  };
  function We(e, t, n, s, o) {
    const [r, a] = v(() => o && n ? n(e).matches : s ? s(e).matches : t);
    return be(() => {
      if (!n) return;
      const c = n(e), l = () => {
        a(c.matches);
      };
      return l(), c.addEventListener("change", l), () => {
        c.removeEventListener("change", l);
      };
    }, [
      e,
      n
    ]), r;
  }
  const Be = {
    ...T
  }, U = Be.useSyncExternalStore;
  function Ke(e, t, n, s, o) {
    const r = ue(() => t, [
      t
    ]), a = k(() => {
      if (o && n) return () => n(e).matches;
      if (s !== null) {
        const { matches: i } = s(e);
        return () => i;
      }
      return r;
    }, [
      r,
      e,
      s,
      o,
      n
    ]), [c, l] = k(() => {
      if (n === null) return [
        r,
        () => () => {
        }
      ];
      const i = n(e);
      return [
        () => i.matches,
        (u) => (i.addEventListener("change", u), () => {
          i.removeEventListener("change", u);
        })
      ];
    }, [
      r,
      n,
      e
    ]);
    return U(l, c, a);
  }
  Ye = function(e = {}) {
    const { themeId: t } = e;
    return function(s, o = {}) {
      let r = I();
      r && t && (r = r[t] || r);
      const a = typeof window < "u" && typeof window.matchMedia < "u", { defaultMatches: c = false, matchMedia: l = a ? window.matchMedia : null, ssrMatchMedia: m = null, noSsr: i = false } = D({
        name: "MuiUseMediaQuery",
        props: o,
        theme: r
      });
      let u = typeof s == "function" ? s(r) : s;
      return u = u.replace(/^@media( ?)/m, ""), u.includes("print") && console.warn([
        "MUI: You have provided a `print` query to the `useMediaQuery` hook.",
        "Using the print media query to modify print styles can lead to unexpected results.",
        "Consider using the `displayPrint` field in the `sx` prop instead.",
        "More information about `displayPrint` on our docs: https://mui.com/system/display/#display-in-print."
      ].join(`
`)), (U !== void 0 ? Ke : We)(u, c, l, m, i);
    };
  };
  rt = Ye();
});
export {
  tt as R,
  __tla,
  je as a,
  et as b,
  nt as c,
  st as d,
  Pe as e,
  Ye as f,
  D as g,
  A as h,
  Se as i,
  I as j,
  Ie as k,
  ze as l,
  Qe as m,
  rt as n,
  ke as s,
  S as t,
  be as u
};
