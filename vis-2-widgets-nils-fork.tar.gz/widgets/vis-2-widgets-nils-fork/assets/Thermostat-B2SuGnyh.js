import { j as e, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { C as A, __tla as __tla_1 } from "./index-DBUuV2Mq.js";
import { a as C, b as T, c as S, d as I, e as b, _ as O, f as J, g as H, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { a as k, b as L, c as P, d as R, e as z, _ as N, f as V, g as F, h as E, i as U, j as W, k as G, l as Y, m as q, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CpkBFb5h.js";
import { _ as K, __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CxgaxSjv.js";
import { O as Q, __tla as __tla_5 } from "./ObjectChart-DL9VOeto.js";
import { G as x } from "./Generic-DDdmRdK-.js";
import { __tla as __tla_6 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
import { __tla as __tla_7 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { __tla as __tla_8 } from "./installSVGRenderer-It2PVbYG.js";
import "./tslib.es6-BuLyYyFn.js";
let B;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })()
]).then(async () => {
  const w = {
    AUTO: e.jsx(q, {
      style: {
        width: 24,
        height: 24
      }
    }),
    MANUAL: e.jsx(Y, {
      style: {
        width: 24,
        height: 24
      }
    }),
    VACATION: e.jsx(G, {
      style: {
        width: 24,
        height: 24
      }
    }),
    COOL: e.jsx(W, {
      style: {
        width: 24,
        height: 24
      }
    }),
    COOLING: e.jsx(W, {
      style: {
        width: 24,
        height: 24
      }
    }),
    DRY: e.jsx(U, {
      style: {
        width: 24,
        height: 24
      }
    }),
    ECO: e.jsx(E, {
      style: {
        width: 24,
        height: 24
      }
    }),
    FAN_ONLY: e.jsx(F, {
      style: {
        width: 24,
        height: 24
      }
    }),
    HEAT: e.jsx(V, {
      style: {
        width: 24,
        height: 24
      }
    }),
    HEATING: e.jsx(V, {
      style: {
        width: 24,
        height: 24
      }
    }),
    OFF: e.jsx(z, {
      style: {
        width: 24,
        height: 24
      }
    })
  }, f = {
    thermostatCircleDiv: {
      width: "100%",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-end",
      "& svg circle": {
        cursor: "pointer"
      },
      "&>div": {
        margin: "auto",
        "&>div": {
          top: "35% !important"
        }
      }
    },
    moreButton: {
      position: "absolute",
      top: 4,
      right: 4
    },
    thermostatButtonsDiv: {
      textAlign: "center",
      display: "flex",
      justifyContent: "center",
      width: "100%",
      position: "absolute",
      bottom: 8,
      left: 0
    },
    thermostatNewValueLight: {
      animation: "vis-2-widgets-nils-fork-newValueAnimationLight 2s ease-in-out"
    },
    thermostatNewValueDark: {
      animation: "vis-2-widgets-nils-fork-newValueAnimationDark 2s ease-in-out"
    },
    thermostatDesiredTemp: {
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
      width: "100%",
      left: 0,
      transform: "none"
    },
    tooltip: {
      pointerEvents: "none"
    }
  };
  function $(M) {
    var _a;
    let i = (_a = M == null ? void 0 : M.common) == null ? void 0 : _a.states;
    if (Array.isArray(i)) {
      const r = {};
      i.forEach((d) => r[d] = d), i = r;
    }
    const t = [];
    return i && Object.keys(i).forEach((r) => {
      const d = {
        value: r,
        label: i[r]
      };
      d.icon = w[(i[r] || "").toUpperCase()], t.push(d);
    }), t.length ? t : null;
  }
  B = class extends x {
    lastRxData = "";
    customStyle = {};
    updateTimeout = null;
    constructor(i) {
      super(i), this.state = {
        ...this.state,
        showDialog: false,
        dialogTab: 0,
        size: 0,
        horizontal: false
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2Thermostat",
        visSet: "vis-2-widgets-nils-fork",
        visWidgetLabel: "thermostat",
        visName: "Thermostat",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                hidden: "!!data.externalDialog"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard || !!data.externalDialog"
              },
              {
                name: "oid-temp-set",
                type: "id",
                label: "temperature_oid",
                onChange: async (i, t, r, d) => {
                  var _a;
                  if (t[i.name] && ((_a = await d.getObject(t[i.name])) == null ? void 0 : _a.common)) {
                    const m = t[i.name].split(".");
                    m.pop();
                    const p = await d.getObjectViewSystem("state", `${m.join(".")}.`, `${m.join(".")}.\u9999`);
                    if (p) {
                      let a = false;
                      const y = Object.values(p);
                      for (const D of y) {
                        const l = D.common.role;
                        if (l && l.includes("value.temperature")) t["oid-temp-actual"] = D._id, a = true;
                        else if (l == null ? void 0 : l.includes("power")) t["oid-power"] = D._id, a = true;
                        else if (l == null ? void 0 : l.includes("boost")) t["oid-boost"] = D._id, a = true;
                        else if (l == null ? void 0 : l.includes("party")) t["oid-party"] = D._id, a = true;
                        else if (l == null ? void 0 : l.includes("mode")) {
                          const h = $(D);
                          if (h) {
                            for (let u = 0; u < h.length; u++) {
                              const v = h[u];
                              (!t[`title${u + 1}`] || u + 1 > t.count) && (a = true, t[`title${u + 1}`] = v.label), (!t[`value${u + 1}`] || u + 1 > t.count) && (t[`value${u + 1}`] = v.value, a = true);
                            }
                            t.count !== h.length && (a = true, t.count = h.length);
                          }
                          t["oid-mode"] = D._id, a = true;
                        }
                      }
                      a && r(t);
                    }
                  }
                }
              },
              {
                name: "oid-temp-actual",
                type: "id",
                label: "actual_oid"
              },
              {
                name: "oid-humidity",
                type: "id",
                label: "humidity_oid"
              },
              {
                name: "unit",
                label: "unit"
              },
              {
                name: "oid-power",
                type: "id",
                label: "power_oid"
              },
              {
                name: "oid-mode",
                type: "id",
                label: "mode_oid",
                onChange: async (i, t, r, d) => {
                  if (t[i.name]) {
                    const n = await d.getObject(t[i.name]), m = n ? $(n) : null;
                    if (m) {
                      let p = false;
                      m.forEach((a, y) => {
                        (!t[`title${y + 1}`] || y + 1 > t.count) && (p = true, t[`title${y + 1}`] = a.label), (!t[`value${y + 1}`] || y + 1 > t.count) && (t[`value${y + 1}`] = a.value, p = true);
                      }), t.count !== m.length && (p = true, t.count = m.length), p && r(t);
                    }
                  }
                }
              },
              {
                name: "oid-boost",
                type: "id",
                label: "mode_boost"
              },
              {
                name: "oid-party",
                type: "id",
                label: "mode_party"
              },
              {
                name: "step",
                type: "select",
                disabled: '!data["oid-temp-set"]',
                label: "step",
                noTranslation: true,
                options: [
                  "0.5",
                  "1"
                ],
                default: "1"
              },
              {
                name: "timeout",
                label: "controlTimeout",
                tooltip: "timeout_tooltip",
                type: "slider",
                min: 0,
                max: 2e3,
                default: 500
              },
              {
                name: "externalDialog",
                label: "use_as_dialog",
                type: "checkbox",
                tooltip: "use_as_dialog_tooltip"
              },
              {
                name: "count",
                type: "slider",
                min: 1,
                max: 9,
                label: "modes_count",
                default: 2,
                hidden: '!data["oid-mode"]'
              }
            ]
          },
          {
            name: "modes",
            label: "group_modes",
            indexFrom: 1,
            indexTo: "count",
            hidden: '!data["oid-mode"]',
            fields: [
              {
                name: "hide",
                type: "checkbox",
                label: "hide",
                noBinding: false
              },
              {
                name: "title",
                label: "title",
                hidden: 'data["hide" + index] === true'
              },
              {
                name: "tooltip",
                label: "tooltip",
                hidden: 'data["hide" + index] === true || !!data["title" + index]'
              },
              {
                name: "icon",
                type: "image",
                label: "icon",
                hidden: 'data["hide" + index] === true || !!data["iconSmall" + index]'
              },
              {
                name: "iconSmall",
                type: "icon64",
                label: "small_icon",
                hidden: 'data["hide" + index] === true || !!data["icon" + index]'
              },
              {
                name: "color",
                type: "color",
                label: "color",
                hidden: 'data["hide" + index] === true'
              },
              {
                name: "noText",
                type: "checkbox",
                label: "no_text",
                noBinding: false,
                hidden: 'data["hide" + index] === true || data["noIcon" + index] === true'
              },
              {
                name: "noIcon",
                type: "checkbox",
                label: "no_icon",
                noBinding: false,
                hidden: 'data["hide" + index] === true || data["noText" + index] === true || !data["title" + index]'
              },
              {
                name: "value",
                type: "text",
                label: "value",
                hidden: 'data["hide" + index] === true'
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_thermostat.png"
      };
    }
    async thermostatReadObjects() {
      var _a, _b, _c, _d;
      const i = JSON.stringify(this.state.rxData);
      if (this.lastRxData === i) return;
      const t = {};
      this.lastRxData = i;
      const r = [];
      this.state.rxData["oid-mode"] && this.state.rxData["oid-mode"] !== "nothing_selected" && r.push(this.state.rxData["oid-mode"]), this.state.rxData["oid-temp-set"] && this.state.rxData["oid-temp-set"] !== "nothing_selected" && r.push(this.state.rxData["oid-temp-set"]), this.state.rxData["oid-temp-actual"] && this.state.rxData["oid-temp-actual"] !== "nothing_selected" && r.push(this.state.rxData["oid-temp-actual"]), this.state.rxData["oid-humidity"] && this.state.rxData["oid-humidity"] !== "nothing_selected" && r.push(this.state.rxData["oid-humidity"]);
      const d = r.length ? await this.props.context.socket.getObjectsById(r) : {};
      if (this.state.rxData["oid-mode"] && this.state.rxData["oid-mode"] !== "nothing_selected") {
        const a = d[this.state.rxData["oid-mode"]];
        if (a) {
          t.modeObject = {
            common: a.common,
            _id: a._id
          };
          const y = $(a);
          t.modes = [];
          const D = parseInt(this.state.rxData.count, 10) || 10;
          y == null ? void 0 : y.forEach((l, h) => {
            if (this.state.rxData[`hide${h + 1}`] === true || this.state.rxData[`hide${h + 1}`] === "true" || h >= D) return;
            const u = this.state.rxData[`noIcon${h + 1}`] !== true && this.state.rxData[`noIcon${h + 1}`] !== "true" ? this.state.rxData[`icon${h + 1}`] || this.state.rxData[`iconSmall${h + 1}`] || !!w[(l.label || "").toUpperCase()] : void 0, v = {
              value: this.state.rxData[`value${h + 1}`] || l.value,
              tooltip: this.state.rxData[`tooltip${h + 1}`] || l.label,
              icon: u,
              original: l.label,
              label: u && (this.state.rxData[`noText${h + 1}`] === true || this.state.rxData[`noText${h + 1}`] === "true") ? null : this.state.rxData[`title${h + 1}`] || l.label,
              color: this.state.rxData[`color${h + 1}`]
            };
            v.label && !(this.state.rxData[`noText${h + 1}`] === true || this.state.rxData[`noText${h + 1}`] === "true") && v.icon === true && !this.state.rxData[`title${h + 1}`] && (v.label = null), t.modes.push(v);
          });
          for (let l = (y == null ? void 0 : y.length) || 0; l < D; l++) {
            if (this.state.rxData[`hide${l + 1}`] === true || this.state.rxData[`hide${l + 1}`] === "true") continue;
            const h = this.state.rxData[`noIcon${l + 1}`] !== true && this.state.rxData[`noIcon${l + 1}`] !== "true" ? this.state.rxData[`icon${l + 1}`] || this.state.rxData[`iconSmall${l + 1}`] || !!w[(this.state.rxData[`title${l + 1}`] || "").toUpperCase()] : void 0;
            t.modes.push({
              tooltip: this.state.rxData[`tooltip${l + 1}`],
              icon: h,
              original: this.state.rxData[`title${l + 1}`],
              label: h && (this.state.rxData[`noText${l + 1}`] === true || this.state.rxData[`noText${l + 1}`] === "true") ? null : this.state.rxData[`title${l + 1}`],
              value: this.state.rxData[`value${l + 1}`],
              color: this.state.rxData[`color${l + 1}`]
            });
          }
        } else t.modes = null;
      } else t.modes = null;
      if (this.state.rxData["oid-temp-set"] && this.state.rxData["oid-temp-set"] !== "nothing_selected") {
        const a = d[this.state.rxData["oid-temp-set"]];
        t.min = ((_a = a == null ? void 0 : a.common) == null ? void 0 : _a.min) === void 0 ? 12 : a.common.min, t.max = ((_b = a == null ? void 0 : a.common) == null ? void 0 : _b.max) === void 0 ? 30 : a.common.max, t.tempObject = {
          common: a.common,
          _id: a._id
        };
      } else t.tempObject = null, t.max = null, t.min = null;
      if (this.state.rxData["oid-temp-actual"] && this.state.rxData["oid-temp-actual"] !== "nothing_selected") {
        const a = d[this.state.rxData["oid-temp-actual"]];
        t.tempStateObject = {
          common: a.common,
          _id: a._id
        };
      } else t.tempStateObject = null;
      if (this.state.rxData["oid-humidity"] && this.state.rxData["oid-humidity"] !== "nothing_selected") {
        const a = d[this.state.rxData["oid-humidity"]];
        t.humidityObject = a ? {
          common: a.common,
          _id: a._id
        } : null;
      } else t.humidityObject = null;
      const n = (_d = (_c = this.props.context.systemConfig) == null ? void 0 : _c.common) == null ? void 0 : _d.defaultHistory, m = x.getHistoryInstance(t.tempObject, n), p = x.getHistoryInstance(t.tempStateObject, n);
      t.isChart = !!m || !!p, Object.keys(t).find((a) => JSON.stringify(this.state[a]) !== JSON.stringify(t[a])) && this.setState(t);
    }
    async componentDidMount() {
      super.componentDidMount(), await this.thermostatReadObjects();
    }
    async onRxDataChanged() {
      await this.thermostatReadObjects();
    }
    getWidgetInfo() {
      return B.getWidgetInfo();
    }
    formatValue(i, t) {
      var _a;
      return typeof i == "number" && (t === 0 ? i = Math.round(i) : i = Math.round(i * 100) / 100, ((_a = this.props.context.systemConfig) == null ? void 0 : _a.common) && this.props.context.systemConfig.common.isFloatComma && (i = i.toString().replace(".", ","))), i == null ? "" : i.toString();
    }
    renderChartDialog() {
      var _a, _b, _c, _d;
      return this.state.showDialog ? e.jsxs(C, {
        sx: {
          "& .MuiDialog-paper": {
            height: "100%"
          }
        },
        maxWidth: "lg",
        fullWidth: true,
        open: true,
        onClose: () => this.setState({
          showDialog: false
        }),
        children: [
          e.jsxs(T, {
            children: [
              this.state.rxData.widgetTitle,
              e.jsx(S, {
                style: {
                  float: "right"
                },
                onClick: () => this.setState({
                  showDialog: false
                }),
                children: e.jsx(k, {})
              })
            ]
          }),
          e.jsx(I, {
            children: this.state.dialogTab === 1 && e.jsx("div", {
              style: {
                height: "100%"
              },
              children: e.jsx(Q, {
                t: (i) => x.t(i),
                lang: x.getLanguage(),
                socket: this.props.context.socket,
                obj: this.state.tempStateObject || this.state.tempObject,
                obj2: this.state.tempStateObject ? this.state.tempObject : null,
                objLineType: this.state.tempStateObject ? "line" : "step",
                obj2LineType: "step",
                themeType: this.props.context.themeType,
                historyInstance: x.getHistoryInstance(this.state.tempStateObject || this.state.tempObject, ((_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory) || "history.0"),
                historyInstance2: x.getHistoryInstance(this.state.tempStateObject, ((_d = (_c = this.props.context.systemConfig) == null ? void 0 : _c.common) == null ? void 0 : _d.defaultHistory) || "history.0"),
                noToolbar: false,
                systemConfig: this.props.context.systemConfig,
                dateFormat: this.props.context.systemConfig.common.dateFormat
              })
            })
          })
        ]
      }) : null;
    }
    componentDidUpdate(i, t) {
      var _a;
      if (super.componentDidUpdate(i, t), (_a = this.refService) == null ? void 0 : _a.current) {
        let r = this.refService.current.clientWidth, d = this.refService.current.clientHeight, n = r;
        const m = this.props.context.views[this.props.view].widgets[this.props.id];
        !this.state.rxData.noCard && !m.usedInWidget && (d -= 32, r -= 32);
        const p = this.state.rxData.widgetTitle && !this.state.rxData.noCard && !m.usedInWidget, a = this.thermIsWithModeButtons() || this.thermIsWithPowerButton();
        p && a ? d -= 64 : p ? d -= 36 : a && (d -= 28), d < 0 && (d = 0), r > d ? n = d : n = r, n < 80 && (n = 0), n !== this.state.size && this.setState({
          size: n
        });
      }
    }
    thermIsWithPowerButton() {
      return !!this.state.rxData["oid-power"] && this.state.rxData["oid-power"] !== "nothing_selected";
    }
    thermIsWithModeButtons() {
      var _a;
      return (((_a = this.state.modes) == null ? void 0 : _a.length) || this.state.rxData["oid-party"] || this.state.rxData["oid-boost"]) && (!this.state.rxData["oid-power"] || this.state.values[`${this.state.rxData["oid-power"]}.val`]);
    }
    onCommand(i) {
      const t = super.onCommand(i);
      if (t === false) {
        if (i === "openDialog") return this.setState({
          dialog: true
        }), true;
        if (i === "closeDialog") return this.setState({
          dialog: false
        }), true;
      }
      return t;
    }
    renderWidgetBody(i) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q;
      super.renderWidgetBody(i), this.customStyle = {}, this.state.rxStyle && (this.state.rxStyle["font-weight"] && (this.customStyle.fontWeight = this.state.rxStyle["font-weight"]), this.state.rxStyle["font-size"] && (this.customStyle.fontSize = this.state.rxStyle["font-size"]), this.state.rxStyle["font-family"] && (this.customStyle.fontFamily = this.state.rxStyle["font-family"]), this.state.rxStyle["font-style"] && (this.customStyle.fontStyle = this.state.rxStyle["font-style"]), this.state.rxStyle["word-spacing"] && (this.customStyle.wordSpacing = this.state.rxStyle["word-spacing"]), this.state.rxStyle["letter-spacing"] && (this.customStyle.letterSpacing = this.state.rxStyle["letter-spacing"]));
      const t = !this.state.rxData.noCard && !i.widget.usedInWidget, r = this.state.rxData.widgetTitle && t, d = JSON.stringify(this.state.rxData);
      this.lastRxData !== d && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
        this.updateTimeout = null, await this.thermostatReadObjects();
      }, 50)));
      let n = this.state.values[`${this.state.rxData["oid-temp-set"]}.val`];
      n === void 0 && (n = null), n !== null && (this.state.min === null || this.state.min === void 0 || n < this.state.min) ? n = this.state.min : n !== null && (this.state.max === null || this.state.max === void 0 || n > this.state.max) && (n = this.state.max), n === null && this.state.min !== null && this.state.min !== void 0 && this.state.max !== null && this.state.max !== void 0 && (n = (this.state.max - this.state.min) / 2 + this.state.min);
      let m = this.state.values[`${this.state.rxData["oid-temp-actual"]}.val`];
      m === void 0 && (m = null);
      const p = this.state.values[`${this.state.rxData["oid-humidity"]}.val`];
      let a = Math.round(this.state.size / 25);
      a < 8 && (a = 8);
      const y = this.state.isChart ? e.jsx(S, {
        style: {
          ...r ? void 0 : f.moreButton,
          right: this.state.rxData.externalDialog || r ? void 0 : 4,
          left: this.state.rxData.externalDialog ? 16 : void 0,
          top: this.state.rxData.externalDialog ? 16 : r ? void 0 : 4,
          zIndex: 2
        },
        onClick: () => this.setState({
          showDialog: true
        }),
        children: e.jsx(L, {})
      }) : null;
      m = m !== null ? this.formatValue(m) : null;
      const D = this.thermIsWithModeButtons(), l = this.thermIsWithPowerButton(), h = ((_e = (_d = (_c = (_b = (_a = this.props.customSettings) == null ? void 0 : _a.viewStyle) == null ? void 0 : _b.overrides) == null ? void 0 : _c.palette) == null ? void 0 : _d.primary) == null ? void 0 : _e.main) || ((_f = this.props.context.theme) == null ? void 0 : _f.palette.primary.main) || "#448aff";
      let u = [];
      if (D) {
        if (((_g = this.state.modes) == null ? void 0 : _g.length) && (u = this.state.modes.map((s, o) => {
          const g = s.icon === true ? w[(s.original || "").toUpperCase()] : s.icon ? e.jsx(K, {
            src: s.icon,
            style: {
              width: 24,
              height: 24
            }
          }) : null;
          let _ = this.state.values[`${this.state.rxData["oid-mode"]}.val`];
          return _ == null ? _ = "null" : _ = _.toString(), g && !s.label ? e.jsx(b, {
            title: s.tooltip,
            slotProps: {
              popper: {
                sx: f.tooltip
              }
            },
            children: e.jsx(S, {
              color: _ === s.value ? "primary" : "inherit",
              style: _ === s.value || !s.color ? void 0 : {
                color: s.color
              },
              onClick: () => {
                var _a2, _b2, _c2, _d2;
                let c = s.value;
                ((_b2 = (_a2 = this.state.modeObject) == null ? void 0 : _a2.common) == null ? void 0 : _b2.type) === "number" ? c = parseFloat(c) : ((_d2 = (_c2 = this.state.modeObject) == null ? void 0 : _c2.common) == null ? void 0 : _d2.type) === "boolean" && (c = c === "true" || c === true || c === "1" || c === 1);
                const j = JSON.parse(JSON.stringify(this.state.values));
                j[`${this.state.rxData["oid-mode"]}.val`] = c, this.setState({
                  values: j
                }), this.props.context.setValue(this.state.rxData["oid-mode"], c);
              },
              children: g
            })
          }, `${o}_${s.value}`) : e.jsx(O, {
            color: _ === s.value ? "primary" : "inherit",
            onClick: () => {
              var _a2, _b2, _c2, _d2;
              let c = s.value;
              ((_b2 = (_a2 = this.state.modeObject) == null ? void 0 : _a2.common) == null ? void 0 : _b2.type) === "number" ? c = parseFloat(c) : ((_d2 = (_c2 = this.state.modeObject) == null ? void 0 : _c2.common) == null ? void 0 : _d2.type) === "boolean" && (c = c === "true" || c === true || c === "1" || c === 1);
              const j = JSON.parse(JSON.stringify(this.state.values));
              j[`${this.state.rxData["oid-mode"]}.val`] = c, this.setState({
                values: j
              }), this.props.context.setValue(this.state.rxData["oid-mode"], c);
            },
            startIcon: g,
            children: s.label
          }, `${o}_${s.value}`);
        })), this.state.rxData["oid-party"]) {
          let s = this.state.values[`${this.state.rxData["oid-party"]}.val`];
          s == null ? s = false : s = s === "1" || s === "true" || s === true, u.push(e.jsx(O, {
            color: s ? "primary" : "inherit",
            onClick: () => {
              let o = this.state.values[`${this.state.rxData["oid-party"]}.val`];
              o == null ? o = false : o = o === "1" || o === "true" || o === true;
              const g = JSON.parse(JSON.stringify(this.state.values));
              g[`${this.state.rxData["oid-party"]}.val`] = !o, this.setState({
                values: g
              }), this.props.context.setValue(this.state.rxData["oid-party"], !o);
            },
            startIcon: e.jsx(P, {}),
            children: x.t("Party")
          }, "party"));
        }
        if (this.state.rxData["oid-boost"]) {
          let s = this.state.values[`${this.state.rxData["oid-boost"]}.val`];
          s == null ? s = false : s = s === "1" || s === "true" || s === true, u.push(e.jsx(O, {
            color: s ? "primary" : "inherit",
            onClick: () => {
              let o = this.state.values[`${this.state.rxData["oid-boost"]}.val`];
              o == null ? o = false : o = o === "1" || o === "true" || o === true;
              const g = JSON.parse(JSON.stringify(this.state.values));
              g[`${this.state.rxData["oid-boost"]}.val`] = !o, this.setState({
                values: g
              }), this.props.context.setValue(this.state.rxData["oid-boost"], !o);
            },
            startIcon: e.jsx(R, {}),
            children: x.t("Boost")
          }, "boost"));
        }
      }
      l && u.push(e.jsx(b, {
        title: x.t("power").replace("vis_2_widgets_nils_", ""),
        slotProps: {
          popper: {
            sx: f.tooltip
          }
        },
        children: e.jsx(S, {
          color: this.state.values[`${this.state.rxData["oid-power"]}.val`] ? "primary" : "inherit",
          onClick: () => {
            const s = JSON.parse(JSON.stringify(this.state.values)), o = `${this.state.rxData["oid-power"]}.val`;
            s[o] = !s[o], this.setState({
              values: s
            }), this.props.context.setValue(this.state.rxData["oid-power"], s[o]);
          },
          children: e.jsx(z, {})
        })
      }, "power"));
      const v = e.jsxs(J, {
        component: "div",
        sx: f.thermostatCircleDiv,
        style: {
          height: r ? "calc(100% - 36px)" : "100%"
        },
        children: [
          e.jsx("style", {
            children: `
@keyframes vis-2-widgets-nils-fork-newValueAnimationLight {
    0% {
        color: #00bd00;
    },
    80% {
        color: #008000;
    },
    100% {
        color: #000;
    }
}

@keyframes vis-2-widgets-nils-fork-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: #ffffff;
    }
}                          
                            `
          }),
          r ? null : y,
          this.state.size && this.state.tempObject ? e.jsxs(A, {
            minValue: this.state.min === null || this.state.min === void 0 ? 12 : this.state.min,
            maxValue: this.state.max === null || this.state.max === void 0 ? 30 : this.state.max,
            size: this.state.size,
            arcColor: h,
            arcBackgroundColor: this.props.context.themeType === "dark" ? "#DDD" : "#222",
            startAngle: 40,
            handleSize: a,
            endAngle: 320,
            handle1: {
              value: n,
              onChange: (s) => {
                const o = JSON.parse(JSON.stringify(this.state.values));
                this.state.rxData.step === "0.5" ? o[`${this.state.rxData["oid-temp-set"]}.val`] = Math.round(s * 2) / 2 : o[`${this.state.rxData["oid-temp-set"]}.val`] = Math.round(s), this.setState({
                  values: o
                });
              }
            },
            onControlFinished: () => this.props.context.setValue(this.state.rxData["oid-temp-set"], this.state.values[`${this.state.rxData["oid-temp-set"]}.val`]),
            children: [
              n !== null ? e.jsx(b, {
                title: x.t("desired_temperature"),
                slotProps: {
                  popper: {
                    sx: f.tooltip
                  }
                },
                children: e.jsxs("div", {
                  style: {
                    ...f.thermostatDesiredTemp,
                    fontSize: Math.round(this.state.size / 6),
                    ...this.customStyle
                  },
                  children: [
                    e.jsx(N, {
                      style: {
                        width: this.state.size / 8,
                        height: this.state.size / 8
                      }
                    }),
                    e.jsxs("div", {
                      style: {
                        display: "flex",
                        alignItems: "top",
                        ...this.customStyle
                      },
                      children: [
                        this.formatValue(n),
                        e.jsx("span", {
                          style: {
                            fontSize: Math.round(this.state.size / 12),
                            fontWeight: "normal"
                          },
                          children: this.state.rxData.unit || ((_i = (_h = this.state.tempObject) == null ? void 0 : _h.common) == null ? void 0 : _i.unit)
                        })
                      ]
                    })
                  ]
                })
              }) : null,
              m !== null ? e.jsx(b, {
                title: x.t("actual_temperature"),
                slotProps: {
                  popper: {
                    sx: f.tooltip
                  }
                },
                children: e.jsxs("div", {
                  style: {
                    ...this.props.context.themeType === "dark" ? f.thermostatNewValueDark : f.thermostatNewValueLight,
                    fontSize: Math.round(this.state.size * 0.6 / 6),
                    opacity: 0.7,
                    ...this.customStyle
                  },
                  children: [
                    m,
                    this.state.rxData.unit || ((_k = (_j = this.state.tempStateObject) == null ? void 0 : _j.common) == null ? void 0 : _k.unit)
                  ]
                }, `${m}valText`)
              }) : null
            ]
          }) : this.state.tempObject ? e.jsxs("div", {
            style: {
              width: "100%"
            },
            children: [
              e.jsx(H, {
                style: {
                  width: "calc(100% - 50px)",
                  display: "inline-block"
                },
                min: this.state.min === null || this.state.min === void 0 ? 12 : this.state.min,
                max: this.state.max === null || this.state.max === void 0 ? 30 : this.state.max,
                step: this.state.step || 0.5,
                value: n,
                valueLabelDisplay: "auto",
                onChange: (s, o) => {
                  const g = JSON.parse(JSON.stringify(this.state.values));
                  this.state.rxData.step === "0.5" ? g[`${this.state.rxData["oid-temp-set"]}.val`] = Math.round(o * 2) / 2 : g[`${this.state.rxData["oid-temp-set"]}.val`] = Math.round(o), this.setState({
                    values: g
                  });
                },
                onChangeCommitted: () => this.props.context.setValue(this.state.rxData["oid-temp-set"], this.state.values[`${this.state.rxData["oid-temp-set"]}.val`])
              }),
              e.jsxs("div", {
                style: {
                  textAlign: "center",
                  display: "inline-block",
                  flexDirection: "column",
                  width: 50
                },
                children: [
                  n !== null ? e.jsx(b, {
                    title: x.t("desired_temperature"),
                    slotProps: {
                      popper: {
                        sx: f.tooltip
                      }
                    },
                    children: e.jsxs("div", {
                      style: {
                        ...f.thermostatDesiredTemp,
                        fontSize: 12,
                        ...this.customStyle
                      },
                      children: [
                        e.jsx(N, {
                          style: {
                            width: 24,
                            height: 24
                          }
                        }),
                        e.jsxs("div", {
                          style: {
                            display: "flex",
                            alignItems: "top",
                            ...this.customStyle
                          },
                          children: [
                            this.formatValue(n),
                            e.jsx("span", {
                              style: {
                                fontSize: 10,
                                fontWeight: "normal"
                              },
                              children: this.state.rxData.unit || ((_m = (_l = this.state.tempObject) == null ? void 0 : _l.common) == null ? void 0 : _m.unit)
                            })
                          ]
                        })
                      ]
                    })
                  }) : null,
                  m !== null ? e.jsx(b, {
                    title: x.t("actual_temperature"),
                    slotProps: {
                      popper: {
                        sx: f.tooltip
                      }
                    },
                    children: e.jsxs("div", {
                      style: {
                        ...this.props.context.themeType === "dark" ? f.thermostatNewValueDark : f.thermostatNewValueLight,
                        fontSize: Math.round(10),
                        opacity: 0.7,
                        ...this.customStyle
                      },
                      children: [
                        m,
                        this.state.rxData.unit || ((_o = (_n = this.state.tempStateObject) == null ? void 0 : _n.common) == null ? void 0 : _o.unit)
                      ]
                    }, `${m}valText`)
                  }) : null
                ]
              })
            ]
          }) : null,
          this.state.rxData["oid-humidity"] && this.state.rxData["oid-humidity"] !== "nothing_selected" ? e.jsx(b, {
            title: x.t("humidity"),
            slotProps: {
              popper: {
                sx: f.tooltip
              }
            },
            children: e.jsx("div", {
              style: {
                textAlign: "center",
                opacity: 0.7,
                ...this.customStyle
              },
              children: p == null ? x.t("humidity") : `${this.formatValue(p)}${((_q = (_p = this.state.humidityObject) == null ? void 0 : _p.common) == null ? void 0 : _q.unit) || "%"}`
            })
          }) : null,
          e.jsx("div", {
            style: {
              ...f.thermostatButtonsDiv,
              bottom: 8
            },
            children: u
          }),
          this.renderChartDialog()
        ]
      });
      return this.state.rxData.externalDialog && !this.props.editMode ? this.state.dialog ? e.jsxs(C, {
        open: true,
        onClose: () => this.setState({
          dialog: false
        }),
        children: [
          e.jsxs(T, {
            children: [
              this.state.rxData.widgetTitle,
              e.jsx(S, {
                style: {
                  float: "right",
                  zIndex: 2
                },
                onClick: () => this.setState({
                  dialog: false
                }),
                children: e.jsx(k, {})
              })
            ]
          }),
          e.jsx(I, {
            style: {
              minWidth: 150,
              minHeight: 150
            },
            children: v
          })
        ]
      }) : null : t ? this.wrapContent(v, r ? y : null, {
        textAlign: "center"
      }) : v;
    }
  };
});
export {
  __tla,
  B as default
};
