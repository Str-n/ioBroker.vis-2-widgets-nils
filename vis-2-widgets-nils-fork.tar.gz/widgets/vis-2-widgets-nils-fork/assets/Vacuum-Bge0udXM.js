import { B as e } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as t, H as n, I as r, J as i, L as a, O as o, P as s, T as c, Y as l, ft as u, k as d, n as f, pt as p, st as m, u as h } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as g } from "./Generic-BOiMPpxz.js";
var _ = m(u(`path`, { d: `M15.67 4H14V2h-4v2H8.33C7.6 4 7 4.6 7 5.33v15.33C7 21.4 7.6 22 8.33 22h7.33c.74 0 1.34-.6 1.34-1.33V5.33C17 4.6 16.4 4 15.67 4M11 20v-5.5H9L13 7v5.5h2z` }), `BatteryChargingFull`), v = m(u(`path`, { d: `M15.67 4H14V2h-4v2H8.33C7.6 4 7 4.6 7 5.33v15.33C7 21.4 7.6 22 8.33 22h7.33c.74 0 1.34-.6 1.34-1.33V5.33C17 4.6 16.4 4 15.67 4` }), `BatteryFull`), y = m(u(`path`, { d: `M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z` }), `Home`), b = m(u(`path`, { d: `M6 19h4V5H6zm8-14v14h4V5z` }), `Pause`), x = m(u(`path`, { d: `M8 5v14l11-7z` }), `PlayArrow`);
e();
function S(e3) {
  return p(`svg`, { viewBox: `0 0 360 360`, xmlns: `http://www.w3.org/2000/svg`, style: e3.style, children: [u(`path`, { fill: `currentColor`, d: `M 330.46 100.64 Q 351.46 139.72 350.97 184.28 Q 350.96 185.00 350.24 185.00 L 347.50 185.00 Q 347.00 185.00 347.00 185.50 L 347.00 193.37 Q 347.00 194.00 347.63 194.00 L 349.80 194.00 Q 350.47 194.00 350.42 194.67 C 344.01 276.68 279.41 342.29 198.02 350.15 C 102.00 359.42 18.58 287.54 12.39 191.62 Q 12.35 191.00 12.97 191.00 L 14.47 191.00 Q 15.01 191.00 15.01 190.46 L 15.00 183.62 Q 14.99 183.00 14.37 183.00 L 12.53 183.00 Q 12.09 183.00 12.09 182.56 C 11.80 95.69 76.68 22.25 163.51 13.11 C 223.60 6.78 281.26 32.21 317.43 80.29 A 0.42 0.42 0.0 0 0 318.16 80.17 L 323.63 63.55 A 0.53 0.52 17.9 0 1 324.29 63.22 L 328.97 64.78 Q 329.56 64.98 329.37 65.57 L 322.36 86.46 Q 322.19 86.97 322.48 87.43 L 326.10 93.06 Q 326.39 93.51 326.93 93.58 L 348.86 96.52 Q 349.39 96.59 349.32 97.12 L 348.69 101.93 Q 348.61 102.54 348.01 102.46 L 330.81 100.13 Q 330.13 100.04 330.46 100.64 Z M 212.79 184.77 C 182.63 212.40 133.76 194.13 129.34 153.02 Q 129.28 152.50 128.76 152.50 L 21.03 152.50 A 0.53 0.52 4.5 0 0 20.51 152.94 C 1.62 261.25 92.99 357.54 201.51 343.78 C 277.79 334.11 337.83 272.59 344.40 195.57 C 355.70 63.05 212.90 -26.21 98.05 41.00 C 59.13 63.78 32.69 101.49 21.88 145.42 Q 21.61 146.50 22.72 146.50 L 128.46 146.50 Q 128.90 146.50 128.94 146.07 Q 131.26 119.63 151.75 106.22 C 184.91 84.50 226.66 107.87 228.98 146.00 Q 229.01 146.50 229.51 146.50 L 337.25 146.50 Q 338.00 146.50 338.00 147.25 L 338.00 151.75 Q 338.00 152.50 337.25 152.50 L 229.25 152.50 Q 228.75 152.50 228.69 153.00 Q 226.50 172.21 212.79 184.77 Z M 222.95 148.00 A 43.95 43.95 0.0 0 0 179.00 104.05 A 43.95 43.95 0.0 0 0 135.05 148.00 A 43.95 43.95 0.0 0 0 179.00 191.95 A 43.95 43.95 0.0 0 0 222.95 148.00 Z` }), u(`path`, { fill: `#a0a0a0`, d: ` M 234.86 54.37 Q 237.06 56.61 233.37 58.52 A 2.80 2.79 44.2 0 1 230.87 58.55 Q 178.34 32.73 126.63 59.92 A 2.35 2.35 0.0 0 1 123.30 58.57 Q 122.82 57.10 123.23 55.66 Q 123.37 55.14 123.84 54.88 C 157.72 35.70 198.72 35.20 233.14 53.20 Q 234.31 53.81 234.86 54.37 Z` }), u(`path`, { fill: `currentColor`, d: ` M 153.81 56.69 Q 155.34 56.33 156.14 55.70 A 1.12 1.09 -58.9 0 1 157.01 55.47 Q 159.34 55.82 161.29 54.58 A 1.24 1.22 -55.7 0 1 162.15 54.41 C 165.00 54.94 166.83 53.51 169.29 53.51 Q 178.97 53.49 188.64 53.50 C 191.13 53.51 193.05 54.90 195.91 54.44 Q 196.47 54.36 196.95 54.65 Q 198.86 55.80 201.11 55.49 Q 201.63 55.42 202.03 55.76 C 203.10 56.70 204.44 56.54 205.63 57.07 Q 209.27 58.70 211.98 61.56 Q 212.37 61.97 212.42 62.53 L 212.75 66.42 A 1.23 1.18 -31.8 0 1 212.55 67.20 L 209.96 71.11 Q 209.71 71.50 209.25 71.50 L 193.25 71.50 A 0.50 0.50 0.0 0 1 192.75 70.99 Q 192.75 70.80 192.75 70.61 Q 192.74 70.16 192.29 70.17 L 148.62 71.47 Q 148.05 71.48 147.86 70.95 C 146.80 68.02 144.00 63.58 146.73 60.83 Q 149.97 57.58 153.81 56.69 Z M 187.04 56.93 Q 178.43 55.86 169.96 57.11 Q 169.43 57.18 169.42 57.72 Q 169.37 59.98 170.21 62.04 Q 170.38 62.47 170.41 62.93 L 170.67 66.86 Q 170.71 67.50 171.35 67.50 L 186.25 67.50 A 1.32 1.31 86.2 0 0 187.55 66.01 Q 187.12 62.74 188.59 59.88 A 2.03 2.03 0.0 0 0 187.04 56.93 Z M 167.55 67.30 A 0.31 0.30 -13.3 0 0 167.80 66.90 Q 166.45 62.88 166.42 58.72 Q 166.41 57.32 165.02 57.42 C 163.40 57.54 162.36 58.27 160.75 58.45 Q 154.55 59.13 149.36 62.70 Q 148.95 62.98 149.08 63.45 L 150.62 68.92 Q 150.74 69.34 151.18 69.29 L 167.55 67.30 Z M 208.27 67.58 C 214.74 60.58 196.37 58.91 194.06 57.33 A 1.58 1.58 0.0 0 0 191.59 58.57 L 191.43 62.59 A 0.38 0.38 0.0 0 1 191.39 62.76 Q 190.44 64.75 190.34 66.95 Q 190.31 67.58 190.94 67.57 L 196.52 67.47 Q 196.92 67.47 197.12 67.81 L 197.40 68.28 Q 197.57 68.56 197.89 68.56 L 204.23 68.48 Q 204.75 68.47 205.04 68.90 Q 205.79 69.98 206.94 69.51 Q 207.29 69.37 207.39 69.00 Q 207.60 68.30 208.27 67.58 Z` }), u(`path`, { fill: `currentColor`, d: ` M 159.80 309.70 Q 160.31 307.85 160.90 306.05 Q 161.11 305.42 161.44 305.23 Q 161.70 305.07 161.98 305.12 Q 162.47 305.21 162.30 305.69 L 160.32 311.22 A 1.04 1.03 -45.8 0 1 158.38 311.25 L 156.12 305.42 Q 156.00 305.09 156.34 305.05 L 156.75 304.99 A 0.74 0.74 0.0 0 1 157.55 305.48 L 159.03 309.73 Q 159.46 310.96 159.80 309.70 Z` }), u(`path`, { fill: `currentColor`, d: ` M 175.18 311.15 C 171.14 315.72 166.72 304.88 173.66 305.10 Q 175.04 305.14 174.99 306.40 A 0.41 0.40 -66.3 0 1 174.30 306.67 L 174.00 306.37 Q 173.04 305.42 172.22 306.49 Q 170.50 308.73 172.13 310.85 A 0.65 0.64 63.1 0 0 172.82 311.08 L 174.81 310.55 A 0.37 0.37 0.0 0 1 175.18 311.15 Z` }), u(`path`, { fill: `currentColor`, d: ` M 179.13 311.01 Q 180.78 310.85 181.22 309.24 A 0.43 0.38 48.6 0 0 181.22 308.99 Q 180.70 307.15 181.17 305.34 A 0.55 0.55 0.0 0 1 182.25 305.48 L 182.25 311.59 Q 182.25 312.23 181.65 312.01 L 180.91 311.74 Q 180.48 311.58 180.05 311.75 C 175.85 313.45 176.89 307.92 176.64 306.03 A 0.83 0.75 56.0 0 1 176.70 305.60 Q 177.12 304.69 177.73 305.11 A 0.28 0.27 -73.9 0 1 177.85 305.34 L 177.95 309.97 A 1.08 1.07 -3.5 0 0 179.13 311.01 Z` }), u(`path`, { fill: `currentColor`, d: ` M 188.74 309.68 L 188.76 305.51 A 0.53 0.53 0.0 0 1 189.27 304.98 Q 189.61 304.97 189.81 305.13 Q 189.96 305.25 189.96 305.53 Q 190.06 308.61 189.98 311.70 Q 189.96 312.37 189.42 311.97 L 188.88 311.58 A 0.65 0.65 0.0 0 0 188.14 311.55 Q 186.22 312.75 184.77 311.10 A 0.82 0.81 -67.4 0 1 184.56 310.58 L 184.37 305.50 A 0.49 0.48 1.6 0 1 184.90 305.00 Q 185.51 305.05 185.47 305.75 Q 185.32 308.20 185.75 310.02 A 1.52 1.51 -51.5 0 0 188.74 309.68 Z` }), u(`path`, { fill: `currentColor`, d: ` M 196.21 307.08 A 1.21 1.21 0.0 0 0 193.89 306.64 Q 192.94 308.94 193.29 311.41 Q 193.36 311.90 192.87 311.99 Q 192.41 312.08 192.14 311.79 Q 191.96 311.59 191.98 311.17 Q 192.12 308.69 192.10 306.20 Q 192.10 305.69 192.58 305.55 Q 194.99 304.88 197.23 305.78 Q 197.77 306.00 198.22 305.62 Q 199.55 304.50 200.99 305.59 Q 201.48 305.97 201.57 306.57 Q 201.91 309.05 201.70 311.55 A 0.60 0.60 0.0 0 1 200.50 311.50 L 200.50 306.82 A 0.64 0.64 0.0 0 0 199.63 306.22 L 197.96 306.87 Q 197.50 307.04 197.50 307.54 L 197.50 311.25 A 0.75 0.53 -55.1 0 1 196.28 311.69 L 196.21 307.08 Z` }), u(`path`, { fill: `currentColor`, d: ` M 166.19 306.06 Q 165.20 305.95 163.65 306.73 A 0.26 0.25 54.0 0 1 163.36 306.68 L 163.06 306.39 Q 162.74 306.06 163.15 305.85 Q 165.37 304.69 167.67 305.57 A 0.83 0.81 -81.0 0 1 168.19 306.31 L 168.38 311.17 Q 168.40 311.74 167.83 311.77 L 164.15 311.96 A 0.95 0.95 0.0 0 1 163.14 311.01 Q 163.14 307.54 166.75 308.06 A 0.37 0.36 -82.6 0 0 167.17 307.73 Q 167.33 306.19 166.19 306.06 Z M 165.15 310.91 Q 166.31 311.37 166.98 310.36 A 0.88 0.88 0.0 0 0 166.25 309.00 L 165.00 309.00 A 1.14 0.94 70.8 0 0 164.37 310.71 Q 164.44 310.82 164.72 310.82 Q 164.94 310.82 165.15 310.91 Z` })] });
}
e();
function C(e3) {
  return u(`svg`, { viewBox: `0 0 512 512`, width: e3.width || 20, height: e3.height || e3.width || 20, xmlns: `http://www.w3.org/2000/svg`, style: e3.style, children: u(`path`, { fill: `currentColor`, d: `M352.57 128c-28.09 0-54.09 4.52-77.06 12.86l12.41-123.11C289 7.31 279.81-1.18 269.33.13 189.63 10.13 128 77.64 128 159.43c0 28.09 4.52 54.09 12.86 77.06L17.75 224.08C7.31 223-1.18 232.19.13 242.67c10 79.7 77.51 141.33 159.3 141.33 28.09 0 54.09-4.52 77.06-12.86l-12.41 123.11c-1.05 10.43 8.11 18.93 18.59 17.62 79.7-10 141.33-77.51 141.33-159.3 0-28.09-4.52-54.09-12.86-77.06l123.11 12.41c10.44 1.05 18.93-8.11 17.62-18.59-10-79.7-77.51-141.33-159.3-141.33zM256 288a32 32 0 1 1 32-32 32 32 0 0 1-32 32z` }) });
}
var w = { vacuumBattery: { display: `flex`, alignItems: `center`, gap: 4 }, vacuumSensorsContainer: { overflow: `auto` }, vacuumSensors: { display: `flex`, justifyContent: `space-between`, alignItems: `center`, gap: 4, minWidth: `min-content` }, vacuumButtons: { display: `flex`, alignItems: `center`, gap: 4 }, vacuumContent: { width: `100%`, height: `100%`, overflow: `auto` }, vacuumMapContainer: { flex: 1 }, vacuumTopPanel: { display: `flex`, alignItems: `center`, justifyContent: `space-between` }, vacuumBottomPanel: { display: `flex`, justifyContent: `space-between`, alignItems: `center` }, vacuumSensorCard: { boxShadow: `none`, backgroundColor: `transparent` }, vacuumSensorCardContent: { display: `flex`, flexDirection: `column`, alignItems: `center`, textAlign: `center`, padding: 2, paddingBottom: 2 }, vacuumSensorBigText: { fontSize: 20 }, vacuumSensorSmallText: { fontSize: 12 }, vacuumImage: { width: `100%`, height: `100%`, objectFit: `contain`, color: `grey` }, vacuumSpeedContainer: { gap: 4, display: `flex`, alignItems: `center` }, tooltip: { pointerEvents: `none` } }, T = { status: { role: `value.state` }, battery: { role: `value.battery` }, "is-charging": { name: `is_charging` }, "fan-speed": { role: `level.suction` }, "sensors-left": { role: `value.usage.sensors` }, "filter-left": { role: `value.usage.filter` }, "main-brush-left": { role: `value.usage.brush` }, "side-brush-left": { role: `value.usage.brush.side` }, "cleaning-count": { name: `cleanups` }, start: { role: `button`, name: `start` }, home: { role: `button`, name: `home` }, pause: { role: `button`, name: `pause` }, map64: { role: `vacuum.map.base64` } }, E = async (e3, t2, n2, r2) => {
  if (t2[e3.name]) {
    let i2 = await r2.getObject(t2[e3.name]);
    if (i2 && i2.common) {
      let e4 = i2._id.split(`.`);
      e4.pop();
      let a2 = await r2.getObject(e4.join(`.`));
      if (!a2) return;
      (a2.type === `channel` || a2.type === `folder`) && (e4.pop(), a2 = await r2.getObject(e4.join(`.`))), (!a2 || a2.type !== `device`) && (e4 = i2._id.split(`.`), e4.pop());
      let o2 = await r2.getObjectViewSystem(`state`, `${e4.join(`.`)}.`, `${e4.join(`.`)}.\u9999`);
      if (o2) {
        let e5 = false;
        for (let n3 in T) t2[`vacuum-${n3}-oid`] || Object.values(o2).forEach((r3) => {
          var _a;
          if (r3._id.split(`.`).includes(`rooms`)) {
            t2["vacuum-rooms"] || (t2["vacuum-rooms"] = (e5 = true, true));
            return;
          }
          let i3 = (_a = r3.common) == null ? void 0 : _a.role, a3 = T[n3].role;
          if (a3 && !(i3 == null ? void 0 : i3.includes(a3))) return;
          let o3 = T[n3].name;
          (!o3 || r3._id.split(`.`).pop().toLowerCase().includes(o3)) && (e5 = true, t2[`vacuum-${n3}-oid`] = r3._id);
        });
        e5 && n2(t2);
      }
    }
  }
}, D = [`cleaning`, `spot Cleaning`, `zone cleaning`, `room cleaning`], O = [`pause`, `waiting`], k = [`charging`, `charging Erro`], A = [`back to home`, `docking`], j = (e3) => {
  if (typeof e3 == `boolean`) {
    if (e3) return `green`;
  } else {
    e3 ?? (e3 = ``);
    let t2 = e3.toString().toLowerCase();
    if (D.includes(t2)) return `green`;
    if (O.includes(t2)) return `yellow`;
    if (k.includes(t2)) return `gray`;
    if (A.includes(t2)) return `blue`;
  }
}, M = class e2 extends g {
  constructor(e3) {
    super(e3), this.state = { ...this.state, objects: {}, rooms: [] };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Vacuum`, visSet: `vis-2-widgets-nils-fork`, visWidgetLabel: `vacuum`, visName: `Vacuum`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox`, hidden: `!!data.externalDialog` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard || !!data.externalDialog` }, { name: `externalDialog`, label: `use_as_dialog`, type: `checkbox`, tooltip: `use_as_dialog_tooltip` }] }, { name: `sensors`, label: `sensors`, fields: [{ label: `status`, name: `vacuum-status-oid`, type: `id`, onChange: E }, { label: `battery`, name: `vacuum-battery-oid`, type: `id`, onChange: E }, { label: `is_charging`, name: `vacuum-is-charging-oid`, type: `id`, onChange: E }, { label: `fan_speed`, name: `vacuum-fan-speed-oid`, type: `id`, onChange: E }, { label: `sensors_left`, name: `vacuum-sensors-left-oid`, type: `id`, onChange: E }, { label: `filter_left`, name: `vacuum-filter-left-oid`, type: `id`, onChange: E }, { label: `main_brush_left`, name: `vacuum-main-brush-left-oid`, type: `id`, onChange: E }, { label: `side_brush_left`, name: `vacuum-side-brush-left-oid`, type: `id`, onChange: E }, { label: `cleaning_count`, name: `vacuum-cleaning-count-oid`, type: `id`, onChange: E }] }, { name: `map`, label: `map`, fields: [{ label: `rooms`, name: `vacuum-use-rooms`, type: `checkbox`, tooltip: `rooms_tooltip` }, { label: `map64`, name: `vacuum-map64-oid`, type: `id`, onChange: E }, { label: `useDefaultPicture`, name: `vacuum-use-default-picture`, type: `checkbox`, default: true, hidden: `!!data["vacuum-map64-oid"]` }, { label: `ownImage`, name: `vacuum-own-image`, type: `image`, hidden: `!!data["vacuum-map64-oid"] || !data["vacuum-use-default-picture"]` }] }, { name: `actions`, label: `actions`, fields: [{ label: `start`, name: `vacuum-start-oid`, type: `id` }, { label: `home`, name: `vacuum-home-oid`, type: `id` }, { label: `pause`, name: `vacuum-pause-oid`, type: `id` }] }], visDefaultStyle: { width: `100%`, height: 400, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_vacuum.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  async componentDidMount() {
    super.componentDidMount(), await this.vacuumPropertiesUpdate();
  }
  async onRxDataChanged() {
    await this.vacuumPropertiesUpdate();
  }
  async vacuumPropertiesUpdate() {
    let e3 = {}, t2 = [], n2 = Object.keys(T);
    for (let e4 = 0; e4 < n2.length; e4++) {
      let r3 = this.state.rxData[`vacuum-${n2[e4]}-oid`];
      r3 && t2.push(r3);
    }
    let r2 = await this.props.context.socket.getObjectsById(t2) || {};
    Object.values(r2).forEach((t3) => {
      let r3 = n2.find((e4) => this.state.rxData[`vacuum-${e4}-oid`] === t3._id);
      r3 && (e3[r3] = t3);
    });
    let i2 = await this.vacuumLoadRooms();
    this.setState({ objects: e3, rooms: i2 });
  }
  async vacuumLoadRooms() {
    if (this.state.rxData[`vacuum-use-rooms`] && this.state.rxData[`vacuum-status-oid`]) {
      let e3 = this.state.rxData[`vacuum-status-oid`].split(`.`);
      if (e3.length === 4) {
        e3.pop(), e3.pop(), e3.push(`rooms`);
        let t2 = await this.props.context.socket.getObjectViewSystem(`channel`, `${e3.join(`.`)}.room`, `${e3.join(`.`)}.room\u9999`), n2 = [];
        return Object.keys(t2).forEach((e4) => {
          var _a;
          return n2.push({ value: `${e4}.roomClean`, label: g.getText(((_a = t2[e4].common) == null ? void 0 : _a.name) || e4.split(`.`).pop() || ``) });
        }), n2.sort((e4, t3) => e4.label.localeCompare(t3.label)), n2;
      }
    }
    return null;
  }
  vacuumGetValue(e3, t2) {
    var _a;
    let n2 = this.vacuumGetObj(e3);
    if (!n2) return null;
    let r2 = this.state.values[`${n2._id}.val`];
    return !t2 && ((_a = n2.common) == null ? void 0 : _a.states) && n2.common.states[r2] !== void 0 && n2.common.states[r2] !== null ? n2.common.states[r2] : r2;
  }
  vacuumGetObj(e3) {
    return this.state.objects[e3];
  }
  vacuumRenderBattery() {
    var _a;
    let e3 = this.vacuumGetObj(`battery`);
    return e3 ? p(`div`, { style: w.vacuumBattery, children: [this.vacuumGetObj(`is-charging`) && this.vacuumGetValue(`is-charging`) ? u(_, {}) : u(v, {}), this.vacuumGetValue(`battery`) || 0, ` `, (_a = e3.common) == null ? void 0 : _a.unit] }) : null;
  }
  vacuumRenderSpeed() {
    let e3 = this.vacuumGetObj(`fan-speed`);
    if (!e3) return null;
    let n2 = null;
    Array.isArray(e3.common.states) ? (n2 = {}, e3.common.states.forEach((e4) => n2[e4] = e4)) : n2 = e3.common.states;
    let r2 = this.vacuumGetValue(`fan-speed`, true);
    return r2 ?? (r2 = ``), r2 = r2.toString(), [u(t, { style: w.vacuumSpeedContainer, endIcon: u(C, {}), onClick: (e4) => {
      e4.stopPropagation(), this.setState({ showSpeedMenu: e4.currentTarget });
    }, children: n2[r2] !== void 0 && n2[r2] !== null ? g.t(n2[r2]).replace(`vis_2_widgets_nils_`, ``) : r2 }, `speed`), this.state.showSpeedMenu ? u(i, { open: true, anchorEl: this.state.showSpeedMenu, onClose: () => this.setState({ showSpeedMenu: null }), children: Object.keys(n2).map((e4) => u(l, { selected: r2 === e4, onClick: () => {
      this.setState({ showSpeedMenu: null }, () => this.props.context.setValue(this.state.rxData[`vacuum-fan-speed-oid`], e4));
    }, children: g.t(n2[e4]).replace(`vis_2_widgets_nils_`, ``) }, e4)) }, `speedMenu`) : null];
  }
  vacuumRenderRooms() {
    var _a;
    return ((_a = this.state.rooms) == null ? void 0 : _a.length) ? [u(t, { variant: `outlined`, color: `grey`, onClick: (e3) => this.setState({ showRoomsMenu: e3.currentTarget }), children: g.t(`Room`) }, `rooms`), this.state.showRoomsMenu ? u(i, { onClose: () => this.setState({ showRoomsMenu: null }), open: true, anchorEl: this.state.showRoomsMenu, children: this.state.rooms.map((e3) => u(l, { value: e3.value, onClick: () => {
      let t2 = e3.value;
      this.setState({ showRoomsMenu: null }, () => this.props.context.setValue(t2, true));
    }, children: e3.label }, e3.value)) }, `roomsMenu`) : null] : null;
  }
  vacuumRenderSensors() {
    let e3 = [`filter-left`, `side-brush-left`, `main-brush-left`, `sensors-left`, `cleaning-count`].filter((e4) => this.vacuumGetObj(e4));
    return e3.length ? u(`div`, { style: w.vacuumSensorsContainer, children: u(`div`, { style: w.vacuumSensors, children: e3.map((e4) => {
      let t2 = this.vacuumGetObj(e4);
      return u(o, { style: w.vacuumSensorCard, children: p(d, { style: { ...w.vacuumSensorCardContent, paddingBottom: 2 }, children: [p(`div`, { children: [u(`span`, { style: w.vacuumSensorBigText, children: this.vacuumGetValue(e4) || 0 }), ` `, u(`span`, { style: w.vacuumSensorSmallText, children: t2.common.unit })] }), u(`div`, { children: u(`span`, { style: w.vacuumSensorSmallText, children: g.t(e4.replaceAll(`-`, `_`)) }) })] }) }, e4);
    }) }) }) : null;
  }
  vacuumRenderButtons() {
    let e3, t2 = this.vacuumGetObj(`status`), r2 = ``, i2;
    if (t2) {
      let t3 = this.vacuumGetValue(`status`);
      e3 = j(t3), typeof t3 == `boolean` ? (i2 = t3 ? `cleaning` : `pause`, r2 = t3 ? `Cleaning` : `Pause`) : (t3 ?? (r2 = ``), r2 = (t3 || ``).toString(), i2 = r2.toLowerCase());
    }
    return p(`div`, { style: w.vacuumButtons, children: [this.vacuumGetObj(`start`) && (!i2 || !D.includes(i2)) && u(c, { title: g.t(`Start`), slotProps: { popper: { sx: w.tooltip } }, children: u(n, { onClick: () => this.props.context.setValue(this.state.rxData[`vacuum-start-oid`], true), children: u(x, {}) }) }), this.vacuumGetObj(`pause`) && (!i2 || !O.includes(i2)) && (!i2 || !k.includes(i2)) && u(c, { title: g.t(`Pause`), slotProps: { popper: { sx: w.tooltip } }, children: u(n, { onClick: () => this.props.context.setValue(this.state.rxData[`vacuum-pause-oid`], true), children: u(b, {}) }) }), this.vacuumGetObj(`home`) && (!i2 || !k.includes(i2)) && u(c, { title: g.t(`Home`), slotProps: { popper: { sx: w.tooltip } }, children: u(n, { onClick: () => this.props.context.setValue(this.state.rxData[`vacuum-home-oid`], true), children: u(y, {}) }) }), t2 && u(c, { title: g.t(`Status`), slotProps: { popper: { sx: w.tooltip } }, children: u(`div`, { style: { color: e3 }, children: g.t(r2).replace(`vis_2_widgets_nils_`, ``) }) })] });
  }
  vacuumRenderMap() {
    let e3 = this.vacuumGetObj(`map64`);
    return !e3 || !this.state.values[`${e3._id}.val`] ? this.state.rxData[`vacuum-use-default-picture`] ? u(S, { style: w.vacuumImage }) : this.state.rxData[`vacuum-own-image`] ? u(f, { src: this.state.rxData[`vacuum-own-image`], style: w.vacuumImage }) : null : u(`img`, { src: this.state.values[`${e3._id}.val`], alt: `vacuum`, style: w.vacuumImage });
  }
  onCommand(e3) {
    let t2 = super.onCommand(e3);
    if (t2 === false) {
      if (e3 === `openDialog`) return this.setState({ dialog: true }), true;
      if (e3 === `closeDialog`) return this.setState({ dialog: false }), true;
    }
    return t2;
  }
  renderWidgetBody(e3) {
    super.renderWidgetBody(e3);
    let t2 = this.vacuumRenderRooms(), i2 = this.vacuumRenderBattery(), o2 = 0;
    t2 ? o2 += 36 : i2 && (o2 += 24);
    let c2 = this.vacuumRenderSensors();
    c2 && (o2 += 46);
    let l2 = this.vacuumRenderButtons(), d2 = this.vacuumRenderSpeed();
    (l2 || t2) && (o2 += 40);
    let f2 = this.vacuumRenderMap(), m2 = p(`div`, { style: w.vacuumContent, children: [i2 || t2 ? p(`div`, { style: w.vacuumTopPanel, children: [t2, i2] }) : null, f2 ? u(`div`, { style: { ...w.vacuumMapContainer, height: `calc(100% - ${o2 + 5}px)`, width: `100%` }, children: f2 }) : null, c2, l2 || d2 ? p(`div`, { style: w.vacuumBottomPanel, children: [l2, d2] }) : null] });
    return this.state.rxData.externalDialog && !this.props.editMode ? this.state.dialog ? p(s, { open: true, onClose: () => this.setState({ dialog: null }), children: [p(a, { children: [this.state.rxData.widgetTitle, u(n, { style: { float: `right`, zIndex: 2 }, onClick: () => this.setState({ dialog: null }), children: u(h, {}) })] }), u(r, { children: m2 })] }) : null : this.wrapContent(m2);
  }
};
export {
  C as FanIcon,
  k as VACUUM_CHARGING_STATES,
  D as VACUUM_CLEANING_STATES,
  A as VACUUM_GOING_HOME_STATES,
  T as VACUUM_ID_ROLES,
  O as VACUUM_PAUSE_STATES,
  v as a,
  M as default,
  y as i,
  x as n,
  _ as o,
  b as r,
  S as t,
  j as vacuumGetStatusColor
};
