const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./ThermostatCompact-C8m6g_l_.css","./RGBLight-BaA6ZHhJ.css","./Map-CIGW-MKW.css"])))=>i.map(i=>d[i]);
import { _ as r } from "./preload-helper-PPVm8Dsz.js";
let M;
let __tla = (async () => {
  const m = {}, n = /* @__PURE__ */ new Set();
  let l = Promise.resolve();
  async function o(t) {
    const e = l.then(t, t);
    return l = e.then(() => {
    }, () => {
    }), e;
  }
  async function a(t) {
    if (typeof document > "u") return;
    const e = m[t] || [];
    await Promise.all(e.map((s) => {
      const i = new URL(s, import.meta.url).href;
      return n.has(i) || (n.add(i), document.querySelector(`link[rel="stylesheet"][data-mf-href="${i}"]`)) ? Promise.resolve() : new Promise((_, c) => {
        const u = document.createElement("link");
        u.rel = "stylesheet", u.href = i, u.setAttribute("data-mf-href", i), u.onload = () => _(), u.onerror = () => c(new Error(`[Module Federation] Failed to load CSS asset: ${i}`)), document.head.appendChild(u);
      });
    }));
  }
  M = {
    "./Thermostat": async () => {
      await a("./Thermostat");
      const t = await o(() => r(() => import("./Thermostat-B2SuGnyh.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./ThermostatCompact": async () => {
      await a("./ThermostatCompact");
      const t = await o(() => r(() => import("./ThermostatCompact-Dpq1dDFo.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), __vite__mapDeps([0]), import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Actual": async () => {
      await a("./Actual");
      const t = await o(() => r(() => import("./Actual-CcLLaIty.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Switches": async () => {
      await a("./Switches");
      const t = await o(() => r(() => import("./Switches-rQe9ubpH.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), __vite__mapDeps([1]), import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./SimpleState": async () => {
      await a("./SimpleState");
      const t = await o(() => r(() => import("./SimpleState-B4jK5pz3.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Blinds": async () => {
      await a("./Blinds");
      const t = await o(() => r(() => import("./Blinds-Cc_1ojmA.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Clock": async () => {
      await a("./Clock");
      const t = await o(() => r(() => import("./Clock-C9cSf1af.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./ViewInWidget": async () => {
      await a("./ViewInWidget");
      const t = await o(() => r(() => import("./ViewInWidget-CxXuglSp.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Camera": async () => {
      await a("./Camera");
      const t = await o(() => r(() => import("./Camera-CmZdUA5W.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Security": async () => {
      await a("./Security");
      const t = await o(() => r(() => import("./Security-Cy51v3qe.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Player": async () => {
      await a("./Player");
      const t = await o(() => r(() => import("./Player-BlZoYa1v.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Map": async () => {
      await a("./Map");
      const t = await o(() => r(() => import("./Map-BIVkwIML.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), __vite__mapDeps([2]), import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Html": async () => {
      await a("./Html");
      const t = await o(() => r(() => import("./Html-kRVrqRdL.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./ThemeSwitcher": async () => {
      await a("./ThemeSwitcher");
      const t = await o(() => r(() => import("./ThemeSwitcher-5HsglN-M.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./WasherDryer": async () => {
      await a("./WasherDryer");
      const t = await o(() => r(() => import("./WasherDryer-DgbZ-cY2.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Wizard": async () => {
      await a("./Wizard");
      const t = await o(() => r(() => import("./Wizard-CZ_RVvha.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./RGBLight": async () => {
      await a("./RGBLight");
      const t = await o(() => r(() => import("./RGBLight-ybLIdJ3m.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }).then((s) => s.j), __vite__mapDeps([1]), import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Lock": async () => {
      await a("./Lock");
      const t = await o(() => r(() => import("./Lock-BQZ26BiW.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Vacuum": async () => {
      await a("./Vacuum");
      const t = await o(() => r(() => import("./Vacuum-BDvrm0Z6.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }).then((s) => s.e), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./Navigate": async () => {
      await a("./Navigate");
      const t = await o(() => r(() => import("./Navigate-PvAzRQXL.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      }), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    },
    "./translations": async () => {
      await a("./translations");
      const t = await o(() => r(() => import("./translations-fGuQfizN.js"), [], import.meta.url)), e = {};
      return Object.assign(e, t), Object.defineProperty(e, "__esModule", {
        value: true,
        enumerable: false
      }), e;
    }
  };
})();
export {
  __tla,
  M as default
};
