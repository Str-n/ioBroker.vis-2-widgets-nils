import { j as t, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { _ as h, a as u, b as c, c as p, d as g, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { _ as f, a as x, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CpkBFb5h.js";
import { G as s } from "./Generic-DDdmRdK-.js";
import o, { __tla as __tla_3 } from "./Thermostat-B2SuGnyh.js";
import { __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { __tla as __tla_6 } from "./index-DBUuV2Mq.js";
import { __tla as __tla_7 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-CxgaxSjv.js";
import { __tla as __tla_8 } from "./ObjectChart-DL9VOeto.js";
import { __tla as __tla_9 } from "./installSVGRenderer-It2PVbYG.js";
import "./tslib.es6-BuLyYyFn.js";
let r;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_7;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_8;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_9;
    } catch {
    }
  })()
]).then(async () => {
  r = class extends o {
    static getWidgetInfo() {
      return {
        ...o.getWidgetInfo(),
        id: "tplNils2ThermostatCompact",
        visName: "Thermostat Compact",
        visWidgetLabel: "thermostat compact",
        visDefaultStyle: {
          position: "relative",
          width: "100%",
          height: 42,
          display: "inline-block"
        }
      };
    }
    getWidgetInfo() {
      return r.getWidgetInfo();
    }
    renderWidgetBody(a) {
      var _a, _b, _c, _d, _e, _f;
      const i = this.state.values[`${this.state.rxData["oid-temp-actual"]}.val`] ?? this.state.values[`${this.state.rxData["oid-temp-set"]}.val`] ?? null, m = this.state.rxData.unit || ((_b = (_a = this.state.tempStateObject) == null ? void 0 : _a.common) == null ? void 0 : _b.unit) || ((_d = (_c = this.state.tempObject) == null ? void 0 : _c.common) == null ? void 0 : _d.unit) || "", l = i == null ? s.t("temperature") : `${this.formatValue(i)}${m}`, e = this.state.values[`${this.state.rxData["oid-humidity"]}.val`], n = e == null ? s.t("humidity") : `${this.formatValue(e)}${((_f = (_e = this.state.humidityObject) == null ? void 0 : _e.common) == null ? void 0 : _f.unit) || "%"}`, d = super.renderWidgetBody({
        ...a,
        widget: {
          ...a.widget,
          usedInWidget: true
        }
      });
      return t.jsxs(t.Fragment, {
        children: [
          t.jsxs(h, {
            variant: "contained",
            color: "primary",
            size: "small",
            startIcon: t.jsx(f, {
              style: {
                width: 18,
                height: 18
              }
            }),
            onClick: () => this.setState({
              dialog: true
            }),
            className: `thermostat-compact-button${this.state.rxData["oid-humidity"] && this.state.rxData["oid-humidity"] !== "nothing_selected" ? " thermostat-compact-button--with-humidity" : ""}`,
            children: [
              l,
              this.state.rxData["oid-humidity"] && this.state.rxData["oid-humidity"] !== "nothing_selected" ? t.jsx("span", {
                style: {
                  fontSize: 10,
                  fontWeight: "normal"
                },
                children: n
              }) : null
            ]
          }),
          t.jsxs(u, {
            open: !!this.state.dialog,
            onClose: () => this.setState({
              dialog: false
            }),
            maxWidth: "lg",
            fullWidth: true,
            children: [
              t.jsxs(c, {
                children: [
                  this.state.rxData.widgetTitle || s.t("thermostat"),
                  t.jsx(p, {
                    style: {
                      float: "right",
                      zIndex: 2
                    },
                    onClick: () => this.setState({
                      dialog: false
                    }),
                    children: t.jsx(x, {})
                  })
                ]
              }),
              t.jsx(g, {
                style: {
                  minWidth: 180,
                  minHeight: 180
                },
                children: d
              })
            ]
          })
        ]
      });
    }
  };
});
export {
  __tla,
  r as default
};
