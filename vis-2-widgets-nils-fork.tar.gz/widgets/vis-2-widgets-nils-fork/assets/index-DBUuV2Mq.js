import { c, _ as E, b as B, d as T, __tla as __tla_0 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
let X;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  function W(r) {
    var t = r.angle, e = r.minValue, a = r.maxValue, n = r.startAngle, o = r.endAngle;
    if (o <= n) throw new Error("endAngle must be greater than startAngle");
    if (t < n) return e;
    if (t > o) return a;
    var i = (t - n) / (o - n), l = i * (a - e) + e;
    return l;
  }
  function b(r) {
    var t = r.value, e = r.minValue, a = r.maxValue, n = r.startAngle, o = r.endAngle;
    if (o <= n) throw new Error("endAngle must be greater than startAngle");
    var i = (t - e) / (a - e), l = i * (o - n) + n;
    return l;
  }
  function z(r, t, e) {
    if (e = e || {
      direction: "ccw",
      axis: "+x"
    }, t.direction !== e.direction && (r = r === 0 ? 0 : 360 - r), t.axis === e.axis) return r;
    if (t.axis[1] === e.axis[1]) return (180 + r) % 360;
    switch (e.direction + t.axis + e.axis) {
      case "ccw+x-y":
      case "ccw-x+y":
      case "ccw+y+x":
      case "ccw-y-x":
      case "cw+y-x":
      case "cw-y+x":
      case "cw-x-y":
      case "cw+x+y":
        return (90 + r) % 360;
      case "ccw+y-x":
      case "ccw-y+x":
      case "ccw+x+y":
      case "ccw-x-y":
      case "cw+x-y":
      case "cw-x+y":
      case "cw+y+x":
      case "cw-y-x":
        return (270 + r) % 360;
      default:
        throw new Error("Unhandled conversion");
    }
  }
  function M(r, t, e) {
    var a = z(r.degree, r, {
      direction: "ccw",
      axis: "+x"
    }), n = a / 180 * Math.PI, o, i;
    n <= Math.PI ? n <= Math.PI / 2 ? (i = Math.sin(n) * t, o = Math.cos(n) * t) : (i = Math.sin(Math.PI - n) * t, o = Math.cos(Math.PI - n) * t * -1) : n <= Math.PI * 1.5 ? (i = Math.sin(n - Math.PI) * t * -1, o = Math.cos(n - Math.PI) * t * -1) : (i = Math.sin(2 * Math.PI - n) * t * -1, o = Math.cos(2 * Math.PI - n) * t);
    var l = o + e / 2, u = e / 2 - i;
    return {
      x: l,
      y: u
    };
  }
  function D(r, t, e) {
    var a = r.x - t / 2, n = t / 2 - r.y, o = Math.atan2(n, a);
    o < 0 && (o = o + 2 * Math.PI);
    var i = o / Math.PI * 180;
    return z(i, {
      direction: "ccw",
      axis: "+x"
    }, e);
  }
  var _ = function() {
    return _ = Object.assign || function(r) {
      for (var t, e = 1, a = arguments.length; e < a; e++) {
        t = arguments[e];
        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
      }
      return r;
    }, _.apply(this, arguments);
  };
  function C(r) {
    var t = r.startAngle, e = r.innerRadius, a = r.thickness, n = r.direction, o = r.angleType, i = r.svgSize, l = r.endAngle;
    t % 360 === l % 360 && t !== l && (l = l - 1e-3);
    var u = l - t >= 180, g = e + a, v = M(_({
      degree: t
    }, o), e, i), w = `
    M `.concat(v.x, ",").concat(v.y, `
  `), y = M(_({
      degree: l
    }, o), e, i), h = `
    A `.concat(e, " ").concat(e, ` 0
      `).concat(u ? "1" : "0", `
      `).concat(n === "cw" ? "1" : "0", `
      `).concat(y.x, " ").concat(y.y, `
  `), s = M(_({
      degree: l
    }, o), g, i), x = `
    A `.concat(a / 2, " ").concat(a / 2, ` 0
      `).concat(u ? "1" : "0", `
      `).concat(n === "cw" ? "0" : "1", `
      `).concat(s.x, " ").concat(s.y, `
  `), A = M(_({
      degree: t
    }, o), g, i), p = `
    A `.concat(g, " ").concat(g, ` 0
      `).concat(u ? "1" : "0", `
      `).concat(n === "cw" ? "0" : "1", `
      `).concat(A.x, " ").concat(A.y, `
  `), m = `
    A `.concat(a / 2, " ").concat(a / 2, ` 0
      `).concat(u ? "1" : "0", `
      `).concat(n === "cw" ? "0" : "1", `
      `).concat(v.x, " ").concat(v.y, `
  `);
    return w + h + x + p + m + " Z";
  }
  let L, V, k;
  L = /* @__PURE__ */ (function() {
    var r = function(t, e) {
      return r = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function(a, n) {
        a.__proto__ = n;
      } || function(a, n) {
        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (a[o] = n[o]);
      }, r(t, e);
    };
    return function(t, e) {
      if (typeof e != "function" && e !== null) throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
      r(t, e);
      function a() {
        this.constructor = t;
      }
      t.prototype = e === null ? Object.create(e) : (a.prototype = e.prototype, new a());
    };
  })();
  V = function() {
    return V = Object.assign || function(r) {
      for (var t, e = 1, a = arguments.length; e < a; e++) {
        t = arguments[e];
        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (r[n] = t[n]);
      }
      return r;
    }, V.apply(this, arguments);
  };
  k = (function(r) {
    L(t, r);
    function t() {
      var e = r !== null && r.apply(this, arguments) || this;
      return e.svgRef = B(), e.onMouseEnter = function(a) {
        a.buttons === 1 && e.onMouseDown(a);
      }, e.onMouseDown = function(a) {
        var n = e.svgRef.current;
        n && (n.addEventListener("mousemove", e.handleMousePosition), n.addEventListener("mouseleave", e.removeMouseListeners), n.addEventListener("mouseup", e.removeMouseListeners)), e.handleMousePosition(a);
      }, e.removeMouseListeners = function() {
        var a = e.svgRef.current;
        a && (a.removeEventListener("mousemove", e.handleMousePosition), a.removeEventListener("mouseleave", e.removeMouseListeners), a.removeEventListener("mouseup", e.removeMouseListeners)), e.props.onControlFinished && e.props.onControlFinished();
      }, e.handleMousePosition = function(a) {
        var n = a.clientX, o = a.clientY;
        e.processSelection(n, o);
      }, e.onTouch = function(a) {
        if (!(a.touches.length > 1 || a.type === "touchend" && a.touches.length > 0)) {
          var n = a.changedTouches[0], o = n.clientX, i = n.clientY;
          e.processSelection(o, i), (a.type === "touchend" || a.type === "touchcancel") && e.props.onControlFinished && e.props.onControlFinished();
        }
      }, e.processSelection = function(a, n) {
        var o, i = e.props, l = i.size, u = i.maxValue, g = i.minValue, v = i.angleType, w = i.startAngle, y = i.endAngle, h = i.handle1, s = i.disabled, x = i.handle2, A = i.coerceToInt;
        if (h.onChange) {
          var p = e.svgRef.current;
          if (p) {
            var m = p.createSVGPoint();
            m.x = a, m.y = n;
            var P = m.matrixTransform((o = p.getScreenCTM()) === null || o === void 0 ? void 0 : o.inverse()), f = D(P, l, v), d = W({
              angle: f,
              minValue: g,
              maxValue: u,
              startAngle: w,
              endAngle: y
            });
            A && (d = Math.round(d)), s || (x && x.onChange && Math.abs(d - x.value) < Math.abs(d - h.value) ? x.onChange(d) : h.onChange(d));
          }
        }
      }, e;
    }
    return t.prototype.render = function() {
      var e, a, n = this.props, o = n.size, i = n.trackWidth, l = n.handle1, u = n.handle2, g = n.handleSize, v = n.maxValue, w = n.minValue, y = n.startAngle, h = n.endAngle, s = n.angleType, x = n.disabled, A = n.arcColor, p = n.arcBackgroundColor, m = n.outerShadow, P = 20, f = o / 2 - i - P, d = b({
        value: l.value,
        minValue: w,
        maxValue: v,
        startAngle: y,
        endAngle: h
      }), S = u && b({
        value: u.value,
        minValue: w,
        maxValue: v,
        startAngle: y,
        endAngle: h
      }), R = M(V({
        degree: d
      }, s), f + i / 2, o), O = S && M(V({
        degree: S
      }, s), f + i / 2, o), I = !x && !!l.onChange;
      return c("svg", {
        width: o,
        height: o,
        ref: this.svgRef,
        onMouseDown: this.onMouseDown,
        onMouseEnter: this.onMouseEnter,
        onClick: function(j) {
          return I && j.stopPropagation();
        },
        onTouchStart: this.onTouch,
        onTouchEnd: this.onTouch,
        onTouchMove: this.onTouch,
        onTouchCancel: this.onTouch,
        style: {
          touchAction: "none"
        }
      }, m && c(T, null, c("radialGradient", {
        id: "outerShadow"
      }, c("stop", {
        offset: "90%",
        stopColor: A
      }), c("stop", {
        offset: "100%",
        stopColor: "white"
      })), c("circle", {
        fill: "none",
        stroke: "url(#outerShadow)",
        cx: o / 2,
        cy: o / 2,
        r: f + i + P / 2 - 1,
        strokeWidth: P
      })), S === void 0 ? c(T, null, c("path", {
        d: C({
          startAngle: d,
          endAngle: h,
          angleType: s,
          innerRadius: f,
          thickness: i,
          svgSize: o,
          direction: s.direction
        }),
        fill: p
      }), c("path", {
        d: C({
          startAngle: y,
          endAngle: d,
          angleType: s,
          innerRadius: f,
          thickness: i,
          svgSize: o,
          direction: s.direction
        }),
        fill: A
      })) : c(T, null, c("path", {
        d: C({
          startAngle: y,
          endAngle: d,
          angleType: s,
          innerRadius: f,
          thickness: i,
          svgSize: o,
          direction: s.direction
        }),
        fill: p
      }), c("path", {
        d: C({
          startAngle: S,
          endAngle: h,
          angleType: s,
          innerRadius: f,
          thickness: i,
          svgSize: o,
          direction: s.direction
        }),
        fill: p
      }), c("path", {
        d: C({
          startAngle: d,
          endAngle: S,
          angleType: s,
          innerRadius: f,
          thickness: i,
          svgSize: o,
          direction: s.direction
        }),
        fill: A
      })), I && c(T, null, c("filter", {
        id: "handleShadow",
        x: "-50%",
        y: "-50%",
        width: "16",
        height: "16"
      }, c("feOffset", {
        result: "offOut",
        in: "SourceGraphic",
        dx: "0",
        dy: "0"
      }), c("feColorMatrix", {
        result: "matrixOut",
        in: "offOut",
        type: "matrix",
        values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"
      }), c("feGaussianBlur", {
        result: "blurOut",
        in: "matrixOut",
        stdDeviation: "5"
      }), c("feBlend", {
        in: "SourceGraphic",
        in2: "blurOut",
        mode: "normal"
      })), c("circle", {
        r: g,
        cx: R.x,
        cy: R.y,
        fill: (e = l.color) !== null && e !== void 0 ? e : "#ffffff",
        filter: "url(#handleShadow)"
      })), O && c(T, null, c("circle", {
        r: g,
        cx: O.x,
        cy: O.y,
        fill: (a = u.color) !== null && a !== void 0 ? a : "#ffffff",
        filter: "url(#handleShadow)"
      })));
    }, t.defaultProps = {
      size: 200,
      trackWidth: 4,
      minValue: 0,
      maxValue: 100,
      startAngle: 0,
      endAngle: 360,
      angleType: {
        direction: "cw",
        axis: "-y"
      },
      handleSize: 8,
      arcBackgroundColor: "#aaa"
    }, t;
  })(E);
  X = (function(r) {
    L(t, r);
    function t() {
      return r !== null && r.apply(this, arguments) || this;
    }
    return t.prototype.render = function() {
      var e = this.props.size;
      return c("div", {
        style: {
          width: e,
          height: e,
          position: "relative"
        }
      }, c(k, V({}, this.props)), c("div", {
        style: {
          position: "absolute",
          top: "25%",
          left: "50%",
          transform: "translateX(-50%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center"
        }
      }, this.props.children));
    }, t.defaultProps = k.defaultProps, t;
  })(E);
});
export {
  X as C,
  __tla
};
