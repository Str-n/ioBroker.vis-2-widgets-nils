const r = ["history", "sql", "influxdb"];
class l extends window.visRxWidget {
  getPropertyValue = (t) => this.state.values[`${this.state.rxData[t]}.val`];
  static getI18nPrefix() {
    return "vis_2_widgets_nils_";
  }
  static getHistoryInstance(t, s) {
    var _a;
    if ((_a = t == null ? void 0 : t.common) == null ? void 0 : _a.custom) {
      if (t.common.custom[s]) return s;
      for (const n in t.common.custom) if (r.includes(n.split(".")[0])) return n;
    }
    return null;
  }
  async getParentObject(t) {
    const s = t.split(".");
    s.pop();
    const n = s.join(".");
    return await this.props.context.socket.getObject(n);
  }
  static getObjectIcon(t, s, n) {
    n || (n = "../..");
    let a = "";
    const i = t == null ? void 0 : t.common;
    if (i) {
      const e = i.icon;
      if (e) if (e.startsWith("data:image/")) a = e;
      else if (e.includes(".")) {
        let c;
        t.type === "instance" || t.type === "adapter" ? a = `${n}/adapter/${i.name}/${e}` : s && s.startsWith("system.adapter.") ? (c = s.split(".", 3), e[0] === "/" ? c[2] += e : c[2] += `/${e}`, a = `${n}/adapter/${c[2]}`) : (c = s.split(".", 2), e[0] === "/" ? c[0] += e : c[0] += `/${e}`, a = `${n}/adapter/${c[0]}`);
      } else return null;
    }
    return a || null;
  }
}
export {
  l as G
};
