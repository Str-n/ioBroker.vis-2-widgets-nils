import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { B as t, g as n } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { H as r, I as i, L as a, P as o, T as s, ft as c, n as l, pt as u, st as d, u as f } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { A as p, At as m, Bn as h, D as g, Dn as _, E as v, En as y, Et as b, F as x, G as S, Gt as C, H as ee, Hn as w, Jt as T, K as E, Ln as D, Mn as O, Nn as k, O as te, On as ne, Sn as re, T as A, Tn as ie, Tt as j, U as M, Un as N, Vn as ae, Xt as oe, Yt as se, Zt as P, _n as F, bn as ce, dn as le, fn as ue, gn as de, gt as fe, hn as pe, i as me, it as he, jn as ge, k as I, kn as L, ln as _e, lt as ve, mn as R, n as ye, nt as be, o as z, ot as xe, pn as Se, pt as Ce, q as we, qt as Te, r as Ee, rt as De, vn as B, w as Oe, wn as ke, wt as Ae, xn as je, xt as Me, yn as Ne, zn as Pe } from "./installSVGRenderer-DpsPSOBw.js";
import { a as Fe, i as Ie, n as Le, o as Re, r as ze, t as Be } from "./ObjectChart-mIZVGQw1.js";
import { t as V } from "./Generic-BOiMPpxz.js";
var Ve = d(c(`path`, { d: `M15 13V5c0-1.66-1.34-3-3-3S9 3.34 9 5v8c-1.21.91-2 2.37-2 4 0 2.76 2.24 5 5 5s5-2.24 5-5c0-1.63-.79-3.09-2-4m-4-8c0-.55.45-1 1-1s1 .45 1 1h-1v1h1v2h-1v1h1v2h-2z` }), `DeviceThermostat`), He = d(c(`path`, { d: `M17.66 8 12 2.35 6.34 8C4.78 9.56 4 11.64 4 13.64s.78 4.11 2.34 5.67 3.61 2.35 5.66 2.35 4.1-.79 5.66-2.35S20 15.64 20 13.64 19.22 9.56 17.66 8M6 14c.01-2 .62-3.27 1.76-4.4L12 5.27l4.24 4.38C17.38 10.77 17.99 12 18 14z` }), `Opacity`);
N();
var Ue = function(e3, t2) {
  if (t2 === `all`) return { type: `all`, title: e3.getLocaleModel().get([`legend`, `selector`, `all`]) };
  if (t2 === `inverse`) return { type: `inverse`, title: e3.getLocaleModel().get([`legend`, `selector`, `inverse`]) };
}, H = (function(e3) {
  w(t2, e3);
  function t2() {
    var n2 = e3 !== null && e3.apply(this, arguments) || this;
    return n2.type = t2.type, n2.layoutMode = { type: `box`, ignoreSize: true }, n2;
  }
  return t2.prototype.init = function(e4, t3, n2) {
    this.mergeDefaultAndTheme(e4, n2), e4.selected = e4.selected || {}, this._updateSelector(e4);
  }, t2.prototype.mergeOption = function(t3, n2) {
    e3.prototype.mergeOption.call(this, t3, n2), this._updateSelector(t3);
  }, t2.prototype._updateSelector = function(e4) {
    var t3 = e4.selector, n2 = this.ecModel;
    t3 === true && (t3 = e4.selector = [`all`, `inverse`]), re(t3) && F(t3, function(e5, r2) {
      L(e5) && (e5 = { type: e5 }), t3[r2] = k(e5, Ue(n2, e5.type));
    });
  }, t2.prototype.optionUpdated = function() {
    this._updateData(this.ecModel);
    var e4 = this._data;
    if (e4[0] && this.get(`selectedMode`) === `single`) {
      for (var t3 = false, n2 = 0; n2 < e4.length; n2++) {
        var r2 = e4[n2].get(`name`);
        if (this.isSelected(r2)) {
          this.select(r2), t3 = true;
          break;
        }
      }
      !t3 && this.select(e4[0].get(`name`));
    }
  }, t2.prototype._updateData = function(e4) {
    var t3 = [], n2 = [];
    e4.eachRawSeries(function(r3) {
      var i3 = r3.name;
      n2.push(i3);
      var a3;
      if (r3.legendVisualProvider) {
        var o2 = r3.legendVisualProvider.getAllNames();
        e4.isSeriesFiltered(r3) || (n2 = n2.concat(o2)), o2.length ? t3 = t3.concat(o2) : a3 = true;
      } else a3 = true;
      a3 && m(r3) && t3.push(r3.name);
    }), this._availableNames = n2;
    var r2 = this.get(`data`) || t3, i2 = Se(), a2 = O(r2, function(e5) {
      return (L(e5) || _(e5)) && (e5 = { name: e5 }), i2.get(e5.name) ? null : (i2.set(e5.name, true), new De(e5, this, this.ecModel));
    }, this);
    this._data = Ne(a2, function(e5) {
      return !!e5;
    });
  }, t2.prototype.getData = function() {
    return this._data;
  }, t2.prototype.select = function(e4) {
    var t3 = this.option.selected;
    if (this.get(`selectedMode`) === `single`) {
      var n2 = this._data;
      F(n2, function(e5) {
        t3[e5.get(`name`)] = false;
      });
    }
    t3[e4] = true;
  }, t2.prototype.unSelect = function(e4) {
    this.get(`selectedMode`) !== `single` && (this.option.selected[e4] = false);
  }, t2.prototype.toggleSelected = function(e4) {
    var t3 = this.option.selected;
    t3.hasOwnProperty(e4) || (t3[e4] = true), this[t3[e4] ? `unSelect` : `select`](e4);
  }, t2.prototype.allSelect = function() {
    var e4 = this._data, t3 = this.option.selected;
    F(e4, function(e5) {
      t3[e5.get(`name`, true)] = true;
    });
  }, t2.prototype.inverseSelect = function() {
    var e4 = this._data, t3 = this.option.selected;
    F(e4, function(e5) {
      var n2 = e5.get(`name`, true);
      t3.hasOwnProperty(n2) || (t3[n2] = true), t3[n2] = !t3[n2];
    });
  }, t2.prototype.isSelected = function(e4) {
    var t3 = this.option.selected;
    return !(t3.hasOwnProperty(e4) && !t3[e4]) && je(this._availableNames, e4) >= 0;
  }, t2.prototype.getOrient = function() {
    return this.get(`orient`) === `vertical` ? { index: 1, name: `vertical` } : { index: 0, name: `horizontal` };
  }, t2.type = `legend.plain`, t2.dependencies = [`series`], t2.defaultOption = { z: 4, show: true, orient: `horizontal`, left: `center`, top: 0, align: `auto`, backgroundColor: `rgba(0,0,0,0)`, borderColor: `#ccc`, borderRadius: 0, borderWidth: 0, padding: 5, itemGap: 10, itemWidth: 25, itemHeight: 14, symbolRotate: `inherit`, symbolKeepAspect: true, inactiveColor: `#ccc`, inactiveBorderColor: `#ccc`, inactiveBorderWidth: `auto`, itemStyle: { color: `inherit`, opacity: `inherit`, borderColor: `inherit`, borderWidth: `auto`, borderCap: `inherit`, borderJoin: `inherit`, borderDashOffset: `inherit`, borderMiterLimit: `inherit` }, lineStyle: { width: `auto`, color: `inherit`, inactiveColor: `#ccc`, inactiveWidth: 2, opacity: `inherit`, type: `inherit`, cap: `inherit`, join: `inherit`, dashOffset: `inherit`, miterLimit: `inherit` }, textStyle: { color: `#333` }, selectedMode: true, selector: false, selectorLabel: { show: true, borderRadius: 10, padding: [3, 5, 3, 5], fontSize: 12, fontFamily: `sans-serif`, color: `#666`, borderWidth: 1, borderColor: `#666` }, emphasis: { selectorLabel: { show: true, color: `#eee`, backgroundColor: `#666` } }, selectorPosition: `auto`, selectorItemGap: 7, selectorButtonGap: 10, tooltip: { show: false } }, t2;
})(ee);
N();
var U = R, W = F, G = C, We = (function(e3) {
  w(t2, e3);
  function t2() {
    var n2 = e3 !== null && e3.apply(this, arguments) || this;
    return n2.type = t2.type, n2.newlineDisabled = false, n2;
  }
  return t2.prototype.init = function() {
    this.group.add(this._contentGroup = new G()), this.group.add(this._selectorGroup = new G()), this._isFirstRender = true;
  }, t2.prototype.getContentGroup = function() {
    return this._contentGroup;
  }, t2.prototype.getSelectorGroup = function() {
    return this._selectorGroup;
  }, t2.prototype.render = function(e4, t3, n2) {
    var r2 = this._isFirstRender;
    if (this._isFirstRender = false, this.resetInner(), e4.get(`show`, true)) {
      var i2 = e4.get(`align`), a2 = e4.get(`orient`);
      (!i2 || i2 === `auto`) && (i2 = e4.get(`left`) === `right` && a2 === `vertical` ? `right` : `left`);
      var o2 = e4.get(`selector`, true), s2 = e4.get(`selectorPosition`, true);
      o2 && (!s2 || s2 === `auto`) && (s2 = a2 === `horizontal` ? `end` : `start`), this.renderInner(i2, e4, t3, n2, o2, a2, s2);
      var c2 = e4.getBoxLayoutParams(), l2 = { width: n2.getWidth(), height: n2.getHeight() }, u2 = e4.get(`padding`), d2 = E(c2, l2, u2), f2 = this.layoutInner(e4, i2, d2, r2, o2, s2), p2 = E(pe({ width: f2.width, height: f2.height }, c2), l2, u2);
      this.group.x = p2.x - f2.x, this.group.y = p2.y - f2.y, this.group.markRedraw(), this.group.add(this._backgroundEl = Fe(f2, e4));
    }
  }, t2.prototype.resetInner = function() {
    this.getContentGroup().removeAll(), this._backgroundEl && this.group.remove(this._backgroundEl), this.getSelectorGroup().removeAll();
  }, t2.prototype.renderInner = function(e4, t3, n2, r2, i2, a2, o2) {
    var s2 = this.getContentGroup(), c2 = Se(), l2 = t3.get(`selectedMode`), u2 = [];
    n2.eachRawSeries(function(e5) {
      !e5.get(`legendHoverLink`) && u2.push(e5.id);
    }), W(t3.getData(), function(i3, a3) {
      var o3 = i3.get(`name`);
      if (!this.newlineDisabled && (o3 === `` || o3 === `
`)) {
        var d2 = new G();
        d2.newline = true, s2.add(d2);
        return;
      }
      var f2 = n2.getSeriesByName(o3)[0];
      if (!c2.get(o3)) {
        if (f2) {
          var p2 = f2.getData(), m2 = p2.getVisual(`legendLineStyle`) || {}, h2 = p2.getVisual(`legendIcon`), g2 = p2.getVisual(`style`), _2 = this._createItem(f2, o3, a3, i3, t3, e4, m2, g2, h2, l2, r2);
          _2.on(`click`, U(qe, o3, null, r2, u2)).on(`mouseover`, U(K, f2.name, null, r2, u2)).on(`mouseout`, U(q, f2.name, null, r2, u2)), n2.ssr && _2.eachChild(function(e5) {
            var t4 = Ae(e5);
            t4.seriesIndex = f2.seriesIndex, t4.dataIndex = a3, t4.ssrType = `legend`;
          }), c2.set(o3, true);
        } else n2.eachRawSeries(function(s3) {
          if (!c2.get(o3) && s3.legendVisualProvider) {
            var d3 = s3.legendVisualProvider;
            if (!d3.containName(o3)) return;
            var f3 = d3.indexOfName(o3), p3 = d3.getItemVisual(f3, `style`), m3 = d3.getItemVisual(f3, `legendIcon`), h3 = T(p3.fill);
            h3 && h3[3] === 0 && (h3[3] = 0.2, p3 = B(B({}, p3), { fill: se(h3, `rgba`) }));
            var g3 = this._createItem(s3, o3, a3, i3, t3, e4, {}, p3, m3, l2, r2);
            g3.on(`click`, U(qe, null, o3, r2, u2)).on(`mouseover`, U(K, null, o3, r2, u2)).on(`mouseout`, U(q, null, o3, r2, u2)), n2.ssr && g3.eachChild(function(e5) {
              var t4 = Ae(e5);
              t4.seriesIndex = s3.seriesIndex, t4.dataIndex = a3, t4.ssrType = `legend`;
            }), c2.set(o3, true);
          }
        }, this);
      }
    }, this), i2 && this._createSelector(i2, t3, r2, a2, o2);
  }, t2.prototype._createSelector = function(e4, t3, n2, r2, i2) {
    var a2 = this.getSelectorGroup();
    W(e4, function(e5) {
      var r3 = e5.type, i3 = new j({ style: { x: 0, y: 0, align: `center`, verticalAlign: `middle` }, onclick: function() {
        n2.dispatchAction({ type: r3 === `all` ? `legendAllSelect` : `legendInverseSelect`, legendId: t3.id });
      } });
      a2.add(i3);
      var o2 = t3.getModel(`selectorLabel`), s2 = t3.getModel([`emphasis`, `selectorLabel`]);
      xe(i3, { normal: o2, emphasis: s2 }, { defaultText: e5.title }), Me(i3);
    });
  }, t2.prototype._createItem = function(e4, t3, n2, r2, i2, a2, o2, s2, c2, l2, u2) {
    var d2 = e4.visualDrawType, f2 = i2.get(`itemWidth`), p2 = i2.get(`itemHeight`), m2 = i2.isSelected(t3), h2 = r2.get(`symbolRotate`), g2 = r2.get(`symbolKeepAspect`), _2 = r2.get(`icon`);
    c2 = _2 || c2 || `roundRect`;
    var v2 = Ge(c2, r2, o2, s2, d2, m2, u2), y2 = new G(), x2 = r2.getModel(`textStyle`);
    if (ke(e4.getLegendIcon) && (!_2 || _2 === `inherit`)) y2.add(e4.getLegendIcon({ itemWidth: f2, itemHeight: p2, icon: c2, iconRotate: h2, itemStyle: v2.itemStyle, lineStyle: v2.lineStyle, symbolKeepAspect: g2 }));
    else {
      var S2 = _2 === `inherit` && e4.getData().getVisual(`symbol`) ? h2 === `inherit` ? e4.getData().getVisual(`symbolRotate`) : h2 : 0;
      y2.add(Ke({ itemWidth: f2, itemHeight: p2, icon: c2, iconRotate: S2, itemStyle: v2.itemStyle, lineStyle: v2.lineStyle, symbolKeepAspect: g2 }));
    }
    var C2 = a2 === `left` ? f2 + 5 : -5, ee2 = a2, w2 = i2.get(`formatter`), T2 = t3;
    L(w2) && w2 ? T2 = w2.replace(`{name}`, t3 ?? ``) : ke(w2) && (T2 = w2(t3));
    var E2 = m2 ? x2.getTextColor() : r2.get(`inactiveColor`);
    y2.add(new j({ style: he(x2, { text: T2, x: C2, y: p2 / 2, fill: E2, align: ee2, verticalAlign: `middle` }, { inheritColor: E2 }) }));
    var D2 = new b({ shape: y2.getBoundingRect(), style: { fill: `transparent` } }), O2 = r2.getModel(`tooltip`);
    return O2.get(`show`) && Ce({ el: D2, componentModel: i2, itemName: t3, itemTooltipOption: O2.option }), y2.add(D2), y2.eachChild(function(e5) {
      e5.silent = true;
    }), D2.silent = !l2, this.getContentGroup().add(y2), Me(y2), y2.__legendDataIndex = n2, y2;
  }, t2.prototype.layoutInner = function(e4, t3, n2, r2, i2, a2) {
    var o2 = this.getContentGroup(), s2 = this.getSelectorGroup();
    M(e4.get(`orient`), o2, e4.get(`itemGap`), n2.width, n2.height);
    var c2 = o2.getBoundingRect(), l2 = [-c2.x, -c2.y];
    if (s2.markRedraw(), o2.markRedraw(), i2) {
      M(`horizontal`, s2, e4.get(`selectorItemGap`, true));
      var u2 = s2.getBoundingRect(), d2 = [-u2.x, -u2.y], f2 = e4.get(`selectorButtonGap`, true), p2 = e4.getOrient().index, m2 = p2 === 0 ? `width` : `height`, h2 = p2 === 0 ? `height` : `width`, g2 = p2 === 0 ? `y` : `x`;
      a2 === `end` ? d2[p2] += c2[m2] + f2 : l2[p2] += u2[m2] + f2, d2[1 - p2] += c2[h2] / 2 - u2[h2] / 2, s2.x = d2[0], s2.y = d2[1], o2.x = l2[0], o2.y = l2[1];
      var _2 = { x: 0, y: 0 };
      return _2[m2] = c2[m2] + f2 + u2[m2], _2[h2] = Math.max(c2[h2], u2[h2]), _2[g2] = Math.min(0, u2[g2] + d2[1 - p2]), _2;
    }
    return o2.x = l2[0], o2.y = l2[1], this.group.getBoundingRect();
  }, t2.prototype.remove = function() {
    this.getContentGroup().removeAll(), this._isFirstRender = true;
  }, t2.type = `legend.plain`, t2;
})(x);
function Ge(e3, t2, n2, r2, i2, a2, o2) {
  function s2(e4, t3) {
    e4.lineWidth === `auto` && (e4.lineWidth = t3.lineWidth > 0 ? 2 : 0), W(e4, function(n3, r3) {
      e4[r3] === `inherit` && (e4[r3] = t3[r3]);
    });
  }
  var c2 = t2.getModel(`itemStyle`), l2 = c2.getItemStyle(), u2 = e3.lastIndexOf(`empty`, 0) === 0 ? `fill` : `stroke`, d2 = c2.getShallow(`decal`);
  l2.decal = !d2 || d2 === `inherit` ? r2.decal : Oe(d2, o2), l2.fill === `inherit` && (l2.fill = r2[i2]), l2.stroke === `inherit` && (l2.stroke = r2[u2]), l2.opacity === `inherit` && (l2.opacity = (i2 === `fill` ? r2 : n2).opacity), s2(l2, r2);
  var f2 = t2.getModel(`lineStyle`), p2 = f2.getLineStyle();
  if (s2(p2, n2), l2.fill === `auto` && (l2.fill = r2.fill), l2.stroke === `auto` && (l2.stroke = r2.fill), p2.stroke === `auto` && (p2.stroke = r2.fill), !a2) {
    var m2 = t2.get(`inactiveBorderWidth`), h2 = l2[u2];
    l2.lineWidth = m2 === `auto` ? r2.lineWidth > 0 && h2 ? 2 : 0 : l2.lineWidth, l2.fill = t2.get(`inactiveColor`), l2.stroke = t2.get(`inactiveBorderColor`), p2.stroke = f2.get(`inactiveColor`), p2.lineWidth = f2.get(`inactiveWidth`);
  }
  return { itemStyle: l2, lineStyle: p2 };
}
function Ke(e3) {
  var t2 = e3.icon || `roundRect`, n2 = p(t2, 0, 0, e3.itemWidth, e3.itemHeight, e3.itemStyle.fill, e3.symbolKeepAspect);
  return n2.setStyle(e3.itemStyle), n2.rotation = (e3.iconRotate || 0) * Math.PI / 180, n2.setOrigin([e3.itemWidth / 2, e3.itemHeight / 2]), t2.indexOf(`empty`) > -1 && (n2.style.stroke = n2.style.fill, n2.style.fill = `#fff`, n2.style.lineWidth = 2), n2;
}
function qe(e3, t2, n2, r2) {
  q(e3, t2, n2, r2), n2.dispatchAction({ type: `legendToggleSelect`, name: e3 ?? t2 }), K(e3, t2, n2, r2);
}
function Je(e3) {
  for (var t2 = e3.getZr().storage.getDisplayList(), n2, r2 = 0, i2 = t2.length; r2 < i2 && !(n2 = t2[r2].states.emphasis); ) r2++;
  return n2 && n2.hoverLayer;
}
function K(e3, t2, n2, r2) {
  Je(n2) || n2.dispatchAction({ type: `highlight`, seriesName: e3, name: t2, excludeSeriesId: r2 });
}
function q(e3, t2, n2, r2) {
  Je(n2) || n2.dispatchAction({ type: `downplay`, seriesName: e3, name: t2, excludeSeriesId: r2 });
}
function Ye(e3) {
  var t2 = e3.findComponents({ mainType: `legend` });
  t2 && t2.length && e3.filterSeries(function(e4) {
    for (var n2 = 0; n2 < t2.length; n2++) if (!t2[n2].isSelected(e4.name)) return false;
    return true;
  });
}
function J(e3, t2, n2) {
  var r2 = e3 === `allSelect` || e3 === `inverseSelect`, i2 = {}, a2 = [];
  n2.eachComponent({ mainType: `legend`, query: t2 }, function(n3) {
    r2 ? n3[e3]() : n3[e3](t2.name), Xe(n3, i2), a2.push(n3.componentIndex);
  });
  var o2 = {};
  return n2.eachComponent(`legend`, function(e4) {
    F(i2, function(t3, n3) {
      e4[t3 ? `select` : `unSelect`](n3);
    }), Xe(e4, o2);
  }), r2 ? { selected: o2, legendIndex: a2 } : { name: t2.name, selected: o2 };
}
function Xe(e3, t2) {
  var n2 = t2 || {};
  return F(e3.getData(), function(t3) {
    var r2 = t3.get(`name`);
    if (r2 !== `
` && r2 !== ``) {
      var i2 = e3.isSelected(r2);
      n2[r2] = ce(n2, r2) ? n2[r2] && i2 : i2;
    }
  }), n2;
}
function Ze(e3) {
  e3.registerAction(`legendToggleSelect`, `legendselectchanged`, R(J, `toggleSelected`)), e3.registerAction(`legendAllSelect`, `legendselectall`, R(J, `allSelect`)), e3.registerAction(`legendInverseSelect`, `legendinverseselect`, R(J, `inverseSelect`)), e3.registerAction(`legendSelect`, `legendselected`, R(J, `select`)), e3.registerAction(`legendUnSelect`, `legendunselected`, R(J, `unSelect`));
}
function Qe(e3) {
  e3.registerComponentModel(H), e3.registerComponentView(We), e3.registerProcessor(e3.PRIORITY.PROCESSOR.SERIES_FILTER, Ye), e3.registerSubTypeDefaulter(`legend`, function() {
    return `plain`;
  }), Ze(e3);
}
N();
var $e = (function(e3) {
  w(t2, e3);
  function t2() {
    var n2 = e3 !== null && e3.apply(this, arguments) || this;
    return n2.type = t2.type, n2;
  }
  return t2.prototype.setScrollDataIndex = function(e4) {
    this.option.scrollDataIndex = e4;
  }, t2.prototype.init = function(t3, n2, r2) {
    var i2 = S(t3);
    e3.prototype.init.call(this, t3, n2, r2), et(this, t3, i2);
  }, t2.prototype.mergeOption = function(t3, n2) {
    e3.prototype.mergeOption.call(this, t3, n2), et(this, this.option, t3);
  }, t2.type = `legend.scroll`, t2.defaultOption = be(H.defaultOption, { scrollDataIndex: 0, pageButtonItemGap: 5, pageButtonGap: null, pageButtonPosition: `end`, pageFormatter: `{current}/{total}`, pageIcons: { horizontal: [`M0,0L12,-10L12,10z`, `M0,0L-12,-10L-12,10z`], vertical: [`M0,0L20,0L10,-20z`, `M0,0L20,0L10,20z`] }, pageIconColor: `#2f4554`, pageIconInactiveColor: `#aaa`, pageIconSize: 15, pageTextStyle: { color: `#333` }, animationDurationUpdate: 800 }), t2;
})(H);
function et(e3, t2, n2) {
  var r2 = e3.getOrient(), i2 = [1, 1];
  i2[r2.index] = 0, we(t2, n2, { type: `box`, ignoreSize: !!i2 });
}
N();
var tt = C, Y = [`width`, `height`], X = [`x`, `y`], nt = (function(e3) {
  w(t2, e3);
  function t2() {
    var n2 = e3 !== null && e3.apply(this, arguments) || this;
    return n2.type = t2.type, n2.newlineDisabled = true, n2._currentIndex = 0, n2;
  }
  return t2.prototype.init = function() {
    e3.prototype.init.call(this), this.group.add(this._containerGroup = new tt()), this._containerGroup.add(this.getContentGroup()), this.group.add(this._controllerGroup = new tt());
  }, t2.prototype.resetInner = function() {
    e3.prototype.resetInner.call(this), this._controllerGroup.removeAll(), this._containerGroup.removeClipPath(), this._containerGroup.__rectSize = null;
  }, t2.prototype.renderInner = function(t3, n2, r2, i2, a2, o2, s2) {
    var c2 = this;
    e3.prototype.renderInner.call(this, t3, n2, r2, i2, a2, o2, s2);
    var l2 = this._controllerGroup, u2 = n2.get(`pageIconSize`, true), d2 = re(u2) ? u2 : [u2, u2];
    p2(`pagePrev`, 0);
    var f2 = n2.getModel(`pageTextStyle`);
    l2.add(new j({ name: `pageText`, style: { text: `xx/xx`, fill: f2.getTextColor(), font: f2.getFont(), verticalAlign: `middle`, align: `center` }, silent: true })), p2(`pageNext`, 1);
    function p2(e4, t4) {
      var r3 = e4 + `DataIndex`, a3 = ve(n2.get(`pageIcons`, true)[n2.getOrient().name][t4], { onclick: le(c2._pageGo, c2, r3, n2, i2) }, { x: -d2[0] / 2, y: -d2[1] / 2, width: d2[0], height: d2[1] });
      a3.name = e4, l2.add(a3);
    }
  }, t2.prototype.layoutInner = function(e4, t3, n2, r2, i2, a2) {
    var o2 = this.getSelectorGroup(), s2 = e4.getOrient().index, c2 = Y[s2], l2 = X[s2], u2 = Y[1 - s2], d2 = X[1 - s2];
    i2 && M(`horizontal`, o2, e4.get(`selectorItemGap`, true));
    var f2 = e4.get(`selectorButtonGap`, true), p2 = o2.getBoundingRect(), m2 = [-p2.x, -p2.y], h2 = ue(n2);
    i2 && (h2[c2] = n2[c2] - p2[c2] - f2);
    var g2 = this._layoutContentAndController(e4, r2, h2, s2, c2, u2, d2, l2);
    if (i2) {
      if (a2 === `end`) m2[s2] += g2[c2] + f2;
      else {
        var _2 = p2[c2] + f2;
        m2[s2] -= _2, g2[l2] -= _2;
      }
      g2[c2] += p2[c2] + f2, m2[1 - s2] += g2[d2] + g2[u2] / 2 - p2[u2] / 2, g2[u2] = Math.max(g2[u2], p2[u2]), g2[d2] = Math.min(g2[d2], p2[d2] + m2[1 - s2]), o2.x = m2[0], o2.y = m2[1], o2.markRedraw();
    }
    return g2;
  }, t2.prototype._layoutContentAndController = function(e4, t3, n2, r2, i2, a2, o2, s2) {
    var c2 = this.getContentGroup(), l2 = this._containerGroup, u2 = this._controllerGroup;
    M(e4.get(`orient`), c2, e4.get(`itemGap`), r2 ? n2.width : null, r2 ? null : n2.height), M(`horizontal`, u2, e4.get(`pageButtonItemGap`, true));
    var d2 = c2.getBoundingRect(), f2 = u2.getBoundingRect(), p2 = this._showController = d2[i2] > n2[i2], m2 = [-d2.x, -d2.y];
    t3 || (m2[r2] = c2[s2]);
    var h2 = [0, 0], g2 = [-f2.x, -f2.y], _2 = D(e4.get(`pageButtonGap`, true), e4.get(`itemGap`, true));
    p2 && (e4.get(`pageButtonPosition`, true) === `end` ? g2[r2] += n2[i2] - f2[i2] : h2[r2] += f2[i2] + _2), g2[1 - r2] += d2[a2] / 2 - f2[a2] / 2, c2.setPosition(m2), l2.setPosition(h2), u2.setPosition(g2);
    var v2 = { x: 0, y: 0 };
    if (v2[i2] = p2 ? n2[i2] : d2[i2], v2[a2] = Math.max(d2[a2], f2[a2]), v2[o2] = Math.min(0, f2[o2] + g2[1 - r2]), l2.__rectSize = n2[i2], p2) {
      var y2 = { x: 0, y: 0 };
      y2[i2] = Math.max(n2[i2] - f2[i2] - _2, 0), y2[a2] = v2[a2], l2.setClipPath(new b({ shape: y2 })), l2.__rectSize = y2[i2];
    } else u2.eachChild(function(e5) {
      e5.attr({ invisible: true, silent: true });
    });
    var x2 = this._getPageInfo(e4);
    return x2.pageIndex != null && fe(c2, { x: x2.contentPosition[0], y: x2.contentPosition[1] }, p2 ? e4 : null), this._updatePageInfoView(e4, x2), v2;
  }, t2.prototype._pageGo = function(e4, t3, n2) {
    var r2 = this._getPageInfo(t3)[e4];
    r2 != null && n2.dispatchAction({ type: `legendScroll`, scrollDataIndex: r2, legendId: t3.id });
  }, t2.prototype._updatePageInfoView = function(e4, t3) {
    var n2 = this._controllerGroup;
    F([`pagePrev`, `pageNext`], function(r3) {
      var i3 = t3[r3 + `DataIndex`] != null, a3 = n2.childOfName(r3);
      a3 && (a3.setStyle(`fill`, i3 ? e4.get(`pageIconColor`, true) : e4.get(`pageIconInactiveColor`, true)), a3.cursor = i3 ? `pointer` : `default`);
    });
    var r2 = n2.childOfName(`pageText`), i2 = e4.get(`pageFormatter`), a2 = t3.pageIndex, o2 = a2 == null ? 0 : a2 + 1, s2 = t3.pageCount;
    r2 && i2 && r2.setStyle(`text`, L(i2) ? i2.replace(`{current}`, o2 == null ? `` : o2 + ``).replace(`{total}`, s2 == null ? `` : s2 + ``) : i2({ current: o2, total: s2 }));
  }, t2.prototype._getPageInfo = function(e4) {
    var t3 = e4.get(`scrollDataIndex`, true), n2 = this.getContentGroup(), r2 = this._containerGroup.__rectSize, i2 = e4.getOrient().index, a2 = Y[i2], o2 = X[i2], s2 = this._findTargetItemIndex(t3), c2 = n2.children(), l2 = c2[s2], u2 = c2.length, d2 = +!!u2, f2 = { contentPosition: [n2.x, n2.y], pageCount: d2, pageIndex: d2 - 1, pagePrevDataIndex: null, pageNextDataIndex: null };
    if (!l2) return f2;
    var p2 = v2(l2);
    f2.contentPosition[i2] = -p2.s;
    for (var m2 = s2 + 1, h2 = p2, g2 = p2, _2 = null; m2 <= u2; ++m2) _2 = v2(c2[m2]), (!_2 && g2.e > h2.s + r2 || _2 && !y2(_2, h2.s)) && (h2 = g2.i > h2.i ? g2 : _2, h2 && (f2.pageNextDataIndex ?? (f2.pageNextDataIndex = h2.i), ++f2.pageCount)), g2 = _2;
    for (var m2 = s2 - 1, h2 = p2, g2 = p2, _2 = null; m2 >= -1; --m2) _2 = v2(c2[m2]), (!_2 || !y2(g2, _2.s)) && h2.i < g2.i && (g2 = h2, f2.pagePrevDataIndex ?? (f2.pagePrevDataIndex = h2.i), ++f2.pageCount, ++f2.pageIndex), h2 = _2;
    return f2;
    function v2(e5) {
      if (e5) {
        var t4 = e5.getBoundingRect(), n3 = t4[o2] + e5[o2];
        return { s: n3, e: n3 + t4[a2], i: e5.__legendDataIndex };
      }
    }
    function y2(e5, t4) {
      return e5.e >= t4 && e5.s <= t4 + r2;
    }
  }, t2.prototype._findTargetItemIndex = function(e4) {
    if (!this._showController) return 0;
    var t3, n2 = this.getContentGroup(), r2;
    return n2.eachChild(function(n3, i2) {
      var a2 = n3.__legendDataIndex;
      r2 == null && a2 != null && (r2 = i2), a2 === e4 && (t3 = i2);
    }), t3 ?? r2;
  }, t2.type = `legend.scroll`, t2;
})(We);
function rt(e3) {
  e3.registerAction(`legendScroll`, `legendscroll`, function(e4, t2) {
    var n2 = e4.scrollDataIndex;
    n2 != null && t2.eachComponent({ mainType: `legend`, subType: `scroll`, query: e4 }, function(e5) {
      e5.setScrollDataIndex(n2);
    });
  });
}
function it(e3) {
  z(Qe), e3.registerComponentModel($e), e3.registerComponentView(nt), rt(e3);
}
function at(e3) {
  z(Qe), z(it);
}
N();
function ot(e3, t2, n2) {
  var r2 = Pe.createCanvas(), i2 = t2.getWidth(), a2 = t2.getHeight(), o2 = r2.style;
  return o2 && (o2.position = `absolute`, o2.left = `0`, o2.top = `0`, o2.width = i2 + `px`, o2.height = a2 + `px`, r2.setAttribute(`data-zr-dom-id`, e3)), r2.width = i2 * n2, r2.height = a2 * n2, r2;
}
var st = (function(e3) {
  w(t2, e3);
  function t2(t3, n2, r2) {
    var i2 = e3.call(this) || this;
    i2.motionBlur = false, i2.lastFrameAlpha = 0.7, i2.dpr = 1, i2.virtual = false, i2.config = {}, i2.incremental = false, i2.zlevel = 0, i2.maxRepaintRectCount = 5, i2.__dirty = true, i2.__firstTimePaint = true, i2.__used = false, i2.__drawIndex = 0, i2.__startIndex = 0, i2.__endIndex = 0, i2.__prevStartIndex = null, i2.__prevEndIndex = null;
    var a2;
    r2 || (r2 = Te), typeof t3 == `string` ? a2 = ot(t3, n2, r2) : ne(t3) && (a2 = t3, t3 = a2.id), i2.id = t3, i2.dom = a2;
    var o2 = a2.style;
    return o2 && (de(a2), a2.onselectstart = function() {
      return false;
    }, o2.padding = `0`, o2.margin = `0`, o2.borderWidth = `0`), i2.painter = n2, i2.dpr = r2, i2;
  }
  return t2.prototype.getElementCount = function() {
    return this.__endIndex - this.__startIndex;
  }, t2.prototype.afterBrush = function() {
    this.__prevStartIndex = this.__startIndex, this.__prevEndIndex = this.__endIndex;
  }, t2.prototype.initContext = function() {
    this.ctx = this.dom.getContext(`2d`), this.ctx.dpr = this.dpr;
  }, t2.prototype.setUnpainted = function() {
    this.__firstTimePaint = true;
  }, t2.prototype.createBackBuffer = function() {
    var e4 = this.dpr;
    this.domBack = ot(`back-` + this.id, this.painter, e4), this.ctxBack = this.domBack.getContext(`2d`), e4 !== 1 && this.ctxBack.scale(e4, e4);
  }, t2.prototype.createRepaintRects = function(e4, t3, n2, r2) {
    if (this.__firstTimePaint) return this.__firstTimePaint = false, null;
    var i2 = [], a2 = this.maxRepaintRectCount, o2 = false, s2 = new P(0, 0, 0, 0);
    function c2(e5) {
      if (e5.isFinite() && !e5.isZero()) {
        if (i2.length === 0) {
          var t4 = new P(0, 0, 0, 0);
          t4.copy(e5), i2.push(t4);
        } else {
          for (var n3 = false, r3 = 1 / 0, c3 = 0, l3 = 0; l3 < i2.length; ++l3) {
            var u3 = i2[l3];
            if (u3.intersect(e5)) {
              var d3 = new P(0, 0, 0, 0);
              d3.copy(u3), d3.union(e5), i2[l3] = d3, n3 = true;
              break;
            }
            if (o2) {
              s2.copy(e5), s2.union(u3);
              var f3 = e5.width * e5.height, p3 = u3.width * u3.height, m3 = s2.width * s2.height - f3 - p3;
              m3 < r3 && (r3 = m3, c3 = l3);
            }
          }
          if (o2 && (i2[c3].union(e5), n3 = true), !n3) {
            var t4 = new P(0, 0, 0, 0);
            t4.copy(e5), i2.push(t4);
          }
          o2 || (o2 = i2.length >= a2);
        }
      }
    }
    for (var l2 = this.__startIndex; l2 < this.__endIndex; ++l2) {
      var u2 = e4[l2];
      if (u2) {
        var d2 = u2.shouldBePainted(n2, r2, true, true), f2 = u2.__isRendered && (u2.__dirty & 1 || !d2) ? u2.getPrevPaintRect() : null;
        f2 && c2(f2);
        var p2 = d2 && (u2.__dirty & 1 || !u2.__isRendered) ? u2.getPaintRect() : null;
        p2 && c2(p2);
      }
    }
    for (var l2 = this.__prevStartIndex; l2 < this.__prevEndIndex; ++l2) {
      var u2 = t3[l2], d2 = u2 && u2.shouldBePainted(n2, r2, true, true);
      if (u2 && (!d2 || !u2.__zr) && u2.__isRendered) {
        var f2 = u2.getPrevPaintRect();
        f2 && c2(f2);
      }
    }
    var m2;
    do {
      m2 = false;
      for (var l2 = 0; l2 < i2.length; ) {
        if (i2[l2].isZero()) {
          i2.splice(l2, 1);
          continue;
        }
        for (var h2 = l2 + 1; h2 < i2.length; ) i2[l2].intersect(i2[h2]) ? (m2 = true, i2[l2].union(i2[h2]), i2.splice(h2, 1)) : h2++;
        l2++;
      }
    } while (m2);
    return this._paintRects = i2, i2;
  }, t2.prototype.debugGetPaintRects = function() {
    return (this._paintRects || []).slice();
  }, t2.prototype.resize = function(e4, t3) {
    var n2 = this.dpr, r2 = this.dom, i2 = r2.style, a2 = this.domBack;
    i2 && (i2.width = e4 + `px`, i2.height = t3 + `px`), r2.width = e4 * n2, r2.height = t3 * n2, a2 && (a2.width = e4 * n2, a2.height = t3 * n2, n2 !== 1 && this.ctxBack.scale(n2, n2));
  }, t2.prototype.clear = function(e4, t3, n2) {
    var r2 = this.dom, i2 = this.ctx, a2 = r2.width, o2 = r2.height;
    t3 || (t3 = this.clearColor);
    var s2 = this.motionBlur && !e4, c2 = this.lastFrameAlpha, l2 = this.dpr, u2 = this;
    s2 && (this.domBack || this.createBackBuffer(), this.ctxBack.globalCompositeOperation = `copy`, this.ctxBack.drawImage(r2, 0, 0, a2 / l2, o2 / l2));
    var d2 = this.domBack;
    function f2(e5, n3, r3, a3) {
      if (i2.clearRect(e5, n3, r3, a3), t3 && t3 !== `transparent`) {
        var o3 = void 0;
        ie(t3) ? (o3 = (t3.global || t3.__width === r3 && t3.__height === a3) && t3.__canvasGradient || te(i2, t3, { x: 0, y: 0, width: r3, height: a3 }), t3.__canvasGradient = o3, t3.__width = r3, t3.__height = a3) : y(t3) && (t3.scaleX = t3.scaleX || l2, t3.scaleY = t3.scaleY || l2, o3 = g(i2, t3, { dirty: function() {
          u2.setUnpainted(), u2.painter.refresh();
        } })), i2.save(), i2.fillStyle = o3 || t3, i2.fillRect(e5, n3, r3, a3), i2.restore();
      }
      s2 && (i2.save(), i2.globalAlpha = c2, i2.drawImage(d2, e5, n3, r3, a3), i2.restore());
    }
    !n2 || s2 ? f2(0, 0, a2, o2) : n2.length && F(n2, function(e5) {
      f2(e5.x * l2, e5.y * l2, e5.width * l2, e5.height * l2);
    });
  }, t2;
})(_e), ct = 1e5, Z = 314159, Q = 0.01, lt = 1e-3;
function ut(e3) {
  return e3 ? e3.__builtin__ ? true : typeof e3.resize == `function` && typeof e3.refresh == `function` : false;
}
function dt(e3, t2) {
  var n2 = document.createElement(`div`);
  return n2.style.cssText = [`position:relative`, `width:` + e3 + `px`, `height:` + t2 + `px`, `padding:0`, `margin:0`, `border-width:0`].join(`;`) + `;`, n2;
}
var ft = (function() {
  function e3(e4, t2, n2, r2) {
    this.type = `canvas`, this._zlevelList = [], this._prevDisplayList = [], this._layers = {}, this._layerConfig = {}, this._needsManuallyCompositing = false, this.type = `canvas`;
    var i2 = !e4.nodeName || e4.nodeName.toUpperCase() === `CANVAS`;
    this._opts = n2 = B({}, n2 || {}), this.dpr = n2.devicePixelRatio || Te, this._singleCanvas = i2, this.root = e4, e4.style && (de(e4), e4.innerHTML = ``), this.storage = t2;
    var a2 = this._zlevelList;
    this._prevDisplayList = [];
    var o2 = this._layers;
    if (i2) {
      var s2 = e4, c2 = s2.width, l2 = s2.height;
      n2.width != null && (c2 = n2.width), n2.height != null && (l2 = n2.height), this.dpr = n2.devicePixelRatio || 1, s2.width = c2 * this.dpr, s2.height = l2 * this.dpr, this._width = c2, this._height = l2;
      var u2 = new st(s2, this, this.dpr);
      u2.__builtin__ = true, u2.initContext(), o2[Z] = u2, u2.zlevel = Z, a2.push(Z), this._domRoot = e4;
    } else {
      this._width = I(e4, 0, n2), this._height = I(e4, 1, n2);
      var d2 = this._domRoot = dt(this._width, this._height);
      e4.appendChild(d2);
    }
  }
  return e3.prototype.getType = function() {
    return `canvas`;
  }, e3.prototype.isSingleCanvas = function() {
    return this._singleCanvas;
  }, e3.prototype.getViewportRoot = function() {
    return this._domRoot;
  }, e3.prototype.getViewportRootOffset = function() {
    var e4 = this.getViewportRoot();
    if (e4) return { offsetLeft: e4.offsetLeft || 0, offsetTop: e4.offsetTop || 0 };
  }, e3.prototype.refresh = function(e4) {
    var t2 = this.storage.getDisplayList(true), n2 = this._prevDisplayList, r2 = this._zlevelList;
    this._redrawId = Math.random(), this._paintList(t2, n2, e4, this._redrawId);
    for (var i2 = 0; i2 < r2.length; i2++) {
      var a2 = r2[i2], o2 = this._layers[a2];
      if (!o2.__builtin__ && o2.refresh) {
        var s2 = i2 === 0 ? this._backgroundColor : null;
        o2.refresh(s2);
      }
    }
    return this._opts.useDirtyRect && (this._prevDisplayList = t2.slice()), this;
  }, e3.prototype.refreshHover = function() {
    this._paintHoverList(this.storage.getDisplayList(false));
  }, e3.prototype._paintHoverList = function(e4) {
    var t2 = e4.length, n2 = this._hoverlayer;
    if (n2 && n2.clear(), t2) {
      for (var r2 = { inHover: true, viewWidth: this._width, viewHeight: this._height }, i2, a2 = 0; a2 < t2; a2++) {
        var o2 = e4[a2];
        o2.__inHover && (n2 || (n2 = this._hoverlayer = this.getLayer(ct)), i2 || (i2 = n2.ctx, i2.save()), A(i2, o2, r2, a2 === t2 - 1));
      }
      i2 && i2.restore();
    }
  }, e3.prototype.getHoverLayer = function() {
    return this.getLayer(ct);
  }, e3.prototype.paintOne = function(e4, t2) {
    v(e4, t2);
  }, e3.prototype._paintList = function(e4, t2, n2, r2) {
    if (this._redrawId === r2) {
      n2 || (n2 = false), this._updateLayerStatus(e4);
      var i2 = this._doPaintList(e4, t2, n2), a2 = i2.finished, o2 = i2.needsRefreshHover;
      if (this._needsManuallyCompositing && this._compositeManually(), o2 && this._paintHoverList(e4), a2) this.eachLayer(function(e5) {
        e5.afterBrush && e5.afterBrush();
      });
      else {
        var s2 = this;
        oe(function() {
          s2._paintList(e4, t2, n2, r2);
        });
      }
    }
  }, e3.prototype._compositeManually = function() {
    var e4 = this.getLayer(Z).ctx, t2 = this._domRoot.width, n2 = this._domRoot.height;
    e4.clearRect(0, 0, t2, n2), this.eachBuiltinLayer(function(r2) {
      r2.virtual && e4.drawImage(r2.dom, 0, 0, t2, n2);
    });
  }, e3.prototype._doPaintList = function(e4, t2, n2) {
    for (var r2 = this, i2 = [], a2 = this._opts.useDirtyRect, o2 = 0; o2 < this._zlevelList.length; o2++) {
      var s2 = this._zlevelList[o2], c2 = this._layers[s2];
      c2.__builtin__ && c2 !== this._hoverlayer && (c2.__dirty || n2) && i2.push(c2);
    }
    for (var l2 = true, u2 = false, d2 = function(o3) {
      var s3 = i2[o3], c3 = s3.ctx, d3 = a2 && s3.createRepaintRects(e4, t2, f2._width, f2._height), p3 = n2 ? s3.__startIndex : s3.__drawIndex, m2 = !n2 && s3.incremental && Date.now, h2 = m2 && Date.now(), g2 = s3.zlevel === f2._zlevelList[0] ? f2._backgroundColor : null;
      if (s3.__startIndex === s3.__endIndex) s3.clear(false, g2, d3);
      else if (p3 === s3.__startIndex) {
        var _2 = e4[p3];
        (!_2.incremental || !_2.notClear || n2) && s3.clear(false, g2, d3);
      }
      p3 === -1 && (console.error(`For some unknown reason. drawIndex is -1`), p3 = s3.__startIndex);
      var v2, y2 = function(t3) {
        var n3 = { inHover: false, allClipped: false, prevEl: null, viewWidth: r2._width, viewHeight: r2._height };
        for (v2 = p3; v2 < s3.__endIndex; v2++) {
          var i3 = e4[v2];
          if (i3.__inHover && (u2 = true), r2._doPaintEl(i3, s3, a2, t3, n3, v2 === s3.__endIndex - 1), m2 && Date.now() - h2 > 15) break;
        }
        n3.prevElClipPaths && c3.restore();
      };
      if (d3) {
        if (d3.length === 0) v2 = s3.__endIndex;
        else for (var b2 = f2.dpr, x2 = 0; x2 < d3.length; ++x2) {
          var S2 = d3[x2];
          c3.save(), c3.beginPath(), c3.rect(S2.x * b2, S2.y * b2, S2.width * b2, S2.height * b2), c3.clip(), y2(S2), c3.restore();
        }
      } else c3.save(), y2(), c3.restore();
      s3.__drawIndex = v2, s3.__drawIndex < s3.__endIndex && (l2 = false);
    }, f2 = this, p2 = 0; p2 < i2.length; p2++) d2(p2);
    return h.wxa && F(this._layers, function(e5) {
      e5 && e5.ctx && e5.ctx.draw && e5.ctx.draw();
    }), { finished: l2, needsRefreshHover: u2 };
  }, e3.prototype._doPaintEl = function(e4, t2, n2, r2, i2, a2) {
    var o2 = t2.ctx;
    if (n2) {
      var s2 = e4.getPaintRect();
      (!r2 || s2 && s2.intersect(r2)) && (A(o2, e4, i2, a2), e4.setPrevPaintRect(s2));
    } else A(o2, e4, i2, a2);
  }, e3.prototype.getLayer = function(e4, t2) {
    this._singleCanvas && !this._needsManuallyCompositing && (e4 = Z);
    var n2 = this._layers[e4];
    return n2 || (n2 = new st(`zr_` + e4, this, this.dpr), n2.zlevel = e4, n2.__builtin__ = true, this._layerConfig[e4] ? k(n2, this._layerConfig[e4], true) : this._layerConfig[e4 - Q] && k(n2, this._layerConfig[e4 - Q], true), t2 && (n2.virtual = t2), this.insertLayer(e4, n2), n2.initContext()), n2;
  }, e3.prototype.insertLayer = function(e4, t2) {
    var n2 = this._layers, r2 = this._zlevelList, i2 = r2.length, a2 = this._domRoot, o2 = null, s2 = -1;
    if (!n2[e4] && ut(t2)) {
      if (i2 > 0 && e4 > r2[0]) {
        for (s2 = 0; s2 < i2 - 1 && !(r2[s2] < e4 && r2[s2 + 1] > e4); s2++) ;
        o2 = n2[r2[s2]];
      }
      if (r2.splice(s2 + 1, 0, e4), n2[e4] = t2, !t2.virtual) {
        if (o2) {
          var c2 = o2.dom;
          c2.nextSibling ? a2.insertBefore(t2.dom, c2.nextSibling) : a2.appendChild(t2.dom);
        } else a2.firstChild ? a2.insertBefore(t2.dom, a2.firstChild) : a2.appendChild(t2.dom);
      }
      t2.painter || (t2.painter = this);
    }
  }, e3.prototype.eachLayer = function(e4, t2) {
    for (var n2 = this._zlevelList, r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2];
      e4.call(t2, this._layers[i2], i2);
    }
  }, e3.prototype.eachBuiltinLayer = function(e4, t2) {
    for (var n2 = this._zlevelList, r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2], a2 = this._layers[i2];
      a2.__builtin__ && e4.call(t2, a2, i2);
    }
  }, e3.prototype.eachOtherLayer = function(e4, t2) {
    for (var n2 = this._zlevelList, r2 = 0; r2 < n2.length; r2++) {
      var i2 = n2[r2], a2 = this._layers[i2];
      a2.__builtin__ || e4.call(t2, a2, i2);
    }
  }, e3.prototype.getLayers = function() {
    return this._layers;
  }, e3.prototype._updateLayerStatus = function(e4) {
    this.eachBuiltinLayer(function(e5, t3) {
      e5.__dirty = e5.__used = false;
    });
    function t2(e5) {
      i2 && (i2.__endIndex !== e5 && (i2.__dirty = true), i2.__endIndex = e5);
    }
    if (this._singleCanvas) for (var n2 = 1; n2 < e4.length; n2++) {
      var r2 = e4[n2];
      if (r2.zlevel !== e4[n2 - 1].zlevel || r2.incremental) {
        this._needsManuallyCompositing = true;
        break;
      }
    }
    for (var i2 = null, a2 = 0, o2, s2 = 0; s2 < e4.length; s2++) {
      var r2 = e4[s2], c2 = r2.zlevel, l2 = void 0;
      o2 !== c2 && (o2 = c2, a2 = 0), r2.incremental ? (l2 = this.getLayer(c2 + lt, this._needsManuallyCompositing), l2.incremental = true, a2 = 1) : l2 = this.getLayer(c2 + (a2 > 0 ? Q : 0), this._needsManuallyCompositing), l2.__builtin__ || ge(`ZLevel ` + c2 + ` has been used by unkown layer ` + l2.id), l2 !== i2 && (l2.__used = true, l2.__startIndex !== s2 && (l2.__dirty = true), l2.__startIndex = s2, l2.incremental ? l2.__drawIndex = -1 : l2.__drawIndex = s2, t2(s2), i2 = l2), r2.__dirty & 1 && !r2.__inHover && (l2.__dirty = true, l2.incremental && l2.__drawIndex < 0 && (l2.__drawIndex = s2));
    }
    t2(s2), this.eachBuiltinLayer(function(e5, t3) {
      !e5.__used && e5.getElementCount() > 0 && (e5.__dirty = true, e5.__startIndex = e5.__endIndex = e5.__drawIndex = 0), e5.__dirty && e5.__drawIndex < 0 && (e5.__drawIndex = e5.__startIndex);
    });
  }, e3.prototype.clear = function() {
    return this.eachBuiltinLayer(this._clearLayer), this;
  }, e3.prototype._clearLayer = function(e4) {
    e4.clear();
  }, e3.prototype.setBackgroundColor = function(e4) {
    this._backgroundColor = e4, F(this._layers, function(e5) {
      e5.setUnpainted();
    });
  }, e3.prototype.configLayer = function(e4, t2) {
    if (t2) {
      var n2 = this._layerConfig;
      n2[e4] ? k(n2[e4], t2, true) : n2[e4] = t2;
      for (var r2 = 0; r2 < this._zlevelList.length; r2++) {
        var i2 = this._zlevelList[r2];
        if (i2 === e4 || i2 === e4 + Q) {
          var a2 = this._layers[i2];
          k(a2, n2[e4], true);
        }
      }
    }
  }, e3.prototype.delLayer = function(e4) {
    var t2 = this._layers, n2 = this._zlevelList, r2 = t2[e4];
    r2 && (r2.dom.parentNode.removeChild(r2.dom), delete t2[e4], n2.splice(je(n2, e4), 1));
  }, e3.prototype.resize = function(e4, t2) {
    if (this._domRoot.style) {
      var n2 = this._domRoot;
      n2.style.display = `none`;
      var r2 = this._opts, i2 = this.root;
      if (e4 != null && (r2.width = e4), t2 != null && (r2.height = t2), e4 = I(i2, 0, r2), t2 = I(i2, 1, r2), n2.style.display = ``, this._width !== e4 || t2 !== this._height) {
        for (var a2 in n2.style.width = e4 + `px`, n2.style.height = t2 + `px`, this._layers) this._layers.hasOwnProperty(a2) && this._layers[a2].resize(e4, t2);
        this.refresh(true);
      }
      this._width = e4, this._height = t2;
    } else {
      if (e4 == null || t2 == null) return;
      this._width = e4, this._height = t2, this.getLayer(Z).resize(e4, t2);
    }
    return this;
  }, e3.prototype.clearLayer = function(e4) {
    var t2 = this._layers[e4];
    t2 && t2.clear();
  }, e3.prototype.dispose = function() {
    this.root.innerHTML = ``, this.root = this.storage = this._domRoot = this._layers = null;
  }, e3.prototype.getRenderedCanvas = function(e4) {
    if (e4 || (e4 = {}), this._singleCanvas && !this._compositeManually) return this._layers[Z].dom;
    var t2 = new st(`image`, this, e4.pixelRatio || this.dpr);
    t2.initContext(), t2.clear(false, e4.backgroundColor || this._backgroundColor);
    var n2 = t2.ctx;
    if (e4.pixelRatio <= this.dpr) {
      this.refresh();
      var r2 = t2.dom.width, i2 = t2.dom.height;
      this.eachLayer(function(e5) {
        e5.__builtin__ ? n2.drawImage(e5.dom, 0, 0, r2, i2) : e5.renderToCanvas && (n2.save(), e5.renderToCanvas(n2), n2.restore());
      });
    } else for (var a2 = { inHover: false, viewWidth: this._width, viewHeight: this._height }, o2 = this.storage.getDisplayList(true), s2 = 0, c2 = o2.length; s2 < c2; s2++) {
      var l2 = o2[s2];
      A(n2, l2, a2, s2 === c2 - 1);
    }
    return t2.dom;
  }, e3.prototype.getWidth = function() {
    return this._width;
  }, e3.prototype.getHeight = function() {
    return this._height;
  }, e3;
})();
function pt(e3) {
  e3.registerPainter(`canvas`, ft);
}
t();
var mt = e(ae(), 1);
z([ye, Ie, Le, ze, Re, Ee, at, pt]);
var $ = { chart: { height: `calc(100% - 40px)`, width: `100%` }, mainDiv: { marginLeft: 10, color: `rgba(243,177,31)`, display: `inline-block`, lineHeight: `24px` }, temperatureValue: { verticalAlign: `middle`, fontSize: 28 }, temperatureUnit: { paddingLeft: 5, opacity: 0.6, fontSize: 14, verticalAlign: `middle` }, mainIcon: { verticalAlign: `middle`, marginRight: 4, fontSize: 20, width: 20 }, secondaryDiv: { color: `rgba(77,134,255)`, display: `inline-block`, float: `right`, marginRight: 12, lineHeight: `24px` }, humidityValue: { verticalAlign: `middle` }, humidityUnit: { paddingLeft: 5, opacity: 0.6, fontSize: 14, verticalAlign: `middle` }, secondaryIcon: { verticalAlign: `middle`, fontSize: 20, marginRight: 4 }, newValueLight: { animation: `vis-2-widgets-nils-fork-newValueAnimationLight 2s ease-in-out` }, newValueDark: { animation: `vis-2-widgets-nils-fork-newValueAnimationDark 2s ease-in-out` }, tooltip: { pointerEvents: `none` } }, ht = class e2 extends V {
  refContainer = n.createRef();
  mainTimer;
  updateTimeout;
  lastRxData;
  constructor(e3) {
    super(e3), this.state = { ...this.state, showDialog: false, dialogTab: 0, isChart: false, containerHeight: 0, chartData: {} };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Actual`, visSet: `vis-2-widgets-nils-fork`, visSetLabel: `set_label`, visSetColor: `#0783ff`, visWidgetLabel: `actual_value_with_chart`, visName: `Actual values`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox`, noBinding: false }, { name: `widgetTitle`, label: `name`, hidden: `data.noCard === true` }, { name: `timeInterval`, label: `chart_time_interval`, tooltip: `hours`, type: `slider`, min: 0, max: 48, step: 1, default: 12 }, { name: `updateInterval`, label: `chart_update_interval`, tooltip: `seconds`, type: `slider`, min: 10, max: 360, step: 1, default: 60 }] }, { name: `main`, label: `main_object`, fields: [{ label: `oid`, name: `oid-main`, type: `id` }, { label: `title`, name: `title-main`, type: `text`, noButton: true, hidden: `!data["oid-main"] || data["oid-main"] === "nothing_selected"` }, { label: `icon`, name: `icon-main`, type: `icon64`, hidden: `!data["oid-main"] || data["oid-main"] === "nothing_selected"` }, { label: `unit`, name: `unit-main`, type: `text`, noButton: true, hidden: `!data["oid-main"] || data["oid-main"] === "nothing_selected"` }, { label: `hide_chart`, name: `noChart`, noBinding: false, type: `checkbox`, hidden: `!data["oid-main"] || data["oid-main"] === "nothing_selected"` }, { label: `color`, name: `color-main`, type: `color`, hidden: `!data["oid-main"] || data["oid-main"] === "nothing_selected"` }, { label: `font_size`, name: `font-size-main`, type: `slider`, min: 1, max: 100, hidden: `!data["oid-main"] || data["oid-main"] === "nothing_selected"` }, { label: `font_style`, name: `font-style-main`, type: `select`, noTranslation: true, options: [{ value: `normal`, label: `normal` }, { value: `italic`, label: `italic` }], hidden: `!data["oid-main"] || data["oid-main"] === "nothing_selected"` }, { label: `digits_after_comma`, name: `digits_after_comma_main`, type: `number`, min: 0, max: 10, hidden: `!data["oid-main"] || data["oid-main"] === "nothing_selected"` }] }, { name: `secondary`, label: `secondary_object`, fields: [{ label: `oid`, name: `oid-secondary`, type: `id` }, { label: `title`, name: `title-secondary`, type: `text`, noButton: true, hidden: `!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"` }, { label: `icon`, name: `icon-secondary`, type: `icon64`, hidden: `!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"` }, { label: `unit`, name: `unit-secondary`, type: `text`, noButton: true, hidden: `!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"` }, { label: `hide_chart`, name: `noChart-secondary`, noBinding: false, type: `checkbox`, hidden: `!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"` }, { label: `color`, name: `color-secondary`, type: `color`, hidden: `!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"` }, { label: `font_size`, name: `font-size-secondary`, type: `slider`, min: 1, max: 100, hidden: `!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"` }, { label: `font_style`, name: `font-style-secondary`, type: `select`, noTranslation: true, options: [{ value: `normal`, label: `normal` }, { value: `italic`, label: `italic` }], hidden: `!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"` }, { label: `digits_after_comma`, name: `digits_after_comma_secondary`, type: `number`, min: 0, max: 10, hidden: `!data["oid-secondary"] || data["oid-secondary"] === "nothing_selected"` }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_actual.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  async getIcon(e3, t2) {
    var _a, _b, _c;
    if (!t2.common.icon && (t2.type === `state` || t2.type === `channel`)) {
      let n2 = e3.split(`.`), r2 = await this.props.context.socket.getObject(n2.slice(0, -1).join(`.`));
      if (!((_a = r2 == null ? void 0 : r2.common) == null ? void 0 : _a.icon) && (t2.type === `state` || t2.type === `channel`)) {
        let e4 = await this.props.context.socket.getObject(n2.slice(0, -2).join(`.`));
        ((_b = e4 == null ? void 0 : e4.common) == null ? void 0 : _b.icon) && (t2.common.icon = e4.common.icon, (e4.type === `instance` || e4.type === `adapter`) && (t2.common.icon = `../${e4.common.name}.admin/${t2.common.icon}`));
      } else ((_c = r2 == null ? void 0 : r2.common) == null ? void 0 : _c.icon) && (t2.common.icon = r2.common.icon, (r2.type === `instance` || r2.type === `adapter`) && (t2.common.icon = `../${r2.common.name}.admin/${t2.common.icon}`));
    }
    if (t2.common.icon && t2.common.icon.startsWith(`/`)) {
      let n2 = e3.split(`.`);
      t2.common.icon = `../adapter/${n2[0]}${t2.common.icon}`;
    }
  }
  async propertiesUpdate() {
    var _a, _b, _c, _d, _e2, _f, _g, _h;
    let e3 = JSON.stringify(this.state.rxData);
    if (this.lastRxData === e3) return;
    this.lastRxData = e3;
    let t2 = {}, n2 = [];
    this.state.rxData[`oid-main`] && this.state.rxData[`oid-main`] !== `nothing_selected` && n2.push(this.state.rxData[`oid-main`]), this.state.rxData[`oid-secondary`] && this.state.rxData[`oid-secondary`] !== `nothing_selected` && n2.push(this.state.rxData[`oid-secondary`]);
    let r2 = n2.length && await this.props.context.socket.getObjectsById(n2) || {};
    if (this.state.rxData[`oid-main`] && this.state.rxData[`oid-main`] !== `nothing_selected`) {
      let e4 = r2[this.state.rxData[`oid-main`]];
      e4 ? (e4.common || (e4.common = {}), await this.getIcon(this.state.rxData[`oid-main`], e4), t2.main = { common: e4.common, _id: e4._id }) : t2.main = { common: {}, _id: `` };
    }
    if (this.state.rxData[`oid-secondary`] && this.state.rxData[`oid-secondary`] !== `nothing_selected`) {
      let e4 = r2[this.state.rxData[`oid-secondary`]];
      e4 ? (e4.common = e4.common || {}, await this.getIcon(this.state.rxData[`oid-secondary`], e4), t2.secondary = { common: e4.common, _id: e4._id }) : t2.secondary = { common: {}, _id: `` };
    }
    let i2 = (_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory, a2 = V.getHistoryInstance(t2.main, i2), o2 = V.getHistoryInstance(t2.secondary, i2), s2 = this.state.rxData.noChart !== true && this.state.rxData.noChart !== `true` && !!a2 || this.state.rxData[`noChart-secondary`] !== true && this.state.rxData[`noChart-secondary`] !== `true` && !!o2, c2 = { objects: t2, isChart: s2 };
    this.mainTimer && (this.mainTimer = (clearInterval(this.mainTimer), void 0));
    let l2 = false;
    this.state.rxData.noChart !== true && this.state.rxData.noChart !== `true` && a2 && ((_e2 = (_d = (_c = t2.main) == null ? void 0 : _c.common) == null ? void 0 : _d.custom) == null ? void 0 : _e2[a2]) ? (await this.readHistory(t2.main._id, a2), this.mainTimer || (this.mainTimer = setInterval(async () => {
      var _a2, _b2, _c2;
      await this.readHistory(this.state.objects.main._id, a2), this.state.rxData[`noChart-secondary`] !== true && this.state.rxData[`noChart-secondary`] !== `true` && o2 && ((_c2 = (_b2 = (_a2 = this.state.objects.secondary) == null ? void 0 : _a2.common) == null ? void 0 : _b2.custom) == null ? void 0 : _c2[o2]) && await this.readHistory(this.state.objects.secondary._id, o2);
    }, parseInt(this.state.rxData.updateInterval, 10) * 1e3 || 6e4))) : this.state.chartData[this.state.rxData[`oid-main`]] && (this.state.chartData[this.state.rxData[`oid-main`]] = null, l2 = true), this.state.rxData[`noChart-secondary`] !== true && this.state.rxData[`noChart-secondary`] !== `true` && o2 && ((_h = (_g = (_f = t2.secondary) == null ? void 0 : _f.common) == null ? void 0 : _g.custom) == null ? void 0 : _h[o2]) ? (await this.readHistory(t2.secondary._id, o2), this.mainTimer || (this.mainTimer = setInterval(() => this.readHistory(this.state.objects.secondary._id, o2), parseInt(this.state.rxData.updateInterval, 10) * 60 || 6e4))) : this.state.chartData[this.state.rxData[`oid-secondary`]] && (this.state.chartData[this.state.rxData[`oid-secondary`]] = null, l2 = true), (l2 || JSON.stringify(t2) !== JSON.stringify(this.state.objects) || s2 !== this.state.isChart) && this.setState(c2);
  }
  static convertData(e3, t2) {
    let n2 = [];
    if (!(e3 == null ? void 0 : e3.length)) return n2;
    for (let t3 = 0; t3 < e3.length; t3++) e3[t3].val === true ? e3[t3].val = 1 : e3[t3].val === false && (e3[t3].val = 0), n2.push({ value: [e3[t3].ts, e3[t3].val] });
    return (t2.min === void 0 || t2.max === void 0) && (t2.min = e3[0].ts, t2.max = e3[e3.length - 1].ts), n2;
  }
  readHistory = (t2, n2) => {
    let r2 = this.state.rxData.timeInterval || 12, i2 = /* @__PURE__ */ new Date();
    i2.setHours(i2.getHours() - r2), i2.setMinutes(0), i2.setSeconds(0), i2.setMilliseconds(0);
    let a2 = i2.getTime(), o2 = { instance: n2, start: a2, end: Date.now(), step: 18e5, from: false, ack: false, q: false, addId: false, aggregate: `minmax` }, s2;
    return this.props.context.socket.getHistory(t2, o2).then((e3) => (s2 = e3, this.props.context.socket.getState(t2))).then((n3) => {
      if ((s2 == null ? void 0 : s2[0]) && s2[0].ts !== a2 && s2.unshift({ ts: a2, val: null }), s2) {
        s2.sort((e3, t3) => e3.ts > t3.ts ? 1 : e3.ts < t3.ts ? -1 : 0).filter((e3) => e3.val !== null), n3 && n3.val !== null && n3.val !== void 0 && s2.push({ ts: Date.now(), val: n3.val });
        let r3 = {}, i3 = e2.convertData(s2, r3), a3 = this.state.chartData;
        a3[t2] = { data: i3, min: r3.min, max: r3.max }, this.setState({ chartData: a3 });
      }
    }).catch((e3) => console.error(`Cannot read history: ${e3}`));
  };
  async componentDidMount() {
    super.componentDidMount(), await this.propertiesUpdate();
  }
  componentWillUnmount() {
    this.mainTimer && (this.mainTimer = (clearInterval(this.mainTimer), void 0)), super.componentWillUnmount();
  }
  async onRxDataChanged() {
    await this.propertiesUpdate();
  }
  static getColor(e3, t2) {
    let n2, r2, i2;
    if (e3.startsWith(`#`)) n2 = parseInt(e3.substring(1, 3), 16), r2 = parseInt(e3.substring(3, 5), 16), i2 = parseInt(e3.substring(5, 7), 16);
    else if (e3.startsWith(`rgb(`)) {
      let t3 = e3.replace(`rgb(`, ``).replace(`)`, ``).split(`,`);
      n2 = parseInt(t3[0], 10), r2 = parseInt(t3[1], 10), i2 = parseInt(t3[2], 10);
    } else if (e3.startsWith(`rgba(`)) {
      let t3 = e3.replace(`rgba(`, ``).replace(`)`, ``).split(`,`);
      n2 = parseInt(t3[0], 10), r2 = parseInt(t3[1], 10), i2 = parseInt(t3[2], 10);
    }
    return `rgba(${n2},${r2},${i2},${t2})`;
  }
  getOptions() {
    var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l, _m, _n;
    let t2 = [];
    if (this.state.chartData[this.state.rxData[`oid-main`]] && this.state.rxData.noChart !== true && this.state.rxData.noChart !== `true`) {
      let n2 = this.state.rxData[`title-main`] || V.getText(((_c = (_b = (_a = this.state.objects) == null ? void 0 : _a.main) == null ? void 0 : _b.common) == null ? void 0 : _c.name) || ``);
      n2 || ((_g = (_f = (_e2 = (_d = this.state.objects) == null ? void 0 : _d.secondary) == null ? void 0 : _e2.common) == null ? void 0 : _f.role) == null ? void 0 : _g.includes(`temperature`)) && (n2 = V.t(`temperature`).replace(`vis_2_widgets_nils_`, ``));
      let r2 = e2.getColor(this.state.rxData[`color-main`] || `#F3B11F`, 0.65), i2 = e2.getColor(this.state.rxData[`color-main`] || `#F3B11F`, 0.14);
      t2.push({ areaStyle: { color: i2 }, lineStyle: { color: r2 }, type: `line`, smooth: true, showSymbol: false, data: this.state.chartData[this.state.rxData[`oid-main`]].data, name: n2 });
    }
    if (this.state.chartData[this.state.rxData[`oid-secondary`]] && this.state.rxData[`noData-secondary`] !== true && this.state.rxData[`noData-secondary`] !== `true`) {
      let n2 = this.state.rxData[`title-secondary`] || V.getText(((_j = (_i = (_h = this.state.objects) == null ? void 0 : _h.secondary) == null ? void 0 : _i.common) == null ? void 0 : _j.name) || ``);
      n2 || ((_n = (_m = (_l = (_k = this.state.objects) == null ? void 0 : _k.secondary) == null ? void 0 : _l.common) == null ? void 0 : _m.role) == null ? void 0 : _n.includes(`humidity`)) && (n2 = V.t(`humidity`).replace(`vis_2_widgets_nils_`, ``));
      let r2 = e2.getColor(this.state.rxData[`color-secondary`] || `#F3B11F`, 0.65), i2 = e2.getColor(this.state.rxData[`color-secondary`] || `#F3B11F`, 0.14);
      t2.push({ areaStyle: { color: i2 }, lineStyle: { color: r2 }, type: `line`, smooth: true, showSymbol: false, data: this.state.chartData[this.state.rxData[`oid-secondary`]].data, name: n2 });
    }
    return { animation: false, backgroundColor: `transparent`, grid: { show: false, left: 0, top: 0, right: 0, bottom: 0 }, legend: void 0, calculable: true, xAxis: { show: false, boundaryGap: false, type: `time` }, yAxis: { show: false }, series: t2 };
  }
  componentDidUpdate() {
    this.refContainer.current && this.state.containerHeight !== this.refContainer.current.clientHeight && this.setState({ containerHeight: this.refContainer.current.clientHeight });
  }
  renderDialog() {
    var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x;
    if (!this.state.showDialog) return null;
    let t2 = e2.getColor(this.state.rxData[`color-main`] || `#F3B11F`, 0.65), n2 = e2.getColor(this.state.rxData[`color-main`] || `#F3B11F`, 0.14), s2 = e2.getColor(this.state.rxData[`color-secondary`] || `#F3B11F`, 0.65), l2 = e2.getColor(this.state.rxData[`color-secondary`] || `#F3B11F`, 0.14);
    return u(o, { sx: { "& .MuiDialog-paper": { height: `100%` } }, maxWidth: `lg`, fullWidth: true, open: true, onClose: () => this.setState({ showDialog: false }), children: [u(a, { children: [this.state.rxData.widgetTitle, c(r, { style: { float: `right` }, onClick: () => this.setState({ showDialog: false }), children: c(f, {}) })] }), c(i, { children: c(Be, { t: (e3) => V.t(e3), lang: V.getLanguage(), socket: this.props.context.socket, obj: ((_a = this.state.objects) == null ? void 0 : _a.main) || ((_b = this.state.objects) == null ? void 0 : _b.secondary), obj2: ((_c = this.state.objects) == null ? void 0 : _c.main) ? (_d = this.state.objects) == null ? void 0 : _d.secondary : null, unit: ((_e2 = this.state.objects) == null ? void 0 : _e2.main) ? this.state.rxData[`unit-main`] || ((_f = this.state.objects.main.common) == null ? void 0 : _f.unit) || `` : this.state.rxData[`unit-secondary`] || ((_i = (_h = (_g = this.state.objects) == null ? void 0 : _g.secondary) == null ? void 0 : _h.common) == null ? void 0 : _i.unit) || ``, unit2: this.state.rxData[`unit-secondary`] || ((_l = (_k = (_j = this.state.objects) == null ? void 0 : _j.secondary) == null ? void 0 : _k.common) == null ? void 0 : _l.unit) || ``, title: ((_m = this.state.objects) == null ? void 0 : _m.main) ? this.state.rxData[`title-main`] || V.getText((_n = this.state.objects.main.common) == null ? void 0 : _n.name) : this.state.rxData[`title-secondary`] || V.getText(((_q = (_p = (_o = this.state.objects) == null ? void 0 : _o.secondary) == null ? void 0 : _p.common) == null ? void 0 : _q.name) || ``), title2: this.state.rxData[`title-secondary`] || V.getText(((_t = (_s = (_r = this.state.objects) == null ? void 0 : _r.secondary) == null ? void 0 : _s.common) == null ? void 0 : _t.name) || ``), objLineType: `line`, obj2LineType: `line`, objColor: t2, obj2Color: s2, objBackgroundColor: n2, obj2BackgroundColor: l2, themeType: this.props.context.themeType, historyInstance: V.getHistoryInstance(this.state.objects.main || this.state.objects.secondary, ((_v = (_u = this.props.context.systemConfig) == null ? void 0 : _u.common) == null ? void 0 : _v.defaultHistory) || `history.0`), historyInstance2: V.getHistoryInstance(this.state.objects.secondary, ((_x = (_w = this.props.context.systemConfig) == null ? void 0 : _w.common) == null ? void 0 : _x.defaultHistory) || `history.0`), noToolbar: false, systemConfig: this.props.context.systemConfig, dateFormat: this.props.context.systemConfig.common.dateFormat, chartTitle: `` }) })] });
  }
  renderWidgetBody(e3) {
    var _a, _b, _c, _d, _e2, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F;
    super.renderWidgetBody(e3);
    let t2 = JSON.stringify(this.state.rxData);
    this.lastRxData !== t2 && (this.updateTimeout || (this.updateTimeout = setTimeout(async () => {
      this.updateTimeout = void 0, await this.propertiesUpdate();
    }, 50)));
    let n2 = !this.state.showDialog && this.state.isChart ? (e4) => {
      e4 == null ? void 0 : e4.preventDefault(), e4 == null ? void 0 : e4.stopPropagation(), this.setState({ showDialog: true });
    } : void 0, r2 = this.props.context.themeType === `dark` ? $.newValueDark : $.newValueLight, i2 = ((_a = this.state.objects) == null ? void 0 : _a.main) && this.state.values[`${this.state.rxData[`oid-main`]}.val`] !== void 0 ? this.formatValue(this.state.values[`${this.state.rxData[`oid-main`]}.val`], this.state.rxData.digits_after_comma_main) : void 0, a2 = ((_b = this.state.objects) == null ? void 0 : _b.secondary) && this.state.values[`${this.state.rxData[`oid-secondary`]}.val`] !== void 0 ? this.formatValue(this.state.values[`${this.state.rxData[`oid-secondary`]}.val`], this.state.rxData.digits_after_comma_secondary) : void 0, o2 = this.state.rxData[`icon-main`] || ((_e2 = (_d = (_c = this.state.objects) == null ? void 0 : _c.main) == null ? void 0 : _d.common) == null ? void 0 : _e2.icon);
    o2 = o2 ? c(l, { src: o2, style: { ...$.mainIcon, width: 24, color: this.state.rxData[`color-main`] } }) : ((_i = (_h = (_g = (_f = this.state.objects) == null ? void 0 : _f.main) == null ? void 0 : _g.common) == null ? void 0 : _h.role) == null ? void 0 : _i.includes(`temperature`)) || ((_m = (_l = (_k = (_j = this.state.objects) == null ? void 0 : _j.main) == null ? void 0 : _k.common) == null ? void 0 : _l.unit) == null ? void 0 : _m.includes(`\xB0`)) ? c(Ve, { style: $.mainIcon }) : null;
    let d2 = this.state.rxData[`icon-secondary`] || ((_p = (_o = (_n = this.state.objects) == null ? void 0 : _n.secondary) == null ? void 0 : _o.common) == null ? void 0 : _p.icon);
    d2 = d2 ? c(l, { src: d2, style: { ...$.secondaryIcon, width: 20, color: this.state.rxData[`color-secondary`] } }) : ((_t = (_s = (_r = (_q = this.state.objects) == null ? void 0 : _q.secondary) == null ? void 0 : _r.common) == null ? void 0 : _s.role) == null ? void 0 : _t.includes(`humidity`)) ? c(He, { style: $.secondaryIcon }) : null;
    let f2 = parseInt(this.state.rxData[`font-size-main`], 10) || 0, p2 = parseInt(this.state.rxData[`font-size-secondary`], 10) || 0, m2 = u(`div`, { style: { width: `100%`, height: this.state.rxData.noCard !== true && this.state.rxData.noCard !== `true` && !e3.widget.usedInWidget && this.state.rxData.widgetTitle ? `calc(100% - 32px)` : `100%` }, ref: this.refContainer, children: [c(`style`, { children: `
@keyframes vis-2-widgets-nils-fork-newValueAnimationLight {
    0% {
        color: #00bd00;
    }
    80% {
        color: #008000;
    }
    100% {
        color: rgba(243,177,31);
    }
}
@keyframes vis-2-widgets-nils-fork-newValueAnimationDark {
    0% {
        color: #008000;
    }
    80% {
        color: #00bd00;
    }
    100% {
        color: rgba(243,177,31);
    }
}                
                ` }), i2 === void 0 ? null : c(s, { title: this.state.rxData[`title-main`] || V.getText(((_w = (_v = (_u = this.state.objects) == null ? void 0 : _u.main) == null ? void 0 : _v.common) == null ? void 0 : _w.name) || ``) || null, slotProps: { popper: { sx: $.tooltip } }, children: u(`div`, { style: $.mainDiv, children: [o2, c(`span`, { style: { ...$.temperatureValue, ...r2, fontSize: f2 || void 0, fontStyle: this.state.rxData[`font-style-main`], color: this.state.rxData[`color-main`] }, children: i2 }, `${i2}valText`), c(`span`, { style: { ...$.temperatureUnit, fontSize: f2 ? f2 * 0.5 : void 0, fontStyle: this.state.rxData[`font-style-main`], color: this.state.rxData[`color-main`] }, children: this.state.rxData[`unit-main`] || ((_z = (_y = (_x = this.state.objects) == null ? void 0 : _x.main) == null ? void 0 : _y.common) == null ? void 0 : _z.unit) })] }) }), a2 === void 0 ? null : c(s, { title: this.state.rxData[`title-secondary`] || V.getText(((_C = (_B = (_A = this.state.objects) == null ? void 0 : _A.secondary) == null ? void 0 : _B.common) == null ? void 0 : _C.name) || ``) || null, slotProps: { popper: { sx: $.tooltip } }, children: u(`div`, { style: $.secondaryDiv, children: [d2, c(`span`, { style: { ...$.humidityValue, ...r2, fontSize: p2 || void 0, fontStyle: this.state.rxData[`font-style-secondary`], color: this.state.rxData[`color-secondary`] }, children: a2 }, `${a2}valText`), c(`span`, { style: { ...$.humidityUnit, fontSize: p2 ? p2 / 2 : void 0, fontStyle: this.state.rxData[`font-style-secondary`], color: this.state.rxData[`color-secondary`] }, children: this.state.rxData[`unit-secondary`] || ((_F = (_E = (_D = this.state.objects) == null ? void 0 : _D.secondary) == null ? void 0 : _E.common) == null ? void 0 : _F.unit) })] }) }), this.state.containerHeight && (this.state.chartData[this.state.rxData[`oid-main`]] || this.state.chartData[this.state.rxData[`oid-secondary`]]) ? c(mt.default, { echarts: me, option: this.getOptions(), notMerge: true, lazyUpdate: true, theme: this.props.context.themeType === `dark` ? `dark` : ``, style: { ...$.chart, height: this.state.containerHeight - 26, width: `100%` } }) : null, this.renderDialog()] });
    return this.state.rxData.noCard === true || this.state.rxData.noCard === `true` || e3.widget.usedInWidget ? m2 : this.wrapContent(m2, null, { paddingLeft: 0, paddingRight: 0, paddingBottom: 0, height: `calc(100% - 16px)` }, { paddingLeft: 16 }, n2);
  }
};
export {
  ht as default
};
