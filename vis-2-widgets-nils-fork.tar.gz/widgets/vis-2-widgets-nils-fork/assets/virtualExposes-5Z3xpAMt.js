const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./ThermostatCompact-C9loG33T.css","./RGBLight-mHwH3P8U.css","./Map-BgX4OC_Y.css"])))=>i.map(i=>d[i]);
import { t as e } from "./vite-preload-helper-HclGiUj8.js";
let o;
let __tla = (async () => {
  var t = {}, n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map();
  function i(e2, t2) {
    let n2 = r.get(e2);
    return n2 || (n2 = Promise.resolve().then(t2).catch((t3) => {
      throw r.delete(e2), t3;
    }), r.set(e2, n2)), n2;
  }
  async function a(e2) {
    if (typeof document > `u`) return;
    let r2 = t[e2] || [];
    await Promise.all(r2.map((e3) => {
      let t2 = new URL(e3, import.meta.url).href;
      return n.has(t2) || (n.add(t2), document.querySelector(`link[rel="stylesheet"][href="${t2}"]`)) ? Promise.resolve() : new Promise((e4, n2) => {
        let r3 = document.createElement(`link`);
        r3.rel = `stylesheet`, r3.href = t2, r3.onload = () => e4(), r3.onerror = () => n2(Error(`[Module Federation] Failed to load CSS asset: ${t2}`)), document.head.appendChild(r3);
      });
    }));
  }
  o = {
    "./Thermostat": async () => {
      await a(`./Thermostat`), await Promise.all([]);
      let t2 = await i(`./Thermostat`, () => e(() => import("./Thermostat-DBcZxdN_.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./ThermostatCompact": async () => {
      await a(`./ThermostatCompact`), await Promise.all([]);
      let t2 = await i(`./ThermostatCompact`, () => e(() => import("./ThermostatCompact-DCubERzV.js").then(async (m) => {
        await m.__tla;
        return m;
      }), __vite__mapDeps([0]), import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Actual": async () => {
      await a(`./Actual`), await Promise.all([]);
      let t2 = await i(`./Actual`, () => e(() => import("./Actual-DZqrgQ-g.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Switches": async () => {
      await a(`./Switches`), await Promise.all([]);
      let t2 = await i(`./Switches`, () => e(() => import("./Switches-BXeC2c0H.js").then(async (m) => {
        await m.__tla;
        return m;
      }), __vite__mapDeps([1]), import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./SwitchButton": async () => {
      await a(`./SwitchButton`), await Promise.all([]);
      let t2 = await i(`./SwitchButton`, () => e(() => import("./SwitchButton-BpSxehwH.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./SimpleState": async () => {
      await a(`./SimpleState`), await Promise.all([]);
      let t2 = await i(`./SimpleState`, () => e(() => import("./SimpleState-DijnAHB_.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Blinds": async () => {
      await a(`./Blinds`), await Promise.all([]);
      let t2 = await i(`./Blinds`, () => e(() => import("./Blinds-j2EP2hez.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Clock": async () => {
      await a(`./Clock`), await Promise.all([]);
      let t2 = await i(`./Clock`, () => e(() => import("./Clock-Bc46YZQn.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./ViewInWidget": async () => {
      await a(`./ViewInWidget`), await Promise.all([]);
      let t2 = await i(`./ViewInWidget`, () => e(() => import("./ViewInWidget-BiSi29HF.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Camera": async () => {
      await a(`./Camera`), await Promise.all([]);
      let t2 = await i(`./Camera`, () => e(() => import("./Camera-DOV0FHkL.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Security": async () => {
      await a(`./Security`), await Promise.all([]);
      let t2 = await i(`./Security`, () => e(() => import("./Security-C61WAUow.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Player": async () => {
      await a(`./Player`), await Promise.all([]);
      let t2 = await i(`./Player`, () => e(() => import("./Player-DgI8zjsk.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Map": async () => {
      await a(`./Map`), await Promise.all([]);
      let t2 = await i(`./Map`, () => e(() => import("./Map-Aajnbw5M.js").then(async (m) => {
        await m.__tla;
        return m;
      }), __vite__mapDeps([2]), import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Html": async () => {
      await a(`./Html`), await Promise.all([]);
      let t2 = await i(`./Html`, () => e(() => import("./Html-B_OGJd4i.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./ThemeSwitcher": async () => {
      await a(`./ThemeSwitcher`), await Promise.all([]);
      let t2 = await i(`./ThemeSwitcher`, () => e(() => import("./ThemeSwitcher-DOg3OvBg.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./WasherDryer": async () => {
      await a(`./WasherDryer`), await Promise.all([]);
      let t2 = await i(`./WasherDryer`, () => e(() => import("./WasherDryer-Bqy9Pt8r.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Wizard": async () => {
      await a(`./Wizard`), await Promise.all([]);
      let t2 = await i(`./Wizard`, () => e(() => import("./Wizard-BOhMQqG6.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./RGBLight": async () => {
      await a(`./RGBLight`), await Promise.all([]);
      let t2 = await i(`./RGBLight`, () => e(() => import("./RGBLight-B5teopid.js").then(async (m) => {
        await m.__tla;
        return m;
      }), __vite__mapDeps([1]), import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Lock": async () => {
      await a(`./Lock`), await Promise.all([]);
      let t2 = await i(`./Lock`, () => e(() => import("./Lock-DHemCZKy.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Vacuum": async () => {
      await a(`./Vacuum`), await Promise.all([]);
      let t2 = await i(`./Vacuum`, () => e(() => import("./Vacuum-Bge0udXM.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./Navigate": async () => {
      await a(`./Navigate`), await Promise.all([]);
      let t2 = await i(`./Navigate`, () => e(() => import("./Navigate-BQfs6_EB.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./EnergyGame": async () => {
      await a(`./EnergyGame`), await Promise.all([]);
      let t2 = await i(`./EnergyGame`, () => e(() => import("./EnergyGame-BGBcLfVE.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    },
    "./translations": async () => {
      await a(`./translations`), await Promise.all([]);
      let t2 = await i(`./translations`, () => e(() => import("./translations-Btf6KI_z.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)), n2 = t2 && t2.__mf_remote_dependency_pending;
      n2 && typeof n2.then == `function` && await n2;
      let r2 = {};
      return Object.assign(r2, t2), Object.defineProperty(r2, "__esModule", {
        value: true,
        enumerable: false
      }), r2;
    }
  };
})();
export {
  __tla,
  o as default
};
