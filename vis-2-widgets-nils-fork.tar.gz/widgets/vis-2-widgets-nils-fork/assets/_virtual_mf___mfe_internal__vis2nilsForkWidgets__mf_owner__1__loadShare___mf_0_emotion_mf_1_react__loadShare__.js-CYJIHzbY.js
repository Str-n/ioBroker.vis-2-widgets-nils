var _a, _b;
import { n as e, o as t, r as n, t as r } from "./rolldown-runtime-C0FnF6B9.js";
var i = r(((e3) => {
  var t2 = /* @__PURE__ */ Symbol.for(`react.transitional.element`), n2 = /* @__PURE__ */ Symbol.for(`react.portal`), r2 = /* @__PURE__ */ Symbol.for(`react.fragment`), i2 = /* @__PURE__ */ Symbol.for(`react.strict_mode`), a2 = /* @__PURE__ */ Symbol.for(`react.profiler`), o2 = /* @__PURE__ */ Symbol.for(`react.consumer`), s2 = /* @__PURE__ */ Symbol.for(`react.context`), c2 = /* @__PURE__ */ Symbol.for(`react.forward_ref`), l2 = /* @__PURE__ */ Symbol.for(`react.suspense`), u2 = /* @__PURE__ */ Symbol.for(`react.memo`), d2 = /* @__PURE__ */ Symbol.for(`react.lazy`), f2 = /* @__PURE__ */ Symbol.for(`react.activity`), p2 = Symbol.iterator;
  function m2(e4) {
    return typeof e4 != `object` || !e4 ? null : (e4 = p2 && e4[p2] || e4[`@@iterator`], typeof e4 == `function` ? e4 : null);
  }
  var h2 = { isMounted: function() {
    return false;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, g2 = Object.assign, _2 = {};
  function v2(e4, t3, n3) {
    this.props = e4, this.context = t3, this.refs = _2, this.updater = n3 || h2;
  }
  v2.prototype.isReactComponent = {}, v2.prototype.setState = function(e4, t3) {
    if (typeof e4 != `object` && typeof e4 != `function` && e4 != null) throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);
    this.updater.enqueueSetState(this, e4, t3, `setState`);
  }, v2.prototype.forceUpdate = function(e4) {
    this.updater.enqueueForceUpdate(this, e4, `forceUpdate`);
  };
  function y2() {
  }
  y2.prototype = v2.prototype;
  function b2(e4, t3, n3) {
    this.props = e4, this.context = t3, this.refs = _2, this.updater = n3 || h2;
  }
  var x2 = b2.prototype = new y2();
  x2.constructor = b2, g2(x2, v2.prototype), x2.isPureReactComponent = true;
  var S2 = Array.isArray;
  function C2() {
  }
  var w2 = { H: null, A: null, T: null, S: null }, ee2 = Object.prototype.hasOwnProperty;
  function T2(e4, n3, r3) {
    var i3 = r3.ref;
    return { $$typeof: t2, type: e4, key: n3, ref: i3 === void 0 ? null : i3, props: r3 };
  }
  function te2(e4, t3) {
    return T2(e4.type, t3, e4.props);
  }
  function E2(e4) {
    return typeof e4 == `object` && !!e4 && e4.$$typeof === t2;
  }
  function ne2(e4) {
    var t3 = { "=": `=0`, ":": `=2` };
    return `$` + e4.replace(/[=:]/g, function(e5) {
      return t3[e5];
    });
  }
  var re2 = /\/+/g;
  function D2(e4, t3) {
    return typeof e4 == `object` && e4 && e4.key != null ? ne2(`` + e4.key) : t3.toString(36);
  }
  function ie2(e4) {
    switch (e4.status) {
      case `fulfilled`:
        return e4.value;
      case `rejected`:
        throw e4.reason;
      default:
        switch (typeof e4.status == `string` ? e4.then(C2, C2) : (e4.status = `pending`, e4.then(function(t3) {
          e4.status === `pending` && (e4.status = `fulfilled`, e4.value = t3);
        }, function(t3) {
          e4.status === `pending` && (e4.status = `rejected`, e4.reason = t3);
        })), e4.status) {
          case `fulfilled`:
            return e4.value;
          case `rejected`:
            throw e4.reason;
        }
    }
    throw e4;
  }
  function O2(e4, r3, i3, a3, o3) {
    var s3 = typeof e4;
    (s3 === `undefined` || s3 === `boolean`) && (e4 = null);
    var c3 = false;
    if (e4 === null) c3 = true;
    else switch (s3) {
      case `bigint`:
      case `string`:
      case `number`:
        c3 = true;
        break;
      case `object`:
        switch (e4.$$typeof) {
          case t2:
          case n2:
            c3 = true;
            break;
          case d2:
            return c3 = e4._init, O2(c3(e4._payload), r3, i3, a3, o3);
        }
    }
    if (c3) return o3 = o3(e4), c3 = a3 === `` ? `.` + D2(e4, 0) : a3, S2(o3) ? (i3 = ``, c3 != null && (i3 = c3.replace(re2, `$&/`) + `/`), O2(o3, r3, i3, ``, function(e5) {
      return e5;
    })) : o3 != null && (E2(o3) && (o3 = te2(o3, i3 + (o3.key == null || e4 && e4.key === o3.key ? `` : (`` + o3.key).replace(re2, `$&/`) + `/`) + c3)), r3.push(o3)), 1;
    c3 = 0;
    var l3 = a3 === `` ? `.` : a3 + `:`;
    if (S2(e4)) for (var u3 = 0; u3 < e4.length; u3++) a3 = e4[u3], s3 = l3 + D2(a3, u3), c3 += O2(a3, r3, i3, s3, o3);
    else if (u3 = m2(e4), typeof u3 == `function`) for (e4 = u3.call(e4), u3 = 0; !(a3 = e4.next()).done; ) a3 = a3.value, s3 = l3 + D2(a3, u3++), c3 += O2(a3, r3, i3, s3, o3);
    else if (s3 === `object`) {
      if (typeof e4.then == `function`) return O2(ie2(e4), r3, i3, a3, o3);
      throw r3 = String(e4), Error(`Objects are not valid as a React child (found: ` + (r3 === `[object Object]` ? `object with keys {` + Object.keys(e4).join(`, `) + `}` : r3) + `). If you meant to render a collection of children, use an array instead.`);
    }
    return c3;
  }
  function k2(e4, t3, n3) {
    if (e4 == null) return e4;
    var r3 = [], i3 = 0;
    return O2(e4, r3, ``, ``, function(e5) {
      return t3.call(n3, e5, i3++);
    }), r3;
  }
  function ae2(e4) {
    if (e4._status === -1) {
      var t3 = e4._result;
      t3 = t3(), t3.then(function(t4) {
        (e4._status === 0 || e4._status === -1) && (e4._status = 1, e4._result = t4);
      }, function(t4) {
        (e4._status === 0 || e4._status === -1) && (e4._status = 2, e4._result = t4);
      }), e4._status === -1 && (e4._status = 0, e4._result = t3);
    }
    if (e4._status === 1) return e4._result.default;
    throw e4._result;
  }
  var oe2 = typeof reportError == `function` ? reportError : function(e4) {
    if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
      var t3 = new window.ErrorEvent(`error`, { bubbles: true, cancelable: true, message: typeof e4 == `object` && e4 && typeof e4.message == `string` ? String(e4.message) : String(e4), error: e4 });
      if (!window.dispatchEvent(t3)) return;
    } else if (typeof process == `object` && typeof process.emit == `function`) {
      process.emit(`uncaughtException`, e4);
      return;
    }
    console.error(e4);
  }, se2 = { map: k2, forEach: function(e4, t3, n3) {
    k2(e4, function() {
      t3.apply(this, arguments);
    }, n3);
  }, count: function(e4) {
    var t3 = 0;
    return k2(e4, function() {
      t3++;
    }), t3;
  }, toArray: function(e4) {
    return k2(e4, function(e5) {
      return e5;
    }) || [];
  }, only: function(e4) {
    if (!E2(e4)) throw Error(`React.Children.only expected to receive a single React element child.`);
    return e4;
  } };
  e3.Activity = f2, e3.Children = se2, e3.Component = v2, e3.Fragment = r2, e3.Profiler = a2, e3.PureComponent = b2, e3.StrictMode = i2, e3.Suspense = l2, e3.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = w2, e3.__COMPILER_RUNTIME = { __proto__: null, c: function(e4) {
    return w2.H.useMemoCache(e4);
  } }, e3.cache = function(e4) {
    return function() {
      return e4.apply(null, arguments);
    };
  }, e3.cacheSignal = function() {
    return null;
  }, e3.cloneElement = function(e4, t3, n3) {
    if (e4 == null) throw Error(`The argument must be a React element, but you passed ` + e4 + `.`);
    var r3 = g2({}, e4.props), i3 = e4.key;
    if (t3 != null) for (a3 in t3.key !== void 0 && (i3 = `` + t3.key), t3) !ee2.call(t3, a3) || a3 === `key` || a3 === `__self` || a3 === `__source` || a3 === `ref` && t3.ref === void 0 || (r3[a3] = t3[a3]);
    var a3 = arguments.length - 2;
    if (a3 === 1) r3.children = n3;
    else if (1 < a3) {
      for (var o3 = Array(a3), s3 = 0; s3 < a3; s3++) o3[s3] = arguments[s3 + 2];
      r3.children = o3;
    }
    return T2(e4.type, i3, r3);
  }, e3.createContext = function(e4) {
    return e4 = { $$typeof: s2, _currentValue: e4, _currentValue2: e4, _threadCount: 0, Provider: null, Consumer: null }, e4.Provider = e4, e4.Consumer = { $$typeof: o2, _context: e4 }, e4;
  }, e3.createElement = function(e4, t3, n3) {
    var r3, i3 = {}, a3 = null;
    if (t3 != null) for (r3 in t3.key !== void 0 && (a3 = `` + t3.key), t3) ee2.call(t3, r3) && r3 !== `key` && r3 !== `__self` && r3 !== `__source` && (i3[r3] = t3[r3]);
    var o3 = arguments.length - 2;
    if (o3 === 1) i3.children = n3;
    else if (1 < o3) {
      for (var s3 = Array(o3), c3 = 0; c3 < o3; c3++) s3[c3] = arguments[c3 + 2];
      i3.children = s3;
    }
    if (e4 && e4.defaultProps) for (r3 in o3 = e4.defaultProps, o3) i3[r3] === void 0 && (i3[r3] = o3[r3]);
    return T2(e4, a3, i3);
  }, e3.createRef = function() {
    return { current: null };
  }, e3.forwardRef = function(e4) {
    return { $$typeof: c2, render: e4 };
  }, e3.isValidElement = E2, e3.lazy = function(e4) {
    return { $$typeof: d2, _payload: { _status: -1, _result: e4 }, _init: ae2 };
  }, e3.memo = function(e4, t3) {
    return { $$typeof: u2, type: e4, compare: t3 === void 0 ? null : t3 };
  }, e3.startTransition = function(e4) {
    var t3 = w2.T, n3 = {};
    w2.T = n3;
    try {
      var r3 = e4(), i3 = w2.S;
      i3 !== null && i3(n3, r3), typeof r3 == `object` && r3 && typeof r3.then == `function` && r3.then(C2, oe2);
    } catch (e5) {
      oe2(e5);
    } finally {
      t3 !== null && n3.types !== null && (t3.types = n3.types), w2.T = t3;
    }
  }, e3.unstable_useCacheRefresh = function() {
    return w2.H.useCacheRefresh();
  }, e3.use = function(e4) {
    return w2.H.use(e4);
  }, e3.useActionState = function(e4, t3, n3) {
    return w2.H.useActionState(e4, t3, n3);
  }, e3.useCallback = function(e4, t3) {
    return w2.H.useCallback(e4, t3);
  }, e3.useContext = function(e4) {
    return w2.H.useContext(e4);
  }, e3.useDebugValue = function() {
  }, e3.useDeferredValue = function(e4, t3) {
    return w2.H.useDeferredValue(e4, t3);
  }, e3.useEffect = function(e4, t3) {
    return w2.H.useEffect(e4, t3);
  }, e3.useEffectEvent = function(e4) {
    return w2.H.useEffectEvent(e4);
  }, e3.useId = function() {
    return w2.H.useId();
  }, e3.useImperativeHandle = function(e4, t3, n3) {
    return w2.H.useImperativeHandle(e4, t3, n3);
  }, e3.useInsertionEffect = function(e4, t3) {
    return w2.H.useInsertionEffect(e4, t3);
  }, e3.useLayoutEffect = function(e4, t3) {
    return w2.H.useLayoutEffect(e4, t3);
  }, e3.useMemo = function(e4, t3) {
    return w2.H.useMemo(e4, t3);
  }, e3.useOptimistic = function(e4, t3) {
    return w2.H.useOptimistic(e4, t3);
  }, e3.useReducer = function(e4, t3, n3) {
    return w2.H.useReducer(e4, t3, n3);
  }, e3.useRef = function(e4) {
    return w2.H.useRef(e4);
  }, e3.useState = function(e4) {
    return w2.H.useState(e4);
  }, e3.useSyncExternalStore = function(e4, t3, n3) {
    return w2.H.useSyncExternalStore(e4, t3, n3);
  }, e3.useTransition = function() {
    return w2.H.useTransition();
  }, e3.version = `19.2.8`;
})), a = r(((e3, t2) => {
  t2.exports = i();
})), o = n({ Activity: () => l, Children: () => u, Component: () => d, Fragment: () => f, Profiler: () => p, PureComponent: () => m, StrictMode: () => h, Suspense: () => g, __CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE: () => _, __COMPILER_RUNTIME: () => v, cache: () => y, cacheSignal: () => b, cloneElement: () => x, createContext: () => S, createElement: () => C, createRef: () => w, default: () => xe, forwardRef: () => ee, isValidElement: () => T, lazy: () => te, memo: () => E, startTransition: () => ne, unstable_useCacheRefresh: () => re, use: () => D, useActionState: () => ie, useCallback: () => O, useContext: () => k, useDebugValue: () => ae, useDeferredValue: () => oe, useEffect: () => se, useEffectEvent: () => ce, useId: () => le, useImperativeHandle: () => ue, useInsertionEffect: () => de, useLayoutEffect: () => fe, useMemo: () => pe, useOptimistic: () => me, useReducer: () => he, useRef: () => ge, useState: () => _e, useSyncExternalStore: () => ve, useTransition: () => ye, version: () => be }), s, c, l, u, d, f, p, m, h, g, _, v, y, b, x, S, C, w, ee, T, te, E, ne, re, D, ie, O, k, ae, oe, se, ce, le, ue, de, fe, pe, me, he, ge, _e, ve, ye, be, xe, Se = e((() => {
  s = t(a()), c = s, l = c.Activity, u = c.Children, d = c.Component, f = c.Fragment, p = c.Profiler, m = c.PureComponent, h = c.StrictMode, g = c.Suspense, _ = c.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, v = c.__COMPILER_RUNTIME, y = c.cache, b = c.cacheSignal, x = c.cloneElement, S = c.createContext, C = c.createElement, w = c.createRef, ee = c.forwardRef, T = c.isValidElement, te = c.lazy, E = c.memo, ne = c.startTransition, re = c.unstable_useCacheRefresh, D = c.use, ie = c.useActionState, O = c.useCallback, k = c.useContext, ae = c.useDebugValue, oe = c.useDeferredValue, se = c.useEffect, ce = c.useEffectEvent, le = c.useId, ue = c.useImperativeHandle, de = c.useInsertionEffect, fe = c.useLayoutEffect, pe = c.useMemo, me = c.useOptimistic, he = c.useReducer, ge = c.useRef, _e = c.useState, ve = c.useSyncExternalStore, ye = c.useTransition, be = c.version, xe = Reflect.get(s, `default`) ?? s;
})), Ce = n({ Activity: () => Pe, Children: () => Fe, Component: () => Ie, Fragment: () => M, Profiler: () => Le, PureComponent: () => Re, StrictMode: () => ze, Suspense: () => Be, __CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE: () => Ve, __COMPILER_RUNTIME: () => He, __moduleExports: () => yt, cache: () => Ue, cacheSignal: () => We, cloneElement: () => Ge, createContext: () => N, createElement: () => P, createRef: () => Ke, default: () => Ne, forwardRef: () => qe, isValidElement: () => Je, lazy: () => Ye, memo: () => Xe, startTransition: () => Ze, unstable_useCacheRefresh: () => Qe, use: () => $e, useActionState: () => et, useCallback: () => tt, useContext: () => F, useDebugValue: () => nt, useDeferredValue: () => rt, useEffect: () => it, useEffectEvent: () => at, useId: () => ot, useImperativeHandle: () => st, useInsertionEffect: () => ct, useLayoutEffect: () => lt, useMemo: () => ut, useOptimistic: () => dt, useReducer: () => ft, useRef: () => pt, useState: () => mt, useSyncExternalStore: () => ht, useTransition: () => gt, version: () => _t }), we, A, Te, Ee, De, Oe, ke, Ae, je, Me, j, Ne, Pe, Fe, Ie, M, Le, Re, ze, Be, Ve, He, Ue, We, Ge, N, P, Ke, qe, Je, Ye, Xe, Ze, Qe, $e, et, tt, F, nt, rt, it, at, ot, st, ct, lt, ut, dt, ft, pt, mt, ht, gt, _t, vt, yt, bt = e((() => {
  var _a2, _b2;
  Se(), we = `__mf_module_cache__`, globalThis[we] || (globalThis[we] = { share: {}, remote: {} }), (_a2 = globalThis[we]).share || (_a2.share = {}), (_b2 = globalThis[we]).remote || (_b2.remote = {}), A = globalThis[we];
  for (let e3 of Object.keys(A.share)) if (e3.startsWith(`default:`)) {
    let t2 = e3.slice(8);
    A.share[t2] === void 0 && (A.share[t2] = A.share[e3]);
  } else if (!e3.includes(`:`)) {
    let t2 = `default:` + e3;
    A.share[t2] === void 0 && (A.share[t2] = A.share[e3]);
  }
  Te = (e3, t2) => {
    let n2 = e3[t2.canonical];
    if (n2 !== void 0) return n2;
    let r2 = t2.aliases || [];
    for (let n3 of r2) {
      if (!Object.prototype.hasOwnProperty.call(e3, n3)) continue;
      let r3 = e3[n3];
      if (r3 !== void 0) return e3[t2.canonical] = r3, r3;
    }
  }, Ee = /* @__PURE__ */ Symbol.for(`module-federation.shared-cache-listeners`), De = (e3) => {
    let t2 = e3[Ee];
    return t2 === void 0 && (t2 = /* @__PURE__ */ Object.create(null), Object.defineProperty(e3, Ee, { value: t2, enumerable: false, configurable: false, writable: false })), t2;
  }, Oe = (e3, t2, n2) => {
    var _a3;
    let r2 = De(e3);
    (r2[_a3 = t2.canonical] || (r2[_a3] = /* @__PURE__ */ new Set())).add(n2);
  }, ke = /* @__PURE__ */ Symbol.for(`module-federation.shared-cache-owners`), Ae = (e3) => {
    let t2 = e3[ke];
    return t2 === void 0 && (t2 = /* @__PURE__ */ Object.create(null), Object.defineProperty(e3, ke, { value: t2, enumerable: false, configurable: false, writable: false })), t2;
  }, je = (e3, t2, n2, r2) => {
    var _a3;
    e3[t2.canonical] = n2;
    let i2 = t2.aliases || [];
    for (let t3 of i2) Object.defineProperty(e3, t3, { value: n2, enumerable: true, configurable: true, writable: true });
    let a2 = e3[ke];
    r2 === void 0 ? a2 && delete a2[t2.canonical] : Ae(e3)[t2.canonical] = r2;
    let o2 = (_a3 = e3[Ee]) == null ? void 0 : _a3[t2.canonical];
    if (o2) for (let e4 of o2) e4(n2);
    return n2;
  }, Me = (e3) => {
    let t2 = (() => {
      let t3 = e3;
      for (let e4 = 0; e4 < 5; e4++) {
        let e5 = t3 == null ? void 0 : t3.default;
        if (!e5 || typeof e5 != `object`) break;
        let n2 = Object.keys(t3).filter((e6) => e6 !== "default").map((e6) => t3[e6]);
        if (n2.length > 0 && n2.some((e6) => e6 !== void 0)) break;
        t3 = e5;
      }
      return t3;
    })();
    return t2 && Object.getPrototypeOf(t2) === null ? Object.assign({}, t2) : t2;
  }, j = Te(A.share, { canonical: `default:react`, aliases: [`react`] }), j === void 0 && (j = Me(o), je(A.share, { canonical: `default:react`, aliases: [`react`] }, j, `vis2nilsForkWidgets`)), vt = (e3) => {
    let t2 = e3.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    if (t2 && `A` in t2) {
      let e4 = t2.A;
      Object.defineProperty(t2, "A", { configurable: true, enumerable: true, get: () => e4, set: (t3) => {
        t3 && typeof t3.getOwner != `function` && (t3.getOwner = () => null), e4 = t3;
      } }), t2.A = e4;
    }
    Pe = e3.Activity, Fe = e3.Children, Ie = e3.Component, M = e3.Fragment, Le = e3.Profiler, Re = e3.PureComponent, ze = e3.StrictMode, Be = e3.Suspense, Ve = e3.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, He = e3.__COMPILER_RUNTIME, Ue = e3.cache, We = e3.cacheSignal, Ge = e3.cloneElement, N = e3.createContext, P = e3.createElement, Ke = e3.createRef, qe = e3.forwardRef, Je = e3.isValidElement, Ye = e3.lazy, Xe = e3.memo, Ze = e3.startTransition, Qe = e3.unstable_useCacheRefresh, $e = e3.use, et = e3.useActionState, tt = e3.useCallback, F = e3.useContext, nt = e3.useDebugValue, rt = e3.useDeferredValue, it = e3.useEffect, at = e3.useEffectEvent, ot = e3.useId, st = e3.useImperativeHandle, ct = e3.useInsertionEffect, lt = e3.useLayoutEffect, ut = e3.useMemo, dt = e3.useOptimistic, ft = e3.useReducer, pt = e3.useRef, mt = e3.useState, ht = e3.useSyncExternalStore, gt = e3.useTransition, _t = e3.version, Ne = (() => {
      let t3 = e3;
      for (let e4 = 0; e4 < 5; e4++) {
        let e5 = t3 == null ? void 0 : t3.default;
        if (!e5 || typeof e5 != `object`) return e5 ?? t3;
        t3 = e5;
      }
      return t3;
    })();
  }, Oe(A.share, { canonical: `default:react`, aliases: [`react`] }, vt), vt(j), yt = j;
}));
bt();
function xt(e3) {
  if (e3.sheet) return e3.sheet;
  for (var t2 = 0; t2 < document.styleSheets.length; t2++) if (document.styleSheets[t2].ownerNode === e3) return document.styleSheets[t2];
}
function St(e3) {
  var t2 = document.createElement(`style`);
  return t2.setAttribute(`data-emotion`, e3.key), e3.nonce !== void 0 && t2.setAttribute(`nonce`, e3.nonce), t2.appendChild(document.createTextNode(``)), t2.setAttribute(`data-s`, ``), t2;
}
var Ct = (function() {
  function e3(e4) {
    var t3 = this;
    this._insertTag = function(e5) {
      var n2 = t3.tags.length === 0 ? t3.insertionPoint ? t3.insertionPoint.nextSibling : t3.prepend ? t3.container.firstChild : t3.before : t3.tags[t3.tags.length - 1].nextSibling;
      t3.container.insertBefore(e5, n2), t3.tags.push(e5);
    }, this.isSpeedy = e4.speedy === void 0 || e4.speedy, this.tags = [], this.ctr = 0, this.nonce = e4.nonce, this.key = e4.key, this.container = e4.container, this.prepend = e4.prepend, this.insertionPoint = e4.insertionPoint, this.before = null;
  }
  var t2 = e3.prototype;
  return t2.hydrate = function(e4) {
    e4.forEach(this._insertTag);
  }, t2.insert = function(e4) {
    this.ctr % (this.isSpeedy ? 65e3 : 1) == 0 && this._insertTag(St(this));
    var t3 = this.tags[this.tags.length - 1];
    if (this.isSpeedy) {
      var n2 = xt(t3);
      try {
        n2.insertRule(e4, n2.cssRules.length);
      } catch {
      }
    } else t3.appendChild(document.createTextNode(e4));
    this.ctr++;
  }, t2.flush = function() {
    this.tags.forEach(function(e4) {
      var _a2;
      return (_a2 = e4.parentNode) == null ? void 0 : _a2.removeChild(e4);
    }), this.tags = [], this.ctr = 0;
  }, e3;
})(), I = `-ms-`, wt = `-moz-`, L = `-webkit-`, Tt = `comm`, Et = `rule`, Dt = `decl`, Ot = `@import`, kt = `@keyframes`, At = `@layer`, jt = Math.abs, Mt = String.fromCharCode, Nt = Object.assign;
function Pt(e3, t2) {
  return z(e3, 0) ^ 45 ? (((t2 << 2 ^ z(e3, 0)) << 2 ^ z(e3, 1)) << 2 ^ z(e3, 2)) << 2 ^ z(e3, 3) : 0;
}
function Ft(e3) {
  return e3.trim();
}
function It(e3, t2) {
  return (e3 = t2.exec(e3)) ? e3[0] : e3;
}
function R(e3, t2, n2) {
  return e3.replace(t2, n2);
}
function Lt(e3, t2) {
  return e3.indexOf(t2);
}
function z(e3, t2) {
  return e3.charCodeAt(t2) | 0;
}
function B(e3, t2, n2) {
  return e3.slice(t2, n2);
}
function V(e3) {
  return e3.length;
}
function Rt(e3) {
  return e3.length;
}
function zt(e3, t2) {
  return t2.push(e3), e3;
}
function Bt(e3, t2) {
  return e3.map(t2).join(``);
}
var Vt = 1, H = 1, Ht = 0, U = 0, W = 0, G = ``;
function Ut(e3, t2, n2, r2, i2, a2, o2) {
  return { value: e3, root: t2, parent: n2, type: r2, props: i2, children: a2, line: Vt, column: H, length: o2, return: `` };
}
function K(e3, t2) {
  return Nt(Ut(``, null, null, ``, null, null, 0), e3, { length: -e3.length }, t2);
}
function Wt() {
  return W;
}
function Gt() {
  return W = U > 0 ? z(G, --U) : 0, H--, W === 10 && (H = 1, Vt--), W;
}
function q() {
  return W = U < Ht ? z(G, U++) : 0, H++, W === 10 && (H = 1, Vt++), W;
}
function J() {
  return z(G, U);
}
function Kt() {
  return U;
}
function qt(e3, t2) {
  return B(G, e3, t2);
}
function Jt(e3) {
  switch (e3) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function Yt(e3) {
  return Vt = H = 1, Ht = V(G = e3), U = 0, [];
}
function Xt(e3) {
  return G = ``, e3;
}
function Zt(e3) {
  return Ft(qt(U - 1, en(e3 === 91 ? e3 + 2 : e3 === 40 ? e3 + 1 : e3)));
}
function Qt(e3) {
  for (; (W = J()) && W < 33; ) q();
  return Jt(e3) > 2 || Jt(W) > 3 ? `` : ` `;
}
function $t(e3, t2) {
  for (; --t2 && q() && !(W < 48 || W > 102 || W > 57 && W < 65 || W > 70 && W < 97); ) ;
  return qt(e3, Kt() + (t2 < 6 && J() == 32 && q() == 32));
}
function en(e3) {
  for (; q(); ) switch (W) {
    case e3:
      return U;
    case 34:
    case 39:
      e3 !== 34 && e3 !== 39 && en(W);
      break;
    case 40:
      e3 === 41 && en(e3);
      break;
    case 92:
      q();
  }
  return U;
}
function tn(e3, t2) {
  for (; q() && e3 + W !== 57 && (e3 + W !== 84 || J() !== 47); ) ;
  return `/*` + qt(t2, U - 1) + `*` + Mt(e3 === 47 ? e3 : q());
}
function nn(e3) {
  for (; !Jt(J()); ) q();
  return qt(e3, U);
}
function rn(e3) {
  return Xt(an(``, null, null, null, [``], e3 = Yt(e3), 0, [0], e3));
}
function an(e3, t2, n2, r2, i2, a2, o2, s2, c2) {
  for (var l2 = 0, u2 = 0, d2 = o2, f2 = 0, p2 = 0, m2 = 0, h2 = 1, g2 = 1, _2 = 1, v2 = 0, y2 = ``, b2 = i2, x2 = a2, S2 = r2, C2 = y2; g2; ) switch (m2 = v2, v2 = q()) {
    case 40:
      if (m2 != 108 && z(C2, d2 - 1) == 58) {
        Lt(C2 += R(Zt(v2), `&`, `&\f`), `&\f`) != -1 && (_2 = -1);
        break;
      }
    case 34:
    case 39:
    case 91:
      C2 += Zt(v2);
      break;
    case 9:
    case 10:
    case 13:
    case 32:
      C2 += Qt(m2);
      break;
    case 92:
      C2 += $t(Kt() - 1, 7);
      continue;
    case 47:
      switch (J()) {
        case 42:
        case 47:
          zt(sn(tn(q(), Kt()), t2, n2), c2);
          break;
        default:
          C2 += `/`;
      }
      break;
    case 123 * h2:
      s2[l2++] = V(C2) * _2;
    case 125 * h2:
    case 59:
    case 0:
      switch (v2) {
        case 0:
        case 125:
          g2 = 0;
        case 59 + u2:
          _2 == -1 && (C2 = R(C2, /\f/g, ``)), p2 > 0 && V(C2) - d2 && zt(p2 > 32 ? cn(C2 + `;`, r2, n2, d2 - 1) : cn(R(C2, ` `, ``) + `;`, r2, n2, d2 - 2), c2);
          break;
        case 59:
          C2 += `;`;
        default:
          if (zt(S2 = on(C2, t2, n2, l2, u2, i2, s2, y2, b2 = [], x2 = [], d2), a2), v2 === 123) {
            if (u2 === 0) an(C2, t2, S2, S2, b2, a2, d2, s2, x2);
            else switch (f2 === 99 && z(C2, 3) === 110 ? 100 : f2) {
              case 100:
              case 108:
              case 109:
              case 115:
                an(e3, S2, S2, r2 && zt(on(e3, S2, S2, 0, 0, i2, s2, y2, i2, b2 = [], d2), x2), i2, x2, d2, s2, r2 ? b2 : x2);
                break;
              default:
                an(C2, S2, S2, S2, [``], x2, 0, s2, x2);
            }
          }
      }
      l2 = u2 = p2 = 0, h2 = _2 = 1, y2 = C2 = ``, d2 = o2;
      break;
    case 58:
      d2 = 1 + V(C2), p2 = m2;
    default:
      if (h2 < 1) {
        if (v2 == 123) --h2;
        else if (v2 == 125 && h2++ == 0 && Gt() == 125) continue;
      }
      switch (C2 += Mt(v2), v2 * h2) {
        case 38:
          _2 = u2 > 0 ? 1 : (C2 += `\f`, -1);
          break;
        case 44:
          s2[l2++] = (V(C2) - 1) * _2, _2 = 1;
          break;
        case 64:
          J() === 45 && (C2 += Zt(q())), f2 = J(), u2 = d2 = V(y2 = C2 += nn(Kt())), v2++;
          break;
        case 45:
          m2 === 45 && V(C2) == 2 && (h2 = 0);
      }
  }
  return a2;
}
function on(e3, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2) {
  for (var d2 = i2 - 1, f2 = i2 === 0 ? a2 : [``], p2 = Rt(f2), m2 = 0, h2 = 0, g2 = 0; m2 < r2; ++m2) for (var _2 = 0, v2 = B(e3, d2 + 1, d2 = jt(h2 = o2[m2])), y2 = e3; _2 < p2; ++_2) (y2 = Ft(h2 > 0 ? f2[_2] + ` ` + v2 : R(v2, /&\f/g, f2[_2]))) && (c2[g2++] = y2);
  return Ut(e3, t2, n2, i2 === 0 ? Et : s2, c2, l2, u2);
}
function sn(e3, t2, n2) {
  return Ut(e3, t2, n2, Tt, Mt(Wt()), B(e3, 2, -2), 0);
}
function cn(e3, t2, n2, r2) {
  return Ut(e3, t2, n2, Dt, B(e3, 0, r2), B(e3, r2 + 1, -1), r2);
}
function Y(e3, t2) {
  for (var n2 = ``, r2 = Rt(e3), i2 = 0; i2 < r2; i2++) n2 += t2(e3[i2], i2, e3, t2) || ``;
  return n2;
}
function ln(e3, t2, n2, r2) {
  switch (e3.type) {
    case At:
      if (e3.children.length) break;
    case Ot:
    case Dt:
      return e3.return = e3.return || e3.value;
    case Tt:
      return ``;
    case kt:
      return e3.return = e3.value + `{` + Y(e3.children, r2) + `}`;
    case Et:
      e3.value = e3.props.join(`,`);
  }
  return V(n2 = Y(e3.children, r2)) ? e3.return = e3.value + `{` + n2 + `}` : ``;
}
function un(e3) {
  var t2 = Rt(e3);
  return function(n2, r2, i2, a2) {
    for (var o2 = ``, s2 = 0; s2 < t2; s2++) o2 += e3[s2](n2, r2, i2, a2) || ``;
    return o2;
  };
}
function dn(e3) {
  return function(t2) {
    t2.root || (t2 = t2.return) && e3(t2);
  };
}
var fn = function(e3) {
  var t2 = /* @__PURE__ */ new WeakMap();
  return function(n2) {
    if (t2.has(n2)) return t2.get(n2);
    var r2 = e3(n2);
    return t2.set(n2, r2), r2;
  };
};
function pn(e3) {
  var t2 = /* @__PURE__ */ Object.create(null);
  return function(n2) {
    return t2[n2] === void 0 && (t2[n2] = e3(n2)), t2[n2];
  };
}
var mn = function(e3, t2, n2) {
  for (var r2 = 0, i2 = 0; r2 = i2, i2 = J(), r2 === 38 && i2 === 12 && (t2[n2] = 1), !Jt(i2); ) q();
  return qt(e3, U);
}, hn = function(e3, t2) {
  var n2 = -1, r2 = 44;
  do
    switch (Jt(r2)) {
      case 0:
        r2 === 38 && J() === 12 && (t2[n2] = 1), e3[n2] += mn(U - 1, t2, n2);
        break;
      case 2:
        e3[n2] += Zt(r2);
        break;
      case 4:
        if (r2 === 44) {
          e3[++n2] = J() === 58 ? `&\f` : ``, t2[n2] = e3[n2].length;
          break;
        }
      default:
        e3[n2] += Mt(r2);
    }
  while (r2 = q());
  return e3;
}, gn = function(e3, t2) {
  return Xt(hn(Yt(e3), t2));
}, _n = /* @__PURE__ */ new WeakMap(), vn = function(e3) {
  if (!(e3.type !== `rule` || !e3.parent || e3.length < 1)) {
    for (var t2 = e3.value, n2 = e3.parent, r2 = e3.column === n2.column && e3.line === n2.line; n2.type !== `rule`; ) if (n2 = n2.parent, !n2) return;
    if ((e3.props.length !== 1 || t2.charCodeAt(0) === 58 || _n.get(n2)) && !r2) {
      _n.set(e3, true);
      for (var i2 = [], a2 = gn(t2, i2), o2 = n2.props, s2 = 0, c2 = 0; s2 < a2.length; s2++) for (var l2 = 0; l2 < o2.length; l2++, c2++) e3.props[c2] = i2[s2] ? a2[s2].replace(/&\f/g, o2[l2]) : o2[l2] + ` ` + a2[s2];
    }
  }
}, yn = function(e3) {
  if (e3.type === `decl`) {
    var t2 = e3.value;
    t2.charCodeAt(0) === 108 && t2.charCodeAt(2) === 98 && (e3.return = ``, e3.value = ``);
  }
};
function bn(e3, t2) {
  switch (Pt(e3, t2)) {
    case 5103:
      return L + `print-` + e3 + e3;
    case 5737:
    case 4201:
    case 3177:
    case 3433:
    case 1641:
    case 4457:
    case 2921:
    case 5572:
    case 6356:
    case 5844:
    case 3191:
    case 6645:
    case 3005:
    case 6391:
    case 5879:
    case 5623:
    case 6135:
    case 4599:
    case 4855:
    case 4215:
    case 6389:
    case 5109:
    case 5365:
    case 5621:
    case 3829:
      return L + e3 + e3;
    case 5349:
    case 4246:
    case 4810:
    case 6968:
    case 2756:
      return L + e3 + wt + e3 + I + e3 + e3;
    case 6828:
    case 4268:
      return L + e3 + I + e3 + e3;
    case 6165:
      return L + e3 + I + `flex-` + e3 + e3;
    case 5187:
      return L + e3 + R(e3, /(\w+).+(:[^]+)/, L + `box-$1$2` + I + `flex-$1$2`) + e3;
    case 5443:
      return L + e3 + I + `flex-item-` + R(e3, /flex-|-self/, ``) + e3;
    case 4675:
      return L + e3 + I + `flex-line-pack` + R(e3, /align-content|flex-|-self/, ``) + e3;
    case 5548:
      return L + e3 + I + R(e3, `shrink`, `negative`) + e3;
    case 5292:
      return L + e3 + I + R(e3, `basis`, `preferred-size`) + e3;
    case 6060:
      return L + `box-` + R(e3, `-grow`, ``) + L + e3 + I + R(e3, `grow`, `positive`) + e3;
    case 4554:
      return L + R(e3, /([^-])(transform)/g, `$1` + L + `$2`) + e3;
    case 6187:
      return R(R(R(e3, /(zoom-|grab)/, L + `$1`), /(image-set)/, L + `$1`), e3, ``) + e3;
    case 5495:
    case 3959:
      return R(e3, /(image-set\([^]*)/, L + "$1$`$1");
    case 4968:
      return R(R(e3, /(.+:)(flex-)?(.*)/, L + `box-pack:$3` + I + `flex-pack:$3`), /s.+-b[^;]+/, `justify`) + L + e3 + e3;
    case 4095:
    case 3583:
    case 4068:
    case 2532:
      return R(e3, /(.+)-inline(.+)/, L + `$1$2`) + e3;
    case 8116:
    case 7059:
    case 5753:
    case 5535:
    case 5445:
    case 5701:
    case 4933:
    case 4677:
    case 5533:
    case 5789:
    case 5021:
    case 4765:
      if (V(e3) - 1 - t2 > 6) switch (z(e3, t2 + 1)) {
        case 109:
          if (z(e3, t2 + 4) !== 45) break;
        case 102:
          return R(e3, /(.+:)(.+)-([^]+)/, `$1` + L + `$2-$3$1` + wt + (z(e3, t2 + 3) == 108 ? `$3` : `$2-$3`)) + e3;
        case 115:
          return ~Lt(e3, `stretch`) ? bn(R(e3, `stretch`, `fill-available`), t2) + e3 : e3;
      }
      break;
    case 4949:
      if (z(e3, t2 + 1) !== 115) break;
    case 6444:
      switch (z(e3, V(e3) - 3 - (~Lt(e3, `!important`) && 10))) {
        case 107:
          return R(e3, `:`, `:` + L) + e3;
        case 101:
          return R(e3, /(.+:)([^;!]+)(;|!.+)?/, `$1` + L + (z(e3, 14) === 45 ? `inline-` : ``) + `box$3$1` + L + `$2$3$1` + I + `$2box$3`) + e3;
      }
      break;
    case 5936:
      switch (z(e3, t2 + 11)) {
        case 114:
          return L + e3 + I + R(e3, /[svh]\w+-[tblr]{2}/, `tb`) + e3;
        case 108:
          return L + e3 + I + R(e3, /[svh]\w+-[tblr]{2}/, `tb-rl`) + e3;
        case 45:
          return L + e3 + I + R(e3, /[svh]\w+-[tblr]{2}/, `lr`) + e3;
      }
      return L + e3 + I + e3 + e3;
  }
  return e3;
}
var xn = [function(e3, t2, n2, r2) {
  if (e3.length > -1 && !e3.return) switch (e3.type) {
    case Dt:
      e3.return = bn(e3.value, e3.length);
      break;
    case kt:
      return Y([K(e3, { value: R(e3.value, `@`, `@` + L) })], r2);
    case Et:
      if (e3.length) return Bt(e3.props, function(t3) {
        switch (It(t3, /(::plac\w+|:read-\w+)/)) {
          case `:read-only`:
          case `:read-write`:
            return Y([K(e3, { props: [R(t3, /:(read-\w+)/, `:` + wt + `$1`)] })], r2);
          case `::placeholder`:
            return Y([K(e3, { props: [R(t3, /:(plac\w+)/, `:` + L + `input-$1`)] }), K(e3, { props: [R(t3, /:(plac\w+)/, `:` + wt + `$1`)] }), K(e3, { props: [R(t3, /:(plac\w+)/, I + `input-$1`)] })], r2);
        }
        return ``;
      });
  }
}], Sn = function(e3) {
  var t2 = e3.key;
  if (t2 === `css`) {
    var n2 = document.querySelectorAll(`style[data-emotion]:not([data-s])`);
    Array.prototype.forEach.call(n2, function(e4) {
      e4.getAttribute(`data-emotion`).indexOf(` `) !== -1 && (document.head.appendChild(e4), e4.setAttribute(`data-s`, ``));
    });
  }
  var r2 = e3.stylisPlugins || xn, i2 = {}, a2, o2 = [];
  a2 = e3.container || document.head, Array.prototype.forEach.call(document.querySelectorAll(`style[data-emotion^="` + t2 + ` "]`), function(e4) {
    for (var t3 = e4.getAttribute(`data-emotion`).split(` `), n3 = 1; n3 < t3.length; n3++) i2[t3[n3]] = true;
    o2.push(e4);
  });
  var s2, c2 = [vn, yn], l2, u2 = [ln, dn(function(e4) {
    l2.insert(e4);
  })], d2 = un(c2.concat(r2, u2)), f2 = function(e4) {
    return Y(rn(e4), d2);
  };
  s2 = function(e4, t3, n3, r3) {
    l2 = n3, f2(e4 ? e4 + `{` + t3.styles + `}` : t3.styles), r3 && (p2.inserted[t3.name] = true);
  };
  var p2 = { key: t2, sheet: new Ct({ key: t2, container: a2, nonce: e3.nonce, speedy: e3.speedy, prepend: e3.prepend, insertionPoint: e3.insertionPoint }), nonce: e3.nonce, inserted: i2, registered: {}, insert: s2 };
  return p2.sheet.hydrate(o2), p2;
};
function Cn() {
  return Cn = Object.assign ? Object.assign.bind() : function(e3) {
    for (var t2 = 1; t2 < arguments.length; t2++) {
      var n2 = arguments[t2];
      for (var r2 in n2) ({}).hasOwnProperty.call(n2, r2) && (e3[r2] = n2[r2]);
    }
    return e3;
  }, Cn.apply(null, arguments);
}
var wn = r(((e3) => {
  var t2 = typeof Symbol == `function` && Symbol.for, n2 = t2 ? /* @__PURE__ */ Symbol.for(`react.element`) : 60103, r2 = t2 ? /* @__PURE__ */ Symbol.for(`react.portal`) : 60106, i2 = t2 ? /* @__PURE__ */ Symbol.for(`react.fragment`) : 60107, a2 = t2 ? /* @__PURE__ */ Symbol.for(`react.strict_mode`) : 60108, o2 = t2 ? /* @__PURE__ */ Symbol.for(`react.profiler`) : 60114, s2 = t2 ? /* @__PURE__ */ Symbol.for(`react.provider`) : 60109, c2 = t2 ? /* @__PURE__ */ Symbol.for(`react.context`) : 60110, l2 = t2 ? /* @__PURE__ */ Symbol.for(`react.async_mode`) : 60111, u2 = t2 ? /* @__PURE__ */ Symbol.for(`react.concurrent_mode`) : 60111, d2 = t2 ? /* @__PURE__ */ Symbol.for(`react.forward_ref`) : 60112, f2 = t2 ? /* @__PURE__ */ Symbol.for(`react.suspense`) : 60113, p2 = t2 ? /* @__PURE__ */ Symbol.for(`react.suspense_list`) : 60120, m2 = t2 ? /* @__PURE__ */ Symbol.for(`react.memo`) : 60115, h2 = t2 ? /* @__PURE__ */ Symbol.for(`react.lazy`) : 60116, g2 = t2 ? /* @__PURE__ */ Symbol.for(`react.block`) : 60121, _2 = t2 ? /* @__PURE__ */ Symbol.for(`react.fundamental`) : 60117, v2 = t2 ? /* @__PURE__ */ Symbol.for(`react.responder`) : 60118, y2 = t2 ? /* @__PURE__ */ Symbol.for(`react.scope`) : 60119;
  function b2(e4) {
    if (typeof e4 == `object` && e4) {
      var t3 = e4.$$typeof;
      switch (t3) {
        case n2:
          switch (e4 = e4.type, e4) {
            case l2:
            case u2:
            case i2:
            case o2:
            case a2:
            case f2:
              return e4;
            default:
              switch (e4 && (e4 = e4.$$typeof), e4) {
                case c2:
                case d2:
                case h2:
                case m2:
                case s2:
                  return e4;
                default:
                  return t3;
              }
          }
        case r2:
          return t3;
      }
    }
  }
  function x2(e4) {
    return b2(e4) === u2;
  }
  e3.AsyncMode = l2, e3.ConcurrentMode = u2, e3.ContextConsumer = c2, e3.ContextProvider = s2, e3.Element = n2, e3.ForwardRef = d2, e3.Fragment = i2, e3.Lazy = h2, e3.Memo = m2, e3.Portal = r2, e3.Profiler = o2, e3.StrictMode = a2, e3.Suspense = f2, e3.isAsyncMode = function(e4) {
    return x2(e4) || b2(e4) === l2;
  }, e3.isConcurrentMode = x2, e3.isContextConsumer = function(e4) {
    return b2(e4) === c2;
  }, e3.isContextProvider = function(e4) {
    return b2(e4) === s2;
  }, e3.isElement = function(e4) {
    return typeof e4 == `object` && !!e4 && e4.$$typeof === n2;
  }, e3.isForwardRef = function(e4) {
    return b2(e4) === d2;
  }, e3.isFragment = function(e4) {
    return b2(e4) === i2;
  }, e3.isLazy = function(e4) {
    return b2(e4) === h2;
  }, e3.isMemo = function(e4) {
    return b2(e4) === m2;
  }, e3.isPortal = function(e4) {
    return b2(e4) === r2;
  }, e3.isProfiler = function(e4) {
    return b2(e4) === o2;
  }, e3.isStrictMode = function(e4) {
    return b2(e4) === a2;
  }, e3.isSuspense = function(e4) {
    return b2(e4) === f2;
  }, e3.isValidElementType = function(e4) {
    return typeof e4 == `string` || typeof e4 == `function` || e4 === i2 || e4 === u2 || e4 === o2 || e4 === a2 || e4 === f2 || e4 === p2 || typeof e4 == `object` && !!e4 && (e4.$$typeof === h2 || e4.$$typeof === m2 || e4.$$typeof === s2 || e4.$$typeof === c2 || e4.$$typeof === d2 || e4.$$typeof === _2 || e4.$$typeof === v2 || e4.$$typeof === y2 || e4.$$typeof === g2);
  }, e3.typeOf = b2;
})), Tn = r(((e3, t2) => {
  t2.exports = wn();
})), En = t(r(((e3, t2) => {
  var n2 = Tn(), r2 = { childContextTypes: true, contextType: true, contextTypes: true, defaultProps: true, displayName: true, getDefaultProps: true, getDerivedStateFromError: true, getDerivedStateFromProps: true, mixins: true, propTypes: true, type: true }, i2 = { name: true, length: true, prototype: true, caller: true, callee: true, arguments: true, arity: true }, a2 = { $$typeof: true, render: true, defaultProps: true, displayName: true, propTypes: true }, o2 = { $$typeof: true, compare: true, defaultProps: true, displayName: true, propTypes: true, type: true }, s2 = {};
  s2[n2.ForwardRef] = a2, s2[n2.Memo] = o2;
  function c2(e4) {
    return n2.isMemo(e4) ? o2 : s2[e4.$$typeof] || r2;
  }
  var l2 = Object.defineProperty, u2 = Object.getOwnPropertyNames, d2 = Object.getOwnPropertySymbols, f2 = Object.getOwnPropertyDescriptor, p2 = Object.getPrototypeOf, m2 = Object.prototype;
  function h2(e4, t3, n3) {
    if (typeof t3 != `string`) {
      if (m2) {
        var r3 = p2(t3);
        r3 && r3 !== m2 && h2(e4, r3, n3);
      }
      var a3 = u2(t3);
      d2 && (a3 = a3.concat(d2(t3)));
      for (var o3 = c2(e4), s3 = c2(t3), g2 = 0; g2 < a3.length; ++g2) {
        var _2 = a3[g2];
        if (!i2[_2] && !(n3 && n3[_2]) && !(s3 && s3[_2]) && !(o3 && o3[_2])) {
          var v2 = f2(t3, _2);
          try {
            l2(e4, _2, v2);
          } catch {
          }
        }
      }
    }
    return e4;
  }
  t2.exports = h2;
}))()), Dn = (function(e3, t2) {
  return (0, En.default)(e3, t2);
});
function On(e3, t2, n2) {
  var r2 = ``;
  return n2.split(` `).forEach(function(n3) {
    e3[n3] === void 0 ? n3 && (r2 += n3 + ` `) : t2.push(e3[n3] + `;`);
  }), r2;
}
var kn = function(e3, t2, n2) {
  var r2 = e3.key + `-` + t2.name;
  n2 === false && e3.registered[r2] === void 0 && (e3.registered[r2] = t2.styles);
}, An = function(e3, t2, n2) {
  kn(e3, t2, n2);
  var r2 = e3.key + `-` + t2.name;
  if (e3.inserted[t2.name] === void 0) {
    var i2 = t2;
    do
      e3.insert(t2 === i2 ? `.` + r2 : ``, i2, e3.sheet, true), i2 = i2.next;
    while (i2 !== void 0);
  }
};
function jn(e3) {
  for (var t2 = 0, n2, r2 = 0, i2 = e3.length; i2 >= 4; ++r2, i2 -= 4) n2 = e3.charCodeAt(r2) & 255 | (e3.charCodeAt(++r2) & 255) << 8 | (e3.charCodeAt(++r2) & 255) << 16 | (e3.charCodeAt(++r2) & 255) << 24, n2 = (n2 & 65535) * 1540483477 + ((n2 >>> 16) * 59797 << 16), n2 ^= n2 >>> 24, t2 = (n2 & 65535) * 1540483477 + ((n2 >>> 16) * 59797 << 16) ^ (t2 & 65535) * 1540483477 + ((t2 >>> 16) * 59797 << 16);
  switch (i2) {
    case 3:
      t2 ^= (e3.charCodeAt(r2 + 2) & 255) << 16;
    case 2:
      t2 ^= (e3.charCodeAt(r2 + 1) & 255) << 8;
    case 1:
      t2 ^= e3.charCodeAt(r2) & 255, t2 = (t2 & 65535) * 1540483477 + ((t2 >>> 16) * 59797 << 16);
  }
  return t2 ^= t2 >>> 13, t2 = (t2 & 65535) * 1540483477 + ((t2 >>> 16) * 59797 << 16), ((t2 ^ t2 >>> 15) >>> 0).toString(36);
}
var Mn = { animationIterationCount: 1, aspectRatio: 1, borderImageOutset: 1, borderImageSlice: 1, borderImageWidth: 1, boxFlex: 1, boxFlexGroup: 1, boxOrdinalGroup: 1, columnCount: 1, columns: 1, flex: 1, flexGrow: 1, flexPositive: 1, flexShrink: 1, flexNegative: 1, flexOrder: 1, gridRow: 1, gridRowEnd: 1, gridRowSpan: 1, gridRowStart: 1, gridColumn: 1, gridColumnEnd: 1, gridColumnSpan: 1, gridColumnStart: 1, msGridRow: 1, msGridRowSpan: 1, msGridColumn: 1, msGridColumnSpan: 1, fontWeight: 1, lineHeight: 1, opacity: 1, order: 1, orphans: 1, scale: 1, tabSize: 1, widows: 1, zIndex: 1, zoom: 1, WebkitLineClamp: 1, fillOpacity: 1, floodOpacity: 1, stopOpacity: 1, strokeDasharray: 1, strokeDashoffset: 1, strokeMiterlimit: 1, strokeOpacity: 1, strokeWidth: 1 }, Nn = /[A-Z]|^ms/g, Pn = /_EMO_([^_]+?)_([^]*?)_EMO_/g, Fn = function(e3) {
  return e3.charCodeAt(1) === 45;
}, In = function(e3) {
  return e3 != null && typeof e3 != `boolean`;
}, Ln = pn(function(e3) {
  return Fn(e3) ? e3 : e3.replace(Nn, `-$&`).toLowerCase();
}), Rn = function(e3, t2) {
  switch (e3) {
    case `animation`:
    case `animationName`:
      if (typeof t2 == `string`) return t2.replace(Pn, function(e4, t3, n2) {
        return X = { name: t3, styles: n2, next: X }, t3;
      });
  }
  return Mn[e3] !== 1 && !Fn(e3) && typeof t2 == `number` && t2 !== 0 ? t2 + `px` : t2;
};
function zn(e3, t2, n2) {
  if (n2 == null) return ``;
  var r2 = n2;
  if (r2.__emotion_styles !== void 0) return r2;
  switch (typeof n2) {
    case `boolean`:
      return ``;
    case `object`:
      var i2 = n2;
      if (i2.anim === 1) return X = { name: i2.name, styles: i2.styles, next: X }, i2.name;
      var a2 = n2;
      if (a2.styles !== void 0) {
        var o2 = a2.next;
        if (o2 !== void 0) for (; o2 !== void 0; ) X = { name: o2.name, styles: o2.styles, next: X }, o2 = o2.next;
        return a2.styles + `;`;
      }
      return Bn(e3, t2, n2);
    case `function`:
      if (e3 !== void 0) {
        var s2 = X, c2 = n2(e3);
        return X = s2, zn(e3, t2, c2);
      }
  }
  var l2 = n2;
  if (t2 == null) return l2;
  var u2 = t2[l2];
  return u2 === void 0 ? l2 : u2;
}
function Bn(e3, t2, n2) {
  var r2 = ``;
  if (Array.isArray(n2)) for (var i2 = 0; i2 < n2.length; i2++) r2 += zn(e3, t2, n2[i2]) + `;`;
  else for (var a2 in n2) {
    var o2 = n2[a2];
    if (typeof o2 != `object`) {
      var s2 = o2;
      t2 != null && t2[s2] !== void 0 ? r2 += a2 + `{` + t2[s2] + `}` : In(s2) && (r2 += Ln(a2) + `:` + Rn(a2, s2) + `;`);
    } else if (Array.isArray(o2) && typeof o2[0] == `string` && (t2 == null || t2[o2[0]] === void 0)) for (var c2 = 0; c2 < o2.length; c2++) In(o2[c2]) && (r2 += Ln(a2) + `:` + Rn(a2, o2[c2]) + `;`);
    else {
      var l2 = zn(e3, t2, o2);
      switch (a2) {
        case `animation`:
        case `animationName`:
          r2 += Ln(a2) + `:` + l2 + `;`;
          break;
        default:
          r2 += a2 + `{` + l2 + `}`;
      }
    }
  }
  return r2;
}
var Vn = /label:\s*([^\s;{]+)\s*(;|$)/g, X;
function Hn(e3, t2, n2) {
  if (e3.length === 1 && typeof e3[0] == `object` && e3[0] !== null && e3[0].styles !== void 0) return e3[0];
  var r2 = true, i2 = ``;
  X = void 0;
  var a2 = e3[0];
  a2 == null || a2.raw === void 0 ? (r2 = false, i2 += zn(n2, t2, a2)) : i2 += a2[0];
  for (var o2 = 1; o2 < e3.length; o2++) i2 += zn(n2, t2, e3[o2]), r2 && (i2 += a2[o2]);
  Vn.lastIndex = 0;
  for (var s2 = ``, c2; (c2 = Vn.exec(i2)) !== null; ) s2 += `-` + c2[1];
  return { name: jn(i2) + s2, styles: i2, next: X };
}
var Un = function(e3) {
  return e3();
}, Wn = ct || false, Gn = Wn || Un, Kn = Wn || lt;
bt();
var qn = N(typeof HTMLElement < `u` ? Sn({ key: `css` }) : null), Jn = qn.Provider, Yn = function() {
  return F(qn);
}, Xn = function(e3) {
  return qe(function(t2, n2) {
    return e3(t2, F(qn), n2);
  });
}, Z = N({}), Zn = function() {
  return F(Z);
}, Qn = function(e3, t2) {
  return typeof t2 == `function` ? t2(e3) : Cn({}, e3, t2);
}, $n = fn(function(e3) {
  return fn(function(t2) {
    return Qn(e3, t2);
  });
}), er = function(e3) {
  var t2 = F(Z);
  return e3.theme !== t2 && (t2 = $n(t2)(e3.theme)), P(Z.Provider, { value: t2 }, e3.children);
};
function tr(e3) {
  var t2 = e3.displayName || e3.name || `Component`, n2 = qe(function(t3, n3) {
    var r2 = F(Z);
    return P(e3, Cn({ theme: r2, ref: n3 }, t3));
  });
  return n2.displayName = `WithTheme(` + t2 + `)`, Dn(n2, e3);
}
var nr = {}.hasOwnProperty, rr = `__EMOTION_TYPE_PLEASE_DO_NOT_USE__`, ir = function(e3, t2) {
  var n2 = {};
  for (var r2 in t2) nr.call(t2, r2) && (n2[r2] = t2[r2]);
  return n2[rr] = e3, n2;
}, ar = function(e3) {
  var t2 = e3.cache, n2 = e3.serialized, r2 = e3.isStringTag;
  return kn(t2, n2, r2), Gn(function() {
    return An(t2, n2, r2);
  }), null;
}, or = Xn(function(e3, t2, n2) {
  var r2 = e3.css;
  typeof r2 == `string` && t2.registered[r2] !== void 0 && (r2 = t2.registered[r2]);
  var i2 = e3[rr], a2 = [r2], o2 = ``;
  typeof e3.className == `string` ? o2 = On(t2.registered, a2, e3.className) : e3.className != null && (o2 = e3.className + ` `);
  var s2 = Hn(a2, void 0, F(Z));
  o2 += t2.key + `-` + s2.name;
  var c2 = {};
  for (var l2 in e3) nr.call(e3, l2) && l2 !== `css` && l2 !== rr && (c2[l2] = e3[l2]);
  return c2.className = o2, n2 && (c2.ref = n2), P(M, null, P(ar, { cache: t2, serialized: s2, isStringTag: typeof i2 == `string` }), P(i2, c2));
}), sr = n({ CacheProvider: () => Jn, ClassNames: () => hr, Global: () => lr, ThemeContext: () => Z, ThemeProvider: () => er, __unsafe_useEmotionCache: () => Yn, createElement: () => cr, css: () => ur, jsx: () => cr, keyframes: () => dr, useTheme: () => Zn, withEmotionCache: () => Xn, withTheme: () => tr });
bt();
var cr = function(e3, t2) {
  var n2 = arguments;
  if (t2 == null || !nr.call(t2, `css`)) return P.apply(void 0, n2);
  var r2 = n2.length, i2 = Array(r2);
  i2[0] = or, i2[1] = ir(e3, t2);
  for (var a2 = 2; a2 < r2; a2++) i2[a2] = n2[a2];
  return P.apply(null, i2);
};
(function(e3) {
  var t2;
  t2 || (t2 = e3.JSX || (e3.JSX = {}));
})(cr || (cr = {}));
var lr = Xn(function(e3, t2) {
  var n2 = e3.styles, r2 = Hn([n2], void 0, F(Z)), i2 = pt();
  return Kn(function() {
    var e4 = t2.key + `-global`, n3 = new t2.sheet.constructor({ key: e4, nonce: t2.sheet.nonce, container: t2.sheet.container, speedy: t2.sheet.isSpeedy }), a2 = false, o2 = document.querySelector(`style[data-emotion="` + e4 + ` ` + r2.name + `"]`);
    return t2.sheet.tags.length && (n3.before = t2.sheet.tags[0]), o2 !== null && (a2 = true, o2.setAttribute(`data-emotion`, e4), n3.hydrate([o2])), i2.current = [n3, a2], function() {
      n3.flush();
    };
  }, [t2]), Kn(function() {
    var e4 = i2.current, n3 = e4[0];
    if (e4[1]) {
      e4[1] = false;
      return;
    }
    r2.next !== void 0 && An(t2, r2.next, true), n3.tags.length && (n3.before = n3.tags[n3.tags.length - 1].nextElementSibling, n3.flush()), t2.insert(``, r2, n3, false);
  }, [t2, r2.name]), null;
});
function ur() {
  return Hn([...arguments]);
}
function dr() {
  var e3 = ur.apply(void 0, arguments), t2 = `animation-` + e3.name;
  return { name: t2, styles: `@keyframes ` + t2 + `{` + e3.styles + `}`, anim: 1, toString: function() {
    return `_EMO_` + this.name + `_` + this.styles + `_EMO_`;
  } };
}
var fr = function e2(t2) {
  for (var n2 = t2.length, r2 = 0, i2 = ``; r2 < n2; r2++) {
    var a2 = t2[r2];
    if (a2 != null) {
      var o2 = void 0;
      switch (typeof a2) {
        case `boolean`:
          break;
        case `object`:
          if (Array.isArray(a2)) o2 = e2(a2);
          else for (var s2 in o2 = ``, a2) a2[s2] && s2 && (o2 && (o2 += ` `), o2 += s2);
          break;
        default:
          o2 = a2;
      }
      o2 && (i2 && (i2 += ` `), i2 += o2);
    }
  }
  return i2;
};
function pr(e3, t2, n2) {
  var r2 = [], i2 = On(e3, r2, n2);
  return r2.length < 2 ? n2 : i2 + t2(r2);
}
var mr = function(e3) {
  var t2 = e3.cache, n2 = e3.serializedArr;
  return Gn(function() {
    for (var e4 = 0; e4 < n2.length; e4++) An(t2, n2[e4], false);
  }), null;
}, hr = Xn(function(e3, t2) {
  var n2 = [], r2 = function() {
    var e4 = Hn([...arguments], t2.registered);
    return n2.push(e4), kn(t2, e4, false), t2.key + `-` + e4.name;
  }, i2 = { css: r2, cx: function() {
    var e4 = [...arguments];
    return pr(t2.registered, r2, fr(e4));
  }, theme: F(Z) }, a2 = e3.children(i2);
  return P(M, null, P(mr, { cache: t2, serializedArr: n2 }), a2);
}), gr = n({ CacheProvider: () => _r, ClassNames: () => wr, Global: () => Tr, ThemeContext: () => vr, ThemeProvider: () => yr, __unsafe_useEmotionCache: () => br, createElement: () => Er, css: () => Dr, default: () => Ar, jsx: () => Or, keyframes: () => kr, useTheme: () => xr, withEmotionCache: () => Sr, withTheme: () => Cr }), Q = sr, _r = Q.CacheProvider, vr = Q.ThemeContext, yr = Q.ThemeProvider, br = Q.__unsafe_useEmotionCache, xr = Q.useTheme, Sr = Q.withEmotionCache, Cr = Q.withTheme, wr = Q.ClassNames, Tr = Q.Global, Er = Q.createElement, Dr = Q.css, Or = Q.jsx, kr = Q.keyframes, Ar = Reflect.get(sr, `default`) ?? sr, jr = `__mf_module_cache__`;
globalThis[jr] || (globalThis[jr] = { share: {}, remote: {} }), (_a = globalThis[jr]).share || (_a.share = {}), (_b = globalThis[jr]).remote || (_b.remote = {});
var $ = globalThis[jr];
for (let e3 of Object.keys($.share)) if (e3.startsWith(`default:`)) {
  let t2 = e3.slice(8);
  $.share[t2] === void 0 && ($.share[t2] = $.share[e3]);
} else if (!e3.includes(`:`)) {
  let t2 = `default:` + e3;
  $.share[t2] === void 0 && ($.share[t2] = $.share[e3]);
}
var Mr = (e3, t2) => {
  let n2 = e3[t2.canonical];
  if (n2 !== void 0) return n2;
  let r2 = t2.aliases || [];
  for (let n3 of r2) {
    if (!Object.prototype.hasOwnProperty.call(e3, n3)) continue;
    let r3 = e3[n3];
    if (r3 !== void 0) return e3[t2.canonical] = r3, r3;
  }
}, Nr = /* @__PURE__ */ Symbol.for(`module-federation.shared-cache-listeners`), Pr = (e3) => {
  let t2 = e3[Nr];
  return t2 === void 0 && (t2 = /* @__PURE__ */ Object.create(null), Object.defineProperty(e3, Nr, { value: t2, enumerable: false, configurable: false, writable: false })), t2;
}, Fr = (e3, t2, n2) => {
  var _a2;
  let r2 = Pr(e3);
  (r2[_a2 = t2.canonical] || (r2[_a2] = /* @__PURE__ */ new Set())).add(n2);
}, Ir = /* @__PURE__ */ Symbol.for(`module-federation.shared-cache-owners`), Lr = (e3) => {
  let t2 = e3[Ir];
  return t2 === void 0 && (t2 = /* @__PURE__ */ Object.create(null), Object.defineProperty(e3, Ir, { value: t2, enumerable: false, configurable: false, writable: false })), t2;
}, Rr = (e3, t2, n2, r2) => {
  var _a2;
  e3[t2.canonical] = n2;
  let i2 = t2.aliases || [];
  for (let t3 of i2) Object.defineProperty(e3, t3, { value: n2, enumerable: true, configurable: true, writable: true });
  let a2 = e3[Ir];
  r2 === void 0 ? a2 && delete a2[t2.canonical] : Lr(e3)[t2.canonical] = r2;
  let o2 = (_a2 = e3[Nr]) == null ? void 0 : _a2[t2.canonical];
  if (o2) for (let e4 of o2) e4(n2);
  return n2;
}, zr = (e3) => {
  let t2 = (() => {
    let t3 = e3;
    for (let e4 = 0; e4 < 5; e4++) {
      let e5 = t3 == null ? void 0 : t3.default;
      if (!e5 || typeof e5 != `object`) break;
      let n2 = Object.keys(t3).filter((e6) => e6 !== "default").map((e6) => t3[e6]);
      if (n2.length > 0 && n2.some((e6) => e6 !== void 0)) break;
      t3 = e5;
    }
    return t3;
  })();
  return t2 && Object.getPrototypeOf(t2) === null ? Object.assign({}, t2) : t2;
}, Br = Mr($.share, { canonical: `default:@emotion/react`, aliases: [`@emotion/react`] });
Br === void 0 && (Br = zr(gr), Rr($.share, { canonical: `default:@emotion/react`, aliases: [`@emotion/react`] }, Br, `vis2nilsForkWidgets`));
var Vr, Hr, Ur, Wr, Gr, Kr, qr = (e3) => {
  Vr = e3.CacheProvider, Hr = e3.ThemeContext, e3.ThemeProvider, e3.__unsafe_useEmotionCache, e3.useTheme, Ur = e3.withEmotionCache, e3.withTheme, e3.ClassNames, Wr = e3.Global, e3.createElement, Gr = e3.css, e3.jsx, Kr = e3.keyframes, (() => {
    let t2 = e3;
    for (let e4 = 0; e4 < 5; e4++) {
      let e5 = t2 == null ? void 0 : t2.default;
      if (!e5 || typeof e5 != `object`) return e5 ?? t2;
      t2 = e5;
    }
    return t2;
  })();
};
Fr($.share, { canonical: `default:@emotion/react`, aliases: [`@emotion/react`] }, qr), qr(Br);
export {
  M as A,
  bt as B,
  Je as C,
  tt as D,
  $e as E,
  pt as F,
  Se as H,
  mt as I,
  ht as L,
  lt as M,
  ut as N,
  F as O,
  ft as P,
  _t as R,
  qe as S,
  Ie as T,
  o as V,
  Fe as _,
  Ur as a,
  P as b,
  Gn as c,
  An as d,
  kn as f,
  Ne as g,
  Ct as h,
  Kr as i,
  st as j,
  it as k,
  Hn as l,
  pn as m,
  Hr as n,
  Wr as o,
  Sn as p,
  Gr as r,
  gr as s,
  Vr as t,
  On as u,
  Ge as v,
  Xe as w,
  Ke as x,
  N as y,
  Ce as z
};
