import { j as l, __tla as __tla_0 } from "./jsx-runtime-DTPVEbuR.js";
import { e as Y, f as ae, l as I, a as A, k as ne, d as je, m as he, __tla as __tla_1 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js-C90OBA92.js";
import { r as Be, e as Q, g as ie, c as q, a as Pe, b as Ee, d as Ve, _ as Ge, __tla as __tla_2 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_material__loadShare__.js-CHMFtWRD.js";
import { y as ze, z as He, t as pe, e as Ue, _ as $e, __tla as __tla_3 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_mui_mf_1_icons_mf_2_material__loadShare__.js-CgDCyMuJ.js";
import { _ as Ye, __tla as __tla_4 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare___mf_0_iobroker_mf_1_adapter_mf_2_react_mf_2_v5__loadShare__.js-Buo0KxVv.js";
import { G as V } from "./Generic-DDdmRdK-.js";
import { _ as b } from "./extends-CF3RwP-h.js";
import { _ as O } from "./objectWithoutPropertiesLoose-Dsqj8S3w.js";
import { __tla as __tla_5 } from "./__mfe_internal__vis2nilsForkWidgets__loadShare__react__loadShare__.js_commonjs-proxy-CIVBDDlY.js";
let ee, Re, Tt, Oe, le, W, ce, F, P, ke, te, Fe, Xe, Bt, U;
let __tla = Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla_5;
    } catch {
    }
  })()
]).then(async () => {
  let H, M, ge, ue, Ke, Je, Ze, Qe, qe, et, tt, G, re;
  H = 255;
  M = 100;
  U = (r) => {
    var { r: e, g: t, b: a, a: s } = r, i = Math.max(e, t, a), o = i - Math.min(e, t, a), n = o ? i === e ? (t - a) / o : i === t ? 2 + (a - e) / o : 4 + (e - t) / o : 0;
    return {
      h: 60 * (n < 0 ? n + 6 : n),
      s: i ? o / i * M : 0,
      v: i / H * M,
      a: s
    };
  };
  ge = (r) => {
    var { h: e, s: t, l: a, a: s } = ce(r);
    return "hsla(" + e + ", " + t + "%, " + a + "%, " + s + ")";
  };
  Fe = (r) => {
    var { h: e, s: t, l: a, a: s } = r;
    return t *= (a < 50 ? a : M - a) / M, {
      h: e,
      s: t > 0 ? 2 * t / (a + t) * M : 0,
      v: a + t,
      a: s
    };
  };
  ce = (r) => {
    var { h: e, s: t, v: a, a: s } = r, i = (200 - t) * a / M;
    return {
      h: e,
      s: i > 0 && i < 200 ? t * a / M / (i <= M ? i : 200 - i) * M : 0,
      l: i / 2,
      a: s
    };
  };
  Xe = (r) => {
    var { r: e, g: t, b: a } = r;
    return ue({
      r: e,
      g: t,
      b: a
    });
  };
  ue = (r) => {
    var { r: e, g: t, b: a } = r, s = e << 16 | t << 8 | a;
    return "#" + ((i) => new Array(7 - i.length).join("0") + i)(s.toString(16));
  };
  Ke = (r) => {
    var { r: e, g: t, b: a, a: s } = r, i = typeof s == "number" && (s * 255 | 256).toString(16).slice(1);
    return "" + ue({
      r: e,
      g: t,
      b: a
    }) + (i || "");
  };
  W = (r) => U(Je(r));
  Je = (r) => {
    var e = r.replace("#", "");
    /^#?/.test(r) && e.length === 3 && (r = "#" + e.charAt(0) + e.charAt(0) + e.charAt(1) + e.charAt(1) + e.charAt(2) + e.charAt(2));
    var t = new RegExp("[A-Za-z0-9]{2}", "g"), [a, s, i = 0, o] = r.match(t).map((n) => parseInt(n, 16));
    return {
      r: a,
      g: s,
      b: i,
      a: (o ?? 255) / H
    };
  };
  F = (r) => {
    var { h: e, s: t, v: a, a: s } = r, i = e / 60, o = t / M, n = a / M, u = Math.floor(i) % 6, h = i - Math.floor(i), v = H * n * (1 - o), m = H * n * (1 - o * h), p = H * n * (1 - o * (1 - h));
    n *= H;
    var g = {};
    switch (u) {
      case 0:
        g.r = n, g.g = p, g.b = v;
        break;
      case 1:
        g.r = m, g.g = n, g.b = v;
        break;
      case 2:
        g.r = v, g.g = n, g.b = p;
        break;
      case 3:
        g.r = v, g.g = m, g.b = n;
        break;
      case 4:
        g.r = p, g.g = v, g.b = n;
        break;
      case 5:
        g.r = n, g.g = v, g.b = m;
        break;
    }
    return g.r = Math.round(g.r), g.g = Math.round(g.g), g.b = Math.round(g.b), b({}, g, {
      a: s
    });
  };
  Ze = (r) => {
    var { r: e, g: t, b: a, a: s } = F(r);
    return "rgba(" + e + ", " + t + ", " + a + ", " + s + ")";
  };
  Qe = (r) => {
    var { r: e, g: t, b: a } = r;
    return {
      r: e,
      g: t,
      b: a
    };
  };
  qe = (r) => {
    var { h: e, s: t, l: a } = r;
    return {
      h: e,
      s: t,
      l: a
    };
  };
  P = (r) => ue(F(r));
  et = (r) => {
    var { h: e, s: t, v: a } = r;
    return {
      h: e,
      s: t,
      v: a
    };
  };
  tt = (r) => {
    var { r: e, g: t, b: a } = r, s = function(v) {
      return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    }, i = s(e / 255), o = s(t / 255), n = s(a / 255), u = {};
    return u.x = i * 0.4124 + o * 0.3576 + n * 0.1805, u.y = i * 0.2126 + o * 0.7152 + n * 0.0722, u.bri = i * 0.0193 + o * 0.1192 + n * 0.9505, u;
  };
  G = (r) => {
    var e, t, a, s, i, o, n, u, h;
    return typeof r == "string" && re(r) ? (o = W(r), u = r) : typeof r != "string" && (o = r), o && (a = et(o), i = ce(o), s = F(o), h = Ke(s), u = P(o), t = qe(i), e = Qe(s), n = tt(e)), {
      rgb: e,
      hsl: t,
      hsv: a,
      rgba: s,
      hsla: i,
      hsva: o,
      hex: u,
      hexa: h,
      xy: n
    };
  };
  re = (r) => /^#?([A-Fa-f0-9]{3,4}){1,2}$/.test(r);
  function ve(r) {
    var e = Y(r);
    return ae(() => {
      e.current = r;
    }), I((t, a) => e.current && e.current(t, a), []);
  }
  var K = (r) => "touches" in r, fe = (r) => {
    !K(r) && r.preventDefault && r.preventDefault();
  }, me = function(e, t, a) {
    return t === void 0 && (t = 0), a === void 0 && (a = 1), e > a ? a : e < t ? t : e;
  }, xe = (r, e) => {
    var t = r.getBoundingClientRect(), a = K(e) ? e.touches[0] : e;
    return {
      left: me((a.pageX - (t.left + window.pageXOffset)) / t.width),
      top: me((a.pageY - (t.top + window.pageYOffset)) / t.height),
      width: t.width,
      height: t.height,
      x: a.pageX - (t.left + window.pageXOffset),
      y: a.pageY - (t.top + window.pageYOffset)
    };
  }, rt = [
    "prefixCls",
    "className",
    "onMove",
    "onDown"
  ], se = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-interactive", className: a, onMove: s, onDown: i } = r, o = O(r, rt), n = Y(null), u = Y(false), [h, v] = ne(false), m = ve(s), p = ve(i), g = (c) => u.current && !K(c) ? false : (u.current = K(c), true), x = I((c) => {
      if (fe(c), !!n.current) {
        var d = K(c) ? c.touches.length > 0 : c.buttons > 0;
        if (!d) {
          v(false);
          return;
        }
        m == null ? void 0 : m(xe(n.current, c), c);
      }
    }, [
      m
    ]), f = I(() => v(false), []), w = I((c) => {
      c ? (window.addEventListener(u.current ? "touchmove" : "mousemove", x), window.addEventListener(u.current ? "touchend" : "mouseup", f)) : (window.removeEventListener("mousemove", x), window.removeEventListener("mouseup", f), window.removeEventListener("touchmove", x), window.removeEventListener("touchend", f));
    }, [
      x,
      f
    ]);
    ae(() => (w(h), () => {
      w(false);
    }), [
      h,
      x,
      f,
      w
    ]);
    var D = I((c) => {
      var d = document.activeElement;
      d == null ? void 0 : d.blur(), fe(c.nativeEvent), g(c.nativeEvent) && n.current && (p == null ? void 0 : p(xe(n.current, c.nativeEvent), c.nativeEvent), v(true));
    }, [
      p
    ]);
    return l.jsx("div", b({}, o, {
      className: [
        t,
        a || ""
      ].filter(Boolean).join(" "),
      style: b({}, o.style, {
        touchAction: "none"
      }),
      ref: n,
      tabIndex: 0,
      onMouseDown: D,
      onTouchStart: D
    }));
  });
  se.displayName = "Interactive";
  var at = [
    "className",
    "prefixCls",
    "left",
    "top",
    "style",
    "fillProps"
  ], st = (r) => {
    var { className: e, prefixCls: t, left: a, top: s, style: i, fillProps: o } = r, n = O(r, at), u = b({}, i, {
      position: "absolute",
      left: a,
      top: s
    }), h = b({
      width: 18,
      height: 18,
      boxShadow: "var(--alpha-pointer-box-shadow)",
      borderRadius: "50%",
      backgroundColor: "var(--alpha-pointer-background-color)"
    }, o == null ? void 0 : o.style, {
      transform: a ? "translate(-9px, -1px)" : "translate(-1px, -9px)"
    });
    return l.jsx("div", b({
      className: t + "-pointer " + (e || ""),
      style: u
    }, n, {
      children: l.jsx("div", b({
        className: t + "-fill"
      }, o, {
        style: h
      }))
    }));
  }, it = [
    "prefixCls",
    "className",
    "hsva",
    "background",
    "bgProps",
    "innerProps",
    "pointerProps",
    "radius",
    "width",
    "height",
    "direction",
    "reverse",
    "style",
    "onChange",
    "pointer"
  ], ot = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAMUlEQVQ4T2NkYGAQYcAP3uCTZhw1gGGYhAGBZIA/nYDCgBDAm9BGDWAAJyRCgLaBCAAgXwixzAS0pgAAAABJRU5ErkJggg==", J = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-alpha", className: a, hsva: s, background: i, bgProps: o = {}, innerProps: n = {}, pointerProps: u = {}, radius: h = 0, width: v, height: m = 16, direction: p = "horizontal", reverse: g = false, style: x, onChange: f, pointer: w } = r, D = O(r, it), c = I((_) => {
      var R = p === "horizontal" ? _.left : _.top;
      return p === "horizontal" ? g ? 1 - R : R : g ? R : 1 - R;
    }, [
      p,
      g
    ]), d = I((_) => p === "horizontal" ? g ? 1 - _ : _ : g ? _ : 1 - _, [
      p,
      g
    ]), j = (_) => {
      var R = c(_);
      f && f(b({}, s, {
        a: R
      }), _);
    }, C = ge(Object.assign({}, s, {
      a: 1
    })), y = g ? "linear-gradient(to right, " + C + " 0%, rgba(244, 67, 54, 0) 100%)" : "linear-gradient(to right, rgba(244, 67, 54, 0) 0%, " + C + " 100%)", T = g ? "linear-gradient(to bottom, rgba(244, 67, 54, 0) 0%, " + C + " 100%)" : "linear-gradient(to bottom, " + C + " 0%, rgba(244, 67, 54, 0) 100%)", X = p === "horizontal" ? y : T, k = {};
    p === "horizontal" ? k.left = d(s.a) * 100 + "%" : k.top = d(s.a) * 100 + "%";
    var B = b({
      "--alpha-background-color": "#fff",
      "--alpha-pointer-background-color": "rgb(248, 248, 248)",
      "--alpha-pointer-box-shadow": "rgb(0 0 0 / 37%) 0px 1px 4px 0px",
      borderRadius: h,
      background: "url(" + ot + ") left center",
      backgroundColor: "var(--alpha-background-color)"
    }, {
      width: v,
      height: m
    }, x, {
      position: "relative"
    }), z = I((_) => {
      var R = 0.01, L = s.a, E = L;
      switch (_.key) {
        case "ArrowLeft":
          p === "horizontal" && (E = g ? Math.min(1, L + R) : Math.max(0, L - R), _.preventDefault());
          break;
        case "ArrowRight":
          p === "horizontal" && (E = g ? Math.max(0, L - R) : Math.min(1, L + R), _.preventDefault());
          break;
        case "ArrowUp":
          p === "vertical" && (E = g ? Math.max(0, L - R) : Math.min(1, L + R), _.preventDefault());
          break;
        case "ArrowDown":
          p === "vertical" && (E = g ? Math.min(1, L + R) : Math.max(0, L - R), _.preventDefault());
          break;
        default:
          return;
      }
      if (E !== L) {
        var be = d(E), We = {
          left: p === "horizontal" ? be : s.a,
          top: p === "vertical" ? be : s.a,
          width: 0,
          height: 0,
          x: 0,
          y: 0
        };
        f && f(b({}, s, {
          a: E
        }), We);
      }
    }, [
      d,
      s,
      p,
      f,
      g
    ]), Z = I((_) => {
      _.target.focus();
    }, []), Le = w && typeof w == "function" ? w(b({
      prefixCls: t
    }, u, k)) : l.jsx(st, b({}, u, {
      prefixCls: t
    }, k));
    return l.jsxs("div", b({}, D, {
      className: [
        t,
        t + "-" + p,
        a || ""
      ].filter(Boolean).join(" "),
      style: B,
      ref: e,
      children: [
        l.jsx("div", b({}, o, {
          style: b({
            inset: 0,
            position: "absolute",
            background: i || X,
            borderRadius: h
          }, o.style)
        })),
        l.jsx(se, b({}, n, {
          style: b({}, n.style, {
            inset: 0,
            zIndex: 1,
            position: "absolute",
            outline: "none"
          }),
          onMove: j,
          onDown: j,
          onClick: Z,
          onKeyDown: z,
          children: Le
        }))
      ]
    }));
  });
  J.displayName = "Alpha";
  var lt = [
    "prefixCls",
    "placement",
    "label",
    "value",
    "className",
    "style",
    "labelStyle",
    "inputStyle",
    "onChange",
    "onBlur",
    "renderInput"
  ], nt = (r) => /^#?([A-Fa-f0-9]{3,4}){1,2}$/.test(r), ht = (r) => Number(String(r).replace(/%/g, "")), $ = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-editable-input", placement: a = "bottom", label: s, value: i, className: o, style: n, labelStyle: u, inputStyle: h, onChange: v, onBlur: m, renderInput: p } = r, g = O(r, lt), [x, f] = ne(i), w = Y(false), D = Y(g.id || t + "-" + Math.random().toString(36).slice(2, 11)), c = g.id || D.current;
    ae(() => {
      r.value !== x && (w.current || f(r.value));
    }, [
      r.value
    ]);
    function d(k, B) {
      var z = (B || k.target.value).trim().replace(/^#/, "");
      nt(z) && v && v(k, z);
      var Z = ht(z);
      isNaN(Z) || v && v(k, Z), f(z);
    }
    function j(k) {
      w.current = false, f(r.value), m && m(k);
    }
    var C = {};
    a === "bottom" && (C.flexDirection = "column"), a === "top" && (C.flexDirection = "column-reverse"), a === "left" && (C.flexDirection = "row-reverse");
    var y = b({
      "--editable-input-label-color": "rgb(153, 153, 153)",
      "--editable-input-box-shadow": "rgb(204 204 204) 0px 0px 0px 1px inset",
      "--editable-input-color": "#666",
      position: "relative",
      alignItems: "center",
      display: "flex",
      fontSize: 11
    }, C, n), T = b({
      width: "100%",
      paddingTop: 2,
      paddingBottom: 2,
      paddingLeft: 3,
      paddingRight: 3,
      fontSize: 11,
      background: "transparent",
      boxSizing: "border-box",
      border: "none",
      color: "var(--editable-input-color)",
      boxShadow: "var(--editable-input-box-shadow)"
    }, h), X = b({
      value: x,
      onChange: d,
      onBlur: j,
      autoComplete: "off",
      onFocus: () => w.current = true
    }, g, {
      id: c,
      style: T,
      onFocusCapture: (k) => {
        var B = k.target;
        B.setSelectionRange(B.value.length, B.value.length);
      }
    });
    return l.jsxs("div", {
      className: [
        t,
        o || ""
      ].filter(Boolean).join(" "),
      style: y,
      children: [
        p ? p(X, e) : l.jsx("input", b({
          ref: e
        }, X)),
        s && l.jsx("label", {
          htmlFor: c,
          style: b({
            color: "var(--editable-input-label-color)",
            textTransform: "capitalize"
          }, u),
          children: s
        })
      ]
    });
  });
  $.displayName = "EditableInput";
  var gt = [
    "prefixCls",
    "className",
    "color",
    "colors",
    "style",
    "rectProps",
    "onChange",
    "addonAfter",
    "addonBefore",
    "rectRender"
  ], De = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-swatch", className: a, color: s, colors: i = [], style: o, rectProps: n = {}, onChange: u, addonAfter: h, addonBefore: v, rectRender: m } = r, p = O(r, gt), g = b({
      "--swatch-background-color": "rgb(144, 19, 254)",
      background: "var(--swatch-background-color)",
      height: 15,
      width: 15,
      marginRight: 5,
      marginBottom: 5,
      cursor: "pointer",
      position: "relative",
      outline: "none",
      borderRadius: 2
    }, n.style), x = (f, w) => {
      u && u(W(f), G(W(f)), w);
    };
    return l.jsxs("div", b({
      ref: e
    }, p, {
      className: [
        t,
        a || ""
      ].filter(Boolean).join(" "),
      style: b({
        display: "flex",
        flexWrap: "wrap",
        position: "relative"
      }, o),
      children: [
        v && A.isValidElement(v) && v,
        i && Array.isArray(i) && i.map((f, w) => {
          var D = "", c = "";
          typeof f == "string" && (D = f, c = f), typeof f == "object" && f.color && (D = f.title || f.color, c = f.color);
          var d = s && s.toLocaleLowerCase() === c.toLocaleLowerCase(), j = m && m({
            title: D,
            color: c,
            checked: !!d,
            style: b({}, g, {
              background: c
            }),
            onClick: (y) => x(c, y)
          });
          if (j) return l.jsx(je, {
            children: j
          }, w);
          var C = n.children && A.isValidElement(n.children) ? A.cloneElement(n.children, {
            color: c,
            checked: d
          }) : null;
          return l.jsx("div", b({
            tabIndex: 0,
            title: D,
            onClick: (y) => x(c, y)
          }, n, {
            children: C,
            style: b({}, g, {
              background: c
            })
          }), w);
        }),
        h && A.isValidElement(h) && h
      ]
    }));
  });
  De.displayName = "Swatch";
  var ct = (r) => {
    var { className: e, color: t, left: a, top: s, prefixCls: i } = r, o = {
      position: "absolute",
      top: s,
      left: a
    }, n = {
      "--saturation-pointer-box-shadow": "rgb(255 255 255) 0px 0px 0px 1.5px, rgb(0 0 0 / 30%) 0px 0px 1px 1px inset, rgb(0 0 0 / 40%) 0px 0px 1px 2px",
      width: 6,
      height: 6,
      transform: "translate(-3px, -3px)",
      boxShadow: "var(--saturation-pointer-box-shadow)",
      borderRadius: "50%",
      backgroundColor: t
    };
    return he(() => l.jsx("div", {
      className: i + "-pointer " + (e || ""),
      style: o,
      children: l.jsx("div", {
        className: i + "-fill",
        style: n
      })
    }), [
      s,
      a,
      t,
      e,
      i
    ]);
  }, ut = [
    "prefixCls",
    "radius",
    "pointer",
    "className",
    "hue",
    "style",
    "hsva",
    "onChange"
  ], _e = A.forwardRef((r, e) => {
    var t, { prefixCls: a = "w-color-saturation", radius: s = 0, pointer: i, className: o, hue: n = 0, style: u, hsva: h, onChange: v } = r, m = O(r, ut), p = b({
      width: 200,
      height: 200,
      borderRadius: s
    }, u, {
      position: "relative"
    }), g = Y(null), x = I((d) => {
      g.current = d, typeof e == "function" ? e(d) : e && "current" in e && (e.current = d);
    }, [
      e
    ]), f = I((d, j) => {
      v && h && v({
        h: h.h,
        s: d.left * 100,
        v: (1 - d.top) * 100,
        a: h.a
      });
      var C = g.current;
      C && C.focus();
    }, [
      h,
      v
    ]), w = I((d) => {
      if (!(!h || !v)) {
        var j = 1, C = h.s, y = h.v, T = false;
        switch (d.key) {
          case "ArrowLeft":
            C = Math.max(0, h.s - j), T = true, d.preventDefault();
            break;
          case "ArrowRight":
            C = Math.min(100, h.s + j), T = true, d.preventDefault();
            break;
          case "ArrowUp":
            y = Math.min(100, h.v + j), T = true, d.preventDefault();
            break;
          case "ArrowDown":
            y = Math.max(0, h.v - j), T = true, d.preventDefault();
            break;
          default:
            return;
        }
        T && v({
          h: h.h,
          s: C,
          v: y,
          a: h.a
        });
      }
    }, [
      h,
      v
    ]), D = he(() => {
      if (!h) return null;
      var d = {
        top: 100 - h.v + "%",
        left: h.s + "%",
        color: ge(h)
      };
      return i && typeof i == "function" ? i(b({
        prefixCls: a
      }, d)) : l.jsx(ct, b({
        prefixCls: a
      }, d));
    }, [
      h,
      i,
      a
    ]), c = I((d) => {
      d.target.focus();
    }, []);
    return l.jsx(se, b({
      className: [
        a,
        o || ""
      ].filter(Boolean).join(" ")
    }, m, {
      style: b({
        position: "absolute",
        inset: 0,
        cursor: "crosshair",
        backgroundImage: "linear-gradient(0deg, #000, transparent), linear-gradient(90deg, #fff, hsl(" + ((t = h == null ? void 0 : h.h) != null ? t : n) + ", 100%, 50%))"
      }, p, {
        outline: "none"
      }),
      ref: x,
      onMove: f,
      onDown: f,
      onKeyDown: w,
      onClick: c,
      children: D
    }));
  });
  _e.displayName = "Saturation";
  var dt = [
    "prefixCls",
    "className",
    "hue",
    "onChange",
    "direction",
    "reverse"
  ], ye = "rgb(255, 0, 0) 0%, rgb(255, 255, 0) 17%, rgb(0, 255, 0) 33%, rgb(0, 255, 255) 50%, rgb(0, 0, 255) 67%, rgb(255, 0, 255) 83%, rgb(255, 0, 0) 100%", we = "rgb(255, 0, 0) 0%, rgb(255, 0, 255) 17%, rgb(0, 0, 255) 33%, rgb(0, 255, 255) 50%, rgb(0, 255, 0) 67%, rgb(255, 255, 0) 83%, rgb(255, 0, 0) 100%", Se = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-hue", className: a, hue: s = 0, onChange: i, direction: o = "horizontal", reverse: n = false } = r, u = O(r, dt), h = I(() => {
      if (o === "horizontal") {
        var p = n ? we : ye, g = "right";
        return "linear-gradient(to " + g + ", " + p + ")";
      } else {
        var x = n ? ye : we, f = "bottom";
        return "linear-gradient(to " + f + ", " + x + ")";
      }
    }, [
      o,
      n
    ]), v = I((p) => {
      var g = o === "horizontal" ? p.left : p.top, x;
      return o === "horizontal" ? x = n ? 1 - g : g : x = n ? g : 1 - g, 360 * x;
    }, [
      o,
      n
    ]), m = he(() => h(), [
      h
    ]);
    return l.jsx(J, b({
      ref: e,
      className: t + " " + (a || "")
    }, u, {
      direction: o,
      reverse: n,
      background: m,
      hsva: {
        h: s,
        s: 100,
        v: 100,
        a: s / 360
      },
      onChange: (p, g) => {
        i && i({
          h: v(g)
        });
      }
    }));
  });
  Se.displayName = "Hue";
  var bt = [
    "prefixCls",
    "hsva",
    "placement",
    "rProps",
    "gProps",
    "bProps",
    "aProps",
    "className",
    "style",
    "onChange"
  ], Te = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-editable-input-rgba", hsva: a, placement: s = "bottom", rProps: i = {}, gProps: o = {}, bProps: n = {}, aProps: u = {}, className: h, style: v, onChange: m } = r, p = O(r, bt), g = a ? F(a) : {};
    function x(c) {
      var d = Number(c.target.value);
      d && d > 255 && (c.target.value = "255"), d && d < 0 && (c.target.value = "0");
    }
    var f = (c) => {
      var d = Number(c.target.value);
      d && d > 100 && (c.target.value = "100"), d && d < 0 && (c.target.value = "0");
    }, w = (c, d, j) => {
      typeof c == "number" && (d === "a" && (c < 0 && (c = 0), c > 100 && (c = 100), m && m(G(U(b({}, g, {
        a: c / 100
      }))))), c > 255 && (c = 255, j.target.value = "255"), c < 0 && (c = 0, j.target.value = "0"), d === "r" && m && m(G(U(b({}, g, {
        r: c
      })))), d === "g" && m && m(G(U(b({}, g, {
        g: c
      })))), d === "b" && m && m(G(U(b({}, g, {
        b: c
      })))));
    }, D = g.a ? Math.round(g.a * 100) / 100 : 0;
    return l.jsxs("div", b({
      ref: e,
      className: [
        t,
        h || ""
      ].filter(Boolean).join(" ")
    }, p, {
      style: b({
        fontSize: 11,
        display: "flex"
      }, v),
      children: [
        l.jsx($, b({
          label: "R",
          value: g.r || 0,
          onBlur: x,
          placement: s,
          onChange: (c, d) => w(d, "r", c)
        }, i, {
          style: b({}, i.style)
        })),
        l.jsx($, b({
          label: "G",
          value: g.g || 0,
          onBlur: x,
          placement: s,
          onChange: (c, d) => w(d, "g", c)
        }, o, {
          style: b({
            marginLeft: 5
          }, o.style)
        })),
        l.jsx($, b({
          label: "B",
          value: g.b || 0,
          onBlur: x,
          placement: s,
          onChange: (c, d) => w(d, "b", c)
        }, n, {
          style: b({
            marginLeft: 5
          }, n.style)
        })),
        u && l.jsx($, b({
          label: "A",
          value: parseInt(String(D * 100), 10),
          onBlur: f,
          placement: s,
          onChange: (c, d) => w(d, "a", c)
        }, u, {
          style: b({
            marginLeft: 5
          }, u.style)
        }))
      ]
    }));
  });
  Te.displayName = "EditableInputRGBA";
  let pt;
  pt = [
    "prefixCls",
    "className",
    "onChange",
    "direction",
    "hsva"
  ];
  ke = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-saturation", className: a, onChange: s, direction: i = "horizontal", hsva: o } = r, n = O(r, pt), u = ge(b({}, o, {
      a: 1,
      v: 100
    }));
    return l.jsx(J, b({
      ref: e
    }, n, {
      className: t + " " + (a || ""),
      hsva: {
        h: o.h,
        s: o.s,
        v: o.v,
        a: 1 - o.v / 100
      },
      direction: i,
      background: "linear-gradient(to " + (i === "horizontal" ? "right" : "bottom") + ", " + u + ", rgb(0, 0, 0))",
      onChange: (h, v) => {
        s && s({
          v: i === "horizontal" ? 100 - v.left * 100 : 100 - v.top * 100
        });
      }
    }));
  });
  ke.displayName = "ShadeSlider";
  let vt, ft, Ce;
  vt = [
    "prefixCls",
    "className",
    "onChange",
    "width",
    "presetColors",
    "color",
    "editableDisable",
    "disableAlpha",
    "style"
  ];
  ft = [
    "#D0021B",
    "#F5A623",
    "#f8e61b",
    "#8B572A",
    "#7ED321",
    "#417505",
    "#BD10E0",
    "#9013FE",
    "#4A90E2",
    "#50E3C2",
    "#B8E986",
    "#000000",
    "#4A4A4A",
    "#9B9B9B",
    "#FFFFFF"
  ];
  Ce = (r) => l.jsx("div", {
    style: {
      boxShadow: "rgb(0 0 0 / 60%) 0px 0px 2px",
      width: 4,
      top: 1,
      bottom: 1,
      left: r.left,
      borderRadius: 1,
      position: "absolute",
      backgroundColor: "#fff"
    }
  });
  Re = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-sketch", className: a, onChange: s, width: i = 218, presetColors: o = ft, color: n, editableDisable: u = true, disableAlpha: h = false, style: v } = r, m = O(r, vt), [p, g] = ne({
      h: 209,
      s: 36,
      v: 90,
      a: 1
    });
    ae(() => {
      typeof n == "string" && re(n) && g(W(n)), typeof n == "object" && g(n);
    }, [
      n
    ]);
    var x = (y) => {
      g(y), s && s(G(y));
    }, f = (y, T) => {
      typeof y == "string" && re(y) && /(3|6)/.test(String(y.length)) && x(W(y));
    }, w = (y) => x(b({}, p, {
      a: y.a
    })), D = (y) => x(b({}, p, y, {
      a: p.a
    })), c = b({
      "--sketch-background": "rgb(255, 255, 255)",
      "--sketch-box-shadow": "rgb(0 0 0 / 15%) 0px 0px 0px 1px, rgb(0 0 0 / 15%) 0px 8px 16px",
      "--sketch-swatch-box-shadow": "rgb(0 0 0 / 15%) 0px 0px 0px 1px inset",
      "--sketch-alpha-box-shadow": "rgb(0 0 0 / 15%) 0px 0px 0px 1px inset, rgb(0 0 0 / 25%) 0px 0px 4px inset",
      "--sketch-swatch-border-top": "1px solid rgb(238, 238, 238)",
      background: "var(--sketch-background)",
      borderRadius: 4,
      boxShadow: "var(--sketch-box-shadow)",
      width: i
    }, v), d = {
      borderRadius: 2,
      background: Ze(p),
      boxShadow: "var(--sketch-alpha-box-shadow)"
    }, j = {
      borderTop: "var(--sketch-swatch-border-top)",
      paddingTop: 10,
      paddingLeft: 10
    }, C = {
      marginRight: 10,
      marginBottom: 10,
      borderRadius: 3,
      boxShadow: "var(--sketch-swatch-box-shadow)"
    };
    return l.jsxs("div", b({}, m, {
      className: t + " " + (a || ""),
      ref: e,
      style: c,
      children: [
        l.jsxs("div", {
          style: {
            padding: "10px 10px 8px"
          },
          children: [
            l.jsx(_e, {
              hsva: p,
              style: {
                width: "auto",
                height: 150
              },
              onChange: D
            }),
            l.jsxs("div", {
              style: {
                display: "flex",
                marginTop: 4
              },
              children: [
                l.jsxs("div", {
                  style: {
                    flex: 1
                  },
                  children: [
                    l.jsx(Se, {
                      width: "auto",
                      height: 10,
                      hue: p.h,
                      pointer: Ce,
                      innerProps: {
                        style: {
                          marginLeft: 1,
                          marginRight: 5
                        }
                      },
                      onChange: (y) => x(b({}, p, y))
                    }),
                    !h && l.jsx(J, {
                      width: "auto",
                      height: 10,
                      hsva: p,
                      pointer: Ce,
                      style: {
                        marginTop: 4
                      },
                      innerProps: {
                        style: {
                          marginLeft: 1,
                          marginRight: 5
                        }
                      },
                      onChange: w
                    })
                  ]
                }),
                !h && l.jsx(J, {
                  width: 24,
                  height: 24,
                  hsva: p,
                  radius: 2,
                  style: {
                    marginLeft: 4
                  },
                  bgProps: {
                    style: {
                      background: "transparent"
                    }
                  },
                  innerProps: {
                    style: d
                  },
                  pointer: () => l.jsx(je, {})
                })
              ]
            })
          ]
        }),
        u && l.jsxs("div", {
          style: {
            display: "flex",
            margin: "0 10px 3px 10px"
          },
          children: [
            l.jsx($, {
              label: "Hex",
              value: P(p).replace(/^#/, "").toLocaleUpperCase(),
              onChange: (y, T) => f(T),
              style: {
                minWidth: 58
              }
            }),
            l.jsx(Te, {
              hsva: p,
              style: {
                marginLeft: 6
              },
              aProps: h ? false : {},
              onChange: (y) => x(y.hsva)
            })
          ]
        }),
        o && o.length > 0 && l.jsx(De, {
          style: j,
          colors: o,
          color: P(p),
          onChange: (y) => x(y),
          rectProps: {
            style: C
          }
        })
      ]
    }));
  });
  Re.displayName = "Sketch";
  var mt = "rgb(255 255 255) 0px 0px 0px 1.5px, rgb(0 0 0 / 30%) 0px 0px 1px 1px inset, rgb(0 0 0 / 40%) 0px 0px 1px 2px", xt = (r) => {
    var { className: e, color: t, left: a, top: s, style: i, prefixCls: o } = r, n = b({}, i, {
      position: "absolute",
      top: s,
      left: a
    }), u = o + "-pointer " + (e || "");
    return l.jsx("div", {
      className: u,
      style: n,
      children: l.jsx("div", {
        className: o + "-fill",
        style: {
          width: 10,
          height: 10,
          transform: "translate(-5px, -5px)",
          boxShadow: mt,
          borderRadius: "50%",
          backgroundColor: "#fff"
        },
        children: l.jsx("div", {
          style: {
            inset: 0,
            borderRadius: "50%",
            position: "absolute",
            backgroundColor: t
          }
        })
      })
    });
  }, Ne = Math.PI * 2, yt = (r, e) => (r % e + e) % e, wt = (r, e) => Math.sqrt(r * r + e * e);
  function Ae(r) {
    var { width: e = 0 } = r, t = e / 2;
    return {
      width: e,
      radius: t,
      cx: t,
      cy: t
    };
  }
  function Ct(r, e) {
    var { cx: t, cy: a } = Ae(r), s = Ie(r), i = (180 + Me(r, e.h, true)) * (Ne / 360), o = e.s / 100 * s, n = r.direction === "clockwise" ? -1 : 1;
    return {
      x: t + o * Math.cos(i) * n,
      y: a + o * Math.sin(i) * n
    };
  }
  function Ie(r) {
    var { width: e = 0 } = r;
    return e / 2;
  }
  function Me(r, e, t) {
    var a = r.angle || 0, s = r.direction;
    return t && s === "clockwise" ? e = a + e : s === "clockwise" ? e = 360 - a + e : t && s === "anticlockwise" ? e = a + 180 - e : s === "anticlockwise" && (e = a - e), yt(e, 360);
  }
  function jt(r, e, t) {
    var { cx: a, cy: s } = Ae(r), i = Ie(r);
    e = a - e, t = s - t;
    var o = Me(r, Math.atan2(-t, -e) * (360 / Ne)), n = Math.min(wt(e, t), i);
    return {
      h: Math.round(o),
      s: Math.round(100 / i * n)
    };
  }
  let Dt, _t, St;
  Dt = [
    "prefixCls",
    "radius",
    "pointer",
    "className",
    "style",
    "width",
    "height",
    "oval",
    "direction",
    "angle",
    "color",
    "onChange"
  ];
  _t = "conic-gradient(red, yellow, lime, aqua, blue, magenta, red)";
  St = "conic-gradient(red, magenta, blue, aqua, lime, yellow, red)";
  Oe = A.forwardRef((r, e) => {
    var { prefixCls: t = "w-color-wheel", radius: a = 0, pointer: s, className: i, style: o, width: n = 200, height: u = 200, oval: h, direction: v = "anticlockwise", angle: m = 180, color: p, onChange: g } = r, x = O(r, Dt), f = typeof p == "string" && re(p) ? W(p) : p || {}, w = p ? P(f) : "", D = {
      width: n,
      direction: v,
      angle: m
    }, c = Ct(D, f), d = {
      top: "0",
      left: "0",
      color: w
    }, j = (T, X) => {
      var k = jt(D, T.x, T.y), B = {
        h: k.h,
        s: k.s,
        v: f.v,
        a: f.a
      };
      g && g(G(B));
    }, C = {
      zIndex: 1,
      position: "absolute",
      transform: "translate(" + c.x + "px, " + c.y + "px) " + (h === "x" || h === "X" ? "scaleY(2)" : h === "y" || h === "Y" ? "scaleX(2)" : "")
    }, y = s && typeof s == "function" ? s(b({
      prefixCls: t,
      style: C
    }, d)) : l.jsx(xt, b({
      prefixCls: t,
      style: C
    }, d));
    return l.jsxs(se, b({
      className: [
        t,
        i || ""
      ].filter(Boolean).join(" ")
    }, x, {
      style: b({
        position: "relative",
        width: n,
        transform: h === "x" || h === "X" ? "scaleY(0.5)" : h === "y" || h === "Y" ? "scaleX(0.5)" : "",
        height: u
      }, o),
      ref: e,
      onMove: j,
      onDown: j,
      children: [
        y,
        l.jsx("div", {
          style: {
            position: "absolute",
            borderRadius: "50%",
            background: v === "anticlockwise" ? St : _t,
            transform: "rotateZ(" + (90 - m) + "deg)",
            inset: 0
          }
        }),
        l.jsx("div", {
          style: {
            position: "absolute",
            borderRadius: "50%",
            background: "radial-gradient(circle closest-side, #fff, transparent)",
            inset: 0
          }
        }),
        l.jsx("div", {
          style: {
            backgroundColor: "#000",
            borderRadius: "50%",
            position: "absolute",
            inset: 0,
            opacity: typeof f.v == "number" ? 1 - f.v / 100 : 0
          }
        })
      ]
    }));
  });
  Oe.displayName = "Wheel";
  Tt = function(r) {
    return l.jsxs("svg", {
      viewBox: "0 0 24 24",
      style: r.style,
      xmlns: "http://www.w3.org/2000/svg",
      children: [
        l.jsx("path", {
          stroke: "currentColor",
          fill: "none",
          "stroke-width": "2",
          "stroke-linecap": "round",
          "stroke-linejoin": "round",
          d: "M3 3m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z"
        }),
        l.jsx("path", {
          stroke: "currentColor",
          fill: "none",
          "stroke-width": "2",
          "stroke-linecap": "round",
          "stroke-linejoin": "round",
          d: "M9 8l1 8l2 -5l2 5l1 -8"
        })
      ]
    });
  };
  let S;
  S = {
    rgbDialog: {
      maxWidth: 400
    },
    rgbSliderContainer: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      width: "100%"
    },
    rgbDialogContainer: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      width: "calc(100% - 20px)"
    },
    rgbWheel: {
      display: "flex",
      justifyContent: "center"
    },
    rgbContent: {
      width: "100%",
      height: "100%",
      flex: 1,
      display: "flex",
      justifyContent: "center",
      overflow: "hidden",
      alignItems: "center"
    },
    tooltip: {
      pointerEvents: "none"
    }
  };
  ee = {
    "switch.light": "switch",
    switch: "switch",
    "level.brightness": "brightness",
    "level.dimmer": "brightness",
    "level.color.red": "red",
    "level.color.green": "green",
    "level.color.blue": "blue",
    "level.color.white": "white",
    "level.color.rgb": "rgb",
    "level.color.hue": "hue",
    "level.color.saturation": "saturation",
    "level.color.luminance": "luminance",
    "level.color.temperature": "color_temperature"
  };
  function oe(r, e, t) {
    return r < e ? e : r > t ? t : r;
  }
  let N;
  te = (r) => {
    const e = r / 100;
    let t, a, s;
    return e <= 66 ? (t = 255, a = e, a = 99.4708025861 * Math.log(a) - 161.1195681661, e <= 19 ? s = 0 : (s = e - 10, s = 138.5177312231 * Math.log(s) - 305.0447927307)) : (t = e - 60, t = 329.698727446 * t ** -0.1332047592, a = e - 60, a = 288.1221695283 * a ** -0.0755148492, s = 255), {
      red: oe(t, 0, 255),
      green: oe(a, 0, 255),
      blue: oe(s, 0, 255)
    };
  };
  N = async (r, e, t, a) => {
    var _a;
    if (e[r.name] && ((_a = await a.getObject(e[r.name])) == null ? void 0 : _a.common)) {
      const i = e[r.name].split(".");
      i.pop();
      const o = await a.getObjectViewSystem("state", `${i.join(".")}.`, `${i.join(".")}.\u9999`);
      o && (Object.values(o).forEach((n) => {
        var _a2;
        const u = (_a2 = n.common) == null ? void 0 : _a2.role;
        if (u && ee[u] && (!e[u] || e[u] === "nothing_selected") && (e[ee[u]] = n._id, ee[u] === "color_temperature")) {
          const h = n.common;
          !e.ct_min && h.min && (e.ct_min = h.min), !e.ct_max && h.max && (e.ct_max = h.max);
        }
      }), t(e));
    }
  };
  le = [
    "switch",
    "brightness",
    "rgb",
    "red",
    "green",
    "blue",
    "white",
    "color_temperature",
    "hue",
    "saturation",
    "luminance",
    "white_mode"
  ];
  class de extends V {
    contentRef = A.createRef();
    timeouts = {};
    _pressTimeout = null;
    constructor(e) {
      super(e), this.state = {
        ...this.state,
        dialog: false,
        rgbObjects: {},
        colorTemperatures: [],
        sketch: false,
        controlValue: null
      };
    }
    static getWidgetInfo() {
      return {
        id: "tplNils2RGBLight",
        visSet: "vis-2-widgets-nils-fork",
        visName: "RGBLight",
        visWidgetLabel: "rgb_light",
        visAttrs: [
          {
            name: "common",
            fields: [
              {
                name: "noCard",
                label: "without_card",
                type: "checkbox",
                hidden: "!!data.externalDialog"
              },
              {
                name: "fullSize",
                label: "fullSize",
                type: "checkbox",
                hidden: "!!data.externalDialog"
              },
              {
                name: "widgetTitle",
                label: "name",
                hidden: "!!data.noCard"
              },
              {
                name: "icon",
                type: "icon64",
                label: "icon",
                default: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iY3VycmVudENvbG9yIj4NCiAgICA8cGF0aCBkPSJNMTIgM2MtNC45NyAwLTkgNC4wMy05IDlzNC4wMyA5IDkgOWMuODMgMCAxLjUtLjY3IDEuNS0xLjUgMC0uMzktLjE1LS43NC0uMzktMS4wMS0uMjMtLjI2LS4zOC0uNjEtLjM4LS45OSAwLS44My42Ny0xLjUgMS41LTEuNUgxNmMyLjc2IDAgNS0yLjI0IDUtNSAwLTQuNDItNC4wMy04LTktOHptLTUuNSA5Yy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTNS42NyA5IDYuNSA5IDggOS42NyA4IDEwLjUgNy4zMyAxMiA2LjUgMTJ6bTMtNEM4LjY3IDggOCA3LjMzIDggNi41UzguNjcgNSA5LjUgNXMxLjUuNjcgMS41IDEuNVMxMC4zMyA4IDkuNSA4em01IDBjLS44MyAwLTEuNS0uNjctMS41LTEuNVMxMy42NyA1IDE0LjUgNXMxLjUuNjcgMS41IDEuNVMxNS4zMyA4IDE0LjUgOHptMyA0Yy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTMTYuNjcgOSAxNy41IDlzMS41LjY3IDEuNSAxLjUtLjY3IDEuNS0xLjUgMS41eiIvPg0KPC9zdmc+DQo=",
                hidden: "!!data.externalDialog"
              },
              {
                name: "switch",
                type: "id",
                label: "switch",
                onChange: N
              },
              {
                name: "brightness",
                type: "id",
                label: "brightness",
                onChange: N
              },
              {
                name: "rgbType",
                label: "type",
                type: "select",
                noTranslation: true,
                options: [
                  "rgb",
                  "rgbw",
                  "r/g/b",
                  "r/g/b/w",
                  "hue/sat/lum",
                  "ct"
                ],
                onChange: N
              },
              {
                name: "rgb",
                type: "id",
                label: "rgb",
                hidden: (e) => e.rgbType !== "rgb" && e.rgbType !== "rgbw",
                onChange: N
              },
              {
                name: "red",
                type: "id",
                label: "red",
                hidden: (e) => e.rgbType !== "r/g/b" && e.rgbType !== "r/g/b/w",
                onChange: N
              },
              {
                name: "green",
                type: "id",
                label: "green",
                hidden: (e) => e.rgbType !== "r/g/b" && e.rgbType !== "r/g/b/w",
                onChange: N
              },
              {
                name: "blue",
                type: "id",
                label: "blue",
                hidden: (e) => e.rgbType !== "r/g/b" && e.rgbType !== "r/g/b/w",
                onChange: N
              },
              {
                name: "white",
                type: "id",
                label: "white",
                hidden: (e) => e.rgbType !== "r/g/b/w" && e.rgbType !== "rgbw",
                onChange: N
              },
              {
                name: "color_temperature",
                type: "id",
                label: "color_temperature",
                hidden: (e) => e.rgbType !== "ct",
                onChange: N
              },
              {
                name: "ct_min",
                type: "number",
                min: 500,
                max: 1e4,
                label: "color_temperature_min",
                hidden: (e) => e.rgbType !== "ct" || !e.color_temperature
              },
              {
                name: "ct_max",
                type: "number",
                min: 500,
                max: 1e4,
                label: "color_temperature_max",
                hidden: (e) => e.rgbType !== "ct" || !e.color_temperature
              },
              {
                name: "hue",
                type: "id",
                label: "hue",
                hidden: (e) => e.rgbType !== "hue/sat/lum",
                onChange: N
              },
              {
                name: "saturation",
                type: "id",
                label: "saturation",
                hidden: (e) => e.rgbType !== "hue/sat/lum",
                onChange: N
              },
              {
                name: "luminance",
                type: "id",
                label: "luminance",
                hidden: (e) => e.rgbType !== "hue/sat/lum",
                onChange: N
              },
              {
                name: "hideBrightness",
                type: "checkbox",
                label: "hideBrightness",
                hidden: (e) => e.rgbType !== "rgb" && e.rgbType !== "rgbw" && e.rgbType !== "r/g/b" && e.rgbType !== "r/g/b/w",
                onChange: N
              },
              {
                name: "white_mode",
                type: "id",
                label: "whiteMode",
                tooltip: "whiteModeTooltip",
                hidden: (e) => e.rgbType !== "rgbw" && e.rgbType !== "r/g/b/w",
                onChange: N
              },
              {
                name: "noRgbPalette",
                type: "checkbox",
                label: "noRgbPalette",
                hidden: (e) => e.rgbType !== "rgb" && e.rgbType !== "rgbw" && e.rgbType !== "r/g/b" && e.rgbType !== "r/g/b/w",
                onChange: N
              },
              {
                name: "timeout",
                label: "controlTimeout",
                tooltip: "In milliseconds",
                type: "number",
                min: 0,
                max: 2e3
              },
              {
                name: "toggleOnClick",
                label: "toggleOnClick",
                type: "checkbox",
                hidden: "!data.switch"
              },
              {
                label: "pressDuration",
                name: "pressDuration",
                tooltip: "pressDuration_tooltip",
                type: "slider",
                min: 100,
                max: 3e3,
                hidden: "!data.toggleOnClick || !data.switch"
              },
              {
                label: "borderRadius",
                name: "borderRadius",
                type: "slider",
                min: 0,
                max: 100,
                hidden: "!data.noCard"
              },
              {
                name: "color",
                type: "color",
                label: "color"
              },
              {
                name: "colorEnabled",
                type: "color",
                label: "color_active"
              },
              {
                name: "onlyCircle",
                label: "onlyCircle",
                type: "checkbox"
              },
              {
                name: "externalDialog",
                label: "use_as_dialog",
                type: "checkbox",
                tooltip: "use_as_dialog_tooltip"
              }
            ]
          }
        ],
        visDefaultStyle: {
          width: "100%",
          height: 120,
          position: "relative"
        },
        visPrev: "widgets/vis-2-widgets-nils-fork/img/prev_rgb_light.png"
      };
    }
    async componentDidMount() {
      super.componentDidMount(), await this.rgbReadObjects();
    }
    componentWillUnmount() {
      super.componentWillUnmount(), this.rgbDestroy();
    }
    async onRxDataChanged() {
      await this.rgbReadObjects();
    }
    getWidgetInfo() {
      return de.getWidgetInfo();
    }
    rgbGetIdMin = (e) => {
      var _a, _b, _c, _d;
      return e === "color_temperature" ? this.state.rxData.ct_min || ((_b = (_a = this.state.rgbObjects[e]) == null ? void 0 : _a.common) == null ? void 0 : _b.min) || 0 : ((_d = (_c = this.state.rgbObjects[e]) == null ? void 0 : _c.common) == null ? void 0 : _d.min) || 0;
    };
    rgbGetIdMax = (e) => {
      var _a, _b, _c, _d;
      return e === "color_temperature" ? this.state.rxData.ct_max || ((_b = (_a = this.state.rgbObjects[e]) == null ? void 0 : _a.common) == null ? void 0 : _b.max) || 0 : ((_d = (_c = this.state.rgbObjects[e]) == null ? void 0 : _c.common) == null ? void 0 : _d.max) || 0;
    };
    rgbSetId = (e, t) => {
      var _a;
      this.state.rgbObjects[e] && (this.timeouts[e] && (clearTimeout(this.timeouts[e]), this.timeouts[e] = null), e === "switch" || e === "white_mode" ? this.props.context.setValue(this.state.rxData[e], t) : this.setState({
        controlValue: {
          id: e,
          value: t,
          changed: !!((_a = this.state.controlValue) == null ? void 0 : _a.changed)
        }
      }, () => {
        this.timeouts[e] = setTimeout(() => {
          this.timeouts[e] = null, this.props.context.setValue(this.state.rxData[e], t);
        }, parseInt(this.state.rxData.timeout, 10) || 200);
      }));
    };
    async rgbReadObjects() {
      var _a, _b, _c, _d;
      const e = {}, t = [];
      for (const i of le) this.state.rxData[i] && this.state.rxData[i] !== "nothing_selected" && t.push(this.state.rxData[i]);
      const a = await this.props.context.socket.getObjectsById(t), s = {};
      for (const i of le) if (this.state.rxData[i]) {
        const o = a[this.state.rxData[i]];
        o && (e[i] = o);
      }
      if (s.rgbObjects = e, e.color_temperature) {
        const i = [];
        let o = parseInt(this.state.rxData.ct_min || ((_b = (_a = e.color_temperature) == null ? void 0 : _a.common) == null ? void 0 : _b.min), 10) || 2700, n = parseInt(this.state.rxData.ct_max || ((_d = (_c = e.color_temperature) == null ? void 0 : _c.common) == null ? void 0 : _d.max), 10) || 6e3;
        if (n < o) {
          const h = n;
          n = o, o = h;
        }
        const u = (n - o) / 20;
        if (u) for (let h = o; h <= n; h += u) i.push(te(h));
        s.colorTemperatures = i;
      } else s.colorTemperatures = [];
      this.setState(s);
    }
    rgbDestroy() {
      for (const e in this.timeouts) this.timeouts[e] && (clearTimeout(this.timeouts[e]), this.timeouts[e] = null);
    }
    rgbIsOnlyHue = () => this.state.rxData.rgbType === "hue/sat/lum" && (!this.state.rgbObjects.saturation || !this.state.rgbObjects.luminance);
    rgbGetWheelColor = () => {
      let e = {
        h: 0,
        s: 0,
        v: 0,
        a: 1
      };
      if (this.state.rxData.rgbType === "hue/sat/lum") e = Fe({
        h: this.getPropertyValue("hue"),
        s: this.rgbIsOnlyHue() ? 100 : this.getPropertyValue("saturation"),
        l: this.rgbIsOnlyHue() ? 50 : this.getPropertyValue("luminance"),
        a: 1
      });
      else if (this.state.rxData.rgbType === "r/g/b" || this.state.rxData.rgbType === "r/g/b/w") e = U({
        r: this.getPropertyValue("red"),
        g: this.getPropertyValue("green"),
        b: this.getPropertyValue("blue"),
        a: 1
      });
      else if (this.state.rxData.rgbType === "rgb") try {
        const t = this.getPropertyValue("rgb") || "";
        t && t.length >= 4 ? e = W(t) : e = W("#000000");
      } catch (t) {
        console.error(t);
      }
      else if (this.state.rxData.rgbType === "rgbw") try {
        const t = this.getPropertyValue("rgb") || "";
        t && t.length >= 4 ? e = W(t) : e = W("#000000");
      } catch (t) {
        console.error(t);
      }
      return this.state.rxData.hideBrightness && (e.v = 100), e;
    };
    rgbSetWheelColor = (e) => {
      if (this.state.rxData.rgbType === "hue/sat/lum") {
        const t = ce(e);
        this.rgbSetId("hue", e.h), this.rgbIsOnlyHue() || (this.rgbSetId("saturation", t.s), this.rgbSetId("luminance", t.l));
      } else if (this.state.rxData.rgbType === "r/g/b" || this.state.rxData.rgbType === "r/g/b/w") {
        const t = F(e);
        this.rgbSetId("red", t.r), this.rgbSetId("green", t.g), this.rgbSetId("blue", t.b);
      } else if (this.state.rxData.rgbType === "rgb") this.rgbSetId("rgb", P(e));
      else if (this.state.rxData.rgbType === "rgbw") if (this.state.rgbObjects.white) this.rgbSetId("rgb", P(e));
      else {
        let t = this.getPropertyValue("rgb") || "#00000000";
        t = P(e) + t.substring(7), this.rgbSetId("rgb", t);
      }
    };
    rgbGetWhite = () => {
      var _a;
      if (this.state.rxData.rgbType === "r/g/b/w") return this.getPropertyValue("white");
      if (this.state.rxData.rgbType === "rgbw") {
        if (this.state.rgbObjects.white) return this.getPropertyValue("white");
        const e = (_a = this.getPropertyValue("rgb")) == null ? void 0 : _a.substring(7);
        return parseInt(e, 16);
      }
      return 0;
    };
    rgbGetWhiteId = () => this.state.rxData.rgbType === "r/g/b/w" ? "white" : this.state.rxData.rgbType === "rgbw" ? this.state.rgbObjects.white ? "white" : "rgb" : "";
    rgbSetWhite = (e) => {
      if (this.state.rxData.rgbType === "r/g/b/w") this.rgbSetId("white", e);
      else if (this.state.rxData.rgbType === "rgbw") if (this.state.rgbObjects.white) this.rgbSetId("white", e);
      else {
        let t = this.getPropertyValue("rgb") || "#00000000";
        t = t.substring(0, 7) + e.toString(16).padStart(2, "0"), this.rgbSetId("rgb", t);
      }
    };
    rgbSetWhiteMode = (e) => {
      this.state.rxData.white_mode && this.rgbSetId("white_mode", e);
    };
    rgbGetWhiteMode = () => {
      if (this.state.rxData.white_mode) return this.getPropertyValue("white_mode");
    };
    rgbIsRgb = () => (this.state.rxData.rgbType === "rgb" || this.state.rxData.rgbType === "rgbw") && this.state.rxData.rgb ? true : !!((this.state.rxData.rgbType === "r/g/b" || this.state.rxData.rgbType === "r/g/b/w") && this.state.rgbObjects.red && this.state.rgbObjects.green && this.state.rgbObjects.blue);
    rgbIsWhite = () => !!(this.state.rxData.rgbType === "rgbw" && this.state.rxData.rgb || this.state.rxData.rgbType === "r/g/b/w" && this.state.rgbObjects.white);
    rgbIsHSL = () => this.state.rxData.rgbType === "hue/sat/lum" && !!this.state.rgbObjects.hue;
    rgbRenderSwitch() {
      return this.state.rgbObjects.switch && l.jsxs("div", {
        style: {
          ...S.rgbSliderContainer,
          justifyContent: "center"
        },
        children: [
          V.t("Off"),
          l.jsx(Be, {
            checked: this.getPropertyValue("switch") || false,
            onChange: (e) => this.rgbSetId("switch", e.target.checked)
          }),
          V.t("On")
        ]
      });
    }
    onStateUpdated(e) {
      var _a;
      ((_a = this.state.controlValue) == null ? void 0 : _a.id) && this.state.rxData[this.state.controlValue.id] === e && this.setState({
        controlValue: {
          id: this.state.controlValue.id,
          value: this.state.controlValue.value,
          changed: true
        }
      });
    }
    finishChanging() {
      if (this.state.controlValue) {
        const e = {
          controlValue: null
        };
        if (!this.state.controlValue.changed && this.state.controlValue.id) {
          const t = JSON.parse(JSON.stringify(this.state.values));
          t[`${this.state.rxData[this.state.controlValue.id]}.val`] = this.state.controlValue.value, e.values = t;
        }
        this.setState(e);
      }
    }
    rgbRenderBrightness() {
      var _a;
      return this.state.rgbObjects.brightness && l.jsxs("div", {
        style: S.rgbSliderContainer,
        children: [
          l.jsx(Q, {
            title: V.t("Brightness"),
            slotProps: {
              popper: {
                sx: S.tooltip
              }
            },
            children: l.jsx(ze, {})
          }),
          l.jsx(ie, {
            min: this.rgbGetIdMin("brightness") || 0,
            max: this.rgbGetIdMax("brightness") || 100,
            valueLabelDisplay: "auto",
            value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === "brightness" ? this.state.controlValue.value : this.getPropertyValue("brightness") || 0,
            onChange: (e, t) => this.rgbSetId("brightness", t),
            onChangeCommitted: () => this.finishChanging()
          })
        ]
      });
    }
    rgbRenderSketch() {
      return l.jsx("div", {
        className: "dark",
        style: S.rgbWheel,
        children: l.jsx(Re, {
          color: this.rgbGetWheelColor(),
          disableAlpha: true,
          onChange: (e) => this.rgbSetWheelColor(e.hsva)
        })
      });
    }
    rgbRenderWheelTypeSwitch(e, t, a) {
      return !e || a === null && this.state.rxData.noRgbPalette ? null : !this.rgbIsOnlyHue() && l.jsxs("div", {
        style: {
          textAlign: t ? "right" : void 0
        },
        children: [
          a !== null ? l.jsx(Q, {
            title: V.t("Switch white mode"),
            slotProps: {
              popper: {
                sx: S.tooltip
              }
            },
            children: l.jsx(q, {
              onClick: () => this.rgbSetWhiteMode(!a),
              color: a ? "primary" : "default",
              children: l.jsx(He, {})
            })
          }) : null,
          !this.state.rxData.noRgbPalette && a !== true ? l.jsx(Q, {
            title: V.t("Switch color picker"),
            slotProps: {
              popper: {
                sx: S.tooltip
              }
            },
            children: l.jsx(q, {
              onClick: () => this.setState({
                sketch: !this.state.sketch
              }),
              children: l.jsx(pe, {})
            })
          }) : null
        ]
      });
    }
    rgbRenderBrightnessSlider(e, t) {
      return !e || this.state.sketch || this.state.rxData.hideBrightness || t === true ? null : !this.rgbIsOnlyHue() && l.jsx(ke, {
        hsva: this.rgbGetWheelColor(),
        onChange: (a) => this.rgbSetWheelColor({
          ...this.rgbGetWheelColor(),
          ...a
        })
      });
    }
    rgbRenderWheel(e, t) {
      return !e || t === true ? null : this.state.sketch ? this.rgbRenderSketch() : l.jsx("div", {
        style: S.rgbWheel,
        children: l.jsx(Oe, {
          color: this.rgbGetWheelColor(),
          onChange: (a) => {
            a = JSON.parse(JSON.stringify(a)), this.rgbSetWheelColor(a.hsva);
          }
        })
      });
    }
    rgbRenderWhite() {
      var _a;
      if (!this.rgbIsWhite()) return null;
      let e, t;
      return this.state.rgbObjects.white ? (e = this.rgbGetIdMin("white") || 0, t = this.rgbGetIdMax("white") || 100) : (e = 0, t = 255), l.jsxs("div", {
        style: S.rgbSliderContainer,
        children: [
          l.jsx(Tt, {
            style: {
              width: 24,
              height: 24
            }
          }),
          l.jsx(ie, {
            min: e,
            max: t,
            valueLabelDisplay: "auto",
            value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === this.rgbGetWhiteId() ? this.state.controlValue.value : this.rgbGetWhite() || 0,
            onChange: (a, s) => this.rgbSetWhite(s),
            onChangeCommitted: () => this.finishChanging()
          })
        ]
      });
    }
    rgbRenderColorTemperature(e) {
      var _a;
      return this.state.rxData.rgbType !== "ct" || e === true ? null : l.jsxs("div", {
        style: S.rgbSliderContainer,
        children: [
          l.jsx(Q, {
            title: V.t("Color temperature"),
            slotProps: {
              popper: {
                sx: S.tooltip
              }
            },
            children: l.jsx(Ue, {})
          }),
          l.jsx("div", {
            style: {
              ...S.rgbSliderContainer,
              background: `linear-gradient(to right, ${this.state.colorTemperatures.map((t) => `rgb(${t.red}, ${t.green}, ${t.blue})`).join(", ")})`,
              flex: "1",
              borderRadius: 4
            },
            children: l.jsx(ie, {
              valueLabelDisplay: "auto",
              min: this.rgbGetIdMin("color_temperature") || 2700,
              max: this.rgbGetIdMax("color_temperature") || 6e3,
              value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === "color_temperature" ? this.state.controlValue.value : this.getPropertyValue("color_temperature") || 0,
              onChange: (t, a) => this.rgbSetId("color_temperature", a),
              onChangeCommitted: () => this.finishChanging()
            })
          })
        ]
      });
    }
    rgbRenderDialog(e, t) {
      return this.state.dialog ? l.jsxs(Pe, {
        fullWidth: true,
        maxWidth: "sm",
        open: true,
        sx: {
          "& .MuiDialog-paper": S.rgbDialog
        },
        onClose: () => this.setState({
          dialog: false
        }),
        children: [
          l.jsxs(Ee, {
            children: [
              this.state.rxData.widgetTitle,
              l.jsx(q, {
                style: {
                  float: "right",
                  zIndex: 2
                },
                onClick: () => this.setState({
                  dialog: false
                }),
                children: l.jsx($e, {})
              })
            ]
          }),
          l.jsx(Ve, {
            style: {
              maxWidth: 400
            },
            children: l.jsxs("div", {
              style: S.rgbDialogContainer,
              children: [
                this.rgbRenderSwitch(),
                this.rgbRenderBrightness(),
                this.rgbRenderWhite(),
                this.rgbRenderWheelTypeSwitch(e, false, t),
                this.rgbRenderWheel(e, t),
                this.rgbRenderBrightnessSlider(e, t),
                this.rgbRenderColorTemperature(t)
              ]
            })
          })
        ]
      }) : null;
    }
    rgbGetColor = () => {
      if (this.state.rxData.rgbType === "ct") {
        const e = te(this.getPropertyValue("color_temperature"));
        return Xe({
          r: e.red,
          g: e.green,
          b: e.blue
        });
      }
      return P(this.rgbGetWheelColor());
    };
    rgbGetTextColor = () => {
      if (this.state.rxData.rgbType === "ct") {
        const t = te(this.getPropertyValue("color_temperature"));
        return t.red + t.green + t.blue > 384 ? "#000000" : "#ffffff";
      }
      const e = F(this.rgbGetWheelColor());
      return e.r + e.g + e.b > 384 ? "#000000" : "#ffffff";
    };
    onCommand(e) {
      const t = super.onCommand(e);
      if (t === false) {
        if (e === "openDialog") return this.setState({
          dialog: true
        }), true;
        if (e === "closeDialog") return this.setState({
          dialog: false
        }), true;
      }
      return t;
    }
    renderWidgetBody(e) {
      var _a, _b;
      super.renderWidgetBody(e);
      let t = 0;
      this.state.rxData.fullSize ? t = (_b = (_a = this.refService) == null ? void 0 : _a.current) == null ? void 0 : _b.clientWidth : this.contentRef.current && (t = this.contentRef.current.offsetWidth > this.contentRef.current.offsetHeight ? this.contentRef.current.offsetHeight : this.contentRef.current.offsetWidth);
      let a = null;
      this.state.rgbObjects.switch && (a = this.getPropertyValue("switch"));
      let s;
      a ? s = this.state.rxData.colorEnabled || "#4DABF5" : s = this.state.rxData.color || (this.props.context.themeType === "dark" ? "#111" : "#eee");
      const i = this.rgbIsRgb() || this.rgbIsHSL(), o = this.rgbGetWhiteMode();
      let n;
      if (this.state.rxData.fullSize && !this.state.rxData.externalDialog) i && t >= 350 ? n = l.jsxs("div", {
        ref: this.contentRef,
        style: {
          ...S.rgbDialogContainer,
          flexDirection: "row",
          width: "100%"
        },
        children: [
          l.jsxs("div", {
            style: {
              flexDirection: "column",
              gap: 12,
              flexGrow: 1,
              display: "flex"
            },
            children: [
              this.rgbRenderSwitch(),
              this.rgbRenderBrightness(),
              this.rgbRenderWhite(),
              this.rgbRenderColorTemperature(o),
              this.rgbRenderBrightnessSlider(i, o),
              this.rgbRenderWheelTypeSwitch(i, true, o)
            ]
          }),
          l.jsx("div", {
            style: {
              flexDirection: "column",
              display: "flex"
            },
            children: this.rgbRenderWheel(i, o)
          })
        ]
      }) : n = l.jsxs("div", {
        ref: this.contentRef,
        style: S.rgbDialogContainer,
        children: [
          this.rgbRenderSwitch(),
          this.rgbRenderBrightness(),
          this.rgbRenderWhite(),
          this.rgbRenderWheelTypeSwitch(i, false, o),
          this.rgbRenderWheel(i, o),
          this.rgbRenderBrightnessSlider(i, o),
          this.rgbRenderColorTemperature(o)
        ]
      });
      else if (this.props.editMode || !this.state.rxData.externalDialog) {
        a ? e.className = `${e.className} vis-on`.trim() : e.className = `${e.className} vis-off`.trim();
        let u = this.state.rxData.icon;
        const h = {
          color: this.rgbGetColor(),
          width: "90%",
          height: "90%"
        };
        a === false && (h.opacity = 0.7), u !== void 0 ? u ? u = l.jsx(Ye, {
          src: u,
          alt: this.props.id,
          style: h
        }) : (h.borderRadius = "50%", u = l.jsx("div", {
          style: h
        })) : u = l.jsx(pe, {
          style: h
        });
        let v = null;
        this.state.rxData.noCard || e.widget.usedInWidget ? (v = {
          boxSizing: "border-box"
        }, this.state.rxData.onlyCircle || (v.backgroundColor = s)) : this.state.rxData.onlyCircle || (v = {
          backgroundColor: s
        });
        let m;
        this.state.rxData.onlyCircle ? m = l.jsx(q, {
          onClick: !this.state.rxData.toggleOnClick || !this.state.rgbObjects.switch ? () => this.setState({
            dialog: true
          }) : void 0,
          onMouseDown: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
            this._pressTimeout && clearTimeout(this._pressTimeout), this._pressTimeout = setTimeout(() => {
              this._pressTimeout = null, this.setState({
                dialog: true
              });
            }, parseInt(this.state.rxData.pressDuration, 10) || 300);
          } : void 0,
          onMouseUp: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
            this._pressTimeout && (clearTimeout(this._pressTimeout), this._pressTimeout = null, this.rgbSetId("switch", !a));
          } : void 0,
          onTouchStart: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
            this._pressTimeout && clearTimeout(this._pressTimeout), this._pressTimeout = setTimeout(() => {
              this._pressTimeout = null, this.setState({
                dialog: true
              });
            }, parseInt(this.state.rxData.pressDuration, 10) || 300);
          } : void 0,
          onTouchEnd: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
            this._pressTimeout && (clearTimeout(this._pressTimeout), this._pressTimeout = null, this.rgbSetId("switch", !a));
          } : void 0,
          style: {
            backgroundColor: this.state.rxData.onlyCircle ? s : void 0,
            width: t,
            height: t,
            borderRadius: parseInt(this.state.rxData.borderRadius, 10) || void 0
          },
          children: u
        }) : m = l.jsx(Ge, {
          onClick: !this.state.rxData.toggleOnClick || !this.state.rgbObjects.switch ? () => this.setState({
            dialog: true
          }) : void 0,
          onMouseDown: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
            this._pressTimeout && clearTimeout(this._pressTimeout), this._pressTimeout = setTimeout(() => {
              this._pressTimeout = null, this.setState({
                dialog: true
              });
            }, parseInt(this.state.rxData.pressDuration, 10) || 300);
          } : void 0,
          onMouseUp: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
            this._pressTimeout && (clearTimeout(this._pressTimeout), this._pressTimeout = null, this.rgbSetId("switch", !a));
          } : void 0,
          onTouchStart: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
            this._pressTimeout && clearTimeout(this._pressTimeout), this._pressTimeout = setTimeout(() => {
              this._pressTimeout = null, this.setState({
                dialog: true
              });
            }, parseInt(this.state.rxData.pressDuration, 10) || 300);
          } : void 0,
          onTouchEnd: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
            this._pressTimeout && (clearTimeout(this._pressTimeout), this._pressTimeout = null, this.rgbSetId("switch", !a));
          } : void 0,
          style: {
            backgroundColor: this.state.rxData.onlyCircle ? s : void 0,
            width: "100%",
            height: "100%",
            borderRadius: parseInt(this.state.rxData.borderRadius, 10) || void 0
          },
          children: u
        }), n = l.jsxs(l.Fragment, {
          children: [
            l.jsx("div", {
              ref: this.contentRef,
              style: {
                ...S.rgbContent,
                ...v
              },
              children: m
            }),
            this.rgbRenderDialog(i, o)
          ]
        });
      } else if (this.state.rxData.externalDialog) return this.rgbRenderDialog(i);
      return this.state.rxData.noCard || e.widget.usedInWidget ? n || l.jsx("div", {}) : this.wrapContent(n || l.jsx("div", {}), null);
    }
  }
  Bt = Object.freeze(Object.defineProperty({
    __proto__: null,
    RGB_NAMES: le,
    RGB_ROLES: ee,
    colorTemperatureToRGB: te,
    default: de
  }, Symbol.toStringTag, {
    value: "Module"
  }));
});
export {
  ee as R,
  Re as S,
  Tt as T,
  Oe as W,
  __tla,
  le as a,
  W as b,
  ce as c,
  F as d,
  P as e,
  ke as f,
  te as g,
  Fe as h,
  Xe as i,
  Bt as j,
  U as r
};
