import { A as e, B as t, D as n, F as r, I as i, N as a, g as o, k as s } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as c, H as l, I as u, L as d, P as f, Q as p, T as m, dt as h, ft as g, g as _, n as v, p as y, pt as b, st as x, u as S } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as C } from "./Thermostat-XvI2VZ3I.js";
import { t as w } from "./Generic-BOiMPpxz.js";
var T = x(g(`path`, { d: `M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8m-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12m3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8m5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8m3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5` }), `ColorLens`), E = x(g(`path`, { d: `M6.85 12.65h2.3L8 9zM22 7l-1.2 6.29L19.3 7h-1.6l-1.49 6.29L15 7h-.76C12.77 5.17 10.53 4 8 4c-4.42 0-8 3.58-8 8s3.58 8 8 8c3.13 0 5.84-1.81 7.15-4.43l.1.43H17l1.5-6.1L20 16h1.75l2.05-9zm-11.7 9-.7-2H6.4l-.7 2H3.8L7 7h2l3.2 9z` }), `WbAuto`);
function D() {
  return D = Object.assign ? Object.assign.bind() : function(e3) {
    for (var t2 = 1; t2 < arguments.length; t2++) {
      var n2 = arguments[t2];
      for (var r2 in n2) ({}).hasOwnProperty.call(n2, r2) && (e3[r2] = n2[r2]);
    }
    return e3;
  }, D.apply(null, arguments);
}
var O = 255, k = 360, A = 100, j = (e3) => {
  var t2 = e3.r, n2 = e3.g, r2 = e3.b, i2 = e3.a, a2 = Math.max(t2, n2, r2), o2 = a2 - Math.min(t2, n2, r2), s2 = o2 ? a2 === t2 ? (n2 - r2) / o2 : a2 === n2 ? 2 + (r2 - t2) / o2 : 4 + (t2 - n2) / o2 : 0;
  return { h: 60 * (s2 < 0 ? s2 + 6 : s2), s: a2 ? o2 / a2 * A : 0, v: a2 / O * A, a: i2 };
}, M = (e3) => {
  var t2 = P(e3), n2 = t2.h, r2 = t2.s, i2 = t2.l, a2 = t2.a;
  return `hsla(` + n2 + `, ` + r2 + `%, ` + i2 + `%, ` + a2 + `)`;
}, N = (e3) => {
  var t2 = e3.h, n2 = e3.s, r2 = e3.l, i2 = e3.a;
  return n2 *= (r2 < 50 ? r2 : A - r2) / A, { h: t2, s: n2 > 0 ? 2 * n2 / (r2 + n2) * A : 0, v: r2 + n2, a: i2 };
}, P = (e3) => {
  var t2 = e3.h, n2 = e3.s, r2 = e3.v, i2 = e3.a, a2 = (200 - n2) * r2 / A;
  return { h: t2, s: a2 > 0 && a2 < 200 ? n2 * r2 / A / (a2 <= A ? a2 : 200 - a2) * A : 0, l: a2 / 2, a: i2 };
};
k / 400, k / (Math.PI * 2);
var F = (e3) => {
  var t2 = e3.r, n2 = e3.g, r2 = e3.b;
  return I({ r: t2, g: n2, b: r2 });
}, I = (e3) => {
  var t2 = e3.r, n2 = e3.g, r2 = e3.b;
  return `#` + ((e4) => Array(7 - e4.length).join(`0`) + e4)((t2 << 16 | n2 << 8 | r2).toString(16));
}, ee = (e3) => {
  var t2 = e3.r, n2 = e3.g, r2 = e3.b, i2 = e3.a, a2 = typeof i2 == `number` && (i2 * 255 | 256).toString(16).slice(1);
  return `` + I({ r: t2, g: n2, b: r2 }) + (a2 || ``);
}, L = (e3) => j(te(e3)), te = (e3) => {
  var t2 = e3.replace(`#`, ``);
  /^#?/.test(e3) && t2.length === 3 && (e3 = `#` + t2.charAt(0) + t2.charAt(0) + t2.charAt(1) + t2.charAt(1) + t2.charAt(2) + t2.charAt(2));
  var n2 = RegExp(`[A-Za-z0-9]{2}`, `g`), r2 = e3.match(n2).map((e4) => parseInt(e4, 16)), i2 = r2[0], a2 = r2[1], o2 = r2[2];
  return { r: i2, g: a2, b: o2 === void 0 ? 0 : o2, a: (r2[3] ?? 255) / O };
}, R = (e3) => {
  var t2 = e3.h, n2 = e3.s, r2 = e3.v, i2 = e3.a, a2 = t2 / 60, o2 = n2 / A, s2 = r2 / A, c2 = Math.floor(a2) % 6, l2 = a2 - Math.floor(a2), u2 = O * s2 * (1 - o2), d2 = O * s2 * (1 - o2 * l2), f2 = O * s2 * (1 - o2 * (1 - l2));
  s2 *= O;
  var p2 = {};
  switch (c2) {
    case 0:
      p2.r = s2, p2.g = f2, p2.b = u2;
      break;
    case 1:
      p2.r = d2, p2.g = s2, p2.b = u2;
      break;
    case 2:
      p2.r = u2, p2.g = s2, p2.b = f2;
      break;
    case 3:
      p2.r = u2, p2.g = d2, p2.b = s2;
      break;
    case 4:
      p2.r = f2, p2.g = u2, p2.b = s2;
      break;
    case 5:
      p2.r = s2, p2.g = u2, p2.b = d2;
  }
  return p2.r = Math.round(p2.r), p2.g = Math.round(p2.g), p2.b = Math.round(p2.b), D({}, p2, { a: i2 });
}, ne = (e3) => {
  var t2 = R(e3), n2 = t2.r, r2 = t2.g, i2 = t2.b, a2 = t2.a;
  return `rgba(` + n2 + `, ` + r2 + `, ` + i2 + `, ` + a2 + `)`;
}, re = (e3) => ({ r: e3.r, g: e3.g, b: e3.b }), ie = (e3) => ({ h: e3.h, s: e3.s, l: e3.l }), z = (e3) => I(R(e3)), ae = (e3) => ({ h: e3.h, s: e3.s, v: e3.v }), oe = (e3) => {
  var t2 = e3.r, n2 = e3.g, r2 = e3.b, i2 = function(e4) {
    return e4 <= 0.04045 ? e4 / 12.92 : ((e4 + 0.055) / 1.055) ** 2.4;
  }, a2 = i2(t2 / 255), o2 = i2(n2 / 255), s2 = i2(r2 / 255), c2 = {};
  return c2.x = a2 * 0.4124 + o2 * 0.3576 + s2 * 0.1805, c2.y = a2 * 0.2126 + o2 * 0.7152 + s2 * 0.0722, c2.bri = a2 * 0.0193 + o2 * 0.1192 + s2 * 0.9505, c2;
}, B = (e3) => {
  var t2, n2, r2, i2, a2, o2, s2, c2, l2;
  return typeof e3 == `string` && V(e3) ? (o2 = L(e3), c2 = e3) : typeof e3 != `string` && (o2 = e3), o2 && (r2 = ae(o2), a2 = P(o2), i2 = R(o2), l2 = ee(i2), c2 = z(o2), n2 = ie(a2), t2 = re(i2), s2 = oe(t2)), { rgb: t2, hsl: n2, hsv: r2, rgba: i2, hsla: a2, hsva: o2, hex: c2, hexa: l2, xy: s2 };
}, V = (e3) => /^#?([A-Fa-f0-9]{3,4}){1,2}$/.test(e3);
function H(e3, t2) {
  if (e3 == null) return {};
  var n2 = {};
  for (var r2 in e3) if ({}.hasOwnProperty.call(e3, r2)) {
    if (t2.indexOf(r2) !== -1) continue;
    n2[r2] = e3[r2];
  }
  return n2;
}
t();
function se(e3) {
  var t2 = r(e3);
  return s(() => {
    t2.current = e3;
  }), n((e4, n2) => t2.current && t2.current(e4, n2), []);
}
var U = (e3) => `touches` in e3, ce = (e3) => {
  !U(e3) && e3.preventDefault && e3.preventDefault();
}, le = function(e3, t2, n2) {
  return t2 === void 0 && (t2 = 0), n2 === void 0 && (n2 = 1), e3 > n2 ? n2 : e3 < t2 ? t2 : e3;
}, ue = (e3, t2) => {
  var n2 = e3.getBoundingClientRect(), r2 = U(t2) ? t2.touches[0] : t2;
  return { left: le((r2.pageX - (n2.left + window.pageXOffset)) / n2.width), top: le((r2.pageY - (n2.top + window.pageYOffset)) / n2.height), width: n2.width, height: n2.height, x: r2.pageX - (n2.left + window.pageXOffset), y: r2.pageY - (n2.top + window.pageYOffset) };
};
t();
var de = [`prefixCls`, `className`, `onMove`, `onDown`], W = o.forwardRef((e3, t2) => {
  var a2 = e3.prefixCls, o2 = a2 === void 0 ? `w-color-interactive` : a2, c2 = e3.className, l2 = e3.onMove, u2 = e3.onDown, d2 = H(e3, de), f2 = r(null), p2 = r(false), m2 = i(false), h2 = m2[0], _2 = m2[1], v2 = se(l2), y2 = se(u2), b2 = (e4) => p2.current && !U(e4) ? false : (p2.current = U(e4), true), x2 = n((e4) => {
    if (ce(e4), f2.current) {
      if (!(U(e4) ? e4.touches.length > 0 : e4.buttons > 0)) {
        _2(false);
        return;
      }
      v2 == null ? void 0 : v2(ue(f2.current, e4), e4);
    }
  }, [v2]), S2 = n(() => _2(false), []), C2 = n((e4) => {
    e4 ? (window.addEventListener(p2.current ? `touchmove` : `mousemove`, x2), window.addEventListener(p2.current ? `touchend` : `mouseup`, S2)) : (window.removeEventListener(`mousemove`, x2), window.removeEventListener(`mouseup`, S2), window.removeEventListener(`touchmove`, x2), window.removeEventListener(`touchend`, S2));
  }, [x2, S2]);
  s(() => (C2(h2), () => {
    C2(false);
  }), [h2, x2, S2, C2]);
  var w2 = n((e4) => {
    var _a;
    (_a = document.activeElement) == null ? void 0 : _a.blur(), ce(e4.nativeEvent), b2(e4.nativeEvent) && f2.current && (y2 == null ? void 0 : y2(ue(f2.current, e4.nativeEvent), e4.nativeEvent), _2(true));
  }, [y2]);
  return g(`div`, D({}, d2, { className: [o2, c2 || ``].filter(Boolean).join(` `), style: D({}, d2.style, { touchAction: `none` }), ref: f2, tabIndex: 0, onMouseDown: w2, onTouchStart: w2 }));
});
W.displayName = `Interactive`, t();
var fe = [`className`, `prefixCls`, `left`, `top`, `style`, `fillProps`], pe = (e3) => {
  var t2 = e3.className, n2 = e3.prefixCls, r2 = e3.left, i2 = e3.top, a2 = e3.style, o2 = e3.fillProps, s2 = H(e3, fe), c2 = D({}, a2, { position: `absolute`, left: r2, top: i2 }), l2 = D({ width: 18, height: 18, boxShadow: `var(--alpha-pointer-box-shadow)`, borderRadius: `50%`, backgroundColor: `var(--alpha-pointer-background-color)` }, o2 == null ? void 0 : o2.style, { transform: r2 ? `translate(-9px, -1px)` : `translate(-1px, -9px)` });
  return g(`div`, D({ className: n2 + `-pointer ` + (t2 || ``), style: c2 }, s2, { children: g(`div`, D({ className: n2 + `-fill` }, o2, { style: l2 })) }));
};
t();
var me = [`prefixCls`, `className`, `hsva`, `background`, `bgProps`, `innerProps`, `pointerProps`, `radius`, `width`, `height`, `direction`, `reverse`, `style`, `onChange`, `pointer`], he = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAMUlEQVQ4T2NkYGAQYcAP3uCTZhw1gGGYhAGBZIA/nYDCgBDAm9BGDWAAJyRCgLaBCAAgXwixzAS0pgAAAABJRU5ErkJggg==`, G = o.forwardRef((e3, t2) => {
  var r2 = e3.prefixCls, i2 = r2 === void 0 ? `w-color-alpha` : r2, a2 = e3.className, o2 = e3.hsva, s2 = e3.background, c2 = e3.bgProps, l2 = c2 === void 0 ? {} : c2, u2 = e3.innerProps, d2 = u2 === void 0 ? {} : u2, f2 = e3.pointerProps, p2 = f2 === void 0 ? {} : f2, m2 = e3.radius, h2 = m2 === void 0 ? 0 : m2, _2 = e3.width, v2 = e3.height, y2 = v2 === void 0 ? 16 : v2, x2 = e3.direction, S2 = x2 === void 0 ? `horizontal` : x2, C2 = e3.reverse, w2 = C2 !== void 0 && C2, T2 = e3.style, E2 = e3.onChange, O2 = e3.pointer, k2 = H(e3, me), A2 = n((e4) => {
    var t3 = S2 === `horizontal` ? e4.left : e4.top;
    return S2 === `horizontal` ? w2 ? 1 - t3 : t3 : w2 ? t3 : 1 - t3;
  }, [S2, w2]), j2 = n((e4) => S2 === `horizontal` ? w2 ? 1 - e4 : e4 : w2 ? e4 : 1 - e4, [S2, w2]), N2 = (e4) => {
    var t3 = A2(e4);
    E2 && E2(D({}, o2, { a: t3 }), e4);
  }, P2 = M(Object.assign({}, o2, { a: 1 })), F2 = w2 ? `linear-gradient(to right, ` + P2 + ` 0%, rgba(244, 67, 54, 0) 100%)` : `linear-gradient(to right, rgba(244, 67, 54, 0) 0%, ` + P2 + ` 100%)`, I2 = w2 ? `linear-gradient(to bottom, rgba(244, 67, 54, 0) 0%, ` + P2 + ` 100%)` : `linear-gradient(to bottom, ` + P2 + ` 0%, rgba(244, 67, 54, 0) 100%)`, ee2 = S2 === `horizontal` ? F2 : I2, L2 = {};
  S2 === `horizontal` ? L2.left = j2(o2.a) * 100 + `%` : L2.top = j2(o2.a) * 100 + `%`;
  var te2 = D({ "--alpha-background-color": `#fff`, "--alpha-pointer-background-color": `rgb(248, 248, 248)`, "--alpha-pointer-box-shadow": `rgb(0 0 0 / 37%) 0px 1px 4px 0px`, borderRadius: h2, background: `url(` + he + `) left center`, backgroundColor: `var(--alpha-background-color)` }, { width: _2, height: y2 }, T2, { position: `relative` }), R2 = n((e4) => {
    var t3 = 0.01, n2 = o2.a, r3 = n2;
    switch (e4.key) {
      case `ArrowLeft`:
        S2 === `horizontal` && (r3 = w2 ? Math.min(1, n2 + t3) : Math.max(0, n2 - t3), e4.preventDefault());
        break;
      case `ArrowRight`:
        S2 === `horizontal` && (r3 = w2 ? Math.max(0, n2 - t3) : Math.min(1, n2 + t3), e4.preventDefault());
        break;
      case `ArrowUp`:
        S2 === `vertical` && (r3 = w2 ? Math.max(0, n2 - t3) : Math.min(1, n2 + t3), e4.preventDefault());
        break;
      case `ArrowDown`:
        S2 === `vertical` && (r3 = w2 ? Math.min(1, n2 + t3) : Math.max(0, n2 - t3), e4.preventDefault());
        break;
      default:
        return;
    }
    if (r3 !== n2) {
      var i3 = j2(r3), a3 = { left: S2 === `horizontal` ? i3 : o2.a, top: S2 === `vertical` ? i3 : o2.a, width: 0, height: 0, x: 0, y: 0 };
      E2 && E2(D({}, o2, { a: r3 }), a3);
    }
  }, [j2, o2, S2, E2, w2]), ne2 = n((e4) => {
    e4.target.focus();
  }, []), re2 = O2 && typeof O2 == `function` ? O2(D({ prefixCls: i2 }, p2, L2)) : g(pe, D({}, p2, { prefixCls: i2 }, L2));
  return b(`div`, D({}, k2, { className: [i2, i2 + `-` + S2, a2 || ``].filter(Boolean).join(` `), style: te2, ref: t2, children: [g(`div`, D({}, l2, { style: D({ inset: 0, position: `absolute`, background: s2 || ee2, borderRadius: h2 }, l2.style) })), g(W, D({}, d2, { style: D({}, d2.style, { inset: 0, zIndex: 1, position: `absolute`, outline: `none` }), onMove: N2, onDown: N2, onClick: ne2, onKeyDown: R2, children: re2 }))] }));
});
G.displayName = `Alpha`, t();
var ge = [`prefixCls`, `placement`, `label`, `value`, `className`, `style`, `labelStyle`, `inputStyle`, `onChange`, `onBlur`, `renderInput`], _e = (e3) => /^#?([A-Fa-f0-9]{3,4}){1,2}$/.test(e3), ve = (e3) => Number(String(e3).replace(/%/g, ``)), K = o.forwardRef((e3, t2) => {
  var n2 = e3.prefixCls, a2 = n2 === void 0 ? `w-color-editable-input` : n2, o2 = e3.placement, c2 = o2 === void 0 ? `bottom` : o2, l2 = e3.label, u2 = e3.value, d2 = e3.className, f2 = e3.style, p2 = e3.labelStyle, m2 = e3.inputStyle, h2 = e3.onChange, _2 = e3.onBlur, v2 = e3.renderInput, y2 = H(e3, ge), x2 = i(u2), S2 = x2[0], C2 = x2[1], w2 = r(false), T2 = r(y2.id || a2 + `-` + Math.random().toString(36).slice(2, 11)), E2 = y2.id || T2.current;
  s(() => {
    e3.value !== S2 && (w2.current || C2(e3.value));
  }, [e3.value]);
  function O2(e4, t3) {
    var n3 = (t3 || e4.target.value).trim().replace(/^#/, ``);
    _e(n3) && h2 && h2(e4, n3);
    var r2 = ve(n3);
    isNaN(r2) || h2 && h2(e4, r2), C2(n3);
  }
  function k2(t3) {
    w2.current = false, C2(e3.value), _2 && _2(t3);
  }
  var A2 = {};
  c2 === `bottom` && (A2.flexDirection = `column`), c2 === `top` && (A2.flexDirection = `column-reverse`), c2 === `left` && (A2.flexDirection = `row-reverse`);
  var j2 = D({ "--editable-input-label-color": `rgb(153, 153, 153)`, "--editable-input-box-shadow": `rgb(204 204 204) 0px 0px 0px 1px inset`, "--editable-input-color": `#666`, position: `relative`, alignItems: `center`, display: `flex`, fontSize: 11 }, A2, f2), M2 = D({ width: `100%`, paddingTop: 2, paddingBottom: 2, paddingLeft: 3, paddingRight: 3, fontSize: 11, background: `transparent`, boxSizing: `border-box`, border: `none`, color: `var(--editable-input-color)`, boxShadow: `var(--editable-input-box-shadow)` }, m2), N2 = D({ value: S2, onChange: O2, onBlur: k2, autoComplete: `off`, onFocus: () => w2.current = true }, y2, { id: E2, style: M2, onFocusCapture: (e4) => {
    var t3 = e4.target;
    t3.setSelectionRange(t3.value.length, t3.value.length);
  } });
  return b(`div`, { className: [a2, d2 || ``].filter(Boolean).join(` `), style: j2, children: [v2 ? v2(N2, t2) : g(`input`, D({ ref: t2 }, N2)), l2 && g(`label`, { htmlFor: E2, style: D({ color: `var(--editable-input-label-color)`, textTransform: `capitalize` }, p2), children: l2 })] });
});
K.displayName = `EditableInput`, t();
var ye = [`prefixCls`, `className`, `color`, `colors`, `style`, `rectProps`, `onChange`, `addonAfter`, `addonBefore`, `rectRender`], be = o.forwardRef((t2, n2) => {
  var r2 = t2.prefixCls, i2 = r2 === void 0 ? `w-color-swatch` : r2, a2 = t2.className, s2 = t2.color, c2 = t2.colors, l2 = c2 === void 0 ? [] : c2, u2 = t2.style, d2 = t2.rectProps, f2 = d2 === void 0 ? {} : d2, p2 = t2.onChange, m2 = t2.addonAfter, h2 = t2.addonBefore, _2 = t2.rectRender, v2 = H(t2, ye), y2 = D({ "--swatch-background-color": `rgb(144, 19, 254)`, background: `var(--swatch-background-color)`, height: 15, width: 15, marginRight: 5, marginBottom: 5, cursor: `pointer`, position: `relative`, outline: `none`, borderRadius: 2 }, f2.style), x2 = (e3, t3) => {
    p2 && p2(L(e3), B(L(e3)), t3);
  };
  return b(`div`, D({ ref: n2 }, v2, { className: [i2, a2 || ``].filter(Boolean).join(` `), style: D({ display: `flex`, flexWrap: `wrap`, position: `relative` }, u2), children: [h2 && o.isValidElement(h2) && h2, l2 && Array.isArray(l2) && l2.map((t3, n3) => {
    var r3 = ``, i3 = ``;
    typeof t3 == `string` && (r3 = t3, i3 = t3), typeof t3 == `object` && t3.color && (r3 = t3.title || t3.color, i3 = t3.color);
    var a3 = s2 && s2.toLocaleLowerCase() === i3.toLocaleLowerCase(), c3 = _2 && _2({ title: r3, color: i3, checked: !!a3, style: D({}, y2, { background: i3 }), onClick: (e3) => x2(i3, e3) });
    if (c3) return g(e, { children: c3 }, n3);
    var l3 = f2.children && o.isValidElement(f2.children) ? o.cloneElement(f2.children, { color: i3, checked: a3 }) : null;
    return g(`div`, D({ tabIndex: 0, title: r3, onClick: (e3) => x2(i3, e3) }, f2, { children: l3, style: D({}, y2, { background: i3 }) }), n3);
  }), m2 && o.isValidElement(m2) && m2] }));
});
be.displayName = `Swatch`, t();
var xe = (e3) => {
  var t2 = e3.className, n2 = e3.color, r2 = e3.left, i2 = e3.top, o2 = e3.prefixCls, s2 = { position: `absolute`, top: i2, left: r2 }, c2 = { "--saturation-pointer-box-shadow": `rgb(255 255 255) 0px 0px 0px 1.5px, rgb(0 0 0 / 30%) 0px 0px 1px 1px inset, rgb(0 0 0 / 40%) 0px 0px 1px 2px`, width: 6, height: 6, transform: `translate(-3px, -3px)`, boxShadow: `var(--saturation-pointer-box-shadow)`, borderRadius: `50%`, backgroundColor: n2 };
  return a(() => g(`div`, { className: o2 + `-pointer ` + (t2 || ``), style: s2, children: g(`div`, { className: o2 + `-fill`, style: c2 }) }), [i2, r2, n2, t2, o2]);
};
t();
var Se = [`prefixCls`, `radius`, `pointer`, `className`, `hue`, `style`, `hsva`, `onChange`], Ce = o.forwardRef((e3, t2) => {
  var i2 = e3.prefixCls, o2 = i2 === void 0 ? `w-color-saturation` : i2, s2 = e3.radius, c2 = s2 === void 0 ? 0 : s2, l2 = e3.pointer, u2 = e3.className, d2 = e3.hue, f2 = d2 === void 0 ? 0 : d2, p2 = e3.style, m2 = e3.hsva, h2 = e3.onChange, _2 = H(e3, Se), v2 = D({ width: 200, height: 200, borderRadius: c2 }, p2, { position: `relative` }), y2 = r(null), b2 = n((e4) => {
    y2.current = e4, typeof t2 == `function` ? t2(e4) : t2 && `current` in t2 && (t2.current = e4);
  }, [t2]), x2 = n((e4, t3) => {
    h2 && m2 && h2({ h: m2.h, s: e4.left * 100, v: (1 - e4.top) * 100, a: m2.a });
    var n2 = y2.current;
    n2 && n2.focus();
  }, [m2, h2]), S2 = n((e4) => {
    if (m2 && h2) {
      var t3 = 1, n2 = m2.s, r2 = m2.v, i3 = false;
      switch (e4.key) {
        case `ArrowLeft`:
          n2 = Math.max(0, m2.s - t3), i3 = true, e4.preventDefault();
          break;
        case `ArrowRight`:
          n2 = Math.min(100, m2.s + t3), i3 = true, e4.preventDefault();
          break;
        case `ArrowUp`:
          r2 = Math.min(100, m2.v + t3), i3 = true, e4.preventDefault();
          break;
        case `ArrowDown`:
          r2 = Math.max(0, m2.v - t3), i3 = true, e4.preventDefault();
          break;
        default:
          return;
      }
      i3 && h2({ h: m2.h, s: n2, v: r2, a: m2.a });
    }
  }, [m2, h2]), C2 = a(() => {
    if (!m2) return null;
    var e4 = { top: 100 - m2.v + `%`, left: m2.s + `%`, color: M(m2) };
    return l2 && typeof l2 == `function` ? l2(D({ prefixCls: o2 }, e4)) : g(xe, D({ prefixCls: o2 }, e4));
  }, [m2, l2, o2]), w2 = n((e4) => {
    e4.target.focus();
  }, []);
  return g(W, D({ className: [o2, u2 || ``].filter(Boolean).join(` `) }, _2, { style: D({ position: `absolute`, inset: 0, cursor: `crosshair`, backgroundImage: `linear-gradient(0deg, #000, transparent), linear-gradient(90deg, #fff, hsl(` + ((m2 == null ? void 0 : m2.h) ?? f2) + `, 100%, 50%))` }, v2, { outline: `none` }), ref: b2, onMove: x2, onDown: x2, onKeyDown: S2, onClick: w2, children: C2 }));
});
Ce.displayName = `Saturation`, t();
var we = [`prefixCls`, `className`, `hue`, `onChange`, `direction`, `reverse`], Te = `rgb(255, 0, 0) 0%, rgb(255, 255, 0) 17%, rgb(0, 255, 0) 33%, rgb(0, 255, 255) 50%, rgb(0, 0, 255) 67%, rgb(255, 0, 255) 83%, rgb(255, 0, 0) 100%`, Ee = `rgb(255, 0, 0) 0%, rgb(255, 0, 255) 17%, rgb(0, 0, 255) 33%, rgb(0, 255, 255) 50%, rgb(0, 255, 0) 67%, rgb(255, 255, 0) 83%, rgb(255, 0, 0) 100%`, De = o.forwardRef((e3, t2) => {
  var r2 = e3.prefixCls, i2 = r2 === void 0 ? `w-color-hue` : r2, o2 = e3.className, s2 = e3.hue, c2 = s2 === void 0 ? 0 : s2, l2 = e3.onChange, u2 = e3.direction, d2 = u2 === void 0 ? `horizontal` : u2, f2 = e3.reverse, p2 = f2 !== void 0 && f2, m2 = H(e3, we), h2 = n(() => d2 === `horizontal` ? `linear-gradient(to right, ` + (p2 ? Ee : Te) + `)` : `linear-gradient(to bottom, ` + (p2 ? Te : Ee) + `)`, [d2, p2]), _2 = n((e4) => {
    var t3 = d2 === `horizontal` ? e4.left : e4.top;
    return 360 * (d2 === `horizontal` ? p2 ? 1 - t3 : t3 : p2 ? t3 : 1 - t3);
  }, [d2, p2]), v2 = a(() => h2(), [h2]);
  return g(G, D({ ref: t2, className: i2 + ` ` + (o2 || ``) }, m2, { direction: d2, reverse: p2, background: v2, hsva: { h: c2, s: 100, v: 100, a: c2 / 360 }, onChange: (e4, t3) => {
    l2 && l2({ h: _2(t3) });
  } }));
});
De.displayName = `Hue`, t();
var Oe = [`prefixCls`, `hsva`, `placement`, `rProps`, `gProps`, `bProps`, `aProps`, `className`, `style`, `onChange`], ke = o.forwardRef((e3, t2) => {
  var n2 = e3.prefixCls, r2 = n2 === void 0 ? `w-color-editable-input-rgba` : n2, i2 = e3.hsva, a2 = e3.placement, o2 = a2 === void 0 ? `bottom` : a2, s2 = e3.rProps, c2 = s2 === void 0 ? {} : s2, l2 = e3.gProps, u2 = l2 === void 0 ? {} : l2, d2 = e3.bProps, f2 = d2 === void 0 ? {} : d2, p2 = e3.aProps, m2 = p2 === void 0 ? {} : p2, h2 = e3.className, _2 = e3.style, v2 = e3.onChange, y2 = H(e3, Oe), x2 = i2 ? R(i2) : {};
  function S2(e4) {
    var t3 = Number(e4.target.value);
    t3 && t3 > 255 && (e4.target.value = `255`), t3 && t3 < 0 && (e4.target.value = `0`);
  }
  var C2 = (e4) => {
    var t3 = Number(e4.target.value);
    t3 && t3 > 100 && (e4.target.value = `100`), t3 && t3 < 0 && (e4.target.value = `0`);
  }, w2 = (e4, t3, n3) => {
    typeof e4 == `number` && (t3 === `a` && (e4 < 0 && (e4 = 0), e4 > 100 && (e4 = 100), v2 && v2(B(j(D({}, x2, { a: e4 / 100 }))))), e4 > 255 && (e4 = 255, n3.target.value = `255`), e4 < 0 && (e4 = 0, n3.target.value = `0`), t3 === `r` && v2 && v2(B(j(D({}, x2, { r: e4 })))), t3 === `g` && v2 && v2(B(j(D({}, x2, { g: e4 })))), t3 === `b` && v2 && v2(B(j(D({}, x2, { b: e4 })))));
  }, T2 = x2.a ? Math.round(x2.a * 100) / 100 : 0;
  return b(`div`, D({ ref: t2, className: [r2, h2 || ``].filter(Boolean).join(` `) }, y2, { style: D({ fontSize: 11, display: `flex` }, _2), children: [g(K, D({ label: `R`, value: x2.r || 0, onBlur: S2, placement: o2, onChange: (e4, t3) => w2(t3, `r`, e4) }, c2, { style: D({}, c2.style) })), g(K, D({ label: `G`, value: x2.g || 0, onBlur: S2, placement: o2, onChange: (e4, t3) => w2(t3, `g`, e4) }, u2, { style: D({ marginLeft: 5 }, u2.style) })), g(K, D({ label: `B`, value: x2.b || 0, onBlur: S2, placement: o2, onChange: (e4, t3) => w2(t3, `b`, e4) }, f2, { style: D({ marginLeft: 5 }, f2.style) })), m2 && g(K, D({ label: `A`, value: parseInt(String(T2 * 100), 10), onBlur: C2, placement: o2, onChange: (e4, t3) => w2(t3, `a`, e4) }, m2, { style: D({ marginLeft: 5 }, m2.style) }))] }));
});
ke.displayName = `EditableInputRGBA`, t();
var Ae = [`prefixCls`, `className`, `onChange`, `direction`, `hsva`], q = o.forwardRef((e3, t2) => {
  var n2 = e3.prefixCls, r2 = n2 === void 0 ? `w-color-saturation` : n2, i2 = e3.className, a2 = e3.onChange, o2 = e3.direction, s2 = o2 === void 0 ? `horizontal` : o2, c2 = e3.hsva, l2 = H(e3, Ae), u2 = M(D({}, c2, { a: 1, v: 100 }));
  return g(G, D({ ref: t2 }, l2, { className: r2 + ` ` + (i2 || ``), hsva: { h: c2.h, s: c2.s, v: c2.v, a: 1 - c2.v / 100 }, direction: s2, background: `linear-gradient(to ` + (s2 === `horizontal` ? `right` : `bottom`) + `, ` + u2 + `, rgb(0, 0, 0))`, onChange: (e4, t3) => {
    a2 && a2({ v: s2 === `horizontal` ? 100 - t3.left * 100 : 100 - t3.top * 100 });
  } }));
});
q.displayName = `ShadeSlider`, t();
var je = [`prefixCls`, `className`, `onChange`, `width`, `presetColors`, `color`, `editableDisable`, `disableAlpha`, `style`], Me = [`#D0021B`, `#F5A623`, `#f8e61b`, `#8B572A`, `#7ED321`, `#417505`, `#BD10E0`, `#9013FE`, `#4A90E2`, `#50E3C2`, `#B8E986`, `#000000`, `#4A4A4A`, `#9B9B9B`, `#FFFFFF`], Ne = (e3) => g(`div`, { style: { boxShadow: `rgb(0 0 0 / 60%) 0px 0px 2px`, width: 4, top: 1, bottom: 1, left: e3.left, borderRadius: 1, position: `absolute`, backgroundColor: `#fff` } }), J = o.forwardRef((t2, n2) => {
  var r2 = t2.prefixCls, a2 = r2 === void 0 ? `w-color-sketch` : r2, o2 = t2.className, c2 = t2.onChange, l2 = t2.width, u2 = l2 === void 0 ? 218 : l2, d2 = t2.presetColors, f2 = d2 === void 0 ? Me : d2, p2 = t2.color, m2 = t2.editableDisable, h2 = m2 === void 0 || m2, _2 = t2.disableAlpha, v2 = _2 !== void 0 && _2, y2 = t2.style, x2 = H(t2, je), S2 = i({ h: 209, s: 36, v: 90, a: 1 }), C2 = S2[0], w2 = S2[1];
  s(() => {
    typeof p2 == `string` && V(p2) && w2(L(p2)), typeof p2 == `object` && w2(p2);
  }, [p2]);
  var T2 = (e3) => {
    w2(e3), c2 && c2(B(e3));
  }, E2 = (e3, t3) => {
    typeof e3 == `string` && V(e3) && /(3|6)/.test(String(e3.length)) && T2(L(e3));
  }, O2 = (e3) => T2(D({}, C2, { a: e3.a })), k2 = (e3) => T2(D({}, C2, e3, { a: C2.a })), A2 = D({ "--sketch-background": `rgb(255, 255, 255)`, "--sketch-box-shadow": `rgb(0 0 0 / 15%) 0px 0px 0px 1px, rgb(0 0 0 / 15%) 0px 8px 16px`, "--sketch-swatch-box-shadow": `rgb(0 0 0 / 15%) 0px 0px 0px 1px inset`, "--sketch-alpha-box-shadow": `rgb(0 0 0 / 15%) 0px 0px 0px 1px inset, rgb(0 0 0 / 25%) 0px 0px 4px inset`, "--sketch-swatch-border-top": `1px solid rgb(238, 238, 238)`, background: `var(--sketch-background)`, borderRadius: 4, boxShadow: `var(--sketch-box-shadow)`, width: u2 }, y2), j2 = { borderRadius: 2, background: ne(C2), boxShadow: `var(--sketch-alpha-box-shadow)` };
  return b(`div`, D({}, x2, { className: a2 + ` ` + (o2 || ``), ref: n2, style: A2, children: [b(`div`, { style: { padding: `10px 10px 8px` }, children: [g(Ce, { hsva: C2, style: { width: `auto`, height: 150 }, onChange: k2 }), b(`div`, { style: { display: `flex`, marginTop: 4 }, children: [b(`div`, { style: { flex: 1 }, children: [g(De, { width: `auto`, height: 10, hue: C2.h, pointer: Ne, innerProps: { style: { marginLeft: 1, marginRight: 5 } }, onChange: (e3) => T2(D({}, C2, e3)) }), !v2 && g(G, { width: `auto`, height: 10, hsva: C2, pointer: Ne, style: { marginTop: 4 }, innerProps: { style: { marginLeft: 1, marginRight: 5 } }, onChange: O2 })] }), !v2 && g(G, { width: 24, height: 24, hsva: C2, radius: 2, style: { marginLeft: 4 }, bgProps: { style: { background: `transparent` } }, innerProps: { style: j2 }, pointer: () => g(e, {}) })] })] }), h2 && b(`div`, { style: { display: `flex`, margin: `0 10px 3px 10px` }, children: [g(K, { label: `Hex`, value: z(C2).replace(/^#/, ``).toLocaleUpperCase(), onChange: (e3, t3) => E2(t3, e3), style: { minWidth: 58 } }), g(ke, { hsva: C2, style: { marginLeft: 6 }, aProps: !v2 && {}, onChange: (e3) => T2(e3.hsva) })] }), f2 && f2.length > 0 && g(be, { style: { borderTop: `var(--sketch-swatch-border-top)`, paddingTop: 10, paddingLeft: 10 }, colors: f2, color: z(C2), onChange: (e3) => T2(e3), rectProps: { style: { marginRight: 10, marginBottom: 10, borderRadius: 3, boxShadow: `var(--sketch-swatch-box-shadow)` } } })] }));
});
J.displayName = `Sketch`, t();
var Pe = `rgb(255 255 255) 0px 0px 0px 1.5px, rgb(0 0 0 / 30%) 0px 0px 1px 1px inset, rgb(0 0 0 / 40%) 0px 0px 1px 2px`, Fe = (e3) => {
  var t2 = e3.className, n2 = e3.color, r2 = e3.left, i2 = e3.top, a2 = e3.style, o2 = e3.prefixCls, s2 = D({}, a2, { position: `absolute`, top: i2, left: r2 }), c2 = o2 + `-pointer ` + (t2 || ``);
  return g(`div`, { className: c2, style: s2, children: g(`div`, { className: o2 + `-fill`, style: { width: 10, height: 10, transform: `translate(-5px, -5px)`, boxShadow: Pe, borderRadius: `50%`, backgroundColor: `#fff` }, children: g(`div`, { style: { inset: 0, borderRadius: `50%`, position: `absolute`, backgroundColor: n2 } }) }) });
}, Ie = Math.PI * 2, Le = (e3, t2) => (e3 % t2 + t2) % t2, Re = (e3, t2) => Math.sqrt(e3 * e3 + t2 * t2);
function ze(e3) {
  var t2 = e3.width, n2 = t2 === void 0 ? 0 : t2, r2 = n2 / 2;
  return { width: n2, radius: r2, cx: r2, cy: r2 };
}
function Be(e3, t2) {
  var n2 = ze(e3), r2 = n2.cx, i2 = n2.cy, a2 = Ve(e3), o2 = (180 + He(e3, t2.h, true)) * (Ie / 360), s2 = t2.s / 100 * a2, c2 = e3.direction === `clockwise` ? -1 : 1;
  return { x: r2 + s2 * Math.cos(o2) * c2, y: i2 + s2 * Math.sin(o2) * c2 };
}
function Ve(e3) {
  var t2 = e3.width;
  return (t2 === void 0 ? 0 : t2) / 2;
}
function He(e3, t2, n2) {
  var r2 = e3.angle || 0, i2 = e3.direction;
  return n2 && i2 === `clockwise` ? t2 = r2 + t2 : i2 === `clockwise` ? t2 = 360 - r2 + t2 : n2 && i2 === `anticlockwise` ? t2 = r2 + 180 - t2 : i2 === `anticlockwise` && (t2 = r2 - t2), Le(t2, 360);
}
function Ue(e3, t2, n2) {
  var r2 = ze(e3), i2 = r2.cx, a2 = r2.cy, o2 = Ve(e3);
  t2 = i2 - t2, n2 = a2 - n2;
  var s2 = He(e3, Math.atan2(-n2, -t2) * (360 / Ie)), c2 = Math.min(Re(t2, n2), o2);
  return { h: Math.round(s2), s: Math.round(100 / o2 * c2) };
}
t();
var We = [`prefixCls`, `radius`, `pointer`, `className`, `style`, `width`, `height`, `oval`, `direction`, `angle`, `color`, `onChange`], Ge = `conic-gradient(red, yellow, lime, aqua, blue, magenta, red)`, Ke = `conic-gradient(red, magenta, blue, aqua, lime, yellow, red)`, Y = o.forwardRef((e3, t2) => {
  var n2 = e3.prefixCls, r2 = n2 === void 0 ? `w-color-wheel` : n2;
  e3.radius;
  var i2 = e3.pointer, a2 = e3.className, o2 = e3.style, s2 = e3.width, c2 = s2 === void 0 ? 200 : s2, l2 = e3.height, u2 = l2 === void 0 ? 200 : l2, d2 = e3.oval, f2 = e3.direction, p2 = f2 === void 0 ? `anticlockwise` : f2, m2 = e3.angle, h2 = m2 === void 0 ? 180 : m2, _2 = e3.color, v2 = e3.onChange, y2 = H(e3, We), x2 = typeof _2 == `string` && V(_2) ? L(_2) : _2 || {}, S2 = _2 ? z(x2) : ``, C2 = { width: c2, direction: p2, angle: h2 }, w2 = Be(C2, x2), T2 = { top: `0`, left: `0`, color: S2 }, E2 = (e4, t3) => {
    var n3 = Ue(C2, e4.x, e4.y), r3 = { h: n3.h, s: n3.s, v: x2.v, a: x2.a };
    v2 && v2(B(r3));
  }, O2 = { zIndex: 1, position: `absolute`, transform: `translate(` + w2.x + `px, ` + w2.y + `px) ` + (d2 === `x` || d2 === `X` ? `scaleY(2)` : d2 === `y` || d2 === `Y` ? `scaleX(2)` : ``) }, k2 = i2 && typeof i2 == `function` ? i2(D({ prefixCls: r2, style: O2 }, T2)) : g(Fe, D({ prefixCls: r2, style: O2 }, T2));
  return b(W, D({ className: [r2, a2 || ``].filter(Boolean).join(` `) }, y2, { style: D({ position: `relative`, width: c2, transform: d2 === `x` || d2 === `X` ? `scaleY(0.5)` : d2 === `y` || d2 === `Y` ? `scaleX(0.5)` : ``, height: u2 }, o2), ref: t2, onMove: E2, onDown: E2, children: [k2, g(`div`, { style: { position: `absolute`, borderRadius: `50%`, background: p2 === `anticlockwise` ? Ke : Ge, transform: `rotateZ(` + (90 - h2) + `deg)`, inset: 0 } }), g(`div`, { style: { position: `absolute`, borderRadius: `50%`, background: `radial-gradient(circle closest-side, #fff, transparent)`, inset: 0 } }), g(`div`, { style: { backgroundColor: `#000`, borderRadius: `50%`, position: `absolute`, inset: 0, opacity: typeof x2.v == `number` ? 1 - x2.v / 100 : 0 } })] }));
});
Y.displayName = `Wheel`, t();
function qe(e3) {
  return b(`svg`, { viewBox: `0 0 24 24`, style: e3.style, xmlns: `http://www.w3.org/2000/svg`, children: [g(`path`, { stroke: `currentColor`, fill: `none`, "stroke-width": `2`, "stroke-linecap": `round`, "stroke-linejoin": `round`, d: `M3 3m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z` }), g(`path`, { stroke: `currentColor`, fill: `none`, "stroke-width": `2`, "stroke-linecap": `round`, "stroke-linejoin": `round`, d: `M9 8l1 8l2 -5l2 5l1 -8` })] });
}
t();
var X = { rgbDialog: { maxWidth: 400 }, rgbSliderContainer: { display: `flex`, alignItems: `center`, gap: 12, width: `100%` }, rgbDialogContainer: { display: `flex`, flexDirection: `column`, gap: 12, width: `calc(100% - 20px)` }, rgbWheel: { display: `flex`, justifyContent: `center` }, rgbContent: { width: `100%`, height: `100%`, flex: 1, display: `flex`, justifyContent: `center`, overflow: `hidden`, alignItems: `center` }, tooltip: { pointerEvents: `none` } }, Z = { "switch.light": `switch`, switch: `switch`, "level.brightness": `brightness`, "level.dimmer": `brightness`, "level.color.red": `red`, "level.color.green": `green`, "level.color.blue": `blue`, "level.color.white": `white`, "level.color.rgb": `rgb`, "level.color.hue": `hue`, "level.color.saturation": `saturation`, "level.color.luminance": `luminance`, "level.color.temperature": `color_temperature` };
function Je(e3, t2, n2) {
  return e3 < t2 ? t2 : e3 > n2 ? n2 : e3;
}
var Q = (e3) => {
  let t2 = e3 / 100, n2, r2, i2;
  return t2 <= 66 ? (n2 = 255, r2 = t2, r2 = 99.4708025861 * Math.log(r2) - 161.1195681661, t2 <= 19 ? i2 = 0 : (i2 = t2 - 10, i2 = 138.5177312231 * Math.log(i2) - 305.0447927307)) : (n2 = t2 - 60, n2 = 329.698727446 * n2 ** -0.1332047592, r2 = t2 - 60, r2 = 288.1221695283 * r2 ** -0.0755148492, i2 = 255), { red: Je(n2, 0, 255), green: Je(r2, 0, 255), blue: Je(i2, 0, 255) };
}, $ = async (e3, t2, n2, r2) => {
  var _a;
  if (t2[e3.name] && ((_a = await r2.getObject(t2[e3.name])) == null ? void 0 : _a.common)) {
    let i2 = t2[e3.name].split(`.`);
    i2.pop();
    let a2 = await r2.getObjectViewSystem(`state`, `${i2.join(`.`)}.`, `${i2.join(`.`)}.\u9999`);
    a2 && (Object.values(a2).forEach((e4) => {
      var _a2;
      let n3 = (_a2 = e4.common) == null ? void 0 : _a2.role;
      if (n3 && Z[n3] && (!t2[n3] || t2[n3] === `nothing_selected`) && (t2[Z[n3]] = e4._id, Z[n3] === `color_temperature`)) {
        let n4 = e4.common;
        !t2.ct_min && n4.min && (t2.ct_min = n4.min), !t2.ct_max && n4.max && (t2.ct_max = n4.max);
      }
    }), n2(t2));
  }
}, Ye = [`switch`, `brightness`, `rgb`, `red`, `green`, `blue`, `white`, `color_temperature`, `hue`, `saturation`, `luminance`, `white_mode`], Xe = class e2 extends w {
  contentRef = o.createRef();
  timeouts = {};
  _pressTimeout = null;
  constructor(e3) {
    super(e3), this.state = { ...this.state, dialog: false, rgbObjects: {}, colorTemperatures: [], sketch: false, controlValue: null };
  }
  static getWidgetInfo() {
    return { id: `tplNils2RGBLight`, visSet: `vis-2-widgets-nils-fork`, visName: `RGBLight`, visWidgetLabel: `rgb_light`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox`, hidden: `!!data.externalDialog` }, { name: `fullSize`, label: `fullSize`, type: `checkbox`, hidden: `!!data.externalDialog` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard` }, { name: `icon`, type: `icon64`, label: `icon`, default: `data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iY3VycmVudENvbG9yIj4NCiAgICA8cGF0aCBkPSJNMTIgM2MtNC45NyAwLTkgNC4wMy05IDlzNC4wMyA5IDkgOWMuODMgMCAxLjUtLjY3IDEuNS0xLjUgMC0uMzktLjE1LS43NC0uMzktMS4wMS0uMjMtLjI2LS4zOC0uNjEtLjM4LS45OSAwLS44My42Ny0xLjUgMS41LTEuNUgxNmMyLjc2IDAgNS0yLjI0IDUtNSAwLTQuNDItNC4wMy04LTktOHptLTUuNSA5Yy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTNS42NyA5IDYuNSA5IDggOS42NyA4IDEwLjUgNy4zMyAxMiA2LjUgMTJ6bTMtNEM4LjY3IDggOCA3LjMzIDggNi41UzguNjcgNSA5LjUgNXMxLjUuNjcgMS41IDEuNVMxMC4zMyA4IDkuNSA4em01IDBjLS44MyAwLTEuNS0uNjctMS41LTEuNVMxMy42NyA1IDE0LjUgNXMxLjUuNjcgMS41IDEuNVMxNS4zMyA4IDE0LjUgOHptMyA0Yy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTMTYuNjcgOSAxNy41IDlzMS41LjY3IDEuNSAxLjUtLjY3IDEuNS0xLjUgMS41eiIvPg0KPC9zdmc+DQo=`, hidden: `!!data.externalDialog` }, { name: `switch`, type: `id`, label: `switch`, onChange: $ }, { name: `brightness`, type: `id`, label: `brightness`, onChange: $ }, { name: `rgbType`, label: `type`, type: `select`, noTranslation: true, options: [`rgb`, `rgbw`, `r/g/b`, `r/g/b/w`, `hue/sat/lum`, `ct`], onChange: $ }, { name: `rgb`, type: `id`, label: `rgb`, hidden: (e3) => e3.rgbType !== `rgb` && e3.rgbType !== `rgbw`, onChange: $ }, { name: `red`, type: `id`, label: `red`, hidden: (e3) => e3.rgbType !== `r/g/b` && e3.rgbType !== `r/g/b/w`, onChange: $ }, { name: `green`, type: `id`, label: `green`, hidden: (e3) => e3.rgbType !== `r/g/b` && e3.rgbType !== `r/g/b/w`, onChange: $ }, { name: `blue`, type: `id`, label: `blue`, hidden: (e3) => e3.rgbType !== `r/g/b` && e3.rgbType !== `r/g/b/w`, onChange: $ }, { name: `white`, type: `id`, label: `white`, hidden: (e3) => e3.rgbType !== `r/g/b/w` && e3.rgbType !== `rgbw`, onChange: $ }, { name: `color_temperature`, type: `id`, label: `color_temperature`, hidden: (e3) => e3.rgbType !== `ct`, onChange: $ }, { name: `ct_min`, type: `number`, min: 500, max: 1e4, label: `color_temperature_min`, hidden: (e3) => e3.rgbType !== `ct` || !e3.color_temperature }, { name: `ct_max`, type: `number`, min: 500, max: 1e4, label: `color_temperature_max`, hidden: (e3) => e3.rgbType !== `ct` || !e3.color_temperature }, { name: `hue`, type: `id`, label: `hue`, hidden: (e3) => e3.rgbType !== `hue/sat/lum`, onChange: $ }, { name: `saturation`, type: `id`, label: `saturation`, hidden: (e3) => e3.rgbType !== `hue/sat/lum`, onChange: $ }, { name: `luminance`, type: `id`, label: `luminance`, hidden: (e3) => e3.rgbType !== `hue/sat/lum`, onChange: $ }, { name: `hideBrightness`, type: `checkbox`, label: `hideBrightness`, hidden: (e3) => e3.rgbType !== `rgb` && e3.rgbType !== `rgbw` && e3.rgbType !== `r/g/b` && e3.rgbType !== `r/g/b/w`, onChange: $ }, { name: `white_mode`, type: `id`, label: `whiteMode`, tooltip: `whiteModeTooltip`, hidden: (e3) => e3.rgbType !== `rgbw` && e3.rgbType !== `r/g/b/w`, onChange: $ }, { name: `noRgbPalette`, type: `checkbox`, label: `noRgbPalette`, hidden: (e3) => e3.rgbType !== `rgb` && e3.rgbType !== `rgbw` && e3.rgbType !== `r/g/b` && e3.rgbType !== `r/g/b/w`, onChange: $ }, { name: `timeout`, label: `controlTimeout`, tooltip: `In milliseconds`, type: `number`, min: 0, max: 2e3 }, { name: `toggleOnClick`, label: `toggleOnClick`, type: `checkbox`, hidden: `!data.switch` }, { label: `pressDuration`, name: `pressDuration`, tooltip: `pressDuration_tooltip`, type: `slider`, min: 100, max: 3e3, hidden: `!data.toggleOnClick || !data.switch` }, { label: `borderRadius`, name: `borderRadius`, type: `slider`, min: 0, max: 100, hidden: `!data.noCard` }, { name: `color`, type: `color`, label: `color` }, { name: `colorEnabled`, type: `color`, label: `color_active` }, { name: `onlyCircle`, label: `onlyCircle`, type: `checkbox` }, { name: `externalDialog`, label: `use_as_dialog`, type: `checkbox`, tooltip: `use_as_dialog_tooltip` }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_rgb_light.png` };
  }
  async componentDidMount() {
    super.componentDidMount(), await this.rgbReadObjects();
  }
  componentWillUnmount() {
    super.componentWillUnmount(), this.rgbDestroy();
  }
  async onRxDataChanged() {
    await this.rgbReadObjects();
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  rgbGetIdMin = (e3) => {
    var _a, _b, _c, _d;
    return e3 === `color_temperature` ? this.state.rxData.ct_min || ((_b = (_a = this.state.rgbObjects[e3]) == null ? void 0 : _a.common) == null ? void 0 : _b.min) || 0 : ((_d = (_c = this.state.rgbObjects[e3]) == null ? void 0 : _c.common) == null ? void 0 : _d.min) || 0;
  };
  rgbGetIdMax = (e3) => {
    var _a, _b, _c, _d;
    return e3 === `color_temperature` ? this.state.rxData.ct_max || ((_b = (_a = this.state.rgbObjects[e3]) == null ? void 0 : _a.common) == null ? void 0 : _b.max) || 0 : ((_d = (_c = this.state.rgbObjects[e3]) == null ? void 0 : _c.common) == null ? void 0 : _d.max) || 0;
  };
  rgbSetId = (e3, t2) => {
    var _a;
    this.state.rgbObjects[e3] && (this.timeouts[e3] && (clearTimeout(this.timeouts[e3]), this.timeouts[e3] = null), e3 === `switch` || e3 === `white_mode` ? this.props.context.setValue(this.state.rxData[e3], t2) : this.setState({ controlValue: { id: e3, value: t2, changed: !!((_a = this.state.controlValue) == null ? void 0 : _a.changed) } }, () => {
      this.timeouts[e3] = setTimeout(() => {
        this.timeouts[e3] = null, this.props.context.setValue(this.state.rxData[e3], t2);
      }, parseInt(this.state.rxData.timeout, 10) || 200);
    }));
  };
  async rgbReadObjects() {
    var _a, _b, _c, _d;
    let e3 = {}, t2 = [];
    for (let e4 of Ye) this.state.rxData[e4] && this.state.rxData[e4] !== `nothing_selected` && t2.push(this.state.rxData[e4]);
    let n2 = await this.props.context.socket.getObjectsById(t2), r2 = {};
    for (let t3 of Ye) if (this.state.rxData[t3]) {
      let r3 = n2[this.state.rxData[t3]];
      r3 && (e3[t3] = r3);
    }
    if (r2.rgbObjects = e3, e3.color_temperature) {
      let t3 = [], n3 = parseInt(this.state.rxData.ct_min || ((_b = (_a = e3.color_temperature) == null ? void 0 : _a.common) == null ? void 0 : _b.min), 10) || 2700, i2 = parseInt(this.state.rxData.ct_max || ((_d = (_c = e3.color_temperature) == null ? void 0 : _c.common) == null ? void 0 : _d.max), 10) || 6e3;
      if (i2 < n3) {
        let e4 = i2;
        i2 = n3, n3 = e4;
      }
      let a2 = (i2 - n3) / 20;
      if (a2) for (let e4 = n3; e4 <= i2; e4 += a2) t3.push(Q(e4));
      r2.colorTemperatures = t3;
    } else r2.colorTemperatures = [];
    this.setState(r2);
  }
  rgbDestroy() {
    for (let e3 in this.timeouts) this.timeouts[e3] && (clearTimeout(this.timeouts[e3]), this.timeouts[e3] = null);
  }
  rgbIsOnlyHue = () => this.state.rxData.rgbType === `hue/sat/lum` && (!this.state.rgbObjects.saturation || !this.state.rgbObjects.luminance);
  rgbGetWheelColor = () => {
    let e3 = { h: 0, s: 0, v: 0, a: 1 };
    if (this.state.rxData.rgbType === `hue/sat/lum`) e3 = N({ h: this.getPropertyValue(`hue`), s: this.rgbIsOnlyHue() ? 100 : this.getPropertyValue(`saturation`), l: this.rgbIsOnlyHue() ? 50 : this.getPropertyValue(`luminance`), a: 1 });
    else if (this.state.rxData.rgbType === `r/g/b` || this.state.rxData.rgbType === `r/g/b/w`) e3 = j({ r: this.getPropertyValue(`red`), g: this.getPropertyValue(`green`), b: this.getPropertyValue(`blue`), a: 1 });
    else if (this.state.rxData.rgbType === `rgb`) try {
      let t2 = this.getPropertyValue(`rgb`) || ``;
      e3 = t2 && t2.length >= 4 ? L(t2) : L(`#000000`);
    } catch (e4) {
      console.error(e4);
    }
    else if (this.state.rxData.rgbType === `rgbw`) try {
      let t2 = this.getPropertyValue(`rgb`) || ``;
      e3 = t2 && t2.length >= 4 ? L(t2) : L(`#000000`);
    } catch (e4) {
      console.error(e4);
    }
    return this.state.rxData.hideBrightness && (e3.v = 100), e3;
  };
  rgbSetWheelColor = (e3) => {
    if (this.state.rxData.rgbType === `hue/sat/lum`) {
      let t2 = P(e3);
      this.rgbSetId(`hue`, e3.h), this.rgbIsOnlyHue() || (this.rgbSetId(`saturation`, t2.s), this.rgbSetId(`luminance`, t2.l));
    } else if (this.state.rxData.rgbType === `r/g/b` || this.state.rxData.rgbType === `r/g/b/w`) {
      let t2 = R(e3);
      this.rgbSetId(`red`, t2.r), this.rgbSetId(`green`, t2.g), this.rgbSetId(`blue`, t2.b);
    } else if (this.state.rxData.rgbType === `rgb`) this.rgbSetId(`rgb`, z(e3));
    else if (this.state.rxData.rgbType === `rgbw`) {
      if (this.state.rgbObjects.white) this.rgbSetId(`rgb`, z(e3));
      else {
        let t2 = this.getPropertyValue(`rgb`) || `#00000000`;
        t2 = z(e3) + t2.substring(7), this.rgbSetId(`rgb`, t2);
      }
    }
  };
  rgbGetWhite = () => {
    var _a;
    if (this.state.rxData.rgbType === `r/g/b/w`) return this.getPropertyValue(`white`);
    if (this.state.rxData.rgbType === `rgbw`) {
      if (this.state.rgbObjects.white) return this.getPropertyValue(`white`);
      let e3 = (_a = this.getPropertyValue(`rgb`)) == null ? void 0 : _a.substring(7);
      return parseInt(e3, 16);
    }
    return 0;
  };
  rgbGetWhiteId = () => this.state.rxData.rgbType === `r/g/b/w` ? `white` : this.state.rxData.rgbType === `rgbw` ? this.state.rgbObjects.white ? `white` : `rgb` : ``;
  rgbSetWhite = (e3) => {
    if (this.state.rxData.rgbType === `r/g/b/w`) this.rgbSetId(`white`, e3);
    else if (this.state.rxData.rgbType === `rgbw`) {
      if (this.state.rgbObjects.white) this.rgbSetId(`white`, e3);
      else {
        let t2 = this.getPropertyValue(`rgb`) || `#00000000`;
        t2 = t2.substring(0, 7) + e3.toString(16).padStart(2, `0`), this.rgbSetId(`rgb`, t2);
      }
    }
  };
  rgbSetWhiteMode = (e3) => {
    this.state.rxData.white_mode && this.rgbSetId(`white_mode`, e3);
  };
  rgbGetWhiteMode = () => {
    if (this.state.rxData.white_mode) return this.getPropertyValue(`white_mode`);
  };
  rgbIsRgb = () => (this.state.rxData.rgbType === `rgb` || this.state.rxData.rgbType === `rgbw`) && this.state.rxData.rgb ? true : !!((this.state.rxData.rgbType === `r/g/b` || this.state.rxData.rgbType === `r/g/b/w`) && this.state.rgbObjects.red && this.state.rgbObjects.green && this.state.rgbObjects.blue);
  rgbIsWhite = () => !!(this.state.rxData.rgbType === `rgbw` && this.state.rxData.rgb || this.state.rxData.rgbType === `r/g/b/w` && this.state.rgbObjects.white);
  rgbIsHSL = () => this.state.rxData.rgbType === `hue/sat/lum` && !!this.state.rgbObjects.hue;
  rgbRenderSwitch() {
    return this.state.rgbObjects.switch && b(`div`, { style: { ...X.rgbSliderContainer, justifyContent: `center` }, children: [w.t(`Off`), g(_, { checked: this.getPropertyValue(`switch`) || false, onChange: (e3) => this.rgbSetId(`switch`, e3.target.checked) }), w.t(`On`)] });
  }
  onStateUpdated(e3) {
    var _a;
    ((_a = this.state.controlValue) == null ? void 0 : _a.id) && this.state.rxData[this.state.controlValue.id] === e3 && this.setState({ controlValue: { id: this.state.controlValue.id, value: this.state.controlValue.value, changed: true } });
  }
  finishChanging() {
    if (this.state.controlValue) {
      let e3 = { controlValue: null };
      if (!this.state.controlValue.changed && this.state.controlValue.id) {
        let t2 = JSON.parse(JSON.stringify(this.state.values));
        t2[`${this.state.rxData[this.state.controlValue.id]}.val`] = this.state.controlValue.value, e3.values = t2;
      }
      this.setState(e3);
    }
  }
  rgbRenderBrightness() {
    var _a;
    return this.state.rgbObjects.brightness && b(`div`, { style: X.rgbSliderContainer, children: [g(m, { title: w.t(`Brightness`), slotProps: { popper: { sx: X.tooltip } }, children: g(y, {}) }), g(p, { min: this.rgbGetIdMin(`brightness`) || 0, max: this.rgbGetIdMax(`brightness`) || 100, valueLabelDisplay: `auto`, value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === `brightness` ? this.state.controlValue.value : this.getPropertyValue(`brightness`) || 0, onChange: (e3, t2) => this.rgbSetId(`brightness`, t2), onChangeCommitted: () => this.finishChanging() })] });
  }
  rgbRenderSketch() {
    return g(`div`, { className: `dark`, style: X.rgbWheel, children: g(J, { color: this.rgbGetWheelColor(), disableAlpha: true, onChange: (e3) => this.rgbSetWheelColor(e3.hsva) }) });
  }
  rgbRenderWheelTypeSwitch(e3, t2, n2) {
    return !e3 || n2 === null && this.state.rxData.noRgbPalette ? null : !this.rgbIsOnlyHue() && b(`div`, { style: { textAlign: t2 ? `right` : void 0 }, children: [n2 === null ? null : g(m, { title: w.t(`Switch white mode`), slotProps: { popper: { sx: X.tooltip } }, children: g(l, { onClick: () => this.rgbSetWhiteMode(!n2), color: n2 ? `primary` : `default`, children: g(E, {}) }) }), !this.state.rxData.noRgbPalette && n2 !== true ? g(m, { title: w.t(`Switch color picker`), slotProps: { popper: { sx: X.tooltip } }, children: g(l, { onClick: () => this.setState({ sketch: !this.state.sketch }), children: g(T, {}) }) }) : null] });
  }
  rgbRenderBrightnessSlider(e3, t2) {
    return !e3 || this.state.sketch || this.state.rxData.hideBrightness || t2 === true ? null : !this.rgbIsOnlyHue() && g(q, { hsva: this.rgbGetWheelColor(), onChange: (e4) => this.rgbSetWheelColor({ ...this.rgbGetWheelColor(), ...e4 }) });
  }
  rgbRenderWheel(e3, t2) {
    return !e3 || t2 === true ? null : this.state.sketch ? this.rgbRenderSketch() : g(`div`, { style: X.rgbWheel, children: g(Y, { color: this.rgbGetWheelColor(), onChange: (e4) => {
      e4 = JSON.parse(JSON.stringify(e4)), this.rgbSetWheelColor(e4.hsva);
    } }) });
  }
  rgbRenderWhite() {
    var _a;
    if (!this.rgbIsWhite()) return null;
    let e3, t2;
    return this.state.rgbObjects.white ? (e3 = this.rgbGetIdMin(`white`) || 0, t2 = this.rgbGetIdMax(`white`) || 100) : (e3 = 0, t2 = 255), b(`div`, { style: X.rgbSliderContainer, children: [g(qe, { style: { width: 24, height: 24 } }), g(p, { min: e3, max: t2, valueLabelDisplay: `auto`, value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === this.rgbGetWhiteId() ? this.state.controlValue.value : this.rgbGetWhite() || 0, onChange: (e4, t3) => this.rgbSetWhite(t3), onChangeCommitted: () => this.finishChanging() })] });
  }
  rgbRenderColorTemperature(e3) {
    var _a;
    return this.state.rxData.rgbType !== `ct` || e3 === true ? null : b(`div`, { style: X.rgbSliderContainer, children: [g(m, { title: w.t(`Color temperature`), slotProps: { popper: { sx: X.tooltip } }, children: g(C, {}) }), g(`div`, { style: { ...X.rgbSliderContainer, background: `linear-gradient(to right, ${this.state.colorTemperatures.map((e4) => `rgb(${e4.red}, ${e4.green}, ${e4.blue})`).join(`, `)})`, flex: `1`, borderRadius: 4 }, children: g(p, { valueLabelDisplay: `auto`, min: this.rgbGetIdMin(`color_temperature`) || 2700, max: this.rgbGetIdMax(`color_temperature`) || 6e3, value: ((_a = this.state.controlValue) == null ? void 0 : _a.id) === `color_temperature` ? this.state.controlValue.value : this.getPropertyValue(`color_temperature`) || 0, onChange: (e4, t2) => this.rgbSetId(`color_temperature`, t2), onChangeCommitted: () => this.finishChanging() }) })] });
  }
  rgbRenderDialog(e3, t2) {
    return this.state.dialog ? b(f, { fullWidth: true, maxWidth: `sm`, open: true, sx: { "& .MuiDialog-paper": X.rgbDialog }, onClose: () => this.setState({ dialog: false }), children: [b(d, { children: [this.state.rxData.widgetTitle, g(l, { style: { float: `right`, zIndex: 2 }, onClick: () => this.setState({ dialog: false }), children: g(S, {}) })] }), g(u, { style: { maxWidth: 400 }, children: b(`div`, { style: X.rgbDialogContainer, children: [this.rgbRenderSwitch(), this.rgbRenderBrightness(), this.rgbRenderWhite(), this.rgbRenderWheelTypeSwitch(e3, false, t2), this.rgbRenderWheel(e3, t2), this.rgbRenderBrightnessSlider(e3, t2), this.rgbRenderColorTemperature(t2)] }) })] }) : null;
  }
  rgbGetColor = () => {
    if (this.state.rxData.rgbType === `ct`) {
      let e3 = Q(this.getPropertyValue(`color_temperature`));
      return F({ r: e3.red, g: e3.green, b: e3.blue, a: 1 });
    }
    return z(this.rgbGetWheelColor());
  };
  rgbGetTextColor = () => {
    if (this.state.rxData.rgbType === `ct`) {
      let e4 = Q(this.getPropertyValue(`color_temperature`));
      return e4.red + e4.green + e4.blue > 384 ? `#000000` : `#ffffff`;
    }
    let e3 = R(this.rgbGetWheelColor());
    return e3.r + e3.g + e3.b > 384 ? `#000000` : `#ffffff`;
  };
  onCommand(e3) {
    let t2 = super.onCommand(e3);
    if (t2 === false) {
      if (e3 === `openDialog`) return this.setState({ dialog: true }), true;
      if (e3 === `closeDialog`) return this.setState({ dialog: false }), true;
    }
    return t2;
  }
  renderWidgetBody(e3) {
    var _a, _b;
    super.renderWidgetBody(e3);
    let t2 = 0;
    this.state.rxData.fullSize ? t2 = (_b = (_a = this.refService) == null ? void 0 : _a.current) == null ? void 0 : _b.clientWidth : this.contentRef.current && (t2 = this.contentRef.current.offsetWidth > this.contentRef.current.offsetHeight ? this.contentRef.current.offsetHeight : this.contentRef.current.offsetWidth);
    let n2 = null;
    this.state.rgbObjects.switch && (n2 = this.getPropertyValue(`switch`));
    let r2;
    r2 = n2 ? this.state.rxData.colorEnabled || `#4DABF5` : this.state.rxData.color || (this.props.context.themeType === `dark` ? `#111` : `#eee`);
    let i2 = this.rgbIsRgb() || this.rgbIsHSL(), a2 = this.rgbGetWhiteMode(), o2;
    if (this.state.rxData.fullSize && !this.state.rxData.externalDialog) o2 = i2 && t2 >= 350 ? b(`div`, { ref: this.contentRef, style: { ...X.rgbDialogContainer, flexDirection: `row`, width: `100%` }, children: [b(`div`, { style: { flexDirection: `column`, gap: 12, flexGrow: 1, display: `flex` }, children: [this.rgbRenderSwitch(), this.rgbRenderBrightness(), this.rgbRenderWhite(), this.rgbRenderColorTemperature(a2), this.rgbRenderBrightnessSlider(i2, a2), this.rgbRenderWheelTypeSwitch(i2, true, a2)] }), g(`div`, { style: { flexDirection: `column`, display: `flex` }, children: this.rgbRenderWheel(i2, a2) })] }) : b(`div`, { ref: this.contentRef, style: X.rgbDialogContainer, children: [this.rgbRenderSwitch(), this.rgbRenderBrightness(), this.rgbRenderWhite(), this.rgbRenderWheelTypeSwitch(i2, false, a2), this.rgbRenderWheel(i2, a2), this.rgbRenderBrightnessSlider(i2, a2), this.rgbRenderColorTemperature(a2)] });
    else if (this.props.editMode || !this.state.rxData.externalDialog) {
      e3.className = n2 ? `${e3.className} vis-on`.trim() : `${e3.className} vis-off`.trim();
      let s2 = this.state.rxData.icon, u2 = { color: this.rgbGetColor(), width: `90%`, height: `90%` };
      n2 === false && (u2.opacity = 0.7), s2 === void 0 ? s2 = g(T, { style: u2 }) : s2 ? s2 = g(v, { src: s2, alt: this.props.id, style: u2 }) : (u2.borderRadius = `50%`, s2 = g(`div`, { style: u2 }));
      let d2 = null;
      this.state.rxData.noCard || e3.widget.usedInWidget ? (d2 = { boxSizing: `border-box` }, this.state.rxData.onlyCircle || (d2.backgroundColor = r2)) : this.state.rxData.onlyCircle || (d2 = { backgroundColor: r2 });
      let f2;
      f2 = this.state.rxData.onlyCircle ? g(l, { onClick: !this.state.rxData.toggleOnClick || !this.state.rgbObjects.switch ? () => this.setState({ dialog: true }) : void 0, onMouseDown: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
        this._pressTimeout && clearTimeout(this._pressTimeout), this._pressTimeout = setTimeout(() => {
          this._pressTimeout = null, this.setState({ dialog: true });
        }, parseInt(this.state.rxData.pressDuration, 10) || 300);
      } : void 0, onMouseUp: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
        this._pressTimeout && (clearTimeout(this._pressTimeout), this._pressTimeout = null, this.rgbSetId(`switch`, !n2));
      } : void 0, onTouchStart: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
        this._pressTimeout && clearTimeout(this._pressTimeout), this._pressTimeout = setTimeout(() => {
          this._pressTimeout = null, this.setState({ dialog: true });
        }, parseInt(this.state.rxData.pressDuration, 10) || 300);
      } : void 0, onTouchEnd: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
        this._pressTimeout && (clearTimeout(this._pressTimeout), this._pressTimeout = null, this.rgbSetId(`switch`, !n2));
      } : void 0, style: { backgroundColor: this.state.rxData.onlyCircle ? r2 : void 0, width: t2, height: t2, borderRadius: parseInt(this.state.rxData.borderRadius, 10) || void 0 }, children: s2 }) : g(c, { onClick: !this.state.rxData.toggleOnClick || !this.state.rgbObjects.switch ? () => this.setState({ dialog: true }) : void 0, onMouseDown: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
        this._pressTimeout && clearTimeout(this._pressTimeout), this._pressTimeout = setTimeout(() => {
          this._pressTimeout = null, this.setState({ dialog: true });
        }, parseInt(this.state.rxData.pressDuration, 10) || 300);
      } : void 0, onMouseUp: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
        this._pressTimeout && (clearTimeout(this._pressTimeout), this._pressTimeout = null, this.rgbSetId(`switch`, !n2));
      } : void 0, onTouchStart: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
        this._pressTimeout && clearTimeout(this._pressTimeout), this._pressTimeout = setTimeout(() => {
          this._pressTimeout = null, this.setState({ dialog: true });
        }, parseInt(this.state.rxData.pressDuration, 10) || 300);
      } : void 0, onTouchEnd: this.state.rxData.toggleOnClick && this.state.rgbObjects.switch ? () => {
        this._pressTimeout && (clearTimeout(this._pressTimeout), this._pressTimeout = null, this.rgbSetId(`switch`, !n2));
      } : void 0, style: { backgroundColor: this.state.rxData.onlyCircle ? r2 : void 0, width: `100%`, height: `100%`, borderRadius: parseInt(this.state.rxData.borderRadius, 10) || void 0 }, children: s2 }), o2 = b(h, { children: [g(`div`, { ref: this.contentRef, style: { ...X.rgbContent, ...d2 }, children: f2 }), this.rgbRenderDialog(i2, a2)] });
    } else if (this.state.rxData.externalDialog) return this.rgbRenderDialog(i2);
    return this.state.rxData.noCard || e3.widget.usedInWidget ? o2 || g(`div`, {}) : this.wrapContent(o2 || g(`div`, {}), null);
  }
};
export {
  Ye as RGB_NAMES,
  Z as RGB_ROLES,
  L as a,
  P as c,
  Q as colorTemperatureToRGB,
  j as d,
  Xe as default,
  E as f,
  q as i,
  R as l,
  Y as n,
  N as o,
  T as p,
  J as r,
  z as s,
  qe as t,
  F as u
};
