import { B as e } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as t, I as n, L as r, P as i, dt as a, ft as o, j as s, n as c, pt as l, st as u, t as d } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as f } from "./Generic-BOiMPpxz.js";
import { t as p } from "./PinCodeDialog-BOKi9bwC.js";
var m = u(o(`path`, { d: `m22.27 21.73-3.54-3.55L5.78 5.23 2.27 1.72 1 2.99 3.01 5H3v6c0 5.55 3.84 10.74 9 12 2.16-.53 4.08-1.76 5.6-3.41L21 23zM13 9.92l6.67 6.67C20.51 14.87 21 12.96 21 11V5l-9-4-5.48 2.44L11 7.92z` }), `RemoveModerator`), h = u(o(`path`, { d: `M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11z` }), `Security`);
e();
var g = { timerDialog: { textAlign: `center` }, timerSeconds: { fontSize: `200%`, padding: 40 }, lockedButton: { display: `flex`, width: `100%`, justifyContent: `center`, alignItems: `center`, flex: 1, gap: 8 }, unlockedButtons: { display: `flex`, width: `100%`, justifyContent: `space-around`, alignItems: `center`, flex: 1, gap: 8 }, lockButton: { display: `flex`, gap: 8, alignItems: `center` }, icon: { height: 20 }, status: { display: `flex`, alignItems: `center` }, noCardContainer: { width: `100%`, height: `100%`, display: `flex`, flexDirection: `column` }, noCardLocked: { width: `100%`, textAlign: `right` } }, _ = class e2 extends f {
  timerInterval;
  lastRxData = ``;
  constructor(e3) {
    super(e3), this.state = { ...this.state, dialog: false, objects: [], timerDialog: null, pinInput: ``, invalidPin: false, timerSeconds: 0 };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Security`, visSet: `vis-2-widgets-nils-fork`, visName: `Security`, visWidgetLabel: `security`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard` }, { name: `disarmText`, label: `disarm_text` }, { name: `securityOffText`, label: `security_off_text` }, { name: `buttonsCount`, label: `buttons_count`, type: `number`, default: 1 }] }, { name: `buttons`, indexFrom: 1, indexTo: `buttonsCount`, fields: [{ name: `oid`, type: `id`, label: `oid`, onChange: async (e3, t2, n2, r2) => {
      if (t2[e3.name]) {
        let i2 = await r2.getObject(t2[e3.name]), a2 = false;
        if (i2 == null ? void 0 : i2.common) {
          if (i2.common.color && t2[`color${e3.index}`] !== i2.common.color && (t2[`color${e3.index}`] = i2.common.color, a2 = true), i2.common.name) {
            let n3 = i2.common.name ? f.getText(i2.common.name) : ``;
            t2[`name${e3.index}`] !== n3 && (t2[`name${e3.index}`] = n3, a2 = true);
          }
          a2 && n2(t2);
        }
      }
    } }, { name: `name`, label: `name`, default: f.t(`default_button_name`) }, { name: `color`, type: `color`, label: `color` }, { name: `icon`, type: `image`, label: `icon` }, { name: `iconSmall`, type: `icon64`, label: `small_icon`, hidden: `!!data.icon` }, { name: `pincode`, label: `pincode`, onChange: (e3, t2, n2) => (t2[`pincode${e3.index}`] = (t2[`pincode${e3.index}`] || ``).replace(/[^0-9]/g, ``), n2(t2), Promise.resolve()), hidden: (e3, t2) => !!e3[`pincode-oid${t2}`] }, { name: `pincode-oid`, type: `id`, label: `pincode_oid`, hidden: (e3, t2) => !!e3[`pincode${t2}`] }, { name: `pincodeReturnButton`, type: `select`, options: [`submit`, `backspace`], default: `submit`, label: `pincode_return_button`, hidden: (e3, t2) => !!e3[`pincode-oid${t2}`] && !!e3[`pincode${t2}`] }, { name: `timerSeconds`, type: `number`, label: `timer_seconds` }, { name: `timerSeconds-oid`, type: `id`, label: `timer_seconds_oid` }] }], visDefaultStyle: { width: `100%`, height: 240, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_security.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  async propertiesUpdate() {
    var _a, _b, _c, _d, _e;
    let e3 = JSON.stringify(this.state.rxData);
    if (this.lastRxData === e3) return;
    this.lastRxData = e3;
    let t2 = [], n2 = [];
    for (let e4 = 1; e4 <= this.state.rxData.buttonsCount; e4++) this.state.rxData[`oid${e4}`] && this.state.rxData[`oid${e4}`] !== `nothing_selected` && n2.push(this.state.rxData[`oid${e4}`]);
    let r2 = n2.length && await this.props.context.socket.getObjectsById(n2) || {};
    for (let e4 = 1; e4 <= this.state.rxData.buttonsCount; e4++) {
      let n3 = r2[this.state.rxData[`oid${e4}`]];
      if (!n3) {
        t2[e4] = { common: {}, _id: this.state.rxData[`oid${e4}`], isChart: false };
        continue;
      }
      n3.common || (n3.common = {});
      let i2 = !!(n3.common.custom && n3.common.custom[(_b = (_a = this.props.context.systemConfig) == null ? void 0 : _a.common) == null ? void 0 : _b.defaultHistory]);
      if (!this.state.rxData[`icon${e4}`] && !n3.common.icon && (n3.type === `state` || n3.type === `channel`)) {
        let t3 = this.state.rxData[`oid${e4}`].split(`.`), r3 = await this.props.context.socket.getObject(t3.slice(0, -1).join(`.`));
        if (!((_c = r3 == null ? void 0 : r3.common) == null ? void 0 : _c.icon) && (n3.type === `state` || n3.type === `channel`)) {
          let e5 = await this.props.context.socket.getObject(t3.slice(0, -2).join(`.`));
          ((_d = e5 == null ? void 0 : e5.common) == null ? void 0 : _d.icon) && (n3.common.icon = e5.common.icon, (e5.type === `instance` || e5.type === `adapter`) && (n3.common.icon = `../${e5.common.name}.admin/${n3.common.icon}`));
        } else ((_e = r3 == null ? void 0 : r3.common) == null ? void 0 : _e.icon) && (n3.common.icon = r3.common.icon, (r3.type === `instance` || r3.type === `adapter`) && (n3.common.icon = `../${r3.common.name}.admin/${n3.common.icon}`));
      }
      t2[e4] = { common: n3.common, _id: n3._id, isChart: i2 };
    }
    JSON.stringify(t2) !== JSON.stringify(this.state.objects) && this.setState({ objects: t2 });
  }
  async onRxDataChanged() {
    await this.propertiesUpdate();
  }
  async componentDidMount() {
    super.componentDidMount(), await this.propertiesUpdate();
  }
  componentWillUnmount() {
    this.timerInterval && clearInterval(this.timerInterval), this.timerInterval = void 0, super.componentWillUnmount();
  }
  renderUnlockDialog() {
    let e3 = null, t2 = ``, n2 = `submit`;
    for (let r2 = 1; r2 <= this.state.rxData.buttonsCount; r2++) if (this.getPropertyValue(`oid${r2}`)) {
      e3 = this.state.rxData[`oid${r2}`], t2 = this.getPinCode(r2), n2 = this.state.rxData[`pincodeReturnButton${r2}`] === `backspace` ? `backspace` : `submit`;
      break;
    }
    return this.state.dialog ? o(p, { pinCode: t2, pinCodeReturnButton: n2, onClose: (t3) => {
      t3 && e3 && this.props.context.setValue(e3, false), this.setState({ dialog: false });
    } }) : null;
  }
  renderTimerDialog() {
    if (this.state.timerDialog === null) return null;
    let e3 = () => {
      let e4 = this.state.timerDialog;
      this.setState({ timerDialog: null }), this.state.rxData[`timerSeconds-oid${e4}`] && this.props.context.setValue(this.state.rxData[`timerSeconds-oid${e4}`], -1), clearInterval(this.timerInterval);
    }, a2 = this.state.timerDialog;
    return l(i, { open: true, onClose: e3, style: g.timerDialog, children: [o(r, { children: f.t(`lock_after`, (this.state.rxData[`timerSeconds${a2}`] || 0).toString()) }), l(n, { children: [o(`div`, { style: g.timerSeconds, children: this.state.timerSeconds }), o(`div`, { children: o(t, { onClick: e3, variant: `contained`, children: f.t(`lock_cancel`) }) })] })] });
  }
  startTimer(e3) {
    let t2 = this.state.rxData[`timerSeconds${e3}`];
    this.setState({ timerSeconds: t2, timerDialog: e3 }), this.state.rxData[`timerSeconds-oid${e3}`] && this.props.context.setValue(this.state.rxData[`timerSeconds-oid${e3}`], t2), this.timerInterval = setInterval(() => {
      let t3 = this.state.timerSeconds - 1;
      this.setState({ timerSeconds: t3 }), t3 || (this.state.rxData[`oid${e3}`] ? this.props.context.setValue(this.state.rxData[`oid${e3}`], true) : this.setState({ message: f.t(`no_oid`) }), this.state.rxData[`timerSeconds-oid${e3}`] && this.props.context.setValue(this.state.rxData[`timerSeconds-oid${e3}`], 0), this.timerInterval && clearInterval(this.timerInterval), this.setState({ timerDialog: null }));
    }, 1e3);
  }
  getPinCode(e3) {
    return this.state.rxData[`pincode-oid${e3}`] ? this.getPropertyValue(`pincode-oid${e3}`) : this.state.rxData[`pincode${e3}`];
  }
  renderMessageDialog() {
    return this.state.message ? o(d, { text: this.state.message, onClose: () => this.setState({ message: null }) }) : null;
  }
  renderWidgetBody(e3) {
    var _a, _b;
    super.renderWidgetBody(e3);
    let n2 = [], r2 = null;
    for (let e4 = 1; e4 <= this.state.rxData.buttonsCount; e4++) n2.push({ i: e4, oid: this.state.rxData[`oid${e4}`], name: this.state.rxData[`name${e4}`], color: this.state.rxData[`color${e4}`], icon: this.state.rxData[`icon${e4}`] || this.state.rxData[`iconSmall${e4}`] || ((_b = (_a = this.state.objects[e4]) == null ? void 0 : _a.common) == null ? void 0 : _b.icon) }), this.getPropertyValue(`oid${e4}`) && (r2 = n2[n2.length - 1]);
    let i2 = l(a, { children: [this.renderUnlockDialog(), this.renderTimerDialog(), this.renderMessageDialog(), r2 ? o(`div`, { style: g.lockedButton, children: o(t, { variant: `contained`, onClick: () => {
      this.getPinCode(r2.i) ? this.setState({ dialog: true, pinInput: `` }) : this.props.context.setValue(r2.oid, false);
    }, children: this.state.rxData.disarmText || f.t(`unlock`) }) }) : o(`div`, { style: g.unlockedButtons, children: n2.map((e4, n3) => o(t, { variant: `contained`, style: { backgroundColor: e4.color }, onClick: () => {
      this.state.rxData[`timerSeconds${e4.i}`] ? this.startTimer(e4.i) : e4.oid ? this.props.context.setValue(e4.oid, true) : this.setState({ message: f.t(`no_oid`) });
    }, children: l(`span`, { style: g.lockButton, children: [e4.icon ? o(c, { style: g.icon, src: e4.icon, alt: `` }) : null, e4.name] }) }, n3)) })] }), u2 = o(s, { label: o(`span`, { style: g.status, children: r2 ? l(a, { children: [o(h, {}), r2.name] }) : l(a, { children: [o(m, {}), this.state.rxData.securityOffText || f.t(`security_off`)] }) }), style: { backgroundColor: r2 ? `orange` : `green`, color: r2 ? `black` : `white` } });
    return this.state.rxData.noCard || e3.widget.usedInWidget ? l(`div`, { style: g.noCardContainer, children: [o(`div`, { style: g.noCardLocked, children: u2 }), i2] }) : this.wrapContent(i2, u2, { boxSizing: `border-box`, paddingBottom: 10, height: `100%` });
  }
};
export {
  _ as default
};
