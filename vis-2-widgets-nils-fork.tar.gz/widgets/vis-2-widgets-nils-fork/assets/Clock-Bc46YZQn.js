import { B as e, T as t, g as n } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { ft as r, pt as i } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as a } from "./Generic-BOiMPpxz.js";
e();
var o = 90, s = (e3) => e3 * 30 - o, c = (e3) => e3 * 6, l = [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], u = { analogClockBase: { borderRadius: `50%`, borderStyle: `solid`, display: `flex`, justifyContent: `center`, alignItems: `center` }, analogClockBaseCenter: { borderRadius: `50%`, zIndex: 2 }, tickLabel: { position: `absolute`, borderRadius: 2, transformOrigin: `center` }, hourLabel: { position: `absolute`, display: `flex`, transformOrigin: `center` }, hourLabelSpan: { fontWeight: 500 } }, d = class extends t {
  render() {
    let e3 = Math.round(0.064 * this.props.size), t2 = Math.round(0.036 * this.props.size);
    return i(`div`, { style: { ...u.analogClockBase, width: this.props.size, height: this.props.size, backgroundColor: this.props.backgroundColor, borderColor: this.props.ticksColor, borderWidth: this.props.size * 0.012 }, children: [r(`div`, { style: { ...u.analogClockBaseCenter, backgroundColor: this.props.withSeconds ? this.props.secondHandColor : this.props.handsColor, width: this.props.size * 0.05, height: this.props.size * 0.05 } }), Array.from(Array(60)).map((e4, n2) => r(`div`, { style: { ...u.tickLabel, width: n2 % 5 ? Math.round(t2 / 2) : t2, height: n2 % 5 ? Math.round(t2 / 9) : Math.round(t2 / 3), backgroundColor: this.props.ticksColor, transform: `rotate(${c(n2)}deg) translateX(${this.props.size * 0.46}px)` } }, n2.toString())), this.props.showNumbers && l.map((t3, n2) => r(`div`, { style: { ...u.hourLabel, color: this.props.ticksColor, transform: `rotate(${s(n2)}deg) translateX(${this.props.size * 0.4}px)` }, children: r(`span`, { style: { ...u.hourLabelSpan, transform: `rotate(${-1 * s(n2)}deg)`, fontSize: e3 }, children: t3 }) }, t3.toString() + n2.toString())), this.props.children] });
  }
};
e();
var f = 90, p = (e3, t2) => e3 * 30 + t2 * 0.5 - f, m = (e3, t2, n2) => e3 * 360 + t2 * 6 + n2 / 12 - f, h = (e3, t2) => e3 * 360 + t2 * 6 - f, g = { analogClock: { verticalAlign: `middle` }, hourHand: { position: `absolute`, zIndex: 1, transformOrigin: `center`, transition: `transform linear 0.5s` }, minuteHand: { position: `absolute`, transformOrigin: `center`, transition: `transform linear 0.5s` }, secondHand: { position: `absolute`, transformOrigin: `center`, transition: `transform linear 1s` } }, _ = class extends t {
  render() {
    let e3 = /* @__PURE__ */ new Date(), t2 = e3.getHours() % 12, n2 = e3.getMinutes(), a2 = e3.getSeconds(), o2 = this.props.size * 0.45, s2 = Math.round(this.props.size / 50);
    return r(`div`, { style: { ...g.analogClock, ...this.props.style }, children: i(d, { backgroundColor: this.props.backgroundColor || (this.props.themeType === `dark` ? `#111` : `#EEE`), ticksColor: this.props.ticksColor || (this.props.themeType === `dark` ? `#dedede` : `#212121`), handsColor: this.props.handsColor || (this.props.themeType === `dark` ? `#dedede` : `#212121`), secondHandColor: this.props.secondHandColor || `#F44336`, showNumbers: this.props.showNumbers, size: this.props.size, withSeconds: this.props.withSeconds, children: [r(`div`, { style: { ...g.hourHand, width: this.props.size * 0.3, height: s2, borderRadius: `0 ${Math.round(s2 / 2)}px ${Math.round(s2 / 2)}px 0`, backgroundColor: this.props.handsColor || (this.props.themeType === `dark` ? `#dedede` : `#212121`), transform: `rotate(${p(t2, n2)}deg) translateX(${this.props.size * 0.3 / 2}px)` } }), r(`div`, { style: { ...g.minuteHand, width: this.props.size * 0.4, height: s2, borderRadius: `0 ${Math.round(s2 / 2)}px ${Math.round(s2 / 2)}px 0`, backgroundColor: this.props.handsColor || (this.props.themeType === `dark` ? `#dedede` : `#212121`), transform: `rotate(${m(t2, n2, a2)}deg) translateX(${this.props.size * 0.4 / 2}px)` } }), this.props.withSeconds ? r(`div`, { style: { ...g.secondHand, width: o2, height: this.props.size / 100, borderRadius: `0 ${Math.round(this.props.size / 500)}px ${Math.round(this.props.size / 500)}px 0`, backgroundColor: this.props.secondHandColor || `#F44336`, transform: `rotate(${h(n2, a2)}deg) translateX(${o2 / 2}px)` } }) : null] }) });
  }
};
e();
var v = { uClock: { verticalAlign: `middle`, animation: `vis-2-widgets-nils-fork-uClockFadeIn 500ms ease-in-out`, animationFillMode: `both`, backgroundColor: `#fff`, borderRadius: `50%` }, uClockHand: { transition: `transform 200ms cubic-bezier(0.175, 0.885, 0.32, 1.275)` }, hourLabelSpan: {} }, y = class e2 extends a {
  refContainer = n.createRef();
  rotations;
  timeInterval;
  constructor(e3) {
    super(e3), this.state = { ...this.state, time: /* @__PURE__ */ new Date(), width: 0, fontSizeSvg: 0, textWidthSvg: 0 };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Clock`, visSet: `vis-2-widgets-nils-fork`, visWidgetLabel: `clock`, visName: `Clock`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `type`, label: `type`, type: `select`, options: [{ value: `analog`, label: `analog` }, { value: `analog2`, label: `analog2` }, { value: `digital`, label: `digital` }, { value: `digital2`, label: `digital2` }], default: `analog` }, { name: `backgroundColor`, hidden: `data.type === "digital" || data.type === "digital2"`, label: `background`, type: `color` }, { name: `ticksColor`, hidden: `data.type === "digital" || data.type === "digital2"`, label: `color`, type: `color` }, { name: `handsColor`, hidden: `data.type === "digital" || data.type === "digital2"`, label: `hands_color`, type: `color` }, { name: `secondHandColor`, hidden: `data.type === "digital" || data.type === "digital2"`, label: `seconds_hand_color`, type: `color` }, { name: `withSeconds`, label: `with_seconds`, type: `checkbox`, default: true }, { name: `showNumbers`, hidden: `data.type === "digital" || data.type === "digital2"`, label: `show_numbers`, type: `checkbox`, default: true }, { name: `blinkDelimiter`, label: `blink`, hidden: `(data.type !== "digital" && data.type !== "digital2") || data.withSeconds`, type: `checkbox`, default: true }, { name: `hoursFormat`, label: `am_pm`, hidden: `data.type !== "digital" && data.type !== "digital2"`, type: `select`, options: [`24`, `12`], noTranslation: true, default: `24` }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_clock.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  nextTick = () => {
    let e3 = this.state.rxData || {}, t2 = /* @__PURE__ */ new Date(), n2;
    n2 = e3.withSeconds || e3.type === `digital2` && e3.blinkDelimiter ? 1e3 - t2.getMilliseconds() : 1e3 - t2.getMilliseconds() + 1e3 * (60 - t2.getSeconds()), this.timeInterval = setTimeout(this.nextTick, n2), this.setState({ time: t2 });
  };
  onRxDataChanged() {
    this.timeInterval && clearTimeout(this.timeInterval), this.timeInterval = setTimeout(() => {
      this.timeInterval = void 0, this.nextTick();
    }, 1e3 - (/* @__PURE__ */ new Date()).getMilliseconds());
  }
  componentDidMount() {
    super.componentDidMount(), this.timeInterval = this.timeInterval || setTimeout(() => {
      this.timeInterval = void 0, this.nextTick();
    }, 1e3 - (/* @__PURE__ */ new Date()).getMilliseconds()), this.recalculateWidth();
  }
  recalculateWidth() {
    if (this.refContainer.current) {
      let t2 = this.refContainer.current.clientWidth;
      this.state.rxData.type !== `digital` && this.state.rxData.type !== `digital2` && t2 > this.refContainer.current.clientHeight && (t2 = this.refContainer.current.clientHeight);
      let n2 = this.getDigitalClockText(true), r2 = n2.digits.join(`:`);
      if (n2.ampm && (r2 += ` ${n2.ampm}`), t2 !== this.state.width || this.state.height !== this.refContainer.current.clientHeight || this.state.timeFormat !== r2) {
        let n3 = 0, i2 = 0;
        if (this.state.rxData.type === `digital` || this.state.rxData.type === `digital2`) {
          let t3 = this.getDigitalClockText(true), r3 = `${t3.digits[0]}${t3.hideDelimiter ? ` ` : `:`}${t3.digits[1]}${t3.digits[2] ? `:${t3.digits[2]}` : ``}`;
          this.state.rxData.type === `digital` && this.state.rxData.hoursFormat === `12` && (r3 += ` mm`), i2 = e2.calculateFontSize(r3, this.refContainer.current.clientWidth, this.refContainer.current.clientHeight), n3 = e2.getTextWidth(r3, `normal ${i2}px Arial`);
        }
        this.setState({ width: t2, height: this.refContainer.current.clientHeight, timeFormat: r2, fontSizeSvg: i2, textWidthSvg: n3 });
      }
    }
  }
  componentWillUnmount() {
    this.timeInterval && (this.timeInterval = (clearTimeout(this.timeInterval), void 0)), super.componentWillUnmount();
  }
  componentDidUpdate(e3, t2) {
    super.componentDidUpdate(e3, t2), this.recalculateWidth();
  }
  renderSimpleClock() {
    let e3 = this.state.rxData || {}, t2 = /* @__PURE__ */ new Date(), n2 = t2.getSeconds(), a2 = t2.getMinutes(), o2 = t2.getHours() % 12;
    this.rotations = this.rotations || [0, 0, 0], n2 === 0 && (this.rotations[0] += 1), a2 === 0 && n2 === 0 && (this.rotations[1] += 1), o2 === 0 && a2 === 0 && n2 === 0 && (this.rotations[2] += 1);
    let s2 = n2 / 60 * 360 + this.rotations[0] * 360, c2 = a2 / 60 * 360 + this.rotations[1] * 360, l2 = o2 / 12 * 360 + a2 / 60 * 30 + this.rotations[2] * 360;
    return i(`svg`, { viewBox: `0 0 100 100`, color: e3.ticksColor || (this.props.context.themeType === `dark` ? `#dedede` : `#212121`), fill: `currentColor`, width: this.state.width, height: this.state.width, style: { ...v.uClock, backgroundColor: e3.backgroundColor || (this.props.context.themeType === `dark` ? `#111` : `#EEE`) }, children: [[...Array(12)].map((e4, t3) => r(`line`, { style: { transformOrigin: `center` }, stroke: `currentColor`, opacity: 0.7, strokeWidth: 1, transform: `rotate(${30 * t3})`, strokeLinecap: `round`, x1: `50`, y1: `5`, x2: `50`, y2: `10` }, t3)), r(`line`, { stroke: e3.handsColor || (this.props.context.themeType === `dark` ? `#dedede` : `#212121`), style: { ...v.uClockHand, transform: `rotate(${l2}deg)`, transformOrigin: `center` }, strokeLinecap: `round`, strokeWidth: `1.5`, x1: `50`, y1: `25`, x2: `50`, y2: `50` }), r(`line`, { stroke: e3.handsColor || (this.props.context.themeType === `dark` ? `#dedede` : `#212121`), style: { ...v.uClockHand, transform: `rotate(${c2}deg)`, transformOrigin: `center` }, strokeLinecap: `round`, strokeWidth: `1.5`, x1: `50`, y1: `10`, x2: `50`, y2: `50` }), r(`circle`, { stroke: `currentColor`, cx: `50`, cy: `50`, r: `3` }), e3.withSeconds ? i(`g`, { style: { ...v.uClockHand, transform: `rotate(${s2}deg)`, transformOrigin: `center` }, stroke: `currentColor`, color: e3.secondHandColor || `#F44336`, strokeWidth: `1`, children: [r(`line`, { x1: `50`, y1: `10`, x2: `50`, y2: `60`, strokeLinecap: `round` }), r(`circle`, { cx: `50`, cy: `50`, r: `1.5` })] }) : null, e3.showNumbers ? [...Array(12)].map((e4, t3) => r(`g`, { style: { transformOrigin: `center center`, transform: `rotate(${30 * (t3 + 1)}deg)` }, children: r(`text`, { x: t3 + 1 > 9 ? 46 : 48, y: `18`, stroke: `currentColor`, fontSize: 6, children: t3 + 1 }) }, t3.toString())) : null] });
  }
  renderAnalogClock() {
    let e3 = this.state.rxData || {};
    return r(_, { style: { marginTop: this.refContainer.current.clientHeight > this.refContainer.current.clientWidth ? (this.refContainer.current.clientHeight - this.refContainer.current.clientWidth) / 2 : void 0, marginLeft: this.refContainer.current.clientHeight < this.refContainer.current.clientWidth ? (this.refContainer.current.clientWidth - this.refContainer.current.clientHeight) / 2 : void 0 }, size: this.state.width, ticksColor: e3.ticksColor, backgroundColor: e3.backgroundColor, showNumbers: e3.showNumbers, withSeconds: e3.withSeconds, handsColor: e3.handsColor, secondHandColor: e3.secondHandColor, themeType: this.props.context.themeType });
  }
  getDigitalClockText(e3) {
    let t2 = this.state.rxData || {}, n2 = [];
    if (e3) return n2.push(`00`), n2.push(`00`), t2.withSeconds && n2.push(`00`), { ampm: t2.hoursFormat === `12` ? `pm` : void 0, digits: n2 };
    let r2 = /* @__PURE__ */ new Date();
    return t2.hoursFormat === `12` ? n2.push((r2.getHours() % 12).toString().padStart(2, `0`)) : n2.push(r2.getHours().toString().padStart(2, `0`)), n2.push(r2.getMinutes().toString().padStart(2, `0`)), t2.withSeconds && n2.push(r2.getSeconds().toString().padStart(2, `0`)), { ampm: t2.hoursFormat === `12` ? r2.getHours() > 11 ? `pm` : `am` : void 0, digits: n2, hideDelimiter: !t2.withSeconds && t2.blinkDelimiter && r2.getSeconds() % 2 == 0 };
  }
  renderDigitalClock() {
    let e3 = this.getDigitalClockText(), t2 = [r(`span`, { children: e3.digits[0] }, `hours`), r(`span`, { style: { opacity: +!e3.hideDelimiter }, children: `:` }, `delimiter1`), r(`span`, { children: e3.digits[1] }, `minutes`), e3.digits.length > 2 ? r(`span`, { style: { opacity: +!e3.hideDelimiter }, children: `:` }, `delimiter2`) : null, e3.digits.length > 2 ? r(`span`, { children: e3.digits[2] }, `seconds`) : null, e3.ampm ? i(`span`, { style: { fontSize: `50%` }, children: [`\xA0`, e3.ampm] }, `ampm`) : null];
    return r(`div`, { style: { display: `inline-block`, margin: `0 auto`, fontSize: this.state.rxStyle[`font-size`] || this.state.fontSizeSvg }, children: t2 });
  }
  static getTextWidth(e3, t2) {
    let n2 = document.createElement(`canvas`).getContext(`2d`);
    return n2.font = t2, n2.measureText(e3).width;
  }
  static calculateFontSize(t2, n2, r2, i2 = `Arial`, a2 = `normal`) {
    let o2 = r2, s2 = e2.getTextWidth(t2, `${a2} ${o2}px ${i2}`);
    for (; (s2 > n2 || o2 > r2) && o2 > 6; ) --o2, s2 = e2.getTextWidth(t2, `${a2} ${o2}px ${i2}`);
    return o2;
  }
  renderDigitalClock2() {
    var _a;
    let t2 = this.state.rxData || {}, n2 = this.getDigitalClockText(), a2 = `${n2.digits[0]}${n2.hideDelimiter ? ` ` : `:`}${n2.digits[1]}${n2.digits[2] ? `:${n2.digits[2]}` : ``}`, o2 = t2.withSeconds ? this.state.fontSizeSvg / 3 : t2.blinkDelimiter ? this.state.fontSizeSvg / 4 : this.state.fontSizeSvg / 3, s2 = e2.getTextWidth(`mm`, `normal ${o2}px Arial`);
    return i(`svg`, { viewBox: `0 0 ${this.state.width} ${this.state.height}`, color: ((_a = this.state.rxStyle) == null ? void 0 : _a.color) || (this.props.context.themeType === `dark` ? `#dedede` : `#212121`), fill: `currentColor`, width: this.state.width, height: this.state.height, children: [r(`text`, { x: `50%`, y: `50%`, fontSize: this.state.fontSizeSvg, dominantBaseline: `middle`, textAnchor: `middle`, fontFamily: t2.withSeconds || !t2.blinkDelimiter ? void 0 : `monospace`, children: a2 }), n2.ampm ? r(`text`, { x: `50%`, y: `50%`, transform: `translate(${this.state.textWidthSvg / 2 - s2}, ${this.state.fontSizeSvg * 0.55})`, fontSize: o2, children: n2.ampm === `pm` ? `PM` : `AM` }) : null] });
  }
  renderWidgetBody(e3) {
    super.renderWidgetBody(e3);
    let t2 = null;
    if (this.state.width) {
      switch (this.state.rxData.type) {
        case `analog2`:
          t2 = this.renderAnalogClock(), this.resizeLocked = !this.props.isRelative;
          break;
        case `digital`:
          this.resizeLocked = false, t2 = this.renderDigitalClock();
          break;
        case `digital2`:
          this.resizeLocked = false, t2 = this.renderDigitalClock2();
          break;
        default:
          t2 = this.renderSimpleClock(), this.resizeLocked = !this.props.isRelative;
      }
      this.timeInterval = this.timeInterval || setTimeout(() => {
        this.timeInterval = void 0, this.nextTick();
      }, 1e3 - (/* @__PURE__ */ new Date()).getMilliseconds());
    }
    let n2 = { textAlign: `center`, lineHeight: this.state.height ? `${this.state.height}px` : void 0, fontFamily: this.state.rxStyle[`font-family`], textShadow: this.state.rxStyle[`text-shadow`], fontStyle: this.state.rxStyle[`font-style`], fontWeight: this.state.rxStyle[`font-weight`], fontVariant: this.state.rxStyle[`font-variant`] };
    n2.width = `calc(100% - 4px)`, n2.height = `calc(100% - 8px)`, n2.margin = `auto`;
    let a2 = i(`div`, { style: n2, ref: this.refContainer, children: [r(`style`, { children: `
@keyframes vis-2-widgets-nils-fork-uClockFadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}               
                ` }), t2] });
    return this.state.rxData.noCard || e3.widget.usedInWidget ? a2 : this.wrapContent(a2, null);
  }
};
export {
  y as default
};
