import { A as e, B as t, T as n, b as r, x as i } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
t();
function a(e2) {
  var t2 = e2.angle, n2 = e2.minValue, r2 = e2.maxValue, i2 = e2.startAngle, a2 = e2.endAngle;
  if (a2 <= i2) throw Error(`endAngle must be greater than startAngle`);
  return t2 < i2 ? n2 : t2 > a2 ? r2 : (t2 - i2) / (a2 - i2) * (r2 - n2) + n2;
}
function o(e2) {
  var t2 = e2.value, n2 = e2.minValue, r2 = e2.maxValue, i2 = e2.startAngle, a2 = e2.endAngle;
  if (a2 <= i2) throw Error(`endAngle must be greater than startAngle`);
  return (t2 - n2) / (r2 - n2) * (a2 - i2) + i2;
}
function s(e2, t2, n2) {
  if (n2 || (n2 = { direction: `ccw`, axis: `+x` }), t2.direction !== n2.direction && (e2 = e2 === 0 ? 0 : 360 - e2), t2.axis === n2.axis) return e2;
  if (t2.axis[1] === n2.axis[1]) return (180 + e2) % 360;
  switch (n2.direction + t2.axis + n2.axis) {
    case `ccw+x-y`:
    case `ccw-x+y`:
    case `ccw+y+x`:
    case `ccw-y-x`:
    case `cw+y-x`:
    case `cw-y+x`:
    case `cw-x-y`:
    case `cw+x+y`:
      return (90 + e2) % 360;
    case `ccw+y-x`:
    case `ccw-y+x`:
    case `ccw+x+y`:
    case `ccw-x-y`:
    case `cw+x-y`:
    case `cw-x+y`:
    case `cw+y+x`:
    case `cw-y-x`:
      return (270 + e2) % 360;
    default:
      throw Error(`Unhandled conversion`);
  }
}
function c(e2, t2, n2) {
  var r2 = s(e2.degree, e2, { direction: `ccw`, axis: `+x` }) / 180 * Math.PI, i2, a2;
  return r2 <= Math.PI ? r2 <= Math.PI / 2 ? (a2 = Math.sin(r2) * t2, i2 = Math.cos(r2) * t2) : (a2 = Math.sin(Math.PI - r2) * t2, i2 = Math.cos(Math.PI - r2) * t2 * -1) : r2 <= Math.PI * 1.5 ? (a2 = Math.sin(r2 - Math.PI) * t2 * -1, i2 = Math.cos(r2 - Math.PI) * t2 * -1) : (a2 = Math.sin(2 * Math.PI - r2) * t2 * -1, i2 = Math.cos(2 * Math.PI - r2) * t2), { x: i2 + n2 / 2, y: n2 / 2 - a2 };
}
function l(e2, t2, n2) {
  var r2 = e2.x - t2 / 2, i2 = t2 / 2 - e2.y, a2 = Math.atan2(i2, r2);
  return a2 < 0 && (a2 += 2 * Math.PI), s(a2 / Math.PI * 180, { direction: `ccw`, axis: `+x` }, n2);
}
var u = function() {
  return u = Object.assign || function(e2) {
    for (var t2, n2 = 1, r2 = arguments.length; n2 < r2; n2++) for (var i2 in t2 = arguments[n2], t2) Object.prototype.hasOwnProperty.call(t2, i2) && (e2[i2] = t2[i2]);
    return e2;
  }, u.apply(this, arguments);
};
function d(e2) {
  var t2 = e2.startAngle, n2 = e2.innerRadius, r2 = e2.thickness, i2 = e2.direction, a2 = e2.angleType, o2 = e2.svgSize, s2 = e2.endAngle;
  t2 % 360 == s2 % 360 && t2 !== s2 && (s2 -= 1e-3);
  var l2 = s2 - t2 >= 180, d2 = n2 + r2, f2 = c(u({ degree: t2 }, a2), n2, o2), p2 = `
    M ${f2.x},${f2.y}
  `, m2 = c(u({ degree: s2 }, a2), n2, o2), h2 = `
    A ${n2} ${n2} 0
      ${l2 ? `1` : `0`}
      ${i2 === `cw` ? `1` : `0`}
      ${m2.x} ${m2.y}
  `, g = c(u({ degree: s2 }, a2), d2, o2), _ = `
    A ${r2 / 2} ${r2 / 2} 0
      ${l2 ? `1` : `0`}
      ${i2 === `cw` ? `0` : `1`}
      ${g.x} ${g.y}
  `, v = c(u({ degree: t2 }, a2), d2, o2), y = `
    A ${d2} ${d2} 0
      ${l2 ? `1` : `0`}
      ${i2 === `cw` ? `0` : `1`}
      ${v.x} ${v.y}
  `, b = `
    A ${r2 / 2} ${r2 / 2} 0
      ${l2 ? `1` : `0`}
      ${i2 === `cw` ? `0` : `1`}
      ${f2.x} ${f2.y}
  `;
  return p2 + h2 + _ + y + b + ` Z`;
}
var f = /* @__PURE__ */ (function() {
  var e2 = function(t2, n2) {
    return e2 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e3, t3) {
      e3.__proto__ = t3;
    } || function(e3, t3) {
      for (var n3 in t3) Object.prototype.hasOwnProperty.call(t3, n3) && (e3[n3] = t3[n3]);
    }, e2(t2, n2);
  };
  return function(t2, n2) {
    if (typeof n2 != `function` && n2 !== null) throw TypeError(`Class extends value ` + String(n2) + ` is not a constructor or null`);
    e2(t2, n2);
    function r2() {
      this.constructor = t2;
    }
    t2.prototype = n2 === null ? Object.create(n2) : (r2.prototype = n2.prototype, new r2());
  };
})(), p = function() {
  return p = Object.assign || function(e2) {
    for (var t2, n2 = 1, r2 = arguments.length; n2 < r2; n2++) for (var i2 in t2 = arguments[n2], t2) Object.prototype.hasOwnProperty.call(t2, i2) && (e2[i2] = t2[i2]);
    return e2;
  }, p.apply(this, arguments);
}, m = (function(t2) {
  f(n2, t2);
  function n2() {
    var e2 = t2 !== null && t2.apply(this, arguments) || this;
    return e2.svgRef = i(), e2.onMouseEnter = function(t3) {
      t3.buttons === 1 && e2.onMouseDown(t3);
    }, e2.onMouseDown = function(t3) {
      var n3 = e2.svgRef.current;
      n3 && (n3.addEventListener(`mousemove`, e2.handleMousePosition), n3.addEventListener(`mouseleave`, e2.removeMouseListeners), n3.addEventListener(`mouseup`, e2.removeMouseListeners)), e2.handleMousePosition(t3);
    }, e2.removeMouseListeners = function() {
      var t3 = e2.svgRef.current;
      t3 && (t3.removeEventListener(`mousemove`, e2.handleMousePosition), t3.removeEventListener(`mouseleave`, e2.removeMouseListeners), t3.removeEventListener(`mouseup`, e2.removeMouseListeners)), e2.props.onControlFinished && e2.props.onControlFinished();
    }, e2.handleMousePosition = function(t3) {
      var n3 = t3.clientX, r2 = t3.clientY;
      e2.processSelection(n3, r2);
    }, e2.onTouch = function(t3) {
      if (!(t3.touches.length > 1 || t3.type === `touchend` && t3.touches.length > 0)) {
        var n3 = t3.changedTouches[0], r2 = n3.clientX, i2 = n3.clientY;
        e2.processSelection(r2, i2), (t3.type === `touchend` || t3.type === `touchcancel`) && e2.props.onControlFinished && e2.props.onControlFinished();
      }
    }, e2.processSelection = function(t3, n3) {
      var _a;
      var r2 = e2.props, i2 = r2.size, o2 = r2.maxValue, s2 = r2.minValue, c2 = r2.angleType, u2 = r2.startAngle, d2 = r2.endAngle, f2 = r2.handle1, p2 = r2.disabled, m2 = r2.handle2, h2 = r2.coerceToInt;
      if (f2.onChange) {
        var g = e2.svgRef.current;
        if (g) {
          var _ = g.createSVGPoint();
          _.x = t3, _.y = n3;
          var v = a({ angle: l(_.matrixTransform((_a = g.getScreenCTM()) == null ? void 0 : _a.inverse()), i2, c2), minValue: s2, maxValue: o2, startAngle: u2, endAngle: d2 });
          h2 && (v = Math.round(v)), p2 || (m2 && m2.onChange && Math.abs(v - m2.value) < Math.abs(v - f2.value) ? m2.onChange(v) : f2.onChange(v));
        }
      }
    }, e2;
  }
  return n2.prototype.render = function() {
    var t3 = this.props, n3 = t3.size, i2 = t3.trackWidth, a2 = t3.handle1, s2 = t3.handle2, l2 = t3.handleSize, u2 = t3.maxValue, f2 = t3.minValue, m2 = t3.startAngle, h2 = t3.endAngle, g = t3.angleType, _ = t3.disabled, v = t3.arcColor, y = t3.arcBackgroundColor, b = t3.outerShadow, x = 20, S = n3 / 2 - i2 - x, C = o({ value: a2.value, minValue: f2, maxValue: u2, startAngle: m2, endAngle: h2 }), w = s2 && o({ value: s2.value, minValue: f2, maxValue: u2, startAngle: m2, endAngle: h2 }), T = c(p({ degree: C }, g), S + i2 / 2, n3), E = w && c(p({ degree: w }, g), S + i2 / 2, n3), D = !_ && !!a2.onChange;
    return r(`svg`, { width: n3, height: n3, ref: this.svgRef, onMouseDown: this.onMouseDown, onMouseEnter: this.onMouseEnter, onClick: function(e2) {
      return D && e2.stopPropagation();
    }, onTouchStart: this.onTouch, onTouchEnd: this.onTouch, onTouchMove: this.onTouch, onTouchCancel: this.onTouch, style: { touchAction: `none` } }, b && r(e, null, r(`radialGradient`, { id: `outerShadow` }, r(`stop`, { offset: `90%`, stopColor: v }), r(`stop`, { offset: `100%`, stopColor: `white` })), r(`circle`, { fill: `none`, stroke: `url(#outerShadow)`, cx: n3 / 2, cy: n3 / 2, r: S + i2 + x / 2 - 1, strokeWidth: x })), w === void 0 ? r(e, null, r(`path`, { d: d({ startAngle: C, endAngle: h2, angleType: g, innerRadius: S, thickness: i2, svgSize: n3, direction: g.direction }), fill: y }), r(`path`, { d: d({ startAngle: m2, endAngle: C, angleType: g, innerRadius: S, thickness: i2, svgSize: n3, direction: g.direction }), fill: v })) : r(e, null, r(`path`, { d: d({ startAngle: m2, endAngle: C, angleType: g, innerRadius: S, thickness: i2, svgSize: n3, direction: g.direction }), fill: y }), r(`path`, { d: d({ startAngle: w, endAngle: h2, angleType: g, innerRadius: S, thickness: i2, svgSize: n3, direction: g.direction }), fill: y }), r(`path`, { d: d({ startAngle: C, endAngle: w, angleType: g, innerRadius: S, thickness: i2, svgSize: n3, direction: g.direction }), fill: v })), D && r(e, null, r(`filter`, { id: `handleShadow`, x: `-50%`, y: `-50%`, width: `16`, height: `16` }, r(`feOffset`, { result: `offOut`, in: `SourceGraphic`, dx: `0`, dy: `0` }), r(`feColorMatrix`, { result: `matrixOut`, in: `offOut`, type: `matrix`, values: `0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0` }), r(`feGaussianBlur`, { result: `blurOut`, in: `matrixOut`, stdDeviation: `5` }), r(`feBlend`, { in: `SourceGraphic`, in2: `blurOut`, mode: `normal` })), r(`circle`, { r: l2, cx: T.x, cy: T.y, fill: a2.color ?? `#ffffff`, filter: `url(#handleShadow)` })), E && r(e, null, r(`circle`, { r: l2, cx: E.x, cy: E.y, fill: s2.color ?? `#ffffff`, filter: `url(#handleShadow)` })));
  }, n2.defaultProps = { size: 200, trackWidth: 4, minValue: 0, maxValue: 100, startAngle: 0, endAngle: 360, angleType: { direction: `cw`, axis: `-y` }, handleSize: 8, arcBackgroundColor: `#aaa` }, n2;
})(n), h = (function(e2) {
  f(t2, e2);
  function t2() {
    return e2 !== null && e2.apply(this, arguments) || this;
  }
  return t2.prototype.render = function() {
    var e3 = this.props.size;
    return r(`div`, { style: { width: e3, height: e3, position: `relative` } }, r(m, p({}, this.props)), r(`div`, { style: { position: `absolute`, top: `25%`, left: `50%`, transform: `translateX(-50%)`, display: `flex`, flexDirection: `column`, alignItems: `center`, justifyContent: `center` } }, this.props.children));
  }, t2.defaultProps = m.defaultProps, t2;
})(n);
export {
  h as t
};
