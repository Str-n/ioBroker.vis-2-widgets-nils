import { B as e, g as t } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { ft as n, pt as r } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { t as i } from "./Generic-BOiMPpxz.js";
e();
var a = { overlay: { zIndex: 999, top: 0, bottom: 0, position: `absolute`, left: 0, right: 0 } }, o = class e2 extends i {
  refContainer = t.createRef();
  constructor(e3) {
    super(e3), this.state = { ...this.state, width: 0 };
  }
  static getWidgetInfo() {
    return { id: `tplNils2ViewInWidget`, visSet: `vis-2-widgets-nils-fork`, visWidgetLabel: `view_in_widget`, visName: `View in Widget`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox` }, { name: `widgetTitle`, label: `name`, hidden: `!!data.noCard` }, { name: `view`, label: `view`, type: `select-views`, multiple: false }, { name: `button`, label: `view_button`, type: `checkbox` }] }], visDefaultStyle: { width: `100%`, height: 120, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_view.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  componentDidMount() {
    super.componentDidMount(), this.recalculateWidth();
  }
  recalculateWidth() {
    this.refContainer.current && this.refContainer.current.clientWidth !== this.state.width && this.setState({ width: this.refContainer.current.clientWidth });
  }
  componentWillUnmount() {
    super.componentWillUnmount();
  }
  componentDidUpdate(e3, t2) {
    super.componentDidUpdate(e3, t2), this.recalculateWidth();
  }
  onNavigate() {
    window.vis.changeView(this.state.rxData.view, this.state.rxData.view);
  }
  renderWidgetBody(e3) {
    super.renderWidgetBody(e3);
    let t2 = this.state.rxData.view;
    if (t2 === this.props.view) return n(`div`, { className: `vis-widget-body`, style: { overflow: `hidden`, position: `absolute` }, children: `Cannot use recursive views` });
    let i2;
    if (this.state.width && this.state.rxData.button && this.props.refParent.current && this.refContainer.current) {
      let e4 = this.refContainer.current.offsetWidth, t3 = this.refContainer.current.offsetHeight, n2 = this.props.refParent.current, r2 = 0;
      for (; n2.className.includes(`vis-view`) && r2 < 5; ) n2 = n2.parentNode, r2 += 1;
      if (n2) {
        let r3 = e4 / n2.offsetWidth;
        i2 = { transform: `scale(${r3})`, transformOrigin: `top left`, width: `${1 / r3 * 100}%`, height: `${1 / r3 * 100 * (t3 / e4)}%`, cursor: `pointer` };
      }
    }
    let o2 = this.state.rxData.noCard || e3.widget.usedInWidget, s = r(`div`, { style: { overflow: `hidden`, position: `absolute`, top: !o2 && this.state.rxData.widgetTitle ? 53 : o2 ? 0 : 16, left: o2 ? 0 : 8, width: o2 ? `100%` : `calc(100% - 16px)`, height: !o2 && this.state.rxData.widgetTitle ? `calc(100% - 68px)` : o2 ? `100%` : `calc(100% - 32px)`, textAlign: `center`, lineHeight: this.state.height ? `${this.state.height}px` : void 0, fontFamily: this.state.rxStyle[`font-family`], textShadow: this.state.rxStyle[`text-shadow`], fontStyle: this.state.rxStyle[`font-style`], fontWeight: this.state.rxStyle[`font-weight`], fontVariant: this.state.rxStyle[`font-variant`] }, ref: this.refContainer, children: [this.state.editMode || this.state.rxData.button ? n(`div`, { style: { ...a.overlay, cursor: this.state.editMode ? void 0 : `pointer` }, onClick: !this.state.editMode && this.state.rxData.button ? () => this.onNavigate() : void 0 }) : null, t2 ? this.getWidgetView(t2, { style: i2 }) : null] });
    return this.state.rxData.noCard || e3.widget.usedInWidget ? s : this.wrapContent(s, null);
  }
};
export {
  o as default
};
