import { t as e } from "./vite-preload-helper-HclGiUj8.js";
let r, i;
let __tla = (async () => {
  var _a, _b;
  var t = `__mf_module_cache__`;
  globalThis[t] || (globalThis[t] = {
    share: {},
    remote: {}
  }), (_a = globalThis[t]).share || (_a.share = {}), (_b = globalThis[t]).remote || (_b.remote = {});
  var n = globalThis[t];
  for (let e2 of Object.keys(n.share)) if (e2.startsWith(`default:`)) {
    let t2 = e2.slice(8);
    n.share[t2] === void 0 && (n.share[t2] = n.share[e2]);
  } else if (!e2.includes(`:`)) {
    let t2 = `default:` + e2;
    n.share[t2] === void 0 && (n.share[t2] = n.share[e2]);
  }
  i = async function() {
    return r || (r = (async () => {
      let t2 = (e2, t3, n2, r3) => {
        let i3 = (Array.isArray(r3) ? r3[0] : r3) || `default`, a2 = t3 || !n2 ? e2 : e2 + `@` + n2, o2 = {
          canonical: i3 + `:` + a2
        };
        return i3 === "default" && (o2.aliases = [
          a2
        ]), o2;
      }, r2 = (e2, t3) => {
        let n2 = e2[t3.canonical];
        if (n2 !== void 0) return n2;
        let r3 = t3.aliases || [];
        for (let n3 of r3) {
          if (!Object.prototype.hasOwnProperty.call(e2, n3)) continue;
          let r4 = e2[n3];
          if (r4 !== void 0) return e2[t3.canonical] = r4, r4;
        }
      }, i2 = /* @__PURE__ */ Symbol.for(`module-federation.shared-cache-listeners`), a = /* @__PURE__ */ Symbol.for(`module-federation.shared-cache-owners`), o = (e2) => {
        let t3 = e2[a];
        return t3 === void 0 && (t3 = /* @__PURE__ */ Object.create(null), Object.defineProperty(e2, a, {
          value: t3,
          enumerable: false,
          configurable: false,
          writable: false
        })), t3;
      }, s = (e2, t3) => {
        var _a2;
        return (_a2 = e2[a]) == null ? void 0 : _a2[t3.canonical];
      }, c = (e2, t3, n2, r3) => {
        var _a2;
        e2[t3.canonical] = n2;
        let s2 = t3.aliases || [];
        for (let t4 of s2) Object.defineProperty(e2, t4, {
          value: n2,
          enumerable: true,
          configurable: true,
          writable: true
        });
        let c2 = e2[a];
        r3 === void 0 ? c2 && delete c2[t3.canonical] : o(e2)[t3.canonical] = r3;
        let l2 = (_a2 = e2[i2]) == null ? void 0 : _a2[t3.canonical];
        if (l2) for (let e3 of l2) e3(n2);
        return n2;
      }, l = await (await e(() => import("../customWidgets.js").then(async (m) => {
        await m.__tla;
        return m;
      }), [], import.meta.url)).init(), { usedShared: u } = await e(async () => {
        let { usedShared: e2 } = await import("./_virtual_mf-localSharedImportMap___mfe_internal__vis2nilsForkWidgets__mf_owner__1-DJF1wT9s.js").then(async (m) => {
          await m.__tla;
          return m;
        });
        return {
          usedShared: e2
        };
      }, [], import.meta.url), d = (e2) => {
        let t3 = e2;
        for (let e3 = 0; e3 < 5; e3++) {
          let e4 = t3 == null ? void 0 : t3.default;
          if (!e4 || typeof e4 != `object` || Object.keys(e4).length === 0) break;
          let n2 = Object.keys(t3).filter((e5) => e5 !== "default").map((e5) => t3[e5]);
          if (n2.length > 0 && n2.some((e5) => e5 !== void 0)) break;
          t3 = e4;
        }
        return t3;
      };
      for (let e2 of [
        [
          `react`,
          `moment`
        ],
        [
          `react/jsx-dev-runtime`,
          `react/jsx-runtime`,
          `react-dom`,
          `@emotion/react`,
          `@mui/private-theming`
        ],
        [
          `react-dom/client`,
          `@mui/system`
        ],
        [
          `@mui/material`
        ],
        [
          `@iobroker/gui-components`
        ]
      ]) await Promise.all(e2.map(async (e3) => {
        var _a2;
        let i3 = u[e3];
        if (!i3 || i3.materialize === false || i3.treeShaking) return;
        let a2 = t2(e3, (_a2 = i3.shareConfig) == null ? void 0 : _a2.singleton, i3.version, i3.scope);
        (r2(n.share, a2) === void 0 || s(n.share, a2) !== `vis2nilsForkWidgets`) && await l.loadShare(e3, {
          customShareInfo: {
            shareConfig: i3.shareConfig
          }
        }).then(async (e4) => {
          let t3 = typeof e4 == `function` ? e4() : e4, r3 = d(await Promise.resolve(t3));
          c(n.share, a2, r3, `vis2nilsForkWidgets`);
        });
      }));
      return l;
    })()), r;
  };
  r = i();
})();
export {
  __tla,
  r as hostInitPromise,
  i as initHost
};
