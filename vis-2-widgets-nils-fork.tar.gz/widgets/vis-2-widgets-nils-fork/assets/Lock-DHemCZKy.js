import { B as e } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_emotion_mf_1_react__loadShare__.js-CYJIHzbY.js";
import { D as t, F as n, H as r, I as i, L as a, M as o, P as s, f as c, ft as l, pt as u, u as d } from "./_virtual_mf___mfe_internal__vis2nilsForkWidgets__mf_owner__1__loadShare___mf_0_iobroker_mf_1_gui_mf_2_components__loadShare__.js-BSVWkIUS.js";
import { a as f, i as p, n as m, r as h, t as g } from "./LockIcon-BaqJjXJa.js";
import { t as _ } from "./Generic-BOiMPpxz.js";
import { t as v } from "./PinCodeDialog-BOKi9bwC.js";
e();
var y = { content: { width: `100%`, height: `100%`, display: `flex`, alignItems: `center`, justifyContent: `center`, flexWrap: `wrap` }, lockWorkingIcon: { position: `absolute`, top: 10, left: 10 }, lockSvgIcon: {} }, b = class e2 extends _ {
  constructor(e3) {
    super(e3), this.state = { ...this.state, dialogPin: false, lockPinInput: ``, invalidPin: false, confirmDialog: false };
  }
  static getWidgetInfo() {
    return { id: `tplNils2Lock`, visSet: `vis-2-widgets-nils-fork`, visName: `Lock`, visWidgetLabel: `lock`, visAttrs: [{ name: `common`, fields: [{ name: `noCard`, label: `without_card`, type: `checkbox`, hidden: `data.externalDialog === true`, noBinding: false }, { name: `widgetTitle`, label: `name`, hidden: `data.noCard === true || data.externalDialog === true` }, { name: `lock-oid`, type: `id`, label: `lock-oid`, onChange: async (e3, t2, n2, r2) => {
      if (t2[`lock-oid`]) {
        let i2 = await r2.getObject(t2[`lock-oid`]);
        if (i2 && i2.common && i2.common.role === `switch.lock`) {
          let i3 = t2[e3.name].split(`.`);
          i3.pop();
          let a2 = await r2.getObjectViewSystem(`state`, `${i3.join(`.`)}.`, `${i3.join(`.`)}.\u9999`);
          a2 && (Object.values(a2).forEach((e4) => {
            var _a;
            let n3 = (_a = e4.common) == null ? void 0 : _a.role;
            (n3 == null ? void 0 : n3.startsWith(`button`)) ? t2[`doorOpen-oid`] = e4._id : ((n3 == null ? void 0 : n3.includes(`direction`)) || (n3 == null ? void 0 : n3.includes(`working`))) && (t2[`lockWorking-oid`] = e4._id);
          }), n2(t2));
        }
      }
    } }, { name: `doorOpen-oid`, type: `id`, label: `doorOpen-oid` }, { name: `lockWorking-oid`, type: `id`, label: `lockWorking-oid`, hidden: (e3) => !e3[`lock-oid`] }, { name: `doorSensor-oid`, type: `id`, label: `doorSensor-oid` }, { name: `pincode`, label: `pincode`, onChange: (e3, t2, n2) => {
      var _a;
      return ((_a = t2.pincode) == null ? void 0 : _a.match(/[^0-9]/g)) && (t2.pincode = t2.pincode.replace(/[^0-9]/g, ``), n2(t2)), Promise.resolve();
    }, hidden: (e3) => !!e3[`pincode-oid`] }, { name: `pincode-oid`, type: `id`, label: `pincode_oid`, hidden: (e3) => !!e3.pincode }, { name: `doNotConfirm`, type: `checkbox`, label: `doNotConfirm`, hidden: (e3) => !!e3.pincode || !!e3[`pincode-oid`], noBinding: false }, { name: `pincodeReturnButton`, type: `select`, options: [`submit`, `backspace`], default: `submit`, label: `pincode_return_button`, hidden: (e3) => !!e3[`pincode-oid`] && !!e3.pincode }, { name: `doorSize`, label: `doorSize`, type: `slider`, min: 20, max: 500, default: 100, hidden: (e3) => !e3[`doorOpen-oid`] && !e3[`doorSensor-oid`] }, { name: `lockSize`, label: `lockSize`, type: `slider`, min: 15, max: 500, default: 40, hidden: (e3) => !e3[`lock-oid`] }, { name: `noLockAnimation`, label: `noLockAnimation`, type: `checkbox`, hidden: (e3) => !e3[`lock-oid`], noBinding: false }, { name: `lockColor`, label: `Lock color`, type: `color`, hidden: (e3) => !e3[`lock-oid`] || e3.noLockAnimation === true || e3.noLockAnimation === `true` }, { name: `externalDialog`, label: `use_as_dialog`, type: `checkbox`, tooltip: `use_as_dialog_tooltip`, noBinding: false }] }], visDefaultStyle: { width: `100%`, height: 240, position: `relative` }, visPrev: `widgets/vis-2-widgets-nils-fork/img/prev_lock.png` };
  }
  getWidgetInfo() {
    return e2.getWidgetInfo();
  }
  lockRenderUnlockDialog() {
    return this.state.dialogPin ? l(v, { pinCode: this.lockGetPinCode(), pinCodeReturnButton: this.state.rxData.pincodeReturnButton === `backspace` ? `backspace` : `submit`, onClose: (e3) => {
      e3 && (this.state.dialogPin === `doorOpen-oid` ? this.props.context.setValue(this.state.rxData[`doorOpen-oid`], true) : this.props.context.setValue(this.state.rxData[`lock-oid`], true)), this.setState({ dialogPin: false });
    } }) : null;
  }
  lockGetPinCode() {
    return this.state.rxData[`pincode-oid`] ? this.getPropertyValue(`pincode-oid`) : this.state.rxData.pincode;
  }
  lockRenderConfirmDialog() {
    return this.state.confirmDialog ? u(s, { open: true, onClose: () => this.setState({ confirmDialog: false }), children: [l(i, { children: _.t(`please_confirm`) }), u(n, { children: [l(t, { variant: `contained`, color: `primary`, onClick: () => {
      this.setState({ confirmDialog: false }), this.state.confirmDialog === `doorOpen-oid` ? this.props.context.setValue(this.state.rxData[`doorOpen-oid`], true) : this.props.context.setValue(this.state.rxData[`lock-oid`], true);
    }, startIcon: this.state.confirmDialog === `doorOpen-oid` ? l(h, {}) : l(p, {}), children: _.t(`Open`) }), l(t, { variant: `contained`, color: `grey`, autoFocus: true, onClick: () => this.setState({ confirmDialog: false }), startIcon: l(c, {}), children: _.t(`Cancel`) })] })] }) : null;
  }
  onCommand(e3) {
    let t2 = super.onCommand(e3);
    if (t2 === false) {
      if (e3 === `openDialog`) return this.setState({ dialog: true }), true;
      if (e3 === `closeDialog`) return this.setState({ dialog: false }), true;
    }
    return t2;
  }
  renderWidgetBody(e3) {
    super.renderWidgetBody(e3);
    let t2 = this.state.rxData[`doorSensor-oid`] && this.getPropertyValue(`doorSensor-oid`), n2 = this.getPropertyValue(`lock-oid`), c2 = this.state.rxData[`lockWorking-oid`] && this.getPropertyValue(`lockWorking-oid`);
    console.log(`Lock opened: ${n2}, oid: ${this.state.rxData[`lock-oid`]}, value: ${this.state.values[`${this.state.rxData[`lock-oid`]}.val`]}`);
    let h2 = u(`div`, { children: [this.lockRenderUnlockDialog(), this.lockRenderConfirmDialog(), this.state.rxData[`doorSensor-oid`] || this.state.rxData[`doorOpen-oid`] ? l(r, { disabled: !this.state.rxData[`doorOpen-oid`], title: this.state.rxData[`doorOpen-oid`] ? _.t(`open_door`) : void 0, onClick: () => {
      this.lockGetPinCode() ? this.setState({ dialogPin: `doorOpen-oid`, lockPinInput: `` }) : this.state.rxData.doNotConfirm === true || this.state.rxData.doNotConfirm === `true` ? this.props.context.setValue(this.state.rxData[`doorOpen-oid`], true) : this.setState({ confirmDialog: `doorOpen-oid` });
    }, children: l(m, { open: t2, size: this.state.rxData.doorSize }) }) : null, this.state.rxData[`lock-oid`] ? u(r, { title: n2 ? _.t(`close_lock`) : _.t(`open_lock`), onClick: () => {
      !n2 && this.lockGetPinCode() ? this.setState({ dialogPin: `lock-oid`, lockPinInput: `` }) : n2 || this.state.rxData.doNotConfirm === true || this.state.rxData.doNotConfirm === `true` ? this.props.context.setValue(this.state.rxData[`lock-oid`], !this.getPropertyValue(`lock-oid`)) : this.setState({ confirmDialog: `lock-oid` });
    }, children: [l(`style`, { children: `
.iob-lock {
    transition: transform 0.5s ease;
    transform-origin: 15px 60px;
}
.iob-lock-opened {
    transform: rotate(-30deg);
}
.iob-lock-closed {
    transform: rotate(0deg);
}
` }), c2 && c2 !== 3 ? l(o, { style: y.lockWorkingIcon, size: this.state.rxData.lockSize || 40 }) : null, this.state.rxData.noLockAnimation === true || this.state.rxData.noLockAnimation === `true` ? n2 ? l(p, { style: { ...y.lockSvgIcon, width: this.state.rxData.lockSize, height: this.state.rxData.lockSize }, sx: (e4) => ({ color: e4.palette.primary.main }) }) : l(f, { style: { ...y.lockSvgIcon, width: this.state.rxData.lockSize, height: this.state.rxData.lockSize } }) : l(g, { className: n2 ? `iob-lock iob-lock-opened` : `iob-lock iob-lock-closed`, opened: n2, style: { color: this.state.rxData.lockColor, height: this.state.rxData.lockSize, width: `auto` } })] }) : null] });
    return (this.state.rxData.externalDialog === true || this.state.rxData.externalDialog === `true`) && !this.props.editMode ? this.state.dialog ? u(s, { open: true, onClose: () => this.setState({ dialog: null }), children: [u(a, { children: [this.state.rxData.widgetTitle, l(r, { style: { float: `right`, zIndex: 2 }, onClick: () => this.setState({ dialog: null }), children: l(d, {}) })] }), l(i, { children: h2 })] }) : null : this.state.rxData.noCard === true || this.state.rxData.noCard === `true` || e3.widget.usedInWidget ? h2 : this.wrapContent(h2, null, { boxSizing: `border-box`, paddingBottom: 10, height: `100%` });
  }
};
export {
  b as default
};
